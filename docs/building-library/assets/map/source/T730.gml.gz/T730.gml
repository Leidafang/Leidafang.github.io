<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_d05e33f9-21d5-48ab-b6b9-1949cff6353e">
			<core:creationDate>2023-08-22</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>18</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103018002</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="再開発等促進区を定める地区計画">
				<gen:value>環状第二号線新橋・虎ノ門地区</gen:value>
			</gen:stringAttribute>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">401</bldg:usage>
			<bldg:measuredHeight uom="m">35.5</bldg:measuredHeight>
			<bldg:storeysAboveGround>10</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.66857335186189 139.74790384081498 0 35.668513254909314 139.74807852668673 0 35.66856349417285 139.74810443802053 0 35.668591357835425 139.748023548269 0 35.66860530718372 139.74803074978976 0 35.668624455737 139.7480406145003 0 35.66862632238682 139.7480353910617 0 35.668648560174674 139.74804685084936 0 35.668676682874164 139.7479652283647 0 35.66865438916069 139.74795372226197 0 35.66870059640105 139.74781926719092 0 35.668689231336316 139.74781341718506 0 35.66867746641383 139.74782456302228 0 35.66862431638908 139.74779714715075 0 35.668596508647994 139.74787787347347 0 35.66858543918608 139.74791006230643 0 35.66857335186189 139.74790384081498 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66857335186189 139.74790384081498 5.451 35.66858543918608 139.74791006230643 5.451 35.668596508647994 139.74787787347347 5.451 35.66862431638908 139.74779714715075 5.451 35.66867746641383 139.74782456302228 5.451 35.668689231336316 139.74781341718506 5.451 35.66870059640105 139.74781926719092 5.451 35.66865438916069 139.74795372226197 5.451 35.668676682874164 139.7479652283647 5.451 35.668648560174674 139.74804685084936 5.451 35.66862632238682 139.7480353910617 5.451 35.668624455737 139.7480406145003 5.451 35.66860530718372 139.74803074978976 5.451 35.668591357835425 139.748023548269 5.451 35.66856349417285 139.74810443802053 5.451 35.668513254909314 139.74807852668673 5.451 35.66857335186189 139.74790384081498 5.451</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66857335186189 139.74790384081498 5.451 35.668513254909314 139.74807852668673 5.451 35.668513254909314 139.74807852668673 37.323 35.66857335186189 139.74790384081498 37.323 35.66857335186189 139.74790384081498 5.451</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668513254909314 139.74807852668673 5.451 35.66856349417285 139.74810443802053 5.451 35.66856349417285 139.74810443802053 37.323 35.668513254909314 139.74807852668673 37.323 35.668513254909314 139.74807852668673 5.451</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66856349417285 139.74810443802053 5.451 35.668591357835425 139.748023548269 5.451 35.668591357835425 139.748023548269 37.323 35.66856349417285 139.74810443802053 37.323 35.66856349417285 139.74810443802053 5.451</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668591357835425 139.748023548269 5.451 35.66860530718372 139.74803074978976 5.451 35.66860530718372 139.74803074978976 37.323 35.668591357835425 139.748023548269 37.323 35.668591357835425 139.748023548269 5.451</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66860530718372 139.74803074978976 5.451 35.668624455737 139.7480406145003 5.451 35.668624455737 139.7480406145003 37.323 35.66860530718372 139.74803074978976 37.323 35.66860530718372 139.74803074978976 5.451</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668624455737 139.7480406145003 5.451 35.66862632238682 139.7480353910617 5.451 35.66862632238682 139.7480353910617 37.323 35.668624455737 139.7480406145003 37.323 35.668624455737 139.7480406145003 5.451</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66862632238682 139.7480353910617 5.451 35.668648560174674 139.74804685084936 5.451 35.668648560174674 139.74804685084936 37.323 35.66862632238682 139.7480353910617 37.323 35.66862632238682 139.7480353910617 5.451</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668648560174674 139.74804685084936 5.451 35.668676682874164 139.7479652283647 5.451 35.668676682874164 139.7479652283647 37.323 35.668648560174674 139.74804685084936 37.323 35.668648560174674 139.74804685084936 5.451</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668676682874164 139.7479652283647 5.451 35.66865438916069 139.74795372226197 5.451 35.66865438916069 139.74795372226197 37.323 35.668676682874164 139.7479652283647 37.323 35.668676682874164 139.7479652283647 5.451</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66865438916069 139.74795372226197 5.451 35.66870059640105 139.74781926719092 5.451 35.66870059640105 139.74781926719092 37.323 35.66865438916069 139.74795372226197 37.323 35.66865438916069 139.74795372226197 5.451</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66870059640105 139.74781926719092 5.451 35.668689231336316 139.74781341718506 5.451 35.668689231336316 139.74781341718506 37.323 35.66870059640105 139.74781926719092 37.323 35.66870059640105 139.74781926719092 5.451</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668689231336316 139.74781341718506 5.451 35.66867746641383 139.74782456302228 5.451 35.66867746641383 139.74782456302228 37.323 35.668689231336316 139.74781341718506 37.323 35.668689231336316 139.74781341718506 5.451</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66867746641383 139.74782456302228 5.451 35.66862431638908 139.74779714715075 5.451 35.66862431638908 139.74779714715075 37.323 35.66867746641383 139.74782456302228 37.323 35.66867746641383 139.74782456302228 5.451</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66862431638908 139.74779714715075 5.451 35.668596508647994 139.74787787347347 5.451 35.668596508647994 139.74787787347347 37.323 35.66862431638908 139.74779714715075 37.323 35.66862431638908 139.74779714715075 5.451</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668596508647994 139.74787787347347 5.451 35.66858543918608 139.74791006230643 5.451 35.66858543918608 139.74791006230643 37.323 35.668596508647994 139.74787787347347 37.323 35.668596508647994 139.74787787347347 5.451</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66858543918608 139.74791006230643 5.451 35.66857335186189 139.74790384081498 5.451 35.66857335186189 139.74790384081498 37.323 35.66858543918608 139.74791006230643 37.323 35.66858543918608 139.74791006230643 5.451</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66857335186189 139.74790384081498 37.323 35.668513254909314 139.74807852668673 37.323 35.66856349417285 139.74810443802053 37.323 35.668591357835425 139.748023548269 37.323 35.66860530718372 139.74803074978976 37.323 35.668624455737 139.7480406145003 37.323 35.66862632238682 139.7480353910617 37.323 35.668648560174674 139.74804685084936 37.323 35.668676682874164 139.7479652283647 37.323 35.66865438916069 139.74795372226197 37.323 35.66870059640105 139.74781926719092 37.323 35.668689231336316 139.74781341718506 37.323 35.66867746641383 139.74782456302228 37.323 35.66862431638908 139.74779714715075 37.323 35.668596508647994 139.74787787347347 37.323 35.66858543918608 139.74791006230643 37.323 35.66857335186189 139.74790384081498 37.323</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly_TMmnt0161_p994_0"/>
							<gml:surfaceMember xlink:href="#poly_TMmnt0161_p994_1"/>
							<gml:surfaceMember xlink:href="#poly_TMmnt0161_p994_2"/>
							<gml:surfaceMember xlink:href="#poly_TMmnt0161_p994_3"/>
							<gml:surfaceMember xlink:href="#poly_TMmnt0161_p994_4"/>
							<gml:surfaceMember xlink:href="#poly_TMmnt0161_p992_0"/>
							<gml:surfaceMember xlink:href="#poly_TMmnt0161_p992_1"/>
							<gml:surfaceMember xlink:href="#poly_TMmnt0161_p992_2"/>
							<gml:surfaceMember xlink:href="#poly_TMmnt0161_p992_3"/>
							<gml:surfaceMember xlink:href="#poly_TMmnt0161_p992_4"/>
							<gml:surfaceMember xlink:href="#poly_TMmnt0161_p992_5"/>
							<gml:surfaceMember xlink:href="#poly_TMmnt0161_p992_6"/>
							<gml:surfaceMember xlink:href="#poly_TMmnt0161_p992_7"/>
							<gml:surfaceMember xlink:href="#poly_TMmnt0161_p992_8"/>
							<gml:surfaceMember xlink:href="#poly_TMmnt0161_p993_0"/>
							<gml:surfaceMember xlink:href="#poly_TMmnt0161_p993_1"/>
							<gml:surfaceMember xlink:href="#poly_TMmnt0161_p993_2"/>
							<gml:surfaceMember xlink:href="#poly_TMmnt0161_p993_3"/>
							<gml:surfaceMember xlink:href="#poly_TMmnt0161_p993_4"/>
							<gml:surfaceMember xlink:href="#poly_TMmnt0161_p993_5"/>
							<gml:surfaceMember xlink:href="#poly_TMmnt0161_p993_6"/>
							<gml:surfaceMember xlink:href="#poly_TMmnt0161_p991_0"/>
							<gml:surfaceMember xlink:href="#poly_TMmnt0161_p991_1"/>
							<gml:surfaceMember xlink:href="#poly_TMmnt0161_p991_2"/>
							<gml:surfaceMember xlink:href="#poly_TMmnt0161_p991_3"/>
							<gml:surfaceMember xlink:href="#poly_TMmnt0161_p991_4"/>
							<gml:surfaceMember xlink:href="#poly_TMmnt0161_p991_5"/>
							<gml:surfaceMember xlink:href="#poly_TMmnt0161_b_0"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="gml_13d23a4c-b923-453b-97db-71b4bc15a16c">
					<bldg:lod3Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_ad5b9fb5-8b04-47ec-82c0-c180fb2aaaa0">
									<gml:exterior>
										<gml:LinearRing gml:id="line_4c0e3a81-81ca-4c62-8abb-fd1fc392044a">
											<gml:posList>35.668686432971406 139.74781918309426 9.79950745344442 35.668686432971406 139.74781918309426 9.355507209303795 35.66863472644675 139.74779309175605 9.79950745344442 35.668686432971406 139.74781918309426 9.79950745344442</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_54bd5185-7ccb-482e-b08d-42a63610a8d2">
									<gml:exterior>
										<gml:LinearRing gml:id="line_3912741c-b4b6-4bc2-a492-d16dca1f188e">
											<gml:posList>35.66863472644675 139.74779309175605 9.79950745344442 35.668686432971406 139.74781918309426 9.355507209303795 35.66863472644675 139.74779309175605 9.355507209303795 35.66863472644675 139.74779309175605 9.79950745344442</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_5be23790-5e7f-456f-8282-9b3734aa24d1">
									<gml:exterior>
										<gml:LinearRing gml:id="line_c86e459b-bc19-412c-979d-3b38f9cdc2e8">
											<gml:posList>35.66863472644675 139.74779309175605 9.79950745344442 35.66863472644675 139.74779309175605 9.355507209303795 35.66862094168115 139.74780303297814 9.79950745344442 35.66863472644675 139.74779309175605 9.79950745344442</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_35f92f14-d023-479e-88f9-0610b15d40b1">
									<gml:exterior>
										<gml:LinearRing gml:id="line_3a67f2f8-38c2-40fb-8ec1-aa5b6f989f34">
											<gml:posList>35.66862094168115 139.74780303297814 9.79950745344442 35.66863472644675 139.74779309175605 9.355507209303795 35.66862094168115 139.74780303297814 9.355507209303795 35.66862094168115 139.74780303297814 9.79950745344442</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_7370786d-d993-4f22-9603-fb7427e2a857">
									<gml:exterior>
										<gml:LinearRing gml:id="line_17303414-a8cf-43b2-9d38-a5826af5604f">
											<gml:posList>35.66862094168115 139.74780303297814 9.79950745344442 35.66862094168115 139.74780303297814 9.355507209303795 35.6686747729746 139.74783019638366 9.79950745344442 35.66862094168115 139.74780303297814 9.79950745344442</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_38d6ea3e-d2ab-4cb0-8ac5-cd598c837cc1">
									<gml:exterior>
										<gml:LinearRing gml:id="line_8f6f4257-a343-4653-9872-f67950cc537d">
											<gml:posList>35.6686747729746 139.74783019638366 9.79950745344442 35.66862094168115 139.74780303297814 9.355507209303795 35.6686747729746 139.74783019638366 9.355507209303795 35.6686747729746 139.74783019638366 9.79950745344442</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_c998c61f-3fb3-4bc7-aa91-ad596db86df5">
									<gml:exterior>
										<gml:LinearRing gml:id="line_735f5335-f512-47c7-95e3-10734a91b2c6">
											<gml:posList>35.6686747729746 139.74783019638366 9.79950745344442 35.6686747729746 139.74783019638366 9.355507209303795 35.668686432971406 139.74781918309426 9.79950745344442 35.6686747729746 139.74783019638366 9.79950745344442</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_52a520ad-1f6e-4c9a-a1b7-a3b5398d7db1">
									<gml:exterior>
										<gml:LinearRing gml:id="line_dfd4e2bb-671b-4f8d-a4fa-e9cc46ca4498">
											<gml:posList>35.668686432971406 139.74781918309426 9.79950745344442 35.6686747729746 139.74783019638366 9.355507209303795 35.668686432971406 139.74781918309426 9.355507209303795 35.668686432971406 139.74781918309426 9.79950745344442</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_f8d4e787-fa73-4aab-9dd5-0bfa761336fc">
									<gml:exterior>
										<gml:LinearRing gml:id="line_8dbc3670-e462-4a40-9d1a-2da2e55afbe1">
											<gml:posList>35.668686432971406 139.74781918309426 9.355507209303795 35.6686747729746 139.74783019638366 9.355507209303795 35.66862094168115 139.74780303297814 9.355507209303795 35.668686432971406 139.74781918309426 9.355507209303795</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_da3d7332-193c-4ab5-addf-6063e0e55aa3">
									<gml:exterior>
										<gml:LinearRing gml:id="line_1ce98560-2446-4bad-8e3c-446f6df5dfee">
											<gml:posList>35.668686432971406 139.74781918309426 9.355507209303795 35.66862094168115 139.74780303297814 9.355507209303795 35.66863472644675 139.74779309175605 9.355507209303795 35.668686432971406 139.74781918309426 9.355507209303795</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_ddef6bc9-73e7-47e3-bd95-590c300eed1b">
									<gml:exterior>
										<gml:LinearRing gml:id="line_bfd0ee59-1264-4d25-b7b1-95b34289af9a">
											<gml:posList>35.66863472644675 139.74779309175605 9.79950745344442 35.66862094168115 139.74780303297814 9.79950745344442 35.668686432971406 139.74781918309426 9.79950745344442 35.66863472644675 139.74779309175605 9.79950745344442</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_d52d2593-eca1-4e41-a189-e5bc317a80d8">
									<gml:exterior>
										<gml:LinearRing gml:id="line_1e0add10-4d5f-4150-b27b-44723e4c7993">
											<gml:posList>35.668686432971406 139.74781918309426 9.79950745344442 35.66862094168115 139.74780303297814 9.79950745344442 35.6686747729746 139.74783019638366 9.79950745344442 35.668686432971406 139.74781918309426 9.79950745344442</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="gml_a3e3cfb8-90f8-435d-961c-f9813fbdcad1">
					<bldg:lod3Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_c71e6bba-f87a-4fab-83e2-59f34b51acf9">
									<gml:exterior>
										<gml:LinearRing gml:id="line_156b6a5b-c850-4ac3-8c5d-57a24ac9e23b">
											<gml:posList>35.6686752542573 139.74783043925513 14.020202949049889 35.6686752542573 139.74783043925513 13.418846442702232 35.66868526091045 139.74782098748136 14.020202949049889 35.6686752542573 139.74783043925513 14.020202949049889</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_2dd84418-c9c9-4143-b3f3-59171c63effe">
									<gml:exterior>
										<gml:LinearRing gml:id="line_f815c054-6609-489d-9802-e8e13237275e">
											<gml:posList>35.66868526091045 139.74782098748136 14.020202949049889 35.6686752542573 139.74783043925513 13.418846442702232 35.66868526091045 139.74782098748136 13.418846442702232 35.66868526091045 139.74782098748136 14.020202949049889</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_599dc215-590e-4a2e-bd94-6500d43c7ae5">
									<gml:exterior>
										<gml:LinearRing gml:id="line_96fc3b21-2488-45af-8d74-91fb45c15aa4">
											<gml:posList>35.66868526091045 139.74782098748136 14.020202949049889 35.66868526091045 139.74782098748136 13.418846442702232 35.66868477962785 139.74782074477844 14.020202949049889 35.66868526091045 139.74782098748136 14.020202949049889</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_154557f9-cad2-48da-a312-9aa90064097a">
									<gml:exterior>
										<gml:LinearRing gml:id="line_6abe14e1-23fd-4cd8-af35-c41e668b1fe8">
											<gml:posList>35.66868477962785 139.74782074477844 14.020202949049889 35.66868526091045 139.74782098748136 13.418846442702232 35.66868477962785 139.74782074477844 13.418846442702232 35.66868477962785 139.74782074477844 14.020202949049889</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_2b015aca-6aa4-4f26-8ed5-c44d42b69db1">
									<gml:exterior>
										<gml:LinearRing gml:id="line_0c4f0591-726b-459e-8d16-3b3fbf17034d">
											<gml:posList>35.66868477962785 139.74782074477844 14.020202949049889 35.66868477962785 139.74782074477844 13.418846442702232 35.6686747729746 139.74783019638366 14.020202949049889 35.66868477962785 139.74782074477844 14.020202949049889</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_568a4b11-06e0-4509-82e9-9d1567e5356a">
									<gml:exterior>
										<gml:LinearRing gml:id="line_743e377d-0f06-4037-b1d4-276c27d5d637">
											<gml:posList>35.6686747729746 139.74783019638366 14.020202949049889 35.66868477962785 139.74782074477844 13.418846442702232 35.6686747729746 139.74783019638366 13.418846442702232 35.6686747729746 139.74783019638366 14.020202949049889</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_7b754173-0705-4008-9865-f8362cd438c5">
									<gml:exterior>
										<gml:LinearRing gml:id="line_8e80e837-8188-4ba0-a81b-04e6b464c368">
											<gml:posList>35.6686747729746 139.74783019638366 14.020202949049889 35.6686747729746 139.74783019638366 13.418846442702232 35.6686752542573 139.74783043925513 14.020202949049889 35.6686747729746 139.74783019638366 14.020202949049889</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_548ec358-cb63-45cc-b3fa-5630d9a1fdaf">
									<gml:exterior>
										<gml:LinearRing gml:id="line_d5d8a176-e503-4c8a-a4ed-ea40f5d91974">
											<gml:posList>35.6686752542573 139.74783043925513 14.020202949049889 35.6686747729746 139.74783019638366 13.418846442702232 35.6686752542573 139.74783043925513 13.418846442702232 35.6686752542573 139.74783043925513 14.020202949049889</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_6131f5e1-39d0-47a9-904f-ab569d5e31f7">
									<gml:exterior>
										<gml:LinearRing gml:id="line_0cd07e82-682e-45a9-8add-ce3c7751a017">
											<gml:posList>35.6686752542573 139.74783043925513 13.418846442702232 35.6686747729746 139.74783019638366 13.418846442702232 35.66868477962785 139.74782074477844 13.418846442702232 35.6686752542573 139.74783043925513 13.418846442702232</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_75d0f4fb-eb98-45f6-9bd9-387d6286dda4">
									<gml:exterior>
										<gml:LinearRing gml:id="line_37c67c9d-1579-4940-8b3e-fc0eb9e22f45">
											<gml:posList>35.6686752542573 139.74783043925513 13.418846442702232 35.66868477962785 139.74782074477844 13.418846442702232 35.66868526091045 139.74782098748136 13.418846442702232 35.6686752542573 139.74783043925513 13.418846442702232</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_c255ac07-836e-4561-beec-83da7c926101">
									<gml:exterior>
										<gml:LinearRing gml:id="line_faeee771-a3db-4343-adee-af5a4e5f1436">
											<gml:posList>35.66868526091045 139.74782098748136 14.020202949049889 35.66868477962785 139.74782074477844 14.020202949049889 35.6686752542573 139.74783043925513 14.020202949049889 35.66868526091045 139.74782098748136 14.020202949049889</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_02b64fec-f1c3-46d0-889e-cf644061fd9c">
									<gml:exterior>
										<gml:LinearRing gml:id="line_d9925eaa-552e-460b-a046-69d2ae8c74b3">
											<gml:posList>35.6686752542573 139.74783043925513 14.020202949049889 35.66868477962785 139.74782074477844 14.020202949049889 35.6686747729746 139.74783019638366 14.020202949049889 35.6686752542573 139.74783043925513 14.020202949049889</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="gml_17cdf945-cab5-4c28-ba69-816a59a4b27b">
					<bldg:lod3Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_fdcfe622-430d-4cfd-ab39-dc2412716aea">
									<gml:exterior>
										<gml:LinearRing gml:id="line_7d8b7904-fb5e-4d86-a478-b068d8683e71">
											<gml:posList>35.6686752542573 139.74783043925513 10.960441901686607 35.6686752542573 139.74783043925513 10.359085395338951 35.66868526091045 139.74782098748136 10.960441901686607 35.6686752542573 139.74783043925513 10.960441901686607</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_295f48a2-54ba-4c08-ace8-89947a71f8d5">
									<gml:exterior>
										<gml:LinearRing gml:id="line_77abc2d3-5834-47b6-8401-6444aabc1da4">
											<gml:posList>35.66868526091045 139.74782098748136 10.960441901686607 35.6686752542573 139.74783043925513 10.359085395338951 35.66868526091045 139.74782098748136 10.359085395338951 35.66868526091045 139.74782098748136 10.960441901686607</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_c417893c-9607-4341-a6ae-02276ec15b21">
									<gml:exterior>
										<gml:LinearRing gml:id="line_4c7e39fc-d621-4499-9298-51d23a321f69">
											<gml:posList>35.66868526091045 139.74782098748136 10.960441901686607 35.66868526091045 139.74782098748136 10.359085395338951 35.66868477962785 139.74782074477844 10.960441901686607 35.66868526091045 139.74782098748136 10.960441901686607</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_6317ee2b-156b-48c0-bb5e-096f58f001f4">
									<gml:exterior>
										<gml:LinearRing gml:id="line_3e06704e-54c5-4028-a512-5fb1cd628b4b">
											<gml:posList>35.66868477962785 139.74782074477844 10.960441901686607 35.66868526091045 139.74782098748136 10.359085395338951 35.66868477962785 139.74782074477844 10.359085395338951 35.66868477962785 139.74782074477844 10.960441901686607</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_796cbddc-f168-4fa8-9414-cb3eab14635b">
									<gml:exterior>
										<gml:LinearRing gml:id="line_a5f4bf11-75bf-4ce7-b5df-aab0585b1485">
											<gml:posList>35.66868477962785 139.74782074477844 10.960441901686607 35.66868477962785 139.74782074477844 10.359085395338951 35.6686747729746 139.74783019638366 10.960441901686607 35.66868477962785 139.74782074477844 10.960441901686607</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_a565cea0-7b84-4dc5-901b-672923f9daf7">
									<gml:exterior>
										<gml:LinearRing gml:id="line_754192c8-3622-4afb-be96-32477bc16ca9">
											<gml:posList>35.6686747729746 139.74783019638366 10.960441901686607 35.66868477962785 139.74782074477844 10.359085395338951 35.6686747729746 139.74783019638366 10.359085395338951 35.6686747729746 139.74783019638366 10.960441901686607</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_9937c61f-b4cf-4fed-a1d3-9c66046b858b">
									<gml:exterior>
										<gml:LinearRing gml:id="line_83509bb0-f0ba-4f3b-bd58-3ae7048f1e8d">
											<gml:posList>35.6686747729746 139.74783019638366 10.960441901686607 35.6686747729746 139.74783019638366 10.359085395338951 35.6686752542573 139.74783043925513 10.960441901686607 35.6686747729746 139.74783019638366 10.960441901686607</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_3d3dd3c1-0c88-424b-991c-ee396e8ddd82">
									<gml:exterior>
										<gml:LinearRing gml:id="line_66999d51-168a-4058-a6a2-88d46ea603f3">
											<gml:posList>35.6686752542573 139.74783043925513 10.960441901686607 35.6686747729746 139.74783019638366 10.359085395338951 35.6686752542573 139.74783043925513 10.359085395338951 35.6686752542573 139.74783043925513 10.960441901686607</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_9f04143d-f119-49a2-be20-1f0c0c6b1fb9">
									<gml:exterior>
										<gml:LinearRing gml:id="line_369606f7-344e-4100-b78b-acd40042059c">
											<gml:posList>35.6686752542573 139.74783043925513 10.359085395338951 35.6686747729746 139.74783019638366 10.359085395338951 35.66868477962785 139.74782074477844 10.359085395338951 35.6686752542573 139.74783043925513 10.359085395338951</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_e3854e2c-1d73-4144-9729-e58b6888f1b6">
									<gml:exterior>
										<gml:LinearRing gml:id="line_8ab1bdbf-df12-4aeb-ba26-5c5840aa1c9f">
											<gml:posList>35.6686752542573 139.74783043925513 10.359085395338951 35.66868477962785 139.74782074477844 10.359085395338951 35.66868526091045 139.74782098748136 10.359085395338951 35.6686752542573 139.74783043925513 10.359085395338951</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_fc4811d8-8c68-4472-a6cc-e9adcbe294e8">
									<gml:exterior>
										<gml:LinearRing gml:id="line_fbee3a10-444b-4eb0-937b-a0a3e2e634e9">
											<gml:posList>35.66868526091045 139.74782098748136 10.960441901686607 35.66868477962785 139.74782074477844 10.960441901686607 35.6686752542573 139.74783043925513 10.960441901686607 35.66868526091045 139.74782098748136 10.960441901686607</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_f4b3590c-8d9f-47d4-b247-c39398a39012">
									<gml:exterior>
										<gml:LinearRing gml:id="line_24a90e00-03c7-402a-a9e2-c0ece390bcb7">
											<gml:posList>35.6686752542573 139.74783043925513 10.960441901686607 35.66868477962785 139.74782074477844 10.960441901686607 35.6686747729746 139.74783019638366 10.960441901686607 35.6686752542573 139.74783043925513 10.960441901686607</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="gml_29306ffc-354f-47d8-8b23-5a68f31256fc">
					<bldg:lod3Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_8158113f-f254-4bfe-9fd6-09dabde1e6ba">
									<gml:exterior>
										<gml:LinearRing gml:id="line_ae45ac36-1b8f-410e-b684-ea6c3d99740c">
											<gml:posList>35.6686752542573 139.74783043925513 23.199493720534264 35.6686752542573 139.74783043925513 22.598137214186607 35.66868526091045 139.74782098748136 23.199493720534264 35.6686752542573 139.74783043925513 23.199493720534264</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_4f5ee8c0-cc05-40bb-86a0-7c8b7f5a0d4f">
									<gml:exterior>
										<gml:LinearRing gml:id="line_21c8e342-61c1-4e4c-bc67-b0b397885847">
											<gml:posList>35.66868526091045 139.74782098748136 23.199493720534264 35.6686752542573 139.74783043925513 22.598137214186607 35.66868526091045 139.74782098748136 22.598137214186607 35.66868526091045 139.74782098748136 23.199493720534264</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_4f22f54a-e9ec-469c-996a-37287db86cd6">
									<gml:exterior>
										<gml:LinearRing gml:id="line_099ef0d2-9564-45ba-8b9c-c0408f4190f8">
											<gml:posList>35.66868526091045 139.74782098748136 23.199493720534264 35.66868526091045 139.74782098748136 22.598137214186607 35.66868477962785 139.74782074477844 23.199493720534264 35.66868526091045 139.74782098748136 23.199493720534264</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_25e107f4-7537-456f-966e-9b9fa833c9fc">
									<gml:exterior>
										<gml:LinearRing gml:id="line_e645349b-8818-4c14-9853-b58a1162055b">
											<gml:posList>35.66868477962785 139.74782074477844 23.199493720534264 35.66868526091045 139.74782098748136 22.598137214186607 35.66868477962785 139.74782074477844 22.598137214186607 35.66868477962785 139.74782074477844 23.199493720534264</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_881a9ac2-3afa-454e-9b29-d575ed7c8da5">
									<gml:exterior>
										<gml:LinearRing gml:id="line_4a102155-17a1-46b2-9746-6335a077e02f">
											<gml:posList>35.66868477962785 139.74782074477844 23.199493720534264 35.66868477962785 139.74782074477844 22.598137214186607 35.6686747729746 139.74783019638366 23.199493720534264 35.66868477962785 139.74782074477844 23.199493720534264</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_a2bb7f83-83df-4d5e-a7e0-11d76b1a303b">
									<gml:exterior>
										<gml:LinearRing gml:id="line_6780eae5-9783-4f87-9f6d-7e7ca1f336d7">
											<gml:posList>35.6686747729746 139.74783019638366 23.199493720534264 35.66868477962785 139.74782074477844 22.598137214186607 35.6686747729746 139.74783019638366 22.598137214186607 35.6686747729746 139.74783019638366 23.199493720534264</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_6130a2ca-5c85-499b-a731-e7365da4054a">
									<gml:exterior>
										<gml:LinearRing gml:id="line_13eef6f4-cde8-4128-bb60-6504b7d0391d">
											<gml:posList>35.6686747729746 139.74783019638366 23.199493720534264 35.6686747729746 139.74783019638366 22.598137214186607 35.6686752542573 139.74783043925513 23.199493720534264 35.6686747729746 139.74783019638366 23.199493720534264</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_2b884363-c0fc-426a-a9b6-ac06755a7f00">
									<gml:exterior>
										<gml:LinearRing gml:id="line_3ebdb559-87e5-4803-9402-0898e4220593">
											<gml:posList>35.6686752542573 139.74783043925513 23.199493720534264 35.6686747729746 139.74783019638366 22.598137214186607 35.6686752542573 139.74783043925513 22.598137214186607 35.6686752542573 139.74783043925513 23.199493720534264</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_304acf4d-cb3a-4cbf-9bd7-30f29abb391e">
									<gml:exterior>
										<gml:LinearRing gml:id="line_1ffd6177-eef4-4c20-aa26-13a6ad8421e5">
											<gml:posList>35.6686752542573 139.74783043925513 22.598137214186607 35.6686747729746 139.74783019638366 22.598137214186607 35.66868477962785 139.74782074477844 22.598137214186607 35.6686752542573 139.74783043925513 22.598137214186607</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_2a80001e-7a39-45a7-b1d3-9eb8fd181877">
									<gml:exterior>
										<gml:LinearRing gml:id="line_839cd184-a3d1-456e-a371-8338e3415b49">
											<gml:posList>35.6686752542573 139.74783043925513 22.598137214186607 35.66868477962785 139.74782074477844 22.598137214186607 35.66868526091045 139.74782098748136 22.598137214186607 35.6686752542573 139.74783043925513 22.598137214186607</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_1c19d908-96e7-4fbd-9619-0a89ac3e0785">
									<gml:exterior>
										<gml:LinearRing gml:id="line_2746dac6-c2d1-4993-b7a3-37770a78ba13">
											<gml:posList>35.66868526091045 139.74782098748136 23.199493720534264 35.66868477962785 139.74782074477844 23.199493720534264 35.6686752542573 139.74783043925513 23.199493720534264 35.66868526091045 139.74782098748136 23.199493720534264</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_13f01c02-afa8-41f7-9e93-64b74eb2a8a5">
									<gml:exterior>
										<gml:LinearRing gml:id="line_68ef95c6-0ae9-4981-9852-3d5d7c806341">
											<gml:posList>35.6686752542573 139.74783043925513 23.199493720534264 35.66868477962785 139.74782074477844 23.199493720534264 35.6686747729746 139.74783019638366 23.199493720534264 35.6686752542573 139.74783043925513 23.199493720534264</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="gml_ff44c373-1fb7-48c1-9bde-38319cc1d876">
					<bldg:lod3Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_1d90d232-b000-4348-aece-bd7848921fa4">
									<gml:exterior>
										<gml:LinearRing gml:id="line_737b0686-72cd-4ea3-9657-877e5b2d636d">
											<gml:posList>35.6686752542573 139.74783043925513 29.319015815260826 35.6686752542573 139.74783043925513 28.71765930891317 35.66868526091045 139.74782098748136 29.319015815260826 35.6686752542573 139.74783043925513 29.319015815260826</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_2dbbc92c-7bd3-4131-8142-ae9a82142cd8">
									<gml:exterior>
										<gml:LinearRing gml:id="line_62f258d5-84f9-4641-a419-50efe154c1ee">
											<gml:posList>35.66868526091045 139.74782098748136 29.319015815260826 35.6686752542573 139.74783043925513 28.71765930891317 35.66868526091045 139.74782098748136 28.71765930891317 35.66868526091045 139.74782098748136 29.319015815260826</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_afcfe2f7-8724-4010-b5dd-f372afd2cdbd">
									<gml:exterior>
										<gml:LinearRing gml:id="line_e3648a4d-eceb-4478-bc0e-c73702154ab4">
											<gml:posList>35.66868526091045 139.74782098748136 29.319015815260826 35.66868526091045 139.74782098748136 28.71765930891317 35.66868477962785 139.74782074477844 29.319015815260826 35.66868526091045 139.74782098748136 29.319015815260826</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_7bc61acf-752d-42d6-8847-183080f75995">
									<gml:exterior>
										<gml:LinearRing gml:id="line_aaf4f229-8ab3-4890-ac30-bdbb66514f41">
											<gml:posList>35.66868477962785 139.74782074477844 29.319015815260826 35.66868526091045 139.74782098748136 28.71765930891317 35.66868477962785 139.74782074477844 28.71765930891317 35.66868477962785 139.74782074477844 29.319015815260826</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_bbf3838f-a99a-4204-8942-3e77f96de441">
									<gml:exterior>
										<gml:LinearRing gml:id="line_12017f61-b99d-4983-8fdc-86fcb2d19495">
											<gml:posList>35.66868477962785 139.74782074477844 29.319015815260826 35.66868477962785 139.74782074477844 28.71765930891317 35.6686747729746 139.74783019638366 29.319015815260826 35.66868477962785 139.74782074477844 29.319015815260826</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_71b8a1ea-728e-48a6-b4d8-e5e41ca25bca">
									<gml:exterior>
										<gml:LinearRing gml:id="line_b31be9ad-7e65-43f2-a657-951b20f5f386">
											<gml:posList>35.6686747729746 139.74783019638366 29.319015815260826 35.66868477962785 139.74782074477844 28.71765930891317 35.6686747729746 139.74783019638366 28.71765930891317 35.6686747729746 139.74783019638366 29.319015815260826</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_895fac5c-aa16-4172-9276-98d913a7e53b">
									<gml:exterior>
										<gml:LinearRing gml:id="line_b758bbdf-4c72-490a-90f0-8be098b80906">
											<gml:posList>35.6686747729746 139.74783019638366 29.319015815260826 35.6686747729746 139.74783019638366 28.71765930891317 35.6686752542573 139.74783043925513 29.319015815260826 35.6686747729746 139.74783019638366 29.319015815260826</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_adfdc048-4852-41e5-8b60-4b92ac79b504">
									<gml:exterior>
										<gml:LinearRing gml:id="line_1e5a832e-c47f-4c53-9c78-871e1267c3f6">
											<gml:posList>35.6686752542573 139.74783043925513 29.319015815260826 35.6686747729746 139.74783019638366 28.71765930891317 35.6686752542573 139.74783043925513 28.71765930891317 35.6686752542573 139.74783043925513 29.319015815260826</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_b731f67b-67d9-4eb3-9374-aebf07f516f7">
									<gml:exterior>
										<gml:LinearRing gml:id="line_b7792836-52d1-4604-a9a8-932066c05422">
											<gml:posList>35.6686752542573 139.74783043925513 28.71765930891317 35.6686747729746 139.74783019638366 28.71765930891317 35.66868477962785 139.74782074477844 28.71765930891317 35.6686752542573 139.74783043925513 28.71765930891317</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_de698494-c643-42d3-8d62-0211d4bbffc9">
									<gml:exterior>
										<gml:LinearRing gml:id="line_f4d2f6d7-9223-4daf-a6e9-d908eb397817">
											<gml:posList>35.6686752542573 139.74783043925513 28.71765930891317 35.66868477962785 139.74782074477844 28.71765930891317 35.66868526091045 139.74782098748136 28.71765930891317 35.6686752542573 139.74783043925513 28.71765930891317</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_547045f5-0644-4cab-aa74-87712261f603">
									<gml:exterior>
										<gml:LinearRing gml:id="line_7a3fe34f-0610-4776-885e-a3a62dc0a245">
											<gml:posList>35.66868526091045 139.74782098748136 29.319015815260826 35.66868477962785 139.74782074477844 29.319015815260826 35.6686752542573 139.74783043925513 29.319015815260826 35.66868526091045 139.74782098748136 29.319015815260826</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_4455682d-c2a3-4a72-9ef2-4aadab27882d">
									<gml:exterior>
										<gml:LinearRing gml:id="line_78a0c6eb-50b6-4a90-83d0-034082dc0cbf">
											<gml:posList>35.6686752542573 139.74783043925513 29.319015815260826 35.66868477962785 139.74782074477844 29.319015815260826 35.6686747729746 139.74783019638366 29.319015815260826 35.6686752542573 139.74783043925513 29.319015815260826</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="gml_f55ac2c4-d00d-4dda-84be-99c59a005ccd">
					<bldg:lod3Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_a09664bc-124b-4d9e-800d-a1b6d2d96fae">
									<gml:exterior>
										<gml:LinearRing gml:id="line_894bac0f-525d-41a8-89ba-d9d5ecb2b71f">
											<gml:posList>35.6686752542573 139.74783043925513 17.07996399641317 35.6686752542573 139.74783043925513 16.478615119460045 35.66868526091045 139.74782098748136 17.07996399641317 35.6686752542573 139.74783043925513 17.07996399641317</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_a369c373-702b-471f-927d-e6aa74475ecf">
									<gml:exterior>
										<gml:LinearRing gml:id="line_3ef4277d-cc78-489a-9d1e-9767a124efdb">
											<gml:posList>35.66868526091045 139.74782098748136 17.07996399641317 35.6686752542573 139.74783043925513 16.478615119460045 35.66868526091045 139.74782098748136 16.478615119460045 35.66868526091045 139.74782098748136 17.07996399641317</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_134269c3-420c-48ce-96c3-d46a6900031c">
									<gml:exterior>
										<gml:LinearRing gml:id="line_8811c991-2b28-4148-95ec-13c618d0e3b9">
											<gml:posList>35.66868526091045 139.74782098748136 17.07996399641317 35.66868526091045 139.74782098748136 16.478615119460045 35.66868477962785 139.74782074477844 17.07996399641317 35.66868526091045 139.74782098748136 17.07996399641317</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_13aa55d6-f97c-463e-9604-c4fe7911cb24">
									<gml:exterior>
										<gml:LinearRing gml:id="line_504ed2f0-9cf5-43fa-aacc-8f7e1f867cd2">
											<gml:posList>35.66868477962785 139.74782074477844 17.07996399641317 35.66868526091045 139.74782098748136 16.478615119460045 35.66868477962785 139.74782074477844 16.478615119460045 35.66868477962785 139.74782074477844 17.07996399641317</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_2da4255c-1947-471f-ad07-81b4fdd492a3">
									<gml:exterior>
										<gml:LinearRing gml:id="line_3eb66c17-b7c0-4b6a-ae6f-ae5641f3cc26">
											<gml:posList>35.66868477962785 139.74782074477844 17.07996399641317 35.66868477962785 139.74782074477844 16.478615119460045 35.6686747729746 139.74783019638366 17.07996399641317 35.66868477962785 139.74782074477844 17.07996399641317</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_917c87d9-2301-4d8e-b5e2-a1566b619530">
									<gml:exterior>
										<gml:LinearRing gml:id="line_20fdaf56-f4fe-4604-8907-166de4bebf73">
											<gml:posList>35.6686747729746 139.74783019638366 17.07996399641317 35.66868477962785 139.74782074477844 16.478615119460045 35.6686747729746 139.74783019638366 16.478615119460045 35.6686747729746 139.74783019638366 17.07996399641317</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_0e47cdd2-6801-4326-9d0c-1d7f09cd5182">
									<gml:exterior>
										<gml:LinearRing gml:id="line_98749531-ab85-4d94-a872-2ca5f097eb2a">
											<gml:posList>35.6686747729746 139.74783019638366 17.07996399641317 35.6686747729746 139.74783019638366 16.478615119460045 35.6686752542573 139.74783043925513 17.07996399641317 35.6686747729746 139.74783019638366 17.07996399641317</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_d1c9690e-2064-4c75-a5bf-96461df41f58">
									<gml:exterior>
										<gml:LinearRing gml:id="line_d3c339a6-ed35-491d-a8fd-86020b61be00">
											<gml:posList>35.6686752542573 139.74783043925513 17.07996399641317 35.6686747729746 139.74783019638366 16.478615119460045 35.6686752542573 139.74783043925513 16.478615119460045 35.6686752542573 139.74783043925513 17.07996399641317</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_97b92b70-d159-4ee4-b9a6-010a24167e73">
									<gml:exterior>
										<gml:LinearRing gml:id="line_adfdd723-5df1-4405-91a2-2d9679cad3ba">
											<gml:posList>35.6686752542573 139.74783043925513 16.478615119460045 35.6686747729746 139.74783019638366 16.478615119460045 35.66868477962785 139.74782074477844 16.478615119460045 35.6686752542573 139.74783043925513 16.478615119460045</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_3a05ee20-2509-4191-a517-5f89f45a9002">
									<gml:exterior>
										<gml:LinearRing gml:id="line_e48682cd-eded-4bb2-b347-b3fad34abd70">
											<gml:posList>35.6686752542573 139.74783043925513 16.478615119460045 35.66868477962785 139.74782074477844 16.478615119460045 35.66868526091045 139.74782098748136 16.478615119460045 35.6686752542573 139.74783043925513 16.478615119460045</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_39029e5d-e767-4121-b8ca-7998859df5b2">
									<gml:exterior>
										<gml:LinearRing gml:id="line_f631cac3-08c8-4141-b28f-83e41a4a9d7a">
											<gml:posList>35.66868526091045 139.74782098748136 17.07996399641317 35.66868477962785 139.74782074477844 17.07996399641317 35.6686752542573 139.74783043925513 17.07996399641317 35.66868526091045 139.74782098748136 17.07996399641317</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_9ba4b720-3f81-4182-9ec7-736bc86783c0">
									<gml:exterior>
										<gml:LinearRing gml:id="line_dfd2200d-5647-44de-a51c-7e4597861cd2">
											<gml:posList>35.6686752542573 139.74783043925513 17.07996399641317 35.66868477962785 139.74782074477844 17.07996399641317 35.6686747729746 139.74783019638366 17.07996399641317 35.6686752542573 139.74783043925513 17.07996399641317</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="gml_7f3eb833-321c-4454-8c21-34f673d0f45a">
					<bldg:lod3Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_be34e30e-995b-4bb3-801a-10bad77edb7c">
									<gml:exterior>
										<gml:LinearRing gml:id="line_e9d4c9de-7286-4388-b4ef-02eb04308cdc">
											<gml:posList>35.66869541480967 139.74780022405542 9.678757026198326 35.66869541480967 139.74780022405542 10.597503974440514 35.66870375291623 139.7478044314149 9.678757026198326 35.66869541480967 139.74780022405542 9.678757026198326</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_8ba8d163-4c23-4324-9ae9-b5930a0773f7">
									<gml:exterior>
										<gml:LinearRing gml:id="line_2bd516dd-8e34-4a44-9c67-bc1069827da6">
											<gml:posList>35.66870375291623 139.7478044314149 9.678757026198326 35.66869541480967 139.74780022405542 10.597503974440514 35.66870375291623 139.7478044314149 10.597503974440514 35.66870375291623 139.7478044314149 9.678757026198326</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_1ed905df-9869-49f1-9db5-3be3bc729bdd">
									<gml:exterior>
										<gml:LinearRing gml:id="line_20b80f90-7c5d-484e-898d-c96c0242e4dc">
											<gml:posList>35.66869541480967 139.74780022405542 10.597503974440514 35.66868866588641 139.74782030965406 10.597503974440514 35.66870375291623 139.7478044314149 10.597503974440514 35.66869541480967 139.74780022405542 10.597503974440514</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_2dc7fb00-32fc-497c-845f-917ba82023bc">
									<gml:exterior>
										<gml:LinearRing gml:id="line_5b73af88-92b4-4d26-8a38-6e1362ccf7ad">
											<gml:posList>35.66870375291623 139.7478044314149 10.597503974440514 35.66868866588641 139.74782030965406 10.597503974440514 35.6686970039924 139.74782451718383 10.597503974440514 35.66870375291623 139.7478044314149 10.597503974440514</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_56dada29-2895-4c15-a6af-aa1374cd583c">
									<gml:exterior>
										<gml:LinearRing gml:id="line_a676c510-ab81-4836-9632-869c4380aa51">
											<gml:posList>35.6686970039924 139.74782451718383 10.597503974440514 35.66870375291623 139.7478044314149 9.678757026198326 35.66870375291623 139.7478044314149 10.597503974440514 35.6686970039924 139.74782451718383 10.597503974440514</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_5ad5f493-8a90-4afe-80fb-758addbe44a8">
									<gml:exterior>
										<gml:LinearRing gml:id="line_16e39fb5-d0ac-475f-98eb-bdb02f280b8d">
											<gml:posList>35.66870375291623 139.7478044314149 9.678757026198326 35.6686970039924 139.74782451718383 6.3942492747334825 35.668709899453326 139.7477861386358 6.3942492747334825 35.66870375291623 139.7478044314149 9.678757026198326</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_04669880-4231-4bd2-8fbf-1d98517a200c">
									<gml:exterior>
										<gml:LinearRing gml:id="line_f15e70d7-18e7-43bf-9e64-c594c4312f92">
											<gml:posList>35.66870375291623 139.7478044314149 9.678757026198326 35.668709899453326 139.7477861386358 6.3942492747334825 35.668709899453326 139.7477861386358 9.678757026198326 35.66870375291623 139.7478044314149 9.678757026198326</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_21aec63f-989b-446e-9ef7-87629179c2c3">
									<gml:exterior>
										<gml:LinearRing gml:id="line_89eaa007-1368-4235-b616-cd8e03c4098a">
											<gml:posList>35.66869541480967 139.74780022405542 9.678757026198326 35.66870156120859 139.74778193127807 6.3942492747334825 35.66868866588641 139.74782030965406 6.3942492747334825 35.66869541480967 139.74780022405542 9.678757026198326</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_9d6bccb2-b0fe-4a25-a926-31ad8499107e">
									<gml:exterior>
										<gml:LinearRing gml:id="line_74cb9db0-c528-40af-9cfd-609a0ed29ceb">
											<gml:posList>35.66870156120859 139.74778193127807 6.3942492747334825 35.66869541480967 139.74780022405542 9.678757026198326 35.66870156120859 139.74778193127807 9.678757026198326 35.66870156120859 139.74778193127807 6.3942492747334825</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_9445ddc6-ad0c-4f44-8b88-ac864355c71a">
									<gml:exterior>
										<gml:LinearRing gml:id="line_88a164df-13b3-41b2-8f0d-830b29507acc">
											<gml:posList>35.66869541480967 139.74780022405542 9.678757026198326 35.66868866588641 139.74782030965406 10.597503974440514 35.66869541480967 139.74780022405542 10.597503974440514 35.66869541480967 139.74780022405542 9.678757026198326</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_735381f3-9273-412c-9c00-296f9f1c14f6">
									<gml:exterior>
										<gml:LinearRing gml:id="line_a9a63451-52c2-4f9d-b82a-96725a467048">
											<gml:posList>35.66870156120859 139.74778193127807 6.3942492747334825 35.66870156120859 139.74778193127807 9.678757026198326 35.668709899453326 139.7477861386358 6.3942492747334825 35.66870156120859 139.74778193127807 6.3942492747334825</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_f34552c1-6616-411c-adde-5532d2bf0436">
									<gml:exterior>
										<gml:LinearRing gml:id="line_ea04b57b-b679-42e2-9e4b-66947b8eea41">
											<gml:posList>35.668709899453326 139.7477861386358 6.3942492747334825 35.66870156120859 139.74778193127807 9.678757026198326 35.668709899453326 139.7477861386358 9.678757026198326 35.668709899453326 139.7477861386358 6.3942492747334825</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_9cb40bec-2dd5-4875-a60b-d62c6d3b174c">
									<gml:exterior>
										<gml:LinearRing gml:id="line_aeb08157-f993-4a6f-b38f-be23c3846435">
											<gml:posList>35.66869541480967 139.74780022405542 9.678757026198326 35.66870375291623 139.7478044314149 9.678757026198326 35.66870156120859 139.74778193127807 9.678757026198326 35.66869541480967 139.74780022405542 9.678757026198326</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_eaa3b191-c6f6-4080-8f58-5095eba38354">
									<gml:exterior>
										<gml:LinearRing gml:id="line_d05f0b5d-e421-4ea6-b09a-54037a11efb1">
											<gml:posList>35.66870156120859 139.74778193127807 9.678757026198326 35.66870375291623 139.7478044314149 9.678757026198326 35.668709899453326 139.7477861386358 9.678757026198326 35.66870156120859 139.74778193127807 9.678757026198326</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_4a64104a-ba09-45e3-bf4d-0478ac50196c">
									<gml:exterior>
										<gml:LinearRing gml:id="line_953ff3b6-724f-4bea-abb9-47b9271b40cd">
											<gml:posList>35.66868866588641 139.74782030965406 6.3942492747334825 35.66870156120859 139.74778193127807 6.3942492747334825 35.6686970039924 139.74782451718383 6.3942492747334825 35.66868866588641 139.74782030965406 6.3942492747334825</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_69ba7b06-3dbe-41fe-9dca-47d7bdd4cea1">
									<gml:exterior>
										<gml:LinearRing gml:id="line_9307b568-0c39-4d0a-b553-234afad0b9c8">
											<gml:posList>35.6686970039924 139.74782451718383 6.3942492747334825 35.66870156120859 139.74778193127807 6.3942492747334825 35.668709899453326 139.7477861386358 6.3942492747334825 35.6686970039924 139.74782451718383 6.3942492747334825</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_9d3383c7-7714-4f71-8d6d-f0510ee47242">
									<gml:exterior>
										<gml:LinearRing gml:id="line_0926c79d-9c2b-4363-baff-8f19f562e0db">
											<gml:posList>35.66868866588641 139.74782030965406 6.3942492747334825 35.66868866588641 139.74782030965406 9.355507209303795 35.66869541480967 139.74780022405542 9.678757026198326 35.66868866588641 139.74782030965406 6.3942492747334825</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_705fef16-11ae-40f3-86d2-fbf0cce8c2f4">
									<gml:exterior>
										<gml:LinearRing gml:id="line_1ed37f1d-9e32-4c9f-914a-f9a1b5ff2c5b">
											<gml:posList>35.66869541480967 139.74780022405542 9.678757026198326 35.66868866588641 139.74782030965406 9.355507209303795 35.66868866588641 139.74782030965406 10.597503974440514 35.66869541480967 139.74780022405542 9.678757026198326</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_50851a6d-3920-42e3-9f57-4242c2231141">
									<gml:exterior>
										<gml:LinearRing gml:id="line_91aaa793-d47d-4bb2-8db1-d7cf0040d8c2">
											<gml:posList>35.6686970039924 139.74782451718383 9.355507209303795 35.66868866588641 139.74782030965406 9.355507209303795 35.6686970039924 139.74782451718383 6.3942492747334825 35.6686970039924 139.74782451718383 9.355507209303795</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_569b80df-43f8-4483-9f4b-a310c8da74be">
									<gml:exterior>
										<gml:LinearRing gml:id="line_f36548c6-25e9-441f-9448-e2774e039457">
											<gml:posList>35.6686970039924 139.74782451718383 6.3942492747334825 35.66868866588641 139.74782030965406 9.355507209303795 35.66868866588641 139.74782030965406 6.3942492747334825 35.6686970039924 139.74782451718383 6.3942492747334825</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_de7ad068-3568-4fea-9389-8d37f339e641">
									<gml:exterior>
										<gml:LinearRing gml:id="line_024b2194-af8d-4847-b8f6-08c53b2e75f2">
											<gml:posList>35.6686970039924 139.74782451718383 10.597503974440514 35.66868866588641 139.74782030965406 10.597503974440514 35.6686970039924 139.74782451718383 9.355507209303795 35.6686970039924 139.74782451718383 10.597503974440514</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_8d668994-12b1-43b1-bac1-9c3b2fc1ae13">
									<gml:exterior>
										<gml:LinearRing gml:id="line_d90a98d9-5f2f-4ab5-b01f-620a1170575c">
											<gml:posList>35.6686970039924 139.74782451718383 9.355507209303795 35.66868866588641 139.74782030965406 10.597503974440514 35.66868866588641 139.74782030965406 9.355507209303795 35.6686970039924 139.74782451718383 9.355507209303795</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_51e271e9-44b4-4079-ba80-bded8f02ce13">
									<gml:exterior>
										<gml:LinearRing gml:id="line_4aeb66cf-ead9-4c17-936f-e2b6e3324e70">
											<gml:posList>35.66870375291623 139.7478044314149 9.678757026198326 35.6686970039924 139.74782451718383 10.597503974440514 35.6686970039924 139.74782451718383 9.355507209303795 35.66870375291623 139.7478044314149 9.678757026198326</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_5a5a7dfe-a9c3-48a5-b2ee-4e47de1da93d">
									<gml:exterior>
										<gml:LinearRing gml:id="line_67abf10d-400c-4a7b-9647-ebb016eb220a">
											<gml:posList>35.66870375291623 139.7478044314149 9.678757026198326 35.6686970039924 139.74782451718383 9.355507209303795 35.6686970039924 139.74782451718383 6.3942492747334825 35.66870375291623 139.7478044314149 9.678757026198326</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="gml_da4bb305-377b-4adc-aaed-678c2f9724e5">
					<bldg:lod3Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_a8e7d81e-edac-46f1-b71b-edd13d7f46eb">
									<gml:exterior>
										<gml:LinearRing gml:id="line_2f482ce4-7ec4-4296-8aa3-5429d1e41633">
											<gml:posList>35.6686752542573 139.74783043925513 26.259254767897545 35.6686752542573 139.74783043925513 25.65789826154989 35.66868526091045 139.74782098748136 26.259254767897545 35.6686752542573 139.74783043925513 26.259254767897545</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_fd755f04-86a3-4e98-8ec7-0b8c3929ae90">
									<gml:exterior>
										<gml:LinearRing gml:id="line_cc2d3a9f-3f01-4569-823a-52a2be206a0b">
											<gml:posList>35.66868526091045 139.74782098748136 26.259254767897545 35.6686752542573 139.74783043925513 25.65789826154989 35.66868526091045 139.74782098748136 25.65789826154989 35.66868526091045 139.74782098748136 26.259254767897545</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_7b0aaffc-0320-4318-a96a-73f9db3cf81b">
									<gml:exterior>
										<gml:LinearRing gml:id="line_43640c94-feaa-428b-9b1b-1bd4cc14628c">
											<gml:posList>35.66868526091045 139.74782098748136 26.259254767897545 35.66868526091045 139.74782098748136 25.65789826154989 35.66868477962785 139.74782074477844 26.259254767897545 35.66868526091045 139.74782098748136 26.259254767897545</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_12726a3a-cdf8-46e2-8a4b-fac1b198a815">
									<gml:exterior>
										<gml:LinearRing gml:id="line_ab1e8353-c41d-4ea4-bc1d-8e27930f98f2">
											<gml:posList>35.66868477962785 139.74782074477844 26.259254767897545 35.66868526091045 139.74782098748136 25.65789826154989 35.66868477962785 139.74782074477844 25.65789826154989 35.66868477962785 139.74782074477844 26.259254767897545</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_ca3dc51c-f609-467a-88f4-90b59e0bba92">
									<gml:exterior>
										<gml:LinearRing gml:id="line_9c84f1e2-52bf-46c6-8e0a-4177dbb6bb32">
											<gml:posList>35.66868477962785 139.74782074477844 26.259254767897545 35.66868477962785 139.74782074477844 25.65789826154989 35.6686747729746 139.74783019638366 26.259254767897545 35.66868477962785 139.74782074477844 26.259254767897545</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_b0555b32-df8e-4fdc-9299-ebbb077221c8">
									<gml:exterior>
										<gml:LinearRing gml:id="line_d1ee2573-8db6-4cde-b720-f14408083209">
											<gml:posList>35.6686747729746 139.74783019638366 26.259254767897545 35.66868477962785 139.74782074477844 25.65789826154989 35.6686747729746 139.74783019638366 25.65789826154989 35.6686747729746 139.74783019638366 26.259254767897545</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_267c3394-870c-48e0-8e09-a80c8bb2bc3c">
									<gml:exterior>
										<gml:LinearRing gml:id="line_dc323cf4-2907-4b03-b401-f3fadd7dab08">
											<gml:posList>35.6686747729746 139.74783019638366 26.259254767897545 35.6686747729746 139.74783019638366 25.65789826154989 35.6686752542573 139.74783043925513 26.259254767897545 35.6686747729746 139.74783019638366 26.259254767897545</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_f4753568-5642-40c7-b1e7-7a06cf640286">
									<gml:exterior>
										<gml:LinearRing gml:id="line_eec85174-b83c-46a6-beca-e100ef327890">
											<gml:posList>35.6686752542573 139.74783043925513 26.259254767897545 35.6686747729746 139.74783019638366 25.65789826154989 35.6686752542573 139.74783043925513 25.65789826154989 35.6686752542573 139.74783043925513 26.259254767897545</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_218d6c67-002f-4b67-8eab-5bc5e2af3b06">
									<gml:exterior>
										<gml:LinearRing gml:id="line_9403d477-6cb0-4808-958d-b6c9cbd3b4fc">
											<gml:posList>35.6686752542573 139.74783043925513 25.65789826154989 35.6686747729746 139.74783019638366 25.65789826154989 35.66868477962785 139.74782074477844 25.65789826154989 35.6686752542573 139.74783043925513 25.65789826154989</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_284f2cda-ea9e-4b74-9dd2-f0b2be1f396f">
									<gml:exterior>
										<gml:LinearRing gml:id="line_23312233-f2b3-49a6-a90a-ee106ba62430">
											<gml:posList>35.6686752542573 139.74783043925513 25.65789826154989 35.66868477962785 139.74782074477844 25.65789826154989 35.66868526091045 139.74782098748136 25.65789826154989 35.6686752542573 139.74783043925513 25.65789826154989</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_c4766b33-a6fb-4a49-98f8-cb4184200294">
									<gml:exterior>
										<gml:LinearRing gml:id="line_bd279d72-6d92-46c5-8df8-ef6f4e43c9b6">
											<gml:posList>35.66868526091045 139.74782098748136 26.259254767897545 35.66868477962785 139.74782074477844 26.259254767897545 35.6686752542573 139.74783043925513 26.259254767897545 35.66868526091045 139.74782098748136 26.259254767897545</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_297ff2a3-3a2c-47f4-b7f2-bfd12d688a0e">
									<gml:exterior>
										<gml:LinearRing gml:id="line_cd379528-b768-4113-864a-10ddafa26b1f">
											<gml:posList>35.6686752542573 139.74783043925513 26.259254767897545 35.66868477962785 139.74782074477844 26.259254767897545 35.6686747729746 139.74783019638366 26.259254767897545 35.6686752542573 139.74783043925513 26.259254767897545</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="gml_c083a8d5-887e-4bd2-90ef-49997e5581c3">
					<bldg:lod3Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_1491b227-1575-46b9-9646-e81bb44e0a2b">
									<gml:exterior>
										<gml:LinearRing gml:id="line_ef50e737-d748-4d49-a3e0-d41488204b87">
											<gml:posList>35.66853762841625 139.74809236806965 8.685997321608482 35.66853762841625 139.74809236806965 9.23169739485067 35.668512412421634 139.748079644004 8.685997321608482 35.66853762841625 139.74809236806965 8.685997321608482</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_54b8a4df-968d-44c1-94db-ca01fe44481f">
									<gml:exterior>
										<gml:LinearRing gml:id="line_83b9e4e4-4333-4dcd-a0c9-3328758a687e">
											<gml:posList>35.668512412421634 139.748079644004 8.685997321608482 35.66853762841625 139.74809236806965 9.23169739485067 35.668512412421634 139.748079644004 9.23169739485067 35.668512412421634 139.748079644004 8.685997321608482</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_47ea3cef-4102-40e2-a6e5-8b8f672e0491">
									<gml:exterior>
										<gml:LinearRing gml:id="line_c8442719-9430-4181-90e9-c3933c6eadec">
											<gml:posList>35.66853793887452 139.7480914439243 8.685997321608482 35.66853793887452 139.7480914439243 9.23169739485067 35.66853762841625 139.74809236806965 8.685997321608482 35.66853793887452 139.7480914439243 8.685997321608482</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_3fd43386-87c5-4b99-bcc5-a7ff3105f6c3">
									<gml:exterior>
										<gml:LinearRing gml:id="line_31231b90-f777-4e03-b132-3d51bc59fd7b">
											<gml:posList>35.66853762841625 139.74809236806965 8.685997321608482 35.66853793887452 139.7480914439243 9.23169739485067 35.66853762841625 139.74809236806965 9.23169739485067 35.66853762841625 139.74809236806965 8.685997321608482</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_4b5f8138-94fa-441d-88ff-7fcb110ec883">
									<gml:exterior>
										<gml:LinearRing gml:id="line_e47fe760-761f-4663-8b09-2a1f5a2d0480">
											<gml:posList>35.66851272301735 139.74807871985874 8.685997321608482 35.66851272301735 139.74807871985874 9.23169739485067 35.66853793887452 139.7480914439243 8.685997321608482 35.66851272301735 139.74807871985874 8.685997321608482</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_6c7cd6b4-6f44-4eb1-ad42-4210892f3065">
									<gml:exterior>
										<gml:LinearRing gml:id="line_5f51296c-487c-4334-9c55-6c9db0a81d4d">
											<gml:posList>35.66853793887452 139.7480914439243 8.685997321608482 35.66851272301735 139.74807871985874 9.23169739485067 35.66853793887452 139.7480914439243 9.23169739485067 35.66853793887452 139.7480914439243 8.685997321608482</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_59009f70-bdd7-43ec-94ad-8d87954846a2">
									<gml:exterior>
										<gml:LinearRing gml:id="line_77e93599-0789-48d0-b47b-47fd9d68cecb">
											<gml:posList>35.668512412421634 139.748079644004 8.685997321608482 35.668512412421634 139.748079644004 9.23169739485067 35.66851272301735 139.74807871985874 8.685997321608482 35.668512412421634 139.748079644004 8.685997321608482</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_743326ff-af93-4c0b-a32f-767c3fcd97c4">
									<gml:exterior>
										<gml:LinearRing gml:id="line_939f6415-4ea9-4c76-8f05-e52af6f77c4a">
											<gml:posList>35.66851272301735 139.74807871985874 8.685997321608482 35.668512412421634 139.748079644004 9.23169739485067 35.66851272301735 139.74807871985874 9.23169739485067 35.66851272301735 139.74807871985874 8.685997321608482</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_04a043ca-5fb9-4fbb-abcf-a49b135f7e77">
									<gml:exterior>
										<gml:LinearRing gml:id="line_c00a7c5f-119e-445d-9259-c67dfe3f71f9">
											<gml:posList>35.66853762841625 139.74809236806965 9.23169739485067 35.66853793887452 139.7480914439243 9.23169739485067 35.668512412421634 139.748079644004 9.23169739485067 35.66853762841625 139.74809236806965 9.23169739485067</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_87022e28-d74b-4e2b-ad49-8b3582e7a810">
									<gml:exterior>
										<gml:LinearRing gml:id="line_c9447e6a-56f4-4326-bec0-477de3bc3194">
											<gml:posList>35.668512412421634 139.748079644004 9.23169739485067 35.66853793887452 139.7480914439243 9.23169739485067 35.66851272301735 139.74807871985874 9.23169739485067 35.668512412421634 139.748079644004 9.23169739485067</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_97c4db1a-17f5-4208-85d6-1ca8dc50d5d0">
									<gml:exterior>
										<gml:LinearRing gml:id="line_ee010606-3e74-4581-8046-b62c4e2f10d3">
											<gml:posList>35.668512412421634 139.748079644004 8.685997321608482 35.66851272301735 139.74807871985874 8.685997321608482 35.66853793887452 139.7480914439243 8.685997321608482 35.668512412421634 139.748079644004 8.685997321608482</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_8e0e5ae0-fedf-4378-ba71-a28e12d8ecc4">
									<gml:exterior>
										<gml:LinearRing gml:id="line_fcb1e772-69a2-476d-9e02-72b59a725d8b">
											<gml:posList>35.668512412421634 139.748079644004 8.685997321608482 35.66853793887452 139.7480914439243 8.685997321608482 35.66853762841625 139.74809236806965 8.685997321608482 35.668512412421634 139.748079644004 8.685997321608482</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="gml_81eb8cf7-5f72-4fdf-9742-9c00fa46e1e3">
					<bldg:lod3Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_6091d404-757a-4e08-84f8-f34a56825aa1">
									<gml:exterior>
										<gml:LinearRing gml:id="line_12e7372d-ed50-4e8b-80d5-5492b5eddbe2">
											<gml:posList>35.6686752542573 139.74783043925513 20.139732673170982 35.6686752542573 139.74783043925513 19.538376166823326 35.66868526091045 139.74782098748136 20.139732673170982 35.6686752542573 139.74783043925513 20.139732673170982</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_3e177bc1-1a19-42c4-b3af-b62154a856ea">
									<gml:exterior>
										<gml:LinearRing gml:id="line_fdd019e6-6277-4590-8fd5-cb904e07832d">
											<gml:posList>35.66868526091045 139.74782098748136 20.139732673170982 35.6686752542573 139.74783043925513 19.538376166823326 35.66868526091045 139.74782098748136 19.538376166823326 35.66868526091045 139.74782098748136 20.139732673170982</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_079f12c9-c0c0-45b1-b7e4-138e102e7b75">
									<gml:exterior>
										<gml:LinearRing gml:id="line_4820bb37-9532-4869-9bad-72d078666a2d">
											<gml:posList>35.66868526091045 139.74782098748136 20.139732673170982 35.66868526091045 139.74782098748136 19.538376166823326 35.66868477962785 139.74782074477844 20.139732673170982 35.66868526091045 139.74782098748136 20.139732673170982</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_a073edff-fb3d-42f6-92d5-282bd7964d58">
									<gml:exterior>
										<gml:LinearRing gml:id="line_cbafbc12-7608-425c-a831-00156c718335">
											<gml:posList>35.66868477962785 139.74782074477844 20.139732673170982 35.66868526091045 139.74782098748136 19.538376166823326 35.66868477962785 139.74782074477844 19.538376166823326 35.66868477962785 139.74782074477844 20.139732673170982</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_8fb19d46-b24a-45ae-8817-7a3f367f0465">
									<gml:exterior>
										<gml:LinearRing gml:id="line_c46d03b1-d521-480f-b0f8-2936690e30e3">
											<gml:posList>35.66868477962785 139.74782074477844 20.139732673170982 35.66868477962785 139.74782074477844 19.538376166823326 35.6686747729746 139.74783019638366 20.139732673170982 35.66868477962785 139.74782074477844 20.139732673170982</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_785df1ef-c030-482c-bdcc-93ce142f1a39">
									<gml:exterior>
										<gml:LinearRing gml:id="line_a9d25811-d6ba-4a70-81b9-fac19a864836">
											<gml:posList>35.6686747729746 139.74783019638366 20.139732673170982 35.66868477962785 139.74782074477844 19.538376166823326 35.6686747729746 139.74783019638366 19.538376166823326 35.6686747729746 139.74783019638366 20.139732673170982</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_b89f534d-6587-4bf7-a265-1f69ae0c175e">
									<gml:exterior>
										<gml:LinearRing gml:id="line_56228131-889d-48b7-a735-d02739f3ada6">
											<gml:posList>35.6686747729746 139.74783019638366 20.139732673170982 35.6686747729746 139.74783019638366 19.538376166823326 35.6686752542573 139.74783043925513 20.139732673170982 35.6686747729746 139.74783019638366 20.139732673170982</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_08075f08-009a-49e3-97ca-a99536073d13">
									<gml:exterior>
										<gml:LinearRing gml:id="line_76659d56-f512-49f0-bdde-9f3f3fddafe7">
											<gml:posList>35.6686752542573 139.74783043925513 20.139732673170982 35.6686747729746 139.74783019638366 19.538376166823326 35.6686752542573 139.74783043925513 19.538376166823326 35.6686752542573 139.74783043925513 20.139732673170982</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_3642b590-d99d-4bb5-8a37-615140a052ac">
									<gml:exterior>
										<gml:LinearRing gml:id="line_dee55f42-6a97-4487-8206-ddd666dd4216">
											<gml:posList>35.6686752542573 139.74783043925513 19.538376166823326 35.6686747729746 139.74783019638366 19.538376166823326 35.66868477962785 139.74782074477844 19.538376166823326 35.6686752542573 139.74783043925513 19.538376166823326</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_9d0716bc-4fde-4b13-9756-a04a446331e7">
									<gml:exterior>
										<gml:LinearRing gml:id="line_438799cb-636a-4295-9010-9d96f4f7c21b">
											<gml:posList>35.6686752542573 139.74783043925513 19.538376166823326 35.66868477962785 139.74782074477844 19.538376166823326 35.66868526091045 139.74782098748136 19.538376166823326 35.6686752542573 139.74783043925513 19.538376166823326</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_d4975de3-a4fd-4f9a-8d74-576e9eb9ed42">
									<gml:exterior>
										<gml:LinearRing gml:id="line_a8713735-2f4a-4a59-b6c0-ff7ccce120df">
											<gml:posList>35.66868526091045 139.74782098748136 20.139732673170982 35.66868477962785 139.74782074477844 20.139732673170982 35.6686752542573 139.74783043925513 20.139732673170982 35.66868526091045 139.74782098748136 20.139732673170982</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_5f13414c-b5e8-4bcf-a7d8-3d7f9ceee164">
									<gml:exterior>
										<gml:LinearRing gml:id="line_6f2369ac-d805-41f9-84b0-14bdc6ba062f">
											<gml:posList>35.6686752542573 139.74783043925513 20.139732673170982 35.66868477962785 139.74782074477844 20.139732673170982 35.6686747729746 139.74783019638366 20.139732673170982 35.6686752542573 139.74783043925513 20.139732673170982</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="gml_98b5d57c-2dd4-4672-ad83-e8c32654f5f1">
					<bldg:lod3Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_6b09e8a5-3a23-4d51-b9c9-a22fa47c062e">
									<gml:exterior>
										<gml:LinearRing gml:id="line_e8b7f8a1-f132-47ef-a5a2-20e649279129">
											<gml:posList>35.6686752542573 139.74783043925513 32.37877686262411 35.6686752542573 139.74783043925513 31.77742035627645 35.66868526091045 139.74782098748136 32.37877686262411 35.6686752542573 139.74783043925513 32.37877686262411</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_dc427cf7-5ab2-40b5-b04b-4de00666749b">
									<gml:exterior>
										<gml:LinearRing gml:id="line_1c4c27af-a89e-471d-a7f0-928632c64cd3">
											<gml:posList>35.66868526091045 139.74782098748136 32.37877686262411 35.6686752542573 139.74783043925513 31.77742035627645 35.66868526091045 139.74782098748136 31.77742035627645 35.66868526091045 139.74782098748136 32.37877686262411</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_c36b8f6f-cb9e-4984-b33f-5765a7b32016">
									<gml:exterior>
										<gml:LinearRing gml:id="line_f8510a7a-ae9e-41e4-bee5-ca2f456b11c6">
											<gml:posList>35.66868526091045 139.74782098748136 32.37877686262411 35.66868526091045 139.74782098748136 31.77742035627645 35.66868477962785 139.74782074477844 32.37877686262411 35.66868526091045 139.74782098748136 32.37877686262411</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_27a9ab45-1c5f-4b25-9617-c0f209fef670">
									<gml:exterior>
										<gml:LinearRing gml:id="line_22df1348-bb83-4bd2-a9d6-baec25b82441">
											<gml:posList>35.66868477962785 139.74782074477844 32.37877686262411 35.66868526091045 139.74782098748136 31.77742035627645 35.66868477962785 139.74782074477844 31.77742035627645 35.66868477962785 139.74782074477844 32.37877686262411</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_04c6a773-5838-4f50-a08b-743d1e870113">
									<gml:exterior>
										<gml:LinearRing gml:id="line_71763841-d0d8-4c8f-bf6f-663e0eeca50a">
											<gml:posList>35.66868477962785 139.74782074477844 32.37877686262411 35.66868477962785 139.74782074477844 31.77742035627645 35.6686747729746 139.74783019638366 32.37877686262411 35.66868477962785 139.74782074477844 32.37877686262411</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_249cc47e-6ed8-4ee4-9ed3-ba44a456bc85">
									<gml:exterior>
										<gml:LinearRing gml:id="line_2ec2fbc5-e671-451b-95a7-66dff1e5084a">
											<gml:posList>35.6686747729746 139.74783019638366 32.37877686262411 35.66868477962785 139.74782074477844 31.77742035627645 35.6686747729746 139.74783019638366 31.77742035627645 35.6686747729746 139.74783019638366 32.37877686262411</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_a1718e34-3a64-4641-81be-86abe6ccd731">
									<gml:exterior>
										<gml:LinearRing gml:id="line_30e026ff-d5bf-4f65-a203-bbab691b0982">
											<gml:posList>35.6686747729746 139.74783019638366 32.37877686262411 35.6686747729746 139.74783019638366 31.77742035627645 35.6686752542573 139.74783043925513 32.37877686262411 35.6686747729746 139.74783019638366 32.37877686262411</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_6aa2e635-4957-467c-a3a3-210c71fb1995">
									<gml:exterior>
										<gml:LinearRing gml:id="line_966e409a-70f7-4cc4-9393-15361676ee9d">
											<gml:posList>35.6686752542573 139.74783043925513 32.37877686262411 35.6686747729746 139.74783019638366 31.77742035627645 35.6686752542573 139.74783043925513 31.77742035627645 35.6686752542573 139.74783043925513 32.37877686262411</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_746213b0-3bca-4b85-a75a-89d7dcc87638">
									<gml:exterior>
										<gml:LinearRing gml:id="line_114f016f-15da-45e5-9347-72e15f0db29e">
											<gml:posList>35.6686752542573 139.74783043925513 31.77742035627645 35.6686747729746 139.74783019638366 31.77742035627645 35.66868477962785 139.74782074477844 31.77742035627645 35.6686752542573 139.74783043925513 31.77742035627645</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_65ca9c61-1d8b-4fd1-9a4f-416c50a86d06">
									<gml:exterior>
										<gml:LinearRing gml:id="line_92d22d2d-af76-4823-9a4a-775686ccff37">
											<gml:posList>35.6686752542573 139.74783043925513 31.77742035627645 35.66868477962785 139.74782074477844 31.77742035627645 35.66868526091045 139.74782098748136 31.77742035627645 35.6686752542573 139.74783043925513 31.77742035627645</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_55a6d55d-935f-4c62-b704-06949000ae25">
									<gml:exterior>
										<gml:LinearRing gml:id="line_5290598a-e20a-4ae3-a589-3658d9669afa">
											<gml:posList>35.66868526091045 139.74782098748136 32.37877686262411 35.66868477962785 139.74782074477844 32.37877686262411 35.6686752542573 139.74783043925513 32.37877686262411 35.66868526091045 139.74782098748136 32.37877686262411</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_775942b8-f549-480d-8a6f-349c5a4c89dc">
									<gml:exterior>
										<gml:LinearRing gml:id="line_47d95415-a628-49de-a4d9-49105553479b">
											<gml:posList>35.6686752542573 139.74783043925513 32.37877686262411 35.66868477962785 139.74782074477844 32.37877686262411 35.6686747729746 139.74783019638366 32.37877686262411 35.6686752542573 139.74783043925513 32.37877686262411</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="gml_bf1b540d-8616-4446-a9a9-e183a71fddf1">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_0851ba9a-f7e1-4aba-8de2-8234fd9948b3">
									<gml:exterior>
										<gml:LinearRing gml:id="line_a39c1b0d-f221-4272-a8ee-a634979c25b2">
											<gml:posList>35.66856187915317 139.74809555685056 6.3942492747334825 35.66856091215805 139.7481047449641 6.3942492747334825 35.66855909916354 139.7481038301547 6.3942492747334825 35.66856187915317 139.74809555685056 6.3942492747334825</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_22cd0b85-599d-4cd0-8a72-76f8ccad3330">
									<gml:exterior>
										<gml:LinearRing gml:id="line_e697fa8e-24b1-4904-a7ae-f92320617fe0">
											<gml:posList>35.66856091215805 139.7481047449641 6.3942492747334825 35.66856187915317 139.74809555685056 6.3942492747334825 35.66858854430902 139.74802250878727 6.3942492747334825 35.66856091215805 139.7481047449641 6.3942492747334825</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_91ecf96f-bd43-40ac-9d3f-e8aefc20f90a">
									<gml:exterior>
										<gml:LinearRing gml:id="line_345f6a7b-ac73-400b-b8e3-54f0a8fc6dbb">
											<gml:posList>35.66858854430902 139.74802250878727 6.3942492747334825 35.66856187915317 139.74809555685056 6.3942492747334825 35.668557901274575 139.74808430893498 6.3942492747334825 35.66858854430902 139.74802250878727 6.3942492747334825</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_083e3753-80cf-4b72-9e35-32ed1dc12833">
									<gml:exterior>
										<gml:LinearRing gml:id="line_5cc219d2-d416-4c01-a265-7acdfaa0b384">
											<gml:posList>35.66858854430902 139.74802250878727 6.3942492747334825 35.668557901274575 139.74808430893498 6.3942492747334825 35.66854356888887 139.74807707674765 6.3942492747334825 35.66858854430902 139.74802250878727 6.3942492747334825</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_a864d864-d8e9-4dae-9c4b-419e984a0d64">
									<gml:exterior>
										<gml:LinearRing gml:id="line_3ca7ce3c-b33f-4bfd-85f9-e9d68be9abda">
											<gml:posList>35.66858854430902 139.74802250878727 6.3942492747334825 35.66854356888887 139.74807707674765 6.3942492747334825 35.66853454188932 139.7480725217106 6.3942492747334825 35.66858854430902 139.74802250878727 6.3942492747334825</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_b2ab1b37-9f08-432d-a1b0-72a4c42133b4">
									<gml:exterior>
										<gml:LinearRing gml:id="line_235868ee-a84a-45e5-8048-c3e1fe5b5c63">
											<gml:posList>35.66858854430902 139.74802250878727 6.3942492747334825 35.66853454188932 139.7480725217106 6.3942492747334825 35.66852755724325 139.74806899720042 6.3942492747334825 35.66858854430902 139.74802250878727 6.3942492747334825</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_7b3b1890-f0a4-4b41-adcc-fda9adc743d8">
									<gml:exterior>
										<gml:LinearRing gml:id="line_747e94ca-f3d1-4ce7-8368-ae08ae0ba42c">
											<gml:posList>35.66858854430902 139.74802250878727 6.3942492747334825 35.66852755724325 139.74806899720042 6.3942492747334825 35.668524753753644 139.74806758251881 6.3942492747334825 35.66858854430902 139.74802250878727 6.3942492747334825</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_c84571c2-43a0-4a91-94b4-a5ed0a360303">
									<gml:exterior>
										<gml:LinearRing gml:id="line_64bb1d29-18d5-4b8d-96db-86bcd98cf6f8">
											<gml:posList>35.66867650520553 139.7479650200619 6.3942492747334825 35.66862610337473 139.74803552647538 6.3942492747334825 35.66865366644167 139.74795349557397 6.3942492747334825 35.66867650520553 139.7479650200619 6.3942492747334825</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_3eaa760a-0f55-4b2d-8cae-ab29f3018801">
									<gml:exterior>
										<gml:LinearRing gml:id="line_02f9978a-5a0e-4e66-a6a5-9f132a8b66c8">
											<gml:posList>35.66862610337473 139.74803552647538 6.3942492747334825 35.66867650520553 139.7479650200619 6.3942492747334825 35.668648942130886 139.74804705098273 6.3942492747334825 35.66862610337473 139.74803552647538 6.3942492747334825</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_32e2ff79-2534-45b1-8a92-1d187ac9c85c">
									<gml:exterior>
										<gml:LinearRing gml:id="line_2b419e41-b4c5-49d2-b138-907ee0fc243c">
											<gml:posList>35.66865366644167 139.74795349557397 6.3942492747334825 35.66862610337473 139.74803552647538 6.3942492747334825 35.66858854430902 139.74802250878727 6.3942492747334825 35.66865366644167 139.74795349557397 6.3942492747334825</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_0fdd3969-a718-4b3b-960d-df67baf2bbc7">
									<gml:exterior>
										<gml:LinearRing gml:id="line_4ab4a26f-0378-4e03-b08e-3177e2747147">
											<gml:posList>35.66865366644167 139.74795349557397 6.3942492747334825 35.6685802824288 139.74792404026175 6.3942492747334825 35.668644592228574 139.74781496713786 6.3942492747334825 35.66865366644167 139.74795349557397 6.3942492747334825</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_cda9d6ed-4ec0-43b4-a13b-9ae6a76fa9ff">
									<gml:exterior>
										<gml:LinearRing gml:id="line_940a52ef-c1d0-4839-b74f-64b2724a86d9">
											<gml:posList>35.6685802824288 139.74792404026175 6.3942492747334825 35.66865366644167 139.74795349557397 6.3942492747334825 35.66858854430902 139.74802250878727 6.3942492747334825 35.6685802824288 139.74792404026175 6.3942492747334825</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_fcec348a-22d4-49e5-b9c1-9a4d5c59ab97">
									<gml:exterior>
										<gml:LinearRing gml:id="line_7946f2ec-3575-411d-8248-ac4273b17f61">
											<gml:posList>35.668644592228574 139.74781496713786 6.3942492747334825 35.6685802824288 139.74792404026175 6.3942492747334825 35.66862094168115 139.74780303297814 6.3942492747334825 35.668644592228574 139.74781496713786 6.3942492747334825</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_9545eab3-3518-4b0e-a8f2-96cddca21557">
									<gml:exterior>
										<gml:LinearRing gml:id="line_339af960-160a-4f54-b0f9-09fa0c42daea">
											<gml:posList>35.66868272803529 139.7478342104908 6.3942492747334825 35.66865366644167 139.74795349557397 6.3942492747334825 35.668674299121726 139.74782995738087 6.3942492747334825 35.66868272803529 139.7478342104908 6.3942492747334825</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_31b8f63d-9d8c-404f-ae8c-cdece0f4d681">
									<gml:exterior>
										<gml:LinearRing gml:id="line_5682d38e-3067-41a6-aaae-437a9170eda5">
											<gml:posList>35.66865366644167 139.74795349557397 6.3942492747334825 35.66868272803529 139.7478342104908 6.3942492747334825 35.66868381140286 139.74783475711982 6.3942492747334825 35.66865366644167 139.74795349557397 6.3942492747334825</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_26525bcd-0273-44c1-a313-3587c9d7ff4a">
									<gml:exterior>
										<gml:LinearRing gml:id="line_e8251dc5-6ea7-4437-a087-ae8dfe686d57">
											<gml:posList>35.668674299121726 139.74782995738087 6.3942492747334825 35.66865366644167 139.74795349557397 6.3942492747334825 35.668669178785656 139.74782737359192 6.3942492747334825 35.668674299121726 139.74782995738087 6.3942492747334825</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_111e788f-ae88-4ff7-8c57-6870a7bd9adf">
									<gml:exterior>
										<gml:LinearRing gml:id="line_0beee315-3271-4eb0-a6b2-98a1e453f094">
											<gml:posList>35.668669178785656 139.74782737359192 6.3942492747334825 35.66865366644167 139.74795349557397 6.3942492747334825 35.668644592228574 139.74781496713786 6.3942492747334825 35.668669178785656 139.74782737359192 6.3942492747334825</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_5eff0d5d-89d2-448b-b9f6-803375f14903">
									<gml:exterior>
										<gml:LinearRing gml:id="line_7edabd79-5351-401f-b23e-e9a18bfca27b">
											<gml:posList>35.668515012063814 139.74807190738593 6.3942492747334825 35.66851072947919 139.74807942246645 6.3942492747334825 35.66856545347873 139.74791655749243 6.3942492747334825 35.668515012063814 139.74807190738593 6.3942492747334825</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_0a299722-d4ca-4b55-a4c1-8898e00ceb7c">
									<gml:exterior>
										<gml:LinearRing gml:id="line_6e66a95d-51c7-4176-bf50-e837d5e6e9ab">
											<gml:posList>35.66851072947919 139.74807942246645 6.3942492747334825 35.668515012063814 139.74807190738593 6.3942492747334825 35.6685122320758 139.74808018068603 6.3942492747334825 35.66851072947919 139.74807942246645 6.3942492747334825</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_29027a56-1444-4e5d-8867-38a3c777ac7b">
									<gml:exterior>
										<gml:LinearRing gml:id="line_b5861cf3-6d29-41da-bdff-549a9a611213">
											<gml:posList>35.668515012063814 139.74807190738593 6.3942492747334825 35.66856545347873 139.74791655749243 6.3942492747334825 35.668524753753644 139.74806758251881 6.3942492747334825 35.668515012063814 139.74807190738593 6.3942492747334825</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_634f2473-432f-4ecd-919c-1deecacdf03e">
									<gml:exterior>
										<gml:LinearRing gml:id="line_ac7108c4-4770-4981-b13b-cd98ce4d3a03">
											<gml:posList>35.668524753753644 139.74806758251881 6.3942492747334825 35.66856545347873 139.74791655749243 6.3942492747334825 35.66858854430902 139.74802250878727 6.3942492747334825 35.668524753753644 139.74806758251881 6.3942492747334825</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_423db445-2cce-4f41-8da6-352eb1845776">
									<gml:exterior>
										<gml:LinearRing gml:id="line_d83cd9f3-f184-4a9e-8783-be403295a26e">
											<gml:posList>35.66858854430902 139.74802250878727 6.3942492747334825 35.66856545347873 139.74791655749243 6.3942492747334825 35.6685802824288 139.74792404026175 6.3942492747334825 35.66858854430902 139.74802250878727 6.3942492747334825</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_52231d77-7d9e-4060-8393-8e3acface9d0">
									<gml:exterior>
										<gml:LinearRing gml:id="line_cebc5b5d-dc7c-4909-b251-20c0f7d7ca52">
											<gml:posList>35.66858854430902 139.74802250878727 6.3942492747334825 35.66862610337473 139.74803552647538 6.3942492747334825 35.66862439832634 139.74804060093578 6.3942492747334825 35.66858854430902 139.74802250878727 6.3942492747334825</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_3586df16-23bc-4ff7-a4c3-dab4941452d0">
									<gml:exterior>
										<gml:LinearRing gml:id="line_ed9dda5a-51cd-4af1-b18d-962e93d342c7">
											<gml:posList>35.66865366644167 139.74795349557397 6.3942492747334825 35.66868381140286 139.74783475711982 6.3942492747334825 35.66869214950836 139.7478389646508 6.3942492747334825 35.66865366644167 139.74795349557397 6.3942492747334825</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_01390c18-ee69-49f7-885d-068a97fba554">
									<gml:exterior>
										<gml:LinearRing gml:id="line_ca596df6-c798-4f99-98a3-85fb607cd582">
											<gml:posList>35.668557901274575 139.74808430893498 6.3942492747334825 35.66856187915317 139.74809555685056 6.3942492747334825 35.66855524659499 139.7480922099503 6.3942492747334825 35.668557901274575 139.74808430893498 6.3942492747334825</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_4bfd17f5-ad1c-4526-b475-d088fe53bfe2">
									<gml:exterior>
										<gml:LinearRing gml:id="line_266ee1dc-a5a1-4584-8ec6-f62e0e7d6122">
											<gml:posList>35.668515012063814 139.74807190738593 6.3942492747334825 35.668524753753644 139.74806758251881 6.3942492747334825 35.66852209893759 139.74807548353158 6.3942492747334825 35.668515012063814 139.74807190738593 6.3942492747334825</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="gnd_TMmnt0161_b_0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly_TMmnt0161_b_0">
									<gml:exterior>
										<gml:LinearRing gml:id="line_TMmnt0161_b_0">
											<gml:posList>35.6686243702306 139.747797159778 5.44862419 35.66867755368657 139.74782460828197 5.45125518 35.66868928553584 139.7478134290291 5.45171664 35.668700596541825 139.74781926666608 5.4522772 35.66865438913517 139.7479537218797 5.45110006 35.66867668261765 139.74796522801174 5.45220574 35.668648625614985 139.74804686583292 5.4515043 35.668626332929605 139.74803536008534 5.45039866 35.66862452168971 139.74804063044013 5.45035373 35.66859136752457 139.74802351967682 5.44871149 35.668563554493765 139.74810445258177 5.4480268 35.668513375020865 139.7480785554907 5.44554602 35.66857341183139 139.74790385459326 5.44703635 35.66858554966255 139.74791011886649 5.4476359 35.6686243702306 139.747797159778 5.44862419</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:OuterCeilingSurface gml:id="gml_2ddc007d-1d9d-4d5c-aad7-ac62b25280d0">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_0f2f8d3d-89ce-4bd7-80d2-dae427a0c755">
									<gml:exterior>
										<gml:LinearRing gml:id="line_19207985-dce5-4ad0-ab4f-d6d81a37165e">
											<gml:posList>35.668628031727216 139.74780661061828 30.426239326003014 35.668631888868546 139.7478085569517 30.426239326003014 35.66862642811532 139.74781138344156 30.426239326003014 35.668628031727216 139.74780661061828 30.426239326003014</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_9fdc1ad6-eb8a-4c51-b387-e5d3aa65643c">
									<gml:exterior>
										<gml:LinearRing gml:id="line_4b610df6-a2f9-42d5-838d-3bc5180685c2">
											<gml:posList>35.66862642811532 139.74781138344156 30.426239326003014 35.668631888868546 139.7478085569517 30.426239326003014 35.668630285119036 139.74781332977528 30.426239326003014 35.66862642811532 139.74781138344156 30.426239326003014</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:OuterCeilingSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:OuterCeilingSurface gml:id="gml_83820a77-1182-4c29-ad93-a460220d90a7">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_1104c540-f53b-4c22-b3aa-221585a96d6d">
									<gml:exterior>
										<gml:LinearRing gml:id="line_85bb8d31-2ae6-4056-8891-bef276bfbe49">
											<gml:posList>35.66868610967223 139.747835916983 21.24694855451864 35.6686747729746 139.74783019638366 21.24694855451864 35.668690275854296 139.74782351812135 21.24694855451864 35.66868610967223 139.747835916983 21.24694855451864</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_6d198c00-3e14-4dd7-9e5f-e5ee22f56ac6">
									<gml:exterior>
										<gml:LinearRing gml:id="line_af986dd3-47aa-4273-b447-e46c58a6da4b">
											<gml:posList>35.668690275854296 139.74782351812135 21.24694855451864 35.6686747729746 139.74783019638366 21.24694855451864 35.66868477962785 139.74782074477844 21.24694855451864 35.668690275854296 139.74782351812135 21.24694855451864</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:OuterCeilingSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:OuterCeilingSurface gml:id="gml_91068c89-971a-48d6-9930-df846ebbac0a">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_afe87d6d-1b7c-47b6-9f0f-52f92fc9e431">
									<gml:exterior>
										<gml:LinearRing gml:id="line_058054b9-c362-4477-bbaa-cbb7528c494b">
											<gml:posList>35.668670915971305 139.74782825021657 24.30670960188192 35.6686747729746 139.74783019638366 24.30670960188192 35.66867316936178 139.74783496920924 24.30670960188192 35.668670915971305 139.74782825021657 24.30670960188192</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_9dcd8723-c204-49ad-864f-9587efdf8153">
									<gml:exterior>
										<gml:LinearRing gml:id="line_a18af7d7-8002-4800-bdd9-8ac3ba82fe37">
											<gml:posList>35.668670915971305 139.74782825021657 24.30670960188192 35.66867316936178 139.74783496920924 24.30670960188192 35.668669312220906 139.74783302287355 24.30670960188192 35.668670915971305 139.74782825021657 24.30670960188192</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:OuterCeilingSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:OuterCeilingSurface gml:id="gml_cf5ed9ec-f5b2-4be5-838f-58dbd6eddb8d">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_797cd6c0-0962-4d36-b1f6-45a70edfba5c">
									<gml:exterior>
										<gml:LinearRing gml:id="line_5c33bb69-77c5-4941-8048-9a1554fde77f">
											<gml:posList>35.668628031727216 139.74780661061828 21.24694855451864 35.668631888868546 139.7478085569517 21.24694855451864 35.66862642811532 139.74781138344156 21.24694855451864 35.668628031727216 139.74780661061828 21.24694855451864</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_4e1b1145-2276-4440-8757-2be9731d1be2">
									<gml:exterior>
										<gml:LinearRing gml:id="line_4b2f93fa-c603-4bda-a840-3f143bc636bd">
											<gml:posList>35.66862642811532 139.74781138344156 21.24694855451864 35.668631888868546 139.7478085569517 21.24694855451864 35.668630285119036 139.74781332977528 21.24694855451864 35.66862642811532 139.74781138344156 21.24694855451864</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:OuterCeilingSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:OuterCeilingSurface gml:id="gml_c41a7b71-6925-402f-a635-526148e5a301">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_27bd4f3c-368f-41f8-ad22-b0bd22b5c78d">
									<gml:exterior>
										<gml:LinearRing gml:id="line_f4765968-4fe5-44f2-bbe8-be58653efee6">
											<gml:posList>35.6686747729746 139.74783019638366 30.426239326003014 35.66868477962785 139.74782074477844 30.426239326003014 35.668690275854296 139.74782351812135 30.426239326003014 35.6686747729746 139.74783019638366 30.426239326003014</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_4196916b-ec73-4944-8cf7-e378a3f6634a">
									<gml:exterior>
										<gml:LinearRing gml:id="line_83c24951-55f8-42a9-a420-e77ec028263b">
											<gml:posList>35.6686747729746 139.74783019638366 30.426239326003014 35.668690275854296 139.74782351812135 30.426239326003014 35.66868610967223 139.747835916983 30.426239326003014 35.6686747729746 139.74783019638366 30.426239326003014</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:OuterCeilingSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:OuterCeilingSurface gml:id="gml_41b7b13b-b100-4cfb-81b1-3aad7a4e5d6c">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_b495e9e1-1265-41b4-94e7-5b74a2145aaf">
									<gml:exterior>
										<gml:LinearRing gml:id="line_aca491aa-044d-4cec-94db-bf9696e36f98">
											<gml:posList>35.66853762841625 139.74809236806965 9.23169739485067 35.66855909916354 139.7481038301547 9.23169739485067 35.6685122320758 139.74808018068603 9.23169739485067 35.66853762841625 139.74809236806965 9.23169739485067</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_92bbd25d-666b-455c-aa95-92108d9486bf">
									<gml:exterior>
										<gml:LinearRing gml:id="line_8b28a011-835c-4fca-b00b-b8f0def28704">
											<gml:posList>35.66855909916354 139.7481038301547 9.23169739485067 35.66853762841625 139.74809236806965 9.23169739485067 35.66853793887452 139.7480914439243 9.23169739485067 35.66855909916354 139.7481038301547 9.23169739485067</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_f8a16140-ce5b-4285-be78-68c51d31cda4">
									<gml:exterior>
										<gml:LinearRing gml:id="line_659999a5-945d-4645-85b8-843598e2af6c">
											<gml:posList>35.66853762841625 139.74809236806965 9.23169739485067 35.6685122320758 139.74808018068603 9.23169739485067 35.668512412421634 139.748079644004 9.23169739485067 35.66853762841625 139.74809236806965 9.23169739485067</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_10678df2-91f5-41bc-bc30-e45876fbc665">
									<gml:exterior>
										<gml:LinearRing gml:id="line_d3437521-995c-4bdc-8da4-a22dd30936f1">
											<gml:posList>35.6685599733061 139.74810122885575 9.23169739485067 35.66853793887452 139.7480914439243 9.23169739485067 35.66851310608031 139.74807757938854 9.23169739485067 35.6685599733061 139.74810122885575 9.23169739485067</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_b93e5e0b-d9fd-405c-b4fc-bb9aa8d6d33e">
									<gml:exterior>
										<gml:LinearRing gml:id="line_d1513faf-51f7-4a5b-aee3-2b0340c51b6e">
											<gml:posList>35.66853793887452 139.7480914439243 9.23169739485067 35.6685599733061 139.74810122885575 9.23169739485067 35.66855909916354 139.7481038301547 9.23169739485067 35.66853793887452 139.7480914439243 9.23169739485067</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_6e029a58-5fe1-402d-b9f5-d94a5a7dee4e">
									<gml:exterior>
										<gml:LinearRing gml:id="line_d02f2581-31a5-4944-8c2c-8ced886f9503">
											<gml:posList>35.66851310608031 139.74807757938854 9.23169739485067 35.66853793887452 139.7480914439243 9.23169739485067 35.66851272301735 139.74807871985874 9.23169739485067 35.66851310608031 139.74807757938854 9.23169739485067</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_b409ed12-ed4c-4983-823c-cf208e1b4a10">
									<gml:exterior>
										<gml:LinearRing gml:id="line_9db3a15b-fe8d-48f8-8a25-3b8c18beda8d">
											<gml:posList>35.66851272301735 139.74807871985874 9.23169739485067 35.66853793887452 139.7480914439243 9.23169739485067 35.668512412421634 139.748079644004 9.23169739485067 35.66851272301735 139.74807871985874 9.23169739485067</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_59a1bf7a-1ab9-4e7b-83e3-db05be2089e3">
									<gml:exterior>
										<gml:LinearRing gml:id="line_32d22b6a-d267-469f-a1a2-b2303fbbe8c0">
											<gml:posList>35.668512412421634 139.748079644004 9.23169739485067 35.66853793887452 139.7480914439243 9.23169739485067 35.66853762841625 139.74809236806965 9.23169739485067 35.668512412421634 139.748079644004 9.23169739485067</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:OuterCeilingSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:OuterCeilingSurface gml:id="gml_041cc4c5-1594-4d9f-b40b-32008f524e04">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_441c0e6c-239a-4ed7-9a6c-a6a9c48eebef">
									<gml:exterior>
										<gml:LinearRing gml:id="line_400a82db-ecd7-4f8a-b8b3-61433b3527db">
											<gml:posList>35.66856072996256 139.74809897657752 8.85669739485067 35.6685599733061 139.74810122885575 9.23169739485067 35.66851310608031 139.74807757938854 9.23169739485067 35.66856072996256 139.74809897657752 8.85669739485067</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_7eb453e8-3b23-4366-bdd2-e8f4300899ac">
									<gml:exterior>
										<gml:LinearRing gml:id="line_1808534e-6421-4173-b64c-d7624f248acd">
											<gml:posList>35.66856072996256 139.74809897657752 8.85669739485067 35.66851310608031 139.74807757938854 9.23169739485067 35.668513862873986 139.7480753272798 8.85669739485067 35.66856072996256 139.74809897657752 8.85669739485067</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:OuterCeilingSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:OuterCeilingSurface gml:id="gml_5207fa69-b7d0-4c67-bcb1-a7d797a8eebf">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_71461a5a-0f61-4bdb-be4e-45a2f578f91d">
									<gml:exterior>
										<gml:LinearRing gml:id="line_1a083cae-e805-4451-a43a-f717110210f0">
											<gml:posList>35.6686747729746 139.74783019638366 33.486000373366295 35.66867316936178 139.74783496920924 33.486000373366295 35.668670915971305 139.74782825021657 33.486000373366295 35.6686747729746 139.74783019638366 33.486000373366295</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_3cd37034-53e7-4bbe-bab2-39f83baea617">
									<gml:exterior>
										<gml:LinearRing gml:id="line_d5332e5b-a133-49b6-a13e-b04a4a5300d7">
											<gml:posList>35.668670915971305 139.74782825021657 33.486000373366295 35.66867316936178 139.74783496920924 33.486000373366295 35.668669312220906 139.74783302287355 33.486000373366295 35.668670915971305 139.74782825021657 33.486000373366295</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:OuterCeilingSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:OuterCeilingSurface gml:id="gml_31aa2c8b-0ede-4c12-8020-8d04f6cba991">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_9cb6eb89-31e0-4e51-9f1a-48100d0d9408">
									<gml:exterior>
										<gml:LinearRing gml:id="line_62092a8b-1973-4f8e-bb1b-81a6f729d7e3">
											<gml:posList>35.668669312220906 139.74783302287355 15.127426459792076 35.668670915971305 139.74782825021657 15.127426459792076 35.66867316936178 139.74783496920924 15.127426459792076 35.668669312220906 139.74783302287355 15.127426459792076</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_1086ec55-c6ef-47a6-9e1f-1b84891e6c40">
									<gml:exterior>
										<gml:LinearRing gml:id="line_1c091328-7b37-4591-b3d7-2a64caa96d98">
											<gml:posList>35.66867316936178 139.74783496920924 15.127426459792076 35.668670915971305 139.74782825021657 15.127426459792076 35.6686747729746 139.74783019638366 15.127426459792076 35.66867316936178 139.74783496920924 15.127426459792076</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:OuterCeilingSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:OuterCeilingSurface gml:id="gml_017dfb03-77b2-407c-b1ce-51b42cadce3a">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_880ded9b-a3b2-4882-b79a-9b4192322c14">
									<gml:exterior>
										<gml:LinearRing gml:id="line_18ec4879-8ae9-4d03-a84c-3065a30bb214">
											<gml:posList>35.668513862873986 139.7480753272798 8.85669739485067 35.66852209893759 139.74807548353158 8.85669739485067 35.66856072996256 139.74809897657752 8.85669739485067 35.668513862873986 139.7480753272798 8.85669739485067</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_095decfe-e149-46b7-b3f8-fc5ffdafb698">
									<gml:exterior>
										<gml:LinearRing gml:id="line_22665115-1d9e-46ca-b96b-5c05aa7b8077">
											<gml:posList>35.66852209893759 139.74807548353158 8.85669739485067 35.668513862873986 139.7480753272798 8.85669739485067 35.668515012063814 139.74807190738593 8.85669739485067 35.66852209893759 139.74807548353158 8.85669739485067</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_57aeb552-b4b8-4c5b-b06f-cd00cd960e0a">
									<gml:exterior>
										<gml:LinearRing gml:id="line_cdda0da5-1f2d-48df-bd47-5b637dcdb641">
											<gml:posList>35.66856072996256 139.74809897657752 8.85669739485067 35.66852209893759 139.74807548353158 8.85669739485067 35.66855524659499 139.7480922099503 8.85669739485067 35.66856072996256 139.74809897657752 8.85669739485067</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_03b0b592-34e4-42fb-8365-c0b34b4bc5e4">
									<gml:exterior>
										<gml:LinearRing gml:id="line_13bd84b4-3216-4b7b-9700-18d0b09d94fb">
											<gml:posList>35.66855524659499 139.7480922099503 8.85669739485067 35.66852209893759 139.74807548353158 8.85669739485067 35.66854356888887 139.74807707674765 8.85669739485067 35.66855524659499 139.7480922099503 8.85669739485067</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_f9ef6448-db33-45ff-bba6-df3983a073ed">
									<gml:exterior>
										<gml:LinearRing gml:id="line_8233cca1-9422-4ea9-b673-656348c268de">
											<gml:posList>35.66853454188932 139.7480725217106 8.85669739485067 35.66852209893759 139.74807548353158 8.85669739485067 35.66852755724325 139.74806899720042 8.85669739485067 35.66853454188932 139.7480725217106 8.85669739485067</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_77faf265-678d-4651-86d1-50c236b2489d">
									<gml:exterior>
										<gml:LinearRing gml:id="line_da684603-0c38-4610-a139-6ed132cd24c6">
											<gml:posList>35.66852209893759 139.74807548353158 8.85669739485067 35.66853454188932 139.7480725217106 8.85669739485067 35.66854356888887 139.74807707674765 8.85669739485067 35.66852209893759 139.74807548353158 8.85669739485067</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_72496295-0d2c-4f58-b171-c6a46504760f">
									<gml:exterior>
										<gml:LinearRing gml:id="line_7c01b47e-07fb-436b-b99a-741798666bd5">
											<gml:posList>35.66856072996256 139.74809897657752 8.85669739485067 35.66855524659499 139.7480922099503 8.85669739485067 35.66856187915317 139.74809555685056 8.85669739485067 35.66856072996256 139.74809897657752 8.85669739485067</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_7b43bc1b-9ac3-4cff-8512-ac033f078e4e">
									<gml:exterior>
										<gml:LinearRing gml:id="line_ae890a0c-4f11-40d4-9c97-4acc5ed8445a">
											<gml:posList>35.66855524659499 139.7480922099503 8.85669739485067 35.66854356888887 139.74807707674765 8.85669739485067 35.668557901274575 139.74808430893498 8.85669739485067 35.66855524659499 139.7480922099503 8.85669739485067</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_a479f3cb-056b-4474-b524-6022c90a5a5f">
									<gml:exterior>
										<gml:LinearRing gml:id="line_48c8b1ec-6a5d-4e1c-8ce9-9c9c4a832019">
											<gml:posList>35.66852755724325 139.74806899720042 8.85669739485067 35.66852209893759 139.74807548353158 8.85669739485067 35.668524753753644 139.74806758251881 8.85669739485067 35.66852755724325 139.74806899720042 8.85669739485067</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
					<bldg:opening>
						<bldg:Door gml:id="dor_6e44686d-1d83-44ba-84f9-6df7639100a2">
							<bldg:lod3MultiSurface>
								<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_32d21bd3-fda2-406f-8f22-bcb7e4b56d16">
											<gml:exterior>
												<gml:LinearRing gml:id="line_e13df8d1-58c0-4d68-b597-dde167279d5a">
													<gml:posList>35.66853454188932 139.7480725217106 8.85669739485067 35.66852755724325 139.74806899720042 8.85669739485067 35.66853454188932 139.7480725217106 6.3942492747334825 35.66853454188932 139.7480725217106 8.85669739485067</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_44625b89-6489-474b-810e-2692d039b2ce">
											<gml:exterior>
												<gml:LinearRing gml:id="line_666d797f-61f3-41dd-a2aa-f760dbcc77fb">
													<gml:posList>35.66853454188932 139.7480725217106 6.3942492747334825 35.66852755724325 139.74806899720042 8.85669739485067 35.66852755724325 139.74806899720042 6.3942492747334825 35.66853454188932 139.7480725217106 6.3942492747334825</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
								</gml:MultiSurface>
							</bldg:lod3MultiSurface>
						</bldg:Door>
					</bldg:opening>
					<bldg:opening>
						<bldg:Window gml:id="wnd_b42c8c44-b889-4e9b-b7ac-d9b90487bf0f">
							<bldg:lod3MultiSurface>
								<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_40c4500d-76a5-4207-a018-85d371384c60">
											<gml:exterior>
												<gml:LinearRing gml:id="line_a889c63a-ed6a-4c12-ab13-18b2e6e0526e">
													<gml:posList>35.66854356888887 139.74807707674765 8.85669739485067 35.66853454188932 139.7480725217106 8.85669739485067 35.66854356888887 139.74807707674765 6.3942492747334825 35.66854356888887 139.74807707674765 8.85669739485067</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_b7211871-a6d8-4c77-a8e1-a2cab911ff33">
											<gml:exterior>
												<gml:LinearRing gml:id="line_79e1ca78-e908-4c79-ae45-62bcbfe65bc8">
													<gml:posList>35.66854356888887 139.74807707674765 6.3942492747334825 35.66853454188932 139.7480725217106 8.85669739485067 35.66853454188932 139.7480725217106 6.3942492747334825 35.66854356888887 139.74807707674765 6.3942492747334825</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
								</gml:MultiSurface>
							</bldg:lod3MultiSurface>
						</bldg:Window>
					</bldg:opening>
				</bldg:OuterCeilingSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:OuterCeilingSurface gml:id="gml_d15d93a4-0aa0-4664-aa22-71fe120ae432">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_988a71cb-76bf-46b0-b644-38ffd402ac44">
									<gml:exterior>
										<gml:LinearRing gml:id="line_dad6889d-fce9-46a0-91aa-b99a4141eba5">
											<gml:posList>35.668669312220906 139.74783302287355 30.426239326003014 35.668670915971305 139.74782825021657 30.426239326003014 35.66867316936178 139.74783496920924 30.426239326003014 35.668669312220906 139.74783302287355 30.426239326003014</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_153a3067-b791-4d13-80d5-c4312eb55ad5">
									<gml:exterior>
										<gml:LinearRing gml:id="line_21de67b1-97de-42ef-a35b-6fb37f33aec1">
											<gml:posList>35.66867316936178 139.74783496920924 30.426239326003014 35.668670915971305 139.74782825021657 30.426239326003014 35.6686747729746 139.74783019638366 30.426239326003014 35.66867316936178 139.74783496920924 30.426239326003014</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:OuterCeilingSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:OuterCeilingSurface gml:id="gml_66f39901-2c89-4d81-b8a8-cbe90b0ff175">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_4589e25a-70fa-41ce-94b4-1295e67f7be6">
									<gml:exterior>
										<gml:LinearRing gml:id="line_cd4f01d7-2055-48b9-9360-ca7c66fbd2a3">
											<gml:posList>35.66868477962785 139.74782074477844 27.3664706492452 35.668690275854296 139.74782351812135 27.3664706492452 35.6686747729746 139.74783019638366 27.3664706492452 35.66868477962785 139.74782074477844 27.3664706492452</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_c60d04a3-1aa3-4a1b-b917-b0c8a8a358fe">
									<gml:exterior>
										<gml:LinearRing gml:id="line_a43d4e54-22fe-49ac-af6c-bf5a53f30d37">
											<gml:posList>35.6686747729746 139.74783019638366 27.3664706492452 35.668690275854296 139.74782351812135 27.3664706492452 35.66868610967223 139.747835916983 27.3664706492452 35.6686747729746 139.74783019638366 27.3664706492452</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:OuterCeilingSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:OuterCeilingSurface gml:id="gml_df8c632c-db50-4a2a-9db3-0c7db0371e5d">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_334e7c1b-bbbb-4ad3-860e-2ef48c56c8ac">
									<gml:exterior>
										<gml:LinearRing gml:id="line_22a1298d-a8b2-4873-80de-654c5f57a067">
											<gml:posList>35.6686747729746 139.74783019638366 12.067657783034264 35.66868477962785 139.74782074477844 12.067657783034264 35.668690275854296 139.74782351812135 12.067657783034264 35.6686747729746 139.74783019638366 12.067657783034264</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_b8c3559f-7429-4765-aec8-b41d4b718728">
									<gml:exterior>
										<gml:LinearRing gml:id="line_48ea5228-5734-41d4-9241-aca28fdb418b">
											<gml:posList>35.6686747729746 139.74783019638366 12.067657783034264 35.668690275854296 139.74782351812135 12.067657783034264 35.66868610967223 139.747835916983 12.067657783034264 35.6686747729746 139.74783019638366 12.067657783034264</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:OuterCeilingSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:OuterCeilingSurface gml:id="gml_cbdaacc8-f7be-4544-a7a8-d6bdbab7e0b3">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_6b665cd9-391c-4486-b68d-64f81c29d21d">
									<gml:exterior>
										<gml:LinearRing gml:id="line_10452a2b-a1c5-406e-a8ef-a9dd339ea2bd">
											<gml:posList>35.6686747729746 139.74783019638366 33.486000373366295 35.66868477962785 139.74782074477844 33.486000373366295 35.668690275854296 139.74782351812135 33.486000373366295 35.6686747729746 139.74783019638366 33.486000373366295</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_249ea9ac-5f21-442d-8f0a-e8f5fdc8bd0f">
									<gml:exterior>
										<gml:LinearRing gml:id="line_07dbfbf6-b019-4019-ad8c-07e567609ec4">
											<gml:posList>35.6686747729746 139.74783019638366 33.486000373366295 35.668690275854296 139.74782351812135 33.486000373366295 35.66868610967223 139.747835916983 33.486000373366295 35.6686747729746 139.74783019638366 33.486000373366295</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:OuterCeilingSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:OuterCeilingSurface gml:id="gml_887cc22b-cde0-4e1b-9f84-219a35a62e45">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_f85766d7-ae13-4f8a-83b1-be8c054282e9">
									<gml:exterior>
										<gml:LinearRing gml:id="line_aed58fa7-0590-4c0a-9ce5-926603b2464e">
											<gml:posList>35.668669312220906 139.74783302287355 12.067657783034264 35.668670915971305 139.74782825021657 12.067657783034264 35.6686747729746 139.74783019638366 12.067657783034264 35.668669312220906 139.74783302287355 12.067657783034264</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_9e09dcdc-fc66-488b-9bc8-26e4ecc9ca9d">
									<gml:exterior>
										<gml:LinearRing gml:id="line_ae0f8e88-7edc-4ff9-a213-c57ab4035895">
											<gml:posList>35.668669312220906 139.74783302287355 12.067657783034264 35.6686747729746 139.74783019638366 12.067657783034264 35.66867316936178 139.74783496920924 12.067657783034264 35.668669312220906 139.74783302287355 12.067657783034264</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:OuterCeilingSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:OuterCeilingSurface gml:id="gml_2d304d4f-5ffd-482e-9144-3423addda5b6">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_4eaeee1b-bea5-4d35-8d15-de7ca135bec6">
									<gml:exterior>
										<gml:LinearRing gml:id="line_94b28b48-7db8-4b4c-8ec0-5b7f6bf9a10f">
											<gml:posList>35.6686970039924 139.74782451718383 9.355507209303795 35.66868381140286 139.74783475711982 9.355507209303795 35.66868866588641 139.74782030965406 9.355507209303795 35.6686970039924 139.74782451718383 9.355507209303795</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_bc30abba-018f-44a1-ae1c-ec9082fe3bf1">
									<gml:exterior>
										<gml:LinearRing gml:id="line_7bc07a06-1917-46e1-b7c6-bf2e6994fe3f">
											<gml:posList>35.66868381140286 139.74783475711982 9.355507209303795 35.6686970039924 139.74782451718383 9.355507209303795 35.66869214950836 139.7478389646508 9.355507209303795 35.66868381140286 139.74783475711982 9.355507209303795</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_4c736e8a-dbb0-4d9e-86c8-73ac833996fc">
									<gml:exterior>
										<gml:LinearRing gml:id="line_9aaf9430-27e0-4acc-9a7d-cd7366db0cb2">
											<gml:posList>35.66868866588641 139.74782030965406 9.355507209303795 35.66868381140286 139.74783475711982 9.355507209303795 35.668686432971406 139.74781918309426 9.355507209303795 35.66868866588641 139.74782030965406 9.355507209303795</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_9b8035dd-122d-4cb2-a0f8-dda76d75a112">
									<gml:exterior>
										<gml:LinearRing gml:id="line_656a7fa6-26f9-48ca-977f-103505d6c9f9">
											<gml:posList>35.668686432971406 139.74781918309426 9.355507209303795 35.66868381140286 139.74783475711982 9.355507209303795 35.6686747729746 139.74783019638366 9.355507209303795 35.668686432971406 139.74781918309426 9.355507209303795</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:OuterCeilingSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:OuterCeilingSurface gml:id="gml_a2272064-c5ca-42f4-b87c-cbfb3bdb0521">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_c62f47d7-37e3-47fa-94d5-6d1c03b45d08">
									<gml:exterior>
										<gml:LinearRing gml:id="line_8fc4773e-e0ae-4db0-83dd-9836af41a5b0">
											<gml:posList>35.668669312220906 139.74783302287355 18.187187507155357 35.668670915971305 139.74782825021657 18.187187507155357 35.6686747729746 139.74783019638366 18.187187507155357 35.668669312220906 139.74783302287355 18.187187507155357</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_a8fbf74b-069d-4d3d-92e8-18836f4c945c">
									<gml:exterior>
										<gml:LinearRing gml:id="line_1a1266ba-d2c1-4704-a9c7-7b65e28ed598">
											<gml:posList>35.668669312220906 139.74783302287355 18.187187507155357 35.6686747729746 139.74783019638366 18.187187507155357 35.66867316936178 139.74783496920924 18.187187507155357 35.668669312220906 139.74783302287355 18.187187507155357</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:OuterCeilingSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:OuterCeilingSurface gml:id="gml_33799ab2-0e64-4e1d-b63d-7dfc1a016c94">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_f2fc12a9-5435-4bcb-8413-7af3cbd935fb">
									<gml:exterior>
										<gml:LinearRing gml:id="line_ed90daa9-1347-4dc7-a413-6e3f28e98ce2">
											<gml:posList>35.668670915971305 139.74782825021657 27.3664706492452 35.6686747729746 139.74783019638366 27.3664706492452 35.66867316936178 139.74783496920924 27.3664706492452 35.668670915971305 139.74782825021657 27.3664706492452</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_ac6f4ac8-3068-4ab3-974a-2df4f07a22cb">
									<gml:exterior>
										<gml:LinearRing gml:id="line_4248922c-a0ac-44fc-a22e-fd6cd29e1b00">
											<gml:posList>35.668670915971305 139.74782825021657 27.3664706492452 35.66867316936178 139.74783496920924 27.3664706492452 35.668669312220906 139.74783302287355 27.3664706492452 35.668670915971305 139.74782825021657 27.3664706492452</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:OuterCeilingSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:OuterCeilingSurface gml:id="gml_4b84a875-6268-4ea9-9397-5f54dfe39ff9">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_20a76f82-3f80-41d7-96d2-360017ecc4be">
									<gml:exterior>
										<gml:LinearRing gml:id="line_306d3c24-2674-4165-80b1-a4412c8767ca">
											<gml:posList>35.66868610967223 139.747835916983 24.30670960188192 35.6686747729746 139.74783019638366 24.30670960188192 35.668690275854296 139.74782351812135 24.30670960188192 35.66868610967223 139.747835916983 24.30670960188192</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_04748b8c-faa7-45ec-85d0-87c09744e8ce">
									<gml:exterior>
										<gml:LinearRing gml:id="line_3194ace6-e1ab-4a5f-a557-bda99b2809df">
											<gml:posList>35.668690275854296 139.74782351812135 24.30670960188192 35.6686747729746 139.74783019638366 24.30670960188192 35.66868477962785 139.74782074477844 24.30670960188192 35.668690275854296 139.74782351812135 24.30670960188192</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:OuterCeilingSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:OuterCeilingSurface gml:id="gml_cf1b2e6e-5cf5-4603-af54-839eb22accd2">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_0952874a-72b7-4962-a0a2-09a801ed2191">
									<gml:exterior>
										<gml:LinearRing gml:id="line_137a2c7e-5c68-4257-8bff-1b4d08a4fdcf">
											<gml:posList>35.668670915971305 139.74782825021657 21.24694855451864 35.6686747729746 139.74783019638366 21.24694855451864 35.668669312220906 139.74783302287355 21.24694855451864 35.668670915971305 139.74782825021657 21.24694855451864</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_4834911f-e96e-4480-a386-12bf796b87bc">
									<gml:exterior>
										<gml:LinearRing gml:id="line_e60dd1d1-d66b-4f93-85db-6ac4ffd278a3">
											<gml:posList>35.668669312220906 139.74783302287355 21.24694855451864 35.6686747729746 139.74783019638366 21.24694855451864 35.66867316936178 139.74783496920924 21.24694855451864 35.668669312220906 139.74783302287355 21.24694855451864</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:OuterCeilingSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:OuterCeilingSurface gml:id="gml_eaa27d69-90b1-4594-a095-b56baf13799e">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_f6a6249c-8148-4c9c-aa6e-90c8d099f086">
									<gml:exterior>
										<gml:LinearRing gml:id="line_4bc38624-ff5f-49d7-a0d0-683fb6af142b">
											<gml:posList>35.668628031727216 139.74780661061828 24.30670960188192 35.668631888868546 139.7478085569517 24.30670960188192 35.66862642811532 139.74781138344156 24.30670960188192 35.668628031727216 139.74780661061828 24.30670960188192</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_57910e82-4c88-462a-9fd0-744a6fc4899e">
									<gml:exterior>
										<gml:LinearRing gml:id="line_f60d5e7a-2324-4100-96d1-b68e34bba0ce">
											<gml:posList>35.66862642811532 139.74781138344156 24.30670960188192 35.668631888868546 139.7478085569517 24.30670960188192 35.668630285119036 139.74781332977528 24.30670960188192 35.66862642811532 139.74781138344156 24.30670960188192</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:OuterCeilingSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:OuterCeilingSurface gml:id="gml_89cacedc-8f1a-491d-8039-7bb61a7466ae">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_02255500-32ed-425e-9fe8-9dc335052af4">
									<gml:exterior>
										<gml:LinearRing gml:id="line_b8a08a4d-0dc8-4951-a17b-b3210a003377">
											<gml:posList>35.668628031727216 139.74780661061828 33.486000373366295 35.668631888868546 139.7478085569517 33.486000373366295 35.66862642811532 139.74781138344156 33.486000373366295 35.668628031727216 139.74780661061828 33.486000373366295</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_23fc76b5-8e7d-4d0d-bde6-d8b4a216c414">
									<gml:exterior>
										<gml:LinearRing gml:id="line_e3a7f4c7-4bb6-436e-939a-53cebc2163e3">
											<gml:posList>35.66862642811532 139.74781138344156 33.486000373366295 35.668631888868546 139.7478085569517 33.486000373366295 35.668630285119036 139.74781332977528 33.486000373366295 35.66862642811532 139.74781138344156 33.486000373366295</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:OuterCeilingSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:OuterCeilingSurface gml:id="gml_af7d128b-dfc7-4f29-98c9-114a912e67fc">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_41cf6616-1174-48e2-88c2-2764bacecb64">
									<gml:exterior>
										<gml:LinearRing gml:id="line_b3aff384-1e98-414e-b3a7-34835aa449d9">
											<gml:posList>35.66868610967223 139.747835916983 18.187187507155357 35.6686747729746 139.74783019638366 18.187187507155357 35.668690275854296 139.74782351812135 18.187187507155357 35.66868610967223 139.747835916983 18.187187507155357</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_cdff257a-9542-42ee-9afb-7687885da20d">
									<gml:exterior>
										<gml:LinearRing gml:id="line_1b4bf5a7-e0cc-4dc0-951b-ffd553930543">
											<gml:posList>35.668690275854296 139.74782351812135 18.187187507155357 35.6686747729746 139.74783019638366 18.187187507155357 35.66868477962785 139.74782074477844 18.187187507155357 35.668690275854296 139.74782351812135 18.187187507155357</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:OuterCeilingSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:OuterCeilingSurface gml:id="gml_ed0692ec-52fc-4681-8ae7-c451611efac9">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_4e9131eb-57b2-440f-a5d7-c2ffe3aeae59">
									<gml:exterior>
										<gml:LinearRing gml:id="line_36aa05f9-280d-481e-a9c7-af90ec7d11fd">
											<gml:posList>35.668631888868546 139.7478085569517 27.3664706492452 35.668630285119036 139.74781332977528 27.3664706492452 35.66862642811532 139.74781138344156 27.3664706492452 35.668631888868546 139.7478085569517 27.3664706492452</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_9239ac8f-6682-4933-a5d7-3b28245def2d">
									<gml:exterior>
										<gml:LinearRing gml:id="line_268f0441-dffc-41aa-a71a-21b7ae1e01b5">
											<gml:posList>35.668631888868546 139.7478085569517 27.3664706492452 35.66862642811532 139.74781138344156 27.3664706492452 35.668628031727216 139.74780661061828 27.3664706492452 35.668631888868546 139.7478085569517 27.3664706492452</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:OuterCeilingSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:OuterCeilingSurface gml:id="gml_507754f6-0b0e-40fe-97ba-5bf210d035d9">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_bbcec3ab-d11c-4684-905e-148fcf192eff">
									<gml:exterior>
										<gml:LinearRing gml:id="line_6c944f29-c285-4451-b297-628a7d741405">
											<gml:posList>35.66868610967223 139.747835916983 15.127426459792076 35.6686747729746 139.74783019638366 15.127426459792076 35.668690275854296 139.74782351812135 15.127426459792076 35.66868610967223 139.747835916983 15.127426459792076</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_bab33dfc-1b55-47f1-9da4-6f5763d1ddf5">
									<gml:exterior>
										<gml:LinearRing gml:id="line_8ca46a73-aff3-43c9-a495-55c8e0e0fc1d">
											<gml:posList>35.668690275854296 139.74782351812135 15.127426459792076 35.6686747729746 139.74783019638366 15.127426459792076 35.66868477962785 139.74782074477844 15.127426459792076 35.668690275854296 139.74782351812135 15.127426459792076</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:OuterCeilingSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="roof_TMmnt0161_p994_0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly_TMmnt0161_p994_0">
									<gml:exterior>
										<gml:LinearRing gml:id="line_TMmnt0161_p994_0">
											<gml:posList>35.66860002688576 139.74790255310108 39.12413428 35.66858494202354 139.74794644550522 39.1237546 35.66860446358953 139.74795652105036 39.12472004 35.66861954856139 139.7479126286901 39.12509972 35.66860002688576 139.74790255310108 39.12413428</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="roof_TMmnt0161_p993_0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly_TMmnt0161_p993_0">
									<gml:exterior>
										<gml:LinearRing gml:id="line_TMmnt0161_p993_0">
											<gml:posList>35.66862196369172 139.74798228174478 40.90570594 35.66860530640587 139.74803075034654 40.90529111 35.66862438966881 139.74804059916218 40.90623667 35.66862620089855 139.74803532883664 40.90628161 35.66864849345966 139.74804683452038 40.90738724 35.668676550305804 139.74796519715258 40.90808868 35.66865117429369 139.74795210006292 40.9068302 35.66863796358011 139.74799053951006 40.90649867 35.66862196369172 139.74798228174478 40.90570594</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="gml_a8f6275d-1aba-4296-a9d0-ac2d2ce312c8">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_294748e8-468f-492b-9506-8e831bdc4744">
									<gml:exterior>
										<gml:LinearRing gml:id="line_899a6537-ee0f-4d08-bb9c-37f4a0fd0cc4">
											<gml:posList>35.66867650520553 139.7479650200619 40.907394721510826 35.66863826445226 139.7479905575038 40.907394721510826 35.668648942130886 139.74804705098273 40.907394721510826 35.66867650520553 139.7479650200619 40.907394721510826</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_48d52f1a-0753-46c9-a925-49ef9f93f289">
									<gml:exterior>
										<gml:LinearRing gml:id="line_1e07691d-e6a9-43d8-9558-194862e7c001">
											<gml:posList>35.66863826445226 139.7479905575038 40.907394721510826 35.66867650520553 139.7479650200619 40.907394721510826 35.66865114500591 139.74795222318627 40.907394721510826 35.66863826445226 139.7479905575038 40.907394721510826</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_f6242d0c-56a7-4b29-9be3-6cda3c22f20c">
									<gml:exterior>
										<gml:LinearRing gml:id="line_e70c5d1a-1185-42be-8829-9fa7360fb87b">
											<gml:posList>35.668648942130886 139.74804705098273 40.907394721510826 35.66863826445226 139.7479905575038 40.907394721510826 35.66862610337473 139.74803552647538 40.907394721510826 35.668648942130886 139.74804705098273 40.907394721510826</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_05453d9d-0a33-42fe-8c9f-f4669e4650d4">
									<gml:exterior>
										<gml:LinearRing gml:id="line_64287d77-3bd3-4c2b-a8ab-cbe5c28a3b04">
											<gml:posList>35.66862610337473 139.74803552647538 40.907394721510826 35.668621903878346 139.74798230203365 40.907394721510826 35.668605516458285 139.74803107289867 40.907394721510826 35.66862610337473 139.74803552647538 40.907394721510826</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_4756da64-a615-4e5b-a88d-4bbb8a79cf04">
									<gml:exterior>
										<gml:LinearRing gml:id="line_0eca1dc5-cdf2-40e0-b6b7-9e07e3b38500">
											<gml:posList>35.668621903878346 139.74798230203365 40.907394721510826 35.66862610337473 139.74803552647538 40.907394721510826 35.66863826445226 139.7479905575038 40.907394721510826 35.668621903878346 139.74798230203365 40.907394721510826</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_49169abf-dea0-4708-bb78-3f359e9270be">
									<gml:exterior>
										<gml:LinearRing gml:id="line_5ee0d8be-c5a6-4f8d-8f65-e231f266dfb9">
											<gml:posList>35.66862610337473 139.74803552647538 40.907394721510826 35.668605516458285 139.74803107289867 40.907394721510826 35.66862439832634 139.74804060093578 40.907394721510826 35.66862610337473 139.74803552647538 40.907394721510826</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="roof_TMmnt0161_p992_1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly_TMmnt0161_p992_1">
									<gml:exterior>
										<gml:LinearRing gml:id="line_TMmnt0161_p992_1">
											<gml:posList>35.668591246955046 139.74802349115882 37.87459471 35.66860531767898 139.74803075301475 37.87529138 35.668621974972744 139.74798228439 37.8757062 35.668637974868794 139.74799054215927 37.87649894 35.66865118558869 139.7479521026939 37.87683046 35.66865426824419 139.74795369371623 37.87698327 35.668667698010054 139.74791461558144 37.87732257 35.668626226593894 139.74789321238558 37.87526873 35.66861955321487 139.74791262976777 37.87509983 35.66860446824003 139.74795652213663 37.87472015 35.66858494667018 139.74794644658942 37.87375471 35.66860003153536 139.7479025541768 37.87413439 35.66858542912262 139.74791009092453 37.87351913 35.6685732913533 139.7479038266831 37.87291958 35.66851325484911 139.7480785266932 37.87142926 35.66856343406604 139.7481044236526 37.87391003 35.668591246955046 139.74802349115882 37.87459471</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="gml_ba04e242-d6b3-4a79-883d-8a8b01a6d8c9">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_1d0a2762-0198-450b-b291-7f2d60ed441c">
									<gml:exterior>
										<gml:LinearRing gml:id="line_bed201ea-e992-4e7c-87e1-7389aecdd678">
											<gml:posList>35.66856545347873 139.74791655749243 41.17650635481161 35.66856262697436 139.74792496973683 41.17650635481161 35.6685725697646 139.7479299869554 41.17650635481161 35.66856545347873 139.74791655749243 41.17650635481161</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_5a8319ce-c6aa-4ee4-8648-5d29826baa6a">
									<gml:exterior>
										<gml:LinearRing gml:id="line_7f830818-a70e-42df-adbf-c11e05df809f">
											<gml:posList>35.66856545347873 139.74791655749243 41.17650635481161 35.6685725697646 139.7479299869554 41.17650635481161 35.668575396406865 139.74792157470998 41.17650635481161 35.66856545347873 139.74791655749243 41.17650635481161</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="gml_983c6839-9325-42da-9c39-6043d6df1b4b">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_94c5f69f-2a99-41f8-a567-64b11f2786c3">
									<gml:exterior>
										<gml:LinearRing gml:id="line_c744e459-29af-427a-a0ea-73f35b28ca5b">
											<gml:posList>35.668575396406865 139.74792157470998 38.68550141096395 35.668577455786235 139.74793245233906 38.68550141096395 35.6685802824288 139.74792404026175 38.68550141096395 35.668575396406865 139.74792157470998 38.68550141096395</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_8eee54e9-d129-480e-8aca-13039b92adae">
									<gml:exterior>
										<gml:LinearRing gml:id="line_97a06daa-af11-400f-9139-71d114710c9e">
											<gml:posList>35.668577455786235 139.74793245233906 38.68550141096395 35.668575396406865 139.74792157470998 38.68550141096395 35.6685725697646 139.7479299869554 38.68550141096395 35.668577455786235 139.74793245233906 38.68550141096395</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_00220846-41ce-4646-961e-8e2f75475ce9">
									<gml:exterior>
										<gml:LinearRing gml:id="line_ef56902c-a8be-4920-9e8f-f4d555732805">
											<gml:posList>35.668577455786235 139.74793245233906 38.68550141096395 35.66860490590231 139.74795651934778 38.68550141096395 35.6685802824288 139.74792404026175 38.68550141096395 35.668577455786235 139.74793245233906 38.68550141096395</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_e7fe3fe1-0ffa-40d0-b833-2b5101887ccf">
									<gml:exterior>
										<gml:LinearRing gml:id="line_f2e5fcd9-d9e1-4618-a7a0-405869636c5a">
											<gml:posList>35.66860490590231 139.74795651934778 38.68550141096395 35.668577455786235 139.74793245233906 38.68550141096395 35.66857452099137 139.74794118696468 38.68550141096395 35.66860490590231 139.74795651934778 38.68550141096395</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_664a9e5c-48ff-439b-a2a9-aec9a1592721">
									<gml:exterior>
										<gml:LinearRing gml:id="line_f2b144eb-2047-4889-96e7-cc82ff64ed44">
											<gml:posList>35.6685802824288 139.74792404026175 38.68550141096395 35.66860490590231 139.74795651934778 38.68550141096395 35.66862411485443 139.74789935105437 38.68550141096395 35.6685802824288 139.74792404026175 38.68550141096395</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_57ad0a26-d139-4948-b0de-dbdef6f4ecc2">
									<gml:exterior>
										<gml:LinearRing gml:id="line_825e647c-faaf-427b-a60e-ca52a1a18e85">
											<gml:posList>35.6685802824288 139.74792404026175 38.68550141096395 35.66862411485443 139.74789935105437 38.68550141096395 35.66859372993633 139.7478840186893 38.68550141096395 35.6685802824288 139.74792404026175 38.68550141096395</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="gml_167345e9-43ac-4d3b-9e16-3704931f1492">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_96271e77-aee7-4713-952a-fdde736f97f2">
									<gml:exterior>
										<gml:LinearRing gml:id="line_d0f1ed0d-3d12-408d-9a56-fc9c87efa57d">
											<gml:posList>35.66851072947919 139.74807942246645 37.902504279616295 35.66858854430902 139.74802250878727 37.902504279616295 35.66857452099137 139.74794118696468 37.902504279616295 35.66851072947919 139.74807942246645 37.902504279616295</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_e3c2b371-9909-41df-b70a-6ec85c20c198">
									<gml:exterior>
										<gml:LinearRing gml:id="line_79eb894e-82be-4b6c-998e-345ab4745e3b">
											<gml:posList>35.66858854430902 139.74802250878727 37.902504279616295 35.66851072947919 139.74807942246645 37.902504279616295 35.66856091215805 139.7481047449641 37.902504279616295 35.66858854430902 139.74802250878727 37.902504279616295</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_be2a58e6-c688-430c-be60-f71f68a2defb">
									<gml:exterior>
										<gml:LinearRing gml:id="line_4a9cb93c-bdb9-4386-9a86-8b4edbaa901d">
											<gml:posList>35.66851072947919 139.74807942246645 37.902504279616295 35.66857452099137 139.74794118696468 37.902504279616295 35.66856262697436 139.74792496973683 37.902504279616295 35.66851072947919 139.74807942246645 37.902504279616295</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_cd52f043-abfe-46b2-a2d6-c2a5e231d68a">
									<gml:exterior>
										<gml:LinearRing gml:id="line_ee883870-b88d-4151-8a7f-db69f48755e0">
											<gml:posList>35.66857452099137 139.74794118696468 37.902504279616295 35.66858854430902 139.74802250878727 37.902504279616295 35.66860490590231 139.74795651934778 37.902504279616295 35.66857452099137 139.74794118696468 37.902504279616295</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_829e5f80-1b16-4123-bd1e-06d3e1b2776c">
									<gml:exterior>
										<gml:LinearRing gml:id="line_f8b56bbb-7cc8-4131-afcd-c2a804c18184">
											<gml:posList>35.66856262697436 139.74792496973683 37.902504279616295 35.66857452099137 139.74794118696468 37.902504279616295 35.668577455786235 139.74793245233906 37.902504279616295 35.66856262697436 139.74792496973683 37.902504279616295</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_d5d47a9c-ba0e-451b-82b7-d34f0a88c56a">
									<gml:exterior>
										<gml:LinearRing gml:id="line_86c1b06b-6500-4aba-ac73-185094077f93">
											<gml:posList>35.668621903878346 139.74798230203365 37.902504279616295 35.66865114500591 139.74795222318627 37.902504279616295 35.66860490590231 139.74795651934778 37.902504279616295 35.668621903878346 139.74798230203365 37.902504279616295</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_5ecc587e-a5d3-4960-abca-f008a0b8c120">
									<gml:exterior>
										<gml:LinearRing gml:id="line_03331aec-9e72-4a8e-8c95-f7b46c930433">
											<gml:posList>35.66865114500591 139.74795222318627 37.902504279616295 35.668621903878346 139.74798230203365 37.902504279616295 35.66863826445226 139.7479905575038 37.902504279616295 35.66865114500591 139.74795222318627 37.902504279616295</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_06f710e9-c1c4-4178-a844-38df26daded0">
									<gml:exterior>
										<gml:LinearRing gml:id="line_76d0d2c2-c521-4891-bec3-b0963f26e4b0">
											<gml:posList>35.668621903878346 139.74798230203365 37.902504279616295 35.66860490590231 139.74795651934778 37.902504279616295 35.66858854430902 139.74802250878727 37.902504279616295 35.668621903878346 139.74798230203365 37.902504279616295</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_fbb7eb05-e0d9-41fb-a90d-bec52ae12cd1">
									<gml:exterior>
										<gml:LinearRing gml:id="line_b0c24eb7-3c54-4e52-95b6-e44e9accda15">
											<gml:posList>35.66860490590231 139.74795651934778 37.902504279616295 35.66865114500591 139.74795222318627 37.902504279616295 35.66862411485443 139.74789935105437 37.902504279616295 35.66860490590231 139.74795651934778 37.902504279616295</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_a80262f9-9705-4729-9ab2-11ac18c36de4">
									<gml:exterior>
										<gml:LinearRing gml:id="line_0202a61c-834f-4938-bd21-3baa8ebcbad0">
											<gml:posList>35.66862411485443 139.74789935105437 37.902504279616295 35.66865114500591 139.74795222318627 37.902504279616295 35.668664937877324 139.74791995042165 37.902504279616295 35.66862411485443 139.74789935105437 37.902504279616295</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_a1df1e08-4bc8-4342-a912-4c6d51cc5740">
									<gml:exterior>
										<gml:LinearRing gml:id="line_521a2d39-e705-4545-b89d-d87315a1b9b3">
											<gml:posList>35.668664937877324 139.74791995042165 37.902504279616295 35.66865114500591 139.74795222318627 37.902504279616295 35.66865366644167 139.74795349557397 37.902504279616295 35.668664937877324 139.74791995042165 37.902504279616295</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_a4c84405-4d2c-484e-aa13-7f55fefec2db">
									<gml:exterior>
										<gml:LinearRing gml:id="line_591a5d98-260c-4cfb-8557-d27be71a3fa9">
											<gml:posList>35.668621903878346 139.74798230203365 37.902504279616295 35.66858854430902 139.74802250878727 37.902504279616295 35.668605516458285 139.74803107289867 37.902504279616295 35.668621903878346 139.74798230203365 37.902504279616295</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="roof_TMmnt0161_p991_0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly_TMmnt0161_p991_0">
									<gml:exterior>
										<gml:LinearRing gml:id="line_TMmnt0161_p991_0">
											<gml:posList>35.668624261631244 139.74779713516125 34.6145077 35.66859651403997 139.7478778744316 34.61379934 35.66866771017094 139.74791461839294 34.61732286 35.66870048759267 139.74781924194826 34.61816069 35.66868917663862 139.747813404338 34.61760013 35.66867744484322 139.74782458353985 34.61713868 35.668624261631244 139.74779713516125 34.6145077</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="roof_TMmnt0161_p992_0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly_TMmnt0161_p992_0">
									<gml:exterior>
										<gml:LinearRing gml:id="line_TMmnt0161_p992_0">
											<gml:posList>35.66861955321487 139.74791262976777 37.87509983 35.668626226593894 139.74789321238558 37.87526873 35.66859650191569 139.74787787163882 37.87379905 35.66858542912262 139.74791009092453 37.87351913 35.66860003153536 139.7479025541768 37.87413439 35.66861955321487 139.74791262976777 37.87509983</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="gml_aeb3eb89-d3d7-4e89-bc8c-c941269c75f8">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_3c579667-1bb3-438c-9bae-9e9b4c043fac">
									<gml:exterior>
										<gml:LinearRing gml:id="line_22c7453a-69c7-44a9-8a56-689c1a71408c">
											<gml:posList>35.6686747729746 139.74783019638366 35.550506904128014 35.668664937877324 139.74791995042165 35.550506904128014 35.6686970039924 139.74782451718383 35.550506904128014 35.6686747729746 139.74783019638366 35.550506904128014</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_9b48649b-9c7f-49eb-b942-f3e373f6ebc0">
									<gml:exterior>
										<gml:LinearRing gml:id="line_a7544d30-3f63-4220-8c5a-db319c5cb624">
											<gml:posList>35.668664937877324 139.74791995042165 35.550506904128014 35.6686747729746 139.74783019638366 35.550506904128014 35.66859372993633 139.7478840186893 35.550506904128014 35.668664937877324 139.74791995042165 35.550506904128014</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_894d1e72-24f7-4146-b3a5-87fa62f0f387">
									<gml:exterior>
										<gml:LinearRing gml:id="line_c0cf536b-7877-49e5-8eae-d0c8bf222f44">
											<gml:posList>35.6686747729746 139.74783019638366 35.550506904128014 35.6686970039924 139.74782451718383 35.550506904128014 35.668686432971406 139.74781918309426 35.550506904128014 35.6686747729746 139.74783019638366 35.550506904128014</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_2ea587dd-aea8-4de1-b471-70b604da727b">
									<gml:exterior>
										<gml:LinearRing gml:id="line_58e57841-82ae-44fc-b32d-8cf5bfe549c5">
											<gml:posList>35.66859372993633 139.7478840186893 35.550506904128014 35.6686747729746 139.74783019638366 35.550506904128014 35.66862094168115 139.74780303297814 35.550506904128014 35.66859372993633 139.7478840186893 35.550506904128014</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_fa61642c-c644-4d07-b12c-0e35ce1985e7">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_094ef61b-3552-49e6-8d9f-a77f90e40b95">
									<gml:exterior>
										<gml:LinearRing gml:id="line_fb3c50fb-1782-4435-96a5-f147ae1356ad">
											<gml:posList>35.668630285119036 139.74781332977528 27.262848212721764 35.66862642811532 139.74781138344156 27.262848212721764 35.668630285119036 139.74781332977528 27.3664706492452 35.668630285119036 139.74781332977528 27.262848212721764</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_c8341d66-c22e-4887-82b8-44c156290ccb">
									<gml:exterior>
										<gml:LinearRing gml:id="line_7408937d-45df-404a-a6ef-6dce69624ef0">
											<gml:posList>35.668630285119036 139.74781332977528 27.3664706492452 35.66862642811532 139.74781138344156 27.262848212721764 35.66862642811532 139.74781138344156 27.3664706492452 35.668630285119036 139.74781332977528 27.3664706492452</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="wall_TMmnt0161_p992_7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly_TMmnt0161_p992_7">
									<gml:exterior>
										<gml:LinearRing gml:id="line_TMmnt0161_p992_7">
											<gml:posList>35.6685732913533 139.7479038266831 37.87291958 35.66858542912262 139.74791009092453 37.87351913 35.66858554966255 139.74791011886649 5.4476359 35.66857341183139 139.74790385459326 5.44703635 35.6685732913533 139.7479038266831 37.87291958</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_55dca880-5980-4b12-bffb-6c63714ff877">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_595ef26d-bdf3-4b3a-939f-087d56b3ee18">
									<gml:exterior>
										<gml:LinearRing gml:id="line_3277fa08-ce5f-48e1-ac6c-021f5340aa76">
											<gml:posList>35.66868526091045 139.74782098748136 29.319015815260826 35.668690275854296 139.74782351812135 28.71765930891317 35.668690275854296 139.74782351812135 30.426239326003014 35.66868526091045 139.74782098748136 29.319015815260826</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_98af2d16-280c-4510-84fd-71cc129287d9">
									<gml:exterior>
										<gml:LinearRing gml:id="line_551b04f1-5947-4408-8ccc-1ed5e0005c44">
											<gml:posList>35.668690275854296 139.74782351812135 28.71765930891317 35.66868526091045 139.74782098748136 29.319015815260826 35.66868526091045 139.74782098748136 28.71765930891317 35.668690275854296 139.74782351812135 28.71765930891317</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_27fac7e5-6aa3-45f6-881e-2a49a2fb65d3">
									<gml:exterior>
										<gml:LinearRing gml:id="line_46f64546-900a-479f-a7d6-ebd76501e850">
											<gml:posList>35.66868526091045 139.74782098748136 29.319015815260826 35.668690275854296 139.74782351812135 30.426239326003014 35.66868477962785 139.74782074477844 30.426239326003014 35.66868526091045 139.74782098748136 29.319015815260826</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_9ffc5296-0ea7-4a81-9ae3-42c5aede1f51">
									<gml:exterior>
										<gml:LinearRing gml:id="line_b57d24b0-f50b-4e12-9643-c52e98d89b65">
											<gml:posList>35.66868526091045 139.74782098748136 29.319015815260826 35.66868477962785 139.74782074477844 30.426239326003014 35.66868477962785 139.74782074477844 29.319015815260826 35.66868526091045 139.74782098748136 29.319015815260826</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_8d7f543b-a843-4dfa-bcbe-556d451f9e9a">
									<gml:exterior>
										<gml:LinearRing gml:id="line_b1cce0e2-135a-4507-bd75-57e2534fd6b7">
											<gml:posList>35.66868526091045 139.74782098748136 29.319015815260826 35.66868477962785 139.74782074477844 29.319015815260826 35.66868477962785 139.74782074477844 28.71765930891317 35.66868526091045 139.74782098748136 29.319015815260826</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_da0222ae-ef0d-4dbe-b79a-cb2265cd3bd6">
									<gml:exterior>
										<gml:LinearRing gml:id="line_bd47a1b1-dc27-4f14-a6eb-883c4883e064">
											<gml:posList>35.66868526091045 139.74782098748136 29.319015815260826 35.66868477962785 139.74782074477844 28.71765930891317 35.66868526091045 139.74782098748136 28.71765930891317 35.66868526091045 139.74782098748136 29.319015815260826</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_b00c6e26-a501-4f4a-9ec7-3198f59f42d5">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_beb09dd7-6bf0-4019-b6e4-a634a1ef709c">
									<gml:exterior>
										<gml:LinearRing gml:id="line_379816fc-7846-4742-8c30-062034a91a24">
											<gml:posList>35.6686752542573 139.74783043925513 20.139732673170982 35.66868610967223 139.747835916983 21.24694855451864 35.66868610967223 139.747835916983 19.538376166823326 35.6686752542573 139.74783043925513 20.139732673170982</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_4fe63fa6-146d-4349-9e19-4e4916b06538">
									<gml:exterior>
										<gml:LinearRing gml:id="line_88c7da74-ac0a-4150-bddf-39c75d7abda8">
											<gml:posList>35.66868610967223 139.747835916983 21.24694855451864 35.6686752542573 139.74783043925513 20.139732673170982 35.6686747729746 139.74783019638366 21.24694855451864 35.66868610967223 139.747835916983 21.24694855451864</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_d7b08645-010d-4919-a530-2e2022aed1aa">
									<gml:exterior>
										<gml:LinearRing gml:id="line_bc87d663-1307-4c81-aaad-560fa81f5b57">
											<gml:posList>35.6686747729746 139.74783019638366 21.24694855451864 35.6686752542573 139.74783043925513 20.139732673170982 35.6686747729746 139.74783019638366 20.139732673170982 35.6686747729746 139.74783019638366 21.24694855451864</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_243b7682-6d3b-4440-99ed-1f15343574ea">
									<gml:exterior>
										<gml:LinearRing gml:id="line_1096ba38-cb96-420b-a5a3-90c6bfdef7c8">
											<gml:posList>35.6686752542573 139.74783043925513 20.139732673170982 35.66868610967223 139.747835916983 19.538376166823326 35.6686752542573 139.74783043925513 19.538376166823326 35.6686752542573 139.74783043925513 20.139732673170982</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_008e28e9-f890-4dce-96cb-03e864b01ebc">
									<gml:exterior>
										<gml:LinearRing gml:id="line_202c4bba-e019-491b-8b8e-9177e1622707">
											<gml:posList>35.6686752542573 139.74783043925513 20.139732673170982 35.6686752542573 139.74783043925513 19.538376166823326 35.6686747729746 139.74783019638366 20.139732673170982 35.6686752542573 139.74783043925513 20.139732673170982</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_ab8ed70d-59e1-4b54-ace5-c5d5d536b905">
									<gml:exterior>
										<gml:LinearRing gml:id="line_0e1d67f7-bede-4c0b-9700-daa9d975b2d0">
											<gml:posList>35.6686747729746 139.74783019638366 20.139732673170982 35.6686752542573 139.74783043925513 19.538376166823326 35.6686747729746 139.74783019638366 19.538376166823326 35.6686747729746 139.74783019638366 20.139732673170982</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_371bb565-5685-4a16-a5e1-b8ae48e5c8af">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_25551357-2461-4d8c-ba5b-b5db26a3df04">
									<gml:exterior>
										<gml:LinearRing gml:id="line_045c047a-39bb-4829-a5c5-2036c0272dd4">
											<gml:posList>35.6686752542573 139.74783043925513 17.07996399641317 35.66868610967223 139.747835916983 18.187187507155357 35.66868610967223 139.747835916983 16.478615119460045 35.6686752542573 139.74783043925513 17.07996399641317</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_e28bcdfc-9366-4d9f-ae2a-c1f8b91a4f15">
									<gml:exterior>
										<gml:LinearRing gml:id="line_09d1ecf9-7f3e-4cb6-a25d-0fa1fa273e3b">
											<gml:posList>35.66868610967223 139.747835916983 18.187187507155357 35.6686752542573 139.74783043925513 17.07996399641317 35.6686747729746 139.74783019638366 18.187187507155357 35.66868610967223 139.747835916983 18.187187507155357</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_70a31072-1e99-4761-accc-880075686f77">
									<gml:exterior>
										<gml:LinearRing gml:id="line_1de9bc08-2bff-408c-8c5e-3f6d2d7fc873">
											<gml:posList>35.6686747729746 139.74783019638366 18.187187507155357 35.6686752542573 139.74783043925513 17.07996399641317 35.6686747729746 139.74783019638366 17.07996399641317 35.6686747729746 139.74783019638366 18.187187507155357</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_ee098b8c-4861-4a6c-b57a-94cb44a0126e">
									<gml:exterior>
										<gml:LinearRing gml:id="line_1eeb6039-e439-4f9f-a4ea-7f1230594d46">
											<gml:posList>35.6686752542573 139.74783043925513 17.07996399641317 35.66868610967223 139.747835916983 16.478615119460045 35.6686752542573 139.74783043925513 16.478615119460045 35.6686752542573 139.74783043925513 17.07996399641317</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_83ff0009-2932-40b7-a53e-4664def1b595">
									<gml:exterior>
										<gml:LinearRing gml:id="line_6d264227-5572-4526-81e2-4a62878e8422">
											<gml:posList>35.6686752542573 139.74783043925513 17.07996399641317 35.6686752542573 139.74783043925513 16.478615119460045 35.6686747729746 139.74783019638366 17.07996399641317 35.6686752542573 139.74783043925513 17.07996399641317</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_057d5127-0d47-4771-be96-81e3cdc4d1fb">
									<gml:exterior>
										<gml:LinearRing gml:id="line_c886f810-7d68-4933-9a94-bf868e1e77e7">
											<gml:posList>35.6686747729746 139.74783019638366 17.07996399641317 35.6686752542573 139.74783043925513 16.478615119460045 35.6686747729746 139.74783019638366 16.478615119460045 35.6686747729746 139.74783019638366 17.07996399641317</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_e8e0bd46-d664-4304-8d49-34116559a40c">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_95833627-d82e-49d3-b287-fa6382790175">
									<gml:exterior>
										<gml:LinearRing gml:id="line_44072c4c-2ec9-4b87-b02a-cedff13b780f">
											<gml:posList>35.6686752542573 139.74783043925513 32.37877686262411 35.6686747729746 139.74783019638366 33.486000373366295 35.66868610967223 139.747835916983 33.486000373366295 35.6686752542573 139.74783043925513 32.37877686262411</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_a0ad0672-9b03-4d94-bb4f-b0449a59a3a0">
									<gml:exterior>
										<gml:LinearRing gml:id="line_84f3213a-7eb3-4c66-8042-da417e40c3ae">
											<gml:posList>35.6686747729746 139.74783019638366 33.486000373366295 35.6686752542573 139.74783043925513 32.37877686262411 35.6686747729746 139.74783019638366 32.37877686262411 35.6686747729746 139.74783019638366 33.486000373366295</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_5dac9e16-47e0-40a1-a21a-b68feb2e1e22">
									<gml:exterior>
										<gml:LinearRing gml:id="line_c7bbe86d-21b0-45c8-bc52-5d3b2539580e">
											<gml:posList>35.6686752542573 139.74783043925513 32.37877686262411 35.66868610967223 139.747835916983 33.486000373366295 35.66868610967223 139.747835916983 31.77742035627645 35.6686752542573 139.74783043925513 32.37877686262411</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_2ebf7918-f7e5-4e31-acfe-477d6c832d9f">
									<gml:exterior>
										<gml:LinearRing gml:id="line_e3ea0d01-e13f-4d81-a39f-b423c8e3e827">
											<gml:posList>35.6686752542573 139.74783043925513 32.37877686262411 35.66868610967223 139.747835916983 31.77742035627645 35.6686752542573 139.74783043925513 31.77742035627645 35.6686752542573 139.74783043925513 32.37877686262411</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_fb495888-e147-4125-8506-cede03ec75a4">
									<gml:exterior>
										<gml:LinearRing gml:id="line_a75ad386-af28-49ce-a017-5d090d4c45cf">
											<gml:posList>35.6686752542573 139.74783043925513 32.37877686262411 35.6686752542573 139.74783043925513 31.77742035627645 35.6686747729746 139.74783019638366 32.37877686262411 35.6686752542573 139.74783043925513 32.37877686262411</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_09923c84-59a5-44cf-945e-3db80f98ab30">
									<gml:exterior>
										<gml:LinearRing gml:id="line_c28b2aa3-4051-40f2-b90a-0e46c0d5dab6">
											<gml:posList>35.6686747729746 139.74783019638366 32.37877686262411 35.6686752542573 139.74783043925513 31.77742035627645 35.6686747729746 139.74783019638366 31.77742035627645 35.6686747729746 139.74783019638366 32.37877686262411</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="wall_TMmnt0161_p992_5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly_TMmnt0161_p992_5">
									<gml:exterior>
										<gml:LinearRing gml:id="line_TMmnt0161_p992_5">
											<gml:posList>35.66856343406604 139.7481044236526 37.87391003 35.66851325484911 139.7480785266932 37.87142926 35.668513375020865 139.7480785554907 5.44554602 35.668563554493765 139.74810445258177 5.4480268 35.66856343406604 139.7481044236526 37.87391003</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_69ae9baf-277f-4709-8c69-071c0b9a88f8">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_901f0f88-b5be-40aa-9857-84d3213c7e73">
									<gml:exterior>
										<gml:LinearRing gml:id="line_c22b0002-2aa4-42e8-b689-848623ea9fd9">
											<gml:posList>35.66859951867811 139.74786679070854 33.41845734358114 35.66859372993633 139.7478840186893 35.550506904128014 35.66860158385983 139.74786064439732 33.41845734358114 35.66859951867811 139.74786679070854 33.41845734358114</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_627039cf-30d9-4c5a-807b-a18b5bf8b88e">
									<gml:exterior>
										<gml:LinearRing gml:id="line_ba7d21ac-2abf-4010-92bd-14a2f4ef2e98">
											<gml:posList>35.66859372993633 139.7478840186893 35.550506904128014 35.66859951867811 139.74786679070854 33.41845734358114 35.66859951867811 139.74786679070854 32.10109741926473 35.66859372993633 139.7478840186893 35.550506904128014</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_ed3d7544-567b-4826-8a59-293001afd04b">
									<gml:exterior>
										<gml:LinearRing gml:id="line_b4b3f315-1b83-4167-aa90-693dd96feebe">
											<gml:posList>35.66860158385983 139.74786064439732 33.41845734358114 35.66859372993633 139.7478840186893 35.550506904128014 35.668604037043295 139.7478533432813 33.41845734358114 35.66860158385983 139.74786064439732 33.41845734358114</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_e63ba3e9-feed-4341-852d-591d2af6c976">
									<gml:exterior>
										<gml:LinearRing gml:id="line_ef6de3eb-39b4-45e5-8227-e294f84e6529">
											<gml:posList>35.668604037043295 139.7478533432813 33.41845734358114 35.66859372993633 139.7478840186893 35.550506904128014 35.66860610222434 139.7478471969694 33.41845734358114 35.668604037043295 139.7478533432813 33.41845734358114</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_eaca28da-34ad-4234-9cf1-10f11f5d94c2">
									<gml:exterior>
										<gml:LinearRing gml:id="line_31bfc0fa-bdac-412a-b779-cddf71164eff">
											<gml:posList>35.66860158385983 139.74786064439732 33.41845734358114 35.668604037043295 139.7478533432813 33.41845734358114 35.66860158385983 139.74786064439732 32.10109741926473 35.66860158385983 139.74786064439732 33.41845734358114</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_36bfae45-e113-4c3e-b302-9788d332af6e">
									<gml:exterior>
										<gml:LinearRing gml:id="line_e2a27906-bbfb-4cb1-8a23-2ef403bbfccb">
											<gml:posList>35.668604037043295 139.7478533432813 32.10109741926473 35.66860158385983 139.74786064439732 32.10109741926473 35.668604037043295 139.7478533432813 33.41845734358114 35.668604037043295 139.7478533432813 32.10109741926473</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_fa21993a-3105-4f6a-a37a-4a6d45ee8542">
									<gml:exterior>
										<gml:LinearRing gml:id="line_e2c7b9d8-b8b6-4bb2-b9ed-ddcd0a6ab246">
											<gml:posList>35.66860158385983 139.74786064439732 32.10109741926473 35.668604037043295 139.7478533432813 32.10109741926473 35.66860158385983 139.74786064439732 30.401481940749107 35.66860158385983 139.74786064439732 32.10109741926473</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_aca75637-287c-4602-9d1d-00e49d4d1776">
									<gml:exterior>
										<gml:LinearRing gml:id="line_7141b55a-254d-4838-ac47-867503c6957d">
											<gml:posList>35.66860158385983 139.74786064439732 30.401481940749107 35.668604037043295 139.7478533432813 30.401481940749107 35.66860158385983 139.74786064439732 29.08411438703817 35.66860158385983 139.74786064439732 30.401481940749107</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_4308a2da-1156-4166-8c43-afb56b41053b">
									<gml:exterior>
										<gml:LinearRing gml:id="line_9b90a162-c724-4c2f-9883-e27f1d48fd4f">
											<gml:posList>35.668604037043295 139.7478533432813 30.401481940749107 35.66860158385983 139.74786064439732 30.401481940749107 35.668604037043295 139.7478533432813 32.10109741926473 35.668604037043295 139.7478533432813 30.401481940749107</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_b639c42b-4619-4560-973f-f266d339220a">
									<gml:exterior>
										<gml:LinearRing gml:id="line_81e226bf-e254-4f8e-ac6f-06247d94cf65">
											<gml:posList>35.668604037043295 139.7478533432813 29.08411438703817 35.66860158385983 139.74786064439732 29.08411438703817 35.668604037043295 139.7478533432813 30.401481940749107 35.668604037043295 139.7478533432813 29.08411438703817</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_a4a8058c-a12f-471a-a394-85089ad2679c">
									<gml:exterior>
										<gml:LinearRing gml:id="line_022921f1-3350-424b-a033-3e509b745606">
											<gml:posList>35.66860158385983 139.74786064439732 29.08411438703817 35.668604037043295 139.7478533432813 29.08411438703817 35.66860158385983 139.74786064439732 27.384498908522545 35.66860158385983 139.74786064439732 29.08411438703817</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_dd9cdcbe-0c56-40a9-aa3e-b2b2666cb266">
									<gml:exterior>
										<gml:LinearRing gml:id="line_f7746063-4f3f-428c-aed2-f864b8885258">
											<gml:posList>35.66860158385983 139.74786064439732 27.384498908522545 35.668604037043295 139.7478533432813 27.384498908522545 35.66860158385983 139.74786064439732 26.06713898420614 35.66860158385983 139.74786064439732 27.384498908522545</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_015f2895-5bc9-455e-913a-bf0cc00ccce2">
									<gml:exterior>
										<gml:LinearRing gml:id="line_0ea01a35-bada-4a4d-b8ef-cc9c6f4c850a">
											<gml:posList>35.668604037043295 139.7478533432813 27.384498908522545 35.66860158385983 139.74786064439732 27.384498908522545 35.668604037043295 139.7478533432813 29.08411438703817 35.668604037043295 139.7478533432813 27.384498908522545</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_fd4d321f-6991-4554-8a05-657fc429b80c">
									<gml:exterior>
										<gml:LinearRing gml:id="line_1552cf4c-5eb1-4d9e-bfa7-e4e7871c136d">
											<gml:posList>35.66860610222434 139.7478471969694 33.41845734358114 35.66859372993633 139.7478840186893 35.550506904128014 35.66862094168115 139.74780303297814 35.550506904128014 35.66860610222434 139.7478471969694 33.41845734358114</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_1c28913f-0962-4de6-969f-edde3531baff">
									<gml:exterior>
										<gml:LinearRing gml:id="line_ba03179c-5379-4963-bf7b-d52783f43822">
											<gml:posList>35.66860610222434 139.7478471969694 33.41845734358114 35.66862094168115 139.74780303297814 35.550506904128014 35.66860610222434 139.7478471969694 32.10109741926473 35.66860610222434 139.7478471969694 33.41845734358114</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_85b721d5-8a9a-4fe4-b863-3530291fa453">
									<gml:exterior>
										<gml:LinearRing gml:id="line_6f593aa7-564d-461c-9258-4be4e1c5f574">
											<gml:posList>35.66860610222434 139.7478471969694 30.401481940749107 35.66862094168115 139.74780303297814 35.550506904128014 35.66860610222434 139.7478471969694 29.08411438703817 35.66860610222434 139.7478471969694 30.401481940749107</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_ead0d444-c1d0-459d-aa7f-48a76eef901c">
									<gml:exterior>
										<gml:LinearRing gml:id="line_f6f556eb-5e0f-4a81-8d35-9817de00526e">
											<gml:posList>35.66862094168115 139.74780303297814 35.550506904128014 35.66860610222434 139.7478471969694 30.401481940749107 35.66860610222434 139.7478471969694 32.10109741926473 35.66862094168115 139.74780303297814 35.550506904128014</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_26360abd-ff30-4b03-94bd-3f5a6a458957">
									<gml:exterior>
										<gml:LinearRing gml:id="line_b4a5d26b-a378-489e-a358-c3134415bb81">
											<gml:posList>35.66862094168115 139.74780303297814 9.79950745344442 35.66860610222434 139.7478471969694 23.050155951979576 35.66862094168115 139.74780303297814 35.550506904128014 35.66862094168115 139.74780303297814 9.79950745344442</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_7b897a1c-f8a6-4d66-9922-1e5257bc7d74">
									<gml:exterior>
										<gml:LinearRing gml:id="line_601141e8-8177-4a36-bac5-2719ec676199">
											<gml:posList>35.66860610222434 139.7478471969694 23.050155951979576 35.66862094168115 139.74780303297814 9.79950745344442 35.66860610222434 139.7478471969694 21.350548102858482 35.66860610222434 139.7478471969694 23.050155951979576</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_31b359ea-3b57-4d0a-8bbd-30d76eb144da">
									<gml:exterior>
										<gml:LinearRing gml:id="line_38669707-6422-41ce-b484-12977f0dc537">
											<gml:posList>35.66860610222434 139.7478471969694 21.350548102858482 35.66862094168115 139.74780303297814 9.79950745344442 35.66860610222434 139.7478471969694 20.033180549147545 35.66860610222434 139.7478471969694 21.350548102858482</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_2b68591f-9015-43dc-9c63-fb8d33388873">
									<gml:exterior>
										<gml:LinearRing gml:id="line_c7b5e840-f06b-4ca5-8736-62d5930bbf9d">
											<gml:posList>35.66860610222434 139.7478471969694 20.033180549147545 35.66862094168115 139.74780303297814 9.79950745344442 35.668604037043295 139.7478533432813 20.033180549147545 35.66860610222434 139.7478471969694 20.033180549147545</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_72d876a0-82c5-4a25-b43c-ec499af939a1">
									<gml:exterior>
										<gml:LinearRing gml:id="line_a1c3ad20-3fa8-4d65-acaa-d807ebfe1f8c">
											<gml:posList>35.66859951867811 139.74786679070854 30.401481940749107 35.66859951867811 139.74786679070854 32.10109741926473 35.66860158385983 139.74786064439732 32.10109741926473 35.66859951867811 139.74786679070854 30.401481940749107</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_adfe8e6f-6dc2-427d-9520-b1e7c677e03d">
									<gml:exterior>
										<gml:LinearRing gml:id="line_74d340b3-0e90-4cc0-b5a2-caca300ccbfc">
											<gml:posList>35.66859951867811 139.74786679070854 32.10109741926473 35.66859951867811 139.74786679070854 30.401481940749107 35.66859372993633 139.7478840186893 35.550506904128014 35.66859951867811 139.74786679070854 32.10109741926473</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_cc37e01b-dacc-4e22-baba-f96ad3862f04">
									<gml:exterior>
										<gml:LinearRing gml:id="line_a92cecb0-95b6-4fc4-be0f-2c3da2304157">
											<gml:posList>35.66859951867811 139.74786679070854 30.401481940749107 35.66860158385983 139.74786064439732 32.10109741926473 35.66860158385983 139.74786064439732 30.401481940749107 35.66859951867811 139.74786679070854 30.401481940749107</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_ae201c8f-ba86-4e03-9924-84967d782f2f">
									<gml:exterior>
										<gml:LinearRing gml:id="line_8ba2a7a7-8e43-4e52-afde-cceba54f72d1">
											<gml:posList>35.66859951867811 139.74786679070854 27.384498908522545 35.66859951867811 139.74786679070854 29.08411438703817 35.66860158385983 139.74786064439732 29.08411438703817 35.66859951867811 139.74786679070854 27.384498908522545</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_0c3b036e-0060-42f2-be29-838a3fd78cbc">
									<gml:exterior>
										<gml:LinearRing gml:id="line_37db9f5c-4f7a-4c94-a57c-253f6ecb6540">
											<gml:posList>35.66859951867811 139.74786679070854 29.08411438703817 35.66859951867811 139.74786679070854 27.384498908522545 35.6685802824288 139.74792404026175 38.68550141096395 35.66859951867811 139.74786679070854 29.08411438703817</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_656b1a41-aeab-4676-b769-9cd7bc9ac71b">
									<gml:exterior>
										<gml:LinearRing gml:id="line_6dc42f6b-bfe9-4dce-926c-b6b9472ab95a">
											<gml:posList>35.66859951867811 139.74786679070854 27.384498908522545 35.66860158385983 139.74786064439732 29.08411438703817 35.66860158385983 139.74786064439732 27.384498908522545 35.66859951867811 139.74786679070854 27.384498908522545</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_891cb83a-1fe8-49ac-91d9-7e874ab535ee">
									<gml:exterior>
										<gml:LinearRing gml:id="line_aedc2c47-fb13-4acf-8bb6-c2915e1641a2">
											<gml:posList>35.66859951867811 139.74786679070854 24.367523505690514 35.66859951867811 139.74786679070854 26.06713898420614 35.66860158385983 139.74786064439732 26.06713898420614 35.66859951867811 139.74786679070854 24.367523505690514</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_eb2dee5a-840b-4849-af58-81bd322f0cc5">
									<gml:exterior>
										<gml:LinearRing gml:id="line_caddff48-ec2f-4401-b7c1-ca971116ed06">
											<gml:posList>35.66859951867811 139.74786679070854 26.06713898420614 35.66859951867811 139.74786679070854 24.367523505690514 35.6685802824288 139.74792404026175 38.68550141096395 35.66859951867811 139.74786679070854 26.06713898420614</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_c3fd3b32-fb07-4129-aafd-f4164a97b120">
									<gml:exterior>
										<gml:LinearRing gml:id="line_e6fcce2d-12a9-4bc6-8bcd-855b3ab608ca">
											<gml:posList>35.66859951867811 139.74786679070854 24.367523505690514 35.66860158385983 139.74786064439732 26.06713898420614 35.66860158385983 139.74786064439732 24.367523505690514 35.66859951867811 139.74786679070854 24.367523505690514</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_af7fe22f-ee24-463c-94fe-8fc7d636037c">
									<gml:exterior>
										<gml:LinearRing gml:id="line_0ff5eb3b-c13d-4221-bceb-24e575e280ca">
											<gml:posList>35.66860158385983 139.74786064439732 24.367523505690514 35.66860158385983 139.74786064439732 26.06713898420614 35.668604037043295 139.7478533432813 26.06713898420614 35.66860158385983 139.74786064439732 24.367523505690514</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_8601cbf2-6c92-446a-b3ef-d9a0c294d93f">
									<gml:exterior>
										<gml:LinearRing gml:id="line_bf41fab6-2b12-405f-86df-ec2c5c19518e">
											<gml:posList>35.66859951867811 139.74786679070854 21.350548102858482 35.66859951867811 139.74786679070854 23.050155951979576 35.66860158385983 139.74786064439732 23.050155951979576 35.66859951867811 139.74786679070854 21.350548102858482</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_4c8c07d4-7730-4aea-af12-00b8945c7d22">
									<gml:exterior>
										<gml:LinearRing gml:id="line_98aaa2c2-95e3-4c25-a6c8-5a18b88ce288">
											<gml:posList>35.66859951867811 139.74786679070854 23.050155951979576 35.66859951867811 139.74786679070854 21.350548102858482 35.6685802824288 139.74792404026175 6.3942492747334825 35.66859951867811 139.74786679070854 23.050155951979576</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_18c3d570-d49e-4927-a81e-791bcabc9256">
									<gml:exterior>
										<gml:LinearRing gml:id="line_a2ca3cd7-2ef3-4784-8989-8ac0772cc9d1">
											<gml:posList>35.66859951867811 139.74786679070854 21.350548102858482 35.66860158385983 139.74786064439732 23.050155951979576 35.66860158385983 139.74786064439732 21.350548102858482 35.66859951867811 139.74786679070854 21.350548102858482</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_95405f70-a770-4d66-a668-f28ef6c4c5f4">
									<gml:exterior>
										<gml:LinearRing gml:id="line_89da946d-22df-4542-88f4-c6154aa78d43">
											<gml:posList>35.66860158385983 139.74786064439732 21.350548102858482 35.66860158385983 139.74786064439732 23.050155951979576 35.668604037043295 139.7478533432813 23.050155951979576 35.66860158385983 139.74786064439732 21.350548102858482</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_5fad0a80-bb9a-4664-9427-ed7e8f9d238e">
									<gml:exterior>
										<gml:LinearRing gml:id="line_514b8937-6b6e-413c-ad6b-9174b71a2a84">
											<gml:posList>35.668604037043295 139.7478533432813 26.06713898420614 35.66860158385983 139.74786064439732 26.06713898420614 35.668604037043295 139.7478533432813 27.384498908522545 35.668604037043295 139.7478533432813 26.06713898420614</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_c777fd60-f663-45c7-b613-b71bca0ff785">
									<gml:exterior>
										<gml:LinearRing gml:id="line_872d7c05-2e72-45fc-a65e-77c33292fc6f">
											<gml:posList>35.668604037043295 139.7478533432813 30.401481940749107 35.668604037043295 139.7478533432813 32.10109741926473 35.66860610222434 139.7478471969694 32.10109741926473 35.668604037043295 139.7478533432813 30.401481940749107</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_915d60e7-1471-4495-9f5a-a2a4b1823a2e">
									<gml:exterior>
										<gml:LinearRing gml:id="line_8504d047-7962-4a76-8300-f4eac402648f">
											<gml:posList>35.66860158385983 139.74786064439732 24.367523505690514 35.668604037043295 139.7478533432813 26.06713898420614 35.668604037043295 139.7478533432813 24.367523505690514 35.66860158385983 139.74786064439732 24.367523505690514</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_78db6a3a-4069-4e7d-b153-baf50b214c7c">
									<gml:exterior>
										<gml:LinearRing gml:id="line_880e7d3c-02f6-4e13-b530-48a12c9ccede">
											<gml:posList>35.668604037043295 139.7478533432813 30.401481940749107 35.66860610222434 139.7478471969694 32.10109741926473 35.66860610222434 139.7478471969694 30.401481940749107 35.668604037043295 139.7478533432813 30.401481940749107</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_c142cc11-0783-4e50-870d-4ca52eeb79f4">
									<gml:exterior>
										<gml:LinearRing gml:id="line_613ab606-f36a-4e4b-b6c5-058ea5485b13">
											<gml:posList>35.66860610222434 139.7478471969694 27.384498908522545 35.668604037043295 139.7478533432813 29.08411438703817 35.66860610222434 139.7478471969694 29.08411438703817 35.66860610222434 139.7478471969694 27.384498908522545</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_0278617b-5eaf-4d65-9eb8-1c8227f248d7">
									<gml:exterior>
										<gml:LinearRing gml:id="line_c59f2649-8847-43c1-a631-4e9647852104">
											<gml:posList>35.668604037043295 139.7478533432813 29.08411438703817 35.66860610222434 139.7478471969694 27.384498908522545 35.668604037043295 139.7478533432813 27.384498908522545 35.668604037043295 139.7478533432813 29.08411438703817</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_60995e4f-e96e-4d98-8254-41c6571e10e4">
									<gml:exterior>
										<gml:LinearRing gml:id="line_4cff47d6-306b-4b89-a23e-cd047ed8f187">
											<gml:posList>35.66860610222434 139.7478471969694 27.384498908522545 35.66860610222434 139.7478471969694 29.08411438703817 35.66862094168115 139.74780303297814 35.550506904128014 35.66860610222434 139.7478471969694 27.384498908522545</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_8b855c0b-c88e-4a74-98b8-3630b18f3c24">
									<gml:exterior>
										<gml:LinearRing gml:id="line_845ca77c-2103-41d3-bf16-6283295a5ba3">
											<gml:posList>35.668604037043295 139.7478533432813 24.367523505690514 35.668604037043295 139.7478533432813 26.06713898420614 35.66860610222434 139.7478471969694 26.06713898420614 35.668604037043295 139.7478533432813 24.367523505690514</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_99a819f6-982f-43a3-9597-3514d9e2de2d">
									<gml:exterior>
										<gml:LinearRing gml:id="line_727a9de0-e692-4eb0-ad51-47b62636fd6b">
											<gml:posList>35.668604037043295 139.7478533432813 24.367523505690514 35.66860610222434 139.7478471969694 26.06713898420614 35.66860610222434 139.7478471969694 24.367523505690514 35.668604037043295 139.7478533432813 24.367523505690514</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_5c1c08e5-15d7-477f-91d6-2443ea4749d5">
									<gml:exterior>
										<gml:LinearRing gml:id="line_2e80a45b-9ae6-4fb8-8b17-1dc91114c30d">
											<gml:posList>35.66860610222434 139.7478471969694 24.367523505690514 35.66860610222434 139.7478471969694 26.06713898420614 35.66862094168115 139.74780303297814 35.550506904128014 35.66860610222434 139.7478471969694 24.367523505690514</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_5860f29c-7206-4c0b-925e-89a8101cf574">
									<gml:exterior>
										<gml:LinearRing gml:id="line_ca5099d4-0bc6-422f-9847-8a26e056e5fb">
											<gml:posList>35.668604037043295 139.7478533432813 21.350548102858482 35.668604037043295 139.7478533432813 23.050155951979576 35.66860610222434 139.7478471969694 23.050155951979576 35.668604037043295 139.7478533432813 21.350548102858482</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_01144aca-edb4-47de-af07-c15a11713d36">
									<gml:exterior>
										<gml:LinearRing gml:id="line_46543c99-750b-4c11-bac6-8e6057029886">
											<gml:posList>35.668604037043295 139.7478533432813 23.050155951979576 35.668604037043295 139.7478533432813 21.350548102858482 35.66860158385983 139.74786064439732 21.350548102858482 35.668604037043295 139.7478533432813 23.050155951979576</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_cde830c1-505f-4dc5-9204-6fb4ffd49b07">
									<gml:exterior>
										<gml:LinearRing gml:id="line_47fcc3b6-5fa2-40ca-931d-61bc738c84b7">
											<gml:posList>35.668604037043295 139.7478533432813 21.350548102858482 35.66860610222434 139.7478471969694 23.050155951979576 35.66860610222434 139.7478471969694 21.350548102858482 35.668604037043295 139.7478533432813 21.350548102858482</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_e5a8c37e-8fc5-4c32-9a4e-a9bbaecbd3ba">
									<gml:exterior>
										<gml:LinearRing gml:id="line_8ce227ef-1858-4701-b130-8b08b746409a">
											<gml:posList>35.66862094168115 139.74780303297814 35.550506904128014 35.66860610222434 139.7478471969694 23.050155951979576 35.66860610222434 139.7478471969694 24.367523505690514 35.66862094168115 139.74780303297814 35.550506904128014</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_f10f4cb9-f523-455c-8223-ed5723565a95">
									<gml:exterior>
										<gml:LinearRing gml:id="line_1448ff6b-f5ab-4c9b-a6a4-47fae8d527d8">
											<gml:posList>35.6685802824288 139.74792404026175 6.3942492747334825 35.66859951867811 139.74786679070854 20.033180549147545 35.66862094168115 139.74780303297814 9.79950745344442 35.6685802824288 139.74792404026175 6.3942492747334825</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_a1a42daf-7541-4e1a-a3cd-7583cb967d4b">
									<gml:exterior>
										<gml:LinearRing gml:id="line_933437f5-f375-47d1-ac94-9ccd8cd0839e">
											<gml:posList>35.66859951867811 139.74786679070854 20.033180549147545 35.6685802824288 139.74792404026175 6.3942492747334825 35.66859951867811 139.74786679070854 21.350548102858482 35.66859951867811 139.74786679070854 20.033180549147545</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_82fa7609-3fb1-4054-aaa3-2cfcaa1b9a28">
									<gml:exterior>
										<gml:LinearRing gml:id="line_05856299-6e8c-4a82-ba1a-07d9cd3d25e4">
											<gml:posList>35.66859951867811 139.74786679070854 23.050155951979576 35.6685802824288 139.74792404026175 6.3942492747334825 35.6685802824288 139.74792404026175 38.68550141096395 35.66859951867811 139.74786679070854 23.050155951979576</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_9fa87b93-25ff-425d-9a9d-e81342e45815">
									<gml:exterior>
										<gml:LinearRing gml:id="line_fd11c37c-36e4-49e0-97bd-10d3791f8905">
											<gml:posList>35.6685802824288 139.74792404026175 38.68550141096395 35.66859951867811 139.74786679070854 24.367523505690514 35.66859951867811 139.74786679070854 23.050155951979576 35.6685802824288 139.74792404026175 38.68550141096395</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_3c42c6d2-961d-4071-85e3-ee17c5449394">
									<gml:exterior>
										<gml:LinearRing gml:id="line_7e2e84c5-1597-4455-b4e1-d9dc3925fcb6">
											<gml:posList>35.6685802824288 139.74792404026175 38.68550141096395 35.66859951867811 139.74786679070854 27.384498908522545 35.66859951867811 139.74786679070854 26.06713898420614 35.6685802824288 139.74792404026175 38.68550141096395</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_e0612c30-d69c-4551-bc5c-03cfeb150507">
									<gml:exterior>
										<gml:LinearRing gml:id="line_3e1f5c99-de0c-4395-b9de-c18d9687c784">
											<gml:posList>35.66859951867811 139.74786679070854 30.401481940749107 35.6685802824288 139.74792404026175 38.68550141096395 35.66859372993633 139.7478840186893 35.550506904128014 35.66859951867811 139.74786679070854 30.401481940749107</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_99844600-1706-4d23-b8a2-35d91fb3e11a">
									<gml:exterior>
										<gml:LinearRing gml:id="line_a8e80619-7d9b-45b1-b7cc-dadca83d90b3">
											<gml:posList>35.6685802824288 139.74792404026175 38.68550141096395 35.66859951867811 139.74786679070854 30.401481940749107 35.66859951867811 139.74786679070854 29.08411438703817 35.6685802824288 139.74792404026175 38.68550141096395</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_56878d7b-2963-416b-bdae-c8a2a9b3ceac">
									<gml:exterior>
										<gml:LinearRing gml:id="line_320911fa-a957-4d3f-b3eb-5d9479fdb0ec">
											<gml:posList>35.66862094168115 139.74780303297814 9.355507209303795 35.6685802824288 139.74792404026175 6.3942492747334825 35.66862094168115 139.74780303297814 9.79950745344442 35.66862094168115 139.74780303297814 9.355507209303795</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_5cb6dd17-e37e-4691-96ac-6cd51f6de771">
									<gml:exterior>
										<gml:LinearRing gml:id="line_8389ca03-ff82-4292-82b8-9f59c5a86f25">
											<gml:posList>35.6685802824288 139.74792404026175 6.3942492747334825 35.66862094168115 139.74780303297814 9.355507209303795 35.66862094168115 139.74780303297814 6.3942492747334825 35.6685802824288 139.74792404026175 6.3942492747334825</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_e34eb704-3e8b-4c36-8471-8c28417171e7">
									<gml:exterior>
										<gml:LinearRing gml:id="line_04f4c17d-085c-4e7f-a86b-29e1f10c82af">
											<gml:posList>35.668604037043295 139.7478533432813 20.033180549147545 35.66860158385983 139.74786064439732 20.033180549147545 35.668604037043295 139.7478533432813 21.350548102858482 35.668604037043295 139.7478533432813 20.033180549147545</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_8a047ec2-c34a-41bf-bd23-dc4b16d386db">
									<gml:exterior>
										<gml:LinearRing gml:id="line_3ccd0772-8e7e-42d2-a45c-1abf4ca77a74">
											<gml:posList>35.66860158385983 139.74786064439732 20.033180549147545 35.668604037043295 139.7478533432813 20.033180549147545 35.66862094168115 139.74780303297814 9.79950745344442 35.66860158385983 139.74786064439732 20.033180549147545</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_7704d34b-c594-44de-9190-68faea00a646">
									<gml:exterior>
										<gml:LinearRing gml:id="line_f1ca2a99-76de-4552-a1b9-49e3925e7be4">
											<gml:posList>35.668604037043295 139.7478533432813 21.350548102858482 35.66860158385983 139.74786064439732 20.033180549147545 35.66860158385983 139.74786064439732 21.350548102858482 35.668604037043295 139.7478533432813 21.350548102858482</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_ccfedb77-e867-49c8-ab53-932cb76e0a44">
									<gml:exterior>
										<gml:LinearRing gml:id="line_597946f0-a2e1-498d-b211-b14586508d0e">
											<gml:posList>35.66860158385983 139.74786064439732 23.050155951979576 35.668604037043295 139.7478533432813 24.367523505690514 35.668604037043295 139.7478533432813 23.050155951979576 35.66860158385983 139.74786064439732 23.050155951979576</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_835258bf-71a4-463d-99a1-0ec4437d7ea2">
									<gml:exterior>
										<gml:LinearRing gml:id="line_ef413b2b-9b06-4db8-a43a-f3851e1afab3">
											<gml:posList>35.668604037043295 139.7478533432813 24.367523505690514 35.66860158385983 139.74786064439732 23.050155951979576 35.66860158385983 139.74786064439732 24.367523505690514 35.668604037043295 139.7478533432813 24.367523505690514</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_de2e94d4-826d-4a27-a26d-edb70a78b393">
									<gml:exterior>
										<gml:LinearRing gml:id="line_731f1225-e238-43aa-88b4-67480ab769cf">
											<gml:posList>35.66862094168115 139.74780303297814 9.79950745344442 35.66859951867811 139.74786679070854 20.033180549147545 35.66860158385983 139.74786064439732 20.033180549147545 35.66862094168115 139.74780303297814 9.79950745344442</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_b289b07a-f332-452d-916c-9e0b8069a3fd">
									<gml:exterior>
										<gml:LinearRing gml:id="line_5dbd7309-c03f-4b45-9bde-212d8e0ac8a0">
											<gml:posList>35.66859372993633 139.7478840186893 35.550506904128014 35.6685802824288 139.74792404026175 38.68550141096395 35.66859372993633 139.7478840186893 38.68550141096395 35.66859372993633 139.7478840186893 35.550506904128014</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_c6133eda-3b83-4233-ae45-03254de90078">
									<gml:exterior>
										<gml:LinearRing gml:id="line_0ff4cc0e-1f9a-48e7-a4f9-f4519c192260">
											<gml:posList>35.66862094168115 139.74780303297814 35.550506904128014 35.66860610222434 139.7478471969694 26.06713898420614 35.66860610222434 139.7478471969694 27.384498908522545 35.66862094168115 139.74780303297814 35.550506904128014</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
					<bldg:opening>
						<bldg:Window gml:id="wnd_1f3c6860-6feb-49ee-a0dd-9ff96f5795f0">
							<bldg:lod3MultiSurface>
								<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_cbcdf01f-82bd-4617-a0b4-7fd0a67ed63b">
											<gml:exterior>
												<gml:LinearRing gml:id="line_0d728492-93de-4b5f-a85e-541d361fd97c">
													<gml:posList>35.66860610222434 139.7478471969694 24.367523505690514 35.66860610222434 139.7478471969694 23.050155951979576 35.668604037043295 139.7478533432813 24.367523505690514 35.66860610222434 139.7478471969694 24.367523505690514</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_38415677-e409-428e-909c-80a2767573c9">
											<gml:exterior>
												<gml:LinearRing gml:id="line_d01fe36d-a5ad-4fff-868c-82222930c71a">
													<gml:posList>35.668604037043295 139.7478533432813 24.367523505690514 35.66860610222434 139.7478471969694 23.050155951979576 35.668604037043295 139.7478533432813 23.050155951979576 35.668604037043295 139.7478533432813 24.367523505690514</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
								</gml:MultiSurface>
							</bldg:lod3MultiSurface>
						</bldg:Window>
					</bldg:opening>
					<bldg:opening>
						<bldg:Window gml:id="wnd_4a22ecf5-8344-4f43-84a8-d129708b4e86">
							<bldg:lod3MultiSurface>
								<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_498db53f-a0a7-446e-9ac3-c8ceda1b55ad">
											<gml:exterior>
												<gml:LinearRing gml:id="line_d6262804-bbb8-4828-aad1-bae634fe541f">
													<gml:posList>35.66860610222434 139.7478471969694 21.350548102858482 35.66860610222434 139.7478471969694 20.033180549147545 35.668604037043295 139.7478533432813 21.350548102858482 35.66860610222434 139.7478471969694 21.350548102858482</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_babdad5a-4f1b-4645-a371-328bbc21cea8">
											<gml:exterior>
												<gml:LinearRing gml:id="line_d842ac5e-d884-4518-87cc-438f9b48c394">
													<gml:posList>35.668604037043295 139.7478533432813 21.350548102858482 35.66860610222434 139.7478471969694 20.033180549147545 35.668604037043295 139.7478533432813 20.033180549147545 35.668604037043295 139.7478533432813 21.350548102858482</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
								</gml:MultiSurface>
							</bldg:lod3MultiSurface>
						</bldg:Window>
					</bldg:opening>
					<bldg:opening>
						<bldg:Window gml:id="wnd_b9a85ced-5c91-4b80-984e-b901972b087f">
							<bldg:lod3MultiSurface>
								<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_522ebef7-1494-4356-95bb-5f31c85df9cd">
											<gml:exterior>
												<gml:LinearRing gml:id="line_5006e01f-c917-4bff-9ec7-8c1c7ba6054d">
													<gml:posList>35.66860610222434 139.7478471969694 33.41845734358114 35.66860610222434 139.7478471969694 32.10109741926473 35.668604037043295 139.7478533432813 33.41845734358114 35.66860610222434 139.7478471969694 33.41845734358114</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_1991d0de-f7fa-46b0-a293-c8b8c997c824">
											<gml:exterior>
												<gml:LinearRing gml:id="line_2b596cf7-c408-403f-b29c-a8af4baa827a">
													<gml:posList>35.668604037043295 139.7478533432813 33.41845734358114 35.66860610222434 139.7478471969694 32.10109741926473 35.668604037043295 139.7478533432813 32.10109741926473 35.668604037043295 139.7478533432813 33.41845734358114</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
								</gml:MultiSurface>
							</bldg:lod3MultiSurface>
						</bldg:Window>
					</bldg:opening>
					<bldg:opening>
						<bldg:Window gml:id="wnd_aa50951c-191f-4b54-ab85-de474ebdca44">
							<bldg:lod3MultiSurface>
								<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_72aff4a7-9c4c-44f0-a76a-9368e7a451bf">
											<gml:exterior>
												<gml:LinearRing gml:id="line_56ec165d-efae-4e85-8592-00e0d1b524cb">
													<gml:posList>35.66860158385983 139.74786064439732 24.367523505690514 35.66860158385983 139.74786064439732 23.050155951979576 35.66859951867811 139.74786679070854 24.367523505690514 35.66860158385983 139.74786064439732 24.367523505690514</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_0f595a9f-e9a7-478b-b93b-91873119d570">
											<gml:exterior>
												<gml:LinearRing gml:id="line_de1e5dfa-b28f-4154-8e11-dcd30f717db8">
													<gml:posList>35.66859951867811 139.74786679070854 24.367523505690514 35.66860158385983 139.74786064439732 23.050155951979576 35.66859951867811 139.74786679070854 23.050155951979576 35.66859951867811 139.74786679070854 24.367523505690514</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
								</gml:MultiSurface>
							</bldg:lod3MultiSurface>
						</bldg:Window>
					</bldg:opening>
					<bldg:opening>
						<bldg:Window gml:id="wnd_df435af2-3575-46a7-9162-f311d574e48a">
							<bldg:lod3MultiSurface>
								<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_868b198d-7a38-4cfa-a082-f04b79a82201">
											<gml:exterior>
												<gml:LinearRing gml:id="line_a64dd12a-0348-4627-8aeb-f207afe8cca0">
													<gml:posList>35.66860158385983 139.74786064439732 21.350548102858482 35.66860158385983 139.74786064439732 20.033180549147545 35.66859951867811 139.74786679070854 21.350548102858482 35.66860158385983 139.74786064439732 21.350548102858482</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_e173bdfe-485d-4c24-8dff-e042740ded77">
											<gml:exterior>
												<gml:LinearRing gml:id="line_f57b3412-69cd-4ea9-a979-77ecefb9b233">
													<gml:posList>35.66859951867811 139.74786679070854 21.350548102858482 35.66860158385983 139.74786064439732 20.033180549147545 35.66859951867811 139.74786679070854 20.033180549147545 35.66859951867811 139.74786679070854 21.350548102858482</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
								</gml:MultiSurface>
							</bldg:lod3MultiSurface>
						</bldg:Window>
					</bldg:opening>
					<bldg:opening>
						<bldg:Window gml:id="wnd_882c37fa-7822-4c6e-a0cc-98d46b815675">
							<bldg:lod3MultiSurface>
								<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_749400f7-a052-4d97-94a4-f6d9b500c967">
											<gml:exterior>
												<gml:LinearRing gml:id="line_ffb8f158-92cc-409f-83ae-f783a006163d">
													<gml:posList>35.66860158385983 139.74786064439732 30.401481940749107 35.66860158385983 139.74786064439732 29.08411438703817 35.66859951867811 139.74786679070854 30.401481940749107 35.66860158385983 139.74786064439732 30.401481940749107</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_87350894-43d7-4f07-945c-43675a9d2ba9">
											<gml:exterior>
												<gml:LinearRing gml:id="line_6f7223ba-ea78-466b-a697-a8689b451be4">
													<gml:posList>35.66859951867811 139.74786679070854 30.401481940749107 35.66860158385983 139.74786064439732 29.08411438703817 35.66859951867811 139.74786679070854 29.08411438703817 35.66859951867811 139.74786679070854 30.401481940749107</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
								</gml:MultiSurface>
							</bldg:lod3MultiSurface>
						</bldg:Window>
					</bldg:opening>
					<bldg:opening>
						<bldg:Window gml:id="wnd_77048f92-c979-441e-be2c-1db75c94eb83">
							<bldg:lod3MultiSurface>
								<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_f751a5b1-2fee-4f7f-bc1f-d85b0eff2ead">
											<gml:exterior>
												<gml:LinearRing gml:id="line_eff1d852-8c74-4860-920e-ae43659b14b7">
													<gml:posList>35.66860158385983 139.74786064439732 33.41845734358114 35.66860158385983 139.74786064439732 32.10109741926473 35.66859951867811 139.74786679070854 33.41845734358114 35.66860158385983 139.74786064439732 33.41845734358114</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_0df35b16-0d87-453b-9487-200eeea967ab">
											<gml:exterior>
												<gml:LinearRing gml:id="line_10b2355d-a20c-4a7c-8ff7-0aa26f018a8e">
													<gml:posList>35.66859951867811 139.74786679070854 33.41845734358114 35.66860158385983 139.74786064439732 32.10109741926473 35.66859951867811 139.74786679070854 32.10109741926473 35.66859951867811 139.74786679070854 33.41845734358114</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
								</gml:MultiSurface>
							</bldg:lod3MultiSurface>
						</bldg:Window>
					</bldg:opening>
					<bldg:opening>
						<bldg:Window gml:id="wnd_0cb7286e-4c59-45ca-8315-60f3d7204770">
							<bldg:lod3MultiSurface>
								<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_35eee4bb-cde4-41e0-84d4-7c8dea46f70f">
											<gml:exterior>
												<gml:LinearRing gml:id="line_8fcbf248-62ba-42ae-93e3-0ac8bbe0cfd1">
													<gml:posList>35.66860610222434 139.7478471969694 30.401481940749107 35.66860610222434 139.7478471969694 29.08411438703817 35.668604037043295 139.7478533432813 30.401481940749107 35.66860610222434 139.7478471969694 30.401481940749107</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_d689df06-8929-4b04-abf4-55aa28f5b714">
											<gml:exterior>
												<gml:LinearRing gml:id="line_71bc42bf-168e-472b-8e16-8b1325e3f61e">
													<gml:posList>35.668604037043295 139.7478533432813 30.401481940749107 35.66860610222434 139.7478471969694 29.08411438703817 35.668604037043295 139.7478533432813 29.08411438703817 35.668604037043295 139.7478533432813 30.401481940749107</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
								</gml:MultiSurface>
							</bldg:lod3MultiSurface>
						</bldg:Window>
					</bldg:opening>
					<bldg:opening>
						<bldg:Window gml:id="wnd_965e78bf-ec48-461c-982c-2251ddbf5468">
							<bldg:lod3MultiSurface>
								<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_81fe93c7-80b9-4bf1-955a-c5a21ba02028">
											<gml:exterior>
												<gml:LinearRing gml:id="line_511f1409-6e04-4792-81ff-bcdae58bb267">
													<gml:posList>35.66860158385983 139.74786064439732 27.384498908522545 35.66860158385983 139.74786064439732 26.06713898420614 35.66859951867811 139.74786679070854 27.384498908522545 35.66860158385983 139.74786064439732 27.384498908522545</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_482a38f6-52ec-48b6-8b19-64dc998dce4d">
											<gml:exterior>
												<gml:LinearRing gml:id="line_d874e931-a8c8-4c10-9b7e-e954ba5e6c51">
													<gml:posList>35.66859951867811 139.74786679070854 27.384498908522545 35.66860158385983 139.74786064439732 26.06713898420614 35.66859951867811 139.74786679070854 26.06713898420614 35.66859951867811 139.74786679070854 27.384498908522545</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
								</gml:MultiSurface>
							</bldg:lod3MultiSurface>
						</bldg:Window>
					</bldg:opening>
					<bldg:opening>
						<bldg:Window gml:id="wnd_8868ce45-a748-45f8-9996-faa0c04ba040">
							<bldg:lod3MultiSurface>
								<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_024cb529-0e81-49b9-860e-4ad26cd640fb">
											<gml:exterior>
												<gml:LinearRing gml:id="line_03ea0fd8-6e25-4263-8a3d-a7aabb9580d6">
													<gml:posList>35.66860610222434 139.7478471969694 27.384498908522545 35.66860610222434 139.7478471969694 26.06713898420614 35.668604037043295 139.7478533432813 27.384498908522545 35.66860610222434 139.7478471969694 27.384498908522545</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_ec0d77c7-5bd6-4ea8-829d-9705110d08d4">
											<gml:exterior>
												<gml:LinearRing gml:id="line_b5d30a8c-b773-4d82-a4b2-f24f598ba664">
													<gml:posList>35.668604037043295 139.7478533432813 27.384498908522545 35.66860610222434 139.7478471969694 26.06713898420614 35.668604037043295 139.7478533432813 26.06713898420614 35.668604037043295 139.7478533432813 27.384498908522545</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
								</gml:MultiSurface>
							</bldg:lod3MultiSurface>
						</bldg:Window>
					</bldg:opening>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_65ccff8a-9b97-4f62-b26d-14246bee126e">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_77a63c6b-f2b2-4fab-8460-61295e5b61f9">
									<gml:exterior>
										<gml:LinearRing gml:id="line_36f0ac69-0d8c-441d-8596-a7612230dc78">
											<gml:posList>35.66862642811532 139.74781138344156 22.93818695783895 35.668630285119036 139.74781332977528 22.93818695783895 35.66862642811532 139.74781138344156 22.14813263654989 35.66862642811532 139.74781138344156 22.93818695783895</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_682d59c3-e62b-440c-8be7-5e2ae41f0926">
									<gml:exterior>
										<gml:LinearRing gml:id="line_c7083ff4-e739-4ff7-9f57-ea1765b0187e">
											<gml:posList>35.66862642811532 139.74781138344156 22.14813263654989 35.668630285119036 139.74781332977528 22.93818695783895 35.668630285119036 139.74781332977528 22.14813263654989 35.66862642811532 139.74781138344156 22.14813263654989</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_46f47b5f-18e5-483c-8ac2-e2354535402d">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_5f24cfaf-a05b-423c-8bb3-0a624a89f68d">
									<gml:exterior>
										<gml:LinearRing gml:id="line_5e8eec6a-631f-463c-81d9-4f8fd16044c2">
											<gml:posList>35.66867316936178 139.74783496920924 24.203087165358482 35.668669312220906 139.74783302287355 24.203087165358482 35.66867316936178 139.74783496920924 24.30670960188192 35.66867316936178 139.74783496920924 24.203087165358482</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_ef48014b-31d9-47ee-b464-a06b19a1a40e">
									<gml:exterior>
										<gml:LinearRing gml:id="line_90267727-139f-47a6-8498-affd2eacd026">
											<gml:posList>35.66867316936178 139.74783496920924 24.30670960188192 35.668669312220906 139.74783302287355 24.203087165358482 35.668669312220906 139.74783302287355 24.30670960188192 35.66867316936178 139.74783496920924 24.30670960188192</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_8ead112f-0247-4f4e-a024-f7cf197f658d">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_c544d9ca-d039-4fda-b2bf-373f8cf5773e">
									<gml:exterior>
										<gml:LinearRing gml:id="line_5f1b1efb-4bee-4f2b-8fa5-f47252f9b944">
											<gml:posList>35.668669312220906 139.74783302287355 19.87842591047567 35.66867316936178 139.74783496920924 19.87842591047567 35.668669312220906 139.74783302287355 19.088371589186607 35.668669312220906 139.74783302287355 19.87842591047567</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_85e2e78c-5cb5-421b-b78f-81836e2576d3">
									<gml:exterior>
										<gml:LinearRing gml:id="line_30b465df-ce2f-4e69-bb78-306f8577cbc1">
											<gml:posList>35.668669312220906 139.74783302287355 19.088371589186607 35.66867316936178 139.74783496920924 19.87842591047567 35.66867316936178 139.74783496920924 19.088371589186607 35.668669312220906 139.74783302287355 19.088371589186607</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="wall_TMmnt0161_p992_8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly_TMmnt0161_p992_8">
									<gml:exterior>
										<gml:LinearRing gml:id="line_TMmnt0161_p992_8">
											<gml:posList>35.668667698010054 139.74791461558144 37.87732257 35.66866771017094 139.74791461839294 34.61732286 35.66859651403997 139.7478778744316 34.61379934 35.66859650191569 139.74787787163882 37.87379905 35.668626226593894 139.74789321238558 37.87526873 35.668667698010054 139.74791461558144 37.87732257</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_6dcd4dc1-086d-4d29-8d09-aa1c87e5cea1">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_087f708d-b3b3-4233-90b5-eb9b4dd24f92">
									<gml:exterior>
										<gml:LinearRing gml:id="line_bde9bd4f-74a1-4c77-b8dd-5f25f7916e65">
											<gml:posList>35.668630285119036 139.74781332977528 24.203087165358482 35.66862642811532 139.74781138344156 24.203087165358482 35.668630285119036 139.74781332977528 24.30670960188192 35.668630285119036 139.74781332977528 24.203087165358482</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_f7147748-1d5f-4b14-bb8f-21da96c87e6d">
									<gml:exterior>
										<gml:LinearRing gml:id="line_4415c378-5958-46b8-b7b1-137c619e0706">
											<gml:posList>35.668630285119036 139.74781332977528 24.30670960188192 35.66862642811532 139.74781138344156 24.203087165358482 35.66862642811532 139.74781138344156 24.30670960188192 35.668630285119036 139.74781332977528 24.30670960188192</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="wall_TMmnt0161_p994_2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly_TMmnt0161_p994_2">
									<gml:exterior>
										<gml:LinearRing gml:id="line_TMmnt0161_p994_2">
											<gml:posList>35.66858494202354 139.74794644550522 39.1237546 35.66858494667018 139.74794644658942 37.87375471 35.66860446824003 139.74795652213663 37.87472015 35.66860446358953 139.74795652105036 39.12472004 35.66858494202354 139.74794644550522 39.1237546</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_12cfc32f-f624-4265-ad3c-0b9c5d355e31">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_67d166f6-2708-4988-823b-df2f40858265">
									<gml:exterior>
										<gml:LinearRing gml:id="line_90688f9f-a403-4005-9337-0cdcf64162a2">
											<gml:posList>35.66867316936178 139.74783496920924 12.067657783034264 35.6686747729746 139.74783019638366 10.960441901686607 35.66867316936178 139.74783496920924 9.909088447096764 35.66867316936178 139.74783496920924 12.067657783034264</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_c5b30e90-bd38-403f-807d-c37a3522b080">
									<gml:exterior>
										<gml:LinearRing gml:id="line_a0315523-b1a1-4cff-8984-9ef7af77acf1">
											<gml:posList>35.6686747729746 139.74783019638366 10.960441901686607 35.66867316936178 139.74783496920924 12.067657783034264 35.6686747729746 139.74783019638366 12.067657783034264 35.6686747729746 139.74783019638366 10.960441901686607</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_0dded7dd-1f56-478c-9566-bed93da0dd51">
									<gml:exterior>
										<gml:LinearRing gml:id="line_c8fe58f7-b233-4d02-a651-72d99b0fa260">
											<gml:posList>35.6686747729746 139.74783019638366 10.359085395338951 35.66867316936178 139.74783496920924 9.909088447096764 35.6686747729746 139.74783019638366 10.960441901686607 35.6686747729746 139.74783019638366 10.359085395338951</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_6fe6ec0a-7aba-48f9-83c5-4b3e2fca7dc9">
									<gml:exterior>
										<gml:LinearRing gml:id="line_6477a91c-70d4-43ce-910c-5f482d9e519c">
											<gml:posList>35.66867316936178 139.74783496920924 9.909088447096764 35.6686747729746 139.74783019638366 10.359085395338951 35.6686747729746 139.74783019638366 9.909088447096764 35.66867316936178 139.74783496920924 9.909088447096764</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_af9a4236-c8b2-40a7-a824-c9d0d84daee5">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_d7d04d63-3535-4c82-b324-56e797fce62f">
									<gml:exterior>
										<gml:LinearRing gml:id="line_c926ae38-6da2-463f-b91b-d3ace580ee0d">
											<gml:posList>35.66862610337473 139.74803552647538 40.907394721510826 35.66862439832634 139.74804060093578 40.907394721510826 35.66862610337473 139.74803552647538 6.3942492747334825 35.66862610337473 139.74803552647538 40.907394721510826</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_716fdaa5-26c5-41fb-a599-3ca8eb81f47d">
									<gml:exterior>
										<gml:LinearRing gml:id="line_ffd044e8-afba-492f-ae2e-8ae1bc7af973">
											<gml:posList>35.66862610337473 139.74803552647538 6.3942492747334825 35.66862439832634 139.74804060093578 40.907394721510826 35.66862439832634 139.74804060093578 6.3942492747334825 35.66862610337473 139.74803552647538 6.3942492747334825</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_e5587180-3c72-47c8-9f80-7b4e832ace13">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_3f14d764-01e2-4d75-8ba0-4887e5627f50">
									<gml:exterior>
										<gml:LinearRing gml:id="line_8d4e910a-77e0-447f-8ba6-6f6bea95bf8f">
											<gml:posList>35.668630285119036 139.74781332977528 32.117470099928795 35.668631888868546 139.7478085569517 31.327423408034264 35.668630285119036 139.74781332977528 31.327423408034264 35.668630285119036 139.74781332977528 32.117470099928795</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_eb0a3d27-b789-4848-b0d0-bde2c480f8b4">
									<gml:exterior>
										<gml:LinearRing gml:id="line_5dbe9cf0-1426-408c-96b5-86d2021287b8">
											<gml:posList>35.668631888868546 139.7478085569517 31.327423408034264 35.668630285119036 139.74781332977528 32.117470099928795 35.668631888868546 139.7478085569517 33.486000373366295 35.668631888868546 139.7478085569517 31.327423408034264</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_3350796a-59a8-4db2-a472-3248d2ed7d2a">
									<gml:exterior>
										<gml:LinearRing gml:id="line_654213be-9b33-440b-b46b-86fd74e48894">
											<gml:posList>35.668631888868546 139.7478085569517 33.486000373366295 35.668630285119036 139.74781332977528 32.117470099928795 35.668630285119036 139.74781332977528 33.382370307448326 35.668631888868546 139.7478085569517 33.486000373366295</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_e148d1f2-4c60-4bb0-9f41-3095a3b4fd23">
									<gml:exterior>
										<gml:LinearRing gml:id="line_40d2d25b-a794-40b8-adc0-0b3c28445092">
											<gml:posList>35.668631888868546 139.7478085569517 33.486000373366295 35.668630285119036 139.74781332977528 33.382370307448326 35.668630285119036 139.74781332977528 33.486000373366295 35.668631888868546 139.7478085569517 33.486000373366295</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
					<bldg:opening>
						<bldg:Window gml:id="wnd_a53ed723-5c2b-4bf4-8f4a-6d0175c01c96">
							<bldg:lod3MultiSurface>
								<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_098c57a8-86b0-4cf9-a113-2730f693c1c6">
											<gml:exterior>
												<gml:LinearRing gml:id="line_073aff70-e4eb-4c71-9141-7552d20535e2">
													<gml:posList>35.668630285119036 139.74781332977528 33.382370307448326 35.668630285119036 139.74781332977528 32.117470099928795 35.66862642811532 139.74781138344156 33.382370307448326 35.668630285119036 139.74781332977528 33.382370307448326</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_ebc1aefd-7acd-4cad-8920-01419924db80">
											<gml:exterior>
												<gml:LinearRing gml:id="line_53fa2895-e861-4339-9975-6bf264b0a909">
													<gml:posList>35.66862642811532 139.74781138344156 33.382370307448326 35.668630285119036 139.74781332977528 32.117470099928795 35.66862642811532 139.74781138344156 32.117470099928795 35.66862642811532 139.74781138344156 33.382370307448326</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
								</gml:MultiSurface>
							</bldg:lod3MultiSurface>
						</bldg:Window>
					</bldg:opening>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_faca6f64-3e99-4749-a464-46d674d7e426">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_f6d700c7-1e59-437a-a144-bb231a716282">
									<gml:exterior>
										<gml:LinearRing gml:id="line_bce59e2c-3f59-4a00-b376-3430a0eae4fe">
											<gml:posList>35.66867316936178 139.74783496920924 33.382370307448326 35.668669312220906 139.74783302287355 33.382370307448326 35.66867316936178 139.74783496920924 33.486000373366295 35.66867316936178 139.74783496920924 33.382370307448326</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_435a0ceb-0ece-467a-8883-5bac657c7740">
									<gml:exterior>
										<gml:LinearRing gml:id="line_92eae6e7-e337-492b-83b4-20f842d46cb7">
											<gml:posList>35.66867316936178 139.74783496920924 33.486000373366295 35.668669312220906 139.74783302287355 33.382370307448326 35.668669312220906 139.74783302287355 33.486000373366295 35.66867316936178 139.74783496920924 33.486000373366295</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_4ceed91a-1bd1-4a9c-b5ce-b7cf8dc08a05">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_af810e82-e714-45a2-aa67-5e45850b7f76">
									<gml:exterior>
										<gml:LinearRing gml:id="line_255d2b7c-930a-4692-a5ba-92d0a134333b">
											<gml:posList>35.668605516458285 139.74803107289867 37.902504279616295 35.66862439832634 139.74804060093578 6.3942492747334825 35.66862439832634 139.74804060093578 40.907394721510826 35.668605516458285 139.74803107289867 37.902504279616295</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_c4fccfeb-2248-4070-9641-7573dc6ecf93">
									<gml:exterior>
										<gml:LinearRing gml:id="line_8165aa27-1550-439c-831d-a2b1dc826671">
											<gml:posList>35.66862439832634 139.74804060093578 6.3942492747334825 35.668605516458285 139.74803107289867 37.902504279616295 35.66858854430902 139.74802250878727 6.3942492747334825 35.66862439832634 139.74804060093578 6.3942492747334825</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_0ee9d95b-72b1-4244-a060-9671bc89e35e">
									<gml:exterior>
										<gml:LinearRing gml:id="line_28013078-1bb5-49c6-bb08-cc8ef5771f29">
											<gml:posList>35.66858854430902 139.74802250878727 6.3942492747334825 35.668605516458285 139.74803107289867 37.902504279616295 35.66858854430902 139.74802250878727 37.902504279616295 35.66858854430902 139.74802250878727 6.3942492747334825</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_724efebf-137f-457a-b623-7485ccb943ae">
									<gml:exterior>
										<gml:LinearRing gml:id="line_71bbed63-436a-486b-aae7-0b761d3ac663">
											<gml:posList>35.668605516458285 139.74803107289867 37.902504279616295 35.66862439832634 139.74804060093578 40.907394721510826 35.668605516458285 139.74803107289867 40.907394721510826 35.668605516458285 139.74803107289867 37.902504279616295</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_e232a98f-f1d9-4a37-a1ac-7b8be3fc30cb">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_fbfeac40-d898-421a-a865-cb4a99755bde">
									<gml:exterior>
										<gml:LinearRing gml:id="line_3c862571-8c60-4ee9-9941-caa8c144460c">
											<gml:posList>35.66863826445226 139.7479905575038 40.907394721510826 35.66863826445226 139.7479905575038 37.902504279616295 35.668621903878346 139.74798230203365 40.907394721510826 35.66863826445226 139.7479905575038 40.907394721510826</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_16dba55e-48a7-4872-9ead-693dd8c8827b">
									<gml:exterior>
										<gml:LinearRing gml:id="line_c43d47b7-3b38-4adc-900e-7dad5a2ce456">
											<gml:posList>35.668621903878346 139.74798230203365 40.907394721510826 35.66863826445226 139.7479905575038 37.902504279616295 35.668621903878346 139.74798230203365 37.902504279616295 35.668621903878346 139.74798230203365 40.907394721510826</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_8b7a87cf-75f0-400b-b579-e680e43815a1">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_32083abf-ccd6-4389-9cb1-ad62e8eb4e74">
									<gml:exterior>
										<gml:LinearRing gml:id="line_cd77613d-58ce-4c3d-a227-0415288b3546">
											<gml:posList>35.66868526091045 139.74782098748136 17.07996399641317 35.668690275854296 139.74782351812135 16.478615119460045 35.668690275854296 139.74782351812135 18.187187507155357 35.66868526091045 139.74782098748136 17.07996399641317</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_e280851c-22c4-4c64-bd0e-da927fa0a173">
									<gml:exterior>
										<gml:LinearRing gml:id="line_0f2a4bd4-df8a-405b-9b95-ce058b3c38ad">
											<gml:posList>35.668690275854296 139.74782351812135 16.478615119460045 35.66868526091045 139.74782098748136 17.07996399641317 35.66868526091045 139.74782098748136 16.478615119460045 35.668690275854296 139.74782351812135 16.478615119460045</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_74000610-1cdd-495e-80c5-3fb09cdb576a">
									<gml:exterior>
										<gml:LinearRing gml:id="line_3c0c7c22-75d5-45c9-9b2d-53d2bd1aa2ea">
											<gml:posList>35.66868526091045 139.74782098748136 17.07996399641317 35.668690275854296 139.74782351812135 18.187187507155357 35.66868477962785 139.74782074477844 18.187187507155357 35.66868526091045 139.74782098748136 17.07996399641317</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_370f1fa5-1d40-47a6-aaed-a6b0856a4995">
									<gml:exterior>
										<gml:LinearRing gml:id="line_03558732-da0d-4c86-abfa-7eb8b4d06831">
											<gml:posList>35.66868526091045 139.74782098748136 17.07996399641317 35.66868477962785 139.74782074477844 18.187187507155357 35.66868477962785 139.74782074477844 17.07996399641317 35.66868526091045 139.74782098748136 17.07996399641317</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_c415d248-63cb-4805-af45-514de9d460b5">
									<gml:exterior>
										<gml:LinearRing gml:id="line_4b830b95-218a-485d-9693-16a866307fe7">
											<gml:posList>35.66868526091045 139.74782098748136 17.07996399641317 35.66868477962785 139.74782074477844 17.07996399641317 35.66868526091045 139.74782098748136 16.478615119460045 35.66868526091045 139.74782098748136 17.07996399641317</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_ef268533-fbe9-42a4-97bb-c4be6b7ff2ed">
									<gml:exterior>
										<gml:LinearRing gml:id="line_868aa22c-f919-4de9-9402-bd832ae424ff">
											<gml:posList>35.66868526091045 139.74782098748136 16.478615119460045 35.66868477962785 139.74782074477844 17.07996399641317 35.66868477962785 139.74782074477844 16.478615119460045 35.66868526091045 139.74782098748136 16.478615119460045</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_fedea9e9-9f70-4431-a890-f86e8fe3ee89">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_8f4f1e64-40d8-42d6-9476-3e87bc4c8acb">
									<gml:exterior>
										<gml:LinearRing gml:id="line_0ce02688-0f89-44ea-a52e-6f7b219eb3d6">
											<gml:posList>35.6686752542573 139.74783043925513 14.020202949049889 35.66868610967223 139.747835916983 15.127426459792076 35.66868610967223 139.747835916983 13.418846442702232 35.6686752542573 139.74783043925513 14.020202949049889</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_2b1e628f-7af5-436d-9dff-d691379bb146">
									<gml:exterior>
										<gml:LinearRing gml:id="line_a2b92a12-2e42-4565-a933-985051e58852">
											<gml:posList>35.66868610967223 139.747835916983 15.127426459792076 35.6686752542573 139.74783043925513 14.020202949049889 35.6686747729746 139.74783019638366 15.127426459792076 35.66868610967223 139.747835916983 15.127426459792076</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_94eb6c46-9352-4a88-897e-23fc47e0e44f">
									<gml:exterior>
										<gml:LinearRing gml:id="line_de98f68b-a865-47d9-b5f7-b9493c4eba30">
											<gml:posList>35.6686747729746 139.74783019638366 15.127426459792076 35.6686752542573 139.74783043925513 14.020202949049889 35.6686747729746 139.74783019638366 14.020202949049889 35.6686747729746 139.74783019638366 15.127426459792076</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_6c1e4e61-39dd-421e-82a3-a53b011cbfbc">
									<gml:exterior>
										<gml:LinearRing gml:id="line_7efb9a42-e4e0-4c4a-9839-f193550025b0">
											<gml:posList>35.6686752542573 139.74783043925513 14.020202949049889 35.66868610967223 139.747835916983 13.418846442702232 35.6686752542573 139.74783043925513 13.418846442702232 35.6686752542573 139.74783043925513 14.020202949049889</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_574806cf-e2e2-41ba-96aa-40f8d3deabbf">
									<gml:exterior>
										<gml:LinearRing gml:id="line_32ca3756-1448-40c9-a17b-7fa43c70b8ae">
											<gml:posList>35.6686752542573 139.74783043925513 14.020202949049889 35.6686752542573 139.74783043925513 13.418846442702232 35.6686747729746 139.74783019638366 14.020202949049889 35.6686752542573 139.74783043925513 14.020202949049889</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_af7d61c8-2607-4dc9-8855-d755f235fd54">
									<gml:exterior>
										<gml:LinearRing gml:id="line_a4e390d4-08df-4d0b-b88e-810dd0d87c20">
											<gml:posList>35.6686747729746 139.74783019638366 14.020202949049889 35.6686752542573 139.74783043925513 13.418846442702232 35.6686747729746 139.74783019638366 13.418846442702232 35.6686747729746 139.74783019638366 14.020202949049889</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_4d024a36-4002-4c29-989b-38b8bbab0e36">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_6d2de3b8-a7bc-4685-bd88-2971b113bb79">
									<gml:exterior>
										<gml:LinearRing gml:id="line_2331f587-b2e9-4596-b244-f2838aa1028d">
											<gml:posList>35.6685725697646 139.7479299869554 38.68550141096395 35.66856262697436 139.74792496973683 41.17650635481161 35.66856262697436 139.74792496973683 37.902504279616295 35.6685725697646 139.7479299869554 38.68550141096395</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_a9213486-971a-4583-97d6-bf2f62c11b17">
									<gml:exterior>
										<gml:LinearRing gml:id="line_c34b32df-1939-4d5c-800e-8dc91c0cb432">
											<gml:posList>35.66856262697436 139.74792496973683 41.17650635481161 35.6685725697646 139.7479299869554 38.68550141096395 35.6685725697646 139.7479299869554 41.17650635481161 35.66856262697436 139.74792496973683 41.17650635481161</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_436feef4-4557-49d6-99a1-0ee26d3aabe9">
									<gml:exterior>
										<gml:LinearRing gml:id="line_003ec36f-3014-487f-9166-47512f76178c">
											<gml:posList>35.6685725697646 139.7479299869554 38.68550141096395 35.66856262697436 139.74792496973683 37.902504279616295 35.668577455786235 139.74793245233906 37.902504279616295 35.6685725697646 139.7479299869554 38.68550141096395</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_c0e3955c-0be5-49d9-8046-874488446bbb">
									<gml:exterior>
										<gml:LinearRing gml:id="line_873a3d7d-2c92-480a-b5a1-69456741e003">
											<gml:posList>35.6685725697646 139.7479299869554 38.68550141096395 35.668577455786235 139.74793245233906 37.902504279616295 35.668577455786235 139.74793245233906 38.68550141096395 35.6685725697646 139.7479299869554 38.68550141096395</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_5ecd550b-8775-4d55-ac6f-4d02121bbb46">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_695cd32e-3a2e-4d76-803c-69261a3218d1">
									<gml:exterior>
										<gml:LinearRing gml:id="line_0d7ae045-4ad0-43c0-a18c-8a2ce00847c7">
											<gml:posList>35.668630285119036 139.74781332977528 33.382370307448326 35.66862642811532 139.74781138344156 33.382370307448326 35.668630285119036 139.74781332977528 33.486000373366295 35.668630285119036 139.74781332977528 33.382370307448326</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_01cee467-b83f-4c8d-9475-fe46cc9b8c9b">
									<gml:exterior>
										<gml:LinearRing gml:id="line_7007ce30-47d2-4d0b-932e-a5f355d1fd39">
											<gml:posList>35.668630285119036 139.74781332977528 33.486000373366295 35.66862642811532 139.74781138344156 33.382370307448326 35.66862642811532 139.74781138344156 33.486000373366295 35.668630285119036 139.74781332977528 33.486000373366295</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_83527275-f2aa-4d9f-9b34-86baaebc1565">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_1d41c96b-02c2-4ed4-b8f3-2d6699123421">
									<gml:exterior>
										<gml:LinearRing gml:id="line_5cac82ef-2c93-4e4c-a76b-707f899a918e">
											<gml:posList>35.66867316936178 139.74783496920924 21.1433261179952 35.6686747729746 139.74783019638366 21.24694855451864 35.6686747729746 139.74783019638366 20.139732673170982 35.66867316936178 139.74783496920924 21.1433261179952</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_44f4f60a-175a-49de-92c4-23d55e84e963">
									<gml:exterior>
										<gml:LinearRing gml:id="line_0295bc34-6742-4a04-9bbb-8b3c9c8e347e">
											<gml:posList>35.6686747729746 139.74783019638366 21.24694855451864 35.66867316936178 139.74783496920924 21.1433261179952 35.66867316936178 139.74783496920924 21.24694855451864 35.6686747729746 139.74783019638366 21.24694855451864</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_f077f384-8870-4480-a594-fadd5a42a72f">
									<gml:exterior>
										<gml:LinearRing gml:id="line_e257064d-6363-4010-b174-f9bda0494641">
											<gml:posList>35.6686747729746 139.74783019638366 19.538376166823326 35.66867316936178 139.74783496920924 19.088371589186607 35.66867316936178 139.74783496920924 19.87842591047567 35.6686747729746 139.74783019638366 19.538376166823326</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_333a1ce6-c5b3-4c3d-a56e-bc0e5254acd2">
									<gml:exterior>
										<gml:LinearRing gml:id="line_a33765bf-3d7f-4801-aec3-9b872fe2b681">
											<gml:posList>35.66867316936178 139.74783496920924 19.088371589186607 35.6686747729746 139.74783019638366 19.538376166823326 35.6686747729746 139.74783019638366 19.088371589186607 35.66867316936178 139.74783496920924 19.088371589186607</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_782d4c61-5e33-4822-9dd5-cb0279b22fed">
									<gml:exterior>
										<gml:LinearRing gml:id="line_61727aef-6757-49e6-9425-4803b0b25d3d">
											<gml:posList>35.66867316936178 139.74783496920924 21.1433261179952 35.6686747729746 139.74783019638366 20.139732673170982 35.66867316936178 139.74783496920924 19.87842591047567 35.66867316936178 139.74783496920924 21.1433261179952</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_95c74a8f-0e66-4197-abc4-78c6139c53d5">
									<gml:exterior>
										<gml:LinearRing gml:id="line_f4fb0208-ab82-489c-a6f6-28b8923ffb84">
											<gml:posList>35.66867316936178 139.74783496920924 19.87842591047567 35.6686747729746 139.74783019638366 20.139732673170982 35.6686747729746 139.74783019638366 19.538376166823326 35.66867316936178 139.74783496920924 19.87842591047567</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
					<bldg:opening>
						<bldg:Window gml:id="wnd_117bcfc2-98b4-47e0-a07e-6e5e90b0c409">
							<bldg:lod3MultiSurface>
								<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_a7a3a788-6a13-40b8-8086-38e90f36a08d">
											<gml:exterior>
												<gml:LinearRing gml:id="line_bbf14a70-f13b-49f3-9557-006ba091c36b">
													<gml:posList>35.66867316936178 139.74783496920924 21.1433261179952 35.66867316936178 139.74783496920924 19.87842591047567 35.668669312220906 139.74783302287355 21.1433261179952 35.66867316936178 139.74783496920924 21.1433261179952</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_7a819d13-6caa-4348-a825-7250b1ccb081">
											<gml:exterior>
												<gml:LinearRing gml:id="line_c2ee63a8-af47-4394-ae1f-7c0b5cb1fb30">
													<gml:posList>35.668669312220906 139.74783302287355 21.1433261179952 35.66867316936178 139.74783496920924 19.87842591047567 35.668669312220906 139.74783302287355 19.87842591047567 35.668669312220906 139.74783302287355 21.1433261179952</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
								</gml:MultiSurface>
							</bldg:lod3MultiSurface>
						</bldg:Window>
					</bldg:opening>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_1b669ad2-f375-47a6-9ea1-f27371b8b09d">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_8929c83b-5d47-4c98-b5d9-12ea6e56e5e7">
									<gml:exterior>
										<gml:LinearRing gml:id="line_4af19ac7-4b6a-42ed-9ef2-2a24c52a89f0">
											<gml:posList>35.668670915971305 139.74782825021657 16.028610541823326 35.668670915971305 139.74782825021657 18.187187507155357 35.668669312220906 139.74783302287355 18.187187507155357 35.668670915971305 139.74782825021657 16.028610541823326</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_8dfc83af-8bff-4f21-99ab-fc41d064e06a">
									<gml:exterior>
										<gml:LinearRing gml:id="line_5314114a-8750-4a15-bdf8-76f852990fee">
											<gml:posList>35.668670915971305 139.74782825021657 16.028610541823326 35.668669312220906 139.74783302287355 18.187187507155357 35.668669312220906 139.74783302287355 16.028610541823326 35.668670915971305 139.74782825021657 16.028610541823326</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="wall_TMmnt0161_p993_5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly_TMmnt0161_p993_5">
									<gml:exterior>
										<gml:LinearRing gml:id="line_TMmnt0161_p993_5">
											<gml:posList>35.66862196369172 139.74798228174478 40.90570594 35.668621974972744 139.74798228439 37.8757062 35.66860531767898 139.74803075301475 37.87529138 35.66860530640587 139.74803075034654 40.90529111 35.66862196369172 139.74798228174478 40.90570594</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_2fa6a403-fc6c-4580-a0c8-1f7d33ad80cd">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_04949cc0-2d0a-499a-b29c-d7435a251d37">
									<gml:exterior>
										<gml:LinearRing gml:id="line_e0866f23-c7fd-4b0e-b646-fb8e420501bb">
											<gml:posList>35.668575396406865 139.74792157470998 38.68550141096395 35.668575396406865 139.74792157470998 41.17650635481161 35.6685725697646 139.7479299869554 38.68550141096395 35.668575396406865 139.74792157470998 38.68550141096395</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_533fb80a-f0ec-4df7-a5d8-eb5544f1c250">
									<gml:exterior>
										<gml:LinearRing gml:id="line_5eefa0ca-b938-4c7d-a2bf-417a7eeb7b18">
											<gml:posList>35.6685725697646 139.7479299869554 38.68550141096395 35.668575396406865 139.74792157470998 41.17650635481161 35.6685725697646 139.7479299869554 41.17650635481161 35.6685725697646 139.7479299869554 38.68550141096395</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_f74a8235-c762-4b56-ac1e-89336d0944d7">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_d28bbb84-fc09-4835-ba1c-2d215840d50f">
									<gml:exterior>
										<gml:LinearRing gml:id="line_eb03c7c6-8564-49b6-a53a-66f6731633e5">
											<gml:posList>35.6686747729746 139.74783019638366 17.07996399641317 35.66867316936178 139.74783496920924 18.187187507155357 35.6686747729746 139.74783019638366 18.187187507155357 35.6686747729746 139.74783019638366 17.07996399641317</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_28c647a9-94b6-4ead-a0ff-5b7a38df2872">
									<gml:exterior>
										<gml:LinearRing gml:id="line_c501d185-2633-41f0-8f15-ca270237d538">
											<gml:posList>35.66867316936178 139.74783496920924 18.187187507155357 35.6686747729746 139.74783019638366 17.07996399641317 35.66867316936178 139.74783496920924 16.028610541823326 35.66867316936178 139.74783496920924 18.187187507155357</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_1add8786-955e-45f7-9d47-ba42e897c2b5">
									<gml:exterior>
										<gml:LinearRing gml:id="line_193aa0e8-1294-40e3-8a20-34b9cdc69c47">
											<gml:posList>35.66867316936178 139.74783496920924 16.028610541823326 35.6686747729746 139.74783019638366 17.07996399641317 35.6686747729746 139.74783019638366 16.478615119460045 35.66867316936178 139.74783496920924 16.028610541823326</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_a22cad33-e8a4-4330-bb1e-b3a7305129fb">
									<gml:exterior>
										<gml:LinearRing gml:id="line_f45433b5-8e11-4f2e-a330-cbeadaa87901">
											<gml:posList>35.66867316936178 139.74783496920924 16.028610541823326 35.6686747729746 139.74783019638366 16.478615119460045 35.6686747729746 139.74783019638366 16.028610541823326 35.66867316936178 139.74783496920924 16.028610541823326</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
					<bldg:opening>
						<bldg:Window gml:id="wnd_ddd28b5e-4e49-4feb-9ccb-35445682bb7a">
							<bldg:lod3MultiSurface>
								<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_8fab033e-0cc2-4577-98ac-ed72956f92c3">
											<gml:exterior>
												<gml:LinearRing gml:id="line_2df62154-457b-46d0-90a0-0b57b7f5c60d">
													<gml:posList>35.66867316936178 139.74783496920924 16.028610541823326 35.668669312220906 139.74783302287355 16.028610541823326 35.66867316936178 139.74783496920924 18.187187507155357 35.66867316936178 139.74783496920924 16.028610541823326</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_305952e3-78dd-4039-98b8-e75e83e1d4f8">
											<gml:exterior>
												<gml:LinearRing gml:id="line_aa60a011-bf1e-42ab-adf2-dc13d377ea38">
													<gml:posList>35.66867316936178 139.74783496920924 18.187187507155357 35.668669312220906 139.74783302287355 16.028610541823326 35.668669312220906 139.74783302287355 18.187187507155357 35.66867316936178 139.74783496920924 18.187187507155357</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
								</gml:MultiSurface>
							</bldg:lod3MultiSurface>
						</bldg:Window>
					</bldg:opening>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_d16662fd-ef20-4064-9699-e694e8fda06e">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_031fcc9e-9998-4bd5-b884-691bb7d1fc63">
									<gml:exterior>
										<gml:LinearRing gml:id="line_21a0bc93-d792-427f-86fc-ecbc7c2bf107">
											<gml:posList>35.668670915971305 139.74782825021657 9.909088447096764 35.668670915971305 139.74782825021657 12.067657783034264 35.668669312220906 139.74783302287355 12.067657783034264 35.668670915971305 139.74782825021657 9.909088447096764</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_3b9e9faf-4705-4f75-8ff2-6e42eb299226">
									<gml:exterior>
										<gml:LinearRing gml:id="line_95914f84-8bd4-4f62-96f1-67d3ca7464f4">
											<gml:posList>35.668670915971305 139.74782825021657 9.909088447096764 35.668669312220906 139.74783302287355 12.067657783034264 35.668669312220906 139.74783302287355 9.909088447096764 35.668670915971305 139.74782825021657 9.909088447096764</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
					<bldg:opening>
						<bldg:Window gml:id="wnd_c7dbf258-63c9-4510-8387-4ac251fed9e3">
							<bldg:lod3MultiSurface>
								<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_c344250d-e3c5-4502-a4f7-77349c1a245e">
											<gml:exterior>
												<gml:LinearRing gml:id="line_e1f13b9f-c5cb-4a1e-8d41-37b4d0f938db">
													<gml:posList>35.668669312220906 139.74783302287355 9.909088447096764 35.668669312220906 139.74783302287355 12.067657783034264 35.66867316936178 139.74783496920924 9.909088447096764 35.668669312220906 139.74783302287355 9.909088447096764</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_a64c33ed-6ba4-4dcd-8eb1-535f4cb33f6a">
											<gml:exterior>
												<gml:LinearRing gml:id="line_6ccd4166-2110-4c77-a80f-44d9cbb1d5d1">
													<gml:posList>35.66867316936178 139.74783496920924 9.909088447096764 35.668669312220906 139.74783302287355 12.067657783034264 35.66867316936178 139.74783496920924 12.067657783034264 35.66867316936178 139.74783496920924 9.909088447096764</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
								</gml:MultiSurface>
							</bldg:lod3MultiSurface>
						</bldg:Window>
					</bldg:opening>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_bb9a9b77-74db-415b-a948-660a4f281a52">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_fb31554b-fccf-4b76-afe2-759d1dd53743">
									<gml:exterior>
										<gml:LinearRing gml:id="line_c337f69d-0ffd-4e23-a83e-2e54d59e4028">
											<gml:posList>35.66867316936178 139.74783496920924 30.322609260085045 35.6686747729746 139.74783019638366 30.426239326003014 35.6686747729746 139.74783019638366 29.319015815260826 35.66867316936178 139.74783496920924 30.322609260085045</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_bdee288b-15de-43f8-84a0-057079ef8a7d">
									<gml:exterior>
										<gml:LinearRing gml:id="line_053a1e21-5e8f-474c-8538-28535e2342d9">
											<gml:posList>35.6686747729746 139.74783019638366 30.426239326003014 35.66867316936178 139.74783496920924 30.322609260085045 35.66867316936178 139.74783496920924 30.426239326003014 35.6686747729746 139.74783019638366 30.426239326003014</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_4a4ca872-b161-4a2d-b20b-b96ca3d1148a">
									<gml:exterior>
										<gml:LinearRing gml:id="line_12262979-7f22-4377-ad84-9013f5b27464">
											<gml:posList>35.66867316936178 139.74783496920924 30.322609260085045 35.6686747729746 139.74783019638366 29.319015815260826 35.66867316936178 139.74783496920924 29.057709052565514 35.66867316936178 139.74783496920924 30.322609260085045</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_59cd8dd0-e165-4b6e-adf3-9a680ec9e11a">
									<gml:exterior>
										<gml:LinearRing gml:id="line_2c93de4e-f248-43fb-8814-d9fc04e8c7ee">
											<gml:posList>35.66867316936178 139.74783496920924 29.057709052565514 35.6686747729746 139.74783019638366 29.319015815260826 35.6686747729746 139.74783019638366 28.71765930891317 35.66867316936178 139.74783496920924 29.057709052565514</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_f1df555e-3f02-4d9f-a11e-7979d60d7ade">
									<gml:exterior>
										<gml:LinearRing gml:id="line_b3f58795-5a22-4f1f-a4b6-dfe71a740594">
											<gml:posList>35.66867316936178 139.74783496920924 29.057709052565514 35.6686747729746 139.74783019638366 28.71765930891317 35.66867316936178 139.74783496920924 28.267662360670982 35.66867316936178 139.74783496920924 29.057709052565514</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_d43b1406-1b8a-400b-86aa-3088067a8814">
									<gml:exterior>
										<gml:LinearRing gml:id="line_d9231f32-4b24-4820-8ec6-7da7a62b3a94">
											<gml:posList>35.66867316936178 139.74783496920924 28.267662360670982 35.6686747729746 139.74783019638366 28.71765930891317 35.6686747729746 139.74783019638366 28.267662360670982 35.66867316936178 139.74783496920924 28.267662360670982</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
					<bldg:opening>
						<bldg:Window gml:id="wnd_de4afb97-4ec4-4ed5-869e-28a805af8ea5">
							<bldg:lod3MultiSurface>
								<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_5a6d92e2-2c72-47f2-9613-ed549a6c4b07">
											<gml:exterior>
												<gml:LinearRing gml:id="line_e2222212-85af-4f11-b67e-412a0fe61d42">
													<gml:posList>35.66867316936178 139.74783496920924 30.322609260085045 35.66867316936178 139.74783496920924 29.057709052565514 35.668669312220906 139.74783302287355 30.322609260085045 35.66867316936178 139.74783496920924 30.322609260085045</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_0571d487-492f-4943-8893-02edeb563710">
											<gml:exterior>
												<gml:LinearRing gml:id="line_28213f40-d682-4a5a-8f98-9c142ec1f3ae">
													<gml:posList>35.668669312220906 139.74783302287355 30.322609260085045 35.66867316936178 139.74783496920924 29.057709052565514 35.668669312220906 139.74783302287355 29.057709052565514 35.668669312220906 139.74783302287355 30.322609260085045</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
								</gml:MultiSurface>
							</bldg:lod3MultiSurface>
						</bldg:Window>
					</bldg:opening>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_0d0f51b7-accb-4815-9a29-5f15ca3a452e">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_6acaa125-a4d3-455a-b81e-ee20ef01f7b5">
									<gml:exterior>
										<gml:LinearRing gml:id="line_048c8e85-8451-40e8-8d52-f5f511c6fc6d">
											<gml:posList>35.668690275854296 139.74782351812135 27.3664706492452 35.668690275854296 139.74782351812135 25.65789826154989 35.66868610967223 139.747835916983 27.3664706492452 35.668690275854296 139.74782351812135 27.3664706492452</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_26b7718f-eff6-4a1d-b47c-80d1b8bf5e4c">
									<gml:exterior>
										<gml:LinearRing gml:id="line_312a77d3-a3b1-4a67-aa44-3f7bc79f91bf">
											<gml:posList>35.66868610967223 139.747835916983 27.3664706492452 35.668690275854296 139.74782351812135 25.65789826154989 35.66868610967223 139.747835916983 25.65789826154989 35.66868610967223 139.747835916983 27.3664706492452</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_7bacaac8-c303-494f-8b4c-e6d3e16138a9">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_20d959e9-0991-410c-b0e8-e1ce178e88be">
									<gml:exterior>
										<gml:LinearRing gml:id="line_08b10f52-777f-4062-831a-72dde0f23326">
											<gml:posList>35.66862411485443 139.74789935105437 38.68550141096395 35.66860490590231 139.74795651934778 38.68550141096395 35.66862411485443 139.74789935105437 37.902504279616295 35.66862411485443 139.74789935105437 38.68550141096395</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_d883a868-1946-42ff-a6f2-be5234b945e1">
									<gml:exterior>
										<gml:LinearRing gml:id="line_da140362-7721-49bd-8221-1804c14c2558">
											<gml:posList>35.66862411485443 139.74789935105437 37.902504279616295 35.66860490590231 139.74795651934778 38.68550141096395 35.66860490590231 139.74795651934778 37.902504279616295 35.66862411485443 139.74789935105437 37.902504279616295</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_50723028-b532-42f1-987f-fde95e181a0e">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_79d0dfd4-a4af-4796-9e01-fdc445c2a644">
									<gml:exterior>
										<gml:LinearRing gml:id="line_a1da66f0-b09f-4c5d-b9e8-83eba51a36f1">
											<gml:posList>35.668631888868546 139.7478085569517 22.14813263654989 35.668630285119036 139.74781332977528 22.93818695783895 35.668631888868546 139.7478085569517 24.30670960188192 35.668631888868546 139.7478085569517 22.14813263654989</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_8f7e2856-e7b2-412f-90e0-a09841c70e4a">
									<gml:exterior>
										<gml:LinearRing gml:id="line_8c7075e7-2b0d-4b99-96a7-ebc7b12a7c90">
											<gml:posList>35.668630285119036 139.74781332977528 22.93818695783895 35.668631888868546 139.7478085569517 22.14813263654989 35.668630285119036 139.74781332977528 22.14813263654989 35.668630285119036 139.74781332977528 22.93818695783895</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_2ae570ec-4c7a-4565-b9f7-5285c199a477">
									<gml:exterior>
										<gml:LinearRing gml:id="line_cd1bf117-0d3e-4766-a2b0-f709e6f29699">
											<gml:posList>35.668631888868546 139.7478085569517 24.30670960188192 35.668630285119036 139.74781332977528 22.93818695783895 35.668630285119036 139.74781332977528 24.203087165358482 35.668631888868546 139.7478085569517 24.30670960188192</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_b8c8d40b-20fa-4157-a361-3093afd62834">
									<gml:exterior>
										<gml:LinearRing gml:id="line_7cda6d12-c781-4c30-b7ef-29acea9b696d">
											<gml:posList>35.668631888868546 139.7478085569517 24.30670960188192 35.668630285119036 139.74781332977528 24.203087165358482 35.668630285119036 139.74781332977528 24.30670960188192 35.668631888868546 139.7478085569517 24.30670960188192</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
					<bldg:opening>
						<bldg:Window gml:id="wnd_1b91d27a-155d-4d00-9859-174beee42cfd">
							<bldg:lod3MultiSurface>
								<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_76ec948b-7552-4384-ae76-051f2f00d764">
											<gml:exterior>
												<gml:LinearRing gml:id="line_662f162e-e54e-4dfa-9e52-2058e9a060cc">
													<gml:posList>35.668630285119036 139.74781332977528 24.203087165358482 35.668630285119036 139.74781332977528 22.93818695783895 35.66862642811532 139.74781138344156 24.203087165358482 35.668630285119036 139.74781332977528 24.203087165358482</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_5ce163e7-ef23-4bf8-8aba-12771d9a4910">
											<gml:exterior>
												<gml:LinearRing gml:id="line_01ec1b9e-44a9-4f8f-a841-5df5f17ad110">
													<gml:posList>35.66862642811532 139.74781138344156 24.203087165358482 35.668630285119036 139.74781332977528 22.93818695783895 35.66862642811532 139.74781138344156 22.93818695783895 35.66862642811532 139.74781138344156 24.203087165358482</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
								</gml:MultiSurface>
							</bldg:lod3MultiSurface>
						</bldg:Window>
					</bldg:opening>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="wall_TMmnt0161_p993_1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly_TMmnt0161_p993_1">
									<gml:exterior>
										<gml:LinearRing gml:id="line_TMmnt0161_p993_1">
											<gml:posList>35.66865438913517 139.7479537218797 5.45110006 35.66865426824419 139.74795369371623 37.87698327 35.66865118558869 139.7479521026939 37.87683046 35.66865117429369 139.74795210006292 40.9068302 35.668676550305804 139.74796519715258 40.90808868 35.66867668261765 139.74796522801174 5.45220574 35.66865438913517 139.7479537218797 5.45110006</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_0f87377e-c6a7-4faa-83e6-bd9361778ed3">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_7fcf4cbd-f43c-4c00-bca3-adf315708397">
									<gml:exterior>
										<gml:LinearRing gml:id="line_60170a33-76d6-47f6-9a23-93aa393f20ee">
											<gml:posList>35.66862642811532 139.74781138344156 19.87842591047567 35.668630285119036 139.74781332977528 19.87842591047567 35.66862642811532 139.74781138344156 19.088371589186607 35.66862642811532 139.74781138344156 19.87842591047567</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_98f866a3-ec5a-4df5-a141-dfe7f6e02b2c">
									<gml:exterior>
										<gml:LinearRing gml:id="line_718296d6-af0e-4199-8c6d-bd932fe7250c">
											<gml:posList>35.66862642811532 139.74781138344156 19.088371589186607 35.668630285119036 139.74781332977528 19.87842591047567 35.668630285119036 139.74781332977528 19.088371589186607 35.66862642811532 139.74781138344156 19.088371589186607</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_d77839e3-b531-4aa9-9da1-1f49f673a91b">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_57e3a827-02e1-4dbe-a66d-a7ee72a678d5">
									<gml:exterior>
										<gml:LinearRing gml:id="line_95d5a0e9-4752-4091-97b2-5d2ffb4b6392">
											<gml:posList>35.66852209893759 139.74807548353158 6.3942492747334825 35.66852209893759 139.74807548353158 8.85669739485067 35.668515012063814 139.74807190738593 6.3942492747334825 35.66852209893759 139.74807548353158 6.3942492747334825</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_820e4951-5343-4929-9b2a-cbe37a05e20e">
									<gml:exterior>
										<gml:LinearRing gml:id="line_b620318d-9263-4182-81d0-43d570cd695d">
											<gml:posList>35.668515012063814 139.74807190738593 6.3942492747334825 35.66852209893759 139.74807548353158 8.85669739485067 35.668515012063814 139.74807190738593 8.85669739485067 35.668515012063814 139.74807190738593 6.3942492747334825</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="wall_TMmnt0161_p992_2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly_TMmnt0161_p992_2">
									<gml:exterior>
										<gml:LinearRing gml:id="line_TMmnt0161_p992_2">
											<gml:posList>35.668626332929605 139.74803536008534 5.45039866 35.66862620089855 139.74803532883664 40.90628161 35.66862438966881 139.74804059916218 40.90623667 35.66862452168971 139.74804063044013 5.45035373 35.668626332929605 139.74803536008534 5.45039866</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_6ae687f2-3dc0-4fe2-9dbf-f3fed0a932f6">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_d7720953-e944-4c93-8652-d51c01e8667b">
									<gml:exterior>
										<gml:LinearRing gml:id="line_24f82d2f-2f6a-4b38-9029-4be2eee8ff47">
											<gml:posList>35.66867316936178 139.74783496920924 21.1433261179952 35.668669312220906 139.74783302287355 21.1433261179952 35.66867316936178 139.74783496920924 21.24694855451864 35.66867316936178 139.74783496920924 21.1433261179952</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_c5f94a23-cc32-43ab-a160-49372e273b3c">
									<gml:exterior>
										<gml:LinearRing gml:id="line_81e315ae-f487-43a2-bb84-37c09a6bb4d2">
											<gml:posList>35.66867316936178 139.74783496920924 21.24694855451864 35.668669312220906 139.74783302287355 21.1433261179952 35.668669312220906 139.74783302287355 21.24694855451864 35.66867316936178 139.74783496920924 21.24694855451864</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="wall_TMmnt0161_p991_4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly_TMmnt0161_p991_4">
									<gml:exterior>
										<gml:LinearRing gml:id="line_TMmnt0161_p991_4">
											<gml:posList>35.6686243702306 139.747797159778 5.44862419 35.66858554966255 139.74791011886649 5.4476359 35.66858542912262 139.74791009092453 37.87351913 35.66859650191569 139.74787787163882 37.87379905 35.66859651403997 139.7478778744316 34.61379934 35.668624261631244 139.74779713516125 34.6145077 35.6686243702306 139.747797159778 5.44862419</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="wall_TMmnt0161_p993_6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly_TMmnt0161_p993_6">
									<gml:exterior>
										<gml:LinearRing gml:id="line_TMmnt0161_p993_6">
											<gml:posList>35.66863796358011 139.74799053951006 40.90649867 35.668637974868794 139.74799054215927 37.87649894 35.668621974972744 139.74798228439 37.8757062 35.66862196369172 139.74798228174478 40.90570594 35.66863796358011 139.74799053951006 40.90649867</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_b7ff1767-ba83-4df2-b041-e5fbbc48b7ea">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_208efd56-c484-49d9-8edc-14e79701d7fb">
									<gml:exterior>
										<gml:LinearRing gml:id="line_384043da-5449-4cf9-ae8c-c81fbbbd6a2e">
											<gml:posList>35.668605516458285 139.74803107289867 40.907394721510826 35.668621903878346 139.74798230203365 40.907394721510826 35.668621903878346 139.74798230203365 37.902504279616295 35.668605516458285 139.74803107289867 40.907394721510826</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_1283e6fb-8b17-4040-a639-8188fd0e40b4">
									<gml:exterior>
										<gml:LinearRing gml:id="line_dfaeb89c-5afd-438f-8093-b4f2c1a68907">
											<gml:posList>35.668605516458285 139.74803107289867 40.907394721510826 35.668621903878346 139.74798230203365 37.902504279616295 35.668605516458285 139.74803107289867 37.902504279616295 35.668605516458285 139.74803107289867 40.907394721510826</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_1486db79-4a55-46c4-a30d-278a1ebfcc70">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_a601c091-f12a-4b90-9ea5-d0e7539fbfae">
									<gml:exterior>
										<gml:LinearRing gml:id="line_61e12d36-927c-4afc-99a8-46e96c591e97">
											<gml:posList>35.668631888868546 139.7478085569517 25.2079013133077 35.668630285119036 139.74781332977528 25.997948005202232 35.668631888868546 139.7478085569517 27.3664706492452 35.668631888868546 139.7478085569517 25.2079013133077</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_70a67229-a121-441b-81ea-3776bf6152f5">
									<gml:exterior>
										<gml:LinearRing gml:id="line_89058254-7cdc-459a-9b93-dd17f9bf8650">
											<gml:posList>35.668630285119036 139.74781332977528 25.997948005202232 35.668631888868546 139.7478085569517 25.2079013133077 35.668630285119036 139.74781332977528 25.2079013133077 35.668630285119036 139.74781332977528 25.997948005202232</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_f15ba58b-f383-446f-a47c-25b8ddadb086">
									<gml:exterior>
										<gml:LinearRing gml:id="line_f85d4645-bde8-4609-88de-f61eccb87914">
											<gml:posList>35.668631888868546 139.7478085569517 27.3664706492452 35.668630285119036 139.74781332977528 25.997948005202232 35.668630285119036 139.74781332977528 27.262848212721764 35.668631888868546 139.7478085569517 27.3664706492452</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_7828f043-078a-4017-bf63-0d5359ab61ac">
									<gml:exterior>
										<gml:LinearRing gml:id="line_a5e62383-80f4-4197-bf6d-02d4a03f7015">
											<gml:posList>35.668631888868546 139.7478085569517 27.3664706492452 35.668630285119036 139.74781332977528 27.262848212721764 35.668630285119036 139.74781332977528 27.3664706492452 35.668631888868546 139.7478085569517 27.3664706492452</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
					<bldg:opening>
						<bldg:Window gml:id="wnd_c9ae39bb-c7a1-4771-8e5a-a9aae4e13838">
							<bldg:lod3MultiSurface>
								<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_6a7d783e-3ce0-46ef-8e92-81827018bc1b">
											<gml:exterior>
												<gml:LinearRing gml:id="line_9b2b60cc-7c92-4485-aeb9-bdaf165c9b6d">
													<gml:posList>35.668630285119036 139.74781332977528 27.262848212721764 35.668630285119036 139.74781332977528 25.997948005202232 35.66862642811532 139.74781138344156 27.262848212721764 35.668630285119036 139.74781332977528 27.262848212721764</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_4b4fa0bf-18b0-4c95-b885-6d4e31ff2832">
											<gml:exterior>
												<gml:LinearRing gml:id="line_b297f4b7-ca49-411b-a6a0-c8a4dec6eba8">
													<gml:posList>35.66862642811532 139.74781138344156 27.262848212721764 35.668630285119036 139.74781332977528 25.997948005202232 35.66862642811532 139.74781138344156 25.997948005202232 35.66862642811532 139.74781138344156 27.262848212721764</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
								</gml:MultiSurface>
							</bldg:lod3MultiSurface>
						</bldg:Window>
					</bldg:opening>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="wall_TMmnt0161_p993_2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly_TMmnt0161_p993_2">
									<gml:exterior>
										<gml:LinearRing gml:id="line_TMmnt0161_p993_2">
											<gml:posList>35.668676550305804 139.74796519715258 40.90808868 35.66864849345966 139.74804683452038 40.90738724 35.668648625614985 139.74804686583292 5.4515043 35.66867668261765 139.74796522801174 5.45220574 35.668676550305804 139.74796519715258 40.90808868</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_25f3c337-d4a4-4ca4-aaea-ca81a63bdecc">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_97ce8ec7-ea6f-42d6-9a5f-58d07fbfaecd">
									<gml:exterior>
										<gml:LinearRing gml:id="line_7d02cbbe-e2a7-4040-8f10-ee3e8181ca0f">
											<gml:posList>35.66855524659499 139.7480922099503 8.85669739485067 35.668557901274575 139.74808430893498 8.85669739485067 35.66855524659499 139.7480922099503 6.3942492747334825 35.66855524659499 139.7480922099503 8.85669739485067</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_cf6a9cad-b116-4456-a98e-20e352984ff6">
									<gml:exterior>
										<gml:LinearRing gml:id="line_23b20e84-bf61-4422-ac96-be0caf098416">
											<gml:posList>35.66855524659499 139.7480922099503 6.3942492747334825 35.668557901274575 139.74808430893498 8.85669739485067 35.668557901274575 139.74808430893498 6.3942492747334825 35.66855524659499 139.7480922099503 6.3942492747334825</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
					<bldg:opening>
						<bldg:Door gml:id="dor_861cc5e2-1872-4f67-ba27-ffa74c902b0a">
							<bldg:lod3MultiSurface>
								<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_9d310a33-4c80-4c05-8d71-07f3ea6582a2">
											<gml:exterior>
												<gml:LinearRing gml:id="line_28a71c3f-5845-4d0b-9c19-c2837bbd6d5e">
													<gml:posList>35.668557901274575 139.74808430893498 8.85669739485067 35.66854356888887 139.74807707674765 8.85669739485067 35.66854356888887 139.74807707674765 6.3942492747334825 35.668557901274575 139.74808430893498 8.85669739485067</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_6ba3444e-c15e-4f9f-8a4a-3b9b3b0d5d17">
											<gml:exterior>
												<gml:LinearRing gml:id="line_6deb4523-5aa3-4805-a412-8c3c24f75557">
													<gml:posList>35.668557901274575 139.74808430893498 8.85669739485067 35.66854356888887 139.74807707674765 6.3942492747334825 35.668557901274575 139.74808430893498 6.3942492747334825 35.668557901274575 139.74808430893498 8.85669739485067</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
								</gml:MultiSurface>
							</bldg:lod3MultiSurface>
						</bldg:Door>
					</bldg:opening>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_1bc0ede0-6cfb-4953-8737-fa46b735712a">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_1b60df17-205b-460f-b4b8-5238add148f8">
									<gml:exterior>
										<gml:LinearRing gml:id="line_06a2f7d7-292d-4bd7-b1fb-f44a9d601799">
											<gml:posList>35.66867316936178 139.74783496920924 15.127426459792076 35.6686747729746 139.74783019638366 14.020202949049889 35.66867316936178 139.74783496920924 12.968849494460045 35.66867316936178 139.74783496920924 15.127426459792076</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_d995b721-668c-4b21-bbc0-e9789900c434">
									<gml:exterior>
										<gml:LinearRing gml:id="line_a3ba8e91-74bf-4310-98fe-422da74c701f">
											<gml:posList>35.6686747729746 139.74783019638366 14.020202949049889 35.66867316936178 139.74783496920924 15.127426459792076 35.6686747729746 139.74783019638366 15.127426459792076 35.6686747729746 139.74783019638366 14.020202949049889</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_583e9ae4-c4e1-4f92-be42-6690a18c6c0b">
									<gml:exterior>
										<gml:LinearRing gml:id="line_ca5d9aa1-5889-4254-b7bc-0b9afc25ef9c">
											<gml:posList>35.66867316936178 139.74783496920924 12.968849494460045 35.6686747729746 139.74783019638366 14.020202949049889 35.6686747729746 139.74783019638366 13.418846442702232 35.66867316936178 139.74783496920924 12.968849494460045</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_5efd7dd2-2aba-4ebc-94c3-a8234ab5609c">
									<gml:exterior>
										<gml:LinearRing gml:id="line_9a7d0c4c-0ce9-448f-a96a-e7e67d45e05d">
											<gml:posList>35.66867316936178 139.74783496920924 12.968849494460045 35.6686747729746 139.74783019638366 13.418846442702232 35.6686747729746 139.74783019638366 12.968849494460045 35.66867316936178 139.74783496920924 12.968849494460045</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
					<bldg:opening>
						<bldg:Window gml:id="wnd_3525fc05-1ece-4e78-a7b7-f5be56ecb9cc">
							<bldg:lod3MultiSurface>
								<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_e96d102a-d44d-4bc1-9346-3e4acc56b91c">
											<gml:exterior>
												<gml:LinearRing gml:id="line_4d3c6d5c-ccfa-4f26-8a0d-ad4c2cf11035">
													<gml:posList>35.66867316936178 139.74783496920924 12.968849494460045 35.668669312220906 139.74783302287355 12.968849494460045 35.66867316936178 139.74783496920924 15.127426459792076 35.66867316936178 139.74783496920924 12.968849494460045</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_f5784dc2-e37d-4149-928c-5a05cbd8ec9c">
											<gml:exterior>
												<gml:LinearRing gml:id="line_d60a0426-2584-43d3-8e68-d447ba5e9061">
													<gml:posList>35.66867316936178 139.74783496920924 15.127426459792076 35.668669312220906 139.74783302287355 12.968849494460045 35.668669312220906 139.74783302287355 15.127426459792076 35.66867316936178 139.74783496920924 15.127426459792076</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
								</gml:MultiSurface>
							</bldg:lod3MultiSurface>
						</bldg:Window>
					</bldg:opening>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_da638c0d-8ef7-4190-bd42-c47628df1328">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_f13dd72a-8210-4258-8b56-1d078846b0cc">
									<gml:exterior>
										<gml:LinearRing gml:id="line_36c1313e-48b1-4705-be45-3d8167687f6d">
											<gml:posList>35.66855524659499 139.7480922099503 6.3942492747334825 35.66856187915317 139.74809555685056 6.3942492747334825 35.66855524659499 139.7480922099503 8.85669739485067 35.66855524659499 139.7480922099503 6.3942492747334825</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_7e2ba2ac-b80b-446c-bd5a-90721cc01548">
									<gml:exterior>
										<gml:LinearRing gml:id="line_1658f89a-30d6-4816-b27c-956ca9a46de5">
											<gml:posList>35.66855524659499 139.7480922099503 8.85669739485067 35.66856187915317 139.74809555685056 6.3942492747334825 35.66856187915317 139.74809555685056 8.85669739485067 35.66855524659499 139.7480922099503 8.85669739485067</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="wall_TMmnt0161_p993_4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly_TMmnt0161_p993_4">
									<gml:exterior>
										<gml:LinearRing gml:id="line_TMmnt0161_p993_4">
											<gml:posList>35.66865117429369 139.74795210006292 40.9068302 35.66865118558869 139.7479521026939 37.87683046 35.668637974868794 139.74799054215927 37.87649894 35.66863796358011 139.74799053951006 40.90649867 35.66865117429369 139.74795210006292 40.9068302</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="wall_TMmnt0161_p992_6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly_TMmnt0161_p992_6">
									<gml:exterior>
										<gml:LinearRing gml:id="line_TMmnt0161_p992_6">
											<gml:posList>35.66851325484911 139.7480785266932 37.87142926 35.6685732913533 139.7479038266831 37.87291958 35.66857341183139 139.74790385459326 5.44703635 35.668513375020865 139.7480785554907 5.44554602 35.66851325484911 139.7480785266932 37.87142926</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_3ca8fda8-ca1e-4667-afe2-ccbfd4d69a7f">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_3d5fd487-a150-4fad-a2dd-4a65a0a8882c">
									<gml:exterior>
										<gml:LinearRing gml:id="line_efe1f23b-1647-44ed-abcc-c01dfdfd2684">
											<gml:posList>35.66867650520553 139.7479650200619 40.907394721510826 35.668648942130886 139.74804705098273 40.907394721510826 35.66867650520553 139.7479650200619 6.3942492747334825 35.66867650520553 139.7479650200619 40.907394721510826</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_28ca69eb-fd0a-47c9-949c-931e33b3944f">
									<gml:exterior>
										<gml:LinearRing gml:id="line_6192d348-a4e6-484c-bc31-2237e7dd5157">
											<gml:posList>35.66867650520553 139.7479650200619 6.3942492747334825 35.668648942130886 139.74804705098273 40.907394721510826 35.668648942130886 139.74804705098273 6.3942492747334825 35.66867650520553 139.7479650200619 6.3942492747334825</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="wall_TMmnt0161_p992_4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly_TMmnt0161_p992_4">
									<gml:exterior>
										<gml:LinearRing gml:id="line_TMmnt0161_p992_4">
											<gml:posList>35.668591246955046 139.74802349115882 37.87459471 35.66856343406604 139.7481044236526 37.87391003 35.668563554493765 139.74810445258177 5.4480268 35.66859136752457 139.74802351967682 5.44871149 35.668591246955046 139.74802349115882 37.87459471</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_1f08e834-c765-42f0-8c7f-ba79dcea150d">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_1c47bf53-a337-4ac0-a883-c8a5766675de">
									<gml:exterior>
										<gml:LinearRing gml:id="line_dd74db59-67fd-4e27-95ca-dc9123a2d564">
											<gml:posList>35.66856072996256 139.74809897657752 8.85669739485067 35.66855909916354 139.7481038301547 6.3942492747334825 35.66855909916354 139.7481038301547 9.23169739485067 35.66856072996256 139.74809897657752 8.85669739485067</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_72b8bd69-437f-4928-b786-7b13b73a8293">
									<gml:exterior>
										<gml:LinearRing gml:id="line_b8e77494-2c9e-4a23-8dcd-72cf5568ed4a">
											<gml:posList>35.66855909916354 139.7481038301547 6.3942492747334825 35.66856072996256 139.74809897657752 8.85669739485067 35.66856187915317 139.74809555685056 6.3942492747334825 35.66855909916354 139.7481038301547 6.3942492747334825</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_54a94861-d71b-45f2-9948-4df8454acb32">
									<gml:exterior>
										<gml:LinearRing gml:id="line_48b96475-7bc9-4189-a4ef-892726a33727">
											<gml:posList>35.66856187915317 139.74809555685056 6.3942492747334825 35.66856072996256 139.74809897657752 8.85669739485067 35.66856187915317 139.74809555685056 8.85669739485067 35.66856187915317 139.74809555685056 6.3942492747334825</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_2a749460-e833-4e48-ba8b-e6628b6f5c6c">
									<gml:exterior>
										<gml:LinearRing gml:id="line_5ab94d07-6c09-493a-8274-6d490ba7884d">
											<gml:posList>35.66856072996256 139.74809897657752 8.85669739485067 35.66855909916354 139.7481038301547 9.23169739485067 35.6685599733061 139.74810122885575 9.23169739485067 35.66856072996256 139.74809897657752 8.85669739485067</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_5ac71baf-b522-46bd-b152-44827c170185">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_c091b54a-c11b-4277-b4e1-776ff2da6e20">
									<gml:exterior>
										<gml:LinearRing gml:id="line_a43cf0f0-86e7-41fb-90c7-4e5d37afffac">
											<gml:posList>35.6686747729746 139.74783019638366 31.77742035627645 35.66867316936178 139.74783496920924 31.327423408034264 35.66867316936178 139.74783496920924 32.117470099928795 35.6686747729746 139.74783019638366 31.77742035627645</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_13c06a71-3a39-4ae0-9668-fd5c21a121cd">
									<gml:exterior>
										<gml:LinearRing gml:id="line_48b4e6c4-b73e-4cba-8b63-61105174e8ce">
											<gml:posList>35.66867316936178 139.74783496920924 31.327423408034264 35.6686747729746 139.74783019638366 31.77742035627645 35.6686747729746 139.74783019638366 31.327423408034264 35.66867316936178 139.74783496920924 31.327423408034264</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_2955b662-4690-40a2-8445-a638e36e3b26">
									<gml:exterior>
										<gml:LinearRing gml:id="line_00fa4190-7202-42d8-bb0c-6a81ab8c5c10">
											<gml:posList>35.6686747729746 139.74783019638366 31.77742035627645 35.66867316936178 139.74783496920924 32.117470099928795 35.6686747729746 139.74783019638366 32.37877686262411 35.6686747729746 139.74783019638366 31.77742035627645</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_9c35816e-f70a-48f7-92e9-1082e29a15a7">
									<gml:exterior>
										<gml:LinearRing gml:id="line_43cd4da5-2a88-477c-a271-c66cc271b93e">
											<gml:posList>35.6686747729746 139.74783019638366 32.37877686262411 35.66867316936178 139.74783496920924 32.117470099928795 35.66867316936178 139.74783496920924 33.382370307448326 35.6686747729746 139.74783019638366 32.37877686262411</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_d5b9a0c5-09ff-457c-b70b-99974c0933d6">
									<gml:exterior>
										<gml:LinearRing gml:id="line_0cb1b5b3-5d9a-4cad-8b70-a006f11d7853">
											<gml:posList>35.6686747729746 139.74783019638366 32.37877686262411 35.66867316936178 139.74783496920924 33.382370307448326 35.6686747729746 139.74783019638366 33.486000373366295 35.6686747729746 139.74783019638366 32.37877686262411</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_da365f34-67df-47db-81c9-06a735dbf9d9">
									<gml:exterior>
										<gml:LinearRing gml:id="line_4b064808-cfc4-4530-a3d8-df0da773eeea">
											<gml:posList>35.6686747729746 139.74783019638366 33.486000373366295 35.66867316936178 139.74783496920924 33.382370307448326 35.66867316936178 139.74783496920924 33.486000373366295 35.6686747729746 139.74783019638366 33.486000373366295</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
					<bldg:opening>
						<bldg:Window gml:id="wnd_cd212457-f79d-4d7c-9437-b2edb8df7572">
							<bldg:lod3MultiSurface>
								<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_0ee5c805-3b51-4801-915e-9bbc241b9fc6">
											<gml:exterior>
												<gml:LinearRing gml:id="line_19dff772-2db2-4583-b982-2916f0c42e7f">
													<gml:posList>35.66867316936178 139.74783496920924 33.382370307448326 35.66867316936178 139.74783496920924 32.117470099928795 35.668669312220906 139.74783302287355 33.382370307448326 35.66867316936178 139.74783496920924 33.382370307448326</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_ced38f0d-070c-4ffb-a64a-3a7416db6d74">
											<gml:exterior>
												<gml:LinearRing gml:id="line_e15d100f-ba33-43a4-97a6-6b9f1520f7f9">
													<gml:posList>35.668669312220906 139.74783302287355 33.382370307448326 35.66867316936178 139.74783496920924 32.117470099928795 35.668669312220906 139.74783302287355 32.117470099928795 35.668669312220906 139.74783302287355 33.382370307448326</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
								</gml:MultiSurface>
							</bldg:lod3MultiSurface>
						</bldg:Window>
					</bldg:opening>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_848130a7-32bb-4876-8d18-cb3ac3b32630">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_b3ef79e3-c217-41ae-bbd5-8715587d190c">
									<gml:exterior>
										<gml:LinearRing gml:id="line_39bd3b68-ce6e-46bd-af10-911c5d6d651a">
											<gml:posList>35.66858854430902 139.74802250878727 6.3942492747334825 35.66858854430902 139.74802250878727 37.902504279616295 35.66856091215805 139.7481047449641 6.3942492747334825 35.66858854430902 139.74802250878727 6.3942492747334825</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_451f2c5c-ba5a-4b46-a2cb-66615146fdc3">
									<gml:exterior>
										<gml:LinearRing gml:id="line_500e7c6f-dbe3-4527-b8e0-1ea2dc62acb1">
											<gml:posList>35.66856091215805 139.7481047449641 6.3942492747334825 35.66858854430902 139.74802250878727 37.902504279616295 35.66856091215805 139.7481047449641 37.902504279616295 35.66856091215805 139.7481047449641 6.3942492747334825</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="wall_TMmnt0161_p992_3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly_TMmnt0161_p992_3">
									<gml:exterior>
										<gml:LinearRing gml:id="line_TMmnt0161_p992_3">
											<gml:posList>35.66860531767898 139.74803075301475 37.87529138 35.668591246955046 139.74802349115882 37.87459471 35.66859136752457 139.74802351967682 5.44871149 35.66862452168971 139.74804063044013 5.45035373 35.66862438966881 139.74804059916218 40.90623667 35.66860530640587 139.74803075034654 40.90529111 35.66860531767898 139.74803075301475 37.87529138</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="wall_TMmnt0161_p991_2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly_TMmnt0161_p991_2">
									<gml:exterior>
										<gml:LinearRing gml:id="line_TMmnt0161_p991_2">
											<gml:posList>35.66868917663862 139.747813404338 34.61760013 35.66870048759267 139.74781924194826 34.61816069 35.668700596541825 139.74781926666608 5.4522772 35.66868928553584 139.7478134290291 5.45171664 35.66868917663862 139.747813404338 34.61760013</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_174a0e12-1ee5-4e5b-809a-b1048ed963dd">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_2cf72563-b678-4b6c-829f-acb9b78cc50a">
									<gml:exterior>
										<gml:LinearRing gml:id="line_87cd77cb-dc37-47c2-8715-821d7afb1675">
											<gml:posList>35.66869214950836 139.7478389646508 9.355507209303795 35.66865366644167 139.74795349557397 6.3942492747334825 35.66869214950836 139.7478389646508 6.3942492747334825 35.66869214950836 139.7478389646508 9.355507209303795</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_3d6acbaf-a309-43f4-bb28-b6ac4337c570">
									<gml:exterior>
										<gml:LinearRing gml:id="line_506efb93-3688-4ac5-beb8-933fdf5ce380">
											<gml:posList>35.66865366644167 139.74795349557397 6.3942492747334825 35.66869214950836 139.7478389646508 9.355507209303795 35.668664937877324 139.74791995042165 35.550506904128014 35.66865366644167 139.74795349557397 6.3942492747334825</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_6a56a653-df6b-4e26-bb12-ddf92e65048f">
									<gml:exterior>
										<gml:LinearRing gml:id="line_fd64311c-e5dc-4aa9-89d6-5c747b5dd0be">
											<gml:posList>35.66865366644167 139.74795349557397 37.902504279616295 35.668664937877324 139.74791995042165 35.550506904128014 35.668664937877324 139.74791995042165 37.902504279616295 35.66865366644167 139.74795349557397 37.902504279616295</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_3f012ca5-e87f-4953-a06f-e202c91158c2">
									<gml:exterior>
										<gml:LinearRing gml:id="line_a3c7503d-b5bc-4837-bd64-45157abab552">
											<gml:posList>35.668664937877324 139.74791995042165 35.550506904128014 35.66865366644167 139.74795349557397 37.902504279616295 35.66865366644167 139.74795349557397 6.3942492747334825 35.668664937877324 139.74791995042165 35.550506904128014</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_76df5a6c-feb0-4cb5-b0b2-01af36623c40">
									<gml:exterior>
										<gml:LinearRing gml:id="line_d72483ce-246f-4127-80b7-0c33179f28e8">
											<gml:posList>35.6686970039924 139.74782451718383 10.597503974440514 35.668664937877324 139.74791995042165 35.550506904128014 35.66869214950836 139.7478389646508 9.355507209303795 35.6686970039924 139.74782451718383 10.597503974440514</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_86d5a8dc-5d66-49e7-828c-8ad0925554e7">
									<gml:exterior>
										<gml:LinearRing gml:id="line_6007fec6-23cd-44c3-8da7-4b95c85d4fa8">
											<gml:posList>35.668664937877324 139.74791995042165 35.550506904128014 35.6686970039924 139.74782451718383 10.597503974440514 35.6686970039924 139.74782451718383 35.550506904128014 35.668664937877324 139.74791995042165 35.550506904128014</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_48ccbf2e-e8a6-4f1a-8fc7-4fbb60bc572a">
									<gml:exterior>
										<gml:LinearRing gml:id="line_7ba4703f-19d3-4cea-bb0d-058e7ca73740">
											<gml:posList>35.6686970039924 139.74782451718383 10.597503974440514 35.66869214950836 139.7478389646508 9.355507209303795 35.6686970039924 139.74782451718383 9.355507209303795 35.6686970039924 139.74782451718383 10.597503974440514</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_a72ed339-f112-4c3c-ad6f-1828752678c2">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_57d1b2d0-cf76-40d1-ab43-4d1948cde412">
									<gml:exterior>
										<gml:LinearRing gml:id="line_ccaf3a20-8944-4e87-a559-9f641ef3e57a">
											<gml:posList>35.668670915971305 139.74782825021657 24.30670960188192 35.668669312220906 139.74783302287355 24.203087165358482 35.668669312220906 139.74783302287355 22.93818695783895 35.668670915971305 139.74782825021657 24.30670960188192</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_29a7a911-50f6-4a60-aa0e-413c57cce114">
									<gml:exterior>
										<gml:LinearRing gml:id="line_6b667164-00cd-4b9e-bb26-2784aae8b16b">
											<gml:posList>35.668669312220906 139.74783302287355 24.203087165358482 35.668670915971305 139.74782825021657 24.30670960188192 35.668669312220906 139.74783302287355 24.30670960188192 35.668669312220906 139.74783302287355 24.203087165358482</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_f6851e01-d34d-4a76-a0ce-eb8ad0996aa1">
									<gml:exterior>
										<gml:LinearRing gml:id="line_9afdb10a-27b2-4659-923c-7ff7e324cc3f">
											<gml:posList>35.668670915971305 139.74782825021657 24.30670960188192 35.668669312220906 139.74783302287355 22.93818695783895 35.668670915971305 139.74782825021657 22.14813263654989 35.668670915971305 139.74782825021657 24.30670960188192</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_7bed1b8c-48ae-4ed0-95b9-475d2cd3c39f">
									<gml:exterior>
										<gml:LinearRing gml:id="line_240d1d7f-99c8-4f12-839b-04173eb40ffe">
											<gml:posList>35.668670915971305 139.74782825021657 22.14813263654989 35.668669312220906 139.74783302287355 22.93818695783895 35.668669312220906 139.74783302287355 22.14813263654989 35.668670915971305 139.74782825021657 22.14813263654989</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_e4329407-601a-4d79-8c04-b74d64938c11">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_d92e6410-2378-4eae-a94c-07f3824d3312">
									<gml:exterior>
										<gml:LinearRing gml:id="line_d9278d11-1e7a-44cb-8b56-7d6029a2dae8">
											<gml:posList>35.668628031727216 139.74780661061828 33.486000373366295 35.66862094168115 139.74780303297814 35.550506904128014 35.668631888868546 139.7478085569517 33.486000373366295 35.668628031727216 139.74780661061828 33.486000373366295</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_30140a5b-2d55-42db-bbea-c9caae290119">
									<gml:exterior>
										<gml:LinearRing gml:id="line_c32d5b4d-71a3-4ef7-b6df-ff9a290ec07b">
											<gml:posList>35.66862094168115 139.74780303297814 35.550506904128014 35.668628031727216 139.74780661061828 33.486000373366295 35.668628031727216 139.74780661061828 31.327423408034264 35.66862094168115 139.74780303297814 35.550506904128014</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_cd82b745-8ffa-4f70-b675-7d5314e00595">
									<gml:exterior>
										<gml:LinearRing gml:id="line_9eae35b5-264c-48ee-8ccd-c0bf4c3d4d94">
											<gml:posList>35.668631888868546 139.7478085569517 33.486000373366295 35.66862094168115 139.74780303297814 35.550506904128014 35.6686334553077 139.74780934746065 33.382370307448326 35.668631888868546 139.7478085569517 33.486000373366295</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_dde91c9c-b9d0-4892-ba0f-e11153726646">
									<gml:exterior>
										<gml:LinearRing gml:id="line_918a02ba-10d1-491f-aeb2-9e28aa80c040">
											<gml:posList>35.6686334553077 139.74780934746065 33.382370307448326 35.66862094168115 139.74780303297814 35.550506904128014 35.6686747729746 139.74783019638366 35.550506904128014 35.6686334553077 139.74780934746065 33.382370307448326</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_c0a8b37c-86cd-4eb8-ac09-6c3a68ca5419">
									<gml:exterior>
										<gml:LinearRing gml:id="line_2150a109-453c-43a2-86da-6811a681cfd7">
											<gml:posList>35.668631888868546 139.7478085569517 33.486000373366295 35.6686334553077 139.74780934746065 33.382370307448326 35.6686334553077 139.74780934746065 32.117470099928795 35.668631888868546 139.7478085569517 33.486000373366295</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_ea4a348e-95f4-41c9-b3db-eb0d5f5f77ab">
									<gml:exterior>
										<gml:LinearRing gml:id="line_74658ef4-0aae-4c3d-9da5-f92006d88b8b">
											<gml:posList>35.668631888868546 139.7478085569517 33.486000373366295 35.6686334553077 139.74780934746065 32.117470099928795 35.668631888868546 139.7478085569517 31.327423408034264 35.668631888868546 139.7478085569517 33.486000373366295</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_cc5fa612-4818-4db5-900f-8bcd2efac76b">
									<gml:exterior>
										<gml:LinearRing gml:id="line_7f0734cd-591e-4976-a72a-cc9ee989231f">
											<gml:posList>35.668631888868546 139.7478085569517 31.327423408034264 35.6686334553077 139.74780934746065 32.117470099928795 35.668670915971305 139.74782825021657 31.327423408034264 35.668631888868546 139.7478085569517 31.327423408034264</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_de94d3a8-5484-4f79-921a-a94bbe295774">
									<gml:exterior>
										<gml:LinearRing gml:id="line_3a7dbef8-e250-4032-b650-b277aea8da5b">
											<gml:posList>35.668631888868546 139.7478085569517 31.327423408034264 35.6686334553077 139.74780934746065 30.322609260085045 35.668631888868546 139.7478085569517 30.426239326003014 35.668631888868546 139.7478085569517 31.327423408034264</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_3e90511c-db9f-45f3-bdb3-f55d9ccce3a3">
									<gml:exterior>
										<gml:LinearRing gml:id="line_935f5216-abda-4bf3-820a-e34fa3761fab">
											<gml:posList>35.6686334553077 139.74780934746065 30.322609260085045 35.668631888868546 139.7478085569517 31.327423408034264 35.668670915971305 139.74782825021657 31.327423408034264 35.6686334553077 139.74780934746065 30.322609260085045</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_fc02080a-ed3d-4b56-be3a-108eeaa2f1aa">
									<gml:exterior>
										<gml:LinearRing gml:id="line_17beca96-3f0a-4700-b5b4-8583afda5304">
											<gml:posList>35.668631888868546 139.7478085569517 30.426239326003014 35.6686334553077 139.74780934746065 30.322609260085045 35.6686334553077 139.74780934746065 29.057709052565514 35.668631888868546 139.7478085569517 30.426239326003014</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_2518cef0-2213-4e1a-8d2f-ae72bd838f92">
									<gml:exterior>
										<gml:LinearRing gml:id="line_191b0641-6645-482a-ad31-49182b156dbf">
											<gml:posList>35.668631888868546 139.7478085569517 30.426239326003014 35.6686334553077 139.74780934746065 29.057709052565514 35.668631888868546 139.7478085569517 28.267662360670982 35.668631888868546 139.7478085569517 30.426239326003014</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_f8122d54-0f98-47dc-b394-451c3dd84065">
									<gml:exterior>
										<gml:LinearRing gml:id="line_00c6a859-1761-4d75-9032-39c684af19f7">
											<gml:posList>35.668631888868546 139.7478085569517 28.267662360670982 35.6686334553077 139.74780934746065 27.262848212721764 35.668631888868546 139.7478085569517 27.3664706492452 35.668631888868546 139.7478085569517 28.267662360670982</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_8517faf5-e9f4-4ec6-bcd5-8f1128264458">
									<gml:exterior>
										<gml:LinearRing gml:id="line_e6e97e01-98fc-47ec-99ed-caaf9f6af1ab">
											<gml:posList>35.6686334553077 139.74780934746065 27.262848212721764 35.668631888868546 139.7478085569517 28.267662360670982 35.668670915971305 139.74782825021657 28.267662360670982 35.6686334553077 139.74780934746065 27.262848212721764</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_a2bc791c-670c-480d-bdc2-aaf3d8a59324">
									<gml:exterior>
										<gml:LinearRing gml:id="line_0e56c18d-37be-4f44-ac35-62eb58c43698">
											<gml:posList>35.6686334553077 139.74780934746065 33.382370307448326 35.6686747729746 139.74783019638366 35.550506904128014 35.668669637916636 139.7478276051942 33.382370307448326 35.6686334553077 139.74780934746065 33.382370307448326</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_3e73373b-f5c1-4d06-8bd7-507b04210a88">
									<gml:exterior>
										<gml:LinearRing gml:id="line_32fa3a63-c436-49f8-8e20-c59eb861b7f5">
											<gml:posList>35.668669637916636 139.7478276051942 33.382370307448326 35.6686747729746 139.74783019638366 35.550506904128014 35.668670915971305 139.74782825021657 33.486000373366295 35.668669637916636 139.7478276051942 33.382370307448326</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_d3260153-3b90-4a54-a4e8-3fcac24e16ec">
									<gml:exterior>
										<gml:LinearRing gml:id="line_c150168e-a98e-4fc1-885c-acbd947778f2">
											<gml:posList>35.668669637916636 139.7478276051942 33.382370307448326 35.668670915971305 139.74782825021657 33.486000373366295 35.668669637916636 139.7478276051942 32.117470099928795 35.668669637916636 139.7478276051942 33.382370307448326</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_dc25b658-8b7e-4444-a4e3-6ec871b0b08b">
									<gml:exterior>
										<gml:LinearRing gml:id="line_585501b1-08c4-459b-a4e2-7d3d91092774">
											<gml:posList>35.668669637916636 139.7478276051942 32.117470099928795 35.668670915971305 139.74782825021657 33.486000373366295 35.668670915971305 139.74782825021657 31.327423408034264 35.668669637916636 139.7478276051942 32.117470099928795</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_55aba0b2-4eaf-42ed-9124-7cf14c694924">
									<gml:exterior>
										<gml:LinearRing gml:id="line_446ad040-3ea9-44ea-a4fa-736fa3bb5a2e">
											<gml:posList>35.668669637916636 139.7478276051942 32.117470099928795 35.668670915971305 139.74782825021657 31.327423408034264 35.6686334553077 139.74780934746065 32.117470099928795 35.668669637916636 139.7478276051942 32.117470099928795</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_24e14c63-43bc-401c-a6f3-3668a35ebee1">
									<gml:exterior>
										<gml:LinearRing gml:id="line_08370e1f-3211-4bc5-a4fc-6adf3a515b40">
											<gml:posList>35.668670915971305 139.74782825021657 31.327423408034264 35.668669637916636 139.7478276051942 30.322609260085045 35.6686334553077 139.74780934746065 30.322609260085045 35.668670915971305 139.74782825021657 31.327423408034264</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_6259db80-dcaf-49bc-a2dd-f88357d16ff0">
									<gml:exterior>
										<gml:LinearRing gml:id="line_ef06a9ce-962e-4e3a-a56a-176995c3e72e">
											<gml:posList>35.668669637916636 139.7478276051942 30.322609260085045 35.668670915971305 139.74782825021657 31.327423408034264 35.668670915971305 139.74782825021657 30.426239326003014 35.668669637916636 139.7478276051942 30.322609260085045</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_628f1201-b88f-4140-b34e-feb9acbda43d">
									<gml:exterior>
										<gml:LinearRing gml:id="line_07d2c986-45f3-4f88-87d6-0b7e37b6e260">
											<gml:posList>35.668669637916636 139.7478276051942 30.322609260085045 35.668670915971305 139.74782825021657 30.426239326003014 35.668669637916636 139.7478276051942 29.057709052565514 35.668669637916636 139.7478276051942 30.322609260085045</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_69f23e22-b9fc-4aad-97ef-9a5e968c0901">
									<gml:exterior>
										<gml:LinearRing gml:id="line_af939a9e-3aa2-45b0-a9ba-06e51a97ef4d">
											<gml:posList>35.668669637916636 139.7478276051942 29.057709052565514 35.668670915971305 139.74782825021657 30.426239326003014 35.668670915971305 139.74782825021657 28.267662360670982 35.668669637916636 139.7478276051942 29.057709052565514</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_fa8a5647-e584-4964-8e56-4a85e0342364">
									<gml:exterior>
										<gml:LinearRing gml:id="line_99680a41-605a-497f-a2bd-edd285f70204">
											<gml:posList>35.668669637916636 139.7478276051942 29.057709052565514 35.668670915971305 139.74782825021657 28.267662360670982 35.6686334553077 139.74780934746065 29.057709052565514 35.668669637916636 139.7478276051942 29.057709052565514</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_6887e9c9-233f-4c7f-b943-5694f4a7aa18">
									<gml:exterior>
										<gml:LinearRing gml:id="line_2fe23e0b-375a-4924-bbf4-7414223aaa9d">
											<gml:posList>35.668670915971305 139.74782825021657 28.267662360670982 35.668669637916636 139.7478276051942 27.262848212721764 35.6686334553077 139.74780934746065 27.262848212721764 35.668670915971305 139.74782825021657 28.267662360670982</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_a344362d-5cf1-4dfe-abe1-ea8f49079de7">
									<gml:exterior>
										<gml:LinearRing gml:id="line_543412fb-0ae7-4825-be00-8b594966eb88">
											<gml:posList>35.668669637916636 139.7478276051942 27.262848212721764 35.668670915971305 139.74782825021657 28.267662360670982 35.668670915971305 139.74782825021657 27.3664706492452 35.668669637916636 139.7478276051942 27.262848212721764</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_97acd5a8-54dd-4122-9982-e8ddbdfed553">
									<gml:exterior>
										<gml:LinearRing gml:id="line_121b6987-58dd-4492-b499-244bb16c44fb">
											<gml:posList>35.668669637916636 139.7478276051942 27.262848212721764 35.668670915971305 139.74782825021657 27.3664706492452 35.668669637916636 139.7478276051942 25.997948005202232 35.668669637916636 139.7478276051942 27.262848212721764</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_38d88dd5-2c7c-423b-9fb2-88dd3c7678b0">
									<gml:exterior>
										<gml:LinearRing gml:id="line_61eaf857-4ab6-49e8-815b-4e3e68dc81f4">
											<gml:posList>35.668670915971305 139.74782825021657 33.486000373366295 35.6686747729746 139.74783019638366 35.550506904128014 35.6686747729746 139.74783019638366 33.486000373366295 35.668670915971305 139.74782825021657 33.486000373366295</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_1d652d60-2858-42b1-854c-883c12cbefc3">
									<gml:exterior>
										<gml:LinearRing gml:id="line_3c51301d-df01-44de-a16e-e7297028b869">
											<gml:posList>35.668628031727216 139.74780661061828 30.426239326003014 35.668631888868546 139.7478085569517 31.327423408034264 35.668631888868546 139.7478085569517 30.426239326003014 35.668628031727216 139.74780661061828 30.426239326003014</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_6dbb14e1-844e-4a96-a3f0-cce8e2d20b50">
									<gml:exterior>
										<gml:LinearRing gml:id="line_8019bc3c-3702-4a58-b4c0-150236a18f34">
											<gml:posList>35.668631888868546 139.7478085569517 31.327423408034264 35.668628031727216 139.74780661061828 30.426239326003014 35.668628031727216 139.74780661061828 31.327423408034264 35.668631888868546 139.7478085569517 31.327423408034264</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_3883d803-b922-413f-978a-f9fc9ab10f45">
									<gml:exterior>
										<gml:LinearRing gml:id="line_e8589d55-eea3-4a84-be40-3a30856f0b29">
											<gml:posList>35.668628031727216 139.74780661061828 27.3664706492452 35.668631888868546 139.7478085569517 28.267662360670982 35.668631888868546 139.7478085569517 27.3664706492452 35.668628031727216 139.74780661061828 27.3664706492452</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_6160d69f-4d6b-47a7-b9e8-cc69081b5a7b">
									<gml:exterior>
										<gml:LinearRing gml:id="line_149ab4be-6841-4bba-9797-2e4d151b46b4">
											<gml:posList>35.668631888868546 139.7478085569517 28.267662360670982 35.668628031727216 139.74780661061828 27.3664706492452 35.668628031727216 139.74780661061828 28.267662360670982 35.668631888868546 139.7478085569517 28.267662360670982</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_3f6a6a81-289a-4db2-a2cc-9ac9b9f1a1d3">
									<gml:exterior>
										<gml:LinearRing gml:id="line_7168de6c-378b-416e-9eef-fe9cd05fbe7e">
											<gml:posList>35.668631888868546 139.7478085569517 24.30670960188192 35.668628031727216 139.74780661061828 25.2079013133077 35.668631888868546 139.7478085569517 25.2079013133077 35.668631888868546 139.7478085569517 24.30670960188192</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_2236ec83-7363-4aa8-bb3a-679bf1e48244">
									<gml:exterior>
										<gml:LinearRing gml:id="line_bccf62bd-39a5-47e7-8fe6-f9d5423724b1">
											<gml:posList>35.668628031727216 139.74780661061828 25.2079013133077 35.668631888868546 139.7478085569517 24.30670960188192 35.668628031727216 139.74780661061828 24.30670960188192 35.668628031727216 139.74780661061828 25.2079013133077</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_09ba7114-e7e6-4828-acf5-cb41ffbe06f4">
									<gml:exterior>
										<gml:LinearRing gml:id="line_fb39da7f-aed3-4586-ba66-28e14a2e7128">
											<gml:posList>35.668631888868546 139.7478085569517 24.30670960188192 35.668631888868546 139.7478085569517 25.2079013133077 35.6686334553077 139.74780934746065 24.203087165358482 35.668631888868546 139.7478085569517 24.30670960188192</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_bdce7778-709f-4f4a-bc31-fbb6a4d51856">
									<gml:exterior>
										<gml:LinearRing gml:id="line_75d114df-3003-4c3a-bd89-746a40014522">
											<gml:posList>35.668628031727216 139.74780661061828 21.24694855451864 35.668628031727216 139.74780661061828 22.14813263654989 35.668631888868546 139.7478085569517 21.24694855451864 35.668628031727216 139.74780661061828 21.24694855451864</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_6c3dbfea-2b5e-4884-905e-728575dfb10e">
									<gml:exterior>
										<gml:LinearRing gml:id="line_00a9c9a6-ac83-409d-9edc-a4ffef3929fb">
											<gml:posList>35.668628031727216 139.74780661061828 22.14813263654989 35.668628031727216 139.74780661061828 21.24694855451864 35.66862094168115 139.74780303297814 9.79950745344442 35.668628031727216 139.74780661061828 22.14813263654989</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_246e25d8-3696-4686-b99b-1ace29368a60">
									<gml:exterior>
										<gml:LinearRing gml:id="line_b8a57e91-05ec-49e8-ab2e-bd0f824e0131">
											<gml:posList>35.668631888868546 139.7478085569517 21.24694855451864 35.668628031727216 139.74780661061828 22.14813263654989 35.668631888868546 139.7478085569517 22.14813263654989 35.668631888868546 139.7478085569517 21.24694855451864</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_5d09bc23-9972-4ecf-9e3d-d0e52887e4f3">
									<gml:exterior>
										<gml:LinearRing gml:id="line_50a547d3-6736-497d-998a-02e3b48f82dc">
											<gml:posList>35.668631888868546 139.7478085569517 21.24694855451864 35.668631888868546 139.7478085569517 22.14813263654989 35.6686334553077 139.74780934746065 21.1433261179952 35.668631888868546 139.7478085569517 21.24694855451864</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_fa778dea-032e-4949-b99d-21e51fbf2fca">
									<gml:exterior>
										<gml:LinearRing gml:id="line_49555ee3-184e-402f-9f8d-2f584813d480">
											<gml:posList>35.668670915971305 139.74782825021657 25.2079013133077 35.6686334553077 139.74780934746065 24.203087165358482 35.668631888868546 139.7478085569517 25.2079013133077 35.668670915971305 139.74782825021657 25.2079013133077</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_cfcff56d-369f-4af8-a0cb-708588307e1a">
									<gml:exterior>
										<gml:LinearRing gml:id="line_aefc09a4-720b-49fb-b67f-f08b0afdd36b">
											<gml:posList>35.6686334553077 139.74780934746065 24.203087165358482 35.668670915971305 139.74782825021657 25.2079013133077 35.668669637916636 139.7478276051942 24.203087165358482 35.6686334553077 139.74780934746065 24.203087165358482</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_77579675-f78f-46e1-8e46-f9cc738e8152">
									<gml:exterior>
										<gml:LinearRing gml:id="line_e9d8ea27-587b-46b0-839c-ab8e5e93b3ba">
											<gml:posList>35.668670915971305 139.74782825021657 22.14813263654989 35.668631888868546 139.7478085569517 22.14813263654989 35.6686334553077 139.74780934746065 22.93818695783895 35.668670915971305 139.74782825021657 22.14813263654989</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_8dc37050-30d5-4d30-99e8-9b7a21d4d9ec">
									<gml:exterior>
										<gml:LinearRing gml:id="line_59c9e866-faa3-4eff-b971-e2811569d8d1">
											<gml:posList>35.668631888868546 139.7478085569517 22.14813263654989 35.668670915971305 139.74782825021657 22.14813263654989 35.6686334553077 139.74780934746065 21.1433261179952 35.668631888868546 139.7478085569517 22.14813263654989</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_958a9119-13cf-4a7e-a096-560d0a15cefb">
									<gml:exterior>
										<gml:LinearRing gml:id="line_a5cff7b5-88fe-4001-b633-8b98c1157c1e">
											<gml:posList>35.668670915971305 139.74782825021657 30.426239326003014 35.668670915971305 139.74782825021657 31.327423408034264 35.6686747729746 139.74783019638366 30.426239326003014 35.668670915971305 139.74782825021657 30.426239326003014</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_79053e95-a963-473a-8e40-87eccf25e772">
									<gml:exterior>
										<gml:LinearRing gml:id="line_4e83a3cb-db34-43d0-8ccf-8de2074d3c1b">
											<gml:posList>35.6686747729746 139.74783019638366 30.426239326003014 35.668670915971305 139.74782825021657 31.327423408034264 35.6686747729746 139.74783019638366 31.327423408034264 35.6686747729746 139.74783019638366 30.426239326003014</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_ea86243a-dcd3-4a66-941f-e927f6d0a527">
									<gml:exterior>
										<gml:LinearRing gml:id="line_25718e1e-0a38-43ea-b9bd-66626a60e57c">
											<gml:posList>35.6686747729746 139.74783019638366 27.3664706492452 35.668670915971305 139.74782825021657 28.267662360670982 35.6686747729746 139.74783019638366 28.267662360670982 35.6686747729746 139.74783019638366 27.3664706492452</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_833a1b67-c4e6-4e40-96cc-00260801acb6">
									<gml:exterior>
										<gml:LinearRing gml:id="line_744413bf-893f-47ab-8cb2-6566e5e95093">
											<gml:posList>35.668670915971305 139.74782825021657 28.267662360670982 35.6686747729746 139.74783019638366 27.3664706492452 35.668670915971305 139.74782825021657 27.3664706492452 35.668670915971305 139.74782825021657 28.267662360670982</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_81872c99-b3d0-4f24-be67-21c9f7870018">
									<gml:exterior>
										<gml:LinearRing gml:id="line_9717a671-4272-4727-b5fe-b8714213c294">
											<gml:posList>35.668670915971305 139.74782825021657 24.30670960188192 35.6686747729746 139.74783019638366 25.2079013133077 35.6686747729746 139.74783019638366 24.30670960188192 35.668670915971305 139.74782825021657 24.30670960188192</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_b87a0197-8f56-4738-b0b1-cabf56a00a07">
									<gml:exterior>
										<gml:LinearRing gml:id="line_6029c603-9c1a-463e-af92-1a01338888f8">
											<gml:posList>35.6686747729746 139.74783019638366 25.2079013133077 35.668670915971305 139.74782825021657 24.30670960188192 35.668670915971305 139.74782825021657 25.2079013133077 35.6686747729746 139.74783019638366 25.2079013133077</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_d020818b-3171-4883-924b-246efc1b9810">
									<gml:exterior>
										<gml:LinearRing gml:id="line_05c0c14e-9b89-4733-ad40-5c226cc0d13c">
											<gml:posList>35.6686747729746 139.74783019638366 21.24694855451864 35.668670915971305 139.74782825021657 22.14813263654989 35.6686747729746 139.74783019638366 22.14813263654989 35.6686747729746 139.74783019638366 21.24694855451864</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_452b3bd4-58c9-44e2-b7cc-3b8da7d2f604">
									<gml:exterior>
										<gml:LinearRing gml:id="line_f96047dc-a498-455e-9e64-64306746ce86">
											<gml:posList>35.668670915971305 139.74782825021657 22.14813263654989 35.6686747729746 139.74783019638366 21.24694855451864 35.668670915971305 139.74782825021657 21.24694855451864 35.668670915971305 139.74782825021657 22.14813263654989</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_dd5fe82d-787e-4c2a-bc99-66afcc664578">
									<gml:exterior>
										<gml:LinearRing gml:id="line_a12a2174-e78b-464c-bab9-f9b004d58076">
											<gml:posList>35.668670915971305 139.74782825021657 18.187187507155357 35.668670915971305 139.74782825021657 19.088371589186607 35.6686747729746 139.74783019638366 18.187187507155357 35.668670915971305 139.74782825021657 18.187187507155357</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_05505ddb-1e77-4f2e-8fc8-54264272379a">
									<gml:exterior>
										<gml:LinearRing gml:id="line_64320a21-272f-4daf-bfad-e0e5d2c02cba">
											<gml:posList>35.668670915971305 139.74782825021657 19.088371589186607 35.668670915971305 139.74782825021657 18.187187507155357 35.668631888868546 139.7478085569517 19.088371589186607 35.668670915971305 139.74782825021657 19.088371589186607</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_d2b57f17-43a0-4da0-ac19-20bcfaead401">
									<gml:exterior>
										<gml:LinearRing gml:id="line_561fda0e-2783-4ce6-a9bb-2697160131dc">
											<gml:posList>35.6686747729746 139.74783019638366 18.187187507155357 35.668670915971305 139.74782825021657 19.088371589186607 35.6686747729746 139.74783019638366 19.088371589186607 35.6686747729746 139.74783019638366 18.187187507155357</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_6da32309-2ac0-40b9-b7bd-f20ab3262eed">
									<gml:exterior>
										<gml:LinearRing gml:id="line_c6e38284-52ec-4cb1-b4bb-c66cec3ee5d8">
											<gml:posList>35.668670915971305 139.74782825021657 15.127426459792076 35.668670915971305 139.74782825021657 16.028610541823326 35.6686747729746 139.74783019638366 15.127426459792076 35.668670915971305 139.74782825021657 15.127426459792076</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_51735ebd-d24e-4bba-9f20-b1db12559733">
									<gml:exterior>
										<gml:LinearRing gml:id="line_7e2b1149-fdb1-4946-9d95-bbdb28b99338">
											<gml:posList>35.668670915971305 139.74782825021657 16.028610541823326 35.668670915971305 139.74782825021657 15.127426459792076 35.668631888868546 139.7478085569517 19.088371589186607 35.668670915971305 139.74782825021657 16.028610541823326</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_85f16b80-05d7-4df4-b11d-10fe68814041">
									<gml:exterior>
										<gml:LinearRing gml:id="line_41a8da68-f91a-4e87-9fbc-34a20c04d2ac">
											<gml:posList>35.6686747729746 139.74783019638366 15.127426459792076 35.668670915971305 139.74782825021657 16.028610541823326 35.6686747729746 139.74783019638366 16.028610541823326 35.6686747729746 139.74783019638366 15.127426459792076</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_a1d8f2bf-0b17-4152-a9a1-b1398cff474c">
									<gml:exterior>
										<gml:LinearRing gml:id="line_5eaab667-f14d-41b2-99c5-090245d941be">
											<gml:posList>35.668670915971305 139.74782825021657 12.067657783034264 35.6686747729746 139.74783019638366 12.968849494460045 35.6686747729746 139.74783019638366 12.067657783034264 35.668670915971305 139.74782825021657 12.067657783034264</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_36241fc6-303b-43c8-a155-67c28d934fe1">
									<gml:exterior>
										<gml:LinearRing gml:id="line_50affe65-cb05-45c7-b570-f6de799899eb">
											<gml:posList>35.6686747729746 139.74783019638366 12.968849494460045 35.668670915971305 139.74782825021657 12.067657783034264 35.668670915971305 139.74782825021657 12.968849494460045 35.6686747729746 139.74783019638366 12.968849494460045</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_e3951c26-9bd2-4fcd-9ce7-e18dd9e37429">
									<gml:exterior>
										<gml:LinearRing gml:id="line_7749d169-3f39-40df-9462-06987be80550">
											<gml:posList>35.668628031727216 139.74780661061828 30.426239326003014 35.66862094168115 139.74780303297814 35.550506904128014 35.668628031727216 139.74780661061828 31.327423408034264 35.668628031727216 139.74780661061828 30.426239326003014</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_4a72a286-546e-4fc1-80dc-63984a291aea">
									<gml:exterior>
										<gml:LinearRing gml:id="line_40cfd22f-a304-4ecf-a317-f61e7da383d6">
											<gml:posList>35.66862094168115 139.74780303297814 35.550506904128014 35.668628031727216 139.74780661061828 30.426239326003014 35.668628031727216 139.74780661061828 28.267662360670982 35.66862094168115 139.74780303297814 35.550506904128014</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_7dc28179-2f53-4576-b05e-529c2d7c4329">
									<gml:exterior>
										<gml:LinearRing gml:id="line_419f8bd8-9bc2-46cd-86d2-b2256e37b1b9">
											<gml:posList>35.66862094168115 139.74780303297814 9.79950745344442 35.668628031727216 139.74780661061828 19.088371589186607 35.668631888868546 139.7478085569517 19.088371589186607 35.66862094168115 139.74780303297814 9.79950745344442</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_d0e09328-5d84-4417-a47b-b72149958560">
									<gml:exterior>
										<gml:LinearRing gml:id="line_c032ffce-3bcd-4e66-a956-891d2a356fa6">
											<gml:posList>35.668628031727216 139.74780661061828 19.088371589186607 35.66862094168115 139.74780303297814 9.79950745344442 35.668628031727216 139.74780661061828 21.24694855451864 35.668628031727216 139.74780661061828 19.088371589186607</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_28d36821-c607-432e-9065-eb27d448ba4b">
									<gml:exterior>
										<gml:LinearRing gml:id="line_c299cf93-15e1-4444-80e0-bb9bb4087f30">
											<gml:posList>35.66862094168115 139.74780303297814 9.79950745344442 35.668670915971305 139.74782825021657 9.909088447096764 35.6686747729746 139.74783019638366 9.79950745344442 35.66862094168115 139.74780303297814 9.79950745344442</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_637178c0-101d-4073-9af7-42ff57bafa7d">
									<gml:exterior>
										<gml:LinearRing gml:id="line_c1b3ee19-b76c-4632-b889-cd792fc8d3ba">
											<gml:posList>35.668670915971305 139.74782825021657 9.909088447096764 35.66862094168115 139.74780303297814 9.79950745344442 35.668670915971305 139.74782825021657 12.067657783034264 35.668670915971305 139.74782825021657 9.909088447096764</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_d2a9431e-c186-4151-96ba-2e8d6e23c1f6">
									<gml:exterior>
										<gml:LinearRing gml:id="line_398985f9-5fb0-46e0-bdf2-b836ab52b391">
											<gml:posList>35.66862094168115 139.74780303297814 35.550506904128014 35.668628031727216 139.74780661061828 27.3664706492452 35.668628031727216 139.74780661061828 25.2079013133077 35.66862094168115 139.74780303297814 35.550506904128014</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_72c77a7a-695d-4c04-bfc0-c520139502b5">
									<gml:exterior>
										<gml:LinearRing gml:id="line_26aeb22d-8301-42ce-b283-e3afdc61dc1c">
											<gml:posList>35.668628031727216 139.74780661061828 27.3664706492452 35.66862094168115 139.74780303297814 35.550506904128014 35.668628031727216 139.74780661061828 28.267662360670982 35.668628031727216 139.74780661061828 27.3664706492452</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_7eaf44a5-6cca-4b35-ad50-e6954e985293">
									<gml:exterior>
										<gml:LinearRing gml:id="line_f2d71b88-f7a4-4fb6-96b0-a0d299ccf255">
											<gml:posList>35.66862094168115 139.74780303297814 35.550506904128014 35.668628031727216 139.74780661061828 25.2079013133077 35.668628031727216 139.74780661061828 24.30670960188192 35.66862094168115 139.74780303297814 35.550506904128014</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_17795ea4-d90f-4965-b509-e1b623aea41d">
									<gml:exterior>
										<gml:LinearRing gml:id="line_ad8596fb-c95c-4f2f-8952-958e9c51831b">
											<gml:posList>35.66862094168115 139.74780303297814 35.550506904128014 35.668628031727216 139.74780661061828 24.30670960188192 35.668628031727216 139.74780661061828 22.14813263654989 35.66862094168115 139.74780303297814 35.550506904128014</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_4aac7d52-ec87-49ca-bb9b-2b8c25e65be4">
									<gml:exterior>
										<gml:LinearRing gml:id="line_05cad701-6e7a-4000-a81d-c503d288f850">
											<gml:posList>35.66862094168115 139.74780303297814 35.550506904128014 35.668628031727216 139.74780661061828 22.14813263654989 35.66862094168115 139.74780303297814 9.79950745344442 35.66862094168115 139.74780303297814 35.550506904128014</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_58a294ad-8160-41ae-bac2-965046e1dfc2">
									<gml:exterior>
										<gml:LinearRing gml:id="line_982e6ca0-724d-4385-b429-80299f995ce8">
											<gml:posList>35.668670915971305 139.74782825021657 12.067657783034264 35.66862094168115 139.74780303297814 9.79950745344442 35.668670915971305 139.74782825021657 12.968849494460045 35.668670915971305 139.74782825021657 12.067657783034264</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_b04b0d34-e95b-4f02-b2bb-995f547676ba">
									<gml:exterior>
										<gml:LinearRing gml:id="line_1967fe0a-4eca-40ac-a20f-4d41b3a24a80">
											<gml:posList>35.668670915971305 139.74782825021657 12.968849494460045 35.66862094168115 139.74780303297814 9.79950745344442 35.668670915971305 139.74782825021657 15.127426459792076 35.668670915971305 139.74782825021657 12.968849494460045</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_08957525-d336-4eb1-9868-bd00ab5a6859">
									<gml:exterior>
										<gml:LinearRing gml:id="line_ae0fa020-3b16-4d25-9812-2fe789f7f815">
											<gml:posList>35.6686334553077 139.74780934746065 19.87842591047567 35.668631888868546 139.7478085569517 19.088371589186607 35.668631888868546 139.7478085569517 21.24694855451864 35.6686334553077 139.74780934746065 19.87842591047567</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_ecf89da1-813c-47c0-82cf-3bb3a2b59f43">
									<gml:exterior>
										<gml:LinearRing gml:id="line_04daf52d-da21-493c-80fa-cac03babfdfb">
											<gml:posList>35.668631888868546 139.7478085569517 19.088371589186607 35.6686334553077 139.74780934746065 19.87842591047567 35.668670915971305 139.74782825021657 19.088371589186607 35.668631888868546 139.7478085569517 19.088371589186607</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_bd3bb072-fc5c-4bfa-a719-de2f852b005e">
									<gml:exterior>
										<gml:LinearRing gml:id="line_24b2c58b-4f78-4e2a-b1ca-ea8160b0ee58">
											<gml:posList>35.6686334553077 139.74780934746065 19.87842591047567 35.668631888868546 139.7478085569517 21.24694855451864 35.6686334553077 139.74780934746065 21.1433261179952 35.6686334553077 139.74780934746065 19.87842591047567</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_5960a201-e855-4fcf-80fd-8f24843a24c0">
									<gml:exterior>
										<gml:LinearRing gml:id="line_fc8a891d-25ca-4e1e-88c4-0f3ef3ec3101">
											<gml:posList>35.668631888868546 139.7478085569517 27.3664706492452 35.6686334553077 139.74780934746065 27.262848212721764 35.6686334553077 139.74780934746065 25.997948005202232 35.668631888868546 139.7478085569517 27.3664706492452</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_fb123214-88fa-4b23-a376-22cf706c9d63">
									<gml:exterior>
										<gml:LinearRing gml:id="line_7937a558-3c6a-4a26-9da3-548aea9e04cb">
											<gml:posList>35.668631888868546 139.7478085569517 27.3664706492452 35.6686334553077 139.74780934746065 25.997948005202232 35.668631888868546 139.7478085569517 25.2079013133077 35.668631888868546 139.7478085569517 27.3664706492452</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_32a74aaf-8655-4027-ac63-c67e6acbbf3a">
									<gml:exterior>
										<gml:LinearRing gml:id="line_2f15058e-46a1-46a5-b2ec-f4f4dd735bc9">
											<gml:posList>35.668631888868546 139.7478085569517 25.2079013133077 35.6686334553077 139.74780934746065 25.997948005202232 35.668670915971305 139.74782825021657 25.2079013133077 35.668631888868546 139.7478085569517 25.2079013133077</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_35a01d02-34d9-4f22-aafc-0c03d8c58968">
									<gml:exterior>
										<gml:LinearRing gml:id="line_58e85dcd-3e44-4a9e-95d3-b7b445abe368">
											<gml:posList>35.668631888868546 139.7478085569517 24.30670960188192 35.6686334553077 139.74780934746065 24.203087165358482 35.6686334553077 139.74780934746065 22.93818695783895 35.668631888868546 139.7478085569517 24.30670960188192</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_b7dd23c4-47d7-4fc3-8653-4c2313742643">
									<gml:exterior>
										<gml:LinearRing gml:id="line_0c925b81-b1c7-4d7b-bb0d-0fb6ba66833e">
											<gml:posList>35.668631888868546 139.7478085569517 24.30670960188192 35.6686334553077 139.74780934746065 22.93818695783895 35.668631888868546 139.7478085569517 22.14813263654989 35.668631888868546 139.7478085569517 24.30670960188192</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_8ca56963-1905-4aa5-a95a-cf20c6274c02">
									<gml:exterior>
										<gml:LinearRing gml:id="line_ca15cbab-7ede-4804-a707-26b5958894b9">
											<gml:posList>35.66862094168115 139.74780303297814 9.79950745344442 35.668631888868546 139.7478085569517 19.088371589186607 35.668670915971305 139.74782825021657 15.127426459792076 35.66862094168115 139.74780303297814 9.79950745344442</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_d21daa44-72d6-4f1c-88e8-90c3b0f021c7">
									<gml:exterior>
										<gml:LinearRing gml:id="line_ab8356fe-9bf5-4536-be56-565c79b7e98e">
											<gml:posList>35.668670915971305 139.74782825021657 16.028610541823326 35.668631888868546 139.7478085569517 19.088371589186607 35.668670915971305 139.74782825021657 18.187187507155357 35.668670915971305 139.74782825021657 16.028610541823326</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_43b703b9-7edb-4a8f-9aef-ce9a2f496f13">
									<gml:exterior>
										<gml:LinearRing gml:id="line_d0e0a0e6-ee41-47ca-be73-46c64093b63e">
											<gml:posList>35.668669637916636 139.7478276051942 24.203087165358482 35.668670915971305 139.74782825021657 25.2079013133077 35.668670915971305 139.74782825021657 24.30670960188192 35.668669637916636 139.7478276051942 24.203087165358482</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_7e4a6486-6ff2-46a9-826a-ee120c8c31b8">
									<gml:exterior>
										<gml:LinearRing gml:id="line_65d11049-b976-4ee8-b9ff-28e9e804e8f0">
											<gml:posList>35.668669637916636 139.7478276051942 24.203087165358482 35.668670915971305 139.74782825021657 24.30670960188192 35.668669637916636 139.7478276051942 22.93818695783895 35.668669637916636 139.7478276051942 24.203087165358482</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_ed7fb158-c600-4fd9-a210-1cbb00fce81f">
									<gml:exterior>
										<gml:LinearRing gml:id="line_fb73ecb3-dbab-4815-aa89-78b557b94172">
											<gml:posList>35.668670915971305 139.74782825021657 22.14813263654989 35.668669637916636 139.7478276051942 22.93818695783895 35.668670915971305 139.74782825021657 24.30670960188192 35.668670915971305 139.74782825021657 22.14813263654989</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_395619e7-dc0b-4f57-954a-5263d1891548">
									<gml:exterior>
										<gml:LinearRing gml:id="line_0f393bf1-ace4-4cb9-9d00-9d797d86be1d">
											<gml:posList>35.668669637916636 139.7478276051942 22.93818695783895 35.668670915971305 139.74782825021657 22.14813263654989 35.6686334553077 139.74780934746065 22.93818695783895 35.668669637916636 139.7478276051942 22.93818695783895</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_af3ff5b1-5562-4eb1-be07-fb0dfd153def">
									<gml:exterior>
										<gml:LinearRing gml:id="line_a6a19a83-e02f-441b-af32-1b1da78b1fed">
											<gml:posList>35.668669637916636 139.7478276051942 21.1433261179952 35.668670915971305 139.74782825021657 22.14813263654989 35.668670915971305 139.74782825021657 21.24694855451864 35.668669637916636 139.7478276051942 21.1433261179952</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_0fa7baff-7157-4e93-81a1-3de6c410b524">
									<gml:exterior>
										<gml:LinearRing gml:id="line_a4393aad-3d5b-4cc6-9903-2c54f40cf54a">
											<gml:posList>35.668670915971305 139.74782825021657 22.14813263654989 35.668669637916636 139.7478276051942 21.1433261179952 35.6686334553077 139.74780934746065 21.1433261179952 35.668670915971305 139.74782825021657 22.14813263654989</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_c7bda2fe-a60e-45f2-abfc-de250c3c3ade">
									<gml:exterior>
										<gml:LinearRing gml:id="line_111d1979-696d-4f9a-8d56-130f92ec4656">
											<gml:posList>35.668669637916636 139.7478276051942 21.1433261179952 35.668670915971305 139.74782825021657 21.24694855451864 35.668669637916636 139.7478276051942 19.87842591047567 35.668669637916636 139.7478276051942 21.1433261179952</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_3e57bf4b-0ef3-4ddc-a0e5-e35c5a11d4a9">
									<gml:exterior>
										<gml:LinearRing gml:id="line_295f5e6a-e5fb-40b5-b7f5-c18a0023a612">
											<gml:posList>35.668669637916636 139.7478276051942 19.87842591047567 35.668670915971305 139.74782825021657 21.24694855451864 35.668670915971305 139.74782825021657 19.088371589186607 35.668669637916636 139.7478276051942 19.87842591047567</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_2bec265f-94e9-4867-95cb-a7668a44c870">
									<gml:exterior>
										<gml:LinearRing gml:id="line_fecd5a06-d3e6-4b31-b51b-362aabe35f5a">
											<gml:posList>35.668670915971305 139.74782825021657 19.088371589186607 35.6686334553077 139.74780934746065 19.87842591047567 35.668669637916636 139.7478276051942 19.87842591047567 35.668670915971305 139.74782825021657 19.088371589186607</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_4d0ce2bb-4285-4cb1-81d7-14e36043ab6e">
									<gml:exterior>
										<gml:LinearRing gml:id="line_4044733a-e954-43a2-87e0-671e848d96db">
											<gml:posList>35.6686747729746 139.74783019638366 9.79950745344442 35.668670915971305 139.74782825021657 9.909088447096764 35.6686747729746 139.74783019638366 9.909088447096764 35.6686747729746 139.74783019638366 9.79950745344442</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_66ecea9c-e06b-40df-8c65-373aba659ed5">
									<gml:exterior>
										<gml:LinearRing gml:id="line_33909a8d-d2ac-4fd1-9c2d-d295e950162f">
											<gml:posList>35.668669637916636 139.7478276051942 25.997948005202232 35.668670915971305 139.74782825021657 27.3664706492452 35.668670915971305 139.74782825021657 25.2079013133077 35.668669637916636 139.7478276051942 25.997948005202232</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_2ac6f68b-0e6c-4838-911b-b8ceb1fe414f">
									<gml:exterior>
										<gml:LinearRing gml:id="line_fc8e9933-b451-4edc-a3e3-05d0d323283a">
											<gml:posList>35.668670915971305 139.74782825021657 28.267662360670982 35.668631888868546 139.7478085569517 28.267662360670982 35.6686334553077 139.74780934746065 29.057709052565514 35.668670915971305 139.74782825021657 28.267662360670982</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_74356478-ef41-4dfb-9189-eba6d8b91d05">
									<gml:exterior>
										<gml:LinearRing gml:id="line_990ac7fd-2cfe-43f9-b2f6-7a390e5db1fb">
											<gml:posList>35.668670915971305 139.74782825021657 25.2079013133077 35.6686334553077 139.74780934746065 25.997948005202232 35.668669637916636 139.7478276051942 25.997948005202232 35.668670915971305 139.74782825021657 25.2079013133077</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_5cd6e3bc-1fe4-4256-90a8-cf0aaf3eacd9">
									<gml:exterior>
										<gml:LinearRing gml:id="line_e76be254-c1d6-4ce8-a541-4a24a6092c94">
											<gml:posList>35.66862094168115 139.74780303297814 9.79950745344442 35.6686747729746 139.74783019638366 9.79950745344442 35.66862094168115 139.74780303297814 9.355507209303795 35.66862094168115 139.74780303297814 9.79950745344442</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_dad3dbd2-5883-4d38-9da2-57812bf05b5a">
									<gml:exterior>
										<gml:LinearRing gml:id="line_5e59c570-5334-4fe8-a02e-1f5645cad566">
											<gml:posList>35.66862094168115 139.74780303297814 9.355507209303795 35.6686747729746 139.74783019638366 9.79950745344442 35.6686747729746 139.74783019638366 9.355507209303795 35.66862094168115 139.74780303297814 9.355507209303795</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_04b99cc6-13a5-4c0e-9fe4-9ce72bd77492">
									<gml:exterior>
										<gml:LinearRing gml:id="line_35b284ba-7fd0-45d9-92de-7aa64c3f0365">
											<gml:posList>35.668644592228574 139.74781496713786 8.692711188795982 35.66862094168115 139.74780303297814 6.3942492747334825 35.66862094168115 139.74780303297814 9.355507209303795 35.668644592228574 139.74781496713786 8.692711188795982</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_23349ea1-87ea-4ba6-b349-997db3e9c534">
									<gml:exterior>
										<gml:LinearRing gml:id="line_e9de4dd2-e0ff-4301-9a3e-32299706b799">
											<gml:posList>35.66862094168115 139.74780303297814 6.3942492747334825 35.668644592228574 139.74781496713786 8.692711188795982 35.668644592228574 139.74781496713786 6.3942492747334825 35.66862094168115 139.74780303297814 6.3942492747334825</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_9cdccf9a-ffde-4237-b242-c57515d773aa">
									<gml:exterior>
										<gml:LinearRing gml:id="line_afa34c57-14c1-4f2a-b4d2-be0a85f95909">
											<gml:posList>35.66868381140286 139.74783475711982 9.355507209303795 35.66868272803529 139.7478342104908 8.692711188795982 35.6686747729746 139.74783019638366 9.355507209303795 35.66868381140286 139.74783475711982 9.355507209303795</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_3234a539-cb99-47d5-9820-ca1de5037c99">
									<gml:exterior>
										<gml:LinearRing gml:id="line_eed83133-ba1e-478c-8915-79bb9d3f24c0">
											<gml:posList>35.66868272803529 139.7478342104908 8.692711188795982 35.66868381140286 139.74783475711982 9.355507209303795 35.66868381140286 139.74783475711982 6.3942492747334825 35.66868272803529 139.7478342104908 8.692711188795982</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_21ff5128-eba5-486b-acfc-b5ca3295abd4">
									<gml:exterior>
										<gml:LinearRing gml:id="line_0f8ccbd6-524b-4201-a41e-fda5a7f8410e">
											<gml:posList>35.6686747729746 139.74783019638366 9.355507209303795 35.66868272803529 139.7478342104908 8.692711188795982 35.668674299121726 139.74782995738087 8.692711188795982 35.6686747729746 139.74783019638366 9.355507209303795</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_5d1e2fae-8639-4ed2-ae47-c29906c3da8f">
									<gml:exterior>
										<gml:LinearRing gml:id="line_db387504-8031-45f7-910d-9178de1089f9">
											<gml:posList>35.6686747729746 139.74783019638366 9.355507209303795 35.668674299121726 139.74782995738087 8.692711188795982 35.668669178785656 139.74782737359192 8.692711188795982 35.6686747729746 139.74783019638366 9.355507209303795</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_82c38696-cf54-4b79-b0c3-63cfac5226da">
									<gml:exterior>
										<gml:LinearRing gml:id="line_fa0f52e7-8f4c-4591-a3ab-fe6af0abd218">
											<gml:posList>35.6686747729746 139.74783019638366 9.355507209303795 35.668669178785656 139.74782737359192 8.692711188795982 35.668644592228574 139.74781496713786 8.692711188795982 35.6686747729746 139.74783019638366 9.355507209303795</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_47a47798-1d05-490c-a8f1-43dbf85e5c96">
									<gml:exterior>
										<gml:LinearRing gml:id="line_d9e4054e-3fad-4b5a-bfc7-394b6cea35c5">
											<gml:posList>35.668669178785656 139.74782737359192 8.692711188795982 35.668674299121726 139.74782995738087 8.692711188795982 35.668669178785656 139.74782737359192 6.3942492747334825 35.668669178785656 139.74782737359192 8.692711188795982</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_aa260000-6303-46ae-a3e9-b05995b4ff0c">
									<gml:exterior>
										<gml:LinearRing gml:id="line_0ff7a4b0-8a75-4bc4-9f10-89d1dbc16e47">
											<gml:posList>35.6686747729746 139.74783019638366 9.355507209303795 35.668644592228574 139.74781496713786 8.692711188795982 35.66862094168115 139.74780303297814 9.355507209303795 35.6686747729746 139.74783019638366 9.355507209303795</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_e4572c8f-f0ce-499e-a9b1-a7e8d830fb6d">
									<gml:exterior>
										<gml:LinearRing gml:id="line_883cb1f8-74e0-4ccf-82ad-c670c2c2599b">
											<gml:posList>35.668669178785656 139.74782737359192 6.3942492747334825 35.668674299121726 139.74782995738087 8.692711188795982 35.668674299121726 139.74782995738087 6.3942492747334825 35.668669178785656 139.74782737359192 6.3942492747334825</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_c3e3a58e-30e6-4aef-bbad-cebd8d335d5f">
									<gml:exterior>
										<gml:LinearRing gml:id="line_0a11cde1-74e1-43bd-8e87-127c22cf7881">
											<gml:posList>35.66868272803529 139.7478342104908 8.692711188795982 35.66868381140286 139.74783475711982 6.3942492747334825 35.66868272803529 139.7478342104908 6.3942492747334825 35.66868272803529 139.7478342104908 8.692711188795982</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_a5fd6138-18f4-4fdc-89df-ea49a5d6dad7">
									<gml:exterior>
										<gml:LinearRing gml:id="line_4cf55f97-ca3c-40a9-9f92-7eb5663ae351">
											<gml:posList>35.66868381140286 139.74783475711982 6.3942492747334825 35.66868381140286 139.74783475711982 9.355507209303795 35.66869214950836 139.7478389646508 6.3942492747334825 35.66868381140286 139.74783475711982 6.3942492747334825</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_699f4cce-959f-4f57-9e71-3789dfe93a43">
									<gml:exterior>
										<gml:LinearRing gml:id="line_29d6d44d-9c07-44fb-aeee-632413b00f24">
											<gml:posList>35.66869214950836 139.7478389646508 6.3942492747334825 35.66868381140286 139.74783475711982 9.355507209303795 35.66869214950836 139.7478389646508 9.355507209303795 35.66869214950836 139.7478389646508 6.3942492747334825</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
					<bldg:opening>
						<bldg:Door gml:id="dor_dd26221c-6257-47c4-b0de-7f2224345e3a">
							<bldg:lod3MultiSurface>
								<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_d87b21dc-02c8-4574-8dc4-7723c55eaf4e">
											<gml:exterior>
												<gml:LinearRing gml:id="line_ca4afce5-a233-4c72-8cbc-ed3e39502468">
													<gml:posList>35.668669178785656 139.74782737359192 6.3942492747334825 35.668644592228574 139.74781496713786 6.3942492747334825 35.668669178785656 139.74782737359192 8.692711188795982 35.668669178785656 139.74782737359192 6.3942492747334825</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_b6950fda-5e39-4ba6-872c-e20e55d54e1b">
											<gml:exterior>
												<gml:LinearRing gml:id="line_2c83a007-2bd3-4a77-b333-3c1670657823">
													<gml:posList>35.668669178785656 139.74782737359192 8.692711188795982 35.668644592228574 139.74781496713786 6.3942492747334825 35.668644592228574 139.74781496713786 8.692711188795982 35.668669178785656 139.74782737359192 8.692711188795982</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
								</gml:MultiSurface>
							</bldg:lod3MultiSurface>
						</bldg:Door>
					</bldg:opening>
					<bldg:opening>
						<bldg:Door gml:id="dor_01bad349-4508-4ccf-8ecf-9f93afd6bc39">
							<bldg:lod3MultiSurface>
								<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_a021b4f1-871c-440b-9624-eb391eb11d43">
											<gml:exterior>
												<gml:LinearRing gml:id="line_d289a6c6-7b7e-425f-abbc-480b585aef26">
													<gml:posList>35.668674299121726 139.74782995738087 8.692711188795982 35.66868272803529 139.7478342104908 8.692711188795982 35.668674299121726 139.74782995738087 6.3942492747334825 35.668674299121726 139.74782995738087 8.692711188795982</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_405b74f8-7391-4276-8ba1-acf95d00b0cb">
											<gml:exterior>
												<gml:LinearRing gml:id="line_9f92aeee-3a86-419a-93a7-b2629111f523">
													<gml:posList>35.668674299121726 139.74782995738087 6.3942492747334825 35.66868272803529 139.7478342104908 8.692711188795982 35.66868272803529 139.7478342104908 6.3942492747334825 35.668674299121726 139.74782995738087 6.3942492747334825</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
								</gml:MultiSurface>
							</bldg:lod3MultiSurface>
						</bldg:Door>
					</bldg:opening>
					<bldg:opening>
						<bldg:Window gml:id="wnd_7375f51a-d2a8-4e59-b007-774532f7789b">
							<bldg:lod3MultiSurface>
								<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_16fe32bc-9994-4ffb-a8e5-bb49834df5ac">
											<gml:exterior>
												<gml:LinearRing gml:id="line_00fbb170-060d-4518-9806-c881914dbad5">
													<gml:posList>35.668669637916636 139.7478276051942 30.322609260085045 35.668669637916636 139.7478276051942 29.057709052565514 35.6686334553077 139.74780934746065 30.322609260085045 35.668669637916636 139.7478276051942 30.322609260085045</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_16ce54b6-12a6-44b2-ab12-577f14da7bdc">
											<gml:exterior>
												<gml:LinearRing gml:id="line_024b4fe4-ee13-453d-afda-1788dfee62e8">
													<gml:posList>35.6686334553077 139.74780934746065 30.322609260085045 35.668669637916636 139.7478276051942 29.057709052565514 35.6686334553077 139.74780934746065 29.057709052565514 35.6686334553077 139.74780934746065 30.322609260085045</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
								</gml:MultiSurface>
							</bldg:lod3MultiSurface>
						</bldg:Window>
					</bldg:opening>
					<bldg:opening>
						<bldg:Window gml:id="wnd_ea2cc9ce-6b99-4306-abbb-81db61c8a95d">
							<bldg:lod3MultiSurface>
								<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_203ac0ea-9052-41b3-b848-ee9bdaa5f3f3">
											<gml:exterior>
												<gml:LinearRing gml:id="line_f90536f4-7cb3-4b68-a7ad-2d28f331eefc">
													<gml:posList>35.668669637916636 139.7478276051942 21.1433261179952 35.668669637916636 139.7478276051942 19.87842591047567 35.6686334553077 139.74780934746065 21.1433261179952 35.668669637916636 139.7478276051942 21.1433261179952</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_559ad748-7b79-4acb-95fd-45774b8089ce">
											<gml:exterior>
												<gml:LinearRing gml:id="line_e2bb6c8b-2323-4f5a-8abd-c77baa70de7a">
													<gml:posList>35.6686334553077 139.74780934746065 21.1433261179952 35.668669637916636 139.7478276051942 19.87842591047567 35.6686334553077 139.74780934746065 19.87842591047567 35.6686334553077 139.74780934746065 21.1433261179952</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
								</gml:MultiSurface>
							</bldg:lod3MultiSurface>
						</bldg:Window>
					</bldg:opening>
					<bldg:opening>
						<bldg:Window gml:id="wnd_a38f487e-5371-4b49-9aef-9fe61f34d181">
							<bldg:lod3MultiSurface>
								<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_c4d90bdb-b3b5-4ade-88dd-ad3ced5bc236">
											<gml:exterior>
												<gml:LinearRing gml:id="line_4767c8c5-9f37-4af2-8089-373d70db1a3f">
													<gml:posList>35.668669637916636 139.7478276051942 27.262848212721764 35.668669637916636 139.7478276051942 25.997948005202232 35.6686334553077 139.74780934746065 27.262848212721764 35.668669637916636 139.7478276051942 27.262848212721764</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_6774d021-4613-4767-8223-4efc303e4e72">
											<gml:exterior>
												<gml:LinearRing gml:id="line_6fe79b24-047a-4447-9563-8f2469d09c2a">
													<gml:posList>35.6686334553077 139.74780934746065 27.262848212721764 35.668669637916636 139.7478276051942 25.997948005202232 35.6686334553077 139.74780934746065 25.997948005202232 35.6686334553077 139.74780934746065 27.262848212721764</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
								</gml:MultiSurface>
							</bldg:lod3MultiSurface>
						</bldg:Window>
					</bldg:opening>
					<bldg:opening>
						<bldg:Window gml:id="wnd_4a91e58c-0a1c-43a2-93f1-1cff0d3eda8d">
							<bldg:lod3MultiSurface>
								<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_74afa576-9df1-4181-88fe-b5bb3b45cffe">
											<gml:exterior>
												<gml:LinearRing gml:id="line_c7f851c3-feac-4652-a56f-092a78dcc00a">
													<gml:posList>35.668669637916636 139.7478276051942 24.203087165358482 35.668669637916636 139.7478276051942 22.93818695783895 35.6686334553077 139.74780934746065 24.203087165358482 35.668669637916636 139.7478276051942 24.203087165358482</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_4f6e99b1-f436-4ab4-838e-fcaaf01ce35f">
											<gml:exterior>
												<gml:LinearRing gml:id="line_cc075da4-db56-497c-8636-70926a7fbad9">
													<gml:posList>35.6686334553077 139.74780934746065 24.203087165358482 35.668669637916636 139.7478276051942 22.93818695783895 35.6686334553077 139.74780934746065 22.93818695783895 35.6686334553077 139.74780934746065 24.203087165358482</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
								</gml:MultiSurface>
							</bldg:lod3MultiSurface>
						</bldg:Window>
					</bldg:opening>
					<bldg:opening>
						<bldg:Window gml:id="wnd_9c7be3d8-2f63-4192-b2be-b22dc2f5ee80">
							<bldg:lod3MultiSurface>
								<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_20be6003-484c-471d-80aa-67f0a3d8e597">
											<gml:exterior>
												<gml:LinearRing gml:id="line_2feaa796-8563-437d-bef0-c7c8d2c91ae7">
													<gml:posList>35.668669637916636 139.7478276051942 33.382370307448326 35.668669637916636 139.7478276051942 32.117470099928795 35.6686334553077 139.74780934746065 33.382370307448326 35.668669637916636 139.7478276051942 33.382370307448326</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_af17a49b-c13e-42a1-897e-5c6ebdefdb67">
											<gml:exterior>
												<gml:LinearRing gml:id="line_f46d7cbd-8ddc-4eaf-9948-30aeff472c46">
													<gml:posList>35.6686334553077 139.74780934746065 33.382370307448326 35.668669637916636 139.7478276051942 32.117470099928795 35.6686334553077 139.74780934746065 32.117470099928795 35.6686334553077 139.74780934746065 33.382370307448326</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
								</gml:MultiSurface>
							</bldg:lod3MultiSurface>
						</bldg:Window>
					</bldg:opening>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_42138b11-f77e-4cee-b85d-a251b08a3b58">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_e26b6cec-f205-446a-8a95-8dd0f504c697">
									<gml:exterior>
										<gml:LinearRing gml:id="line_b301b4a2-2e88-4a01-888e-9c0712c77fdd">
											<gml:posList>35.668690275854296 139.74782351812135 18.187187507155357 35.668690275854296 139.74782351812135 16.478615119460045 35.66868610967223 139.747835916983 18.187187507155357 35.668690275854296 139.74782351812135 18.187187507155357</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_ffc2b0aa-3fc1-4903-b13f-ccfd2bcd345f">
									<gml:exterior>
										<gml:LinearRing gml:id="line_0f3465a7-4b46-4fbc-9f03-366eaabb5e8c">
											<gml:posList>35.66868610967223 139.747835916983 18.187187507155357 35.668690275854296 139.74782351812135 16.478615119460045 35.66868610967223 139.747835916983 16.478615119460045 35.66868610967223 139.747835916983 18.187187507155357</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_7c25e53c-b7be-4191-bca8-5d85ca4c1fbf">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_6720e603-14cb-4b50-93c2-a102d8b56a8c">
									<gml:exterior>
										<gml:LinearRing gml:id="line_faa5efba-396e-49dc-9efb-1246223dc21a">
											<gml:posList>35.66865366644167 139.74795349557397 37.902504279616295 35.66867650520553 139.7479650200619 6.3942492747334825 35.66865366644167 139.74795349557397 6.3942492747334825 35.66865366644167 139.74795349557397 37.902504279616295</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_42a14d54-b9c4-4928-b76b-9c1621f4996b">
									<gml:exterior>
										<gml:LinearRing gml:id="line_4455b359-b77e-44bc-aabd-ad6bc6d95ad8">
											<gml:posList>35.66867650520553 139.7479650200619 6.3942492747334825 35.66865366644167 139.74795349557397 37.902504279616295 35.66867650520553 139.7479650200619 40.907394721510826 35.66867650520553 139.7479650200619 6.3942492747334825</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_78d4e32e-4ce7-4a96-8c1f-7af82b7fc91f">
									<gml:exterior>
										<gml:LinearRing gml:id="line_c1c0bebb-2f0a-439c-8a8f-0c307de66210">
											<gml:posList>35.66867650520553 139.7479650200619 40.907394721510826 35.66865366644167 139.74795349557397 37.902504279616295 35.66865114500591 139.74795222318627 40.907394721510826 35.66867650520553 139.7479650200619 40.907394721510826</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_377dba5c-c3d1-4780-a80e-9f09efbd1cbc">
									<gml:exterior>
										<gml:LinearRing gml:id="line_867a0dd2-1a44-4925-acf5-a1b0c5603934">
											<gml:posList>35.66865114500591 139.74795222318627 40.907394721510826 35.66865366644167 139.74795349557397 37.902504279616295 35.66865114500591 139.74795222318627 37.902504279616295 35.66865114500591 139.74795222318627 40.907394721510826</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_4db09040-3836-4628-8cc5-6f08b67089db">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_63a969de-84bf-4ea1-9bfe-415caa1af518">
									<gml:exterior>
										<gml:LinearRing gml:id="line_33abd381-654a-4687-b483-c835e8156a7f">
											<gml:posList>35.668575396406865 139.74792157470998 38.68550141096395 35.6685802824288 139.74792404026175 6.3942492747334825 35.66856545347873 139.74791655749243 6.3942492747334825 35.668575396406865 139.74792157470998 38.68550141096395</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_e5ba89db-57cc-4d73-a49f-41f2af331b82">
									<gml:exterior>
										<gml:LinearRing gml:id="line_1dbe4165-82f9-48fa-a3a9-935ba10e195c">
											<gml:posList>35.6685802824288 139.74792404026175 6.3942492747334825 35.668575396406865 139.74792157470998 38.68550141096395 35.6685802824288 139.74792404026175 38.68550141096395 35.6685802824288 139.74792404026175 6.3942492747334825</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_5278ea71-f249-4df7-87e5-8cef02ff9625">
									<gml:exterior>
										<gml:LinearRing gml:id="line_5f49719f-383b-4907-973a-d27d5724ff93">
											<gml:posList>35.668575396406865 139.74792157470998 38.68550141096395 35.66856545347873 139.74791655749243 6.3942492747334825 35.66856545347873 139.74791655749243 41.17650635481161 35.668575396406865 139.74792157470998 38.68550141096395</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_f4443571-71cc-4eed-82bc-a74574bd0351">
									<gml:exterior>
										<gml:LinearRing gml:id="line_816a67e4-0b3b-408e-9478-a930896c00a7">
											<gml:posList>35.668575396406865 139.74792157470998 38.68550141096395 35.66856545347873 139.74791655749243 41.17650635481161 35.668575396406865 139.74792157470998 41.17650635481161 35.668575396406865 139.74792157470998 38.68550141096395</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_c52f7d82-d5a7-422e-b67f-4a1605bcbc67">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_0e9d06d7-b4c6-4b75-bdf0-c6c4e05f92cf">
									<gml:exterior>
										<gml:LinearRing gml:id="line_aac604fc-a11b-41f2-b2ce-c79b0f609aeb">
											<gml:posList>35.66862642811532 139.74781138344156 25.997948005202232 35.668630285119036 139.74781332977528 25.997948005202232 35.66862642811532 139.74781138344156 25.2079013133077 35.66862642811532 139.74781138344156 25.997948005202232</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_c4a9fbfe-e82f-43d4-b05f-98e7feadf666">
									<gml:exterior>
										<gml:LinearRing gml:id="line_2f376002-e537-4dc9-9e6d-8586124329d3">
											<gml:posList>35.66862642811532 139.74781138344156 25.2079013133077 35.668630285119036 139.74781332977528 25.997948005202232 35.668630285119036 139.74781332977528 25.2079013133077 35.66862642811532 139.74781138344156 25.2079013133077</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_6bcfd1b6-f13c-4afd-a838-3f7f751ca255">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_7427aff6-5e7e-4466-bb2a-3db5a65994ef">
									<gml:exterior>
										<gml:LinearRing gml:id="line_8e80eb96-9e1b-4367-8731-fa161d242b4d">
											<gml:posList>35.668669312220906 139.74783302287355 29.057709052565514 35.66867316936178 139.74783496920924 29.057709052565514 35.668669312220906 139.74783302287355 28.267662360670982 35.668669312220906 139.74783302287355 29.057709052565514</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_6041a84e-d46b-4d29-83be-68e5305647fd">
									<gml:exterior>
										<gml:LinearRing gml:id="line_da9803bd-eccc-420b-be2e-5c0a36ed1441">
											<gml:posList>35.668669312220906 139.74783302287355 28.267662360670982 35.66867316936178 139.74783496920924 29.057709052565514 35.66867316936178 139.74783496920924 28.267662360670982 35.668669312220906 139.74783302287355 28.267662360670982</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_96df5f0b-5b9d-4b8f-90ac-a2de09457894">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_4ab14f34-3ac4-4802-8fb9-a46454530de8">
									<gml:exterior>
										<gml:LinearRing gml:id="line_c074d512-074c-4175-a5b2-fdb98d18490d">
											<gml:posList>35.6686752542573 139.74783043925513 23.199493720534264 35.6686747729746 139.74783019638366 24.30670960188192 35.66868610967223 139.747835916983 24.30670960188192 35.6686752542573 139.74783043925513 23.199493720534264</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_6401c391-45b1-46cd-9ff3-22dd6fc745b1">
									<gml:exterior>
										<gml:LinearRing gml:id="line_1cd5b24c-cab4-49ba-97b9-05069dd85aaa">
											<gml:posList>35.6686747729746 139.74783019638366 24.30670960188192 35.6686752542573 139.74783043925513 23.199493720534264 35.6686747729746 139.74783019638366 23.199493720534264 35.6686747729746 139.74783019638366 24.30670960188192</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_b89a3eff-22a0-44ad-a2f3-99fcaca42faa">
									<gml:exterior>
										<gml:LinearRing gml:id="line_722a94a2-addc-4451-832a-09da9e9bfc88">
											<gml:posList>35.6686752542573 139.74783043925513 23.199493720534264 35.66868610967223 139.747835916983 24.30670960188192 35.66868610967223 139.747835916983 22.598137214186607 35.6686752542573 139.74783043925513 23.199493720534264</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_f06f77b0-2a22-41c9-9275-3bad6b20b9d8">
									<gml:exterior>
										<gml:LinearRing gml:id="line_7f9ed5a1-b940-4984-8138-d7d37b107810">
											<gml:posList>35.6686752542573 139.74783043925513 23.199493720534264 35.66868610967223 139.747835916983 22.598137214186607 35.6686752542573 139.74783043925513 22.598137214186607 35.6686752542573 139.74783043925513 23.199493720534264</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_f3f4bc27-f60b-4980-992a-c5c933e8a9f6">
									<gml:exterior>
										<gml:LinearRing gml:id="line_9dfeecd5-01f2-44a3-b57b-8cb131ef889e">
											<gml:posList>35.6686752542573 139.74783043925513 23.199493720534264 35.6686752542573 139.74783043925513 22.598137214186607 35.6686747729746 139.74783019638366 23.199493720534264 35.6686752542573 139.74783043925513 23.199493720534264</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_bae12683-f790-419e-adf4-ca27e12e5e3e">
									<gml:exterior>
										<gml:LinearRing gml:id="line_ab465e1d-299d-47af-9c3d-3649a3cc3553">
											<gml:posList>35.6686747729746 139.74783019638366 23.199493720534264 35.6686752542573 139.74783043925513 22.598137214186607 35.6686747729746 139.74783019638366 22.598137214186607 35.6686747729746 139.74783019638366 23.199493720534264</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_38bccaec-40cf-4a47-a67c-9c4989420187">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_19b9b4da-a2fd-48f9-baad-53254b42e44a">
									<gml:exterior>
										<gml:LinearRing gml:id="line_eff408bf-1d4d-4131-b2d2-4e2df53d5df6">
											<gml:posList>35.66862642811532 139.74781138344156 33.382370307448326 35.668628031727216 139.74780661061828 33.486000373366295 35.66862642811532 139.74781138344156 33.486000373366295 35.66862642811532 139.74781138344156 33.382370307448326</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_974cfe5f-e78d-4e39-9e40-055f119878f2">
									<gml:exterior>
										<gml:LinearRing gml:id="line_a1a47c1b-94d6-4c0c-8f07-b12ac0797fee">
											<gml:posList>35.668628031727216 139.74780661061828 33.486000373366295 35.66862642811532 139.74781138344156 33.382370307448326 35.66862642811532 139.74781138344156 32.117470099928795 35.668628031727216 139.74780661061828 33.486000373366295</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_0dcb33a6-70d0-4259-a0ee-22b644dad15c">
									<gml:exterior>
										<gml:LinearRing gml:id="line_0767097d-837d-44d5-9a92-4db2a280acd2">
											<gml:posList>35.668628031727216 139.74780661061828 33.486000373366295 35.66862642811532 139.74781138344156 32.117470099928795 35.668628031727216 139.74780661061828 31.327423408034264 35.668628031727216 139.74780661061828 33.486000373366295</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_c0294477-ff7c-4751-b513-b136cc0efdef">
									<gml:exterior>
										<gml:LinearRing gml:id="line_ca5fd701-fb9d-49bd-8c35-250845f559d8">
											<gml:posList>35.668628031727216 139.74780661061828 31.327423408034264 35.66862642811532 139.74781138344156 32.117470099928795 35.66862642811532 139.74781138344156 31.327423408034264 35.668628031727216 139.74780661061828 31.327423408034264</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_c7fffc13-a32c-47d8-a4f9-e4d35360d878">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_7cdbba5a-75ef-455f-8b04-e9d3170ad264">
									<gml:exterior>
										<gml:LinearRing gml:id="line_e9a77863-2731-4879-8d02-a7f853547b5b">
											<gml:posList>35.6686747729746 139.74783019638366 16.028610541823326 35.66868477962785 139.74782074477844 16.478615119460045 35.66868477962785 139.74782074477844 15.127426459792076 35.6686747729746 139.74783019638366 16.028610541823326</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_0aa8a8ec-1836-4607-af45-e3579991ad5c">
									<gml:exterior>
										<gml:LinearRing gml:id="line_fb73b8df-75ff-4608-89e7-d027dd7d634e">
											<gml:posList>35.66868477962785 139.74782074477844 16.478615119460045 35.6686747729746 139.74783019638366 16.028610541823326 35.6686747729746 139.74783019638366 16.478615119460045 35.66868477962785 139.74782074477844 16.478615119460045</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_663354ea-6752-46d4-83bb-182b074569b7">
									<gml:exterior>
										<gml:LinearRing gml:id="line_7d87a4ad-e110-4294-8fc0-f4f3b687218f">
											<gml:posList>35.6686747729746 139.74783019638366 16.028610541823326 35.66868477962785 139.74782074477844 15.127426459792076 35.6686747729746 139.74783019638366 15.127426459792076 35.6686747729746 139.74783019638366 16.028610541823326</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_403e4af4-a9a3-4856-8cb4-68f83315e0ce">
									<gml:exterior>
										<gml:LinearRing gml:id="line_3a15f70d-2264-4043-80e2-cdc6fef9e924">
											<gml:posList>35.66868477962785 139.74782074477844 15.127426459792076 35.66868477962785 139.74782074477844 16.478615119460045 35.668686432971406 139.74781918309426 9.79950745344442 35.66868477962785 139.74782074477844 15.127426459792076</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_5c72a243-43ae-48d2-9e82-1ba9a4d0e777">
									<gml:exterior>
										<gml:LinearRing gml:id="line_11fe7856-e98d-4399-8971-71c38108c9cc">
											<gml:posList>35.668686432971406 139.74781918309426 9.79950745344442 35.66868477962785 139.74782074477844 16.478615119460045 35.66868477962785 139.74782074477844 17.07996399641317 35.668686432971406 139.74781918309426 9.79950745344442</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_ccc8bc78-a78a-4dfc-9b55-54b3dd95bf99">
									<gml:exterior>
										<gml:LinearRing gml:id="line_dbbb2591-4d91-495d-a163-2ed0b97923e5">
											<gml:posList>35.668686432971406 139.74781918309426 9.79950745344442 35.66868477962785 139.74782074477844 17.07996399641317 35.66868477962785 139.74782074477844 18.187187507155357 35.668686432971406 139.74781918309426 9.79950745344442</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_266ddcec-82ec-4b98-99a8-3a40c922d820">
									<gml:exterior>
										<gml:LinearRing gml:id="line_d6319ddf-689c-4741-a7f8-a51092c4b181">
											<gml:posList>35.668686432971406 139.74781918309426 9.79950745344442 35.66868477962785 139.74782074477844 18.187187507155357 35.66868477962785 139.74782074477844 19.538376166823326 35.668686432971406 139.74781918309426 9.79950745344442</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_9a329279-9f07-40d9-b2d9-0084c23e67e6">
									<gml:exterior>
										<gml:LinearRing gml:id="line_23d66177-c367-4ded-bec1-d3d8eedd122e">
											<gml:posList>35.668686432971406 139.74781918309426 9.79950745344442 35.66868477962785 139.74782074477844 19.538376166823326 35.66868477962785 139.74782074477844 20.139732673170982 35.668686432971406 139.74781918309426 9.79950745344442</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_84a89c0f-b667-4a77-8916-1135e829f135">
									<gml:exterior>
										<gml:LinearRing gml:id="line_d1caecf2-dc94-4a5d-aeab-8a2baf692168">
											<gml:posList>35.668686432971406 139.74781918309426 9.79950745344442 35.66868477962785 139.74782074477844 20.139732673170982 35.66868477962785 139.74782074477844 21.24694855451864 35.668686432971406 139.74781918309426 9.79950745344442</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_d48ea937-45f9-4883-b74c-7be372e8c73d">
									<gml:exterior>
										<gml:LinearRing gml:id="line_bf589782-6337-4ab9-8af4-6febc97426a1">
											<gml:posList>35.6686747729746 139.74783019638366 19.088371589186607 35.66868477962785 139.74782074477844 19.538376166823326 35.66868477962785 139.74782074477844 18.187187507155357 35.6686747729746 139.74783019638366 19.088371589186607</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_5b359b6a-3fd1-4a22-a1b3-e0b7e9f80842">
									<gml:exterior>
										<gml:LinearRing gml:id="line_a022ed6f-01b8-425f-af68-3fc2860b7198">
											<gml:posList>35.66868477962785 139.74782074477844 19.538376166823326 35.6686747729746 139.74783019638366 19.088371589186607 35.6686747729746 139.74783019638366 19.538376166823326 35.66868477962785 139.74782074477844 19.538376166823326</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_4d3becdc-cd2f-463f-bb07-9bd0c15e99a4">
									<gml:exterior>
										<gml:LinearRing gml:id="line_f43cc935-2b5a-46c9-97c5-6ba803645ca6">
											<gml:posList>35.6686747729746 139.74783019638366 19.088371589186607 35.66868477962785 139.74782074477844 18.187187507155357 35.6686747729746 139.74783019638366 18.187187507155357 35.6686747729746 139.74783019638366 19.088371589186607</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_f72b3a0c-70a2-498f-9702-cc94a93c92c5">
									<gml:exterior>
										<gml:LinearRing gml:id="line_2fd039cb-690b-4c41-89de-ef54351e8703">
											<gml:posList>35.6686747729746 139.74783019638366 31.327423408034264 35.66868477962785 139.74782074477844 31.77742035627645 35.66868477962785 139.74782074477844 30.426239326003014 35.6686747729746 139.74783019638366 31.327423408034264</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_e2ba9f34-1f41-47fd-94a1-fb6ac7a2ecda">
									<gml:exterior>
										<gml:LinearRing gml:id="line_d37c211d-dbfa-4598-a2f9-9403f5af974d">
											<gml:posList>35.66868477962785 139.74782074477844 31.77742035627645 35.6686747729746 139.74783019638366 31.327423408034264 35.6686747729746 139.74783019638366 31.77742035627645 35.66868477962785 139.74782074477844 31.77742035627645</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_d496d28d-b0f2-4da4-950c-d6c9992a2f52">
									<gml:exterior>
										<gml:LinearRing gml:id="line_8bfbc5d8-569d-426e-b236-d3bcec9ade04">
											<gml:posList>35.6686747729746 139.74783019638366 31.327423408034264 35.66868477962785 139.74782074477844 30.426239326003014 35.6686747729746 139.74783019638366 30.426239326003014 35.6686747729746 139.74783019638366 31.327423408034264</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_c7ba5d3d-1e18-4723-a247-51a25cbffcc8">
									<gml:exterior>
										<gml:LinearRing gml:id="line_ec734ebf-a4c0-43f2-939b-339d49d710af">
											<gml:posList>35.66868477962785 139.74782074477844 30.426239326003014 35.66868477962785 139.74782074477844 31.77742035627645 35.668686432971406 139.74781918309426 35.550506904128014 35.66868477962785 139.74782074477844 30.426239326003014</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_40570fe5-8aae-4f3e-bc2e-956199591392">
									<gml:exterior>
										<gml:LinearRing gml:id="line_dcd32cd6-7b25-4873-8453-df234d5209b8">
											<gml:posList>35.668686432971406 139.74781918309426 35.550506904128014 35.66868477962785 139.74782074477844 31.77742035627645 35.66868477962785 139.74782074477844 32.37877686262411 35.668686432971406 139.74781918309426 35.550506904128014</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_5f06b91d-02d7-495b-8176-de69b08f1241">
									<gml:exterior>
										<gml:LinearRing gml:id="line_456f77f0-ff4d-4c47-9b30-51f429a3a51a">
											<gml:posList>35.66868477962785 139.74782074477844 33.486000373366295 35.6686747729746 139.74783019638366 35.550506904128014 35.668686432971406 139.74781918309426 35.550506904128014 35.66868477962785 139.74782074477844 33.486000373366295</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_4e14be00-ebf1-4849-86c2-2e3a732e4912">
									<gml:exterior>
										<gml:LinearRing gml:id="line_18e06903-b69c-49b2-9425-2b4d3aa8d63c">
											<gml:posList>35.6686747729746 139.74783019638366 35.550506904128014 35.66868477962785 139.74782074477844 33.486000373366295 35.6686747729746 139.74783019638366 33.486000373366295 35.6686747729746 139.74783019638366 35.550506904128014</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_25e99696-97d9-47f6-b70f-11b1af122892">
									<gml:exterior>
										<gml:LinearRing gml:id="line_862c53f1-d285-49b7-a044-62d99e86878f">
											<gml:posList>35.66868477962785 139.74782074477844 33.486000373366295 35.668686432971406 139.74781918309426 35.550506904128014 35.66868477962785 139.74782074477844 32.37877686262411 35.66868477962785 139.74782074477844 33.486000373366295</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_097d5322-c6df-4030-8379-f7ada001ddf2">
									<gml:exterior>
										<gml:LinearRing gml:id="line_89150eb0-727c-440d-b41d-a7699991fa31">
											<gml:posList>35.66868477962785 139.74782074477844 30.426239326003014 35.668686432971406 139.74781918309426 35.550506904128014 35.66868477962785 139.74782074477844 29.319015815260826 35.66868477962785 139.74782074477844 30.426239326003014</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_a04c94b8-3714-47d9-828c-15316c28f367">
									<gml:exterior>
										<gml:LinearRing gml:id="line_d746bae3-23d2-406c-bf81-c79dbb501a61">
											<gml:posList>35.668686432971406 139.74781918309426 9.79950745344442 35.66868477962785 139.74782074477844 21.24694855451864 35.66868477962785 139.74782074477844 22.598137214186607 35.668686432971406 139.74781918309426 9.79950745344442</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_6d0e4ff9-1519-49b0-9ab2-5e3d7a4d27dc">
									<gml:exterior>
										<gml:LinearRing gml:id="line_38385acd-3469-4595-ba5a-49859903294b">
											<gml:posList>35.6686747729746 139.74783019638366 25.2079013133077 35.66868477962785 139.74782074477844 25.65789826154989 35.66868477962785 139.74782074477844 24.30670960188192 35.6686747729746 139.74783019638366 25.2079013133077</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_e47df084-a537-48b4-a8d1-d2e619061e50">
									<gml:exterior>
										<gml:LinearRing gml:id="line_ccaae166-d021-429c-88a5-d9cc7bd1a68d">
											<gml:posList>35.66868477962785 139.74782074477844 25.65789826154989 35.6686747729746 139.74783019638366 25.2079013133077 35.6686747729746 139.74783019638366 25.65789826154989 35.66868477962785 139.74782074477844 25.65789826154989</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_3fc572ba-543c-4c3f-a3c1-e9d907947c03">
									<gml:exterior>
										<gml:LinearRing gml:id="line_0e6d9650-d7f4-417e-b2ae-0b72e8ad57d5">
											<gml:posList>35.6686747729746 139.74783019638366 25.2079013133077 35.66868477962785 139.74782074477844 24.30670960188192 35.6686747729746 139.74783019638366 24.30670960188192 35.6686747729746 139.74783019638366 25.2079013133077</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_1e95e683-8256-4e4c-9c8a-fba6f16afbf0">
									<gml:exterior>
										<gml:LinearRing gml:id="line_b135ab77-13da-4684-9b2b-23059955cb03">
											<gml:posList>35.6686747729746 139.74783019638366 9.909088447096764 35.66868477962785 139.74782074477844 10.359085395338951 35.6686747729746 139.74783019638366 9.79950745344442 35.6686747729746 139.74783019638366 9.909088447096764</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_867b3ae6-02ad-498f-9b05-7c945e783ccd">
									<gml:exterior>
										<gml:LinearRing gml:id="line_ac83e45f-4eea-417f-9f8f-7a28362db93f">
											<gml:posList>35.66868477962785 139.74782074477844 10.359085395338951 35.6686747729746 139.74783019638366 9.909088447096764 35.6686747729746 139.74783019638366 10.359085395338951 35.66868477962785 139.74782074477844 10.359085395338951</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_abaeb6fa-3af5-4201-bf06-fe44abbfb9f9">
									<gml:exterior>
										<gml:LinearRing gml:id="line_4dff9377-dd50-4194-83bb-d365da416996">
											<gml:posList>35.6686747729746 139.74783019638366 9.79950745344442 35.66868477962785 139.74782074477844 10.359085395338951 35.668686432971406 139.74781918309426 9.79950745344442 35.6686747729746 139.74783019638366 9.79950745344442</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_68ef2673-07a4-4a1d-b4b5-894a2b548c3d">
									<gml:exterior>
										<gml:LinearRing gml:id="line_7c74e23e-7f8b-4cca-965e-21b7c189149a">
											<gml:posList>35.668686432971406 139.74781918309426 9.79950745344442 35.66868477962785 139.74782074477844 10.359085395338951 35.66868477962785 139.74782074477844 10.960441901686607 35.668686432971406 139.74781918309426 9.79950745344442</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_9e0b255d-d27e-40c6-8e64-92f2e091184c">
									<gml:exterior>
										<gml:LinearRing gml:id="line_abe7349f-a56d-4e41-be35-289dcce78a32">
											<gml:posList>35.668686432971406 139.74781918309426 9.79950745344442 35.66868477962785 139.74782074477844 10.960441901686607 35.66868477962785 139.74782074477844 12.067657783034264 35.668686432971406 139.74781918309426 9.79950745344442</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_3486c295-9a24-406b-aec3-b36b2a2498e5">
									<gml:exterior>
										<gml:LinearRing gml:id="line_489d7696-6977-4222-a1c7-97f9155f6013">
											<gml:posList>35.668686432971406 139.74781918309426 9.79950745344442 35.66868477962785 139.74782074477844 12.067657783034264 35.66868477962785 139.74782074477844 13.418846442702232 35.668686432971406 139.74781918309426 9.79950745344442</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_4dbf53bc-9395-41ad-b33e-d180743ce6e3">
									<gml:exterior>
										<gml:LinearRing gml:id="line_23584ca9-f6d1-42a2-a311-ff8a55d0068c">
											<gml:posList>35.668686432971406 139.74781918309426 9.79950745344442 35.66868477962785 139.74782074477844 13.418846442702232 35.66868477962785 139.74782074477844 14.020202949049889 35.668686432971406 139.74781918309426 9.79950745344442</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_df1657e0-5be1-4614-b4c8-07003020fb9e">
									<gml:exterior>
										<gml:LinearRing gml:id="line_be4a4590-3307-44f6-85ea-d313114c20f5">
											<gml:posList>35.668686432971406 139.74781918309426 9.79950745344442 35.66868477962785 139.74782074477844 14.020202949049889 35.66868477962785 139.74782074477844 15.127426459792076 35.668686432971406 139.74781918309426 9.79950745344442</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_b534bf81-111c-4ee8-9226-46af72364b5d">
									<gml:exterior>
										<gml:LinearRing gml:id="line_dfeeb60e-1e9b-4a5d-9406-cc49489cdc42">
											<gml:posList>35.66868477962785 139.74782074477844 13.418846442702232 35.6686747729746 139.74783019638366 12.968849494460045 35.6686747729746 139.74783019638366 13.418846442702232 35.66868477962785 139.74782074477844 13.418846442702232</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_945f5b8b-e50c-4c3a-aa28-92ce05c4c83a">
									<gml:exterior>
										<gml:LinearRing gml:id="line_78e6d28e-ef51-427d-8641-626aa2c3875c">
											<gml:posList>35.6686747729746 139.74783019638366 12.968849494460045 35.66868477962785 139.74782074477844 13.418846442702232 35.66868477962785 139.74782074477844 12.067657783034264 35.6686747729746 139.74783019638366 12.968849494460045</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_7ee095d5-fee2-45ed-a939-5d202bbc87a5">
									<gml:exterior>
										<gml:LinearRing gml:id="line_d0a36992-6570-4d5d-83e8-d027bd10374c">
											<gml:posList>35.6686747729746 139.74783019638366 12.968849494460045 35.66868477962785 139.74782074477844 12.067657783034264 35.6686747729746 139.74783019638366 12.067657783034264 35.6686747729746 139.74783019638366 12.968849494460045</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_35d3bbe8-11d6-43df-8e41-b58d999aa5a7">
									<gml:exterior>
										<gml:LinearRing gml:id="line_c90abfd7-bd8a-4f5b-a41b-01541faae279">
											<gml:posList>35.66868477962785 139.74782074477844 21.24694855451864 35.6686747729746 139.74783019638366 22.14813263654989 35.66868477962785 139.74782074477844 22.598137214186607 35.66868477962785 139.74782074477844 21.24694855451864</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_fc459366-769b-41c4-9103-f32d08ddd2fa">
									<gml:exterior>
										<gml:LinearRing gml:id="line_0f6ff9c5-f7b7-420a-9904-d7b24b393b9c">
											<gml:posList>35.6686747729746 139.74783019638366 22.14813263654989 35.66868477962785 139.74782074477844 21.24694855451864 35.6686747729746 139.74783019638366 21.24694855451864 35.6686747729746 139.74783019638366 22.14813263654989</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_0de5b79b-f988-4832-84a2-f494d5ed4100">
									<gml:exterior>
										<gml:LinearRing gml:id="line_ecc8b8d1-45e2-4c9d-9149-84af85c2206d">
											<gml:posList>35.668686432971406 139.74781918309426 35.550506904128014 35.66868477962785 139.74782074477844 22.598137214186607 35.66868477962785 139.74782074477844 23.199493720534264 35.668686432971406 139.74781918309426 35.550506904128014</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_d3043f56-e7ed-4fe6-b04a-4172dc1f11c2">
									<gml:exterior>
										<gml:LinearRing gml:id="line_302ed128-aa0a-42d5-841b-73410dc87543">
											<gml:posList>35.66868477962785 139.74782074477844 22.598137214186607 35.668686432971406 139.74781918309426 35.550506904128014 35.668686432971406 139.74781918309426 9.79950745344442 35.66868477962785 139.74782074477844 22.598137214186607</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_549eb043-5415-4222-a03f-79b7ba639c3b">
									<gml:exterior>
										<gml:LinearRing gml:id="line_6560eac6-837c-4985-a0eb-6a2f3fe9b615">
											<gml:posList>35.668686432971406 139.74781918309426 35.550506904128014 35.66868477962785 139.74782074477844 23.199493720534264 35.66868477962785 139.74782074477844 24.30670960188192 35.668686432971406 139.74781918309426 35.550506904128014</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_cf9a0f80-66a1-4bf6-9a16-8779789b5095">
									<gml:exterior>
										<gml:LinearRing gml:id="line_660ea3ef-7948-45d1-ac3d-c9b9b2ebce7b">
											<gml:posList>35.668686432971406 139.74781918309426 35.550506904128014 35.66868477962785 139.74782074477844 24.30670960188192 35.66868477962785 139.74782074477844 25.65789826154989 35.668686432971406 139.74781918309426 35.550506904128014</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_cbf62b1f-d7e2-49a7-8841-3620d95bd526">
									<gml:exterior>
										<gml:LinearRing gml:id="line_03a0a3c0-01c5-4918-8e76-b277a4fe6e24">
											<gml:posList>35.668686432971406 139.74781918309426 35.550506904128014 35.66868477962785 139.74782074477844 25.65789826154989 35.66868477962785 139.74782074477844 26.259254767897545 35.668686432971406 139.74781918309426 35.550506904128014</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_cad382a8-c44c-4a03-9c59-826b36c0e2bd">
									<gml:exterior>
										<gml:LinearRing gml:id="line_0bc195d3-d6d7-4b11-b024-8f3e4415f29a">
											<gml:posList>35.668686432971406 139.74781918309426 35.550506904128014 35.66868477962785 139.74782074477844 26.259254767897545 35.66868477962785 139.74782074477844 27.3664706492452 35.668686432971406 139.74781918309426 35.550506904128014</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_02bf2e75-eec3-458c-8488-65af7735f086">
									<gml:exterior>
										<gml:LinearRing gml:id="line_bac2bd28-1a13-43e3-b53c-247fbdba55ec">
											<gml:posList>35.668686432971406 139.74781918309426 35.550506904128014 35.66868477962785 139.74782074477844 27.3664706492452 35.66868477962785 139.74782074477844 28.71765930891317 35.668686432971406 139.74781918309426 35.550506904128014</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_3641a89f-7a20-47ee-8a27-d7b03f878156">
									<gml:exterior>
										<gml:LinearRing gml:id="line_2d3729cc-0680-473f-b101-624c020ebbde">
											<gml:posList>35.668686432971406 139.74781918309426 35.550506904128014 35.66868477962785 139.74782074477844 28.71765930891317 35.66868477962785 139.74782074477844 29.319015815260826 35.668686432971406 139.74781918309426 35.550506904128014</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_bd2a5007-1d84-43c1-90c6-a59de8700c75">
									<gml:exterior>
										<gml:LinearRing gml:id="line_b2fd71d0-139f-49d8-8439-d47bc62b6b3e">
											<gml:posList>35.6686747729746 139.74783019638366 28.267662360670982 35.66868477962785 139.74782074477844 28.71765930891317 35.66868477962785 139.74782074477844 27.3664706492452 35.6686747729746 139.74783019638366 28.267662360670982</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_4f8710e7-148e-47c6-8dcc-b5d4e6d6bbba">
									<gml:exterior>
										<gml:LinearRing gml:id="line_ea0aef36-a927-429d-82b0-c6428f1dd572">
											<gml:posList>35.66868477962785 139.74782074477844 28.71765930891317 35.6686747729746 139.74783019638366 28.267662360670982 35.6686747729746 139.74783019638366 28.71765930891317 35.66868477962785 139.74782074477844 28.71765930891317</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_94011616-be56-4e5f-baf2-b14412482c03">
									<gml:exterior>
										<gml:LinearRing gml:id="line_da329768-292e-48bf-a0ba-0920c375c87c">
											<gml:posList>35.6686747729746 139.74783019638366 28.267662360670982 35.66868477962785 139.74782074477844 27.3664706492452 35.6686747729746 139.74783019638366 27.3664706492452 35.6686747729746 139.74783019638366 28.267662360670982</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_1e81d89b-47fa-4363-8996-841d030a4308">
									<gml:exterior>
										<gml:LinearRing gml:id="line_31c94c86-cf72-4777-9147-d1920b26ce5c">
											<gml:posList>35.66868477962785 139.74782074477844 22.598137214186607 35.6686747729746 139.74783019638366 22.14813263654989 35.6686747729746 139.74783019638366 22.598137214186607 35.66868477962785 139.74782074477844 22.598137214186607</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_7e5dc3c2-ce7a-42d4-8875-f98dffdde870">
									<gml:exterior>
										<gml:LinearRing gml:id="line_8bce115a-33e1-43a9-b976-0866f7deb9ee">
											<gml:posList>35.6686747729746 139.74783019638366 9.79950745344442 35.668686432971406 139.74781918309426 9.79950745344442 35.6686747729746 139.74783019638366 9.355507209303795 35.6686747729746 139.74783019638366 9.79950745344442</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_1d05a1a7-bfda-4189-85c6-1e319eee8779">
									<gml:exterior>
										<gml:LinearRing gml:id="line_6559661b-7e07-4d6c-a842-be24220a0e92">
											<gml:posList>35.6686747729746 139.74783019638366 9.355507209303795 35.668686432971406 139.74781918309426 9.79950745344442 35.668686432971406 139.74781918309426 9.355507209303795 35.6686747729746 139.74783019638366 9.355507209303795</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_0fbfbf74-3071-49a8-9fea-8582382fe03f">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_7a7aea22-368e-48bc-a787-83f029207ed9">
									<gml:exterior>
										<gml:LinearRing gml:id="line_63d0de96-45a2-42ed-b798-87b955db2060">
											<gml:posList>35.66868866588641 139.74782030965406 10.597503974440514 35.668686432971406 139.74781918309426 35.550506904128014 35.6686970039924 139.74782451718383 35.550506904128014 35.66868866588641 139.74782030965406 10.597503974440514</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_ac814b3f-1905-41db-95eb-1b3151de6dd3">
									<gml:exterior>
										<gml:LinearRing gml:id="line_69872233-5dfe-4d9e-a6f2-e6c0f832c0e4">
											<gml:posList>35.668686432971406 139.74781918309426 35.550506904128014 35.66868866588641 139.74782030965406 10.597503974440514 35.668686432971406 139.74781918309426 9.79950745344442 35.668686432971406 139.74781918309426 35.550506904128014</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_6669678b-d455-476f-ad8a-615227590fff">
									<gml:exterior>
										<gml:LinearRing gml:id="line_108321db-62e8-4afb-b998-e10f2a133c8d">
											<gml:posList>35.668686432971406 139.74781918309426 9.79950745344442 35.66868866588641 139.74782030965406 10.597503974440514 35.66868866588641 139.74782030965406 9.355507209303795 35.668686432971406 139.74781918309426 9.79950745344442</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_a0c96f8c-a058-42b5-987a-39e35d4c6ca1">
									<gml:exterior>
										<gml:LinearRing gml:id="line_6bbcfccc-2e20-40d9-be03-ce5dc92f91c8">
											<gml:posList>35.66868866588641 139.74782030965406 10.597503974440514 35.6686970039924 139.74782451718383 35.550506904128014 35.6686970039924 139.74782451718383 10.597503974440514 35.66868866588641 139.74782030965406 10.597503974440514</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_1b5ddd9f-e4ce-4c4c-807b-7d25197f4985">
									<gml:exterior>
										<gml:LinearRing gml:id="line_4c114439-90ed-49c2-b65e-42b66386635a">
											<gml:posList>35.668686432971406 139.74781918309426 9.79950745344442 35.66868866588641 139.74782030965406 9.355507209303795 35.668686432971406 139.74781918309426 9.355507209303795 35.668686432971406 139.74781918309426 9.79950745344442</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_979a9feb-6cc7-40b9-a133-0ee556155994">
									<gml:exterior>
										<gml:LinearRing gml:id="line_8e1a039f-fbea-46a5-9a54-f4a110a79495">
											<gml:posList>35.66868866588641 139.74782030965406 10.597503974440514 35.6686970039924 139.74782451718383 10.597503974440514 35.6686970039924 139.74782451718383 9.355507209303795 35.66868866588641 139.74782030965406 10.597503974440514</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_af39f1d8-2fbd-40ee-be2a-0d2abb383407">
									<gml:exterior>
										<gml:LinearRing gml:id="line_1af48657-762f-4fbb-96da-b5dcc7028a7a">
											<gml:posList>35.66868866588641 139.74782030965406 10.597503974440514 35.6686970039924 139.74782451718383 9.355507209303795 35.66868866588641 139.74782030965406 9.355507209303795 35.66868866588641 139.74782030965406 10.597503974440514</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_89e2b011-ce0d-4563-b3ab-feeb34ab50fc">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_8fe5a4ac-1dc2-4c2f-ad49-5043813ba338">
									<gml:exterior>
										<gml:LinearRing gml:id="line_f82fde74-195c-4d82-8d79-30dac919e11e">
											<gml:posList>35.66868526091045 139.74782098748136 23.199493720534264 35.668690275854296 139.74782351812135 22.598137214186607 35.668690275854296 139.74782351812135 24.30670960188192 35.66868526091045 139.74782098748136 23.199493720534264</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_04542782-5e39-413e-bdee-16fe621fafcc">
									<gml:exterior>
										<gml:LinearRing gml:id="line_6d5bcf67-40b4-4934-a54e-6a16491f3012">
											<gml:posList>35.668690275854296 139.74782351812135 22.598137214186607 35.66868526091045 139.74782098748136 23.199493720534264 35.66868526091045 139.74782098748136 22.598137214186607 35.668690275854296 139.74782351812135 22.598137214186607</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_ed266021-ef0b-4ca7-b774-b949cc0f684f">
									<gml:exterior>
										<gml:LinearRing gml:id="line_1ce37294-c499-478e-9a21-b2d55be7ef09">
											<gml:posList>35.66868526091045 139.74782098748136 23.199493720534264 35.668690275854296 139.74782351812135 24.30670960188192 35.66868477962785 139.74782074477844 24.30670960188192 35.66868526091045 139.74782098748136 23.199493720534264</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_3dfa1669-af54-472c-9ba1-4f218ad93045">
									<gml:exterior>
										<gml:LinearRing gml:id="line_48ab1843-53ae-43fd-a128-40a2c2bb487c">
											<gml:posList>35.66868526091045 139.74782098748136 23.199493720534264 35.66868477962785 139.74782074477844 24.30670960188192 35.66868477962785 139.74782074477844 23.199493720534264 35.66868526091045 139.74782098748136 23.199493720534264</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_5aa9bc67-eca4-4111-8597-5144746b85a0">
									<gml:exterior>
										<gml:LinearRing gml:id="line_60f4fcf2-8bfa-42b4-8278-0b933a4ffb9e">
											<gml:posList>35.66868526091045 139.74782098748136 23.199493720534264 35.66868477962785 139.74782074477844 23.199493720534264 35.66868526091045 139.74782098748136 22.598137214186607 35.66868526091045 139.74782098748136 23.199493720534264</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_959c5ffc-e1b5-479e-96f7-718007d22d0c">
									<gml:exterior>
										<gml:LinearRing gml:id="line_598f3edc-12ac-4f50-a8e9-a4b11b6c84ba">
											<gml:posList>35.66868526091045 139.74782098748136 22.598137214186607 35.66868477962785 139.74782074477844 23.199493720534264 35.66868477962785 139.74782074477844 22.598137214186607 35.66868526091045 139.74782098748136 22.598137214186607</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_770f8766-499d-4d17-973f-5d94868f2d18">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_cc2f1aaa-ce7b-4db4-8ae8-483f154af411">
									<gml:exterior>
										<gml:LinearRing gml:id="line_6235465b-3b3f-4de3-b9f5-b8d49c46f4ed">
											<gml:posList>35.668690275854296 139.74782351812135 21.24694855451864 35.668690275854296 139.74782351812135 19.538376166823326 35.66868610967223 139.747835916983 21.24694855451864 35.668690275854296 139.74782351812135 21.24694855451864</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_eb072629-baf9-436e-861a-43714a5c7074">
									<gml:exterior>
										<gml:LinearRing gml:id="line_2e8db9a7-1f8c-4629-b95c-7a80f5e4ff44">
											<gml:posList>35.66868610967223 139.747835916983 21.24694855451864 35.668690275854296 139.74782351812135 19.538376166823326 35.66868610967223 139.747835916983 19.538376166823326 35.66868610967223 139.747835916983 21.24694855451864</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_6ed13835-27aa-4e86-a28b-1bb9dbeabb6f">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_92349b74-9bb1-4364-a1ef-d6232cbe0a32">
									<gml:exterior>
										<gml:LinearRing gml:id="line_e0d5402a-b9ef-4cc1-9c1d-30d19e56193f">
											<gml:posList>35.66851272301735 139.74807871985874 8.685997321608482 35.668515012063814 139.74807190738593 6.3942492747334825 35.668515012063814 139.74807190738593 8.85669739485067 35.66851272301735 139.74807871985874 8.685997321608482</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_65ff7a07-3940-4303-955d-7f3c155f26c3">
									<gml:exterior>
										<gml:LinearRing gml:id="line_8cc868df-189d-4451-8f27-3507b5c8a1fb">
											<gml:posList>35.668515012063814 139.74807190738593 6.3942492747334825 35.66851272301735 139.74807871985874 8.685997321608482 35.6685122320758 139.74808018068603 6.3942492747334825 35.668515012063814 139.74807190738593 6.3942492747334825</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_ed3a0210-4309-49a5-9f49-47d4874f3bd5">
									<gml:exterior>
										<gml:LinearRing gml:id="line_62402ea7-cebc-41ad-aff5-0b9b9482201d">
											<gml:posList>35.66851272301735 139.74807871985874 8.685997321608482 35.668515012063814 139.74807190738593 8.85669739485067 35.668513862873986 139.7480753272798 8.85669739485067 35.66851272301735 139.74807871985874 8.685997321608482</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_eb1f5ab6-9dcf-4092-8033-428d2cd8d868">
									<gml:exterior>
										<gml:LinearRing gml:id="line_8b51766c-2c2f-43e8-be4e-87f938a19cc8">
											<gml:posList>35.66851272301735 139.74807871985874 8.685997321608482 35.668513862873986 139.7480753272798 8.85669739485067 35.66851310608031 139.74807757938854 9.23169739485067 35.66851272301735 139.74807871985874 8.685997321608482</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_e09175c4-0a4d-4b59-8efc-94b40e3538bf">
									<gml:exterior>
										<gml:LinearRing gml:id="line_3d2c6fb8-bf63-45ce-90aa-37cc15c250de">
											<gml:posList>35.66851272301735 139.74807871985874 8.685997321608482 35.66851310608031 139.74807757938854 9.23169739485067 35.66851272301735 139.74807871985874 9.23169739485067 35.66851272301735 139.74807871985874 8.685997321608482</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_7dc7c2a4-ab41-4a56-a801-8f527eea06e9">
									<gml:exterior>
										<gml:LinearRing gml:id="line_5109bda8-a947-45f4-a25a-bc8129ce305a">
											<gml:posList>35.6685122320758 139.74808018068603 6.3942492747334825 35.668512412421634 139.748079644004 8.685997321608482 35.6685122320758 139.74808018068603 9.23169739485067 35.6685122320758 139.74808018068603 6.3942492747334825</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_30542a29-8cb8-4922-bb98-1988bb903569">
									<gml:exterior>
										<gml:LinearRing gml:id="line_b41c46e6-59a6-4180-a909-fdc9a515cf8f">
											<gml:posList>35.668512412421634 139.748079644004 8.685997321608482 35.6685122320758 139.74808018068603 6.3942492747334825 35.66851272301735 139.74807871985874 8.685997321608482 35.668512412421634 139.748079644004 8.685997321608482</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_dbca2628-8714-4855-8639-8b4b670f2162">
									<gml:exterior>
										<gml:LinearRing gml:id="line_9a85a123-4159-4f66-9a3b-f93b863dbf77">
											<gml:posList>35.6685122320758 139.74808018068603 9.23169739485067 35.668512412421634 139.748079644004 8.685997321608482 35.668512412421634 139.748079644004 9.23169739485067 35.6685122320758 139.74808018068603 9.23169739485067</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_be53fe9b-5b34-4289-b07d-b6f516997d19">
									<gml:exterior>
										<gml:LinearRing gml:id="line_febf60d2-2023-4939-a7fb-f3749a42ef9e">
											<gml:posList>35.66851272301735 139.74807871985874 8.685997321608482 35.66851272301735 139.74807871985874 9.23169739485067 35.668512412421634 139.748079644004 8.685997321608482 35.66851272301735 139.74807871985874 8.685997321608482</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_3b7502e4-19aa-460b-806a-2634234ae5e5">
									<gml:exterior>
										<gml:LinearRing gml:id="line_893cfe56-cc51-4282-8ee5-685afb45601e">
											<gml:posList>35.668512412421634 139.748079644004 8.685997321608482 35.66851272301735 139.74807871985874 9.23169739485067 35.668512412421634 139.748079644004 9.23169739485067 35.668512412421634 139.748079644004 8.685997321608482</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_eac01a7e-6ebb-41e4-bf0c-1ea0497229b8">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_d4fcceba-e865-4d73-9cdc-78a3ab36c082">
									<gml:exterior>
										<gml:LinearRing gml:id="line_599106e0-d7d5-4abd-8608-218f96eea72b">
											<gml:posList>35.668669312220906 139.74783302287355 29.057709052565514 35.668670915971305 139.74782825021657 28.267662360670982 35.668670915971305 139.74782825021657 30.426239326003014 35.668669312220906 139.74783302287355 29.057709052565514</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_7fe04b28-1621-4245-b256-c17e560f7399">
									<gml:exterior>
										<gml:LinearRing gml:id="line_dd19d86f-9eb4-4737-ad03-ca058ef3a686">
											<gml:posList>35.668670915971305 139.74782825021657 28.267662360670982 35.668669312220906 139.74783302287355 29.057709052565514 35.668669312220906 139.74783302287355 28.267662360670982 35.668670915971305 139.74782825021657 28.267662360670982</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_5a0a7a7d-a7ab-49e9-b01f-c193d69c64a5">
									<gml:exterior>
										<gml:LinearRing gml:id="line_4278dfe1-57e8-4d90-bc89-74a0f0814f80">
											<gml:posList>35.668669312220906 139.74783302287355 29.057709052565514 35.668670915971305 139.74782825021657 30.426239326003014 35.668669312220906 139.74783302287355 30.322609260085045 35.668669312220906 139.74783302287355 29.057709052565514</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_502124dc-de38-40da-bda9-571e789f11a2">
									<gml:exterior>
										<gml:LinearRing gml:id="line_b5c68b1f-89e6-4bd5-8780-db3988d3409f">
											<gml:posList>35.668669312220906 139.74783302287355 30.322609260085045 35.668670915971305 139.74782825021657 30.426239326003014 35.668669312220906 139.74783302287355 30.426239326003014 35.668669312220906 139.74783302287355 30.322609260085045</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_e62e80a7-347c-4e67-ae36-912d9cae41c2">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_f434659d-113b-42cd-98d5-48776024402f">
									<gml:exterior>
										<gml:LinearRing gml:id="line_bab632d9-b689-4bbc-b67e-780a88b2db2c">
											<gml:posList>35.668630285119036 139.74781332977528 21.1433261179952 35.66862642811532 139.74781138344156 21.1433261179952 35.668630285119036 139.74781332977528 21.24694855451864 35.668630285119036 139.74781332977528 21.1433261179952</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_bf9e0095-393e-42d3-94c0-663cd098a2fa">
									<gml:exterior>
										<gml:LinearRing gml:id="line_17054fc5-3eb5-401f-beca-111c4e0cc90d">
											<gml:posList>35.668630285119036 139.74781332977528 21.24694855451864 35.66862642811532 139.74781138344156 21.1433261179952 35.66862642811532 139.74781138344156 21.24694855451864 35.668630285119036 139.74781332977528 21.24694855451864</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_0c72306c-e5d8-4046-933b-88d6a2b4ae29">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_415588d0-ca84-4779-aefd-f57429236fe3">
									<gml:exterior>
										<gml:LinearRing gml:id="line_47e161d3-5535-4ab8-8d8e-2110c644cf8a">
											<gml:posList>35.66852209893759 139.74807548353158 8.85669739485067 35.66852209893759 139.74807548353158 6.3942492747334825 35.668524753753644 139.74806758251881 8.85669739485067 35.66852209893759 139.74807548353158 8.85669739485067</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_1434ff8c-42e5-4eea-ad73-07be5f2582e0">
									<gml:exterior>
										<gml:LinearRing gml:id="line_80c43a2c-72e4-4db1-8284-95555b7ac57d">
											<gml:posList>35.668524753753644 139.74806758251881 8.85669739485067 35.66852209893759 139.74807548353158 6.3942492747334825 35.668524753753644 139.74806758251881 6.3942492747334825 35.668524753753644 139.74806758251881 8.85669739485067</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
					<bldg:opening>
						<bldg:Window gml:id="wnd_ceae0ff6-7738-41e5-9079-4bf65a95ea27">
							<bldg:lod3MultiSurface>
								<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_afd4cc5f-8fb2-4c93-8539-95e9d32d2ac5">
											<gml:exterior>
												<gml:LinearRing gml:id="line_e013525b-6f98-4f29-83c2-da77aecec3bc">
													<gml:posList>35.66852755724325 139.74806899720042 6.3942492747334825 35.66852755724325 139.74806899720042 8.85669739485067 35.668524753753644 139.74806758251881 6.3942492747334825 35.66852755724325 139.74806899720042 6.3942492747334825</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_f7fb8d61-1991-41e7-af6e-0e7644e0fd18">
											<gml:exterior>
												<gml:LinearRing gml:id="line_486e0ff6-5259-4585-a882-f95ba598408b">
													<gml:posList>35.668524753753644 139.74806758251881 6.3942492747334825 35.66852755724325 139.74806899720042 8.85669739485067 35.668524753753644 139.74806758251881 8.85669739485067 35.668524753753644 139.74806758251881 6.3942492747334825</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
								</gml:MultiSurface>
							</bldg:lod3MultiSurface>
						</bldg:Window>
					</bldg:opening>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_4acd7792-b898-4690-b8a2-7267544f7517">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_c575ff02-e84a-4bea-9c59-7529d6e3a692">
									<gml:exterior>
										<gml:LinearRing gml:id="line_36f62a5c-bb0f-460d-91d9-451bb092cbcc">
											<gml:posList>35.66860490590231 139.74795651934778 38.68550141096395 35.66857452099137 139.74794118696468 38.68550141096395 35.66860490590231 139.74795651934778 37.902504279616295 35.66860490590231 139.74795651934778 38.68550141096395</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_4ecfb3ba-5882-4112-93d3-78e6aefde3dd">
									<gml:exterior>
										<gml:LinearRing gml:id="line_c46256a0-4503-4b44-8bae-4859156e7fb8">
											<gml:posList>35.66860490590231 139.74795651934778 37.902504279616295 35.66857452099137 139.74794118696468 38.68550141096395 35.66857452099137 139.74794118696468 37.902504279616295 35.66860490590231 139.74795651934778 37.902504279616295</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_3b190a32-6a93-449e-976e-1052aedb2272">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_963b4afd-1643-4a9d-b325-fa89df77f47c">
									<gml:exterior>
										<gml:LinearRing gml:id="line_865c639d-03ee-4c33-8033-73dfbde302d9">
											<gml:posList>35.66867316936178 139.74783496920924 27.262848212721764 35.6686747729746 139.74783019638366 27.3664706492452 35.6686747729746 139.74783019638366 26.259254767897545 35.66867316936178 139.74783496920924 27.262848212721764</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_65737eef-88ab-4279-a806-73692d281e1f">
									<gml:exterior>
										<gml:LinearRing gml:id="line_fc366f32-e37a-4bec-aba0-0cf392461e4a">
											<gml:posList>35.6686747729746 139.74783019638366 27.3664706492452 35.66867316936178 139.74783496920924 27.262848212721764 35.66867316936178 139.74783496920924 27.3664706492452 35.6686747729746 139.74783019638366 27.3664706492452</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_89813f25-9c8f-40e0-a1ed-027dc75afd10">
									<gml:exterior>
										<gml:LinearRing gml:id="line_9c9f4b83-8390-43e5-aa65-da4e7e701504">
											<gml:posList>35.6686747729746 139.74783019638366 25.65789826154989 35.66867316936178 139.74783496920924 25.2079013133077 35.66867316936178 139.74783496920924 25.997948005202232 35.6686747729746 139.74783019638366 25.65789826154989</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_dba0127d-efd0-4654-bd3e-934af6c3de74">
									<gml:exterior>
										<gml:LinearRing gml:id="line_dd4a0b6f-80b2-4af3-b661-399c43c24ef9">
											<gml:posList>35.66867316936178 139.74783496920924 25.2079013133077 35.6686747729746 139.74783019638366 25.65789826154989 35.6686747729746 139.74783019638366 25.2079013133077 35.66867316936178 139.74783496920924 25.2079013133077</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_ccb3f30e-a2d9-47e0-ab93-2c6f24bd9ac0">
									<gml:exterior>
										<gml:LinearRing gml:id="line_0b2ced8e-1c22-4e1b-ad34-d8bf99656e8d">
											<gml:posList>35.6686747729746 139.74783019638366 25.65789826154989 35.66867316936178 139.74783496920924 25.997948005202232 35.6686747729746 139.74783019638366 26.259254767897545 35.6686747729746 139.74783019638366 25.65789826154989</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_eb4e683b-fbf7-40ef-a322-6e301edae1cc">
									<gml:exterior>
										<gml:LinearRing gml:id="line_642dcbb6-04e4-4b95-9fde-4fe751298ea5">
											<gml:posList>35.6686747729746 139.74783019638366 26.259254767897545 35.66867316936178 139.74783496920924 25.997948005202232 35.66867316936178 139.74783496920924 27.262848212721764 35.6686747729746 139.74783019638366 26.259254767897545</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
					<bldg:opening>
						<bldg:Window gml:id="wnd_e8cadac4-1782-4a44-87fa-ec834b5c5c18">
							<bldg:lod3MultiSurface>
								<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_8544044c-464a-4580-94a2-63834d62e4b1">
											<gml:exterior>
												<gml:LinearRing gml:id="line_d635a025-ec16-4c8c-a16b-0bcd637481a5">
													<gml:posList>35.66867316936178 139.74783496920924 27.262848212721764 35.66867316936178 139.74783496920924 25.997948005202232 35.668669312220906 139.74783302287355 27.262848212721764 35.66867316936178 139.74783496920924 27.262848212721764</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_d727ec2b-12a4-44d6-a2c5-60e6e393da80">
											<gml:exterior>
												<gml:LinearRing gml:id="line_fe280993-d22b-4412-8100-a59939fbc169">
													<gml:posList>35.668669312220906 139.74783302287355 27.262848212721764 35.66867316936178 139.74783496920924 25.997948005202232 35.668669312220906 139.74783302287355 25.997948005202232 35.668669312220906 139.74783302287355 27.262848212721764</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
								</gml:MultiSurface>
							</bldg:lod3MultiSurface>
						</bldg:Window>
					</bldg:opening>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_46e276de-64cc-4ea5-a888-0d4e567e717d">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_27aa3536-742f-4013-b573-22ad6993fb2c">
									<gml:exterior>
										<gml:LinearRing gml:id="line_a6f357f8-10c4-4229-bf01-4c47a1770e34">
											<gml:posList>35.668690275854296 139.74782351812135 28.71765930891317 35.66868610967223 139.747835916983 28.71765930891317 35.668690275854296 139.74782351812135 30.426239326003014 35.668690275854296 139.74782351812135 28.71765930891317</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_02b1170d-ff72-41a3-8416-fd93d3a92711">
									<gml:exterior>
										<gml:LinearRing gml:id="line_df1c98a0-a376-4f8e-8820-6edb04e5e604">
											<gml:posList>35.668690275854296 139.74782351812135 30.426239326003014 35.66868610967223 139.747835916983 28.71765930891317 35.66868610967223 139.747835916983 30.426239326003014 35.668690275854296 139.74782351812135 30.426239326003014</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_aa5608b2-8da5-4aba-809e-2d85199854d8">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_6412e036-61db-4853-873a-40be0e842826">
									<gml:exterior>
										<gml:LinearRing gml:id="line_d9347a74-9e10-44f2-8b68-ada1ae046d87">
											<gml:posList>35.66857452099137 139.74794118696468 37.902504279616295 35.66857452099137 139.74794118696468 38.68550141096395 35.668577455786235 139.74793245233906 37.902504279616295 35.66857452099137 139.74794118696468 37.902504279616295</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_1e5d24bb-841d-498e-87cb-ff788507c680">
									<gml:exterior>
										<gml:LinearRing gml:id="line_dc8e2ef4-f3ae-450d-9cd0-72dd4c0d33e9">
											<gml:posList>35.668577455786235 139.74793245233906 37.902504279616295 35.66857452099137 139.74794118696468 38.68550141096395 35.668577455786235 139.74793245233906 38.68550141096395 35.668577455786235 139.74793245233906 37.902504279616295</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_790ab7b7-ed70-40b9-b2d1-00f1afba7bc0">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_94fe44b5-1f78-43c2-8d28-a4c768d0a92b">
									<gml:exterior>
										<gml:LinearRing gml:id="line_31ec9f3c-6451-4575-803d-26971c722a8e">
											<gml:posList>35.668628031727216 139.74780661061828 21.24694855451864 35.66862642811532 139.74781138344156 21.1433261179952 35.66862642811532 139.74781138344156 19.87842591047567 35.668628031727216 139.74780661061828 21.24694855451864</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_3bbdcc8a-62c6-4a3a-ab39-3f82f168eba9">
									<gml:exterior>
										<gml:LinearRing gml:id="line_4c4aeff4-29ed-4f0d-b9af-d5ebe5225e87">
											<gml:posList>35.66862642811532 139.74781138344156 21.1433261179952 35.668628031727216 139.74780661061828 21.24694855451864 35.66862642811532 139.74781138344156 21.24694855451864 35.66862642811532 139.74781138344156 21.1433261179952</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_064a4268-79c3-4e93-9945-69bf3f8074cb">
									<gml:exterior>
										<gml:LinearRing gml:id="line_10981146-6738-4424-b7c7-7ca242280bd6">
											<gml:posList>35.668628031727216 139.74780661061828 21.24694855451864 35.66862642811532 139.74781138344156 19.87842591047567 35.668628031727216 139.74780661061828 19.088371589186607 35.668628031727216 139.74780661061828 21.24694855451864</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_82edb714-028f-4182-9fce-d28401def991">
									<gml:exterior>
										<gml:LinearRing gml:id="line_3dcd1962-b913-4969-829a-efb405df91bc">
											<gml:posList>35.668628031727216 139.74780661061828 19.088371589186607 35.66862642811532 139.74781138344156 19.87842591047567 35.66862642811532 139.74781138344156 19.088371589186607 35.668628031727216 139.74780661061828 19.088371589186607</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_7ccf3ecc-6e07-4918-9d77-1636ef29924b">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_85dca159-ccd2-45da-b240-a9d9df50b491">
									<gml:exterior>
										<gml:LinearRing gml:id="line_bb59819f-dfdf-4064-a024-35e4b8d020d2">
											<gml:posList>35.668630285119036 139.74781332977528 30.322609260085045 35.66862642811532 139.74781138344156 30.322609260085045 35.668630285119036 139.74781332977528 30.426239326003014 35.668630285119036 139.74781332977528 30.322609260085045</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_a65002fd-f486-4d63-abbf-6af80f27fa40">
									<gml:exterior>
										<gml:LinearRing gml:id="line_52c1b14c-1316-4eb4-a7b3-bafe784640e4">
											<gml:posList>35.668630285119036 139.74781332977528 30.426239326003014 35.66862642811532 139.74781138344156 30.322609260085045 35.66862642811532 139.74781138344156 30.426239326003014 35.668630285119036 139.74781332977528 30.426239326003014</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_bc208781-e2bc-4596-9456-4328919b0220">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_5c5a15e4-41d3-45b2-8f81-c6bde237e559">
									<gml:exterior>
										<gml:LinearRing gml:id="line_e49e3bff-7949-4723-b3b0-74476b12868c">
											<gml:posList>35.66856091215805 139.7481047449641 37.902504279616295 35.66855889071795 139.74810372486473 36.598793342116295 35.66855889071795 139.74810372486473 34.84155304670614 35.66856091215805 139.7481047449641 37.902504279616295</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_efcea443-a18d-4db1-b421-750dd9471eb2">
									<gml:exterior>
										<gml:LinearRing gml:id="line_5d435e1c-595a-4530-be9a-a889338c90da">
											<gml:posList>35.66855889071795 139.74810372486473 36.598793342116295 35.66856091215805 139.7481047449641 37.902504279616295 35.66855062072753 139.74809955179325 36.598793342116295 35.66855889071795 139.74810372486473 36.598793342116295</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_220fcd55-91c9-4029-ba66-727da07cc72e">
									<gml:exterior>
										<gml:LinearRing gml:id="line_306263d9-ef16-4b68-9606-0c0c7a4fcb3b">
											<gml:posList>35.66856091215805 139.7481047449641 37.902504279616295 35.66855889071795 139.74810372486473 34.84155304670614 35.66855889071795 139.74810372486473 33.58221466779989 35.66856091215805 139.7481047449641 37.902504279616295</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_5c6e8f52-f70d-4bb9-8a1b-2e772a8c58fb">
									<gml:exterior>
										<gml:LinearRing gml:id="line_e403f210-209c-4a0f-a9bb-52d4d4701879">
											<gml:posList>35.66856091215805 139.7481047449641 37.902504279616295 35.66855889071795 139.74810372486473 33.58221466779989 35.66855889071795 139.74810372486473 31.8249667429952 35.66856091215805 139.7481047449641 37.902504279616295</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_0e2b60e4-e8c3-4f56-bc52-0a733914a940">
									<gml:exterior>
										<gml:LinearRing gml:id="line_6f2d3b98-a8a1-415a-8d9d-0c77de0dc38e">
											<gml:posList>35.66855889071795 139.74810372486473 33.58221466779989 35.66855889071795 139.74810372486473 34.84155304670614 35.66855062072753 139.74809955179325 33.58221466779989 35.66855889071795 139.74810372486473 33.58221466779989</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_ebcc9536-6ade-4916-a1eb-f71b2392b094">
									<gml:exterior>
										<gml:LinearRing gml:id="line_78c8f29d-16af-4b05-ba61-d19421288ff7">
											<gml:posList>35.66855062072753 139.74809955179325 33.58221466779989 35.66855889071795 139.74810372486473 34.84155304670614 35.66855062072753 139.74809955179325 34.84155304670614 35.66855062072753 139.74809955179325 33.58221466779989</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_f83fb810-30e9-45ae-b1a0-0a09ab19dea5">
									<gml:exterior>
										<gml:LinearRing gml:id="line_8287364a-74f5-48ac-a458-891852ae4358">
											<gml:posList>35.66855062072753 139.74809955179325 33.58221466779989 35.66855062072753 139.74809955179325 34.84155304670614 35.668521921422965 139.74808507009323 33.58221466779989 35.66855062072753 139.74809955179325 33.58221466779989</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_464e3827-9143-4035-9b32-f62179fb7e26">
									<gml:exterior>
										<gml:LinearRing gml:id="line_6081f76f-eb92-4961-b0f4-4bb51009036d">
											<gml:posList>35.66856091215805 139.7481047449641 37.902504279616295 35.66855889071795 139.74810372486473 31.8249667429952 35.66855889071795 139.74810372486473 30.545700385573326 35.66856091215805 139.7481047449641 37.902504279616295</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_d03f1836-b68a-40d4-b3c4-12d2a9cb843c">
									<gml:exterior>
										<gml:LinearRing gml:id="line_d3ff8d50-40f5-47ed-9c76-3312aff05e1d">
											<gml:posList>35.66856091215805 139.7481047449641 37.902504279616295 35.66855889071795 139.74810372486473 30.545700385573326 35.66855889071795 139.74810372486473 28.78846009016317 35.66856091215805 139.7481047449641 37.902504279616295</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_bd298ddf-2409-4564-a0c9-c6977f5cdbdd">
									<gml:exterior>
										<gml:LinearRing gml:id="line_ce092c92-dcb6-4ed1-a120-9ef6bc248a4d">
											<gml:posList>35.66855889071795 139.74810372486473 30.545700385573326 35.66855889071795 139.74810372486473 31.8249667429952 35.66855062072753 139.74809955179325 31.8249667429952 35.66855889071795 139.74810372486473 30.545700385573326</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_2b4c46bc-b8ee-42ce-aa96-739a8a9f618a">
									<gml:exterior>
										<gml:LinearRing gml:id="line_ee1fba30-1cde-4e6e-abc6-3e1a29902dea">
											<gml:posList>35.66855889071795 139.74810372486473 30.545700385573326 35.66855062072753 139.74809955179325 31.8249667429952 35.66855062072753 139.74809955179325 30.545700385573326 35.66855889071795 139.74810372486473 30.545700385573326</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_a521560d-f9bc-4909-9ab5-969e4e07c5d5">
									<gml:exterior>
										<gml:LinearRing gml:id="line_4434b1f7-9900-43ac-b7b8-5c3f5716cc41">
											<gml:posList>35.66855062072753 139.74809955179325 30.545700385573326 35.66855062072753 139.74809955179325 31.8249667429952 35.668521921422965 139.74808507009323 31.8249667429952 35.66855062072753 139.74809955179325 30.545700385573326</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_55aa27d5-9081-4009-b103-ed7dd7f73997">
									<gml:exterior>
										<gml:LinearRing gml:id="line_ba39a935-2e95-43c7-a041-783f097817e5">
											<gml:posList>35.66856091215805 139.7481047449641 37.902504279616295 35.66855889071795 139.74810372486473 28.78846009016317 35.66855889071795 139.74810372486473 27.52912171125692 35.66856091215805 139.7481047449641 37.902504279616295</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_180d1ba7-c971-44cd-80e9-140627d859ca">
									<gml:exterior>
										<gml:LinearRing gml:id="line_97913710-0e1b-4cc5-9be8-54b032243ae4">
											<gml:posList>35.66856091215805 139.7481047449641 37.902504279616295 35.66855889071795 139.74810372486473 27.52912171125692 35.66855889071795 139.74810372486473 25.771873786452232 35.66856091215805 139.7481047449641 37.902504279616295</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_42eb7c9b-497d-4a17-8439-980ea2a99d33">
									<gml:exterior>
										<gml:LinearRing gml:id="line_36f7fccf-4eb1-47cf-aab2-0c1c21181352">
											<gml:posList>35.66855889071795 139.74810372486473 27.52912171125692 35.66855889071795 139.74810372486473 28.78846009016317 35.66855062072753 139.74809955179325 27.52912171125692 35.66855889071795 139.74810372486473 27.52912171125692</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_4ae20914-54f9-4dee-ba7a-e41cdd1c01fb">
									<gml:exterior>
										<gml:LinearRing gml:id="line_86a769b8-ff0d-4398-aeea-5519281edac8">
											<gml:posList>35.66855062072753 139.74809955179325 27.52912171125692 35.66855889071795 139.74810372486473 28.78846009016317 35.66855062072753 139.74809955179325 28.78846009016317 35.66855062072753 139.74809955179325 27.52912171125692</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_9eeb9316-5cbe-4e12-9b16-c101beaf70ad">
									<gml:exterior>
										<gml:LinearRing gml:id="line_b771b7d8-1432-4a1e-afe2-648de4877e3b">
											<gml:posList>35.66855062072753 139.74809955179325 27.52912171125692 35.66855062072753 139.74809955179325 28.78846009016317 35.668521921422965 139.74808507009323 27.52912171125692 35.66855062072753 139.74809955179325 27.52912171125692</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_5f0581ac-90de-4952-9a58-c261dda9ab78">
									<gml:exterior>
										<gml:LinearRing gml:id="line_4f7180c8-82e0-429e-86e2-ac85137eb0de">
											<gml:posList>35.66856091215805 139.7481047449641 37.902504279616295 35.66855889071795 139.74810372486473 25.771873786452232 35.66855889071795 139.74810372486473 24.447136237624107 35.66856091215805 139.7481047449641 37.902504279616295</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_f7dc61d5-3d59-428e-8104-890e7b385837">
									<gml:exterior>
										<gml:LinearRing gml:id="line_15722ced-3f6d-4593-94e9-7d8974cbbfb6">
											<gml:posList>35.66856091215805 139.7481047449641 37.902504279616295 35.66855889071795 139.74810372486473 24.447136237624107 35.66855889071795 139.74810372486473 22.68988831281942 35.66856091215805 139.7481047449641 37.902504279616295</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_9b6d2fea-de1b-4e86-b494-d4c6387dabf6">
									<gml:exterior>
										<gml:LinearRing gml:id="line_84597be6-f1f8-463b-a32b-fd3d04acc836">
											<gml:posList>35.66855889071795 139.74810372486473 24.447136237624107 35.66855889071795 139.74810372486473 25.771873786452232 35.66855062072753 139.74809955179325 24.447136237624107 35.66855889071795 139.74810372486473 24.447136237624107</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_76d85904-faf8-412d-8998-d24370585de9">
									<gml:exterior>
										<gml:LinearRing gml:id="line_3f391fb6-e9d6-414b-a51e-5b5fbe65284d">
											<gml:posList>35.66855062072753 139.74809955179325 24.447136237624107 35.66855889071795 139.74810372486473 25.771873786452232 35.66855062072753 139.74809955179325 25.771873786452232 35.66855062072753 139.74809955179325 24.447136237624107</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_9b18ed33-647b-46f1-9e96-a9d7b143919c">
									<gml:exterior>
										<gml:LinearRing gml:id="line_da0e5311-3a96-4cb0-b15f-00ba477a9493">
											<gml:posList>35.66855062072753 139.74809955179325 24.447136237624107 35.66855062072753 139.74809955179325 25.771873786452232 35.668521921422965 139.74808507009323 24.447136237624107 35.66855062072753 139.74809955179325 24.447136237624107</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_1778978c-4999-4e73-a154-b69b7ffa0bda">
									<gml:exterior>
										<gml:LinearRing gml:id="line_8756b591-3dfb-4366-bbff-8bd8217f19e7">
											<gml:posList>35.66856091215805 139.7481047449641 37.902504279616295 35.66855889071795 139.74810372486473 22.68988831281942 35.66856091215805 139.7481047449641 6.3942492747334825 35.66856091215805 139.7481047449641 37.902504279616295</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_9b38eefe-8d28-4c36-aaa8-b0475b37bfed">
									<gml:exterior>
										<gml:LinearRing gml:id="line_bf4f8528-0276-475d-8e92-91fcae75206e">
											<gml:posList>35.66856091215805 139.7481047449641 6.3942492747334825 35.66855889071795 139.74810372486473 22.68988831281942 35.66855889071795 139.74810372486473 21.43054993391317 35.66856091215805 139.7481047449641 6.3942492747334825</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_f59ff5f5-e436-4ffa-8fa7-1e80386cd01e">
									<gml:exterior>
										<gml:LinearRing gml:id="line_4b6b9735-b94b-4c15-8bd2-5cae10d87704">
											<gml:posList>35.66855889071795 139.74810372486473 21.43054993391317 35.66855889071795 139.74810372486473 22.68988831281942 35.66855062072753 139.74809955179325 22.68988831281942 35.66855889071795 139.74810372486473 21.43054993391317</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_60960793-96a1-4aa7-a506-fd028baf6ae9">
									<gml:exterior>
										<gml:LinearRing gml:id="line_0f361be2-2402-416a-aa88-cbcb628d1749">
											<gml:posList>35.66855889071795 139.74810372486473 21.43054993391317 35.66855062072753 139.74809955179325 22.68988831281942 35.66855062072753 139.74809955179325 21.43054993391317 35.66855889071795 139.74810372486473 21.43054993391317</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_0d52dfa7-e175-4965-9121-37ebcb00e1d0">
									<gml:exterior>
										<gml:LinearRing gml:id="line_4e131ad1-8441-4cfe-8cbb-b5bea6566b58">
											<gml:posList>35.66855062072753 139.74809955179325 21.43054993391317 35.66855062072753 139.74809955179325 22.68988831281942 35.668521921422965 139.74808507009323 21.43054993391317 35.66855062072753 139.74809955179325 21.43054993391317</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_7dcc0232-848b-4a60-87d8-f1a69a699955">
									<gml:exterior>
										<gml:LinearRing gml:id="line_53c97be5-1fd6-4db4-a677-73a084c8ee31">
											<gml:posList>35.66856091215805 139.7481047449641 6.3942492747334825 35.66855889071795 139.74810372486473 21.43054993391317 35.66855889071795 139.74810372486473 19.673309638503014 35.66856091215805 139.7481047449641 6.3942492747334825</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_2b19e256-3ed0-428e-bf49-316415e7532a">
									<gml:exterior>
										<gml:LinearRing gml:id="line_b47b8d20-c9fe-484f-b462-22cf1fb38c70">
											<gml:posList>35.66856091215805 139.7481047449641 6.3942492747334825 35.66855889071795 139.74810372486473 19.673309638503014 35.66855889071795 139.74810372486473 18.413971259596764 35.66856091215805 139.7481047449641 6.3942492747334825</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_dc656fae-a73a-4348-804b-09737f5a3f1d">
									<gml:exterior>
										<gml:LinearRing gml:id="line_6e4690c0-4dfe-42f4-a25a-dad858e55f24">
											<gml:posList>35.66855889071795 139.74810372486473 18.413971259596764 35.66855889071795 139.74810372486473 19.673309638503014 35.66855062072753 139.74809955179325 19.673309638503014 35.66855889071795 139.74810372486473 18.413971259596764</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_7cc827e1-fdd1-4d46-8b24-28c17ac4c72d">
									<gml:exterior>
										<gml:LinearRing gml:id="line_fc45abb6-841d-41b9-92ea-0fcf9f997764">
											<gml:posList>35.66855889071795 139.74810372486473 18.413971259596764 35.66855062072753 139.74809955179325 19.673309638503014 35.66855062072753 139.74809955179325 18.413971259596764 35.66855889071795 139.74810372486473 18.413971259596764</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_4172c94d-bd30-4f55-8fc6-fae3f8858a53">
									<gml:exterior>
										<gml:LinearRing gml:id="line_e07c3354-790c-4315-afa2-f0207999c6cf">
											<gml:posList>35.66855062072753 139.74809955179325 18.413971259596764 35.66855062072753 139.74809955179325 19.673309638503014 35.668521921422965 139.74808507009323 19.673309638503014 35.66855062072753 139.74809955179325 18.413971259596764</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_6bf5d802-7780-4cc7-9cd8-f46740d726a2">
									<gml:exterior>
										<gml:LinearRing gml:id="line_99e8dccb-9fe8-4723-b730-de0ffe000239">
											<gml:posList>35.66856091215805 139.7481047449641 6.3942492747334825 35.66855889071795 139.74810372486473 18.413971259596764 35.66855889071795 139.74810372486473 16.656730964186607 35.66856091215805 139.7481047449641 6.3942492747334825</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_8810ffee-7ecd-46dc-92b6-aa1288b67852">
									<gml:exterior>
										<gml:LinearRing gml:id="line_8b696315-d9b7-4643-ade2-c571c4192e0d">
											<gml:posList>35.66856091215805 139.7481047449641 6.3942492747334825 35.66855889071795 139.74810372486473 16.656730964186607 35.66855889071795 139.74810372486473 15.397392585280357 35.66856091215805 139.7481047449641 6.3942492747334825</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_9d0654e7-11f3-41b1-b9a6-8c971c117280">
									<gml:exterior>
										<gml:LinearRing gml:id="line_592f7614-fd13-48d0-98de-dd4586b7cb2c">
											<gml:posList>35.66855889071795 139.74810372486473 15.397392585280357 35.66855889071795 139.74810372486473 16.656730964186607 35.66855062072753 139.74809955179325 16.656730964186607 35.66855889071795 139.74810372486473 15.397392585280357</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_8394df1b-6b1e-498e-b845-c712df0e3268">
									<gml:exterior>
										<gml:LinearRing gml:id="line_cda02dd2-f295-4ae9-8867-b9dcad92814c">
											<gml:posList>35.66855889071795 139.74810372486473 15.397392585280357 35.66855062072753 139.74809955179325 16.656730964186607 35.66855062072753 139.74809955179325 15.397392585280357 35.66855889071795 139.74810372486473 15.397392585280357</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_c3ba8bd3-8dda-401d-8a6b-070415153a0a">
									<gml:exterior>
										<gml:LinearRing gml:id="line_4ea09569-6885-4bd6-9c34-0d278bc8968b">
											<gml:posList>35.66855062072753 139.74809955179325 15.397392585280357 35.66855062072753 139.74809955179325 16.656730964186607 35.668521921422965 139.74808507009323 16.656730964186607 35.66855062072753 139.74809955179325 15.397392585280357</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_5ce094fb-75ce-43dc-b436-ed0898ea4ef3">
									<gml:exterior>
										<gml:LinearRing gml:id="line_918d3742-d1db-44b1-b45c-80353a9d5763">
											<gml:posList>35.66856091215805 139.7481047449641 6.3942492747334825 35.66855889071795 139.74810372486473 15.397392585280357 35.66855889071795 139.74810372486473 13.64014466047567 35.66856091215805 139.7481047449641 6.3942492747334825</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_80083689-fbd3-4e1a-af28-604f94ca85fd">
									<gml:exterior>
										<gml:LinearRing gml:id="line_d8f040ed-341c-4e31-8c3c-335e0c1f77b7">
											<gml:posList>35.66856091215805 139.7481047449641 6.3942492747334825 35.66855889071795 139.74810372486473 13.64014466047567 35.66855909916354 139.7481038301547 9.23169739485067 35.66856091215805 139.7481047449641 6.3942492747334825</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_a17e9980-ed3a-4804-a046-7d3eda514fbb">
									<gml:exterior>
										<gml:LinearRing gml:id="line_f83ee550-34c6-49aa-809e-28bc4018a48d">
											<gml:posList>35.66855909916354 139.7481038301547 9.23169739485067 35.66855889071795 139.74810372486473 13.64014466047567 35.66855062072753 139.74809955179325 13.64014466047567 35.66855909916354 139.7481038301547 9.23169739485067</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_0b3508f0-98bf-4097-87fe-0b64d30d0f8e">
									<gml:exterior>
										<gml:LinearRing gml:id="line_252a3e43-61a8-4c3a-b3a4-ec21b1e50faf">
											<gml:posList>35.66855909916354 139.7481038301547 9.23169739485067 35.66855062072753 139.74809955179325 13.64014466047567 35.668521921422965 139.74808507009323 13.64014466047567 35.66855909916354 139.7481038301547 9.23169739485067</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_0c11784b-d53e-4f4d-b72f-d4c9c728cdb0">
									<gml:exterior>
										<gml:LinearRing gml:id="line_c05170db-a25b-44ae-956f-08e3ff5349d4">
											<gml:posList>35.66855909916354 139.7481038301547 9.23169739485067 35.668521921422965 139.74808507009323 13.64014466047567 35.6685122320758 139.74808018068603 9.23169739485067 35.66855909916354 139.7481038301547 9.23169739485067</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_25a06a88-3c5a-45d0-9a17-36eecc7b25a6">
									<gml:exterior>
										<gml:LinearRing gml:id="line_448eae96-deb2-43be-90da-159f031bb239">
											<gml:posList>35.6685122320758 139.74808018068603 9.23169739485067 35.668521921422965 139.74808507009323 13.64014466047567 35.66851365143185 139.74808089702555 13.64014466047567 35.6685122320758 139.74808018068603 9.23169739485067</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_eb8b66f4-d34a-49ee-b50e-a959acde5ab2">
									<gml:exterior>
										<gml:LinearRing gml:id="line_b5a785d5-63d4-4d21-84ef-0961851fa403">
											<gml:posList>35.66856091215805 139.7481047449641 6.3942492747334825 35.66855909916354 139.7481038301547 9.23169739485067 35.66855909916354 139.7481038301547 6.3942492747334825 35.66856091215805 139.7481047449641 6.3942492747334825</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_b41f6f0a-6617-4fc2-b42d-c8719d853b83">
									<gml:exterior>
										<gml:LinearRing gml:id="line_88da4ef0-b74b-467c-acf5-3244efcf2fe0">
											<gml:posList>35.668521921422965 139.74808507009323 34.84155304670614 35.66855062072753 139.74809955179325 36.598793342116295 35.668521921422965 139.74808507009323 36.598793342116295 35.668521921422965 139.74808507009323 34.84155304670614</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_fcd58446-0121-4ef4-a7b1-9cf25ad80905">
									<gml:exterior>
										<gml:LinearRing gml:id="line_0f6296b6-3243-457b-9455-6bec456f0b75">
											<gml:posList>35.66855062072753 139.74809955179325 36.598793342116295 35.668521921422965 139.74808507009323 34.84155304670614 35.66855062072753 139.74809955179325 34.84155304670614 35.66855062072753 139.74809955179325 36.598793342116295</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_60b1150d-b5cf-4124-876c-d9f070d23543">
									<gml:exterior>
										<gml:LinearRing gml:id="line_a6144815-9e94-4115-ae2f-4e686bbcfb56">
											<gml:posList>35.668521921422965 139.74808507009323 31.8249667429952 35.66855062072753 139.74809955179325 33.58221466779989 35.668521921422965 139.74808507009323 33.58221466779989 35.668521921422965 139.74808507009323 31.8249667429952</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_d45b9e99-98be-4f11-8d46-74c219bfe3fd">
									<gml:exterior>
										<gml:LinearRing gml:id="line_870fbfb4-1d4a-4a08-829a-86c34ee9401e">
											<gml:posList>35.66855062072753 139.74809955179325 33.58221466779989 35.668521921422965 139.74808507009323 31.8249667429952 35.66855062072753 139.74809955179325 31.8249667429952 35.66855062072753 139.74809955179325 33.58221466779989</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_9395ec34-0762-42f8-b55b-d9674327ec46">
									<gml:exterior>
										<gml:LinearRing gml:id="line_ff1e2971-7b47-45c1-a4e2-f9aa38dde7cd">
											<gml:posList>35.668521921422965 139.74808507009323 28.78846009016317 35.66855062072753 139.74809955179325 30.545700385573326 35.668521921422965 139.74808507009323 30.545700385573326 35.668521921422965 139.74808507009323 28.78846009016317</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_9b447a9b-dc54-4618-8105-8c33bf224baa">
									<gml:exterior>
										<gml:LinearRing gml:id="line_8904a0ce-9b1a-40fc-a30f-5b3d3aeaa51b">
											<gml:posList>35.66855062072753 139.74809955179325 30.545700385573326 35.668521921422965 139.74808507009323 28.78846009016317 35.66855062072753 139.74809955179325 28.78846009016317 35.66855062072753 139.74809955179325 30.545700385573326</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_8d8061dd-06d9-4e2e-8dc9-c36bd666ca83">
									<gml:exterior>
										<gml:LinearRing gml:id="line_2d6f86a9-c4b9-462d-bae5-2ea1fcf83cea">
											<gml:posList>35.66855062072753 139.74809955179325 25.771873786452232 35.668521921422965 139.74808507009323 27.52912171125692 35.668521921422965 139.74808507009323 25.771873786452232 35.66855062072753 139.74809955179325 25.771873786452232</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_1ea10e85-8add-4504-8f81-af2620c27ced">
									<gml:exterior>
										<gml:LinearRing gml:id="line_d8aece32-75f6-4f26-9c05-4bda37dda0bd">
											<gml:posList>35.668521921422965 139.74808507009323 27.52912171125692 35.66855062072753 139.74809955179325 25.771873786452232 35.66855062072753 139.74809955179325 27.52912171125692 35.668521921422965 139.74808507009323 27.52912171125692</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_bc380f38-e59f-47c6-ab59-27967a3f10d5">
									<gml:exterior>
										<gml:LinearRing gml:id="line_e8e6590e-4537-44b0-aa3c-da2ea5b94463">
											<gml:posList>35.66855062072753 139.74809955179325 22.68988831281942 35.668521921422965 139.74808507009323 24.447136237624107 35.668521921422965 139.74808507009323 22.68988831281942 35.66855062072753 139.74809955179325 22.68988831281942</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_d43fba7b-fefe-4908-97f4-b5657cf760b4">
									<gml:exterior>
										<gml:LinearRing gml:id="line_14be82f3-46ba-4664-8185-bda653f426d2">
											<gml:posList>35.668521921422965 139.74808507009323 24.447136237624107 35.66855062072753 139.74809955179325 22.68988831281942 35.66855062072753 139.74809955179325 24.447136237624107 35.668521921422965 139.74808507009323 24.447136237624107</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_5c09c1ec-f76f-4a58-8584-09fa142f20f1">
									<gml:exterior>
										<gml:LinearRing gml:id="line_9e95fa7b-1782-4ab2-9c3b-15a2fb7fbbae">
											<gml:posList>35.66855062072753 139.74809955179325 19.673309638503014 35.668521921422965 139.74808507009323 21.43054993391317 35.668521921422965 139.74808507009323 19.673309638503014 35.66855062072753 139.74809955179325 19.673309638503014</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_9ba5d6c5-dafb-4140-a804-3e0a595a54f2">
									<gml:exterior>
										<gml:LinearRing gml:id="line_5acbc113-2c59-42e5-b6f7-d308679e4f1e">
											<gml:posList>35.668521921422965 139.74808507009323 21.43054993391317 35.66855062072753 139.74809955179325 19.673309638503014 35.66855062072753 139.74809955179325 21.43054993391317 35.668521921422965 139.74808507009323 21.43054993391317</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_8094217c-4a8c-4c91-afe1-da1607966cc6">
									<gml:exterior>
										<gml:LinearRing gml:id="line_ff310f4a-4fd0-4137-a45c-9ace31fd0c32">
											<gml:posList>35.668521921422965 139.74808507009323 16.656730964186607 35.66855062072753 139.74809955179325 18.413971259596764 35.668521921422965 139.74808507009323 18.413971259596764 35.668521921422965 139.74808507009323 16.656730964186607</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_9712e862-7b48-4a65-a95e-a9c352b2e729">
									<gml:exterior>
										<gml:LinearRing gml:id="line_a4193b39-0a58-4779-80b1-0cda220ae941">
											<gml:posList>35.66855062072753 139.74809955179325 18.413971259596764 35.668521921422965 139.74808507009323 16.656730964186607 35.66855062072753 139.74809955179325 16.656730964186607 35.66855062072753 139.74809955179325 18.413971259596764</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_6de48a7d-67f6-4b65-a4dd-01eeda4d57f0">
									<gml:exterior>
										<gml:LinearRing gml:id="line_0e4297bd-489c-4e7e-a42e-e4e0b8e4cd9c">
											<gml:posList>35.668521921422965 139.74808507009323 36.598793342116295 35.66856091215805 139.7481047449641 37.902504279616295 35.66851072947919 139.74807942246645 37.902504279616295 35.668521921422965 139.74808507009323 36.598793342116295</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_00df1d1d-4267-4ea3-b62e-d0fef9c04213">
									<gml:exterior>
										<gml:LinearRing gml:id="line_dd10442d-534e-4a64-a77f-8c0c2dde6d44">
											<gml:posList>35.66856091215805 139.7481047449641 37.902504279616295 35.668521921422965 139.74808507009323 36.598793342116295 35.66855062072753 139.74809955179325 36.598793342116295 35.66856091215805 139.7481047449641 37.902504279616295</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_a85df06d-924c-4cee-a06d-15de7f4a7f3e">
									<gml:exterior>
										<gml:LinearRing gml:id="line_65f5cb17-36ce-4416-932f-de06799397b8">
											<gml:posList>35.66851365143185 139.74808089702555 36.598793342116295 35.66851072947919 139.74807942246645 37.902504279616295 35.66851365143185 139.74808089702555 34.84155304670614 35.66851365143185 139.74808089702555 36.598793342116295</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_5368a7c2-9bf5-4ab7-9b05-2b6c27bf5208">
									<gml:exterior>
										<gml:LinearRing gml:id="line_82ea11f1-59da-43ec-9834-ebe62ca81129">
											<gml:posList>35.66851072947919 139.74807942246645 37.902504279616295 35.66851365143185 139.74808089702555 36.598793342116295 35.668521921422965 139.74808507009323 36.598793342116295 35.66851072947919 139.74807942246645 37.902504279616295</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_61f3f796-8ed8-4b59-85fe-53f7c3c1c48d">
									<gml:exterior>
										<gml:LinearRing gml:id="line_dd1aace7-c719-4ce7-8dd8-41729b0c85d2">
											<gml:posList>35.66851365143185 139.74808089702555 34.84155304670614 35.66851072947919 139.74807942246645 37.902504279616295 35.66851365143185 139.74808089702555 33.58221466779989 35.66851365143185 139.74808089702555 34.84155304670614</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_48ec70ca-37d4-4bfc-b7b3-bcede605ea60">
									<gml:exterior>
										<gml:LinearRing gml:id="line_439371fe-d339-4531-b047-403b296e310f">
											<gml:posList>35.66851365143185 139.74808089702555 33.58221466779989 35.66851072947919 139.74807942246645 37.902504279616295 35.66851365143185 139.74808089702555 31.8249667429952 35.66851365143185 139.74808089702555 33.58221466779989</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_33283110-c4a6-4663-b3ca-33707b53911d">
									<gml:exterior>
										<gml:LinearRing gml:id="line_acbd2a82-ee63-4ea0-b3a5-37bf75f73546">
											<gml:posList>35.66851365143185 139.74808089702555 34.84155304670614 35.66851365143185 139.74808089702555 33.58221466779989 35.668521921422965 139.74808507009323 34.84155304670614 35.66851365143185 139.74808089702555 34.84155304670614</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_cde38b98-8b8c-4afc-86db-e35c9d7d206f">
									<gml:exterior>
										<gml:LinearRing gml:id="line_a8c4d946-4ea4-4502-b0c2-45d4b7bb76de">
											<gml:posList>35.668521921422965 139.74808507009323 34.84155304670614 35.668521921422965 139.74808507009323 33.58221466779989 35.66855062072753 139.74809955179325 34.84155304670614 35.668521921422965 139.74808507009323 34.84155304670614</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_500c8978-27b2-4d1b-a45b-0151ae92a041">
									<gml:exterior>
										<gml:LinearRing gml:id="line_2e4d816f-8944-4fd7-bffb-85a1554e05ca">
											<gml:posList>35.668521921422965 139.74808507009323 33.58221466779989 35.668521921422965 139.74808507009323 34.84155304670614 35.66851365143185 139.74808089702555 33.58221466779989 35.668521921422965 139.74808507009323 33.58221466779989</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_608d1224-28a5-42f1-be9b-71284bbd55d7">
									<gml:exterior>
										<gml:LinearRing gml:id="line_1da570f3-ace5-49f7-af4d-be89f4abf40d">
											<gml:posList>35.66851365143185 139.74808089702555 31.8249667429952 35.66851072947919 139.74807942246645 37.902504279616295 35.66851365143185 139.74808089702555 30.545700385573326 35.66851365143185 139.74808089702555 31.8249667429952</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_3c56326c-2462-40e6-8bab-044ab4e5c39b">
									<gml:exterior>
										<gml:LinearRing gml:id="line_d39e1327-cc58-4216-b78c-f117e14ed9d3">
											<gml:posList>35.66851365143185 139.74808089702555 30.545700385573326 35.66851072947919 139.74807942246645 37.902504279616295 35.66851365143185 139.74808089702555 28.78846009016317 35.66851365143185 139.74808089702555 30.545700385573326</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_5853aa13-f5a4-470e-8814-5d8ef2909db1">
									<gml:exterior>
										<gml:LinearRing gml:id="line_a08eac86-7d8d-40fe-a1db-892f0fec233e">
											<gml:posList>35.66851365143185 139.74808089702555 31.8249667429952 35.66851365143185 139.74808089702555 30.545700385573326 35.668521921422965 139.74808507009323 31.8249667429952 35.66851365143185 139.74808089702555 31.8249667429952</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_1def5a56-85c8-49c6-942b-a07e56a7748a">
									<gml:exterior>
										<gml:LinearRing gml:id="line_0c4a8875-4eae-4de6-964f-77a84f0e1f01">
											<gml:posList>35.668521921422965 139.74808507009323 31.8249667429952 35.66851365143185 139.74808089702555 30.545700385573326 35.668521921422965 139.74808507009323 30.545700385573326 35.668521921422965 139.74808507009323 31.8249667429952</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_26532936-adb4-4539-bae2-8f77c40ae463">
									<gml:exterior>
										<gml:LinearRing gml:id="line_6588f574-5e6c-4d10-8013-3b83b0aac466">
											<gml:posList>35.66855062072753 139.74809955179325 30.545700385573326 35.668521921422965 139.74808507009323 31.8249667429952 35.668521921422965 139.74808507009323 30.545700385573326 35.66855062072753 139.74809955179325 30.545700385573326</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_232c183b-4bdd-49a1-89db-1e027a1525d2">
									<gml:exterior>
										<gml:LinearRing gml:id="line_aec784e1-7742-4086-978a-22a9b1523121">
											<gml:posList>35.66851365143185 139.74808089702555 28.78846009016317 35.66851072947919 139.74807942246645 37.902504279616295 35.66851365143185 139.74808089702555 27.52912171125692 35.66851365143185 139.74808089702555 28.78846009016317</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_fa2f8a6b-c144-4b70-8afd-45a9f89b63e5">
									<gml:exterior>
										<gml:LinearRing gml:id="line_d396d67e-a6a7-4793-a4b4-3d7d7ed923b3">
											<gml:posList>35.66851365143185 139.74808089702555 27.52912171125692 35.66851072947919 139.74807942246645 37.902504279616295 35.66851365143185 139.74808089702555 25.771873786452232 35.66851365143185 139.74808089702555 27.52912171125692</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_21441fcc-f238-42de-bbe9-fcaadde66414">
									<gml:exterior>
										<gml:LinearRing gml:id="line_970357c3-ac4d-4dec-99db-2ece2d7db1f1">
											<gml:posList>35.66851365143185 139.74808089702555 28.78846009016317 35.66851365143185 139.74808089702555 27.52912171125692 35.668521921422965 139.74808507009323 27.52912171125692 35.66851365143185 139.74808089702555 28.78846009016317</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_7f5d5513-285c-4934-8835-d1d6bb97ca30">
									<gml:exterior>
										<gml:LinearRing gml:id="line_89f8ed3a-33d1-464c-80d6-50f2df421485">
											<gml:posList>35.66851365143185 139.74808089702555 28.78846009016317 35.668521921422965 139.74808507009323 27.52912171125692 35.668521921422965 139.74808507009323 28.78846009016317 35.66851365143185 139.74808089702555 28.78846009016317</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_b2a4408e-04d8-44f0-abc4-c4ccb912d5c8">
									<gml:exterior>
										<gml:LinearRing gml:id="line_d5466688-b47f-4b2e-aa2c-eaa4f599c831">
											<gml:posList>35.668521921422965 139.74808507009323 27.52912171125692 35.66855062072753 139.74809955179325 28.78846009016317 35.668521921422965 139.74808507009323 28.78846009016317 35.668521921422965 139.74808507009323 27.52912171125692</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_48d96acb-7435-4aba-994d-d796a5c6fce4">
									<gml:exterior>
										<gml:LinearRing gml:id="line_d4a294ec-f369-41aa-8787-2ce762ae85da">
											<gml:posList>35.66851365143185 139.74808089702555 25.771873786452232 35.66851072947919 139.74807942246645 37.902504279616295 35.66851365143185 139.74808089702555 24.447136237624107 35.66851365143185 139.74808089702555 25.771873786452232</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_ca142917-5f6e-4ef1-8732-e9d69a461bbf">
									<gml:exterior>
										<gml:LinearRing gml:id="line_d6f7c79c-4f4e-4315-bcd8-f1bb2771aaf5">
											<gml:posList>35.66851365143185 139.74808089702555 24.447136237624107 35.66851072947919 139.74807942246645 37.902504279616295 35.66851365143185 139.74808089702555 22.68988831281942 35.66851365143185 139.74808089702555 24.447136237624107</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_cb247e62-1c11-420e-83cf-bdc0d68c049a">
									<gml:exterior>
										<gml:LinearRing gml:id="line_aef33487-c134-41b0-922e-ac61c307bd12">
											<gml:posList>35.66851365143185 139.74808089702555 25.771873786452232 35.66851365143185 139.74808089702555 24.447136237624107 35.668521921422965 139.74808507009323 24.447136237624107 35.66851365143185 139.74808089702555 25.771873786452232</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_3a0e6916-42a5-4a0b-b3c8-dd15934e2232">
									<gml:exterior>
										<gml:LinearRing gml:id="line_01906319-8012-4728-b1f8-c7c88eeca51c">
											<gml:posList>35.66851365143185 139.74808089702555 25.771873786452232 35.668521921422965 139.74808507009323 24.447136237624107 35.668521921422965 139.74808507009323 25.771873786452232 35.66851365143185 139.74808089702555 25.771873786452232</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_63e97109-a43e-4348-9b62-48881f83fd67">
									<gml:exterior>
										<gml:LinearRing gml:id="line_4dc7c36c-f375-404b-986b-4e2470132da9">
											<gml:posList>35.668521921422965 139.74808507009323 24.447136237624107 35.66855062072753 139.74809955179325 25.771873786452232 35.668521921422965 139.74808507009323 25.771873786452232 35.668521921422965 139.74808507009323 24.447136237624107</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_04207cf4-6c0c-4861-9473-4c8afaa10612">
									<gml:exterior>
										<gml:LinearRing gml:id="line_f7141ed9-c5cd-4037-bafa-07361152fd93">
											<gml:posList>35.66851365143185 139.74808089702555 22.68988831281942 35.66851072947919 139.74807942246645 37.902504279616295 35.66851072947919 139.74807942246645 6.3942492747334825 35.66851365143185 139.74808089702555 22.68988831281942</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_aacfece6-3541-4885-aa8a-f6fde33975d5">
									<gml:exterior>
										<gml:LinearRing gml:id="line_deb1e040-505f-45b0-a6e9-63f8b6a29baa">
											<gml:posList>35.66851365143185 139.74808089702555 22.68988831281942 35.66851072947919 139.74807942246645 6.3942492747334825 35.66851365143185 139.74808089702555 21.43054993391317 35.66851365143185 139.74808089702555 22.68988831281942</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_46861e27-6e54-4aea-9f05-da46af2b3b30">
									<gml:exterior>
										<gml:LinearRing gml:id="line_c384f56e-a644-4466-89b9-93ebb70c1c55">
											<gml:posList>35.66851365143185 139.74808089702555 22.68988831281942 35.66851365143185 139.74808089702555 21.43054993391317 35.668521921422965 139.74808507009323 22.68988831281942 35.66851365143185 139.74808089702555 22.68988831281942</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_f33f0961-a42f-4080-b8d1-7d511bef6250">
									<gml:exterior>
										<gml:LinearRing gml:id="line_8de24fc8-9016-446b-abae-365f0922666d">
											<gml:posList>35.668521921422965 139.74808507009323 22.68988831281942 35.668521921422965 139.74808507009323 21.43054993391317 35.66855062072753 139.74809955179325 22.68988831281942 35.668521921422965 139.74808507009323 22.68988831281942</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_7bdbf9c8-c6e5-4104-a699-ed400d684a01">
									<gml:exterior>
										<gml:LinearRing gml:id="line_5f6072f6-49cc-4d78-9dac-7543f201730f">
											<gml:posList>35.668521921422965 139.74808507009323 21.43054993391317 35.668521921422965 139.74808507009323 22.68988831281942 35.66851365143185 139.74808089702555 21.43054993391317 35.668521921422965 139.74808507009323 21.43054993391317</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_52a0bebf-8944-4ca9-bd8a-ad127a1ce671">
									<gml:exterior>
										<gml:LinearRing gml:id="line_6a7646fb-4578-4e1b-a1b4-e02b000d82e6">
											<gml:posList>35.66851365143185 139.74808089702555 21.43054993391317 35.66851072947919 139.74807942246645 6.3942492747334825 35.66851365143185 139.74808089702555 19.673309638503014 35.66851365143185 139.74808089702555 21.43054993391317</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_bde82156-b983-4189-8f17-65a076947560">
									<gml:exterior>
										<gml:LinearRing gml:id="line_8244944d-f9a1-4b12-ac4b-f820ce368774">
											<gml:posList>35.66851365143185 139.74808089702555 19.673309638503014 35.66851072947919 139.74807942246645 6.3942492747334825 35.66851365143185 139.74808089702555 18.413971259596764 35.66851365143185 139.74808089702555 19.673309638503014</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_fccb7e42-0147-4c03-9a9e-2c16e2cc9ebe">
									<gml:exterior>
										<gml:LinearRing gml:id="line_72dafe87-29ea-4983-8b78-eb183a8d6250">
											<gml:posList>35.66851365143185 139.74808089702555 19.673309638503014 35.66851365143185 139.74808089702555 18.413971259596764 35.668521921422965 139.74808507009323 18.413971259596764 35.66851365143185 139.74808089702555 19.673309638503014</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_dc5bd5a6-28ab-4c7f-bd59-f70f45511ee5">
									<gml:exterior>
										<gml:LinearRing gml:id="line_c23799e7-a822-4f68-b2ab-5f99f62afcac">
											<gml:posList>35.66855062072753 139.74809955179325 18.413971259596764 35.668521921422965 139.74808507009323 19.673309638503014 35.668521921422965 139.74808507009323 18.413971259596764 35.66855062072753 139.74809955179325 18.413971259596764</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_969452f9-51cd-4d40-92d7-9d9729694bde">
									<gml:exterior>
										<gml:LinearRing gml:id="line_38d41f85-1e1f-4b38-bb4a-3ec851dda5d6">
											<gml:posList>35.668521921422965 139.74808507009323 18.413971259596764 35.668521921422965 139.74808507009323 19.673309638503014 35.66851365143185 139.74808089702555 19.673309638503014 35.668521921422965 139.74808507009323 18.413971259596764</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_26ce292d-bbed-40e7-a784-f78ef8fb1f9f">
									<gml:exterior>
										<gml:LinearRing gml:id="line_189324aa-ef7f-4e63-bea8-2fe9504a91e5">
											<gml:posList>35.66851365143185 139.74808089702555 18.413971259596764 35.66851072947919 139.74807942246645 6.3942492747334825 35.66851365143185 139.74808089702555 16.656730964186607 35.66851365143185 139.74808089702555 18.413971259596764</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_618f350d-01a6-4168-9ae2-662ac8c3f807">
									<gml:exterior>
										<gml:LinearRing gml:id="line_ebf87a21-4a03-4dfa-ae9a-95975e34db14">
											<gml:posList>35.66851365143185 139.74808089702555 16.656730964186607 35.66851072947919 139.74807942246645 6.3942492747334825 35.66851365143185 139.74808089702555 15.397392585280357 35.66851365143185 139.74808089702555 16.656730964186607</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_30912bf0-909c-4d1a-8cd7-2d541626c2c8">
									<gml:exterior>
										<gml:LinearRing gml:id="line_3befcf56-6325-4a4a-be9c-d675c83a8043">
											<gml:posList>35.66851365143185 139.74808089702555 16.656730964186607 35.66851365143185 139.74808089702555 15.397392585280357 35.668521921422965 139.74808507009323 15.397392585280357 35.66851365143185 139.74808089702555 16.656730964186607</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_e05488bf-7a50-4e6d-9f40-0975995b7bda">
									<gml:exterior>
										<gml:LinearRing gml:id="line_dbba5164-4a58-49fd-b14e-edb474e4a468">
											<gml:posList>35.66851365143185 139.74808089702555 16.656730964186607 35.668521921422965 139.74808507009323 15.397392585280357 35.668521921422965 139.74808507009323 16.656730964186607 35.66851365143185 139.74808089702555 16.656730964186607</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_59467dea-e0c4-428e-a6a2-6bc000c25990">
									<gml:exterior>
										<gml:LinearRing gml:id="line_de440ce4-1b99-4c34-afbb-a72db56f48ac">
											<gml:posList>35.66855062072753 139.74809955179325 15.397392585280357 35.668521921422965 139.74808507009323 16.656730964186607 35.668521921422965 139.74808507009323 15.397392585280357 35.66855062072753 139.74809955179325 15.397392585280357</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_968a1d0f-892a-4aa5-858d-92514f322890">
									<gml:exterior>
										<gml:LinearRing gml:id="line_9a685883-4753-462e-9e61-d286411be02f">
											<gml:posList>35.66851365143185 139.74808089702555 15.397392585280357 35.66851072947919 139.74807942246645 6.3942492747334825 35.6685122320758 139.74808018068603 9.23169739485067 35.66851365143185 139.74808089702555 15.397392585280357</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_58f30653-1709-4781-aeeb-4f1cf6eef228">
									<gml:exterior>
										<gml:LinearRing gml:id="line_09d1b69b-3ac1-4545-820a-1fca1320cd78">
											<gml:posList>35.66851365143185 139.74808089702555 15.397392585280357 35.6685122320758 139.74808018068603 9.23169739485067 35.66851365143185 139.74808089702555 13.64014466047567 35.66851365143185 139.74808089702555 15.397392585280357</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_df664965-8ad3-474e-9b0a-bfa63f8cdf0d">
									<gml:exterior>
										<gml:LinearRing gml:id="line_113a6341-90f5-438c-8fdd-031ecc46e080">
											<gml:posList>35.6685122320758 139.74808018068603 9.23169739485067 35.66851072947919 139.74807942246645 6.3942492747334825 35.6685122320758 139.74808018068603 6.3942492747334825 35.6685122320758 139.74808018068603 9.23169739485067</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_cad2e786-b7af-49e1-956d-7a695d1d901c">
									<gml:exterior>
										<gml:LinearRing gml:id="line_96d0684f-4e71-4034-857c-3522947c7e63">
											<gml:posList>35.668521921422965 139.74808507009323 13.64014466047567 35.66855062072753 139.74809955179325 15.397392585280357 35.668521921422965 139.74808507009323 15.397392585280357 35.668521921422965 139.74808507009323 13.64014466047567</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_f15dd004-ec7a-4023-82fd-fad7145aa71c">
									<gml:exterior>
										<gml:LinearRing gml:id="line_5d484669-3ab8-4e37-abeb-5c9d6550dd35">
											<gml:posList>35.66855062072753 139.74809955179325 15.397392585280357 35.668521921422965 139.74808507009323 13.64014466047567 35.66855062072753 139.74809955179325 13.64014466047567 35.66855062072753 139.74809955179325 15.397392585280357</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
					<bldg:opening>
						<bldg:Window gml:id="wnd_c7de40dd-a96d-4a4e-a4ed-369d17f08847">
							<bldg:lod3MultiSurface>
								<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_a0f06783-7aa6-4395-b308-b88b9a5dd8e9">
											<gml:exterior>
												<gml:LinearRing gml:id="line_21a17c16-7a22-4709-983e-8129cea3e36d">
													<gml:posList>35.66855062072753 139.74809955179325 33.58221466779989 35.66855062072753 139.74809955179325 31.8249667429952 35.66855889071795 139.74810372486473 33.58221466779989 35.66855062072753 139.74809955179325 33.58221466779989</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_d2862cec-5890-4102-af81-2d0e2b3dbf90">
											<gml:exterior>
												<gml:LinearRing gml:id="line_9aab9295-2086-4070-ac6b-d46d58eb638c">
													<gml:posList>35.66855889071795 139.74810372486473 33.58221466779989 35.66855062072753 139.74809955179325 31.8249667429952 35.66855889071795 139.74810372486473 31.8249667429952 35.66855889071795 139.74810372486473 33.58221466779989</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
								</gml:MultiSurface>
							</bldg:lod3MultiSurface>
						</bldg:Window>
					</bldg:opening>
					<bldg:opening>
						<bldg:Window gml:id="wnd_2491cdce-f731-40ad-a2e9-548741778e2e">
							<bldg:lod3MultiSurface>
								<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_03686811-019f-4478-8b35-bab451076e73">
											<gml:exterior>
												<gml:LinearRing gml:id="line_8549d3f8-c353-43d2-bef5-cba1b62bef98">
													<gml:posList>35.66855062072753 139.74809955179325 21.43054993391317 35.66855062072753 139.74809955179325 19.673309638503014 35.66855889071795 139.74810372486473 21.43054993391317 35.66855062072753 139.74809955179325 21.43054993391317</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_5038b1db-0f18-4662-a867-79230e4925db">
											<gml:exterior>
												<gml:LinearRing gml:id="line_e7eca83a-8a9a-477d-85af-f830104d5d4e">
													<gml:posList>35.66855889071795 139.74810372486473 21.43054993391317 35.66855062072753 139.74809955179325 19.673309638503014 35.66855889071795 139.74810372486473 19.673309638503014 35.66855889071795 139.74810372486473 21.43054993391317</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
								</gml:MultiSurface>
							</bldg:lod3MultiSurface>
						</bldg:Window>
					</bldg:opening>
					<bldg:opening>
						<bldg:Window gml:id="wnd_412985c5-3c4d-475a-9c27-43af4ec390fa">
							<bldg:lod3MultiSurface>
								<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_0c624d2d-453a-4707-b2e8-c6eb4032a341">
											<gml:exterior>
												<gml:LinearRing gml:id="line_ad192747-2b3b-4595-af26-781b1f16f3d7">
													<gml:posList>35.66851365143185 139.74808089702555 27.52912171125692 35.66851365143185 139.74808089702555 25.771873786452232 35.668521921422965 139.74808507009323 27.52912171125692 35.66851365143185 139.74808089702555 27.52912171125692</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_6534cccb-f4ff-4e14-b1f8-673558a1a4c7">
											<gml:exterior>
												<gml:LinearRing gml:id="line_b10bffa2-e416-424d-b269-c98542f54d0c">
													<gml:posList>35.668521921422965 139.74808507009323 27.52912171125692 35.66851365143185 139.74808089702555 25.771873786452232 35.668521921422965 139.74808507009323 25.771873786452232 35.668521921422965 139.74808507009323 27.52912171125692</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
								</gml:MultiSurface>
							</bldg:lod3MultiSurface>
						</bldg:Window>
					</bldg:opening>
					<bldg:opening>
						<bldg:Window gml:id="wnd_72e48445-5524-405f-8822-11bed2431622">
							<bldg:lod3MultiSurface>
								<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_b5eb19f7-8cf4-4a02-8207-eda9252d932d">
											<gml:exterior>
												<gml:LinearRing gml:id="line_31bc635f-8134-41ca-aede-4172f4450f86">
													<gml:posList>35.66851365143185 139.74808089702555 15.397392585280357 35.66851365143185 139.74808089702555 13.64014466047567 35.668521921422965 139.74808507009323 15.397392585280357 35.66851365143185 139.74808089702555 15.397392585280357</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_831eee7c-8448-42b5-b6d4-219ca6356c01">
											<gml:exterior>
												<gml:LinearRing gml:id="line_9253d934-204d-47b4-b11b-4bf5f4c64a98">
													<gml:posList>35.668521921422965 139.74808507009323 15.397392585280357 35.66851365143185 139.74808089702555 13.64014466047567 35.668521921422965 139.74808507009323 13.64014466047567 35.668521921422965 139.74808507009323 15.397392585280357</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
								</gml:MultiSurface>
							</bldg:lod3MultiSurface>
						</bldg:Window>
					</bldg:opening>
					<bldg:opening>
						<bldg:Window gml:id="wnd_4f9dbaa1-df94-4549-9db5-caa886a1b7f4">
							<bldg:lod3MultiSurface>
								<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_7cdccf49-c98c-4632-bcc2-56af3b11e0ec">
											<gml:exterior>
												<gml:LinearRing gml:id="line_99868b5a-c9e7-454b-ba54-269e7667654a">
													<gml:posList>35.66855062072753 139.74809955179325 27.52912171125692 35.66855062072753 139.74809955179325 25.771873786452232 35.66855889071795 139.74810372486473 27.52912171125692 35.66855062072753 139.74809955179325 27.52912171125692</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_e10aa534-68c4-49b0-a6f8-ba027fdd9cde">
											<gml:exterior>
												<gml:LinearRing gml:id="line_05c3d3e5-e320-49de-97f5-ba3d0c5b1f91">
													<gml:posList>35.66855889071795 139.74810372486473 27.52912171125692 35.66855062072753 139.74809955179325 25.771873786452232 35.66855889071795 139.74810372486473 25.771873786452232 35.66855889071795 139.74810372486473 27.52912171125692</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
								</gml:MultiSurface>
							</bldg:lod3MultiSurface>
						</bldg:Window>
					</bldg:opening>
					<bldg:opening>
						<bldg:Window gml:id="wnd_54f61b52-d6db-4c87-8a5f-cc86503ad648">
							<bldg:lod3MultiSurface>
								<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_a03e5577-32dc-4d1e-bcaa-6376fe4cc3fb">
											<gml:exterior>
												<gml:LinearRing gml:id="line_3e1a2d80-11d7-4270-ab95-cdbf3b936735">
													<gml:posList>35.66851365143185 139.74808089702555 21.43054993391317 35.66851365143185 139.74808089702555 19.673309638503014 35.668521921422965 139.74808507009323 21.43054993391317 35.66851365143185 139.74808089702555 21.43054993391317</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_2724ca4a-98c7-47ad-b418-9d602632b3d7">
											<gml:exterior>
												<gml:LinearRing gml:id="line_2cc9a62d-8361-4696-a08b-0919dd9a6634">
													<gml:posList>35.668521921422965 139.74808507009323 21.43054993391317 35.66851365143185 139.74808089702555 19.673309638503014 35.668521921422965 139.74808507009323 19.673309638503014 35.668521921422965 139.74808507009323 21.43054993391317</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
								</gml:MultiSurface>
							</bldg:lod3MultiSurface>
						</bldg:Window>
					</bldg:opening>
					<bldg:opening>
						<bldg:Window gml:id="wnd_6c313158-7094-42b3-94aa-349aad43d922">
							<bldg:lod3MultiSurface>
								<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_092d8fc2-30dc-4485-aa95-af1f2599e08e">
											<gml:exterior>
												<gml:LinearRing gml:id="line_6000ef76-0634-45b7-8eb7-0f1648b85fb0">
													<gml:posList>35.66851365143185 139.74808089702555 33.58221466779989 35.66851365143185 139.74808089702555 31.8249667429952 35.668521921422965 139.74808507009323 33.58221466779989 35.66851365143185 139.74808089702555 33.58221466779989</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_6fddd394-8e1b-41ae-98f9-7580b42c3891">
											<gml:exterior>
												<gml:LinearRing gml:id="line_441b562b-87f2-435b-95f7-2d70a3c4777a">
													<gml:posList>35.668521921422965 139.74808507009323 33.58221466779989 35.66851365143185 139.74808089702555 31.8249667429952 35.668521921422965 139.74808507009323 31.8249667429952 35.668521921422965 139.74808507009323 33.58221466779989</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
								</gml:MultiSurface>
							</bldg:lod3MultiSurface>
						</bldg:Window>
					</bldg:opening>
					<bldg:opening>
						<bldg:Window gml:id="wnd_d7f01567-3b76-48ee-b0bd-8d11ee832b70">
							<bldg:lod3MultiSurface>
								<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_25c25a84-dec2-4da2-b537-4463bfa568a3">
											<gml:exterior>
												<gml:LinearRing gml:id="line_d1527a3c-c112-4e40-8fe7-60bd25a870b0">
													<gml:posList>35.66851365143185 139.74808089702555 30.545700385573326 35.66851365143185 139.74808089702555 28.78846009016317 35.668521921422965 139.74808507009323 30.545700385573326 35.66851365143185 139.74808089702555 30.545700385573326</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_ad6d983c-6a29-4c1c-956e-cb2ad845ff33">
											<gml:exterior>
												<gml:LinearRing gml:id="line_2e1e36ae-ebf3-486a-80a4-89e2101ec62b">
													<gml:posList>35.668521921422965 139.74808507009323 30.545700385573326 35.66851365143185 139.74808089702555 28.78846009016317 35.668521921422965 139.74808507009323 28.78846009016317 35.668521921422965 139.74808507009323 30.545700385573326</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
								</gml:MultiSurface>
							</bldg:lod3MultiSurface>
						</bldg:Window>
					</bldg:opening>
					<bldg:opening>
						<bldg:Window gml:id="wnd_3b3762fa-234a-4a3d-8521-bbf1632c0541">
							<bldg:lod3MultiSurface>
								<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_9105cb46-2c6f-4436-bf79-a9b984535fa9">
											<gml:exterior>
												<gml:LinearRing gml:id="line_2499de02-e6bb-4fc9-8d74-20c20bc13514">
													<gml:posList>35.66851365143185 139.74808089702555 36.598793342116295 35.66851365143185 139.74808089702555 34.84155304670614 35.668521921422965 139.74808507009323 36.598793342116295 35.66851365143185 139.74808089702555 36.598793342116295</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_83ba6ec6-9dc0-40c4-8a8c-e8fca56b9b6c">
											<gml:exterior>
												<gml:LinearRing gml:id="line_7c97130c-edd9-48ef-84de-342539ef419f">
													<gml:posList>35.668521921422965 139.74808507009323 36.598793342116295 35.66851365143185 139.74808089702555 34.84155304670614 35.668521921422965 139.74808507009323 34.84155304670614 35.668521921422965 139.74808507009323 36.598793342116295</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
								</gml:MultiSurface>
							</bldg:lod3MultiSurface>
						</bldg:Window>
					</bldg:opening>
					<bldg:opening>
						<bldg:Window gml:id="wnd_c81513c7-9053-45e4-8dfc-3d580bd658b2">
							<bldg:lod3MultiSurface>
								<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_8999f27b-e896-474d-82aa-783b3c46b0ae">
											<gml:exterior>
												<gml:LinearRing gml:id="line_2ab1cf3b-b289-42ae-9d99-98015820f22f">
													<gml:posList>35.66855062072753 139.74809955179325 36.598793342116295 35.66855062072753 139.74809955179325 34.84155304670614 35.66855889071795 139.74810372486473 36.598793342116295 35.66855062072753 139.74809955179325 36.598793342116295</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_221a4da2-781e-4938-93bb-82dcd02bd652">
											<gml:exterior>
												<gml:LinearRing gml:id="line_eb3c0ba4-0042-491b-884e-a076bef9d3c0">
													<gml:posList>35.66855889071795 139.74810372486473 36.598793342116295 35.66855062072753 139.74809955179325 34.84155304670614 35.66855889071795 139.74810372486473 34.84155304670614 35.66855889071795 139.74810372486473 36.598793342116295</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
								</gml:MultiSurface>
							</bldg:lod3MultiSurface>
						</bldg:Window>
					</bldg:opening>
					<bldg:opening>
						<bldg:Window gml:id="wnd_d0a3165d-738c-4272-b2e3-49f2f61c9f15">
							<bldg:lod3MultiSurface>
								<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_9fdaeb86-c879-48d6-9461-c153a16fa3bf">
											<gml:exterior>
												<gml:LinearRing gml:id="line_cf366e9d-90d4-4135-97ce-ca66111f1b91">
													<gml:posList>35.66855062072753 139.74809955179325 30.545700385573326 35.66855062072753 139.74809955179325 28.78846009016317 35.66855889071795 139.74810372486473 30.545700385573326 35.66855062072753 139.74809955179325 30.545700385573326</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_1735eccd-211b-410d-b036-97ddcfa5290d">
											<gml:exterior>
												<gml:LinearRing gml:id="line_24310cbe-e882-4114-9eda-fdf368478b85">
													<gml:posList>35.66855889071795 139.74810372486473 30.545700385573326 35.66855062072753 139.74809955179325 28.78846009016317 35.66855889071795 139.74810372486473 28.78846009016317 35.66855889071795 139.74810372486473 30.545700385573326</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
								</gml:MultiSurface>
							</bldg:lod3MultiSurface>
						</bldg:Window>
					</bldg:opening>
					<bldg:opening>
						<bldg:Window gml:id="wnd_4e74ed74-b20e-4687-959f-892fc2d9e5c0">
							<bldg:lod3MultiSurface>
								<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_6a3ae9f7-1c3d-4a34-8a5d-e1472098db88">
											<gml:exterior>
												<gml:LinearRing gml:id="line_bc8dc301-e3bb-46e7-b980-1863cac190bb">
													<gml:posList>35.66855062072753 139.74809955179325 24.447136237624107 35.66855062072753 139.74809955179325 22.68988831281942 35.66855889071795 139.74810372486473 24.447136237624107 35.66855062072753 139.74809955179325 24.447136237624107</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_b4c6c5cb-916c-46f2-9fdc-58d974ac0732">
											<gml:exterior>
												<gml:LinearRing gml:id="line_744536ee-35b2-4b7d-a76e-276fe4fef566">
													<gml:posList>35.66855889071795 139.74810372486473 24.447136237624107 35.66855062072753 139.74809955179325 22.68988831281942 35.66855889071795 139.74810372486473 22.68988831281942 35.66855889071795 139.74810372486473 24.447136237624107</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
								</gml:MultiSurface>
							</bldg:lod3MultiSurface>
						</bldg:Window>
					</bldg:opening>
					<bldg:opening>
						<bldg:Window gml:id="wnd_ef7fb9d8-10b0-4a76-82c0-c6c60daa9b68">
							<bldg:lod3MultiSurface>
								<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_ac21b73f-4247-4f53-9abe-df7f61407f73">
											<gml:exterior>
												<gml:LinearRing gml:id="line_88ca04b7-7164-4764-9414-1840571183e8">
													<gml:posList>35.66851365143185 139.74808089702555 18.413971259596764 35.66851365143185 139.74808089702555 16.656730964186607 35.668521921422965 139.74808507009323 18.413971259596764 35.66851365143185 139.74808089702555 18.413971259596764</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_65b9a3ef-838c-4973-b92c-453efdc70cf6">
											<gml:exterior>
												<gml:LinearRing gml:id="line_97adfbb7-302f-4909-9d80-20638e0a930f">
													<gml:posList>35.668521921422965 139.74808507009323 18.413971259596764 35.66851365143185 139.74808089702555 16.656730964186607 35.668521921422965 139.74808507009323 16.656730964186607 35.668521921422965 139.74808507009323 18.413971259596764</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
								</gml:MultiSurface>
							</bldg:lod3MultiSurface>
						</bldg:Window>
					</bldg:opening>
					<bldg:opening>
						<bldg:Window gml:id="wnd_cc13388f-5206-4338-894e-53b821fa259a">
							<bldg:lod3MultiSurface>
								<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_cf9bb05b-118b-42c9-99d6-13a61c92db08">
											<gml:exterior>
												<gml:LinearRing gml:id="line_ff3573c9-2aee-4e45-b3f0-1efe26b99af3">
													<gml:posList>35.66855062072753 139.74809955179325 18.413971259596764 35.66855062072753 139.74809955179325 16.656730964186607 35.66855889071795 139.74810372486473 18.413971259596764 35.66855062072753 139.74809955179325 18.413971259596764</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_3eba90a6-e0c3-4704-a148-e8e0202a687a">
											<gml:exterior>
												<gml:LinearRing gml:id="line_30a169e5-2134-4fbb-9fca-0bad32b12dd8">
													<gml:posList>35.66855889071795 139.74810372486473 18.413971259596764 35.66855062072753 139.74809955179325 16.656730964186607 35.66855889071795 139.74810372486473 16.656730964186607 35.66855889071795 139.74810372486473 18.413971259596764</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
								</gml:MultiSurface>
							</bldg:lod3MultiSurface>
						</bldg:Window>
					</bldg:opening>
					<bldg:opening>
						<bldg:Window gml:id="wnd_0ceb6726-9c3e-440d-839f-4c415a8c3931">
							<bldg:lod3MultiSurface>
								<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_20e46824-1d82-4f68-9a96-8d8892c5d1c5">
											<gml:exterior>
												<gml:LinearRing gml:id="line_282aa30b-5805-46a8-b109-9eb9b5e8f05e">
													<gml:posList>35.66851365143185 139.74808089702555 24.447136237624107 35.66851365143185 139.74808089702555 22.68988831281942 35.668521921422965 139.74808507009323 24.447136237624107 35.66851365143185 139.74808089702555 24.447136237624107</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_c4f256a6-8c20-4d7e-85e4-aa47c97496e9">
											<gml:exterior>
												<gml:LinearRing gml:id="line_667d9af2-8e2a-46dd-aa39-f96fc4a2b3bd">
													<gml:posList>35.668521921422965 139.74808507009323 24.447136237624107 35.66851365143185 139.74808089702555 22.68988831281942 35.668521921422965 139.74808507009323 22.68988831281942 35.668521921422965 139.74808507009323 24.447136237624107</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
								</gml:MultiSurface>
							</bldg:lod3MultiSurface>
						</bldg:Window>
					</bldg:opening>
					<bldg:opening>
						<bldg:Window gml:id="wnd_8bbb67ec-c45c-4647-9f76-dddd3a48cf15">
							<bldg:lod3MultiSurface>
								<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_40af74ca-cc3f-454a-a932-b64a986cbcd6">
											<gml:exterior>
												<gml:LinearRing gml:id="line_311ece8e-8dbd-42e1-8fcc-e19da40bed46">
													<gml:posList>35.66855062072753 139.74809955179325 15.397392585280357 35.66855062072753 139.74809955179325 13.64014466047567 35.66855889071795 139.74810372486473 15.397392585280357 35.66855062072753 139.74809955179325 15.397392585280357</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_9b1d005b-bde6-487b-af3e-018154320e0d">
											<gml:exterior>
												<gml:LinearRing gml:id="line_77adf5a1-9f9b-4988-87b7-ba8edb841004">
													<gml:posList>35.66855889071795 139.74810372486473 15.397392585280357 35.66855062072753 139.74809955179325 13.64014466047567 35.66855889071795 139.74810372486473 13.64014466047567 35.66855889071795 139.74810372486473 15.397392585280357</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
								</gml:MultiSurface>
							</bldg:lod3MultiSurface>
						</bldg:Window>
					</bldg:opening>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_8365fbc4-6a00-42c9-a1cc-331cb829ef8b">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_e8657e66-8e7e-4392-a5ea-0696f46a7402">
									<gml:exterior>
										<gml:LinearRing gml:id="line_b6925ee4-329d-4855-bc61-ccb0cacbf09d">
											<gml:posList>35.668669312220906 139.74783302287355 27.262848212721764 35.668670915971305 139.74782825021657 27.3664706492452 35.668669312220906 139.74783302287355 27.3664706492452 35.668669312220906 139.74783302287355 27.262848212721764</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_437b9dc1-2ad0-4f41-90da-0d72fb401424">
									<gml:exterior>
										<gml:LinearRing gml:id="line_107d6bfb-035c-474c-b8c9-fe963bc0651a">
											<gml:posList>35.668670915971305 139.74782825021657 27.3664706492452 35.668669312220906 139.74783302287355 27.262848212721764 35.668669312220906 139.74783302287355 25.997948005202232 35.668670915971305 139.74782825021657 27.3664706492452</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_828eafb3-6a23-4644-8d67-f0ce236babe0">
									<gml:exterior>
										<gml:LinearRing gml:id="line_065aad45-f979-4ecd-b0ba-2930f9bb62bd">
											<gml:posList>35.668670915971305 139.74782825021657 27.3664706492452 35.668669312220906 139.74783302287355 25.997948005202232 35.668670915971305 139.74782825021657 25.2079013133077 35.668670915971305 139.74782825021657 27.3664706492452</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_173ca19c-d27d-4266-814a-bd9a6b4726f5">
									<gml:exterior>
										<gml:LinearRing gml:id="line_4a51a103-d263-4fe5-a6b8-ee94530a2ecc">
											<gml:posList>35.668670915971305 139.74782825021657 25.2079013133077 35.668669312220906 139.74783302287355 25.997948005202232 35.668669312220906 139.74783302287355 25.2079013133077 35.668670915971305 139.74782825021657 25.2079013133077</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_49c7affc-2367-4675-b68f-a88c965c2608">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_1edd78fa-3bd3-41f1-97e6-e6dc276eed7b">
									<gml:exterior>
										<gml:LinearRing gml:id="line_16c61bd7-1403-4946-a0b5-d98bd19488d9">
											<gml:posList>35.668690275854296 139.74782351812135 12.067657783034264 35.668690275854296 139.74782351812135 10.359085395338951 35.66868610967223 139.747835916983 12.067657783034264 35.668690275854296 139.74782351812135 12.067657783034264</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_8786edbd-f323-47da-a0e2-ba0975c59c00">
									<gml:exterior>
										<gml:LinearRing gml:id="line_9974f351-14a5-4802-a124-6e41769c7054">
											<gml:posList>35.66868610967223 139.747835916983 12.067657783034264 35.668690275854296 139.74782351812135 10.359085395338951 35.66868610967223 139.747835916983 10.359085395338951 35.66868610967223 139.747835916983 12.067657783034264</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_65eabb14-48e7-403d-98f0-83110962559a">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_b9d66ab2-8615-44f8-a1fe-8c5595c1de46">
									<gml:exterior>
										<gml:LinearRing gml:id="line_80d6bb42-9971-4c74-b295-17edc3e36057">
											<gml:posList>35.66867316936178 139.74783496920924 24.203087165358482 35.6686747729746 139.74783019638366 24.30670960188192 35.6686747729746 139.74783019638366 23.199493720534264 35.66867316936178 139.74783496920924 24.203087165358482</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_27c942d4-8b44-43d6-b6e1-0b3f2caaa921">
									<gml:exterior>
										<gml:LinearRing gml:id="line_525bed40-b5bc-48f7-b2db-7622c3202cf1">
											<gml:posList>35.6686747729746 139.74783019638366 24.30670960188192 35.66867316936178 139.74783496920924 24.203087165358482 35.66867316936178 139.74783496920924 24.30670960188192 35.6686747729746 139.74783019638366 24.30670960188192</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_79d5fe9a-9ac3-4c68-823a-a64b80a8368f">
									<gml:exterior>
										<gml:LinearRing gml:id="line_77ea6be8-a8ce-4874-8673-13dee663b15d">
											<gml:posList>35.66867316936178 139.74783496920924 24.203087165358482 35.6686747729746 139.74783019638366 23.199493720534264 35.66867316936178 139.74783496920924 22.93818695783895 35.66867316936178 139.74783496920924 24.203087165358482</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_5b964c5a-e124-4da2-861f-7024d09936b0">
									<gml:exterior>
										<gml:LinearRing gml:id="line_13b6dfbf-64eb-4512-9367-9e5855238764">
											<gml:posList>35.66867316936178 139.74783496920924 22.93818695783895 35.6686747729746 139.74783019638366 23.199493720534264 35.6686747729746 139.74783019638366 22.598137214186607 35.66867316936178 139.74783496920924 22.93818695783895</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_e81fc049-fdda-47b0-8471-c191765a0cb2">
									<gml:exterior>
										<gml:LinearRing gml:id="line_0eeb00ab-aec9-4770-9999-88d01b36b8ba">
											<gml:posList>35.66867316936178 139.74783496920924 22.93818695783895 35.6686747729746 139.74783019638366 22.598137214186607 35.66867316936178 139.74783496920924 22.14813263654989 35.66867316936178 139.74783496920924 22.93818695783895</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_4fcdb1c8-3d20-4929-bb6b-c3945216271c">
									<gml:exterior>
										<gml:LinearRing gml:id="line_8c2d81ac-ed7a-470b-bc69-a7046cc794b3">
											<gml:posList>35.66867316936178 139.74783496920924 22.14813263654989 35.6686747729746 139.74783019638366 22.598137214186607 35.6686747729746 139.74783019638366 22.14813263654989 35.66867316936178 139.74783496920924 22.14813263654989</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
					<bldg:opening>
						<bldg:Window gml:id="wnd_8f4371a8-7e96-4c9d-b6d7-3999419361cd">
							<bldg:lod3MultiSurface>
								<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_772c454c-7dc3-4fe3-a89d-c48dc7c4553d">
											<gml:exterior>
												<gml:LinearRing gml:id="line_3dcd1289-c1ab-40b4-a82f-158c00f7ebc4">
													<gml:posList>35.66867316936178 139.74783496920924 24.203087165358482 35.66867316936178 139.74783496920924 22.93818695783895 35.668669312220906 139.74783302287355 24.203087165358482 35.66867316936178 139.74783496920924 24.203087165358482</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_89a4c9c3-4760-4f9d-8f8c-a7d0af538623">
											<gml:exterior>
												<gml:LinearRing gml:id="line_fc52b329-acdd-4248-a68d-9fceed950a1f">
													<gml:posList>35.668669312220906 139.74783302287355 24.203087165358482 35.66867316936178 139.74783496920924 22.93818695783895 35.668669312220906 139.74783302287355 22.93818695783895 35.668669312220906 139.74783302287355 24.203087165358482</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
								</gml:MultiSurface>
							</bldg:lod3MultiSurface>
						</bldg:Window>
					</bldg:opening>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="wall_TMmnt0161_p991_5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly_TMmnt0161_p991_5">
									<gml:exterior>
										<gml:LinearRing gml:id="line_TMmnt0161_p991_5">
											<gml:posList>35.668624261631244 139.74779713516125 34.6145077 35.66867744484322 139.74782458353985 34.61713868 35.66867755368657 139.74782460828197 5.45125518 35.6686243702306 139.747797159778 5.44862419 35.668624261631244 139.74779713516125 34.6145077</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_1a343adf-6f5d-401e-8ce9-8360e13ed10a">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_1b2830b8-4d98-4d96-bdff-7bc73254acec">
									<gml:exterior>
										<gml:LinearRing gml:id="line_06cb75d3-6d7f-49ba-9f89-28db62a4535a">
											<gml:posList>35.66862642811532 139.74781138344156 22.93818695783895 35.668628031727216 139.74780661061828 22.14813263654989 35.668628031727216 139.74780661061828 24.30670960188192 35.66862642811532 139.74781138344156 22.93818695783895</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_44019daa-b5ac-4c92-a73f-16c33cc9a8d1">
									<gml:exterior>
										<gml:LinearRing gml:id="line_b8c3d892-51c8-4eca-ba7f-a99a2e1951ee">
											<gml:posList>35.668628031727216 139.74780661061828 22.14813263654989 35.66862642811532 139.74781138344156 22.93818695783895 35.66862642811532 139.74781138344156 22.14813263654989 35.668628031727216 139.74780661061828 22.14813263654989</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_96ba8ee0-8bc8-4738-9ca7-09e4784c6406">
									<gml:exterior>
										<gml:LinearRing gml:id="line_9bcffb60-b0ba-4277-912c-531c1c7cd01f">
											<gml:posList>35.66862642811532 139.74781138344156 22.93818695783895 35.668628031727216 139.74780661061828 24.30670960188192 35.66862642811532 139.74781138344156 24.203087165358482 35.66862642811532 139.74781138344156 22.93818695783895</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_62c64488-03f9-439f-91f0-e3a468ed1686">
									<gml:exterior>
										<gml:LinearRing gml:id="line_ef551eb7-6e98-4671-94f4-30438e869ab1">
											<gml:posList>35.66862642811532 139.74781138344156 24.203087165358482 35.668628031727216 139.74780661061828 24.30670960188192 35.66862642811532 139.74781138344156 24.30670960188192 35.66862642811532 139.74781138344156 24.203087165358482</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_c884342d-7c6b-4ed2-b4e0-c03fef83ce48">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_dee4f58c-14d8-4724-a0fd-1ca29e65bfa5">
									<gml:exterior>
										<gml:LinearRing gml:id="line_b35e8f2b-dffd-47fe-b1af-6896e26f8d86">
											<gml:posList>35.6686752542573 139.74783043925513 10.960441901686607 35.66868610967223 139.747835916983 12.067657783034264 35.66868610967223 139.747835916983 10.359085395338951 35.6686752542573 139.74783043925513 10.960441901686607</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_60f3b826-ebde-4838-bacb-3ae9653fb1e0">
									<gml:exterior>
										<gml:LinearRing gml:id="line_bfae028b-5e53-42d3-bb24-4f5696f99e17">
											<gml:posList>35.66868610967223 139.747835916983 12.067657783034264 35.6686752542573 139.74783043925513 10.960441901686607 35.6686747729746 139.74783019638366 12.067657783034264 35.66868610967223 139.747835916983 12.067657783034264</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_862808ca-a277-4a2a-9c62-b5eddbaeef2e">
									<gml:exterior>
										<gml:LinearRing gml:id="line_e17bcf79-c42e-4385-9c92-e9a67a5477a9">
											<gml:posList>35.6686747729746 139.74783019638366 12.067657783034264 35.6686752542573 139.74783043925513 10.960441901686607 35.6686747729746 139.74783019638366 10.960441901686607 35.6686747729746 139.74783019638366 12.067657783034264</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_639da54f-9559-4ba5-9a00-e2cd19393680">
									<gml:exterior>
										<gml:LinearRing gml:id="line_a57d3093-08ed-492c-86fb-ae0a80138414">
											<gml:posList>35.6686752542573 139.74783043925513 10.960441901686607 35.66868610967223 139.747835916983 10.359085395338951 35.6686752542573 139.74783043925513 10.359085395338951 35.6686752542573 139.74783043925513 10.960441901686607</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_944c0488-a768-4518-98ad-4b1171001da2">
									<gml:exterior>
										<gml:LinearRing gml:id="line_3d00c983-e77a-42fa-88c7-a3ad073acec1">
											<gml:posList>35.6686752542573 139.74783043925513 10.960441901686607 35.6686752542573 139.74783043925513 10.359085395338951 35.6686747729746 139.74783019638366 10.960441901686607 35.6686752542573 139.74783043925513 10.960441901686607</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_5400c6f2-522e-402e-9403-2d491cfcd880">
									<gml:exterior>
										<gml:LinearRing gml:id="line_774ddab6-8af1-4f37-b187-248f85849dd4">
											<gml:posList>35.6686747729746 139.74783019638366 10.960441901686607 35.6686752542573 139.74783043925513 10.359085395338951 35.6686747729746 139.74783019638366 10.359085395338951 35.6686747729746 139.74783019638366 10.960441901686607</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_f2859a06-92df-4f45-b46a-486ff9b60b40">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_d96aadc5-e960-4ab4-ac93-4bce2c49e7b9">
									<gml:exterior>
										<gml:LinearRing gml:id="line_cc68a044-d6af-404f-927e-49074aba6317">
											<gml:posList>35.66868526091045 139.74782098748136 10.960441901686607 35.668690275854296 139.74782351812135 10.359085395338951 35.668690275854296 139.74782351812135 12.067657783034264 35.66868526091045 139.74782098748136 10.960441901686607</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_3ee8f760-386f-45de-83d1-449d31deea2f">
									<gml:exterior>
										<gml:LinearRing gml:id="line_d69ad4a5-3ff2-487b-bbf4-c56a8cab56b6">
											<gml:posList>35.668690275854296 139.74782351812135 10.359085395338951 35.66868526091045 139.74782098748136 10.960441901686607 35.66868526091045 139.74782098748136 10.359085395338951 35.668690275854296 139.74782351812135 10.359085395338951</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_1a71f249-e4f9-428f-85fb-d8cf3a27b109">
									<gml:exterior>
										<gml:LinearRing gml:id="line_942f797c-0013-491b-8d70-4bf70087159e">
											<gml:posList>35.66868526091045 139.74782098748136 10.960441901686607 35.668690275854296 139.74782351812135 12.067657783034264 35.66868477962785 139.74782074477844 12.067657783034264 35.66868526091045 139.74782098748136 10.960441901686607</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_0a5957d1-cf31-450d-976f-e7f8e6237543">
									<gml:exterior>
										<gml:LinearRing gml:id="line_76f23fde-5ee5-44c5-8abe-35f1cf86eb2b">
											<gml:posList>35.66868526091045 139.74782098748136 10.960441901686607 35.66868477962785 139.74782074477844 12.067657783034264 35.66868477962785 139.74782074477844 10.960441901686607 35.66868526091045 139.74782098748136 10.960441901686607</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_477666fe-d10b-4b3e-902b-fe010fbf435c">
									<gml:exterior>
										<gml:LinearRing gml:id="line_7bf420b0-9baa-47fa-8d53-fb7afd2a2f1d">
											<gml:posList>35.66868526091045 139.74782098748136 10.960441901686607 35.66868477962785 139.74782074477844 10.960441901686607 35.66868526091045 139.74782098748136 10.359085395338951 35.66868526091045 139.74782098748136 10.960441901686607</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_27a19c5b-f3da-4f06-ab6f-2cb014fe5c38">
									<gml:exterior>
										<gml:LinearRing gml:id="line_5080b9cd-fb67-402a-be04-6a0696912a82">
											<gml:posList>35.66868526091045 139.74782098748136 10.359085395338951 35.66868477962785 139.74782074477844 10.960441901686607 35.66868477962785 139.74782074477844 10.359085395338951 35.66868526091045 139.74782098748136 10.359085395338951</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_7dc573c2-0b6b-405b-8128-2b5e8146952d">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_8d099b69-e81d-4727-b19e-162277d185a7">
									<gml:exterior>
										<gml:LinearRing gml:id="line_89896de6-a148-4e6d-a789-17e8ebf6c499">
											<gml:posList>35.66868526091045 139.74782098748136 14.020202949049889 35.668690275854296 139.74782351812135 13.418846442702232 35.668690275854296 139.74782351812135 15.127426459792076 35.66868526091045 139.74782098748136 14.020202949049889</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_b61dcf08-84b4-4bc8-a5dc-3bd3fd9b582e">
									<gml:exterior>
										<gml:LinearRing gml:id="line_e3e7eb4f-d657-42ee-ad8a-e7b6c580a8d4">
											<gml:posList>35.668690275854296 139.74782351812135 13.418846442702232 35.66868526091045 139.74782098748136 14.020202949049889 35.66868526091045 139.74782098748136 13.418846442702232 35.668690275854296 139.74782351812135 13.418846442702232</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_8cd79f0b-d60c-4d3e-950e-0aeeec8737c4">
									<gml:exterior>
										<gml:LinearRing gml:id="line_9348b7d2-f4ec-4e72-83f0-ad97f838c6ed">
											<gml:posList>35.66868526091045 139.74782098748136 14.020202949049889 35.668690275854296 139.74782351812135 15.127426459792076 35.66868477962785 139.74782074477844 15.127426459792076 35.66868526091045 139.74782098748136 14.020202949049889</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_d44e02a5-0e25-403b-89b3-163958667783">
									<gml:exterior>
										<gml:LinearRing gml:id="line_5e1a8ba8-b41b-4417-9b92-0ea6748e6b91">
											<gml:posList>35.66868526091045 139.74782098748136 14.020202949049889 35.66868477962785 139.74782074477844 15.127426459792076 35.66868477962785 139.74782074477844 14.020202949049889 35.66868526091045 139.74782098748136 14.020202949049889</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_9f4e12e0-dd72-4dca-9380-abb4b412b667">
									<gml:exterior>
										<gml:LinearRing gml:id="line_7992e461-6ae7-4370-aa9d-0d1125c15440">
											<gml:posList>35.66868526091045 139.74782098748136 14.020202949049889 35.66868477962785 139.74782074477844 14.020202949049889 35.66868526091045 139.74782098748136 13.418846442702232 35.66868526091045 139.74782098748136 14.020202949049889</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_47dc1f50-980d-4919-a2c9-8d2fd341f523">
									<gml:exterior>
										<gml:LinearRing gml:id="line_eeaf081c-6345-47a4-9494-4dd6671a69dc">
											<gml:posList>35.66868526091045 139.74782098748136 13.418846442702232 35.66868477962785 139.74782074477844 14.020202949049889 35.66868477962785 139.74782074477844 13.418846442702232 35.66868526091045 139.74782098748136 13.418846442702232</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_d67155c9-86d8-4b84-8372-b38f38dbb79c">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_962ba078-625c-47e0-9741-3bec65dfa78c">
									<gml:exterior>
										<gml:LinearRing gml:id="line_e8362d0e-52cc-4de5-9600-5aa11e64bc0c">
											<gml:posList>35.668628031727216 139.74780661061828 27.3664706492452 35.66862642811532 139.74781138344156 27.262848212721764 35.66862642811532 139.74781138344156 25.997948005202232 35.668628031727216 139.74780661061828 27.3664706492452</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_ba7b3fb3-5ebd-44f9-90a4-89fc253b15c7">
									<gml:exterior>
										<gml:LinearRing gml:id="line_135870eb-7302-4d78-b55e-d47a573150d6">
											<gml:posList>35.66862642811532 139.74781138344156 27.262848212721764 35.668628031727216 139.74780661061828 27.3664706492452 35.66862642811532 139.74781138344156 27.3664706492452 35.66862642811532 139.74781138344156 27.262848212721764</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_876f5b96-d3c4-401e-8629-526087740d76">
									<gml:exterior>
										<gml:LinearRing gml:id="line_3aa101a3-f5b2-46ef-92f1-7a9eb90420a8">
											<gml:posList>35.668628031727216 139.74780661061828 27.3664706492452 35.66862642811532 139.74781138344156 25.997948005202232 35.668628031727216 139.74780661061828 25.2079013133077 35.668628031727216 139.74780661061828 27.3664706492452</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_6b8e98e1-a0cd-49d4-9ec3-0e15df80073f">
									<gml:exterior>
										<gml:LinearRing gml:id="line_1d833bad-644a-40eb-bbf4-252a7c0bab8d">
											<gml:posList>35.668628031727216 139.74780661061828 25.2079013133077 35.66862642811532 139.74781138344156 25.997948005202232 35.66862642811532 139.74781138344156 25.2079013133077 35.668628031727216 139.74780661061828 25.2079013133077</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_dde3f95c-fef2-4cdd-91a5-8c60bc062a71">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_5a093fd3-aeda-422d-ba21-a52b5798b559">
									<gml:exterior>
										<gml:LinearRing gml:id="line_5f87a8bb-7506-4f53-94a6-e63a9bbcf889">
											<gml:posList>35.66863826445226 139.7479905575038 40.907394721510826 35.66865114500591 139.74795222318627 40.907394721510826 35.66865114500591 139.74795222318627 37.902504279616295 35.66863826445226 139.7479905575038 40.907394721510826</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_c604bbe3-e3fd-4bd0-b941-1c7343772b6f">
									<gml:exterior>
										<gml:LinearRing gml:id="line_a2b456c5-0c42-4873-bfea-53ba097e2285">
											<gml:posList>35.66863826445226 139.7479905575038 40.907394721510826 35.66865114500591 139.74795222318627 37.902504279616295 35.66863826445226 139.7479905575038 37.902504279616295 35.66863826445226 139.7479905575038 40.907394721510826</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_92cf3c3c-c2d1-4467-912e-5bfaa78fd990">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_de173f8e-3be5-4f8d-8561-7ad5ddcc4088">
									<gml:exterior>
										<gml:LinearRing gml:id="line_b420896c-21e8-447c-8ba9-5846337d5ce2">
											<gml:posList>35.668669312220906 139.74783302287355 25.997948005202232 35.66867316936178 139.74783496920924 25.997948005202232 35.668669312220906 139.74783302287355 25.2079013133077 35.668669312220906 139.74783302287355 25.997948005202232</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_6be40475-4526-46a8-92a9-b9b6bad9213d">
									<gml:exterior>
										<gml:LinearRing gml:id="line_9b1ce9b6-727a-4e3f-a0af-fe5dbaf1e9ef">
											<gml:posList>35.668669312220906 139.74783302287355 25.2079013133077 35.66867316936178 139.74783496920924 25.997948005202232 35.66867316936178 139.74783496920924 25.2079013133077 35.668669312220906 139.74783302287355 25.2079013133077</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_16ce2dcb-91f4-4780-8c6f-cf1889620b5d">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_139646c8-c3d6-40fd-8d78-e4365f62004b">
									<gml:exterior>
										<gml:LinearRing gml:id="line_3f450d41-4079-4bea-a67a-9ed8b1b01adb">
											<gml:posList>35.668669312220906 139.74783302287355 32.117470099928795 35.668670915971305 139.74782825021657 31.327423408034264 35.668670915971305 139.74782825021657 33.486000373366295 35.668669312220906 139.74783302287355 32.117470099928795</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_33f1665f-c7a3-42ec-9ef0-3be41e4b0fd1">
									<gml:exterior>
										<gml:LinearRing gml:id="line_9365b801-b60d-4e99-a2d7-d21ffb341ad5">
											<gml:posList>35.668670915971305 139.74782825021657 31.327423408034264 35.668669312220906 139.74783302287355 32.117470099928795 35.668669312220906 139.74783302287355 31.327423408034264 35.668670915971305 139.74782825021657 31.327423408034264</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_0faf7312-5760-4acd-b770-cf605a1eb66c">
									<gml:exterior>
										<gml:LinearRing gml:id="line_e159dd0b-f415-4e4b-849a-5936bd32552d">
											<gml:posList>35.668669312220906 139.74783302287355 32.117470099928795 35.668670915971305 139.74782825021657 33.486000373366295 35.668669312220906 139.74783302287355 33.382370307448326 35.668669312220906 139.74783302287355 32.117470099928795</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_7fa0d230-f9da-4de8-b09a-55794a37d8e4">
									<gml:exterior>
										<gml:LinearRing gml:id="line_5e6fb2de-36c3-4e47-9662-60a7c6b86edf">
											<gml:posList>35.668669312220906 139.74783302287355 33.382370307448326 35.668670915971305 139.74782825021657 33.486000373366295 35.668669312220906 139.74783302287355 33.486000373366295 35.668669312220906 139.74783302287355 33.382370307448326</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_145a2751-d7e6-4bf4-a33f-7233ae1c5535">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_650e0f71-f7ca-4ba8-afb3-f894c53d8615">
									<gml:exterior>
										<gml:LinearRing gml:id="line_ed4396a6-2f8d-4bef-a081-dd5243d0caee">
											<gml:posList>35.668669312220906 139.74783302287355 22.93818695783895 35.66867316936178 139.74783496920924 22.93818695783895 35.668669312220906 139.74783302287355 22.14813263654989 35.668669312220906 139.74783302287355 22.93818695783895</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_83776d2f-631d-4670-a7cf-88b2c7baab43">
									<gml:exterior>
										<gml:LinearRing gml:id="line_60ad5efc-5425-4ca7-a7c7-bba7635ef203">
											<gml:posList>35.668669312220906 139.74783302287355 22.14813263654989 35.66867316936178 139.74783496920924 22.93818695783895 35.66867316936178 139.74783496920924 22.14813263654989 35.668669312220906 139.74783302287355 22.14813263654989</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_a97adcf3-75a5-4b89-b364-f56c43919bf7">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_976b5926-05fc-48d4-b0c1-d6cdd77af9bc">
									<gml:exterior>
										<gml:LinearRing gml:id="line_3a7c090e-40cd-48f0-b8e7-aa1019b57eea">
											<gml:posList>35.668669312220906 139.74783302287355 19.87842591047567 35.668670915971305 139.74782825021657 19.088371589186607 35.668670915971305 139.74782825021657 21.24694855451864 35.668669312220906 139.74783302287355 19.87842591047567</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_3340a94d-09ee-4017-9764-f9e6ac43d502">
									<gml:exterior>
										<gml:LinearRing gml:id="line_e31fb05d-afb6-44c9-9457-4dc430ff7d8c">
											<gml:posList>35.668670915971305 139.74782825021657 19.088371589186607 35.668669312220906 139.74783302287355 19.87842591047567 35.668669312220906 139.74783302287355 19.088371589186607 35.668670915971305 139.74782825021657 19.088371589186607</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_77cddcf4-40fa-4a6b-9f16-505718946e8a">
									<gml:exterior>
										<gml:LinearRing gml:id="line_444cbede-fb71-4ffd-8f75-a3b89373256d">
											<gml:posList>35.668669312220906 139.74783302287355 19.87842591047567 35.668670915971305 139.74782825021657 21.24694855451864 35.668669312220906 139.74783302287355 21.1433261179952 35.668669312220906 139.74783302287355 19.87842591047567</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_69ba5772-bdaf-4d04-9d98-fb54ffdb389c">
									<gml:exterior>
										<gml:LinearRing gml:id="line_3a25fee7-b9ce-483e-8c94-a7bc68ce8fef">
											<gml:posList>35.668669312220906 139.74783302287355 21.1433261179952 35.668670915971305 139.74782825021657 21.24694855451864 35.668669312220906 139.74783302287355 21.24694855451864 35.668669312220906 139.74783302287355 21.1433261179952</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_d1b4109d-445e-440c-8f41-e90865ad6098">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_79bf2784-6fa4-4b16-b6e9-f4b1c31d975f">
									<gml:exterior>
										<gml:LinearRing gml:id="line_aa10fba7-6b6c-4450-963b-8c7b7df5a9ea">
											<gml:posList>35.668670915971305 139.74782825021657 12.968849494460045 35.668670915971305 139.74782825021657 15.127426459792076 35.668669312220906 139.74783302287355 15.127426459792076 35.668670915971305 139.74782825021657 12.968849494460045</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_65c2e38a-5261-41b6-899b-15226320a3bc">
									<gml:exterior>
										<gml:LinearRing gml:id="line_03641ddb-d6e0-46e4-a00f-2594fc05bf47">
											<gml:posList>35.668670915971305 139.74782825021657 12.968849494460045 35.668669312220906 139.74783302287355 15.127426459792076 35.668669312220906 139.74783302287355 12.968849494460045 35.668670915971305 139.74782825021657 12.968849494460045</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_cb3891e4-d95b-48ca-a19a-7df3c1a84453">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_f4e552d1-dad1-4ef5-8667-e60ec22e8d2f">
									<gml:exterior>
										<gml:LinearRing gml:id="line_45696e04-ee2e-4787-ae61-d737f8c356b8">
											<gml:posList>35.6686752542573 139.74783043925513 26.259254767897545 35.66868610967223 139.747835916983 27.3664706492452 35.66868610967223 139.747835916983 25.65789826154989 35.6686752542573 139.74783043925513 26.259254767897545</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_48d2fc73-9029-4745-8f65-06d7aea26670">
									<gml:exterior>
										<gml:LinearRing gml:id="line_95177ba4-7b7c-4dca-a368-ebe8639c62ec">
											<gml:posList>35.66868610967223 139.747835916983 27.3664706492452 35.6686752542573 139.74783043925513 26.259254767897545 35.6686747729746 139.74783019638366 27.3664706492452 35.66868610967223 139.747835916983 27.3664706492452</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_bb2995df-0991-4275-aea0-2704e32a45fb">
									<gml:exterior>
										<gml:LinearRing gml:id="line_0ae28b56-4567-4a24-a9b8-41d06a798d55">
											<gml:posList>35.6686747729746 139.74783019638366 27.3664706492452 35.6686752542573 139.74783043925513 26.259254767897545 35.6686747729746 139.74783019638366 26.259254767897545 35.6686747729746 139.74783019638366 27.3664706492452</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_7e364b93-3068-47cb-9f0f-0ddf54dad333">
									<gml:exterior>
										<gml:LinearRing gml:id="line_056ccdb5-3de6-4e16-af83-1d8b22df79a8">
											<gml:posList>35.6686752542573 139.74783043925513 26.259254767897545 35.66868610967223 139.747835916983 25.65789826154989 35.6686752542573 139.74783043925513 25.65789826154989 35.6686752542573 139.74783043925513 26.259254767897545</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_d296a6a7-4a25-45bc-a2a8-e408552d6799">
									<gml:exterior>
										<gml:LinearRing gml:id="line_c425d6c0-fa5f-4cb8-898e-709bfaeb749b">
											<gml:posList>35.6686752542573 139.74783043925513 26.259254767897545 35.6686752542573 139.74783043925513 25.65789826154989 35.6686747729746 139.74783019638366 26.259254767897545 35.6686752542573 139.74783043925513 26.259254767897545</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_d2b8a478-2d79-4ce7-b26d-75afaff18796">
									<gml:exterior>
										<gml:LinearRing gml:id="line_d85bd19e-9ca4-41ff-926d-d33e9cb24346">
											<gml:posList>35.6686747729746 139.74783019638366 26.259254767897545 35.6686752542573 139.74783043925513 25.65789826154989 35.6686747729746 139.74783019638366 25.65789826154989 35.6686747729746 139.74783019638366 26.259254767897545</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_ffa6f1e3-c2ec-4cf5-97cd-3055dd849168">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_df100bc9-daf4-4c30-8728-32eac97b7109">
									<gml:exterior>
										<gml:LinearRing gml:id="line_a6a72641-d3e4-45f0-adba-14e3248d90c6">
											<gml:posList>35.66862642811532 139.74781138344156 32.117470099928795 35.668630285119036 139.74781332977528 32.117470099928795 35.66862642811532 139.74781138344156 31.327423408034264 35.66862642811532 139.74781138344156 32.117470099928795</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_542d1657-7129-4b35-aa36-ec09cb9722bc">
									<gml:exterior>
										<gml:LinearRing gml:id="line_54d11760-06ee-4704-b133-ba530083924e">
											<gml:posList>35.66862642811532 139.74781138344156 31.327423408034264 35.668630285119036 139.74781332977528 32.117470099928795 35.668630285119036 139.74781332977528 31.327423408034264 35.66862642811532 139.74781138344156 31.327423408034264</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="wall_TMmnt0161_p994_4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly_TMmnt0161_p994_4">
									<gml:exterior>
										<gml:LinearRing gml:id="line_TMmnt0161_p994_4">
											<gml:posList>35.66861954856139 139.7479126286901 39.12509972 35.66861955321487 139.74791262976777 37.87509983 35.66860003153536 139.7479025541768 37.87413439 35.66860002688576 139.74790255310108 39.12413428 35.66861954856139 139.7479126286901 39.12509972</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_39bc49e2-798d-449f-83e8-7a76061e85f6">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_beafbc85-b5d3-4aa3-be9b-2db88bb95fa1">
									<gml:exterior>
										<gml:LinearRing gml:id="line_5f9c38dc-38d1-4f0a-b0ed-d9e650be2950">
											<gml:posList>35.66862411485443 139.74789935105437 37.902504279616295 35.66859372993633 139.7478840186893 35.550506904128014 35.66859372993633 139.7478840186893 38.68550141096395 35.66862411485443 139.74789935105437 37.902504279616295</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_f10c38d4-78f0-4e8b-8177-7b079a7e9a07">
									<gml:exterior>
										<gml:LinearRing gml:id="line_c089fb1b-4786-4b39-92b0-5ee015061755">
											<gml:posList>35.66859372993633 139.7478840186893 35.550506904128014 35.66862411485443 139.74789935105437 37.902504279616295 35.668664937877324 139.74791995042165 35.550506904128014 35.66859372993633 139.7478840186893 35.550506904128014</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_ef5ad4c3-dee8-440a-827e-7ad84d8a8b6e">
									<gml:exterior>
										<gml:LinearRing gml:id="line_201f3070-5ab5-459e-8499-2aef93031a6f">
											<gml:posList>35.668664937877324 139.74791995042165 35.550506904128014 35.66862411485443 139.74789935105437 37.902504279616295 35.668664937877324 139.74791995042165 37.902504279616295 35.668664937877324 139.74791995042165 35.550506904128014</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_f2b8dbf8-f6c8-4192-9e60-6914386afb75">
									<gml:exterior>
										<gml:LinearRing gml:id="line_2d26be22-8899-4d4d-bd9d-832aa311d381">
											<gml:posList>35.66862411485443 139.74789935105437 37.902504279616295 35.66859372993633 139.7478840186893 38.68550141096395 35.66862411485443 139.74789935105437 38.68550141096395 35.66862411485443 139.74789935105437 37.902504279616295</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_f1d7b829-f1ed-4893-b705-b44f55446852">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_94c314a0-5a3b-4be8-83a4-a21f9baf4551">
									<gml:exterior>
										<gml:LinearRing gml:id="line_f97e26fa-00e1-4477-94d9-fa0c194b3f7d">
											<gml:posList>35.6686752542573 139.74783043925513 29.319015815260826 35.66868610967223 139.747835916983 30.426239326003014 35.66868610967223 139.747835916983 28.71765930891317 35.6686752542573 139.74783043925513 29.319015815260826</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_bd8528e7-5ecf-4973-b3d9-22241c27054c">
									<gml:exterior>
										<gml:LinearRing gml:id="line_aaabc782-a641-4c56-8e9a-833196858ef9">
											<gml:posList>35.66868610967223 139.747835916983 30.426239326003014 35.6686752542573 139.74783043925513 29.319015815260826 35.6686747729746 139.74783019638366 30.426239326003014 35.66868610967223 139.747835916983 30.426239326003014</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_988c86d5-e029-4446-9ac1-f777fe856aca">
									<gml:exterior>
										<gml:LinearRing gml:id="line_1c13a6c1-2db7-44a1-b7ce-7fb11bd325f1">
											<gml:posList>35.6686747729746 139.74783019638366 30.426239326003014 35.6686752542573 139.74783043925513 29.319015815260826 35.6686747729746 139.74783019638366 29.319015815260826 35.6686747729746 139.74783019638366 30.426239326003014</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_08ea70a8-e1d9-4f4a-8f0a-aec767ba8019">
									<gml:exterior>
										<gml:LinearRing gml:id="line_6e303e7e-d1ac-4fea-8cc8-f936312fdf0c">
											<gml:posList>35.6686752542573 139.74783043925513 29.319015815260826 35.66868610967223 139.747835916983 28.71765930891317 35.6686752542573 139.74783043925513 28.71765930891317 35.6686752542573 139.74783043925513 29.319015815260826</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_66f104ca-2f79-4d63-99a3-cb23f44b3f92">
									<gml:exterior>
										<gml:LinearRing gml:id="line_5fa0a1fe-e65e-4e18-9a54-2838b81d7e9c">
											<gml:posList>35.6686752542573 139.74783043925513 29.319015815260826 35.6686752542573 139.74783043925513 28.71765930891317 35.6686747729746 139.74783019638366 29.319015815260826 35.6686752542573 139.74783043925513 29.319015815260826</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_8a186083-8e95-45c3-beba-749433fc81ec">
									<gml:exterior>
										<gml:LinearRing gml:id="line_ac1ab87a-1c5b-416a-9efd-02eb7ed5b907">
											<gml:posList>35.6686747729746 139.74783019638366 29.319015815260826 35.6686752542573 139.74783043925513 28.71765930891317 35.6686747729746 139.74783019638366 28.71765930891317 35.6686747729746 139.74783019638366 29.319015815260826</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="wall_TMmnt0161_p991_1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly_TMmnt0161_p991_1">
									<gml:exterior>
										<gml:LinearRing gml:id="line_TMmnt0161_p991_1">
											<gml:posList>35.66867744484322 139.74782458353985 34.61713868 35.66868917663862 139.747813404338 34.61760013 35.66868928553584 139.7478134290291 5.45171664 35.66867755368657 139.74782460828197 5.45125518 35.66867744484322 139.74782458353985 34.61713868</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_be69ad38-770a-4f1f-80a4-e9d960178ae3">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_051e4859-8e7b-4ad7-8e50-9c593d0384f0">
									<gml:exterior>
										<gml:LinearRing gml:id="line_c3a1dedc-c3d4-463b-ac49-f560c7965114">
											<gml:posList>35.66854953245749 139.74796394034698 35.0962069773702 35.66854953245749 139.74796394034698 33.35395081281942 35.668547264690574 139.74797068926028 33.35395081281942 35.66854953245749 139.74796394034698 35.0962069773702</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_3ea1c530-faa6-468f-be40-2210de9feb4f">
									<gml:exterior>
										<gml:LinearRing gml:id="line_a548e1b2-dc98-4d80-a168-f8c5e5bc93e4">
											<gml:posList>35.66854953245749 139.74796394034698 33.35395081281942 35.66854953245749 139.74796394034698 35.0962069773702 35.66856262697436 139.74792496973683 37.902504279616295 35.66854953245749 139.74796394034698 33.35395081281942</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_8dcc1048-7b32-4205-bbee-c0e61c9e0888">
									<gml:exterior>
										<gml:LinearRing gml:id="line_ae130758-ad85-47ba-918a-2a77e0d8ff32">
											<gml:posList>35.66854953245749 139.74796394034698 35.0962069773702 35.668547264690574 139.74797068926028 33.35395081281942 35.668547264690574 139.74797068926028 35.0962069773702 35.66854953245749 139.74796394034698 35.0962069773702</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_ba233536-81b9-4340-90b2-16d399c67658">
									<gml:exterior>
										<gml:LinearRing gml:id="line_c94813f7-e567-43e2-8bb8-c81a6d819e70">
											<gml:posList>35.668547264690574 139.74797068926028 32.04187805891317 35.66854953245749 139.74796394034698 30.29962189436239 35.668547264690574 139.74797068926028 30.29962189436239 35.668547264690574 139.74797068926028 32.04187805891317</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_c061ee0d-a976-43ec-b051-0a71de0cf358">
									<gml:exterior>
										<gml:LinearRing gml:id="line_662c0f6b-7d33-4157-b669-343d0d02a6d5">
											<gml:posList>35.66854953245749 139.74796394034698 30.29962189436239 35.668547264690574 139.74797068926028 32.04187805891317 35.66854953245749 139.74796394034698 32.04187805891317 35.66854953245749 139.74796394034698 30.29962189436239</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_a39e944e-ac51-4e79-88cb-24667d97c72a">
									<gml:exterior>
										<gml:LinearRing gml:id="line_a53546d8-f426-4ae2-978d-83c36d8463ec">
											<gml:posList>35.66854279462402 139.7479839930165 33.35395081281942 35.66854505086256 139.74797727816306 35.0962069773702 35.66854505086256 139.74797727816306 33.35395081281942 35.66854279462402 139.7479839930165 33.35395081281942</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_b1d3ecd9-f737-4dfd-9599-0a555fe24556">
									<gml:exterior>
										<gml:LinearRing gml:id="line_0bec689f-ae8f-4337-8381-2c03a0483dca">
											<gml:posList>35.66854505086256 139.74797727816306 35.0962069773702 35.66854279462402 139.7479839930165 33.35395081281942 35.66854279462402 139.7479839930165 35.0962069773702 35.66854505086256 139.74797727816306 35.0962069773702</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_e198d086-dd5f-48eb-abb7-2b87885e9fa6">
									<gml:exterior>
										<gml:LinearRing gml:id="line_16cf2ff5-7fe0-470a-a2c9-54f05765a2a6">
											<gml:posList>35.66854279462402 139.7479839930165 35.0962069773702 35.66854279462402 139.7479839930165 33.35395081281942 35.66853779642093 139.7479988683756 33.35395081281942 35.66854279462402 139.7479839930165 35.0962069773702</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_4c9eda9c-e0bf-48f1-bae1-35750330ef83">
									<gml:exterior>
										<gml:LinearRing gml:id="line_e993bd5d-cc96-4b03-bd92-900e0d11c8ad">
											<gml:posList>35.66854279462402 139.7479839930165 32.04187805891317 35.66854505086256 139.74797727816306 30.29962189436239 35.66854279462402 139.7479839930165 30.29962189436239 35.66854279462402 139.7479839930165 32.04187805891317</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_63033c98-d3d2-4a12-a3c3-cbf301fd663f">
									<gml:exterior>
										<gml:LinearRing gml:id="line_375ded6d-37ad-4d6c-9a91-3ee025be1f6d">
											<gml:posList>35.66854505086256 139.74797727816306 30.29962189436239 35.66854279462402 139.7479839930165 32.04187805891317 35.66854505086256 139.74797727816306 32.04187805891317 35.66854505086256 139.74797727816306 30.29962189436239</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_34e3d3e7-0139-4a75-a3ac-5183d6874d65">
									<gml:exterior>
										<gml:LinearRing gml:id="line_eefa5ae7-01a3-4bcd-8035-6132913e2a5f">
											<gml:posList>35.66856262697436 139.74792496973683 37.902504279616295 35.66856545347873 139.74791655749243 6.3942492747334825 35.66854953245749 139.74796394034698 28.98754914045614 35.66856262697436 139.74792496973683 37.902504279616295</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_57b10f02-bd22-4d04-9bd0-87701c436a58">
									<gml:exterior>
										<gml:LinearRing gml:id="line_17e646a4-500b-42a5-980c-e93c2bbe0835">
											<gml:posList>35.66856545347873 139.74791655749243 6.3942492747334825 35.66856262697436 139.74792496973683 37.902504279616295 35.66856545347873 139.74791655749243 41.17650635481161 35.66856545347873 139.74791655749243 6.3942492747334825</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_5e1ef5be-2946-453a-b7f7-32ad16ee9a2f">
									<gml:exterior>
										<gml:LinearRing gml:id="line_1cffb581-28e6-4f9e-9311-996961224d6b">
											<gml:posList>35.66854953245749 139.74796394034698 28.98754914045614 35.66856545347873 139.74791655749243 6.3942492747334825 35.668547264690574 139.74797068926028 28.98754914045614 35.66854953245749 139.74796394034698 28.98754914045614</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_776a8db5-dca6-406f-8848-525134df59db">
									<gml:exterior>
										<gml:LinearRing gml:id="line_7eb8d72f-4412-4447-9ede-d2bee2d3774c">
											<gml:posList>35.66856545347873 139.74791655749243 41.17650635481161 35.66856262697436 139.74792496973683 37.902504279616295 35.66856262697436 139.74792496973683 41.17650635481161 35.66856545347873 139.74791655749243 41.17650635481161</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_eddf989d-3181-4c54-afcb-436fe68e4e7d">
									<gml:exterior>
										<gml:LinearRing gml:id="line_1f7a6464-97cd-462c-a744-6ce16392b1eb">
											<gml:posList>35.66856262697436 139.74792496973683 37.902504279616295 35.66854953245749 139.74796394034698 28.98754914045614 35.66854953245749 139.74796394034698 30.29962189436239 35.66856262697436 139.74792496973683 37.902504279616295</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_902a25c5-88ad-40a0-8448-efe0b62b2881">
									<gml:exterior>
										<gml:LinearRing gml:id="line_c62b76dd-c889-4ec4-8f8e-0f64a66ba2d7">
											<gml:posList>35.66856262697436 139.74792496973683 37.902504279616295 35.66854953245749 139.74796394034698 32.04187805891317 35.66854953245749 139.74796394034698 33.35395081281942 35.66856262697436 139.74792496973683 37.902504279616295</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_93e1c39d-e796-4df2-87d4-5b5a92145620">
									<gml:exterior>
										<gml:LinearRing gml:id="line_64348522-be6a-4677-86a5-d5163a7c868f">
											<gml:posList>35.66854953245749 139.74796394034698 32.04187805891317 35.66856262697436 139.74792496973683 37.902504279616295 35.66854953245749 139.74796394034698 30.29962189436239 35.66854953245749 139.74796394034698 32.04187805891317</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_ed31f793-6221-4615-90be-4593e25dc8ec">
									<gml:exterior>
										<gml:LinearRing gml:id="line_6cb78a44-7d0f-466b-bf8c-2da8ea9f35bf">
											<gml:posList>35.668547264690574 139.74797068926028 28.98754914045614 35.66856545347873 139.74791655749243 6.3942492747334825 35.66854505086256 139.74797727816306 28.98754914045614 35.668547264690574 139.74797068926028 28.98754914045614</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_e27e9179-ff3a-451d-b711-99a64747b8ff">
									<gml:exterior>
										<gml:LinearRing gml:id="line_71ebd9ac-0ec4-4f03-9dcc-6e9495dd201c">
											<gml:posList>35.66854505086256 139.74797727816306 28.98754914045614 35.66856545347873 139.74791655749243 6.3942492747334825 35.66854279462402 139.7479839930165 28.98754914045614 35.66854505086256 139.74797727816306 28.98754914045614</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_9e055141-09ce-4d6a-a287-1a19d83f1924">
									<gml:exterior>
										<gml:LinearRing gml:id="line_dddecd1d-fe58-4bf0-9bc3-e3c796537b8e">
											<gml:posList>35.668547264690574 139.74797068926028 28.98754914045614 35.66854505086256 139.74797727816306 28.98754914045614 35.668547264690574 139.74797068926028 30.29962189436239 35.668547264690574 139.74797068926028 28.98754914045614</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_7a01894b-67ad-4000-a2db-a24f554ac16e">
									<gml:exterior>
										<gml:LinearRing gml:id="line_4ffdcb18-7262-4528-b148-460b2db8e1d3">
											<gml:posList>35.668547264690574 139.74797068926028 30.29962189436239 35.66854505086256 139.74797727816306 30.29962189436239 35.66854505086256 139.74797727816306 32.04187805891317 35.668547264690574 139.74797068926028 30.29962189436239</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_b0303294-a12d-4d04-89ce-4e9fba527125">
									<gml:exterior>
										<gml:LinearRing gml:id="line_51d40931-616c-48d3-b49a-8f175150a7a7">
											<gml:posList>35.66854505086256 139.74797727816306 30.29962189436239 35.668547264690574 139.74797068926028 30.29962189436239 35.66854505086256 139.74797727816306 28.98754914045614 35.66854505086256 139.74797727816306 30.29962189436239</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_65e8b7ef-0dea-4e65-bc83-ffd75d5eec64">
									<gml:exterior>
										<gml:LinearRing gml:id="line_17a81a94-59f0-4fb8-a192-a2d44a9f2bf4">
											<gml:posList>35.668547264690574 139.74797068926028 30.29962189436239 35.66854505086256 139.74797727816306 32.04187805891317 35.668547264690574 139.74797068926028 32.04187805891317 35.668547264690574 139.74797068926028 30.29962189436239</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_c19dbfec-7c9a-42c6-8be6-fdd10568e4e4">
									<gml:exterior>
										<gml:LinearRing gml:id="line_ebfbc82a-2224-4987-a68a-0523bb9a02a6">
											<gml:posList>35.668547264690574 139.74797068926028 32.04187805891317 35.66854505086256 139.74797727816306 32.04187805891317 35.66854505086256 139.74797727816306 33.35395081281942 35.668547264690574 139.74797068926028 32.04187805891317</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_c5ed99c9-5b83-4edc-a1ee-2abf2c21f651">
									<gml:exterior>
										<gml:LinearRing gml:id="line_cd6a46ad-8e8d-49cd-87ff-92251990c0eb">
											<gml:posList>35.66854279462402 139.7479839930165 28.98754914045614 35.66856545347873 139.74791655749243 6.3942492747334825 35.66853779642093 139.7479988683756 28.98754914045614 35.66854279462402 139.7479839930165 28.98754914045614</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_16e9f5ca-1586-489d-a024-d16a07de6086">
									<gml:exterior>
										<gml:LinearRing gml:id="line_0d9083fb-fdac-448b-aab6-482187106d56">
											<gml:posList>35.66853779642093 139.7479988683756 28.98754914045614 35.66856545347873 139.74791655749243 6.3942492747334825 35.66851072947919 139.74807942246645 6.3942492747334825 35.66853779642093 139.7479988683756 28.98754914045614</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_8f640eb8-1af3-4a63-b473-52d25c7e5046">
									<gml:exterior>
										<gml:LinearRing gml:id="line_f0fd9de8-9759-45a5-b79a-34cdb5a606b7">
											<gml:posList>35.66854279462402 139.7479839930165 28.98754914045614 35.66853779642093 139.7479988683756 28.98754914045614 35.66853779642093 139.7479988683756 30.29962189436239 35.66854279462402 139.7479839930165 28.98754914045614</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_59432baf-ae3f-4247-a651-e07bc0e17f5c">
									<gml:exterior>
										<gml:LinearRing gml:id="line_090901ef-fbb8-4a1c-b2d5-7f544f6c65d2">
											<gml:posList>35.66854279462402 139.7479839930165 30.29962189436239 35.66853779642093 139.7479988683756 30.29962189436239 35.66853779642093 139.7479988683756 32.04187805891317 35.66854279462402 139.7479839930165 30.29962189436239</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_60d64295-f931-48ce-8879-f68328f2dd15">
									<gml:exterior>
										<gml:LinearRing gml:id="line_97d7f960-7a30-494b-b155-22461bebe7b2">
											<gml:posList>35.66853779642093 139.7479988683756 30.29962189436239 35.66854279462402 139.7479839930165 30.29962189436239 35.66854279462402 139.7479839930165 28.98754914045614 35.66853779642093 139.7479988683756 30.29962189436239</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_a7e92a12-b3b8-466c-a5fb-dac2881fb872">
									<gml:exterior>
										<gml:LinearRing gml:id="line_65614947-9518-47dc-bcd8-16be3ad62174">
											<gml:posList>35.66853779642093 139.7479988683756 28.98754914045614 35.66851072947919 139.74807942246645 6.3942492747334825 35.66853552865205 139.7480056172869 28.98754914045614 35.66853779642093 139.7479988683756 28.98754914045614</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_ca9297f2-49cc-49ea-af77-613729ae81a6">
									<gml:exterior>
										<gml:LinearRing gml:id="line_744a007d-3a82-4143-8028-1961432d7092">
											<gml:posList>35.66853552865205 139.7480056172869 28.98754914045614 35.66851072947919 139.74807942246645 6.3942492747334825 35.66853331482213 139.74801220618775 28.98754914045614 35.66853552865205 139.7480056172869 28.98754914045614</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_a7cbeede-0173-4d84-a520-1dad4d98bb2b">
									<gml:exterior>
										<gml:LinearRing gml:id="line_0c5b3b16-52b2-40ff-8f44-be0bca7aebd1">
											<gml:posList>35.66853552865205 139.7480056172869 28.98754914045614 35.66853331482213 139.74801220618775 28.98754914045614 35.66853552865205 139.7480056172869 30.29962189436239 35.66853552865205 139.7480056172869 28.98754914045614</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_dfbf2ec4-3c5a-4515-a381-247122e203df">
									<gml:exterior>
										<gml:LinearRing gml:id="line_4d944f6a-87c0-4bbd-803b-24295fac4c20">
											<gml:posList>35.66853552865205 139.7480056172869 32.04187805891317 35.66853331482213 139.74801220618775 32.04187805891317 35.66853331482213 139.74801220618775 33.35395081281942 35.66853552865205 139.7480056172869 32.04187805891317</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_b94234fd-09ec-489d-b59c-04c39161481b">
									<gml:exterior>
										<gml:LinearRing gml:id="line_1911e008-c260-452c-a9f0-40ea4e1518c8">
											<gml:posList>35.66853331482213 139.74801220618775 32.04187805891317 35.66853552865205 139.7480056172869 32.04187805891317 35.66853331482213 139.74801220618775 30.29962189436239 35.66853331482213 139.74801220618775 32.04187805891317</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_e08ab483-7192-4e34-bc70-48efa05a3184">
									<gml:exterior>
										<gml:LinearRing gml:id="line_8ab93df9-04aa-4032-80c9-4bb50a66c943">
											<gml:posList>35.66853331482213 139.74801220618775 28.98754914045614 35.66851072947919 139.74807942246645 6.3942492747334825 35.668531058581614 139.74801892103923 28.98754914045614 35.66853331482213 139.74801220618775 28.98754914045614</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_f9e94ff9-fbe8-4f80-be80-b06a28ee1999">
									<gml:exterior>
										<gml:LinearRing gml:id="line_7c9e0369-981a-4fbb-a05c-673d684d8ddd">
											<gml:posList>35.668531058581614 139.74801892103923 28.98754914045614 35.66851072947919 139.74807942246645 6.3942492747334825 35.66851072947919 139.74807942246645 37.902504279616295 35.668531058581614 139.74801892103923 28.98754914045614</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_1b9c9ba8-b9f4-4de6-a195-ae935549e526">
									<gml:exterior>
										<gml:LinearRing gml:id="line_0eb10c23-806d-44fd-a97a-ed6ef7e9ed1c">
											<gml:posList>35.66851072947919 139.74807942246645 37.902504279616295 35.668531058581614 139.74801892103923 30.29962189436239 35.668531058581614 139.74801892103923 28.98754914045614 35.66851072947919 139.74807942246645 37.902504279616295</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_f69e26e8-c6b6-47b8-b42a-23bcb7974c96">
									<gml:exterior>
										<gml:LinearRing gml:id="line_94435aa1-4b59-49c6-b4f0-2dc4b8cf1f64">
											<gml:posList>35.668531058581614 139.74801892103923 30.29962189436239 35.66851072947919 139.74807942246645 37.902504279616295 35.668531058581614 139.74801892103923 32.04187805891317 35.668531058581614 139.74801892103923 30.29962189436239</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_33863400-b15e-4566-a2ec-e25cc51bac49">
									<gml:exterior>
										<gml:LinearRing gml:id="line_c73c90d7-6ff0-4da9-931e-9191ee3237d5">
											<gml:posList>35.66853552865205 139.7480056172869 32.04187805891317 35.66853779642093 139.7479988683756 30.29962189436239 35.66853552865205 139.7480056172869 30.29962189436239 35.66853552865205 139.7480056172869 32.04187805891317</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_debf2694-3c8f-4223-9327-8ca2e73d3e32">
									<gml:exterior>
										<gml:LinearRing gml:id="line_ed63b0c6-8e61-4268-ae12-4bc1466adcab">
											<gml:posList>35.66853779642093 139.7479988683756 30.29962189436239 35.66853552865205 139.7480056172869 32.04187805891317 35.66853779642093 139.7479988683756 32.04187805891317 35.66853779642093 139.7479988683756 30.29962189436239</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_f3070ec5-e27e-4d6d-b826-0d44600658f5">
									<gml:exterior>
										<gml:LinearRing gml:id="line_9558a522-b28c-4ea2-ac66-b7ed301a547a">
											<gml:posList>35.66853779642093 139.7479988683756 35.0962069773702 35.66853779642093 139.7479988683756 33.35395081281942 35.66853552865205 139.7480056172869 33.35395081281942 35.66853779642093 139.7479988683756 35.0962069773702</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_e0f4e91f-8317-465b-bcc4-2cd151036bf6">
									<gml:exterior>
										<gml:LinearRing gml:id="line_962b45f0-7231-412d-a3d0-785d3c24ca95">
											<gml:posList>35.66853779642093 139.7479988683756 33.35395081281942 35.66853779642093 139.7479988683756 35.0962069773702 35.66854279462402 139.7479839930165 35.0962069773702 35.66853779642093 139.7479988683756 33.35395081281942</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_ec404324-5fdb-4fc9-9774-7cd5eb61de0e">
									<gml:exterior>
										<gml:LinearRing gml:id="line_501add23-cee7-4bd3-89c9-5b3cfb56046e">
											<gml:posList>35.66853779642093 139.7479988683756 35.0962069773702 35.66853552865205 139.7480056172869 33.35395081281942 35.66853552865205 139.7480056172869 35.0962069773702 35.66853779642093 139.7479988683756 35.0962069773702</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_f8e9bf3e-d106-4905-bafe-0c449bd2168a">
									<gml:exterior>
										<gml:LinearRing gml:id="line_5f7a9f65-0f5d-4815-bc58-7c9b92d3c535">
											<gml:posList>35.66853552865205 139.7480056172869 35.0962069773702 35.66853552865205 139.7480056172869 33.35395081281942 35.66853331482213 139.74801220618775 33.35395081281942 35.66853552865205 139.7480056172869 35.0962069773702</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_806d735e-3353-4905-a2c7-7ee5c04a13ed">
									<gml:exterior>
										<gml:LinearRing gml:id="line_af2b50f2-e92c-4de8-864b-17b6ad2d0ba8">
											<gml:posList>35.66853331482213 139.74801220618775 30.29962189436239 35.66853552865205 139.7480056172869 32.04187805891317 35.66853552865205 139.7480056172869 30.29962189436239 35.66853331482213 139.74801220618775 30.29962189436239</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_49c88477-fddf-4b27-93de-c85fc98aef8b">
									<gml:exterior>
										<gml:LinearRing gml:id="line_e29cf083-8012-4a4c-866b-e9ed497a6460">
											<gml:posList>35.66853331482213 139.74801220618775 30.29962189436239 35.66853552865205 139.7480056172869 30.29962189436239 35.66853331482213 139.74801220618775 28.98754914045614 35.66853331482213 139.74801220618775 30.29962189436239</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_d6268da8-93e5-444c-b419-7c2e90a43c2d">
									<gml:exterior>
										<gml:LinearRing gml:id="line_c6aee40b-b722-41d0-b340-0390435168bb">
											<gml:posList>35.66856262697436 139.74792496973683 37.902504279616295 35.66854953245749 139.74796394034698 36.40827973127645 35.668547264690574 139.74797068926028 36.40827973127645 35.66856262697436 139.74792496973683 37.902504279616295</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_eaa33a05-b964-4c19-aae4-57ca6c374e2b">
									<gml:exterior>
										<gml:LinearRing gml:id="line_63846f5a-0663-4c51-b4b6-4e2ede4f7e44">
											<gml:posList>35.66854953245749 139.74796394034698 36.40827973127645 35.66856262697436 139.74792496973683 37.902504279616295 35.66854953245749 139.74796394034698 35.0962069773702 35.66854953245749 139.74796394034698 36.40827973127645</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_06c01ec0-ba69-4238-88b8-fb43790d96a2">
									<gml:exterior>
										<gml:LinearRing gml:id="line_03bfeee7-2d62-416e-9a75-0bb79f174c4f">
											<gml:posList>35.66856262697436 139.74792496973683 37.902504279616295 35.668547264690574 139.74797068926028 36.40827973127645 35.66854505086256 139.74797727816306 36.40827973127645 35.66856262697436 139.74792496973683 37.902504279616295</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_02cee936-e4f2-48ae-ba66-d37eef57adf0">
									<gml:exterior>
										<gml:LinearRing gml:id="line_56b5f0a0-ae99-4d2d-82c8-b865bb72f039">
											<gml:posList>35.66856262697436 139.74792496973683 37.902504279616295 35.66854505086256 139.74797727816306 36.40827973127645 35.66854279462402 139.7479839930165 36.40827973127645 35.66856262697436 139.74792496973683 37.902504279616295</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_832cf563-4bbf-4dc0-bbb0-427cb2f9dfe3">
									<gml:exterior>
										<gml:LinearRing gml:id="line_1e40898d-4506-4e73-a4a4-c4efbcfd3dab">
											<gml:posList>35.66854505086256 139.74797727816306 36.40827973127645 35.668547264690574 139.74797068926028 36.40827973127645 35.66854505086256 139.74797727816306 35.0962069773702 35.66854505086256 139.74797727816306 36.40827973127645</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_739d963e-1cfa-4967-8bbb-1a1af7b49553">
									<gml:exterior>
										<gml:LinearRing gml:id="line_4717623d-79fb-41a9-9eb4-a142d325aec3">
											<gml:posList>35.66854505086256 139.74797727816306 35.0962069773702 35.668547264690574 139.74797068926028 36.40827973127645 35.668547264690574 139.74797068926028 35.0962069773702 35.66854505086256 139.74797727816306 35.0962069773702</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_d804b054-27d8-417e-a58e-3d88bd6c701d">
									<gml:exterior>
										<gml:LinearRing gml:id="line_fcaab60e-3502-4647-ad90-52e63dce4333">
											<gml:posList>35.66854505086256 139.74797727816306 35.0962069773702 35.668547264690574 139.74797068926028 35.0962069773702 35.668547264690574 139.74797068926028 33.35395081281942 35.66854505086256 139.74797727816306 35.0962069773702</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_2a77f7fc-ef34-4b9a-b958-9b92ab39eac6">
									<gml:exterior>
										<gml:LinearRing gml:id="line_06dc1d58-725d-4a06-9340-2625fa582744">
											<gml:posList>35.66854505086256 139.74797727816306 35.0962069773702 35.668547264690574 139.74797068926028 33.35395081281942 35.66854505086256 139.74797727816306 33.35395081281942 35.66854505086256 139.74797727816306 35.0962069773702</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_5feac9e7-fc6e-48c3-8883-4fc0f232c810">
									<gml:exterior>
										<gml:LinearRing gml:id="line_997ce85e-ac85-417c-b10a-cac671cc476e">
											<gml:posList>35.66854505086256 139.74797727816306 33.35395081281942 35.668547264690574 139.74797068926028 33.35395081281942 35.668547264690574 139.74797068926028 32.04187805891317 35.66854505086256 139.74797727816306 33.35395081281942</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_1b4589b8-2a36-40c7-94f1-0eb11d278dcb">
									<gml:exterior>
										<gml:LinearRing gml:id="line_247b675c-ae41-45c1-b227-932780a1b057">
											<gml:posList>35.66856262697436 139.74792496973683 37.902504279616295 35.66854279462402 139.7479839930165 36.40827973127645 35.66853779642093 139.7479988683756 36.40827973127645 35.66856262697436 139.74792496973683 37.902504279616295</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_285b61e6-48c4-44ce-925d-87fc909b4fe0">
									<gml:exterior>
										<gml:LinearRing gml:id="line_cee87f9f-f83d-42af-babf-3f5d68aa0b0f">
											<gml:posList>35.66856262697436 139.74792496973683 37.902504279616295 35.66853779642093 139.7479988683756 36.40827973127645 35.66851072947919 139.74807942246645 37.902504279616295 35.66856262697436 139.74792496973683 37.902504279616295</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_60b93bf5-7049-40ae-906f-7d16cdca4347">
									<gml:exterior>
										<gml:LinearRing gml:id="line_c4675492-c913-45bc-9367-2f8a5a7d6653">
											<gml:posList>35.66853779642093 139.7479988683756 36.40827973127645 35.66854279462402 139.7479839930165 36.40827973127645 35.66854279462402 139.7479839930165 35.0962069773702 35.66853779642093 139.7479988683756 36.40827973127645</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_df6e57b1-391f-4cae-bcb1-1772cbf4b429">
									<gml:exterior>
										<gml:LinearRing gml:id="line_4bf25a28-d06c-473d-8ef0-e3439d931930">
											<gml:posList>35.66853779642093 139.7479988683756 36.40827973127645 35.66854279462402 139.7479839930165 35.0962069773702 35.66853779642093 139.7479988683756 35.0962069773702 35.66853779642093 139.7479988683756 36.40827973127645</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_8a1c47ef-63bf-40dd-a96e-24b9507277c9">
									<gml:exterior>
										<gml:LinearRing gml:id="line_11fa4855-9a91-4dbf-850a-440ce32e76ed">
											<gml:posList>35.66853779642093 139.7479988683756 33.35395081281942 35.66854279462402 139.7479839930165 33.35395081281942 35.66854279462402 139.7479839930165 32.04187805891317 35.66853779642093 139.7479988683756 33.35395081281942</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_3955b620-21a8-4c0b-8f6e-de0e772dcedf">
									<gml:exterior>
										<gml:LinearRing gml:id="line_3e4002d1-6654-40bd-8e2b-f08b662676eb">
											<gml:posList>35.66853779642093 139.7479988683756 33.35395081281942 35.66854279462402 139.7479839930165 32.04187805891317 35.66853779642093 139.7479988683756 32.04187805891317 35.66853779642093 139.7479988683756 33.35395081281942</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_3d76f715-ae43-4111-83f9-171fa4ebfa64">
									<gml:exterior>
										<gml:LinearRing gml:id="line_ec22536a-1630-4c40-98b2-11302af8fb41">
											<gml:posList>35.66851072947919 139.74807942246645 37.902504279616295 35.66853779642093 139.7479988683756 36.40827973127645 35.66853552865205 139.7480056172869 36.40827973127645 35.66851072947919 139.74807942246645 37.902504279616295</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_6c90238c-da7e-4705-94e5-78e2382afe16">
									<gml:exterior>
										<gml:LinearRing gml:id="line_a724bc32-c7f1-4543-bb9b-a4ce212759d4">
											<gml:posList>35.66851072947919 139.74807942246645 37.902504279616295 35.66853552865205 139.7480056172869 36.40827973127645 35.66853331482213 139.74801220618775 36.40827973127645 35.66851072947919 139.74807942246645 37.902504279616295</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_c32d6981-c6d5-42b7-aa8a-18ddb7835b8c">
									<gml:exterior>
										<gml:LinearRing gml:id="line_fda373e6-87b3-4b4c-a74f-091024a614c1">
											<gml:posList>35.66853331482213 139.74801220618775 36.40827973127645 35.66853552865205 139.7480056172869 36.40827973127645 35.66853331482213 139.74801220618775 35.0962069773702 35.66853331482213 139.74801220618775 36.40827973127645</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_c2da0fb4-9150-4779-b2db-745538a3bbf1">
									<gml:exterior>
										<gml:LinearRing gml:id="line_2dc585fc-547d-454b-847a-2d597e6c31de">
											<gml:posList>35.66853331482213 139.74801220618775 35.0962069773702 35.66853552865205 139.7480056172869 36.40827973127645 35.66853552865205 139.7480056172869 35.0962069773702 35.66853331482213 139.74801220618775 35.0962069773702</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_2578876d-0bea-4320-b402-94bfaa26702f">
									<gml:exterior>
										<gml:LinearRing gml:id="line_3b01e5da-5d1d-40c5-863b-b4a0661e628d">
											<gml:posList>35.66851072947919 139.74807942246645 37.902504279616295 35.66853331482213 139.74801220618775 36.40827973127645 35.668531058581614 139.74801892103923 36.40827973127645 35.66851072947919 139.74807942246645 37.902504279616295</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_d03d34a4-f8de-49ad-b3a1-36612764b18d">
									<gml:exterior>
										<gml:LinearRing gml:id="line_7cb582b2-47ec-4f60-928e-73851612271c">
											<gml:posList>35.66851072947919 139.74807942246645 37.902504279616295 35.668531058581614 139.74801892103923 36.40827973127645 35.668531058581614 139.74801892103923 35.0962069773702 35.66851072947919 139.74807942246645 37.902504279616295</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_83d55cbf-035e-457d-a736-3ed49aa7d7c3">
									<gml:exterior>
										<gml:LinearRing gml:id="line_be3de71f-616d-42d2-bb1a-eeee86a22296">
											<gml:posList>35.66851072947919 139.74807942246645 37.902504279616295 35.668531058581614 139.74801892103923 35.0962069773702 35.668531058581614 139.74801892103923 33.35395081281942 35.66851072947919 139.74807942246645 37.902504279616295</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_ac1c230b-d6b9-47b3-a504-4cfe00188066">
									<gml:exterior>
										<gml:LinearRing gml:id="line_8ea49807-ccc5-4618-b1e5-d50e8e6440e5">
											<gml:posList>35.66851072947919 139.74807942246645 37.902504279616295 35.668531058581614 139.74801892103923 33.35395081281942 35.668531058581614 139.74801892103923 32.04187805891317 35.66851072947919 139.74807942246645 37.902504279616295</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_2b4eb642-7667-4c94-b690-5e8e979cc42e">
									<gml:exterior>
										<gml:LinearRing gml:id="line_e62f0ff4-a02b-4bda-b071-557bb9f55c3d">
											<gml:posList>35.66853552865205 139.7480056172869 35.0962069773702 35.66853331482213 139.74801220618775 33.35395081281942 35.66853331482213 139.74801220618775 35.0962069773702 35.66853552865205 139.7480056172869 35.0962069773702</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_8d0cfd1f-fc9c-4800-8936-6e2a5a96391a">
									<gml:exterior>
										<gml:LinearRing gml:id="line_01753210-3cbb-40df-9adc-9a9a0f714cb1">
											<gml:posList>35.66853331482213 139.74801220618775 33.35395081281942 35.66853552865205 139.7480056172869 33.35395081281942 35.66853552865205 139.7480056172869 32.04187805891317 35.66853331482213 139.74801220618775 33.35395081281942</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_ef9aab51-0bfd-461e-94e9-0392c5860493">
									<gml:exterior>
										<gml:LinearRing gml:id="line_cd771d00-f4e5-4c3e-a343-ab8b7075f42c">
											<gml:posList>35.66853331482213 139.74801220618775 32.04187805891317 35.66853331482213 139.74801220618775 30.29962189436239 35.668531058581614 139.74801892103923 30.29962189436239 35.66853331482213 139.74801220618775 32.04187805891317</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_a2629455-8b43-41ce-8377-f554e191b45d">
									<gml:exterior>
										<gml:LinearRing gml:id="line_5d72c263-304e-427a-9a27-46a01e7216ad">
											<gml:posList>35.66853331482213 139.74801220618775 32.04187805891317 35.668531058581614 139.74801892103923 30.29962189436239 35.668531058581614 139.74801892103923 32.04187805891317 35.66853331482213 139.74801220618775 32.04187805891317</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_54b55bd5-b17c-48a0-823a-4c28cc9cdef1">
									<gml:exterior>
										<gml:LinearRing gml:id="line_bd5a1b6d-615a-4629-9191-48ac02812605">
											<gml:posList>35.668531058581614 139.74801892103923 35.0962069773702 35.66853331482213 139.74801220618775 33.35395081281942 35.668531058581614 139.74801892103923 33.35395081281942 35.668531058581614 139.74801892103923 35.0962069773702</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_b7bde1bf-4754-4289-87a6-47f66a09131a">
									<gml:exterior>
										<gml:LinearRing gml:id="line_6d3d45fd-7cb9-48c3-8548-0fa3dcdd1197">
											<gml:posList>35.66853331482213 139.74801220618775 33.35395081281942 35.668531058581614 139.74801892103923 35.0962069773702 35.66853331482213 139.74801220618775 35.0962069773702 35.66853331482213 139.74801220618775 33.35395081281942</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_7a2a695c-d4cb-4694-bf08-b4f74f13bc88">
									<gml:exterior>
										<gml:LinearRing gml:id="line_6d51b1fc-f1de-43f0-9a68-6b6b02f38ec3">
											<gml:posList>35.66853779642093 139.7479988683756 32.04187805891317 35.66854279462402 139.7479839930165 32.04187805891317 35.66854279462402 139.7479839930165 30.29962189436239 35.66853779642093 139.7479988683756 32.04187805891317</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
					<bldg:opening>
						<bldg:Window gml:id="wnd_8c10559d-8887-48b7-9781-d41f6ff1a1c1">
							<bldg:lod3MultiSurface>
								<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_c7a69410-707d-459d-819d-16ad0ef0a908">
											<gml:exterior>
												<gml:LinearRing gml:id="line_59435388-370a-4eeb-8b68-3e2a21191a74">
													<gml:posList>35.66853331482213 139.74801220618775 30.29962189436239 35.66853331482213 139.74801220618775 28.98754914045614 35.668531058581614 139.74801892103923 30.29962189436239 35.66853331482213 139.74801220618775 30.29962189436239</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_37572902-9397-44a3-9f36-cebea84d223e">
											<gml:exterior>
												<gml:LinearRing gml:id="line_9cb1da14-bd40-4c32-ba61-2a5050d4b858">
													<gml:posList>35.668531058581614 139.74801892103923 30.29962189436239 35.66853331482213 139.74801220618775 28.98754914045614 35.668531058581614 139.74801892103923 28.98754914045614 35.668531058581614 139.74801892103923 30.29962189436239</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
								</gml:MultiSurface>
							</bldg:lod3MultiSurface>
						</bldg:Window>
					</bldg:opening>
					<bldg:opening>
						<bldg:Window gml:id="wnd_c2437753-6747-4143-9ebd-d71e3113f9fc">
							<bldg:lod3MultiSurface>
								<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_38da0fb1-d436-4a8e-97c2-5fee08aff69a">
											<gml:exterior>
												<gml:LinearRing gml:id="line_4c13a6f4-0e4e-411f-9ba8-abb105301fe6">
													<gml:posList>35.66853779642093 139.7479988683756 30.29962189436239 35.66853779642093 139.7479988683756 28.98754914045614 35.66853552865205 139.7480056172869 28.98754914045614 35.66853779642093 139.7479988683756 30.29962189436239</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_f22be188-b248-4927-8849-783f3d124989">
											<gml:exterior>
												<gml:LinearRing gml:id="line_315b4b0f-b5ad-44df-9695-7d2535e17d7a">
													<gml:posList>35.66853779642093 139.7479988683756 30.29962189436239 35.66853552865205 139.7480056172869 28.98754914045614 35.66853552865205 139.7480056172869 30.29962189436239 35.66853779642093 139.7479988683756 30.29962189436239</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
								</gml:MultiSurface>
							</bldg:lod3MultiSurface>
						</bldg:Window>
					</bldg:opening>
					<bldg:opening>
						<bldg:Window gml:id="wnd_9bd88e73-8a8f-4244-990f-476f9bfaabc3">
							<bldg:lod3MultiSurface>
								<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_a09bf501-4fa6-4883-9e8a-40747597c357">
											<gml:exterior>
												<gml:LinearRing gml:id="line_27690eb2-9ff7-48cf-92ca-d8b84c180e81">
													<gml:posList>35.66854953245749 139.74796394034698 30.29962189436239 35.66854953245749 139.74796394034698 28.98754914045614 35.668547264690574 139.74797068926028 30.29962189436239 35.66854953245749 139.74796394034698 30.29962189436239</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_7f840771-c3a3-406d-9a72-3eaf485af0bf">
											<gml:exterior>
												<gml:LinearRing gml:id="line_6c15f8f0-a6f4-4d7b-a1f3-f9836b5aa076">
													<gml:posList>35.668547264690574 139.74797068926028 30.29962189436239 35.66854953245749 139.74796394034698 28.98754914045614 35.668547264690574 139.74797068926028 28.98754914045614 35.668547264690574 139.74797068926028 30.29962189436239</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
								</gml:MultiSurface>
							</bldg:lod3MultiSurface>
						</bldg:Window>
					</bldg:opening>
					<bldg:opening>
						<bldg:Window gml:id="wnd_6b436e67-d786-46d7-8620-0b2eafb83fa6">
							<bldg:lod3MultiSurface>
								<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_2257b106-bb00-4097-851a-99055e9e100c">
											<gml:exterior>
												<gml:LinearRing gml:id="line_e16b3268-eb35-419b-bdd5-b00f37c68f8a">
													<gml:posList>35.66854505086256 139.74797727816306 30.29962189436239 35.66854505086256 139.74797727816306 28.98754914045614 35.66854279462402 139.7479839930165 30.29962189436239 35.66854505086256 139.74797727816306 30.29962189436239</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_1a257125-f1b3-4c1e-9099-93f5a6462632">
											<gml:exterior>
												<gml:LinearRing gml:id="line_8ce91944-aacb-4cbc-a4bd-c1a286128fcf">
													<gml:posList>35.66854279462402 139.7479839930165 30.29962189436239 35.66854505086256 139.74797727816306 28.98754914045614 35.66854279462402 139.7479839930165 28.98754914045614 35.66854279462402 139.7479839930165 30.29962189436239</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
								</gml:MultiSurface>
							</bldg:lod3MultiSurface>
						</bldg:Window>
					</bldg:opening>
					<bldg:opening>
						<bldg:Window gml:id="wnd_a9db72a2-0455-4824-8ef4-4b76b7786e4e">
							<bldg:lod3MultiSurface>
								<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_760c47e3-f55c-4f56-9a1d-1a420def5434">
											<gml:exterior>
												<gml:LinearRing gml:id="line_1f7e0d92-ba85-4891-acbd-2880ee421036">
													<gml:posList>35.66854953245749 139.74796394034698 33.35395081281942 35.66854953245749 139.74796394034698 32.04187805891317 35.668547264690574 139.74797068926028 32.04187805891317 35.66854953245749 139.74796394034698 33.35395081281942</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_c1912dca-dbe7-451c-9cd1-223698348f43">
											<gml:exterior>
												<gml:LinearRing gml:id="line_2ee6b248-0702-412b-ae22-47f092115647">
													<gml:posList>35.66854953245749 139.74796394034698 33.35395081281942 35.668547264690574 139.74797068926028 32.04187805891317 35.668547264690574 139.74797068926028 33.35395081281942 35.66854953245749 139.74796394034698 33.35395081281942</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
								</gml:MultiSurface>
							</bldg:lod3MultiSurface>
						</bldg:Window>
					</bldg:opening>
					<bldg:opening>
						<bldg:Window gml:id="wnd_329be6f8-181e-44ac-902f-aa3dd7326ff2">
							<bldg:lod3MultiSurface>
								<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_863d02c5-caf9-41bd-84db-f957c64ae3f4">
											<gml:exterior>
												<gml:LinearRing gml:id="line_a7e96c33-ed0a-4d99-bc9c-8c1214d39c11">
													<gml:posList>35.66854505086256 139.74797727816306 36.40827973127645 35.66854505086256 139.74797727816306 35.0962069773702 35.66854279462402 139.7479839930165 36.40827973127645 35.66854505086256 139.74797727816306 36.40827973127645</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_0afe2335-2a24-41d1-846b-e0fe94288bea">
											<gml:exterior>
												<gml:LinearRing gml:id="line_1fa6af74-b7c9-487e-91be-83df6b92455a">
													<gml:posList>35.66854279462402 139.7479839930165 36.40827973127645 35.66854505086256 139.74797727816306 35.0962069773702 35.66854279462402 139.7479839930165 35.0962069773702 35.66854279462402 139.7479839930165 36.40827973127645</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
								</gml:MultiSurface>
							</bldg:lod3MultiSurface>
						</bldg:Window>
					</bldg:opening>
					<bldg:opening>
						<bldg:Window gml:id="wnd_e8ccabe8-fd3b-4da8-8672-23745854a47e">
							<bldg:lod3MultiSurface>
								<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_2d56f6bf-bc83-4b3d-8182-22b5eb9aa410">
											<gml:exterior>
												<gml:LinearRing gml:id="line_4748a7a7-b107-4de3-9029-3574bc047029">
													<gml:posList>35.66854505086256 139.74797727816306 33.35395081281942 35.66854505086256 139.74797727816306 32.04187805891317 35.66854279462402 139.7479839930165 33.35395081281942 35.66854505086256 139.74797727816306 33.35395081281942</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_f3b82076-f951-4a03-8a29-4019077a47c2">
											<gml:exterior>
												<gml:LinearRing gml:id="line_036aed3f-c4b5-4441-9380-1cbb4f81a19e">
													<gml:posList>35.66854279462402 139.7479839930165 33.35395081281942 35.66854505086256 139.74797727816306 32.04187805891317 35.66854279462402 139.7479839930165 32.04187805891317 35.66854279462402 139.7479839930165 33.35395081281942</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
								</gml:MultiSurface>
							</bldg:lod3MultiSurface>
						</bldg:Window>
					</bldg:opening>
					<bldg:opening>
						<bldg:Window gml:id="wnd_08ccf9a5-bebf-4be0-9842-35e7547efbdd">
							<bldg:lod3MultiSurface>
								<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_86dbb0a9-0fb2-48a0-82ac-21b5a068e862">
											<gml:exterior>
												<gml:LinearRing gml:id="line_03ff132e-cbee-4c0a-b345-cff0a4af5fa9">
													<gml:posList>35.66853779642093 139.7479988683756 33.35395081281942 35.66853779642093 139.7479988683756 32.04187805891317 35.66853552865205 139.7480056172869 32.04187805891317 35.66853779642093 139.7479988683756 33.35395081281942</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_caa4cba0-1e5d-43c3-ae51-cee5a52eca35">
											<gml:exterior>
												<gml:LinearRing gml:id="line_4581d326-53d9-4508-a7ca-7e73e18eb6c5">
													<gml:posList>35.66853779642093 139.7479988683756 33.35395081281942 35.66853552865205 139.7480056172869 32.04187805891317 35.66853552865205 139.7480056172869 33.35395081281942 35.66853779642093 139.7479988683756 33.35395081281942</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
								</gml:MultiSurface>
							</bldg:lod3MultiSurface>
						</bldg:Window>
					</bldg:opening>
					<bldg:opening>
						<bldg:Window gml:id="wnd_79296dc9-a4bb-44bb-96e6-bfa585a690bf">
							<bldg:lod3MultiSurface>
								<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_093b66a7-1f74-4e7c-8f0a-f52f47eb9157">
											<gml:exterior>
												<gml:LinearRing gml:id="line_077f1c70-4512-467d-9952-1249aa85f28d">
													<gml:posList>35.66854953245749 139.74796394034698 36.40827973127645 35.66854953245749 139.74796394034698 35.0962069773702 35.668547264690574 139.74797068926028 36.40827973127645 35.66854953245749 139.74796394034698 36.40827973127645</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_2e469c18-52da-4f0b-9857-292a9702e1c8">
											<gml:exterior>
												<gml:LinearRing gml:id="line_aa54947b-c5dd-4758-a658-10dce5d7acc9">
													<gml:posList>35.668547264690574 139.74797068926028 36.40827973127645 35.66854953245749 139.74796394034698 35.0962069773702 35.668547264690574 139.74797068926028 35.0962069773702 35.668547264690574 139.74797068926028 36.40827973127645</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
								</gml:MultiSurface>
							</bldg:lod3MultiSurface>
						</bldg:Window>
					</bldg:opening>
					<bldg:opening>
						<bldg:Window gml:id="wnd_e887b1be-9dc3-4bff-97f2-9054040ed9ff">
							<bldg:lod3MultiSurface>
								<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_bc9d07bd-42c3-44a7-94ef-702dc843cb23">
											<gml:exterior>
												<gml:LinearRing gml:id="line_57f26534-936b-41d6-a75d-734bc30f81e8">
													<gml:posList>35.66853779642093 139.7479988683756 36.40827973127645 35.66853779642093 139.7479988683756 35.0962069773702 35.66853552865205 139.7480056172869 35.0962069773702 35.66853779642093 139.7479988683756 36.40827973127645</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_05ec335f-4762-45c7-9c20-7384b478348c">
											<gml:exterior>
												<gml:LinearRing gml:id="line_7f080a17-ae1c-4442-bf0c-21034322528a">
													<gml:posList>35.66853779642093 139.7479988683756 36.40827973127645 35.66853552865205 139.7480056172869 35.0962069773702 35.66853552865205 139.7480056172869 36.40827973127645 35.66853779642093 139.7479988683756 36.40827973127645</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
								</gml:MultiSurface>
							</bldg:lod3MultiSurface>
						</bldg:Window>
					</bldg:opening>
					<bldg:opening>
						<bldg:Window gml:id="wnd_1f8c4f15-b53e-4d26-a5b3-acf9b12e2598">
							<bldg:lod3MultiSurface>
								<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_b46292fc-e672-4920-ad14-3ca70a1c38ba">
											<gml:exterior>
												<gml:LinearRing gml:id="line_a8730f32-c03d-4b0e-a244-f8746a0d3372">
													<gml:posList>35.66853331482213 139.74801220618775 36.40827973127645 35.66853331482213 139.74801220618775 35.0962069773702 35.668531058581614 139.74801892103923 36.40827973127645 35.66853331482213 139.74801220618775 36.40827973127645</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_000ec5f7-b34f-423e-ad1c-ce14228b7c14">
											<gml:exterior>
												<gml:LinearRing gml:id="line_168122e4-0eca-4e27-a1d4-c2d05b7b01ce">
													<gml:posList>35.668531058581614 139.74801892103923 36.40827973127645 35.66853331482213 139.74801220618775 35.0962069773702 35.668531058581614 139.74801892103923 35.0962069773702 35.668531058581614 139.74801892103923 36.40827973127645</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
								</gml:MultiSurface>
							</bldg:lod3MultiSurface>
						</bldg:Window>
					</bldg:opening>
					<bldg:opening>
						<bldg:Window gml:id="wnd_c9da1262-1697-48cd-ba56-05f80a40dd4b">
							<bldg:lod3MultiSurface>
								<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_76c5611b-da27-497c-963f-a8e72d901782">
											<gml:exterior>
												<gml:LinearRing gml:id="line_b66bb4ee-1dc1-49b2-ad06-bc5a3df05062">
													<gml:posList>35.66853331482213 139.74801220618775 33.35395081281942 35.66853331482213 139.74801220618775 32.04187805891317 35.668531058581614 139.74801892103923 33.35395081281942 35.66853331482213 139.74801220618775 33.35395081281942</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_46af3ce4-8b1b-4d70-94c1-26e7adb71a86">
											<gml:exterior>
												<gml:LinearRing gml:id="line_8c114f32-eb00-4f9d-879a-2f0d1159a880">
													<gml:posList>35.668531058581614 139.74801892103923 33.35395081281942 35.66853331482213 139.74801220618775 32.04187805891317 35.668531058581614 139.74801892103923 32.04187805891317 35.668531058581614 139.74801892103923 33.35395081281942</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
								</gml:MultiSurface>
							</bldg:lod3MultiSurface>
						</bldg:Window>
					</bldg:opening>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_f1e330a0-4712-40a4-9af7-4f649842bc92">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_0db2893d-10c1-426d-abe5-dd1b3ae9ddaa">
									<gml:exterior>
										<gml:LinearRing gml:id="line_5ae6270c-c4ef-40cc-b59a-6c2d6802858e">
											<gml:posList>35.668628031727216 139.74780661061828 30.426239326003014 35.66862642811532 139.74781138344156 30.322609260085045 35.66862642811532 139.74781138344156 29.057709052565514 35.668628031727216 139.74780661061828 30.426239326003014</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_cda17be1-9527-41bb-9f4f-0b0c82f41f52">
									<gml:exterior>
										<gml:LinearRing gml:id="line_d8fef124-be5d-45c7-8bd6-15e9e69165bf">
											<gml:posList>35.66862642811532 139.74781138344156 30.322609260085045 35.668628031727216 139.74780661061828 30.426239326003014 35.66862642811532 139.74781138344156 30.426239326003014 35.66862642811532 139.74781138344156 30.322609260085045</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_40446bae-28cf-433a-b49f-30d35c8f936c">
									<gml:exterior>
										<gml:LinearRing gml:id="line_fa4edc84-8ac5-4d8a-a03b-48b363682fa2">
											<gml:posList>35.66862642811532 139.74781138344156 29.057709052565514 35.668628031727216 139.74780661061828 28.267662360670982 35.668628031727216 139.74780661061828 30.426239326003014 35.66862642811532 139.74781138344156 29.057709052565514</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_db976a9a-f35f-4330-8a2f-057513026184">
									<gml:exterior>
										<gml:LinearRing gml:id="line_be8c6001-3589-4be8-8fab-e3a31c4e1269">
											<gml:posList>35.668628031727216 139.74780661061828 28.267662360670982 35.66862642811532 139.74781138344156 29.057709052565514 35.66862642811532 139.74781138344156 28.267662360670982 35.668628031727216 139.74780661061828 28.267662360670982</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_dd5561da-b203-45c5-9481-30f16cb0c5bc">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_305c4152-7bd3-4c4e-86bd-cabc36f31e4d">
									<gml:exterior>
										<gml:LinearRing gml:id="line_477f43b3-9347-4934-9765-cc02a6a944fb">
											<gml:posList>35.66868526091045 139.74782098748136 32.37877686262411 35.668690275854296 139.74782351812135 31.77742035627645 35.668690275854296 139.74782351812135 33.486000373366295 35.66868526091045 139.74782098748136 32.37877686262411</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_1d30836d-4e67-4829-b5d1-8e87585ddadb">
									<gml:exterior>
										<gml:LinearRing gml:id="line_5775430e-a5b4-4bc8-9125-4f28d19dd2a3">
											<gml:posList>35.668690275854296 139.74782351812135 31.77742035627645 35.66868526091045 139.74782098748136 32.37877686262411 35.66868526091045 139.74782098748136 31.77742035627645 35.668690275854296 139.74782351812135 31.77742035627645</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_17ff2a6e-4125-4152-98a7-2b06a341c3fd">
									<gml:exterior>
										<gml:LinearRing gml:id="line_99509532-71ee-41bc-9a46-0ef4d912e93a">
											<gml:posList>35.66868526091045 139.74782098748136 32.37877686262411 35.668690275854296 139.74782351812135 33.486000373366295 35.66868477962785 139.74782074477844 33.486000373366295 35.66868526091045 139.74782098748136 32.37877686262411</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_3005aa84-6c95-4ac8-b5c0-b0061fde9e25">
									<gml:exterior>
										<gml:LinearRing gml:id="line_87ced9a6-f20d-4ad8-9f29-18c5de6244d9">
											<gml:posList>35.66868526091045 139.74782098748136 32.37877686262411 35.66868477962785 139.74782074477844 33.486000373366295 35.66868477962785 139.74782074477844 32.37877686262411 35.66868526091045 139.74782098748136 32.37877686262411</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_c0dc9f8b-90cb-41a2-9e0a-cc5be04e6659">
									<gml:exterior>
										<gml:LinearRing gml:id="line_1fc0749b-6e6e-43ba-a354-4dff7eae3a68">
											<gml:posList>35.66868526091045 139.74782098748136 32.37877686262411 35.66868477962785 139.74782074477844 32.37877686262411 35.66868526091045 139.74782098748136 31.77742035627645 35.66868526091045 139.74782098748136 32.37877686262411</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_5254ea57-1884-43b4-a607-51632c3c6a91">
									<gml:exterior>
										<gml:LinearRing gml:id="line_9fd1671d-18a0-4e59-a410-ec41c8055f1d">
											<gml:posList>35.66868526091045 139.74782098748136 31.77742035627645 35.66868477962785 139.74782074477844 32.37877686262411 35.66868477962785 139.74782074477844 31.77742035627645 35.66868526091045 139.74782098748136 31.77742035627645</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_0a4e8fb6-170e-4e2c-8e28-9a6c8b56e84b">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_095df9c4-436c-4f46-90bb-93487602c982">
									<gml:exterior>
										<gml:LinearRing gml:id="line_a22f39df-1b35-4662-ae72-64a60896cf20">
											<gml:posList>35.66868526091045 139.74782098748136 20.139732673170982 35.668690275854296 139.74782351812135 19.538376166823326 35.668690275854296 139.74782351812135 21.24694855451864 35.66868526091045 139.74782098748136 20.139732673170982</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_d5dd2ea3-6ed9-4dbb-a3d6-977e863ff2e5">
									<gml:exterior>
										<gml:LinearRing gml:id="line_b5da8b18-62e0-4562-b0c2-b595b8e22e71">
											<gml:posList>35.668690275854296 139.74782351812135 19.538376166823326 35.66868526091045 139.74782098748136 20.139732673170982 35.66868526091045 139.74782098748136 19.538376166823326 35.668690275854296 139.74782351812135 19.538376166823326</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_9c69d1fc-b6b6-473e-97fb-e8e451085e7f">
									<gml:exterior>
										<gml:LinearRing gml:id="line_98fc99a1-d735-4480-aa12-688a1c0fb593">
											<gml:posList>35.66868526091045 139.74782098748136 20.139732673170982 35.668690275854296 139.74782351812135 21.24694855451864 35.66868477962785 139.74782074477844 21.24694855451864 35.66868526091045 139.74782098748136 20.139732673170982</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_feb04a7c-f2b6-4fa6-b758-ce77d9f9ef6c">
									<gml:exterior>
										<gml:LinearRing gml:id="line_b9d83454-8212-4bc2-8a6b-6b4a28b6bb62">
											<gml:posList>35.66868526091045 139.74782098748136 20.139732673170982 35.66868477962785 139.74782074477844 21.24694855451864 35.66868477962785 139.74782074477844 20.139732673170982 35.66868526091045 139.74782098748136 20.139732673170982</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_a896180f-5bda-4bf3-9241-285c94f2e7e4">
									<gml:exterior>
										<gml:LinearRing gml:id="line_675c1ff6-278d-4d6f-8e84-df644f9d2d03">
											<gml:posList>35.66868526091045 139.74782098748136 20.139732673170982 35.66868477962785 139.74782074477844 20.139732673170982 35.66868526091045 139.74782098748136 19.538376166823326 35.66868526091045 139.74782098748136 20.139732673170982</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_b760b6bc-e584-4d70-b131-b61d3c839b75">
									<gml:exterior>
										<gml:LinearRing gml:id="line_a652691d-cbd3-4e45-96b7-fe0c7cb4b52e">
											<gml:posList>35.66868526091045 139.74782098748136 19.538376166823326 35.66868477962785 139.74782074477844 20.139732673170982 35.66868477962785 139.74782074477844 19.538376166823326 35.66868526091045 139.74782098748136 19.538376166823326</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_bc0bb6e4-715d-4c02-bc6c-1422372f696f">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_83984f05-6276-461a-b732-194af41af613">
									<gml:exterior>
										<gml:LinearRing gml:id="line_ed6a21fe-4508-4d96-90db-90794c42eeb5">
											<gml:posList>35.668631888868546 139.7478085569517 28.267662360670982 35.668630285119036 139.74781332977528 29.057709052565514 35.668631888868546 139.7478085569517 30.426239326003014 35.668631888868546 139.7478085569517 28.267662360670982</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_6c3cd2c3-8b5e-403a-8a4c-e1362ef4993f">
									<gml:exterior>
										<gml:LinearRing gml:id="line_6c1f8914-9370-4fb7-abb7-fb9f1d605db5">
											<gml:posList>35.668630285119036 139.74781332977528 29.057709052565514 35.668631888868546 139.7478085569517 28.267662360670982 35.668630285119036 139.74781332977528 28.267662360670982 35.668630285119036 139.74781332977528 29.057709052565514</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_fa3d39e0-15c0-4600-b140-e6152e0f1726">
									<gml:exterior>
										<gml:LinearRing gml:id="line_93961d2c-e716-4ceb-964f-b1ebe90ffb7a">
											<gml:posList>35.668631888868546 139.7478085569517 30.426239326003014 35.668630285119036 139.74781332977528 29.057709052565514 35.668630285119036 139.74781332977528 30.322609260085045 35.668631888868546 139.7478085569517 30.426239326003014</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_8b37e68b-0cf2-4a38-b551-2f1494bfb79e">
									<gml:exterior>
										<gml:LinearRing gml:id="line_19aa26fd-35e5-40b6-8e11-a14237f83e6e">
											<gml:posList>35.668631888868546 139.7478085569517 30.426239326003014 35.668630285119036 139.74781332977528 30.322609260085045 35.668630285119036 139.74781332977528 30.426239326003014 35.668631888868546 139.7478085569517 30.426239326003014</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
					<bldg:opening>
						<bldg:Window gml:id="wnd_368cf952-af80-4ceb-966b-c258f9f74522">
							<bldg:lod3MultiSurface>
								<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_9d37c1c6-cc18-4612-80c7-a2bd1b5da1c7">
											<gml:exterior>
												<gml:LinearRing gml:id="line_d600e2d3-17db-4c2d-819e-d93fca8190c1">
													<gml:posList>35.668630285119036 139.74781332977528 30.322609260085045 35.668630285119036 139.74781332977528 29.057709052565514 35.66862642811532 139.74781138344156 30.322609260085045 35.668630285119036 139.74781332977528 30.322609260085045</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_e4385306-8d76-462f-a36a-1a223759ea10">
											<gml:exterior>
												<gml:LinearRing gml:id="line_9d4aa8fb-8e7a-4137-abb9-9b2f0c05d168">
													<gml:posList>35.66862642811532 139.74781138344156 30.322609260085045 35.668630285119036 139.74781332977528 29.057709052565514 35.66862642811532 139.74781138344156 29.057709052565514 35.66862642811532 139.74781138344156 30.322609260085045</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
								</gml:MultiSurface>
							</bldg:lod3MultiSurface>
						</bldg:Window>
					</bldg:opening>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_2bb85164-ed71-419f-84b6-aa1da6a33149">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_13fe9845-cbb0-4914-83ff-70eddc8474bd">
									<gml:exterior>
										<gml:LinearRing gml:id="line_21197e1e-4581-4ff3-b25c-df158236817a">
											<gml:posList>35.66867316936178 139.74783496920924 27.262848212721764 35.668669312220906 139.74783302287355 27.262848212721764 35.66867316936178 139.74783496920924 27.3664706492452 35.66867316936178 139.74783496920924 27.262848212721764</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_c943c5a1-e2d3-411b-ba1c-19728571163b">
									<gml:exterior>
										<gml:LinearRing gml:id="line_592c6860-e304-4e86-9bc1-1bb86e2720f9">
											<gml:posList>35.66867316936178 139.74783496920924 27.3664706492452 35.668669312220906 139.74783302287355 27.262848212721764 35.668669312220906 139.74783302287355 27.3664706492452 35.66867316936178 139.74783496920924 27.3664706492452</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="wall_TMmnt0161_p994_1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly_TMmnt0161_p994_1">
									<gml:exterior>
										<gml:LinearRing gml:id="line_TMmnt0161_p994_1">
											<gml:posList>35.66860446358953 139.74795652105036 39.12472004 35.66860446824003 139.74795652213663 37.87472015 35.66861955321487 139.74791262976777 37.87509983 35.66861954856139 139.7479126286901 39.12509972 35.66860446358953 139.74795652105036 39.12472004</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_6f470520-a53e-4077-a9ef-e14f4c7aba6d">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_ced2daf1-bbde-440e-8953-c1ee10af57ca">
									<gml:exterior>
										<gml:LinearRing gml:id="line_36dde2ad-8c1a-4e50-bbee-ffcaed8b4c06">
											<gml:posList>35.668690275854296 139.74782351812135 13.418846442702232 35.66868610967223 139.747835916983 13.418846442702232 35.668690275854296 139.74782351812135 15.127426459792076 35.668690275854296 139.74782351812135 13.418846442702232</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_d0956ab7-3aca-4b4f-8206-621b9a2d7a75">
									<gml:exterior>
										<gml:LinearRing gml:id="line_8f7c1166-7444-4ecf-a735-a229f19c9aaa">
											<gml:posList>35.668690275854296 139.74782351812135 15.127426459792076 35.66868610967223 139.747835916983 13.418846442702232 35.66868610967223 139.747835916983 15.127426459792076 35.668690275854296 139.74782351812135 15.127426459792076</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="wall_TMmnt0161_p993_3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly_TMmnt0161_p993_3">
									<gml:exterior>
										<gml:LinearRing gml:id="line_TMmnt0161_p993_3">
											<gml:posList>35.668648625614985 139.74804686583292 5.4515043 35.66864849345966 139.74804683452038 40.90738724 35.66862620089855 139.74803532883664 40.90628161 35.668626332929605 139.74803536008534 5.45039866 35.668648625614985 139.74804686583292 5.4515043</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_a9290d97-ab30-4e3a-8aa6-f6ff10cbb00d">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_55d9f438-7338-417c-9804-417ddfd2e6d4">
									<gml:exterior>
										<gml:LinearRing gml:id="line_99b838b1-18b4-4e53-be45-96679050daad">
											<gml:posList>35.668631888868546 139.7478085569517 21.24694855451864 35.668630285119036 139.74781332977528 21.1433261179952 35.668630285119036 139.74781332977528 21.24694855451864 35.668631888868546 139.7478085569517 21.24694855451864</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_7d12fbdf-224a-4359-aa30-c4b62ce4e590">
									<gml:exterior>
										<gml:LinearRing gml:id="line_b9c37486-c07d-4812-b005-7710aceb3fb8">
											<gml:posList>35.668630285119036 139.74781332977528 21.1433261179952 35.668631888868546 139.7478085569517 21.24694855451864 35.668630285119036 139.74781332977528 19.87842591047567 35.668630285119036 139.74781332977528 21.1433261179952</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_17124091-ed93-427c-8927-d9ca87425c91">
									<gml:exterior>
										<gml:LinearRing gml:id="line_c49dbf55-c126-41b7-a496-ed3aff46cf15">
											<gml:posList>35.668630285119036 139.74781332977528 19.87842591047567 35.668631888868546 139.7478085569517 21.24694855451864 35.668631888868546 139.7478085569517 19.088371589186607 35.668630285119036 139.74781332977528 19.87842591047567</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_480b74e2-3310-49ed-bbc4-0934c7eecd61">
									<gml:exterior>
										<gml:LinearRing gml:id="line_d8411073-cf34-4ed0-97b1-819e512cac4b">
											<gml:posList>35.668630285119036 139.74781332977528 19.87842591047567 35.668631888868546 139.7478085569517 19.088371589186607 35.668630285119036 139.74781332977528 19.088371589186607 35.668630285119036 139.74781332977528 19.87842591047567</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
					<bldg:opening>
						<bldg:Window gml:id="wnd_26e18932-e4aa-4afa-be79-cbd4d38d34c3">
							<bldg:lod3MultiSurface>
								<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_e51bba14-10e3-4da3-b09e-952e5bca25ba">
											<gml:exterior>
												<gml:LinearRing gml:id="line_61cc25fd-a8ec-4584-9471-09e62e23efbd">
													<gml:posList>35.668630285119036 139.74781332977528 21.1433261179952 35.668630285119036 139.74781332977528 19.87842591047567 35.66862642811532 139.74781138344156 21.1433261179952 35.668630285119036 139.74781332977528 21.1433261179952</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_0657b0df-8cb0-4a73-a018-f046af536231">
											<gml:exterior>
												<gml:LinearRing gml:id="line_10087ce5-da56-450b-b3f7-99904b62d3be">
													<gml:posList>35.66862642811532 139.74781138344156 21.1433261179952 35.668630285119036 139.74781332977528 19.87842591047567 35.66862642811532 139.74781138344156 19.87842591047567 35.66862642811532 139.74781138344156 21.1433261179952</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
								</gml:MultiSurface>
							</bldg:lod3MultiSurface>
						</bldg:Window>
					</bldg:opening>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_47e7d639-8e50-4dd3-a817-cc3877567886">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_4447abd4-7ba2-496a-b312-bb9be97f420b">
									<gml:exterior>
										<gml:LinearRing gml:id="line_f234fac5-4c77-45be-9c32-47d20610338b">
											<gml:posList>35.668690275854296 139.74782351812135 31.77742035627645 35.66868610967223 139.747835916983 31.77742035627645 35.66868610967223 139.747835916983 33.486000373366295 35.668690275854296 139.74782351812135 31.77742035627645</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_e3c712b9-813c-48d2-83aa-03eef487dd67">
									<gml:exterior>
										<gml:LinearRing gml:id="line_49d288fd-e64e-4c0f-929e-5c3c3ea59a8a">
											<gml:posList>35.668690275854296 139.74782351812135 31.77742035627645 35.66868610967223 139.747835916983 33.486000373366295 35.668690275854296 139.74782351812135 33.486000373366295 35.668690275854296 139.74782351812135 31.77742035627645</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_4b999b5a-b377-4487-92c8-b3bffe4b3145">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_34005c76-5904-460d-9623-e35c343da270">
									<gml:exterior>
										<gml:LinearRing gml:id="line_e7252b9f-bfd3-4a01-bb3a-87b92b227e72">
											<gml:posList>35.66868526091045 139.74782098748136 26.259254767897545 35.668690275854296 139.74782351812135 25.65789826154989 35.668690275854296 139.74782351812135 27.3664706492452 35.66868526091045 139.74782098748136 26.259254767897545</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_f17c21f5-a8d3-48b6-b8b5-92eae7011c8b">
									<gml:exterior>
										<gml:LinearRing gml:id="line_183476c9-b71b-4f50-846e-a984e3552a28">
											<gml:posList>35.668690275854296 139.74782351812135 25.65789826154989 35.66868526091045 139.74782098748136 26.259254767897545 35.66868526091045 139.74782098748136 25.65789826154989 35.668690275854296 139.74782351812135 25.65789826154989</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_8d526f45-5cdb-4772-8767-20b15de353ab">
									<gml:exterior>
										<gml:LinearRing gml:id="line_b8fc8a4d-907b-4b9e-b8bf-4e5876f31d46">
											<gml:posList>35.66868526091045 139.74782098748136 26.259254767897545 35.668690275854296 139.74782351812135 27.3664706492452 35.66868477962785 139.74782074477844 27.3664706492452 35.66868526091045 139.74782098748136 26.259254767897545</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_5f84dc84-54e3-4d1c-8ffa-adb2330ae18a">
									<gml:exterior>
										<gml:LinearRing gml:id="line_162c3e50-0b30-45ad-bc1a-ab567e0da9c2">
											<gml:posList>35.66868526091045 139.74782098748136 26.259254767897545 35.66868477962785 139.74782074477844 27.3664706492452 35.66868477962785 139.74782074477844 26.259254767897545 35.66868526091045 139.74782098748136 26.259254767897545</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_97101368-4db9-4a50-8bc0-7a4a08ceec6c">
									<gml:exterior>
										<gml:LinearRing gml:id="line_d8a55ecc-ac81-456f-806a-6abdb74a2dc5">
											<gml:posList>35.66868526091045 139.74782098748136 26.259254767897545 35.66868477962785 139.74782074477844 26.259254767897545 35.66868526091045 139.74782098748136 25.65789826154989 35.66868526091045 139.74782098748136 26.259254767897545</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_b307da0f-d71e-465f-b077-da6539d2aa97">
									<gml:exterior>
										<gml:LinearRing gml:id="line_4f4855c5-f56e-4dea-8f9b-3f074353c55f">
											<gml:posList>35.66868526091045 139.74782098748136 25.65789826154989 35.66868477962785 139.74782074477844 26.259254767897545 35.66868477962785 139.74782074477844 25.65789826154989 35.66868526091045 139.74782098748136 25.65789826154989</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="wall_TMmnt0161_p994_3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly_TMmnt0161_p994_3">
									<gml:exterior>
										<gml:LinearRing gml:id="line_TMmnt0161_p994_3">
											<gml:posList>35.66860002688576 139.74790255310108 39.12413428 35.66860003153536 139.7479025541768 37.87413439 35.66858494667018 139.74794644658942 37.87375471 35.66858494202354 139.74794644550522 39.1237546 35.66860002688576 139.74790255310108 39.12413428</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_1553dd9e-71d8-4b54-a4a3-c46c01cea336">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_174c59b4-1b21-4731-9c79-dc0e7a3027fc">
									<gml:exterior>
										<gml:LinearRing gml:id="line_523eb4b6-3c2c-4a3a-b106-40d58aa11529">
											<gml:posList>35.66867316936178 139.74783496920924 30.322609260085045 35.668669312220906 139.74783302287355 30.322609260085045 35.66867316936178 139.74783496920924 30.426239326003014 35.66867316936178 139.74783496920924 30.322609260085045</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_8fa6d90e-a9a6-4921-915e-5c30fcb069b3">
									<gml:exterior>
										<gml:LinearRing gml:id="line_2aa117c9-38ad-4c3e-ae67-3a5304e8ea72">
											<gml:posList>35.66867316936178 139.74783496920924 30.426239326003014 35.668669312220906 139.74783302287355 30.322609260085045 35.668669312220906 139.74783302287355 30.426239326003014 35.66867316936178 139.74783496920924 30.426239326003014</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_0de97e75-0d43-49d5-a234-3cbea83ee072">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_f5727e4e-2c5b-410b-b3ac-1f8256dc93ff">
									<gml:exterior>
										<gml:LinearRing gml:id="line_1cab6058-f9f1-4b44-87b9-367e1310f618">
											<gml:posList>35.668669312220906 139.74783302287355 32.117470099928795 35.66867316936178 139.74783496920924 32.117470099928795 35.668669312220906 139.74783302287355 31.327423408034264 35.668669312220906 139.74783302287355 32.117470099928795</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_470ea7fd-846c-4793-8a50-f5a70c06bc50">
									<gml:exterior>
										<gml:LinearRing gml:id="line_e8970166-683b-47a7-848c-3baf2fe3e296">
											<gml:posList>35.668669312220906 139.74783302287355 31.327423408034264 35.66867316936178 139.74783496920924 32.117470099928795 35.66867316936178 139.74783496920924 31.327423408034264 35.668669312220906 139.74783302287355 31.327423408034264</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_04e99b3a-6486-4995-acb3-e61a55bde53e">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_be0aa18a-09f7-447e-8c49-3c3159e86113">
									<gml:exterior>
										<gml:LinearRing gml:id="line_342100c0-2361-437f-8a0d-3ffe19f76b03">
											<gml:posList>35.668648942130886 139.74804705098273 40.907394721510826 35.66862610337473 139.74803552647538 40.907394721510826 35.66862610337473 139.74803552647538 6.3942492747334825 35.668648942130886 139.74804705098273 40.907394721510826</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_895ae905-0d96-48e9-b898-c6d7f4aa66e4">
									<gml:exterior>
										<gml:LinearRing gml:id="line_3d76a0c4-f64d-465e-9bc0-732e821e6e55">
											<gml:posList>35.668648942130886 139.74804705098273 40.907394721510826 35.66862610337473 139.74803552647538 6.3942492747334825 35.668648942130886 139.74804705098273 6.3942492747334825 35.668648942130886 139.74804705098273 40.907394721510826</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_1c11770e-8581-4ee8-94d7-53fa4d70ec2e">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_f3463a67-f340-4de8-97b3-8668891d6e36">
									<gml:exterior>
										<gml:LinearRing gml:id="line_ee0e8d2a-a8b0-4f72-8779-df5f688a991c">
											<gml:posList>35.66862642811532 139.74781138344156 29.057709052565514 35.668630285119036 139.74781332977528 29.057709052565514 35.66862642811532 139.74781138344156 28.267662360670982 35.66862642811532 139.74781138344156 29.057709052565514</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_c1604968-1602-402b-9299-2713cd6ec9db">
									<gml:exterior>
										<gml:LinearRing gml:id="line_5e804ffb-2992-43d1-934f-8b4c9db3b903">
											<gml:posList>35.66862642811532 139.74781138344156 28.267662360670982 35.668630285119036 139.74781332977528 29.057709052565514 35.668630285119036 139.74781332977528 28.267662360670982 35.66862642811532 139.74781138344156 28.267662360670982</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="wall_TMmnt0161_p991_3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly_TMmnt0161_p991_3">
									<gml:exterior>
										<gml:LinearRing gml:id="line_TMmnt0161_p991_3">
											<gml:posList>35.66870048759267 139.74781924194826 34.61816069 35.66866771017094 139.74791461839294 34.61732286 35.668667698010054 139.74791461558144 37.87732257 35.66865426824419 139.74795369371623 37.87698327 35.66865438913517 139.7479537218797 5.45110006 35.668700596541825 139.74781926666608 5.4522772 35.66870048759267 139.74781924194826 34.61816069</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_7e7bd5e1-9019-4d7a-8107-a78071bdb061">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_117af173-f9d3-4df4-9f9d-1f8bbb767fb0">
									<gml:exterior>
										<gml:LinearRing gml:id="line_2417f941-3815-4ae6-ada8-09ebf8291dfe">
											<gml:posList>35.668690275854296 139.74782351812135 24.30670960188192 35.668690275854296 139.74782351812135 22.598137214186607 35.66868610967223 139.747835916983 24.30670960188192 35.668690275854296 139.74782351812135 24.30670960188192</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_1e85d81d-c596-4530-acf6-5857a4631ca2">
									<gml:exterior>
										<gml:LinearRing gml:id="line_9390f1e7-10f5-4226-b3cd-2f2d6b3220e0">
											<gml:posList>35.66868610967223 139.747835916983 24.30670960188192 35.668690275854296 139.74782351812135 22.598137214186607 35.66868610967223 139.747835916983 22.598137214186607 35.66868610967223 139.747835916983 24.30670960188192</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:OuterFloorSurface gml:id="gml_4e8a0c9b-df7d-497b-ba4a-f1b5ebc38e4b">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_c8f935d2-1d9f-4823-88cd-755f43450efd">
									<gml:exterior>
										<gml:LinearRing gml:id="line_c3278341-01a0-4633-b279-a4e9571ae82b">
											<gml:posList>35.668631888868546 139.7478085569517 19.088371589186607 35.668628031727216 139.74780661061828 19.088371589186607 35.668630285119036 139.74781332977528 19.088371589186607 35.668631888868546 139.7478085569517 19.088371589186607</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_219e88a7-90da-4cf2-b8e6-f9322a99a925">
									<gml:exterior>
										<gml:LinearRing gml:id="line_9b466c39-25c6-41b1-822c-3b6e459377f3">
											<gml:posList>35.668630285119036 139.74781332977528 19.088371589186607 35.668628031727216 139.74780661061828 19.088371589186607 35.66862642811532 139.74781138344156 19.088371589186607 35.668630285119036 139.74781332977528 19.088371589186607</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:OuterFloorSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:OuterFloorSurface gml:id="gml_bca095e3-deef-4a8b-98c9-49e4912289d7">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_f9e10d31-76b9-40d7-b8fc-36482b3a32e4">
									<gml:exterior>
										<gml:LinearRing gml:id="line_c03d59f6-6b73-4d49-85c1-22ddfe6b585c">
											<gml:posList>35.668690275854296 139.74782351812135 19.538376166823326 35.66868526091045 139.74782098748136 19.538376166823326 35.66868610967223 139.747835916983 19.538376166823326 35.668690275854296 139.74782351812135 19.538376166823326</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_b594ec47-c99b-4a24-8d19-d2b62788d82f">
									<gml:exterior>
										<gml:LinearRing gml:id="line_fbd2c723-6272-4036-8b85-cd8b5713b44b">
											<gml:posList>35.66868610967223 139.747835916983 19.538376166823326 35.66868526091045 139.74782098748136 19.538376166823326 35.6686752542573 139.74783043925513 19.538376166823326 35.66868610967223 139.747835916983 19.538376166823326</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_22600d32-d270-4f48-9ee3-8e7517508593">
									<gml:exterior>
										<gml:LinearRing gml:id="line_999a6c70-0dcb-4870-b19f-b4fba672bf24">
											<gml:posList>35.6686752542573 139.74783043925513 19.538376166823326 35.66868526091045 139.74782098748136 19.538376166823326 35.66868477962785 139.74782074477844 19.538376166823326 35.6686752542573 139.74783043925513 19.538376166823326</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_49a5a4d4-a224-45ff-aed6-d5362ffdb413">
									<gml:exterior>
										<gml:LinearRing gml:id="line_bdfcdd4a-2add-4f63-925b-ec98ec763c5b">
											<gml:posList>35.6686752542573 139.74783043925513 19.538376166823326 35.66868477962785 139.74782074477844 19.538376166823326 35.6686747729746 139.74783019638366 19.538376166823326 35.6686752542573 139.74783043925513 19.538376166823326</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:OuterFloorSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:OuterFloorSurface gml:id="gml_15cea78d-7a67-4d24-a9d0-b98aed77c583">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_6649ec54-1e0d-4269-a03f-c7a56e68bfb2">
									<gml:exterior>
										<gml:LinearRing gml:id="line_88190dbc-787e-4a7c-bf09-02e3b732e3ba">
											<gml:posList>35.668690275854296 139.74782351812135 22.598137214186607 35.66868526091045 139.74782098748136 22.598137214186607 35.66868610967223 139.747835916983 22.598137214186607 35.668690275854296 139.74782351812135 22.598137214186607</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_fbf6a8c5-3784-4ae9-aedb-14f6080436a4">
									<gml:exterior>
										<gml:LinearRing gml:id="line_3c07a9cc-dc0a-4f77-afdd-03904842f057">
											<gml:posList>35.66868610967223 139.747835916983 22.598137214186607 35.66868526091045 139.74782098748136 22.598137214186607 35.6686752542573 139.74783043925513 22.598137214186607 35.66868610967223 139.747835916983 22.598137214186607</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_7e5b065a-ade8-4bee-a8d6-b9b1aa1a3164">
									<gml:exterior>
										<gml:LinearRing gml:id="line_71847d53-2c51-4463-b90f-26bb657786ac">
											<gml:posList>35.6686752542573 139.74783043925513 22.598137214186607 35.66868526091045 139.74782098748136 22.598137214186607 35.66868477962785 139.74782074477844 22.598137214186607 35.6686752542573 139.74783043925513 22.598137214186607</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_92e9097a-3044-43dc-a7c2-6df6cef0d079">
									<gml:exterior>
										<gml:LinearRing gml:id="line_455410aa-daad-4ed5-815c-ef1b31fa3fec">
											<gml:posList>35.6686752542573 139.74783043925513 22.598137214186607 35.66868477962785 139.74782074477844 22.598137214186607 35.6686747729746 139.74783019638366 22.598137214186607 35.6686752542573 139.74783043925513 22.598137214186607</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:OuterFloorSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:OuterFloorSurface gml:id="gml_7bd8fc72-a75b-4e91-839e-7f51a24c4297">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_f811b9db-d2cf-4908-b786-044e7bdb2d71">
									<gml:exterior>
										<gml:LinearRing gml:id="line_6952c37b-782b-42e7-8e92-fcff91fd7c5b">
											<gml:posList>35.66867316936178 139.74783496920924 28.267662360670982 35.6686747729746 139.74783019638366 28.267662360670982 35.668670915971305 139.74782825021657 28.267662360670982 35.66867316936178 139.74783496920924 28.267662360670982</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_659877b7-1a4b-47a5-a7bb-a9ae99af96d4">
									<gml:exterior>
										<gml:LinearRing gml:id="line_39f56c78-34d4-41d4-bb27-fb39ad9095b2">
											<gml:posList>35.66867316936178 139.74783496920924 28.267662360670982 35.668670915971305 139.74782825021657 28.267662360670982 35.668669312220906 139.74783302287355 28.267662360670982 35.66867316936178 139.74783496920924 28.267662360670982</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:OuterFloorSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:OuterFloorSurface gml:id="gml_f2280610-f2be-4805-a3b4-b31321b3aa45">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_fc962a9f-25c0-47f3-95d2-ce655b3c851a">
									<gml:exterior>
										<gml:LinearRing gml:id="line_8b9c9b76-74a5-452f-b871-8ac628f5e74e">
											<gml:posList>35.668690275854296 139.74782351812135 31.77742035627645 35.66868526091045 139.74782098748136 31.77742035627645 35.6686752542573 139.74783043925513 31.77742035627645 35.668690275854296 139.74782351812135 31.77742035627645</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_f53a015e-4129-408a-bb50-8be6076b038f">
									<gml:exterior>
										<gml:LinearRing gml:id="line_8b918362-32e1-4b17-8502-a1394f909729">
											<gml:posList>35.668690275854296 139.74782351812135 31.77742035627645 35.6686752542573 139.74783043925513 31.77742035627645 35.66868610967223 139.747835916983 31.77742035627645 35.668690275854296 139.74782351812135 31.77742035627645</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_90626f5a-6f57-456c-b1b8-445dd22d7f47">
									<gml:exterior>
										<gml:LinearRing gml:id="line_54e5ae1d-f279-4954-ad41-f7593f65d293">
											<gml:posList>35.6686752542573 139.74783043925513 31.77742035627645 35.66868526091045 139.74782098748136 31.77742035627645 35.6686747729746 139.74783019638366 31.77742035627645 35.6686752542573 139.74783043925513 31.77742035627645</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_1271fdfe-56f7-4a70-b3f8-1baf3fa563fa">
									<gml:exterior>
										<gml:LinearRing gml:id="line_e701ab75-3ed1-49ac-af04-5ed5c1802e38">
											<gml:posList>35.6686747729746 139.74783019638366 31.77742035627645 35.66868526091045 139.74782098748136 31.77742035627645 35.66868477962785 139.74782074477844 31.77742035627645 35.6686747729746 139.74783019638366 31.77742035627645</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:OuterFloorSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:OuterFloorSurface gml:id="gml_0264c604-c973-45c8-8daf-83652f96e2f0">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_15e438c0-120a-4871-b407-87aff169b762">
									<gml:exterior>
										<gml:LinearRing gml:id="line_8da74cf0-da7e-41b6-83ff-1b64dad9eddb">
											<gml:posList>35.668670915971305 139.74782825021657 16.028610541823326 35.668669312220906 139.74783302287355 16.028610541823326 35.6686747729746 139.74783019638366 16.028610541823326 35.668670915971305 139.74782825021657 16.028610541823326</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_39c09e46-a2b3-4408-8fbf-aa1d9e67997c">
									<gml:exterior>
										<gml:LinearRing gml:id="line_55477576-5ac4-450c-a32d-4acb9115b78a">
											<gml:posList>35.6686747729746 139.74783019638366 16.028610541823326 35.668669312220906 139.74783302287355 16.028610541823326 35.66867316936178 139.74783496920924 16.028610541823326 35.6686747729746 139.74783019638366 16.028610541823326</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:OuterFloorSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:OuterFloorSurface gml:id="gml_d41f2af6-77c5-472e-bb83-8dd86031b89b">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_481950a9-5ca5-4196-8ccc-08faaa1cd66a">
									<gml:exterior>
										<gml:LinearRing gml:id="line_54bf0ce2-5518-4afd-b675-63722567dc64">
											<gml:posList>35.668630285119036 139.74781332977528 31.327423408034264 35.668631888868546 139.7478085569517 31.327423408034264 35.66862642811532 139.74781138344156 31.327423408034264 35.668630285119036 139.74781332977528 31.327423408034264</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_5022667f-8776-4469-8180-25db2a31a382">
									<gml:exterior>
										<gml:LinearRing gml:id="line_65fdddfd-68a2-4271-92bf-ac0916dba690">
											<gml:posList>35.66862642811532 139.74781138344156 31.327423408034264 35.668631888868546 139.7478085569517 31.327423408034264 35.668628031727216 139.74780661061828 31.327423408034264 35.66862642811532 139.74781138344156 31.327423408034264</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:OuterFloorSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:OuterFloorSurface gml:id="gml_13f88512-73fe-4adc-900d-38f933800e0f">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_02004dee-00d5-42a3-b28a-40ddf3d879c8">
									<gml:exterior>
										<gml:LinearRing gml:id="line_8c90894c-e39d-4069-9c01-a7a81625f83c">
											<gml:posList>35.6686747729746 139.74783019638366 19.088371589186607 35.668670915971305 139.74782825021657 19.088371589186607 35.66867316936178 139.74783496920924 19.088371589186607 35.6686747729746 139.74783019638366 19.088371589186607</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_62363658-990f-4ab5-81d2-c645541b1a8d">
									<gml:exterior>
										<gml:LinearRing gml:id="line_1b6d6fb7-3604-4c79-b85f-4130f024b3b6">
											<gml:posList>35.66867316936178 139.74783496920924 19.088371589186607 35.668670915971305 139.74782825021657 19.088371589186607 35.668669312220906 139.74783302287355 19.088371589186607 35.66867316936178 139.74783496920924 19.088371589186607</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:OuterFloorSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:OuterFloorSurface gml:id="gml_321949e4-f173-40f4-9676-4a0d7151572e">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_5bb7d460-3719-4ff4-b3e7-0b2d43e77a58">
									<gml:exterior>
										<gml:LinearRing gml:id="line_9d993dbd-1a32-4a6c-8a63-98b711b413b8">
											<gml:posList>35.6686747729746 139.74783019638366 12.968849494460045 35.668670915971305 139.74782825021657 12.968849494460045 35.668669312220906 139.74783302287355 12.968849494460045 35.6686747729746 139.74783019638366 12.968849494460045</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_57bc0959-0130-4665-9ed6-f501436bd7e3">
									<gml:exterior>
										<gml:LinearRing gml:id="line_2cdd22c2-59c3-4384-aa6b-080a3caefad5">
											<gml:posList>35.6686747729746 139.74783019638366 12.968849494460045 35.668669312220906 139.74783302287355 12.968849494460045 35.66867316936178 139.74783496920924 12.968849494460045 35.6686747729746 139.74783019638366 12.968849494460045</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:OuterFloorSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:OuterFloorSurface gml:id="gml_2589a501-4fdd-4fb6-a1b9-e07071d1c445">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_d91be7b6-025f-4c4b-9fcc-76bcd4d91595">
									<gml:exterior>
										<gml:LinearRing gml:id="line_524c3661-44a2-48f5-8454-5c12d074046e">
											<gml:posList>35.668630285119036 139.74781332977528 22.14813263654989 35.668631888868546 139.7478085569517 22.14813263654989 35.66862642811532 139.74781138344156 22.14813263654989 35.668630285119036 139.74781332977528 22.14813263654989</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_52657f86-9cef-42c5-834e-aed478d2041d">
									<gml:exterior>
										<gml:LinearRing gml:id="line_34e065ec-6b6f-4c63-ae91-379d4deb45d7">
											<gml:posList>35.66862642811532 139.74781138344156 22.14813263654989 35.668631888868546 139.7478085569517 22.14813263654989 35.668628031727216 139.74780661061828 22.14813263654989 35.66862642811532 139.74781138344156 22.14813263654989</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:OuterFloorSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:OuterFloorSurface gml:id="gml_f03d079c-e62b-4c14-8683-27706f3083bc">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_bd87f379-ccfa-4f95-9f59-e4d38a0ed5fa">
									<gml:exterior>
										<gml:LinearRing gml:id="line_00a59034-1e07-46ba-be05-592ca24cd57c">
											<gml:posList>35.66867316936178 139.74783496920924 22.14813263654989 35.6686747729746 139.74783019638366 22.14813263654989 35.668669312220906 139.74783302287355 22.14813263654989 35.66867316936178 139.74783496920924 22.14813263654989</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_ac3cfa0c-fd39-44bd-a58a-8f88d08933cf">
									<gml:exterior>
										<gml:LinearRing gml:id="line_450f4a73-2f5a-433d-9907-2b83e9742314">
											<gml:posList>35.668669312220906 139.74783302287355 22.14813263654989 35.6686747729746 139.74783019638366 22.14813263654989 35.668670915971305 139.74782825021657 22.14813263654989 35.668669312220906 139.74783302287355 22.14813263654989</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:OuterFloorSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:OuterFloorSurface gml:id="gml_67f237de-2d1b-4b7c-a925-6d554d53a003">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_abc97ddd-6e30-4e84-a723-307785fddb60">
									<gml:exterior>
										<gml:LinearRing gml:id="line_a09a3c06-4321-4600-98d2-99ed3112bc98">
											<gml:posList>35.668690275854296 139.74782351812135 16.478615119460045 35.66868526091045 139.74782098748136 16.478615119460045 35.66868610967223 139.747835916983 16.478615119460045 35.668690275854296 139.74782351812135 16.478615119460045</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_1f49c4f4-19e4-4865-b6d8-0df80d27ebd2">
									<gml:exterior>
										<gml:LinearRing gml:id="line_cd387547-99cb-4d1a-ba0d-65595c1fbfda">
											<gml:posList>35.66868610967223 139.747835916983 16.478615119460045 35.66868526091045 139.74782098748136 16.478615119460045 35.6686752542573 139.74783043925513 16.478615119460045 35.66868610967223 139.747835916983 16.478615119460045</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_d5ff1e2e-bbce-4d95-a8ad-817e48148b4d">
									<gml:exterior>
										<gml:LinearRing gml:id="line_a60f2c95-0769-4a67-8447-73d81289f955">
											<gml:posList>35.6686752542573 139.74783043925513 16.478615119460045 35.66868526091045 139.74782098748136 16.478615119460045 35.66868477962785 139.74782074477844 16.478615119460045 35.6686752542573 139.74783043925513 16.478615119460045</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_a289ff84-7021-4090-b191-011224fdfee0">
									<gml:exterior>
										<gml:LinearRing gml:id="line_719ef319-02cf-4abe-9914-0a2328361c76">
											<gml:posList>35.6686752542573 139.74783043925513 16.478615119460045 35.66868477962785 139.74782074477844 16.478615119460045 35.6686747729746 139.74783019638366 16.478615119460045 35.6686752542573 139.74783043925513 16.478615119460045</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:OuterFloorSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:OuterFloorSurface gml:id="gml_689e840d-d0a2-4d47-b9e3-a062aed3840e">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_f5b0b5c1-32fe-48a7-aaa2-687dbf2362e8">
									<gml:exterior>
										<gml:LinearRing gml:id="line_999d8362-f75a-435e-9512-5d07ddad859a">
											<gml:posList>35.668690275854296 139.74782351812135 13.418846442702232 35.66868526091045 139.74782098748136 13.418846442702232 35.66868610967223 139.747835916983 13.418846442702232 35.668690275854296 139.74782351812135 13.418846442702232</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_6fc75c3a-105e-4098-b4e3-4bd7f6b9c3a6">
									<gml:exterior>
										<gml:LinearRing gml:id="line_e6d568da-917a-4c1a-a226-ae69373cbce6">
											<gml:posList>35.66868610967223 139.747835916983 13.418846442702232 35.66868526091045 139.74782098748136 13.418846442702232 35.6686752542573 139.74783043925513 13.418846442702232 35.66868610967223 139.747835916983 13.418846442702232</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_e663bbc6-9340-4856-ad23-763118e6cf09">
									<gml:exterior>
										<gml:LinearRing gml:id="line_cfdc8b28-b2f3-4ec2-b3ab-1800dbf7d11a">
											<gml:posList>35.6686752542573 139.74783043925513 13.418846442702232 35.66868526091045 139.74782098748136 13.418846442702232 35.66868477962785 139.74782074477844 13.418846442702232 35.6686752542573 139.74783043925513 13.418846442702232</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_71054ebc-f1a0-4fe2-8f0c-42e126a1f563">
									<gml:exterior>
										<gml:LinearRing gml:id="line_f1af1857-d435-4e8c-8d9d-0af56b66b7ba">
											<gml:posList>35.6686752542573 139.74783043925513 13.418846442702232 35.66868477962785 139.74782074477844 13.418846442702232 35.6686747729746 139.74783019638366 13.418846442702232 35.6686752542573 139.74783043925513 13.418846442702232</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:OuterFloorSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:OuterFloorSurface gml:id="gml_161fc2a6-155f-4f3a-b93c-696e7544808e">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_23c69738-a469-4b37-b1e3-188c58746248">
									<gml:exterior>
										<gml:LinearRing gml:id="line_2eeafc28-3015-4ffb-a504-248960e17bd3">
											<gml:posList>35.66862642811532 139.74781138344156 25.2079013133077 35.668630285119036 139.74781332977528 25.2079013133077 35.668628031727216 139.74780661061828 25.2079013133077 35.66862642811532 139.74781138344156 25.2079013133077</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_26a6ca31-3410-4cb0-bbc3-efbd7f5fb39f">
									<gml:exterior>
										<gml:LinearRing gml:id="line_8a452268-c133-48e7-b3da-9e783a283b20">
											<gml:posList>35.668628031727216 139.74780661061828 25.2079013133077 35.668630285119036 139.74781332977528 25.2079013133077 35.668631888868546 139.7478085569517 25.2079013133077 35.668628031727216 139.74780661061828 25.2079013133077</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:OuterFloorSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:OuterFloorSurface gml:id="gml_fd5fd7aa-3128-4e70-b78d-d8cc27b3c066">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_19a275a1-2825-4319-9ed0-e47a04225d2f">
									<gml:exterior>
										<gml:LinearRing gml:id="line_05af59b2-813f-422a-b36b-49e55891faaf">
											<gml:posList>35.6686752542573 139.74783043925513 28.71765930891317 35.66868526091045 139.74782098748136 28.71765930891317 35.66868477962785 139.74782074477844 28.71765930891317 35.6686752542573 139.74783043925513 28.71765930891317</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_febde3e2-8303-4a9b-9030-84c819b40418">
									<gml:exterior>
										<gml:LinearRing gml:id="line_f830972f-178b-458c-8fa1-c8bd2bf6630c">
											<gml:posList>35.6686752542573 139.74783043925513 28.71765930891317 35.66868477962785 139.74782074477844 28.71765930891317 35.6686747729746 139.74783019638366 28.71765930891317 35.6686752542573 139.74783043925513 28.71765930891317</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_e002f6e3-bac3-4663-b60d-60c559be2bc6">
									<gml:exterior>
										<gml:LinearRing gml:id="line_0c5f333e-998a-4562-a372-70a9ee0f2643">
											<gml:posList>35.668690275854296 139.74782351812135 28.71765930891317 35.66868526091045 139.74782098748136 28.71765930891317 35.66868610967223 139.747835916983 28.71765930891317 35.668690275854296 139.74782351812135 28.71765930891317</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_1bb18f18-df9c-47cc-bbf4-93fe58b442d5">
									<gml:exterior>
										<gml:LinearRing gml:id="line_b80e83fc-1990-4f81-87f0-ae5f48c3ef01">
											<gml:posList>35.66868610967223 139.747835916983 28.71765930891317 35.66868526091045 139.74782098748136 28.71765930891317 35.6686752542573 139.74783043925513 28.71765930891317 35.66868610967223 139.747835916983 28.71765930891317</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:OuterFloorSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:OuterFloorSurface gml:id="gml_74db1efe-8654-4da3-a379-26329feee26d">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_4d447cc7-62d5-4deb-8d14-44cbf187a498">
									<gml:exterior>
										<gml:LinearRing gml:id="line_f146eb65-009a-44d4-a771-d152f272e177">
											<gml:posList>35.668690275854296 139.74782351812135 10.359085395338951 35.66868526091045 139.74782098748136 10.359085395338951 35.66868610967223 139.747835916983 10.359085395338951 35.668690275854296 139.74782351812135 10.359085395338951</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_e0ab2cc1-025a-46aa-a00d-8ad4a7a12788">
									<gml:exterior>
										<gml:LinearRing gml:id="line_8c2a363a-8813-4abf-bda9-8dca15b5d6cb">
											<gml:posList>35.66868610967223 139.747835916983 10.359085395338951 35.66868526091045 139.74782098748136 10.359085395338951 35.6686752542573 139.74783043925513 10.359085395338951 35.66868610967223 139.747835916983 10.359085395338951</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_84c81901-f919-4186-b146-46d5c25270cc">
									<gml:exterior>
										<gml:LinearRing gml:id="line_ae5af79a-cee4-45bf-ac32-457604d2ca55">
											<gml:posList>35.6686752542573 139.74783043925513 10.359085395338951 35.66868526091045 139.74782098748136 10.359085395338951 35.66868477962785 139.74782074477844 10.359085395338951 35.6686752542573 139.74783043925513 10.359085395338951</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_90c680f2-b579-4525-8546-ee0d19d270aa">
									<gml:exterior>
										<gml:LinearRing gml:id="line_5201f5a2-7f6e-4f70-a1a3-e67c058ad564">
											<gml:posList>35.6686752542573 139.74783043925513 10.359085395338951 35.66868477962785 139.74782074477844 10.359085395338951 35.6686747729746 139.74783019638366 10.359085395338951 35.6686752542573 139.74783043925513 10.359085395338951</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:OuterFloorSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:OuterFloorSurface gml:id="gml_665cd4b8-4b6b-4885-9acd-7fb07e4bd418">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_58d71711-c531-41cf-9018-a0405d071b36">
									<gml:exterior>
										<gml:LinearRing gml:id="line_2d7a2fd4-f64c-46ea-bc9b-0a59afb439a4">
											<gml:posList>35.668670915971305 139.74782825021657 31.327423408034264 35.668669312220906 139.74783302287355 31.327423408034264 35.6686747729746 139.74783019638366 31.327423408034264 35.668670915971305 139.74782825021657 31.327423408034264</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_4ff6fe66-368c-4dae-86f7-e6a930a16eee">
									<gml:exterior>
										<gml:LinearRing gml:id="line_f69ee789-7cac-42ad-8018-6edcc280fd5c">
											<gml:posList>35.6686747729746 139.74783019638366 31.327423408034264 35.668669312220906 139.74783302287355 31.327423408034264 35.66867316936178 139.74783496920924 31.327423408034264 35.6686747729746 139.74783019638366 31.327423408034264</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:OuterFloorSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:OuterFloorSurface gml:id="gml_ea0ede0e-2d68-4926-98a4-13fb807000fd">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_e448ec45-cf89-4c9d-8369-52e1ea124884">
									<gml:exterior>
										<gml:LinearRing gml:id="line_e56ce093-a564-4dcd-9664-a10dc92fd0a3">
											<gml:posList>35.6686747729746 139.74783019638366 25.2079013133077 35.668670915971305 139.74782825021657 25.2079013133077 35.66867316936178 139.74783496920924 25.2079013133077 35.6686747729746 139.74783019638366 25.2079013133077</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_5320a43a-6eb2-44c2-ad05-fa68a8904db9">
									<gml:exterior>
										<gml:LinearRing gml:id="line_42385169-efd7-4b0d-84dd-e64ce0d11cec">
											<gml:posList>35.66867316936178 139.74783496920924 25.2079013133077 35.668670915971305 139.74782825021657 25.2079013133077 35.668669312220906 139.74783302287355 25.2079013133077 35.66867316936178 139.74783496920924 25.2079013133077</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:OuterFloorSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:OuterFloorSurface gml:id="gml_a21680c1-f3ce-49ea-a035-fd17488c3a3f">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_4322285b-f5ae-4040-9ff4-e432b1294668">
									<gml:exterior>
										<gml:LinearRing gml:id="line_fb12f404-9eaa-4bed-a60d-fcccd77e15cb">
											<gml:posList>35.668690275854296 139.74782351812135 25.65789826154989 35.66868526091045 139.74782098748136 25.65789826154989 35.66868610967223 139.747835916983 25.65789826154989 35.668690275854296 139.74782351812135 25.65789826154989</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_4b7385be-e718-429d-8186-af379e94e22a">
									<gml:exterior>
										<gml:LinearRing gml:id="line_f5c28e74-516e-4197-9ef1-b5de36ece522">
											<gml:posList>35.66868610967223 139.747835916983 25.65789826154989 35.66868526091045 139.74782098748136 25.65789826154989 35.6686752542573 139.74783043925513 25.65789826154989 35.66868610967223 139.747835916983 25.65789826154989</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_c6096fab-c21c-4fb3-b80d-34efde1e6bdf">
									<gml:exterior>
										<gml:LinearRing gml:id="line_644a633e-fc87-4972-8fe1-8dbc08c67013">
											<gml:posList>35.6686752542573 139.74783043925513 25.65789826154989 35.66868526091045 139.74782098748136 25.65789826154989 35.6686747729746 139.74783019638366 25.65789826154989 35.6686752542573 139.74783043925513 25.65789826154989</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_b4caffca-369a-4e64-a51b-299f2955e759">
									<gml:exterior>
										<gml:LinearRing gml:id="line_87f3f586-ec1b-40fc-a7bc-b6e6ef908b46">
											<gml:posList>35.6686747729746 139.74783019638366 25.65789826154989 35.66868526091045 139.74782098748136 25.65789826154989 35.66868477962785 139.74782074477844 25.65789826154989 35.6686747729746 139.74783019638366 25.65789826154989</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:OuterFloorSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:OuterFloorSurface gml:id="gml_5b92710e-f05d-4e10-84ee-db2e0b07fc5b">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_7922d3b6-6ddb-4e96-83dc-b60f2c373300">
									<gml:exterior>
										<gml:LinearRing gml:id="line_8482d694-41ec-4a94-865e-dc6ee03e8dae">
											<gml:posList>35.668630285119036 139.74781332977528 28.267662360670982 35.668631888868546 139.7478085569517 28.267662360670982 35.66862642811532 139.74781138344156 28.267662360670982 35.668630285119036 139.74781332977528 28.267662360670982</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_373ac7ae-502a-4b20-a0ab-93f79aa59410">
									<gml:exterior>
										<gml:LinearRing gml:id="line_e1ca8032-9983-4121-8c69-c69bb38bde73">
											<gml:posList>35.66862642811532 139.74781138344156 28.267662360670982 35.668631888868546 139.7478085569517 28.267662360670982 35.668628031727216 139.74780661061828 28.267662360670982 35.66862642811532 139.74781138344156 28.267662360670982</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:OuterFloorSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:OuterFloorSurface gml:id="gml_cbca3a7c-2c77-4620-a204-fd7cbefe0663">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_45f25108-5f1d-4f02-a838-655f10c1820f">
									<gml:exterior>
										<gml:LinearRing gml:id="line_8c2a392f-72a4-44e6-8363-53b66beaac6b">
											<gml:posList>35.668670915971305 139.74782825021657 9.909088447096764 35.668669312220906 139.74783302287355 9.909088447096764 35.66867316936178 139.74783496920924 9.909088447096764 35.668670915971305 139.74782825021657 9.909088447096764</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_15b84006-c28a-4153-bb5d-efe8703e34f9">
									<gml:exterior>
										<gml:LinearRing gml:id="line_0bc97c5f-7a12-4cd6-96eb-80ff451c3ddf">
											<gml:posList>35.668670915971305 139.74782825021657 9.909088447096764 35.66867316936178 139.74783496920924 9.909088447096764 35.6686747729746 139.74783019638366 9.909088447096764 35.668670915971305 139.74782825021657 9.909088447096764</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:OuterFloorSurface>
			</bldg:boundedBy>
			<bldg:lod3Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#Poly_32d21bd3-fda2-406f-8f22-bcb7e4b56d16"/>
							<gml:surfaceMember xlink:href="#Poly_44625b89-6489-474b-810e-2692d039b2ce"/>
							<gml:surfaceMember xlink:href="#Poly_40c4500d-76a5-4207-a018-85d371384c60"/>
							<gml:surfaceMember xlink:href="#Poly_b7211871-a6d8-4c77-a8e1-a2cab911ff33"/>
							<gml:surfaceMember xlink:href="#Poly_9d310a33-4c80-4c05-8d71-07f3ea6582a2"/>
							<gml:surfaceMember xlink:href="#Poly_6ba3444e-c15e-4f9f-8a4a-3b9b3b0d5d17"/>
							<gml:surfaceMember xlink:href="#Poly_b5eb19f7-8cf4-4a02-8207-eda9252d932d"/>
							<gml:surfaceMember xlink:href="#Poly_831eee7c-8448-42b5-b6d4-219ca6356c01"/>
							<gml:surfaceMember xlink:href="#Poly_40af74ca-cc3f-454a-a932-b64a986cbcd6"/>
							<gml:surfaceMember xlink:href="#Poly_9b1d005b-bde6-487b-af3e-018154320e0d"/>
							<gml:surfaceMember xlink:href="#Poly_ac21b73f-4247-4f53-9abe-df7f61407f73"/>
							<gml:surfaceMember xlink:href="#Poly_65b9a3ef-838c-4973-b92c-453efdc70cf6"/>
							<gml:surfaceMember xlink:href="#Poly_cf9bb05b-118b-42c9-99d6-13a61c92db08"/>
							<gml:surfaceMember xlink:href="#Poly_3eba90a6-e0c3-4704-a148-e8e0202a687a"/>
							<gml:surfaceMember xlink:href="#Poly_03686811-019f-4478-8b35-bab451076e73"/>
							<gml:surfaceMember xlink:href="#Poly_5038b1db-0f18-4662-a867-79230e4925db"/>
							<gml:surfaceMember xlink:href="#Poly_a03e5577-32dc-4d1e-bcaa-6376fe4cc3fb"/>
							<gml:surfaceMember xlink:href="#Poly_2724ca4a-98c7-47ad-b418-9d602632b3d7"/>
							<gml:surfaceMember xlink:href="#Poly_20e46824-1d82-4f68-9a96-8d8892c5d1c5"/>
							<gml:surfaceMember xlink:href="#Poly_c4f256a6-8c20-4d7e-85e4-aa47c97496e9"/>
							<gml:surfaceMember xlink:href="#Poly_6a3ae9f7-1c3d-4a34-8a5d-e1472098db88"/>
							<gml:surfaceMember xlink:href="#Poly_b4c6c5cb-916c-46f2-9fdc-58d974ac0732"/>
							<gml:surfaceMember xlink:href="#Poly_7cdccf49-c98c-4632-bcc2-56af3b11e0ec"/>
							<gml:surfaceMember xlink:href="#Poly_e10aa534-68c4-49b0-a6f8-ba027fdd9cde"/>
							<gml:surfaceMember xlink:href="#Poly_0c624d2d-453a-4707-b2e8-c6eb4032a341"/>
							<gml:surfaceMember xlink:href="#Poly_6534cccb-f4ff-4e14-b1f8-673558a1a4c7"/>
							<gml:surfaceMember xlink:href="#Poly_25c25a84-dec2-4da2-b537-4463bfa568a3"/>
							<gml:surfaceMember xlink:href="#Poly_ad6d983c-6a29-4c1c-956e-cb2ad845ff33"/>
							<gml:surfaceMember xlink:href="#Poly_9fdaeb86-c879-48d6-9461-c153a16fa3bf"/>
							<gml:surfaceMember xlink:href="#Poly_1735eccd-211b-410d-b036-97ddcfa5290d"/>
							<gml:surfaceMember xlink:href="#Poly_a0f06783-7aa6-4395-b308-b88b9a5dd8e9"/>
							<gml:surfaceMember xlink:href="#Poly_d2862cec-5890-4102-af81-2d0e2b3dbf90"/>
							<gml:surfaceMember xlink:href="#Poly_092d8fc2-30dc-4485-aa95-af1f2599e08e"/>
							<gml:surfaceMember xlink:href="#Poly_6fddd394-8e1b-41ae-98f9-7580b42c3891"/>
							<gml:surfaceMember xlink:href="#Poly_9105cb46-2c6f-4436-bf79-a9b984535fa9"/>
							<gml:surfaceMember xlink:href="#Poly_83ba6ec6-9dc0-40c4-8a8c-e8fca56b9b6c"/>
							<gml:surfaceMember xlink:href="#Poly_8999f27b-e896-474d-82aa-783b3c46b0ae"/>
							<gml:surfaceMember xlink:href="#Poly_221a4da2-781e-4938-93bb-82dcd02bd652"/>
							<gml:surfaceMember xlink:href="#Poly_a09bf501-4fa6-4883-9e8a-40747597c357"/>
							<gml:surfaceMember xlink:href="#Poly_7f840771-c3a3-406d-9a72-3eaf485af0bf"/>
							<gml:surfaceMember xlink:href="#Poly_2257b106-bb00-4097-851a-99055e9e100c"/>
							<gml:surfaceMember xlink:href="#Poly_1a257125-f1b3-4c1e-9099-93f5a6462632"/>
							<gml:surfaceMember xlink:href="#Poly_38da0fb1-d436-4a8e-97c2-5fee08aff69a"/>
							<gml:surfaceMember xlink:href="#Poly_f22be188-b248-4927-8849-783f3d124989"/>
							<gml:surfaceMember xlink:href="#Poly_c7a69410-707d-459d-819d-16ad0ef0a908"/>
							<gml:surfaceMember xlink:href="#Poly_37572902-9397-44a3-9f36-cebea84d223e"/>
							<gml:surfaceMember xlink:href="#Poly_76c5611b-da27-497c-963f-a8e72d901782"/>
							<gml:surfaceMember xlink:href="#Poly_46af3ce4-8b1b-4d70-94c1-26e7adb71a86"/>
							<gml:surfaceMember xlink:href="#Poly_86dbb0a9-0fb2-48a0-82ac-21b5a068e862"/>
							<gml:surfaceMember xlink:href="#Poly_caa4cba0-1e5d-43c3-ae51-cee5a52eca35"/>
							<gml:surfaceMember xlink:href="#Poly_2d56f6bf-bc83-4b3d-8182-22b5eb9aa410"/>
							<gml:surfaceMember xlink:href="#Poly_f3b82076-f951-4a03-8a29-4019077a47c2"/>
							<gml:surfaceMember xlink:href="#Poly_760c47e3-f55c-4f56-9a1d-1a420def5434"/>
							<gml:surfaceMember xlink:href="#Poly_c1912dca-dbe7-451c-9cd1-223698348f43"/>
							<gml:surfaceMember xlink:href="#Poly_093b66a7-1f74-4e7c-8f0a-f52f47eb9157"/>
							<gml:surfaceMember xlink:href="#Poly_2e469c18-52da-4f0b-9857-292a9702e1c8"/>
							<gml:surfaceMember xlink:href="#Poly_863d02c5-caf9-41bd-84db-f957c64ae3f4"/>
							<gml:surfaceMember xlink:href="#Poly_0afe2335-2a24-41d1-846b-e0fe94288bea"/>
							<gml:surfaceMember xlink:href="#Poly_bc9d07bd-42c3-44a7-94ef-702dc843cb23"/>
							<gml:surfaceMember xlink:href="#Poly_05ec335f-4762-45c7-9c20-7384b478348c"/>
							<gml:surfaceMember xlink:href="#Poly_b46292fc-e672-4920-ad14-3ca70a1c38ba"/>
							<gml:surfaceMember xlink:href="#Poly_000ec5f7-b34f-423e-ad1c-ce14228b7c14"/>
							<gml:surfaceMember xlink:href="#Poly_868b198d-7a38-4cfa-a082-f04b79a82201"/>
							<gml:surfaceMember xlink:href="#Poly_e173bdfe-485d-4c24-8dff-e042740ded77"/>
							<gml:surfaceMember xlink:href="#Poly_498db53f-a0a7-446e-9ac3-c8ceda1b55ad"/>
							<gml:surfaceMember xlink:href="#Poly_babdad5a-4f1b-4645-a371-328bbc21cea8"/>
							<gml:surfaceMember xlink:href="#Poly_cbcdf01f-82bd-4617-a0b4-7fd0a67ed63b"/>
							<gml:surfaceMember xlink:href="#Poly_38415677-e409-428e-909c-80a2767573c9"/>
							<gml:surfaceMember xlink:href="#Poly_72aff4a7-9c4c-44f0-a76a-9368e7a451bf"/>
							<gml:surfaceMember xlink:href="#Poly_0f595a9f-e9a7-478b-b93b-91873119d570"/>
							<gml:surfaceMember xlink:href="#Poly_024cb529-0e81-49b9-860e-4ad26cd640fb"/>
							<gml:surfaceMember xlink:href="#Poly_ec0d77c7-5bd6-4ea8-829d-9705110d08d4"/>
							<gml:surfaceMember xlink:href="#Poly_81fe93c7-80b9-4bf1-955a-c5a21ba02028"/>
							<gml:surfaceMember xlink:href="#Poly_482a38f6-52ec-48b6-8b19-64dc998dce4d"/>
							<gml:surfaceMember xlink:href="#Poly_749400f7-a052-4d97-94a4-f6d9b500c967"/>
							<gml:surfaceMember xlink:href="#Poly_87350894-43d7-4f07-945c-43675a9d2ba9"/>
							<gml:surfaceMember xlink:href="#Poly_35eee4bb-cde4-41e0-84d4-7c8dea46f70f"/>
							<gml:surfaceMember xlink:href="#Poly_d689df06-8929-4b04-abf4-55aa28f5b714"/>
							<gml:surfaceMember xlink:href="#Poly_522ebef7-1494-4356-95bb-5f31c85df9cd"/>
							<gml:surfaceMember xlink:href="#Poly_1991d0de-f7fa-46b0-a293-c8b8c997c824"/>
							<gml:surfaceMember xlink:href="#Poly_f751a5b1-2fee-4f7f-bc1f-d85b0eff2ead"/>
							<gml:surfaceMember xlink:href="#Poly_0df35b16-0d87-453b-9487-200eeea967ab"/>
							<gml:surfaceMember xlink:href="#Poly_a7a3a788-6a13-40b8-8086-38e90f36a08d"/>
							<gml:surfaceMember xlink:href="#Poly_7a819d13-6caa-4348-a825-7250b1ccb081"/>
							<gml:surfaceMember xlink:href="#Poly_c544d9ca-d039-4fda-b2bf-373f8cf5773e"/>
							<gml:surfaceMember xlink:href="#Poly_85e2e78c-5cb5-421b-b78f-81836e2576d3"/>
							<gml:surfaceMember xlink:href="#Poly_772c454c-7dc3-4fe3-a89d-c48dc7c4553d"/>
							<gml:surfaceMember xlink:href="#Poly_89a4c9c3-4760-4f9d-8f8c-a7d0af538623"/>
							<gml:surfaceMember xlink:href="#Poly_650e0f71-f7ca-4ba8-afb3-f894c53d8615"/>
							<gml:surfaceMember xlink:href="#Poly_83776d2f-631d-4670-a7cf-88b2c7baab43"/>
							<gml:surfaceMember xlink:href="#Poly_8544044c-464a-4580-94a2-63834d62e4b1"/>
							<gml:surfaceMember xlink:href="#Poly_d727ec2b-12a4-44d6-a2c5-60e6e393da80"/>
							<gml:surfaceMember xlink:href="#Poly_de173f8e-3be5-4f8d-8561-7ad5ddcc4088"/>
							<gml:surfaceMember xlink:href="#Poly_6be40475-4526-46a8-92a9-b9b6bad9213d"/>
							<gml:surfaceMember xlink:href="#Poly_5a6d92e2-2c72-47f2-9613-ed549a6c4b07"/>
							<gml:surfaceMember xlink:href="#Poly_0571d487-492f-4943-8893-02edeb563710"/>
							<gml:surfaceMember xlink:href="#Poly_7427aff6-5e7e-4466-bb2a-3db5a65994ef"/>
							<gml:surfaceMember xlink:href="#Poly_6041a84e-d46b-4d29-83be-68e5305647fd"/>
							<gml:surfaceMember xlink:href="#Poly_0ee5c805-3b51-4801-915e-9bbc241b9fc6"/>
							<gml:surfaceMember xlink:href="#Poly_ced38f0d-070c-4ffb-a64a-3a7416db6d74"/>
							<gml:surfaceMember xlink:href="#Poly_f5727e4e-2c5b-410b-b3ac-1f8256dc93ff"/>
							<gml:surfaceMember xlink:href="#Poly_470ea7fd-846c-4793-8a50-f5a70c06bc50"/>
							<gml:surfaceMember xlink:href="#Poly_e51bba14-10e3-4da3-b09e-952e5bca25ba"/>
							<gml:surfaceMember xlink:href="#Poly_0657b0df-8cb0-4a73-a018-f046af536231"/>
							<gml:surfaceMember xlink:href="#Poly_7fcf4cbd-f43c-4c00-bca3-adf315708397"/>
							<gml:surfaceMember xlink:href="#Poly_98f866a3-ec5a-4df5-a141-dfe7f6e02b2c"/>
							<gml:surfaceMember xlink:href="#Poly_76ec948b-7552-4384-ae76-051f2f00d764"/>
							<gml:surfaceMember xlink:href="#Poly_5ce163e7-ef23-4bf8-8aba-12771d9a4910"/>
							<gml:surfaceMember xlink:href="#Poly_77a63c6b-f2b2-4fab-8460-61295e5b61f9"/>
							<gml:surfaceMember xlink:href="#Poly_682d59c3-e62b-440c-8be7-5e2ae41f0926"/>
							<gml:surfaceMember xlink:href="#Poly_6a7d783e-3ce0-46ef-8e92-81827018bc1b"/>
							<gml:surfaceMember xlink:href="#Poly_4b4fa0bf-18b0-4c95-b885-6d4e31ff2832"/>
							<gml:surfaceMember xlink:href="#Poly_0e9d06d7-b4c6-4b75-bdf0-c6c4e05f92cf"/>
							<gml:surfaceMember xlink:href="#Poly_c4a9fbfe-e82f-43d4-b05f-98e7feadf666"/>
							<gml:surfaceMember xlink:href="#Poly_9d37c1c6-cc18-4612-80c7-a2bd1b5da1c7"/>
							<gml:surfaceMember xlink:href="#Poly_e4385306-8d76-462f-a36a-1a223759ea10"/>
							<gml:surfaceMember xlink:href="#Poly_f3463a67-f340-4de8-97b3-8668891d6e36"/>
							<gml:surfaceMember xlink:href="#Poly_c1604968-1602-402b-9299-2713cd6ec9db"/>
							<gml:surfaceMember xlink:href="#Poly_098c57a8-86b0-4cf9-a113-2730f693c1c6"/>
							<gml:surfaceMember xlink:href="#Poly_ebc1aefd-7acd-4cad-8920-01419924db80"/>
							<gml:surfaceMember xlink:href="#Poly_df100bc9-daf4-4c30-8728-32eac97b7109"/>
							<gml:surfaceMember xlink:href="#Poly_542d1657-7129-4b35-aa36-ec09cb9722bc"/>
							<gml:surfaceMember xlink:href="#Poly_20be6003-484c-471d-80aa-67f0a3d8e597"/>
							<gml:surfaceMember xlink:href="#Poly_af17a49b-c13e-42a1-897e-5c6ebdefdb67"/>
							<gml:surfaceMember xlink:href="#Poly_16fe32bc-9994-4ffb-a8e5-bb49834df5ac"/>
							<gml:surfaceMember xlink:href="#Poly_16ce54b6-12a6-44b2-ab12-577f14da7bdc"/>
							<gml:surfaceMember xlink:href="#Poly_c4d90bdb-b3b5-4ade-88dd-ad3ced5bc236"/>
							<gml:surfaceMember xlink:href="#Poly_6774d021-4613-4767-8223-4efc303e4e72"/>
							<gml:surfaceMember xlink:href="#Poly_74afa576-9df1-4181-88fe-b5bb3b45cffe"/>
							<gml:surfaceMember xlink:href="#Poly_4f6e99b1-f436-4ab4-838e-fcaaf01ce35f"/>
							<gml:surfaceMember xlink:href="#Poly_203ac0ea-9052-41b3-b848-ee9bdaa5f3f3"/>
							<gml:surfaceMember xlink:href="#Poly_559ad748-7b79-4acb-95fd-45774b8089ce"/>
							<gml:surfaceMember xlink:href="#Poly_a021b4f1-871c-440b-9624-eb391eb11d43"/>
							<gml:surfaceMember xlink:href="#Poly_405b74f8-7391-4276-8ba1-acf95d00b0cb"/>
							<gml:surfaceMember xlink:href="#Poly_d87b21dc-02c8-4574-8dc4-7723c55eaf4e"/>
							<gml:surfaceMember xlink:href="#Poly_b6950fda-5e39-4ba6-872c-e20e55d54e1b"/>
							<gml:surfaceMember xlink:href="#Poly_c8f935d2-1d9f-4823-88cd-755f43450efd"/>
							<gml:surfaceMember xlink:href="#Poly_219e88a7-90da-4cf2-b8e6-f9322a99a925"/>
							<gml:surfaceMember xlink:href="#Poly_94fe44b5-1f78-43c2-8d28-a4c768d0a92b"/>
							<gml:surfaceMember xlink:href="#Poly_3bbdcc8a-62c6-4a3a-ab39-3f82f168eba9"/>
							<gml:surfaceMember xlink:href="#Poly_064a4268-79c3-4e93-9945-69bf3f8074cb"/>
							<gml:surfaceMember xlink:href="#Poly_82edb714-028f-4182-9fce-d28401def991"/>
							<gml:surfaceMember xlink:href="#Poly_55d9f438-7338-417c-9804-417ddfd2e6d4"/>
							<gml:surfaceMember xlink:href="#Poly_7d12fbdf-224a-4359-aa30-c4b62ce4e590"/>
							<gml:surfaceMember xlink:href="#Poly_17124091-ed93-427c-8927-d9ca87425c91"/>
							<gml:surfaceMember xlink:href="#Poly_480b74e2-3310-49ed-bbc4-0934c7eecd61"/>
							<gml:surfaceMember xlink:href="#Poly_797cd6c0-0962-4d36-b1f6-45a70edfba5c"/>
							<gml:surfaceMember xlink:href="#Poly_4e1b1145-2276-4440-8757-2be9731d1be2"/>
							<gml:surfaceMember xlink:href="#Poly_0851ba9a-f7e1-4aba-8de2-8234fd9948b3"/>
							<gml:surfaceMember xlink:href="#Poly_22cd0b85-599d-4cd0-8a72-76f8ccad3330"/>
							<gml:surfaceMember xlink:href="#Poly_91ecf96f-bd43-40ac-9d3f-e8aefc20f90a"/>
							<gml:surfaceMember xlink:href="#Poly_083e3753-80cf-4b72-9e35-32ed1dc12833"/>
							<gml:surfaceMember xlink:href="#Poly_a864d864-d8e9-4dae-9c4b-419e984a0d64"/>
							<gml:surfaceMember xlink:href="#Poly_b2ab1b37-9f08-432d-a1b0-72a4c42133b4"/>
							<gml:surfaceMember xlink:href="#Poly_7b3b1890-f0a4-4b41-adcc-fda9adc743d8"/>
							<gml:surfaceMember xlink:href="#Poly_c84571c2-43a0-4a91-94b4-a5ed0a360303"/>
							<gml:surfaceMember xlink:href="#Poly_3eaa760a-0f55-4b2d-8cae-ab29f3018801"/>
							<gml:surfaceMember xlink:href="#Poly_32e2ff79-2534-45b1-8a92-1d187ac9c85c"/>
							<gml:surfaceMember xlink:href="#Poly_0fdd3969-a718-4b3b-960d-df67baf2bbc7"/>
							<gml:surfaceMember xlink:href="#Poly_cda9d6ed-4ec0-43b4-a13b-9ae6a76fa9ff"/>
							<gml:surfaceMember xlink:href="#Poly_fcec348a-22d4-49e5-b9c1-9a4d5c59ab97"/>
							<gml:surfaceMember xlink:href="#Poly_9545eab3-3518-4b0e-a8f2-96cddca21557"/>
							<gml:surfaceMember xlink:href="#Poly_31b8f63d-9d8c-404f-ae8c-cdece0f4d681"/>
							<gml:surfaceMember xlink:href="#Poly_26525bcd-0273-44c1-a313-3587c9d7ff4a"/>
							<gml:surfaceMember xlink:href="#Poly_111e788f-ae88-4ff7-8c57-6870a7bd9adf"/>
							<gml:surfaceMember xlink:href="#Poly_5eff0d5d-89d2-448b-b9f6-803375f14903"/>
							<gml:surfaceMember xlink:href="#Poly_0a299722-d4ca-4b55-a4c1-8898e00ceb7c"/>
							<gml:surfaceMember xlink:href="#Poly_29027a56-1444-4e5d-8867-38a3c777ac7b"/>
							<gml:surfaceMember xlink:href="#Poly_634f2473-432f-4ecd-919c-1deecacdf03e"/>
							<gml:surfaceMember xlink:href="#Poly_423db445-2cce-4f41-8da6-352eb1845776"/>
							<gml:surfaceMember xlink:href="#Poly_52231d77-7d9e-4060-8393-8e3acface9d0"/>
							<gml:surfaceMember xlink:href="#Poly_3586df16-23bc-4ff7-a4c3-dab4941452d0"/>
							<gml:surfaceMember xlink:href="#Poly_01390c18-ee69-49f7-885d-068a97fba554"/>
							<gml:surfaceMember xlink:href="#Poly_4bfd17f5-ad1c-4526-b475-d088fe53bfe2"/>
							<gml:surfaceMember xlink:href="#Poly_031fcc9e-9998-4bd5-b884-691bb7d1fc63"/>
							<gml:surfaceMember xlink:href="#Poly_3b9e9faf-4705-4f75-8ff2-6e42eb299226"/>
							<gml:surfaceMember xlink:href="#Poly_79bf2784-6fa4-4b16-b6e9-f4b1c31d975f"/>
							<gml:surfaceMember xlink:href="#Poly_65c2e38a-5261-41b6-899b-15226320a3bc"/>
							<gml:surfaceMember xlink:href="#Poly_8929c83b-5d47-4c98-b5d9-12ea6e56e5e7"/>
							<gml:surfaceMember xlink:href="#Poly_8dfc83af-8bff-4f21-99ab-fc41d064e06a"/>
							<gml:surfaceMember xlink:href="#Poly_901f0f88-b5be-40aa-9857-84d3213c7e73"/>
							<gml:surfaceMember xlink:href="#Poly_627039cf-30d9-4c5a-807b-a18b5bf8b88e"/>
							<gml:surfaceMember xlink:href="#Poly_ed3d7544-567b-4826-8a59-293001afd04b"/>
							<gml:surfaceMember xlink:href="#Poly_e63ba3e9-feed-4341-852d-591d2af6c976"/>
							<gml:surfaceMember xlink:href="#Poly_eaca28da-34ad-4234-9cf1-10f11f5d94c2"/>
							<gml:surfaceMember xlink:href="#Poly_36bfae45-e113-4c3e-b302-9788d332af6e"/>
							<gml:surfaceMember xlink:href="#Poly_fa21993a-3105-4f6a-a37a-4a6d45ee8542"/>
							<gml:surfaceMember xlink:href="#Poly_aca75637-287c-4602-9d1d-00e49d4d1776"/>
							<gml:surfaceMember xlink:href="#Poly_4308a2da-1156-4166-8c43-afb56b41053b"/>
							<gml:surfaceMember xlink:href="#Poly_b639c42b-4619-4560-973f-f266d339220a"/>
							<gml:surfaceMember xlink:href="#Poly_a4a8058c-a12f-471a-a394-85089ad2679c"/>
							<gml:surfaceMember xlink:href="#Poly_dd9cdcbe-0c56-40a9-aa3e-b2b2666cb266"/>
							<gml:surfaceMember xlink:href="#Poly_015f2895-5bc9-455e-913a-bf0cc00ccce2"/>
							<gml:surfaceMember xlink:href="#Poly_fd4d321f-6991-4554-8a05-657fc429b80c"/>
							<gml:surfaceMember xlink:href="#Poly_1c28913f-0962-4de6-969f-edde3531baff"/>
							<gml:surfaceMember xlink:href="#Poly_85b721d5-8a9a-4fe4-b863-3530291fa453"/>
							<gml:surfaceMember xlink:href="#Poly_ead0d444-c1d0-459d-aa7f-48a76eef901c"/>
							<gml:surfaceMember xlink:href="#Poly_26360abd-ff30-4b03-94bd-3f5a6a458957"/>
							<gml:surfaceMember xlink:href="#Poly_7b897a1c-f8a6-4d66-9922-1e5257bc7d74"/>
							<gml:surfaceMember xlink:href="#Poly_31b359ea-3b57-4d0a-8bbd-30d76eb144da"/>
							<gml:surfaceMember xlink:href="#Poly_2b68591f-9015-43dc-9c63-fb8d33388873"/>
							<gml:surfaceMember xlink:href="#Poly_72d876a0-82c5-4a25-b43c-ec499af939a1"/>
							<gml:surfaceMember xlink:href="#Poly_adfe8e6f-6dc2-427d-9520-b1e7c677e03d"/>
							<gml:surfaceMember xlink:href="#Poly_cc37e01b-dacc-4e22-baba-f96ad3862f04"/>
							<gml:surfaceMember xlink:href="#Poly_ae201c8f-ba86-4e03-9924-84967d782f2f"/>
							<gml:surfaceMember xlink:href="#Poly_0c3b036e-0060-42f2-be29-838a3fd78cbc"/>
							<gml:surfaceMember xlink:href="#Poly_656b1a41-aeab-4676-b769-9cd7bc9ac71b"/>
							<gml:surfaceMember xlink:href="#Poly_891cb83a-1fe8-49ac-91d9-7e874ab535ee"/>
							<gml:surfaceMember xlink:href="#Poly_eb2dee5a-840b-4849-af58-81bd322f0cc5"/>
							<gml:surfaceMember xlink:href="#Poly_c3fd3b32-fb07-4129-aafd-f4164a97b120"/>
							<gml:surfaceMember xlink:href="#Poly_af7fe22f-ee24-463c-94fe-8fc7d636037c"/>
							<gml:surfaceMember xlink:href="#Poly_8601cbf2-6c92-446a-b3ef-d9a0c294d93f"/>
							<gml:surfaceMember xlink:href="#Poly_4c8c07d4-7730-4aea-af12-00b8945c7d22"/>
							<gml:surfaceMember xlink:href="#Poly_18c3d570-d49e-4927-a81e-791bcabc9256"/>
							<gml:surfaceMember xlink:href="#Poly_95405f70-a770-4d66-a668-f28ef6c4c5f4"/>
							<gml:surfaceMember xlink:href="#Poly_5fad0a80-bb9a-4664-9427-ed7e8f9d238e"/>
							<gml:surfaceMember xlink:href="#Poly_c777fd60-f663-45c7-b613-b71bca0ff785"/>
							<gml:surfaceMember xlink:href="#Poly_915d60e7-1471-4495-9f5a-a2a4b1823a2e"/>
							<gml:surfaceMember xlink:href="#Poly_78db6a3a-4069-4e7d-b153-baf50b214c7c"/>
							<gml:surfaceMember xlink:href="#Poly_c142cc11-0783-4e50-870d-4ca52eeb79f4"/>
							<gml:surfaceMember xlink:href="#Poly_0278617b-5eaf-4d65-9eb8-1c8227f248d7"/>
							<gml:surfaceMember xlink:href="#Poly_60995e4f-e96e-4d98-8254-41c6571e10e4"/>
							<gml:surfaceMember xlink:href="#Poly_8b855c0b-c88e-4a74-98b8-3630b18f3c24"/>
							<gml:surfaceMember xlink:href="#Poly_99a819f6-982f-43a3-9597-3514d9e2de2d"/>
							<gml:surfaceMember xlink:href="#Poly_5c1c08e5-15d7-477f-91d6-2443ea4749d5"/>
							<gml:surfaceMember xlink:href="#Poly_5860f29c-7206-4c0b-925e-89a8101cf574"/>
							<gml:surfaceMember xlink:href="#Poly_01144aca-edb4-47de-af07-c15a11713d36"/>
							<gml:surfaceMember xlink:href="#Poly_cde830c1-505f-4dc5-9204-6fb4ffd49b07"/>
							<gml:surfaceMember xlink:href="#Poly_e5a8c37e-8fc5-4c32-9a4e-a9bbaecbd3ba"/>
							<gml:surfaceMember xlink:href="#Poly_f10f4cb9-f523-455c-8223-ed5723565a95"/>
							<gml:surfaceMember xlink:href="#Poly_a1a42daf-7541-4e1a-a3cd-7583cb967d4b"/>
							<gml:surfaceMember xlink:href="#Poly_82fa7609-3fb1-4054-aaa3-2cfcaa1b9a28"/>
							<gml:surfaceMember xlink:href="#Poly_9fa87b93-25ff-425d-9a9d-e81342e45815"/>
							<gml:surfaceMember xlink:href="#Poly_3c42c6d2-961d-4071-85e3-ee17c5449394"/>
							<gml:surfaceMember xlink:href="#Poly_e0612c30-d69c-4551-bc5c-03cfeb150507"/>
							<gml:surfaceMember xlink:href="#Poly_99844600-1706-4d23-b8a2-35d91fb3e11a"/>
							<gml:surfaceMember xlink:href="#Poly_56878d7b-2963-416b-bdae-c8a2a9b3ceac"/>
							<gml:surfaceMember xlink:href="#Poly_5cb6dd17-e37e-4691-96ac-6cd51f6de771"/>
							<gml:surfaceMember xlink:href="#Poly_e34eb704-3e8b-4c36-8471-8c28417171e7"/>
							<gml:surfaceMember xlink:href="#Poly_8a047ec2-c34a-41bf-bd23-dc4b16d386db"/>
							<gml:surfaceMember xlink:href="#Poly_7704d34b-c594-44de-9190-68faea00a646"/>
							<gml:surfaceMember xlink:href="#Poly_ccfedb77-e867-49c8-ab53-932cb76e0a44"/>
							<gml:surfaceMember xlink:href="#Poly_835258bf-71a4-463d-99a1-0ec4437d7ea2"/>
							<gml:surfaceMember xlink:href="#Poly_de2e94d4-826d-4a27-a26d-edb70a78b393"/>
							<gml:surfaceMember xlink:href="#Poly_b289b07a-f332-452d-916c-9e0b8069a3fd"/>
							<gml:surfaceMember xlink:href="#Poly_c6133eda-3b83-4233-ae45-03254de90078"/>
							<gml:surfaceMember xlink:href="#Poly_3f14d764-01e2-4d75-8ba0-4887e5627f50"/>
							<gml:surfaceMember xlink:href="#Poly_eb0a3d27-b789-4848-b0d0-bde2c480f8b4"/>
							<gml:surfaceMember xlink:href="#Poly_3350796a-59a8-4db2-a472-3248d2ed7d2a"/>
							<gml:surfaceMember xlink:href="#Poly_e148d1f2-4c60-4bb0-9f41-3095a3b4fd23"/>
							<gml:surfaceMember xlink:href="#Poly_695cd32e-3a2e-4d76-803c-69261a3218d1"/>
							<gml:surfaceMember xlink:href="#Poly_01cee467-b83f-4c8d-9475-fe46cc9b8c9b"/>
							<gml:surfaceMember xlink:href="#Poly_481950a9-5ca5-4196-8ccc-08faaa1cd66a"/>
							<gml:surfaceMember xlink:href="#Poly_5022667f-8776-4469-8180-25db2a31a382"/>
							<gml:surfaceMember xlink:href="#Poly_19b9b4da-a2fd-48f9-baad-53254b42e44a"/>
							<gml:surfaceMember xlink:href="#Poly_974cfe5f-e78d-4e39-9e40-055f119878f2"/>
							<gml:surfaceMember xlink:href="#Poly_0dcb33a6-70d0-4259-a0ee-22b644dad15c"/>
							<gml:surfaceMember xlink:href="#Poly_c0294477-ff7c-4751-b513-b136cc0efdef"/>
							<gml:surfaceMember xlink:href="#Poly_02255500-32ed-425e-9fe8-9dc335052af4"/>
							<gml:surfaceMember xlink:href="#Poly_23fc76b5-8e7d-4d0d-bde6-d8b4a216c414"/>
							<gml:surfaceMember xlink:href="#Poly_85dca159-ccd2-45da-b240-a9d9df50b491"/>
							<gml:surfaceMember xlink:href="#Poly_a65002fd-f486-4d63-abbf-6af80f27fa40"/>
							<gml:surfaceMember xlink:href="#Poly_83984f05-6276-461a-b732-194af41af613"/>
							<gml:surfaceMember xlink:href="#Poly_6c3cd2c3-8b5e-403a-8a4c-e1362ef4993f"/>
							<gml:surfaceMember xlink:href="#Poly_fa3d39e0-15c0-4600-b140-e6152e0f1726"/>
							<gml:surfaceMember xlink:href="#Poly_8b37e68b-0cf2-4a38-b551-2f1494bfb79e"/>
							<gml:surfaceMember xlink:href="#Poly_7922d3b6-6ddb-4e96-83dc-b60f2c373300"/>
							<gml:surfaceMember xlink:href="#Poly_373ac7ae-502a-4b20-a0ab-93f79aa59410"/>
							<gml:surfaceMember xlink:href="#Poly_0db2893d-10c1-426d-abe5-dd1b3ae9ddaa"/>
							<gml:surfaceMember xlink:href="#Poly_cda17be1-9527-41bb-9f4f-0b0c82f41f52"/>
							<gml:surfaceMember xlink:href="#Poly_40446bae-28cf-433a-b49f-30d35c8f936c"/>
							<gml:surfaceMember xlink:href="#Poly_db976a9a-f35f-4330-8a2f-057513026184"/>
							<gml:surfaceMember xlink:href="#Poly_0f2f8d3d-89ce-4bd7-80d2-dae427a0c755"/>
							<gml:surfaceMember xlink:href="#Poly_9fdc1ad6-eb8a-4c51-b387-e5d3aa65643c"/>
							<gml:surfaceMember xlink:href="#Poly_962ba078-625c-47e0-9741-3bec65dfa78c"/>
							<gml:surfaceMember xlink:href="#Poly_ba7b3fb3-5ebd-44f9-90a4-89fc253b15c7"/>
							<gml:surfaceMember xlink:href="#Poly_876f5b96-d3c4-401e-8629-526087740d76"/>
							<gml:surfaceMember xlink:href="#Poly_6b8e98e1-a0cd-49d4-9ec3-0e15df80073f"/>
							<gml:surfaceMember xlink:href="#Poly_094ef61b-3552-49e6-8d9f-a77f90e40b95"/>
							<gml:surfaceMember xlink:href="#Poly_c8341d66-c22e-4887-82b8-44c156290ccb"/>
							<gml:surfaceMember xlink:href="#Poly_23c69738-a469-4b37-b1e3-188c58746248"/>
							<gml:surfaceMember xlink:href="#Poly_26a6ca31-3410-4cb0-bbc3-efbd7f5fb39f"/>
							<gml:surfaceMember xlink:href="#Poly_4e9131eb-57b2-440f-a5d7-c2ffe3aeae59"/>
							<gml:surfaceMember xlink:href="#Poly_9239ac8f-6682-4933-a5d7-3b28245def2d"/>
							<gml:surfaceMember xlink:href="#Poly_a601c091-f12a-4b90-9ea5-d0e7539fbfae"/>
							<gml:surfaceMember xlink:href="#Poly_70a67229-a121-441b-81ea-3776bf6152f5"/>
							<gml:surfaceMember xlink:href="#Poly_f15ba58b-f383-446f-a47c-25b8ddadb086"/>
							<gml:surfaceMember xlink:href="#Poly_7828f043-078a-4017-bf63-0d5359ab61ac"/>
							<gml:surfaceMember xlink:href="#Poly_79d0dfd4-a4af-4796-9e01-fdc445c2a644"/>
							<gml:surfaceMember xlink:href="#Poly_8f7e2856-e7b2-412f-90e0-a09841c70e4a"/>
							<gml:surfaceMember xlink:href="#Poly_2ae570ec-4c7a-4565-b9f7-5285c199a477"/>
							<gml:surfaceMember xlink:href="#Poly_b8c8d40b-20fa-4157-a361-3093afd62834"/>
							<gml:surfaceMember xlink:href="#Poly_087f708d-b3b3-4233-90b5-eb9b4dd24f92"/>
							<gml:surfaceMember xlink:href="#Poly_f7147748-1d5f-4b14-bb8f-21da96c87e6d"/>
							<gml:surfaceMember xlink:href="#Poly_d91be7b6-025f-4c4b-9fcc-76bcd4d91595"/>
							<gml:surfaceMember xlink:href="#Poly_52657f86-9cef-42c5-834e-aed478d2041d"/>
							<gml:surfaceMember xlink:href="#Poly_1b2830b8-4d98-4d96-bdff-7bc73254acec"/>
							<gml:surfaceMember xlink:href="#Poly_44019daa-b5ac-4c92-a73f-16c33cc9a8d1"/>
							<gml:surfaceMember xlink:href="#Poly_96ba8ee0-8bc8-4738-9ca7-09e4784c6406"/>
							<gml:surfaceMember xlink:href="#Poly_62c64488-03f9-439f-91f0-e3a468ed1686"/>
							<gml:surfaceMember xlink:href="#Poly_f6a6249c-8148-4c9c-aa6e-90c8d099f086"/>
							<gml:surfaceMember xlink:href="#Poly_57910e82-4c88-462a-9fd0-744a6fc4899e"/>
							<gml:surfaceMember xlink:href="#Poly_f434659d-113b-42cd-98d5-48776024402f"/>
							<gml:surfaceMember xlink:href="#Poly_bf9e0095-393e-42d3-94c0-663cd098a2fa"/>
							<gml:surfaceMember xlink:href="#Poly_c575ff02-e84a-4bea-9c59-7529d6e3a692"/>
							<gml:surfaceMember xlink:href="#Poly_4ecfb3ba-5882-4112-93d3-78e6aefde3dd"/>
							<gml:surfaceMember xlink:href="#Poly_6412e036-61db-4853-873a-40be0e842826"/>
							<gml:surfaceMember xlink:href="#Poly_1e5d24bb-841d-498e-87cb-ff788507c680"/>
							<gml:surfaceMember xlink:href="#Poly_96271e77-aee7-4713-952a-fdde736f97f2"/>
							<gml:surfaceMember xlink:href="#Poly_e3c2b371-9909-41df-b70a-6ec85c20c198"/>
							<gml:surfaceMember xlink:href="#Poly_be2a58e6-c688-430c-be60-f71f68a2defb"/>
							<gml:surfaceMember xlink:href="#Poly_cd52f043-abfe-46b2-a2d6-c2a5e231d68a"/>
							<gml:surfaceMember xlink:href="#Poly_829e5f80-1b16-4123-bd1e-06d3e1b2776c"/>
							<gml:surfaceMember xlink:href="#Poly_d5d47a9c-ba0e-451b-82b7-d34f0a88c56a"/>
							<gml:surfaceMember xlink:href="#Poly_5ecc587e-a5d3-4960-abca-f008a0b8c120"/>
							<gml:surfaceMember xlink:href="#Poly_06f710e9-c1c4-4178-a844-38df26daded0"/>
							<gml:surfaceMember xlink:href="#Poly_fbb7eb05-e0d9-41fb-a90d-bec52ae12cd1"/>
							<gml:surfaceMember xlink:href="#Poly_a80262f9-9705-4729-9ab2-11ac18c36de4"/>
							<gml:surfaceMember xlink:href="#Poly_a1df1e08-4bc8-4342-a912-4c6d51cc5740"/>
							<gml:surfaceMember xlink:href="#Poly_a4c84405-4d2c-484e-aa13-7f55fefec2db"/>
							<gml:surfaceMember xlink:href="#Poly_94c5f69f-2a99-41f8-a567-64b11f2786c3"/>
							<gml:surfaceMember xlink:href="#Poly_8eee54e9-d129-480e-8aca-13039b92adae"/>
							<gml:surfaceMember xlink:href="#Poly_00220846-41ce-4646-961e-8e2f75475ce9"/>
							<gml:surfaceMember xlink:href="#Poly_e7fe3fe1-0ffa-40d0-b833-2b5101887ccf"/>
							<gml:surfaceMember xlink:href="#Poly_664a9e5c-48ff-439b-a2a9-aec9a1592721"/>
							<gml:surfaceMember xlink:href="#Poly_57ad0a26-d139-4948-b0de-dbdef6f4ecc2"/>
							<gml:surfaceMember xlink:href="#Poly_20d959e9-0991-410c-b0e8-e1ce178e88be"/>
							<gml:surfaceMember xlink:href="#Poly_d883a868-1946-42ff-a6f2-be5234b945e1"/>
							<gml:surfaceMember xlink:href="#Poly_6d2de3b8-a7bc-4685-bd88-2971b113bb79"/>
							<gml:surfaceMember xlink:href="#Poly_a9213486-971a-4583-97d6-bf2f62c11b17"/>
							<gml:surfaceMember xlink:href="#Poly_436feef4-4557-49d6-99a1-0ee26d3aabe9"/>
							<gml:surfaceMember xlink:href="#Poly_c0e3955c-0be5-49d9-8046-874488446bbb"/>
							<gml:surfaceMember xlink:href="#Poly_051e4859-8e7b-4ad7-8e50-9c593d0384f0"/>
							<gml:surfaceMember xlink:href="#Poly_3ea1c530-faa6-468f-be40-2210de9feb4f"/>
							<gml:surfaceMember xlink:href="#Poly_8dcc1048-7b32-4205-bbee-c0e61c9e0888"/>
							<gml:surfaceMember xlink:href="#Poly_ba233536-81b9-4340-90b2-16d399c67658"/>
							<gml:surfaceMember xlink:href="#Poly_c061ee0d-a976-43ec-b051-0a71de0cf358"/>
							<gml:surfaceMember xlink:href="#Poly_a39e944e-ac51-4e79-88cb-24667d97c72a"/>
							<gml:surfaceMember xlink:href="#Poly_b1d3ecd9-f737-4dfd-9599-0a555fe24556"/>
							<gml:surfaceMember xlink:href="#Poly_e198d086-dd5f-48eb-abb7-2b87885e9fa6"/>
							<gml:surfaceMember xlink:href="#Poly_4c9eda9c-e0bf-48f1-bae1-35750330ef83"/>
							<gml:surfaceMember xlink:href="#Poly_63033c98-d3d2-4a12-a3c3-cbf301fd663f"/>
							<gml:surfaceMember xlink:href="#Poly_34e3d3e7-0139-4a75-a3ac-5183d6874d65"/>
							<gml:surfaceMember xlink:href="#Poly_57b10f02-bd22-4d04-9bd0-87701c436a58"/>
							<gml:surfaceMember xlink:href="#Poly_5e1ef5be-2946-453a-b7f7-32ad16ee9a2f"/>
							<gml:surfaceMember xlink:href="#Poly_776a8db5-dca6-406f-8848-525134df59db"/>
							<gml:surfaceMember xlink:href="#Poly_eddf989d-3181-4c54-afcb-436fe68e4e7d"/>
							<gml:surfaceMember xlink:href="#Poly_902a25c5-88ad-40a0-8448-efe0b62b2881"/>
							<gml:surfaceMember xlink:href="#Poly_93e1c39d-e796-4df2-87d4-5b5a92145620"/>
							<gml:surfaceMember xlink:href="#Poly_ed31f793-6221-4615-90be-4593e25dc8ec"/>
							<gml:surfaceMember xlink:href="#Poly_e27e9179-ff3a-451d-b711-99a64747b8ff"/>
							<gml:surfaceMember xlink:href="#Poly_9e055141-09ce-4d6a-a287-1a19d83f1924"/>
							<gml:surfaceMember xlink:href="#Poly_7a01894b-67ad-4000-a2db-a24f554ac16e"/>
							<gml:surfaceMember xlink:href="#Poly_b0303294-a12d-4d04-89ce-4e9fba527125"/>
							<gml:surfaceMember xlink:href="#Poly_65e8b7ef-0dea-4e65-bc83-ffd75d5eec64"/>
							<gml:surfaceMember xlink:href="#Poly_c19dbfec-7c9a-42c6-8be6-fdd10568e4e4"/>
							<gml:surfaceMember xlink:href="#Poly_c5ed99c9-5b83-4edc-a1ee-2abf2c21f651"/>
							<gml:surfaceMember xlink:href="#Poly_16e9f5ca-1586-489d-a024-d16a07de6086"/>
							<gml:surfaceMember xlink:href="#Poly_8f640eb8-1af3-4a63-b473-52d25c7e5046"/>
							<gml:surfaceMember xlink:href="#Poly_59432baf-ae3f-4247-a651-e07bc0e17f5c"/>
							<gml:surfaceMember xlink:href="#Poly_60d64295-f931-48ce-8879-f68328f2dd15"/>
							<gml:surfaceMember xlink:href="#Poly_a7e92a12-b3b8-466c-a5fb-dac2881fb872"/>
							<gml:surfaceMember xlink:href="#Poly_ca9297f2-49cc-49ea-af77-613729ae81a6"/>
							<gml:surfaceMember xlink:href="#Poly_a7cbeede-0173-4d84-a520-1dad4d98bb2b"/>
							<gml:surfaceMember xlink:href="#Poly_dfbf2ec4-3c5a-4515-a381-247122e203df"/>
							<gml:surfaceMember xlink:href="#Poly_b94234fd-09ec-489d-b59c-04c39161481b"/>
							<gml:surfaceMember xlink:href="#Poly_e08ab483-7192-4e34-bc70-48efa05a3184"/>
							<gml:surfaceMember xlink:href="#Poly_f9e94ff9-fbe8-4f80-be80-b06a28ee1999"/>
							<gml:surfaceMember xlink:href="#Poly_1b9c9ba8-b9f4-4de6-a195-ae935549e526"/>
							<gml:surfaceMember xlink:href="#Poly_f69e26e8-c6b6-47b8-b42a-23bcb7974c96"/>
							<gml:surfaceMember xlink:href="#Poly_33863400-b15e-4566-a2ec-e25cc51bac49"/>
							<gml:surfaceMember xlink:href="#Poly_debf2694-3c8f-4223-9327-8ca2e73d3e32"/>
							<gml:surfaceMember xlink:href="#Poly_f3070ec5-e27e-4d6d-b826-0d44600658f5"/>
							<gml:surfaceMember xlink:href="#Poly_e0f4e91f-8317-465b-bcc4-2cd151036bf6"/>
							<gml:surfaceMember xlink:href="#Poly_ec404324-5fdb-4fc9-9774-7cd5eb61de0e"/>
							<gml:surfaceMember xlink:href="#Poly_f8e9bf3e-d106-4905-bafe-0c449bd2168a"/>
							<gml:surfaceMember xlink:href="#Poly_806d735e-3353-4905-a2c7-7ee5c04a13ed"/>
							<gml:surfaceMember xlink:href="#Poly_49c88477-fddf-4b27-93de-c85fc98aef8b"/>
							<gml:surfaceMember xlink:href="#Poly_d6268da8-93e5-444c-b419-7c2e90a43c2d"/>
							<gml:surfaceMember xlink:href="#Poly_eaa33a05-b964-4c19-aae4-57ca6c374e2b"/>
							<gml:surfaceMember xlink:href="#Poly_06c01ec0-ba69-4238-88b8-fb43790d96a2"/>
							<gml:surfaceMember xlink:href="#Poly_02cee936-e4f2-48ae-ba66-d37eef57adf0"/>
							<gml:surfaceMember xlink:href="#Poly_832cf563-4bbf-4dc0-bbb0-427cb2f9dfe3"/>
							<gml:surfaceMember xlink:href="#Poly_739d963e-1cfa-4967-8bbb-1a1af7b49553"/>
							<gml:surfaceMember xlink:href="#Poly_d804b054-27d8-417e-a58e-3d88bd6c701d"/>
							<gml:surfaceMember xlink:href="#Poly_2a77f7fc-ef34-4b9a-b958-9b92ab39eac6"/>
							<gml:surfaceMember xlink:href="#Poly_5feac9e7-fc6e-48c3-8883-4fc0f232c810"/>
							<gml:surfaceMember xlink:href="#Poly_1b4589b8-2a36-40c7-94f1-0eb11d278dcb"/>
							<gml:surfaceMember xlink:href="#Poly_285b61e6-48c4-44ce-925d-87fc909b4fe0"/>
							<gml:surfaceMember xlink:href="#Poly_60b93bf5-7049-40ae-906f-7d16cdca4347"/>
							<gml:surfaceMember xlink:href="#Poly_df6e57b1-391f-4cae-bcb1-1772cbf4b429"/>
							<gml:surfaceMember xlink:href="#Poly_8a1c47ef-63bf-40dd-a96e-24b9507277c9"/>
							<gml:surfaceMember xlink:href="#Poly_3955b620-21a8-4c0b-8f6e-de0e772dcedf"/>
							<gml:surfaceMember xlink:href="#Poly_3d76f715-ae43-4111-83f9-171fa4ebfa64"/>
							<gml:surfaceMember xlink:href="#Poly_6c90238c-da7e-4705-94e5-78e2382afe16"/>
							<gml:surfaceMember xlink:href="#Poly_c32d6981-c6d5-42b7-aa8a-18ddb7835b8c"/>
							<gml:surfaceMember xlink:href="#Poly_c2da0fb4-9150-4779-b2db-745538a3bbf1"/>
							<gml:surfaceMember xlink:href="#Poly_2578876d-0bea-4320-b402-94bfaa26702f"/>
							<gml:surfaceMember xlink:href="#Poly_d03d34a4-f8de-49ad-b3a1-36612764b18d"/>
							<gml:surfaceMember xlink:href="#Poly_83d55cbf-035e-457d-a736-3ed49aa7d7c3"/>
							<gml:surfaceMember xlink:href="#Poly_ac1c230b-d6b9-47b3-a504-4cfe00188066"/>
							<gml:surfaceMember xlink:href="#Poly_2b4eb642-7667-4c94-b690-5e8e979cc42e"/>
							<gml:surfaceMember xlink:href="#Poly_8d0cfd1f-fc9c-4800-8936-6e2a5a96391a"/>
							<gml:surfaceMember xlink:href="#Poly_ef9aab51-0bfd-461e-94e9-0392c5860493"/>
							<gml:surfaceMember xlink:href="#Poly_a2629455-8b43-41ce-8377-f554e191b45d"/>
							<gml:surfaceMember xlink:href="#Poly_54b55bd5-b17c-48a0-823a-4c28cc9cdef1"/>
							<gml:surfaceMember xlink:href="#Poly_b7bde1bf-4754-4289-87a6-47f66a09131a"/>
							<gml:surfaceMember xlink:href="#Poly_7a2a695c-d4cb-4694-bf08-b4f74f13bc88"/>
							<gml:surfaceMember xlink:href="#Poly_441c0e6c-239a-4ed7-9a6c-a6a9c48eebef"/>
							<gml:surfaceMember xlink:href="#Poly_7eb453e8-3b23-4366-bdd2-e8f4300899ac"/>
							<gml:surfaceMember xlink:href="#Poly_afd4cc5f-8fb2-4c93-8539-95e9d32d2ac5"/>
							<gml:surfaceMember xlink:href="#Poly_f7fb8d61-1991-41e7-af6e-0e7644e0fd18"/>
							<gml:surfaceMember xlink:href="#Poly_880ded9b-a3b2-4882-b79a-9b4192322c14"/>
							<gml:surfaceMember xlink:href="#Poly_095decfe-e149-46b7-b3f8-fc5ffdafb698"/>
							<gml:surfaceMember xlink:href="#Poly_57aeb552-b4b8-4c5b-b06f-cd00cd960e0a"/>
							<gml:surfaceMember xlink:href="#Poly_03b0b592-34e4-42fb-8365-c0b34b4bc5e4"/>
							<gml:surfaceMember xlink:href="#Poly_f9ef6448-db33-45ff-bba6-df3983a073ed"/>
							<gml:surfaceMember xlink:href="#Poly_77faf265-678d-4651-86d1-50c236b2489d"/>
							<gml:surfaceMember xlink:href="#Poly_72496295-0d2c-4f58-b171-c6a46504760f"/>
							<gml:surfaceMember xlink:href="#Poly_7b43bc1b-9ac3-4cff-8512-ac033f078e4e"/>
							<gml:surfaceMember xlink:href="#Poly_a479f3cb-056b-4474-b524-6022c90a5a5f"/>
							<gml:surfaceMember xlink:href="#Poly_97ce8ec7-ea6f-42d6-9a5f-58d07fbfaecd"/>
							<gml:surfaceMember xlink:href="#Poly_cf6a9cad-b116-4456-a98e-20e352984ff6"/>
							<gml:surfaceMember xlink:href="#Poly_415588d0-ca84-4779-aefd-f57429236fe3"/>
							<gml:surfaceMember xlink:href="#Poly_1434ff8c-42e5-4eea-ad73-07be5f2582e0"/>
							<gml:surfaceMember xlink:href="#Poly_57e3a827-02e1-4dbe-a66d-a7ee72a678d5"/>
							<gml:surfaceMember xlink:href="#Poly_820e4951-5343-4929-9b2a-cbe37a05e20e"/>
							<gml:surfaceMember xlink:href="#Poly_f13dd72a-8210-4258-8b56-1d078846b0cc"/>
							<gml:surfaceMember xlink:href="#Poly_7e2ba2ac-b80b-446c-bd5a-90721cc01548"/>
							<gml:surfaceMember xlink:href="#Poly_1c47bf53-a337-4ac0-a883-c8a5766675de"/>
							<gml:surfaceMember xlink:href="#Poly_72b8bd69-437f-4928-b786-7b13b73a8293"/>
							<gml:surfaceMember xlink:href="#Poly_54a94861-d71b-45f2-9948-4df8454acb32"/>
							<gml:surfaceMember xlink:href="#Poly_2a749460-e833-4e48-ba8b-e6628b6f5c6c"/>
							<gml:surfaceMember xlink:href="#Poly_5c5a15e4-41d3-45b2-8f81-c6bde237e559"/>
							<gml:surfaceMember xlink:href="#Poly_efcea443-a18d-4db1-b421-750dd9471eb2"/>
							<gml:surfaceMember xlink:href="#Poly_220fcd55-91c9-4029-ba66-727da07cc72e"/>
							<gml:surfaceMember xlink:href="#Poly_5c6e8f52-f70d-4bb9-8a1b-2e772a8c58fb"/>
							<gml:surfaceMember xlink:href="#Poly_0e2b60e4-e8c3-4f56-bc52-0a733914a940"/>
							<gml:surfaceMember xlink:href="#Poly_ebcc9536-6ade-4916-a1eb-f71b2392b094"/>
							<gml:surfaceMember xlink:href="#Poly_f83fb810-30e9-45ae-b1a0-0a09ab19dea5"/>
							<gml:surfaceMember xlink:href="#Poly_464e3827-9143-4035-9b32-f62179fb7e26"/>
							<gml:surfaceMember xlink:href="#Poly_d03f1836-b68a-40d4-b3c4-12d2a9cb843c"/>
							<gml:surfaceMember xlink:href="#Poly_bd298ddf-2409-4564-a0c9-c6977f5cdbdd"/>
							<gml:surfaceMember xlink:href="#Poly_2b4c46bc-b8ee-42ce-aa96-739a8a9f618a"/>
							<gml:surfaceMember xlink:href="#Poly_a521560d-f9bc-4909-9ab5-969e4e07c5d5"/>
							<gml:surfaceMember xlink:href="#Poly_55aa27d5-9081-4009-b103-ed7dd7f73997"/>
							<gml:surfaceMember xlink:href="#Poly_180d1ba7-c971-44cd-80e9-140627d859ca"/>
							<gml:surfaceMember xlink:href="#Poly_42eb7c9b-497d-4a17-8439-980ea2a99d33"/>
							<gml:surfaceMember xlink:href="#Poly_4ae20914-54f9-4dee-ba7a-e41cdd1c01fb"/>
							<gml:surfaceMember xlink:href="#Poly_9eeb9316-5cbe-4e12-9b16-c101beaf70ad"/>
							<gml:surfaceMember xlink:href="#Poly_5f0581ac-90de-4952-9a58-c261dda9ab78"/>
							<gml:surfaceMember xlink:href="#Poly_f7dc61d5-3d59-428e-8104-890e7b385837"/>
							<gml:surfaceMember xlink:href="#Poly_9b6d2fea-de1b-4e86-b494-d4c6387dabf6"/>
							<gml:surfaceMember xlink:href="#Poly_76d85904-faf8-412d-8998-d24370585de9"/>
							<gml:surfaceMember xlink:href="#Poly_9b18ed33-647b-46f1-9e96-a9d7b143919c"/>
							<gml:surfaceMember xlink:href="#Poly_1778978c-4999-4e73-a154-b69b7ffa0bda"/>
							<gml:surfaceMember xlink:href="#Poly_9b38eefe-8d28-4c36-aaa8-b0475b37bfed"/>
							<gml:surfaceMember xlink:href="#Poly_f59ff5f5-e436-4ffa-8fa7-1e80386cd01e"/>
							<gml:surfaceMember xlink:href="#Poly_60960793-96a1-4aa7-a506-fd028baf6ae9"/>
							<gml:surfaceMember xlink:href="#Poly_0d52dfa7-e175-4965-9121-37ebcb00e1d0"/>
							<gml:surfaceMember xlink:href="#Poly_7dcc0232-848b-4a60-87d8-f1a69a699955"/>
							<gml:surfaceMember xlink:href="#Poly_2b19e256-3ed0-428e-bf49-316415e7532a"/>
							<gml:surfaceMember xlink:href="#Poly_dc656fae-a73a-4348-804b-09737f5a3f1d"/>
							<gml:surfaceMember xlink:href="#Poly_7cc827e1-fdd1-4d46-8b24-28c17ac4c72d"/>
							<gml:surfaceMember xlink:href="#Poly_4172c94d-bd30-4f55-8fc6-fae3f8858a53"/>
							<gml:surfaceMember xlink:href="#Poly_6bf5d802-7780-4cc7-9cd8-f46740d726a2"/>
							<gml:surfaceMember xlink:href="#Poly_8810ffee-7ecd-46dc-92b6-aa1288b67852"/>
							<gml:surfaceMember xlink:href="#Poly_9d0654e7-11f3-41b1-b9a6-8c971c117280"/>
							<gml:surfaceMember xlink:href="#Poly_8394df1b-6b1e-498e-b845-c712df0e3268"/>
							<gml:surfaceMember xlink:href="#Poly_c3ba8bd3-8dda-401d-8a6b-070415153a0a"/>
							<gml:surfaceMember xlink:href="#Poly_5ce094fb-75ce-43dc-b436-ed0898ea4ef3"/>
							<gml:surfaceMember xlink:href="#Poly_80083689-fbd3-4e1a-af28-604f94ca85fd"/>
							<gml:surfaceMember xlink:href="#Poly_a17e9980-ed3a-4804-a046-7d3eda514fbb"/>
							<gml:surfaceMember xlink:href="#Poly_0b3508f0-98bf-4097-87fe-0b64d30d0f8e"/>
							<gml:surfaceMember xlink:href="#Poly_0c11784b-d53e-4f4d-b72f-d4c9c728cdb0"/>
							<gml:surfaceMember xlink:href="#Poly_25a06a88-3c5a-45d0-9a17-36eecc7b25a6"/>
							<gml:surfaceMember xlink:href="#Poly_eb8b66f4-d34a-49ee-b50e-a959acde5ab2"/>
							<gml:surfaceMember xlink:href="#Poly_b41f6f0a-6617-4fc2-b42d-c8719d853b83"/>
							<gml:surfaceMember xlink:href="#Poly_fcd58446-0121-4ef4-a7b1-9cf25ad80905"/>
							<gml:surfaceMember xlink:href="#Poly_60b1150d-b5cf-4124-876c-d9f070d23543"/>
							<gml:surfaceMember xlink:href="#Poly_d45b9e99-98be-4f11-8d46-74c219bfe3fd"/>
							<gml:surfaceMember xlink:href="#Poly_9395ec34-0762-42f8-b55b-d9674327ec46"/>
							<gml:surfaceMember xlink:href="#Poly_9b447a9b-dc54-4618-8105-8c33bf224baa"/>
							<gml:surfaceMember xlink:href="#Poly_8d8061dd-06d9-4e2e-8dc9-c36bd666ca83"/>
							<gml:surfaceMember xlink:href="#Poly_1ea10e85-8add-4504-8f81-af2620c27ced"/>
							<gml:surfaceMember xlink:href="#Poly_bc380f38-e59f-47c6-ab59-27967a3f10d5"/>
							<gml:surfaceMember xlink:href="#Poly_d43fba7b-fefe-4908-97f4-b5657cf760b4"/>
							<gml:surfaceMember xlink:href="#Poly_5c09c1ec-f76f-4a58-8584-09fa142f20f1"/>
							<gml:surfaceMember xlink:href="#Poly_9ba5d6c5-dafb-4140-a804-3e0a595a54f2"/>
							<gml:surfaceMember xlink:href="#Poly_8094217c-4a8c-4c91-afe1-da1607966cc6"/>
							<gml:surfaceMember xlink:href="#Poly_9712e862-7b48-4a65-a95e-a9c352b2e729"/>
							<gml:surfaceMember xlink:href="#Poly_6de48a7d-67f6-4b65-a4dd-01eeda4d57f0"/>
							<gml:surfaceMember xlink:href="#Poly_00df1d1d-4267-4ea3-b62e-d0fef9c04213"/>
							<gml:surfaceMember xlink:href="#Poly_a85df06d-924c-4cee-a06d-15de7f4a7f3e"/>
							<gml:surfaceMember xlink:href="#Poly_5368a7c2-9bf5-4ab7-9b05-2b6c27bf5208"/>
							<gml:surfaceMember xlink:href="#Poly_61f3f796-8ed8-4b59-85fe-53f7c3c1c48d"/>
							<gml:surfaceMember xlink:href="#Poly_48ec70ca-37d4-4bfc-b7b3-bcede605ea60"/>
							<gml:surfaceMember xlink:href="#Poly_33283110-c4a6-4663-b3ca-33707b53911d"/>
							<gml:surfaceMember xlink:href="#Poly_cde38b98-8b8c-4afc-86db-e35c9d7d206f"/>
							<gml:surfaceMember xlink:href="#Poly_500c8978-27b2-4d1b-a45b-0151ae92a041"/>
							<gml:surfaceMember xlink:href="#Poly_608d1224-28a5-42f1-be9b-71284bbd55d7"/>
							<gml:surfaceMember xlink:href="#Poly_3c56326c-2462-40e6-8bab-044ab4e5c39b"/>
							<gml:surfaceMember xlink:href="#Poly_5853aa13-f5a4-470e-8814-5d8ef2909db1"/>
							<gml:surfaceMember xlink:href="#Poly_1def5a56-85c8-49c6-942b-a07e56a7748a"/>
							<gml:surfaceMember xlink:href="#Poly_26532936-adb4-4539-bae2-8f77c40ae463"/>
							<gml:surfaceMember xlink:href="#Poly_232c183b-4bdd-49a1-89db-1e027a1525d2"/>
							<gml:surfaceMember xlink:href="#Poly_fa2f8a6b-c144-4b70-8afd-45a9f89b63e5"/>
							<gml:surfaceMember xlink:href="#Poly_21441fcc-f238-42de-bbe9-fcaadde66414"/>
							<gml:surfaceMember xlink:href="#Poly_7f5d5513-285c-4934-8835-d1d6bb97ca30"/>
							<gml:surfaceMember xlink:href="#Poly_b2a4408e-04d8-44f0-abc4-c4ccb912d5c8"/>
							<gml:surfaceMember xlink:href="#Poly_48d96acb-7435-4aba-994d-d796a5c6fce4"/>
							<gml:surfaceMember xlink:href="#Poly_ca142917-5f6e-4ef1-8732-e9d69a461bbf"/>
							<gml:surfaceMember xlink:href="#Poly_cb247e62-1c11-420e-83cf-bdc0d68c049a"/>
							<gml:surfaceMember xlink:href="#Poly_3a0e6916-42a5-4a0b-b3c8-dd15934e2232"/>
							<gml:surfaceMember xlink:href="#Poly_63e97109-a43e-4348-9b62-48881f83fd67"/>
							<gml:surfaceMember xlink:href="#Poly_04207cf4-6c0c-4861-9473-4c8afaa10612"/>
							<gml:surfaceMember xlink:href="#Poly_aacfece6-3541-4885-aa8a-f6fde33975d5"/>
							<gml:surfaceMember xlink:href="#Poly_46861e27-6e54-4aea-9f05-da46af2b3b30"/>
							<gml:surfaceMember xlink:href="#Poly_f33f0961-a42f-4080-b8d1-7d511bef6250"/>
							<gml:surfaceMember xlink:href="#Poly_7bdbf9c8-c6e5-4104-a699-ed400d684a01"/>
							<gml:surfaceMember xlink:href="#Poly_52a0bebf-8944-4ca9-bd8a-ad127a1ce671"/>
							<gml:surfaceMember xlink:href="#Poly_bde82156-b983-4189-8f17-65a076947560"/>
							<gml:surfaceMember xlink:href="#Poly_fccb7e42-0147-4c03-9a9e-2c16e2cc9ebe"/>
							<gml:surfaceMember xlink:href="#Poly_dc5bd5a6-28ab-4c7f-bd59-f70f45511ee5"/>
							<gml:surfaceMember xlink:href="#Poly_969452f9-51cd-4d40-92d7-9d9729694bde"/>
							<gml:surfaceMember xlink:href="#Poly_26ce292d-bbed-40e7-a784-f78ef8fb1f9f"/>
							<gml:surfaceMember xlink:href="#Poly_618f350d-01a6-4168-9ae2-662ac8c3f807"/>
							<gml:surfaceMember xlink:href="#Poly_30912bf0-909c-4d1a-8cd7-2d541626c2c8"/>
							<gml:surfaceMember xlink:href="#Poly_e05488bf-7a50-4e6d-9f40-0975995b7bda"/>
							<gml:surfaceMember xlink:href="#Poly_59467dea-e0c4-428e-a6a2-6bc000c25990"/>
							<gml:surfaceMember xlink:href="#Poly_968a1d0f-892a-4aa5-858d-92514f322890"/>
							<gml:surfaceMember xlink:href="#Poly_58f30653-1709-4781-aeeb-4f1cf6eef228"/>
							<gml:surfaceMember xlink:href="#Poly_df664965-8ad3-474e-9b0a-bfa63f8cdf0d"/>
							<gml:surfaceMember xlink:href="#Poly_cad2e786-b7af-49e1-956d-7a695d1d901c"/>
							<gml:surfaceMember xlink:href="#Poly_f15dd004-ec7a-4023-82fd-fad7145aa71c"/>
							<gml:surfaceMember xlink:href="#Poly_f85766d7-ae13-4f8a-83b1-be8c054282e9"/>
							<gml:surfaceMember xlink:href="#Poly_9e09dcdc-fc66-488b-9bc8-26e4ecc9ca9d"/>
							<gml:surfaceMember xlink:href="#Poly_45f25108-5f1d-4f02-a838-655f10c1820f"/>
							<gml:surfaceMember xlink:href="#Poly_15b84006-c28a-4153-bb5d-efe8703e34f9"/>
							<gml:surfaceMember xlink:href="#Poly_c344250d-e3c5-4502-a4f7-77349c1a245e"/>
							<gml:surfaceMember xlink:href="#Poly_a64c33ed-6ba4-4dcd-8eb1-535f4cb33f6a"/>
							<gml:surfaceMember xlink:href="#Poly_67d166f6-2708-4988-823b-df2f40858265"/>
							<gml:surfaceMember xlink:href="#Poly_c5b30e90-bd38-403f-807d-c37a3522b080"/>
							<gml:surfaceMember xlink:href="#Poly_0dded7dd-1f56-478c-9566-bed93da0dd51"/>
							<gml:surfaceMember xlink:href="#Poly_6fe6ec0a-7aba-48f9-83c5-4b3e2fca7dc9"/>
							<gml:surfaceMember xlink:href="#Poly_5bb7d460-3719-4ff4-b3e7-0b2d43e77a58"/>
							<gml:surfaceMember xlink:href="#Poly_57bc0959-0130-4665-9ed6-f501436bd7e3"/>
							<gml:surfaceMember xlink:href="#Poly_1b60df17-205b-460f-b4b8-5238add148f8"/>
							<gml:surfaceMember xlink:href="#Poly_d995b721-668c-4b21-bbc0-e9789900c434"/>
							<gml:surfaceMember xlink:href="#Poly_583e9ae4-c4e1-4f92-be42-6690a18c6c0b"/>
							<gml:surfaceMember xlink:href="#Poly_5efd7dd2-2aba-4ebc-94c3-a8234ab5609c"/>
							<gml:surfaceMember xlink:href="#Poly_e96d102a-d44d-4bc1-9346-3e4acc56b91c"/>
							<gml:surfaceMember xlink:href="#Poly_f5784dc2-e37d-4149-928c-5a05cbd8ec9c"/>
							<gml:surfaceMember xlink:href="#Poly_9cb6eb89-31e0-4e51-9f1a-48100d0d9408"/>
							<gml:surfaceMember xlink:href="#Poly_1086ec55-c6ef-47a6-9e1f-1b84891e6c40"/>
							<gml:surfaceMember xlink:href="#Poly_15e438c0-120a-4871-b407-87aff169b762"/>
							<gml:surfaceMember xlink:href="#Poly_39c09e46-a2b3-4408-8fbf-aa1d9e67997c"/>
							<gml:surfaceMember xlink:href="#Poly_8fab033e-0cc2-4577-98ac-ed72956f92c3"/>
							<gml:surfaceMember xlink:href="#Poly_305952e3-78dd-4039-98b8-e75e83e1d4f8"/>
							<gml:surfaceMember xlink:href="#Poly_d28bbb84-fc09-4835-ba1c-2d215840d50f"/>
							<gml:surfaceMember xlink:href="#Poly_28c647a9-94b6-4ead-a0ff-5b7a38df2872"/>
							<gml:surfaceMember xlink:href="#Poly_1add8786-955e-45f7-9d47-ba42e897c2b5"/>
							<gml:surfaceMember xlink:href="#Poly_a22cad33-e8a4-4330-bb1e-b3a7305129fb"/>
							<gml:surfaceMember xlink:href="#Poly_c62f47d7-37e3-47fa-94d5-6d1c03b45d08"/>
							<gml:surfaceMember xlink:href="#Poly_a8fbf74b-069d-4d3d-92e8-18836f4c945c"/>
							<gml:surfaceMember xlink:href="#Poly_976b5926-05fc-48d4-b0c1-d6cdd77af9bc"/>
							<gml:surfaceMember xlink:href="#Poly_3340a94d-09ee-4017-9764-f9e6ac43d502"/>
							<gml:surfaceMember xlink:href="#Poly_77cddcf4-40fa-4a6b-9f16-505718946e8a"/>
							<gml:surfaceMember xlink:href="#Poly_69ba5772-bdaf-4d04-9d98-fb54ffdb389c"/>
							<gml:surfaceMember xlink:href="#Poly_d7720953-e944-4c93-8652-d51c01e8667b"/>
							<gml:surfaceMember xlink:href="#Poly_c5f94a23-cc32-43ab-a160-49372e273b3c"/>
							<gml:surfaceMember xlink:href="#Poly_02004dee-00d5-42a3-b28a-40ddf3d879c8"/>
							<gml:surfaceMember xlink:href="#Poly_62363658-990f-4ab5-81d2-c645541b1a8d"/>
							<gml:surfaceMember xlink:href="#Poly_0952874a-72b7-4962-a0a2-09a801ed2191"/>
							<gml:surfaceMember xlink:href="#Poly_4834911f-e96e-4480-a386-12bf796b87bc"/>
							<gml:surfaceMember xlink:href="#Poly_1d41c96b-02c2-4ed4-b8f3-2d6699123421"/>
							<gml:surfaceMember xlink:href="#Poly_44f4f60a-175a-49de-92c4-23d55e84e963"/>
							<gml:surfaceMember xlink:href="#Poly_f077f384-8870-4480-a594-fadd5a42a72f"/>
							<gml:surfaceMember xlink:href="#Poly_333a1ce6-c5b3-4c3d-a56e-bc0e5254acd2"/>
							<gml:surfaceMember xlink:href="#Poly_782d4c61-5e33-4822-9dd5-cb0279b22fed"/>
							<gml:surfaceMember xlink:href="#Poly_95c74a8f-0e66-4197-abc4-78c6139c53d5"/>
							<gml:surfaceMember xlink:href="#Poly_b9d66ab2-8615-44f8-a1fe-8c5595c1de46"/>
							<gml:surfaceMember xlink:href="#Poly_27c942d4-8b44-43d6-b6e1-0b3f2caaa921"/>
							<gml:surfaceMember xlink:href="#Poly_79d5fe9a-9ac3-4c68-823a-a64b80a8368f"/>
							<gml:surfaceMember xlink:href="#Poly_5b964c5a-e124-4da2-861f-7024d09936b0"/>
							<gml:surfaceMember xlink:href="#Poly_e81fc049-fdda-47b0-8471-c191765a0cb2"/>
							<gml:surfaceMember xlink:href="#Poly_4fcdb1c8-3d20-4929-bb6b-c3945216271c"/>
							<gml:surfaceMember xlink:href="#Poly_5f24cfaf-a05b-423c-8bb3-0a624a89f68d"/>
							<gml:surfaceMember xlink:href="#Poly_ef48014b-31d9-47ee-b464-a06b19a1a40e"/>
							<gml:surfaceMember xlink:href="#Poly_bd87f379-ccfa-4f95-9f59-e4d38a0ed5fa"/>
							<gml:surfaceMember xlink:href="#Poly_ac3cfa0c-fd39-44bd-a58a-8f88d08933cf"/>
							<gml:surfaceMember xlink:href="#Poly_57d1b2d0-cf76-40d1-ab43-4d1948cde412"/>
							<gml:surfaceMember xlink:href="#Poly_29a7a911-50f6-4a60-aa0e-413c57cce114"/>
							<gml:surfaceMember xlink:href="#Poly_f6851e01-d34d-4a76-a0ce-eb8ad0996aa1"/>
							<gml:surfaceMember xlink:href="#Poly_7bed1b8c-48ae-4ed0-95b9-475d2cd3c39f"/>
							<gml:surfaceMember xlink:href="#Poly_afe87d6d-1b7c-47b6-9f0f-52f92fc9e431"/>
							<gml:surfaceMember xlink:href="#Poly_9dcd8723-c204-49ad-864f-9587efdf8153"/>
							<gml:surfaceMember xlink:href="#Poly_13fe9845-cbb0-4914-83ff-70eddc8474bd"/>
							<gml:surfaceMember xlink:href="#Poly_c943c5a1-e2d3-411b-ba1c-19728571163b"/>
							<gml:surfaceMember xlink:href="#Poly_963b4afd-1643-4a9d-b325-fa89df77f47c"/>
							<gml:surfaceMember xlink:href="#Poly_65737eef-88ab-4279-a806-73692d281e1f"/>
							<gml:surfaceMember xlink:href="#Poly_89813f25-9c8f-40e0-a1ed-027dc75afd10"/>
							<gml:surfaceMember xlink:href="#Poly_dba0127d-efd0-4654-bd3e-934af6c3de74"/>
							<gml:surfaceMember xlink:href="#Poly_ccb3f30e-a2d9-47e0-ab93-2c6f24bd9ac0"/>
							<gml:surfaceMember xlink:href="#Poly_eb4e683b-fbf7-40ef-a322-6e301edae1cc"/>
							<gml:surfaceMember xlink:href="#Poly_e448ec45-cf89-4c9d-8369-52e1ea124884"/>
							<gml:surfaceMember xlink:href="#Poly_5320a43a-6eb2-44c2-ad05-fa68a8904db9"/>
							<gml:surfaceMember xlink:href="#Poly_e8657e66-8e7e-4392-a5ea-0696f46a7402"/>
							<gml:surfaceMember xlink:href="#Poly_437b9dc1-2ad0-4f41-90da-0d72fb401424"/>
							<gml:surfaceMember xlink:href="#Poly_828eafb3-6a23-4644-8d67-f0ce236babe0"/>
							<gml:surfaceMember xlink:href="#Poly_173ca19c-d27d-4266-814a-bd9a6b4726f5"/>
							<gml:surfaceMember xlink:href="#Poly_f2fc12a9-5435-4bcb-8413-7af3cbd935fb"/>
							<gml:surfaceMember xlink:href="#Poly_ac6f4ac8-3068-4ab3-974a-2df4f07a22cb"/>
							<gml:surfaceMember xlink:href="#Poly_d4fcceba-e865-4d73-9cdc-78a3ab36c082"/>
							<gml:surfaceMember xlink:href="#Poly_7fe04b28-1621-4245-b256-c17e560f7399"/>
							<gml:surfaceMember xlink:href="#Poly_5a0a7a7d-a7ab-49e9-b01f-c193d69c64a5"/>
							<gml:surfaceMember xlink:href="#Poly_502124dc-de38-40da-bda9-571e789f11a2"/>
							<gml:surfaceMember xlink:href="#Poly_174c59b4-1b21-4731-9c79-dc0e7a3027fc"/>
							<gml:surfaceMember xlink:href="#Poly_8fa6d90e-a9a6-4921-915e-5c30fcb069b3"/>
							<gml:surfaceMember xlink:href="#Poly_fb31554b-fccf-4b76-afe2-759d1dd53743"/>
							<gml:surfaceMember xlink:href="#Poly_bdee288b-15de-43f8-84a0-057079ef8a7d"/>
							<gml:surfaceMember xlink:href="#Poly_4a4ca872-b161-4a2d-b20b-b96ca3d1148a"/>
							<gml:surfaceMember xlink:href="#Poly_59cd8dd0-e165-4b6e-adf3-9a680ec9e11a"/>
							<gml:surfaceMember xlink:href="#Poly_f1df555e-3f02-4d9f-a11e-7979d60d7ade"/>
							<gml:surfaceMember xlink:href="#Poly_d43b1406-1b8a-400b-86aa-3088067a8814"/>
							<gml:surfaceMember xlink:href="#Poly_f811b9db-d2cf-4908-b786-044e7bdb2d71"/>
							<gml:surfaceMember xlink:href="#Poly_659877b7-1a4b-47a5-a7bb-a9ae99af96d4"/>
							<gml:surfaceMember xlink:href="#Poly_988a71cb-76bf-46b0-b644-38ffd402ac44"/>
							<gml:surfaceMember xlink:href="#Poly_153a3067-b791-4d13-80d5-c4312eb55ad5"/>
							<gml:surfaceMember xlink:href="#Poly_c091b54a-c11b-4277-b4e1-776ff2da6e20"/>
							<gml:surfaceMember xlink:href="#Poly_13c06a71-3a39-4ae0-9668-fd5c21a121cd"/>
							<gml:surfaceMember xlink:href="#Poly_2955b662-4690-40a2-8445-a638e36e3b26"/>
							<gml:surfaceMember xlink:href="#Poly_9c35816e-f70a-48f7-92e9-1082e29a15a7"/>
							<gml:surfaceMember xlink:href="#Poly_d5b9a0c5-09ff-457c-b70b-99974c0933d6"/>
							<gml:surfaceMember xlink:href="#Poly_da365f34-67df-47db-81c9-06a735dbf9d9"/>
							<gml:surfaceMember xlink:href="#Poly_f6d700c7-1e59-437a-a144-bb231a716282"/>
							<gml:surfaceMember xlink:href="#Poly_435a0ceb-0ece-467a-8883-5bac657c7740"/>
							<gml:surfaceMember xlink:href="#Poly_139646c8-c3d6-40fd-8d78-e4365f62004b"/>
							<gml:surfaceMember xlink:href="#Poly_33f1665f-c7a3-42ec-9ef0-3be41e4b0fd1"/>
							<gml:surfaceMember xlink:href="#Poly_0faf7312-5760-4acd-b770-cf605a1eb66c"/>
							<gml:surfaceMember xlink:href="#Poly_7fa0d230-f9da-4de8-b09a-55794a37d8e4"/>
							<gml:surfaceMember xlink:href="#Poly_71461a5a-0f61-4bdb-be4e-45a2f578f91d"/>
							<gml:surfaceMember xlink:href="#Poly_3cd37034-53e7-4bbe-bab2-39f83baea617"/>
							<gml:surfaceMember xlink:href="#Poly_58d71711-c531-41cf-9018-a0405d071b36"/>
							<gml:surfaceMember xlink:href="#Poly_4ff6fe66-368c-4dae-86f7-e6a930a16eee"/>
							<gml:surfaceMember xlink:href="#Poly_ced2daf1-bbde-440e-8953-c1ee10af57ca"/>
							<gml:surfaceMember xlink:href="#Poly_d0956ab7-3aca-4b4f-8206-621b9a2d7a75"/>
							<gml:surfaceMember xlink:href="#Poly_bbcec3ab-d11c-4684-905e-148fcf192eff"/>
							<gml:surfaceMember xlink:href="#Poly_bab33dfc-1b55-47f1-9da4-6f5763d1ddf5"/>
							<gml:surfaceMember xlink:href="#Poly_41cf6616-1174-48e2-88c2-2764bacecb64"/>
							<gml:surfaceMember xlink:href="#Poly_cdff257a-9542-42ee-9afb-7687885da20d"/>
							<gml:surfaceMember xlink:href="#Poly_e26b6cec-f205-446a-8a95-8dd0f504c697"/>
							<gml:surfaceMember xlink:href="#Poly_ffc2b0aa-3fc1-4903-b13f-ccfd2bcd345f"/>
							<gml:surfaceMember xlink:href="#Poly_1104c540-f53b-4c22-b3aa-221585a96d6d"/>
							<gml:surfaceMember xlink:href="#Poly_6d198c00-3e14-4dd7-9e5f-e5ee22f56ac6"/>
							<gml:surfaceMember xlink:href="#Poly_cc2f1aaa-ce7b-4db4-8ae8-483f154af411"/>
							<gml:surfaceMember xlink:href="#Poly_eb072629-baf9-436e-861a-43714a5c7074"/>
							<gml:surfaceMember xlink:href="#Poly_117af173-f9d3-4df4-9f9d-1f8bbb767fb0"/>
							<gml:surfaceMember xlink:href="#Poly_1e85d81d-c596-4530-acf6-5857a4631ca2"/>
							<gml:surfaceMember xlink:href="#Poly_20a76f82-3f80-41d7-96d2-360017ecc4be"/>
							<gml:surfaceMember xlink:href="#Poly_04748b8c-faa7-45ec-85d0-87c09744e8ce"/>
							<gml:surfaceMember xlink:href="#Poly_4589e25a-70fa-41ce-94b4-1295e67f7be6"/>
							<gml:surfaceMember xlink:href="#Poly_c60d04a3-1aa3-4a1b-b917-b0c8a8a358fe"/>
							<gml:surfaceMember xlink:href="#Poly_6acaa125-a4d3-455a-b81e-ee20ef01f7b5"/>
							<gml:surfaceMember xlink:href="#Poly_26b7718f-eff6-4a1d-b47c-80d1b8bf5e4c"/>
							<gml:surfaceMember xlink:href="#Poly_27bd4f3c-368f-41f8-ad22-b0bd22b5c78d"/>
							<gml:surfaceMember xlink:href="#Poly_4196916b-ec73-4944-8cf7-e378a3f6634a"/>
							<gml:surfaceMember xlink:href="#Poly_27aa3536-742f-4013-b573-22ad6993fb2c"/>
							<gml:surfaceMember xlink:href="#Poly_02b1170d-ff72-41a3-8416-fd93d3a92711"/>
							<gml:surfaceMember xlink:href="#Poly_6b665cd9-391c-4486-b68d-64f81c29d21d"/>
							<gml:surfaceMember xlink:href="#Poly_249ea9ac-5f21-442d-8f0a-e8f5fdc8bd0f"/>
							<gml:surfaceMember xlink:href="#Poly_4447abd4-7ba2-496a-b312-bb9be97f420b"/>
							<gml:surfaceMember xlink:href="#Poly_e3c712b9-813c-48d2-83aa-03eef487dd67"/>
							<gml:surfaceMember xlink:href="#Poly_334e7c1b-bbbb-4ad3-860e-2ef48c56c8ac"/>
							<gml:surfaceMember xlink:href="#Poly_b8c3559f-7429-4765-aec8-b41d4b718728"/>
							<gml:surfaceMember xlink:href="#Poly_1edd78fa-3bd3-41f1-97e6-e6dc276eed7b"/>
							<gml:surfaceMember xlink:href="#Poly_8786edbd-f323-47da-a0e2-ba0975c59c00"/>
							<gml:surfaceMember xlink:href="#Poly_4eaeee1b-bea5-4d35-8d15-de7ca135bec6"/>
							<gml:surfaceMember xlink:href="#Poly_bc30abba-018f-44a1-ae1c-ec9082fe3bf1"/>
							<gml:surfaceMember xlink:href="#Poly_4c736e8a-dbb0-4d9e-86c8-73ac833996fc"/>
							<gml:surfaceMember xlink:href="#Poly_9b8035dd-122d-4cb2-a0f8-dda76d75a112"/>
							<gml:surfaceMember xlink:href="#Poly_beafbc85-b5d3-4aa3-be9b-2db88bb95fa1"/>
							<gml:surfaceMember xlink:href="#Poly_f10c38d4-78f0-4e8b-8177-7b079a7e9a07"/>
							<gml:surfaceMember xlink:href="#Poly_ef5ad4c3-dee8-440a-827e-7ad84d8a8b6e"/>
							<gml:surfaceMember xlink:href="#Poly_f2b8dbf8-f6c8-4192-9e60-6914386afb75"/>
							<gml:surfaceMember xlink:href="#Poly_2cf72563-b678-4b6c-829f-acb9b78cc50a"/>
							<gml:surfaceMember xlink:href="#Poly_3d6acbaf-a309-43f4-bb28-b6ac4337c570"/>
							<gml:surfaceMember xlink:href="#Poly_6a56a653-df6b-4e26-bb12-ddf92e65048f"/>
							<gml:surfaceMember xlink:href="#Poly_3f012ca5-e87f-4953-a06f-e202c91158c2"/>
							<gml:surfaceMember xlink:href="#Poly_76df5a6c-feb0-4cb5-b0b2-01af36623c40"/>
							<gml:surfaceMember xlink:href="#Poly_86d5a8dc-5d66-49e7-828c-8ad0925554e7"/>
							<gml:surfaceMember xlink:href="#Poly_48ccbf2e-e8a6-4f1a-8fc7-4fbb60bc572a"/>
							<gml:surfaceMember xlink:href="#Poly_3c579667-1bb3-438c-9bae-9e9b4c043fac"/>
							<gml:surfaceMember xlink:href="#Poly_9b48649b-9c7f-49eb-b942-f3e373f6ebc0"/>
							<gml:surfaceMember xlink:href="#Poly_894d1e72-24f7-4146-b3a5-87fa62f0f387"/>
							<gml:surfaceMember xlink:href="#Poly_2ea587dd-aea8-4de1-b471-70b604da727b"/>
							<gml:surfaceMember xlink:href="#Poly_1d0a2762-0198-450b-b291-7f2d60ed441c"/>
							<gml:surfaceMember xlink:href="#Poly_5a8319ce-c6aa-4ee4-8648-5d29826baa6a"/>
							<gml:surfaceMember xlink:href="#Poly_63a969de-84bf-4ea1-9bfe-415caa1af518"/>
							<gml:surfaceMember xlink:href="#Poly_e5ba89db-57cc-4d73-a49f-41f2af331b82"/>
							<gml:surfaceMember xlink:href="#Poly_5278ea71-f249-4df7-87e5-8cef02ff9625"/>
							<gml:surfaceMember xlink:href="#Poly_f4443571-71cc-4eed-82bc-a74574bd0351"/>
							<gml:surfaceMember xlink:href="#Poly_af810e82-e714-45a2-aa67-5e45850b7f76"/>
							<gml:surfaceMember xlink:href="#Poly_c4fccfeb-2248-4070-9641-7573dc6ecf93"/>
							<gml:surfaceMember xlink:href="#Poly_0ee9d95b-72b1-4244-a060-9671bc89e35e"/>
							<gml:surfaceMember xlink:href="#Poly_724efebf-137f-457a-b623-7485ccb943ae"/>
							<gml:surfaceMember xlink:href="#Poly_b3ef79e3-c217-41ae-bbd5-8715587d190c"/>
							<gml:surfaceMember xlink:href="#Poly_451f2c5c-ba5a-4b46-a2cb-66615146fdc3"/>
							<gml:surfaceMember xlink:href="#Poly_3d5fd487-a150-4fad-a2dd-4a65a0a8882c"/>
							<gml:surfaceMember xlink:href="#Poly_28ca69eb-fd0a-47c9-949c-931e33b3944f"/>
							<gml:surfaceMember xlink:href="#Poly_294748e8-468f-492b-9506-8e831bdc4744"/>
							<gml:surfaceMember xlink:href="#Poly_48d52f1a-0753-46c9-a925-49ef9f93f289"/>
							<gml:surfaceMember xlink:href="#Poly_f6242d0c-56a7-4b29-9be3-6cda3c22f20c"/>
							<gml:surfaceMember xlink:href="#Poly_05453d9d-0a33-42fe-8c9f-f4669e4650d4"/>
							<gml:surfaceMember xlink:href="#Poly_4756da64-a615-4e5b-a88d-4bbb8a79cf04"/>
							<gml:surfaceMember xlink:href="#Poly_49169abf-dea0-4708-bb78-3f359e9270be"/>
							<gml:surfaceMember xlink:href="#Poly_6720e603-14cb-4b50-93c2-a102d8b56a8c"/>
							<gml:surfaceMember xlink:href="#Poly_42a14d54-b9c4-4928-b76b-9c1621f4996b"/>
							<gml:surfaceMember xlink:href="#Poly_78d4e32e-4ce7-4a96-8c1f-7af82b7fc91f"/>
							<gml:surfaceMember xlink:href="#Poly_377dba5c-c3d1-4780-a80e-9f09efbd1cbc"/>
							<gml:surfaceMember xlink:href="#Poly_5a093fd3-aeda-422d-ba21-a52b5798b559"/>
							<gml:surfaceMember xlink:href="#Poly_c604bbe3-e3fd-4bd0-b941-1c7343772b6f"/>
							<gml:surfaceMember xlink:href="#Poly_fbfeac40-d898-421a-a865-cb4a99755bde"/>
							<gml:surfaceMember xlink:href="#Poly_16dba55e-48a7-4872-9ead-693dd8c8827b"/>
							<gml:surfaceMember xlink:href="#Poly_be0aa18a-09f7-447e-8c49-3c3159e86113"/>
							<gml:surfaceMember xlink:href="#Poly_895ae905-0d96-48e9-b898-c6d7f4aa66e4"/>
							<gml:surfaceMember xlink:href="#Poly_d7d04d63-3535-4c82-b324-56e797fce62f"/>
							<gml:surfaceMember xlink:href="#Poly_716fdaa5-26c5-41fb-a599-3ca8eb81f47d"/>
							<gml:surfaceMember xlink:href="#Poly_208efd56-c484-49d9-8edc-14e79701d7fb"/>
							<gml:surfaceMember xlink:href="#Poly_1283e6fb-8b17-4040-a639-8188fd0e40b4"/>
							<gml:surfaceMember xlink:href="#Poly_04949cc0-2d0a-499a-b29c-d7435a251d37"/>
							<gml:surfaceMember xlink:href="#Poly_533fb80a-f0ec-4df7-a5d8-eb5544f1c250"/>
							<gml:surfaceMember xlink:href="#Poly_d92e6410-2378-4eae-a94c-07f3824d3312"/>
							<gml:surfaceMember xlink:href="#Poly_30140a5b-2d55-42db-bbea-c9caae290119"/>
							<gml:surfaceMember xlink:href="#Poly_cd82b745-8ffa-4f70-b675-7d5314e00595"/>
							<gml:surfaceMember xlink:href="#Poly_dde91c9c-b9d0-4892-ba0f-e11153726646"/>
							<gml:surfaceMember xlink:href="#Poly_c0a8b37c-86cd-4eb8-ac09-6c3a68ca5419"/>
							<gml:surfaceMember xlink:href="#Poly_ea4a348e-95f4-41c9-b3db-eb0d5f5f77ab"/>
							<gml:surfaceMember xlink:href="#Poly_cc5fa612-4818-4db5-900f-8bcd2efac76b"/>
							<gml:surfaceMember xlink:href="#Poly_de94d3a8-5484-4f79-921a-a94bbe295774"/>
							<gml:surfaceMember xlink:href="#Poly_3e90511c-db9f-45f3-bdb3-f55d9ccce3a3"/>
							<gml:surfaceMember xlink:href="#Poly_fc02080a-ed3d-4b56-be3a-108eeaa2f1aa"/>
							<gml:surfaceMember xlink:href="#Poly_2518cef0-2213-4e1a-8d2f-ae72bd838f92"/>
							<gml:surfaceMember xlink:href="#Poly_f8122d54-0f98-47dc-b394-451c3dd84065"/>
							<gml:surfaceMember xlink:href="#Poly_8517faf5-e9f4-4ec6-bcd5-8f1128264458"/>
							<gml:surfaceMember xlink:href="#Poly_a2bc791c-670c-480d-bdc2-aaf3d8a59324"/>
							<gml:surfaceMember xlink:href="#Poly_3e73373b-f5c1-4d06-8bd7-507b04210a88"/>
							<gml:surfaceMember xlink:href="#Poly_d3260153-3b90-4a54-a4e8-3fcac24e16ec"/>
							<gml:surfaceMember xlink:href="#Poly_dc25b658-8b7e-4444-a4e3-6ec871b0b08b"/>
							<gml:surfaceMember xlink:href="#Poly_55aba0b2-4eaf-42ed-9124-7cf14c694924"/>
							<gml:surfaceMember xlink:href="#Poly_24e14c63-43bc-401c-a6f3-3668a35ebee1"/>
							<gml:surfaceMember xlink:href="#Poly_6259db80-dcaf-49bc-a2dd-f88357d16ff0"/>
							<gml:surfaceMember xlink:href="#Poly_628f1201-b88f-4140-b34e-feb9acbda43d"/>
							<gml:surfaceMember xlink:href="#Poly_69f23e22-b9fc-4aad-97ef-9a5e968c0901"/>
							<gml:surfaceMember xlink:href="#Poly_fa8a5647-e584-4964-8e56-4a85e0342364"/>
							<gml:surfaceMember xlink:href="#Poly_6887e9c9-233f-4c7f-b943-5694f4a7aa18"/>
							<gml:surfaceMember xlink:href="#Poly_a344362d-5cf1-4dfe-abe1-ea8f49079de7"/>
							<gml:surfaceMember xlink:href="#Poly_97acd5a8-54dd-4122-9982-e8ddbdfed553"/>
							<gml:surfaceMember xlink:href="#Poly_38d88dd5-2c7c-423b-9fb2-88dd3c7678b0"/>
							<gml:surfaceMember xlink:href="#Poly_1d652d60-2858-42b1-854c-883c12cbefc3"/>
							<gml:surfaceMember xlink:href="#Poly_6dbb14e1-844e-4a96-a3f0-cce8e2d20b50"/>
							<gml:surfaceMember xlink:href="#Poly_3883d803-b922-413f-978a-f9fc9ab10f45"/>
							<gml:surfaceMember xlink:href="#Poly_6160d69f-4d6b-47a7-b9e8-cc69081b5a7b"/>
							<gml:surfaceMember xlink:href="#Poly_3f6a6a81-289a-4db2-a2cc-9ac9b9f1a1d3"/>
							<gml:surfaceMember xlink:href="#Poly_2236ec83-7363-4aa8-bb3a-679bf1e48244"/>
							<gml:surfaceMember xlink:href="#Poly_09ba7114-e7e6-4828-acf5-cb41ffbe06f4"/>
							<gml:surfaceMember xlink:href="#Poly_bdce7778-709f-4f4a-bc31-fbb6a4d51856"/>
							<gml:surfaceMember xlink:href="#Poly_6c3dbfea-2b5e-4884-905e-728575dfb10e"/>
							<gml:surfaceMember xlink:href="#Poly_246e25d8-3696-4686-b99b-1ace29368a60"/>
							<gml:surfaceMember xlink:href="#Poly_5d09bc23-9972-4ecf-9e3d-d0e52887e4f3"/>
							<gml:surfaceMember xlink:href="#Poly_fa778dea-032e-4949-b99d-21e51fbf2fca"/>
							<gml:surfaceMember xlink:href="#Poly_cfcff56d-369f-4af8-a0cb-708588307e1a"/>
							<gml:surfaceMember xlink:href="#Poly_77579675-f78f-46e1-8e46-f9cc738e8152"/>
							<gml:surfaceMember xlink:href="#Poly_8dc37050-30d5-4d30-99e8-9b7a21d4d9ec"/>
							<gml:surfaceMember xlink:href="#Poly_958a9119-13cf-4a7e-a096-560d0a15cefb"/>
							<gml:surfaceMember xlink:href="#Poly_79053e95-a963-473a-8e40-87eccf25e772"/>
							<gml:surfaceMember xlink:href="#Poly_ea86243a-dcd3-4a66-941f-e927f6d0a527"/>
							<gml:surfaceMember xlink:href="#Poly_833a1b67-c4e6-4e40-96cc-00260801acb6"/>
							<gml:surfaceMember xlink:href="#Poly_81872c99-b3d0-4f24-be67-21c9f7870018"/>
							<gml:surfaceMember xlink:href="#Poly_b87a0197-8f56-4738-b0b1-cabf56a00a07"/>
							<gml:surfaceMember xlink:href="#Poly_d020818b-3171-4883-924b-246efc1b9810"/>
							<gml:surfaceMember xlink:href="#Poly_452b3bd4-58c9-44e2-b7cc-3b8da7d2f604"/>
							<gml:surfaceMember xlink:href="#Poly_dd5fe82d-787e-4c2a-bc99-66afcc664578"/>
							<gml:surfaceMember xlink:href="#Poly_05505ddb-1e77-4f2e-8fc8-54264272379a"/>
							<gml:surfaceMember xlink:href="#Poly_d2b57f17-43a0-4da0-ac19-20bcfaead401"/>
							<gml:surfaceMember xlink:href="#Poly_6da32309-2ac0-40b9-b7bd-f20ab3262eed"/>
							<gml:surfaceMember xlink:href="#Poly_51735ebd-d24e-4bba-9f20-b1db12559733"/>
							<gml:surfaceMember xlink:href="#Poly_85f16b80-05d7-4df4-b11d-10fe68814041"/>
							<gml:surfaceMember xlink:href="#Poly_a1d8f2bf-0b17-4152-a9a1-b1398cff474c"/>
							<gml:surfaceMember xlink:href="#Poly_36241fc6-303b-43c8-a155-67c28d934fe1"/>
							<gml:surfaceMember xlink:href="#Poly_e3951c26-9bd2-4fcd-9ce7-e18dd9e37429"/>
							<gml:surfaceMember xlink:href="#Poly_4a72a286-546e-4fc1-80dc-63984a291aea"/>
							<gml:surfaceMember xlink:href="#Poly_7dc28179-2f53-4576-b05e-529c2d7c4329"/>
							<gml:surfaceMember xlink:href="#Poly_d0e09328-5d84-4417-a47b-b72149958560"/>
							<gml:surfaceMember xlink:href="#Poly_28d36821-c607-432e-9065-eb27d448ba4b"/>
							<gml:surfaceMember xlink:href="#Poly_637178c0-101d-4073-9af7-42ff57bafa7d"/>
							<gml:surfaceMember xlink:href="#Poly_d2a9431e-c186-4151-96ba-2e8d6e23c1f6"/>
							<gml:surfaceMember xlink:href="#Poly_72c77a7a-695d-4c04-bfc0-c520139502b5"/>
							<gml:surfaceMember xlink:href="#Poly_7eaf44a5-6cca-4b35-ad50-e6954e985293"/>
							<gml:surfaceMember xlink:href="#Poly_17795ea4-d90f-4965-b509-e1b623aea41d"/>
							<gml:surfaceMember xlink:href="#Poly_4aac7d52-ec87-49ca-bb9b-2b8c25e65be4"/>
							<gml:surfaceMember xlink:href="#Poly_58a294ad-8160-41ae-bac2-965046e1dfc2"/>
							<gml:surfaceMember xlink:href="#Poly_b04b0d34-e95b-4f02-b2bb-995f547676ba"/>
							<gml:surfaceMember xlink:href="#Poly_08957525-d336-4eb1-9868-bd00ab5a6859"/>
							<gml:surfaceMember xlink:href="#Poly_ecf89da1-813c-47c0-82cf-3bb3a2b59f43"/>
							<gml:surfaceMember xlink:href="#Poly_bd3bb072-fc5c-4bfa-a719-de2f852b005e"/>
							<gml:surfaceMember xlink:href="#Poly_5960a201-e855-4fcf-80fd-8f24843a24c0"/>
							<gml:surfaceMember xlink:href="#Poly_fb123214-88fa-4b23-a376-22cf706c9d63"/>
							<gml:surfaceMember xlink:href="#Poly_32a74aaf-8655-4027-ac63-c67e6acbbf3a"/>
							<gml:surfaceMember xlink:href="#Poly_35a01d02-34d9-4f22-aafc-0c03d8c58968"/>
							<gml:surfaceMember xlink:href="#Poly_b7dd23c4-47d7-4fc3-8653-4c2313742643"/>
							<gml:surfaceMember xlink:href="#Poly_8ca56963-1905-4aa5-a95a-cf20c6274c02"/>
							<gml:surfaceMember xlink:href="#Poly_d21daa44-72d6-4f1c-88e8-90c3b0f021c7"/>
							<gml:surfaceMember xlink:href="#Poly_43b703b9-7edb-4a8f-9aef-ce9a2f496f13"/>
							<gml:surfaceMember xlink:href="#Poly_7e4a6486-6ff2-46a9-826a-ee120c8c31b8"/>
							<gml:surfaceMember xlink:href="#Poly_ed7fb158-c600-4fd9-a210-1cbb00fce81f"/>
							<gml:surfaceMember xlink:href="#Poly_395619e7-dc0b-4f57-954a-5263d1891548"/>
							<gml:surfaceMember xlink:href="#Poly_af3ff5b1-5562-4eb1-be07-fb0dfd153def"/>
							<gml:surfaceMember xlink:href="#Poly_0fa7baff-7157-4e93-81a1-3de6c410b524"/>
							<gml:surfaceMember xlink:href="#Poly_c7bda2fe-a60e-45f2-abfc-de250c3c3ade"/>
							<gml:surfaceMember xlink:href="#Poly_3e57bf4b-0ef3-4ddc-a0e5-e35c5a11d4a9"/>
							<gml:surfaceMember xlink:href="#Poly_2bec265f-94e9-4867-95cb-a7668a44c870"/>
							<gml:surfaceMember xlink:href="#Poly_4d0ce2bb-4285-4cb1-81d7-14e36043ab6e"/>
							<gml:surfaceMember xlink:href="#Poly_66ecea9c-e06b-40df-8c65-373aba659ed5"/>
							<gml:surfaceMember xlink:href="#Poly_2ac6f68b-0e6c-4838-911b-b8ceb1fe414f"/>
							<gml:surfaceMember xlink:href="#Poly_74356478-ef41-4dfb-9189-eba6d8b91d05"/>
							<gml:surfaceMember xlink:href="#Poly_5cd6e3bc-1fe4-4256-90a8-cf0aaf3eacd9"/>
							<gml:surfaceMember xlink:href="#Poly_dad3dbd2-5883-4d38-9da2-57812bf05b5a"/>
							<gml:surfaceMember xlink:href="#Poly_04b99cc6-13a5-4c0e-9fe4-9ce72bd77492"/>
							<gml:surfaceMember xlink:href="#Poly_23349ea1-87ea-4ba6-b349-997db3e9c534"/>
							<gml:surfaceMember xlink:href="#Poly_9cdccf9a-ffde-4237-b242-c57515d773aa"/>
							<gml:surfaceMember xlink:href="#Poly_3234a539-cb99-47d5-9820-ca1de5037c99"/>
							<gml:surfaceMember xlink:href="#Poly_21ff5128-eba5-486b-acfc-b5ca3295abd4"/>
							<gml:surfaceMember xlink:href="#Poly_5d1e2fae-8639-4ed2-ae47-c29906c3da8f"/>
							<gml:surfaceMember xlink:href="#Poly_82c38696-cf54-4b79-b0c3-63cfac5226da"/>
							<gml:surfaceMember xlink:href="#Poly_47a47798-1d05-490c-a8f1-43dbf85e5c96"/>
							<gml:surfaceMember xlink:href="#Poly_aa260000-6303-46ae-a3e9-b05995b4ff0c"/>
							<gml:surfaceMember xlink:href="#Poly_e4572c8f-f0ce-499e-a9b1-a7e8d830fb6d"/>
							<gml:surfaceMember xlink:href="#Poly_c3e3a58e-30e6-4aef-bbad-cebd8d335d5f"/>
							<gml:surfaceMember xlink:href="#Poly_a5fd6138-18f4-4fdc-89df-ea49a5d6dad7"/>
							<gml:surfaceMember xlink:href="#Poly_699f4cce-959f-4f57-9e71-3789dfe93a43"/>
							<gml:surfaceMember xlink:href="#Poly_7cdbba5a-75ef-455f-8b04-e9d3170ad264"/>
							<gml:surfaceMember xlink:href="#Poly_0aa8a8ec-1836-4607-af45-e3579991ad5c"/>
							<gml:surfaceMember xlink:href="#Poly_663354ea-6752-46d4-83bb-182b074569b7"/>
							<gml:surfaceMember xlink:href="#Poly_403e4af4-a9a3-4856-8cb4-68f83315e0ce"/>
							<gml:surfaceMember xlink:href="#Poly_5c72a243-43ae-48d2-9e82-1ba9a4d0e777"/>
							<gml:surfaceMember xlink:href="#Poly_ccc8bc78-a78a-4dfc-9b55-54b3dd95bf99"/>
							<gml:surfaceMember xlink:href="#Poly_266ddcec-82ec-4b98-99a8-3a40c922d820"/>
							<gml:surfaceMember xlink:href="#Poly_9a329279-9f07-40d9-b2d9-0084c23e67e6"/>
							<gml:surfaceMember xlink:href="#Poly_84a89c0f-b667-4a77-8916-1135e829f135"/>
							<gml:surfaceMember xlink:href="#Poly_d48ea937-45f9-4883-b74c-7be372e8c73d"/>
							<gml:surfaceMember xlink:href="#Poly_5b359b6a-3fd1-4a22-a1b3-e0b7e9f80842"/>
							<gml:surfaceMember xlink:href="#Poly_4d3becdc-cd2f-463f-bb07-9bd0c15e99a4"/>
							<gml:surfaceMember xlink:href="#Poly_f72b3a0c-70a2-498f-9702-cc94a93c92c5"/>
							<gml:surfaceMember xlink:href="#Poly_e2ba9f34-1f41-47fd-94a1-fb6ac7a2ecda"/>
							<gml:surfaceMember xlink:href="#Poly_d496d28d-b0f2-4da4-950c-d6c9992a2f52"/>
							<gml:surfaceMember xlink:href="#Poly_c7ba5d3d-1e18-4723-a247-51a25cbffcc8"/>
							<gml:surfaceMember xlink:href="#Poly_40570fe5-8aae-4f3e-bc2e-956199591392"/>
							<gml:surfaceMember xlink:href="#Poly_5f06b91d-02d7-495b-8176-de69b08f1241"/>
							<gml:surfaceMember xlink:href="#Poly_4e14be00-ebf1-4849-86c2-2e3a732e4912"/>
							<gml:surfaceMember xlink:href="#Poly_25e99696-97d9-47f6-b70f-11b1af122892"/>
							<gml:surfaceMember xlink:href="#Poly_097d5322-c6df-4030-8379-f7ada001ddf2"/>
							<gml:surfaceMember xlink:href="#Poly_a04c94b8-3714-47d9-828c-15316c28f367"/>
							<gml:surfaceMember xlink:href="#Poly_6d0e4ff9-1519-49b0-9ab2-5e3d7a4d27dc"/>
							<gml:surfaceMember xlink:href="#Poly_e47df084-a537-48b4-a8d1-d2e619061e50"/>
							<gml:surfaceMember xlink:href="#Poly_3fc572ba-543c-4c3f-a3c1-e9d907947c03"/>
							<gml:surfaceMember xlink:href="#Poly_1e95e683-8256-4e4c-9c8a-fba6f16afbf0"/>
							<gml:surfaceMember xlink:href="#Poly_867b3ae6-02ad-498f-9b05-7c945e783ccd"/>
							<gml:surfaceMember xlink:href="#Poly_abaeb6fa-3af5-4201-bf06-fe44abbfb9f9"/>
							<gml:surfaceMember xlink:href="#Poly_68ef2673-07a4-4a1d-b4b5-894a2b548c3d"/>
							<gml:surfaceMember xlink:href="#Poly_9e0b255d-d27e-40c6-8e64-92f2e091184c"/>
							<gml:surfaceMember xlink:href="#Poly_3486c295-9a24-406b-aec3-b36b2a2498e5"/>
							<gml:surfaceMember xlink:href="#Poly_4dbf53bc-9395-41ad-b33e-d180743ce6e3"/>
							<gml:surfaceMember xlink:href="#Poly_df1657e0-5be1-4614-b4c8-07003020fb9e"/>
							<gml:surfaceMember xlink:href="#Poly_b534bf81-111c-4ee8-9226-46af72364b5d"/>
							<gml:surfaceMember xlink:href="#Poly_945f5b8b-e50c-4c3a-aa28-92ce05c4c83a"/>
							<gml:surfaceMember xlink:href="#Poly_7ee095d5-fee2-45ed-a939-5d202bbc87a5"/>
							<gml:surfaceMember xlink:href="#Poly_35d3bbe8-11d6-43df-8e41-b58d999aa5a7"/>
							<gml:surfaceMember xlink:href="#Poly_fc459366-769b-41c4-9103-f32d08ddd2fa"/>
							<gml:surfaceMember xlink:href="#Poly_0de5b79b-f988-4832-84a2-f494d5ed4100"/>
							<gml:surfaceMember xlink:href="#Poly_d3043f56-e7ed-4fe6-b04a-4172dc1f11c2"/>
							<gml:surfaceMember xlink:href="#Poly_549eb043-5415-4222-a03f-79b7ba639c3b"/>
							<gml:surfaceMember xlink:href="#Poly_cf9a0f80-66a1-4bf6-9a16-8779789b5095"/>
							<gml:surfaceMember xlink:href="#Poly_cbf62b1f-d7e2-49a7-8841-3620d95bd526"/>
							<gml:surfaceMember xlink:href="#Poly_cad382a8-c44c-4a03-9c59-826b36c0e2bd"/>
							<gml:surfaceMember xlink:href="#Poly_02bf2e75-eec3-458c-8488-65af7735f086"/>
							<gml:surfaceMember xlink:href="#Poly_3641a89f-7a20-47ee-8a27-d7b03f878156"/>
							<gml:surfaceMember xlink:href="#Poly_bd2a5007-1d84-43c1-90c6-a59de8700c75"/>
							<gml:surfaceMember xlink:href="#Poly_4f8710e7-148e-47c6-8dcc-b5d4e6d6bbba"/>
							<gml:surfaceMember xlink:href="#Poly_94011616-be56-4e5f-baf2-b14412482c03"/>
							<gml:surfaceMember xlink:href="#Poly_1e81d89b-47fa-4363-8996-841d030a4308"/>
							<gml:surfaceMember xlink:href="#Poly_7e5dc3c2-ce7a-42d4-8875-f98dffdde870"/>
							<gml:surfaceMember xlink:href="#Poly_1d05a1a7-bfda-4189-85c6-1e319eee8779"/>
							<gml:surfaceMember xlink:href="#Poly_7a7aea22-368e-48bc-a787-83f029207ed9"/>
							<gml:surfaceMember xlink:href="#Poly_ac814b3f-1905-41db-95eb-1b3151de6dd3"/>
							<gml:surfaceMember xlink:href="#Poly_6669678b-d455-476f-ad8a-615227590fff"/>
							<gml:surfaceMember xlink:href="#Poly_a0c96f8c-a058-42b5-987a-39e35d4c6ca1"/>
							<gml:surfaceMember xlink:href="#Poly_1b5ddd9f-e4ce-4c4c-807b-7d25197f4985"/>
							<gml:surfaceMember xlink:href="#Poly_979a9feb-6cc7-40b9-a133-0ee556155994"/>
							<gml:surfaceMember xlink:href="#Poly_af39f1d8-2fbd-40ee-be2a-0d2abb383407"/>
							<gml:surfaceMember xlink:href="#Poly_4d447cc7-62d5-4deb-8d14-44cbf187a498"/>
							<gml:surfaceMember xlink:href="#Poly_e0ab2cc1-025a-46aa-a00d-8ad4a7a12788"/>
							<gml:surfaceMember xlink:href="#Poly_84c81901-f919-4186-b146-46d5c25270cc"/>
							<gml:surfaceMember xlink:href="#Poly_90c680f2-b579-4525-8546-ee0d19d270aa"/>
							<gml:surfaceMember xlink:href="#Poly_dee4f58c-14d8-4724-a0fd-1ca29e65bfa5"/>
							<gml:surfaceMember xlink:href="#Poly_60f3b826-ebde-4838-bacb-3ae9653fb1e0"/>
							<gml:surfaceMember xlink:href="#Poly_862808ca-a277-4a2a-9c62-b5eddbaeef2e"/>
							<gml:surfaceMember xlink:href="#Poly_639da54f-9559-4ba5-9a00-e2cd19393680"/>
							<gml:surfaceMember xlink:href="#Poly_944c0488-a768-4518-98ad-4b1171001da2"/>
							<gml:surfaceMember xlink:href="#Poly_5400c6f2-522e-402e-9403-2d491cfcd880"/>
							<gml:surfaceMember xlink:href="#Poly_8f4f1e64-40d8-42d6-9476-3e87bc4c8acb"/>
							<gml:surfaceMember xlink:href="#Poly_2b1e628f-7af5-436d-9dff-d691379bb146"/>
							<gml:surfaceMember xlink:href="#Poly_94eb6c46-9352-4a88-897e-23fc47e0e44f"/>
							<gml:surfaceMember xlink:href="#Poly_6c1e4e61-39dd-421e-82a3-a53b011cbfbc"/>
							<gml:surfaceMember xlink:href="#Poly_574806cf-e2e2-41ba-96aa-40f8d3deabbf"/>
							<gml:surfaceMember xlink:href="#Poly_af7d61c8-2607-4dc9-8855-d755f235fd54"/>
							<gml:surfaceMember xlink:href="#Poly_f5b0b5c1-32fe-48a7-aaa2-687dbf2362e8"/>
							<gml:surfaceMember xlink:href="#Poly_6fc75c3a-105e-4098-b4e3-4bd7f6b9c3a6"/>
							<gml:surfaceMember xlink:href="#Poly_e663bbc6-9340-4856-ad23-763118e6cf09"/>
							<gml:surfaceMember xlink:href="#Poly_71054ebc-f1a0-4fe2-8f0c-42e126a1f563"/>
							<gml:surfaceMember xlink:href="#Poly_25551357-2461-4d8c-ba5b-b5db26a3df04"/>
							<gml:surfaceMember xlink:href="#Poly_e28bcdfc-9366-4d9f-ae2a-c1f8b91a4f15"/>
							<gml:surfaceMember xlink:href="#Poly_70a31072-1e99-4761-accc-880075686f77"/>
							<gml:surfaceMember xlink:href="#Poly_ee098b8c-4861-4a6c-b57a-94cb44a0126e"/>
							<gml:surfaceMember xlink:href="#Poly_83ff0009-2932-40b7-a53e-4664def1b595"/>
							<gml:surfaceMember xlink:href="#Poly_057d5127-0d47-4771-be96-81e3cdc4d1fb"/>
							<gml:surfaceMember xlink:href="#Poly_abc97ddd-6e30-4e84-a723-307785fddb60"/>
							<gml:surfaceMember xlink:href="#Poly_1f49c4f4-19e4-4865-b6d8-0df80d27ebd2"/>
							<gml:surfaceMember xlink:href="#Poly_d5ff1e2e-bbce-4d95-a8ad-817e48148b4d"/>
							<gml:surfaceMember xlink:href="#Poly_a289ff84-7021-4090-b191-011224fdfee0"/>
							<gml:surfaceMember xlink:href="#Poly_beb09dd7-6bf0-4019-b6e4-a634a1ef709c"/>
							<gml:surfaceMember xlink:href="#Poly_4fe63fa6-146d-4349-9e19-4e4916b06538"/>
							<gml:surfaceMember xlink:href="#Poly_d7b08645-010d-4919-a530-2e2022aed1aa"/>
							<gml:surfaceMember xlink:href="#Poly_243b7682-6d3b-4440-99ed-1f15343574ea"/>
							<gml:surfaceMember xlink:href="#Poly_008e28e9-f890-4dce-96cb-03e864b01ebc"/>
							<gml:surfaceMember xlink:href="#Poly_ab8ed70d-59e1-4b54-ace5-c5d5d536b905"/>
							<gml:surfaceMember xlink:href="#Poly_f9e10d31-76b9-40d7-b8fc-36482b3a32e4"/>
							<gml:surfaceMember xlink:href="#Poly_b594ec47-c99b-4a24-8d19-d2b62788d82f"/>
							<gml:surfaceMember xlink:href="#Poly_22600d32-d270-4f48-9ee3-8e7517508593"/>
							<gml:surfaceMember xlink:href="#Poly_49a5a4d4-a224-45ff-aed6-d5362ffdb413"/>
							<gml:surfaceMember xlink:href="#Poly_4ab14f34-3ac4-4802-8fb9-a46454530de8"/>
							<gml:surfaceMember xlink:href="#Poly_6401c391-45b1-46cd-9ff3-22dd6fc745b1"/>
							<gml:surfaceMember xlink:href="#Poly_b89a3eff-22a0-44ad-a2f3-99fcaca42faa"/>
							<gml:surfaceMember xlink:href="#Poly_f06f77b0-2a22-41c9-9275-3bad6b20b9d8"/>
							<gml:surfaceMember xlink:href="#Poly_f3f4bc27-f60b-4980-992a-c5c933e8a9f6"/>
							<gml:surfaceMember xlink:href="#Poly_bae12683-f790-419e-adf4-ca27e12e5e3e"/>
							<gml:surfaceMember xlink:href="#Poly_6649ec54-1e0d-4269-a03f-c7a56e68bfb2"/>
							<gml:surfaceMember xlink:href="#Poly_fbf6a8c5-3784-4ae9-aedb-14f6080436a4"/>
							<gml:surfaceMember xlink:href="#Poly_7e5b065a-ade8-4bee-a8d6-b9b1aa1a3164"/>
							<gml:surfaceMember xlink:href="#Poly_92e9097a-3044-43dc-a7c2-6df6cef0d079"/>
							<gml:surfaceMember xlink:href="#Poly_f4e552d1-dad1-4ef5-8667-e60ec22e8d2f"/>
							<gml:surfaceMember xlink:href="#Poly_48d2fc73-9029-4745-8f65-06d7aea26670"/>
							<gml:surfaceMember xlink:href="#Poly_bb2995df-0991-4275-aea0-2704e32a45fb"/>
							<gml:surfaceMember xlink:href="#Poly_7e364b93-3068-47cb-9f0f-0ddf54dad333"/>
							<gml:surfaceMember xlink:href="#Poly_d296a6a7-4a25-45bc-a2a8-e408552d6799"/>
							<gml:surfaceMember xlink:href="#Poly_d2b8a478-2d79-4ce7-b26d-75afaff18796"/>
							<gml:surfaceMember xlink:href="#Poly_4322285b-f5ae-4040-9ff4-e432b1294668"/>
							<gml:surfaceMember xlink:href="#Poly_4b7385be-e718-429d-8186-af379e94e22a"/>
							<gml:surfaceMember xlink:href="#Poly_c6096fab-c21c-4fb3-b80d-34efde1e6bdf"/>
							<gml:surfaceMember xlink:href="#Poly_b4caffca-369a-4e64-a51b-299f2955e759"/>
							<gml:surfaceMember xlink:href="#Poly_94c314a0-5a3b-4be8-83a4-a21f9baf4551"/>
							<gml:surfaceMember xlink:href="#Poly_bd8528e7-5ecf-4973-b3d9-22241c27054c"/>
							<gml:surfaceMember xlink:href="#Poly_988c86d5-e029-4446-9ac1-f777fe856aca"/>
							<gml:surfaceMember xlink:href="#Poly_08ea70a8-e1d9-4f4a-8f0a-aec767ba8019"/>
							<gml:surfaceMember xlink:href="#Poly_66f104ca-2f79-4d63-99a3-cb23f44b3f92"/>
							<gml:surfaceMember xlink:href="#Poly_8a186083-8e95-45c3-beba-749433fc81ec"/>
							<gml:surfaceMember xlink:href="#Poly_19a275a1-2825-4319-9ed0-e47a04225d2f"/>
							<gml:surfaceMember xlink:href="#Poly_febde3e2-8303-4a9b-9030-84c819b40418"/>
							<gml:surfaceMember xlink:href="#Poly_e002f6e3-bac3-4663-b60d-60c559be2bc6"/>
							<gml:surfaceMember xlink:href="#Poly_1bb18f18-df9c-47cc-bbf4-93fe58b442d5"/>
							<gml:surfaceMember xlink:href="#Poly_95833627-d82e-49d3-b287-fa6382790175"/>
							<gml:surfaceMember xlink:href="#Poly_a0ad0672-9b03-4d94-bb4f-b0449a59a3a0"/>
							<gml:surfaceMember xlink:href="#Poly_5dac9e16-47e0-40a1-a21a-b68feb2e1e22"/>
							<gml:surfaceMember xlink:href="#Poly_2ebf7918-f7e5-4e31-acfe-477d6c832d9f"/>
							<gml:surfaceMember xlink:href="#Poly_fb495888-e147-4125-8506-cede03ec75a4"/>
							<gml:surfaceMember xlink:href="#Poly_09923c84-59a5-44cf-945e-3db80f98ab30"/>
							<gml:surfaceMember xlink:href="#Poly_fc962a9f-25c0-47f3-95d2-ce655b3c851a"/>
							<gml:surfaceMember xlink:href="#Poly_f53a015e-4129-408a-bb50-8be6076b038f"/>
							<gml:surfaceMember xlink:href="#Poly_90626f5a-6f57-456c-b1b8-445dd22d7f47"/>
							<gml:surfaceMember xlink:href="#Poly_1271fdfe-56f7-4a70-b3f8-1baf3fa563fa"/>
							<gml:surfaceMember xlink:href="#Poly_305c4152-7bd3-4c4e-86bd-cabc36f31e4d"/>
							<gml:surfaceMember xlink:href="#Poly_1d30836d-4e67-4829-b5d1-8e87585ddadb"/>
							<gml:surfaceMember xlink:href="#Poly_17ff2a6e-4125-4152-98a7-2b06a341c3fd"/>
							<gml:surfaceMember xlink:href="#Poly_3005aa84-6c95-4ac8-b5c0-b0061fde9e25"/>
							<gml:surfaceMember xlink:href="#Poly_c0dc9f8b-90cb-41a2-9e0a-cc5be04e6659"/>
							<gml:surfaceMember xlink:href="#Poly_5254ea57-1884-43b4-a607-51632c3c6a91"/>
							<gml:surfaceMember xlink:href="#Poly_595ef26d-bdf3-4b3a-939f-087d56b3ee18"/>
							<gml:surfaceMember xlink:href="#Poly_98af2d16-280c-4510-84fd-71cc129287d9"/>
							<gml:surfaceMember xlink:href="#Poly_27fac7e5-6aa3-45f6-881e-2a49a2fb65d3"/>
							<gml:surfaceMember xlink:href="#Poly_9ffc5296-0ea7-4a81-9ae3-42c5aede1f51"/>
							<gml:surfaceMember xlink:href="#Poly_8d7f543b-a843-4dfa-bcbe-556d451f9e9a"/>
							<gml:surfaceMember xlink:href="#Poly_da0222ae-ef0d-4dbe-b79a-cb2265cd3bd6"/>
							<gml:surfaceMember xlink:href="#Poly_34005c76-5904-460d-9623-e35c343da270"/>
							<gml:surfaceMember xlink:href="#Poly_f17c21f5-a8d3-48b6-b8b5-92eae7011c8b"/>
							<gml:surfaceMember xlink:href="#Poly_8d526f45-5cdb-4772-8767-20b15de353ab"/>
							<gml:surfaceMember xlink:href="#Poly_5f84dc84-54e3-4d1c-8ffa-adb2330ae18a"/>
							<gml:surfaceMember xlink:href="#Poly_97101368-4db9-4a50-8bc0-7a4a08ceec6c"/>
							<gml:surfaceMember xlink:href="#Poly_b307da0f-d71e-465f-b077-da6539d2aa97"/>
							<gml:surfaceMember xlink:href="#Poly_8fe5a4ac-1dc2-4c2f-ad49-5043813ba338"/>
							<gml:surfaceMember xlink:href="#Poly_04542782-5e39-413e-bdee-16fe621fafcc"/>
							<gml:surfaceMember xlink:href="#Poly_ed266021-ef0b-4ca7-b774-b949cc0f684f"/>
							<gml:surfaceMember xlink:href="#Poly_3dfa1669-af54-472c-9ba1-4f218ad93045"/>
							<gml:surfaceMember xlink:href="#Poly_5aa9bc67-eca4-4111-8597-5144746b85a0"/>
							<gml:surfaceMember xlink:href="#Poly_959c5ffc-e1b5-479e-96f7-718007d22d0c"/>
							<gml:surfaceMember xlink:href="#Poly_095df9c4-436c-4f46-90bb-93487602c982"/>
							<gml:surfaceMember xlink:href="#Poly_d5dd2ea3-6ed9-4dbb-a3d6-977e863ff2e5"/>
							<gml:surfaceMember xlink:href="#Poly_9c69d1fc-b6b6-473e-97fb-e8e451085e7f"/>
							<gml:surfaceMember xlink:href="#Poly_feb04a7c-f2b6-4fa6-b758-ce77d9f9ef6c"/>
							<gml:surfaceMember xlink:href="#Poly_a896180f-5bda-4bf3-9241-285c94f2e7e4"/>
							<gml:surfaceMember xlink:href="#Poly_b760b6bc-e584-4d70-b131-b61d3c839b75"/>
							<gml:surfaceMember xlink:href="#Poly_32083abf-ccd6-4389-9cb1-ad62e8eb4e74"/>
							<gml:surfaceMember xlink:href="#Poly_e280851c-22c4-4c64-bd0e-da927fa0a173"/>
							<gml:surfaceMember xlink:href="#Poly_74000610-1cdd-495e-80c5-3fb09cdb576a"/>
							<gml:surfaceMember xlink:href="#Poly_370f1fa5-1d40-47a6-aaed-a6b0856a4995"/>
							<gml:surfaceMember xlink:href="#Poly_c415d248-63cb-4805-af45-514de9d460b5"/>
							<gml:surfaceMember xlink:href="#Poly_ef268533-fbe9-42a4-97bb-c4be6b7ff2ed"/>
							<gml:surfaceMember xlink:href="#Poly_8d099b69-e81d-4727-b19e-162277d185a7"/>
							<gml:surfaceMember xlink:href="#Poly_b61dcf08-84b4-4bc8-a5dc-3bd3fd9b582e"/>
							<gml:surfaceMember xlink:href="#Poly_8cd79f0b-d60c-4d3e-950e-0aeeec8737c4"/>
							<gml:surfaceMember xlink:href="#Poly_d44e02a5-0e25-403b-89b3-163958667783"/>
							<gml:surfaceMember xlink:href="#Poly_9f4e12e0-dd72-4dca-9380-abb4b412b667"/>
							<gml:surfaceMember xlink:href="#Poly_47dc1f50-980d-4919-a2c9-8d2fd341f523"/>
							<gml:surfaceMember xlink:href="#Poly_d96aadc5-e960-4ab4-ac93-4bce2c49e7b9"/>
							<gml:surfaceMember xlink:href="#Poly_3ee8f760-386f-45de-83d1-449d31deea2f"/>
							<gml:surfaceMember xlink:href="#Poly_1a71f249-e4f9-428f-85fb-d8cf3a27b109"/>
							<gml:surfaceMember xlink:href="#Poly_0a5957d1-cf31-450d-976f-e7f8e6237543"/>
							<gml:surfaceMember xlink:href="#Poly_477666fe-d10b-4b3e-902b-fe010fbf435c"/>
							<gml:surfaceMember xlink:href="#Poly_27a19c5b-f3da-4f06-ab6f-2cb014fe5c38"/>
							<gml:surfaceMember xlink:href="#Poly_92349b74-9bb1-4364-a1ef-d6232cbe0a32"/>
							<gml:surfaceMember xlink:href="#Poly_65ff7a07-3940-4303-955d-7f3c155f26c3"/>
							<gml:surfaceMember xlink:href="#Poly_ed3a0210-4309-49a5-9f49-47d4874f3bd5"/>
							<gml:surfaceMember xlink:href="#Poly_eb1f5ab6-9dcf-4092-8033-428d2cd8d868"/>
							<gml:surfaceMember xlink:href="#Poly_e09175c4-0a4d-4b59-8efc-94b40e3538bf"/>
							<gml:surfaceMember xlink:href="#Poly_7dc7c2a4-ab41-4a56-a801-8f527eea06e9"/>
							<gml:surfaceMember xlink:href="#Poly_30542a29-8cb8-4922-bb98-1988bb903569"/>
							<gml:surfaceMember xlink:href="#Poly_dbca2628-8714-4855-8639-8b4b670f2162"/>
							<gml:surfaceMember xlink:href="#Poly_be53fe9b-5b34-4289-b07d-b6f516997d19"/>
							<gml:surfaceMember xlink:href="#Poly_3b7502e4-19aa-460b-806a-2634234ae5e5"/>
							<gml:surfaceMember xlink:href="#Poly_b495e9e1-1265-41b4-94e7-5b74a2145aaf"/>
							<gml:surfaceMember xlink:href="#Poly_92bbd25d-666b-455c-aa95-92108d9486bf"/>
							<gml:surfaceMember xlink:href="#Poly_f8a16140-ce5b-4285-be78-68c51d31cda4"/>
							<gml:surfaceMember xlink:href="#Poly_10678df2-91f5-41bc-bc30-e45876fbc665"/>
							<gml:surfaceMember xlink:href="#Poly_b93e5e0b-d9fd-405c-b4fc-bb9aa8d6d33e"/>
							<gml:surfaceMember xlink:href="#Poly_6e029a58-5fe1-402d-b9f5-d94a5a7dee4e"/>
							<gml:surfaceMember xlink:href="#Poly_b409ed12-ed4c-4983-823c-cf208e1b4a10"/>
							<gml:surfaceMember xlink:href="#Poly_59a1bf7a-1ab9-4e7b-83e3-db05be2089e3"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod3Solid>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区虎ノ門二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">3</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">2</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">2</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.0</uro:lodType>
					<uro:lodType>3.0</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">254.38213</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">9</uro:districtsAndZonesType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1210</uro:detailedUsage>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.27</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-2406800000</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>