<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_d1208a40-cf6d-4cbc-9d6e-1dcaaacbc842">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>3</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001003</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">402</bldg:usage>
			<bldg:measuredHeight uom="m">20</bldg:measuredHeight>
			<bldg:storeysAboveGround>6</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>1</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.674548413457146 139.73749760542387 0 35.674524648364496 139.73742350960396 0 35.67444716014478 139.73746094056074 0 35.67452062316006 139.73768908020435 0 35.674688485915446 139.73760989493096 0 35.67463851613875 139.73745419407197 0 35.674548413457146 139.73749760542387 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.674548413457146 139.73749760542387 9.189 35.67463851613875 139.73745419407197 9.189 35.674688485915446 139.73760989493096 9.189 35.67452062316006 139.73768908020435 9.189 35.67444716014478 139.73746094056074 9.189 35.674524648364496 139.73742350960396 9.189 35.674548413457146 139.73749760542387 9.189</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.674548413457146 139.73749760542387 9.189 35.674524648364496 139.73742350960396 9.189 35.674524648364496 139.73742350960396 29.14 35.674548413457146 139.73749760542387 29.14 35.674548413457146 139.73749760542387 9.189</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.674524648364496 139.73742350960396 9.189 35.67444716014478 139.73746094056074 9.189 35.67444716014478 139.73746094056074 29.14 35.674524648364496 139.73742350960396 29.14 35.674524648364496 139.73742350960396 9.189</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67444716014478 139.73746094056074 9.189 35.67452062316006 139.73768908020435 9.189 35.67452062316006 139.73768908020435 29.14 35.67444716014478 139.73746094056074 29.14 35.67444716014478 139.73746094056074 9.189</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67452062316006 139.73768908020435 9.189 35.674688485915446 139.73760989493096 9.189 35.674688485915446 139.73760989493096 29.14 35.67452062316006 139.73768908020435 29.14 35.67452062316006 139.73768908020435 9.189</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.674688485915446 139.73760989493096 9.189 35.67463851613875 139.73745419407197 9.189 35.67463851613875 139.73745419407197 29.14 35.674688485915446 139.73760989493096 29.14 35.674688485915446 139.73760989493096 9.189</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67463851613875 139.73745419407197 9.189 35.674548413457146 139.73749760542387 9.189 35.674548413457146 139.73749760542387 29.14 35.67463851613875 139.73745419407197 29.14 35.67463851613875 139.73745419407197 9.189</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.674548413457146 139.73749760542387 29.14 35.674524648364496 139.73742350960396 29.14 35.67444716014478 139.73746094056074 29.14 35.67452062316006 139.73768908020435 29.14 35.674688485915446 139.73760989493096 29.14 35.67463851613875 139.73745419407197 29.14 35.674548413457146 139.73749760542387 29.14</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-7accba2e-fd1e-434f-91ec-c8d8eedbd862"/>
							<gml:surfaceMember xlink:href="#poly-cd5be82f-066e-42c3-800b-affa3f64f890"/>
							<gml:surfaceMember xlink:href="#poly-3be69fcc-c112-40f8-b24a-bdebf97c62bf"/>
							<gml:surfaceMember xlink:href="#poly-a2fe03fa-7cc8-4816-9506-7873281a9125"/>
							<gml:surfaceMember xlink:href="#poly-0595fb0c-a23a-4b3d-ba9c-b633e96313df"/>
							<gml:surfaceMember xlink:href="#poly-4f312365-fe91-4d1f-9485-52754b3990ca"/>
							<gml:surfaceMember xlink:href="#poly-b6f1f53d-f7e7-43db-9e22-93266660ad8e"/>
							<gml:surfaceMember xlink:href="#poly-0b60555b-e9f7-4245-9859-7cb6e1874019"/>
							<gml:surfaceMember xlink:href="#poly-a2f29e13-041e-4f57-968a-40fa5a46be82"/>
							<gml:surfaceMember xlink:href="#poly-cb21a869-736b-4315-9a81-35e898de87ac"/>
							<gml:surfaceMember xlink:href="#poly-74b43c77-5535-4727-b65f-b471510e6deb"/>
							<gml:surfaceMember xlink:href="#poly-b7e65e41-27c1-45c1-9ccd-abe59a39b40d"/>
							<gml:surfaceMember xlink:href="#poly-eb7bd691-8f70-4a53-9113-92ad1b707010"/>
							<gml:surfaceMember xlink:href="#poly-44517312-8b6a-4fdd-830f-755071f63707"/>
							<gml:surfaceMember xlink:href="#poly-3a06b9f3-dbc2-4b83-a61a-9bdc1cc59a1b"/>
							<gml:surfaceMember xlink:href="#poly-e72129fe-bf64-4cf7-b413-34ca3c5a344e"/>
							<gml:surfaceMember xlink:href="#poly-ee91ca30-e320-41a1-97cb-f5d4e3fe2123"/>
							<gml:surfaceMember xlink:href="#poly-27389e49-77f5-409c-8b0e-bd3f63e8901f"/>
							<gml:surfaceMember xlink:href="#poly-52d9d30d-0bd9-41c1-9852-f6f47a92559f"/>
							<gml:surfaceMember xlink:href="#poly-ec91cb13-0814-44b3-8da6-92b68886b817"/>
							<gml:surfaceMember xlink:href="#poly-7ced217d-7d04-42ad-8c27-7b1a7dcb0d8d"/>
							<gml:surfaceMember xlink:href="#poly-c12ec022-86f4-4bb4-baaa-ae13fc33c3d8"/>
							<gml:surfaceMember xlink:href="#poly-ceeaa5aa-7eae-4129-88e4-bce615d5a6cd"/>
							<gml:surfaceMember xlink:href="#poly-f20853b2-d46e-4e9f-a1f0-526dad34e780"/>
							<gml:surfaceMember xlink:href="#poly-48ff3fc6-34d5-466e-981f-d0811f6338b0"/>
							<gml:surfaceMember xlink:href="#poly-142fbbb0-c9ca-49bb-aae6-4bdf2f9791e5"/>
							<gml:surfaceMember xlink:href="#poly-fd21fdf6-5150-43b6-a4ba-f9ab70000adb"/>
							<gml:surfaceMember xlink:href="#poly-da465980-63d9-40ea-9449-84b0c40927f7"/>
							<gml:surfaceMember xlink:href="#poly-2bf02ae9-276f-45bd-ba98-9ea1196a7b08"/>
							<gml:surfaceMember xlink:href="#poly-84516983-52ad-46c5-9014-a16f5abc6601"/>
							<gml:surfaceMember xlink:href="#poly-723b6109-fef9-435f-b357-1d550b11306e"/>
							<gml:surfaceMember xlink:href="#poly-152cd986-fcc9-4a49-ba5b-950bb0f0f701"/>
							<gml:surfaceMember xlink:href="#poly-51e51755-7f7f-4127-985c-6ffa54c5c43f"/>
							<gml:surfaceMember xlink:href="#poly-ec8d60e7-cae8-4257-a7b9-e89547232644"/>
							<gml:surfaceMember xlink:href="#poly-5c81df55-456f-45fe-b32b-53f386d1fc69"/>
							<gml:surfaceMember xlink:href="#poly-67f78271-7858-401b-9608-d8770cec9b99"/>
							<gml:surfaceMember xlink:href="#poly-69c738b7-efff-4e5a-98a1-4a852cc53b1c"/>
							<gml:surfaceMember xlink:href="#poly-32078721-4717-4351-827f-9a7932270745"/>
							<gml:surfaceMember xlink:href="#poly-1d27d5a1-6b5c-4ab6-a32d-f63ced68c207"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_d1208a40-cf6d-4cbc-9d6e-1dcaaacbc842_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9e920989-6c4c-4068-9332-e0dbd7d38890">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6745028973018 139.7375808755867 28.886 35.67449441865437 139.73758498408637 28.886 35.67447923815448 139.73753790960725 28.886 35.67448771680032 139.7375338011034 28.886 35.6745028973018 139.7375808755867 28.886</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6694cd36-8068-4a8a-845e-88a7953e4642">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67455781338931 139.737597844212 28.916 35.674561590563926 139.73760971504913 28.916 35.67454595776522 139.73761727870294 28.916 35.67454204506064 139.73760499929682 28.916 35.67455767786739 139.73759744668777 28.916 35.67455781338931 139.737597844212 28.916</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ab7e4c22-53cf-4e2f-bf25-09e50cd48072">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6746312671178 139.73749698717222 29.008 35.674615184036234 139.73750504850082 29.008 35.67461262704417 139.73749737400203 29.008 35.67462870110271 139.73748930163606 29.008 35.6746312671178 139.73749698717222 29.008</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-71188a37-81c2-41ca-91e7-f50ca884d3da">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-71188a37-81c2-41ca-91e7-f50ca884d3da_0">
											<gml:posList>35.67448771680032 139.7375338011034 28.886 35.67447923815448 139.73753790960725 28.886 35.67447923815448 139.73753790960725 30.373 35.67448771680032 139.7375338011034 30.373 35.67448771680032 139.7375338011034 28.886</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f1f347d0-5c22-454b-8a99-f38dc2e5bc5c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f1f347d0-5c22-454b-8a99-f38dc2e5bc5c_0">
											<gml:posList>35.67449441865437 139.73758498408637 28.886 35.67449441865437 139.73758498408637 30.373 35.67447923815448 139.73753790960725 30.373 35.67447923815448 139.73753790960725 28.886 35.67449441865437 139.73758498408637 28.886</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8709cf53-b728-4805-b744-a6e1e404286b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8709cf53-b728-4805-b744-a6e1e404286b_0">
											<gml:posList>35.6745028973018 139.7375808755867 30.373 35.67448771680032 139.7375338011034 30.373 35.67447923815448 139.73753790960725 30.373 35.67449441865437 139.73758498408637 30.373 35.6745028973018 139.7375808755867 30.373</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3a2fcaaf-da36-40d9-8513-7b9d1daffe93">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3a2fcaaf-da36-40d9-8513-7b9d1daffe93_0">
											<gml:posList>35.67448771680032 139.7375338011034 28.886 35.67448771680032 139.7375338011034 30.373 35.6745028973018 139.7375808755867 30.373 35.6745028973018 139.7375808755867 28.886 35.67448771680032 139.7375338011034 28.886</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-de88f3c6-1fb8-4421-91b1-637f190bc75e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-de88f3c6-1fb8-4421-91b1-637f190bc75e_0">
											<gml:posList>35.67449441865437 139.73758498408637 28.886 35.6745028973018 139.7375808755867 28.886 35.6745028973018 139.7375808755867 30.373 35.67449441865437 139.73758498408637 30.373 35.67449441865437 139.73758498408637 28.886</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c5b64960-23af-4088-8ee2-485874f78650">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c5b64960-23af-4088-8ee2-485874f78650_0">
											<gml:posList>35.67454204506064 139.73760499929682 28.916 35.67454595776522 139.73761727870294 28.916 35.67454595776522 139.73761727870294 31.626 35.67454204506064 139.73760499929682 31.626 35.67454204506064 139.73760499929682 28.916</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-695a2746-6644-4283-a501-498a350ba3b8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-695a2746-6644-4283-a501-498a350ba3b8_0">
											<gml:posList>35.67455767786739 139.73759744668777 28.916 35.67454204506064 139.73760499929682 28.916 35.67454204506064 139.73760499929682 31.626 35.67455767786739 139.73759744668777 31.626 35.67455767786739 139.73759744668777 28.916</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5fc99e59-2e66-4bd4-8c6c-a95c5ef38b93">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5fc99e59-2e66-4bd4-8c6c-a95c5ef38b93_0">
											<gml:posList>35.67455787665221 139.73759805402628 31.626 35.67455767786739 139.73759744668777 31.626 35.67454204506064 139.73760499929682 31.626 35.67454595776522 139.73761727870294 31.626 35.674561590563926 139.73760971504913 31.626 35.67455787665221 139.73759805402628 31.626</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4a744b44-b068-44f3-8062-fe7d29876dd6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4a744b44-b068-44f3-8062-fe7d29876dd6_0">
											<gml:posList>35.67454595776522 139.73761727870294 28.916 35.674561590563926 139.73760971504913 28.916 35.674561590563926 139.73760971504913 31.626 35.67454595776522 139.73761727870294 31.626 35.67454595776522 139.73761727870294 28.916</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-33d33f33-8f78-484a-8eda-9469284f72f5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-33d33f33-8f78-484a-8eda-9469284f72f5_0">
											<gml:posList>35.67455767786739 139.73759744668777 31.626 35.67455787665221 139.73759805402628 31.626 35.67455781338931 139.737597844212 28.916 35.67455767786739 139.73759744668777 28.916 35.67455767786739 139.73759744668777 31.626</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8eb82a4b-e666-4ac0-81c0-b24a919a93a6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8eb82a4b-e666-4ac0-81c0-b24a919a93a6_0">
											<gml:posList>35.67455787665221 139.73759805402628 31.626 35.674561590563926 139.73760971504913 31.626 35.674561590563926 139.73760971504913 28.916 35.67455781338931 139.737597844212 28.916 35.67455787665221 139.73759805402628 31.626</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e60d926c-1af2-4d16-92bf-0f735bed447a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e60d926c-1af2-4d16-92bf-0f735bed447a_0">
											<gml:posList>35.67461262704417 139.73749737400203 29.008 35.674615184036234 139.73750504850082 29.008 35.674615184036234 139.73750504850082 31.247 35.67461262704417 139.73749737400203 31.247 35.67461262704417 139.73749737400203 29.008</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-59aaa7f5-983d-4aba-be75-fe6b9cb379d6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-59aaa7f5-983d-4aba-be75-fe6b9cb379d6_0">
											<gml:posList>35.67462870110271 139.73748930163606 29.008 35.67461262704417 139.73749737400203 29.008 35.67461262704417 139.73749737400203 31.247 35.67462870110271 139.73748930163606 31.247 35.67462870110271 139.73748930163606 29.008</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9cc0b440-f691-4aa2-ac91-27a8c885acf9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9cc0b440-f691-4aa2-ac91-27a8c885acf9_0">
											<gml:posList>35.6746312671178 139.73749698717222 31.247 35.67462870110271 139.73748930163606 31.247 35.67461262704417 139.73749737400203 31.247 35.674615184036234 139.73750504850082 31.247 35.6746312671178 139.73749698717222 31.247</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-27c5780b-3c9f-49c5-9b8f-333333510e60">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-27c5780b-3c9f-49c5-9b8f-333333510e60_0">
											<gml:posList>35.674615184036234 139.73750504850082 29.008 35.6746312671178 139.73749698717222 29.008 35.6746312671178 139.73749698717222 31.247 35.674615184036234 139.73750504850082 31.247 35.674615184036234 139.73750504850082 29.008</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ca7aa351-5acb-400d-9037-bd0828348339">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ca7aa351-5acb-400d-9037-bd0828348339_0">
											<gml:posList>35.67462870110271 139.73748930163606 29.008 35.67462870110271 139.73748930163606 31.247 35.6746312671178 139.73749698717222 31.247 35.6746312671178 139.73749698717222 29.008 35.67462870110271 139.73748930163606 29.008</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_d1208a40-cf6d-4cbc-9d6e-1dcaaacbc842_BuildingInstallation_1041">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-588dbd47-bee3-430c-a00c-ced7da37558d">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67453695545047 139.7375636128954 28.886 35.67451756537598 139.73757299272418 28.886 35.67450046014177 139.73751987791977 28.886 35.674519850212164 139.73751049808016 28.886 35.67453695545047 139.7375636128954 28.886</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fca940a7-31f9-4fa5-a8a9-fe80d732878c">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.674579205793464 139.7375674067203 33.071 35.674586244863654 139.73758926000514 33.071 35.67456767471924 139.73759824116823 33.071 35.67456063565068 139.73757638788766 33.071 35.674579205793464 139.7375674067203 33.071</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a1a9a475-4d64-4484-9500-2b8031268812">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.674629515653926 139.73758410468298 26.715 35.674666169392125 139.7375663859441 26.715 35.67467421152346 139.7375914305944 26.715 35.67463755779037 139.73760916037043 26.715 35.674629515653926 139.73758410468298 26.715</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-078e79be-16e7-48b3-bf99-da9f732a8778">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-078e79be-16e7-48b3-bf99-da9f732a8778_0">
											<gml:posList>35.67450046014177 139.73751987791977 32.025 35.67450046014177 139.73751987791977 28.886 35.67451756537598 139.73757299272418 28.886 35.67451756537598 139.73757299272418 32.025 35.67450046014177 139.73751987791977 32.025</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-33dcafa4-29f2-4f76-a0c1-d8147478a23e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-33dcafa4-29f2-4f76-a0c1-d8147478a23e_0">
											<gml:posList>35.67450046014177 139.73751987791977 32.025 35.674519850212164 139.73751049808016 32.025 35.674519850212164 139.73751049808016 28.886 35.67450046014177 139.73751987791977 28.886 35.67450046014177 139.73751987791977 32.025</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d71d5ecd-d156-4b05-bad8-05770cb36182">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d71d5ecd-d156-4b05-bad8-05770cb36182_0">
											<gml:posList>35.67453695545047 139.7375636128954 32.025 35.674519850212164 139.73751049808016 32.025 35.67450046014177 139.73751987791977 32.025 35.67451756537598 139.73757299272418 32.025 35.67453695545047 139.7375636128954 32.025</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4dd95eaa-d4a3-479a-8329-b1b8d067dc01">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4dd95eaa-d4a3-479a-8329-b1b8d067dc01_0">
											<gml:posList>35.67451756537598 139.73757299272418 32.025 35.67451756537598 139.73757299272418 28.886 35.67453695545047 139.7375636128954 28.886 35.67453695545047 139.7375636128954 32.025 35.67451756537598 139.73757299272418 32.025</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-aa0c565a-6f4f-4b66-9fbb-8be8b14f2973">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-aa0c565a-6f4f-4b66-9fbb-8be8b14f2973_0">
											<gml:posList>35.674519850212164 139.73751049808016 32.025 35.67453695545047 139.7375636128954 32.025 35.67453695545047 139.7375636128954 28.886 35.674519850212164 139.73751049808016 28.886 35.674519850212164 139.73751049808016 32.025</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6e704584-ac25-4df0-be70-26001937b213">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6e704584-ac25-4df0-be70-26001937b213_0">
											<gml:posList>35.67456767471924 139.73759824116823 36.293 35.67456063565068 139.73757638788766 36.293 35.67456063565068 139.73757638788766 33.071 35.67456767471924 139.73759824116823 33.071 35.67456767471924 139.73759824116823 36.293</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6989db56-e7f0-4312-b52d-8254b1fa8f25">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6989db56-e7f0-4312-b52d-8254b1fa8f25_0">
											<gml:posList>35.67456063565068 139.73757638788766 36.293 35.674579205793464 139.7375674067203 36.293 35.674579205793464 139.7375674067203 33.071 35.67456063565068 139.73757638788766 33.071 35.67456063565068 139.73757638788766 36.293</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-44c6163f-4488-4cca-8ec2-852581a08470">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-44c6163f-4488-4cca-8ec2-852581a08470_0">
											<gml:posList>35.674579205793464 139.7375674067203 36.293 35.67456063565068 139.73757638788766 36.293 35.67456767471924 139.73759824116823 36.293 35.674586244863654 139.73758926000514 36.293 35.674579205793464 139.7375674067203 36.293</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2bac7536-2f3e-4446-8012-e2b206ce5d3a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2bac7536-2f3e-4446-8012-e2b206ce5d3a_0">
											<gml:posList>35.67456767471924 139.73759824116823 36.293 35.67456767471924 139.73759824116823 33.071 35.674586244863654 139.73758926000514 33.071 35.674586244863654 139.73758926000514 36.293 35.67456767471924 139.73759824116823 36.293</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-35916644-cecd-4159-b04d-0e71d1ffe619">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-35916644-cecd-4159-b04d-0e71d1ffe619_0">
											<gml:posList>35.674579205793464 139.7375674067203 36.293 35.674586244863654 139.73758926000514 36.293 35.674586244863654 139.73758926000514 33.071 35.674579205793464 139.7375674067203 33.071 35.674579205793464 139.7375674067203 36.293</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d01ba896-213f-4c54-a576-78dccbc1ffd0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d01ba896-213f-4c54-a576-78dccbc1ffd0_0">
											<gml:posList>35.674629515653926 139.73758410468298 26.715 35.67463755779037 139.73760916037043 26.715 35.67463755779037 139.73760916037043 29.105 35.674629515653926 139.73758410468298 29.105 35.674629515653926 139.73758410468298 26.715</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2fe6e033-5f86-45c7-8175-fe3219de52bd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2fe6e033-5f86-45c7-8175-fe3219de52bd_0">
											<gml:posList>35.674629515653926 139.73758410468298 29.105 35.674666169392125 139.7375663859441 29.105 35.674666169392125 139.7375663859441 26.715 35.674629515653926 139.73758410468298 26.715 35.674629515653926 139.73758410468298 29.105</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2eb791a6-f521-445e-8b56-00f8d588876c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2eb791a6-f521-445e-8b56-00f8d588876c_0">
											<gml:posList>35.67467421152346 139.7375914305944 29.105 35.674666169392125 139.7375663859441 29.105 35.674629515653926 139.73758410468298 29.105 35.67463755779037 139.73760916037043 29.105 35.67467421152346 139.7375914305944 29.105</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e11d6fba-4e3d-4e72-8330-95b2c34b1d6c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e11d6fba-4e3d-4e72-8330-95b2c34b1d6c_0">
											<gml:posList>35.67467421152346 139.7375914305944 29.105 35.67463755779037 139.73760916037043 29.105 35.67463755779037 139.73760916037043 26.715 35.67467421152346 139.7375914305944 26.715 35.67467421152346 139.7375914305944 29.105</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e5aa2be2-e89a-4503-8d37-0cd33eacd9e9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e5aa2be2-e89a-4503-8d37-0cd33eacd9e9_0">
											<gml:posList>35.674666169392125 139.7375663859441 29.105 35.67467421152346 139.7375914305944 29.105 35.67467421152346 139.7375914305944 26.715 35.674666169392125 139.7375663859441 26.715 35.674666169392125 139.7375663859441 29.105</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-7accba2e-fd1e-434f-91ec-c8d8eedbd862">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7accba2e-fd1e-434f-91ec-c8d8eedbd862">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7accba2e-fd1e-434f-91ec-c8d8eedbd862">
											<gml:posList>35.67454841345715 139.7374976054239 9.189 35.674638516138735 139.73745419407197 9.189 35.674688485915446 139.73760989493096 9.189 35.67452062316005 139.73768908020435 9.189 35.67444716014477 139.7374609405607 9.189 35.674524648364496 139.73742350960393 9.189 35.67454841345715 139.7374976054239 9.189</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-cd5be82f-066e-42c3-800b-affa3f64f890">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cd5be82f-066e-42c3-800b-affa3f64f890">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cd5be82f-066e-42c3-800b-affa3f64f890">
											<gml:posList>35.67444716014477 139.7374609405607 29.231 35.67445328307013 139.73746421414378 29.231 35.67452196826049 139.7374310246547 29.231 35.674524648364496 139.73742350960393 29.231 35.67444716014477 139.7374609405607 29.231</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-3be69fcc-c112-40f8-b24a-bdebf97c62bf">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3be69fcc-c112-40f8-b24a-bdebf97c62bf">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3be69fcc-c112-40f8-b24a-bdebf97c62bf">
											<gml:posList>35.674528617928914 139.73750718459758 28.886 35.674544016452046 139.7374997316723 28.886 35.67452196826049 139.7374310246547 28.886 35.67445328307013 139.73746421414378 28.886 35.674508701135764 139.73763630163728 28.886 35.67456190672899 139.73761057632476 28.886 35.674528617928914 139.73750718459758 28.886</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a2fe03fa-7cc8-4816-9506-7873281a9125">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a2fe03fa-7cc8-4816-9506-7873281a9125">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a2fe03fa-7cc8-4816-9506-7873281a9125">
											<gml:posList>35.674506048059605 139.73764381664722 29.231 35.674508701135764 139.73763630163728 29.231 35.67445328307013 139.73746421414378 29.231 35.67444716014477 139.7374609405607 29.231 35.674506048059605 139.73764381664722 29.231</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-0595fb0c-a23a-4b3d-ba9c-b633e96313df">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0595fb0c-a23a-4b3d-ba9c-b633e96313df">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0595fb0c-a23a-4b3d-ba9c-b633e96313df">
											<gml:posList>35.67452196826049 139.7374310246547 29.231 35.674544016452046 139.7374997316723 29.231 35.67454841345715 139.7374976054239 29.231 35.674524648364496 139.73742350960393 29.231 35.67452196826049 139.7374310246547 29.231</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-4f312365-fe91-4d1f-9485-52754b3990ca">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4f312365-fe91-4d1f-9485-52754b3990ca">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4f312365-fe91-4d1f-9485-52754b3990ca">
											<gml:posList>35.67463596193465 139.73746134443593 29.231 35.674638516138735 139.73745419407197 29.231 35.67457777792761 139.73748346350777 29.231 35.67457943153536 139.737488609357 29.231 35.67463596193465 139.73746134443593 29.231</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b6f1f53d-f7e7-43db-9e22-93266660ad8e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b6f1f53d-f7e7-43db-9e22-93266660ad8e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b6f1f53d-f7e7-43db-9e22-93266660ad8e">
											<gml:posList>35.674528617928914 139.73750718459758 33.483 35.67453294635866 139.73750949925815 33.483 35.674575898281944 139.73748876823706 33.483 35.67457777792761 139.73748346350777 33.483 35.674528617928914 139.73750718459758 33.483</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-0b60555b-e9f7-4245-9859-7cb6e1874019">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0b60555b-e9f7-4245-9859-7cb6e1874019">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0b60555b-e9f7-4245-9859-7cb6e1874019">
											<gml:posList>35.674638516138735 139.73745419407197 29.231 35.67463596193465 139.73746134443593 29.231 35.67466755224999 139.73755977827582 29.231 35.67467339561548 139.7375628865066 29.231 35.674638516138735 139.73745419407197 29.231</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a2f29e13-041e-4f57-968a-40fa5a46be82">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a2f29e13-041e-4f57-968a-40fa5a46be82">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a2f29e13-041e-4f57-968a-40fa5a46be82">
											<gml:posList>35.67457943153536 139.737488609357 29.008 35.674611111992135 139.7375870761712 29.008 35.67466755224999 139.73755977827582 29.008 35.67463596193465 139.73746134443593 29.008 35.67457943153536 139.737488609357 29.008</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-cb21a869-736b-4315-9a81-35e898de87ac">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cb21a869-736b-4315-9a81-35e898de87ac">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cb21a869-736b-4315-9a81-35e898de87ac">
											<gml:posList>35.67457777792761 139.73748346350777 33.483 35.674575898281944 139.73748876823706 33.483 35.67460843716734 139.73758990735737 33.483 35.67461276558668 139.73759221097788 33.483 35.67457777792761 139.73748346350777 33.483</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-74b43c77-5535-4727-b65f-b471510e6deb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-74b43c77-5535-4727-b65f-b471510e6deb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-74b43c77-5535-4727-b65f-b471510e6deb">
											<gml:posList>35.67460843716734 139.73758990735737 33.071 35.674575898281944 139.73748876823706 33.071 35.67453294635866 139.73750949925815 33.071 35.67456552130802 139.73761067143022 33.071 35.67460843716734 139.73758990735737 33.071</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b7e65e41-27c1-45c1-9ccd-abe59a39b40d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b7e65e41-27c1-45c1-9ccd-abe59a39b40d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b7e65e41-27c1-45c1-9ccd-abe59a39b40d">
											<gml:posList>35.674563641647964 139.7376159651089 33.483 35.67456552130802 139.73761067143022 33.483 35.67453294635866 139.73750949925815 33.483 35.674528617928914 139.73750718459758 33.483 35.674563641647964 139.7376159651089 33.483</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-eb7bd691-8f70-4a53-9113-92ad1b707010">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-eb7bd691-8f70-4a53-9113-92ad1b707010">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-eb7bd691-8f70-4a53-9113-92ad1b707010">
											<gml:posList>35.67466755224999 139.73755977827582 29.231 35.674611111992135 139.7375870761712 29.231 35.67461276558668 139.73759221097788 29.231 35.67467339561548 139.7375628865066 29.231 35.67466755224999 139.73755977827582 29.231</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-44517312-8b6a-4fdd-830f-755071f63707">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-44517312-8b6a-4fdd-830f-755071f63707">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-44517312-8b6a-4fdd-830f-755071f63707">
											<gml:posList>35.674688485915446 139.73760989493096 22.296 35.67468185341497 139.73758923419086 26.715 35.674638000489956 139.7376104523228 26.715 35.674688485915446 139.73760989493096 22.296</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-3a06b9f3-dbc2-4b83-a61a-9bdc1cc59a1b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3a06b9f3-dbc2-4b83-a61a-9bdc1cc59a1b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3a06b9f3-dbc2-4b83-a61a-9bdc1cc59a1b">
											<gml:posList>35.67461276558668 139.73759221097788 33.483 35.67460843716734 139.73758990735737 33.483 35.67456552130802 139.73761067143022 33.483 35.674563641647964 139.7376159651089 33.483 35.67461276558668 139.73759221097788 33.483</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e72129fe-bf64-4cf7-b413-34ca3c5a344e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e72129fe-bf64-4cf7-b413-34ca3c5a344e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e72129fe-bf64-4cf7-b413-34ca3c5a344e">
											<gml:posList>35.674638000489956 139.7376104523228 26.715 35.67468185341497 139.73758923419086 26.715 35.67467339561548 139.7375628865066 26.715 35.674506048059605 139.73764381664722 26.715 35.67451350277383 139.73766696190177 26.715 35.674638000489956 139.7376104523228 26.715</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ee91ca30-e320-41a1-97cb-f5d4e3fe2123">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ee91ca30-e320-41a1-97cb-f5d4e3fe2123">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ee91ca30-e320-41a1-97cb-f5d4e3fe2123">
											<gml:posList>35.674508701135764 139.73763630163728 29.231 35.674506048059605 139.73764381664722 29.231 35.674563641647964 139.7376159651089 29.231 35.67456190672899 139.73761057632476 29.231 35.674508701135764 139.73763630163728 29.231</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-27389e49-77f5-409c-8b0e-bd3f63e8901f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-27389e49-77f5-409c-8b0e-bd3f63e8901f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-27389e49-77f5-409c-8b0e-bd3f63e8901f">
											<gml:posList>35.674688485915446 139.73760989493096 22.296 35.674638000489956 139.7376104523228 26.715 35.67451350277383 139.73766696190177 26.715 35.674688485915446 139.73760989493096 22.296</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-52d9d30d-0bd9-41c1-9852-f6f47a92559f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-52d9d30d-0bd9-41c1-9852-f6f47a92559f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-52d9d30d-0bd9-41c1-9852-f6f47a92559f">
											<gml:posList>35.674688485915446 139.73760989493096 22.296 35.67451350277383 139.73766696190177 26.715 35.67452062316005 139.73768908020435 22.296 35.674688485915446 139.73760989493096 22.296</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ec91cb13-0814-44b3-8da6-92b68886b817">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ec91cb13-0814-44b3-8da6-92b68886b817">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ec91cb13-0814-44b3-8da6-92b68886b817">
											<gml:posList>35.67452196826049 139.7374310246547 29.231 35.67452196826049 139.7374310246547 28.886 35.674544016452046 139.7374997316723 28.886 35.674544016452046 139.7374997316723 29.231 35.67452196826049 139.7374310246547 29.231</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7ced217d-7d04-42ad-8c27-7b1a7dcb0d8d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7ced217d-7d04-42ad-8c27-7b1a7dcb0d8d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7ced217d-7d04-42ad-8c27-7b1a7dcb0d8d">
											<gml:posList>35.674524648364496 139.73742350960393 9.189 35.67444716014477 139.7374609405607 9.189 35.67444716014477 139.7374609405607 29.231 35.674524648364496 139.73742350960393 29.231 35.674524648364496 139.73742350960393 9.189</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c12ec022-86f4-4bb4-baaa-ae13fc33c3d8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c12ec022-86f4-4bb4-baaa-ae13fc33c3d8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c12ec022-86f4-4bb4-baaa-ae13fc33c3d8">
											<gml:posList>35.67445328307013 139.73746421414378 29.231 35.67445328307013 139.73746421414378 28.886 35.67452196826049 139.7374310246547 28.886 35.67452196826049 139.7374310246547 29.231 35.67445328307013 139.73746421414378 29.231</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ceeaa5aa-7eae-4129-88e4-bce615d5a6cd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ceeaa5aa-7eae-4129-88e4-bce615d5a6cd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ceeaa5aa-7eae-4129-88e4-bce615d5a6cd">
											<gml:posList>35.67454841345715 139.7374976054239 9.189 35.674524648364496 139.73742350960393 9.189 35.674524648364496 139.73742350960393 29.231 35.67454841345715 139.7374976054239 29.231 35.67454841345715 139.7374976054239 9.189</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f20853b2-d46e-4e9f-a1f0-526dad34e780">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f20853b2-d46e-4e9f-a1f0-526dad34e780">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f20853b2-d46e-4e9f-a1f0-526dad34e780">
											<gml:posList>35.67457943153536 139.737488609357 29.231 35.67457943153536 139.737488609357 29.008 35.67463596193465 139.73746134443593 29.008 35.67463596193465 139.73746134443593 29.231 35.67457943153536 139.737488609357 29.231</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-48ff3fc6-34d5-466e-981f-d0811f6338b0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-48ff3fc6-34d5-466e-981f-d0811f6338b0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-48ff3fc6-34d5-466e-981f-d0811f6338b0">
											<gml:posList>35.674638516138735 139.73745419407197 9.189 35.67454841345715 139.7374976054239 9.189 35.67454841345715 139.7374976054239 29.231 35.674544016452046 139.7374997316723 29.231 35.674544016452046 139.7374997316723 28.886 35.674528617928914 139.73750718459758 28.886 35.674528617928914 139.73750718459758 33.483 35.67457777792761 139.73748346350777 33.483 35.67457777792761 139.73748346350777 29.231 35.674638516138735 139.73745419407197 29.231 35.674638516138735 139.73745419407197 9.189</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-142fbbb0-c9ca-49bb-aae6-4bdf2f9791e5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-142fbbb0-c9ca-49bb-aae6-4bdf2f9791e5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-142fbbb0-c9ca-49bb-aae6-4bdf2f9791e5">
											<gml:posList>35.67453294635866 139.73750949925815 33.483 35.67453294635866 139.73750949925815 33.071 35.674575898281944 139.73748876823706 33.071 35.674575898281944 139.73748876823706 33.483 35.67453294635866 139.73750949925815 33.483</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-fd21fdf6-5150-43b6-a4ba-f9ab70000adb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fd21fdf6-5150-43b6-a4ba-f9ab70000adb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fd21fdf6-5150-43b6-a4ba-f9ab70000adb">
											<gml:posList>35.67463596193465 139.73746134443593 29.231 35.67463596193465 139.73746134443593 29.008 35.67466755224999 139.73755977827582 29.008 35.67466755224999 139.73755977827582 29.231 35.67463596193465 139.73746134443593 29.231</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-da465980-63d9-40ea-9449-84b0c40927f7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-da465980-63d9-40ea-9449-84b0c40927f7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-da465980-63d9-40ea-9449-84b0c40927f7">
											<gml:posList>35.67467339561548 139.7375628865066 26.715 35.67468185341497 139.73758923419086 26.715 35.674688485915446 139.73760989493096 22.296 35.674688485915446 139.73760989493096 9.189 35.674638516138735 139.73745419407197 9.189 35.674638516138735 139.73745419407197 29.231 35.67467339561548 139.7375628865066 29.231 35.67467339561548 139.7375628865066 26.715</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2bf02ae9-276f-45bd-ba98-9ea1196a7b08">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2bf02ae9-276f-45bd-ba98-9ea1196a7b08">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2bf02ae9-276f-45bd-ba98-9ea1196a7b08">
											<gml:posList>35.67457777792761 139.73748346350777 33.483 35.67461276558668 139.73759221097788 33.483 35.67461276558668 139.73759221097788 29.231 35.674611111992135 139.7375870761712 29.231 35.674611111992135 139.7375870761712 29.008 35.67457943153536 139.737488609357 29.008 35.67457943153536 139.737488609357 29.231 35.67457777792761 139.73748346350777 29.231 35.67457777792761 139.73748346350777 33.483</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-84516983-52ad-46c5-9014-a16f5abc6601">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-84516983-52ad-46c5-9014-a16f5abc6601">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-84516983-52ad-46c5-9014-a16f5abc6601">
											<gml:posList>35.674575898281944 139.73748876823706 33.483 35.674575898281944 139.73748876823706 33.071 35.67460843716734 139.73758990735737 33.071 35.67460843716734 139.73758990735737 33.483 35.674575898281944 139.73748876823706 33.483</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-723b6109-fef9-435f-b357-1d550b11306e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-723b6109-fef9-435f-b357-1d550b11306e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-723b6109-fef9-435f-b357-1d550b11306e">
											<gml:posList>35.674508701135764 139.73763630163728 29.231 35.674508701135764 139.73763630163728 28.886 35.67445328307013 139.73746421414378 28.886 35.67445328307013 139.73746421414378 29.231 35.674508701135764 139.73763630163728 29.231</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-152cd986-fcc9-4a49-ba5b-950bb0f0f701">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-152cd986-fcc9-4a49-ba5b-950bb0f0f701">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-152cd986-fcc9-4a49-ba5b-950bb0f0f701">
											<gml:posList>35.67456552130802 139.73761067143022 33.483 35.67456552130802 139.73761067143022 33.071 35.67453294635866 139.73750949925815 33.071 35.67453294635866 139.73750949925815 33.483 35.67456552130802 139.73761067143022 33.483</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-51e51755-7f7f-4127-985c-6ffa54c5c43f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-51e51755-7f7f-4127-985c-6ffa54c5c43f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-51e51755-7f7f-4127-985c-6ffa54c5c43f">
											<gml:posList>35.67456190672899 139.73761057632476 29.231 35.674563641647964 139.7376159651089 29.231 35.674563641647964 139.7376159651089 33.483 35.674528617928914 139.73750718459758 33.483 35.674528617928914 139.73750718459758 28.886 35.67456190672899 139.73761057632476 28.886 35.67456190672899 139.73761057632476 29.231</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ec8d60e7-cae8-4257-a7b9-e89547232644">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ec8d60e7-cae8-4257-a7b9-e89547232644">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ec8d60e7-cae8-4257-a7b9-e89547232644">
											<gml:posList>35.67466755224999 139.73755977827582 29.231 35.67466755224999 139.73755977827582 29.008 35.674611111992135 139.7375870761712 29.008 35.674611111992135 139.7375870761712 29.231 35.67466755224999 139.73755977827582 29.231</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5c81df55-456f-45fe-b32b-53f386d1fc69">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5c81df55-456f-45fe-b32b-53f386d1fc69">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5c81df55-456f-45fe-b32b-53f386d1fc69">
											<gml:posList>35.67452062316005 139.73768908020435 22.296 35.67451350277383 139.73766696190177 26.715 35.674506048059605 139.73764381664722 26.715 35.674506048059605 139.73764381664722 29.231 35.67444716014477 139.7374609405607 29.231 35.67444716014477 139.7374609405607 9.189 35.67452062316005 139.73768908020435 9.189 35.67452062316005 139.73768908020435 22.296</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-67f78271-7858-401b-9608-d8770cec9b99">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-67f78271-7858-401b-9608-d8770cec9b99">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-67f78271-7858-401b-9608-d8770cec9b99">
											<gml:posList>35.67460843716734 139.73758990735737 33.483 35.67460843716734 139.73758990735737 33.071 35.67456552130802 139.73761067143022 33.071 35.67456552130802 139.73761067143022 33.483 35.67460843716734 139.73758990735737 33.483</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-69c738b7-efff-4e5a-98a1-4a852cc53b1c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-69c738b7-efff-4e5a-98a1-4a852cc53b1c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-69c738b7-efff-4e5a-98a1-4a852cc53b1c">
											<gml:posList>35.674563641647964 139.7376159651089 29.231 35.674506048059605 139.73764381664722 29.231 35.674506048059605 139.73764381664722 26.715 35.67467339561548 139.7375628865066 26.715 35.67467339561548 139.7375628865066 29.231 35.67461276558668 139.73759221097788 29.231 35.67461276558668 139.73759221097788 33.483 35.674563641647964 139.7376159651089 33.483 35.674563641647964 139.7376159651089 29.231</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-32078721-4717-4351-827f-9a7932270745">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-32078721-4717-4351-827f-9a7932270745">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-32078721-4717-4351-827f-9a7932270745">
											<gml:posList>35.67456190672899 139.73761057632476 29.231 35.67456190672899 139.73761057632476 28.886 35.674508701135764 139.73763630163728 28.886 35.674508701135764 139.73763630163728 29.231 35.67456190672899 139.73761057632476 29.231</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1d27d5a1-6b5c-4ab6-a32d-f63ced68c207">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1d27d5a1-6b5c-4ab6-a32d-f63ced68c207">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1d27d5a1-6b5c-4ab6-a32d-f63ced68c207">
											<gml:posList>35.67452062316005 139.73768908020435 9.189 35.674688485915446 139.73760989493096 9.189 35.674688485915446 139.73760989493096 22.296 35.67452062316005 139.73768908020435 22.296 35.67452062316005 139.73768908020435 9.189</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂三丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-10265</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">367.4524</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1242</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>5</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.02</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>