<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_d157a165-5698-4543-93a0-abade23ef341">
			<core:creationDate>2024-03-15</core:creationDate>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:measuredHeight uom="m">17.8</bldg:measuredHeight>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.668476798685 139.73935782881748 0 35.66845669152095 139.7393379033175 0 35.66846861128383 139.73931943148514 0 35.66843859880485 139.73928896869097 0 35.66836903002104 139.73939188838065 0 35.66838265155189 139.73940572408605 0 35.66837995954971 139.73940970379363 0 35.668430981611905 139.7394614939092 0 35.66850324244625 139.73935458343885 0 35.66848885414819 139.73933998644637 0 35.668476798685 139.73935782881748 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668476798685 139.73935782881748 11.474 35.66848885414819 139.73933998644637 11.474 35.66850324244625 139.73935458343885 11.474 35.668430981611905 139.7394614939092 11.474 35.66837995954971 139.73940970379363 11.474 35.66838265155189 139.73940572408605 11.474 35.66836903002104 139.73939188838065 11.474 35.66843859880485 139.73928896869097 11.474 35.66846861128383 139.73931943148514 11.474 35.66845669152095 139.7393379033175 11.474 35.668476798685 139.73935782881748 11.474</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668476798685 139.73935782881748 11.474 35.66845669152095 139.7393379033175 11.474 35.66845669152095 139.7393379033175 29.27 35.668476798685 139.73935782881748 29.27 35.668476798685 139.73935782881748 11.474</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66845669152095 139.7393379033175 11.474 35.66846861128383 139.73931943148514 11.474 35.66846861128383 139.73931943148514 29.27 35.66845669152095 139.7393379033175 29.27 35.66845669152095 139.7393379033175 11.474</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66846861128383 139.73931943148514 11.474 35.66843859880485 139.73928896869097 11.474 35.66843859880485 139.73928896869097 29.27 35.66846861128383 139.73931943148514 29.27 35.66846861128383 139.73931943148514 11.474</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66843859880485 139.73928896869097 11.474 35.66836903002104 139.73939188838065 11.474 35.66836903002104 139.73939188838065 29.27 35.66843859880485 139.73928896869097 29.27 35.66843859880485 139.73928896869097 11.474</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66836903002104 139.73939188838065 11.474 35.66838265155189 139.73940572408605 11.474 35.66838265155189 139.73940572408605 29.27 35.66836903002104 139.73939188838065 29.27 35.66836903002104 139.73939188838065 11.474</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66838265155189 139.73940572408605 11.474 35.66837995954971 139.73940970379363 11.474 35.66837995954971 139.73940970379363 29.27 35.66838265155189 139.73940572408605 29.27 35.66838265155189 139.73940572408605 11.474</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66837995954971 139.73940970379363 11.474 35.668430981611905 139.7394614939092 11.474 35.668430981611905 139.7394614939092 29.27 35.66837995954971 139.73940970379363 29.27 35.66837995954971 139.73940970379363 11.474</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668430981611905 139.7394614939092 11.474 35.66850324244625 139.73935458343885 11.474 35.66850324244625 139.73935458343885 29.27 35.668430981611905 139.7394614939092 29.27 35.668430981611905 139.7394614939092 11.474</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66850324244625 139.73935458343885 11.474 35.66848885414819 139.73933998644637 11.474 35.66848885414819 139.73933998644637 29.27 35.66850324244625 139.73935458343885 29.27 35.66850324244625 139.73935458343885 11.474</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66848885414819 139.73933998644637 11.474 35.668476798685 139.73935782881748 11.474 35.668476798685 139.73935782881748 29.27 35.66848885414819 139.73933998644637 29.27 35.66848885414819 139.73933998644637 11.474</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668476798685 139.73935782881748 29.27 35.66845669152095 139.7393379033175 29.27 35.66846861128383 139.73931943148514 29.27 35.66843859880485 139.73928896869097 29.27 35.66836903002104 139.73939188838065 29.27 35.66838265155189 139.73940572408605 29.27 35.66837995954971 139.73940970379363 29.27 35.668430981611905 139.7394614939092 29.27 35.66850324244625 139.73935458343885 29.27 35.66848885414819 139.73933998644637 29.27 35.668476798685 139.73935782881748 29.27</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-e41305bf-fe28-4f36-b2fc-da1b4f6b9382"/>
							<gml:surfaceMember xlink:href="#poly-61a9b5de-1c04-43e9-89aa-832eb075b51a"/>
							<gml:surfaceMember xlink:href="#poly-0c494a8c-c28a-4a72-902c-33e8c32df4d8"/>
							<gml:surfaceMember xlink:href="#poly-48fd2678-dd41-457b-860e-b26dd80b5f20"/>
							<gml:surfaceMember xlink:href="#poly-32a97abd-0dcb-4f71-b3cb-2594f21d8d2f"/>
							<gml:surfaceMember xlink:href="#poly-a85b1fda-7639-49a7-98d7-83551820ea2f"/>
							<gml:surfaceMember xlink:href="#poly-8c19ecca-43b5-4685-be15-f467bafed7c2"/>
							<gml:surfaceMember xlink:href="#poly-99bea450-b82c-4113-a080-8e3195fb8b2c"/>
							<gml:surfaceMember xlink:href="#poly-c428e440-5efd-4450-b171-0dc0f498dad5"/>
							<gml:surfaceMember xlink:href="#poly-c55bf1cf-998a-4736-8db5-04fda7190dc8"/>
							<gml:surfaceMember xlink:href="#poly-cc8b40c7-f617-4264-97ad-6c5acce67d3c"/>
							<gml:surfaceMember xlink:href="#poly-61d1141c-002e-4f30-8c62-eaaa159ef284"/>
							<gml:surfaceMember xlink:href="#poly-39c4f181-e20d-49da-ae35-6d3b814d1d45"/>
							<gml:surfaceMember xlink:href="#poly-759ce2e9-e6d4-419d-b588-534f6b0be04d"/>
							<gml:surfaceMember xlink:href="#poly-6f3b109a-59f1-4c05-8262-0001b0e1ee96"/>
							<gml:surfaceMember xlink:href="#poly-33a67604-2b52-4125-b329-16f7da1b670b"/>
							<gml:surfaceMember xlink:href="#poly-541c5071-1cf3-4d22-9851-c85ce6b2d26c"/>
							<gml:surfaceMember xlink:href="#poly-8bc41986-597f-4eea-815a-760e350c28b3"/>
							<gml:surfaceMember xlink:href="#poly-82d0b99c-412b-4d22-9a8b-0312057e6c72"/>
							<gml:surfaceMember xlink:href="#poly-6375a906-bc79-45cb-aeec-0ceb28521932"/>
							<gml:surfaceMember xlink:href="#poly-1aa874ee-5ac6-47a6-98da-946b32b48fe1"/>
							<gml:surfaceMember xlink:href="#poly-5d63bcf1-d8fd-4662-b6d4-e45ad4c00857"/>
							<gml:surfaceMember xlink:href="#poly-21855f42-8b4d-4bbb-ac78-b73abf54a1f6"/>
							<gml:surfaceMember xlink:href="#poly-066872ae-55bf-4f1d-8307-7e8074c24970"/>
							<gml:surfaceMember xlink:href="#poly-8be49062-dc11-4588-ace4-6883742e2569"/>
							<gml:surfaceMember xlink:href="#poly-7b100a19-5986-4cb7-b660-a86815b11631"/>
							<gml:surfaceMember xlink:href="#poly-10f9e7e5-82ad-420a-aae7-f4d9047d1804"/>
							<gml:surfaceMember xlink:href="#poly-67d0849b-51ba-44ce-bbd4-93c14b956969"/>
							<gml:surfaceMember xlink:href="#poly-39e36a20-30f9-4a3c-bee0-59f252581c13"/>
							<gml:surfaceMember xlink:href="#poly-318efaa7-6702-405a-b103-487d0e5a799d"/>
							<gml:surfaceMember xlink:href="#poly-b414b49c-a5a1-41ae-aeee-cbd61bc44411"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_d157a165-5698-4543-93a0-abade23ef341_BuildingInstallation_1060">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1781304c-a5b0-47b4-bb4e-9ff7096d756b">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6684767806834 139.73935786197657 11.74 35.66845665545743 139.73933789231376 11.74 35.66846861128381 139.73931943148517 11.74 35.668488854148194 139.73933998644634 11.74 35.6684767806834 139.73935786197657 11.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b74d2d77-381e-4115-ae08-a012329fd21d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b74d2d77-381e-4115-ae08-a012329fd21d_0">
											<gml:posList>35.66845665545743 139.73933789231376 11.74 35.66845665545743 139.73933789231376 34.53 35.66846861128381 139.73931943148517 34.53 35.66846861128381 139.73931943148517 11.74 35.66845665545743 139.73933789231376 11.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a62e17d6-f98b-43b4-b817-e1ee94901268">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a62e17d6-f98b-43b4-b817-e1ee94901268_0">
											<gml:posList>35.66846861128381 139.73931943148517 11.74 35.66846861128381 139.73931943148517 34.53 35.668488854148194 139.73933998644634 30.004 35.668488854148194 139.73933998644634 11.74 35.66846861128381 139.73931943148517 11.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-28ad32e9-12c1-4167-bf70-5fc2782ea7a6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-28ad32e9-12c1-4167-bf70-5fc2782ea7a6_0">
											<gml:posList>35.668476798684985 139.73935782881748 30.004 35.668488854148194 139.73933998644634 30.004 35.66846861128381 139.73931943148517 34.53 35.66845665545743 139.73933789231376 34.53 35.668476798684985 139.73935782881748 30.004</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-12541f10-57be-437f-9b3a-1e6dacab06d5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-12541f10-57be-437f-9b3a-1e6dacab06d5_0">
											<gml:posList>35.6684767806834 139.73935786197657 11.74 35.668476798684985 139.73935782881748 30.004 35.66845665545743 139.73933789231376 34.53 35.66845665545743 139.73933789231376 11.74 35.6684767806834 139.73935786197657 11.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-aa0581ab-1e16-43b4-918a-f345b42a265c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-aa0581ab-1e16-43b4-918a-f345b42a265c_0">
											<gml:posList>35.6684767806834 139.73935786197657 11.74 35.668488854148194 139.73933998644634 11.74 35.668488854148194 139.73933998644634 30.004 35.668476798684985 139.73935782881748 30.004 35.6684767806834 139.73935786197657 11.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-e41305bf-fe28-4f36-b2fc-da1b4f6b9382">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e41305bf-fe28-4f36-b2fc-da1b4f6b9382">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e41305bf-fe28-4f36-b2fc-da1b4f6b9382">
											<gml:posList>35.668430981611905 139.7394614939092 11.474 35.66837995954971 139.7394097037936 11.474 35.668382651551866 139.73940572408603 11.474 35.66836903002102 139.73939188838065 11.474 35.668438598804826 139.73928896869097 11.474 35.66846861128381 139.73931943148517 11.474 35.66845669152096 139.73933790331748 11.474 35.668476798684985 139.73935782881748 11.474 35.668488854148194 139.73933998644634 11.474 35.668503242446235 139.73935458343885 11.474 35.668430981611905 139.7394614939092 11.474</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-61a9b5de-1c04-43e9-89aa-832eb075b51a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-61a9b5de-1c04-43e9-89aa-832eb075b51a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-61a9b5de-1c04-43e9-89aa-832eb075b51a">
											<gml:posList>35.66845885597068 139.73942024867023 30.004 35.66839422136966 139.73935462284902 30.004 35.66836903002102 139.73939188838065 22.72 35.668382651551866 139.73940572408603 22.72 35.66845885597068 139.73942024867023 30.004</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-0c494a8c-c28a-4a72-902c-33e8c32df4d8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0c494a8c-c28a-4a72-902c-33e8c32df4d8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0c494a8c-c28a-4a72-902c-33e8c32df4d8">
											<gml:posList>35.66845885597068 139.73942024867023 30.004 35.668382651551866 139.73940572408603 22.72 35.66837995954971 139.7394097037936 22.1 35.66845885597068 139.73942024867023 30.004</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-48fd2678-dd41-457b-860e-b26dd80b5f20">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-48fd2678-dd41-457b-860e-b26dd80b5f20">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-48fd2678-dd41-457b-860e-b26dd80b5f20">
											<gml:posList>35.66845885597068 139.73942024867023 30.004 35.66837995954971 139.7394097037936 22.1 35.668430981611905 139.7394614939092 22.1 35.66845885597068 139.73942024867023 30.004</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-32a97abd-0dcb-4f71-b3cb-2594f21d8d2f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-32a97abd-0dcb-4f71-b3cb-2594f21d8d2f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-32a97abd-0dcb-4f71-b3cb-2594f21d8d2f">
											<gml:posList>35.66840724920262 139.7393353544235 34.619 35.66840946638073 139.73933509776663 34.619 35.66843880825132 139.7392916968053 34.619 35.668438598804826 139.73928896869097 34.619 35.66840724920262 139.7393353544235 34.619</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a85b1fda-7639-49a7-98d7-83551820ea2f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a85b1fda-7639-49a7-98d7-83551820ea2f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a85b1fda-7639-49a7-98d7-83551820ea2f">
											<gml:posList>35.66844897979079 139.7393777110714 34.619 35.66844877035487 139.73937499400247 34.619 35.66840946638073 139.73933509776663 34.619 35.66840724920262 139.7393353544235 34.619 35.66844897979079 139.7393777110714 34.619</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-8c19ecca-43b5-4685-be15-f467bafed7c2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8c19ecca-43b5-4685-be15-f467bafed7c2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8c19ecca-43b5-4685-be15-f467bafed7c2">
											<gml:posList>35.66844877035487 139.73937499400247 33.887 35.66846601184696 139.73934961219302 33.887 35.668454483391066 139.73933820414783 33.887 35.66846641215906 139.7393197212595 33.887 35.66843880825132 139.7392916968053 33.887 35.66840946638073 139.73933509776663 33.887 35.66844877035487 139.73937499400247 33.887</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-99bea450-b82c-4113-a080-8e3195fb8b2c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-99bea450-b82c-4113-a080-8e3195fb8b2c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-99bea450-b82c-4113-a080-8e3195fb8b2c">
											<gml:posList>35.66844897979079 139.7393777110714 30.004 35.66840724920262 139.7393353544235 30.004 35.66839422136966 139.73935462284902 30.004 35.66845885597068 139.73942024867023 30.004 35.66849117796717 139.73937242582159 30.004 35.66846825605764 139.73934934445865 30.004 35.66844897979079 139.7393777110714 30.004</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c428e440-5efd-4450-b171-0dc0f498dad5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c428e440-5efd-4450-b171-0dc0f498dad5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c428e440-5efd-4450-b171-0dc0f498dad5">
											<gml:posList>35.668438598804826 139.73928896869097 34.619 35.66843880825132 139.7392916968053 34.619 35.66846641215906 139.7393197212595 34.619 35.66846861128381 139.73931943148517 34.619 35.668438598804826 139.73928896869097 34.619</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c55bf1cf-998a-4736-8db5-04fda7190dc8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c55bf1cf-998a-4736-8db5-04fda7190dc8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c55bf1cf-998a-4736-8db5-04fda7190dc8">
											<gml:posList>35.66846825605764 139.73934934445865 34.619 35.66846601184696 139.73934961219302 34.619 35.66844877035487 139.73937499400247 34.619 35.66844897979079 139.7393777110714 34.619 35.66846825605764 139.73934934445865 34.619</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-cc8b40c7-f617-4264-97ad-6c5acce67d3c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cc8b40c7-f617-4264-97ad-6c5acce67d3c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cc8b40c7-f617-4264-97ad-6c5acce67d3c">
											<gml:posList>35.66845669152096 139.73933790331748 34.619 35.668454483391066 139.73933820414783 34.619 35.66846601184696 139.73934961219302 34.619 35.66846825605764 139.73934934445865 34.619 35.66845669152096 139.73933790331748 34.619</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-61d1141c-002e-4f30-8c62-eaaa159ef284">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-61d1141c-002e-4f30-8c62-eaaa159ef284">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-61d1141c-002e-4f30-8c62-eaaa159ef284">
											<gml:posList>35.66845669152096 139.73933790331748 34.619 35.66846861128381 139.73931943148517 34.619 35.66846641215906 139.7393197212595 34.619 35.668454483391066 139.73933820414783 34.619 35.66845669152096 139.73933790331748 34.619</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-39c4f181-e20d-49da-ae35-6d3b814d1d45">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-39c4f181-e20d-49da-ae35-6d3b814d1d45">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-39c4f181-e20d-49da-ae35-6d3b814d1d45">
											<gml:posList>35.668503242446235 139.73935458343885 27.893 35.668488854148194 139.73933998644634 27.893 35.668476798684985 139.73935782881748 27.893 35.66849110579703 139.73937234858417 27.903 35.668503242446235 139.73935458343885 27.893</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-759ce2e9-e6d4-419d-b588-534f6b0be04d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-759ce2e9-e6d4-419d-b588-534f6b0be04d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-759ce2e9-e6d4-419d-b588-534f6b0be04d">
											<gml:posList>35.66836903002102 139.73939188838065 11.474 35.668382651551866 139.73940572408603 11.474 35.668382651551866 139.73940572408603 22.72 35.66836903002102 139.73939188838065 22.72 35.66836903002102 139.73939188838065 11.474</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6f3b109a-59f1-4c05-8262-0001b0e1ee96">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6f3b109a-59f1-4c05-8262-0001b0e1ee96">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6f3b109a-59f1-4c05-8262-0001b0e1ee96">
											<gml:posList>35.668382651551866 139.73940572408603 11.474 35.66837995954971 139.7394097037936 11.474 35.66837995954971 139.7394097037936 22.1 35.668382651551866 139.73940572408603 22.72 35.668382651551866 139.73940572408603 11.474</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-33a67604-2b52-4125-b329-16f7da1b670b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-33a67604-2b52-4125-b329-16f7da1b670b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-33a67604-2b52-4125-b329-16f7da1b670b">
											<gml:posList>35.668438598804826 139.73928896869097 34.619 35.668438598804826 139.73928896869097 11.474 35.66836903002102 139.73939188838065 11.474 35.66836903002102 139.73939188838065 22.72 35.66839422136966 139.73935462284902 30.004 35.66840724920262 139.7393353544235 30.004 35.66840724920262 139.7393353544235 34.619 35.668438598804826 139.73928896869097 34.619</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-541c5071-1cf3-4d22-9851-c85ce6b2d26c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-541c5071-1cf3-4d22-9851-c85ce6b2d26c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-541c5071-1cf3-4d22-9851-c85ce6b2d26c">
											<gml:posList>35.66837995954971 139.7394097037936 11.474 35.668430981611905 139.7394614939092 11.474 35.668430981611905 139.7394614939092 22.1 35.66837995954971 139.7394097037936 22.1 35.66837995954971 139.7394097037936 11.474</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8bc41986-597f-4eea-815a-760e350c28b3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8bc41986-597f-4eea-815a-760e350c28b3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8bc41986-597f-4eea-815a-760e350c28b3">
											<gml:posList>35.66840946638073 139.73933509776663 34.619 35.66840946638073 139.73933509776663 33.887 35.66843880825132 139.7392916968053 33.887 35.66843880825132 139.7392916968053 34.619 35.66840946638073 139.73933509776663 34.619</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-82d0b99c-412b-4d22-9a8b-0312057e6c72">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-82d0b99c-412b-4d22-9a8b-0312057e6c72">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-82d0b99c-412b-4d22-9a8b-0312057e6c72">
											<gml:posList>35.66844897979079 139.7393777110714 30.004 35.66844897979079 139.7393777110714 34.619 35.66840724920262 139.7393353544235 34.619 35.66840724920262 139.7393353544235 30.004 35.66844897979079 139.7393777110714 30.004</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6375a906-bc79-45cb-aeec-0ceb28521932">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6375a906-bc79-45cb-aeec-0ceb28521932">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6375a906-bc79-45cb-aeec-0ceb28521932">
											<gml:posList>35.66844877035487 139.73937499400247 34.619 35.66844877035487 139.73937499400247 33.887 35.66840946638073 139.73933509776663 33.887 35.66840946638073 139.73933509776663 34.619 35.66844877035487 139.73937499400247 34.619</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1aa874ee-5ac6-47a6-98da-946b32b48fe1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1aa874ee-5ac6-47a6-98da-946b32b48fe1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1aa874ee-5ac6-47a6-98da-946b32b48fe1">
											<gml:posList>35.66843880825132 139.7392916968053 34.619 35.66843880825132 139.7392916968053 33.887 35.66846641215906 139.7393197212595 33.887 35.66846641215906 139.7393197212595 34.619 35.66843880825132 139.7392916968053 34.619</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5d63bcf1-d8fd-4662-b6d4-e45ad4c00857">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5d63bcf1-d8fd-4662-b6d4-e45ad4c00857">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5d63bcf1-d8fd-4662-b6d4-e45ad4c00857">
											<gml:posList>35.66846861128381 139.73931943148517 11.474 35.668438598804826 139.73928896869097 11.474 35.668438598804826 139.73928896869097 34.619 35.66846861128381 139.73931943148517 34.619 35.66846861128381 139.73931943148517 11.474</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-21855f42-8b4d-4bbb-ac78-b73abf54a1f6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-21855f42-8b4d-4bbb-ac78-b73abf54a1f6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-21855f42-8b4d-4bbb-ac78-b73abf54a1f6">
											<gml:posList>35.66846601184696 139.73934961219302 34.619 35.66846601184696 139.73934961219302 33.887 35.66844877035487 139.73937499400247 33.887 35.66844877035487 139.73937499400247 34.619 35.66846601184696 139.73934961219302 34.619</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-066872ae-55bf-4f1d-8307-7e8074c24970">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-066872ae-55bf-4f1d-8307-7e8074c24970">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-066872ae-55bf-4f1d-8307-7e8074c24970">
											<gml:posList>35.66846825605764 139.73934934445865 30.004 35.66846825605764 139.73934934445865 34.619 35.66844897979079 139.7393777110714 34.619 35.66844897979079 139.7393777110714 30.004 35.66846825605764 139.73934934445865 30.004</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8be49062-dc11-4588-ace4-6883742e2569">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8be49062-dc11-4588-ace4-6883742e2569">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8be49062-dc11-4588-ace4-6883742e2569">
											<gml:posList>35.668454483391066 139.73933820414783 34.619 35.668454483391066 139.73933820414783 33.887 35.66846601184696 139.73934961219302 33.887 35.66846601184696 139.73934961219302 34.619 35.668454483391066 139.73933820414783 34.619</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7b100a19-5986-4cb7-b660-a86815b11631">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7b100a19-5986-4cb7-b660-a86815b11631">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7b100a19-5986-4cb7-b660-a86815b11631">
											<gml:posList>35.66846641215906 139.7393197212595 34.619 35.66846641215906 139.7393197212595 33.887 35.668454483391066 139.73933820414783 33.887 35.668454483391066 139.73933820414783 34.619 35.66846641215906 139.7393197212595 34.619</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-10f9e7e5-82ad-420a-aae7-f4d9047d1804">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-10f9e7e5-82ad-420a-aae7-f4d9047d1804">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-10f9e7e5-82ad-420a-aae7-f4d9047d1804">
											<gml:posList>35.66845669152096 139.73933790331748 11.474 35.66846861128381 139.73931943148517 11.474 35.66846861128381 139.73931943148517 34.619 35.66845669152096 139.73933790331748 34.619 35.66845669152096 139.73933790331748 11.474</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-67d0849b-51ba-44ce-bbd4-93c14b956969">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-67d0849b-51ba-44ce-bbd4-93c14b956969">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-67d0849b-51ba-44ce-bbd4-93c14b956969">
											<gml:posList>35.668430981611905 139.7394614939092 11.474 35.668503242446235 139.73935458343885 11.474 35.668503242446235 139.73935458343885 27.893 35.66849110579703 139.73937234858417 27.903 35.66849117796717 139.73937242582159 30.004 35.66845885597068 139.73942024867023 30.004 35.668430981611905 139.7394614939092 22.1 35.668430981611905 139.7394614939092 11.474</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-39e36a20-30f9-4a3c-bee0-59f252581c13">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-39e36a20-30f9-4a3c-bee0-59f252581c13">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-39e36a20-30f9-4a3c-bee0-59f252581c13">
											<gml:posList>35.66845669152096 139.73933790331748 11.474 35.66845669152096 139.73933790331748 34.619 35.66846825605764 139.73934934445865 34.619 35.66846825605764 139.73934934445865 30.004 35.66849117796717 139.73937242582159 30.004 35.66849110579703 139.73937234858417 27.903 35.668476798684985 139.73935782881748 27.893 35.668476798684985 139.73935782881748 11.474 35.66845669152096 139.73933790331748 11.474</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-318efaa7-6702-405a-b103-487d0e5a799d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-318efaa7-6702-405a-b103-487d0e5a799d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-318efaa7-6702-405a-b103-487d0e5a799d">
											<gml:posList>35.668476798684985 139.73935782881748 27.893 35.668488854148194 139.73933998644634 27.893 35.668488854148194 139.73933998644634 11.474 35.668476798684985 139.73935782881748 11.474 35.668476798684985 139.73935782881748 27.893</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b414b49c-a5a1-41ae-aeee-cbd61bc44411">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b414b49c-a5a1-41ae-aeee-cbd61bc44411">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b414b49c-a5a1-41ae-aeee-cbd61bc44411">
											<gml:posList>35.668488854148194 139.73933998644634 27.893 35.668503242446235 139.73935458343885 27.893 35.668503242446235 139.73935458343885 11.474 35.668488854148194 139.73933998644634 11.474 35.668488854148194 139.73933998644634 27.893</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-6072</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">211</uro:landUseType>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>4</uro:specifiedFloorAreaRate>
					<uro:surveyYear>0001</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.1</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>