<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_d16d2815-12ea-47d0-8c76-524558d3fa60">
			<core:creationDate>2024-03-15</core:creationDate>
			<bldg:measuredHeight uom="m">10.1</bldg:measuredHeight>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.67164390063782 139.74455002767124 0 35.67161623189182 139.74455464257971 0 35.67161932608365 139.74458246511205 0 35.67164699483074 139.744577850213 0 35.67164390063782 139.74455002767124 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67164390063782 139.74455002767124 8.9 35.67164699483074 139.744577850213 8.9 35.67161932608365 139.74458246511205 8.9 35.67161623189182 139.74455464257971 8.9 35.67164390063782 139.74455002767124 8.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67164390063782 139.74455002767124 8.9 35.67161623189182 139.74455464257971 8.9 35.67161623189182 139.74455464257971 18.99 35.67164390063782 139.74455002767124 18.99 35.67164390063782 139.74455002767124 8.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67161623189182 139.74455464257971 8.9 35.67161932608365 139.74458246511205 8.9 35.67161932608365 139.74458246511205 18.99 35.67161623189182 139.74455464257971 18.99 35.67161623189182 139.74455464257971 8.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67161932608365 139.74458246511205 8.9 35.67164699483074 139.744577850213 8.9 35.67164699483074 139.744577850213 18.99 35.67161932608365 139.74458246511205 18.99 35.67161932608365 139.74458246511205 8.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67164699483074 139.744577850213 8.9 35.67164390063782 139.74455002767124 8.9 35.67164390063782 139.74455002767124 18.99 35.67164699483074 139.744577850213 18.99 35.67164699483074 139.744577850213 8.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67164390063782 139.74455002767124 18.99 35.67161623189182 139.74455464257971 18.99 35.67161932608365 139.74458246511205 18.99 35.67164699483074 139.744577850213 18.99 35.67164390063782 139.74455002767124 18.99</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-3b3e317c-4737-488f-b41a-e98fd336a653"/>
							<gml:surfaceMember xlink:href="#poly-6d781567-a4f9-4630-beae-a7dbd99c99a2"/>
							<gml:surfaceMember xlink:href="#poly-9d8c42e4-2c72-4ed2-a77e-a236f40f4184"/>
							<gml:surfaceMember xlink:href="#poly-c225f73d-1589-45a9-ae03-38efafbaed88"/>
							<gml:surfaceMember xlink:href="#poly-cf14a60d-c9c2-4283-8efd-df5d15b8c830"/>
							<gml:surfaceMember xlink:href="#poly-f61521de-d0c4-4719-b15f-b917b6bd984e"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-3b3e317c-4737-488f-b41a-e98fd336a653">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3b3e317c-4737-488f-b41a-e98fd336a653">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3b3e317c-4737-488f-b41a-e98fd336a653">
											<gml:posList>35.67164390063781 139.74455002767124 8.9 35.67164699483073 139.744577850213 8.9 35.67161932608365 139.74458246511205 8.9 35.6716162318918 139.74455464257971 8.9 35.67164390063781 139.74455002767124 8.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-6d781567-a4f9-4630-beae-a7dbd99c99a2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6d781567-a4f9-4630-beae-a7dbd99c99a2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6d781567-a4f9-4630-beae-a7dbd99c99a2">
											<gml:posList>35.67164699483073 139.744577850213 19.221 35.67164390063781 139.74455002767124 18.409 35.6716162318918 139.74455464257971 18.409 35.67161932608365 139.74458246511205 19.221 35.67164699483073 139.744577850213 19.221</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9d8c42e4-2c72-4ed2-a77e-a236f40f4184">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9d8c42e4-2c72-4ed2-a77e-a236f40f4184">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9d8c42e4-2c72-4ed2-a77e-a236f40f4184">
											<gml:posList>35.67164390063781 139.74455002767124 8.9 35.6716162318918 139.74455464257971 8.9 35.6716162318918 139.74455464257971 18.409 35.67164390063781 139.74455002767124 18.409 35.67164390063781 139.74455002767124 8.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c225f73d-1589-45a9-ae03-38efafbaed88">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c225f73d-1589-45a9-ae03-38efafbaed88">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c225f73d-1589-45a9-ae03-38efafbaed88">
											<gml:posList>35.67164699483073 139.744577850213 8.9 35.67164390063781 139.74455002767124 8.9 35.67164390063781 139.74455002767124 18.409 35.67164699483073 139.744577850213 19.221 35.67164699483073 139.744577850213 8.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-cf14a60d-c9c2-4283-8efd-df5d15b8c830">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cf14a60d-c9c2-4283-8efd-df5d15b8c830">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cf14a60d-c9c2-4283-8efd-df5d15b8c830">
											<gml:posList>35.6716162318918 139.74455464257971 18.409 35.6716162318918 139.74455464257971 8.9 35.67161932608365 139.74458246511205 8.9 35.67161932608365 139.74458246511205 19.221 35.6716162318918 139.74455464257971 18.409</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f61521de-d0c4-4719-b15f-b917b6bd984e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f61521de-d0c4-4719-b15f-b917b6bd984e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f61521de-d0c4-4719-b15f-b917b6bd984e">
											<gml:posList>35.67161932608365 139.74458246511205 8.9 35.67164699483073 139.744577850213 8.9 35.67164699483073 139.744577850213 19.221 35.67161932608365 139.74458246511205 19.221 35.67161932608365 139.74458246511205 8.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13101-bldg-1362</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13101</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>7</uro:specifiedFloorAreaRate>
					<uro:surveyYear>0001</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>