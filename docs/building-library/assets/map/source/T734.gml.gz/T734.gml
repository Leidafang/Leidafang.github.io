<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_d19b0f9b-e0aa-470b-aebc-a8992bcac2e0">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001001</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">401</bldg:usage>
			<bldg:measuredHeight uom="m">33.1</bldg:measuredHeight>
			<bldg:storeysAboveGround>9</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.668699768127034 139.74117291590557 0 35.66876051600866 139.74122570136694 0 35.668776098223965 139.74119883054757 0 35.66886162324093 139.74127309428445 0 35.66894858164147 139.74112376214222 0 35.6688179732682 139.7410069347333 0 35.66868942181467 139.741104177328 0 35.66868337261964 139.74111466696445 0 35.66871674557231 139.74114358022743 0 35.668699768127034 139.74117291590557 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668699768127034 139.74117291590557 10.3 35.66871674557231 139.74114358022743 10.3 35.66868337261964 139.74111466696445 10.3 35.66868942181467 139.741104177328 10.3 35.6688179732682 139.7410069347333 10.3 35.66894858164147 139.74112376214222 10.3 35.66886162324093 139.74127309428445 10.3 35.668776098223965 139.74119883054757 10.3 35.66876051600866 139.74122570136694 10.3 35.668699768127034 139.74117291590557 10.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668699768127034 139.74117291590557 10.3 35.66876051600866 139.74122570136694 10.3 35.66876051600866 139.74122570136694 43.39 35.668699768127034 139.74117291590557 43.39 35.668699768127034 139.74117291590557 10.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66876051600866 139.74122570136694 10.3 35.668776098223965 139.74119883054757 10.3 35.668776098223965 139.74119883054757 43.39 35.66876051600866 139.74122570136694 43.39 35.66876051600866 139.74122570136694 10.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668776098223965 139.74119883054757 10.3 35.66886162324093 139.74127309428445 10.3 35.66886162324093 139.74127309428445 43.39 35.668776098223965 139.74119883054757 43.39 35.668776098223965 139.74119883054757 10.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66886162324093 139.74127309428445 10.3 35.66894858164147 139.74112376214222 10.3 35.66894858164147 139.74112376214222 43.39 35.66886162324093 139.74127309428445 43.39 35.66886162324093 139.74127309428445 10.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66894858164147 139.74112376214222 10.3 35.6688179732682 139.7410069347333 10.3 35.6688179732682 139.7410069347333 43.39 35.66894858164147 139.74112376214222 43.39 35.66894858164147 139.74112376214222 10.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6688179732682 139.7410069347333 10.3 35.66868942181467 139.741104177328 10.3 35.66868942181467 139.741104177328 43.39 35.6688179732682 139.7410069347333 43.39 35.6688179732682 139.7410069347333 10.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66868942181467 139.741104177328 10.3 35.66868337261964 139.74111466696445 10.3 35.66868337261964 139.74111466696445 43.39 35.66868942181467 139.741104177328 43.39 35.66868942181467 139.741104177328 10.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66868337261964 139.74111466696445 10.3 35.66871674557231 139.74114358022743 10.3 35.66871674557231 139.74114358022743 43.39 35.66868337261964 139.74111466696445 43.39 35.66868337261964 139.74111466696445 10.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66871674557231 139.74114358022743 10.3 35.668699768127034 139.74117291590557 10.3 35.668699768127034 139.74117291590557 43.39 35.66871674557231 139.74114358022743 43.39 35.66871674557231 139.74114358022743 10.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668699768127034 139.74117291590557 43.39 35.66876051600866 139.74122570136694 43.39 35.668776098223965 139.74119883054757 43.39 35.66886162324093 139.74127309428445 43.39 35.66894858164147 139.74112376214222 43.39 35.6688179732682 139.7410069347333 43.39 35.66868942181467 139.741104177328 43.39 35.66868337261964 139.74111466696445 43.39 35.66871674557231 139.74114358022743 43.39 35.668699768127034 139.74117291590557 43.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-c8a3a829-d6c3-43a3-b68b-4dfc45e385f8"/>
							<gml:surfaceMember xlink:href="#poly-194f6c3a-c5e5-4921-a83a-f651ea6aa4a1"/>
							<gml:surfaceMember xlink:href="#poly-eea58c12-37a9-472f-a088-d9787cd9a9ef"/>
							<gml:surfaceMember xlink:href="#poly-244742e3-2b2d-4645-98cc-561f839a4802"/>
							<gml:surfaceMember xlink:href="#poly-543954c3-2475-457a-b8bb-be6236335736"/>
							<gml:surfaceMember xlink:href="#poly-5b9fc00f-9ca0-40a8-997c-d00b85d98dee"/>
							<gml:surfaceMember xlink:href="#poly-0ffff80e-1f6e-4570-8af1-1bf502fe52ec"/>
							<gml:surfaceMember xlink:href="#poly-323303d0-3e97-42fc-aeda-2d964a5d0888"/>
							<gml:surfaceMember xlink:href="#poly-b4e1263b-6b10-44a2-bda2-69a7658f50ec"/>
							<gml:surfaceMember xlink:href="#poly-18e3b142-b156-4d5e-9632-0b4344f15156"/>
							<gml:surfaceMember xlink:href="#poly-64c203b9-36dd-43a5-af7a-56e1d1f4ffb1"/>
							<gml:surfaceMember xlink:href="#poly-1dce4f41-fd49-48cb-8f9e-fbcec7ab315c"/>
							<gml:surfaceMember xlink:href="#poly-67a1511b-e5b0-422f-8a52-6d6174b2bca2"/>
							<gml:surfaceMember xlink:href="#poly-e3ccc0b0-bc3a-48c7-8337-f10292f7ed08"/>
							<gml:surfaceMember xlink:href="#poly-830f507d-def1-474c-8930-ab879c892c39"/>
							<gml:surfaceMember xlink:href="#poly-03bd6a7a-2fdd-4afc-a02a-2aab12a0b67d"/>
							<gml:surfaceMember xlink:href="#poly-ddd9b065-1108-41c5-9924-50cd31caa517"/>
							<gml:surfaceMember xlink:href="#poly-688b39e7-9a25-4361-9a5f-f19699ec7448"/>
							<gml:surfaceMember xlink:href="#poly-7a5509ca-e167-444f-be7d-d1ff2b699bdd"/>
							<gml:surfaceMember xlink:href="#poly-4819d38e-a1af-470c-a2ef-1b01508b6f64"/>
							<gml:surfaceMember xlink:href="#poly-1ffa6cac-f63a-482f-be98-3a8ee6516999"/>
							<gml:surfaceMember xlink:href="#poly-986df9da-0212-4335-a1da-7bf0ad54b0c4"/>
							<gml:surfaceMember xlink:href="#poly-9a2e2ebe-1c1d-46d9-88e9-bd593d9ba9ae"/>
							<gml:surfaceMember xlink:href="#poly-eeabfb58-9b15-4bbc-a828-12a62d73430a"/>
							<gml:surfaceMember xlink:href="#poly-cb63a202-0097-499b-9260-9f0aae89b6f3"/>
							<gml:surfaceMember xlink:href="#poly-2c234c0c-e1f8-4d83-8b38-81aa3be2b872"/>
							<gml:surfaceMember xlink:href="#poly-011128e1-ded6-4ddd-b2ce-2467bb51dd06"/>
							<gml:surfaceMember xlink:href="#poly-2c1de54d-82d1-4b7f-99cd-fddcb6b69e9a"/>
							<gml:surfaceMember xlink:href="#poly-c9e48c17-2f7f-4d05-88f6-75d12e1eaf52"/>
							<gml:surfaceMember xlink:href="#poly-65b4b2e5-61e2-44bd-8b91-7b7447a1bbb3"/>
							<gml:surfaceMember xlink:href="#poly-5892efd9-a606-4bbd-8d05-297bffef8ea5"/>
							<gml:surfaceMember xlink:href="#poly-81e15b2c-db66-49e0-9572-9d2b6fa1f86d"/>
							<gml:surfaceMember xlink:href="#poly-927537fa-0e0f-45b7-a075-f63d7b678b97"/>
							<gml:surfaceMember xlink:href="#poly-96319fd9-ce6a-49d2-9c8f-648df2ee9986"/>
							<gml:surfaceMember xlink:href="#poly-30f38042-fc0f-46ba-87dc-5259cb86ce35"/>
							<gml:surfaceMember xlink:href="#poly-fed22e85-3d7e-4e3e-aec7-32d49a59ef5d"/>
							<gml:surfaceMember xlink:href="#poly-15723f69-1a0e-410a-93db-9f01f9b4df38"/>
							<gml:surfaceMember xlink:href="#poly-5059dd0e-c7e0-4f19-898f-ba404ba88845"/>
							<gml:surfaceMember xlink:href="#poly-f0412f74-c6b2-478c-9f35-414db485c3eb"/>
							<gml:surfaceMember xlink:href="#poly-396fc65a-80e3-47d8-a214-1d3ee3660c48"/>
							<gml:surfaceMember xlink:href="#poly-5fce998e-bf23-4cdb-bd65-03ed7de5fea0"/>
							<gml:surfaceMember xlink:href="#poly-81f2d8c8-657a-43ec-a014-1577e291a7f2"/>
							<gml:surfaceMember xlink:href="#poly-2f6262a2-1f6c-4604-9588-70ceb142bcfc"/>
							<gml:surfaceMember xlink:href="#poly-f81dfe3c-01df-4a8b-bbb3-3024747bc95c"/>
							<gml:surfaceMember xlink:href="#poly-e2a9e54a-979b-46eb-9c6e-9ccd37c9a859"/>
							<gml:surfaceMember xlink:href="#poly-37a7e77f-dc2c-4e67-a4ca-1e5119cd5cdd"/>
							<gml:surfaceMember xlink:href="#poly-625e3da5-9952-4203-9c27-ade983d78c73"/>
							<gml:surfaceMember xlink:href="#poly-c740c28b-b535-4a63-8fbe-77d6a7f307f3"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_d19b0f9b-e0aa-470b-aebc-a8992bcac2e0_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3c67c1a6-47fb-4fbf-bb8a-b288f40152cd">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668724439414696 139.74111496216008 48.593 35.66873029055307 139.74110479308104 48.593 35.66874492952418 139.741117434998 48.593 35.66873908739849 139.74112760406763 48.593 35.668724439414696 139.74111496216008 48.593</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8aece79c-fa36-4a1d-8f99-5e09027c7114">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6687392625686 139.7411444822053 48.593 35.668747337917495 139.74113146069206 48.593 35.66875595217381 139.74113948125446 48.593 35.668747876824064 139.74115250276833 48.593 35.6687392625686 139.7411444822053 48.593</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-873128e8-7e6b-4e89-838f-769e36593ba6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66875073688409 139.74112072003751 48.593 35.66875725390496 139.74110907002085 48.593 35.66876552482063 139.74111601951114 48.593 35.66875900779911 139.74112766952845 48.593 35.66875073688409 139.74112072003751 48.593</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1722cef3-229b-4bb6-9cb9-9db9260d5179">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66877437462175 139.74109028310986 48.593 35.66878061593576 139.74109525769342 48.593 35.66877675460644 139.74110251938265 48.593 35.668770522298 139.74109753374242 48.593 35.66877437462175 139.74109028310986 48.593</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4872f99d-444f-4bc1-8aa2-69dd0346cab0">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66879938749778 139.74108997818357 43.392 35.66878846437902 139.74108020395815 43.392 35.66879822269751 139.74106380040507 43.392 35.668809154831294 139.74107357461912 43.392 35.66882330706434 139.74108621710275 43.392 35.66881353972912 139.74110262066858 43.392 35.66879938749778 139.74108997818357 43.392</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-61f51b2b-bbd3-468f-8d9c-ef8aead4436a">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66883845377155 139.7410674324429 43.392 35.66883333193577 139.74107654027887 43.392 35.66881060260426 139.74105732422362 43.392 35.66881572444708 139.74104822743507 43.392 35.66883845377155 139.7410674324429 43.392</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b9d018ae-428c-4ea4-a8f3-a74a50e3c6d8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668833005162874 139.7411206364719 43.392 35.66884414044622 139.74110143668065 43.392 35.66886970241491 139.74112369820895 43.392 35.66885856712806 139.74114289800323 43.392 35.668833005162874 139.7411206364719 43.392</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5bc1eac8-aa65-4fb0-b41a-6da2f9a29f35">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66890487043182 139.7411543547559 43.392 35.6688934827474 139.7411735437984 43.392 35.668869020809154 139.74115173387108 43.392 35.66888040849015 139.74113254483134 43.392 35.66890487043182 139.7411543547559 43.392</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9695fca7-bb11-4bbb-80b1-e7e0846979a5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66886831637872 139.7412324150391 43.392 35.66887761631916 139.7412177131069 43.392 35.66888439958356 139.74122416725533 43.392 35.66887510864762 139.74123885813162 43.392 35.66886831637872 139.7412324150391 43.392</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-20a3a483-7a3d-434b-905d-2fc550673fca">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66885645963018 139.74125116275843 43.392 35.66886680390623 139.74123481376947 43.392 35.66887358716128 139.74124125687243 43.392 35.66886325189809 139.74125760585162 43.392 35.66885645963018 139.74125116275843 43.392</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d41afef2-761e-4f61-9c0c-4d51785246e6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d41afef2-761e-4f61-9c0c-4d51785246e6_0">
											<gml:posList>35.66886680390623 139.74123481376947 43.392 35.66886680390623 139.74123481376947 45.031 35.66887358716128 139.74124125687243 45.031 35.66887358716128 139.74124125687243 43.392 35.66886680390623 139.74123481376947 43.392</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6def8474-a1bf-40ec-9ab2-b41ee6618012">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6def8474-a1bf-40ec-9ab2-b41ee6618012_0">
											<gml:posList>35.668809154831294 139.74107357461912 43.392 35.66879822269751 139.74106380040507 43.392 35.66879822269751 139.74106380040507 45.932 35.668809154831294 139.74107357461912 45.932 35.668809154831294 139.74107357461912 43.392</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a8fe2f8d-d916-4aa6-9eda-aa4f2ac434df">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a8fe2f8d-d916-4aa6-9eda-aa4f2ac434df_0">
											<gml:posList>35.66879822269751 139.74106380040507 43.392 35.66878846437902 139.74108020395815 43.392 35.66878846437902 139.74108020395815 45.932 35.66879822269751 139.74106380040507 45.932 35.66879822269751 139.74106380040507 43.392</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8684447d-f935-4808-ac23-614d5285477d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8684447d-f935-4808-ac23-614d5285477d_0">
											<gml:posList>35.66878846437902 139.74108020395815 45.932 35.66879938749778 139.74108997818357 45.932 35.668809154831294 139.74107357461912 45.932 35.66879822269751 139.74106380040507 45.932 35.66878846437902 139.74108020395815 45.932</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-778a4b17-8456-4c4e-923e-323b3b7166e4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-778a4b17-8456-4c4e-923e-323b3b7166e4_0">
											<gml:posList>35.668809154831294 139.74107357461912 45.932 35.66879938749778 139.74108997818357 45.932 35.66879938749778 139.74108997818357 47.223 35.668809154831294 139.74107357461912 47.223 35.668809154831294 139.74107357461912 45.932</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ae875f38-1b0c-40bc-987e-121a1b3f98f1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ae875f38-1b0c-40bc-987e-121a1b3f98f1_0">
											<gml:posList>35.66879938749778 139.74108997818357 45.932 35.66878846437902 139.74108020395815 45.932 35.66878846437902 139.74108020395815 43.392 35.66879938749778 139.74108997818357 43.392 35.66879938749778 139.74108997818357 45.932</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0f1a6dab-d2e9-4ac1-8820-9e443c617b0f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0f1a6dab-d2e9-4ac1-8820-9e443c617b0f_0">
											<gml:posList>35.66878061593576 139.74109525769342 48.593 35.66877437462175 139.74109028310986 48.593 35.66877437462175 139.74109028310986 49.958 35.66878061593576 139.74109525769342 49.958 35.66878061593576 139.74109525769342 48.593</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fee8c90b-9b93-4969-ae73-5aa8d0a43465">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fee8c90b-9b93-4969-ae73-5aa8d0a43465_0">
											<gml:posList>35.66877437462175 139.74109028310986 48.593 35.668770522298 139.74109753374242 48.593 35.668770522298 139.74109753374242 49.958 35.66877437462175 139.74109028310986 49.958 35.66877437462175 139.74109028310986 48.593</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5be7ef10-96b2-498c-b47f-6b8057ff2a80">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5be7ef10-96b2-498c-b47f-6b8057ff2a80_0">
											<gml:posList>35.66879938749778 139.74108997818357 45.932 35.66879938749778 139.74108997818357 43.392 35.66881353972912 139.74110262066858 43.392 35.66881353972912 139.74110262066858 47.223 35.66879938749778 139.74108997818357 47.223 35.66879938749778 139.74108997818357 45.932</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0d52a2fc-70dc-435a-af54-62d825a39e93">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0d52a2fc-70dc-435a-af54-62d825a39e93_0">
											<gml:posList>35.66877675460644 139.74110251938265 49.958 35.66878061593576 139.74109525769342 49.958 35.66877437462175 139.74109028310986 49.958 35.668770522298 139.74109753374242 49.958 35.66877675460644 139.74110251938265 49.958</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a0ca9842-bf39-42d5-8480-3623c714a73e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a0ca9842-bf39-42d5-8480-3623c714a73e_0">
											<gml:posList>35.66877675460644 139.74110251938265 48.593 35.66878061593576 139.74109525769342 48.593 35.66878061593576 139.74109525769342 49.958 35.66877675460644 139.74110251938265 49.958 35.66877675460644 139.74110251938265 48.593</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f3b1e740-60bb-4949-9ba0-df62c3b99049">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f3b1e740-60bb-4949-9ba0-df62c3b99049_0">
											<gml:posList>35.668770522298 139.74109753374242 48.593 35.66877675460644 139.74110251938265 48.593 35.66877675460644 139.74110251938265 49.958 35.668770522298 139.74109753374242 49.958 35.668770522298 139.74109753374242 48.593</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a03f9b1b-6dd6-4ca4-ab63-ce288e3e6d8f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a03f9b1b-6dd6-4ca4-ab63-ce288e3e6d8f_0">
											<gml:posList>35.668724439414696 139.74111496216008 48.593 35.668724439414696 139.74111496216008 50.254 35.66873029055307 139.74110479308104 50.254 35.66873029055307 139.74110479308104 48.593 35.668724439414696 139.74111496216008 48.593</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9f021ed5-7165-49e8-83ab-f1d8d1e4a2a5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9f021ed5-7165-49e8-83ab-f1d8d1e4a2a5_0">
											<gml:posList>35.66873029055307 139.74110479308104 48.593 35.66873029055307 139.74110479308104 50.254 35.66874492952418 139.741117434998 50.254 35.66874492952418 139.741117434998 48.593 35.66873029055307 139.74110479308104 48.593</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3114d5c8-1169-4bde-b99e-525c87f8bbbb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3114d5c8-1169-4bde-b99e-525c87f8bbbb_0">
											<gml:posList>35.66876552482063 139.74111601951114 48.593 35.66875725390496 139.74110907002085 48.593 35.66875725390496 139.74110907002085 49.958 35.66876552482063 139.74111601951114 49.958 35.66876552482063 139.74111601951114 48.593</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-efa84b86-a87b-4a74-bc58-70e8aa8f5151">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-efa84b86-a87b-4a74-bc58-70e8aa8f5151_0">
											<gml:posList>35.66875073688409 139.74112072003751 48.593 35.66875073688409 139.74112072003751 49.958 35.66875725390496 139.74110907002085 49.958 35.66875725390496 139.74110907002085 48.593 35.66875073688409 139.74112072003751 48.593</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-aa54fb25-169c-4037-b721-5e3ff0ac65b2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-aa54fb25-169c-4037-b721-5e3ff0ac65b2_0">
											<gml:posList>35.668724439414696 139.74111496216008 50.254 35.66873908739849 139.74112760406763 50.254 35.66874492952418 139.741117434998 50.254 35.66873029055307 139.74110479308104 50.254 35.668724439414696 139.74111496216008 50.254</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a1fbf25d-b97a-43d2-ae63-14b7d25ea92d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a1fbf25d-b97a-43d2-ae63-14b7d25ea92d_0">
											<gml:posList>35.66876552482063 139.74111601951114 49.958 35.66875725390496 139.74110907002085 49.958 35.66875073688409 139.74112072003751 49.958 35.66875900779911 139.74112766952845 49.958 35.66876552482063 139.74111601951114 49.958</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7e9990d8-3e98-46a9-a456-26124170caf3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7e9990d8-3e98-46a9-a456-26124170caf3_0">
											<gml:posList>35.668724439414696 139.74111496216008 48.593 35.66873908739849 139.74112760406763 48.593 35.66873908739849 139.74112760406763 50.254 35.668724439414696 139.74111496216008 50.254 35.668724439414696 139.74111496216008 48.593</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-517e5f56-b6d0-443c-8a3a-7f79386138da">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-517e5f56-b6d0-443c-8a3a-7f79386138da_0">
											<gml:posList>35.66876552482063 139.74111601951114 48.593 35.66876552482063 139.74111601951114 49.958 35.66875900779911 139.74112766952845 49.958 35.66875900779911 139.74112766952845 48.593 35.66876552482063 139.74111601951114 48.593</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b2d4952a-907a-4180-bf17-662e44d4270a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b2d4952a-907a-4180-bf17-662e44d4270a_0">
											<gml:posList>35.66874492952418 139.741117434998 48.593 35.66874492952418 139.741117434998 50.254 35.66873908739849 139.74112760406763 50.254 35.66873908739849 139.74112760406763 48.593 35.66874492952418 139.741117434998 48.593</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b8f01caa-4eb6-4a72-b859-31d6b9c7c4fe">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b8f01caa-4eb6-4a72-b859-31d6b9c7c4fe_0">
											<gml:posList>35.66875073688409 139.74112072003751 48.593 35.66875900779911 139.74112766952845 48.593 35.66875900779911 139.74112766952845 49.958 35.66875073688409 139.74112072003751 49.958 35.66875073688409 139.74112072003751 48.593</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6575c4de-2fb4-4ad6-be7e-f2de309425f7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6575c4de-2fb4-4ad6-be7e-f2de309425f7_0">
											<gml:posList>35.66875595217381 139.74113948125446 48.593 35.668747337917495 139.74113146069206 48.593 35.668747337917495 139.74113146069206 49.958 35.66875595217381 139.74113948125446 49.958 35.66875595217381 139.74113948125446 48.593</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fd17c53b-b195-405a-8af8-dde96497573b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fd17c53b-b195-405a-8af8-dde96497573b_0">
											<gml:posList>35.6687392625686 139.7411444822053 48.593 35.6687392625686 139.7411444822053 49.958 35.668747337917495 139.74113146069206 49.958 35.668747337917495 139.74113146069206 48.593 35.6687392625686 139.7411444822053 48.593</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e069565c-f5dc-4782-b44e-66e5b46d7b73">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e069565c-f5dc-4782-b44e-66e5b46d7b73_0">
											<gml:posList>35.66875595217381 139.74113948125446 49.958 35.668747337917495 139.74113146069206 49.958 35.6687392625686 139.7411444822053 49.958 35.668747876824064 139.74115250276833 49.958 35.66875595217381 139.74113948125446 49.958</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5fc42801-8a83-473b-8dfd-38c762ced62b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5fc42801-8a83-473b-8dfd-38c762ced62b_0">
											<gml:posList>35.668747876824064 139.74115250276833 48.593 35.66875595217381 139.74113948125446 48.593 35.66875595217381 139.74113948125446 49.958 35.668747876824064 139.74115250276833 49.958 35.668747876824064 139.74115250276833 48.593</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9e582e0d-1ba4-43cc-a184-6372ff7a0767">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9e582e0d-1ba4-43cc-a184-6372ff7a0767_0">
											<gml:posList>35.6687392625686 139.7411444822053 48.593 35.668747876824064 139.74115250276833 48.593 35.668747876824064 139.74115250276833 49.958 35.6687392625686 139.7411444822053 49.958 35.6687392625686 139.7411444822053 48.593</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-235c7ac0-d24e-4dc8-a6cf-799712e6ad72">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-235c7ac0-d24e-4dc8-a6cf-799712e6ad72_0">
											<gml:posList>35.66881572444708 139.74104822743507 43.392 35.66881060260426 139.74105732422362 43.392 35.66881060260426 139.74105732422362 45.366 35.66881572444708 139.74104822743507 45.366 35.66881572444708 139.74104822743507 43.392</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-55f0a0c0-e6f7-44c1-9321-124a16eaf825">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-55f0a0c0-e6f7-44c1-9321-124a16eaf825_0">
											<gml:posList>35.66883845377155 139.7410674324429 43.392 35.66881572444708 139.74104822743507 43.392 35.66881572444708 139.74104822743507 45.366 35.66883845377155 139.7410674324429 45.366 35.66883845377155 139.7410674324429 43.392</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a8404f46-2c68-47bc-8bb1-2820993ebd07">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a8404f46-2c68-47bc-8bb1-2820993ebd07_0">
											<gml:posList>35.66881060260426 139.74105732422362 45.366 35.66883333193577 139.74107654027887 45.366 35.66883845377155 139.7410674324429 45.366 35.66881572444708 139.74104822743507 45.366 35.66881060260426 139.74105732422362 45.366</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7d7e11f0-dcf7-442e-a230-ceb31724f655">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7d7e11f0-dcf7-442e-a230-ceb31724f655_0">
											<gml:posList>35.66883333193577 139.74107654027887 43.392 35.66883333193577 139.74107654027887 45.366 35.66881060260426 139.74105732422362 45.366 35.66881060260426 139.74105732422362 43.392 35.66883333193577 139.74107654027887 43.392</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-db828033-d1d6-4642-a93a-ce4ca6f0b32e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-db828033-d1d6-4642-a93a-ce4ca6f0b32e_0">
											<gml:posList>35.66883333193577 139.74107654027887 43.392 35.66883845377155 139.7410674324429 43.392 35.66883845377155 139.7410674324429 45.366 35.66883333193577 139.74107654027887 45.366 35.66883333193577 139.74107654027887 43.392</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2c5e97a8-f8f5-4d27-9069-be64a450d065">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2c5e97a8-f8f5-4d27-9069-be64a450d065_0">
											<gml:posList>35.66882330706434 139.74108621710275 47.223 35.66882330706434 139.74108621710275 43.392 35.668809154831294 139.74107357461912 43.392 35.668809154831294 139.74107357461912 45.932 35.668809154831294 139.74107357461912 47.223 35.66882330706434 139.74108621710275 47.223</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-54091f13-71cb-45fb-b72e-0f4cd03cd793">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-54091f13-71cb-45fb-b72e-0f4cd03cd793_0">
											<gml:posList>35.66881353972912 139.74110262066858 47.223 35.66882330706434 139.74108621710275 47.223 35.668809154831294 139.74107357461912 47.223 35.66879938749778 139.74108997818357 47.223 35.66881353972912 139.74110262066858 47.223</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1d304cb0-9452-4cf8-8b08-3985567bd1e3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1d304cb0-9452-4cf8-8b08-3985567bd1e3_0">
											<gml:posList>35.66881353972912 139.74110262066858 43.392 35.66882330706434 139.74108621710275 43.392 35.66882330706434 139.74108621710275 47.223 35.66881353972912 139.74110262066858 47.223 35.66881353972912 139.74110262066858 43.392</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fd2eb1ae-abc5-4c2c-9416-1fce1f2dbd4c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fd2eb1ae-abc5-4c2c-9416-1fce1f2dbd4c_0">
											<gml:posList>35.66884414044622 139.74110143668065 43.392 35.668833005162874 139.7411206364719 43.392 35.668833005162874 139.7411206364719 46.597 35.66884414044622 139.74110143668065 46.597 35.66884414044622 139.74110143668065 43.392</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-872d01ff-6c9b-491a-96a3-c3402dc7ff48">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-872d01ff-6c9b-491a-96a3-c3402dc7ff48_0">
											<gml:posList>35.66884414044622 139.74110143668065 43.392 35.66884414044622 139.74110143668065 46.597 35.66886970241491 139.74112369820895 46.597 35.66886970241491 139.74112369820895 43.392 35.66884414044622 139.74110143668065 43.392</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2433bb5a-6b11-4df6-a960-90d8611ef495">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2433bb5a-6b11-4df6-a960-90d8611ef495_0">
											<gml:posList>35.668833005162874 139.7411206364719 46.597 35.66885856712806 139.74114289800323 46.597 35.66886970241491 139.74112369820895 46.597 35.66884414044622 139.74110143668065 46.597 35.668833005162874 139.7411206364719 46.597</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5eb5df5e-4793-4f8a-876b-3a673460cce5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5eb5df5e-4793-4f8a-876b-3a673460cce5_0">
											<gml:posList>35.66885856712806 139.74114289800323 43.392 35.66885856712806 139.74114289800323 46.597 35.668833005162874 139.7411206364719 46.597 35.668833005162874 139.7411206364719 43.392 35.66885856712806 139.74114289800323 43.392</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cd2e3bea-b0f4-42c6-83cf-0d4da16504f1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cd2e3bea-b0f4-42c6-83cf-0d4da16504f1_0">
											<gml:posList>35.66885856712806 139.74114289800323 43.392 35.66886970241491 139.74112369820895 43.392 35.66886970241491 139.74112369820895 46.597 35.66885856712806 139.74114289800323 46.597 35.66885856712806 139.74114289800323 43.392</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-80f014de-ab6a-4e58-ac2a-9d7f01716c28">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-80f014de-ab6a-4e58-ac2a-9d7f01716c28_0">
											<gml:posList>35.66888040849015 139.74113254483134 43.392 35.668869020809154 139.74115173387108 43.392 35.668869020809154 139.74115173387108 46.521 35.66888040849015 139.74113254483134 46.521 35.66888040849015 139.74113254483134 43.392</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2084317a-565b-4cab-972d-8397712636ad">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2084317a-565b-4cab-972d-8397712636ad_0">
											<gml:posList>35.66890487043182 139.7411543547559 43.392 35.66888040849015 139.74113254483134 43.392 35.66888040849015 139.74113254483134 46.521 35.66890487043182 139.7411543547559 46.521 35.66890487043182 139.7411543547559 43.392</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f5fd7729-f59b-4d4d-a293-df77388f597b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f5fd7729-f59b-4d4d-a293-df77388f597b_0">
											<gml:posList>35.668869020809154 139.74115173387108 46.521 35.6688934827474 139.7411735437984 46.521 35.66890487043182 139.7411543547559 46.521 35.66888040849015 139.74113254483134 46.521 35.668869020809154 139.74115173387108 46.521</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9602c479-187f-491e-9087-5f502f48de06">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9602c479-187f-491e-9087-5f502f48de06_0">
											<gml:posList>35.668869020809154 139.74115173387108 43.392 35.6688934827474 139.7411735437984 43.392 35.6688934827474 139.7411735437984 46.521 35.668869020809154 139.74115173387108 46.521 35.668869020809154 139.74115173387108 43.392</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2ef45edb-3e3e-4f65-873b-89248929f72e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2ef45edb-3e3e-4f65-873b-89248929f72e_0">
											<gml:posList>35.66890487043182 139.7411543547559 43.392 35.66890487043182 139.7411543547559 46.521 35.6688934827474 139.7411735437984 46.521 35.6688934827474 139.7411735437984 43.392 35.66890487043182 139.7411543547559 43.392</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a4c33b36-cddd-427c-a45d-d1c2e995ef25">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a4c33b36-cddd-427c-a45d-d1c2e995ef25_0">
											<gml:posList>35.66888439958356 139.74122416725533 43.392 35.66887761631916 139.7412177131069 43.392 35.66887761631916 139.7412177131069 45.031 35.66888439958356 139.74122416725533 45.031 35.66888439958356 139.74122416725533 43.392</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-419985f3-d570-47cd-94b0-d96ddd6f1259">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-419985f3-d570-47cd-94b0-d96ddd6f1259_0">
											<gml:posList>35.66887761631916 139.7412177131069 43.392 35.66886831637872 139.7412324150391 43.392 35.66886831637872 139.7412324150391 45.031 35.66887761631916 139.7412177131069 45.031 35.66887761631916 139.7412177131069 43.392</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-643b8f9c-e93a-4589-9551-47cafce08faf">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-643b8f9c-e93a-4589-9551-47cafce08faf_0">
											<gml:posList>35.66888439958356 139.74122416725533 45.031 35.66887761631916 139.7412177131069 45.031 35.66886831637872 139.7412324150391 45.031 35.66887510864762 139.74123885813162 45.031 35.66888439958356 139.74122416725533 45.031</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c19a0ba1-3b47-40e7-8a27-ece4a3e57882">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c19a0ba1-3b47-40e7-8a27-ece4a3e57882_0">
											<gml:posList>35.66887510864762 139.74123885813162 43.392 35.66888439958356 139.74122416725533 43.392 35.66888439958356 139.74122416725533 45.031 35.66887510864762 139.74123885813162 45.031 35.66887510864762 139.74123885813162 43.392</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d41859ac-890b-41df-856b-ebcb60957cc6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d41859ac-890b-41df-856b-ebcb60957cc6_0">
											<gml:posList>35.66887510864762 139.74123885813162 43.392 35.66887510864762 139.74123885813162 45.031 35.66886831637872 139.7412324150391 45.031 35.66886831637872 139.7412324150391 43.392 35.66887510864762 139.74123885813162 43.392</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-425d2f40-4a9d-44f7-892d-749dbc04c19d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-425d2f40-4a9d-44f7-892d-749dbc04c19d_0">
											<gml:posList>35.66886680390623 139.74123481376947 43.392 35.66885645963018 139.74125116275843 43.392 35.66885645963018 139.74125116275843 45.031 35.66886680390623 139.74123481376947 45.031 35.66886680390623 139.74123481376947 43.392</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3802e1db-76aa-488d-a4ad-450e58a037bc">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3802e1db-76aa-488d-a4ad-450e58a037bc_0">
											<gml:posList>35.66887358716128 139.74124125687243 45.031 35.66886680390623 139.74123481376947 45.031 35.66885645963018 139.74125116275843 45.031 35.66886325189809 139.74125760585162 45.031 35.66887358716128 139.74124125687243 45.031</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4a7a214a-574c-48d9-9b02-b93164018fee">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4a7a214a-574c-48d9-9b02-b93164018fee_0">
											<gml:posList>35.66886325189809 139.74125760585162 43.392 35.66887358716128 139.74124125687243 43.392 35.66887358716128 139.74124125687243 45.031 35.66886325189809 139.74125760585162 45.031 35.66886325189809 139.74125760585162 43.392</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-aba7ca28-10ef-491e-8b0f-78b80f259afc">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-aba7ca28-10ef-491e-8b0f-78b80f259afc_0">
											<gml:posList>35.66886325189809 139.74125760585162 43.392 35.66886325189809 139.74125760585162 45.031 35.66885645963018 139.74125116275843 45.031 35.66885645963018 139.74125116275843 43.392 35.66886325189809 139.74125760585162 43.392</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_d19b0f9b-e0aa-470b-aebc-a8992bcac2e0_BuildingInstallation_1031">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-089ee968-78cb-4b1a-8844-f7518b4bbe5f">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668790651887676 139.74107651206378 43.392 35.6687789169824 139.74106602078285 43.392 35.6687841742434 139.74105719999358 43.392 35.66879590914944 139.7410676912739 43.392 35.668790651887676 139.74107651206378 43.392</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0f24ba48-630a-47b5-b341-3306424becb1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668795883436516 139.7410811895659 45.932 35.668790651887676 139.74107651206378 45.932 35.66879590914944 139.7410676912739 45.932 35.668801131684894 139.74107236878612 45.932 35.668795883436516 139.7410811895659 45.932</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cbfee8ad-4f1a-4e17-a8ea-3da25742b3a7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66876687560075 139.74116143926278 43.392 35.66876563264518 139.7411626668017 43.392 35.66876274935224 139.74116410610088 43.392 35.66876018049971 139.741164186376 43.392 35.66875665566809 139.7411635828958 43.392 35.66874893689228 139.74115963728812 43.392 35.66874945902883 139.74115877509718 43.392 35.66875362724257 139.741152054316 43.392 35.66876009405783 139.74115723851853 43.392 35.668800406742584 139.74109088278647 43.392 35.66880646812048 139.74109629942035 43.392 35.66876687560075 139.74116143926278 43.392</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a159cce9-7385-475f-a283-ad806b949f0a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a159cce9-7385-475f-a283-ad806b949f0a_0">
											<gml:posList>35.6687841742434 139.74105719999358 47.19 35.6687841742434 139.74105719999358 43.392 35.6687789169824 139.74106602078285 43.392 35.6687789169824 139.74106602078285 47.19 35.6687841742434 139.74105719999358 47.19</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f6c224df-614c-4dc8-8991-bc055cd7cd67">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f6c224df-614c-4dc8-8991-bc055cd7cd67_0">
											<gml:posList>35.66879590914944 139.7410676912739 45.932 35.66879590914944 139.7410676912739 43.392 35.6687841742434 139.74105719999358 43.392 35.6687841742434 139.74105719999358 47.19 35.668801131684894 139.74107236878612 47.19 35.668801131684894 139.74107236878612 45.932 35.66879590914944 139.7410676912739 45.932</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2babdac1-c6cf-4553-be4f-b0adead817fc">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2babdac1-c6cf-4553-be4f-b0adead817fc_0">
											<gml:posList>35.668795883436516 139.7410811895659 47.19 35.668801131684894 139.74107236878612 47.19 35.6687841742434 139.74105719999358 47.19 35.6687789169824 139.74106602078285 47.19 35.668795883436516 139.7410811895659 47.19</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-02437537-aac7-46c5-b7e8-a747da8bb73c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-02437537-aac7-46c5-b7e8-a747da8bb73c_0">
											<gml:posList>35.66879590914944 139.7410676912739 45.932 35.668790651887676 139.74107651206378 45.932 35.668790651887676 139.74107651206378 43.392 35.66879590914944 139.7410676912739 43.392 35.66879590914944 139.7410676912739 45.932</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-77530e82-120d-4776-8e03-9cd1a8be0587">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-77530e82-120d-4776-8e03-9cd1a8be0587_0">
											<gml:posList>35.668795883436516 139.7410811895659 47.19 35.6687789169824 139.74106602078285 47.19 35.6687789169824 139.74106602078285 43.392 35.668790651887676 139.74107651206378 43.392 35.668790651887676 139.74107651206378 45.932 35.668795883436516 139.7410811895659 45.932 35.668795883436516 139.7410811895659 47.19</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4b16dcb6-2baa-449f-ba02-4db949861fff">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4b16dcb6-2baa-449f-ba02-4db949861fff_0">
											<gml:posList>35.668801131684894 139.74107236878612 45.932 35.668801131684894 139.74107236878612 47.19 35.668795883436516 139.7410811895659 47.19 35.668795883436516 139.7410811895659 45.932 35.668801131684894 139.74107236878612 45.932</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-43aa5296-ce29-441b-bd9f-bffe9ff50e39">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-43aa5296-ce29-441b-bd9f-bffe9ff50e39_0">
											<gml:posList>35.668800406742584 139.74109088278647 43.392 35.668800406742584 139.74109088278647 46.534 35.66880646812048 139.74109629942035 46.534 35.66880646812048 139.74109629942035 43.392 35.668800406742584 139.74109088278647 43.392</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-147fe9c9-a12f-4541-8a85-d7f2f5ad479d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-147fe9c9-a12f-4541-8a85-d7f2f5ad479d_0">
											<gml:posList>35.66876009405783 139.74115723851853 46.534 35.668800406742584 139.74109088278647 46.534 35.668800406742584 139.74109088278647 43.392 35.66876009405783 139.74115723851853 43.392 35.66876009405783 139.74115723851853 46.534</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ebd328c1-eb7d-4dfa-ad22-a9ae3eb87a20">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ebd328c1-eb7d-4dfa-ad22-a9ae3eb87a20_0">
											<gml:posList>35.668800406742584 139.74109088278647 46.534 35.66876009405783 139.74115723851853 46.534 35.66875362724257 139.741152054316 46.534 35.66874945902883 139.74115877509718 46.534 35.66874893689228 139.74115963728812 46.534 35.66875665566809 139.7411635828958 46.534 35.66876018049971 139.741164186376 46.534 35.66876274935224 139.74116410610088 46.534 35.66876563264518 139.7411626668017 46.534 35.66876687560075 139.74116143926278 46.534 35.66880646812048 139.74109629942035 46.534 35.668800406742584 139.74109088278647 46.534</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0e77419e-f7ee-4c43-9488-5c0062c9f166">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0e77419e-f7ee-4c43-9488-5c0062c9f166_0">
											<gml:posList>35.66880646812048 139.74109629942035 43.392 35.66880646812048 139.74109629942035 46.534 35.66876687560075 139.74116143926278 46.534 35.66876687560075 139.74116143926278 43.392 35.66880646812048 139.74109629942035 43.392</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-186a1ec8-6f15-4ce2-8eea-d661593343cd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-186a1ec8-6f15-4ce2-8eea-d661593343cd_0">
											<gml:posList>35.66875362724257 139.741152054316 46.534 35.66876009405783 139.74115723851853 46.534 35.66876009405783 139.74115723851853 43.392 35.66875362724257 139.741152054316 43.392 35.66875362724257 139.741152054316 46.534</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-690a08ee-2a47-448b-a09e-7a1593a17cff">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-690a08ee-2a47-448b-a09e-7a1593a17cff_0">
											<gml:posList>35.66874945902883 139.74115877509718 43.392 35.66874945902883 139.74115877509718 46.534 35.66875362724257 139.741152054316 46.534 35.66875362724257 139.741152054316 43.392 35.66874945902883 139.74115877509718 43.392</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-81d39c87-8f75-4d47-aec6-c32b19702967">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-81d39c87-8f75-4d47-aec6-c32b19702967_0">
											<gml:posList>35.66874893689228 139.74115963728812 43.392 35.66874893689228 139.74115963728812 46.534 35.66874945902883 139.74115877509718 46.534 35.66874945902883 139.74115877509718 43.392 35.66874893689228 139.74115963728812 43.392</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f4920596-8091-4f81-be67-97e57cb20f69">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f4920596-8091-4f81-be67-97e57cb20f69_0">
											<gml:posList>35.66875665566809 139.7411635828958 43.392 35.66875665566809 139.7411635828958 46.534 35.66874893689228 139.74115963728812 46.534 35.66874893689228 139.74115963728812 43.392 35.66875665566809 139.7411635828958 43.392</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-63353ac1-bb48-4cdf-b5ca-db11b5599d8a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-63353ac1-bb48-4cdf-b5ca-db11b5599d8a_0">
											<gml:posList>35.66876687560075 139.74116143926278 43.392 35.66876687560075 139.74116143926278 46.534 35.66876563264518 139.7411626668017 46.534 35.66876563264518 139.7411626668017 43.392 35.66876687560075 139.74116143926278 43.392</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-27f8e0c6-b271-4e8d-8a27-8f83f7df618e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-27f8e0c6-b271-4e8d-8a27-8f83f7df618e_0">
											<gml:posList>35.66876563264518 139.7411626668017 43.392 35.66876563264518 139.7411626668017 46.534 35.66876274935224 139.74116410610088 46.534 35.66876274935224 139.74116410610088 43.392 35.66876563264518 139.7411626668017 43.392</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-819adb76-996d-47de-a7b3-5f40aa097ba9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-819adb76-996d-47de-a7b3-5f40aa097ba9_0">
											<gml:posList>35.66876018049971 139.741164186376 46.534 35.66875665566809 139.7411635828958 46.534 35.66875665566809 139.7411635828958 43.392 35.66876018049971 139.741164186376 43.392 35.66876018049971 139.741164186376 46.534</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c2a7f462-ad5d-4bed-9f6b-5bec2e80e42a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c2a7f462-ad5d-4bed-9f6b-5bec2e80e42a_0">
											<gml:posList>35.66876274935224 139.74116410610088 43.392 35.66876274935224 139.74116410610088 46.534 35.66876018049971 139.741164186376 46.534 35.66876018049971 139.741164186376 43.392 35.66876274935224 139.74116410610088 43.392</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_d19b0f9b-e0aa-470b-aebc-a8992bcac2e0_BuildingInstallation_1041">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b4b1417a-ed11-4e76-a7c1-fa42f9261087">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66883330796497 139.7411511673959 43.392 35.6688745825358 139.7411873951792 43.392 35.668863231078404 139.7412068161352 43.392 35.66882195651333 139.741170588347 43.392 35.66883330796497 139.7411511673959 43.392</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-54187654-b5b7-4f84-8bd3-2026224fa184">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-54187654-b5b7-4f84-8bd3-2026224fa184_0">
											<gml:posList>35.66882195651333 139.741170588347 46.804 35.66883330796497 139.7411511673959 46.804 35.66883330796497 139.7411511673959 43.392 35.66882195651333 139.741170588347 43.392 35.66882195651333 139.741170588347 46.804</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cdea714c-d001-45c7-84ba-7292ac858d62">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cdea714c-d001-45c7-84ba-7292ac858d62_0">
											<gml:posList>35.668863231078404 139.7412068161352 43.392 35.668863231078404 139.7412068161352 46.804 35.66882195651333 139.741170588347 46.804 35.66882195651333 139.741170588347 43.392 35.668863231078404 139.7412068161352 43.392</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4abbc485-c3fa-4f44-9591-aa7adb1aef80">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4abbc485-c3fa-4f44-9591-aa7adb1aef80_0">
											<gml:posList>35.668863231078404 139.7412068161352 46.804 35.6688745825358 139.7411873951792 46.804 35.66883330796497 139.7411511673959 46.804 35.66882195651333 139.741170588347 46.804 35.668863231078404 139.7412068161352 46.804</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e5d4c020-8486-4e3a-9399-d5322e614dfc">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e5d4c020-8486-4e3a-9399-d5322e614dfc_0">
											<gml:posList>35.66883330796497 139.7411511673959 43.392 35.66883330796497 139.7411511673959 46.804 35.6688745825358 139.7411873951792 46.804 35.6688745825358 139.7411873951792 43.392 35.66883330796497 139.7411511673959 43.392</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-93f54c25-8bfd-4ec8-806f-1f419b2ff2d9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-93f54c25-8bfd-4ec8-806f-1f419b2ff2d9_0">
											<gml:posList>35.6688745825358 139.7411873951792 43.392 35.6688745825358 139.7411873951792 46.804 35.668863231078404 139.7412068161352 46.804 35.668863231078404 139.7412068161352 43.392 35.6688745825358 139.7411873951792 43.392</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_d19b0f9b-e0aa-470b-aebc-a8992bcac2e0_BuildingInstallation_1060">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-090caa90-105a-4f4a-b7f5-07723c7ded85">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66884405664378 139.741286413895 10.79 35.66881255978017 139.74125906691054 10.79 35.668823560014964 139.74124004403527 10.79 35.668855381596494 139.7412676778404 10.79 35.66884405664378 139.741286413895 10.79</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-da9e5282-db6b-4cd7-a00e-8d3d0b72b1f3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-da9e5282-db6b-4cd7-a00e-8d3d0b72b1f3_0">
											<gml:posList>35.668823560014964 139.74124004403527 35.5 35.668823560014964 139.74124004403527 10.79 35.66881255978017 139.74125906691054 10.79 35.66881255978017 139.74125906691054 35.5 35.668823560014964 139.74124004403527 35.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-aec24a89-de5a-4094-91cc-38195b6fbbcf">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-aec24a89-de5a-4094-91cc-38195b6fbbcf_0">
											<gml:posList>35.668855381596494 139.7412676778404 35.5 35.668855381596494 139.7412676778404 10.79 35.668823560014964 139.74124004403527 10.79 35.668823560014964 139.74124004403527 35.5 35.668855381596494 139.7412676778404 35.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-720eb261-6e2e-4614-b14d-0bd9246e0ea5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-720eb261-6e2e-4614-b14d-0bd9246e0ea5_0">
											<gml:posList>35.668855381596494 139.7412676778404 35.5 35.668823560014964 139.74124004403527 35.5 35.66881255978017 139.74125906691054 35.5 35.66884405664378 139.741286413895 35.5 35.668855381596494 139.7412676778404 35.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-27b72275-ecf5-4154-bdd8-d9588ed87e4c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-27b72275-ecf5-4154-bdd8-d9588ed87e4c_0">
											<gml:posList>35.66881255978017 139.74125906691054 35.5 35.66881255978017 139.74125906691054 10.79 35.66884405664378 139.741286413895 10.79 35.66884405664378 139.741286413895 35.5 35.66881255978017 139.74125906691054 35.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-630fcbad-b3b0-46af-91df-3da843ead6a2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-630fcbad-b3b0-46af-91df-3da843ead6a2_0">
											<gml:posList>35.66884405664378 139.741286413895 35.5 35.66884405664378 139.741286413895 10.79 35.668855381596494 139.7412676778404 10.79 35.668855381596494 139.7412676778404 35.5 35.66884405664378 139.741286413895 35.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-c8a3a829-d6c3-43a3-b68b-4dfc45e385f8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c8a3a829-d6c3-43a3-b68b-4dfc45e385f8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c8a3a829-d6c3-43a3-b68b-4dfc45e385f8">
											<gml:posList>35.66894858164143 139.74112376214222 10.3 35.66886162324092 139.74127309428442 10.3 35.66877609822397 139.74119883054755 10.3 35.668760516008646 139.74122570136694 10.3 35.66869976812701 139.74117291590554 10.3 35.66871674557231 139.74114358022743 10.3 35.66868337261964 139.74111466696445 10.3 35.66868942181464 139.74110417732797 10.3 35.66881797326818 139.7410069347333 10.3 35.66894858164143 139.74112376214222 10.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-194f6c3a-c5e5-4921-a83a-f651ea6aa4a1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-194f6c3a-c5e5-4921-a83a-f651ea6aa4a1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-194f6c3a-c5e5-4921-a83a-f651ea6aa4a1">
											<gml:posList>35.66881797326818 139.7410069347333 44.7 35.66874763481888 139.74106013610526 44.7 35.66875212386569 139.7410604070902 44.7 35.66881784094182 139.7410106905407 44.7 35.66881797326818 139.7410069347333 44.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-eea58c12-37a9-472f-a088-d9787cd9a9ef">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-eea58c12-37a9-472f-a088-d9787cd9a9ef">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-eea58c12-37a9-472f-a088-d9787cd9a9ef">
											<gml:posList>35.66875212386569 139.7410604070902 44.7 35.66874763481888 139.74106013610526 44.7 35.6687505934284 139.74106288316324 44.7 35.66875212386569 139.7410604070902 44.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-244742e3-2b2d-4645-98cc-561f839a4802">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-244742e3-2b2d-4645-98cc-561f839a4802">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-244742e3-2b2d-4645-98cc-561f839a4802">
											<gml:posList>35.66881797326818 139.7410069347333 44.7 35.66881784094182 139.7410106905407 44.7 35.66894503978886 139.74112447316332 44.7 35.66894858164143 139.74112376214222 44.7 35.66881797326818 139.7410069347333 44.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-543954c3-2475-457a-b8bb-be6236335736">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-543954c3-2475-457a-b8bb-be6236335736">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-543954c3-2475-457a-b8bb-be6236335736">
											<gml:posList>35.66874763481888 139.74106013610526 50.6 35.66874750217769 139.74106348320637 50.6 35.66878439465809 139.7410978270738 50.6 35.66878754004207 139.74109729324564 50.6 35.66874763481888 139.74106013610526 50.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-5b9fc00f-9ca0-40a8-997c-d00b85d98dee">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5b9fc00f-9ca0-40a8-997c-d00b85d98dee">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5b9fc00f-9ca0-40a8-997c-d00b85d98dee">
											<gml:posList>35.66868942181464 139.74110417732797 50.6 35.66869099177648 139.74110623008315 50.6 35.66874750217769 139.74106348320637 50.6 35.66874763481888 139.74106013610526 50.6 35.66868942181464 139.74110417732797 50.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-0ffff80e-1f6e-4570-8af1-1bf502fe52ec">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0ffff80e-1f6e-4570-8af1-1bf502fe52ec">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0ffff80e-1f6e-4570-8af1-1bf502fe52ec">
											<gml:posList>35.66868942181464 139.74110417732797 50.6 35.66868337261964 139.74111466696445 50.6 35.66868650890544 139.74111402268784 50.6 35.66869099177648 139.74110623008315 50.6 35.66868942181464 139.74110417732797 50.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-323303d0-3e97-42fc-aeda-2d964a5d0888">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-323303d0-3e97-42fc-aeda-2d964a5d0888">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-323303d0-3e97-42fc-aeda-2d964a5d0888">
											<gml:posList>35.66874715088098 139.74115794929793 48.593 35.66878439465809 139.7410978270738 48.593 35.66874750217769 139.74106348320637 48.593 35.66869099177648 139.74110623008315 48.593 35.66868650890544 139.74111402268784 48.593 35.66871807789537 139.7411413473974 48.593 35.66874301864571 139.74116457062257 48.593 35.66874715088098 139.74115794929793 48.593</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b4e1263b-6b10-44a2-bda2-69a7658f50ec">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b4e1263b-6b10-44a2-bda2-69a7658f50ec">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b4e1263b-6b10-44a2-bda2-69a7658f50ec">
											<gml:posList>35.66874893688382 139.74115962624208 50.6 35.66878754004207 139.74109729324564 50.6 35.66878439465809 139.7410978270738 50.6 35.66874715088098 139.74115794929793 50.6 35.66874893688382 139.74115962624208 50.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-18e3b142-b156-4d5e-9632-0b4344f15156">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-18e3b142-b156-4d5e-9632-0b4344f15156">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-18e3b142-b156-4d5e-9632-0b4344f15156">
											<gml:posList>35.66871674557231 139.74114358022743 50.6 35.66871807789537 139.7411413473974 50.6 35.66868650890544 139.74111402268784 50.6 35.66868337261964 139.74111466696445 50.6 35.66871674557231 139.74114358022743 50.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-64c203b9-36dd-43a5-af7a-56e1d1f4ffb1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-64c203b9-36dd-43a5-af7a-56e1d1f4ffb1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-64c203b9-36dd-43a5-af7a-56e1d1f4ffb1">
											<gml:posList>35.66874701422019 139.74116782460987 43.392 35.668777637660874 139.7411963323739 43.392 35.66886101600239 139.74126875388387 43.392 35.66894503978886 139.74112447316332 43.392 35.66881784094182 139.7410106905407 43.392 35.66875212386569 139.7410604070902 43.392 35.6687505934284 139.74106288316324 43.392 35.66878754004207 139.74109729324564 43.392 35.66874893688382 139.74115962624208 43.392 35.6687453628146 139.74116535219642 43.392 35.66874701422019 139.74116782460987 43.392</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-1dce4f41-fd49-48cb-8f9e-fbcec7ab315c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1dce4f41-fd49-48cb-8f9e-fbcec7ab315c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1dce4f41-fd49-48cb-8f9e-fbcec7ab315c">
											<gml:posList>35.66871674557231 139.74114358022743 50.6 35.668743445241496 139.74116842519808 50.6 35.66874301864571 139.74116457062257 50.6 35.66871807789537 139.7411413473974 50.6 35.66871674557231 139.74114358022743 50.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-67a1511b-e5b0-422f-8a52-6d6174b2bca2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-67a1511b-e5b0-422f-8a52-6d6174b2bca2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-67a1511b-e5b0-422f-8a52-6d6174b2bca2">
											<gml:posList>35.66873980110088 139.74116503825454 33.474 35.66871674557231 139.74114358022743 33.474 35.66869976812701 139.74117291590554 28.436 35.66873980110088 139.74116503825454 33.474</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e3ccc0b0-bc3a-48c7-8337-f10292f7ed08">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e3ccc0b0-bc3a-48c7-8337-f10292f7ed08">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e3ccc0b0-bc3a-48c7-8337-f10292f7ed08">
											<gml:posList>35.66874893688382 139.74115962624208 50.6 35.66874715088098 139.74115794929793 50.6 35.66874301864571 139.74116457062257 50.6 35.668743445241496 139.74116842519808 50.6 35.66874893688382 139.74115962624208 50.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-830f507d-def1-474c-8930-ab879c892c39">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-830f507d-def1-474c-8930-ab879c892c39">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-830f507d-def1-474c-8930-ab879c892c39">
											<gml:posList>35.6687453628146 139.74116535219642 44.7 35.668743445241496 139.74116842519808 44.7 35.66874701422019 139.74116782460987 44.7 35.6687453628146 139.74116535219642 44.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-03bd6a7a-2fdd-4afc-a02a-2aab12a0b67d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-03bd6a7a-2fdd-4afc-a02a-2aab12a0b67d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-03bd6a7a-2fdd-4afc-a02a-2aab12a0b67d">
											<gml:posList>35.66869976812701 139.74117291590554 28.436 35.66872261510071 139.74119276145566 28.436 35.66873980110088 139.74116503825454 33.474 35.66869976812701 139.74117291590554 28.436</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ddd9b065-1108-41c5-9924-50cd31caa517">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ddd9b065-1108-41c5-9924-50cd31caa517">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ddd9b065-1108-41c5-9924-50cd31caa517">
											<gml:posList>35.66877609822397 139.74119883054755 44.7 35.668777637660874 139.7411963323739 44.7 35.66874701422019 139.74116782460987 44.7 35.668743445241496 139.74116842519808 44.7 35.66877609822397 139.74119883054755 44.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-688b39e7-9a25-4361-9a5f-f19699ec7448">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-688b39e7-9a25-4361-9a5f-f19699ec7448">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-688b39e7-9a25-4361-9a5f-f19699ec7448">
											<gml:posList>35.668760516008646 139.74122570136694 21.5 35.66877609822397 139.74119883054755 21.5 35.66873980110088 139.74116503825454 21.5 35.66872261510071 139.74119276145566 21.5 35.668760516008646 139.74122570136694 21.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-7a5509ca-e167-444f-be7d-d1ff2b699bdd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7a5509ca-e167-444f-be7d-d1ff2b699bdd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7a5509ca-e167-444f-be7d-d1ff2b699bdd">
											<gml:posList>35.66894858164143 139.74112376214222 44.7 35.66894503978886 139.74112447316332 44.7 35.66886101600239 139.74126875388387 44.7 35.66886162324092 139.74127309428442 44.7 35.66894858164143 139.74112376214222 44.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-4819d38e-a1af-470c-a2ef-1b01508b6f64">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4819d38e-a1af-470c-a2ef-1b01508b6f64">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4819d38e-a1af-470c-a2ef-1b01508b6f64">
											<gml:posList>35.66877609822397 139.74119883054755 44.7 35.66886162324092 139.74127309428442 44.7 35.66886101600239 139.74126875388387 44.7 35.668777637660874 139.7411963323739 44.7 35.66877609822397 139.74119883054755 44.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1ffa6cac-f63a-482f-be98-3a8ee6516999">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1ffa6cac-f63a-482f-be98-3a8ee6516999">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1ffa6cac-f63a-482f-be98-3a8ee6516999">
											<gml:posList>35.66878439465809 139.7410978270738 50.6 35.66878439465809 139.7410978270738 48.593 35.66874715088098 139.74115794929793 48.593 35.66874715088098 139.74115794929793 50.6 35.66878439465809 139.7410978270738 50.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-986df9da-0212-4335-a1da-7bf0ad54b0c4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-986df9da-0212-4335-a1da-7bf0ad54b0c4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-986df9da-0212-4335-a1da-7bf0ad54b0c4">
											<gml:posList>35.66875212386569 139.7410604070902 44.7 35.66875212386569 139.7410604070902 43.392 35.66881784094182 139.7410106905407 43.392 35.66881784094182 139.7410106905407 44.7 35.66875212386569 139.7410604070902 44.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9a2e2ebe-1c1d-46d9-88e9-bd593d9ba9ae">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9a2e2ebe-1c1d-46d9-88e9-bd593d9ba9ae">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9a2e2ebe-1c1d-46d9-88e9-bd593d9ba9ae">
											<gml:posList>35.66868942181464 139.74110417732797 10.3 35.66868942181464 139.74110417732797 50.6 35.66874763481888 139.74106013610526 50.6 35.66874763481888 139.74106013610526 44.7 35.66881797326818 139.7410069347333 44.7 35.66881797326818 139.7410069347333 10.3 35.66868942181464 139.74110417732797 10.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-eeabfb58-9b15-4bbc-a828-12a62d73430a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-eeabfb58-9b15-4bbc-a828-12a62d73430a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-eeabfb58-9b15-4bbc-a828-12a62d73430a">
											<gml:posList>35.6687505934284 139.74106288316324 44.7 35.6687505934284 139.74106288316324 43.392 35.66875212386569 139.7410604070902 43.392 35.66875212386569 139.7410604070902 44.7 35.6687505934284 139.74106288316324 44.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-cb63a202-0097-499b-9260-9f0aae89b6f3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cb63a202-0097-499b-9260-9f0aae89b6f3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cb63a202-0097-499b-9260-9f0aae89b6f3">
											<gml:posList>35.66894858164143 139.74112376214222 10.3 35.66881797326818 139.7410069347333 10.3 35.66881797326818 139.7410069347333 44.7 35.66894858164143 139.74112376214222 44.7 35.66894858164143 139.74112376214222 10.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2c234c0c-e1f8-4d83-8b38-81aa3be2b872">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2c234c0c-e1f8-4d83-8b38-81aa3be2b872">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2c234c0c-e1f8-4d83-8b38-81aa3be2b872">
											<gml:posList>35.66881784094182 139.7410106905407 44.7 35.66881784094182 139.7410106905407 43.392 35.66894503978886 139.74112447316332 43.392 35.66894503978886 139.74112447316332 44.7 35.66881784094182 139.7410106905407 44.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-011128e1-ded6-4ddd-b2ce-2467bb51dd06">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-011128e1-ded6-4ddd-b2ce-2467bb51dd06">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-011128e1-ded6-4ddd-b2ce-2467bb51dd06">
											<gml:posList>35.6687505934284 139.74106288316324 44.7 35.66874763481888 139.74106013610526 44.7 35.66874763481888 139.74106013610526 50.6 35.66878754004207 139.74109729324564 50.6 35.66878754004207 139.74109729324564 43.392 35.6687505934284 139.74106288316324 43.392 35.6687505934284 139.74106288316324 44.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2c1de54d-82d1-4b7f-99cd-fddcb6b69e9a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2c1de54d-82d1-4b7f-99cd-fddcb6b69e9a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2c1de54d-82d1-4b7f-99cd-fddcb6b69e9a">
											<gml:posList>35.66874750217769 139.74106348320637 50.6 35.66874750217769 139.74106348320637 48.593 35.66878439465809 139.7410978270738 48.593 35.66878439465809 139.7410978270738 50.6 35.66874750217769 139.74106348320637 50.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c9e48c17-2f7f-4d05-88f6-75d12e1eaf52">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c9e48c17-2f7f-4d05-88f6-75d12e1eaf52">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c9e48c17-2f7f-4d05-88f6-75d12e1eaf52">
											<gml:posList>35.66869099177648 139.74110623008315 50.6 35.66869099177648 139.74110623008315 48.593 35.66874750217769 139.74106348320637 48.593 35.66874750217769 139.74106348320637 50.6 35.66869099177648 139.74110623008315 50.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-65b4b2e5-61e2-44bd-8b91-7b7447a1bbb3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-65b4b2e5-61e2-44bd-8b91-7b7447a1bbb3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-65b4b2e5-61e2-44bd-8b91-7b7447a1bbb3">
											<gml:posList>35.66868942181464 139.74110417732797 50.6 35.66868942181464 139.74110417732797 10.3 35.66868337261964 139.74111466696445 10.3 35.66868337261964 139.74111466696445 50.6 35.66868942181464 139.74110417732797 50.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5892efd9-a606-4bbd-8d05-297bffef8ea5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5892efd9-a606-4bbd-8d05-297bffef8ea5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5892efd9-a606-4bbd-8d05-297bffef8ea5">
											<gml:posList>35.66868650890544 139.74111402268784 50.6 35.66868650890544 139.74111402268784 48.593 35.66869099177648 139.74110623008315 48.593 35.66869099177648 139.74110623008315 50.6 35.66868650890544 139.74111402268784 50.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-81e15b2c-db66-49e0-9572-9d2b6fa1f86d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-81e15b2c-db66-49e0-9572-9d2b6fa1f86d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-81e15b2c-db66-49e0-9572-9d2b6fa1f86d">
											<gml:posList>35.66871807789537 139.7411413473974 50.6 35.66871807789537 139.7411413473974 48.593 35.66868650890544 139.74111402268784 48.593 35.66868650890544 139.74111402268784 50.6 35.66871807789537 139.7411413473974 50.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-927537fa-0e0f-45b7-a075-f63d7b678b97">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-927537fa-0e0f-45b7-a075-f63d7b678b97">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-927537fa-0e0f-45b7-a075-f63d7b678b97">
											<gml:posList>35.66874893688382 139.74115962624208 43.392 35.66878754004207 139.74109729324564 43.392 35.66878754004207 139.74109729324564 50.6 35.66874893688382 139.74115962624208 50.6 35.66874893688382 139.74115962624208 43.392</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-96319fd9-ce6a-49d2-9c8f-648df2ee9986">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-96319fd9-ce6a-49d2-9c8f-648df2ee9986">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-96319fd9-ce6a-49d2-9c8f-648df2ee9986">
											<gml:posList>35.66868337261964 139.74111466696445 50.6 35.66868337261964 139.74111466696445 10.3 35.66871674557231 139.74114358022743 10.3 35.66871674557231 139.74114358022743 33.474 35.66871674557231 139.74114358022743 50.6 35.66868337261964 139.74111466696445 50.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-30f38042-fc0f-46ba-87dc-5259cb86ce35">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-30f38042-fc0f-46ba-87dc-5259cb86ce35">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-30f38042-fc0f-46ba-87dc-5259cb86ce35">
											<gml:posList>35.66874301864571 139.74116457062257 50.6 35.66874301864571 139.74116457062257 48.593 35.66871807789537 139.7411413473974 48.593 35.66871807789537 139.7411413473974 50.6 35.66874301864571 139.74116457062257 50.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-fed22e85-3d7e-4e3e-aec7-32d49a59ef5d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fed22e85-3d7e-4e3e-aec7-32d49a59ef5d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fed22e85-3d7e-4e3e-aec7-32d49a59ef5d">
											<gml:posList>35.66871674557231 139.74114358022743 10.3 35.66869976812701 139.74117291590554 10.3 35.66869976812701 139.74117291590554 28.436 35.66871674557231 139.74114358022743 33.474 35.66871674557231 139.74114358022743 10.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-15723f69-1a0e-410a-93db-9f01f9b4df38">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-15723f69-1a0e-410a-93db-9f01f9b4df38">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-15723f69-1a0e-410a-93db-9f01f9b4df38">
											<gml:posList>35.66874715088098 139.74115794929793 50.6 35.66874715088098 139.74115794929793 48.593 35.66874301864571 139.74116457062257 48.593 35.66874301864571 139.74116457062257 50.6 35.66874715088098 139.74115794929793 50.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5059dd0e-c7e0-4f19-898f-ba404ba88845">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5059dd0e-c7e0-4f19-898f-ba404ba88845">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5059dd0e-c7e0-4f19-898f-ba404ba88845">
											<gml:posList>35.66874893688382 139.74115962624208 43.392 35.66874893688382 139.74115962624208 50.6 35.668743445241496 139.74116842519808 50.6 35.668743445241496 139.74116842519808 44.7 35.6687453628146 139.74116535219642 44.7 35.6687453628146 139.74116535219642 43.392 35.66874893688382 139.74115962624208 43.392</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f0412f74-c6b2-478c-9f35-414db485c3eb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f0412f74-c6b2-478c-9f35-414db485c3eb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f0412f74-c6b2-478c-9f35-414db485c3eb">
											<gml:posList>35.66874701422019 139.74116782460987 44.7 35.66874701422019 139.74116782460987 43.392 35.6687453628146 139.74116535219642 43.392 35.6687453628146 139.74116535219642 44.7 35.66874701422019 139.74116782460987 44.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-396fc65a-80e3-47d8-a214-1d3ee3660c48">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-396fc65a-80e3-47d8-a214-1d3ee3660c48">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-396fc65a-80e3-47d8-a214-1d3ee3660c48">
											<gml:posList>35.668743445241496 139.74116842519808 44.7 35.668743445241496 139.74116842519808 50.6 35.66871674557231 139.74114358022743 50.6 35.66871674557231 139.74114358022743 33.474 35.66873980110088 139.74116503825454 33.474 35.66873980110088 139.74116503825454 21.5 35.66877609822397 139.74119883054755 21.5 35.66877609822397 139.74119883054755 44.7 35.668743445241496 139.74116842519808 44.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5fce998e-bf23-4cdb-bd65-03ed7de5fea0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5fce998e-bf23-4cdb-bd65-03ed7de5fea0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5fce998e-bf23-4cdb-bd65-03ed7de5fea0">
											<gml:posList>35.66873980110088 139.74116503825454 21.5 35.66873980110088 139.74116503825454 33.474 35.66872261510071 139.74119276145566 28.436 35.66872261510071 139.74119276145566 21.5 35.66873980110088 139.74116503825454 21.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-81f2d8c8-657a-43ec-a014-1577e291a7f2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-81f2d8c8-657a-43ec-a014-1577e291a7f2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-81f2d8c8-657a-43ec-a014-1577e291a7f2">
											<gml:posList>35.668777637660874 139.7411963323739 44.7 35.668777637660874 139.7411963323739 43.392 35.66874701422019 139.74116782460987 43.392 35.66874701422019 139.74116782460987 44.7 35.668777637660874 139.7411963323739 44.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2f6262a2-1f6c-4604-9588-70ceb142bcfc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2f6262a2-1f6c-4604-9588-70ceb142bcfc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2f6262a2-1f6c-4604-9588-70ceb142bcfc">
											<gml:posList>35.66894503978886 139.74112447316332 44.7 35.66894503978886 139.74112447316332 43.392 35.66886101600239 139.74126875388387 43.392 35.66886101600239 139.74126875388387 44.7 35.66894503978886 139.74112447316332 44.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f81dfe3c-01df-4a8b-bbb3-3024747bc95c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f81dfe3c-01df-4a8b-bbb3-3024747bc95c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f81dfe3c-01df-4a8b-bbb3-3024747bc95c">
											<gml:posList>35.66886162324092 139.74127309428442 10.3 35.66894858164143 139.74112376214222 10.3 35.66894858164143 139.74112376214222 44.7 35.66886162324092 139.74127309428442 44.7 35.66886162324092 139.74127309428442 10.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e2a9e54a-979b-46eb-9c6e-9ccd37c9a859">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e2a9e54a-979b-46eb-9c6e-9ccd37c9a859">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e2a9e54a-979b-46eb-9c6e-9ccd37c9a859">
											<gml:posList>35.66869976812701 139.74117291590554 10.3 35.668760516008646 139.74122570136694 10.3 35.668760516008646 139.74122570136694 21.5 35.66872261510071 139.74119276145566 21.5 35.66872261510071 139.74119276145566 28.436 35.66869976812701 139.74117291590554 28.436 35.66869976812701 139.74117291590554 10.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-37a7e77f-dc2c-4e67-a4ca-1e5119cd5cdd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-37a7e77f-dc2c-4e67-a4ca-1e5119cd5cdd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-37a7e77f-dc2c-4e67-a4ca-1e5119cd5cdd">
											<gml:posList>35.668760516008646 139.74122570136694 10.3 35.66877609822397 139.74119883054755 10.3 35.66877609822397 139.74119883054755 21.5 35.668760516008646 139.74122570136694 21.5 35.668760516008646 139.74122570136694 10.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-625e3da5-9952-4203-9c27-ade983d78c73">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-625e3da5-9952-4203-9c27-ade983d78c73">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-625e3da5-9952-4203-9c27-ade983d78c73">
											<gml:posList>35.66886101600239 139.74126875388387 44.7 35.66886101600239 139.74126875388387 43.392 35.668777637660874 139.7411963323739 43.392 35.668777637660874 139.7411963323739 44.7 35.66886101600239 139.74126875388387 44.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c740c28b-b535-4a63-8fbe-77d6a7f307f3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c740c28b-b535-4a63-8fbe-77d6a7f307f3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c740c28b-b535-4a63-8fbe-77d6a7f307f3">
											<gml:posList>35.66886162324092 139.74127309428442 10.3 35.66886162324092 139.74127309428442 44.7 35.66877609822397 139.74119883054755 44.7 35.66877609822397 139.74119883054755 21.5 35.66877609822397 139.74119883054755 10.3 35.66886162324092 139.74127309428442 10.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂一丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-2658</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">387.65445</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1210</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>7</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.03</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>