<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_d213ed92-d901-4855-be25-3d737134093c">
			<core:creationDate>2024-03-15</core:creationDate>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.66757684614699 139.73830843206366 0 35.66758775582408 139.73828946441438 0 35.667567434026424 139.73827191451977 0 35.667556524352094 139.73829088216664 0 35.66757684614699 139.73830843206366 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66757684614699 139.73830843206366 16.473 35.667556524352094 139.73829088216664 16.473 35.667567434026424 139.73827191451977 16.473 35.66758775582408 139.73828946441438 16.473 35.66757684614699 139.73830843206366 16.473</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66757684614699 139.73830843206366 16.473 35.66758775582408 139.73828946441438 16.473 35.66758775582408 139.73828946441438 19.473 35.66757684614699 139.73830843206366 19.473 35.66757684614699 139.73830843206366 16.473</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66758775582408 139.73828946441438 16.473 35.667567434026424 139.73827191451977 16.473 35.667567434026424 139.73827191451977 19.473 35.66758775582408 139.73828946441438 19.473 35.66758775582408 139.73828946441438 16.473</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667567434026424 139.73827191451977 16.473 35.667556524352094 139.73829088216664 16.473 35.667556524352094 139.73829088216664 19.473 35.667567434026424 139.73827191451977 19.473 35.667567434026424 139.73827191451977 16.473</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667556524352094 139.73829088216664 16.473 35.66757684614699 139.73830843206366 16.473 35.66757684614699 139.73830843206366 19.473 35.667556524352094 139.73829088216664 19.473 35.667556524352094 139.73829088216664 16.473</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66757684614699 139.73830843206366 19.473 35.66758775582408 139.73828946441438 19.473 35.667567434026424 139.73827191451977 19.473 35.667556524352094 139.73829088216664 19.473 35.66757684614699 139.73830843206366 19.473</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-287b9b01-74cb-48ed-8aa7-c79e1399e2fb"/>
							<gml:surfaceMember xlink:href="#poly-f48cb1e2-6c50-440e-a684-9869da946296"/>
							<gml:surfaceMember xlink:href="#poly-1bd17162-b80b-4e3c-bd4e-76bf8d8cf953"/>
							<gml:surfaceMember xlink:href="#poly-58619eac-9c73-4f25-aaae-52069bb680f4"/>
							<gml:surfaceMember xlink:href="#poly-d66f8a7c-9782-4f2f-8e3e-3fc86f5e9759"/>
							<gml:surfaceMember xlink:href="#poly-65c95d8d-093d-4a60-ab5b-83cf7c82cce8"/>
							<gml:surfaceMember xlink:href="#poly-3d376c27-a2b2-4b3d-b15b-c750b13e2a74"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-287b9b01-74cb-48ed-8aa7-c79e1399e2fb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-287b9b01-74cb-48ed-8aa7-c79e1399e2fb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-287b9b01-74cb-48ed-8aa7-c79e1399e2fb">
											<gml:posList>35.66757684614698 139.73830843206366 16.473 35.66755652435205 139.73829088216664 16.473 35.66756743402641 139.73827191451977 16.473 35.66758775582405 139.73828946441435 16.473 35.66757684614698 139.73830843206366 16.473</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f48cb1e2-6c50-440e-a684-9869da946296">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f48cb1e2-6c50-440e-a684-9869da946296">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f48cb1e2-6c50-440e-a684-9869da946296">
											<gml:posList>35.66755652435205 139.73829088216664 18.497 35.66757684614698 139.73830843206366 18.497 35.667582264983295 139.73829901455755 18.598 35.66756239325427 139.7382806798714 18.598 35.66755652435205 139.73829088216664 18.497</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-1bd17162-b80b-4e3c-bd4e-76bf8d8cf953">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1bd17162-b80b-4e3c-bd4e-76bf8d8cf953">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1bd17162-b80b-4e3c-bd4e-76bf8d8cf953">
											<gml:posList>35.66758775582405 139.73828946441435 18.497 35.66756743402641 139.73827191451977 18.497 35.66756239325427 139.7382806798714 18.598 35.667582264983295 139.73829901455755 18.598 35.66758775582405 139.73828946441435 18.497</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-58619eac-9c73-4f25-aaae-52069bb680f4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-58619eac-9c73-4f25-aaae-52069bb680f4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-58619eac-9c73-4f25-aaae-52069bb680f4">
											<gml:posList>35.66755652435205 139.73829088216664 16.473 35.66757684614698 139.73830843206366 16.473 35.66757684614698 139.73830843206366 18.497 35.66755652435205 139.73829088216664 18.497 35.66755652435205 139.73829088216664 16.473</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d66f8a7c-9782-4f2f-8e3e-3fc86f5e9759">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d66f8a7c-9782-4f2f-8e3e-3fc86f5e9759">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d66f8a7c-9782-4f2f-8e3e-3fc86f5e9759">
											<gml:posList>35.667582264983295 139.73829901455755 18.598 35.66757684614698 139.73830843206366 18.497 35.66757684614698 139.73830843206366 16.473 35.66758775582405 139.73828946441435 16.473 35.66758775582405 139.73828946441435 18.497 35.667582264983295 139.73829901455755 18.598</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-65c95d8d-093d-4a60-ab5b-83cf7c82cce8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-65c95d8d-093d-4a60-ab5b-83cf7c82cce8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-65c95d8d-093d-4a60-ab5b-83cf7c82cce8">
											<gml:posList>35.66758775582405 139.73828946441435 16.473 35.66756743402641 139.73827191451977 16.473 35.66756743402641 139.73827191451977 18.497 35.66758775582405 139.73828946441435 18.497 35.66758775582405 139.73828946441435 16.473</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3d376c27-a2b2-4b3d-b15b-c750b13e2a74">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3d376c27-a2b2-4b3d-b15b-c750b13e2a74">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3d376c27-a2b2-4b3d-b15b-c750b13e2a74">
											<gml:posList>35.66756239325427 139.7382806798714 18.598 35.66756743402641 139.73827191451977 18.497 35.66756743402641 139.73827191451977 16.473 35.66755652435205 139.73829088216664 16.473 35.66755652435205 139.73829088216664 18.497 35.66756239325427 139.7382806798714 18.598</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-9908</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">5</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">214</uro:landUseType>
					<uro:specifiedBuildingCoverageRate>0.6</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>3</uro:specifiedFloorAreaRate>
					<uro:surveyYear>0001</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingLandSlideRiskAttribute>
					<uro:description codeSpace="../../codelists/LandSlideRiskAttribute_description.xml">1</uro:description>
					<uro:areaType codeSpace="../../codelists/LandSlideRiskAttribute_areaType.xml">2</uro:areaType>
				</uro:BuildingLandSlideRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">0</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">105</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key105.xml">3</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">20</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>