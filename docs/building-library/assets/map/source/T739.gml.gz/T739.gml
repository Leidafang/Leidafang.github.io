<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_d3442ce2-bfda-4f4c-8058-dff9e43e4aa4">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>29</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103029002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">412</bldg:usage>
			<bldg:measuredHeight uom="m">29.7</bldg:measuredHeight>
			<bldg:storeysAboveGround>10</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.66778146881529 139.7391368309931 0 35.66776140167763 139.73912203097083 0 35.667733755554394 139.7391783754241 0 35.667737254909824 139.73918096710048 0 35.667694057824924 139.7392690535592 0 35.6677472695218 139.73930831452927 0 35.66772189108088 139.73935992860876 0 35.66779061523188 139.7394105487601 0 35.66794657498863 139.73909279576355 0 35.66785990301119 139.73902894179722 0 35.667817615007706 139.7391152158758 0 35.6677988646668 139.73910143052802 0 35.66778146881529 139.7391368309931 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66778146881529 139.7391368309931 11.42 35.6677988646668 139.73910143052802 11.42 35.667817615007706 139.7391152158758 11.42 35.66785990301119 139.73902894179722 11.42 35.66794657498863 139.73909279576355 11.42 35.66779061523188 139.7394105487601 11.42 35.66772189108088 139.73935992860876 11.42 35.6677472695218 139.73930831452927 11.42 35.667694057824924 139.7392690535592 11.42 35.667737254909824 139.73918096710048 11.42 35.667733755554394 139.7391783754241 11.42 35.66776140167763 139.73912203097083 11.42 35.66778146881529 139.7391368309931 11.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66778146881529 139.7391368309931 11.42 35.66776140167763 139.73912203097083 11.42 35.66776140167763 139.73912203097083 41.16 35.66778146881529 139.7391368309931 41.16 35.66778146881529 139.7391368309931 11.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66776140167763 139.73912203097083 11.42 35.667733755554394 139.7391783754241 11.42 35.667733755554394 139.7391783754241 41.16 35.66776140167763 139.73912203097083 41.16 35.66776140167763 139.73912203097083 11.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667733755554394 139.7391783754241 11.42 35.667737254909824 139.73918096710048 11.42 35.667737254909824 139.73918096710048 41.16 35.667733755554394 139.7391783754241 41.16 35.667733755554394 139.7391783754241 11.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667737254909824 139.73918096710048 11.42 35.667694057824924 139.7392690535592 11.42 35.667694057824924 139.7392690535592 41.16 35.667737254909824 139.73918096710048 41.16 35.667737254909824 139.73918096710048 11.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667694057824924 139.7392690535592 11.42 35.6677472695218 139.73930831452927 11.42 35.6677472695218 139.73930831452927 41.16 35.667694057824924 139.7392690535592 41.16 35.667694057824924 139.7392690535592 11.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6677472695218 139.73930831452927 11.42 35.66772189108088 139.73935992860876 11.42 35.66772189108088 139.73935992860876 41.16 35.6677472695218 139.73930831452927 41.16 35.6677472695218 139.73930831452927 11.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66772189108088 139.73935992860876 11.42 35.66779061523188 139.7394105487601 11.42 35.66779061523188 139.7394105487601 41.16 35.66772189108088 139.73935992860876 41.16 35.66772189108088 139.73935992860876 11.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66779061523188 139.7394105487601 11.42 35.66794657498863 139.73909279576355 11.42 35.66794657498863 139.73909279576355 41.16 35.66779061523188 139.7394105487601 41.16 35.66779061523188 139.7394105487601 11.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66794657498863 139.73909279576355 11.42 35.66785990301119 139.73902894179722 11.42 35.66785990301119 139.73902894179722 41.16 35.66794657498863 139.73909279576355 41.16 35.66794657498863 139.73909279576355 11.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66785990301119 139.73902894179722 11.42 35.667817615007706 139.7391152158758 11.42 35.667817615007706 139.7391152158758 41.16 35.66785990301119 139.73902894179722 41.16 35.66785990301119 139.73902894179722 11.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667817615007706 139.7391152158758 11.42 35.6677988646668 139.73910143052802 11.42 35.6677988646668 139.73910143052802 41.16 35.667817615007706 139.7391152158758 41.16 35.667817615007706 139.7391152158758 11.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6677988646668 139.73910143052802 11.42 35.66778146881529 139.7391368309931 11.42 35.66778146881529 139.7391368309931 41.16 35.6677988646668 139.73910143052802 41.16 35.6677988646668 139.73910143052802 11.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66778146881529 139.7391368309931 41.16 35.66776140167763 139.73912203097083 41.16 35.667733755554394 139.7391783754241 41.16 35.667737254909824 139.73918096710048 41.16 35.667694057824924 139.7392690535592 41.16 35.6677472695218 139.73930831452927 41.16 35.66772189108088 139.73935992860876 41.16 35.66779061523188 139.7394105487601 41.16 35.66794657498863 139.73909279576355 41.16 35.66785990301119 139.73902894179722 41.16 35.667817615007706 139.7391152158758 41.16 35.6677988646668 139.73910143052802 41.16 35.66778146881529 139.7391368309931 41.16</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-a3dafa88-0c7a-4373-873b-bc244227ad40"/>
							<gml:surfaceMember xlink:href="#poly-6549e7d8-8d92-41ff-816b-909a2df3a183"/>
							<gml:surfaceMember xlink:href="#poly-d00adc76-2515-4cd2-8399-1049358bbfc2"/>
							<gml:surfaceMember xlink:href="#poly-09557828-7109-4abd-acef-9696b837294e"/>
							<gml:surfaceMember xlink:href="#poly-c3e22032-053f-40f7-be00-2029758c0784"/>
							<gml:surfaceMember xlink:href="#poly-7015cfb3-ce3e-417f-a014-4219ee9fe5cc"/>
							<gml:surfaceMember xlink:href="#poly-190e3762-a48f-420d-bae0-9bf7e4d3f4e8"/>
							<gml:surfaceMember xlink:href="#poly-42a990a8-a229-40a7-be2d-6dbe5e2b140e"/>
							<gml:surfaceMember xlink:href="#poly-3775efe8-973c-4e2e-a880-30c0f05e4092"/>
							<gml:surfaceMember xlink:href="#poly-51eaab27-1427-495d-b081-b4459ac7d241"/>
							<gml:surfaceMember xlink:href="#poly-52c7135c-95bc-4790-b1f0-e7f7f74357cb"/>
							<gml:surfaceMember xlink:href="#poly-b1b1a02e-014a-4390-8d87-02dd54e038b4"/>
							<gml:surfaceMember xlink:href="#poly-9311401e-5be8-4ddf-9ec7-5d449a0882bf"/>
							<gml:surfaceMember xlink:href="#poly-94e3b881-7b35-4c32-a738-2c3f06c58252"/>
							<gml:surfaceMember xlink:href="#poly-7c9b6984-a634-43b3-a51a-291015f9f47b"/>
							<gml:surfaceMember xlink:href="#poly-56538521-a75d-4e8b-b06a-0396a215191c"/>
							<gml:surfaceMember xlink:href="#poly-9245a68b-e00f-4610-8d54-1dddd1165678"/>
							<gml:surfaceMember xlink:href="#poly-fb74868d-8cb6-4025-bf0d-1ff5eea30303"/>
							<gml:surfaceMember xlink:href="#poly-3c002e94-fa50-4f18-b59c-cdc64455ddfc"/>
							<gml:surfaceMember xlink:href="#poly-2c072fa5-e372-470e-b84a-ab692da86c93"/>
							<gml:surfaceMember xlink:href="#poly-24809edc-b60c-4412-9ae8-943976d73c0e"/>
							<gml:surfaceMember xlink:href="#poly-d20144b4-ed5c-49a6-b0ea-33cd9db69e77"/>
							<gml:surfaceMember xlink:href="#poly-b3afea92-15f6-47a0-8791-cb5224677e11"/>
							<gml:surfaceMember xlink:href="#poly-37666528-3fe8-4a3d-80b9-ec7aedec2d47"/>
							<gml:surfaceMember xlink:href="#poly-071b68fa-a3a3-4998-8f21-f9fb93dbfd5d"/>
							<gml:surfaceMember xlink:href="#poly-e2014921-1513-4d75-9743-9a45e7468220"/>
							<gml:surfaceMember xlink:href="#poly-ec61766a-d226-4c48-a144-20a9be9e5573"/>
							<gml:surfaceMember xlink:href="#poly-80bb4536-f157-4c87-a63c-0dda551c971c"/>
							<gml:surfaceMember xlink:href="#poly-a9e77cc2-cc1e-4146-9571-019a61548551"/>
							<gml:surfaceMember xlink:href="#poly-8668d024-1800-48e3-b0e8-52dc7f6b9617"/>
							<gml:surfaceMember xlink:href="#poly-0eae1dfc-23f4-4af2-9ed3-50723b023638"/>
							<gml:surfaceMember xlink:href="#poly-b4e83caa-ca4e-4b34-b41c-eabdfbc7d9d3"/>
							<gml:surfaceMember xlink:href="#poly-0438923f-f6ae-4014-8f06-d8d7572e7964"/>
							<gml:surfaceMember xlink:href="#poly-ba94f69b-ae4d-4189-97c7-0b5662c85f73"/>
							<gml:surfaceMember xlink:href="#poly-3e10f055-067d-4a51-9aba-c63c17f450c5"/>
							<gml:surfaceMember xlink:href="#poly-e0467440-40dd-4fe1-adbc-8323256a841d"/>
							<gml:surfaceMember xlink:href="#poly-06cb9ffa-837d-4d66-bf62-652f00926e29"/>
							<gml:surfaceMember xlink:href="#poly-ee818d4a-7d71-47db-8d0e-b315b94a88cd"/>
							<gml:surfaceMember xlink:href="#poly-6206a02b-0318-4aac-a8db-fc3cc6f75725"/>
							<gml:surfaceMember xlink:href="#poly-9de41461-3130-4908-bd42-536c70c59949"/>
							<gml:surfaceMember xlink:href="#poly-5b8cfa10-69e7-4c28-842c-de598dc4ae2e"/>
							<gml:surfaceMember xlink:href="#poly-3f9ea2ca-b7df-4f74-89de-237d6039426c"/>
							<gml:surfaceMember xlink:href="#poly-ca81e977-d37a-48db-b9ba-41a2f416cdab"/>
							<gml:surfaceMember xlink:href="#poly-8515ed6e-1635-4de5-ae83-12c1654d1174"/>
							<gml:surfaceMember xlink:href="#poly-88a08e94-5c60-4790-bacf-faa0265430d3"/>
							<gml:surfaceMember xlink:href="#poly-c3fa6bd5-8360-4851-9016-76e02b6a637c"/>
							<gml:surfaceMember xlink:href="#poly-113023be-0239-4b1b-a047-5a894f0643d8"/>
							<gml:surfaceMember xlink:href="#poly-47768197-ee77-4a62-8200-23e6e9f139c3"/>
							<gml:surfaceMember xlink:href="#poly-af3b77f3-0b24-47ba-9f2e-bbbb3cb4feca"/>
							<gml:surfaceMember xlink:href="#poly-273cedc2-cce0-451d-bbee-b1729377ee05"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_d3442ce2-bfda-4f4c-8058-dff9e43e4aa4_BuildingInstallation_1060">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1737bddc-b9be-41bf-ac9e-8a1b934d814a">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66781683487237 139.7390513051794 11.42 35.66784040141091 139.73906874105253 11.42 35.66781762402142 139.73911521586524 11.42 35.66779808903683 139.7391008570525 11.42 35.66779397640918 139.7390978353082 11.42 35.66781683487237 139.7390513051794 11.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4aae9ab8-43da-498c-bf9f-2e8851c5a205">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66779808903683 139.7391008570525 19.342 35.66781762402142 139.73911521586524 19.342 35.66779886466677 139.739101430528 19.342 35.66779808903683 139.7391008570525 19.342</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0e9dd47e-be20-4827-815f-eaf50708c045">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0e9dd47e-be20-4827-815f-eaf50708c045_0">
											<gml:posList>35.66779397640918 139.7390978353082 11.42 35.66779397640918 139.7390978353082 40.75 35.66781683487237 139.7390513051794 40.75 35.66781683487237 139.7390513051794 11.42 35.66779397640918 139.7390978353082 11.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ed129774-45c1-4fe5-ba0c-36af54901cae">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ed129774-45c1-4fe5-ba0c-36af54901cae_0">
											<gml:posList>35.66779808903683 139.7391008570525 19.342 35.66779886466677 139.739101430528 19.342 35.66781762402142 139.73911521586524 19.342 35.66781762402142 139.73911521586524 42.123 35.66779397640918 139.7390978353082 40.75 35.66779397640918 139.7390978353082 11.42 35.66779808903683 139.7391008570525 11.42 35.66779808903683 139.7391008570525 19.342</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6304a564-6369-458d-9f2d-b103c1bd07ea">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6304a564-6369-458d-9f2d-b103c1bd07ea_0">
											<gml:posList>35.66781762402142 139.73911521586524 19.342 35.66779808903683 139.7391008570525 19.342 35.66779808903683 139.7391008570525 11.42 35.66781762402142 139.73911521586524 11.42 35.66781762402142 139.73911521586524 19.342</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-04314f7b-b414-41ce-8c6d-40585fa60ae3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-04314f7b-b414-41ce-8c6d-40585fa60ae3_0">
											<gml:posList>35.66781683487237 139.7390513051794 40.75 35.66779397640918 139.7390978353082 40.75 35.66781762402142 139.73911521586524 42.123 35.66784040141091 139.73906874105253 42.123 35.66781683487237 139.7390513051794 40.75</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0e876795-2cd9-42ea-b677-a6bda3317c78">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0e876795-2cd9-42ea-b677-a6bda3317c78_0">
											<gml:posList>35.66784040141091 139.73906874105253 11.42 35.66781683487237 139.7390513051794 11.42 35.66781683487237 139.7390513051794 40.75 35.66784040141091 139.73906874105253 42.123 35.66784040141091 139.73906874105253 11.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-de2179c5-ec3c-4fb4-95d4-677b44374aa9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-de2179c5-ec3c-4fb4-95d4-677b44374aa9_0">
											<gml:posList>35.66781762402142 139.73911521586524 42.123 35.66781762402142 139.73911521586524 19.342 35.66781762402142 139.73911521586524 11.42 35.66784040141091 139.73906874105253 11.42 35.66784040141091 139.73906874105253 42.123 35.66781762402142 139.73911521586524 42.123</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_d3442ce2-bfda-4f4c-8058-dff9e43e4aa4_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-750a545c-99f2-4347-b382-292865bf52b5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667789849883846 139.73934228597923 41.417 35.6677841679599 139.7393380951968 41.417 35.66779448130617 139.73931709589135 41.417 35.6678001632222 139.7393212756269 41.417 35.667789849883846 139.73934228597923 41.417</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-af44fff6-7ad0-43bd-bd77-41ece225eec2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-af44fff6-7ad0-43bd-bd77-41ece225eec2_0">
											<gml:posList>35.667789849883846 139.73934228597923 41.417 35.667789849883846 139.73934228597923 43.482 35.6677841679599 139.7393380951968 43.482 35.6677841679599 139.7393380951968 41.417 35.667789849883846 139.73934228597923 41.417</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f88fefcf-c95f-4b90-8bd8-df7de59ee849">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f88fefcf-c95f-4b90-8bd8-df7de59ee849_0">
											<gml:posList>35.6677841679599 139.7393380951968 41.417 35.6677841679599 139.7393380951968 43.482 35.66779448130617 139.73931709589135 43.482 35.66779448130617 139.73931709589135 41.417 35.6677841679599 139.7393380951968 41.417</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1d339624-bd8b-4b3e-a8b4-417796d0ca09">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1d339624-bd8b-4b3e-a8b4-417796d0ca09_0">
											<gml:posList>35.66779448130617 139.73931709589135 43.482 35.6677841679599 139.7393380951968 43.482 35.667789849883846 139.73934228597923 43.482 35.6678001632222 139.7393212756269 43.482 35.66779448130617 139.73931709589135 43.482</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a6cf7152-8ee5-4095-80f3-c52c8448604d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a6cf7152-8ee5-4095-80f3-c52c8448604d_0">
											<gml:posList>35.6678001632222 139.7393212756269 41.417 35.6678001632222 139.7393212756269 43.482 35.667789849883846 139.73934228597923 43.482 35.667789849883846 139.73934228597923 41.417 35.6678001632222 139.7393212756269 41.417</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b37780c3-3623-447d-a888-f6c10c072bc8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b37780c3-3623-447d-a888-f6c10c072bc8_0">
											<gml:posList>35.66779448130617 139.73931709589135 41.417 35.66779448130617 139.73931709589135 43.482 35.6678001632222 139.7393212756269 43.482 35.6678001632222 139.7393212756269 41.417 35.66779448130617 139.73931709589135 41.417</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-a3dafa88-0c7a-4373-873b-bc244227ad40">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a3dafa88-0c7a-4373-873b-bc244227ad40">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a3dafa88-0c7a-4373-873b-bc244227ad40">
											<gml:posList>35.66778146881529 139.73913683099306 11.42 35.66779886466677 139.739101430528 11.42 35.667817615007685 139.7391152158758 11.42 35.6678599030112 139.73902894179722 11.42 35.667946574988626 139.73909279576355 11.42 35.66779061523188 139.7394105487601 11.42 35.66772189108089 139.73935992860876 11.42 35.66774726952182 139.73930831452927 11.42 35.667694057824924 139.7392690535592 11.42 35.66773725490982 139.73918096710048 11.42 35.667733755554366 139.7391783754241 11.42 35.66776140167763 139.7391220309708 11.42 35.66778146881529 139.73913683099306 11.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-6549e7d8-8d92-41ff-816b-909a2df3a183">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6549e7d8-8d92-41ff-816b-909a2df3a183">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6549e7d8-8d92-41ff-816b-909a2df3a183">
											<gml:posList>35.667694057824924 139.7392690535592 42.123 35.6676968784569 139.73926819971686 42.123 35.667737951678596 139.73918443469347 42.123 35.66773725490982 139.73918096710048 42.123 35.667694057824924 139.7392690535592 42.123</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d00adc76-2515-4cd2-8399-1049358bbfc2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d00adc76-2515-4cd2-8399-1049358bbfc2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d00adc76-2515-4cd2-8399-1049358bbfc2">
											<gml:posList>35.66774726952182 139.73930831452927 42.123 35.66775009015404 139.73930746068774 42.123 35.6676968784569 139.73926819971686 42.123 35.667694057824924 139.7392690535592 42.123 35.66774726952182 139.73930831452927 42.123</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-09557828-7109-4abd-acef-9696b837294e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-09557828-7109-4abd-acef-9696b837294e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-09557828-7109-4abd-acef-9696b837294e">
											<gml:posList>35.66773526012363 139.73923510537384 41.417 35.6676968784569 139.73926819971686 41.417 35.66775009015404 139.73930746068774 41.417 35.66777413167122 139.73926371282306 41.417 35.66773526012363 139.73923510537384 41.417</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c3e22032-053f-40f7-be00-2029758c0784">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c3e22032-053f-40f7-be00-2029758c0784">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c3e22032-053f-40f7-be00-2029758c0784">
											<gml:posList>35.66774726952182 139.73930831452927 42.123 35.66772189108089 139.73935992860876 42.123 35.6677247117135 139.7393590747693 42.123 35.66775009015404 139.73930746068774 42.123 35.66774726952182 139.73930831452927 42.123</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-7015cfb3-ce3e-417f-a014-4219ee9fe5cc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7015cfb3-ce3e-417f-a014-4219ee9fe5cc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7015cfb3-ce3e-417f-a014-4219ee9fe5cc">
											<gml:posList>35.66773725490982 139.73918096710048 42.123 35.667737951678596 139.73918443469347 42.123 35.667752300773024 139.73919497772343 42.123 35.6677551123648 139.73919409075077 42.123 35.66773725490982 139.73918096710048 42.123</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-190e3762-a48f-420d-bae0-9bf7e4d3f4e8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-190e3762-a48f-420d-bae0-9bf7e4d3f4e8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-190e3762-a48f-420d-bae0-9bf7e4d3f4e8">
											<gml:posList>35.66775214267081 139.73920027993972 42.123 35.6677551123648 139.73919409075077 42.123 35.667752300773024 139.73919497772343 42.123 35.667749340092705 139.73920116690155 42.123 35.66775214267081 139.73920027993972 42.123</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-42a990a8-a229-40a7-be2d-6dbe5e2b140e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-42a990a8-a229-40a7-be2d-6dbe5e2b140e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-42a990a8-a229-40a7-be2d-6dbe5e2b140e">
											<gml:posList>35.66779061523188 139.7394105487601 42.123 35.667789900450764 139.73940709222987 42.123 35.6677247117135 139.7393590747693 42.123 35.66772189108089 139.73935992860876 42.123 35.66779061523188 139.7394105487601 42.123</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-3775efe8-973c-4e2e-a880-30c0f05e4092">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3775efe8-973c-4e2e-a880-30c0f05e4092">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3775efe8-973c-4e2e-a880-30c0f05e4092">
											<gml:posList>35.66778757675786 139.73923628112078 46.382 35.66774870520385 139.73920767368006 46.382 35.66773526012363 139.73923510537384 46.382 35.66777413167122 139.73926371282306 46.382 35.66778757675786 139.73923628112078 46.382</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-51eaab27-1427-495d-b081-b4459ac7d241">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-51eaab27-1427-495d-b081-b4459ac7d241">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-51eaab27-1427-495d-b081-b4459ac7d241">
											<gml:posList>35.66775214267081 139.73920027993972 42.123 35.667749340092705 139.73920116690155 42.123 35.667777379938954 139.73922182295672 42.123 35.667776674166156 139.73921836641816 42.123 35.66775214267081 139.73920027993972 42.123</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-52c7135c-95bc-4790-b1f0-e7f7f74357cb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-52c7135c-95bc-4790-b1f0-e7f7f74357cb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-52c7135c-95bc-4790-b1f0-e7f7f74357cb">
											<gml:posList>35.6677551123648 139.73919409075077 19.342 35.66775214267081 139.73920027993972 19.342 35.667776674166156 139.73921836641816 19.342 35.667824730934164 139.7391204432746 19.342 35.667817615007685 139.7391152158758 19.342 35.66779886466677 139.739101430528 19.342 35.66778146881529 139.73913683099306 19.342 35.66776140167763 139.7391220309708 19.342 35.667733755554366 139.7391783754241 19.342 35.66773725490982 139.73918096710048 19.342 35.6677551123648 139.73919409075077 19.342</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b1b1a02e-014a-4390-8d87-02dd54e038b4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b1b1a02e-014a-4390-8d87-02dd54e038b4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b1b1a02e-014a-4390-8d87-02dd54e038b4">
											<gml:posList>35.667776674166156 139.73921836641816 42.123 35.667777379938954 139.73922182295672 42.123 35.66782754255129 139.73911958943623 42.123 35.667824730934164 139.7391204432746 42.123 35.667776674166156 139.73921836641816 42.123</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-9311401e-5be8-4ddf-9ec7-5d449a0882bf">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9311401e-5be8-4ddf-9ec7-5d449a0882bf">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9311401e-5be8-4ddf-9ec7-5d449a0882bf">
											<gml:posList>35.66777413167122 139.73926371282306 41.417 35.66775009015404 139.73930746068774 41.417 35.6677247117135 139.7393590747693 41.417 35.667789900450764 139.73940709222987 41.417 35.66794374536159 139.73909367171714 41.417 35.66786059978434 139.73903240939418 41.417 35.667820426616125 139.73911435099146 41.417 35.66782754255129 139.73911958943623 41.417 35.667777379938954 139.73922182295672 41.417 35.667749340092705 139.73920116690155 41.417 35.667752300773024 139.73919497772343 41.417 35.667737951678596 139.73918443469347 41.417 35.6676968784569 139.73926819971686 41.417 35.66773526012363 139.73923510537384 41.417 35.66774870520385 139.73920767368006 41.417 35.66778757675786 139.73923628112078 41.417 35.66777413167122 139.73926371282306 41.417</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-94e3b881-7b35-4c32-a738-2c3f06c58252">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-94e3b881-7b35-4c32-a738-2c3f06c58252">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-94e3b881-7b35-4c32-a738-2c3f06c58252">
											<gml:posList>35.667824730934164 139.7391204432746 42.123 35.66782754255129 139.73911958943623 42.123 35.667820426616125 139.73911435099146 42.123 35.667817615007685 139.7391152158758 42.123 35.667824730934164 139.7391204432746 42.123</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-7c9b6984-a634-43b3-a51a-291015f9f47b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7c9b6984-a634-43b3-a51a-291015f9f47b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7c9b6984-a634-43b3-a51a-291015f9f47b">
											<gml:posList>35.667817615007685 139.7391152158758 42.123 35.667820426616125 139.73911435099146 42.123 35.66786059978434 139.73903240939418 42.123 35.6678599030112 139.73902894179722 42.123 35.667817615007685 139.7391152158758 42.123</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-56538521-a75d-4e8b-b06a-0396a215191c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-56538521-a75d-4e8b-b06a-0396a215191c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-56538521-a75d-4e8b-b06a-0396a215191c">
											<gml:posList>35.667946574988626 139.73909279576355 42.123 35.66794374536159 139.73909367171714 42.123 35.667789900450764 139.73940709222987 42.123 35.66779061523188 139.7394105487601 42.123 35.667946574988626 139.73909279576355 42.123</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-9245a68b-e00f-4610-8d54-1dddd1165678">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9245a68b-e00f-4610-8d54-1dddd1165678">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9245a68b-e00f-4610-8d54-1dddd1165678">
											<gml:posList>35.6678599030112 139.73902894179722 42.123 35.66786059978434 139.73903240939418 42.123 35.66794374536159 139.73909367171714 42.123 35.667946574988626 139.73909279576355 42.123 35.6678599030112 139.73902894179722 42.123</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-fb74868d-8cb6-4025-bf0d-1ff5eea30303">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fb74868d-8cb6-4025-bf0d-1ff5eea30303">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fb74868d-8cb6-4025-bf0d-1ff5eea30303">
											<gml:posList>35.667820426616125 139.73911435099146 42.123 35.667820426616125 139.73911435099146 41.417 35.66786059978434 139.73903240939418 41.417 35.66786059978434 139.73903240939418 42.123 35.667820426616125 139.73911435099146 42.123</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3c002e94-fa50-4f18-b59c-cdc64455ddfc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3c002e94-fa50-4f18-b59c-cdc64455ddfc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3c002e94-fa50-4f18-b59c-cdc64455ddfc">
											<gml:posList>35.667777379938954 139.73922182295672 42.123 35.667777379938954 139.73922182295672 41.417 35.66782754255129 139.73911958943623 41.417 35.66782754255129 139.73911958943623 42.123 35.667777379938954 139.73922182295672 42.123</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2c072fa5-e372-470e-b84a-ab692da86c93">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2c072fa5-e372-470e-b84a-ab692da86c93">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2c072fa5-e372-470e-b84a-ab692da86c93">
											<gml:posList>35.667694057824924 139.7392690535592 11.42 35.667694057824924 139.7392690535592 42.123 35.66773725490982 139.73918096710048 42.123 35.66773725490982 139.73918096710048 19.342 35.66773725490982 139.73918096710048 11.42 35.667694057824924 139.7392690535592 11.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-24809edc-b60c-4412-9ae8-943976d73c0e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-24809edc-b60c-4412-9ae8-943976d73c0e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-24809edc-b60c-4412-9ae8-943976d73c0e">
											<gml:posList>35.6676968784569 139.73926819971686 42.123 35.6676968784569 139.73926819971686 41.417 35.667737951678596 139.73918443469347 41.417 35.667737951678596 139.73918443469347 42.123 35.6676968784569 139.73926819971686 42.123</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d20144b4-ed5c-49a6-b0ea-33cd9db69e77">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d20144b4-ed5c-49a6-b0ea-33cd9db69e77">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d20144b4-ed5c-49a6-b0ea-33cd9db69e77">
											<gml:posList>35.667694057824924 139.7392690535592 11.42 35.66774726952182 139.73930831452927 11.42 35.66774726952182 139.73930831452927 42.123 35.667694057824924 139.7392690535592 42.123 35.667694057824924 139.7392690535592 11.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b3afea92-15f6-47a0-8791-cb5224677e11">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b3afea92-15f6-47a0-8791-cb5224677e11">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b3afea92-15f6-47a0-8791-cb5224677e11">
											<gml:posList>35.66775009015404 139.73930746068774 42.123 35.66775009015404 139.73930746068774 41.417 35.6676968784569 139.73926819971686 41.417 35.6676968784569 139.73926819971686 42.123 35.66775009015404 139.73930746068774 42.123</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-37666528-3fe8-4a3d-80b9-ec7aedec2d47">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-37666528-3fe8-4a3d-80b9-ec7aedec2d47">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-37666528-3fe8-4a3d-80b9-ec7aedec2d47">
											<gml:posList>35.66774726952182 139.73930831452927 11.42 35.66772189108089 139.73935992860876 11.42 35.66772189108089 139.73935992860876 42.123 35.66774726952182 139.73930831452927 42.123 35.66774726952182 139.73930831452927 11.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-071b68fa-a3a3-4998-8f21-f9fb93dbfd5d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-071b68fa-a3a3-4998-8f21-f9fb93dbfd5d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-071b68fa-a3a3-4998-8f21-f9fb93dbfd5d">
											<gml:posList>35.667733755554366 139.7391783754241 11.42 35.66773725490982 139.73918096710048 11.42 35.66773725490982 139.73918096710048 19.342 35.667733755554366 139.7391783754241 19.342 35.667733755554366 139.7391783754241 11.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e2014921-1513-4d75-9743-9a45e7468220">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e2014921-1513-4d75-9743-9a45e7468220">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e2014921-1513-4d75-9743-9a45e7468220">
											<gml:posList>35.6677247117135 139.7393590747693 42.123 35.6677247117135 139.7393590747693 41.417 35.66775009015404 139.73930746068774 41.417 35.66775009015404 139.73930746068774 42.123 35.6677247117135 139.7393590747693 42.123</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ec61766a-d226-4c48-a144-20a9be9e5573">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ec61766a-d226-4c48-a144-20a9be9e5573">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ec61766a-d226-4c48-a144-20a9be9e5573">
											<gml:posList>35.66773526012363 139.73923510537384 41.417 35.66773526012363 139.73923510537384 46.382 35.66774870520385 139.73920767368006 46.382 35.66774870520385 139.73920767368006 41.417 35.66773526012363 139.73923510537384 41.417</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-80bb4536-f157-4c87-a63c-0dda551c971c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-80bb4536-f157-4c87-a63c-0dda551c971c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-80bb4536-f157-4c87-a63c-0dda551c971c">
											<gml:posList>35.667737951678596 139.73918443469347 42.123 35.667737951678596 139.73918443469347 41.417 35.667752300773024 139.73919497772343 41.417 35.667752300773024 139.73919497772343 42.123 35.667737951678596 139.73918443469347 42.123</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a9e77cc2-cc1e-4146-9571-019a61548551">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a9e77cc2-cc1e-4146-9571-019a61548551">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a9e77cc2-cc1e-4146-9571-019a61548551">
											<gml:posList>35.66773725490982 139.73918096710048 42.123 35.6677551123648 139.73919409075077 42.123 35.6677551123648 139.73919409075077 19.342 35.66773725490982 139.73918096710048 19.342 35.66773725490982 139.73918096710048 42.123</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8668d024-1800-48e3-b0e8-52dc7f6b9617">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8668d024-1800-48e3-b0e8-52dc7f6b9617">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8668d024-1800-48e3-b0e8-52dc7f6b9617">
											<gml:posList>35.66776140167763 139.7391220309708 11.42 35.667733755554366 139.7391783754241 11.42 35.667733755554366 139.7391783754241 19.342 35.66776140167763 139.7391220309708 19.342 35.66776140167763 139.7391220309708 11.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0eae1dfc-23f4-4af2-9ed3-50723b023638">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0eae1dfc-23f4-4af2-9ed3-50723b023638">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0eae1dfc-23f4-4af2-9ed3-50723b023638">
											<gml:posList>35.667752300773024 139.73919497772343 42.123 35.667752300773024 139.73919497772343 41.417 35.667749340092705 139.73920116690155 41.417 35.667749340092705 139.73920116690155 42.123 35.667752300773024 139.73919497772343 42.123</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b4e83caa-ca4e-4b34-b41c-eabdfbc7d9d3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b4e83caa-ca4e-4b34-b41c-eabdfbc7d9d3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b4e83caa-ca4e-4b34-b41c-eabdfbc7d9d3">
											<gml:posList>35.6677551123648 139.73919409075077 42.123 35.66775214267081 139.73920027993972 42.123 35.66775214267081 139.73920027993972 19.342 35.6677551123648 139.73919409075077 19.342 35.6677551123648 139.73919409075077 42.123</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0438923f-f6ae-4014-8f06-d8d7572e7964">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0438923f-f6ae-4014-8f06-d8d7572e7964">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0438923f-f6ae-4014-8f06-d8d7572e7964">
											<gml:posList>35.66777413167122 139.73926371282306 41.417 35.66777413167122 139.73926371282306 46.382 35.66773526012363 139.73923510537384 46.382 35.66773526012363 139.73923510537384 41.417 35.66777413167122 139.73926371282306 41.417</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ba94f69b-ae4d-4189-97c7-0b5662c85f73">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ba94f69b-ae4d-4189-97c7-0b5662c85f73">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ba94f69b-ae4d-4189-97c7-0b5662c85f73">
											<gml:posList>35.66772189108089 139.73935992860876 11.42 35.66779061523188 139.7394105487601 11.42 35.66779061523188 139.7394105487601 42.123 35.66772189108089 139.73935992860876 42.123 35.66772189108089 139.73935992860876 11.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3e10f055-067d-4a51-9aba-c63c17f450c5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3e10f055-067d-4a51-9aba-c63c17f450c5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3e10f055-067d-4a51-9aba-c63c17f450c5">
											<gml:posList>35.667789900450764 139.73940709222987 42.123 35.667789900450764 139.73940709222987 41.417 35.6677247117135 139.7393590747693 41.417 35.6677247117135 139.7393590747693 42.123 35.667789900450764 139.73940709222987 42.123</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e0467440-40dd-4fe1-adbc-8323256a841d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e0467440-40dd-4fe1-adbc-8323256a841d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e0467440-40dd-4fe1-adbc-8323256a841d">
											<gml:posList>35.667749340092705 139.73920116690155 42.123 35.667749340092705 139.73920116690155 41.417 35.667777379938954 139.73922182295672 41.417 35.667777379938954 139.73922182295672 42.123 35.667749340092705 139.73920116690155 42.123</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-06cb9ffa-837d-4d66-bf62-652f00926e29">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-06cb9ffa-837d-4d66-bf62-652f00926e29">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-06cb9ffa-837d-4d66-bf62-652f00926e29">
											<gml:posList>35.66775214267081 139.73920027993972 42.123 35.667776674166156 139.73921836641816 42.123 35.667776674166156 139.73921836641816 19.342 35.66775214267081 139.73920027993972 19.342 35.66775214267081 139.73920027993972 42.123</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ee818d4a-7d71-47db-8d0e-b315b94a88cd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ee818d4a-7d71-47db-8d0e-b315b94a88cd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ee818d4a-7d71-47db-8d0e-b315b94a88cd">
											<gml:posList>35.66774870520385 139.73920767368006 41.417 35.66774870520385 139.73920767368006 46.382 35.66778757675786 139.73923628112078 46.382 35.66778757675786 139.73923628112078 41.417 35.66774870520385 139.73920767368006 41.417</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6206a02b-0318-4aac-a8db-fc3cc6f75725">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6206a02b-0318-4aac-a8db-fc3cc6f75725">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6206a02b-0318-4aac-a8db-fc3cc6f75725">
											<gml:posList>35.66778146881529 139.73913683099306 11.42 35.66776140167763 139.7391220309708 11.42 35.66776140167763 139.7391220309708 19.342 35.66778146881529 139.73913683099306 19.342 35.66778146881529 139.73913683099306 11.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9de41461-3130-4908-bd42-536c70c59949">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9de41461-3130-4908-bd42-536c70c59949">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9de41461-3130-4908-bd42-536c70c59949">
											<gml:posList>35.66778757675786 139.73923628112078 41.417 35.66778757675786 139.73923628112078 46.382 35.66777413167122 139.73926371282306 46.382 35.66777413167122 139.73926371282306 41.417 35.66778757675786 139.73923628112078 41.417</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5b8cfa10-69e7-4c28-842c-de598dc4ae2e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5b8cfa10-69e7-4c28-842c-de598dc4ae2e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5b8cfa10-69e7-4c28-842c-de598dc4ae2e">
											<gml:posList>35.66779886466677 139.739101430528 11.42 35.66778146881529 139.73913683099306 11.42 35.66778146881529 139.73913683099306 19.342 35.66779886466677 139.739101430528 19.342 35.66779886466677 139.739101430528 11.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3f9ea2ca-b7df-4f74-89de-237d6039426c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3f9ea2ca-b7df-4f74-89de-237d6039426c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3f9ea2ca-b7df-4f74-89de-237d6039426c">
											<gml:posList>35.667776674166156 139.73921836641816 42.123 35.667824730934164 139.7391204432746 42.123 35.667824730934164 139.7391204432746 19.342 35.667776674166156 139.73921836641816 19.342 35.667776674166156 139.73921836641816 42.123</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ca81e977-d37a-48db-b9ba-41a2f416cdab">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ca81e977-d37a-48db-b9ba-41a2f416cdab">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ca81e977-d37a-48db-b9ba-41a2f416cdab">
											<gml:posList>35.667817615007685 139.7391152158758 11.42 35.66779886466677 139.739101430528 11.42 35.66779886466677 139.739101430528 19.342 35.667817615007685 139.7391152158758 19.342 35.667817615007685 139.7391152158758 11.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8515ed6e-1635-4de5-ae83-12c1654d1174">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8515ed6e-1635-4de5-ae83-12c1654d1174">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8515ed6e-1635-4de5-ae83-12c1654d1174">
											<gml:posList>35.667824730934164 139.7391204432746 42.123 35.667817615007685 139.7391152158758 42.123 35.667817615007685 139.7391152158758 19.342 35.667824730934164 139.7391204432746 19.342 35.667824730934164 139.7391204432746 42.123</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-88a08e94-5c60-4790-bacf-faa0265430d3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-88a08e94-5c60-4790-bacf-faa0265430d3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-88a08e94-5c60-4790-bacf-faa0265430d3">
											<gml:posList>35.66782754255129 139.73911958943623 42.123 35.66782754255129 139.73911958943623 41.417 35.667820426616125 139.73911435099146 41.417 35.667820426616125 139.73911435099146 42.123 35.66782754255129 139.73911958943623 42.123</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c3fa6bd5-8360-4851-9016-76e02b6a637c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c3fa6bd5-8360-4851-9016-76e02b6a637c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c3fa6bd5-8360-4851-9016-76e02b6a637c">
											<gml:posList>35.6678599030112 139.73902894179722 42.123 35.6678599030112 139.73902894179722 11.42 35.667817615007685 139.7391152158758 11.42 35.667817615007685 139.7391152158758 19.342 35.667817615007685 139.7391152158758 42.123 35.6678599030112 139.73902894179722 42.123</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-113023be-0239-4b1b-a047-5a894f0643d8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-113023be-0239-4b1b-a047-5a894f0643d8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-113023be-0239-4b1b-a047-5a894f0643d8">
											<gml:posList>35.66794374536159 139.73909367171714 42.123 35.66794374536159 139.73909367171714 41.417 35.667789900450764 139.73940709222987 41.417 35.667789900450764 139.73940709222987 42.123 35.66794374536159 139.73909367171714 42.123</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-47768197-ee77-4a62-8200-23e6e9f139c3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-47768197-ee77-4a62-8200-23e6e9f139c3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-47768197-ee77-4a62-8200-23e6e9f139c3">
											<gml:posList>35.66779061523188 139.7394105487601 11.42 35.667946574988626 139.73909279576355 11.42 35.667946574988626 139.73909279576355 42.123 35.66779061523188 139.7394105487601 42.123 35.66779061523188 139.7394105487601 11.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-af3b77f3-0b24-47ba-9f2e-bbbb3cb4feca">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-af3b77f3-0b24-47ba-9f2e-bbbb3cb4feca">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-af3b77f3-0b24-47ba-9f2e-bbbb3cb4feca">
											<gml:posList>35.66786059978434 139.73903240939418 42.123 35.66786059978434 139.73903240939418 41.417 35.66794374536159 139.73909367171714 41.417 35.66794374536159 139.73909367171714 42.123 35.66786059978434 139.73903240939418 42.123</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-273cedc2-cce0-451d-bbee-b1729377ee05">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-273cedc2-cce0-451d-bbee-b1729377ee05">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-273cedc2-cce0-451d-bbee-b1729377ee05">
											<gml:posList>35.667946574988626 139.73909279576355 11.42 35.6678599030112 139.73902894179722 11.42 35.6678599030112 139.73902894179722 42.123 35.667946574988626 139.73909279576355 42.123 35.667946574988626 139.73909279576355 11.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区六本木二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-3975</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">410.37275</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">211</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1320</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>7</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.11</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>