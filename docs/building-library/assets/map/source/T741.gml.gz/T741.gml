<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_d429afb9-2999-4e8d-82e1-7435b3f37eba">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>0.80</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>18</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103018002</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="再開発等促進区を定める地区計画">
				<gen:value>虎ノ門一・二丁目地区</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">412</bldg:usage>
			<bldg:measuredHeight uom="m">53.9</bldg:measuredHeight>
			<bldg:storeysAboveGround>12</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>1</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.667871753071914 139.74596742983084 0 35.667879127652995 139.74595686190065 0 35.66787247046415 139.74594989918285 0 35.66799443442971 139.74577496440654 0 35.667980188427656 139.74575665476584 0 35.66798608627326 139.74574819818775 0 35.667845650725646 139.7455851040685 0 35.66757576350787 139.74597221485817 0 35.66774089424936 139.746145102055 0 35.66785821224257 139.74597682256405 0 35.66786579855699 139.74598476735702 0 35.667875298167615 139.74597114844155 0 35.667871753071914 139.74596742983084 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667871753071914 139.74596742983084 6.53 35.667875298167615 139.74597114844155 6.53 35.66786579855699 139.74598476735702 6.53 35.66785821224257 139.74597682256405 6.53 35.66774089424936 139.746145102055 6.53 35.66757576350787 139.74597221485817 6.53 35.667845650725646 139.7455851040685 6.53 35.66798608627326 139.74574819818775 6.53 35.667980188427656 139.74575665476584 6.53 35.66799443442971 139.74577496440654 6.53 35.66787247046415 139.74594989918285 6.53 35.667879127652995 139.74595686190065 6.53 35.667871753071914 139.74596742983084 6.53</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667871753071914 139.74596742983084 6.53 35.667879127652995 139.74595686190065 6.53 35.667879127652995 139.74595686190065 60.46 35.667871753071914 139.74596742983084 60.46 35.667871753071914 139.74596742983084 6.53</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667879127652995 139.74595686190065 6.53 35.66787247046415 139.74594989918285 6.53 35.66787247046415 139.74594989918285 60.46 35.667879127652995 139.74595686190065 60.46 35.667879127652995 139.74595686190065 6.53</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66787247046415 139.74594989918285 6.53 35.66799443442971 139.74577496440654 6.53 35.66799443442971 139.74577496440654 60.46 35.66787247046415 139.74594989918285 60.46 35.66787247046415 139.74594989918285 6.53</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66799443442971 139.74577496440654 6.53 35.667980188427656 139.74575665476584 6.53 35.667980188427656 139.74575665476584 60.46 35.66799443442971 139.74577496440654 60.46 35.66799443442971 139.74577496440654 6.53</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667980188427656 139.74575665476584 6.53 35.66798608627326 139.74574819818775 6.53 35.66798608627326 139.74574819818775 60.46 35.667980188427656 139.74575665476584 60.46 35.667980188427656 139.74575665476584 6.53</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66798608627326 139.74574819818775 6.53 35.667845650725646 139.7455851040685 6.53 35.667845650725646 139.7455851040685 60.46 35.66798608627326 139.74574819818775 60.46 35.66798608627326 139.74574819818775 6.53</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667845650725646 139.7455851040685 6.53 35.66757576350787 139.74597221485817 6.53 35.66757576350787 139.74597221485817 60.46 35.667845650725646 139.7455851040685 60.46 35.667845650725646 139.7455851040685 6.53</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66757576350787 139.74597221485817 6.53 35.66774089424936 139.746145102055 6.53 35.66774089424936 139.746145102055 60.46 35.66757576350787 139.74597221485817 60.46 35.66757576350787 139.74597221485817 6.53</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66774089424936 139.746145102055 6.53 35.66785821224257 139.74597682256405 6.53 35.66785821224257 139.74597682256405 60.46 35.66774089424936 139.746145102055 60.46 35.66774089424936 139.746145102055 6.53</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66785821224257 139.74597682256405 6.53 35.66786579855699 139.74598476735702 6.53 35.66786579855699 139.74598476735702 60.46 35.66785821224257 139.74597682256405 60.46 35.66785821224257 139.74597682256405 6.53</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66786579855699 139.74598476735702 6.53 35.667875298167615 139.74597114844155 6.53 35.667875298167615 139.74597114844155 60.46 35.66786579855699 139.74598476735702 60.46 35.66786579855699 139.74598476735702 6.53</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667875298167615 139.74597114844155 6.53 35.667871753071914 139.74596742983084 6.53 35.667871753071914 139.74596742983084 60.46 35.667875298167615 139.74597114844155 60.46 35.667875298167615 139.74597114844155 6.53</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667871753071914 139.74596742983084 60.46 35.667879127652995 139.74595686190065 60.46 35.66787247046415 139.74594989918285 60.46 35.66799443442971 139.74577496440654 60.46 35.667980188427656 139.74575665476584 60.46 35.66798608627326 139.74574819818775 60.46 35.667845650725646 139.7455851040685 60.46 35.66757576350787 139.74597221485817 60.46 35.66774089424936 139.746145102055 60.46 35.66785821224257 139.74597682256405 60.46 35.66786579855699 139.74598476735702 60.46 35.667875298167615 139.74597114844155 60.46 35.667871753071914 139.74596742983084 60.46</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-1c25bd92-9a72-47be-adfb-6f181a1b2889"/>
							<gml:surfaceMember xlink:href="#poly-1f03acaf-2e0c-4829-a393-311ccbc8a5b9"/>
							<gml:surfaceMember xlink:href="#poly-21229e6d-3236-4e0b-a0e7-06dffa580260"/>
							<gml:surfaceMember xlink:href="#poly-8c376f6b-b028-4d06-9ed0-4b2e1de161d1"/>
							<gml:surfaceMember xlink:href="#poly-e9230c03-f0bd-4d27-b7a6-a6703e08ea86"/>
							<gml:surfaceMember xlink:href="#poly-81e1bb80-094e-4077-86bb-0995d399f39e"/>
							<gml:surfaceMember xlink:href="#poly-40a389ae-c3df-4604-9e4b-302dc8d2d642"/>
							<gml:surfaceMember xlink:href="#poly-8d7034ff-4491-4ddb-b3b2-b5359e34ca4f"/>
							<gml:surfaceMember xlink:href="#poly-abfd0ff5-038c-4723-8eea-efa70ba38085"/>
							<gml:surfaceMember xlink:href="#poly-fb9900af-2bf2-444e-8ca1-483f09b1b631"/>
							<gml:surfaceMember xlink:href="#poly-88b12a6a-5b52-485d-afe7-c6a93f29f68e"/>
							<gml:surfaceMember xlink:href="#poly-02123fa1-94f1-44d3-bd2b-0f5f7bd2d555"/>
							<gml:surfaceMember xlink:href="#poly-20162f72-d1b8-4abd-963a-f382079f0942"/>
							<gml:surfaceMember xlink:href="#poly-323cd44f-cf28-4099-9c76-28aa65ca9793"/>
							<gml:surfaceMember xlink:href="#poly-038ebccb-728a-40fa-9987-4d64d3fa1002"/>
							<gml:surfaceMember xlink:href="#poly-06ee54f3-52d5-4496-a0d5-9c6fb55f3014"/>
							<gml:surfaceMember xlink:href="#poly-4999b4eb-17d5-4aa8-9711-e583d4c6c41a"/>
							<gml:surfaceMember xlink:href="#poly-9a5f3d99-0140-4a19-9ecd-46b34afd6e30"/>
							<gml:surfaceMember xlink:href="#poly-56d0e681-93ad-4d9b-9302-0ba98c3cfc8f"/>
							<gml:surfaceMember xlink:href="#poly-07d901c9-a5c1-460b-a3f8-254f79900e9b"/>
							<gml:surfaceMember xlink:href="#poly-d2107e40-331b-4fd5-b7bf-57c111850971"/>
							<gml:surfaceMember xlink:href="#poly-c51cb6fe-f5fa-4d8c-a0c3-34629cc3a0fc"/>
							<gml:surfaceMember xlink:href="#poly-0104fd1c-0d28-439f-bc57-b9bae81aecc0"/>
							<gml:surfaceMember xlink:href="#poly-c8878a26-0b5c-46e8-875c-0525efaa3227"/>
							<gml:surfaceMember xlink:href="#poly-79af40cc-75d5-4a35-875f-4a5c9f38dae0"/>
							<gml:surfaceMember xlink:href="#poly-78759809-6531-4d6c-af01-388b432e23c4"/>
							<gml:surfaceMember xlink:href="#poly-1d55e8df-9320-4159-9f68-3f3cf36928df"/>
							<gml:surfaceMember xlink:href="#poly-fc84b100-e7cf-43c1-8acb-2e448f819c0f"/>
							<gml:surfaceMember xlink:href="#poly-c1b5219d-bfc3-4911-8f03-4eefd72380be"/>
							<gml:surfaceMember xlink:href="#poly-e0a78ec3-98c1-4432-aa89-731c6190a1ff"/>
							<gml:surfaceMember xlink:href="#poly-27321116-278d-4edf-8404-32ff4fac9557"/>
							<gml:surfaceMember xlink:href="#poly-3edc63d8-3ce5-45d9-b69b-fe9ce746b613"/>
							<gml:surfaceMember xlink:href="#poly-38b1d8db-490e-464c-9153-bbb0fd235261"/>
							<gml:surfaceMember xlink:href="#poly-c46c9eb3-9baf-4bd1-9a6e-1a3cba2dae86"/>
							<gml:surfaceMember xlink:href="#poly-348f3398-2161-4154-9cb2-dfb098dbf4d6"/>
							<gml:surfaceMember xlink:href="#poly-8b7d88ba-3d2d-43e6-810b-50a76dd94403"/>
							<gml:surfaceMember xlink:href="#poly-c937da68-295f-4b0f-b6d8-920e853a7d4a"/>
							<gml:surfaceMember xlink:href="#poly-f058253b-2681-47ad-8225-59f1837bf6d6"/>
							<gml:surfaceMember xlink:href="#poly-3b1fd8d3-b107-487e-93d4-51a252c3ac6f"/>
							<gml:surfaceMember xlink:href="#poly-ed5a616d-5564-4a9f-aa5f-b6d288742f46"/>
							<gml:surfaceMember xlink:href="#poly-c267b9ae-4a4f-49e6-9a92-319c66883d9d"/>
							<gml:surfaceMember xlink:href="#poly-f4506a45-dbe2-4910-b5ea-51ec5321c798"/>
							<gml:surfaceMember xlink:href="#poly-7d845849-0641-4bdc-92dd-b1d8ed2cc06a"/>
							<gml:surfaceMember xlink:href="#poly-d4fc6eb9-2c5a-4ebf-887b-3e617d9d26ac"/>
							<gml:surfaceMember xlink:href="#poly-fc9a0a8a-9ad6-4d7d-bde5-0a57c3cefd92"/>
							<gml:surfaceMember xlink:href="#poly-b753b6b9-ad63-4150-b7f2-16bbd2ab9bef"/>
							<gml:surfaceMember xlink:href="#poly-3ce221bd-0506-4596-a66a-c8e6b58ae20d"/>
							<gml:surfaceMember xlink:href="#poly-17754e0f-1159-4499-9a3c-6ac1da55fc55"/>
							<gml:surfaceMember xlink:href="#poly-bb62eb16-8ec9-48d2-81ec-7d2b3a02cc4f"/>
							<gml:surfaceMember xlink:href="#poly-fb1311c0-8458-4809-b352-efc14d172da3"/>
							<gml:surfaceMember xlink:href="#poly-3e5f5d26-4854-4c23-8653-211734aa284b"/>
							<gml:surfaceMember xlink:href="#poly-248dbd2e-01ce-4a00-9025-835fb2346f86"/>
							<gml:surfaceMember xlink:href="#poly-c65c3bc9-d29c-43a3-94f9-6a148e958d72"/>
							<gml:surfaceMember xlink:href="#poly-9b0e6f87-46cc-428b-8053-87e5a69c4fa7"/>
							<gml:surfaceMember xlink:href="#poly-ef9df16d-8c4b-441d-b463-497317dd619d"/>
							<gml:surfaceMember xlink:href="#poly-fcecffb1-f5a4-4222-963c-2f53fe253984"/>
							<gml:surfaceMember xlink:href="#poly-cd838f92-bf42-431c-b11d-62cf06b967d1"/>
							<gml:surfaceMember xlink:href="#poly-6bb4c969-fdcb-4de2-a786-6eaffdf64bb8"/>
							<gml:surfaceMember xlink:href="#poly-7791ac46-176b-4aef-808b-9f1d97149e3a"/>
							<gml:surfaceMember xlink:href="#poly-3abccfbd-0671-419f-a7c2-1b70cdae1409"/>
							<gml:surfaceMember xlink:href="#poly-9c26f172-6372-44bf-ae1a-b3fcaf324fb2"/>
							<gml:surfaceMember xlink:href="#poly-2c6fa9cf-89fb-4a22-b17a-f7b0be6e8460"/>
							<gml:surfaceMember xlink:href="#poly-8cc998eb-c2b5-469c-880d-5c4fd42ae71f"/>
							<gml:surfaceMember xlink:href="#poly-38aa3837-6e50-4592-b6f6-0c172e9c26bc"/>
							<gml:surfaceMember xlink:href="#poly-4791f50c-dc98-43e5-bbce-ff40554acf01"/>
							<gml:surfaceMember xlink:href="#poly-493fa0f7-1d6d-4a0e-b7db-2ea82ad747dc"/>
							<gml:surfaceMember xlink:href="#poly-75e86810-a680-48e1-8a7d-513fcf526403"/>
							<gml:surfaceMember xlink:href="#poly-a120ac5a-afc6-47f1-a617-511634e72010"/>
							<gml:surfaceMember xlink:href="#poly-680e8b8e-b07a-4196-9749-0b0dff4e0737"/>
							<gml:surfaceMember xlink:href="#poly-26e5b787-c82d-42fe-a8bc-4e06db46458b"/>
							<gml:surfaceMember xlink:href="#poly-5c1baa5c-f71c-49b9-9692-960c8a60053d"/>
							<gml:surfaceMember xlink:href="#poly-270160e2-0c41-4674-88f9-369b071c0641"/>
							<gml:surfaceMember xlink:href="#poly-c6f2d61a-f126-4da7-b90e-3d36fed8668a"/>
							<gml:surfaceMember xlink:href="#poly-e0097cfd-b651-4c04-8113-a57d296845b7"/>
							<gml:surfaceMember xlink:href="#poly-df3f505e-e333-4efd-9084-3bae577829af"/>
							<gml:surfaceMember xlink:href="#poly-3df6ec2d-6576-4aa7-8872-12ba1cd571e8"/>
							<gml:surfaceMember xlink:href="#poly-5cb52611-fb94-4990-bff6-0ee4eaa26ab6"/>
							<gml:surfaceMember xlink:href="#poly-a55075ee-51bd-4d24-8388-398ac6ff15bf"/>
							<gml:surfaceMember xlink:href="#poly-df286174-4e74-4f2a-a6f7-e708427a25e4"/>
							<gml:surfaceMember xlink:href="#poly-d96f72c2-5402-4d00-8778-d34496265da5"/>
							<gml:surfaceMember xlink:href="#poly-4e785c2d-21fc-469d-868b-c8680a350e57"/>
							<gml:surfaceMember xlink:href="#poly-f10ba7a7-d683-4aa3-bb80-6cc65c8cd462"/>
							<gml:surfaceMember xlink:href="#poly-c119d0b7-d498-4e63-9490-1546c210fd7a"/>
							<gml:surfaceMember xlink:href="#poly-98f270dc-61c6-4f24-b788-b665975ba796"/>
							<gml:surfaceMember xlink:href="#poly-c968b74a-2eeb-498b-b931-a7196cf09969"/>
							<gml:surfaceMember xlink:href="#poly-de1cd581-0884-485f-befb-f4fe5be0063a"/>
							<gml:surfaceMember xlink:href="#poly-9912a08a-3d42-4408-911e-7ecab63119f0"/>
							<gml:surfaceMember xlink:href="#poly-ade4f58d-9e4c-4151-af8c-ae0dd372653b"/>
							<gml:surfaceMember xlink:href="#poly-da55380f-be08-4783-b1aa-7340c4bd2cac"/>
							<gml:surfaceMember xlink:href="#poly-27b137f4-a172-47f7-a4b1-5d869802a15c"/>
							<gml:surfaceMember xlink:href="#poly-37c41926-a77d-4e39-aef8-5c211b603238"/>
							<gml:surfaceMember xlink:href="#poly-c835a913-0643-4294-91b3-29c7efc75a15"/>
							<gml:surfaceMember xlink:href="#poly-0a9a857d-515c-4430-89f0-c82a314073e6"/>
							<gml:surfaceMember xlink:href="#poly-09bd0074-859d-459d-8976-9999f659ac84"/>
							<gml:surfaceMember xlink:href="#poly-d99e90e0-78e5-4481-a3aa-0f28782b5f74"/>
							<gml:surfaceMember xlink:href="#poly-e1913502-5680-41bd-b3dc-487831fb6285"/>
							<gml:surfaceMember xlink:href="#poly-db0a988b-9bdc-4219-8764-08156e4ae861"/>
							<gml:surfaceMember xlink:href="#poly-944fb6fc-2210-4dbc-bf30-7ddf596f0a0f"/>
							<gml:surfaceMember xlink:href="#poly-55079903-a91e-492e-8a1e-abf134cea6e5"/>
							<gml:surfaceMember xlink:href="#poly-df801bf3-f3df-4d0a-9e9e-8439e4095f0f"/>
							<gml:surfaceMember xlink:href="#poly-ee0e7b31-be96-4af8-ad89-8399945e4d5b"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_d429afb9-2999-4e8d-82e1-7435b3f37eba_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6a7f356d-764a-43e0-a519-94ca34fd356b">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66760242899099 139.74596372466456 14.3 35.667618566827684 139.74598062936838 14.3 35.66763366728208 139.7459964306207 14.3 35.66762603156338 139.74600736331328 14.3 35.66761094012412 139.74599156205056 14.3 35.667594802296954 139.74597466839202 14.3 35.66760242899099 139.74596372466456 14.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9d5ea74c-6fb9-492a-aee2-cbb265cfd585">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6676560117463 139.74594592659045 61.55 35.667692579443084 139.745894843682 61.55 35.66770180769716 139.74590476387502 61.55 35.667665239996225 139.74595584678485 61.55 35.6676560117463 139.74594592659045 61.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5779695f-947a-4db4-96a4-7485ec1ce487">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667703242565295 139.7458698462485 61.55 35.66772173007171 139.74584549197908 61.55 35.667736678208875 139.74586253053272 61.55 35.66771819971278 139.74588688479292 61.55 35.667703242565295 139.7458698462485 61.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bef73e7a-ec3c-4cc6-bf0a-0539b74095a7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66773495681522 139.74602431059694 61.55 35.667744915691074 139.74603494799797 61.55 35.667736892626934 139.74604622354647 61.55 35.6677268527166 139.74603570773817 61.55 35.66773495681522 139.74602431059694 61.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8124fb0d-f44a-410d-973f-ce49c59b264c">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66778696841836 139.74597783908126 61.55 35.667756362641285 139.74602183509992 61.55 35.667744933581425 139.7460098958842 61.55 35.6677755393542 139.74596589986726 61.55 35.66778696841836 139.74597783908126 61.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fb8e00d5-375b-4ea6-9482-c6c9f1270702">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66779797091044 139.7460354646233 14.3 35.66775438072955 139.7460979876805 14.3 35.667745459374345 139.74608864151148 14.3 35.667789049558465 139.74602612950204 14.3 35.66779797091044 139.7460354646233 14.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ab999895-a5d6-43b9-bc73-da6afa272701">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66780324533041 139.74581385593552 61.55 35.66778066066957 139.74584383707176 61.55 35.66777194623323 139.7458339715448 61.55 35.66779452187791 139.74580399041892 61.55 35.66780324533041 139.74581385593552 61.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-074cf065-1c26-461f-b1cb-64a3cf754560">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667776058578646 139.74599825274626 61.55 35.667794727074536 139.7459748482348 61.55 35.66778450563324 139.74596260946487 61.55 35.667775781776086 139.74595216954796 61.55 35.66778579594331 139.7459396215357 61.55 35.66779451078782 139.7459500614624 61.55 35.667808007066725 139.7459662290063 61.55 35.667784865856085 139.74599943611113 61.55 35.66778130912658 139.74600453214575 61.55 35.667776058578646 139.74599825274626 61.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ada96023-c9dc-43e2-8f90-3f59989a7c73">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667798174910864 139.74585700677176 61.55 35.66781851477138 139.74582649787894 61.55 35.667832739774276 139.7458407315777 61.55 35.66781239991822 139.74587125151822 61.55 35.667798174910864 139.74585700677176 61.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5d78cdf0-6764-4a39-b461-189ee0702adc">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66782752317536 139.74594327643652 61.55 35.66784396716994 139.74592249220308 61.55 35.667857535522195 139.7459386044442 61.55 35.6678480359152 139.74595222336046 61.55 35.66785064287038 139.7459549599056 61.55 35.66784462795979 139.74596359331633 61.55 35.66782752317536 139.74594327643652 61.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-554b6f9e-7252-4005-8d1c-5666872cfede">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66785740264112 139.74587972987578 61.55 35.66784831872519 139.74586997519765 61.55 35.66785744037219 139.7458572182651 61.55 35.66786652428913 139.74586697294288 61.55 35.66785740264112 139.74587972987578 61.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f7994c21-b9b1-4adb-acef-8e985156bb67">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667850930911435 139.7456072895265 14.3 35.667907345826684 139.74566635661188 14.3 35.667885258188065 139.74569802731057 14.3 35.66782885230989 139.74563897125512 14.3 35.667850930911435 139.7456072895265 14.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-76e286fd-5945-4ece-9446-e2e8e8fb871a">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667870214681045 139.74583494681215 61.55 35.667887431444896 139.74581087001883 61.55 35.66789142764127 139.7458151514728 61.55 35.667874210884605 139.74583923931232 61.55 35.667870214681045 139.74583494681215 61.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-841651b1-9379-424b-8c1c-aec933c4d0ea">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-841651b1-9379-424b-8c1c-aec933c4d0ea_0">
											<gml:posList>35.66760242899099 139.74596372466456 14.3 35.667594802296954 139.74597466839202 14.3 35.667594802296954 139.74597466839202 18.5 35.66760242899099 139.74596372466456 18.5 35.66760242899099 139.74596372466456 14.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-849380ab-6482-44f3-9711-056d6afe32a7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-849380ab-6482-44f3-9711-056d6afe32a7_0">
											<gml:posList>35.667594802296954 139.74597466839202 14.3 35.66761094012412 139.74599156205056 14.3 35.66761094012412 139.74599156205056 18.5 35.667594802296954 139.74597466839202 18.5 35.667594802296954 139.74597466839202 14.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-adf250cd-c585-47c8-9ebd-7bfbaa0d1c5d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-adf250cd-c585-47c8-9ebd-7bfbaa0d1c5d_0">
											<gml:posList>35.66761094012412 139.74599156205056 18.5 35.667618566827684 139.74598062936838 18.5 35.66760242899099 139.74596372466456 18.5 35.667594802296954 139.74597466839202 18.5 35.66761094012412 139.74599156205056 18.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-61477b3c-0264-4526-993c-2d65db8ed2dd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-61477b3c-0264-4526-993c-2d65db8ed2dd_0">
											<gml:posList>35.667618566827684 139.74598062936838 18.5 35.667618566827684 139.74598062936838 14.3 35.66760242899099 139.74596372466456 14.3 35.66760242899099 139.74596372466456 18.5 35.667618566827684 139.74598062936838 18.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-30376832-bc09-4c75-af99-bda93461f661">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-30376832-bc09-4c75-af99-bda93461f661_0">
											<gml:posList>35.66761094012412 139.74599156205056 18.5 35.66761094012412 139.74599156205056 34.468 35.667618566827684 139.74598062936838 34.468 35.667618566827684 139.74598062936838 18.5 35.66761094012412 139.74599156205056 18.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a10712ec-6e1c-4f88-a8e3-a0b3c90282eb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a10712ec-6e1c-4f88-a8e3-a0b3c90282eb_0">
											<gml:posList>35.66762603156338 139.74600736331328 14.3 35.66762603156338 139.74600736331328 34.468 35.66761094012412 139.74599156205056 34.468 35.66761094012412 139.74599156205056 18.5 35.66761094012412 139.74599156205056 14.3 35.66762603156338 139.74600736331328 14.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ae48f647-208f-4bf5-8fb6-cda4941b3ec8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ae48f647-208f-4bf5-8fb6-cda4941b3ec8_0">
											<gml:posList>35.66762603156338 139.74600736331328 34.468 35.66763366728208 139.7459964306207 34.468 35.667618566827684 139.74598062936838 34.468 35.66761094012412 139.74599156205056 34.468 35.66762603156338 139.74600736331328 34.468</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0bff3689-83ee-4a66-ae80-acb0803343dd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0bff3689-83ee-4a66-ae80-acb0803343dd_0">
											<gml:posList>35.667618566827684 139.74598062936838 18.5 35.667618566827684 139.74598062936838 34.468 35.66763366728208 139.7459964306207 34.468 35.66763366728208 139.7459964306207 14.3 35.667618566827684 139.74598062936838 14.3 35.667618566827684 139.74598062936838 18.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-683cfa37-8985-4ee8-aef3-a7b0d498bc56">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-683cfa37-8985-4ee8-aef3-a7b0d498bc56_0">
											<gml:posList>35.66762603156338 139.74600736331328 14.3 35.66763366728208 139.7459964306207 14.3 35.66763366728208 139.7459964306207 34.468 35.66762603156338 139.74600736331328 34.468 35.66762603156338 139.74600736331328 14.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8cfc1705-7ac7-4153-b86a-d4270d69aa2c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8cfc1705-7ac7-4153-b86a-d4270d69aa2c_0">
											<gml:posList>35.6676560117463 139.74594592659045 61.55 35.667665239996225 139.74595584678485 61.55 35.667665239996225 139.74595584678485 64.276 35.6676560117463 139.74594592659045 64.276 35.6676560117463 139.74594592659045 61.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-83f06ec3-d11f-45e5-a466-3b881b03dc61">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-83f06ec3-d11f-45e5-a466-3b881b03dc61_0">
											<gml:posList>35.667692579443084 139.745894843682 61.55 35.6676560117463 139.74594592659045 61.55 35.6676560117463 139.74594592659045 64.276 35.667692579443084 139.745894843682 64.276 35.667692579443084 139.745894843682 61.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-555bc813-2285-4eac-a6da-ee4d0fee18bb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-555bc813-2285-4eac-a6da-ee4d0fee18bb_0">
											<gml:posList>35.66770180769716 139.74590476387502 64.276 35.667692579443084 139.745894843682 64.276 35.6676560117463 139.74594592659045 64.276 35.667665239996225 139.74595584678485 64.276 35.66770180769716 139.74590476387502 64.276</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-79453014-3453-4d4f-a1ab-1c6dfc925f8c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-79453014-3453-4d4f-a1ab-1c6dfc925f8c_0">
											<gml:posList>35.66770180769716 139.74590476387502 61.55 35.66770180769716 139.74590476387502 64.276 35.667665239996225 139.74595584678485 64.276 35.667665239996225 139.74595584678485 61.55 35.66770180769716 139.74590476387502 61.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-426e1bb3-d812-4283-8ef5-4e0b11f39437">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-426e1bb3-d812-4283-8ef5-4e0b11f39437_0">
											<gml:posList>35.66770180769716 139.74590476387502 61.55 35.667692579443084 139.745894843682 61.55 35.667692579443084 139.745894843682 64.276 35.66770180769716 139.74590476387502 64.276 35.66770180769716 139.74590476387502 61.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b45f0936-a790-43e1-acb9-4c78c2d364e7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b45f0936-a790-43e1-acb9-4c78c2d364e7_0">
											<gml:posList>35.667703242565295 139.7458698462485 61.55 35.66771819971278 139.74588688479292 61.55 35.66771819971278 139.74588688479292 64.276 35.667703242565295 139.7458698462485 64.276 35.667703242565295 139.7458698462485 61.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4041efb7-4e53-4b3f-bca0-b5ab89db8b15">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4041efb7-4e53-4b3f-bca0-b5ab89db8b15_0">
											<gml:posList>35.66772173007171 139.74584549197908 61.55 35.667703242565295 139.7458698462485 61.55 35.667703242565295 139.7458698462485 64.276 35.66772173007171 139.74584549197908 64.276 35.66772173007171 139.74584549197908 61.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f843a586-d396-405e-8860-732c3df5b227">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f843a586-d396-405e-8860-732c3df5b227_0">
											<gml:posList>35.667736678208875 139.74586253053272 64.276 35.66772173007171 139.74584549197908 64.276 35.667703242565295 139.7458698462485 64.276 35.66771819971278 139.74588688479292 64.276 35.667736678208875 139.74586253053272 64.276</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-dfb8e80c-8051-4ce0-8fcf-c2ed6716e5a5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-dfb8e80c-8051-4ce0-8fcf-c2ed6716e5a5_0">
											<gml:posList>35.66771819971278 139.74588688479292 61.55 35.667736678208875 139.74586253053272 61.55 35.667736678208875 139.74586253053272 64.276 35.66771819971278 139.74588688479292 64.276 35.66771819971278 139.74588688479292 61.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9c536f35-21de-4466-b112-95e7fcaf9614">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9c536f35-21de-4466-b112-95e7fcaf9614_0">
											<gml:posList>35.667736678208875 139.74586253053272 61.55 35.66772173007171 139.74584549197908 61.55 35.66772173007171 139.74584549197908 64.276 35.667736678208875 139.74586253053272 64.276 35.667736678208875 139.74586253053272 61.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-949fd7d0-6367-436c-a965-9ebb5925450d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-949fd7d0-6367-436c-a965-9ebb5925450d_0">
											<gml:posList>35.66773495681522 139.74602431059694 61.55 35.6677268527166 139.74603570773817 61.55 35.6677268527166 139.74603570773817 64.884 35.66773495681522 139.74602431059694 64.884 35.66773495681522 139.74602431059694 61.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a785098c-ffe5-4e5b-826b-ed91c5225465">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a785098c-ffe5-4e5b-826b-ed91c5225465_0">
											<gml:posList>35.6677268527166 139.74603570773817 61.55 35.667736892626934 139.74604622354647 61.55 35.667736892626934 139.74604622354647 64.884 35.6677268527166 139.74603570773817 64.884 35.6677268527166 139.74603570773817 61.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7b4bc5ed-b23e-4757-8f54-acc23d64ea5d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7b4bc5ed-b23e-4757-8f54-acc23d64ea5d_0">
											<gml:posList>35.667736892626934 139.74604622354647 64.884 35.667744915691074 139.74603494799797 64.884 35.66773495681522 139.74602431059694 64.884 35.6677268527166 139.74603570773817 64.884 35.667736892626934 139.74604622354647 64.884</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c25affb6-d255-407e-9744-caea81e082ca">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c25affb6-d255-407e-9744-caea81e082ca_0">
											<gml:posList>35.667744915691074 139.74603494799797 61.55 35.66773495681522 139.74602431059694 61.55 35.66773495681522 139.74602431059694 64.884 35.667744915691074 139.74603494799797 64.884 35.667744915691074 139.74603494799797 61.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-04a12f1f-2a8b-470b-a112-cd6ea355a1da">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-04a12f1f-2a8b-470b-a112-cd6ea355a1da_0">
											<gml:posList>35.667744915691074 139.74603494799797 61.55 35.667744915691074 139.74603494799797 64.884 35.667736892626934 139.74604622354647 64.884 35.667736892626934 139.74604622354647 61.55 35.667744915691074 139.74603494799797 61.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-37b91599-0644-4a01-80ed-d515981c0f2c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-37b91599-0644-4a01-80ed-d515981c0f2c_0">
											<gml:posList>35.667745459374345 139.74608864151148 14.3 35.66775438072955 139.7460979876805 14.3 35.66775438072955 139.7460979876805 29.216 35.667745459374345 139.74608864151148 29.216 35.667745459374345 139.74608864151148 14.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c5d94dcd-993e-4f56-959a-b3d2d9acc5a0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c5d94dcd-993e-4f56-959a-b3d2d9acc5a0_0">
											<gml:posList>35.667744933581425 139.7460098958842 61.55 35.667756362641285 139.74602183509992 61.55 35.667756362641285 139.74602183509992 65.843 35.667744933581425 139.7460098958842 65.843 35.667744933581425 139.7460098958842 61.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-24fd09b1-12c6-421f-b0da-20d5e82b7bd9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-24fd09b1-12c6-421f-b0da-20d5e82b7bd9_0">
											<gml:posList>35.6677755393542 139.74596589986726 61.55 35.667744933581425 139.7460098958842 61.55 35.667744933581425 139.7460098958842 65.843 35.6677755393542 139.74596589986726 65.843 35.6677755393542 139.74596589986726 61.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-59933a54-17d0-49e8-8a6e-0a95a29756fb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-59933a54-17d0-49e8-8a6e-0a95a29756fb_0">
											<gml:posList>35.66778696841836 139.74597783908126 65.843 35.6677755393542 139.74596589986726 65.843 35.667744933581425 139.7460098958842 65.843 35.667756362641285 139.74602183509992 65.843 35.66778696841836 139.74597783908126 65.843</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ecc9688b-603b-4c9b-b170-0f047169a645">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ecc9688b-603b-4c9b-b170-0f047169a645_0">
											<gml:posList>35.667745459374345 139.74608864151148 29.216 35.667789049558465 139.74602612950204 29.216 35.667789049558465 139.74602612950204 14.3 35.667745459374345 139.74608864151148 14.3 35.667745459374345 139.74608864151148 29.216</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3dcefe60-e58a-44fb-ada5-8c72bc15bec6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3dcefe60-e58a-44fb-ada5-8c72bc15bec6_0">
											<gml:posList>35.66778696841836 139.74597783908126 61.55 35.66778696841836 139.74597783908126 65.843 35.667756362641285 139.74602183509992 65.843 35.667756362641285 139.74602183509992 61.55 35.66778696841836 139.74597783908126 61.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-230ece64-0997-4f58-9d61-5b04ce6afc0e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-230ece64-0997-4f58-9d61-5b04ce6afc0e_0">
											<gml:posList>35.66779797091044 139.7460354646233 29.216 35.667789049558465 139.74602612950204 29.216 35.667745459374345 139.74608864151148 29.216 35.66775438072955 139.7460979876805 29.216 35.66779797091044 139.7460354646233 29.216</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c5a403f9-1301-4544-a475-aa0faa6f01b1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c5a403f9-1301-4544-a475-aa0faa6f01b1_0">
											<gml:posList>35.66779797091044 139.7460354646233 14.3 35.66779797091044 139.7460354646233 29.216 35.66775438072955 139.7460979876805 29.216 35.66775438072955 139.7460979876805 14.3 35.66779797091044 139.7460354646233 14.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c66d4611-35a0-44fb-aa99-ed22055baa00">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c66d4611-35a0-44fb-aa99-ed22055baa00_0">
											<gml:posList>35.66777194623323 139.7458339715448 61.55 35.66778066066957 139.74584383707176 61.55 35.66778066066957 139.74584383707176 65.65 35.66777194623323 139.7458339715448 65.65 35.66777194623323 139.7458339715448 61.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-05766cb1-cd9c-4df9-aac7-bce6cfda40b7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-05766cb1-cd9c-4df9-aac7-bce6cfda40b7_0">
											<gml:posList>35.66778130912658 139.74600453214575 61.55 35.66778130912658 139.74600453214575 65.118 35.667776058578646 139.74599825274626 65.118 35.667776058578646 139.74599825274626 61.55 35.66778130912658 139.74600453214575 61.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bb045e32-10c1-468c-8ee1-9ac410dbae39">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bb045e32-10c1-468c-8ee1-9ac410dbae39_0">
											<gml:posList>35.667775781776086 139.74595216954796 66.302 35.667775781776086 139.74595216954796 61.55 35.66778450563324 139.74596260946487 61.55 35.66778450563324 139.74596260946487 65.118 35.66778450563324 139.74596260946487 66.302 35.667775781776086 139.74595216954796 66.302</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f3999a60-3376-4709-abbe-c31bfcb837c2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f3999a60-3376-4709-abbe-c31bfcb837c2_0">
											<gml:posList>35.66778579594331 139.7459396215357 61.55 35.667775781776086 139.74595216954796 61.55 35.667775781776086 139.74595216954796 66.302 35.66778579594331 139.7459396215357 66.302 35.66778579594331 139.7459396215357 61.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-77c79f22-5dae-4231-b9db-3d05abdc24d9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-77c79f22-5dae-4231-b9db-3d05abdc24d9_0">
											<gml:posList>35.66778696841836 139.74597783908126 61.55 35.6677755393542 139.74596589986726 61.55 35.6677755393542 139.74596589986726 65.843 35.66778696841836 139.74597783908126 65.843 35.66778696841836 139.74597783908126 61.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-70f10cbe-390a-4eca-9278-b7b3f5897a42">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-70f10cbe-390a-4eca-9278-b7b3f5897a42_0">
											<gml:posList>35.66778130912658 139.74600453214575 65.118 35.66778130912658 139.74600453214575 61.55 35.667784865856085 139.74599943611113 61.55 35.667784865856085 139.74599943611113 65.118 35.66778130912658 139.74600453214575 65.118</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ce9d31fa-6227-4d5a-b153-978b51b660fc">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ce9d31fa-6227-4d5a-b153-978b51b660fc_0">
											<gml:posList>35.66779452187791 139.74580399041892 61.55 35.66777194623323 139.7458339715448 61.55 35.66777194623323 139.7458339715448 65.65 35.66779452187791 139.74580399041892 65.65 35.66779452187791 139.74580399041892 61.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-893ee8e2-01e2-44d8-bcd7-a2ae9bcccd13">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-893ee8e2-01e2-44d8-bcd7-a2ae9bcccd13_0">
											<gml:posList>35.66778579594331 139.7459396215357 66.302 35.667775781776086 139.74595216954796 66.302 35.66778450563324 139.74596260946487 66.302 35.66779451078782 139.7459500614624 66.302 35.66778579594331 139.7459396215357 66.302</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-70303ccf-4e52-4a53-aeb4-2b0f9223ecff">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-70303ccf-4e52-4a53-aeb4-2b0f9223ecff_0">
											<gml:posList>35.667794727074536 139.7459748482348 61.55 35.667776058578646 139.74599825274626 61.55 35.667776058578646 139.74599825274626 65.118 35.667794727074536 139.7459748482348 65.118 35.667794727074536 139.7459748482348 61.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d859065e-3d40-4886-938a-4ea97d4e5837">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d859065e-3d40-4886-938a-4ea97d4e5837_0">
											<gml:posList>35.66780324533041 139.74581385593552 65.65 35.66779452187791 139.74580399041892 65.65 35.66777194623323 139.7458339715448 65.65 35.66778066066957 139.74584383707176 65.65 35.66780324533041 139.74581385593552 65.65</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cfb3ffe9-3e8c-4c21-beab-7c2a9da15f0c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cfb3ffe9-3e8c-4c21-beab-7c2a9da15f0c_0">
											<gml:posList>35.66778450563324 139.74596260946487 65.118 35.66779451078782 139.7459500614624 65.118 35.66779451078782 139.7459500614624 66.302 35.66778450563324 139.74596260946487 66.302 35.66778450563324 139.74596260946487 65.118</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e25b25d4-7402-4971-a526-f96f679d019f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e25b25d4-7402-4971-a526-f96f679d019f_0">
											<gml:posList>35.66778450563324 139.74596260946487 61.55 35.667794727074536 139.7459748482348 61.55 35.667794727074536 139.7459748482348 65.118 35.66778450563324 139.74596260946487 65.118 35.66778450563324 139.74596260946487 61.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3b4ecb4b-3b4e-45e8-96ae-b26c698b9052">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3b4ecb4b-3b4e-45e8-96ae-b26c698b9052_0">
											<gml:posList>35.66779451078782 139.7459500614624 65.118 35.66779451078782 139.7459500614624 61.55 35.66778579594331 139.7459396215357 61.55 35.66778579594331 139.7459396215357 66.302 35.66779451078782 139.7459500614624 66.302 35.66779451078782 139.7459500614624 65.118</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-469ec092-89fe-4576-98e0-c27aa6258e4a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-469ec092-89fe-4576-98e0-c27aa6258e4a_0">
											<gml:posList>35.667784865856085 139.74599943611113 65.118 35.667808007066725 139.7459662290063 65.118 35.66779451078782 139.7459500614624 65.118 35.66778450563324 139.74596260946487 65.118 35.667794727074536 139.7459748482348 65.118 35.667776058578646 139.74599825274626 65.118 35.66778130912658 139.74600453214575 65.118 35.667784865856085 139.74599943611113 65.118</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fb2b16c4-a034-4c0f-98a8-2cc04602f2f6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fb2b16c4-a034-4c0f-98a8-2cc04602f2f6_0">
											<gml:posList>35.66778066066957 139.74584383707176 61.55 35.66780324533041 139.74581385593552 61.55 35.66780324533041 139.74581385593552 65.65 35.66778066066957 139.74584383707176 65.65 35.66778066066957 139.74584383707176 61.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-08c8a93d-7317-41b7-94bd-4f7452ad0d64">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-08c8a93d-7317-41b7-94bd-4f7452ad0d64_0">
											<gml:posList>35.66779797091044 139.7460354646233 14.3 35.667789049558465 139.74602612950204 14.3 35.667789049558465 139.74602612950204 29.216 35.66779797091044 139.7460354646233 29.216 35.66779797091044 139.7460354646233 14.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bb817178-1b6b-49cc-b01a-9b744b796b6b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bb817178-1b6b-49cc-b01a-9b744b796b6b_0">
											<gml:posList>35.667808007066725 139.7459662290063 61.55 35.667808007066725 139.7459662290063 65.118 35.667784865856085 139.74599943611113 65.118 35.667784865856085 139.74599943611113 61.55 35.667808007066725 139.7459662290063 61.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0956b1e0-1c87-4f97-8ef6-327717cd78f2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0956b1e0-1c87-4f97-8ef6-327717cd78f2_0">
											<gml:posList>35.66780324533041 139.74581385593552 61.55 35.66779452187791 139.74580399041892 61.55 35.66779452187791 139.74580399041892 65.65 35.66780324533041 139.74581385593552 65.65 35.66780324533041 139.74581385593552 61.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-275c73ec-ea0d-4068-93c6-c8a4ad2cbb98">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-275c73ec-ea0d-4068-93c6-c8a4ad2cbb98_0">
											<gml:posList>35.66779451078782 139.7459500614624 61.55 35.66779451078782 139.7459500614624 65.118 35.667808007066725 139.7459662290063 65.118 35.667808007066725 139.7459662290063 61.55 35.66779451078782 139.7459500614624 61.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-970ddb5b-23b0-4834-83b2-bafe6bb1a343">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-970ddb5b-23b0-4834-83b2-bafe6bb1a343_0">
											<gml:posList>35.667798174910864 139.74585700677176 61.55 35.66781239991822 139.74587125151822 61.55 35.66781239991822 139.74587125151822 65.843 35.667798174910864 139.74585700677176 65.843 35.667798174910864 139.74585700677176 61.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-93f06c1e-6f08-4d97-bf03-0330e0da38d9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-93f06c1e-6f08-4d97-bf03-0330e0da38d9_0">
											<gml:posList>35.66781851477138 139.74582649787894 61.55 35.667798174910864 139.74585700677176 61.55 35.667798174910864 139.74585700677176 65.843 35.66781851477138 139.74582649787894 65.843 35.66781851477138 139.74582649787894 61.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0ddc5bc2-6c28-40f0-92c1-22abfc93a2a3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0ddc5bc2-6c28-40f0-92c1-22abfc93a2a3_0">
											<gml:posList>35.667832739774276 139.7458407315777 65.843 35.66781851477138 139.74582649787894 65.843 35.667798174910864 139.74585700677176 65.843 35.66781239991822 139.74587125151822 65.843 35.667832739774276 139.7458407315777 65.843</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8f6d25a2-8931-4ec5-a2f9-d191d85a18a8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8f6d25a2-8931-4ec5-a2f9-d191d85a18a8_0">
											<gml:posList>35.667832739774276 139.7458407315777 61.55 35.667832739774276 139.7458407315777 65.843 35.66781239991822 139.74587125151822 65.843 35.66781239991822 139.74587125151822 61.55 35.667832739774276 139.7458407315777 61.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e906a39b-f660-487e-834a-33e7fb25c8e9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e906a39b-f660-487e-834a-33e7fb25c8e9_0">
											<gml:posList>35.667832739774276 139.7458407315777 61.55 35.66781851477138 139.74582649787894 61.55 35.66781851477138 139.74582649787894 65.843 35.667832739774276 139.7458407315777 65.843 35.667832739774276 139.7458407315777 61.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f11a410e-bcf4-4d06-998d-811b88359e25">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f11a410e-bcf4-4d06-998d-811b88359e25_0">
											<gml:posList>35.66784396716994 139.74592249220308 61.55 35.66782752317536 139.74594327643652 61.55 35.66782752317536 139.74594327643652 64.655 35.66784396716994 139.74592249220308 64.655 35.66784396716994 139.74592249220308 61.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1f2e6ad1-f38e-4348-9bc2-5997831ca507">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1f2e6ad1-f38e-4348-9bc2-5997831ca507_0">
											<gml:posList>35.66784462795979 139.74596359331633 61.55 35.66784462795979 139.74596359331633 64.655 35.66782752317536 139.74594327643652 64.655 35.66782752317536 139.74594327643652 61.55 35.66784462795979 139.74596359331633 61.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-eb4ae6b9-54aa-40a4-805b-960a8956bfa4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-eb4ae6b9-54aa-40a4-805b-960a8956bfa4_0">
											<gml:posList>35.667850930911435 139.7456072895265 14.3 35.66782885230989 139.74563897125512 14.3 35.66782885230989 139.74563897125512 16.988 35.667850930911435 139.7456072895265 16.988 35.667850930911435 139.7456072895265 14.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7dc4c8ff-205b-45b8-ad9f-18ff86b5c694">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7dc4c8ff-205b-45b8-ad9f-18ff86b5c694_0">
											<gml:posList>35.66785064287038 139.7459549599056 64.655 35.6678480359152 139.74595222336046 64.655 35.667857535522195 139.7459386044442 64.655 35.66784396716994 139.74592249220308 64.655 35.66782752317536 139.74594327643652 64.655 35.66784462795979 139.74596359331633 64.655 35.66785064287038 139.7459549599056 64.655</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1e3bb437-66dd-4779-8a4f-69e8a8b984bf">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1e3bb437-66dd-4779-8a4f-69e8a8b984bf_0">
											<gml:posList>35.66784462795979 139.74596359331633 64.655 35.66784462795979 139.74596359331633 61.55 35.66785064287038 139.7459549599056 61.55 35.66785064287038 139.7459549599056 64.655 35.66784462795979 139.74596359331633 64.655</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a62c9504-b0f3-4885-81d0-4c99567bf937">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a62c9504-b0f3-4885-81d0-4c99567bf937_0">
											<gml:posList>35.66785064287038 139.7459549599056 64.655 35.66785064287038 139.7459549599056 61.55 35.6678480359152 139.74595222336046 61.55 35.6678480359152 139.74595222336046 64.655 35.66785064287038 139.7459549599056 64.655</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6c69716c-6874-4d19-92b5-9425f62e158d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6c69716c-6874-4d19-92b5-9425f62e158d_0">
											<gml:posList>35.66784396716994 139.74592249220308 64.655 35.667857535522195 139.7459386044442 64.655 35.667857535522195 139.7459386044442 61.55 35.66784396716994 139.74592249220308 61.55 35.66784396716994 139.74592249220308 64.655</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9358706e-4110-4195-8a67-e8bec11de32e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9358706e-4110-4195-8a67-e8bec11de32e_0">
											<gml:posList>35.667857535522195 139.7459386044442 61.55 35.667857535522195 139.7459386044442 64.655 35.6678480359152 139.74595222336046 64.655 35.6678480359152 139.74595222336046 61.55 35.667857535522195 139.7459386044442 61.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-464ce755-ea8a-4498-acff-3c58e67158d2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-464ce755-ea8a-4498-acff-3c58e67158d2_0">
											<gml:posList>35.66785740264112 139.74587972987578 61.55 35.66785740264112 139.74587972987578 65.294 35.66784831872519 139.74586997519765 65.294 35.66784831872519 139.74586997519765 61.55 35.66785740264112 139.74587972987578 61.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fea26ef1-61cd-42cf-a5b9-3746bafff03e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fea26ef1-61cd-42cf-a5b9-3746bafff03e_0">
											<gml:posList>35.66784831872519 139.74586997519765 61.55 35.66784831872519 139.74586997519765 65.294 35.66785744037219 139.7458572182651 65.294 35.66785744037219 139.7458572182651 61.55 35.66784831872519 139.74586997519765 61.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ae0e18b4-1a46-4c98-97ed-24b0a87f5409">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ae0e18b4-1a46-4c98-97ed-24b0a87f5409_0">
											<gml:posList>35.667885258188065 139.74569802731057 14.3 35.667885258188065 139.74569802731057 16.988 35.66782885230989 139.74563897125512 16.988 35.66782885230989 139.74563897125512 14.3 35.667885258188065 139.74569802731057 14.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-db23567c-5c21-4189-8542-05b7deec53ac">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-db23567c-5c21-4189-8542-05b7deec53ac_0">
											<gml:posList>35.66785744037219 139.7458572182651 65.294 35.66784831872519 139.74586997519765 65.294 35.66785740264112 139.74587972987578 65.294 35.66786652428913 139.74586697294288 65.294 35.66785744037219 139.7458572182651 65.294</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-37ad04ad-4b00-467d-8a16-245b166288ae">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-37ad04ad-4b00-467d-8a16-245b166288ae_0">
											<gml:posList>35.66785740264112 139.74587972987578 61.55 35.66786652428913 139.74586697294288 61.55 35.66786652428913 139.74586697294288 65.294 35.66785740264112 139.74587972987578 65.294 35.66785740264112 139.74587972987578 61.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cb2713ce-f7ba-4b8e-80ba-9e1c8498e52c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cb2713ce-f7ba-4b8e-80ba-9e1c8498e52c_0">
											<gml:posList>35.66785744037219 139.7458572182651 61.55 35.66785744037219 139.7458572182651 65.294 35.66786652428913 139.74586697294288 65.294 35.66786652428913 139.74586697294288 61.55 35.66785744037219 139.7458572182651 61.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e4209285-4937-403f-b1ba-9084f1696686">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e4209285-4937-403f-b1ba-9084f1696686_0">
											<gml:posList>35.667885258188065 139.74569802731057 16.988 35.667907345826684 139.74566635661188 16.988 35.667850930911435 139.7456072895265 16.988 35.66782885230989 139.74563897125512 16.988 35.667885258188065 139.74569802731057 16.988</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-aa671784-68cb-4efd-9ed1-251406a52da4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-aa671784-68cb-4efd-9ed1-251406a52da4_0">
											<gml:posList>35.667870214681045 139.74583494681215 61.55 35.667874210884605 139.74583923931232 61.55 35.667874210884605 139.74583923931232 63.556 35.667870214681045 139.74583494681215 63.556 35.667870214681045 139.74583494681215 61.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3af63dd6-466f-4840-a6db-ba566f180554">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3af63dd6-466f-4840-a6db-ba566f180554_0">
											<gml:posList>35.667870214681045 139.74583494681215 61.55 35.667870214681045 139.74583494681215 63.556 35.667887431444896 139.74581087001883 63.556 35.667887431444896 139.74581087001883 61.55 35.667870214681045 139.74583494681215 61.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-515134dc-35f1-4f94-8281-97aa237f3da1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-515134dc-35f1-4f94-8281-97aa237f3da1_0">
											<gml:posList>35.667907345826684 139.74566635661188 14.3 35.667850930911435 139.7456072895265 14.3 35.667850930911435 139.7456072895265 16.988 35.667907345826684 139.74566635661188 16.988 35.667907345826684 139.74566635661188 14.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f62dfc4f-3062-4420-b04f-a1c0647f445e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f62dfc4f-3062-4420-b04f-a1c0647f445e_0">
											<gml:posList>35.66789142764127 139.7458151514728 63.556 35.667887431444896 139.74581087001883 63.556 35.667870214681045 139.74583494681215 63.556 35.667874210884605 139.74583923931232 63.556 35.66789142764127 139.7458151514728 63.556</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-25237fe6-44f3-468a-93e0-459f173dce49">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-25237fe6-44f3-468a-93e0-459f173dce49_0">
											<gml:posList>35.667874210884605 139.74583923931232 61.55 35.66789142764127 139.7458151514728 61.55 35.66789142764127 139.7458151514728 63.556 35.667874210884605 139.74583923931232 63.556 35.667874210884605 139.74583923931232 61.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2295c945-90d1-4ecc-a50b-09d3be877400">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2295c945-90d1-4ecc-a50b-09d3be877400_0">
											<gml:posList>35.66789142764127 139.7458151514728 61.55 35.667887431444896 139.74581087001883 61.55 35.667887431444896 139.74581087001883 63.556 35.66789142764127 139.7458151514728 63.556 35.66789142764127 139.7458151514728 61.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8111c7d4-27d3-4fbf-9b5d-7b5848798d30">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8111c7d4-27d3-4fbf-9b5d-7b5848798d30_0">
											<gml:posList>35.667907345826684 139.74566635661188 14.3 35.667907345826684 139.74566635661188 16.988 35.667885258188065 139.74569802731057 16.988 35.667885258188065 139.74569802731057 14.3 35.667907345826684 139.74566635661188 14.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_d429afb9-2999-4e8d-82e1-7435b3f37eba_BuildingInstallation_1051">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-50962ee5-0b4c-4c9e-87ad-354749152097">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6679744177764 139.74580368358627 14.3 35.66791865348843 139.74588319776726 14.306 35.66791674111815 139.74588118949535 14.3 35.66799113506 139.7457744930343 14.3 35.6679744177764 139.74580368358627 14.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-865403b7-296e-4800-b50d-9b60021d2193">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6679744177764 139.74580368358627 14.3 35.66799113506 139.7457744930343 14.3 35.66799443442967 139.74577496440656 14.3 35.6679744177764 139.74580368358627 14.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-448fd2ea-8062-4bd8-ae6d-84b2bbee39f8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66797946679919 139.74575592652266 14.3 35.66798018842761 139.74575665476584 14.3 35.66799443442967 139.74577496440656 14.3 35.66799113506 139.7457744930343 14.3 35.667977656710896 139.74575822605286 14.3 35.66797946679919 139.74575592652266 14.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cb385218-b1a8-4848-b63e-dd76bdf7f174">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cb385218-b1a8-4848-b63e-dd76bdf7f174_0">
											<gml:posList>35.667918842921104 139.74588339638723 16.988 35.66791674111815 139.74588118949535 16.988 35.66791674111815 139.74588118949535 14.3 35.66791865348843 139.74588319776726 14.306 35.667918842921104 139.74588339638723 16.988</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-35401639-fb3c-4e4b-b9eb-ba5e676923de">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-35401639-fb3c-4e4b-b9eb-ba5e676923de_0">
											<gml:posList>35.66799113506 139.7457744930343 16.988 35.66799113506 139.7457744930343 14.3 35.66791674111815 139.74588118949535 14.3 35.66791674111815 139.74588118949535 16.988 35.66799113506 139.7457744930343 16.988</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-dd3268cf-daa5-44e0-a15e-e82ea47f338e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-dd3268cf-daa5-44e0-a15e-e82ea47f338e_0">
											<gml:posList>35.667918842921104 139.74588339638723 16.988 35.66799443442967 139.74577496440656 16.988 35.66799113506 139.7457744930343 16.988 35.66791674111815 139.74588118949535 16.988 35.667918842921104 139.74588339638723 16.988</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cb0654ab-477a-4152-8f57-346e0310b266">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cb0654ab-477a-4152-8f57-346e0310b266_0">
											<gml:posList>35.667918842921104 139.74588339638723 16.988 35.66791865348843 139.74588319776726 14.306 35.6679744177764 139.74580368358627 14.3 35.66799443442967 139.74577496440656 16.988 35.667918842921104 139.74588339638723 16.988</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f3ff9f35-932d-4e34-91b1-fff1fdc2ab26">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f3ff9f35-932d-4e34-91b1-fff1fdc2ab26_0">
											<gml:posList>35.667977656710896 139.74575822605286 14.3 35.667977656710896 139.74575822605286 16.988 35.66797946679919 139.74575592652266 16.988 35.66797946679919 139.74575592652266 14.3 35.667977656710896 139.74575822605286 14.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f7afff80-6a07-43a0-9383-622da933ee0a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f7afff80-6a07-43a0-9383-622da933ee0a_0">
											<gml:posList>35.66797946679919 139.74575592652266 14.3 35.66797946679919 139.74575592652266 16.988 35.66798018842761 139.74575665476584 16.988 35.66798018842761 139.74575665476584 14.3 35.66797946679919 139.74575592652266 14.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-795c03cd-fc2b-4da2-86fd-469003e108ad">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-795c03cd-fc2b-4da2-86fd-469003e108ad_0">
											<gml:posList>35.66799113506 139.7457744930343 14.3 35.66799113506 139.7457744930343 16.988 35.667977656710896 139.74575822605286 16.988 35.667977656710896 139.74575822605286 14.3 35.66799113506 139.7457744930343 14.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-91c484bb-d3c8-468d-a3a0-c32308d20a80">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-91c484bb-d3c8-468d-a3a0-c32308d20a80_0">
											<gml:posList>35.66799443442967 139.74577496440656 16.988 35.6679744177764 139.74580368358627 14.3 35.66799443442967 139.74577496440656 14.3 35.66799443442967 139.74577496440656 16.988</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e6c1e54f-cba2-4a2d-a9ee-f53b4b46f511">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e6c1e54f-cba2-4a2d-a9ee-f53b4b46f511_0">
											<gml:posList>35.66799443442967 139.74577496440656 16.988 35.66798018842761 139.74575665476584 16.988 35.66797946679919 139.74575592652266 16.988 35.667977656710896 139.74575822605286 16.988 35.66799113506 139.7457744930343 16.988 35.66799443442967 139.74577496440656 16.988</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-18076872-bf22-4f6e-9c50-9e677c3ec470">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-18076872-bf22-4f6e-9c50-9e677c3ec470_0">
											<gml:posList>35.66798018842761 139.74575665476584 14.3 35.66798018842761 139.74575665476584 16.988 35.66799443442967 139.74577496440656 16.988 35.66799443442967 139.74577496440656 14.3 35.66798018842761 139.74575665476584 14.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_d429afb9-2999-4e8d-82e1-7435b3f37eba_BuildingInstallation_1031">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-00a03485-ea81-41ec-a16c-30442e00b3d5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66790247772488 139.7458141121417 61.55 35.66786547788634 139.74586585844705 61.55 35.66785965046871 139.7458596017712 61.55 35.6678966503046 139.74580785546672 61.55 35.66790247772488 139.7458141121417 61.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0102292b-a77c-438a-b0d0-897570b10055">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667845226174116 139.74586881875027 61.55 35.66783989423083 139.74586217492845 61.55 35.66785618582065 139.74584255066225 61.55 35.66786151776502 139.74584919448412 61.55 35.667845226174116 139.74586881875027 61.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-902b52ce-aa61-4236-8427-0933ddbd837e">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66785524668351 139.74587742363153 61.55 35.66784336988164 139.74589438101196 61.55 35.66784167612694 139.7458955205877 61.55 35.667839738736895 139.74589629591404 61.55 35.66783625923742 139.7458960235605 61.55 35.66783311247589 139.74589469043684 61.55 35.66782377471194 139.7459077458364 61.55 35.667818344213266 139.74590191951833 61.55 35.66782866343015 139.7458874270806 61.55 35.66783028514714 139.7458863869966 61.55 35.66783197937504 139.74588589912895 61.55 35.667834611584105 139.74588617240607 61.55 35.66783785645394 139.74588606945414 61.55 35.667839586688615 139.7458855152717 61.55 35.66784966282165 139.74587142074594 61.55 35.66785524668351 139.74587742363153 61.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bc800b1f-dce2-4149-a222-11c46d9ebee8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bc800b1f-dce2-4149-a222-11c46d9ebee8_0">
											<gml:posList>35.66790247772488 139.7458141121417 61.55 35.6678966503046 139.74580785546672 61.55 35.6678966503046 139.74580785546672 64.129 35.66790247772488 139.7458141121417 64.129 35.66790247772488 139.7458141121417 61.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b72345c3-2fec-402f-b7f7-1b9ebd9ce862">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b72345c3-2fec-402f-b7f7-1b9ebd9ce862_0">
											<gml:posList>35.6678966503046 139.74580785546672 64.129 35.6678966503046 139.74580785546672 61.55 35.66785965046871 139.7458596017712 61.55 35.66785965046871 139.7458596017712 64.129 35.6678966503046 139.74580785546672 64.129</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e5838d46-651d-4642-b025-ddfd923aa42d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e5838d46-651d-4642-b025-ddfd923aa42d_0">
											<gml:posList>35.66785965046871 139.7458596017712 64.129 35.66786547788634 139.74586585844705 64.129 35.66790247772488 139.7458141121417 64.129 35.6678966503046 139.74580785546672 64.129 35.66785965046871 139.7458596017712 64.129</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8d621289-8c7d-462e-981c-40c28f279b2f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8d621289-8c7d-462e-981c-40c28f279b2f_0">
											<gml:posList>35.66790247772488 139.7458141121417 61.55 35.66790247772488 139.7458141121417 64.129 35.66786547788634 139.74586585844705 64.129 35.66786547788634 139.74586585844705 61.55 35.66790247772488 139.7458141121417 61.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fdcd45f8-446a-4f64-99b5-b8e53e15154b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fdcd45f8-446a-4f64-99b5-b8e53e15154b_0">
											<gml:posList>35.66785618582065 139.74584255066225 61.55 35.66785618582065 139.74584255066225 65.25 35.66786151776502 139.74584919448412 65.25 35.66786151776502 139.74584919448412 61.55 35.66785618582065 139.74584255066225 61.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-de6f2c4b-5fd7-4c22-99c2-4f8478bfda0c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-de6f2c4b-5fd7-4c22-99c2-4f8478bfda0c_0">
											<gml:posList>35.66785618582065 139.74584255066225 61.55 35.66783989423083 139.74586217492845 61.55 35.66783989423083 139.74586217492845 65.25 35.66785618582065 139.74584255066225 65.25 35.66785618582065 139.74584255066225 61.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5cc9cdfe-2e03-4814-afd5-b7e6c2d615b9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5cc9cdfe-2e03-4814-afd5-b7e6c2d615b9_0">
											<gml:posList>35.66785618582065 139.74584255066225 65.25 35.66783989423083 139.74586217492845 65.25 35.667845226174116 139.74586881875027 65.25 35.66786151776502 139.74584919448412 65.25 35.66785618582065 139.74584255066225 65.25</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-900a0d7c-4fa0-40f4-97c0-cfda220fc949">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-900a0d7c-4fa0-40f4-97c0-cfda220fc949_0">
											<gml:posList>35.667845226174116 139.74586881875027 61.55 35.66786151776502 139.74584919448412 61.55 35.66786151776502 139.74584919448412 65.25 35.667845226174116 139.74586881875027 65.25 35.667845226174116 139.74586881875027 61.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-65351c74-a22c-4c98-8c1c-d2e404672a6f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-65351c74-a22c-4c98-8c1c-d2e404672a6f_0">
											<gml:posList>35.66786547788634 139.74586585844705 64.129 35.66785965046871 139.7458596017712 64.129 35.66785965046871 139.7458596017712 61.55 35.66786547788634 139.74586585844705 61.55 35.66786547788634 139.74586585844705 64.129</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2ef7d2b6-3166-4674-9368-accc2ba8c738">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2ef7d2b6-3166-4674-9368-accc2ba8c738_0">
											<gml:posList>35.66783989423083 139.74586217492845 61.55 35.667845226174116 139.74586881875027 61.55 35.667845226174116 139.74586881875027 65.25 35.66783989423083 139.74586217492845 65.25 35.66783989423083 139.74586217492845 61.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-48017307-9578-4c10-a654-ea168f671db3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-48017307-9578-4c10-a654-ea168f671db3_0">
											<gml:posList>35.66784966282165 139.74587142074594 64.129 35.66785524668351 139.74587742363153 64.129 35.66785524668351 139.74587742363153 61.55 35.66784966282165 139.74587142074594 61.55 35.66784966282165 139.74587142074594 64.129</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e1497830-75eb-4194-8513-77927d30e323">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e1497830-75eb-4194-8513-77927d30e323_0">
											<gml:posList>35.667839586688615 139.7458855152717 61.55 35.667839586688615 139.7458855152717 64.129 35.66784966282165 139.74587142074594 64.129 35.66784966282165 139.74587142074594 61.55 35.667839586688615 139.7458855152717 61.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6999d4cb-f2f6-4682-9ba2-33e4ed1ba657">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6999d4cb-f2f6-4682-9ba2-33e4ed1ba657_0">
											<gml:posList>35.667839586688615 139.7458855152717 61.55 35.66783785645394 139.74588606945414 61.55 35.66783785645394 139.74588606945414 64.129 35.667839586688615 139.7458855152717 64.129 35.667839586688615 139.7458855152717 61.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fde3d1f7-4acf-4a46-b50f-e2ca42053828">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fde3d1f7-4acf-4a46-b50f-e2ca42053828_0">
											<gml:posList>35.66785524668351 139.74587742363153 61.55 35.66785524668351 139.74587742363153 64.129 35.66784336988164 139.74589438101196 64.129 35.66784336988164 139.74589438101196 61.55 35.66785524668351 139.74587742363153 61.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-da712895-0cde-4ea8-986a-ecd668ba621c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-da712895-0cde-4ea8-986a-ecd668ba621c_0">
											<gml:posList>35.667834611584105 139.74588617240607 61.55 35.66783197937504 139.74588589912895 61.55 35.66783197937504 139.74588589912895 64.129 35.667834611584105 139.74588617240607 64.129 35.667834611584105 139.74588617240607 61.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-77b816c8-3a9c-4296-997f-70d4f37956e4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-77b816c8-3a9c-4296-997f-70d4f37956e4_0">
											<gml:posList>35.66783785645394 139.74588606945414 61.55 35.667834611584105 139.74588617240607 61.55 35.667834611584105 139.74588617240607 64.129 35.66783785645394 139.74588606945414 64.129 35.66783785645394 139.74588606945414 61.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f1fdf277-6051-442b-bddf-c36c10d40066">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f1fdf277-6051-442b-bddf-c36c10d40066_0">
											<gml:posList>35.66783197937504 139.74588589912895 61.55 35.66783028514714 139.7458863869966 61.55 35.66783028514714 139.7458863869966 64.129 35.66783197937504 139.74588589912895 64.129 35.66783197937504 139.74588589912895 61.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ab0b6db3-f29b-4680-bed1-cb86c08006b8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ab0b6db3-f29b-4680-bed1-cb86c08006b8_0">
											<gml:posList>35.66782866343015 139.7458874270806 61.55 35.66782866343015 139.7458874270806 64.129 35.66783028514714 139.7458863869966 64.129 35.66783028514714 139.7458863869966 61.55 35.66782866343015 139.7458874270806 61.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-62a9de22-2fd1-4fb4-a8a4-1683b34f56a9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-62a9de22-2fd1-4fb4-a8a4-1683b34f56a9_0">
											<gml:posList>35.667839586688615 139.7458855152717 64.129 35.66783785645394 139.74588606945414 64.129 35.667834611584105 139.74588617240607 64.129 35.66783197937504 139.74588589912895 64.129 35.66783028514714 139.7458863869966 64.129 35.66782866343015 139.7458874270806 64.129 35.667818344213266 139.74590191951833 64.129 35.66782377471194 139.7459077458364 64.129 35.66783311247589 139.74589469043684 64.129 35.66783625923742 139.7458960235605 64.129 35.667839738736895 139.74589629591404 64.129 35.66784167612694 139.7458955205877 64.129 35.66784336988164 139.74589438101196 64.129 35.66785524668351 139.74587742363153 64.129 35.66784966282165 139.74587142074594 64.129 35.667839586688615 139.7458855152717 64.129</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7b0ed2e9-fd00-4754-bb98-f9e32ce14b02">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7b0ed2e9-fd00-4754-bb98-f9e32ce14b02_0">
											<gml:posList>35.66782866343015 139.7458874270806 61.55 35.667818344213266 139.74590191951833 61.55 35.667818344213266 139.74590191951833 64.129 35.66782866343015 139.7458874270806 64.129 35.66782866343015 139.7458874270806 61.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2bdb9496-550f-4b8a-88d3-6a3c3c4950ab">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2bdb9496-550f-4b8a-88d3-6a3c3c4950ab_0">
											<gml:posList>35.66784167612694 139.7458955205877 61.55 35.66784336988164 139.74589438101196 61.55 35.66784336988164 139.74589438101196 64.129 35.66784167612694 139.7458955205877 64.129 35.66784167612694 139.7458955205877 61.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b2aa4d04-b8a9-437a-9395-5871871760d9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b2aa4d04-b8a9-437a-9395-5871871760d9_0">
											<gml:posList>35.66783311247589 139.74589469043684 61.55 35.66783625923742 139.7458960235605 61.55 35.66783625923742 139.7458960235605 64.129 35.66783311247589 139.74589469043684 64.129 35.66783311247589 139.74589469043684 61.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-13eb2e99-bc03-4215-aab0-c9c3b4de024f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-13eb2e99-bc03-4215-aab0-c9c3b4de024f_0">
											<gml:posList>35.667839738736895 139.74589629591404 61.55 35.66784167612694 139.7458955205877 61.55 35.66784167612694 139.7458955205877 64.129 35.667839738736895 139.74589629591404 64.129 35.667839738736895 139.74589629591404 61.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1138023e-c6ed-440b-9d76-dc6a0cfa7436">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1138023e-c6ed-440b-9d76-dc6a0cfa7436_0">
											<gml:posList>35.66783625923742 139.7458960235605 61.55 35.667839738736895 139.74589629591404 61.55 35.667839738736895 139.74589629591404 64.129 35.66783625923742 139.7458960235605 64.129 35.66783625923742 139.7458960235605 61.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e8d71d26-7cd0-4224-bf8c-206db6eb3b67">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e8d71d26-7cd0-4224-bf8c-206db6eb3b67_0">
											<gml:posList>35.66782377471194 139.7459077458364 61.55 35.66783311247589 139.74589469043684 61.55 35.66783311247589 139.74589469043684 64.129 35.66782377471194 139.7459077458364 64.129 35.66782377471194 139.7459077458364 61.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-170384d3-8d1e-41f7-9392-4ca9b00cde2b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-170384d3-8d1e-41f7-9392-4ca9b00cde2b_0">
											<gml:posList>35.667818344213266 139.74590191951833 61.55 35.66782377471194 139.7459077458364 61.55 35.66782377471194 139.7459077458364 64.129 35.667818344213266 139.74590191951833 64.129 35.667818344213266 139.74590191951833 61.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_d429afb9-2999-4e8d-82e1-7435b3f37eba_BuildingInstallation_1041">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-04fd28dc-ff2b-46b9-aa1b-0352721bd421">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6677258236315 139.74594662372093 61.55 35.66774594855946 139.74596768840615 61.55 35.6677147034039 139.74601250249847 61.55 35.667694587489386 139.7459914267545 61.55 35.6677258236315 139.74594662372093 61.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ee895763-f1c4-4545-b70f-115820b3c5d1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66779545454041 139.74589668662628 61.55 35.667751792393965 139.7459593092484 61.55 35.667731667464565 139.74593824456377 61.55 35.66777532960021 139.74587562194594 61.55 35.66779545454041 139.74589668662628 61.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b577ae6b-b6b1-416a-b01f-751ae01a26e1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b577ae6b-b6b1-416a-b01f-751ae01a26e1_0">
											<gml:posList>35.667694587489386 139.7459914267545 61.55 35.6677147034039 139.74601250249847 61.55 35.6677147034039 139.74601250249847 65.7 35.667694587489386 139.7459914267545 65.7 35.667694587489386 139.7459914267545 61.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6eb9a175-429b-40a7-b26e-d06abad1a137">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6eb9a175-429b-40a7-b26e-d06abad1a137_0">
											<gml:posList>35.6677258236315 139.74594662372093 61.55 35.667694587489386 139.7459914267545 61.55 35.667694587489386 139.7459914267545 65.7 35.6677258236315 139.74594662372093 65.7 35.6677258236315 139.74594662372093 61.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-672fe3a9-fa84-4032-8a67-4d0817aee0ca">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-672fe3a9-fa84-4032-8a67-4d0817aee0ca_0">
											<gml:posList>35.6677147034039 139.74601250249847 65.7 35.66774594855946 139.74596768840615 65.7 35.6677258236315 139.74594662372093 65.7 35.667694587489386 139.7459914267545 65.7 35.6677147034039 139.74601250249847 65.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5c994315-bb74-48cf-bcd5-40f1656e3152">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5c994315-bb74-48cf-bcd5-40f1656e3152_0">
											<gml:posList>35.66774594855946 139.74596768840615 61.55 35.66774594855946 139.74596768840615 65.7 35.6677147034039 139.74601250249847 65.7 35.6677147034039 139.74601250249847 61.55 35.66774594855946 139.74596768840615 61.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-882b72dd-2ddd-473b-b14f-ea990b390b59">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-882b72dd-2ddd-473b-b14f-ea990b390b59_0">
											<gml:posList>35.66774594855946 139.74596768840615 61.55 35.6677258236315 139.74594662372093 61.55 35.6677258236315 139.74594662372093 65.7 35.66774594855946 139.74596768840615 65.7 35.66774594855946 139.74596768840615 61.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d7111844-9ae7-4546-ae36-04fc672bddb6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d7111844-9ae7-4546-ae36-04fc672bddb6_0">
											<gml:posList>35.667731667464565 139.74593824456377 61.55 35.667751792393965 139.7459593092484 61.55 35.667751792393965 139.7459593092484 65.7 35.667731667464565 139.74593824456377 65.7 35.667731667464565 139.74593824456377 61.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-31807de8-5ca9-4b3c-9a7d-92225ee5973d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-31807de8-5ca9-4b3c-9a7d-92225ee5973d_0">
											<gml:posList>35.66777532960021 139.74587562194594 61.55 35.667731667464565 139.74593824456377 61.55 35.667731667464565 139.74593824456377 65.7 35.66777532960021 139.74587562194594 65.7 35.66777532960021 139.74587562194594 61.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4ca960e8-4254-47ee-a86e-915f0bca8820">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4ca960e8-4254-47ee-a86e-915f0bca8820_0">
											<gml:posList>35.66779545454041 139.74589668662628 65.7 35.66777532960021 139.74587562194594 65.7 35.667731667464565 139.74593824456377 65.7 35.667751792393965 139.7459593092484 65.7 35.66779545454041 139.74589668662628 65.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8021ad04-4f1a-4a36-9f28-49ca8a464d3e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8021ad04-4f1a-4a36-9f28-49ca8a464d3e_0">
											<gml:posList>35.667751792393965 139.7459593092484 61.55 35.66779545454041 139.74589668662628 61.55 35.66779545454041 139.74589668662628 65.7 35.667751792393965 139.7459593092484 65.7 35.667751792393965 139.7459593092484 61.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-20e1d528-06a9-47ed-952a-c93ca689b6ef">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-20e1d528-06a9-47ed-952a-c93ca689b6ef_0">
											<gml:posList>35.66777532960021 139.74587562194594 61.55 35.66777532960021 139.74587562194594 65.7 35.66779545454041 139.74589668662628 65.7 35.66779545454041 139.74589668662628 61.55 35.66777532960021 139.74587562194594 61.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-1c25bd92-9a72-47be-adfb-6f181a1b2889">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1c25bd92-9a72-47be-adfb-6f181a1b2889">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1c25bd92-9a72-47be-adfb-6f181a1b2889">
											<gml:posList>35.66787529816762 139.74597114844155 6.53 35.66786579855698 139.745984767357 6.53 35.66785821224257 139.74597682256405 6.53 35.667740894249356 139.746145102055 6.53 35.66757576350785 139.74597221485817 6.53 35.66784565072562 139.7455851040685 6.53 35.66798608627328 139.74574819818773 6.53 35.66798018842761 139.74575665476584 6.53 35.66799443442967 139.74577496440656 6.53 35.667872470464125 139.74594989918285 6.53 35.667879127652995 139.74595686190065 6.53 35.66787175307188 139.7459674298308 6.53 35.66787529816762 139.74597114844155 6.53</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-1f03acaf-2e0c-4829-a393-311ccbc8a5b9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1f03acaf-2e0c-4829-a393-311ccbc8a5b9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1f03acaf-2e0c-4829-a393-311ccbc8a5b9">
											<gml:posList>35.667609609376235 139.745971239084 65.7 35.6676092902494 139.7459662135571 65.7 35.66760652994881 139.74596332254458 65.7 35.66760242899099 139.74596372466456 65.7 35.667609609376235 139.745971239084 65.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-21229e6d-3236-4e0b-a0e7-06dffa580260">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-21229e6d-3236-4e0b-a0e7-06dffa580260">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-21229e6d-3236-4e0b-a0e7-06dffa580260">
											<gml:posList>35.66762182830238 139.74595371805177 65.7 35.66762151818052 139.74594868146843 65.7 35.6676092902494 139.7459662135571 65.7 35.667609609376235 139.745971239084 65.7 35.66762182830238 139.74595371805177 65.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-8c376f6b-b028-4d06-9ed0-4b2e1de161d1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8c376f6b-b028-4d06-9ed0-4b2e1de161d1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8c376f6b-b028-4d06-9ed0-4b2e1de161d1">
											<gml:posList>35.667609609376235 139.745971239084 60.3 35.667728969725815 139.74609621484484 60.3 35.6677411976756 139.74607868274978 60.3 35.66762182830238 139.74595371805177 60.3 35.667609609376235 139.745971239084 60.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e9230c03-f0bd-4d27-b7a6-a6703e08ea86">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e9230c03-f0bd-4d27-b7a6-a6703e08ea86">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e9230c03-f0bd-4d27-b7a6-a6703e08ea86">
											<gml:posList>35.6677411976756 139.74607868274978 65.7 35.66774529864173 139.74607829168085 65.7 35.66762151818052 139.74594868146843 65.7 35.66762182830238 139.74595371805177 65.7 35.6677411976756 139.74607868274978 65.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-81e1bb80-094e-4077-86bb-0995d399f39e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-81e1bb80-094e-4077-86bb-0995d399f39e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-81e1bb80-094e-4077-86bb-0995d399f39e">
											<gml:posList>35.66762151818052 139.74594868146843 65.134 35.66774529864173 139.74607829168085 65.134 35.667745768876756 139.74605551452944 65.134 35.667639109474926 139.74594383524723 65.134 35.66762151818052 139.74594868146843 65.134</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-40a389ae-c3df-4604-9e4b-302dc8d2d642">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-40a389ae-c3df-4604-9e4b-302dc8d2d642">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-40a389ae-c3df-4604-9e4b-302dc8d2d642">
											<gml:posList>35.66760242899099 139.74596372466456 65.7 35.66760652994881 139.74596332254458 65.7 35.66782916243667 139.74564399680435 65.7 35.66782884329617 139.745638971265 65.7 35.66760242899099 139.74596372466456 65.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-8d7034ff-4491-4ddb-b3b2-b5359e34ca4f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8d7034ff-4491-4ddb-b3b2-b5359e34ca4f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8d7034ff-4491-4ddb-b3b2-b5359e34ca4f">
											<gml:posList>35.66782916243667 139.74564399680435 65.134 35.66760652994881 139.74596332254458 65.134 35.6676092902494 139.7459662135571 65.134 35.66762151818052 139.74594868146843 65.134 35.667639109474926 139.74594383524723 65.134 35.66776938444052 139.74575697336934 65.134 35.66784828802943 139.74584012917916 65.134 35.667844863721086 139.74579177391854 65.134 35.667787204024044 139.7457314047342 65.134 35.66782037601019 139.7456838379548 65.134 35.667820539470604 139.7456607407839 65.134 35.66783093047063 139.7456458395376 65.134 35.66782916243667 139.74564399680435 65.134</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-abfd0ff5-038c-4723-8eea-efa70ba38085">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-abfd0ff5-038c-4723-8eea-efa70ba38085">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-abfd0ff5-038c-4723-8eea-efa70ba38085">
											<gml:posList>35.6677354555175 139.7461030010145 65.7 35.66773513638815 139.74609796443326 65.7 35.667733079697726 139.7460958127212 65.7 35.667728969725815 139.74609621484484 65.7 35.6677354555175 139.7461030010145 65.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-fb9900af-2bf2-444e-8ca1-483f09b1b631">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fb9900af-2bf2-444e-8ca1-483f09b1b631">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fb9900af-2bf2-444e-8ca1-483f09b1b631">
											<gml:posList>35.6677411976756 139.74607868274978 65.7 35.667728969725815 139.74609621484484 65.7 35.667733079697726 139.7460958127212 65.7 35.66774529864173 139.74607829168085 65.7 35.6677411976756 139.74607868274978 65.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-88b12a6a-5b52-485d-afe7-c6a93f29f68e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-88b12a6a-5b52-485d-afe7-c6a93f29f68e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-88b12a6a-5b52-485d-afe7-c6a93f29f68e">
											<gml:posList>35.66774529864173 139.74607829168085 65.134 35.667733079697726 139.7460958127212 65.134 35.66773513638815 139.74609796443326 65.134 35.66779582587464 139.74601092296 65.134 35.667745768876756 139.74605551452944 65.134 35.66774529864173 139.74607829168085 65.134</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-02123fa1-94f1-44d3-bd2b-0f5f7bd2d555">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-02123fa1-94f1-44d3-bd2b-0f5f7bd2d555">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-02123fa1-94f1-44d3-bd2b-0f5f7bd2d555">
											<gml:posList>35.6677961359939 139.7460159595545 65.7 35.66779582587464 139.74601092296 65.7 35.66773513638815 139.74609796443326 65.7 35.6677354555175 139.7461030010145 65.7 35.6677961359939 139.7460159595545 65.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-20162f72-d1b8-4abd-963a-f382079f0942">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-20162f72-d1b8-4abd-963a-f382079f0942">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-20162f72-d1b8-4abd-963a-f382079f0942">
											<gml:posList>35.66788657979622 139.7458544912724 61.55 35.66792741451545 139.74579591438217 61.55 35.667899495753474 139.7457666842236 61.55 35.66784828802943 139.74584012917916 61.55 35.66776938444052 139.74575697336934 61.55 35.667639109474926 139.74594383524723 61.55 35.667745768876756 139.74605551452944 61.55 35.667784865856085 139.74599943611113 61.55 35.667819577676596 139.7459496364926 61.55 35.667840116770414 139.74597006008912 61.55 35.66785064287038 139.7459549599056 61.55 35.6678480359152 139.74595222336046 61.55 35.66786902508476 139.74592212246372 61.55 35.66785252641067 139.74590483150553 61.55 35.66788657979622 139.7458544912724 61.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-323cd44f-cf28-4099-9c76-28aa65ca9793">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-323cd44f-cf28-4099-9c76-28aa65ca9793">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-323cd44f-cf28-4099-9c76-28aa65ca9793">
											<gml:posList>35.66779582587464 139.74601092296 65.134 35.66782140728447 139.74597423373467 65.134 35.667784865856085 139.74599943611113 65.134 35.667745768876756 139.74605551452944 65.134 35.66779582587464 139.74601092296 65.134</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-038ebccb-728a-40fa-9987-4d64d3fa1002">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-038ebccb-728a-40fa-9987-4d64d3fa1002">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-038ebccb-728a-40fa-9987-4d64d3fa1002">
											<gml:posList>35.6679622580725 139.74577864469768 14.3 35.66790172183702 139.74586547648786 14.3 35.667918842921104 139.74588339638723 14.3 35.66799443442967 139.74577496440656 14.3 35.66798018842761 139.74575665476584 14.3 35.66798608627328 139.74574819818773 14.3 35.66784565072562 139.7455851040685 14.3 35.66757576350785 139.74597221485817 14.3 35.667740894249356 139.746145102055 14.3 35.66781625189583 139.74603702428539 14.3 35.6677961359939 139.7460159595545 14.3 35.6677354555175 139.7461030010145 14.3 35.66760242899099 139.74596372466456 14.3 35.66782884329617 139.745638971265 14.3 35.6679622580725 139.74577864469768 14.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-06ee54f3-52d5-4496-a0d5-9c6fb55f3014">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-06ee54f3-52d5-4496-a0d5-9c6fb55f3014">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-06ee54f3-52d5-4496-a0d5-9c6fb55f3014">
											<gml:posList>35.66782140728447 139.74597423373467 65.134 35.667819577676596 139.7459496364926 65.134 35.667784865856085 139.74599943611113 65.134 35.66782140728447 139.74597423373467 65.134</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-4999b4eb-17d5-4aa8-9711-e583d4c6c41a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4999b4eb-17d5-4aa8-9711-e583d4c6c41a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4999b4eb-17d5-4aa8-9711-e583d4c6c41a">
											<gml:posList>35.6677961359939 139.7460159595545 65.7 35.66781625189583 139.74603702428539 65.7 35.667815923749984 139.74603198770916 65.7 35.66779582587464 139.74601092296 65.7 35.6677961359939 139.7460159595545 65.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-9a5f3d99-0140-4a19-9ecd-46b34afd6e30">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9a5f3d99-0140-4a19-9ecd-46b34afd6e30">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9a5f3d99-0140-4a19-9ecd-46b34afd6e30">
											<gml:posList>35.667815923749984 139.74603198770916 65.134 35.66784194637414 139.74599465733797 65.134 35.66782140728447 139.74597423373467 65.134 35.66779582587464 139.74601092296 65.134 35.667815923749984 139.74603198770916 65.134</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-56d0e681-93ad-4d9b-9302-0ba98c3cfc8f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-56d0e681-93ad-4d9b-9302-0ba98c3cfc8f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-56d0e681-93ad-4d9b-9302-0ba98c3cfc8f">
											<gml:posList>35.66782464944901 139.74566034968336 65.7 35.66783504044898 139.74564544843628 65.7 35.66783093047063 139.7456458395376 65.7 35.667820539470604 139.7456607407839 65.7 35.66782464944901 139.74566034968336 65.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-07d901c9-a5c1-460b-a3f8-254f79900e9b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-07d901c9-a5c1-460b-a3f8-254f79900e9b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-07d901c9-a5c1-460b-a3f8-254f79900e9b">
											<gml:posList>35.66782140728447 139.74597423373467 65.134 35.66784194637414 139.74599465733797 65.134 35.667840116770414 139.74597006008912 65.134 35.667819577676596 139.7459496364926 65.134 35.66782140728447 139.74597423373467 65.134</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d2107e40-331b-4fd5-b7bf-57c111850971">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d2107e40-331b-4fd5-b7bf-57c111850971">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d2107e40-331b-4fd5-b7bf-57c111850971">
											<gml:posList>35.66782884329617 139.745638971265 65.7 35.66782916243667 139.74564399680435 65.7 35.66783093047063 139.7456458395376 65.7 35.66783504044898 139.74564544843628 65.7 35.66782884329617 139.745638971265 65.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c51cb6fe-f5fa-4d8c-a0c3-34629cc3a0fc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c51cb6fe-f5fa-4d8c-a0c3-34629cc3a0fc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c51cb6fe-f5fa-4d8c-a0c3-34629cc3a0fc">
											<gml:posList>35.66782037601019 139.7456838379548 61.55 35.667787204024044 139.7457314047342 61.55 35.667844863721086 139.74579177391854 61.55 35.667878026708976 139.74574419609377 61.55 35.66782037601019 139.7456838379548 61.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-0104fd1c-0d28-439f-bc57-b9bae81aecc0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0104fd1c-0d28-439f-bc57-b9bae81aecc0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0104fd1c-0d28-439f-bc57-b9bae81aecc0">
											<gml:posList>35.66787508643307 139.7459526357189 65.7 35.667870976445705 139.74595301575883 65.7 35.667815923749984 139.74603198770916 65.7 35.66781625189583 139.74603702428539 65.7 35.66787508643307 139.7459526357189 65.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c8878a26-0b5c-46e8-875c-0525efaa3227">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c8878a26-0b5c-46e8-875c-0525efaa3227">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c8878a26-0b5c-46e8-875c-0525efaa3227">
											<gml:posList>35.66784194637414 139.74599465733797 65.134 35.667870976445705 139.74595301575883 65.134 35.66785064287038 139.7459549599056 65.134 35.667840116770414 139.74597006008912 65.134 35.66784194637414 139.74599465733797 65.134</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-79af40cc-75d5-4a35-875f-4a5c9f38dae0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-79af40cc-75d5-4a35-875f-4a5c9f38dae0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-79af40cc-75d5-4a35-875f-4a5c9f38dae0">
											<gml:posList>35.667868369490506 139.74595027921305 65.134 35.6678480359152 139.74595222336046 65.134 35.66785064287038 139.7459549599056 65.134 35.667870976445705 139.74595301575883 65.134 35.667868369490506 139.74595027921305 65.134</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-78759809-6531-4d6c-af01-388b432e23c4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-78759809-6531-4d6c-af01-388b432e23c4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-78759809-6531-4d6c-af01-388b432e23c4">
											<gml:posList>35.66785821224257 139.74597682256405 17.5 35.66786579855698 139.745984767357 17.5 35.66787529816762 139.74597114844155 17.5 35.66787175307188 139.7459674298308 17.5 35.667879127652995 139.74595686190065 17.5 35.66787508643307 139.7459526357189 17.5 35.66785821224257 139.74597682256405 17.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-1d55e8df-9320-4159-9f68-3f3cf36928df">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1d55e8df-9320-4159-9f68-3f3cf36928df">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1d55e8df-9320-4159-9f68-3f3cf36928df">
											<gml:posList>35.667868369490506 139.74595027921305 65.134 35.667889367665204 139.74592016725242 65.134 35.66786902508476 139.74592212246372 65.134 35.6678480359152 139.74595222336046 65.134 35.667868369490506 139.74595027921305 65.134</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-fc84b100-e7cf-43c1-8acb-2e448f819c0f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fc84b100-e7cf-43c1-8acb-2e448f819c0f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fc84b100-e7cf-43c1-8acb-2e448f819c0f">
											<gml:posList>35.66787270663149 139.74590272182448 65.134 35.66785252641067 139.74590483150553 65.134 35.66786902508476 139.74592212246372 65.134 35.667889367665204 139.74592016725242 65.134 35.66787270663149 139.74590272182448 65.134</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c1b5219d-bfc3-4911-8f03-4eefd72380be">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c1b5219d-bfc3-4911-8f03-4eefd72380be">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c1b5219d-bfc3-4911-8f03-4eefd72380be">
											<gml:posList>35.667872470464125 139.74594989918285 65.7 35.667868369490506 139.74595027921305 65.7 35.667870976445705 139.74595301575883 65.7 35.66787508643307 139.7459526357189 65.7 35.667872470464125 139.74594989918285 65.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e0a78ec3-98c1-4432-aa89-731c6190a1ff">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e0a78ec3-98c1-4432-aa89-731c6190a1ff">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e0a78ec3-98c1-4432-aa89-731c6190a1ff">
											<gml:posList>35.66787270663149 139.74590272182448 65.134 35.66789762087171 139.74586586756845 65.134 35.66788657979622 139.7458544912724 65.134 35.66785252641067 139.74590483150553 65.134 35.66787270663149 139.74590272182448 65.134</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-27321116-278d-4edf-8404-32ff4fac9557">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-27321116-278d-4edf-8404-32ff4fac9557">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-27321116-278d-4edf-8404-32ff4fac9557">
											<gml:posList>35.667878026708976 139.74574419609377 65.134 35.667844863721086 139.74579177391854 65.134 35.66784828802943 139.74584012917916 65.134 35.667899495753474 139.7457666842236 65.134 35.66792741451545 139.74579591438217 65.134 35.667944969715705 139.74579102396453 65.134 35.667820539470604 139.7456607407839 65.134 35.66782037601019 139.7456838379548 65.134 35.667878026708976 139.74574419609377 65.134</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-3edc63d8-3ce5-45d9-b69b-fe9ce746b613">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3edc63d8-3ce5-45d9-b69b-fe9ce746b613">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3edc63d8-3ce5-45d9-b69b-fe9ce746b613">
											<gml:posList>35.66782464944901 139.74566034968336 65.7 35.667820539470604 139.7456607407839 65.7 35.667944969715705 139.74579102396453 65.7 35.66794465959506 139.74578599840748 65.7 35.66782464944901 139.74566034968336 65.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-38b1d8db-490e-464c-9153-bbb0fd235261">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-38b1d8db-490e-464c-9153-bbb0fd235261">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-38b1d8db-490e-464c-9153-bbb0fd235261">
											<gml:posList>35.66782464944901 139.74566034968336 60.3 35.66794465959506 139.74578599840748 60.3 35.66795504159663 139.74577109716415 60.3 35.66783504044898 139.74564544843628 60.3 35.66782464944901 139.74566034968336 60.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c46c9eb3-9baf-4bd1-9a6e-1a3cba2dae86">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c46c9eb3-9baf-4bd1-9a6e-1a3cba2dae86">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c46c9eb3-9baf-4bd1-9a6e-1a3cba2dae86">
											<gml:posList>35.667872470464125 139.74594989918285 65.7 35.667918842921104 139.74588339638723 65.7 35.667914732942016 139.7458837874768 65.7 35.667868369490506 139.74595027921305 65.7 35.667872470464125 139.74594989918285 65.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-348f3398-2161-4154-9cb2-dfb098dbf4d6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-348f3398-2161-4154-9cb2-dfb098dbf4d6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-348f3398-2161-4154-9cb2-dfb098dbf4d6">
											<gml:posList>35.667914732942016 139.7458837874768 65.134 35.66789762087171 139.74586586756845 65.134 35.66787270663149 139.74590272182448 65.134 35.667889367665204 139.74592016725242 65.134 35.667914732942016 139.7458837874768 65.134</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-8b7d88ba-3d2d-43e6-810b-50a76dd94403">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8b7d88ba-3d2d-43e6-810b-50a76dd94403">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8b7d88ba-3d2d-43e6-810b-50a76dd94403">
											<gml:posList>35.66790172183702 139.74586547648786 65.7 35.66789762087171 139.74586586756845 65.7 35.667914732942016 139.7458837874768 65.7 35.667918842921104 139.74588339638723 65.7 35.66790172183702 139.74586547648786 65.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c937da68-295f-4b0f-b6d8-920e853a7d4a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c937da68-295f-4b0f-b6d8-920e853a7d4a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c937da68-295f-4b0f-b6d8-920e853a7d4a">
											<gml:posList>35.66789762087171 139.74586586756845 65.134 35.66795814810183 139.74577904683875 65.134 35.667955360731625 139.74577612271193 65.134 35.667944969715705 139.74579102396453 65.134 35.66792741451545 139.74579591438217 65.134 35.66788657979622 139.7458544912724 65.134 35.66789762087171 139.74586586756845 65.134</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f058253b-2681-47ad-8225-59f1837bf6d6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f058253b-2681-47ad-8225-59f1837bf6d6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f058253b-2681-47ad-8225-59f1837bf6d6">
											<gml:posList>35.66790172183702 139.74586547648786 65.7 35.6679622580725 139.74577864469768 65.7 35.66795814810183 139.74577904683875 65.7 35.66789762087171 139.74586586756845 65.7 35.66790172183702 139.74586547648786 65.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-3b1fd8d3-b107-487e-93d4-51a252c3ac6f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3b1fd8d3-b107-487e-93d4-51a252c3ac6f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3b1fd8d3-b107-487e-93d4-51a252c3ac6f">
											<gml:posList>35.66794465959506 139.74578599840748 65.7 35.667944969715705 139.74579102396453 65.7 35.667955360731625 139.74577612271193 65.7 35.66795504159663 139.74577109716415 65.7 35.66794465959506 139.74578599840748 65.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ed5a616d-5564-4a9f-aa5f-b6d288742f46">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ed5a616d-5564-4a9f-aa5f-b6d288742f46">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ed5a616d-5564-4a9f-aa5f-b6d288742f46">
											<gml:posList>35.66795504159663 139.74577109716415 65.7 35.667955360731625 139.74577612271193 65.7 35.66795814810183 139.74577904683875 65.7 35.6679622580725 139.74577864469768 65.7 35.66795504159663 139.74577109716415 65.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c267b9ae-4a4f-49e6-9a92-319c66883d9d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c267b9ae-4a4f-49e6-9a92-319c66883d9d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c267b9ae-4a4f-49e6-9a92-319c66883d9d">
											<gml:posList>35.66762151818052 139.74594868146843 65.7 35.66762151818052 139.74594868146843 65.134 35.6676092902494 139.7459662135571 65.134 35.6676092902494 139.7459662135571 65.7 35.66762151818052 139.74594868146843 65.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f4506a45-dbe2-4910-b5ea-51ec5321c798">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f4506a45-dbe2-4910-b5ea-51ec5321c798">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f4506a45-dbe2-4910-b5ea-51ec5321c798">
											<gml:posList>35.667733079697726 139.7460958127212 65.7 35.667733079697726 139.7460958127212 65.134 35.66774529864173 139.74607829168085 65.134 35.66774529864173 139.74607829168085 65.7 35.667733079697726 139.7460958127212 65.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7d845849-0641-4bdc-92dd-b1d8ed2cc06a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7d845849-0641-4bdc-92dd-b1d8ed2cc06a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7d845849-0641-4bdc-92dd-b1d8ed2cc06a">
											<gml:posList>35.667819577676596 139.7459496364926 65.134 35.667819577676596 139.7459496364926 61.55 35.667784865856085 139.74599943611113 61.55 35.667784865856085 139.74599943611113 65.134 35.667819577676596 139.7459496364926 65.134</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d4fc6eb9-2c5a-4ebf-887b-3e617d9d26ac">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d4fc6eb9-2c5a-4ebf-887b-3e617d9d26ac">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d4fc6eb9-2c5a-4ebf-887b-3e617d9d26ac">
											<gml:posList>35.667787204024044 139.7457314047342 61.55 35.667787204024044 139.7457314047342 65.134 35.667844863721086 139.74579177391854 65.134 35.667844863721086 139.74579177391854 61.55 35.667787204024044 139.7457314047342 61.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-fc9a0a8a-9ad6-4d7d-bde5-0a57c3cefd92">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fc9a0a8a-9ad6-4d7d-bde5-0a57c3cefd92">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fc9a0a8a-9ad6-4d7d-bde5-0a57c3cefd92">
											<gml:posList>35.66783093047063 139.7456458395376 65.7 35.66783093047063 139.7456458395376 65.134 35.667820539470604 139.7456607407839 65.134 35.667820539470604 139.7456607407839 65.7 35.66783093047063 139.7456458395376 65.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b753b6b9-ad63-4150-b7f2-16bbd2ab9bef">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b753b6b9-ad63-4150-b7f2-16bbd2ab9bef">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b753b6b9-ad63-4150-b7f2-16bbd2ab9bef">
											<gml:posList>35.667815923749984 139.74603198770916 65.7 35.667870976445705 139.74595301575883 65.7 35.667870976445705 139.74595301575883 65.134 35.66784194637414 139.74599465733797 65.134 35.667815923749984 139.74603198770916 65.134 35.667815923749984 139.74603198770916 65.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3ce221bd-0506-4596-a66a-c8e6b58ae20d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3ce221bd-0506-4596-a66a-c8e6b58ae20d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3ce221bd-0506-4596-a66a-c8e6b58ae20d">
											<gml:posList>35.667899495753474 139.7457666842236 61.55 35.667899495753474 139.7457666842236 65.134 35.66784828802943 139.74584012917916 65.134 35.66784828802943 139.74584012917916 61.55 35.667899495753474 139.7457666842236 61.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-17754e0f-1159-4499-9a3c-6ac1da55fc55">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-17754e0f-1159-4499-9a3c-6ac1da55fc55">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-17754e0f-1159-4499-9a3c-6ac1da55fc55">
											<gml:posList>35.667944969715705 139.74579102396453 65.7 35.667944969715705 139.74579102396453 65.134 35.667955360731625 139.74577612271193 65.134 35.667955360731625 139.74577612271193 65.7 35.667944969715705 139.74579102396453 65.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-bb62eb16-8ec9-48d2-81ec-7d2b3a02cc4f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bb62eb16-8ec9-48d2-81ec-7d2b3a02cc4f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bb62eb16-8ec9-48d2-81ec-7d2b3a02cc4f">
											<gml:posList>35.66784565072562 139.7455851040685 6.53 35.66757576350785 139.74597221485817 6.53 35.66757576350785 139.74597221485817 14.3 35.66784565072562 139.7455851040685 14.3 35.66784565072562 139.7455851040685 6.53</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-fb1311c0-8458-4809-b352-efc14d172da3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fb1311c0-8458-4809-b352-efc14d172da3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fb1311c0-8458-4809-b352-efc14d172da3">
											<gml:posList>35.6676092902494 139.7459662135571 65.7 35.6676092902494 139.7459662135571 65.134 35.66760652994881 139.74596332254458 65.134 35.66760652994881 139.74596332254458 65.7 35.6676092902494 139.7459662135571 65.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3e5f5d26-4854-4c23-8653-211734aa284b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3e5f5d26-4854-4c23-8653-211734aa284b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3e5f5d26-4854-4c23-8653-211734aa284b">
											<gml:posList>35.66762182830238 139.74595371805177 65.7 35.667609609376235 139.745971239084 65.7 35.667609609376235 139.745971239084 60.3 35.66762182830238 139.74595371805177 60.3 35.66762182830238 139.74595371805177 65.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-248dbd2e-01ce-4a00-9025-835fb2346f86">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-248dbd2e-01ce-4a00-9025-835fb2346f86">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-248dbd2e-01ce-4a00-9025-835fb2346f86">
											<gml:posList>35.66757576350785 139.74597221485817 6.53 35.667740894249356 139.746145102055 6.53 35.667740894249356 139.746145102055 14.3 35.66757576350785 139.74597221485817 14.3 35.66757576350785 139.74597221485817 6.53</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c65c3bc9-d29c-43a3-94f9-6a148e958d72">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c65c3bc9-d29c-43a3-94f9-6a148e958d72">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c65c3bc9-d29c-43a3-94f9-6a148e958d72">
											<gml:posList>35.667609609376235 139.745971239084 60.3 35.667609609376235 139.745971239084 65.7 35.66760242899099 139.74596372466456 65.7 35.66760242899099 139.74596372466456 14.3 35.6677354555175 139.7461030010145 14.3 35.6677354555175 139.7461030010145 65.7 35.667728969725815 139.74609621484484 65.7 35.667728969725815 139.74609621484484 60.3 35.667609609376235 139.745971239084 60.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9b0e6f87-46cc-428b-8053-87e5a69c4fa7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9b0e6f87-46cc-428b-8053-87e5a69c4fa7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9b0e6f87-46cc-428b-8053-87e5a69c4fa7">
											<gml:posList>35.6677411976756 139.74607868274978 65.7 35.66762182830238 139.74595371805177 65.7 35.66762182830238 139.74595371805177 60.3 35.6677411976756 139.74607868274978 60.3 35.6677411976756 139.74607868274978 65.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ef9df16d-8c4b-441d-b463-497317dd619d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ef9df16d-8c4b-441d-b463-497317dd619d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ef9df16d-8c4b-441d-b463-497317dd619d">
											<gml:posList>35.66774529864173 139.74607829168085 65.7 35.66774529864173 139.74607829168085 65.134 35.66762151818052 139.74594868146843 65.134 35.66762151818052 139.74594868146843 65.7 35.66774529864173 139.74607829168085 65.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-fcecffb1-f5a4-4222-963c-2f53fe253984">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fcecffb1-f5a4-4222-963c-2f53fe253984">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fcecffb1-f5a4-4222-963c-2f53fe253984">
											<gml:posList>35.667745768876756 139.74605551452944 65.134 35.667745768876756 139.74605551452944 61.55 35.667639109474926 139.74594383524723 61.55 35.667639109474926 139.74594383524723 65.134 35.667745768876756 139.74605551452944 65.134</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-cd838f92-bf42-431c-b11d-62cf06b967d1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cd838f92-bf42-431c-b11d-62cf06b967d1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cd838f92-bf42-431c-b11d-62cf06b967d1">
											<gml:posList>35.66776938444052 139.74575697336934 61.55 35.66776938444052 139.74575697336934 65.134 35.667639109474926 139.74594383524723 65.134 35.667639109474926 139.74594383524723 61.55 35.66776938444052 139.74575697336934 61.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6bb4c969-fdcb-4de2-a786-6eaffdf64bb8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6bb4c969-fdcb-4de2-a786-6eaffdf64bb8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6bb4c969-fdcb-4de2-a786-6eaffdf64bb8">
											<gml:posList>35.66760242899099 139.74596372466456 65.7 35.66782884329617 139.745638971265 65.7 35.66782884329617 139.745638971265 14.3 35.66760242899099 139.74596372466456 14.3 35.66760242899099 139.74596372466456 65.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7791ac46-176b-4aef-808b-9f1d97149e3a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7791ac46-176b-4aef-808b-9f1d97149e3a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7791ac46-176b-4aef-808b-9f1d97149e3a">
											<gml:posList>35.66760652994881 139.74596332254458 65.7 35.66760652994881 139.74596332254458 65.134 35.66782916243667 139.74564399680435 65.134 35.66782916243667 139.74564399680435 65.7 35.66760652994881 139.74596332254458 65.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3abccfbd-0671-419f-a7c2-1b70cdae1409">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3abccfbd-0671-419f-a7c2-1b70cdae1409">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3abccfbd-0671-419f-a7c2-1b70cdae1409">
											<gml:posList>35.66773513638815 139.74609796443326 65.7 35.66773513638815 139.74609796443326 65.134 35.667733079697726 139.7460958127212 65.134 35.667733079697726 139.7460958127212 65.7 35.66773513638815 139.74609796443326 65.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9c26f172-6372-44bf-ae1a-b3fcaf324fb2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9c26f172-6372-44bf-ae1a-b3fcaf324fb2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9c26f172-6372-44bf-ae1a-b3fcaf324fb2">
											<gml:posList>35.667728969725815 139.74609621484484 65.7 35.6677411976756 139.74607868274978 65.7 35.6677411976756 139.74607868274978 60.3 35.667728969725815 139.74609621484484 60.3 35.667728969725815 139.74609621484484 65.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2c6fa9cf-89fb-4a22-b17a-f7b0be6e8460">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2c6fa9cf-89fb-4a22-b17a-f7b0be6e8460">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2c6fa9cf-89fb-4a22-b17a-f7b0be6e8460">
											<gml:posList>35.667784865856085 139.74599943611113 65.134 35.667784865856085 139.74599943611113 61.55 35.667745768876756 139.74605551452944 61.55 35.667745768876756 139.74605551452944 65.134 35.667784865856085 139.74599943611113 65.134</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8cc998eb-c2b5-469c-880d-5c4fd42ae71f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8cc998eb-c2b5-469c-880d-5c4fd42ae71f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8cc998eb-c2b5-469c-880d-5c4fd42ae71f">
											<gml:posList>35.66779582587464 139.74601092296 65.7 35.66779582587464 139.74601092296 65.134 35.66773513638815 139.74609796443326 65.134 35.66773513638815 139.74609796443326 65.7 35.66779582587464 139.74601092296 65.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-38aa3837-6e50-4592-b6f6-0c172e9c26bc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-38aa3837-6e50-4592-b6f6-0c172e9c26bc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-38aa3837-6e50-4592-b6f6-0c172e9c26bc">
											<gml:posList>35.6677354555175 139.7461030010145 14.3 35.6677961359939 139.7460159595545 14.3 35.6677961359939 139.7460159595545 65.7 35.6677354555175 139.7461030010145 65.7 35.6677354555175 139.7461030010145 14.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4791f50c-dc98-43e5-bbce-ff40554acf01">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4791f50c-dc98-43e5-bbce-ff40554acf01">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4791f50c-dc98-43e5-bbce-ff40554acf01">
											<gml:posList>35.66782916243667 139.74564399680435 65.7 35.66782916243667 139.74564399680435 65.134 35.66783093047063 139.7456458395376 65.134 35.66783093047063 139.7456458395376 65.7 35.66782916243667 139.74564399680435 65.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-493fa0f7-1d6d-4a0e-b7db-2ea82ad747dc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-493fa0f7-1d6d-4a0e-b7db-2ea82ad747dc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-493fa0f7-1d6d-4a0e-b7db-2ea82ad747dc">
											<gml:posList>35.66783504044898 139.74564544843628 65.7 35.66782464944901 139.74566034968336 65.7 35.66782464944901 139.74566034968336 60.3 35.66783504044898 139.74564544843628 60.3 35.66783504044898 139.74564544843628 65.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-75e86810-a680-48e1-8a7d-513fcf526403">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-75e86810-a680-48e1-8a7d-513fcf526403">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-75e86810-a680-48e1-8a7d-513fcf526403">
											<gml:posList>35.66798608627328 139.74574819818773 6.53 35.66784565072562 139.7455851040685 6.53 35.66784565072562 139.7455851040685 14.3 35.66798608627328 139.74574819818773 14.3 35.66798608627328 139.74574819818773 6.53</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a120ac5a-afc6-47f1-a617-511634e72010">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a120ac5a-afc6-47f1-a617-511634e72010">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a120ac5a-afc6-47f1-a617-511634e72010">
											<gml:posList>35.66782037601019 139.7456838379548 61.55 35.66782037601019 139.7456838379548 65.134 35.667787204024044 139.7457314047342 65.134 35.667787204024044 139.7457314047342 61.55 35.66782037601019 139.7456838379548 61.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-680e8b8e-b07a-4196-9749-0b0dff4e0737">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-680e8b8e-b07a-4196-9749-0b0dff4e0737">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-680e8b8e-b07a-4196-9749-0b0dff4e0737">
											<gml:posList>35.66795504159663 139.74577109716415 60.3 35.66795504159663 139.74577109716415 65.7 35.6679622580725 139.74577864469768 65.7 35.6679622580725 139.74577864469768 14.3 35.66782884329617 139.745638971265 14.3 35.66782884329617 139.745638971265 65.7 35.66783504044898 139.74564544843628 65.7 35.66783504044898 139.74564544843628 60.3 35.66795504159663 139.74577109716415 60.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-26e5b787-c82d-42fe-a8bc-4e06db46458b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-26e5b787-c82d-42fe-a8bc-4e06db46458b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-26e5b787-c82d-42fe-a8bc-4e06db46458b">
											<gml:posList>35.667878026708976 139.74574419609377 61.55 35.667878026708976 139.74574419609377 65.134 35.66782037601019 139.7456838379548 65.134 35.66782037601019 139.7456838379548 61.55 35.667878026708976 139.74574419609377 61.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5c1baa5c-f71c-49b9-9692-960c8a60053d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5c1baa5c-f71c-49b9-9692-960c8a60053d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5c1baa5c-f71c-49b9-9692-960c8a60053d">
											<gml:posList>35.66782464944901 139.74566034968336 65.7 35.66794465959506 139.74578599840748 65.7 35.66794465959506 139.74578599840748 60.3 35.66782464944901 139.74566034968336 60.3 35.66782464944901 139.74566034968336 65.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-270160e2-0c41-4674-88f9-369b071c0641">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-270160e2-0c41-4674-88f9-369b071c0641">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-270160e2-0c41-4674-88f9-369b071c0641">
											<gml:posList>35.667820539470604 139.7456607407839 65.7 35.667820539470604 139.7456607407839 65.134 35.667944969715705 139.74579102396453 65.134 35.667944969715705 139.74579102396453 65.7 35.667820539470604 139.7456607407839 65.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c6f2d61a-f126-4da7-b90e-3d36fed8668a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c6f2d61a-f126-4da7-b90e-3d36fed8668a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c6f2d61a-f126-4da7-b90e-3d36fed8668a">
											<gml:posList>35.66798018842761 139.74575665476584 6.53 35.66798608627328 139.74574819818773 6.53 35.66798608627328 139.74574819818773 14.3 35.66798018842761 139.74575665476584 14.3 35.66798018842761 139.74575665476584 6.53</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e0097cfd-b651-4c04-8113-a57d296845b7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e0097cfd-b651-4c04-8113-a57d296845b7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e0097cfd-b651-4c04-8113-a57d296845b7">
											<gml:posList>35.66799443442967 139.74577496440656 6.53 35.66798018842761 139.74575665476584 6.53 35.66798018842761 139.74575665476584 14.3 35.66799443442967 139.74577496440656 14.3 35.66799443442967 139.74577496440656 6.53</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-df3f505e-e333-4efd-9084-3bae577829af">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-df3f505e-e333-4efd-9084-3bae577829af">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-df3f505e-e333-4efd-9084-3bae577829af">
											<gml:posList>35.667844863721086 139.74579177391854 61.55 35.667844863721086 139.74579177391854 65.134 35.667878026708976 139.74574419609377 65.134 35.667878026708976 139.74574419609377 61.55 35.667844863721086 139.74579177391854 61.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3df6ec2d-6576-4aa7-8872-12ba1cd571e8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3df6ec2d-6576-4aa7-8872-12ba1cd571e8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3df6ec2d-6576-4aa7-8872-12ba1cd571e8">
											<gml:posList>35.667955360731625 139.74577612271193 65.7 35.667955360731625 139.74577612271193 65.134 35.66795814810183 139.74577904683875 65.134 35.66795814810183 139.74577904683875 65.7 35.667955360731625 139.74577612271193 65.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5cb52611-fb94-4990-bff6-0ee4eaa26ab6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5cb52611-fb94-4990-bff6-0ee4eaa26ab6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5cb52611-fb94-4990-bff6-0ee4eaa26ab6">
											<gml:posList>35.66794465959506 139.74578599840748 65.7 35.66795504159663 139.74577109716415 65.7 35.66795504159663 139.74577109716415 60.3 35.66794465959506 139.74578599840748 60.3 35.66794465959506 139.74578599840748 65.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a55075ee-51bd-4d24-8388-398ac6ff15bf">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a55075ee-51bd-4d24-8388-398ac6ff15bf">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a55075ee-51bd-4d24-8388-398ac6ff15bf">
											<gml:posList>35.66792741451545 139.74579591438217 65.134 35.667899495753474 139.7457666842236 65.134 35.667899495753474 139.7457666842236 61.55 35.66792741451545 139.74579591438217 61.55 35.66792741451545 139.74579591438217 65.134</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-df286174-4e74-4f2a-a6f7-e708427a25e4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-df286174-4e74-4f2a-a6f7-e708427a25e4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-df286174-4e74-4f2a-a6f7-e708427a25e4">
											<gml:posList>35.66784828802943 139.74584012917916 61.55 35.66784828802943 139.74584012917916 65.134 35.66776938444052 139.74575697336934 65.134 35.66776938444052 139.74575697336934 61.55 35.66784828802943 139.74584012917916 61.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d96f72c2-5402-4d00-8778-d34496265da5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d96f72c2-5402-4d00-8778-d34496265da5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d96f72c2-5402-4d00-8778-d34496265da5">
											<gml:posList>35.6679622580725 139.74577864469768 65.7 35.66790172183702 139.74586547648786 65.7 35.66790172183702 139.74586547648786 14.3 35.6679622580725 139.74577864469768 14.3 35.6679622580725 139.74577864469768 65.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4e785c2d-21fc-469d-868b-c8680a350e57">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4e785c2d-21fc-469d-868b-c8680a350e57">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4e785c2d-21fc-469d-868b-c8680a350e57">
											<gml:posList>35.66795814810183 139.74577904683875 65.7 35.66795814810183 139.74577904683875 65.134 35.66789762087171 139.74586586756845 65.134 35.66789762087171 139.74586586756845 65.7 35.66795814810183 139.74577904683875 65.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f10ba7a7-d683-4aa3-bb80-6cc65c8cd462">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f10ba7a7-d683-4aa3-bb80-6cc65c8cd462">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f10ba7a7-d683-4aa3-bb80-6cc65c8cd462">
											<gml:posList>35.66792741451545 139.74579591438217 65.134 35.66792741451545 139.74579591438217 61.55 35.66788657979622 139.7458544912724 61.55 35.66788657979622 139.7458544912724 65.134 35.66792741451545 139.74579591438217 65.134</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c119d0b7-d498-4e63-9490-1546c210fd7a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c119d0b7-d498-4e63-9490-1546c210fd7a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c119d0b7-d498-4e63-9490-1546c210fd7a">
											<gml:posList>35.667872470464125 139.74594989918285 6.53 35.66799443442967 139.74577496440656 6.53 35.66799443442967 139.74577496440656 14.3 35.667918842921104 139.74588339638723 14.3 35.667918842921104 139.74588339638723 65.7 35.667872470464125 139.74594989918285 65.7 35.667872470464125 139.74594989918285 6.53</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-98f270dc-61c6-4f24-b788-b665975ba796">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-98f270dc-61c6-4f24-b788-b665975ba796">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-98f270dc-61c6-4f24-b788-b665975ba796">
											<gml:posList>35.667918842921104 139.74588339638723 14.3 35.66790172183702 139.74586547648786 14.3 35.66790172183702 139.74586547648786 65.7 35.667918842921104 139.74588339638723 65.7 35.667918842921104 139.74588339638723 14.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c968b74a-2eeb-498b-b931-a7196cf09969">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c968b74a-2eeb-498b-b931-a7196cf09969">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c968b74a-2eeb-498b-b931-a7196cf09969">
											<gml:posList>35.66789762087171 139.74586586756845 65.7 35.66789762087171 139.74586586756845 65.134 35.667914732942016 139.7458837874768 65.134 35.667914732942016 139.7458837874768 65.7 35.66789762087171 139.74586586756845 65.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-de1cd581-0884-485f-befb-f4fe5be0063a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-de1cd581-0884-485f-befb-f4fe5be0063a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-de1cd581-0884-485f-befb-f4fe5be0063a">
											<gml:posList>35.66788657979622 139.7458544912724 65.134 35.66788657979622 139.7458544912724 61.55 35.66785252641067 139.74590483150553 61.55 35.66785252641067 139.74590483150553 65.134 35.66788657979622 139.7458544912724 65.134</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9912a08a-3d42-4408-911e-7ecab63119f0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9912a08a-3d42-4408-911e-7ecab63119f0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9912a08a-3d42-4408-911e-7ecab63119f0">
											<gml:posList>35.66785252641067 139.74590483150553 65.134 35.66785252641067 139.74590483150553 61.55 35.66786902508476 139.74592212246372 61.55 35.66786902508476 139.74592212246372 65.134 35.66785252641067 139.74590483150553 65.134</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ade4f58d-9e4c-4151-af8c-ae0dd372653b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ade4f58d-9e4c-4151-af8c-ae0dd372653b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ade4f58d-9e4c-4151-af8c-ae0dd372653b">
											<gml:posList>35.667868369490506 139.74595027921305 65.7 35.667914732942016 139.7458837874768 65.7 35.667914732942016 139.7458837874768 65.134 35.667889367665204 139.74592016725242 65.134 35.667868369490506 139.74595027921305 65.134 35.667868369490506 139.74595027921305 65.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-da55380f-be08-4783-b1aa-7340c4bd2cac">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-da55380f-be08-4783-b1aa-7340c4bd2cac">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-da55380f-be08-4783-b1aa-7340c4bd2cac">
											<gml:posList>35.66786902508476 139.74592212246372 65.134 35.66786902508476 139.74592212246372 61.55 35.6678480359152 139.74595222336046 61.55 35.6678480359152 139.74595222336046 65.134 35.66786902508476 139.74592212246372 65.134</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-27b137f4-a172-47f7-a4b1-5d869802a15c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-27b137f4-a172-47f7-a4b1-5d869802a15c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-27b137f4-a172-47f7-a4b1-5d869802a15c">
											<gml:posList>35.667868369490506 139.74595027921305 65.7 35.667868369490506 139.74595027921305 65.134 35.667870976445705 139.74595301575883 65.134 35.667870976445705 139.74595301575883 65.7 35.667868369490506 139.74595027921305 65.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-37c41926-a77d-4e39-aef8-5c211b603238">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-37c41926-a77d-4e39-aef8-5c211b603238">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-37c41926-a77d-4e39-aef8-5c211b603238">
											<gml:posList>35.667872470464125 139.74594989918285 6.53 35.667872470464125 139.74594989918285 65.7 35.66787508643307 139.7459526357189 65.7 35.66787508643307 139.7459526357189 17.5 35.667879127652995 139.74595686190065 17.5 35.667879127652995 139.74595686190065 6.53 35.667872470464125 139.74594989918285 6.53</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c835a913-0643-4294-91b3-29c7efc75a15">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c835a913-0643-4294-91b3-29c7efc75a15">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c835a913-0643-4294-91b3-29c7efc75a15">
											<gml:posList>35.6678480359152 139.74595222336046 65.134 35.6678480359152 139.74595222336046 61.55 35.66785064287038 139.7459549599056 61.55 35.66785064287038 139.7459549599056 65.134 35.6678480359152 139.74595222336046 65.134</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0a9a857d-515c-4430-89f0-c82a314073e6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0a9a857d-515c-4430-89f0-c82a314073e6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0a9a857d-515c-4430-89f0-c82a314073e6">
											<gml:posList>35.667840116770414 139.74597006008912 65.134 35.667840116770414 139.74597006008912 61.55 35.667819577676596 139.7459496364926 61.55 35.667819577676596 139.7459496364926 65.134 35.667840116770414 139.74597006008912 65.134</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-09bd0074-859d-459d-8976-9999f659ac84">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-09bd0074-859d-459d-8976-9999f659ac84">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-09bd0074-859d-459d-8976-9999f659ac84">
											<gml:posList>35.66787175307188 139.7459674298308 6.53 35.667879127652995 139.74595686190065 6.53 35.667879127652995 139.74595686190065 17.5 35.66787175307188 139.7459674298308 17.5 35.66787175307188 139.7459674298308 6.53</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d99e90e0-78e5-4481-a3aa-0f28782b5f74">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d99e90e0-78e5-4481-a3aa-0f28782b5f74">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d99e90e0-78e5-4481-a3aa-0f28782b5f74">
											<gml:posList>35.66785064287038 139.7459549599056 65.134 35.66785064287038 139.7459549599056 61.55 35.667840116770414 139.74597006008912 61.55 35.667840116770414 139.74597006008912 65.134 35.66785064287038 139.7459549599056 65.134</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e1913502-5680-41bd-b3dc-487831fb6285">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e1913502-5680-41bd-b3dc-487831fb6285">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e1913502-5680-41bd-b3dc-487831fb6285">
											<gml:posList>35.66787529816762 139.74597114844155 6.53 35.66787175307188 139.7459674298308 6.53 35.66787175307188 139.7459674298308 17.5 35.66787529816762 139.74597114844155 17.5 35.66787529816762 139.74597114844155 6.53</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-db0a988b-9bdc-4219-8764-08156e4ae861">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-db0a988b-9bdc-4219-8764-08156e4ae861">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-db0a988b-9bdc-4219-8764-08156e4ae861">
											<gml:posList>35.66786579855698 139.745984767357 6.53 35.66787529816762 139.74597114844155 6.53 35.66787529816762 139.74597114844155 17.5 35.66786579855698 139.745984767357 17.5 35.66786579855698 139.745984767357 6.53</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-944fb6fc-2210-4dbc-bf30-7ddf596f0a0f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-944fb6fc-2210-4dbc-bf30-7ddf596f0a0f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-944fb6fc-2210-4dbc-bf30-7ddf596f0a0f">
											<gml:posList>35.66785821224257 139.74597682256405 6.53 35.66786579855698 139.745984767357 6.53 35.66786579855698 139.745984767357 17.5 35.66785821224257 139.74597682256405 17.5 35.66785821224257 139.74597682256405 6.53</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-55079903-a91e-492e-8a1e-abf134cea6e5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-55079903-a91e-492e-8a1e-abf134cea6e5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-55079903-a91e-492e-8a1e-abf134cea6e5">
											<gml:posList>35.667815923749984 139.74603198770916 65.7 35.667815923749984 139.74603198770916 65.134 35.66779582587464 139.74601092296 65.134 35.66779582587464 139.74601092296 65.7 35.667815923749984 139.74603198770916 65.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-df801bf3-f3df-4d0a-9e9e-8439e4095f0f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-df801bf3-f3df-4d0a-9e9e-8439e4095f0f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-df801bf3-f3df-4d0a-9e9e-8439e4095f0f">
											<gml:posList>35.66781625189583 139.74603702428539 65.7 35.6677961359939 139.7460159595545 65.7 35.6677961359939 139.7460159595545 14.3 35.66781625189583 139.74603702428539 14.3 35.66781625189583 139.74603702428539 65.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ee0e7b31-be96-4af8-ad89-8399945e4d5b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ee0e7b31-be96-4af8-ad89-8399945e4d5b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ee0e7b31-be96-4af8-ad89-8399945e4d5b">
											<gml:posList>35.66787508643307 139.7459526357189 65.7 35.66781625189583 139.74603702428539 65.7 35.66781625189583 139.74603702428539 14.3 35.667740894249356 139.746145102055 14.3 35.667740894249356 139.746145102055 6.53 35.66785821224257 139.74597682256405 6.53 35.66785821224257 139.74597682256405 17.5 35.66787508643307 139.7459526357189 17.5 35.66787508643307 139.7459526357189 65.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区虎ノ門二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-3169</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">1162.81016</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">211</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1320</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>6</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.05</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">2</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">2</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>