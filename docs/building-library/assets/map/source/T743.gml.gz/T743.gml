<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_d44ded73-4661-4b12-8280-b66552290388">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001001</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">412</bldg:usage>
			<bldg:measuredHeight uom="m">19.2</bldg:measuredHeight>
			<bldg:storeysAboveGround>6</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>1</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.667290148599115 139.74183790464005 0 35.66734802129222 139.74172528147693 0 35.66705679596736 139.7414997275359 0 35.66699892348205 139.74161235045185 0 35.667290148599115 139.74183790464005 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667290148599115 139.74183790464005 28.117 35.66699892348205 139.74161235045185 28.117 35.66705679596736 139.7414997275359 28.117 35.66734802129222 139.74172528147693 28.117 35.667290148599115 139.74183790464005 28.117</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667290148599115 139.74183790464005 28.117 35.66734802129222 139.74172528147693 28.117 35.66734802129222 139.74172528147693 47.27 35.667290148599115 139.74183790464005 47.27 35.667290148599115 139.74183790464005 28.117</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66734802129222 139.74172528147693 28.117 35.66705679596736 139.7414997275359 28.117 35.66705679596736 139.7414997275359 47.27 35.66734802129222 139.74172528147693 47.27 35.66734802129222 139.74172528147693 28.117</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66705679596736 139.7414997275359 28.117 35.66699892348205 139.74161235045185 28.117 35.66699892348205 139.74161235045185 47.27 35.66705679596736 139.7414997275359 47.27 35.66705679596736 139.7414997275359 28.117</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66699892348205 139.74161235045185 28.117 35.667290148599115 139.74183790464005 28.117 35.667290148599115 139.74183790464005 47.27 35.66699892348205 139.74161235045185 47.27 35.66699892348205 139.74161235045185 28.117</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667290148599115 139.74183790464005 47.27 35.66734802129222 139.74172528147693 47.27 35.66705679596736 139.7414997275359 47.27 35.66699892348205 139.74161235045185 47.27 35.667290148599115 139.74183790464005 47.27</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-9f2bed08-e046-4ecb-b863-323b39cda49f"/>
							<gml:surfaceMember xlink:href="#poly-aa148748-0aef-47d5-b14f-4959d5a7f2d1"/>
							<gml:surfaceMember xlink:href="#poly-29fa6c68-393b-402a-8afd-2dec3a753b64"/>
							<gml:surfaceMember xlink:href="#poly-8051e3ea-2567-48b1-9c67-071a58769c09"/>
							<gml:surfaceMember xlink:href="#poly-c341c6e2-492b-4ee3-b83e-2fa67f15a1ff"/>
							<gml:surfaceMember xlink:href="#poly-f6041136-b0b1-4df9-9741-6d020887da8d"/>
							<gml:surfaceMember xlink:href="#poly-50ac8b1a-745c-4b7d-bd68-982948a7681d"/>
							<gml:surfaceMember xlink:href="#poly-30ac3a33-d3af-4dea-896b-4289e90bf2d0"/>
							<gml:surfaceMember xlink:href="#poly-3b0d904f-4e96-4f65-aae8-57e6c4d53ed7"/>
							<gml:surfaceMember xlink:href="#poly-507645cc-42fc-4673-a0be-5942b361e09d"/>
							<gml:surfaceMember xlink:href="#poly-e833fa8a-32ec-4074-ab68-f60f0f4a3294"/>
							<gml:surfaceMember xlink:href="#poly-28749d14-0267-4016-b4c2-2ad26c2a9ead"/>
							<gml:surfaceMember xlink:href="#poly-0b3790e5-90e9-476d-8a6e-db562bbc76ea"/>
							<gml:surfaceMember xlink:href="#poly-8529d72f-6678-4bd7-b2d7-ce024d59257a"/>
							<gml:surfaceMember xlink:href="#poly-1f0462c7-24a0-49e7-aa1f-5b2fe7da90a0"/>
							<gml:surfaceMember xlink:href="#poly-625724bc-3276-47be-a070-8133a480e94a"/>
							<gml:surfaceMember xlink:href="#poly-550d1cbf-9c56-4503-87c8-c827da75790d"/>
							<gml:surfaceMember xlink:href="#poly-d734c68c-f00c-4804-a1ab-e1d15b5db624"/>
							<gml:surfaceMember xlink:href="#poly-9206f57a-d119-421c-a578-db0b2d27fa1c"/>
							<gml:surfaceMember xlink:href="#poly-9f63064a-ad0a-4405-b8f5-d1985e3c3eff"/>
							<gml:surfaceMember xlink:href="#poly-cd215f58-b94a-4954-9c65-7bc69c64bfeb"/>
							<gml:surfaceMember xlink:href="#poly-4a382f61-85b6-4a24-9089-1feb978dfeab"/>
							<gml:surfaceMember xlink:href="#poly-e65c8833-22b5-477a-be07-48c97b03c989"/>
							<gml:surfaceMember xlink:href="#poly-6cb856ba-30d9-42a5-abbc-ecde42991079"/>
							<gml:surfaceMember xlink:href="#poly-9d9cf7c7-bd1d-4ff7-bae2-e732bf886c9c"/>
							<gml:surfaceMember xlink:href="#poly-b49f7fc6-353a-41a8-b857-8e4d8085393b"/>
							<gml:surfaceMember xlink:href="#poly-f1d3a755-9c2f-42ca-a94a-47b390c74377"/>
							<gml:surfaceMember xlink:href="#poly-1ae09d61-6092-4d20-a66e-6f2310d1d6b3"/>
							<gml:surfaceMember xlink:href="#poly-515b2009-db23-4833-aeb2-7662501ee725"/>
							<gml:surfaceMember xlink:href="#poly-d2273623-3588-4e77-8cc4-9ee69b1b9599"/>
							<gml:surfaceMember xlink:href="#poly-b9ad5fc6-7b38-4879-a321-662a47406fa9"/>
							<gml:surfaceMember xlink:href="#poly-b1a8f6ea-8d69-4b93-8d09-f0d71bfaaac9"/>
							<gml:surfaceMember xlink:href="#poly-22a28f81-3648-4acd-be2a-f79f2ae250bb"/>
							<gml:surfaceMember xlink:href="#poly-1b07ffff-a52f-42a9-a529-21a405affc5f"/>
							<gml:surfaceMember xlink:href="#poly-b4e03d21-97e0-4d7b-a6c1-5b7e5fb0556b"/>
							<gml:surfaceMember xlink:href="#poly-fa2f26c7-ceda-4694-8146-c6f60d4320e2"/>
							<gml:surfaceMember xlink:href="#poly-e8c342bb-1adb-4751-bb8b-142e49e0914c"/>
							<gml:surfaceMember xlink:href="#poly-141fc1c0-be07-488c-bee4-73a713a4667a"/>
							<gml:surfaceMember xlink:href="#poly-6c0dec14-4f35-487f-8eb6-bc53bc5d5d39"/>
							<gml:surfaceMember xlink:href="#poly-82e40454-b754-47a9-b24e-10c99259de11"/>
							<gml:surfaceMember xlink:href="#poly-a8a94fb2-5dbf-4826-acae-c8569f4e6e30"/>
							<gml:surfaceMember xlink:href="#poly-0e05c13d-fda5-4e97-bc7d-8404c2f6d710"/>
							<gml:surfaceMember xlink:href="#poly-c99180f6-7d83-4ef3-941c-492ad21712d0"/>
							<gml:surfaceMember xlink:href="#poly-f9ce2e0f-c3c4-4d53-a631-bf12d8d25b36"/>
							<gml:surfaceMember xlink:href="#poly-3aa3ca2a-be05-4c6d-8cd6-5cd886023fd3"/>
							<gml:surfaceMember xlink:href="#poly-0bdd7802-bac1-4ba4-a64b-0854451bb3a5"/>
							<gml:surfaceMember xlink:href="#poly-f9bf396d-6e70-4bc0-bec6-36ebe6ac455c"/>
							<gml:surfaceMember xlink:href="#poly-7da91462-48e5-4eba-9aed-e55d6e8eda3f"/>
							<gml:surfaceMember xlink:href="#poly-b787ff28-ba05-4941-8e61-37bbb95e41ac"/>
							<gml:surfaceMember xlink:href="#poly-9085ab25-91df-499c-ada0-f1955d03221e"/>
							<gml:surfaceMember xlink:href="#poly-cbda62e6-4fca-4f11-8172-6ef7377df8e1"/>
							<gml:surfaceMember xlink:href="#poly-f761c1aa-fcf6-46d4-a214-e6aa6e79b050"/>
							<gml:surfaceMember xlink:href="#poly-df894790-85df-462b-8833-234441d22fd3"/>
							<gml:surfaceMember xlink:href="#poly-9c5ded6c-dbe6-45de-84cc-47d73576aecd"/>
							<gml:surfaceMember xlink:href="#poly-67f639c8-5042-44f2-a652-491537495f33"/>
							<gml:surfaceMember xlink:href="#poly-e77690c2-f575-4fff-b0d6-0835d26ff13f"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_d44ded73-4661-4b12-8280-b66552290388_BuildingInstallation_1060">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2b89c863-0ea0-45e7-93ad-c24b5cb1a6fb">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66703859830763 139.74164307866712 48.8 35.667045465654944 139.74162977167126 48.8 35.66705448471585 139.74163676439503 48.8 35.667047626381496 139.74165007138149 48.8 35.66703859830763 139.74164307866712 48.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a72fff25-42d1-42d0-9940-e05bfc107add">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a72fff25-42d1-42d0-9940-e05bfc107add_0">
											<gml:posList>35.66705448471585 139.74163676439503 49.997 35.66705448471585 139.74163676439503 48.8 35.667045465654944 139.74162977167126 48.8 35.667045465654944 139.74162977167126 49.997 35.66705448471585 139.74163676439503 49.997</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-03ebef1b-79dc-4aae-ba5b-0b4c5cc4afe1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-03ebef1b-79dc-4aae-ba5b-0b4c5cc4afe1_0">
											<gml:posList>35.667045465654944 139.74162977167126 49.997 35.667045465654944 139.74162977167126 48.8 35.66703859830763 139.74164307866712 48.8 35.66703859830763 139.74164307866712 49.997 35.667045465654944 139.74162977167126 49.997</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2a9b2908-ccd2-4552-9013-421e4d9b12f9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2a9b2908-ccd2-4552-9013-421e4d9b12f9_0">
											<gml:posList>35.667047626381496 139.74165007138149 49.997 35.66705448471585 139.74163676439503 49.997 35.667045465654944 139.74162977167126 49.997 35.66703859830763 139.74164307866712 49.997 35.667047626381496 139.74165007138149 49.997</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c3b009c8-59c9-4be9-a1bf-77edb6f43a8c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c3b009c8-59c9-4be9-a1bf-77edb6f43a8c_0">
											<gml:posList>35.667047626381496 139.74165007138149 49.997 35.667047626381496 139.74165007138149 48.8 35.66705448471585 139.74163676439503 48.8 35.66705448471585 139.74163676439503 49.997 35.667047626381496 139.74165007138149 49.997</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1f1b1540-3a5a-4131-b3b4-d8075ddb55d6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1f1b1540-3a5a-4131-b3b4-d8075ddb55d6_0">
											<gml:posList>35.66703859830763 139.74164307866712 49.997 35.66703859830763 139.74164307866712 48.8 35.667047626381496 139.74165007138149 48.8 35.667047626381496 139.74165007138149 49.997 35.66703859830763 139.74164307866712 49.997</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_d44ded73-4661-4b12-8280-b66552290388_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-03332127-d7b6-458d-8938-0a1f48e823dd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-03332127-d7b6-458d-8938-0a1f48e823dd_0">
											<gml:posList>35.66715124415703 139.74172754975706 52.103 35.66715894858003 139.74171265119583 51.103 35.66715124415703 139.74172754975706 51.103 35.66715124415703 139.74172754975706 52.103</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8d793d57-fc70-4be5-81cc-b5affffe7952">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8d793d57-fc70-4be5-81cc-b5affffe7952_0">
											<gml:posList>35.66715124415703 139.74172754975706 52.103 35.66715894858003 139.74171265119583 52.103 35.66715894858003 139.74171265119583 51.103 35.66715124415703 139.74172754975706 52.103</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1322af86-dc60-43c6-aedc-06a5d7d863f9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1322af86-dc60-43c6-aedc-06a5d7d863f9_0">
											<gml:posList>35.667166768095875 139.74171870641482 51.103 35.66715894858003 139.74171265119583 52.103 35.667166768095875 139.74171870641482 52.103 35.667166768095875 139.74171870641482 51.103</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ea3e9ec4-4c6b-4e1c-b01e-13cd80cbc03e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ea3e9ec4-4c6b-4e1c-b01e-13cd80cbc03e_0">
											<gml:posList>35.667166768095875 139.74171870641482 51.103 35.66715894858003 139.74171265119583 51.103 35.66715894858003 139.74171265119583 52.103 35.667166768095875 139.74171870641482 51.103</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-94b190d7-e67b-4957-83fd-543b5c77a21b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-94b190d7-e67b-4957-83fd-543b5c77a21b_0">
											<gml:posList>35.66714792514728 139.74172497987396 52.103 35.66718490327621 139.74175365675933 51.103 35.66714792514728 139.74172497987396 51.103 35.66714792514728 139.74172497987396 52.103</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f6d86064-b391-4d30-b4a8-aed4dd03b93e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f6d86064-b391-4d30-b4a8-aed4dd03b93e_0">
											<gml:posList>35.66714792514728 139.74172497987396 52.103 35.66718490327621 139.74175365675933 52.103 35.66718490327621 139.74175365675933 51.103 35.66714792514728 139.74172497987396 52.103</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bb88a5b9-2c24-40e3-b1fb-dd0864fea9af">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bb88a5b9-2c24-40e3-b1fb-dd0864fea9af_0">
											<gml:posList>35.667197017799595 139.74173003800402 52.103 35.667160093806324 139.7417014383841 51.103 35.667197017799595 139.74173003800402 51.103 35.667197017799595 139.74173003800402 52.103</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c25b85f1-e212-4739-89d9-f5285b2254d4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c25b85f1-e212-4739-89d9-f5285b2254d4_0">
											<gml:posList>35.667197017799595 139.74173003800402 52.103 35.667160093806324 139.7417014383841 52.103 35.667160093806324 139.7417014383841 51.103 35.667197017799595 139.74173003800402 52.103</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f9e84007-11ac-4e62-b664-2838521bd552">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f9e84007-11ac-4e62-b664-2838521bd552_0">
											<gml:posList>35.66718958975381 139.74171723333836 49.003 35.66716923375997 139.7417014721229 50.564 35.66716923375997 139.7417014721229 49.003 35.66718958975381 139.74171723333836 49.003</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4732f5f9-4067-432d-9f2f-b5b9b59781f1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4732f5f9-4067-432d-9f2f-b5b9b59781f1_0">
											<gml:posList>35.66718958975381 139.74171723333836 49.003 35.66718958975381 139.74171723333836 50.564 35.66716923375997 139.7417014721229 50.564 35.66718958975381 139.74171723333836 49.003</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2fd110fb-7d56-489c-b45c-84a636738b14">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2fd110fb-7d56-489c-b45c-84a636738b14_0">
											<gml:posList>35.667174870820084 139.74174158409224 51.103 35.66718502334015 139.74172189989142 52.103 35.667174870820084 139.74174158409224 52.103 35.667174870820084 139.74174158409224 51.103</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-43ec4827-e6a1-42e9-b5f8-a98de04b3ad6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-43ec4827-e6a1-42e9-b5f8-a98de04b3ad6_0">
											<gml:posList>35.667174870820084 139.74174158409224 51.103 35.66718502334015 139.74172189989142 51.103 35.66718502334015 139.74172189989142 52.103 35.667174870820084 139.74174158409224 51.103</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d1ec38f2-701b-4f36-856f-23165686d1b2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d1ec38f2-701b-4f36-856f-23165686d1b2_0">
											<gml:posList>35.66716923375997 139.7417014721229 49.003 35.667175543077875 139.74168923719245 50.564 35.667175543077875 139.74168923719245 49.003 35.66716923375997 139.7417014721229 49.003</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5b32bd09-f0de-4670-aee0-181aa8206fd5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5b32bd09-f0de-4670-aee0-181aa8206fd5_0">
											<gml:posList>35.66716923375997 139.7417014721229 49.003 35.66716923375997 139.7417014721229 50.564 35.667175543077875 139.74168923719245 50.564 35.66716923375997 139.7417014721229 49.003</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3d50e190-4359-46e2-8fd3-eccb61645731">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3d50e190-4359-46e2-8fd3-eccb61645731_0">
											<gml:posList>35.667175543077875 139.74168923719245 49.003 35.66719589907329 139.74170499840605 50.564 35.66719589907329 139.74170499840605 49.003 35.667175543077875 139.74168923719245 49.003</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-057db538-c2f6-4670-bd44-25e48bf36eca">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-057db538-c2f6-4670-bd44-25e48bf36eca_0">
											<gml:posList>35.667175543077875 139.74168923719245 49.003 35.667175543077875 139.74168923719245 50.564 35.66719589907329 139.74170499840605 50.564 35.667175543077875 139.74168923719245 49.003</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d8f17dfc-bb6c-4a2b-9e1b-a27922d9f40f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d8f17dfc-bb6c-4a2b-9e1b-a27922d9f40f_0">
											<gml:posList>35.66718958975381 139.74171723333836 50.564 35.667175543077875 139.74168923719245 50.564 35.66716923375997 139.7417014721229 50.564 35.66718958975381 139.74171723333836 50.564</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3170ea71-c77d-4cb0-962a-f7d1cdacf3c2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3170ea71-c77d-4cb0-962a-f7d1cdacf3c2_0">
											<gml:posList>35.66718958975381 139.74171723333836 50.564 35.66719589907329 139.74170499840605 50.564 35.667175543077875 139.74168923719245 50.564 35.66718958975381 139.74171723333836 50.564</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6bbcfaa9-8272-4420-9587-2412e112f4b9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6bbcfaa9-8272-4420-9587-2412e112f4b9_0">
											<gml:posList>35.66719589907329 139.74170499840605 49.003 35.66718958975381 139.74171723333836 50.564 35.66718958975381 139.74171723333836 49.003 35.66719589907329 139.74170499840605 49.003</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-008299e8-4599-4e3a-b108-ae48c0c81a92">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-008299e8-4599-4e3a-b108-ae48c0c81a92_0">
											<gml:posList>35.66719589907329 139.74170499840605 49.003 35.66719589907329 139.74170499840605 50.564 35.66718958975381 139.74171723333836 50.564 35.66719589907329 139.74170499840605 49.003</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-621e82db-7011-49b7-8c35-e6f874ebc11f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-621e82db-7011-49b7-8c35-e6f874ebc11f_0">
											<gml:posList>35.66714543787098 139.74172565651017 50.2 35.66714543787098 139.74172565651017 52.103 35.66714605890226 139.74172445180696 50.2 35.66714543787098 139.74172565651017 50.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cacb8e22-9ae2-43eb-bfa4-24f3621bdd64">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cacb8e22-9ae2-43eb-bfa4-24f3621bdd64_0">
											<gml:posList>35.66714605890226 139.74172445180696 49.003 35.66714605890226 139.74172445180696 50.2 35.667159532635296 139.7416983903802 49.003 35.66714605890226 139.74172445180696 49.003</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a5c080bf-6d99-464c-8469-49848c6eba11">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a5c080bf-6d99-464c-8469-49848c6eba11_0">
											<gml:posList>35.667159532635296 139.7416983903802 49.003 35.66714605890226 139.74172445180696 50.2 35.667159532635296 139.7416983903802 52.103 35.667159532635296 139.7416983903802 49.003</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c7a35ded-e6db-4e79-80f3-d91e8692f24b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c7a35ded-e6db-4e79-80f3-d91e8692f24b_0">
											<gml:posList>35.66714605890226 139.74172445180696 50.2 35.66714543787098 139.74172565651017 52.103 35.667159532635296 139.7416983903802 52.103 35.66714605890226 139.74172445180696 50.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cd2ee159-bc84-44aa-92e5-202839dc6634">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cd2ee159-bc84-44aa-92e5-202839dc6634_0">
											<gml:posList>35.66714792514728 139.74172497987396 52.103 35.667160093806324 139.7417014383841 51.103 35.667160093806324 139.7417014383841 52.103 35.66714792514728 139.74172497987396 52.103</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-709da953-1098-4bd2-8168-3ba4c757b76c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-709da953-1098-4bd2-8168-3ba4c757b76c_0">
											<gml:posList>35.66714792514728 139.74172497987396 52.103 35.66714792514728 139.74172497987396 51.103 35.667160093806324 139.7417014383841 51.103 35.66714792514728 139.74172497987396 52.103</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9208fecd-75b6-483e-8fce-2a7c3cf3d600">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9208fecd-75b6-483e-8fce-2a7c3cf3d600_0">
											<gml:posList>35.667159532635296 139.7416983903802 49.003 35.667199505059095 139.7417293392759 52.103 35.667199505059095 139.7417293392759 49.003 35.667159532635296 139.7416983903802 49.003</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bfcf1066-4757-4c0d-a55d-110d7e46058f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bfcf1066-4757-4c0d-a55d-110d7e46058f_0">
											<gml:posList>35.667159532635296 139.7416983903802 49.003 35.667159532635296 139.7416983903802 52.103 35.667199505059095 139.7417293392759 52.103 35.667159532635296 139.7416983903802 49.003</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9914d556-f4ed-4c6f-b42b-fb751a2b84b2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9914d556-f4ed-4c6f-b42b-fb751a2b84b2_0">
											<gml:posList>35.667159063680536 139.74173361602274 52.103 35.66715894858003 139.74171265119583 52.103 35.66715124415703 139.74172754975706 52.103 35.667159063680536 139.74173361602274 52.103</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-46ce5645-4703-4090-b685-3ca1ee4736dc">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-46ce5645-4703-4090-b685-3ca1ee4736dc_0">
											<gml:posList>35.667159063680536 139.74173361602274 52.103 35.667166768095875 139.74171870641482 52.103 35.66715894858003 139.74171265119583 52.103 35.667159063680536 139.74173361602274 52.103</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4f1d166b-fb7e-44c5-92f5-762998cd094d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4f1d166b-fb7e-44c5-92f5-762998cd094d_0">
											<gml:posList>35.6671672948105 139.74173570532534 51.103 35.66717743831589 139.74171602113594 52.103 35.66717743831589 139.74171602113594 51.103 35.6671672948105 139.74173570532534 51.103</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ba6a2a87-5d60-4ed3-a0c0-8dea0732124c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ba6a2a87-5d60-4ed3-a0c0-8dea0732124c_0">
											<gml:posList>35.6671672948105 139.74173570532534 51.103 35.6671672948105 139.74173570532534 52.103 35.66717743831589 139.74171602113594 52.103 35.6671672948105 139.74173570532534 51.103</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ba437b8f-14bb-4bf6-8854-93f38a5b59b3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ba437b8f-14bb-4bf6-8854-93f38a5b59b3_0">
											<gml:posList>35.667159063680536 139.74173361602274 51.103 35.667166768095875 139.74171870641482 52.103 35.667159063680536 139.74173361602274 52.103 35.667159063680536 139.74173361602274 51.103</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-35e810d9-552f-449b-bb50-d21df370523b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-35e810d9-552f-449b-bb50-d21df370523b_0">
											<gml:posList>35.667159063680536 139.74173361602274 51.103 35.667166768095875 139.74171870641482 51.103 35.667166768095875 139.74171870641482 52.103 35.667159063680536 139.74173361602274 51.103</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-70f991a6-3f6e-4576-9f4f-54368ae96f3b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-70f991a6-3f6e-4576-9f4f-54368ae96f3b_0">
											<gml:posList>35.667197017799595 139.74173003800402 51.103 35.667160093806324 139.7417014383841 51.103 35.66714792514728 139.74172497987396 51.103 35.667197017799595 139.74173003800402 51.103</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e9e5bf58-90fb-4974-a2a2-b3480e32cca8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e9e5bf58-90fb-4974-a2a2-b3480e32cca8_0">
											<gml:posList>35.66718490327621 139.74175365675933 51.103 35.667197017799595 139.74173003800402 51.103 35.66714792514728 139.74172497987396 51.103 35.66718490327621 139.74175365675933 51.103</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6e564b65-ee9f-4975-99e5-814886fd503b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6e564b65-ee9f-4975-99e5-814886fd503b_0">
											<gml:posList>35.667160093806324 139.7417014383841 52.103 35.667199505059095 139.7417293392759 52.103 35.667159532635296 139.7416983903802 52.103 35.667160093806324 139.7417014383841 52.103</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-469a2402-d369-4115-9e0b-f264a5e18077">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-469a2402-d369-4115-9e0b-f264a5e18077_0">
											<gml:posList>35.667159532635296 139.7416983903802 52.103 35.66714543787098 139.74172565651017 52.103 35.66714792514728 139.74172497987396 52.103 35.667159532635296 139.7416983903802 52.103</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-742b46fe-747d-4961-89f5-f89648a664c1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-742b46fe-747d-4961-89f5-f89648a664c1_0">
											<gml:posList>35.66718547346797 139.74175671580014 52.103 35.667199505059095 139.7417293392759 52.103 35.667197017799595 139.74173003800402 52.103 35.66718547346797 139.74175671580014 52.103</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c5598fde-73f5-4add-8616-b443a0c3f7e7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c5598fde-73f5-4add-8616-b443a0c3f7e7_0">
											<gml:posList>35.66714543787098 139.74172565651017 52.103 35.66718547346797 139.74175671580014 52.103 35.66718490327621 139.74175365675933 52.103 35.66714543787098 139.74172565651017 52.103</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-26a78d55-9100-45dd-aa8b-83bb6063d846">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-26a78d55-9100-45dd-aa8b-83bb6063d846_0">
											<gml:posList>35.667160093806324 139.7417014383841 52.103 35.667159532635296 139.7416983903802 52.103 35.66714792514728 139.74172497987396 52.103 35.667160093806324 139.7417014383841 52.103</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-60f7b343-11b7-4bbf-a9b4-32a84314ebc2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-60f7b343-11b7-4bbf-a9b4-32a84314ebc2_0">
											<gml:posList>35.667197017799595 139.74173003800402 52.103 35.667199505059095 139.7417293392759 52.103 35.667160093806324 139.7417014383841 52.103 35.667197017799595 139.74173003800402 52.103</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-04d5400c-9ed4-491c-8093-10d27ea18afb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-04d5400c-9ed4-491c-8093-10d27ea18afb_0">
											<gml:posList>35.66714543787098 139.74172565651017 52.103 35.66718490327621 139.74175365675933 52.103 35.66714792514728 139.74172497987396 52.103 35.66714543787098 139.74172565651017 52.103</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8863c30f-80be-467d-a122-6d5e269d83ee">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8863c30f-80be-467d-a122-6d5e269d83ee_0">
											<gml:posList>35.667197017799595 139.74173003800402 52.103 35.66718490327621 139.74175365675933 52.103 35.66718547346797 139.74175671580014 52.103 35.667197017799595 139.74173003800402 52.103</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-29e6cfeb-ff7d-451e-8da8-9056d780082c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-29e6cfeb-ff7d-451e-8da8-9056d780082c_0">
											<gml:posList>35.6671672948105 139.74173570532534 52.103 35.66718502334015 139.74172189989142 52.103 35.66717743831589 139.74171602113594 52.103 35.6671672948105 139.74173570532534 52.103</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d4070d1a-a866-4416-aff1-f40903c1df20">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d4070d1a-a866-4416-aff1-f40903c1df20_0">
											<gml:posList>35.6671672948105 139.74173570532534 52.103 35.667174870820084 139.74174158409224 52.103 35.66718502334015 139.74172189989142 52.103 35.6671672948105 139.74173570532534 52.103</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7bec2d48-a0da-452f-ab20-e25990c66ce8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7bec2d48-a0da-452f-ab20-e25990c66ce8_0">
											<gml:posList>35.667186112493404 139.7417554668927 49.003 35.66714605890226 139.74172445180696 50.2 35.66714605890226 139.74172445180696 49.003 35.667186112493404 139.7417554668927 49.003</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-08abf614-7b67-42f0-9018-d99a5f6c54f3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-08abf614-7b67-42f0-9018-d99a5f6c54f3_0">
											<gml:posList>35.667186112493404 139.7417554668927 49.003 35.667186112493404 139.7417554668927 50.2 35.66714605890226 139.74172445180696 50.2 35.667186112493404 139.7417554668927 49.003</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3b67aac2-6153-49b6-a200-ac9ac13fb39c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3b67aac2-6153-49b6-a200-ac9ac13fb39c_0">
											<gml:posList>35.66718547346797 139.74175671580014 50.2 35.66714543787098 139.74172565651017 52.103 35.66714543787098 139.74172565651017 50.2 35.66718547346797 139.74175671580014 50.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a7d1197a-3726-4947-8090-2549a0acad6e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a7d1197a-3726-4947-8090-2549a0acad6e_0">
											<gml:posList>35.66718547346797 139.74175671580014 50.2 35.66718547346797 139.74175671580014 52.103 35.66714543787098 139.74172565651017 52.103 35.66718547346797 139.74175671580014 50.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c8b5bd75-8c8f-4768-b13f-847296aefe5b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c8b5bd75-8c8f-4768-b13f-847296aefe5b_0">
											<gml:posList>35.66718490327621 139.74175365675933 52.103 35.667197017799595 139.74173003800402 51.103 35.66718490327621 139.74175365675933 51.103 35.66718490327621 139.74175365675933 52.103</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-60271a61-6a6c-4992-a89b-b97e080bb572">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-60271a61-6a6c-4992-a89b-b97e080bb572_0">
											<gml:posList>35.66718490327621 139.74175365675933 52.103 35.667197017799595 139.74173003800402 52.103 35.667197017799595 139.74173003800402 51.103 35.66718490327621 139.74175365675933 52.103</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-688dae59-8f0d-408c-be80-d2efc91b0ac2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-688dae59-8f0d-408c-be80-d2efc91b0ac2_0">
											<gml:posList>35.66718547346797 139.74175671580014 50.2 35.667186112493404 139.7417554668927 50.2 35.66718547346797 139.74175671580014 52.103 35.66718547346797 139.74175671580014 50.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a60a63a7-54fc-44a1-bcb0-5546d2e66b8e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a60a63a7-54fc-44a1-bcb0-5546d2e66b8e_0">
											<gml:posList>35.66718547346797 139.74175671580014 52.103 35.667186112493404 139.7417554668927 50.2 35.667199505059095 139.7417293392759 52.103 35.66718547346797 139.74175671580014 52.103</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7379df9f-74c1-429e-b322-115a06387dba">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7379df9f-74c1-429e-b322-115a06387dba_0">
											<gml:posList>35.667199505059095 139.7417293392759 52.103 35.667186112493404 139.7417554668927 50.2 35.667199505059095 139.7417293392759 49.003 35.667199505059095 139.7417293392759 52.103</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-188779d0-4ee2-40e3-9823-bbd6ef9d03fc">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-188779d0-4ee2-40e3-9823-bbd6ef9d03fc_0">
											<gml:posList>35.667186112493404 139.7417554668927 50.2 35.667186112493404 139.7417554668927 49.003 35.667199505059095 139.7417293392759 49.003 35.667186112493404 139.7417554668927 50.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b4ad27db-ee20-4848-8f5b-838b5bbf2186">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66715124415703 139.74172754975706 51.103 35.667159063680536 139.74173361602274 52.103 35.66715124415703 139.74172754975706 52.103 35.66715124415703 139.74172754975706 51.103</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9b01aaa5-6768-4b9d-b9ad-83a227103a25">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66715124415703 139.74172754975706 51.103 35.667159063680536 139.74173361602274 51.103 35.667159063680536 139.74173361602274 52.103 35.66715124415703 139.74172754975706 51.103</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-989880a2-0429-48d2-b9a0-985465589865">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667159063680536 139.74173361602274 51.103 35.66715894858003 139.74171265119583 51.103 35.667166768095875 139.74171870641482 51.103 35.667159063680536 139.74173361602274 51.103</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2394e400-020a-486c-97b4-a902bac2af8e">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667159063680536 139.74173361602274 51.103 35.66715124415703 139.74172754975706 51.103 35.66715894858003 139.74171265119583 51.103 35.667159063680536 139.74173361602274 51.103</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6a80db8c-d0bb-4194-8927-877a6ae728e1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667186112493404 139.7417554668927 50.2 35.66718547346797 139.74175671580014 50.2 35.66714543787098 139.74172565651017 50.2 35.667186112493404 139.7417554668927 50.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-57ded1aa-6c4d-4594-a3d1-542a5703435d">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66714605890226 139.74172445180696 50.2 35.667186112493404 139.7417554668927 50.2 35.66714543787098 139.74172565651017 50.2 35.66714605890226 139.74172445180696 50.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-08c5a1fc-25de-48a4-99a5-1268ab5310ae">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6671672948105 139.74173570532534 51.103 35.667174870820084 139.74174158409224 52.103 35.6671672948105 139.74173570532534 52.103 35.6671672948105 139.74173570532534 51.103</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0032dc60-7fc3-45dc-bd2c-b8074a217055">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6671672948105 139.74173570532534 51.103 35.667174870820084 139.74174158409224 51.103 35.667174870820084 139.74174158409224 52.103 35.6671672948105 139.74173570532534 51.103</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-70077eb6-bd37-4b7c-ae3d-bfe3bbb33bc8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66714605890226 139.74172445180696 49.003 35.667199505059095 139.7417293392759 49.003 35.667186112493404 139.7417554668927 49.003 35.66714605890226 139.74172445180696 49.003</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e735ed24-fac0-44f8-9050-6658f7590fef">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66714605890226 139.74172445180696 49.003 35.667159532635296 139.7416983903802 49.003 35.667199505059095 139.7417293392759 49.003 35.66714605890226 139.74172445180696 49.003</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ccb776f1-7ae6-4986-80a9-f32a12552f64">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6671672948105 139.74173570532534 51.103 35.66718502334015 139.74172189989142 51.103 35.667174870820084 139.74174158409224 51.103 35.6671672948105 139.74173570532534 51.103</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4ffa60fc-8e92-4803-a061-5484edd6a2b5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6671672948105 139.74173570532534 51.103 35.66717743831589 139.74171602113594 51.103 35.66718502334015 139.74172189989142 51.103 35.6671672948105 139.74173570532534 51.103</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9b338d51-481d-44ae-bfc9-bcbf66ba4e0d">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66718502334015 139.74172189989142 51.103 35.66717743831589 139.74171602113594 52.103 35.66718502334015 139.74172189989142 52.103 35.66718502334015 139.74172189989142 51.103</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-eab2f3b1-ff83-4ca1-a008-9816b093b0b9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66718502334015 139.74172189989142 51.103 35.66717743831589 139.74171602113594 51.103 35.66717743831589 139.74171602113594 52.103 35.66718502334015 139.74172189989142 51.103</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-588f22c3-f852-4cbf-a840-b7b6eb814923">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667175543077875 139.74168923719245 49.003 35.66718958975381 139.74171723333836 49.003 35.66716923375997 139.7417014721229 49.003 35.667175543077875 139.74168923719245 49.003</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ba6429dd-df74-4b4d-b494-d49fe17e85ce">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667175543077875 139.74168923719245 49.003 35.66719589907329 139.74170499840605 49.003 35.66718958975381 139.74171723333836 49.003 35.667175543077875 139.74168923719245 49.003</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-9f2bed08-e046-4ecb-b863-323b39cda49f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9f2bed08-e046-4ecb-b863-323b39cda49f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9f2bed08-e046-4ecb-b863-323b39cda49f">
											<gml:posList>35.66729014859909 139.74183790464005 28.117 35.66699892348204 139.74161235045185 28.117 35.66705679596736 139.7414997275359 28.117 35.6673480212922 139.74172528147693 28.117 35.66729014859909 139.74183790464005 28.117</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-aa148748-0aef-47d5-b14f-4959d5a7f2d1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-aa148748-0aef-47d5-b14f-4959d5a7f2d1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-aa148748-0aef-47d5-b14f-4959d5a7f2d1">
											<gml:posList>35.66705379883515 139.74150555210562 45.6 35.66705426953686 139.74150815837572 45.6 35.66732898961853 139.74173229523564 45.6 35.66733109844428 139.741731784718 45.6 35.66705379883515 139.74150555210562 45.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-29fa6c68-393b-402a-8afd-2dec3a753b64">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-29fa6c68-393b-402a-8afd-2dec3a753b64">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-29fa6c68-393b-402a-8afd-2dec3a753b64">
											<gml:posList>35.667022641919836 139.74162851646037 45.6 35.667001023243174 139.74161177366878 45.6 35.66699892348204 139.74161235045185 45.6 35.667023058477646 139.7416310454715 45.6 35.667023886613435 139.74162956438764 45.6 35.667022641919836 139.74162851646037 45.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-8051e3ea-2567-48b1-9c67-071a58769c09">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8051e3ea-2567-48b1-9c67-071a58769c09">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8051e3ea-2567-48b1-9c67-071a58769c09">
											<gml:posList>35.66699892348204 139.74161235045185 45.6 35.667001023243174 139.74161177366878 45.6 35.66705426953686 139.74150815837572 45.6 35.66705379883515 139.74150555210562 45.6 35.66699892348204 139.74161235045185 45.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c341c6e2-492b-4ee3-b83e-2fa67f15a1ff">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c341c6e2-492b-4ee3-b83e-2fa67f15a1ff">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c341c6e2-492b-4ee3-b83e-2fa67f15a1ff">
											<gml:posList>35.66705448471585 139.74163676439503 50.2 35.667056269072305 139.7416362873851 50.2 35.667035886001074 139.74162049310988 50.2 35.66703410164468 139.74162097012004 50.2 35.66705448471585 139.74163676439503 50.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f6041136-b0b1-4df9-9741-6d020887da8d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f6041136-b0b1-4df9-9741-6d020887da8d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f6041136-b0b1-4df9-9741-6d020887da8d">
											<gml:posList>35.66703410164468 139.74162097012004 50.2 35.667035886001074 139.74162049310988 50.2 35.66705899912424 139.74157566490166 50.2 35.667058600845245 139.74157346724283 50.2 35.66703410164468 139.74162097012004 50.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-50ac8b1a-745c-4b7d-bd68-982948a7681d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-50ac8b1a-745c-4b7d-bd68-982948a7681d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-50ac8b1a-745c-4b7d-bd68-982948a7681d">
											<gml:posList>35.66705448471585 139.74163676439503 50.2 35.667047626381496 139.74165007138149 50.2 35.66704941073801 139.74164959437186 50.2 35.667056269072305 139.7416362873851 50.2 35.66705448471585 139.74163676439503 50.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-30ac3a33-d3af-4dea-896b-4289e90bf2d0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-30ac3a33-d3af-4dea-896b-4289e90bf2d0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-30ac3a33-d3af-4dea-896b-4289e90bf2d0">
											<gml:posList>35.66708070655445 139.7415905850362 50.2 35.667058600845245 139.74157346724283 50.2 35.66705899912424 139.74157566490166 50.2 35.66708110483314 139.74159278269576 50.2 35.66708070655445 139.7415905850362 50.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-3b0d904f-4e96-4f65-aae8-57e6c4d53ed7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3b0d904f-4e96-4f65-aae8-57e6c4d53ed7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3b0d904f-4e96-4f65-aae8-57e6c4d53ed7">
											<gml:posList>35.66708070655445 139.7415905850362 50.2 35.66708110483314 139.74159278269576 50.2 35.66708638809847 139.74158254823513 50.2 35.66708599881649 139.7415803284736 50.2 35.66708070655445 139.7415905850362 50.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-507645cc-42fc-4673-a0be-5942b361e09d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-507645cc-42fc-4673-a0be-5942b361e09d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-507645cc-42fc-4673-a0be-5942b361e09d">
											<gml:posList>35.667255280979155 139.7418109042354 50.2 35.667254873699115 139.74180871762613 50.2 35.66704941073801 139.74164959437186 50.2 35.667047626381496 139.74165007138149 50.2 35.667255280979155 139.7418109042354 50.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e833fa8a-32ec-4074-ab68-f60f0f4a3294">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e833fa8a-32ec-4074-ab68-f60f0f4a3294">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e833fa8a-32ec-4074-ab68-f60f0f4a3294">
											<gml:posList>35.667058600845245 139.74157346724283 48.8 35.66708070655445 139.7415905850362 48.8 35.66708599881649 139.7415803284736 48.8 35.66726773812938 139.74172814569874 48.8 35.66726510080435 139.741733008877 48.8 35.667286485602055 139.7417504037276 48.8 35.667255280979155 139.7418109042354 48.8 35.66725741849191 139.74181255867012 48.8 35.667295238451565 139.741739226392 48.8 35.66706685070057 139.74155281319634 48.8 35.667023058477646 139.7416310454715 48.8 35.667047626381496 139.74165007138149 48.8 35.66705448471585 139.74163676439503 48.8 35.66703410164468 139.74162097012004 48.8 35.667058600845245 139.74157346724283 48.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-28749d14-0267-4016-b4c2-2ad26c2a9ead">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-28749d14-0267-4016-b4c2-2ad26c2a9ead">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-28749d14-0267-4016-b4c2-2ad26c2a9ead">
											<gml:posList>35.66726329839489 139.74173345276918 49.003 35.667265944733686 139.74172858958073 49.003 35.66708638809847 139.74158254823513 49.003 35.66708110483314 139.74159278269576 49.003 35.66705899912424 139.74157566490166 49.003 35.667035886001074 139.74162049310988 49.003 35.667056269072305 139.7416362873851 49.003 35.66704941073801 139.74164959437186 49.003 35.667254873699115 139.74180871762613 49.003 35.66728471024214 139.74175085863442 49.003 35.66726329839489 139.74173345276918 49.003</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-0b3790e5-90e9-476d-8a6e-db562bbc76ea">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0b3790e5-90e9-476d-8a6e-db562bbc76ea">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0b3790e5-90e9-476d-8a6e-db562bbc76ea">
											<gml:posList>35.66725950923179 139.7418119708549 45.02 35.66727825079678 139.74182647473356 45.02 35.66732898961853 139.74173229523564 45.02 35.66705426953686 139.74150815837572 45.02 35.667001023243174 139.74161177366878 45.02 35.667022641919836 139.74162851646037 45.02 35.667023886613435 139.74162956438764 45.02 35.66706685070057 139.74155281319634 45.02 35.667295238451565 139.741739226392 45.02 35.66725822853528 139.74181098923782 45.02 35.66725950923179 139.7418119708549 45.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-8529d72f-6678-4bd7-b2d7-ce024d59257a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8529d72f-6678-4bd7-b2d7-ce024d59257a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8529d72f-6678-4bd7-b2d7-ce024d59257a">
											<gml:posList>35.66708599881649 139.7415803284736 50.2 35.66708638809847 139.74158254823513 50.2 35.667265944733686 139.74172858958073 50.2 35.66726773812938 139.74172814569874 50.2 35.66708599881649 139.7415803284736 50.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-1f0462c7-24a0-49e7-aa1f-5b2fe7da90a0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1f0462c7-24a0-49e7-aa1f-5b2fe7da90a0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1f0462c7-24a0-49e7-aa1f-5b2fe7da90a0">
											<gml:posList>35.6673480212922 139.74172528147693 43.4 35.66705679596736 139.7414997275359 43.4 35.66705379883515 139.74150555210562 43.4 35.66733109844428 139.741731784718 43.4 35.667278703430505 139.74182903685013 43.4 35.66729014859909 139.74183790464005 43.4 35.6673480212922 139.74172528147693 43.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-625724bc-3276-47be-a070-8133a480e94a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-625724bc-3276-47be-a070-8133a480e94a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-625724bc-3276-47be-a070-8133a480e94a">
											<gml:posList>35.66725822853528 139.74181098923782 45.6 35.66725741849191 139.74181255867012 45.6 35.66725950923179 139.7418119708549 45.6 35.66725822853528 139.74181098923782 45.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-550d1cbf-9c56-4503-87c8-c827da75790d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-550d1cbf-9c56-4503-87c8-c827da75790d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-550d1cbf-9c56-4503-87c8-c827da75790d">
											<gml:posList>35.66726510080435 139.741733008877 50.2 35.66726773812938 139.74172814569874 50.2 35.667265944733686 139.74172858958073 50.2 35.66726329839489 139.74173345276918 50.2 35.66726510080435 139.741733008877 50.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d734c68c-f00c-4804-a1ab-e1d15b5db624">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d734c68c-f00c-4804-a1ab-e1d15b5db624">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d734c68c-f00c-4804-a1ab-e1d15b5db624">
											<gml:posList>35.667278703430505 139.74182903685013 45.6 35.66727825079678 139.74182647473356 45.6 35.66725950923179 139.7418119708549 45.6 35.66725741849191 139.74181255867012 45.6 35.667278703430505 139.74182903685013 45.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-9206f57a-d119-421c-a578-db0b2d27fa1c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9206f57a-d119-421c-a578-db0b2d27fa1c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9206f57a-d119-421c-a578-db0b2d27fa1c">
											<gml:posList>35.667286485602055 139.7417504037276 50.2 35.66728471024214 139.74175085863442 50.2 35.667254873699115 139.74180871762613 50.2 35.667255280979155 139.7418109042354 50.2 35.667286485602055 139.7417504037276 50.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-9f63064a-ad0a-4405-b8f5-d1985e3c3eff">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9f63064a-ad0a-4405-b8f5-d1985e3c3eff">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9f63064a-ad0a-4405-b8f5-d1985e3c3eff">
											<gml:posList>35.66726510080435 139.741733008877 50.2 35.66726329839489 139.74173345276918 50.2 35.66728471024214 139.74175085863442 50.2 35.667286485602055 139.7417504037276 50.2 35.66726510080435 139.741733008877 50.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-cd215f58-b94a-4954-9c65-7bc69c64bfeb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cd215f58-b94a-4954-9c65-7bc69c64bfeb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cd215f58-b94a-4954-9c65-7bc69c64bfeb">
											<gml:posList>35.66733109844428 139.741731784718 45.6 35.66732898961853 139.74173229523564 45.6 35.66727825079678 139.74182647473356 45.6 35.667278703430505 139.74182903685013 45.6 35.66733109844428 139.741731784718 45.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4a382f61-85b6-4a24-9089-1feb978dfeab">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4a382f61-85b6-4a24-9089-1feb978dfeab">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4a382f61-85b6-4a24-9089-1feb978dfeab">
											<gml:posList>35.66708638809847 139.74158254823513 50.2 35.66708638809847 139.74158254823513 49.003 35.667265944733686 139.74172858958073 49.003 35.667265944733686 139.74172858958073 50.2 35.66708638809847 139.74158254823513 50.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e65c8833-22b5-477a-be07-48c97b03c989">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e65c8833-22b5-477a-be07-48c97b03c989">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e65c8833-22b5-477a-be07-48c97b03c989">
											<gml:posList>35.66705426953686 139.74150815837572 45.6 35.66705426953686 139.74150815837572 45.02 35.66732898961853 139.74173229523564 45.02 35.66732898961853 139.74173229523564 45.6 35.66705426953686 139.74150815837572 45.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6cb856ba-30d9-42a5-abbc-ecde42991079">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6cb856ba-30d9-42a5-abbc-ecde42991079">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6cb856ba-30d9-42a5-abbc-ecde42991079">
											<gml:posList>35.66726329839489 139.74173345276918 50.2 35.66726329839489 139.74173345276918 49.003 35.66728471024214 139.74175085863442 49.003 35.66728471024214 139.74175085863442 50.2 35.66726329839489 139.74173345276918 50.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9d9cf7c7-bd1d-4ff7-bae2-e732bf886c9c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9d9cf7c7-bd1d-4ff7-bae2-e732bf886c9c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9d9cf7c7-bd1d-4ff7-bae2-e732bf886c9c">
											<gml:posList>35.66699892348204 139.74161235045185 28.117 35.66699892348204 139.74161235045185 45.6 35.66705379883515 139.74150555210562 45.6 35.66705379883515 139.74150555210562 43.4 35.66705679596736 139.7414997275359 43.4 35.66705679596736 139.7414997275359 28.117 35.66699892348204 139.74161235045185 28.117</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b49f7fc6-353a-41a8-b857-8e4d8085393b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b49f7fc6-353a-41a8-b857-8e4d8085393b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b49f7fc6-353a-41a8-b857-8e4d8085393b">
											<gml:posList>35.667001023243174 139.74161177366878 45.6 35.667001023243174 139.74161177366878 45.02 35.66705426953686 139.74150815837572 45.02 35.66705426953686 139.74150815837572 45.6 35.667001023243174 139.74161177366878 45.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f1d3a755-9c2f-42ca-a94a-47b390c74377">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f1d3a755-9c2f-42ca-a94a-47b390c74377">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f1d3a755-9c2f-42ca-a94a-47b390c74377">
											<gml:posList>35.667058600845245 139.74157346724283 50.2 35.66708070655445 139.7415905850362 50.2 35.66708070655445 139.7415905850362 48.8 35.667058600845245 139.74157346724283 48.8 35.667058600845245 139.74157346724283 50.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1ae09d61-6092-4d20-a66e-6f2310d1d6b3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1ae09d61-6092-4d20-a66e-6f2310d1d6b3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1ae09d61-6092-4d20-a66e-6f2310d1d6b3">
											<gml:posList>35.66705899912424 139.74157566490166 50.2 35.66705899912424 139.74157566490166 49.003 35.66708110483314 139.74159278269576 49.003 35.66708110483314 139.74159278269576 50.2 35.66705899912424 139.74157566490166 50.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-515b2009-db23-4833-aeb2-7662501ee725">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-515b2009-db23-4833-aeb2-7662501ee725">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-515b2009-db23-4833-aeb2-7662501ee725">
											<gml:posList>35.66708070655445 139.7415905850362 50.2 35.66708599881649 139.7415803284736 50.2 35.66708599881649 139.7415803284736 48.8 35.66708070655445 139.7415905850362 48.8 35.66708070655445 139.7415905850362 50.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d2273623-3588-4e77-8cc4-9ee69b1b9599">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d2273623-3588-4e77-8cc4-9ee69b1b9599">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d2273623-3588-4e77-8cc4-9ee69b1b9599">
											<gml:posList>35.66708110483314 139.74159278269576 50.2 35.66708110483314 139.74159278269576 49.003 35.66708638809847 139.74158254823513 49.003 35.66708638809847 139.74158254823513 50.2 35.66708110483314 139.74159278269576 50.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b9ad5fc6-7b38-4879-a321-662a47406fa9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b9ad5fc6-7b38-4879-a321-662a47406fa9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b9ad5fc6-7b38-4879-a321-662a47406fa9">
											<gml:posList>35.667023886613435 139.74162956438764 45.6 35.667023058477646 139.7416310454715 45.6 35.667023058477646 139.7416310454715 48.8 35.66706685070057 139.74155281319634 48.8 35.66706685070057 139.74155281319634 45.02 35.667023886613435 139.74162956438764 45.02 35.667023886613435 139.74162956438764 45.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b1a8f6ea-8d69-4b93-8d09-f0d71bfaaac9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b1a8f6ea-8d69-4b93-8d09-f0d71bfaaac9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b1a8f6ea-8d69-4b93-8d09-f0d71bfaaac9">
											<gml:posList>35.66703410164468 139.74162097012004 50.2 35.667058600845245 139.74157346724283 50.2 35.667058600845245 139.74157346724283 48.8 35.66703410164468 139.74162097012004 48.8 35.66703410164468 139.74162097012004 50.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-22a28f81-3648-4acd-be2a-f79f2ae250bb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-22a28f81-3648-4acd-be2a-f79f2ae250bb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-22a28f81-3648-4acd-be2a-f79f2ae250bb">
											<gml:posList>35.667035886001074 139.74162049310988 50.2 35.667035886001074 139.74162049310988 49.003 35.66705899912424 139.74157566490166 49.003 35.66705899912424 139.74157566490166 50.2 35.667035886001074 139.74162049310988 50.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1b07ffff-a52f-42a9-a529-21a405affc5f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1b07ffff-a52f-42a9-a529-21a405affc5f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1b07ffff-a52f-42a9-a529-21a405affc5f">
											<gml:posList>35.6673480212922 139.74172528147693 28.117 35.66705679596736 139.7414997275359 28.117 35.66705679596736 139.7414997275359 43.4 35.6673480212922 139.74172528147693 43.4 35.6673480212922 139.74172528147693 28.117</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b4e03d21-97e0-4d7b-a6c1-5b7e5fb0556b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b4e03d21-97e0-4d7b-a6c1-5b7e5fb0556b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b4e03d21-97e0-4d7b-a6c1-5b7e5fb0556b">
											<gml:posList>35.66705379883515 139.74150555210562 45.6 35.66733109844428 139.741731784718 45.6 35.66733109844428 139.741731784718 43.4 35.66705379883515 139.74150555210562 43.4 35.66705379883515 139.74150555210562 45.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-fa2f26c7-ceda-4694-8146-c6f60d4320e2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fa2f26c7-ceda-4694-8146-c6f60d4320e2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fa2f26c7-ceda-4694-8146-c6f60d4320e2">
											<gml:posList>35.667022641919836 139.74162851646037 45.6 35.667022641919836 139.74162851646037 45.02 35.667001023243174 139.74161177366878 45.02 35.667001023243174 139.74161177366878 45.6 35.667022641919836 139.74162851646037 45.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e8c342bb-1adb-4751-bb8b-142e49e0914c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e8c342bb-1adb-4751-bb8b-142e49e0914c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e8c342bb-1adb-4751-bb8b-142e49e0914c">
											<gml:posList>35.667056269072305 139.7416362873851 50.2 35.667056269072305 139.7416362873851 49.003 35.667035886001074 139.74162049310988 49.003 35.667035886001074 139.74162049310988 50.2 35.667056269072305 139.7416362873851 50.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-141fc1c0-be07-488c-bee4-73a713a4667a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-141fc1c0-be07-488c-bee4-73a713a4667a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-141fc1c0-be07-488c-bee4-73a713a4667a">
											<gml:posList>35.66705448471585 139.74163676439503 50.2 35.66703410164468 139.74162097012004 50.2 35.66703410164468 139.74162097012004 48.8 35.66705448471585 139.74163676439503 48.8 35.66705448471585 139.74163676439503 50.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6c0dec14-4f35-487f-8eb6-bc53bc5d5d39">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6c0dec14-4f35-487f-8eb6-bc53bc5d5d39">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6c0dec14-4f35-487f-8eb6-bc53bc5d5d39">
											<gml:posList>35.667023886613435 139.74162956438764 45.6 35.667023886613435 139.74162956438764 45.02 35.667022641919836 139.74162851646037 45.02 35.667022641919836 139.74162851646037 45.6 35.667023886613435 139.74162956438764 45.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-82e40454-b754-47a9-b24e-10c99259de11">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-82e40454-b754-47a9-b24e-10c99259de11">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-82e40454-b754-47a9-b24e-10c99259de11">
											<gml:posList>35.66704941073801 139.74164959437186 50.2 35.66704941073801 139.74164959437186 49.003 35.667056269072305 139.7416362873851 49.003 35.667056269072305 139.7416362873851 50.2 35.66704941073801 139.74164959437186 50.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a8a94fb2-5dbf-4826-acae-c8569f4e6e30">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a8a94fb2-5dbf-4826-acae-c8569f4e6e30">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a8a94fb2-5dbf-4826-acae-c8569f4e6e30">
											<gml:posList>35.667047626381496 139.74165007138149 50.2 35.66705448471585 139.74163676439503 50.2 35.66705448471585 139.74163676439503 48.8 35.667047626381496 139.74165007138149 48.8 35.667047626381496 139.74165007138149 50.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0e05c13d-fda5-4e97-bc7d-8404c2f6d710">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0e05c13d-fda5-4e97-bc7d-8404c2f6d710">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0e05c13d-fda5-4e97-bc7d-8404c2f6d710">
											<gml:posList>35.66706685070057 139.74155281319634 48.8 35.667295238451565 139.741739226392 48.8 35.667295238451565 139.741739226392 45.02 35.66706685070057 139.74155281319634 45.02 35.66706685070057 139.74155281319634 48.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c99180f6-7d83-4ef3-941c-492ad21712d0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c99180f6-7d83-4ef3-941c-492ad21712d0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c99180f6-7d83-4ef3-941c-492ad21712d0">
											<gml:posList>35.66708599881649 139.7415803284736 50.2 35.66726773812938 139.74172814569874 50.2 35.66726773812938 139.74172814569874 48.8 35.66708599881649 139.7415803284736 48.8 35.66708599881649 139.7415803284736 50.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f9ce2e0f-c3c4-4d53-a631-bf12d8d25b36">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f9ce2e0f-c3c4-4d53-a631-bf12d8d25b36">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f9ce2e0f-c3c4-4d53-a631-bf12d8d25b36">
											<gml:posList>35.667278703430505 139.74182903685013 43.4 35.667278703430505 139.74182903685013 45.6 35.66725741849191 139.74181255867012 45.6 35.66725741849191 139.74181255867012 48.8 35.667255280979155 139.7418109042354 48.8 35.667255280979155 139.7418109042354 50.2 35.667047626381496 139.74165007138149 50.2 35.667047626381496 139.74165007138149 48.8 35.667023058477646 139.7416310454715 48.8 35.667023058477646 139.7416310454715 45.6 35.66699892348204 139.74161235045185 45.6 35.66699892348204 139.74161235045185 28.117 35.66729014859909 139.74183790464005 28.117 35.66729014859909 139.74183790464005 43.4 35.667278703430505 139.74182903685013 43.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3aa3ca2a-be05-4c6d-8cd6-5cd886023fd3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3aa3ca2a-be05-4c6d-8cd6-5cd886023fd3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3aa3ca2a-be05-4c6d-8cd6-5cd886023fd3">
											<gml:posList>35.667254873699115 139.74180871762613 50.2 35.667254873699115 139.74180871762613 49.003 35.66704941073801 139.74164959437186 49.003 35.66704941073801 139.74164959437186 50.2 35.667254873699115 139.74180871762613 50.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0bdd7802-bac1-4ba4-a64b-0854451bb3a5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0bdd7802-bac1-4ba4-a64b-0854451bb3a5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0bdd7802-bac1-4ba4-a64b-0854451bb3a5">
											<gml:posList>35.66726773812938 139.74172814569874 50.2 35.66726510080435 139.741733008877 50.2 35.66726510080435 139.741733008877 48.8 35.66726773812938 139.74172814569874 48.8 35.66726773812938 139.74172814569874 50.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f9bf396d-6e70-4bc0-bec6-36ebe6ac455c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f9bf396d-6e70-4bc0-bec6-36ebe6ac455c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f9bf396d-6e70-4bc0-bec6-36ebe6ac455c">
											<gml:posList>35.667265944733686 139.74172858958073 50.2 35.667265944733686 139.74172858958073 49.003 35.66726329839489 139.74173345276918 49.003 35.66726329839489 139.74173345276918 50.2 35.667265944733686 139.74172858958073 50.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7da91462-48e5-4eba-9aed-e55d6e8eda3f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7da91462-48e5-4eba-9aed-e55d6e8eda3f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7da91462-48e5-4eba-9aed-e55d6e8eda3f">
											<gml:posList>35.66726510080435 139.741733008877 50.2 35.667286485602055 139.7417504037276 50.2 35.667286485602055 139.7417504037276 48.8 35.66726510080435 139.741733008877 48.8 35.66726510080435 139.741733008877 50.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b787ff28-ba05-4941-8e61-37bbb95e41ac">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b787ff28-ba05-4941-8e61-37bbb95e41ac">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b787ff28-ba05-4941-8e61-37bbb95e41ac">
											<gml:posList>35.667295238451565 139.741739226392 45.02 35.667295238451565 139.741739226392 48.8 35.66725741849191 139.74181255867012 48.8 35.66725741849191 139.74181255867012 45.6 35.66725822853528 139.74181098923782 45.6 35.66725822853528 139.74181098923782 45.02 35.667295238451565 139.741739226392 45.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9085ab25-91df-499c-ada0-f1955d03221e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9085ab25-91df-499c-ada0-f1955d03221e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9085ab25-91df-499c-ada0-f1955d03221e">
											<gml:posList>35.66732898961853 139.74173229523564 45.6 35.66732898961853 139.74173229523564 45.02 35.66727825079678 139.74182647473356 45.02 35.66727825079678 139.74182647473356 45.6 35.66732898961853 139.74173229523564 45.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-cbda62e6-4fca-4f11-8172-6ef7377df8e1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cbda62e6-4fca-4f11-8172-6ef7377df8e1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cbda62e6-4fca-4f11-8172-6ef7377df8e1">
											<gml:posList>35.66728471024214 139.74175085863442 50.2 35.66728471024214 139.74175085863442 49.003 35.667254873699115 139.74180871762613 49.003 35.667254873699115 139.74180871762613 50.2 35.66728471024214 139.74175085863442 50.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f761c1aa-fcf6-46d4-a214-e6aa6e79b050">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f761c1aa-fcf6-46d4-a214-e6aa6e79b050">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f761c1aa-fcf6-46d4-a214-e6aa6e79b050">
											<gml:posList>35.66733109844428 139.741731784718 45.6 35.667278703430505 139.74182903685013 45.6 35.667278703430505 139.74182903685013 43.4 35.66733109844428 139.741731784718 43.4 35.66733109844428 139.741731784718 45.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-df894790-85df-462b-8833-234441d22fd3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-df894790-85df-462b-8833-234441d22fd3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-df894790-85df-462b-8833-234441d22fd3">
											<gml:posList>35.667286485602055 139.7417504037276 50.2 35.667255280979155 139.7418109042354 50.2 35.667255280979155 139.7418109042354 48.8 35.667286485602055 139.7417504037276 48.8 35.667286485602055 139.7417504037276 50.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9c5ded6c-dbe6-45de-84cc-47d73576aecd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9c5ded6c-dbe6-45de-84cc-47d73576aecd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9c5ded6c-dbe6-45de-84cc-47d73576aecd">
											<gml:posList>35.66729014859909 139.74183790464005 28.117 35.6673480212922 139.74172528147693 28.117 35.6673480212922 139.74172528147693 43.4 35.66729014859909 139.74183790464005 43.4 35.66729014859909 139.74183790464005 28.117</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-67f639c8-5042-44f2-a652-491537495f33">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-67f639c8-5042-44f2-a652-491537495f33">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-67f639c8-5042-44f2-a652-491537495f33">
											<gml:posList>35.66725950923179 139.7418119708549 45.6 35.66725950923179 139.7418119708549 45.02 35.66725822853528 139.74181098923782 45.02 35.66725822853528 139.74181098923782 45.6 35.66725950923179 139.7418119708549 45.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e77690c2-f575-4fff-b0d6-0835d26ff13f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e77690c2-f575-4fff-b0d6-0835d26ff13f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e77690c2-f575-4fff-b0d6-0835d26ff13f">
											<gml:posList>35.66727825079678 139.74182647473356 45.6 35.66727825079678 139.74182647473356 45.02 35.66725950923179 139.7418119708549 45.02 35.66725950923179 139.7418119708549 45.6 35.66727825079678 139.74182647473356 45.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂一丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-867</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">460.5286</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">6</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">211</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1320</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.6</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>4</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.27</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>