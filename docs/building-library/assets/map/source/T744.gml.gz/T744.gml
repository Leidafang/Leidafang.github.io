<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_d4642d96-7177-4488-9f3f-bca67acb880f">
			<core:creationDate>2024-03-15</core:creationDate>
			<bldg:measuredHeight uom="m">3.1</bldg:measuredHeight>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.67077738638025 139.74032644579708 0 35.67075883806869 139.74024730944475 0 35.670715791190624 139.74026245972263 0 35.670734330478616 139.74034159604645 0 35.67077738638025 139.74032644579708 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67077738638025 139.74032644579708 13.918 35.670734330478616 139.74034159604645 13.918 35.670715791190624 139.74026245972263 13.918 35.67075883806869 139.74024730944475 13.918 35.67077738638025 139.74032644579708 13.918</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67077738638025 139.74032644579708 13.918 35.67075883806869 139.74024730944475 13.918 35.67075883806869 139.74024730944475 17.01 35.67077738638025 139.74032644579708 17.01 35.67077738638025 139.74032644579708 13.918</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67075883806869 139.74024730944475 13.918 35.670715791190624 139.74026245972263 13.918 35.670715791190624 139.74026245972263 17.01 35.67075883806869 139.74024730944475 17.01 35.67075883806869 139.74024730944475 13.918</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670715791190624 139.74026245972263 13.918 35.670734330478616 139.74034159604645 13.918 35.670734330478616 139.74034159604645 17.01 35.670715791190624 139.74026245972263 17.01 35.670715791190624 139.74026245972263 13.918</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670734330478616 139.74034159604645 13.918 35.67077738638025 139.74032644579708 13.918 35.67077738638025 139.74032644579708 17.01 35.670734330478616 139.74034159604645 17.01 35.670734330478616 139.74034159604645 13.918</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67077738638025 139.74032644579708 17.01 35.67075883806869 139.74024730944475 17.01 35.670715791190624 139.74026245972263 17.01 35.670734330478616 139.74034159604645 17.01 35.67077738638025 139.74032644579708 17.01</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-0f6fd71a-cfb6-488d-841b-259b9a8b4df3"/>
							<gml:surfaceMember xlink:href="#poly-07a4a5af-9577-4951-bfef-fba3aad4b11e"/>
							<gml:surfaceMember xlink:href="#poly-ab8b3852-5cb6-45f0-856b-821072ab008a"/>
							<gml:surfaceMember xlink:href="#poly-b181e8c6-e723-43b6-99e6-f29d42f1b9dd"/>
							<gml:surfaceMember xlink:href="#poly-2832f2ce-618d-4495-a5d8-123b38a1be35"/>
							<gml:surfaceMember xlink:href="#poly-c6750127-fcf8-41f2-b3ed-62224de4f5f7"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-0f6fd71a-cfb6-488d-841b-259b9a8b4df3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0f6fd71a-cfb6-488d-841b-259b9a8b4df3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0f6fd71a-cfb6-488d-841b-259b9a8b4df3">
											<gml:posList>35.67077738638025 139.74032644579705 13.918 35.670734330478595 139.74034159604645 13.918 35.670715791190624 139.74026245972263 13.918 35.67075883806867 139.74024730944473 13.918 35.67077738638025 139.74032644579705 13.918</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-07a4a5af-9577-4951-bfef-fba3aad4b11e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-07a4a5af-9577-4951-bfef-fba3aad4b11e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-07a4a5af-9577-4951-bfef-fba3aad4b11e">
											<gml:posList>35.670734330478595 139.74034159604645 18.126 35.67077738638025 139.74032644579705 18.126 35.67075883806867 139.74024730944473 18.126 35.670715791190624 139.74026245972263 18.126 35.670734330478595 139.74034159604645 18.126</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ab8b3852-5cb6-45f0-856b-821072ab008a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ab8b3852-5cb6-45f0-856b-821072ab008a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ab8b3852-5cb6-45f0-856b-821072ab008a">
											<gml:posList>35.67075883806867 139.74024730944473 13.918 35.670715791190624 139.74026245972263 13.918 35.670715791190624 139.74026245972263 18.126 35.67075883806867 139.74024730944473 18.126 35.67075883806867 139.74024730944473 13.918</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b181e8c6-e723-43b6-99e6-f29d42f1b9dd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b181e8c6-e723-43b6-99e6-f29d42f1b9dd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b181e8c6-e723-43b6-99e6-f29d42f1b9dd">
											<gml:posList>35.67077738638025 139.74032644579705 13.918 35.67075883806867 139.74024730944473 13.918 35.67075883806867 139.74024730944473 18.126 35.67077738638025 139.74032644579705 18.126 35.67077738638025 139.74032644579705 13.918</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2832f2ce-618d-4495-a5d8-123b38a1be35">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2832f2ce-618d-4495-a5d8-123b38a1be35">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2832f2ce-618d-4495-a5d8-123b38a1be35">
											<gml:posList>35.670715791190624 139.74026245972263 13.918 35.670734330478595 139.74034159604645 13.918 35.670734330478595 139.74034159604645 18.126 35.670715791190624 139.74026245972263 18.126 35.670715791190624 139.74026245972263 13.918</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c6750127-fcf8-41f2-b3ed-62224de4f5f7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c6750127-fcf8-41f2-b3ed-62224de4f5f7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c6750127-fcf8-41f2-b3ed-62224de4f5f7">
											<gml:posList>35.670734330478595 139.74034159604645 13.918 35.67077738638025 139.74032644579705 13.918 35.67077738638025 139.74032644579705 18.126 35.670734330478595 139.74034159604645 18.126 35.670734330478595 139.74034159604645 13.918</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-130</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">211</uro:landUseType>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>4</uro:specifiedFloorAreaRate>
					<uro:surveyYear>0001</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>