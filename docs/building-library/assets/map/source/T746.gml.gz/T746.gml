<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_d4cb363b-75ae-4c18-935a-eba421c3de66">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001001</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">413</bldg:usage>
			<bldg:measuredHeight uom="m">13.5</bldg:measuredHeight>
			<bldg:storeysAboveGround>4</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.6701743664656 139.74461296153797 0 35.67020303627992 139.74449904312624 0 35.67011666075889 139.74446655246746 0 35.67008808111201 139.74458047066818 0 35.6701743664656 139.74461296153797 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6701743664656 139.74461296153797 8.43 35.67008808111201 139.74458047066818 8.43 35.67011666075889 139.74446655246746 8.43 35.67020303627992 139.74449904312624 8.43 35.6701743664656 139.74461296153797 8.43</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6701743664656 139.74461296153797 8.43 35.67020303627992 139.74449904312624 8.43 35.67020303627992 139.74449904312624 21.89 35.6701743664656 139.74461296153797 21.89 35.6701743664656 139.74461296153797 8.43</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67020303627992 139.74449904312624 8.43 35.67011666075889 139.74446655246746 8.43 35.67011666075889 139.74446655246746 21.89 35.67020303627992 139.74449904312624 21.89 35.67020303627992 139.74449904312624 8.43</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67011666075889 139.74446655246746 8.43 35.67008808111201 139.74458047066818 8.43 35.67008808111201 139.74458047066818 21.89 35.67011666075889 139.74446655246746 21.89 35.67011666075889 139.74446655246746 8.43</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67008808111201 139.74458047066818 8.43 35.6701743664656 139.74461296153797 8.43 35.6701743664656 139.74461296153797 21.89 35.67008808111201 139.74458047066818 21.89 35.67008808111201 139.74458047066818 8.43</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6701743664656 139.74461296153797 21.89 35.67020303627992 139.74449904312624 21.89 35.67011666075889 139.74446655246746 21.89 35.67008808111201 139.74458047066818 21.89 35.6701743664656 139.74461296153797 21.89</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-6c64089e-0127-43c3-b09b-fe6811f42cca"/>
							<gml:surfaceMember xlink:href="#poly-125e5441-c135-42b4-8842-ac7cde6dab8e"/>
							<gml:surfaceMember xlink:href="#poly-afea44f9-7a11-4497-b928-2d2474d9d694"/>
							<gml:surfaceMember xlink:href="#poly-6277f697-7ca5-4d65-b413-6cc9f3cae63e"/>
							<gml:surfaceMember xlink:href="#poly-f1380366-6830-472b-9884-a13dcd9b64eb"/>
							<gml:surfaceMember xlink:href="#poly-b95483e3-3d02-4a2b-8c46-6f54bca036c1"/>
							<gml:surfaceMember xlink:href="#poly-2eb263e8-b681-47f9-bbd6-0422868f74ee"/>
							<gml:surfaceMember xlink:href="#poly-9550f486-276f-4fd2-8820-5384fc9dec75"/>
							<gml:surfaceMember xlink:href="#poly-2d658980-63ad-4332-8d34-414826e8291b"/>
							<gml:surfaceMember xlink:href="#poly-39c32d80-a4a4-405e-8009-6dd26baf6ed2"/>
							<gml:surfaceMember xlink:href="#poly-fee0526e-099f-40a2-b62d-e803243ff585"/>
							<gml:surfaceMember xlink:href="#poly-e90a0686-fc76-44b5-ac73-19e054443260"/>
							<gml:surfaceMember xlink:href="#poly-b56f0ef4-3c52-4219-8dc8-e6a0f14f598d"/>
							<gml:surfaceMember xlink:href="#poly-4219e167-930c-40be-8521-752e5da10339"/>
							<gml:surfaceMember xlink:href="#poly-7e94989f-9f7c-468c-904b-343e00dc4ed2"/>
							<gml:surfaceMember xlink:href="#poly-bb245dd1-9128-49c9-bb03-51752f1770fc"/>
							<gml:surfaceMember xlink:href="#poly-af3beec1-8a1d-40ab-a7c7-2315c6c73765"/>
							<gml:surfaceMember xlink:href="#poly-370b0f46-7e97-4536-b960-c95c1d826668"/>
							<gml:surfaceMember xlink:href="#poly-0bf1329d-eda0-43a1-8914-f50f64499a2e"/>
							<gml:surfaceMember xlink:href="#poly-b99a336c-31f2-4033-9716-2a3c136d2b69"/>
							<gml:surfaceMember xlink:href="#poly-eb0318c5-5267-469a-9a9c-4f0d1d31dd1f"/>
							<gml:surfaceMember xlink:href="#poly-e78260b4-b3a1-44a1-b757-ecf55c70af0a"/>
							<gml:surfaceMember xlink:href="#poly-c5893b20-7c0e-4b9f-beb4-60e40f5c8b57"/>
							<gml:surfaceMember xlink:href="#poly-16dae379-43a5-4dad-b8dd-2dec75939cd9"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_d4cb363b-75ae-4c18-935a-eba421c3de66_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0fe28df4-4621-49c7-b5db-74d454e78b32">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67013515164216 139.7444838082704 25.062 35.67013531434562 139.74448442667875 25.062 35.670135431996776 139.7444850672295 25.062 35.67013550458744 139.7444857188764 25.062 35.67013552309578 139.74448637058325 25.062 35.6701355055492 139.74448702233 25.062 35.67013543392028 139.74448767413674 25.062 35.6701353262283 139.74448831493717 25.062 35.67013516443768 139.74448893370513 25.062 35.67013495757029 139.74448954147678 25.062 35.67013471463169 139.74449012719595 25.062 35.67013442660003 139.7444906798264 25.062 35.670134102480866 139.74449118831194 25.062 35.670133742290496 139.74449167474498 25.062 35.670133355026366 139.74449211702316 25.062 35.67013293167472 139.74449251515637 25.062 35.67013248124931 139.74449286913466 25.062 35.67013200375013 139.74449317895807 25.062 35.670131508174606 139.74449342252416 25.062 35.670131003552754 139.74449362191535 25.062 35.6701304808627 139.74449376609545 25.062 35.67012994911818 139.74449385505443 25.062 35.67012941732475 139.74449387773612 25.062 35.670128885498734 139.74449385623294 25.062 35.67012835362382 139.7444937684525 25.062 35.67012783973559 139.74449362542094 25.062 35.67012732581478 139.74449343820456 25.062 35.67012682987251 139.7444931846909 25.062 35.670126360938816 139.7444928869624 25.062 35.67012590999181 139.7444925339829 25.062 35.67012548605339 139.74449213678855 25.062 35.67012508912353 139.7444916953794 25.062 35.670124728224124 139.74449122079162 25.062 35.670124403346996 139.74449070197903 25.062 35.670124114500325 139.74449014998785 25.062 35.67012387069782 139.7444895648081 25.062 35.67012366294205 139.7444889685422 25.062 35.67012350023046 139.7444883390877 25.062 35.670123382579334 139.74448769853706 25.062 35.67012330998867 139.74448704689024 25.062 35.67012329148035 139.74448639518351 25.062 35.67012330902691 139.74448574343683 25.062 35.67012338065584 139.74448509163022 25.062 35.67012349736966 139.74448446186608 25.062 35.6701236591521 139.744483832052 25.062 35.6701238570139 139.74448323533662 25.062 35.67012409995246 139.7444826496175 25.062 35.670124387984096 139.7444820969871 25.062 35.67012471209507 139.74448157745536 25.062 35.67012507228539 139.74448109102232 25.062 35.67012546856321 139.7444806487342 25.062 35.67012589191481 139.74448025060096 25.062 35.67012634234018 139.7444798966226 25.062 35.67012681083375 139.74447959785533 25.062 35.6701273064011 139.74447934324297 25.062 35.67012781102294 139.7444791438517 25.062 35.67012833371297 139.74447899967151 25.062 35.67012886545747 139.74447891071242 25.062 35.670129397250896 139.74447888803064 25.062 35.67012992907692 139.7444789095337 25.062 35.670130460951846 139.7444789973141 25.062 35.67013098385381 139.74447914033556 25.062 35.670131488760916 139.74447932756183 25.062 35.670131984703225 139.7444795810754 25.062 35.6701324536451 139.74447988985006 25.062 35.670132904583994 139.7444802317833 25.062 35.670133337536186 139.74448062896766 25.062 35.67013372545236 139.74448107038683 25.062 35.67013408635996 139.7444815560208 25.062 35.67013441123711 139.74448207483337 25.062 35.67013470008383 139.7444826268246 25.062 35.670134952891935 139.7444832009482 25.062 35.67013515164216 139.7444838082704 25.062</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-33ed9270-5526-4f99-8cd2-c937d008433d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-33ed9270-5526-4f99-8cd2-c937d008433d_0">
											<gml:posList>35.67012330998867 139.74448704689024 25.062 35.67012330998867 139.74448704689024 27.284 35.67012329148035 139.74448639518351 27.284 35.67012329148035 139.74448639518351 25.062 35.67012330998867 139.74448704689024 25.062</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2566abad-d49e-4dbd-a17b-6e3e165ce681">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2566abad-d49e-4dbd-a17b-6e3e165ce681_0">
											<gml:posList>35.67012329148035 139.74448639518351 27.284 35.67012330902691 139.74448574343683 27.284 35.67012330902691 139.74448574343683 25.062 35.67012329148035 139.74448639518351 25.062 35.67012329148035 139.74448639518351 27.284</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-18fe322f-04d6-4fee-bceb-9c47d2adf967">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-18fe322f-04d6-4fee-bceb-9c47d2adf967_0">
											<gml:posList>35.67012330902691 139.74448574343683 25.062 35.67012330902691 139.74448574343683 27.284 35.67012338065584 139.74448509163022 27.284 35.67012338065584 139.74448509163022 25.062 35.67012330902691 139.74448574343683 25.062</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cf671609-ae04-4fc0-947b-729bf6690014">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cf671609-ae04-4fc0-947b-729bf6690014_0">
											<gml:posList>35.670123382579334 139.74448769853706 25.062 35.670123382579334 139.74448769853706 27.284 35.67012330998867 139.74448704689024 27.284 35.67012330998867 139.74448704689024 25.062 35.670123382579334 139.74448769853706 25.062</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7f87321e-30a8-43c5-97ba-2e6262b0451c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7f87321e-30a8-43c5-97ba-2e6262b0451c_0">
											<gml:posList>35.67012338065584 139.74448509163022 25.062 35.67012338065584 139.74448509163022 27.284 35.67012349736966 139.74448446186608 27.284 35.67012349736966 139.74448446186608 25.062 35.67012338065584 139.74448509163022 25.062</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c3f959aa-24ca-4102-b541-efef0cb07381">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c3f959aa-24ca-4102-b541-efef0cb07381_0">
											<gml:posList>35.67012350023046 139.7444883390877 25.062 35.67012350023046 139.7444883390877 27.284 35.670123382579334 139.74448769853706 27.284 35.670123382579334 139.74448769853706 25.062 35.67012350023046 139.7444883390877 25.062</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4b97acaa-c942-4c7e-98b0-b649d215a3b6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4b97acaa-c942-4c7e-98b0-b649d215a3b6_0">
											<gml:posList>35.67012366294205 139.7444889685422 25.062 35.67012366294205 139.7444889685422 27.284 35.67012350023046 139.7444883390877 27.284 35.67012350023046 139.7444883390877 25.062 35.67012366294205 139.7444889685422 25.062</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-97b90dfe-ba09-4fef-af98-2c5c8f43b26e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-97b90dfe-ba09-4fef-af98-2c5c8f43b26e_0">
											<gml:posList>35.67012349736966 139.74448446186608 27.284 35.6701236591521 139.744483832052 27.284 35.6701236591521 139.744483832052 25.062 35.67012349736966 139.74448446186608 25.062 35.67012349736966 139.74448446186608 27.284</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c393b767-d35e-44c6-9af8-f12734f6844e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c393b767-d35e-44c6-9af8-f12734f6844e_0">
											<gml:posList>35.6701236591521 139.744483832052 25.062 35.6701236591521 139.744483832052 27.284 35.6701238570139 139.74448323533662 27.284 35.6701238570139 139.74448323533662 25.062 35.6701236591521 139.744483832052 25.062</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c9e192a9-cae8-49a6-a04b-72e73ddabe47">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c9e192a9-cae8-49a6-a04b-72e73ddabe47_0">
											<gml:posList>35.67012387069782 139.7444895648081 25.062 35.67012387069782 139.7444895648081 27.284 35.67012366294205 139.7444889685422 27.284 35.67012366294205 139.7444889685422 25.062 35.67012387069782 139.7444895648081 25.062</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4fd76d1e-4091-40b0-a2ae-916a824ae278">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4fd76d1e-4091-40b0-a2ae-916a824ae278_0">
											<gml:posList>35.6701238570139 139.74448323533662 27.284 35.67012409995246 139.7444826496175 27.284 35.67012409995246 139.7444826496175 25.062 35.6701238570139 139.74448323533662 25.062 35.6701238570139 139.74448323533662 27.284</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a987a0c8-97c7-44d1-ad5e-e64d37824cff">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a987a0c8-97c7-44d1-ad5e-e64d37824cff_0">
											<gml:posList>35.670124114500325 139.74449014998785 25.062 35.670124114500325 139.74449014998785 27.284 35.67012387069782 139.7444895648081 27.284 35.67012387069782 139.7444895648081 25.062 35.670124114500325 139.74449014998785 25.062</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-64c48b9a-7ba0-44a0-9ca0-10126c50b6ed">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-64c48b9a-7ba0-44a0-9ca0-10126c50b6ed_0">
											<gml:posList>35.67012409995246 139.7444826496175 27.284 35.670124387984096 139.7444820969871 27.284 35.670124387984096 139.7444820969871 25.062 35.67012409995246 139.7444826496175 25.062 35.67012409995246 139.7444826496175 27.284</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-41a15413-eee7-48a4-8479-4abda6d97865">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-41a15413-eee7-48a4-8479-4abda6d97865_0">
											<gml:posList>35.670124403346996 139.74449070197903 25.062 35.670124403346996 139.74449070197903 27.284 35.670124114500325 139.74449014998785 27.284 35.670124114500325 139.74449014998785 25.062 35.670124403346996 139.74449070197903 25.062</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-78b30e0f-685c-401a-b4a3-fbbed31cb36d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-78b30e0f-685c-401a-b4a3-fbbed31cb36d_0">
											<gml:posList>35.670124387984096 139.7444820969871 25.062 35.670124387984096 139.7444820969871 27.284 35.67012471209507 139.74448157745536 27.284 35.67012471209507 139.74448157745536 25.062 35.670124387984096 139.7444820969871 25.062</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-dfe4cf0d-dc12-4c1e-8bf8-a51c3e8ed8ee">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-dfe4cf0d-dc12-4c1e-8bf8-a51c3e8ed8ee_0">
											<gml:posList>35.670124728224124 139.74449122079162 25.062 35.670124728224124 139.74449122079162 27.284 35.670124403346996 139.74449070197903 27.284 35.670124403346996 139.74449070197903 25.062 35.670124728224124 139.74449122079162 25.062</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e2a63135-cb18-4d5b-a1c5-58e2e33f6389">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e2a63135-cb18-4d5b-a1c5-58e2e33f6389_0">
											<gml:posList>35.67012471209507 139.74448157745536 25.062 35.67012471209507 139.74448157745536 27.284 35.67012507228539 139.74448109102232 27.284 35.67012507228539 139.74448109102232 25.062 35.67012471209507 139.74448157745536 25.062</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-82299b20-a0e9-4afc-b426-ddac236e3605">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-82299b20-a0e9-4afc-b426-ddac236e3605_0">
											<gml:posList>35.67012508912353 139.7444916953794 27.284 35.670124728224124 139.74449122079162 27.284 35.670124728224124 139.74449122079162 25.062 35.67012508912353 139.7444916953794 25.062 35.67012508912353 139.7444916953794 27.284</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e90e595e-d81c-4e3d-bcf8-97f38bdd4d01">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e90e595e-d81c-4e3d-bcf8-97f38bdd4d01_0">
											<gml:posList>35.67012507228539 139.74448109102232 25.062 35.67012507228539 139.74448109102232 27.284 35.67012546856321 139.7444806487342 27.284 35.67012546856321 139.7444806487342 25.062 35.67012507228539 139.74448109102232 25.062</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bee94870-1e0f-45da-8b97-e413f9d89e2d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bee94870-1e0f-45da-8b97-e413f9d89e2d_0">
											<gml:posList>35.67012548605339 139.74449213678855 25.062 35.67012548605339 139.74449213678855 27.284 35.67012508912353 139.7444916953794 27.284 35.67012508912353 139.7444916953794 25.062 35.67012548605339 139.74449213678855 25.062</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9f246f65-f687-4320-9e82-a0325db9ce20">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9f246f65-f687-4320-9e82-a0325db9ce20_0">
											<gml:posList>35.67012546856321 139.7444806487342 25.062 35.67012546856321 139.7444806487342 27.284 35.67012589191481 139.74448025060096 27.284 35.67012589191481 139.74448025060096 25.062 35.67012546856321 139.7444806487342 25.062</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-728c7423-2835-4e9f-89a8-fe5c1dcd9562">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-728c7423-2835-4e9f-89a8-fe5c1dcd9562_0">
											<gml:posList>35.67012590999181 139.7444925339829 27.284 35.67012548605339 139.74449213678855 27.284 35.67012548605339 139.74449213678855 25.062 35.67012590999181 139.7444925339829 25.062 35.67012590999181 139.7444925339829 27.284</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-45cadb48-4985-4db7-bd49-8ca11b586845">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-45cadb48-4985-4db7-bd49-8ca11b586845_0">
											<gml:posList>35.67012589191481 139.74448025060096 25.062 35.67012589191481 139.74448025060096 27.284 35.67012634234018 139.7444798966226 27.284 35.67012634234018 139.7444798966226 25.062 35.67012589191481 139.74448025060096 25.062</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2fbb2c7b-fc0f-4b32-bcd4-4c9f82d68456">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2fbb2c7b-fc0f-4b32-bcd4-4c9f82d68456_0">
											<gml:posList>35.670126360938816 139.7444928869624 25.062 35.670126360938816 139.7444928869624 27.284 35.67012590999181 139.7444925339829 27.284 35.67012590999181 139.7444925339829 25.062 35.670126360938816 139.7444928869624 25.062</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f0411def-eff9-407b-928f-93a8b63774d3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f0411def-eff9-407b-928f-93a8b63774d3_0">
											<gml:posList>35.67012634234018 139.7444798966226 25.062 35.67012634234018 139.7444798966226 27.284 35.67012681083375 139.74447959785533 27.284 35.67012681083375 139.74447959785533 25.062 35.67012634234018 139.7444798966226 25.062</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c036c1ba-2d7d-4792-8b05-db5473a736a2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c036c1ba-2d7d-4792-8b05-db5473a736a2_0">
											<gml:posList>35.67012682987251 139.7444931846909 25.062 35.67012682987251 139.7444931846909 27.284 35.670126360938816 139.7444928869624 27.284 35.670126360938816 139.7444928869624 25.062 35.67012682987251 139.7444931846909 25.062</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3fa0b51f-ed4f-425b-abf2-f74a16ccb23f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3fa0b51f-ed4f-425b-abf2-f74a16ccb23f_0">
											<gml:posList>35.67012681083375 139.74447959785533 27.284 35.6701273064011 139.74447934324297 27.284 35.6701273064011 139.74447934324297 25.062 35.67012681083375 139.74447959785533 25.062 35.67012681083375 139.74447959785533 27.284</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c8e41033-1865-46fb-96af-361e343f1dc2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c8e41033-1865-46fb-96af-361e343f1dc2_0">
											<gml:posList>35.67012732581478 139.74449343820456 27.284 35.67012682987251 139.7444931846909 27.284 35.67012682987251 139.7444931846909 25.062 35.67012732581478 139.74449343820456 25.062 35.67012732581478 139.74449343820456 27.284</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-38df334e-912c-42f1-9015-f6156bc6f384">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-38df334e-912c-42f1-9015-f6156bc6f384_0">
											<gml:posList>35.6701273064011 139.74447934324297 25.062 35.6701273064011 139.74447934324297 27.284 35.67012781102294 139.7444791438517 27.284 35.67012781102294 139.7444791438517 25.062 35.6701273064011 139.74447934324297 25.062</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b61d9439-f537-46cb-b34e-1026c2d19a90">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b61d9439-f537-46cb-b34e-1026c2d19a90_0">
											<gml:posList>35.67012783973559 139.74449362542094 25.062 35.67012783973559 139.74449362542094 27.284 35.67012732581478 139.74449343820456 27.284 35.67012732581478 139.74449343820456 25.062 35.67012783973559 139.74449362542094 25.062</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f7d0ac96-ddfb-45aa-88df-01e117ca8eea">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f7d0ac96-ddfb-45aa-88df-01e117ca8eea_0">
											<gml:posList>35.67012781102294 139.7444791438517 27.284 35.67012833371297 139.74447899967151 27.284 35.67012833371297 139.74447899967151 25.062 35.67012781102294 139.7444791438517 25.062 35.67012781102294 139.7444791438517 27.284</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-260a7501-7da6-4166-883c-b65fe56b1b72">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-260a7501-7da6-4166-883c-b65fe56b1b72_0">
											<gml:posList>35.67012835362382 139.7444937684525 25.062 35.67012835362382 139.7444937684525 27.284 35.67012783973559 139.74449362542094 27.284 35.67012783973559 139.74449362542094 25.062 35.67012835362382 139.7444937684525 25.062</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-75fa95ad-5521-4575-8544-d4e9700859e3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-75fa95ad-5521-4575-8544-d4e9700859e3_0">
											<gml:posList>35.67012833371297 139.74447899967151 25.062 35.67012833371297 139.74447899967151 27.284 35.67012886545747 139.74447891071242 27.284 35.67012886545747 139.74447891071242 25.062 35.67012833371297 139.74447899967151 25.062</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-409d8974-7e90-4e7b-ac43-5ff127ed66ca">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-409d8974-7e90-4e7b-ac43-5ff127ed66ca_0">
											<gml:posList>35.670128885498734 139.74449385623294 27.284 35.67012835362382 139.7444937684525 27.284 35.67012835362382 139.7444937684525 25.062 35.670128885498734 139.74449385623294 25.062 35.670128885498734 139.74449385623294 27.284</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a029b584-42d2-4f50-8103-9d6efe5b6b13">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a029b584-42d2-4f50-8103-9d6efe5b6b13_0">
											<gml:posList>35.67012886545747 139.74447891071242 27.284 35.670129397250896 139.74447888803064 27.284 35.670129397250896 139.74447888803064 25.062 35.67012886545747 139.74447891071242 25.062 35.67012886545747 139.74447891071242 27.284</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c008eea3-395a-4374-847b-116754b84365">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c008eea3-395a-4374-847b-116754b84365_0">
											<gml:posList>35.67012941732475 139.74449387773612 27.284 35.670128885498734 139.74449385623294 27.284 35.670128885498734 139.74449385623294 25.062 35.67012941732475 139.74449387773612 25.062 35.67012941732475 139.74449387773612 27.284</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6967ec08-b666-4a19-b3ee-82b198aae62c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6967ec08-b666-4a19-b3ee-82b198aae62c_0">
											<gml:posList>35.67013470008383 139.7444826268246 27.284 35.67013441123711 139.74448207483337 27.284 35.67013408635996 139.7444815560208 27.284 35.67013372545236 139.74448107038683 27.284 35.670133337536186 139.74448062896766 27.284 35.670132904583994 139.7444802317833 27.284 35.6701324536451 139.74447988985006 27.284 35.670131984703225 139.7444795810754 27.284 35.670131488760916 139.74447932756183 27.284 35.67013098385381 139.74447914033556 27.284 35.670130460951846 139.7444789973141 27.284 35.67012992907692 139.7444789095337 27.284 35.670129397250896 139.74447888803064 27.284 35.67012886545747 139.74447891071242 27.284 35.67012833371297 139.74447899967151 27.284 35.67012781102294 139.7444791438517 27.284 35.6701273064011 139.74447934324297 27.284 35.67012681083375 139.74447959785533 27.284 35.67012634234018 139.7444798966226 27.284 35.67012589191481 139.74448025060096 27.284 35.67012546856321 139.7444806487342 27.284 35.67012507228539 139.74448109102232 27.284 35.67012471209507 139.74448157745536 27.284 35.670124387984096 139.7444820969871 27.284 35.67012409995246 139.7444826496175 27.284 35.6701238570139 139.74448323533662 27.284 35.6701236591521 139.744483832052 27.284 35.67012349736966 139.74448446186608 27.284 35.67012338065584 139.74448509163022 27.284 35.67012330902691 139.74448574343683 27.284 35.67012329148035 139.74448639518351 27.284 35.67012330998867 139.74448704689024 27.284 35.670123382579334 139.74448769853706 27.284 35.67012350023046 139.7444883390877 27.284 35.67012366294205 139.7444889685422 27.284 35.67012387069782 139.7444895648081 27.284 35.670124114500325 139.74449014998785 27.284 35.670124403346996 139.74449070197903 27.284 35.670124728224124 139.74449122079162 27.284 35.67012508912353 139.7444916953794 27.284 35.67012548605339 139.74449213678855 27.284 35.67012590999181 139.7444925339829 27.284 35.670126360938816 139.7444928869624 27.284 35.67012682987251 139.7444931846909 27.284 35.67012732581478 139.74449343820456 27.284 35.67012783973559 139.74449362542094 27.284 35.67012835362382 139.7444937684525 27.284 35.670128885498734 139.74449385623294 27.284 35.67012941732475 139.74449387773612 27.284 35.67012994911818 139.74449385505443 27.284 35.6701304808627 139.74449376609545 27.284 35.670131003552754 139.74449362191535 27.284 35.670131508174606 139.74449342252416 27.284 35.67013200375013 139.74449317895807 27.284 35.67013248124931 139.74449286913466 27.284 35.67013293167472 139.74449251515637 27.284 35.670133355026366 139.74449211702316 27.284 35.670133742290496 139.74449167474498 27.284 35.670134102480866 139.74449118831194 27.284 35.67013442660003 139.7444906798264 27.284 35.67013471463169 139.74449012719595 27.284 35.67013495757029 139.74448954147678 27.284 35.67013516443768 139.74448893370513 27.284 35.6701353262283 139.74448831493717 27.284 35.67013543392028 139.74448767413674 27.284 35.6701355055492 139.74448702233 27.284 35.67013552309578 139.74448637058325 27.284 35.67013550458744 139.7444857188764 27.284 35.670135431996776 139.7444850672295 27.284 35.67013531434562 139.74448442667875 27.284 35.67013515164216 139.7444838082704 27.284 35.670134952891935 139.7444832009482 27.284 35.67013470008383 139.7444826268246 27.284</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-798ca06b-9109-4512-a76b-1371541552d4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-798ca06b-9109-4512-a76b-1371541552d4_0">
											<gml:posList>35.670129397250896 139.74447888803064 25.062 35.670129397250896 139.74447888803064 27.284 35.67012992907692 139.7444789095337 27.284 35.67012992907692 139.7444789095337 25.062 35.670129397250896 139.74447888803064 25.062</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e3701e38-7962-405a-a17d-813f306a288f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e3701e38-7962-405a-a17d-813f306a288f_0">
											<gml:posList>35.67012994911818 139.74449385505443 25.062 35.67012994911818 139.74449385505443 27.284 35.67012941732475 139.74449387773612 27.284 35.67012941732475 139.74449387773612 25.062 35.67012994911818 139.74449385505443 25.062</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6b87dbe3-a788-400d-9eff-8b8d9bc21e37">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6b87dbe3-a788-400d-9eff-8b8d9bc21e37_0">
											<gml:posList>35.67012992907692 139.7444789095337 27.284 35.670130460951846 139.7444789973141 27.284 35.670130460951846 139.7444789973141 25.062 35.67012992907692 139.7444789095337 25.062 35.67012992907692 139.7444789095337 27.284</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ffc50552-0fd2-4d42-85de-51797c776471">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ffc50552-0fd2-4d42-85de-51797c776471_0">
											<gml:posList>35.6701304808627 139.74449376609545 25.062 35.6701304808627 139.74449376609545 27.284 35.67012994911818 139.74449385505443 27.284 35.67012994911818 139.74449385505443 25.062 35.6701304808627 139.74449376609545 25.062</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-70f4ecc4-201d-4a27-a240-076aa40093aa">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-70f4ecc4-201d-4a27-a240-076aa40093aa_0">
											<gml:posList>35.670130460951846 139.7444789973141 27.284 35.67013098385381 139.74447914033556 27.284 35.67013098385381 139.74447914033556 25.062 35.670130460951846 139.7444789973141 25.062 35.670130460951846 139.7444789973141 27.284</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ad231e1f-7806-4e35-ba64-9f84746c4f5b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ad231e1f-7806-4e35-ba64-9f84746c4f5b_0">
											<gml:posList>35.670131003552754 139.74449362191535 25.062 35.670131003552754 139.74449362191535 27.284 35.6701304808627 139.74449376609545 27.284 35.6701304808627 139.74449376609545 25.062 35.670131003552754 139.74449362191535 25.062</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f1bb33a7-8594-486c-ba13-c8ef0a473f42">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f1bb33a7-8594-486c-ba13-c8ef0a473f42_0">
											<gml:posList>35.67013098385381 139.74447914033556 25.062 35.67013098385381 139.74447914033556 27.284 35.670131488760916 139.74447932756183 27.284 35.670131488760916 139.74447932756183 25.062 35.67013098385381 139.74447914033556 25.062</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c0c7c91c-4982-4246-bd16-b4dd0ba575e1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c0c7c91c-4982-4246-bd16-b4dd0ba575e1_0">
											<gml:posList>35.670131508174606 139.74449342252416 27.284 35.670131003552754 139.74449362191535 27.284 35.670131003552754 139.74449362191535 25.062 35.670131508174606 139.74449342252416 25.062 35.670131508174606 139.74449342252416 27.284</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d106e424-de2b-46d7-bf1c-c31fbdfbd5be">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d106e424-de2b-46d7-bf1c-c31fbdfbd5be_0">
											<gml:posList>35.670131488760916 139.74447932756183 27.284 35.670131984703225 139.7444795810754 27.284 35.670131984703225 139.7444795810754 25.062 35.670131488760916 139.74447932756183 25.062 35.670131488760916 139.74447932756183 27.284</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ccb448c3-9c9b-4df0-9dd3-aebaeee63b93">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ccb448c3-9c9b-4df0-9dd3-aebaeee63b93_0">
											<gml:posList>35.67013200375013 139.74449317895807 27.284 35.670131508174606 139.74449342252416 27.284 35.670131508174606 139.74449342252416 25.062 35.67013200375013 139.74449317895807 25.062 35.67013200375013 139.74449317895807 27.284</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a2c43b3b-1197-460e-9477-88d3e0715615">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a2c43b3b-1197-460e-9477-88d3e0715615_0">
											<gml:posList>35.670131984703225 139.7444795810754 27.284 35.6701324536451 139.74447988985006 27.284 35.6701324536451 139.74447988985006 25.062 35.670131984703225 139.7444795810754 25.062 35.670131984703225 139.7444795810754 27.284</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ff39ac97-4300-483c-8a30-18093eb122b8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ff39ac97-4300-483c-8a30-18093eb122b8_0">
											<gml:posList>35.67013248124931 139.74449286913466 27.284 35.67013200375013 139.74449317895807 27.284 35.67013200375013 139.74449317895807 25.062 35.67013248124931 139.74449286913466 25.062 35.67013248124931 139.74449286913466 27.284</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-80d2c889-bb3b-49a9-a64f-def772ed867e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-80d2c889-bb3b-49a9-a64f-def772ed867e_0">
											<gml:posList>35.6701324536451 139.74447988985006 25.062 35.6701324536451 139.74447988985006 27.284 35.670132904583994 139.7444802317833 27.284 35.670132904583994 139.7444802317833 25.062 35.6701324536451 139.74447988985006 25.062</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-80b46f6c-694a-4be9-8b95-e45ac05407b0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-80b46f6c-694a-4be9-8b95-e45ac05407b0_0">
											<gml:posList>35.67013293167472 139.74449251515637 27.284 35.67013248124931 139.74449286913466 27.284 35.67013248124931 139.74449286913466 25.062 35.67013293167472 139.74449251515637 25.062 35.67013293167472 139.74449251515637 27.284</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3df4ef96-573e-40d0-acce-2d43954e470c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3df4ef96-573e-40d0-acce-2d43954e470c_0">
											<gml:posList>35.670132904583994 139.7444802317833 27.284 35.670133337536186 139.74448062896766 27.284 35.670133337536186 139.74448062896766 25.062 35.670132904583994 139.7444802317833 25.062 35.670132904583994 139.7444802317833 27.284</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-21efe678-51f5-468f-82d8-d3431c57dac8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-21efe678-51f5-468f-82d8-d3431c57dac8_0">
											<gml:posList>35.670133355026366 139.74449211702316 25.062 35.670133355026366 139.74449211702316 27.284 35.67013293167472 139.74449251515637 27.284 35.67013293167472 139.74449251515637 25.062 35.670133355026366 139.74449211702316 25.062</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-304a6177-0157-42f6-990c-aa8d79a4b212">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-304a6177-0157-42f6-990c-aa8d79a4b212_0">
											<gml:posList>35.670133337536186 139.74448062896766 25.062 35.670133337536186 139.74448062896766 27.284 35.67013372545236 139.74448107038683 27.284 35.67013372545236 139.74448107038683 25.062 35.670133337536186 139.74448062896766 25.062</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5962e139-7cd7-4387-a22a-3420d04ed284">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5962e139-7cd7-4387-a22a-3420d04ed284_0">
											<gml:posList>35.670133742290496 139.74449167474498 25.062 35.670133742290496 139.74449167474498 27.284 35.670133355026366 139.74449211702316 27.284 35.670133355026366 139.74449211702316 25.062 35.670133742290496 139.74449167474498 25.062</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c6bf74dc-abd5-4b37-8323-8132818a7008">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c6bf74dc-abd5-4b37-8323-8132818a7008_0">
											<gml:posList>35.67013372545236 139.74448107038683 25.062 35.67013372545236 139.74448107038683 27.284 35.67013408635996 139.7444815560208 27.284 35.67013408635996 139.7444815560208 25.062 35.67013372545236 139.74448107038683 25.062</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6cffc5ee-9460-41ca-91be-deea6d895145">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6cffc5ee-9460-41ca-91be-deea6d895145_0">
											<gml:posList>35.670134102480866 139.74449118831194 25.062 35.670134102480866 139.74449118831194 27.284 35.670133742290496 139.74449167474498 27.284 35.670133742290496 139.74449167474498 25.062 35.670134102480866 139.74449118831194 25.062</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-441049cc-a1b7-4cdc-9aff-ac3cdaa35ae0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-441049cc-a1b7-4cdc-9aff-ac3cdaa35ae0_0">
											<gml:posList>35.67013408635996 139.7444815560208 27.284 35.67013441123711 139.74448207483337 27.284 35.67013441123711 139.74448207483337 25.062 35.67013408635996 139.7444815560208 25.062 35.67013408635996 139.7444815560208 27.284</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a4f1a299-9a99-4d62-9a19-62e86e966d93">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a4f1a299-9a99-4d62-9a19-62e86e966d93_0">
											<gml:posList>35.67013442660003 139.7444906798264 27.284 35.670134102480866 139.74449118831194 27.284 35.670134102480866 139.74449118831194 25.062 35.67013442660003 139.7444906798264 25.062 35.67013442660003 139.7444906798264 27.284</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d2e03136-3c47-4acd-af3a-7111e853c60f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d2e03136-3c47-4acd-af3a-7111e853c60f_0">
											<gml:posList>35.67013441123711 139.74448207483337 25.062 35.67013441123711 139.74448207483337 27.284 35.67013470008383 139.7444826268246 27.284 35.67013470008383 139.7444826268246 25.062 35.67013441123711 139.74448207483337 25.062</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1a89bc5f-14b9-4929-8be0-dadf816c26e3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1a89bc5f-14b9-4929-8be0-dadf816c26e3_0">
											<gml:posList>35.67013471463169 139.74449012719595 27.284 35.67013442660003 139.7444906798264 27.284 35.67013442660003 139.7444906798264 25.062 35.67013471463169 139.74449012719595 25.062 35.67013471463169 139.74449012719595 27.284</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-14a34a74-24c7-438d-bfe3-eded20e0af59">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-14a34a74-24c7-438d-bfe3-eded20e0af59_0">
											<gml:posList>35.67013470008383 139.7444826268246 25.062 35.67013470008383 139.7444826268246 27.284 35.670134952891935 139.7444832009482 27.284 35.670134952891935 139.7444832009482 25.062 35.67013470008383 139.7444826268246 25.062</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-89577d4b-5b5f-4509-a49e-98d4c8c57d66">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-89577d4b-5b5f-4509-a49e-98d4c8c57d66_0">
											<gml:posList>35.67013495757029 139.74448954147678 25.062 35.67013495757029 139.74448954147678 27.284 35.67013471463169 139.74449012719595 27.284 35.67013471463169 139.74449012719595 25.062 35.67013495757029 139.74448954147678 25.062</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2cbbcf81-d647-43de-92c2-aabcef003b3e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2cbbcf81-d647-43de-92c2-aabcef003b3e_0">
											<gml:posList>35.670134952891935 139.7444832009482 27.284 35.67013515164216 139.7444838082704 27.284 35.67013515164216 139.7444838082704 25.062 35.670134952891935 139.7444832009482 25.062 35.670134952891935 139.7444832009482 27.284</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7083eee6-a158-470c-9c96-a7dc55720415">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7083eee6-a158-470c-9c96-a7dc55720415_0">
											<gml:posList>35.67013516443768 139.74448893370513 25.062 35.67013516443768 139.74448893370513 27.284 35.67013495757029 139.74448954147678 27.284 35.67013495757029 139.74448954147678 25.062 35.67013516443768 139.74448893370513 25.062</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-075f0b58-bdc7-4932-b1df-20689e7aeb58">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-075f0b58-bdc7-4932-b1df-20689e7aeb58_0">
											<gml:posList>35.67013515164216 139.7444838082704 25.062 35.67013515164216 139.7444838082704 27.284 35.67013531434562 139.74448442667875 27.284 35.67013531434562 139.74448442667875 25.062 35.67013515164216 139.7444838082704 25.062</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c466b013-8f98-4d29-b811-a33881fe1613">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c466b013-8f98-4d29-b811-a33881fe1613_0">
											<gml:posList>35.6701353262283 139.74448831493717 27.284 35.67013516443768 139.74448893370513 27.284 35.67013516443768 139.74448893370513 25.062 35.6701353262283 139.74448831493717 25.062 35.6701353262283 139.74448831493717 27.284</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-96ce52be-4fde-44a5-97de-be8359d01a2c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-96ce52be-4fde-44a5-97de-be8359d01a2c_0">
											<gml:posList>35.67013531434562 139.74448442667875 25.062 35.67013531434562 139.74448442667875 27.284 35.670135431996776 139.7444850672295 27.284 35.670135431996776 139.7444850672295 25.062 35.67013531434562 139.74448442667875 25.062</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1f3667bf-050c-40c7-b3b4-b4ab1562c328">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1f3667bf-050c-40c7-b3b4-b4ab1562c328_0">
											<gml:posList>35.67013543392028 139.74448767413674 27.284 35.6701353262283 139.74448831493717 27.284 35.6701353262283 139.74448831493717 25.062 35.67013543392028 139.74448767413674 25.062 35.67013543392028 139.74448767413674 27.284</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6c53df05-6c74-474b-a837-88c9ef17ae9d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6c53df05-6c74-474b-a837-88c9ef17ae9d_0">
											<gml:posList>35.670135431996776 139.7444850672295 25.062 35.670135431996776 139.7444850672295 27.284 35.67013550458744 139.7444857188764 27.284 35.67013550458744 139.7444857188764 25.062 35.670135431996776 139.7444850672295 25.062</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-185cbb51-4c3a-4e0b-8dba-06bbf46622c1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-185cbb51-4c3a-4e0b-8dba-06bbf46622c1_0">
											<gml:posList>35.6701355055492 139.74448702233 25.062 35.6701355055492 139.74448702233 27.284 35.67013543392028 139.74448767413674 27.284 35.67013543392028 139.74448767413674 25.062 35.6701355055492 139.74448702233 25.062</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-162eb645-8696-4393-a42b-437ee43b23be">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-162eb645-8696-4393-a42b-437ee43b23be_0">
											<gml:posList>35.67013550458744 139.7444857188764 27.284 35.67013552309578 139.74448637058325 27.284 35.67013552309578 139.74448637058325 25.062 35.67013550458744 139.7444857188764 25.062 35.67013550458744 139.7444857188764 27.284</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6855123e-20ea-42ba-9315-40ddee6b9540">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6855123e-20ea-42ba-9315-40ddee6b9540_0">
											<gml:posList>35.67013552309578 139.74448637058325 27.284 35.6701355055492 139.74448702233 27.284 35.6701355055492 139.74448702233 25.062 35.67013552309578 139.74448637058325 25.062 35.67013552309578 139.74448637058325 27.284</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-6c64089e-0127-43c3-b09b-fe6811f42cca">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6c64089e-0127-43c3-b09b-fe6811f42cca">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6c64089e-0127-43c3-b09b-fe6811f42cca">
											<gml:posList>35.67017436646558 139.74461296153797 8.43 35.67008808111198 139.74458047066815 8.43 35.6701166607589 139.74446655246746 8.43 35.67020303627991 139.7444990431262 8.43 35.67017436646558 139.74461296153797 8.43</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-125e5441-c135-42b4-8842-ac7cde6dab8e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-125e5441-c135-42b4-8842-ac7cde6dab8e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-125e5441-c135-42b4-8842-ac7cde6dab8e">
											<gml:posList>35.670109291170235 139.7444959214951 25.581 35.670110372295554 139.74449521333895 25.581 35.67011723862366 139.74446788842002 25.581 35.6701166607589 139.74446655246746 25.581 35.670109291170235 139.7444959214951 25.581</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-afea44f9-7a11-4497-b928-2d2474d9d694">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-afea44f9-7a11-4497-b928-2d2474d9d694">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-afea44f9-7a11-4497-b928-2d2474d9d694">
											<gml:posList>35.67014526206567 139.7446020027468 22.4 35.67016644509759 139.744517453549 22.4 35.67016461479832 139.74451675966398 22.4 35.67014390800463 139.74459928687338 22.4 35.67008997317173 139.74457935290556 22.4 35.67011076081475 139.74449647217787 22.4 35.670109291170235 139.7444959214951 22.4 35.67008808111198 139.74458047066815 22.4 35.67014526206567 139.7446020027468 22.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-6277f697-7ca5-4d65-b413-6cc9f3cae63e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6277f697-7ca5-4d65-b413-6cc9f3cae63e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6277f697-7ca5-4d65-b413-6cc9f3cae63e">
											<gml:posList>35.67008997317173 139.74457935290556 21.648 35.67014390800463 139.74459928687338 21.648 35.67016461479832 139.74451675966398 21.648 35.67011076081475 139.74449647217787 21.648 35.67008997317173 139.74457935290556 21.648</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f1380366-6830-472b-9884-a13dcd9b64eb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f1380366-6830-472b-9884-a13dcd9b64eb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f1380366-6830-472b-9884-a13dcd9b64eb">
											<gml:posList>35.67016644509759 139.744517453549 25.581 35.67016585822781 139.74451612865147 25.581 35.670110372295554 139.74449521333895 25.581 35.670109291170235 139.7444959214951 25.581 35.67016644509759 139.744517453549 25.581</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b95483e3-3d02-4a2b-8c46-6f54bca036c1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b95483e3-3d02-4a2b-8c46-6f54bca036c1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b95483e3-3d02-4a2b-8c46-6f54bca036c1">
											<gml:posList>35.670172715522405 139.7444887705867 25.062 35.67011723862366 139.74446788842002 25.062 35.670110372295554 139.74449521333895 25.062 35.67016585822781 139.74451612865147 25.062 35.670172715522405 139.7444887705867 25.062</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-2eb263e8-b681-47f9-bbd6-0422868f74ee">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2eb263e8-b681-47f9-bbd6-0422868f74ee">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2eb263e8-b681-47f9-bbd6-0422868f74ee">
											<gml:posList>35.6701166607589 139.74446655246746 25.581 35.67011723862366 139.74446788842002 25.581 35.670172715522405 139.7444887705867 25.581 35.670173805653235 139.7444880513737 25.581 35.6701166607589 139.74446655246746 25.581</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-9550f486-276f-4fd2-8820-5384fc9dec75">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9550f486-276f-4fd2-8820-5384fc9dec75">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9550f486-276f-4fd2-8820-5384fc9dec75">
											<gml:posList>35.67018981848511 139.74449407591968 18.9 35.670173805653235 139.7444880513737 18.9 35.67014526206567 139.7446020027468 18.9 35.670161274900096 139.74460803835964 18.9 35.67018981848511 139.74449407591968 18.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-2d658980-63ad-4332-8d34-414826e8291b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2d658980-63ad-4332-8d34-414826e8291b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2d658980-63ad-4332-8d34-414826e8291b">
											<gml:posList>35.670173805653235 139.7444880513737 25.581 35.670172715522405 139.7444887705867 25.581 35.67016585822781 139.74451612865147 25.581 35.67016644509759 139.744517453549 25.581 35.670173805653235 139.7444880513737 25.581</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-39c32d80-a4a4-405e-8009-6dd26baf6ed2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-39c32d80-a4a4-405e-8009-6dd26baf6ed2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-39c32d80-a4a4-405e-8009-6dd26baf6ed2">
											<gml:posList>35.670161274900096 139.74460803835964 15.8 35.67017436646558 139.74461296153797 15.8 35.67020303627991 139.7444990431262 15.8 35.67018981848511 139.74449407591968 15.8 35.670161274900096 139.74460803835964 15.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-fee0526e-099f-40a2-b62d-e803243ff585">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fee0526e-099f-40a2-b62d-e803243ff585">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fee0526e-099f-40a2-b62d-e803243ff585">
											<gml:posList>35.67016585822781 139.74451612865147 25.581 35.67016585822781 139.74451612865147 25.062 35.670110372295554 139.74449521333895 25.062 35.670110372295554 139.74449521333895 25.581 35.67016585822781 139.74451612865147 25.581</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e90a0686-fc76-44b5-ac73-19e054443260">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e90a0686-fc76-44b5-ac73-19e054443260">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e90a0686-fc76-44b5-ac73-19e054443260">
											<gml:posList>35.67011723862366 139.74446788842002 25.581 35.67011723862366 139.74446788842002 25.062 35.670172715522405 139.7444887705867 25.062 35.670172715522405 139.7444887705867 25.581 35.67011723862366 139.74446788842002 25.581</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b56f0ef4-3c52-4219-8dc8-e6a0f14f598d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b56f0ef4-3c52-4219-8dc8-e6a0f14f598d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b56f0ef4-3c52-4219-8dc8-e6a0f14f598d">
											<gml:posList>35.670110372295554 139.74449521333895 25.581 35.670110372295554 139.74449521333895 25.062 35.67011723862366 139.74446788842002 25.062 35.67011723862366 139.74446788842002 25.581 35.670110372295554 139.74449521333895 25.581</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4219e167-930c-40be-8521-752e5da10339">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4219e167-930c-40be-8521-752e5da10339">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4219e167-930c-40be-8521-752e5da10339">
											<gml:posList>35.67020303627991 139.7444990431262 8.43 35.6701166607589 139.74446655246746 8.43 35.6701166607589 139.74446655246746 25.581 35.670173805653235 139.7444880513737 25.581 35.670173805653235 139.7444880513737 18.9 35.67018981848511 139.74449407591968 18.9 35.67018981848511 139.74449407591968 15.8 35.67020303627991 139.7444990431262 15.8 35.67020303627991 139.7444990431262 8.43</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7e94989f-9f7c-468c-904b-343e00dc4ed2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7e94989f-9f7c-468c-904b-343e00dc4ed2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7e94989f-9f7c-468c-904b-343e00dc4ed2">
											<gml:posList>35.670172715522405 139.7444887705867 25.581 35.670172715522405 139.7444887705867 25.062 35.67016585822781 139.74451612865147 25.062 35.67016585822781 139.74451612865147 25.581 35.670172715522405 139.7444887705867 25.581</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-bb245dd1-9128-49c9-bb03-51752f1770fc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bb245dd1-9128-49c9-bb03-51752f1770fc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bb245dd1-9128-49c9-bb03-51752f1770fc">
											<gml:posList>35.67011076081475 139.74449647217787 22.4 35.67011076081475 139.74449647217787 21.648 35.67016461479832 139.74451675966398 21.648 35.67016461479832 139.74451675966398 22.4 35.67016644509759 139.744517453549 22.4 35.67016644509759 139.744517453549 25.581 35.670109291170235 139.7444959214951 25.581 35.670109291170235 139.7444959214951 22.4 35.67011076081475 139.74449647217787 22.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-af3beec1-8a1d-40ab-a7c7-2315c6c73765">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-af3beec1-8a1d-40ab-a7c7-2315c6c73765">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-af3beec1-8a1d-40ab-a7c7-2315c6c73765">
											<gml:posList>35.67008808111198 139.74458047066815 8.43 35.67008808111198 139.74458047066815 22.4 35.670109291170235 139.7444959214951 22.4 35.670109291170235 139.7444959214951 25.581 35.6701166607589 139.74446655246746 25.581 35.6701166607589 139.74446655246746 8.43 35.67008808111198 139.74458047066815 8.43</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-370b0f46-7e97-4536-b960-c95c1d826668">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-370b0f46-7e97-4536-b960-c95c1d826668">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-370b0f46-7e97-4536-b960-c95c1d826668">
											<gml:posList>35.67008997317173 139.74457935290556 22.4 35.67008997317173 139.74457935290556 21.648 35.67011076081475 139.74449647217787 21.648 35.67011076081475 139.74449647217787 22.4 35.67008997317173 139.74457935290556 22.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0bf1329d-eda0-43a1-8914-f50f64499a2e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0bf1329d-eda0-43a1-8914-f50f64499a2e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0bf1329d-eda0-43a1-8914-f50f64499a2e">
											<gml:posList>35.670173805653235 139.7444880513737 18.9 35.670173805653235 139.7444880513737 25.581 35.67016644509759 139.744517453549 25.581 35.67016644509759 139.744517453549 22.4 35.67014526206567 139.7446020027468 22.4 35.67014526206567 139.7446020027468 18.9 35.670173805653235 139.7444880513737 18.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b99a336c-31f2-4033-9716-2a3c136d2b69">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b99a336c-31f2-4033-9716-2a3c136d2b69">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b99a336c-31f2-4033-9716-2a3c136d2b69">
											<gml:posList>35.67018981848511 139.74449407591968 15.8 35.67018981848511 139.74449407591968 18.9 35.670161274900096 139.74460803835964 18.9 35.670161274900096 139.74460803835964 15.8 35.67018981848511 139.74449407591968 15.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-eb0318c5-5267-469a-9a9c-4f0d1d31dd1f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-eb0318c5-5267-469a-9a9c-4f0d1d31dd1f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-eb0318c5-5267-469a-9a9c-4f0d1d31dd1f">
											<gml:posList>35.67017436646558 139.74461296153797 8.43 35.67020303627991 139.7444990431262 8.43 35.67020303627991 139.7444990431262 15.8 35.67017436646558 139.74461296153797 15.8 35.67017436646558 139.74461296153797 8.43</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e78260b4-b3a1-44a1-b757-ecf55c70af0a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e78260b4-b3a1-44a1-b757-ecf55c70af0a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e78260b4-b3a1-44a1-b757-ecf55c70af0a">
											<gml:posList>35.67016461479832 139.74451675966398 22.4 35.67016461479832 139.74451675966398 21.648 35.67014390800463 139.74459928687338 21.648 35.67014390800463 139.74459928687338 22.4 35.67016461479832 139.74451675966398 22.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c5893b20-7c0e-4b9f-beb4-60e40f5c8b57">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c5893b20-7c0e-4b9f-beb4-60e40f5c8b57">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c5893b20-7c0e-4b9f-beb4-60e40f5c8b57">
											<gml:posList>35.67014390800463 139.74459928687338 22.4 35.67014390800463 139.74459928687338 21.648 35.67008997317173 139.74457935290556 21.648 35.67008997317173 139.74457935290556 22.4 35.67014390800463 139.74459928687338 22.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-16dae379-43a5-4dad-b8dd-2dec75939cd9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-16dae379-43a5-4dad-b8dd-2dec75939cd9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-16dae379-43a5-4dad-b8dd-2dec75939cd9">
											<gml:posList>35.67017436646558 139.74461296153797 8.43 35.67017436646558 139.74461296153797 15.8 35.670161274900096 139.74460803835964 15.8 35.670161274900096 139.74460803835964 18.9 35.67014526206567 139.7446020027468 18.9 35.67014526206567 139.7446020027468 22.4 35.67008808111198 139.74458047066815 22.4 35.67008808111198 139.74458047066815 8.43 35.67017436646558 139.74461296153797 8.43</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂一丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-9869</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">108.114</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">211</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1230</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>7</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>