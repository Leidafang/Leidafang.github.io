<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_d4d22d5c-b484-4c5a-972a-409dd80b34c6">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>3</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001003</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">413</bldg:usage>
			<bldg:measuredHeight uom="m">12</bldg:measuredHeight>
			<bldg:storeysAboveGround>2</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.674418035265575 139.73790152239502 0 35.67450966876295 139.73785601084737 0 35.674495302521734 139.7378126139307 0 35.67440366904061 139.73785812551975 0 35.674418035265575 139.73790152239502 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.674418035265575 139.73790152239502 8.775 35.67440366904061 139.73785812551975 8.775 35.674495302521734 139.7378126139307 8.775 35.67450966876295 139.73785601084737 8.775 35.674418035265575 139.73790152239502 8.775</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.674418035265575 139.73790152239502 8.775 35.67450966876295 139.73785601084737 8.775 35.67450966876295 139.73785601084737 20.77 35.674418035265575 139.73790152239502 20.77 35.674418035265575 139.73790152239502 8.775</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67450966876295 139.73785601084737 8.775 35.674495302521734 139.7378126139307 8.775 35.674495302521734 139.7378126139307 20.77 35.67450966876295 139.73785601084737 20.77 35.67450966876295 139.73785601084737 8.775</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.674495302521734 139.7378126139307 8.775 35.67440366904061 139.73785812551975 8.775 35.67440366904061 139.73785812551975 20.77 35.674495302521734 139.7378126139307 20.77 35.674495302521734 139.7378126139307 8.775</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67440366904061 139.73785812551975 8.775 35.674418035265575 139.73790152239502 8.775 35.674418035265575 139.73790152239502 20.77 35.67440366904061 139.73785812551975 20.77 35.67440366904061 139.73785812551975 8.775</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.674418035265575 139.73790152239502 20.77 35.67450966876295 139.73785601084737 20.77 35.674495302521734 139.7378126139307 20.77 35.67440366904061 139.73785812551975 20.77 35.674418035265575 139.73790152239502 20.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-9b68aab4-fa4f-43ce-885e-eb42acf81fda"/>
							<gml:surfaceMember xlink:href="#poly-17be6eb6-0832-478e-b172-f6e6773fe32b"/>
							<gml:surfaceMember xlink:href="#poly-fc79a28f-2452-44d4-a3f5-c7ba8d72f28f"/>
							<gml:surfaceMember xlink:href="#poly-f2510a5c-6de4-48d2-9e58-f6396ecbe3b0"/>
							<gml:surfaceMember xlink:href="#poly-68280b27-09b6-4580-854d-0657a692d6ce"/>
							<gml:surfaceMember xlink:href="#poly-b4f5aba4-d6d0-4f8e-82fb-3b96a47bdbe1"/>
							<gml:surfaceMember xlink:href="#poly-9b45cabe-b809-46f1-aa4b-c708507041cc"/>
							<gml:surfaceMember xlink:href="#poly-927b2c9d-15b1-46fb-a1d8-09125fe82af0"/>
							<gml:surfaceMember xlink:href="#poly-d55393e5-a974-4b65-bc51-772c84cc9744"/>
							<gml:surfaceMember xlink:href="#poly-42cf0e8c-55f3-40c7-934a-90e1c40ad057"/>
							<gml:surfaceMember xlink:href="#poly-8a3be397-8cde-4685-8b2a-5d5f5b924bdf"/>
							<gml:surfaceMember xlink:href="#poly-1b4a4522-2be3-437f-b324-b09eec50c1b6"/>
							<gml:surfaceMember xlink:href="#poly-d219eb56-1e6c-41ea-9497-d412407417b2"/>
							<gml:surfaceMember xlink:href="#poly-248566b3-3fae-432e-9564-67798dc2405c"/>
							<gml:surfaceMember xlink:href="#poly-d7763e81-488e-4a6d-a835-2ad4f3f24dcf"/>
							<gml:surfaceMember xlink:href="#poly-3d9ee47f-0388-4ac0-8398-a2968a2c1034"/>
							<gml:surfaceMember xlink:href="#poly-8bcdbbf5-8d54-4e5f-9193-010e8bfa422c"/>
							<gml:surfaceMember xlink:href="#poly-a8531a0f-33f5-42a1-95d9-a507f59e3716"/>
							<gml:surfaceMember xlink:href="#poly-3f93d923-d8b9-4b50-89e2-6f54c05f00d2"/>
							<gml:surfaceMember xlink:href="#poly-2c3a40c6-ad6d-4ee1-b398-1857053daa7c"/>
							<gml:surfaceMember xlink:href="#poly-7660f8e4-5486-4c04-a1fb-b201247d8088"/>
							<gml:surfaceMember xlink:href="#poly-aebeb976-e0ef-4626-ab9b-036dcbde224a"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_d4d22d5c-b484-4c5a-972a-409dd80b34c6_BuildingInstallation_1054">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4bdda5f5-7ed0-4ca9-8ec7-aa946f0aaa0d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4bdda5f5-7ed0-4ca9-8ec7-aa946f0aaa0d_0">
											<gml:posList>35.674427978673144 139.7378462764735 20.509 35.67443815116354 139.73784122700764 20.509 35.67443815116354 139.73784122700764 19.36 35.674427978673144 139.7378462764735 19.359 35.674427978673144 139.7378462764735 20.509</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ff8e19aa-cb5a-4e4d-a793-b9ce515e1a2a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ff8e19aa-cb5a-4e4d-a793-b9ce515e1a2a_0">
											<gml:posList>35.67443930765255 139.73784467223743 20.509 35.67443815116354 139.73784122700764 19.36 35.67443815116354 139.73784122700764 20.509 35.67443930765255 139.73784467223743 20.509</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-71a0378e-a39d-47fe-a377-007a84ce5150">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-71a0378e-a39d-47fe-a377-007a84ce5150_0">
											<gml:posList>35.67443815116354 139.73784122700764 20.509 35.674427978673144 139.7378462764735 20.509 35.67442912614829 139.73784972171364 20.509 35.67443930765255 139.73784467223743 20.509 35.67443815116354 139.73784122700764 20.509</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1c9257ac-fe9c-4d20-8511-2a38def9b8af">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1c9257ac-fe9c-4d20-8511-2a38def9b8af_0">
											<gml:posList>35.674427978673144 139.7378462764735 19.359 35.67442912614829 139.73784972171364 20.509 35.674427978673144 139.7378462764735 20.509 35.674427978673144 139.7378462764735 19.359</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1654a830-f64d-45a6-be2d-0f77a3639bdf">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1654a830-f64d-45a6-be2d-0f77a3639bdf_0">
											<gml:posList>35.67443815116354 139.73784122700764 19.36 35.67443930765255 139.73784467223743 20.509 35.67442912614829 139.73784972171364 20.509 35.674427978673144 139.7378462764735 19.359 35.67443815116354 139.73784122700764 19.36</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-529c3789-6476-4c68-83ab-4933da7f62aa">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-529c3789-6476-4c68-83ab-4933da7f62aa_0">
											<gml:posList>35.67448341839929 139.73781889164073 20.509 35.67448341839929 139.73781889164073 19.403 35.67447459744153 139.73782327669267 19.404 35.67447459744153 139.73782327669267 20.509 35.67448341839929 139.73781889164073 20.509</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8990ac95-4a85-41e8-8204-fc088dd50cf0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8990ac95-4a85-41e8-8204-fc088dd50cf0_0">
											<gml:posList>35.67448341839929 139.73781889164073 20.509 35.67448474648251 139.73782275644703 20.509 35.67448382494538 139.73782006211977 19.795 35.67448341839929 139.73781889164073 19.403 35.67448341839929 139.73781889164073 20.509</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-11c3a6f9-354e-4def-8f0f-d28cdeb5f18c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-11c3a6f9-354e-4def-8f0f-d28cdeb5f18c_0">
											<gml:posList>35.674475374426166 139.73782555141258 20.163 35.67448382494538 139.73782006211977 19.795 35.67448474648251 139.73782275644703 20.509 35.67447582614592 139.73782685439957 20.509 35.674475374426166 139.73782555141258 20.163</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d5f23258-99cf-472d-9dff-3cea2b3944cf">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d5f23258-99cf-472d-9dff-3cea2b3944cf_0">
											<gml:posList>35.67448341839929 139.73781889164073 20.509 35.67447459744153 139.73782327669267 20.509 35.67447582614592 139.73782685439957 20.509 35.67448474648251 139.73782275644703 20.509 35.67448341839929 139.73781889164073 20.509</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-de52122b-ab61-4419-ae9f-aedb510c135e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-de52122b-ab61-4419-ae9f-aedb510c135e_0">
											<gml:posList>35.674475374426166 139.73782555141258 20.163 35.67447582614592 139.73782685439957 20.509 35.67447459744153 139.73782327669267 20.509 35.67447459744153 139.73782327669267 19.404 35.674475374426166 139.73782555141258 20.163</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-971721d4-19f9-4845-ba73-2b6ded32f211">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-971721d4-19f9-4845-ba73-2b6ded32f211_0">
											<gml:posList>35.67447459744153 139.73782327669267 19.404 35.67448341839929 139.73781889164073 19.403 35.67448382494538 139.73782006211977 19.795 35.674475374426166 139.73782555141258 20.163 35.67447459744153 139.73782327669267 19.404</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-9b68aab4-fa4f-43ce-885e-eb42acf81fda">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9b68aab4-fa4f-43ce-885e-eb42acf81fda">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9b68aab4-fa4f-43ce-885e-eb42acf81fda">
											<gml:posList>35.67441803526557 139.73790152239502 8.775 35.6744036690406 139.73785812551975 8.775 35.67449530252171 139.7378126139307 8.775 35.67450966876293 139.73785601084737 8.775 35.67441803526557 139.73790152239502 8.775</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-17be6eb6-0832-478e-b172-f6e6773fe32b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-17be6eb6-0832-478e-b172-f6e6773fe32b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-17be6eb6-0832-478e-b172-f6e6773fe32b">
											<gml:posList>35.67450966876293 139.73785601084737 19.295 35.67449530252171 139.7378126139307 19.295 35.67449296265676 139.73782864566311 22.716 35.67450966876293 139.73785601084737 19.295</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-fc79a28f-2452-44d4-a3f5-c7ba8d72f28f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fc79a28f-2452-44d4-a3f5-c7ba8d72f28f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fc79a28f-2452-44d4-a3f5-c7ba8d72f28f">
											<gml:posList>35.67441677931063 139.73786356703252 22.716 35.67449296265676 139.73782864566311 22.716 35.67449530252171 139.7378126139307 19.295 35.67441677931063 139.73786356703252 22.716</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f2510a5c-6de4-48d2-9e58-f6396ecbe3b0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f2510a5c-6de4-48d2-9e58-f6396ecbe3b0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f2510a5c-6de4-48d2-9e58-f6396ecbe3b0">
											<gml:posList>35.67449530252171 139.7378126139307 19.295 35.6744036690406 139.73785812551975 19.295 35.67441677931063 139.73786356703252 22.716 35.67449530252171 139.7378126139307 19.295</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-68280b27-09b6-4580-854d-0657a692d6ce">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-68280b27-09b6-4580-854d-0657a692d6ce">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-68280b27-09b6-4580-854d-0657a692d6ce">
											<gml:posList>35.67449296265676 139.73782864566311 22.716 35.674501520906915 139.7378567054548 22.716 35.67450966876293 139.73785601084737 19.295 35.67449296265676 139.73782864566311 22.716</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b4f5aba4-d6d0-4f8e-82fb-3b96a47bdbe1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b4f5aba4-d6d0-4f8e-82fb-3b96a47bdbe1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b4f5aba4-d6d0-4f8e-82fb-3b96a47bdbe1">
											<gml:posList>35.67449296265676 139.73782864566311 22.716 35.67449166744169 139.73783212695625 22.716 35.674498680333805 139.73785512914168 22.716 35.674501520906915 139.7378567054548 22.716 35.67449296265676 139.73782864566311 22.716</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-9b45cabe-b809-46f1-aa4b-c708507041cc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9b45cabe-b809-46f1-aa4b-c708507041cc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9b45cabe-b809-46f1-aa4b-c708507041cc">
											<gml:posList>35.67441677931063 139.73786356703252 22.716 35.67441961988368 139.73786514334432 22.716 35.67449166744169 139.73783212695625 22.716 35.67449296265676 139.73782864566311 22.716 35.67441677931063 139.73786356703252 22.716</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-927b2c9d-15b1-46fb-a1d8-09125fe82af0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-927b2c9d-15b1-46fb-a1d8-09125fe82af0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-927b2c9d-15b1-46fb-a1d8-09125fe82af0">
											<gml:posList>35.674498680333805 139.73785512914168 22.174 35.67449166744169 139.73783212695625 22.174 35.67441961988368 139.73786514334432 22.174 35.674426641783256 139.73788814550127 22.174 35.674498680333805 139.73785512914168 22.174</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d55393e5-a974-4b65-bc51-772c84cc9744">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d55393e5-a974-4b65-bc51-772c84cc9744">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d55393e5-a974-4b65-bc51-772c84cc9744">
											<gml:posList>35.674501520906915 139.7378567054548 22.716 35.674498680333805 139.73785512914168 22.716 35.674426641783256 139.73788814550127 22.716 35.674425346566444 139.73789162679057 22.716 35.674501520906915 139.7378567054548 22.716</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-42cf0e8c-55f3-40c7-934a-90e1c40ad057">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-42cf0e8c-55f3-40c7-934a-90e1c40ad057">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-42cf0e8c-55f3-40c7-934a-90e1c40ad057">
											<gml:posList>35.674425346566444 139.73789162679057 22.716 35.674426641783256 139.73788814550127 22.716 35.67441961988368 139.73786514334432 22.716 35.67441677931063 139.73786356703252 22.716 35.674425346566444 139.73789162679057 22.716</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-8a3be397-8cde-4685-8b2a-5d5f5b924bdf">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8a3be397-8cde-4685-8b2a-5d5f5b924bdf">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8a3be397-8cde-4685-8b2a-5d5f5b924bdf">
											<gml:posList>35.674425346566444 139.73789162679057 22.716 35.67441803526557 139.73790152239502 19.295 35.67450966876293 139.73785601084737 19.295 35.674425346566444 139.73789162679057 22.716</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-1b4a4522-2be3-437f-b324-b09eec50c1b6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1b4a4522-2be3-437f-b324-b09eec50c1b6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1b4a4522-2be3-437f-b324-b09eec50c1b6">
											<gml:posList>35.67441677931063 139.73786356703252 22.716 35.6744036690406 139.73785812551975 19.295 35.67441803526557 139.73790152239502 19.295 35.67441677931063 139.73786356703252 22.716</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d219eb56-1e6c-41ea-9497-d412407417b2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d219eb56-1e6c-41ea-9497-d412407417b2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d219eb56-1e6c-41ea-9497-d412407417b2">
											<gml:posList>35.67441803526557 139.73790152239502 19.295 35.674425346566444 139.73789162679057 22.716 35.67441677931063 139.73786356703252 22.716 35.67441803526557 139.73790152239502 19.295</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-248566b3-3fae-432e-9564-67798dc2405c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-248566b3-3fae-432e-9564-67798dc2405c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-248566b3-3fae-432e-9564-67798dc2405c">
											<gml:posList>35.67441961988368 139.73786514334432 22.716 35.67441961988368 139.73786514334432 22.174 35.67449166744169 139.73783212695625 22.174 35.67449166744169 139.73783212695625 22.716 35.67441961988368 139.73786514334432 22.716</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d7763e81-488e-4a6d-a835-2ad4f3f24dcf">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d7763e81-488e-4a6d-a835-2ad4f3f24dcf">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d7763e81-488e-4a6d-a835-2ad4f3f24dcf">
											<gml:posList>35.67450966876293 139.73785601084737 8.775 35.67449530252171 139.7378126139307 8.775 35.67449530252171 139.7378126139307 19.295 35.67450966876293 139.73785601084737 19.295 35.67450966876293 139.73785601084737 8.775</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3d9ee47f-0388-4ac0-8398-a2968a2c1034">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3d9ee47f-0388-4ac0-8398-a2968a2c1034">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3d9ee47f-0388-4ac0-8398-a2968a2c1034">
											<gml:posList>35.67449530252171 139.7378126139307 8.775 35.6744036690406 139.73785812551975 8.775 35.6744036690406 139.73785812551975 19.295 35.67449530252171 139.7378126139307 19.295 35.67449530252171 139.7378126139307 8.775</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8bcdbbf5-8d54-4e5f-9193-010e8bfa422c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8bcdbbf5-8d54-4e5f-9193-010e8bfa422c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8bcdbbf5-8d54-4e5f-9193-010e8bfa422c">
											<gml:posList>35.67449166744169 139.73783212695625 22.716 35.67449166744169 139.73783212695625 22.174 35.674498680333805 139.73785512914168 22.174 35.674498680333805 139.73785512914168 22.716 35.67449166744169 139.73783212695625 22.716</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a8531a0f-33f5-42a1-95d9-a507f59e3716">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a8531a0f-33f5-42a1-95d9-a507f59e3716">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a8531a0f-33f5-42a1-95d9-a507f59e3716">
											<gml:posList>35.674498680333805 139.73785512914168 22.716 35.674498680333805 139.73785512914168 22.174 35.674426641783256 139.73788814550127 22.174 35.674426641783256 139.73788814550127 22.716 35.674498680333805 139.73785512914168 22.716</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3f93d923-d8b9-4b50-89e2-6f54c05f00d2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3f93d923-d8b9-4b50-89e2-6f54c05f00d2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3f93d923-d8b9-4b50-89e2-6f54c05f00d2">
											<gml:posList>35.67450966876293 139.73785601084737 19.295 35.674501520906915 139.7378567054548 22.716 35.674425346566444 139.73789162679057 22.716 35.67450966876293 139.73785601084737 19.295</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2c3a40c6-ad6d-4ee1-b398-1857053daa7c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2c3a40c6-ad6d-4ee1-b398-1857053daa7c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2c3a40c6-ad6d-4ee1-b398-1857053daa7c">
											<gml:posList>35.674426641783256 139.73788814550127 22.716 35.674426641783256 139.73788814550127 22.174 35.67441961988368 139.73786514334432 22.174 35.67441961988368 139.73786514334432 22.716 35.674426641783256 139.73788814550127 22.716</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7660f8e4-5486-4c04-a1fb-b201247d8088">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7660f8e4-5486-4c04-a1fb-b201247d8088">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7660f8e4-5486-4c04-a1fb-b201247d8088">
											<gml:posList>35.67441803526557 139.73790152239502 8.775 35.67450966876293 139.73785601084737 8.775 35.67450966876293 139.73785601084737 19.295 35.67441803526557 139.73790152239502 19.295 35.67441803526557 139.73790152239502 8.775</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-aebeb976-e0ef-4626-ab9b-036dcbde224a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-aebeb976-e0ef-4626-ab9b-036dcbde224a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-aebeb976-e0ef-4626-ab9b-036dcbde224a">
											<gml:posList>35.6744036690406 139.73785812551975 8.775 35.67441803526557 139.73790152239502 8.775 35.67441803526557 139.73790152239502 19.295 35.6744036690406 139.73785812551975 19.295 35.6744036690406 139.73785812551975 8.775</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂三丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-3175</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">54.19615</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1002</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">211</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1230</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>5</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.02</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">12</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>