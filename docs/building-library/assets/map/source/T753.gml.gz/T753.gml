<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_d73d866b-736b-48d2-a70a-dbb82f953a03">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">401</bldg:usage>
			<bldg:measuredHeight uom="m">18</bldg:measuredHeight>
			<bldg:storeysAboveGround>5</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.67087138730241 139.73890930287493 0 35.670867484631096 139.7388751743225 0 35.67076764414814 139.73889253524172 0 35.67077849216864 139.7389672618253 0 35.67077120130567 139.73896885002932 0 35.67078054843314 139.73904925619735 0 35.67088887874849 139.73903046050836 0 35.670881255730414 139.73896474382096 0 35.670895675780294 139.73896229665564 0 35.6708892320456 139.73890618888677 0 35.67087138730241 139.73890930287493 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67087138730241 139.73890930287493 18.24 35.6708892320456 139.73890618888677 18.24 35.670895675780294 139.73896229665564 18.24 35.670881255730414 139.73896474382096 18.24 35.67088887874849 139.73903046050836 18.24 35.67078054843314 139.73904925619735 18.24 35.67077120130567 139.73896885002932 18.24 35.67077849216864 139.7389672618253 18.24 35.67076764414814 139.73889253524172 18.24 35.670867484631096 139.7388751743225 18.24 35.67087138730241 139.73890930287493 18.24</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67087138730241 139.73890930287493 18.24 35.670867484631096 139.7388751743225 18.24 35.670867484631096 139.7388751743225 36.27 35.67087138730241 139.73890930287493 36.27 35.67087138730241 139.73890930287493 18.24</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670867484631096 139.7388751743225 18.24 35.67076764414814 139.73889253524172 18.24 35.67076764414814 139.73889253524172 36.27 35.670867484631096 139.7388751743225 36.27 35.670867484631096 139.7388751743225 18.24</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67076764414814 139.73889253524172 18.24 35.67077849216864 139.7389672618253 18.24 35.67077849216864 139.7389672618253 36.27 35.67076764414814 139.73889253524172 36.27 35.67076764414814 139.73889253524172 18.24</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67077849216864 139.7389672618253 18.24 35.67077120130567 139.73896885002932 18.24 35.67077120130567 139.73896885002932 36.27 35.67077849216864 139.7389672618253 36.27 35.67077849216864 139.7389672618253 18.24</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67077120130567 139.73896885002932 18.24 35.67078054843314 139.73904925619735 18.24 35.67078054843314 139.73904925619735 36.27 35.67077120130567 139.73896885002932 36.27 35.67077120130567 139.73896885002932 18.24</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67078054843314 139.73904925619735 18.24 35.67088887874849 139.73903046050836 18.24 35.67088887874849 139.73903046050836 36.27 35.67078054843314 139.73904925619735 36.27 35.67078054843314 139.73904925619735 18.24</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67088887874849 139.73903046050836 18.24 35.670881255730414 139.73896474382096 18.24 35.670881255730414 139.73896474382096 36.27 35.67088887874849 139.73903046050836 36.27 35.67088887874849 139.73903046050836 18.24</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670881255730414 139.73896474382096 18.24 35.670895675780294 139.73896229665564 18.24 35.670895675780294 139.73896229665564 36.27 35.670881255730414 139.73896474382096 36.27 35.670881255730414 139.73896474382096 18.24</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670895675780294 139.73896229665564 18.24 35.6708892320456 139.73890618888677 18.24 35.6708892320456 139.73890618888677 36.27 35.670895675780294 139.73896229665564 36.27 35.670895675780294 139.73896229665564 18.24</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6708892320456 139.73890618888677 18.24 35.67087138730241 139.73890930287493 18.24 35.67087138730241 139.73890930287493 36.27 35.6708892320456 139.73890618888677 36.27 35.6708892320456 139.73890618888677 18.24</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67087138730241 139.73890930287493 36.27 35.670867484631096 139.7388751743225 36.27 35.67076764414814 139.73889253524172 36.27 35.67077849216864 139.7389672618253 36.27 35.67077120130567 139.73896885002932 36.27 35.67078054843314 139.73904925619735 36.27 35.67088887874849 139.73903046050836 36.27 35.670881255730414 139.73896474382096 36.27 35.670895675780294 139.73896229665564 36.27 35.6708892320456 139.73890618888677 36.27 35.67087138730241 139.73890930287493 36.27</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-982dcf0f-ed3c-49f0-ab94-c014a99b0516"/>
							<gml:surfaceMember xlink:href="#poly-08bc1140-f316-420c-86af-21a8c2a82715"/>
							<gml:surfaceMember xlink:href="#poly-047323fa-a722-4224-a4c4-84d2b7fa3126"/>
							<gml:surfaceMember xlink:href="#poly-a1f7fb90-3b50-4907-aece-40bd4e6c0566"/>
							<gml:surfaceMember xlink:href="#poly-6f22b41a-0887-4c8b-81fc-2801ffe3ee3a"/>
							<gml:surfaceMember xlink:href="#poly-fcedaa46-7207-4b29-a084-d8a42157d293"/>
							<gml:surfaceMember xlink:href="#poly-a99257ad-abfd-4e05-b5ff-b14b98bc05fe"/>
							<gml:surfaceMember xlink:href="#poly-500b63ec-fca6-44e7-8088-6321756c335d"/>
							<gml:surfaceMember xlink:href="#poly-5c6a0fd8-1e3b-496e-93ec-20b93c39e129"/>
							<gml:surfaceMember xlink:href="#poly-ad27034f-09db-4906-b57d-223c665cb471"/>
							<gml:surfaceMember xlink:href="#poly-47daeb36-9692-4d87-a106-64b6f176e743"/>
							<gml:surfaceMember xlink:href="#poly-c322ba9e-0995-4685-a584-1b23138804b4"/>
							<gml:surfaceMember xlink:href="#poly-97490ec8-923a-4933-9bc9-19884dad3118"/>
							<gml:surfaceMember xlink:href="#poly-352856c1-7e08-414f-b660-765d1690b90d"/>
							<gml:surfaceMember xlink:href="#poly-66d699c7-2b44-4c92-b8a5-b56b3de8321a"/>
							<gml:surfaceMember xlink:href="#poly-ef8edbb2-41ff-40ef-94be-40b16e9a849c"/>
							<gml:surfaceMember xlink:href="#poly-8dad35d4-bd1e-4c62-946b-8a403cf53dbd"/>
							<gml:surfaceMember xlink:href="#poly-ef1ddd12-5b52-4324-a634-a8db5971c73d"/>
							<gml:surfaceMember xlink:href="#poly-54677d25-6b79-40a6-b59c-d84f6e580cec"/>
							<gml:surfaceMember xlink:href="#poly-3731d07d-fd90-4932-8245-79560acf1ae0"/>
							<gml:surfaceMember xlink:href="#poly-fa257c3c-fc4d-4a7f-8e97-dca117b2f00a"/>
							<gml:surfaceMember xlink:href="#poly-3f3e2910-b4ab-44bc-aa3a-fb8c5a65b6e6"/>
							<gml:surfaceMember xlink:href="#poly-e92d7098-8d28-4e16-b9cc-fb895df39a64"/>
							<gml:surfaceMember xlink:href="#poly-6477174c-d154-41e4-a413-b3dbe590f20b"/>
							<gml:surfaceMember xlink:href="#poly-3d2cd4f6-ab4c-4ec7-adb3-28c9b4ebbf38"/>
							<gml:surfaceMember xlink:href="#poly-ff8cbe70-0ba1-44d0-9d40-6ed1695db15a"/>
							<gml:surfaceMember xlink:href="#poly-4462729e-1616-4d50-a5b4-0d189dc0a098"/>
							<gml:surfaceMember xlink:href="#poly-d424d839-af15-4fdd-be3a-5ae1a0dc82da"/>
							<gml:surfaceMember xlink:href="#poly-c56dcdcd-2725-47b8-b007-dee8466b4b37"/>
							<gml:surfaceMember xlink:href="#poly-82d23cc9-432d-4206-b24f-f3681ede27a1"/>
							<gml:surfaceMember xlink:href="#poly-a4c166f3-c18b-4813-97a2-0ce18981dca6"/>
							<gml:surfaceMember xlink:href="#poly-3ebc7543-68bb-48e4-a139-910e13e5d95c"/>
							<gml:surfaceMember xlink:href="#poly-d58e7b1c-55e9-45bb-8fb9-01dddd26ab3e"/>
							<gml:surfaceMember xlink:href="#poly-e9a402c4-5764-4ce6-86b2-bdd8a6ff39a9"/>
							<gml:surfaceMember xlink:href="#poly-ea083dca-cede-4065-85b8-0d0ec690e9bb"/>
							<gml:surfaceMember xlink:href="#poly-c8d91b82-b454-4ec6-af27-9fcf169f26df"/>
							<gml:surfaceMember xlink:href="#poly-6792727e-e0de-46c7-99ae-c01020f10747"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_d73d866b-736b-48d2-a70a-dbb82f953a03_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-58b69cc9-db6a-47d6-bd23-c40cbb0cb458">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670834447839425 139.73901128183707 36.296 35.67083596049414 139.7390206804776 36.296 35.670827047601904 139.73902283394827 36.296 35.670825534956 139.73901344635502 36.296 35.670834447839425 139.73901128183707 36.296</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0b2afb24-2be4-4066-8e42-50322b435d4f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0b2afb24-2be4-4066-8e42-50322b435d4f_0">
											<gml:posList>35.670825534956 139.73901344635502 36.296 35.670825534956 139.73901344635502 38.669 35.670834447839425 139.73901128183707 38.669 35.670834447839425 139.73901128183707 36.296 35.670825534956 139.73901344635502 36.296</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2ef54c0f-d392-4ca9-a57d-b2b2129935ce">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2ef54c0f-d392-4ca9-a57d-b2b2129935ce_0">
											<gml:posList>35.670834447839425 139.73901128183707 36.296 35.670834447839425 139.73901128183707 38.669 35.67083596049414 139.7390206804776 38.669 35.67083596049414 139.7390206804776 36.296 35.670834447839425 139.73901128183707 36.296</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-43bb7183-885d-4daa-b365-90181c8feeea">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-43bb7183-885d-4daa-b365-90181c8feeea_0">
											<gml:posList>35.670827047601904 139.73902283394827 38.669 35.67083596049414 139.7390206804776 38.669 35.670834447839425 139.73901128183707 38.669 35.670825534956 139.73901344635502 38.669 35.670827047601904 139.73902283394827 38.669</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0e74c5e4-7a5d-43a7-87d4-c24a59cebaff">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0e74c5e4-7a5d-43a7-87d4-c24a59cebaff_0">
											<gml:posList>35.670827047601904 139.73902283394827 36.296 35.670827047601904 139.73902283394827 38.669 35.670825534956 139.73901344635502 38.669 35.670825534956 139.73901344635502 36.296 35.670827047601904 139.73902283394827 36.296</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fb159a73-329a-4763-a7d1-1423db2b1924">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fb159a73-329a-4763-a7d1-1423db2b1924_0">
											<gml:posList>35.67083596049414 139.7390206804776 36.296 35.67083596049414 139.7390206804776 38.669 35.670827047601904 139.73902283394827 38.669 35.670827047601904 139.73902283394827 36.296 35.67083596049414 139.7390206804776 36.296</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_d73d866b-736b-48d2-a70a-dbb82f953a03_BuildingInstallation_1060">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7719fdcb-08f5-4a5d-9bea-5724a9dd8a00">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67076286027476 139.73890711096223 18.24 35.670761317373206 139.73889363627896 18.24 35.67076764414815 139.73889253524172 18.24 35.6707784921686 139.7389672618253 18.24 35.670771201305655 139.7389688500293 18.24 35.67075903442608 139.73897096314843 18.24 35.67075186500684 139.7389090017845 18.24 35.67076286027476 139.73890711096223 18.24</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5bec6225-aa61-4e14-a840-3e2b0c11e512">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670853963852274 139.7389669078846 36.296 35.670848482113776 139.7389191389861 36.296 35.67086477673106 139.73891632507727 36.296 35.670865085293656 139.7389189979248 36.296 35.67087025847067 139.7389640939853 36.296 35.670853963852274 139.7389669078846 36.296</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-517a1e5a-4235-4c06-95c5-70124d788f89">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-517a1e5a-4235-4c06-95c5-70124d788f89_0">
											<gml:posList>35.67075903442608 139.73897096314843 37.557 35.67075186500684 139.7389090017845 37.557 35.67075186500684 139.7389090017845 18.24 35.67075903442608 139.73897096314843 18.24 35.67075903442608 139.73897096314843 37.557</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-59ea5a76-9e20-418b-83d4-eb873ac24f75">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-59ea5a76-9e20-418b-83d4-eb873ac24f75_0">
											<gml:posList>35.67076286027476 139.73890711096223 37.557 35.67076286027476 139.73890711096223 18.24 35.67075186500684 139.7389090017845 18.24 35.67075186500684 139.7389090017845 37.557 35.67076286027476 139.73890711096223 37.557</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8c19a472-8e43-4c28-849c-0e0811490e44">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8c19a472-8e43-4c28-849c-0e0811490e44_0">
											<gml:posList>35.67076286027476 139.73890711096223 37.557 35.670761317373206 139.73889363627896 37.557 35.670761317373206 139.73889363627896 18.24 35.67076286027476 139.73890711096223 18.24 35.67076286027476 139.73890711096223 37.557</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8e81b262-3f6e-4e28-b367-b8b2220485cb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8e81b262-3f6e-4e28-b367-b8b2220485cb_0">
											<gml:posList>35.670761317373206 139.73889363627896 37.557 35.67076764414815 139.73889253524172 37.557 35.67076764414815 139.73889253524172 18.24 35.670761317373206 139.73889363627896 18.24 35.670761317373206 139.73889363627896 37.557</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8a94e7c4-1e32-4b5c-bb06-58ffd565ab5f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8a94e7c4-1e32-4b5c-bb06-58ffd565ab5f_0">
											<gml:posList>35.67075903442608 139.73897096314843 37.557 35.67075903442608 139.73897096314843 18.24 35.670771201305655 139.7389688500293 18.24 35.670771201305655 139.7389688500293 37.557 35.67075903442608 139.73897096314843 37.557</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-717fb6ab-fec4-46aa-b223-df7e956dd8c1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-717fb6ab-fec4-46aa-b223-df7e956dd8c1_0">
											<gml:posList>35.67075903442608 139.73897096314843 37.557 35.670771201305655 139.7389688500293 37.557 35.6707784921686 139.7389672618253 37.557 35.67076764414815 139.73889253524172 37.557 35.670761317373206 139.73889363627896 37.557 35.67076286027476 139.73890711096223 37.557 35.67075186500684 139.7389090017845 37.557 35.67075903442608 139.73897096314843 37.557</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0b617681-9f1b-4cab-b0da-f2a0595fad1a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0b617681-9f1b-4cab-b0da-f2a0595fad1a_0">
											<gml:posList>35.6707784921686 139.7389672618253 37.557 35.6707784921686 139.7389672618253 18.24 35.67076764414815 139.73889253524172 18.24 35.67076764414815 139.73889253524172 37.557 35.6707784921686 139.7389672618253 37.557</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2dd6cbad-3dbc-4089-82ed-5d50961a099d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2dd6cbad-3dbc-4089-82ed-5d50961a099d_0">
											<gml:posList>35.670771201305655 139.7389688500293 18.24 35.6707784921686 139.7389672618253 18.24 35.6707784921686 139.7389672618253 37.557 35.670771201305655 139.7389688500293 37.557 35.670771201305655 139.7389688500293 18.24</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bce0dd24-c121-44fb-ac8c-dde37056b90a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bce0dd24-c121-44fb-ac8c-dde37056b90a_0">
											<gml:posList>35.670848482113776 139.7389191389861 36.296 35.670853963852274 139.7389669078846 36.296 35.670853963852274 139.7389669078846 36.847 35.670848482113776 139.7389191389861 36.847 35.670848482113776 139.7389191389861 36.296</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7b7eed7e-e8c4-4fbc-bed0-e25c9f4170d6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7b7eed7e-e8c4-4fbc-bed0-e25c9f4170d6_0">
											<gml:posList>35.67086477673106 139.73891632507727 36.296 35.670848482113776 139.7389191389861 36.296 35.670848482113776 139.7389191389861 36.847 35.67086477673106 139.73891632507727 36.847 35.67086477673106 139.73891632507727 36.296</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-dc01f656-396f-417b-a2f4-e215e81908d5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-dc01f656-396f-417b-a2f4-e215e81908d5_0">
											<gml:posList>35.670865085293656 139.7389189979248 36.847 35.67086477673106 139.73891632507727 36.847 35.670848482113776 139.7389191389861 36.847 35.670853963852274 139.7389669078846 36.847 35.67087025847067 139.7389640939853 36.847 35.670865085293656 139.7389189979248 36.847</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ed68d531-99e8-4ffa-8647-f6cb0b0929a9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ed68d531-99e8-4ffa-8647-f6cb0b0929a9_0">
											<gml:posList>35.670853963852274 139.7389669078846 36.296 35.67087025847067 139.7389640939853 36.296 35.67087025847067 139.7389640939853 36.847 35.670853963852274 139.7389669078846 36.847 35.670853963852274 139.7389669078846 36.296</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f92ebcdb-2c80-4b40-b779-0f367d04f1b5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f92ebcdb-2c80-4b40-b779-0f367d04f1b5_0">
											<gml:posList>35.67086477673106 139.73891632507727 36.296 35.67086477673106 139.73891632507727 36.847 35.670865085293656 139.7389189979248 36.847 35.670865085293656 139.7389189979248 36.296 35.67086477673106 139.73891632507727 36.296</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ea3a8f56-56f0-4c39-b49e-d3f9dfa1025b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ea3a8f56-56f0-4c39-b49e-d3f9dfa1025b_0">
											<gml:posList>35.67087025847067 139.7389640939853 36.847 35.67087025847067 139.7389640939853 36.296 35.670865085293656 139.7389189979248 36.296 35.670865085293656 139.7389189979248 36.847 35.67087025847067 139.7389640939853 36.847</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_d73d866b-736b-48d2-a70a-dbb82f953a03_BuildingInstallation_1041">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f3a0bfff-fe94-4c6e-828b-122dd6dd3caf">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67086560694673 139.73897503532316 36.296 35.67087165042774 139.73901501591445 36.296 35.67085154437093 139.73901957960624 36.296 35.67084550089143 139.73897959902467 36.296 35.67086560694673 139.73897503532316 36.296</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3dcabe38-2c13-4c8f-aa8f-653b13411aa9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3dcabe38-2c13-4c8f-aa8f-653b13411aa9_0">
											<gml:posList>35.67084550089143 139.73897959902467 36.296 35.67084550089143 139.73897959902467 39.085 35.67086560694673 139.73897503532316 39.085 35.67086560694673 139.73897503532316 36.296 35.67084550089143 139.73897959902467 36.296</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5bc76a83-0fe1-4af5-ae11-5582d85b3a6f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5bc76a83-0fe1-4af5-ae11-5582d85b3a6f_0">
											<gml:posList>35.67086560694673 139.73897503532316 36.296 35.67086560694673 139.73897503532316 39.085 35.67087165042774 139.73901501591445 39.085 35.67087165042774 139.73901501591445 36.296 35.67086560694673 139.73897503532316 36.296</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-da0b6e24-4cd9-4437-9a0d-20d2e66cb3f5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-da0b6e24-4cd9-4437-9a0d-20d2e66cb3f5_0">
											<gml:posList>35.67086560694673 139.73897503532316 39.085 35.67084550089143 139.73897959902467 39.085 35.67085154437093 139.73901957960624 39.085 35.67087165042774 139.73901501591445 39.085 35.67086560694673 139.73897503532316 39.085</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c14213b1-36f8-4131-b6db-aad770de2bee">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c14213b1-36f8-4131-b6db-aad770de2bee_0">
											<gml:posList>35.67085154437093 139.73901957960624 36.296 35.67085154437093 139.73901957960624 39.085 35.67084550089143 139.73897959902467 39.085 35.67084550089143 139.73897959902467 36.296 35.67085154437093 139.73901957960624 36.296</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-07b5b984-4828-481e-b265-dc366facadab">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-07b5b984-4828-481e-b265-dc366facadab_0">
											<gml:posList>35.67087165042774 139.73901501591445 36.296 35.67087165042774 139.73901501591445 39.085 35.67085154437093 139.73901957960624 39.085 35.67085154437093 139.73901957960624 36.296 35.67087165042774 139.73901501591445 36.296</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-982dcf0f-ed3c-49f0-ab94-c014a99b0516">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-982dcf0f-ed3c-49f0-ab94-c014a99b0516">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-982dcf0f-ed3c-49f0-ab94-c014a99b0516">
											<gml:posList>35.6707784921686 139.7389672618253 18.24 35.67076764414815 139.73889253524172 18.24 35.670867484631074 139.7388751743225 18.24 35.67087138730239 139.7389093028749 18.24 35.670889232045596 139.73890618888677 18.24 35.670895675780294 139.73896229665564 18.24 35.670881255730414 139.73896474382096 18.24 35.67088887874848 139.73903046050833 18.24 35.670780548433136 139.73904925619735 18.24 35.670771201305655 139.7389688500293 18.24 35.6707784921686 139.7389672618253 18.24</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-08bc1140-f316-420c-86af-21a8c2a82715">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-08bc1140-f316-420c-86af-21a8c2a82715">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-08bc1140-f316-420c-86af-21a8c2a82715">
											<gml:posList>35.670780548433136 139.73904925619735 37.557 35.67079015576307 139.73904758795214 37.557 35.6707784921686 139.7389672618253 37.557 35.670771201305655 139.7389688500293 37.557 35.670780548433136 139.73904925619735 37.557</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-047323fa-a722-4224-a4c4-84d2b7fa3126">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-047323fa-a722-4224-a4c4-84d2b7fa3126">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-047323fa-a722-4224-a4c4-84d2b7fa3126">
											<gml:posList>35.67079015576307 139.73904758795214 39.288 35.670795655846504 139.73903825839298 39.288 35.670775509606074 139.7388995293398 39.288 35.67076764414815 139.73889253524172 39.288 35.67079015576307 139.73904758795214 39.288</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a1f7fb90-3b50-4907-aece-40bd4e6c0566">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a1f7fb90-3b50-4907-aece-40bd4e6c0566">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a1f7fb90-3b50-4907-aece-40bd4e6c0566">
											<gml:posList>35.67076764414815 139.73889253524172 39.288 35.670775509606074 139.7388995293398 39.288 35.67086173220217 139.7388845373374 39.288 35.670867484631074 139.7388751743225 39.288 35.67076764414815 139.73889253524172 39.288</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-6f22b41a-0887-4c8b-81fc-2801ffe3ee3a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6f22b41a-0887-4c8b-81fc-2801ffe3ee3a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6f22b41a-0887-4c8b-81fc-2801ffe3ee3a">
											<gml:posList>35.670795655846504 139.73903825839298 36.296 35.67088123859805 139.73902341089087 36.296 35.670874577454406 139.7389658894531 36.296 35.67087053985253 139.73896659012397 36.296 35.670865076279945 139.73891899793543 36.296 35.67086173220217 139.7388845373374 36.296 35.670775509606074 139.7388995293398 36.296 35.670795655846504 139.73903825839298 36.296</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-fcedaa46-7207-4b29-a084-d8a42157d293">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fcedaa46-7207-4b29-a084-d8a42157d293">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fcedaa46-7207-4b29-a084-d8a42157d293">
											<gml:posList>35.67088887874848 139.73903046050833 39.288 35.67088123859805 139.73902341089087 39.288 35.670795655846504 139.73903825839298 39.288 35.67079015576307 139.73904758795214 39.288 35.67088887874848 139.73903046050833 39.288</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a99257ad-abfd-4e05-b5ff-b14b98bc05fe">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a99257ad-abfd-4e05-b5ff-b14b98bc05fe">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a99257ad-abfd-4e05-b5ff-b14b98bc05fe">
											<gml:posList>35.67087138730239 139.7389093028749 39.288 35.670867484631074 139.7388751743225 39.288 35.67086173220217 139.7388845373374 39.288 35.670865076279945 139.73891899793543 39.288 35.67087138730239 139.7389093028749 39.288</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-500b63ec-fca6-44e7-8088-6321756c335d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-500b63ec-fca6-44e7-8088-6321756c335d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-500b63ec-fca6-44e7-8088-6321756c335d">
											<gml:posList>35.67087053985253 139.73896659012397 43.815 35.67087326753865 139.7389621573363 43.815 35.67086869341528 139.73892235175921 43.815 35.670865076279945 139.73891899793543 43.815 35.67087053985253 139.73896659012397 43.815</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-5c6a0fd8-1e3b-496e-93ec-20b93c39e129">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5c6a0fd8-1e3b-496e-93ec-20b93c39e129">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5c6a0fd8-1e3b-496e-93ec-20b93c39e129">
											<gml:posList>35.670865076279945 139.73891899793543 43.815 35.67086869341528 139.73892235175921 43.815 35.67088746647687 139.73891911517129 43.815 35.670890203166294 139.73891467132412 43.815 35.670865076279945 139.73891899793543 43.815</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ad27034f-09db-4906-b57d-223c665cb471">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ad27034f-09db-4906-b57d-223c665cb471">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ad27034f-09db-4906-b57d-223c665cb471">
											<gml:posList>35.670890203166294 139.73891467132412 39.288 35.670889232045596 139.73890618888677 39.288 35.67087138730239 139.7389093028749 39.288 35.670865076279945 139.73891899793543 39.288 35.670890203166294 139.73891467132412 39.288</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-47daeb36-9692-4d87-a106-64b6f176e743">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-47daeb36-9692-4d87-a106-64b6f176e743">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-47daeb36-9692-4d87-a106-64b6f176e743">
											<gml:posList>35.670892049641004 139.73895895388583 42.736 35.67088746647687 139.73891911517129 42.736 35.67086869341528 139.73892235175921 42.736 35.67087326753865 139.7389621573363 42.736 35.670892049641004 139.73895895388583 42.736</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c322ba9e-0995-4685-a584-1b23138804b4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c322ba9e-0995-4685-a584-1b23138804b4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c322ba9e-0995-4685-a584-1b23138804b4">
											<gml:posList>35.670881255730414 139.73896474382096 39.288 35.670874577454406 139.7389658894531 39.288 35.67088123859805 139.73902341089087 39.288 35.67088887874848 139.73903046050833 39.288 35.670881255730414 139.73896474382096 39.288</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-97490ec8-923a-4933-9bc9-19884dad3118">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-97490ec8-923a-4933-9bc9-19884dad3118">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-97490ec8-923a-4933-9bc9-19884dad3118">
											<gml:posList>35.670895675780294 139.73896229665564 43.815 35.670892049641004 139.73895895388583 43.815 35.67087326753865 139.7389621573363 43.815 35.67087053985253 139.73896659012397 43.815 35.670895675780294 139.73896229665564 43.815</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-352856c1-7e08-414f-b660-765d1690b90d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-352856c1-7e08-414f-b660-765d1690b90d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-352856c1-7e08-414f-b660-765d1690b90d">
											<gml:posList>35.670890203166294 139.73891467132412 43.815 35.67088746647687 139.73891911517129 43.815 35.670892049641004 139.73895895388583 43.815 35.670895675780294 139.73896229665564 43.815 35.670890203166294 139.73891467132412 43.815</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-66d699c7-2b44-4c92-b8a5-b56b3de8321a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-66d699c7-2b44-4c92-b8a5-b56b3de8321a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-66d699c7-2b44-4c92-b8a5-b56b3de8321a">
											<gml:posList>35.6707784921686 139.7389672618253 18.24 35.670771201305655 139.7389688500293 18.24 35.670771201305655 139.7389688500293 37.557 35.6707784921686 139.7389672618253 37.557 35.6707784921686 139.7389672618253 18.24</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ef8edbb2-41ff-40ef-94be-40b16e9a849c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ef8edbb2-41ff-40ef-94be-40b16e9a849c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ef8edbb2-41ff-40ef-94be-40b16e9a849c">
											<gml:posList>35.670771201305655 139.7389688500293 18.24 35.670780548433136 139.73904925619735 18.24 35.670780548433136 139.73904925619735 37.557 35.670771201305655 139.7389688500293 37.557 35.670771201305655 139.7389688500293 18.24</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8dad35d4-bd1e-4c62-946b-8a403cf53dbd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8dad35d4-bd1e-4c62-946b-8a403cf53dbd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8dad35d4-bd1e-4c62-946b-8a403cf53dbd">
											<gml:posList>35.67076764414815 139.73889253524172 39.288 35.67076764414815 139.73889253524172 18.24 35.6707784921686 139.7389672618253 18.24 35.6707784921686 139.7389672618253 37.557 35.67079015576307 139.73904758795214 37.557 35.67079015576307 139.73904758795214 39.288 35.67076764414815 139.73889253524172 39.288</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ef1ddd12-5b52-4324-a634-a8db5971c73d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ef1ddd12-5b52-4324-a634-a8db5971c73d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ef1ddd12-5b52-4324-a634-a8db5971c73d">
											<gml:posList>35.670795655846504 139.73903825839298 39.288 35.670795655846504 139.73903825839298 36.296 35.670775509606074 139.7388995293398 36.296 35.670775509606074 139.7388995293398 39.288 35.670795655846504 139.73903825839298 39.288</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-54677d25-6b79-40a6-b59c-d84f6e580cec">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-54677d25-6b79-40a6-b59c-d84f6e580cec">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-54677d25-6b79-40a6-b59c-d84f6e580cec">
											<gml:posList>35.670867484631074 139.7388751743225 18.24 35.67076764414815 139.73889253524172 18.24 35.67076764414815 139.73889253524172 39.288 35.670867484631074 139.7388751743225 39.288 35.670867484631074 139.7388751743225 18.24</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3731d07d-fd90-4932-8245-79560acf1ae0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3731d07d-fd90-4932-8245-79560acf1ae0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3731d07d-fd90-4932-8245-79560acf1ae0">
											<gml:posList>35.670775509606074 139.7388995293398 39.288 35.670775509606074 139.7388995293398 36.296 35.67086173220217 139.7388845373374 36.296 35.67086173220217 139.7388845373374 39.288 35.670775509606074 139.7388995293398 39.288</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-fa257c3c-fc4d-4a7f-8e97-dca117b2f00a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fa257c3c-fc4d-4a7f-8e97-dca117b2f00a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fa257c3c-fc4d-4a7f-8e97-dca117b2f00a">
											<gml:posList>35.67088887874848 139.73903046050833 18.24 35.67088887874848 139.73903046050833 39.288 35.67079015576307 139.73904758795214 39.288 35.67079015576307 139.73904758795214 37.557 35.670780548433136 139.73904925619735 37.557 35.670780548433136 139.73904925619735 18.24 35.67088887874848 139.73903046050833 18.24</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3f3e2910-b4ab-44bc-aa3a-fb8c5a65b6e6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3f3e2910-b4ab-44bc-aa3a-fb8c5a65b6e6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3f3e2910-b4ab-44bc-aa3a-fb8c5a65b6e6">
											<gml:posList>35.67088123859805 139.73902341089087 39.288 35.67088123859805 139.73902341089087 36.296 35.670795655846504 139.73903825839298 36.296 35.670795655846504 139.73903825839298 39.288 35.67088123859805 139.73902341089087 39.288</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e92d7098-8d28-4e16-b9cc-fb895df39a64">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e92d7098-8d28-4e16-b9cc-fb895df39a64">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e92d7098-8d28-4e16-b9cc-fb895df39a64">
											<gml:posList>35.67086173220217 139.7388845373374 39.288 35.67086173220217 139.7388845373374 36.296 35.670865076279945 139.73891899793543 36.296 35.670865076279945 139.73891899793543 39.288 35.67086173220217 139.7388845373374 39.288</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6477174c-d154-41e4-a413-b3dbe590f20b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6477174c-d154-41e4-a413-b3dbe590f20b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6477174c-d154-41e4-a413-b3dbe590f20b">
											<gml:posList>35.670865076279945 139.73891899793543 39.288 35.670865076279945 139.73891899793543 36.296 35.67087053985253 139.73896659012397 36.296 35.67087053985253 139.73896659012397 39.288 35.670865076279945 139.73891899793543 39.288</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3d2cd4f6-ab4c-4ec7-adb3-28c9b4ebbf38">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3d2cd4f6-ab4c-4ec7-adb3-28c9b4ebbf38">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3d2cd4f6-ab4c-4ec7-adb3-28c9b4ebbf38">
											<gml:posList>35.67087053985253 139.73896659012397 43.815 35.670865076279945 139.73891899793543 43.815 35.670865076279945 139.73891899793543 39.288 35.67087053985253 139.73896659012397 39.288 35.67087053985253 139.73896659012397 43.815</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ff8cbe70-0ba1-44d0-9d40-6ed1695db15a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ff8cbe70-0ba1-44d0-9d40-6ed1695db15a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ff8cbe70-0ba1-44d0-9d40-6ed1695db15a">
											<gml:posList>35.67087138730239 139.7389093028749 18.24 35.670867484631074 139.7388751743225 18.24 35.670867484631074 139.7388751743225 39.288 35.67087138730239 139.7389093028749 39.288 35.67087138730239 139.7389093028749 18.24</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4462729e-1616-4d50-a5b4-0d189dc0a098">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4462729e-1616-4d50-a5b4-0d189dc0a098">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4462729e-1616-4d50-a5b4-0d189dc0a098">
											<gml:posList>35.67087326753865 139.7389621573363 43.815 35.67087326753865 139.7389621573363 42.736 35.67086869341528 139.73892235175921 42.736 35.67086869341528 139.73892235175921 43.815 35.67087326753865 139.7389621573363 43.815</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d424d839-af15-4fdd-be3a-5ae1a0dc82da">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d424d839-af15-4fdd-be3a-5ae1a0dc82da">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d424d839-af15-4fdd-be3a-5ae1a0dc82da">
											<gml:posList>35.67087053985253 139.73896659012397 39.288 35.67087053985253 139.73896659012397 36.296 35.670874577454406 139.7389658894531 36.296 35.670874577454406 139.7389658894531 39.288 35.67087053985253 139.73896659012397 39.288</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c56dcdcd-2725-47b8-b007-dee8466b4b37">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c56dcdcd-2725-47b8-b007-dee8466b4b37">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c56dcdcd-2725-47b8-b007-dee8466b4b37">
											<gml:posList>35.670865076279945 139.73891899793543 43.815 35.670890203166294 139.73891467132412 43.815 35.670890203166294 139.73891467132412 39.288 35.670865076279945 139.73891899793543 39.288 35.670865076279945 139.73891899793543 43.815</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-82d23cc9-432d-4206-b24f-f3681ede27a1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-82d23cc9-432d-4206-b24f-f3681ede27a1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-82d23cc9-432d-4206-b24f-f3681ede27a1">
											<gml:posList>35.670874577454406 139.7389658894531 39.288 35.670874577454406 139.7389658894531 36.296 35.67088123859805 139.73902341089087 36.296 35.67088123859805 139.73902341089087 39.288 35.670874577454406 139.7389658894531 39.288</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a4c166f3-c18b-4813-97a2-0ce18981dca6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a4c166f3-c18b-4813-97a2-0ce18981dca6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a4c166f3-c18b-4813-97a2-0ce18981dca6">
											<gml:posList>35.67086869341528 139.73892235175921 43.815 35.67086869341528 139.73892235175921 42.736 35.67088746647687 139.73891911517129 42.736 35.67088746647687 139.73891911517129 43.815 35.67086869341528 139.73892235175921 43.815</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3ebc7543-68bb-48e4-a139-910e13e5d95c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3ebc7543-68bb-48e4-a139-910e13e5d95c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3ebc7543-68bb-48e4-a139-910e13e5d95c">
											<gml:posList>35.670889232045596 139.73890618888677 18.24 35.67087138730239 139.7389093028749 18.24 35.67087138730239 139.7389093028749 39.288 35.670889232045596 139.73890618888677 39.288 35.670889232045596 139.73890618888677 18.24</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d58e7b1c-55e9-45bb-8fb9-01dddd26ab3e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d58e7b1c-55e9-45bb-8fb9-01dddd26ab3e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d58e7b1c-55e9-45bb-8fb9-01dddd26ab3e">
											<gml:posList>35.670892049641004 139.73895895388583 43.815 35.670892049641004 139.73895895388583 42.736 35.67087326753865 139.7389621573363 42.736 35.67087326753865 139.7389621573363 43.815 35.670892049641004 139.73895895388583 43.815</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e9a402c4-5764-4ce6-86b2-bdd8a6ff39a9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e9a402c4-5764-4ce6-86b2-bdd8a6ff39a9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e9a402c4-5764-4ce6-86b2-bdd8a6ff39a9">
											<gml:posList>35.670895675780294 139.73896229665564 43.815 35.67087053985253 139.73896659012397 43.815 35.67087053985253 139.73896659012397 39.288 35.670874577454406 139.7389658894531 39.288 35.670881255730414 139.73896474382096 39.288 35.670881255730414 139.73896474382096 18.24 35.670895675780294 139.73896229665564 18.24 35.670895675780294 139.73896229665564 43.815</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ea083dca-cede-4065-85b8-0d0ec690e9bb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ea083dca-cede-4065-85b8-0d0ec690e9bb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ea083dca-cede-4065-85b8-0d0ec690e9bb">
											<gml:posList>35.67088887874848 139.73903046050833 18.24 35.670881255730414 139.73896474382096 18.24 35.670881255730414 139.73896474382096 39.288 35.67088887874848 139.73903046050833 39.288 35.67088887874848 139.73903046050833 18.24</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c8d91b82-b454-4ec6-af27-9fcf169f26df">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c8d91b82-b454-4ec6-af27-9fcf169f26df">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c8d91b82-b454-4ec6-af27-9fcf169f26df">
											<gml:posList>35.67088746647687 139.73891911517129 43.815 35.67088746647687 139.73891911517129 42.736 35.670892049641004 139.73895895388583 42.736 35.670892049641004 139.73895895388583 43.815 35.67088746647687 139.73891911517129 43.815</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6792727e-e0de-46c7-99ae-c01020f10747">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6792727e-e0de-46c7-99ae-c01020f10747">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6792727e-e0de-46c7-99ae-c01020f10747">
											<gml:posList>35.670890203166294 139.73891467132412 39.288 35.670890203166294 139.73891467132412 43.815 35.670895675780294 139.73896229665564 43.815 35.670895675780294 139.73896229665564 18.24 35.670889232045596 139.73890618888677 18.24 35.670889232045596 139.73890618888677 39.288 35.670890203166294 139.73891467132412 39.288</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-1643</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">187.99555</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1210</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>4</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>