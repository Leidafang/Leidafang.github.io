<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_d84cd302-70f8-405d-ba78-ede83c96e6e1">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>18</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103018001</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="再開発等促進区を定める地区計画">
				<gen:value>虎ノ門駅南地区</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">401</bldg:usage>
			<bldg:measuredHeight uom="m">55.4</bldg:measuredHeight>
			<bldg:storeysAboveGround>12</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.66920591643382 139.74924024956832 0 35.669458029718136 139.74936823075967 0 35.66955904498514 139.7490691057723 0 35.6693137677288 139.74892101423984 0 35.66920591643382 139.74924024956832 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66920591643382 139.74924024956832 6.2 35.6693137677288 139.74892101423984 6.2 35.66955904498514 139.7490691057723 6.2 35.669458029718136 139.74936823075967 6.2 35.66920591643382 139.74924024956832 6.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66920591643382 139.74924024956832 6.2 35.669458029718136 139.74936823075967 6.2 35.669458029718136 139.74936823075967 59.12 35.66920591643382 139.74924024956832 59.12 35.66920591643382 139.74924024956832 6.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669458029718136 139.74936823075967 6.2 35.66955904498514 139.7490691057723 6.2 35.66955904498514 139.7490691057723 59.12 35.669458029718136 139.74936823075967 59.12 35.669458029718136 139.74936823075967 6.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66955904498514 139.7490691057723 6.2 35.6693137677288 139.74892101423984 6.2 35.6693137677288 139.74892101423984 59.12 35.66955904498514 139.7490691057723 59.12 35.66955904498514 139.7490691057723 6.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6693137677288 139.74892101423984 6.2 35.66920591643382 139.74924024956832 6.2 35.66920591643382 139.74924024956832 59.12 35.6693137677288 139.74892101423984 59.12 35.6693137677288 139.74892101423984 6.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66920591643382 139.74924024956832 59.12 35.669458029718136 139.74936823075967 59.12 35.66955904498514 139.7490691057723 59.12 35.6693137677288 139.74892101423984 59.12 35.66920591643382 139.74924024956832 59.12</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-63e7eab5-3785-4c4d-bb46-43c730de47c5"/>
							<gml:surfaceMember xlink:href="#poly-116dad98-063d-4664-8cd6-898dcc5b35e8"/>
							<gml:surfaceMember xlink:href="#poly-ada7119a-34c6-4d07-ac1a-f3c591cdfcbc"/>
							<gml:surfaceMember xlink:href="#poly-c912dbc1-cb08-4c6c-aef5-d321b4ebdcb5"/>
							<gml:surfaceMember xlink:href="#poly-cacb604c-2294-48fe-821a-03a6b5411752"/>
							<gml:surfaceMember xlink:href="#poly-074d8583-be99-4d42-9eb7-4f9191f2e98b"/>
							<gml:surfaceMember xlink:href="#poly-d8a4ffea-a5a9-465d-a1b3-0562ff6814da"/>
							<gml:surfaceMember xlink:href="#poly-a7179b5c-b964-4cdb-a826-74344bb1c1b5"/>
							<gml:surfaceMember xlink:href="#poly-02c02241-585c-4d98-b01f-bd658be33531"/>
							<gml:surfaceMember xlink:href="#poly-bcd4f9cf-e861-417a-a1dd-90703818d6e2"/>
							<gml:surfaceMember xlink:href="#poly-cd77af56-214e-4342-8c94-0a57d883185e"/>
							<gml:surfaceMember xlink:href="#poly-61eacf3f-3499-442c-abbc-f39c4493a85a"/>
							<gml:surfaceMember xlink:href="#poly-f254387f-65dd-4cf7-8b8e-365871276067"/>
							<gml:surfaceMember xlink:href="#poly-251d545c-1ebd-4368-9454-fb2a8770797c"/>
							<gml:surfaceMember xlink:href="#poly-bfc1e8ab-98a0-43e4-b542-e1f526ca40aa"/>
							<gml:surfaceMember xlink:href="#poly-e59d8517-21df-4618-b5e8-9b5c7591d7a5"/>
							<gml:surfaceMember xlink:href="#poly-2ff77a81-271f-44ce-9cfa-06ad6c77eb0e"/>
							<gml:surfaceMember xlink:href="#poly-ed64f0f9-ad29-4f87-8b93-453911ee2f30"/>
							<gml:surfaceMember xlink:href="#poly-aa8e533f-af31-4862-b030-78cf9647d526"/>
							<gml:surfaceMember xlink:href="#poly-37178d49-a23f-4c9b-9343-db21f4cedbb5"/>
							<gml:surfaceMember xlink:href="#poly-7c760f7c-7d27-4765-a019-9257c186724d"/>
							<gml:surfaceMember xlink:href="#poly-2b7a619e-88b1-4ff8-ac82-1b0935b3c2e8"/>
							<gml:surfaceMember xlink:href="#poly-4e749917-693b-4dca-9fae-72144f2bca61"/>
							<gml:surfaceMember xlink:href="#poly-bae159ca-8527-495e-917c-6fa058cef41d"/>
							<gml:surfaceMember xlink:href="#poly-0c87039c-e1ed-49df-be10-9d1ee3949620"/>
							<gml:surfaceMember xlink:href="#poly-3ad4321e-e3b5-40fd-a435-90da19ba36c4"/>
							<gml:surfaceMember xlink:href="#poly-ad58c2fa-4f8b-4815-8bc5-fbe367202e80"/>
							<gml:surfaceMember xlink:href="#poly-b7410914-e18b-4f55-a337-ce6a057f5033"/>
							<gml:surfaceMember xlink:href="#poly-8b5128a2-58a7-4a4f-b1c1-b659fc26e5e7"/>
							<gml:surfaceMember xlink:href="#poly-b0a29c61-1a90-45ed-90f6-00554092fbd3"/>
							<gml:surfaceMember xlink:href="#poly-b0ac6d4c-3402-4025-bd7d-5df04aa38f37"/>
							<gml:surfaceMember xlink:href="#poly-8a8a3288-cd04-4506-989d-59aabd667d2a"/>
							<gml:surfaceMember xlink:href="#poly-95e5b632-25b5-4bea-8a9f-c1770f366c0a"/>
							<gml:surfaceMember xlink:href="#poly-43a8aadd-086e-4219-9f59-d52f3489d6ca"/>
							<gml:surfaceMember xlink:href="#poly-1ddcad06-5040-4894-bfa7-2608f196dbb0"/>
							<gml:surfaceMember xlink:href="#poly-2fe49fcf-c3ef-4c6b-aeb1-5e5a572bbe0a"/>
							<gml:surfaceMember xlink:href="#poly-e45fed11-9191-43c0-a434-5f1154375168"/>
							<gml:surfaceMember xlink:href="#poly-44ad5d2f-d9ad-4a3c-8268-dfc7a631c220"/>
							<gml:surfaceMember xlink:href="#poly-0712c038-a6db-4f1d-9812-50387d250607"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_d84cd302-70f8-405d-ba78-ede83c96e6e1_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f3677955-d2f6-4237-a47d-cf92d3e4d054">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6693100781086 139.74923878165237 56.644 35.669326209450645 139.7492470493199 56.644 35.66931922008441 139.7492675361453 56.644 35.66930307972231 139.7492592574377 56.644 35.6693100781086 139.74923878165237 56.644</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9a4ee598-20c7-4863-b3e0-6be6a03e0056">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66932043263099 139.74920974160406 56.644 35.669336572996436 139.7492180203035 56.644 35.66932957461372 139.7492384960974 56.644 35.6693134432711 139.74923022843123 56.644 35.66932043263099 139.74920974160406 56.644</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fcb85983-8229-4160-bf2c-46a079615f15">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66932443377436 139.74911810988365 56.644 35.66938590243737 139.74914963723452 56.644 35.66937741984338 139.74917446677702 56.644 35.66933201040236 139.7491511739967 56.644 35.669321404899314 139.74918220262074 56.644 35.669308059790204 139.74917535699078 56.644 35.66931865627778 139.74914432838045 56.644 35.66931996058817 139.7491404940093 56.644 35.6693172554971 139.7491391050394 56.644 35.66932443377436 139.74911810988365 56.644</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b256992a-7097-42da-ad3b-1818d3df1a56">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66932014590799 139.74927673658777 56.644 35.66935323752874 139.74917665719852 56.644 35.66937405746382 139.74918699660824 56.644 35.66934095682088 139.74928707602874 56.644 35.66932014590799 139.74927673658777 56.644</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e74c0453-ed9f-4d17-b6ac-3ce622e95029">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669375415967416 139.74922202243494 56.644 35.66938314350853 139.7492259909328 56.644 35.66935883798653 139.7492970098392 56.644 35.669351092443385 139.74929307449293 56.644 35.669375415967416 139.74922202243494 56.644</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f768579a-4cf3-48b5-9297-90bd5b6b64f6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66935883798653 139.7492970098392 56.644 35.66938314350853 139.7492259909328 56.644 35.66938314350853 139.7492259909328 63.046 35.66935883798653 139.7492970098392 63.046 35.66935883798653 139.7492970098392 56.644</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7e1241c4-8a78-4060-960c-44ba49ca33df">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66938848222688 139.74922969683018 56.644 35.66939631797101 139.74923372044657 56.644 35.6693723092731 139.74930384431542 56.644 35.66936446454838 139.74929986488726 56.644 35.66938848222688 139.74922969683018 56.644</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0444d85c-8401-463c-8f74-b1f89220617d">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6693723092731 139.74930384431542 63.046 35.6693723092731 139.74930384431542 56.644 35.66939631797101 139.74923372044657 56.644 35.66939631797101 139.74923372044657 63.046 35.6693723092731 139.74930384431542 63.046</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4805949d-547c-43f2-aa88-cc99870ce44f">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66939942835463 139.74923464505866 56.644 35.66940711982497 139.7492385915045 56.644 35.66938293121973 139.7493092457838 56.644 35.66937523076106 139.74930533248013 56.644 35.66939942835463 139.74923464505866 56.644</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ee7fe47c-4954-49a3-a92f-8081ae940d53">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66941111067083 139.749222482066 56.644 35.669409005779585 139.7492286701049 56.644 35.669379204758386 139.74921344666944 56.644 35.66938130964886 139.74920725863242 56.644 35.66941111067083 139.749222482066 56.644</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d0c66bbd-fb90-4496-ad3b-5d7843e24d55">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66941322168566 139.74923796652166 56.644 35.66942030902793 139.74924161535665 56.644 35.66939504996876 139.74931539682163 56.644 35.669387953645796 139.74931179217518 56.644 35.66941322168566 139.74923796652166 56.644</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-99bdc63e-8cb4-4905-a5ff-110fd63a1182">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66932757703919 139.74908872391563 56.644 35.66945775408497 139.74915419012518 56.644 35.66948459499329 139.74907402222246 56.644 35.66952732611187 139.74909551729579 56.644 35.66952633664977 139.74909844556313 56.644 35.66948698687701 139.74907865908654 56.644 35.669460163939014 139.74915874964827 56.644 35.669328706490674 139.7490926330538 56.644 35.66931374789859 139.74913730820612 56.644 35.6693116649786 139.74913623892036 56.644 35.6692908447995 139.74912555710267 56.644 35.66930669388354 139.74907821891213 56.644 35.66932757703919 139.74908872391563 56.644</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-46b061e9-fd9c-4ba1-8941-d090cd7829a1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669418061362016 139.74927569501804 56.644 35.66941141591699 139.74927236605453 56.644 35.66942487230637 139.74923204462334 56.644 35.66943150873106 139.74923536254738 56.644 35.669418061362016 139.74927569501804 56.644</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1f7cd420-4217-4cd2-9134-13addfd30bb4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66951040249152 139.74910147789942 56.644 35.66949342028744 139.74915256203627 56.644 35.669482446744624 139.74914708362743 56.644 35.66949942894642 139.74909599949646 56.644 35.66951040249152 139.74910147789942 56.644</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b3230f36-d25a-45fc-9889-13061f38be08">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b3230f36-d25a-45fc-9889-13061f38be08_0">
											<gml:posList>35.66932443377436 139.74911810988365 56.644 35.6693172554971 139.7491391050394 56.644 35.6693172554971 139.7491391050394 58.927 35.66932443377436 139.74911810988365 58.927 35.66932443377436 139.74911810988365 56.644</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e2e8aa23-2858-473a-8da2-34ebad9c7f85">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e2e8aa23-2858-473a-8da2-34ebad9c7f85_0">
											<gml:posList>35.66931865627778 139.74914432838045 58.927 35.66931865627778 139.74914432838045 59.376 35.66933201040236 139.7491511739967 59.376 35.66933201040236 139.7491511739967 58.927 35.66931865627778 139.74914432838045 58.927</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-61c0adc4-5704-4c30-bc87-1919e3fe1818">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-61c0adc4-5704-4c30-bc87-1919e3fe1818_0">
											<gml:posList>35.66938590243737 139.74914963723452 56.644 35.66932443377436 139.74911810988365 56.644 35.66932443377436 139.74911810988365 58.927 35.66938590243737 139.74914963723452 58.927 35.66938590243737 139.74914963723452 56.644</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-540d5728-1946-4e98-9c3e-795defe75742">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-540d5728-1946-4e98-9c3e-795defe75742_0">
											<gml:posList>35.66936446454838 139.74929986488726 63.046 35.66938848222688 139.74922969683018 63.046 35.66938848222688 139.74922969683018 56.644 35.66936446454838 139.74929986488726 56.644 35.66936446454838 139.74929986488726 63.046</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3d39832f-315f-4c9f-85ca-3f7656b2cd91">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3d39832f-315f-4c9f-85ca-3f7656b2cd91_0">
											<gml:posList>35.66937523076106 139.74930533248013 63.046 35.66939942835463 139.74923464505866 63.046 35.66939942835463 139.74923464505866 56.644 35.66937523076106 139.74930533248013 56.644 35.66937523076106 139.74930533248013 63.046</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-57f61a0c-2ad1-446f-9810-5ac2a6742f6a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-57f61a0c-2ad1-446f-9810-5ac2a6742f6a_0">
											<gml:posList>35.66938293121973 139.7493092457838 63.046 35.66938293121973 139.7493092457838 56.644 35.66940711982497 139.7492385915045 56.644 35.66940711982497 139.7492385915045 63.046 35.66938293121973 139.7493092457838 63.046</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3b918f57-1142-4124-99af-484c68146b09">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3b918f57-1142-4124-99af-484c68146b09_0">
											<gml:posList>35.669482446744624 139.74914708362743 56.644 35.669482446744624 139.74914708362743 60.362 35.66949942894642 139.74909599949646 60.362 35.66949942894642 139.74909599949646 56.644 35.669482446744624 139.74914708362743 56.644</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8c3d053c-4ff9-41b3-8aa4-193adbd175a0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8c3d053c-4ff9-41b3-8aa4-193adbd175a0_0">
											<gml:posList>35.66951040249152 139.74910147789942 56.644 35.66949942894642 139.74909599949646 56.644 35.66949942894642 139.74909599949646 60.362 35.66951040249152 139.74910147789942 60.362 35.66951040249152 139.74910147789942 56.644</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c6bdd859-dabd-4974-b5ff-561e5a5c8cfb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c6bdd859-dabd-4974-b5ff-561e5a5c8cfb_0">
											<gml:posList>35.66930669388354 139.74907821891213 56.644 35.6692908447995 139.74912555710267 56.644 35.6692908447995 139.74912555710267 60.301 35.66930669388354 139.74907821891213 60.301 35.66930669388354 139.74907821891213 56.644</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8cfb5d89-bf09-466b-ae2f-77b0a9516e19">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8cfb5d89-bf09-466b-ae2f-77b0a9516e19_0">
											<gml:posList>35.6693116649786 139.74913623892036 56.644 35.6693116649786 139.74913623892036 60.301 35.6692908447995 139.74912555710267 60.301 35.6692908447995 139.74912555710267 56.644 35.6693116649786 139.74913623892036 56.644</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8ae78dae-029b-4625-a73a-14d3eabbccb7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8ae78dae-029b-4625-a73a-14d3eabbccb7_0">
											<gml:posList>35.6693100781086 139.74923878165237 56.644 35.66930307972231 139.7492592574377 56.644 35.66930307972231 139.7492592574377 60.426 35.6693100781086 139.74923878165237 60.426 35.6693100781086 139.74923878165237 56.644</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-57f9bb3d-efc6-4a14-adda-83ed2e03b89c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-57f9bb3d-efc6-4a14-adda-83ed2e03b89c_0">
											<gml:posList>35.66932757703919 139.74908872391563 60.301 35.66930669388354 139.74907821891213 60.301 35.6692908447995 139.74912555710267 60.301 35.6693116649786 139.74913623892036 60.301 35.66932757703919 139.74908872391563 60.301</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-81ed9136-d612-433e-b79e-595002faccd8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-81ed9136-d612-433e-b79e-595002faccd8_0">
											<gml:posList>35.66930307972231 139.7492592574377 56.644 35.66931922008441 139.7492675361453 56.644 35.66931922008441 139.7492675361453 60.426 35.66930307972231 139.7492592574377 60.426 35.66930307972231 139.7492592574377 56.644</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c4486ea7-2b1e-43ae-9bac-60be79702831">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c4486ea7-2b1e-43ae-9bac-60be79702831_0">
											<gml:posList>35.6693116649786 139.74913623892036 60.301 35.6693116649786 139.74913623892036 56.644 35.66931374789859 139.74913730820612 56.644 35.66931374789859 139.74913730820612 61.581 35.6693116649786 139.74913623892036 61.581 35.6693116649786 139.74913623892036 60.301</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bcc0e133-7630-4966-967f-dff1a506c26a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bcc0e133-7630-4966-967f-dff1a506c26a_0">
											<gml:posList>35.66931865627778 139.74914432838045 58.927 35.66931865627778 139.74914432838045 56.644 35.669308059790204 139.74917535699078 56.644 35.669308059790204 139.74917535699078 59.376 35.66931865627778 139.74914432838045 59.376 35.66931865627778 139.74914432838045 58.927</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9d1bdc64-98b0-4651-b0ee-a7159286eb87">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9d1bdc64-98b0-4651-b0ee-a7159286eb87_0">
											<gml:posList>35.66931922008441 139.7492675361453 60.426 35.669326209450645 139.7492470493199 60.426 35.6693100781086 139.74923878165237 60.426 35.66930307972231 139.7492592574377 60.426 35.66931922008441 139.7492675361453 60.426</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bb5dd2dc-89f8-461b-8155-145f809c884e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bb5dd2dc-89f8-461b-8155-145f809c884e_0">
											<gml:posList>35.669308059790204 139.74917535699078 56.644 35.669321404899314 139.74918220262074 56.644 35.669321404899314 139.74918220262074 59.376 35.669308059790204 139.74917535699078 59.376 35.669308059790204 139.74917535699078 56.644</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-24112519-7e43-4b63-9906-f56ac051a93e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-24112519-7e43-4b63-9906-f56ac051a93e_0">
											<gml:posList>35.66932043263099 139.74920974160406 56.644 35.6693134432711 139.74923022843123 56.644 35.6693134432711 139.74923022843123 60.426 35.66932043263099 139.74920974160406 60.426 35.66932043263099 139.74920974160406 56.644</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-495117d9-7bee-415f-b0ea-632f9dddca99">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-495117d9-7bee-415f-b0ea-632f9dddca99_0">
											<gml:posList>35.66932757703919 139.74908872391563 56.644 35.66930669388354 139.74907821891213 56.644 35.66930669388354 139.74907821891213 60.301 35.66932757703919 139.74908872391563 60.301 35.66932757703919 139.74908872391563 56.644</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cec0ac14-1393-48b9-8719-f9159def7c53">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cec0ac14-1393-48b9-8719-f9159def7c53_0">
											<gml:posList>35.6693100781086 139.74923878165237 56.644 35.6693100781086 139.74923878165237 60.426 35.669326209450645 139.7492470493199 60.426 35.669326209450645 139.7492470493199 56.644 35.6693100781086 139.74923878165237 56.644</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3dbf468b-fc75-492c-9714-d7b9240e452c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3dbf468b-fc75-492c-9714-d7b9240e452c_0">
											<gml:posList>35.6693172554971 139.7491391050394 56.644 35.66931996058817 139.7491404940093 56.644 35.66931996058817 139.7491404940093 58.927 35.6693172554971 139.7491391050394 58.927 35.6693172554971 139.7491391050394 56.644</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-76ae7cda-0c8e-483a-b5af-c2ddf10d56b1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-76ae7cda-0c8e-483a-b5af-c2ddf10d56b1_0">
											<gml:posList>35.66931996058817 139.7491404940093 56.644 35.66931865627778 139.74914432838045 56.644 35.66931865627778 139.74914432838045 58.927 35.66931996058817 139.7491404940093 58.927 35.66931996058817 139.7491404940093 56.644</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6fd089bc-2f68-42f9-95c8-5cf0533b8e84">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6fd089bc-2f68-42f9-95c8-5cf0533b8e84_0">
											<gml:posList>35.6693116649786 139.74913623892036 60.301 35.6693116649786 139.74913623892036 61.581 35.66932757703919 139.74908872391563 61.581 35.66932757703919 139.74908872391563 60.301 35.6693116649786 139.74913623892036 60.301</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9dd4d185-c748-41cc-871c-160c03051786">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9dd4d185-c748-41cc-871c-160c03051786_0">
											<gml:posList>35.66933201040236 139.7491511739967 59.376 35.66931865627778 139.74914432838045 59.376 35.669308059790204 139.74917535699078 59.376 35.669321404899314 139.74918220262074 59.376 35.66933201040236 139.7491511739967 59.376</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-dbd575b8-d5f2-4990-a5ae-97de6b73c5e5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-dbd575b8-d5f2-4990-a5ae-97de6b73c5e5_0">
											<gml:posList>35.66931374789859 139.74913730820612 56.644 35.669328706490674 139.7490926330538 56.644 35.669328706490674 139.7490926330538 61.581 35.66931374789859 139.74913730820612 61.581 35.66931374789859 139.74913730820612 56.644</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-14098409-4f5f-42da-be00-938643a4be6b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-14098409-4f5f-42da-be00-938643a4be6b_0">
											<gml:posList>35.6693134432711 139.74923022843123 56.644 35.66932957461372 139.7492384960974 56.644 35.66932957461372 139.7492384960974 60.426 35.6693134432711 139.74923022843123 60.426 35.6693134432711 139.74923022843123 56.644</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-56f10d96-db59-4050-a57c-1ca1d121e3c1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-56f10d96-db59-4050-a57c-1ca1d121e3c1_0">
											<gml:posList>35.66931922008441 139.7492675361453 56.644 35.669326209450645 139.7492470493199 56.644 35.669326209450645 139.7492470493199 60.426 35.66931922008441 139.7492675361453 60.426 35.66931922008441 139.7492675361453 56.644</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-18ec17b0-5887-462d-92ef-777ff7bb1dca">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-18ec17b0-5887-462d-92ef-777ff7bb1dca_0">
											<gml:posList>35.66932957461372 139.7492384960974 60.426 35.669336572996436 139.7492180203035 60.426 35.66932043263099 139.74920974160406 60.426 35.6693134432711 139.74923022843123 60.426 35.66932957461372 139.7492384960974 60.426</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bdafd3bf-8296-42c2-9dd5-18803b2e1890">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bdafd3bf-8296-42c2-9dd5-18803b2e1890_0">
											<gml:posList>35.669321404899314 139.74918220262074 59.376 35.669321404899314 139.74918220262074 56.644 35.66933201040236 139.7491511739967 56.644 35.66933201040236 139.7491511739967 58.927 35.66933201040236 139.7491511739967 59.376 35.669321404899314 139.74918220262074 59.376</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f22d279e-db0d-4e96-ac70-518ef4ae1df2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f22d279e-db0d-4e96-ac70-518ef4ae1df2_0">
											<gml:posList>35.66932043263099 139.74920974160406 56.644 35.66932043263099 139.74920974160406 60.426 35.669336572996436 139.7492180203035 60.426 35.669336572996436 139.7492180203035 56.644 35.66932043263099 139.74920974160406 56.644</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7086ac2f-0de9-4979-8a7d-65da61e6af02">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7086ac2f-0de9-4979-8a7d-65da61e6af02_0">
											<gml:posList>35.66932014590799 139.74927673658777 56.644 35.66934095682088 139.74928707602874 56.644 35.66934095682088 139.74928707602874 59.455 35.66932014590799 139.74927673658777 59.455 35.66932014590799 139.74927673658777 56.644</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bbf729d1-d9ac-4aba-b819-0173381103df">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bbf729d1-d9ac-4aba-b819-0173381103df_0">
											<gml:posList>35.66932957461372 139.7492384960974 56.644 35.669336572996436 139.7492180203035 56.644 35.669336572996436 139.7492180203035 60.426 35.66932957461372 139.7492384960974 60.426 35.66932957461372 139.7492384960974 56.644</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cce03bc3-62d1-404b-a9d7-b0849d0000a9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cce03bc3-62d1-404b-a9d7-b0849d0000a9_0">
											<gml:posList>35.66932014590799 139.74927673658777 56.644 35.66932014590799 139.74927673658777 59.455 35.66935323752874 139.74917665719852 59.455 35.66935323752874 139.74917665719852 56.644 35.66932014590799 139.74927673658777 56.644</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e33c5701-cf29-4a0d-91de-12c68fd2a1a3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e33c5701-cf29-4a0d-91de-12c68fd2a1a3_0">
											<gml:posList>35.66937405746382 139.74918699660824 59.455 35.66935323752874 139.74917665719852 59.455 35.66932014590799 139.74927673658777 59.455 35.66934095682088 139.74928707602874 59.455 35.66937405746382 139.74918699660824 59.455</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-20e2fe92-bdd2-4f98-ac55-b1816b46d065">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-20e2fe92-bdd2-4f98-ac55-b1816b46d065_0">
											<gml:posList>35.66931996058817 139.7491404940093 58.927 35.66931865627778 139.74914432838045 58.927 35.66933201040236 139.7491511739967 58.927 35.66937741984338 139.74917446677702 58.927 35.66938590243737 139.74914963723452 58.927 35.66932443377436 139.74911810988365 58.927 35.6693172554971 139.7491391050394 58.927 35.66931996058817 139.7491404940093 58.927</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f9086ff1-4f97-467e-9b65-229742f91e1b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f9086ff1-4f97-467e-9b65-229742f91e1b_0">
											<gml:posList>35.66937741984338 139.74917446677702 56.644 35.66937741984338 139.74917446677702 58.927 35.66933201040236 139.7491511739967 58.927 35.66933201040236 139.7491511739967 56.644 35.66937741984338 139.74917446677702 56.644</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1a47e6de-76bf-4013-a165-e990abda73c9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1a47e6de-76bf-4013-a165-e990abda73c9_0">
											<gml:posList>35.66935883798653 139.7492970098392 63.046 35.669351092443385 139.74929307449293 63.046 35.669351092443385 139.74929307449293 56.644 35.66935883798653 139.7492970098392 56.644 35.66935883798653 139.7492970098392 63.046</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b13c56ca-5181-4114-bdbd-59e15a9bfee5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b13c56ca-5181-4114-bdbd-59e15a9bfee5_0">
											<gml:posList>35.66937405746382 139.74918699660824 56.644 35.66937405746382 139.74918699660824 59.455 35.66934095682088 139.74928707602874 59.455 35.66934095682088 139.74928707602874 56.644 35.66937405746382 139.74918699660824 56.644</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e58dc415-6e9f-40e8-b27d-b0718d55a072">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e58dc415-6e9f-40e8-b27d-b0718d55a072_0">
											<gml:posList>35.669351092443385 139.74929307449293 63.046 35.669375415967416 139.74922202243494 63.046 35.669375415967416 139.74922202243494 56.644 35.669351092443385 139.74929307449293 56.644 35.669351092443385 139.74929307449293 63.046</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-018d873d-1f1a-4d2f-8db1-94e009067ec8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-018d873d-1f1a-4d2f-8db1-94e009067ec8_0">
											<gml:posList>35.66937405746382 139.74918699660824 56.644 35.66935323752874 139.74917665719852 56.644 35.66935323752874 139.74917665719852 59.455 35.66937405746382 139.74918699660824 59.455 35.66937405746382 139.74918699660824 56.644</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4ef11f63-96d7-4582-94f2-a309506f5ea6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4ef11f63-96d7-4582-94f2-a309506f5ea6_0">
											<gml:posList>35.66935883798653 139.7492970098392 63.046 35.66938314350853 139.7492259909328 63.046 35.669375415967416 139.74922202243494 63.046 35.669351092443385 139.74929307449293 63.046 35.66935883798653 139.7492970098392 63.046</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f43f6447-b1b5-4939-898a-e56cafb8fde9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f43f6447-b1b5-4939-898a-e56cafb8fde9_0">
											<gml:posList>35.66936446454838 139.74929986488726 56.644 35.6693723092731 139.74930384431542 56.644 35.6693723092731 139.74930384431542 63.046 35.66936446454838 139.74929986488726 63.046 35.66936446454838 139.74929986488726 56.644</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0f775e19-4fec-4072-9fd9-7d424253f088">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0f775e19-4fec-4072-9fd9-7d424253f088_0">
											<gml:posList>35.66938293121973 139.7493092457838 63.046 35.66937523076106 139.74930533248013 63.046 35.66937523076106 139.74930533248013 56.644 35.66938293121973 139.7493092457838 56.644 35.66938293121973 139.7493092457838 63.046</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ae273645-dfa6-4c5d-9de9-9a434dd2c144">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ae273645-dfa6-4c5d-9de9-9a434dd2c144_0">
											<gml:posList>35.66938314350853 139.7492259909328 56.644 35.669375415967416 139.74922202243494 56.644 35.669375415967416 139.74922202243494 63.046 35.66938314350853 139.7492259909328 63.046 35.66938314350853 139.7492259909328 56.644</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a2f4f2c7-9890-49bb-bc50-8e03b6ce6c79">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a2f4f2c7-9890-49bb-bc50-8e03b6ce6c79_0">
											<gml:posList>35.66938130964886 139.74920725863242 56.644 35.669379204758386 139.74921344666944 56.644 35.669379204758386 139.74921344666944 63.387 35.66938130964886 139.74920725863242 63.387 35.66938130964886 139.74920725863242 56.644</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-da8c200b-f48c-424f-841b-0a0e5a7e4854">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-da8c200b-f48c-424f-841b-0a0e5a7e4854_0">
											<gml:posList>35.6693723092731 139.74930384431542 63.046 35.66939631797101 139.74923372044657 63.046 35.66938848222688 139.74922969683018 63.046 35.66936446454838 139.74929986488726 63.046 35.6693723092731 139.74930384431542 63.046</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c11798f7-d6b7-49b1-8d02-593438f9a84a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c11798f7-d6b7-49b1-8d02-593438f9a84a_0">
											<gml:posList>35.66937741984338 139.74917446677702 56.644 35.66938590243737 139.74914963723452 56.644 35.66938590243737 139.74914963723452 58.927 35.66937741984338 139.74917446677702 58.927 35.66937741984338 139.74917446677702 56.644</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8795b3bc-48a9-4dc2-b46e-6b69e0ee239c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8795b3bc-48a9-4dc2-b46e-6b69e0ee239c_0">
											<gml:posList>35.66938293121973 139.7493092457838 63.046 35.66940711982497 139.7492385915045 63.046 35.66939942835463 139.74923464505866 63.046 35.66937523076106 139.74930533248013 63.046 35.66938293121973 139.7493092457838 63.046</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4d6f57e5-cd03-4f1c-b362-5d51b4ec72f0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4d6f57e5-cd03-4f1c-b362-5d51b4ec72f0_0">
											<gml:posList>35.66939504996876 139.74931539682163 63.046 35.669387953645796 139.74931179217518 63.046 35.669387953645796 139.74931179217518 56.644 35.66939504996876 139.74931539682163 56.644 35.66939504996876 139.74931539682163 63.046</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-34b4cdf2-e934-437b-a2bd-2c696be205b9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-34b4cdf2-e934-437b-a2bd-2c696be205b9_0">
											<gml:posList>35.66938848222688 139.74922969683018 56.644 35.66938848222688 139.74922969683018 63.046 35.66939631797101 139.74923372044657 63.046 35.66939631797101 139.74923372044657 56.644 35.66938848222688 139.74922969683018 56.644</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6c3c8708-9669-4562-8521-bb01aa82ff8e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6c3c8708-9669-4562-8521-bb01aa82ff8e_0">
											<gml:posList>35.66945775408497 139.74915419012518 61.581 35.66945775408497 139.74915419012518 56.644 35.66932757703919 139.74908872391563 56.644 35.66932757703919 139.74908872391563 60.301 35.66932757703919 139.74908872391563 61.581 35.66945775408497 139.74915419012518 61.581</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-32b7db3e-9a7d-4d1b-9530-3c9b903ca952">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-32b7db3e-9a7d-4d1b-9530-3c9b903ca952_0">
											<gml:posList>35.669409005779585 139.7492286701049 56.644 35.669409005779585 139.7492286701049 63.387 35.669379204758386 139.74921344666944 63.387 35.669379204758386 139.74921344666944 56.644 35.669409005779585 139.7492286701049 56.644</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3ed6a026-015b-48a5-a0fd-61d41bbe5d12">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3ed6a026-015b-48a5-a0fd-61d41bbe5d12_0">
											<gml:posList>35.669460163939014 139.74915874964827 61.581 35.669328706490674 139.7490926330538 61.581 35.669328706490674 139.7490926330538 56.644 35.669460163939014 139.74915874964827 56.644 35.669460163939014 139.74915874964827 61.581</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cbefa5ed-53f9-4d30-b1aa-87dd5ccde663">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cbefa5ed-53f9-4d30-b1aa-87dd5ccde663_0">
											<gml:posList>35.669379204758386 139.74921344666944 63.387 35.669409005779585 139.7492286701049 63.387 35.66941111067083 139.749222482066 63.387 35.66938130964886 139.74920725863242 63.387 35.669379204758386 139.74921344666944 63.387</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-42129d06-d997-4701-9fc0-4e9320f4868b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-42129d06-d997-4701-9fc0-4e9320f4868b_0">
											<gml:posList>35.66938130964886 139.74920725863242 56.644 35.66938130964886 139.74920725863242 63.387 35.66941111067083 139.749222482066 63.387 35.66941111067083 139.749222482066 56.644 35.66938130964886 139.74920725863242 56.644</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-067202c5-0025-49dc-acf4-316c332f4493">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-067202c5-0025-49dc-acf4-316c332f4493_0">
											<gml:posList>35.669387953645796 139.74931179217518 63.046 35.66941322168566 139.74923796652166 63.046 35.66941322168566 139.74923796652166 56.644 35.669387953645796 139.74931179217518 56.644 35.669387953645796 139.74931179217518 63.046</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-715e9485-8d22-4e4a-ac14-2ea9256d4a83">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-715e9485-8d22-4e4a-ac14-2ea9256d4a83_0">
											<gml:posList>35.66940711982497 139.7492385915045 56.644 35.66939942835463 139.74923464505866 56.644 35.66939942835463 139.74923464505866 63.046 35.66940711982497 139.7492385915045 63.046 35.66940711982497 139.7492385915045 56.644</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c3cc6af0-e114-4ea9-b703-2689300e49ee">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c3cc6af0-e114-4ea9-b703-2689300e49ee_0">
											<gml:posList>35.66939504996876 139.74931539682163 63.046 35.66942030902793 139.74924161535665 63.046 35.66941322168566 139.74923796652166 63.046 35.669387953645796 139.74931179217518 63.046 35.66939504996876 139.74931539682163 63.046</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-47ab14ee-fdcd-44be-8636-d9ee316aebec">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-47ab14ee-fdcd-44be-8636-d9ee316aebec_0">
											<gml:posList>35.66939504996876 139.74931539682163 56.644 35.66942030902793 139.74924161535665 56.644 35.66942030902793 139.74924161535665 63.046 35.66939504996876 139.74931539682163 63.046 35.66939504996876 139.74931539682163 56.644</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c6ed0425-9ec7-4874-a280-9758e4254ba3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c6ed0425-9ec7-4874-a280-9758e4254ba3_0">
											<gml:posList>35.66941111067083 139.749222482066 56.644 35.66941111067083 139.749222482066 63.387 35.669409005779585 139.7492286701049 63.387 35.669409005779585 139.7492286701049 56.644 35.66941111067083 139.749222482066 56.644</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-52eacf8d-1330-42ad-90df-4fcfdf6a91a5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-52eacf8d-1330-42ad-90df-4fcfdf6a91a5_0">
											<gml:posList>35.669418061362016 139.74927569501804 56.644 35.669418061362016 139.74927569501804 60.362 35.66941141591699 139.74927236605453 60.362 35.66941141591699 139.74927236605453 56.644 35.669418061362016 139.74927569501804 56.644</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6a023325-a234-4979-b52d-f0fe4159b6ff">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6a023325-a234-4979-b52d-f0fe4159b6ff_0">
											<gml:posList>35.66941322168566 139.74923796652166 56.644 35.66941322168566 139.74923796652166 63.046 35.66942030902793 139.74924161535665 63.046 35.66942030902793 139.74924161535665 56.644 35.66941322168566 139.74923796652166 56.644</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-426387a6-cdca-4223-93b3-bb101cdbd65f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-426387a6-cdca-4223-93b3-bb101cdbd65f_0">
											<gml:posList>35.66942487230637 139.74923204462334 56.644 35.66941141591699 139.74927236605453 56.644 35.66941141591699 139.74927236605453 60.362 35.66942487230637 139.74923204462334 60.362 35.66942487230637 139.74923204462334 56.644</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0249da28-99d4-430b-9143-1db2ca8d86cd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0249da28-99d4-430b-9143-1db2ca8d86cd_0">
											<gml:posList>35.669328706490674 139.7490926330538 61.581 35.669460163939014 139.74915874964827 61.581 35.66948698687701 139.74907865908654 61.581 35.66952633664977 139.74909844556313 61.581 35.66952732611187 139.74909551729579 61.581 35.66948459499329 139.74907402222246 61.581 35.66945775408497 139.74915419012518 61.581 35.66932757703919 139.74908872391563 61.581 35.6693116649786 139.74913623892036 61.581 35.66931374789859 139.74913730820612 61.581 35.669328706490674 139.7490926330538 61.581</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-57967d9b-c795-41ef-b600-a736d6a87a23">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-57967d9b-c795-41ef-b600-a736d6a87a23_0">
											<gml:posList>35.66942487230637 139.74923204462334 60.362 35.66941141591699 139.74927236605453 60.362 35.669418061362016 139.74927569501804 60.362 35.66943150873106 139.74923536254738 60.362 35.66942487230637 139.74923204462334 60.362</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7bab49a6-9b55-494b-b1bc-7cdcbfd6f93b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7bab49a6-9b55-494b-b1bc-7cdcbfd6f93b_0">
											<gml:posList>35.669418061362016 139.74927569501804 56.644 35.66943150873106 139.74923536254738 56.644 35.66943150873106 139.74923536254738 60.362 35.669418061362016 139.74927569501804 60.362 35.669418061362016 139.74927569501804 56.644</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-20eb5b26-b747-48d7-857a-64ab7ef9c33f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-20eb5b26-b747-48d7-857a-64ab7ef9c33f_0">
											<gml:posList>35.66943150873106 139.74923536254738 56.644 35.66942487230637 139.74923204462334 56.644 35.66942487230637 139.74923204462334 60.362 35.66943150873106 139.74923536254738 60.362 35.66943150873106 139.74923536254738 56.644</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a26b344f-4adf-4d10-b315-c2e29b48c961">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a26b344f-4adf-4d10-b315-c2e29b48c961_0">
											<gml:posList>35.66945775408497 139.74915419012518 61.581 35.66948459499329 139.74907402222246 61.581 35.66948459499329 139.74907402222246 56.644 35.66945775408497 139.74915419012518 56.644 35.66945775408497 139.74915419012518 61.581</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e27c44ff-77db-4d70-8ead-2fd7807b3931">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e27c44ff-77db-4d70-8ead-2fd7807b3931_0">
											<gml:posList>35.669460163939014 139.74915874964827 56.644 35.66948698687701 139.74907865908654 56.644 35.66948698687701 139.74907865908654 61.581 35.669460163939014 139.74915874964827 61.581 35.669460163939014 139.74915874964827 56.644</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-102e4b57-1319-49a5-910c-c1b9d029b611">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-102e4b57-1319-49a5-910c-c1b9d029b611_0">
											<gml:posList>35.669482446744624 139.74914708362743 56.644 35.66949342028744 139.74915256203627 56.644 35.66949342028744 139.74915256203627 60.362 35.669482446744624 139.74914708362743 60.362 35.669482446744624 139.74914708362743 56.644</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-800f2882-98e5-48eb-93f9-12c1b5c68f58">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-800f2882-98e5-48eb-93f9-12c1b5c68f58_0">
											<gml:posList>35.66951040249152 139.74910147789942 60.362 35.66949942894642 139.74909599949646 60.362 35.669482446744624 139.74914708362743 60.362 35.66949342028744 139.74915256203627 60.362 35.66951040249152 139.74910147789942 60.362</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d5470657-3621-49d9-8445-376253b1ed46">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d5470657-3621-49d9-8445-376253b1ed46_0">
											<gml:posList>35.66949342028744 139.74915256203627 56.644 35.66951040249152 139.74910147789942 56.644 35.66951040249152 139.74910147789942 60.362 35.66949342028744 139.74915256203627 60.362 35.66949342028744 139.74915256203627 56.644</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2a0c7a27-2786-4ac9-b7bc-e9d5fd8845f7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2a0c7a27-2786-4ac9-b7bc-e9d5fd8845f7_0">
											<gml:posList>35.66952732611187 139.74909551729579 56.644 35.66948459499329 139.74907402222246 56.644 35.66948459499329 139.74907402222246 61.581 35.66952732611187 139.74909551729579 61.581 35.66952732611187 139.74909551729579 56.644</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a5c51a01-c99d-4d26-8ea0-9643f72b7fca">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a5c51a01-c99d-4d26-8ea0-9643f72b7fca_0">
											<gml:posList>35.66952633664977 139.74909844556313 61.581 35.66948698687701 139.74907865908654 61.581 35.66948698687701 139.74907865908654 56.644 35.66952633664977 139.74909844556313 56.644 35.66952633664977 139.74909844556313 61.581</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8b757711-1e2b-4243-998a-84f4fe9230d1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8b757711-1e2b-4243-998a-84f4fe9230d1_0">
											<gml:posList>35.66952633664977 139.74909844556313 56.644 35.66952732611187 139.74909551729579 56.644 35.66952732611187 139.74909551729579 61.581 35.66952633664977 139.74909844556313 61.581 35.66952633664977 139.74909844556313 56.644</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_d84cd302-70f8-405d-ba78-ede83c96e6e1_BuildingInstallation_1041">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d54b273a-41c3-476f-884c-90415694a0e3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669407331002475 139.7491925068443 56.644 35.66941512057007 139.7491691471568 56.644 35.6694388169573 139.74918101896571 56.644 35.66943102738743 139.74920437865893 56.644 35.669407331002475 139.7491925068443 56.644</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d7a0bdc9-ea84-46cd-a3f4-88e10a7d8242">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669487892157115 139.74917447233057 56.644 35.66943424654705 139.74933529401363 56.644 35.66941203785595 139.74932401709194 56.644 35.66946564748895 139.74916332803727 56.644 35.669487892157115 139.74917447233057 56.644</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f1ac65a0-22d4-4654-ad10-2acf779461af">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f1ac65a0-22d4-4654-ad10-2acf779461af_0">
											<gml:posList>35.66941512057007 139.7491691471568 56.644 35.669407331002475 139.7491925068443 56.644 35.669407331002475 139.7491925068443 61.507 35.66941512057007 139.7491691471568 61.507 35.66941512057007 139.7491691471568 56.644</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-76da0e15-df98-4cd9-b2f0-d4f3b7e4d57b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-76da0e15-df98-4cd9-b2f0-d4f3b7e4d57b_0">
											<gml:posList>35.669407331002475 139.7491925068443 56.644 35.66943102738743 139.74920437865893 56.644 35.66943102738743 139.74920437865893 61.507 35.669407331002475 139.7491925068443 61.507 35.669407331002475 139.7491925068443 56.644</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-109a2295-7b08-4085-be9d-1640400fb8cb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-109a2295-7b08-4085-be9d-1640400fb8cb_0">
											<gml:posList>35.66943424654705 139.74933529401363 59.171 35.66941203785595 139.74932401709194 59.171 35.66941203785595 139.74932401709194 56.644 35.66943424654705 139.74933529401363 56.644 35.66943424654705 139.74933529401363 59.171</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-066dd838-da18-4cf3-b8d2-2748c4bc6a8c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-066dd838-da18-4cf3-b8d2-2748c4bc6a8c_0">
											<gml:posList>35.669407331002475 139.7491925068443 61.507 35.66943102738743 139.74920437865893 61.507 35.6694388169573 139.74918101896571 61.507 35.66941512057007 139.7491691471568 61.507 35.669407331002475 139.7491925068443 61.507</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4f3b9eff-a175-4130-a1ae-867d856cb6bc">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4f3b9eff-a175-4130-a1ae-867d856cb6bc_0">
											<gml:posList>35.6694388169573 139.74918101896571 56.644 35.66941512057007 139.7491691471568 56.644 35.66941512057007 139.7491691471568 61.507 35.6694388169573 139.74918101896571 61.507 35.6694388169573 139.74918101896571 56.644</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a09c48f3-ea05-4cf7-b1cb-b3f1ae6c1afe">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a09c48f3-ea05-4cf7-b1cb-b3f1ae6c1afe_0">
											<gml:posList>35.66943102738743 139.74920437865893 56.644 35.6694388169573 139.74918101896571 56.644 35.6694388169573 139.74918101896571 61.507 35.66943102738743 139.74920437865893 61.507 35.66943102738743 139.74920437865893 56.644</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d4483252-3b7e-474b-8f3f-206f678bbe6a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d4483252-3b7e-474b-8f3f-206f678bbe6a_0">
											<gml:posList>35.66941203785595 139.74932401709194 56.644 35.66941203785595 139.74932401709194 59.171 35.66946564748895 139.74916332803727 61.282 35.66946564748895 139.74916332803727 56.644 35.66941203785595 139.74932401709194 56.644</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-52f592a9-13f8-4411-8d52-423021d5bf49">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-52f592a9-13f8-4411-8d52-423021d5bf49_0">
											<gml:posList>35.66941203785595 139.74932401709194 59.171 35.66943424654705 139.74933529401363 59.171 35.669487892157115 139.74917447233057 61.282 35.66946564748895 139.74916332803727 61.282 35.66941203785595 139.74932401709194 59.171</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-729295b2-b300-4258-bb89-c55eb410f0ed">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-729295b2-b300-4258-bb89-c55eb410f0ed_0">
											<gml:posList>35.66943424654705 139.74933529401363 59.171 35.66943424654705 139.74933529401363 56.644 35.669487892157115 139.74917447233057 56.644 35.669487892157115 139.74917447233057 61.282 35.66943424654705 139.74933529401363 59.171</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-91f3cdbd-50a9-4759-af87-f8770db9238c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-91f3cdbd-50a9-4759-af87-f8770db9238c_0">
											<gml:posList>35.669487892157115 139.74917447233057 56.644 35.66946564748895 139.74916332803727 56.644 35.66946564748895 139.74916332803727 61.282 35.669487892157115 139.74917447233057 61.282 35.669487892157115 139.74917447233057 56.644</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_d84cd302-70f8-405d-ba78-ede83c96e6e1_BuildingInstallation_1060">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-56e5a97c-0a4e-4609-8c1c-6ec794e86121">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66930121939748 139.7492413425953 56.644 35.66928786527795 139.74923449696664 56.644 35.66930318431633 139.74918962263854 56.644 35.669316538438366 139.74919646826103 56.644 35.66930121939748 139.7492413425953 56.644</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-438919d8-a368-4578-9041-0bb7fff90ec1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-438919d8-a368-4578-9041-0bb7fff90ec1_0">
											<gml:posList>35.669316538438366 139.74919646826103 56.644 35.66930318431633 139.74918962263854 56.644 35.66930318431633 139.74918962263854 64.901 35.669316538438366 139.74919646826103 64.901 35.669316538438366 139.74919646826103 56.644</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-779c4b96-8788-4cc7-948f-df0886196446">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-779c4b96-8788-4cc7-948f-df0886196446_0">
											<gml:posList>35.66931413669741 139.74920351820163 64.901 35.669316538438366 139.74919646826103 64.901 35.66930318431633 139.74918962263854 64.901 35.66930078257577 139.7491966725782 64.901 35.6693072928171 139.7492000016727 64.901 35.66931413669741 139.74920351820163 64.901</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3a0682c3-6246-4f69-815f-6071eaf76de0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3a0682c3-6246-4f69-815f-6071eaf76de0_0">
											<gml:posList>35.66931413669741 139.74920351820163 64.901 35.6693072928171 139.7492000016727 64.901 35.6693072928171 139.7492000016727 61.475 35.66931413669741 139.74920351820163 61.475 35.66931413669741 139.74920351820163 64.901</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7c5e16d1-892d-41e6-a16b-5b2d1a1e4a2f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7c5e16d1-892d-41e6-a16b-5b2d1a1e4a2f_0">
											<gml:posList>35.66930318431633 139.74918962263854 64.901 35.66930318431633 139.74918962263854 56.644 35.66928786527795 139.74923449696664 56.644 35.66928786527795 139.74923449696664 63.132 35.66928983525684 139.74922872883093 63.132 35.66930078257577 139.7491966725782 64.901 35.66930318431633 139.74918962263854 64.901</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f63c6b8a-8048-42ea-aa21-627f695f2d6d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f63c6b8a-8048-42ea-aa21-627f695f2d6d_0">
											<gml:posList>35.6693072928171 139.7492000016727 64.901 35.66930078257577 139.7491966725782 64.901 35.66928983525684 139.74922872883093 63.132 35.66929634550502 139.74923206897373 63.132 35.6693072928171 139.7492000016727 64.901</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-77759aab-6fc8-48e8-8fed-6e18a04e3429">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-77759aab-6fc8-48e8-8fed-6e18a04e3429_0">
											<gml:posList>35.6693072928171 139.7492000016727 64.901 35.66929634550502 139.74923206897373 63.132 35.6693072928171 139.7492000016727 61.475 35.6693072928171 139.7492000016727 64.901</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-73742b28-0e3d-4d7d-b7cf-98a5f4f5c81a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-73742b28-0e3d-4d7d-b7cf-98a5f4f5c81a_0">
											<gml:posList>35.66929634550502 139.74923206897373 63.132 35.66930318937669 139.7492355744588 63.132 35.66931413669741 139.74920351820163 61.475 35.6693072928171 139.7492000016727 61.475 35.66929634550502 139.74923206897373 63.132</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d8464d4f-f037-425a-ad42-aa1f63ee341e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d8464d4f-f037-425a-ad42-aa1f63ee341e_0">
											<gml:posList>35.66931413669741 139.74920351820163 61.475 35.66930318937669 139.7492355744588 63.132 35.66930121939748 139.7492413425953 63.132 35.66930121939748 139.7492413425953 56.644 35.669316538438366 139.74919646826103 56.644 35.669316538438366 139.74919646826103 64.901 35.66931413669741 139.74920351820163 64.901 35.66931413669741 139.74920351820163 61.475</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-20631ba4-1d84-4680-91e4-f9061bf64c4d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-20631ba4-1d84-4680-91e4-f9061bf64c4d_0">
											<gml:posList>35.66928983525684 139.74922872883093 63.132 35.66928786527795 139.74923449696664 63.132 35.66930121939748 139.7492413425953 63.132 35.66930318937669 139.7492355744588 63.132 35.66929634550502 139.74923206897373 63.132 35.66928983525684 139.74922872883093 63.132</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-71afd6c4-9546-4c9c-8763-f4b767d569b0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-71afd6c4-9546-4c9c-8763-f4b767d569b0_0">
											<gml:posList>35.66930121939748 139.7492413425953 56.644 35.66930121939748 139.7492413425953 63.132 35.66928786527795 139.74923449696664 63.132 35.66928786527795 139.74923449696664 56.644 35.66930121939748 139.7492413425953 56.644</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_d84cd302-70f8-405d-ba78-ede83c96e6e1_BuildingInstallation_1031">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d42d06c7-2019-405c-93a7-74dc519cec2f">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669448872191936 139.74917516500852 56.644 35.6693270194005 139.74911622932834 56.644 35.669330176365484 139.7491064281079 56.644 35.66945202916936 139.74916537482162 56.644 35.669448872191936 139.74917516500852 56.644</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f7179faa-394f-4de3-a4ce-97075ce9dda5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66933392965592 139.74917600365072 56.644 35.66934715716192 139.74918224186993 56.644 35.669337920541224 139.74921155691155 56.644 35.669325585673455 139.74920571541176 56.644 35.66932806795148 139.74919782588094 56.644 35.669319727491434 139.7491938801239 56.644 35.669326481832 139.74917245461887 56.644 35.66933392965592 139.74917600365072 56.644</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cf61a87f-3cf4-4459-b080-4778a450bb75">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669345706060135 139.74927273318966 56.644 35.66937515482266 139.74918368162005 56.644 35.66936505593674 139.74917866623406 56.644 35.66934409178901 139.74916833802513 56.644 35.669342505149274 139.74916801935322 56.644 35.6693403958601 139.74916791110618 56.644 35.66933740406729 139.74916900781218 56.644 35.66933535992015 139.74917182671757 56.644 35.66933392965592 139.74917600365072 56.644 35.669327897319015 139.74917292811608 56.644 35.66933055097152 139.74916520409585 56.644 35.66933308182114 139.74916232944898 56.644 35.669336947350786 139.74916038127455 56.644 35.669339317273604 139.74915939568223 56.644 35.66934116508751 139.74915939374242 56.644 35.669342229008365 139.74915982342407 56.644 35.66936707974822 139.74917254455906 56.644 35.66937977565291 139.74917908158355 56.644 35.66938083138597 139.74918069320938 56.644 35.669381807577956 139.7491845693739 56.644 35.66938150364314 139.74918819282112 56.644 35.6693524416502 139.7492760731021 56.644 35.669345706060135 139.74927273318966 56.644</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-354f3d0c-3e3f-4506-abfd-5d63778bdf1f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-354f3d0c-3e3f-4506-abfd-5d63778bdf1f_0">
											<gml:posList>35.6693403958601 139.74916791110618 56.644 35.669342505149274 139.74916801935322 56.644 35.669342505149274 139.74916801935322 59.315 35.6693403958601 139.74916791110618 59.315 35.6693403958601 139.74916791110618 56.644</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-421deff7-c02a-4390-b27d-480b25a637b2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-421deff7-c02a-4390-b27d-480b25a637b2_0">
											<gml:posList>35.669327897319015 139.74917292811608 56.644 35.66933392965592 139.74917600365072 59.315 35.669327897319015 139.74917292811608 59.315 35.669327897319015 139.74917292811608 56.644</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4de5d4ed-05bf-46e4-b999-ba47882e67d2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4de5d4ed-05bf-46e4-b999-ba47882e67d2_0">
											<gml:posList>35.66933392965592 139.74917600365072 59.315 35.669327897319015 139.74917292811608 56.644 35.66933392965592 139.74917600365072 56.644 35.66933392965592 139.74917600365072 59.315</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-44fdcbcb-13c9-4a2e-bf51-5584c0862dbd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-44fdcbcb-13c9-4a2e-bf51-5584c0862dbd_0">
											<gml:posList>35.669319727491434 139.7491938801239 56.644 35.669319727491434 139.7491938801239 60.486 35.669326481832 139.74917245461887 60.486 35.669326481832 139.74917245461887 56.644 35.669319727491434 139.7491938801239 56.644</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e09e4814-7075-41cc-9430-ea25be4b66ce">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e09e4814-7075-41cc-9430-ea25be4b66ce_0">
											<gml:posList>35.669319727491434 139.7491938801239 56.644 35.66932806795148 139.74919782588094 56.644 35.66932806795148 139.74919782588094 60.486 35.669319727491434 139.7491938801239 60.486 35.669319727491434 139.7491938801239 56.644</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8fe7edb0-dde1-4fb8-81a1-6d7dbee1d698">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8fe7edb0-dde1-4fb8-81a1-6d7dbee1d698_0">
											<gml:posList>35.66932806795148 139.74919782588094 56.644 35.669325585673455 139.74920571541176 56.644 35.669325585673455 139.74920571541176 60.486 35.66932806795148 139.74919782588094 60.486 35.66932806795148 139.74919782588094 56.644</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5d6beef8-9176-418a-9539-983480a250e2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5d6beef8-9176-418a-9539-983480a250e2_0">
											<gml:posList>35.669330176365484 139.7491064281079 56.644 35.6693270194005 139.74911622932834 56.644 35.6693270194005 139.74911622932834 57.923 35.669330176365484 139.7491064281079 57.923 35.669330176365484 139.7491064281079 56.644</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2851373d-14da-4b38-be59-0881952871d9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2851373d-14da-4b38-be59-0881952871d9_0">
											<gml:posList>35.66933055097152 139.74916520409585 56.644 35.669327897319015 139.74917292811608 56.644 35.669327897319015 139.74917292811608 59.315 35.66933055097152 139.74916520409585 59.315 35.66933055097152 139.74916520409585 56.644</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-44c14f98-09e2-4f43-bbf9-270fb53064bb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-44c14f98-09e2-4f43-bbf9-270fb53064bb_0">
											<gml:posList>35.669326481832 139.74917245461887 56.644 35.66933392965592 139.74917600365072 59.315 35.66933392965592 139.74917600365072 56.644 35.669326481832 139.74917245461887 56.644</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-00f5e661-64f7-4662-b3c2-bc6bc5e983d4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-00f5e661-64f7-4662-b3c2-bc6bc5e983d4_0">
											<gml:posList>35.669337920541224 139.74921155691155 56.644 35.669337920541224 139.74921155691155 60.486 35.669325585673455 139.74920571541176 60.486 35.669325585673455 139.74920571541176 56.644 35.669337920541224 139.74921155691155 56.644</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1b08cd41-a16c-4d64-959e-cbf8fa10d64b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1b08cd41-a16c-4d64-959e-cbf8fa10d64b_0">
											<gml:posList>35.66933308182114 139.74916232944898 56.644 35.66933055097152 139.74916520409585 56.644 35.66933055097152 139.74916520409585 59.315 35.66933308182114 139.74916232944898 59.315 35.66933308182114 139.74916232944898 56.644</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ce24ccb8-83e1-4329-9529-312266f88577">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ce24ccb8-83e1-4329-9529-312266f88577_0">
											<gml:posList>35.669319727491434 139.7491938801239 60.486 35.66932806795148 139.74919782588094 60.486 35.669325585673455 139.74920571541176 60.486 35.669337920541224 139.74921155691155 60.486 35.66934715716192 139.74918224186993 60.486 35.669326481832 139.74917245461887 60.486 35.669319727491434 139.7491938801239 60.486</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3fd0bf02-4108-4896-9276-6aeb4674e975">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3fd0bf02-4108-4896-9276-6aeb4674e975_0">
											<gml:posList>35.66933392965592 139.74917600365072 56.644 35.66933535992015 139.74917182671757 56.644 35.66933535992015 139.74917182671757 59.315 35.66933392965592 139.74917600365072 59.315 35.66933392965592 139.74917600365072 56.644</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2878afc5-aa87-4bec-9cbf-77a960aacca3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2878afc5-aa87-4bec-9cbf-77a960aacca3_0">
											<gml:posList>35.66933308182114 139.74916232944898 56.644 35.66933308182114 139.74916232944898 59.315 35.669336947350786 139.74916038127455 59.315 35.669336947350786 139.74916038127455 56.644 35.66933308182114 139.74916232944898 56.644</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9e53c3e7-e7e6-407e-90f6-a397268f9e62">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9e53c3e7-e7e6-407e-90f6-a397268f9e62_0">
											<gml:posList>35.66933740406729 139.74916900781218 56.644 35.66933740406729 139.74916900781218 59.315 35.66933535992015 139.74917182671757 59.315 35.66933535992015 139.74917182671757 56.644 35.66933740406729 139.74916900781218 56.644</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-63b520a9-00e7-4235-9b66-7a5ecbb3fbfa">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-63b520a9-00e7-4235-9b66-7a5ecbb3fbfa_0">
											<gml:posList>35.66933392965592 139.74917600365072 59.315 35.669326481832 139.74917245461887 56.644 35.669326481832 139.74917245461887 60.486 35.66934715716192 139.74918224186993 60.486 35.66934715716192 139.74918224186993 56.644 35.66933392965592 139.74917600365072 56.644 35.66933392965592 139.74917600365072 59.315</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-89c62512-c14f-41a6-a1b6-a85e6a6a911f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-89c62512-c14f-41a6-a1b6-a85e6a6a911f_0">
											<gml:posList>35.669339317273604 139.74915939568223 56.644 35.669336947350786 139.74916038127455 56.644 35.669336947350786 139.74916038127455 59.315 35.669339317273604 139.74915939568223 59.315 35.669339317273604 139.74915939568223 56.644</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b6d89f09-2aa3-4e99-9890-913808334a98">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b6d89f09-2aa3-4e99-9890-913808334a98_0">
											<gml:posList>35.66933740406729 139.74916900781218 56.644 35.6693403958601 139.74916791110618 56.644 35.6693403958601 139.74916791110618 59.315 35.66933740406729 139.74916900781218 59.315 35.66933740406729 139.74916900781218 56.644</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6cb332c8-18c6-416c-b143-fd1d9f672d76">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6cb332c8-18c6-416c-b143-fd1d9f672d76_0">
											<gml:posList>35.66934116508751 139.74915939374242 56.644 35.669339317273604 139.74915939568223 56.644 35.669339317273604 139.74915939568223 59.315 35.66934116508751 139.74915939374242 59.315 35.66934116508751 139.74915939374242 56.644</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b13d399f-93ce-490b-9c63-cf3a2c3513ed">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b13d399f-93ce-490b-9c63-cf3a2c3513ed_0">
											<gml:posList>35.669342229008365 139.74915982342407 56.644 35.66934116508751 139.74915939374242 56.644 35.66934116508751 139.74915939374242 59.315 35.669342229008365 139.74915982342407 59.315 35.669342229008365 139.74915982342407 56.644</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-13759e66-4f37-4763-83be-5b928b799e2b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-13759e66-4f37-4763-83be-5b928b799e2b_0">
											<gml:posList>35.669337920541224 139.74921155691155 56.644 35.66934715716192 139.74918224186993 56.644 35.66934715716192 139.74918224186993 60.486 35.669337920541224 139.74921155691155 60.486 35.669337920541224 139.74921155691155 56.644</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5c149cd6-7908-4d1e-b770-3dc08e9de05a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5c149cd6-7908-4d1e-b770-3dc08e9de05a_0">
											<gml:posList>35.669342505149274 139.74916801935322 56.644 35.66934409178901 139.74916833802513 56.644 35.66934409178901 139.74916833802513 59.315 35.669342505149274 139.74916801935322 59.315 35.669342505149274 139.74916801935322 56.644</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d3142189-004d-4d51-8449-91190eb3a633">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d3142189-004d-4d51-8449-91190eb3a633_0">
											<gml:posList>35.66933392965592 139.74917600365072 59.315 35.66933535992015 139.74917182671757 59.315 35.66933740406729 139.74916900781218 59.315 35.6693403958601 139.74916791110618 59.315 35.669342505149274 139.74916801935322 59.315 35.66934409178901 139.74916833802513 59.315 35.66936505593674 139.74917866623406 59.315 35.66936707974822 139.74917254455906 59.315 35.669342229008365 139.74915982342407 59.315 35.66934116508751 139.74915939374242 59.315 35.669339317273604 139.74915939568223 59.315 35.669336947350786 139.74916038127455 59.315 35.66933308182114 139.74916232944898 59.315 35.66933055097152 139.74916520409585 59.315 35.669327897319015 139.74917292811608 59.315 35.66933392965592 139.74917600365072 59.315</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-725e5e38-a183-4285-bc63-83d027b21f85">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-725e5e38-a183-4285-bc63-83d027b21f85_0">
											<gml:posList>35.669345706060135 139.74927273318966 56.644 35.6693524416502 139.7492760731021 56.644 35.6693524416502 139.7492760731021 60.47 35.669345706060135 139.74927273318966 60.47 35.669345706060135 139.74927273318966 56.644</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9141ce6b-f870-4469-bf94-8c45b4b4bb4a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9141ce6b-f870-4469-bf94-8c45b4b4bb4a_0">
											<gml:posList>35.66936505593674 139.74917866623406 56.644 35.66936505593674 139.74917866623406 59.315 35.66934409178901 139.74916833802513 59.315 35.66934409178901 139.74916833802513 56.644 35.66936505593674 139.74917866623406 56.644</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ae34fb8e-fb0c-44a3-b876-703f3a082e12">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ae34fb8e-fb0c-44a3-b876-703f3a082e12_0">
											<gml:posList>35.66936707974822 139.74917254455906 56.644 35.669342229008365 139.74915982342407 56.644 35.669342229008365 139.74915982342407 59.315 35.66936707974822 139.74917254455906 59.315 35.66936707974822 139.74917254455906 56.644</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-44ff0e85-c378-4ed8-a3f0-fe12ce823220">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-44ff0e85-c378-4ed8-a3f0-fe12ce823220_0">
											<gml:posList>35.669345706060135 139.74927273318966 56.644 35.669345706060135 139.74927273318966 60.47 35.66937515482266 139.74918368162005 60.47 35.66937515482266 139.74918368162005 56.644 35.669345706060135 139.74927273318966 56.644</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-978320f4-158b-4a2f-ac05-3b967034b144">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-978320f4-158b-4a2f-ac05-3b967034b144_0">
											<gml:posList>35.66938150364314 139.74918819282112 60.47 35.669381807577956 139.7491845693739 60.47 35.66938083138597 139.74918069320938 60.47 35.66937977565291 139.74917908158355 60.47 35.66936707974822 139.74917254455906 60.47 35.66936505593674 139.74917866623406 60.47 35.66937515482266 139.74918368162005 60.47 35.669345706060135 139.74927273318966 60.47 35.6693524416502 139.7492760731021 60.47 35.66938150364314 139.74918819282112 60.47</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b6d40b5f-d35d-426b-8c5d-cfe8708801b8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b6d40b5f-d35d-426b-8c5d-cfe8708801b8_0">
											<gml:posList>35.66936707974822 139.74917254455906 59.315 35.66936505593674 139.74917866623406 59.315 35.66936505593674 139.74917866623406 60.47 35.66936707974822 139.74917254455906 60.47 35.66936707974822 139.74917254455906 59.315</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-21ca020c-7fe9-4aa4-838f-7c91c7f595d8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-21ca020c-7fe9-4aa4-838f-7c91c7f595d8_0">
											<gml:posList>35.6693524416502 139.7492760731021 56.644 35.66938150364314 139.74918819282112 56.644 35.66938150364314 139.74918819282112 60.47 35.6693524416502 139.7492760731021 60.47 35.6693524416502 139.7492760731021 56.644</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fed2067b-c9f4-4fa5-ae38-e6172c973627">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fed2067b-c9f4-4fa5-ae38-e6172c973627_0">
											<gml:posList>35.66936505593674 139.74917866623406 59.315 35.66936505593674 139.74917866623406 56.644 35.66937515482266 139.74918368162005 56.644 35.66937515482266 139.74918368162005 60.47 35.66936505593674 139.74917866623406 60.47 35.66936505593674 139.74917866623406 59.315</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7ab23d85-3fdb-4471-ba3a-edcfdb837853">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7ab23d85-3fdb-4471-ba3a-edcfdb837853_0">
											<gml:posList>35.66937977565291 139.74917908158355 60.47 35.66937977565291 139.74917908158355 56.644 35.66936707974822 139.74917254455906 56.644 35.66936707974822 139.74917254455906 59.315 35.66936707974822 139.74917254455906 60.47 35.66937977565291 139.74917908158355 60.47</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-efc75333-f66b-437d-8bca-db7b3d58cabc">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-efc75333-f66b-437d-8bca-db7b3d58cabc_0">
											<gml:posList>35.66937977565291 139.74917908158355 56.644 35.66937977565291 139.74917908158355 60.47 35.66938083138597 139.74918069320938 60.47 35.66938083138597 139.74918069320938 56.644 35.66937977565291 139.74917908158355 56.644</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ba67ffe7-bd56-472a-b383-5851ad7349fa">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ba67ffe7-bd56-472a-b383-5851ad7349fa_0">
											<gml:posList>35.669381807577956 139.7491845693739 56.644 35.66938083138597 139.74918069320938 56.644 35.66938083138597 139.74918069320938 60.47 35.669381807577956 139.7491845693739 60.47 35.669381807577956 139.7491845693739 56.644</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-38dd8982-c729-4493-9aa5-73f27da714fa">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-38dd8982-c729-4493-9aa5-73f27da714fa_0">
											<gml:posList>35.669381807577956 139.7491845693739 56.644 35.669381807577956 139.7491845693739 60.47 35.66938150364314 139.74918819282112 60.47 35.66938150364314 139.74918819282112 56.644 35.669381807577956 139.7491845693739 56.644</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fe2e2c3e-d3d8-4393-a794-0401e5c7aed7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fe2e2c3e-d3d8-4393-a794-0401e5c7aed7_0">
											<gml:posList>35.669448872191936 139.74917516500852 56.644 35.669448872191936 139.74917516500852 57.923 35.6693270194005 139.74911622932834 57.923 35.6693270194005 139.74911622932834 56.644 35.669448872191936 139.74917516500852 56.644</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f622a39b-80a4-4584-80ef-c10a11ee653a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f622a39b-80a4-4584-80ef-c10a11ee653a_0">
											<gml:posList>35.669330176365484 139.7491064281079 57.923 35.6693270194005 139.74911622932834 57.923 35.669448872191936 139.74917516500852 57.923 35.66945202916936 139.74916537482162 57.923 35.669330176365484 139.7491064281079 57.923</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2b960c74-1ff6-4a46-a4d9-7a992c00be13">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2b960c74-1ff6-4a46-a4d9-7a992c00be13_0">
											<gml:posList>35.66945202916936 139.74916537482162 56.644 35.669330176365484 139.7491064281079 56.644 35.669330176365484 139.7491064281079 57.923 35.66945202916936 139.74916537482162 57.923 35.66945202916936 139.74916537482162 56.644</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-07ae7e63-26f3-483c-9534-181692540765">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-07ae7e63-26f3-483c-9534-181692540765_0">
											<gml:posList>35.669448872191936 139.74917516500852 56.644 35.66945202916936 139.74916537482162 56.644 35.66945202916936 139.74916537482162 57.923 35.669448872191936 139.74917516500852 57.923 35.669448872191936 139.74917516500852 56.644</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-63e7eab5-3785-4c4d-bb46-43c730de47c5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-63e7eab5-3785-4c4d-bb46-43c730de47c5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-63e7eab5-3785-4c4d-bb46-43c730de47c5">
											<gml:posList>35.6692059164338 139.7492402495683 6.2 35.66931376772879 139.7489210142398 6.2 35.66955904498514 139.74906910577226 6.2 35.66945802971815 139.74936823075964 6.2 35.6692059164338 139.7492402495683 6.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-116dad98-063d-4664-8cd6-898dcc5b35e8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-116dad98-063d-4664-8cd6-898dcc5b35e8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-116dad98-063d-4664-8cd6-898dcc5b35e8">
											<gml:posList>35.66926600305268 139.74911281389262 56.644 35.669234196311 139.74920697114035 56.644 35.669235314414394 139.7492075443646 56.644 35.669267418717645 139.74911354144868 56.644 35.66926600305268 139.74911281389262 56.644</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ada7119a-34c6-4d07-ac1a-f3c591cdfcbc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ada7119a-34c6-4d07-ac1a-f3c591cdfcbc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ada7119a-34c6-4d07-ac1a-f3c591cdfcbc">
											<gml:posList>35.66924674748858 139.7491740847657 67.767 35.66925154110805 139.7491716716834 67.767 35.66926938781228 139.74911940486336 67.767 35.669267418717645 139.74911354144868 67.767 35.66924674748858 139.7491740847657 67.767</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c912dbc1-cb08-4c6c-aef5-d321b4ebdcb5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c912dbc1-cb08-4c6c-aef5-d321b4ebdcb5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c912dbc1-cb08-4c6c-aef5-d321b4ebdcb5">
											<gml:posList>35.6692059164338 139.7492402495683 63.2 35.669226478482955 139.74922981152943 63.2 35.66932188057454 139.74894742800458 63.2 35.66931376772879 139.7489210142398 63.2 35.6692059164338 139.7492402495683 63.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-cacb604c-2294-48fe-821a-03a6b5411752">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cacb604c-2294-48fe-821a-03a6b5411752">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cacb604c-2294-48fe-821a-03a6b5411752">
											<gml:posList>35.66928581799149 139.74919411453757 67.767 35.66928385790651 139.7491882400643 67.767 35.66925154110805 139.7491716716834 67.767 35.66924674748858 139.7491740847657 67.767 35.66928581799149 139.74919411453757 67.767</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-074d8583-be99-4d42-9eb7-4f9191f2e98b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-074d8583-be99-4d42-9eb7-4f9191f2e98b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-074d8583-be99-4d42-9eb7-4f9191f2e98b">
											<gml:posList>35.669301704625525 139.74913598427298 67.45 35.66926938781228 139.74911940486336 67.45 35.66925154110805 139.7491716716834 67.45 35.66928385790651 139.7491882400643 67.45 35.669301704625525 139.74913598427298 67.45</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d8a4ffea-a5a9-465d-a1b3-0562ff6814da">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d8a4ffea-a5a9-465d-a1b3-0562ff6814da">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d8a4ffea-a5a9-465d-a1b3-0562ff6814da">
											<gml:posList>35.66928581799149 139.74919411453757 64.398 35.669249001730826 139.74917524224057 64.398 35.669237918717684 139.7492065916673 64.398 35.66928696203832 139.74923182475547 64.398 35.66931682468411 139.749141745513 64.398 35.66930560770037 139.74913616795828 64.398 35.66928581799149 139.74919411453757 64.398</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a7179b5c-b964-4cdb-a826-74344bb1c1b5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a7179b5c-b964-4cdb-a826-74344bb1c1b5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a7179b5c-b964-4cdb-a826-74344bb1c1b5">
											<gml:posList>35.66928786527795 139.74923449696664 64.901 35.66931996058817 139.7491404940093 64.901 35.66931763421263 139.7491393034718 64.901 35.66931682468411 139.749141745513 64.901 35.66928696203832 139.74923182475547 64.901 35.669237918717684 139.7492065916673 64.901 35.669249001730826 139.74917524224057 64.901 35.66924674748858 139.7491740847657 64.901 35.669235314414394 139.7492075443646 64.901 35.66928786527795 139.74923449696664 64.901</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-02c02241-585c-4d98-b01f-bd658be33531">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-02c02241-585c-4d98-b01f-bd658be33531">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-02c02241-585c-4d98-b01f-bd658be33531">
											<gml:posList>35.669267418717645 139.74911354144868 67.767 35.66926938781228 139.74911940486336 67.767 35.669301704625525 139.74913598427298 67.767 35.66930648923818 139.7491335822423 67.767 35.669267418717645 139.74911354144868 67.767</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-bcd4f9cf-e861-417a-a1dd-90703818d6e2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bcd4f9cf-e861-417a-a1dd-90703818d6e2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bcd4f9cf-e861-417a-a1dd-90703818d6e2">
											<gml:posList>35.66930648923818 139.7491335822423 67.767 35.669301704625525 139.74913598427298 67.767 35.66928385790651 139.7491882400643 67.767 35.66928581799149 139.74919411453757 67.767 35.66930648923818 139.7491335822423 67.767</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-cd77af56-214e-4342-8c94-0a57d883185e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cd77af56-214e-4342-8c94-0a57d883185e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cd77af56-214e-4342-8c94-0a57d883185e">
											<gml:posList>35.66931763421263 139.7491393034718 64.901 35.66930648923818 139.7491335822423 64.901 35.66930560770037 139.74913616795828 64.901 35.66931682468411 139.749141745513 64.901 35.66931763421263 139.7491393034718 64.901</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-61eacf3f-3499-442c-abbc-f39c4493a85a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-61eacf3f-3499-442c-abbc-f39c4493a85a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-61eacf3f-3499-442c-abbc-f39c4493a85a">
											<gml:posList>35.66945802971815 139.74936823075964 63.2 35.66944949416716 139.74934303242472 63.2 35.669226478482955 139.74922981152943 63.2 35.6692059164338 139.7492402495683 63.2 35.66945802971815 139.74936823075964 63.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f254387f-65dd-4cf7-8b8e-365871276067">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f254387f-65dd-4cf7-8b8e-365871276067">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f254387f-65dd-4cf7-8b8e-365871276067">
											<gml:posList>35.669226478482955 139.74922981152943 56.644 35.66944949416716 139.74934303242472 56.644 35.66945687920208 139.74932118648366 56.644 35.66928786527795 139.74923449696664 56.644 35.669235314414394 139.7492075443646 56.644 35.669234196311 139.74920697114035 56.644 35.669226478482955 139.74922981152943 56.644</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-251d545c-1ebd-4368-9454-fb2a8770797c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-251d545c-1ebd-4368-9454-fb2a8770797c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-251d545c-1ebd-4368-9454-fb2a8770797c">
											<gml:posList>35.66948866801186 139.74922704008438 56.644 35.66931996058817 139.7491404940093 56.644 35.66928786527795 139.74923449696664 56.644 35.66945687920208 139.74932118648366 56.644 35.66948866801186 139.74922704008438 56.644</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-bfc1e8ab-98a0-43e4-b542-e1f526ca40aa">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bfc1e8ab-98a0-43e4-b542-e1f526ca40aa">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bfc1e8ab-98a0-43e4-b542-e1f526ca40aa">
											<gml:posList>35.669538860747046 139.7490784278382 56.644 35.66932188057454 139.74894742800458 56.644 35.66926600305268 139.74911281389262 56.644 35.669267418717645 139.74911354144868 56.644 35.66931996058817 139.7491404940093 56.644 35.66948866801186 139.74922704008438 56.644 35.669538860747046 139.7490784278382 56.644</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e59d8517-21df-4618-b5e8-9b5c7591d7a5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e59d8517-21df-4618-b5e8-9b5c7591d7a5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e59d8517-21df-4618-b5e8-9b5c7591d7a5">
											<gml:posList>35.66955904498514 139.74906910577226 63.2 35.66931376772879 139.7489210142398 63.2 35.66932188057454 139.74894742800458 63.2 35.669538860747046 139.7490784278382 63.2 35.66955904498514 139.74906910577226 63.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-2ff77a81-271f-44ce-9cfa-06ad6c77eb0e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2ff77a81-271f-44ce-9cfa-06ad6c77eb0e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2ff77a81-271f-44ce-9cfa-06ad6c77eb0e">
											<gml:posList>35.66955904498514 139.74906910577226 63.2 35.669538860747046 139.7490784278382 63.2 35.66944949416716 139.74934303242472 63.2 35.66945802971815 139.74936823075964 63.2 35.66955904498514 139.74906910577226 63.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ed64f0f9-ad29-4f87-8b93-453911ee2f30">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ed64f0f9-ad29-4f87-8b93-453911ee2f30">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ed64f0f9-ad29-4f87-8b93-453911ee2f30">
											<gml:posList>35.669237918717684 139.7492065916673 64.901 35.669237918717684 139.7492065916673 64.398 35.669249001730826 139.74917524224057 64.398 35.669249001730826 139.74917524224057 64.901 35.669237918717684 139.7492065916673 64.901</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-aa8e533f-af31-4862-b030-78cf9647d526">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-aa8e533f-af31-4862-b030-78cf9647d526">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-aa8e533f-af31-4862-b030-78cf9647d526">
											<gml:posList>35.669267418717645 139.74911354144868 56.644 35.669235314414394 139.7492075443646 56.644 35.669235314414394 139.7492075443646 64.901 35.66924674748858 139.7491740847657 64.901 35.66924674748858 139.7491740847657 67.767 35.669267418717645 139.74911354144868 67.767 35.669267418717645 139.74911354144868 56.644</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-37178d49-a23f-4c9b-9343-db21f4cedbb5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-37178d49-a23f-4c9b-9343-db21f4cedbb5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-37178d49-a23f-4c9b-9343-db21f4cedbb5">
											<gml:posList>35.66931376772879 139.7489210142398 6.2 35.6692059164338 139.7492402495683 6.2 35.6692059164338 139.7492402495683 63.2 35.66931376772879 139.7489210142398 63.2 35.66931376772879 139.7489210142398 6.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7c760f7c-7d27-4765-a019-9257c186724d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7c760f7c-7d27-4765-a019-9257c186724d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7c760f7c-7d27-4765-a019-9257c186724d">
											<gml:posList>35.66925154110805 139.7491716716834 67.767 35.66925154110805 139.7491716716834 67.45 35.66926938781228 139.74911940486336 67.45 35.66926938781228 139.74911940486336 67.767 35.66925154110805 139.7491716716834 67.767</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2b7a619e-88b1-4ff8-ac82-1b0935b3c2e8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2b7a619e-88b1-4ff8-ac82-1b0935b3c2e8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2b7a619e-88b1-4ff8-ac82-1b0935b3c2e8">
											<gml:posList>35.66928786527795 139.74923449696664 64.901 35.669235314414394 139.7492075443646 64.901 35.669235314414394 139.7492075443646 56.644 35.66928786527795 139.74923449696664 56.644 35.66928786527795 139.74923449696664 64.901</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4e749917-693b-4dca-9fae-72144f2bca61">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4e749917-693b-4dca-9fae-72144f2bca61">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4e749917-693b-4dca-9fae-72144f2bca61">
											<gml:posList>35.66928696203832 139.74923182475547 64.901 35.66928696203832 139.74923182475547 64.398 35.669237918717684 139.7492065916673 64.398 35.669237918717684 139.7492065916673 64.901 35.66928696203832 139.74923182475547 64.901</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-bae159ca-8527-495e-917c-6fa058cef41d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bae159ca-8527-495e-917c-6fa058cef41d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bae159ca-8527-495e-917c-6fa058cef41d">
											<gml:posList>35.66924674748858 139.7491740847657 67.767 35.66924674748858 139.7491740847657 64.901 35.669249001730826 139.74917524224057 64.901 35.669249001730826 139.74917524224057 64.398 35.66928581799149 139.74919411453757 64.398 35.66928581799149 139.74919411453757 67.767 35.66924674748858 139.7491740847657 67.767</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0c87039c-e1ed-49df-be10-9d1ee3949620">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0c87039c-e1ed-49df-be10-9d1ee3949620">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0c87039c-e1ed-49df-be10-9d1ee3949620">
											<gml:posList>35.66928385790651 139.7491882400643 67.767 35.66928385790651 139.7491882400643 67.45 35.66925154110805 139.7491716716834 67.45 35.66925154110805 139.7491716716834 67.767 35.66928385790651 139.7491882400643 67.767</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3ad4321e-e3b5-40fd-a435-90da19ba36c4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3ad4321e-e3b5-40fd-a435-90da19ba36c4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3ad4321e-e3b5-40fd-a435-90da19ba36c4">
											<gml:posList>35.669226478482955 139.74922981152943 63.2 35.669226478482955 139.74922981152943 56.644 35.669234196311 139.74920697114035 56.644 35.66926600305268 139.74911281389262 56.644 35.66932188057454 139.74894742800458 56.644 35.66932188057454 139.74894742800458 63.2 35.669226478482955 139.74922981152943 63.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ad58c2fa-4f8b-4815-8bc5-fbe367202e80">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ad58c2fa-4f8b-4815-8bc5-fbe367202e80">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ad58c2fa-4f8b-4815-8bc5-fbe367202e80">
											<gml:posList>35.66926938781228 139.74911940486336 67.767 35.66926938781228 139.74911940486336 67.45 35.669301704625525 139.74913598427298 67.45 35.669301704625525 139.74913598427298 67.767 35.66926938781228 139.74911940486336 67.767</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b7410914-e18b-4f55-a337-ce6a057f5033">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b7410914-e18b-4f55-a337-ce6a057f5033">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b7410914-e18b-4f55-a337-ce6a057f5033">
											<gml:posList>35.669301704625525 139.74913598427298 67.767 35.669301704625525 139.74913598427298 67.45 35.66928385790651 139.7491882400643 67.45 35.66928385790651 139.7491882400643 67.767 35.669301704625525 139.74913598427298 67.767</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8b5128a2-58a7-4a4f-b1c1-b659fc26e5e7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8b5128a2-58a7-4a4f-b1c1-b659fc26e5e7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8b5128a2-58a7-4a4f-b1c1-b659fc26e5e7">
											<gml:posList>35.66931763421263 139.7491393034718 64.901 35.66931996058817 139.7491404940093 64.901 35.66931996058817 139.7491404940093 56.644 35.669267418717645 139.74911354144868 56.644 35.669267418717645 139.74911354144868 67.767 35.66930648923818 139.7491335822423 67.767 35.66930648923818 139.7491335822423 64.901 35.66931763421263 139.7491393034718 64.901</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b0a29c61-1a90-45ed-90f6-00554092fbd3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b0a29c61-1a90-45ed-90f6-00554092fbd3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b0a29c61-1a90-45ed-90f6-00554092fbd3">
											<gml:posList>35.66930648923818 139.7491335822423 67.767 35.66928581799149 139.74919411453757 67.767 35.66928581799149 139.74919411453757 64.398 35.66930560770037 139.74913616795828 64.398 35.66930560770037 139.74913616795828 64.901 35.66930648923818 139.7491335822423 64.901 35.66930648923818 139.7491335822423 67.767</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b0ac6d4c-3402-4025-bd7d-5df04aa38f37">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b0ac6d4c-3402-4025-bd7d-5df04aa38f37">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b0ac6d4c-3402-4025-bd7d-5df04aa38f37">
											<gml:posList>35.66931682468411 139.749141745513 64.901 35.66931682468411 139.749141745513 64.398 35.66928696203832 139.74923182475547 64.398 35.66928696203832 139.74923182475547 64.901 35.66931682468411 139.749141745513 64.901</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8a8a3288-cd04-4506-989d-59aabd667d2a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8a8a3288-cd04-4506-989d-59aabd667d2a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8a8a3288-cd04-4506-989d-59aabd667d2a">
											<gml:posList>35.66931996058817 139.7491404940093 64.901 35.66928786527795 139.74923449696664 64.901 35.66928786527795 139.74923449696664 56.644 35.66931996058817 139.7491404940093 56.644 35.66931996058817 139.7491404940093 64.901</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-95e5b632-25b5-4bea-8a9f-c1770f366c0a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-95e5b632-25b5-4bea-8a9f-c1770f366c0a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-95e5b632-25b5-4bea-8a9f-c1770f366c0a">
											<gml:posList>35.66930560770037 139.74913616795828 64.901 35.66930560770037 139.74913616795828 64.398 35.66931682468411 139.749141745513 64.398 35.66931682468411 139.749141745513 64.901 35.66930560770037 139.74913616795828 64.901</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-43a8aadd-086e-4219-9f59-d52f3489d6ca">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-43a8aadd-086e-4219-9f59-d52f3489d6ca">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-43a8aadd-086e-4219-9f59-d52f3489d6ca">
											<gml:posList>35.6692059164338 139.7492402495683 6.2 35.66945802971815 139.74936823075964 6.2 35.66945802971815 139.74936823075964 63.2 35.6692059164338 139.7492402495683 63.2 35.6692059164338 139.7492402495683 6.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1ddcad06-5040-4894-bfa7-2608f196dbb0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1ddcad06-5040-4894-bfa7-2608f196dbb0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1ddcad06-5040-4894-bfa7-2608f196dbb0">
											<gml:posList>35.66944949416716 139.74934303242472 63.2 35.66944949416716 139.74934303242472 56.644 35.669226478482955 139.74922981152943 56.644 35.669226478482955 139.74922981152943 63.2 35.66944949416716 139.74934303242472 63.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2fe49fcf-c3ef-4c6b-aeb1-5e5a572bbe0a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2fe49fcf-c3ef-4c6b-aeb1-5e5a572bbe0a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2fe49fcf-c3ef-4c6b-aeb1-5e5a572bbe0a">
											<gml:posList>35.66932188057454 139.74894742800458 63.2 35.66932188057454 139.74894742800458 56.644 35.669538860747046 139.7490784278382 56.644 35.669538860747046 139.7490784278382 63.2 35.66932188057454 139.74894742800458 63.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e45fed11-9191-43c0-a434-5f1154375168">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e45fed11-9191-43c0-a434-5f1154375168">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e45fed11-9191-43c0-a434-5f1154375168">
											<gml:posList>35.66955904498514 139.74906910577226 6.2 35.66931376772879 139.7489210142398 6.2 35.66931376772879 139.7489210142398 63.2 35.66955904498514 139.74906910577226 63.2 35.66955904498514 139.74906910577226 6.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-44ad5d2f-d9ad-4a3c-8268-dfc7a631c220">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-44ad5d2f-d9ad-4a3c-8268-dfc7a631c220">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-44ad5d2f-d9ad-4a3c-8268-dfc7a631c220">
											<gml:posList>35.669538860747046 139.7490784278382 63.2 35.669538860747046 139.7490784278382 56.644 35.66948866801186 139.74922704008438 56.644 35.66945687920208 139.74932118648366 56.644 35.66944949416716 139.74934303242472 56.644 35.66944949416716 139.74934303242472 63.2 35.669538860747046 139.7490784278382 63.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0712c038-a6db-4f1d-9812-50387d250607">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0712c038-a6db-4f1d-9812-50387d250607">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0712c038-a6db-4f1d-9812-50387d250607">
											<gml:posList>35.66945802971815 139.74936823075964 6.2 35.66955904498514 139.74906910577226 6.2 35.66955904498514 139.74906910577226 63.2 35.66945802971815 139.74936823075964 63.2 35.66945802971815 139.74936823075964 6.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区虎ノ門一丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-9787</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">894.25723</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1210</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>7</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>