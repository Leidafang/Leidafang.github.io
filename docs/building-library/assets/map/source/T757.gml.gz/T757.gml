<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_d8c56c21-258d-4707-9b1c-8a63f2ecf6f7">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">401</bldg:usage>
			<bldg:measuredHeight uom="m">41.1</bldg:measuredHeight>
			<bldg:storeysAboveGround>9</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.67181427521073 139.7421934970967 0 35.671996905854236 139.74191273092512 0 35.67187955326866 139.74180219019684 0 35.67167029358538 139.74205555821254 0 35.67181427521073 139.7421934970967 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67181427521073 139.7421934970967 7.25 35.67167029358538 139.74205555821254 7.25 35.67187955326866 139.74180219019684 7.25 35.671996905854236 139.74191273092512 7.25 35.67181427521073 139.7421934970967 7.25</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67181427521073 139.7421934970967 7.25 35.671996905854236 139.74191273092512 7.25 35.671996905854236 139.74191273092512 42.4 35.67181427521073 139.7421934970967 42.4 35.67181427521073 139.7421934970967 7.25</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671996905854236 139.74191273092512 7.25 35.67187955326866 139.74180219019684 7.25 35.67187955326866 139.74180219019684 42.4 35.671996905854236 139.74191273092512 42.4 35.671996905854236 139.74191273092512 7.25</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67187955326866 139.74180219019684 7.25 35.67167029358538 139.74205555821254 7.25 35.67167029358538 139.74205555821254 42.4 35.67187955326866 139.74180219019684 42.4 35.67187955326866 139.74180219019684 7.25</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67167029358538 139.74205555821254 7.25 35.67181427521073 139.7421934970967 7.25 35.67181427521073 139.7421934970967 42.4 35.67167029358538 139.74205555821254 42.4 35.67167029358538 139.74205555821254 7.25</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67181427521073 139.7421934970967 42.4 35.671996905854236 139.74191273092512 42.4 35.67187955326866 139.74180219019684 42.4 35.67167029358538 139.74205555821254 42.4 35.67181427521073 139.7421934970967 42.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-dddd264a-a73e-4aff-93d1-2e6ef087d844"/>
							<gml:surfaceMember xlink:href="#poly-8e48147f-8b92-4324-b9cc-6108cc4bd5e3"/>
							<gml:surfaceMember xlink:href="#poly-6a758048-6126-49b7-b495-f0692df784b7"/>
							<gml:surfaceMember xlink:href="#poly-fc0bdcc5-3290-4029-ac19-76b84d999e36"/>
							<gml:surfaceMember xlink:href="#poly-6ad9b65b-10ac-479a-a410-02614055f32e"/>
							<gml:surfaceMember xlink:href="#poly-6cb95e4b-2693-4ca0-a8b8-1accf731ed8f"/>
							<gml:surfaceMember xlink:href="#poly-a60af649-a368-4d2b-a6e1-053002b5a2b9"/>
							<gml:surfaceMember xlink:href="#poly-0d4515ed-3d37-443f-b80b-87bcfd670482"/>
							<gml:surfaceMember xlink:href="#poly-06fcd7cd-8bda-4409-be57-14087842f37b"/>
							<gml:surfaceMember xlink:href="#poly-c486ad75-78cc-4c4d-975d-a0e288fd5593"/>
							<gml:surfaceMember xlink:href="#poly-fa6107b8-9c79-463e-9a35-939447c3e203"/>
							<gml:surfaceMember xlink:href="#poly-f881f28c-1739-430a-b497-707b058ec5b8"/>
							<gml:surfaceMember xlink:href="#poly-cb03c36e-0850-4e1f-b15f-d0fedaf16c91"/>
							<gml:surfaceMember xlink:href="#poly-9b882634-c472-4da6-8f5c-f76a7460c2c6"/>
							<gml:surfaceMember xlink:href="#poly-c66a9e1c-b80b-45eb-8bd1-8942d78c1765"/>
							<gml:surfaceMember xlink:href="#poly-13323634-34a9-4ae7-a58b-9f35ee1f40bb"/>
							<gml:surfaceMember xlink:href="#poly-53e11ef5-4201-47c8-a858-3eac0c79d1d2"/>
							<gml:surfaceMember xlink:href="#poly-7dd43c57-36ce-4578-9f2e-7786c61e229d"/>
							<gml:surfaceMember xlink:href="#poly-c4646a5b-e734-4239-a45b-137632889d7b"/>
							<gml:surfaceMember xlink:href="#poly-c1fa3c9a-35c5-4311-acfb-d10053253530"/>
							<gml:surfaceMember xlink:href="#poly-70d0494d-4673-4891-bc4d-aeaf0a82122e"/>
							<gml:surfaceMember xlink:href="#poly-1f89d8fd-4b70-4c1f-b310-de6a64de547f"/>
							<gml:surfaceMember xlink:href="#poly-e48603fc-70a7-49b2-93eb-3580a88cdd94"/>
							<gml:surfaceMember xlink:href="#poly-33df4817-404f-4766-b1c9-3d9d08e3c4e1"/>
							<gml:surfaceMember xlink:href="#poly-3f788c08-5f80-4e75-8508-ce32e44483aa"/>
							<gml:surfaceMember xlink:href="#poly-3883e381-36d2-4432-89a0-8af7a0fc5f7d"/>
							<gml:surfaceMember xlink:href="#poly-a29964ef-5a1a-44ac-ab7d-847a02c0c9a3"/>
							<gml:surfaceMember xlink:href="#poly-7afe6474-3d82-4648-91e0-ea9b4e2c129a"/>
							<gml:surfaceMember xlink:href="#poly-428f3132-4ce1-4497-baa5-8dd9a17ab10c"/>
							<gml:surfaceMember xlink:href="#poly-41b6b74d-a96f-400b-8bd2-f5094e5d2ed7"/>
							<gml:surfaceMember xlink:href="#poly-6e579eb9-dc8f-4b76-8fb3-8c94ddcec650"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-dddd264a-a73e-4aff-93d1-2e6ef087d844">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-dddd264a-a73e-4aff-93d1-2e6ef087d844">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-dddd264a-a73e-4aff-93d1-2e6ef087d844">
											<gml:posList>35.67199690585424 139.74191273092512 7.25 35.671814275210714 139.7421934970967 7.25 35.67167029358536 139.74205555821254 7.25 35.67187955326864 139.74180219019684 7.25 35.67199690585424 139.74191273092512 7.25</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-8e48147f-8b92-4324-b9cc-6108cc4bd5e3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8e48147f-8b92-4324-b9cc-6108cc4bd5e3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8e48147f-8b92-4324-b9cc-6108cc4bd5e3">
											<gml:posList>35.671697676788796 139.74206678336023 43.216 35.67169815397178 139.74206606479834 43.216 35.671691551749774 139.74206056014043 43.216 35.671697676788796 139.74206678336023 43.216</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-6a758048-6126-49b7-b495-f0692df784b7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6a758048-6126-49b7-b495-f0692df784b7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6a758048-6126-49b7-b495-f0692df784b7">
											<gml:posList>35.671691551749774 139.74206056014043 43.216 35.67169815397178 139.74206606479834 43.216 35.67173263779697 139.74201494677695 42.968 35.671787564336285 139.7420702711329 42.998 35.671883459093586 139.741817838581 41.966 35.671691551749774 139.74206056014043 43.216</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-fc0bdcc5-3290-4029-ac19-76b84d999e36">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fc0bdcc5-3290-4029-ac19-76b84d999e36">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fc0bdcc5-3290-4029-ac19-76b84d999e36">
											<gml:posList>35.671857068616085 139.7421051872096 43.216 35.67198272211581 139.74191782847973 43.216 35.671883459093586 139.741817838581 41.966 35.671857068616085 139.7421051872096 43.216</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-6ad9b65b-10ac-479a-a410-02614055f32e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6ad9b65b-10ac-479a-a410-02614055f32e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6ad9b65b-10ac-479a-a410-02614055f32e">
											<gml:posList>35.671883459093586 139.741817838581 41.966 35.671787564336285 139.7420702711329 42.998 35.67179499731864 139.74207775216794 43.037 35.67177147987876 139.74211261944356 43.171 35.67176728784441 139.74212365961748 43.216 35.671857068616085 139.7421051872096 43.216 35.671883459093586 139.741817838581 41.966</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-6cb95e4b-2693-4ca0-a8b8-1accf731ed8f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6cb95e4b-2693-4ca0-a8b8-1accf731ed8f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6cb95e4b-2693-4ca0-a8b8-1accf731ed8f">
											<gml:posList>35.67179434125543 139.74216360595867 39.7 35.671799428269956 139.7421560223057 39.7 35.67176728784441 139.74212365961748 39.7 35.67176176865019 139.74213187340874 39.7 35.671691551749774 139.74206056014043 39.7 35.671883459093586 139.741817838581 39.7 35.67198272211581 139.74191782847973 39.7 35.671857068616085 139.7421051872096 39.7 35.67186514206412 139.74211331926702 39.7 35.67181646880596 139.74218589464027 39.7 35.671814275210714 139.7421934970967 39.7 35.67199690585424 139.74191273092512 39.7 35.67187955326864 139.74180219019684 39.7 35.67167029358536 139.74205555821254 39.7 35.67179434125543 139.74216360595867 39.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a60af649-a368-4d2b-a6e1-053002b5a2b9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a60af649-a368-4d2b-a6e1-053002b5a2b9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a60af649-a368-4d2b-a6e1-053002b5a2b9">
											<gml:posList>35.67179499731864 139.74207775216794 48.341 35.67173263779697 139.74201494677695 48.341 35.671697676788796 139.74206678336023 48.341 35.67175982018878 139.7421298983107 48.341 35.67179499731864 139.74207775216794 48.341</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-0d4515ed-3d37-443f-b80b-87bcfd670482">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0d4515ed-3d37-443f-b80b-87bcfd670482">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0d4515ed-3d37-443f-b80b-87bcfd670482">
											<gml:posList>35.67177147987876 139.74211261944356 43.171 35.67176520435277 139.7421219166486 43.216 35.67176728784441 139.74212365961748 43.216 35.67177147987876 139.74211261944356 43.171</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-06fcd7cd-8bda-4409-be57-14087842f37b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-06fcd7cd-8bda-4409-be57-14087842f37b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-06fcd7cd-8bda-4409-be57-14087842f37b">
											<gml:posList>35.671814275210714 139.7421934970967 39.7 35.67181646880596 139.74218589464027 39.7 35.67179434125543 139.74216360595867 39.7 35.67167029358536 139.74205555821254 39.7 35.671814275210714 139.7421934970967 39.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c486ad75-78cc-4c4d-975d-a0e288fd5593">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c486ad75-78cc-4c4d-975d-a0e288fd5593">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c486ad75-78cc-4c4d-975d-a0e288fd5593">
											<gml:posList>35.67175982018878 139.7421298983107 43.216 35.67176176865019 139.74213187340874 43.216 35.67176728784441 139.74212365961748 43.216 35.67176520435277 139.7421219166486 43.216 35.67175982018878 139.7421298983107 43.216</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-fa6107b8-9c79-463e-9a35-939447c3e203">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fa6107b8-9c79-463e-9a35-939447c3e203">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fa6107b8-9c79-463e-9a35-939447c3e203">
											<gml:posList>35.67181320333873 139.74218259546208 43.216 35.67181646880596 139.74218589464027 43.216 35.67186514206412 139.74211331926702 43.216 35.671857068616085 139.7421051872096 43.216 35.67176728784441 139.74212365961748 43.216 35.671799428269956 139.7421560223057 43.216 35.67180388503457 139.74214937831732 43.216 35.671822747120075 139.74216836781963 43.216 35.67181320333873 139.74218259546208 43.216</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f881f28c-1739-430a-b497-707b058ec5b8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f881f28c-1739-430a-b497-707b058ec5b8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f881f28c-1739-430a-b497-707b058ec5b8">
											<gml:posList>35.67181320333873 139.74218259546208 46.091 35.671822747120075 139.74216836781963 46.091 35.67180388503457 139.74214937831732 46.091 35.67179434125543 139.74216360595867 46.091 35.67181320333873 139.74218259546208 46.091</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-cb03c36e-0850-4e1f-b15f-d0fedaf16c91">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cb03c36e-0850-4e1f-b15f-d0fedaf16c91">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cb03c36e-0850-4e1f-b15f-d0fedaf16c91">
											<gml:posList>35.67199690585424 139.74191273092512 7.25 35.67187955326864 139.74180219019684 7.25 35.67187955326864 139.74180219019684 39.7 35.67199690585424 139.74191273092512 39.7 35.67199690585424 139.74191273092512 7.25</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9b882634-c472-4da6-8f5c-f76a7460c2c6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9b882634-c472-4da6-8f5c-f76a7460c2c6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9b882634-c472-4da6-8f5c-f76a7460c2c6">
											<gml:posList>35.671883459093586 139.741817838581 41.966 35.67198272211581 139.74191782847973 43.216 35.67198272211581 139.74191782847973 39.7 35.671883459093586 139.741817838581 39.7 35.671883459093586 139.741817838581 41.966</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c66a9e1c-b80b-45eb-8bd1-8942d78c1765">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c66a9e1c-b80b-45eb-8bd1-8942d78c1765">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c66a9e1c-b80b-45eb-8bd1-8942d78c1765">
											<gml:posList>35.67187955326864 139.74180219019684 7.25 35.67167029358536 139.74205555821254 7.25 35.67167029358536 139.74205555821254 39.7 35.67187955326864 139.74180219019684 39.7 35.67187955326864 139.74180219019684 7.25</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-13323634-34a9-4ae7-a58b-9f35ee1f40bb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-13323634-34a9-4ae7-a58b-9f35ee1f40bb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-13323634-34a9-4ae7-a58b-9f35ee1f40bb">
											<gml:posList>35.671691551749774 139.74206056014043 43.216 35.671883459093586 139.741817838581 41.966 35.671883459093586 139.741817838581 39.7 35.671691551749774 139.74206056014043 39.7 35.671691551749774 139.74206056014043 43.216</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-53e11ef5-4201-47c8-a858-3eac0c79d1d2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-53e11ef5-4201-47c8-a858-3eac0c79d1d2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-53e11ef5-4201-47c8-a858-3eac0c79d1d2">
											<gml:posList>35.67198272211581 139.74191782847973 43.216 35.671857068616085 139.7421051872096 43.216 35.671857068616085 139.7421051872096 39.7 35.67198272211581 139.74191782847973 39.7 35.67198272211581 139.74191782847973 43.216</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7dd43c57-36ce-4578-9f2e-7786c61e229d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7dd43c57-36ce-4578-9f2e-7786c61e229d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7dd43c57-36ce-4578-9f2e-7786c61e229d">
											<gml:posList>35.67173263779697 139.74201494677695 48.341 35.67173263779697 139.74201494677695 42.968 35.67169815397178 139.74206606479834 43.216 35.671697676788796 139.74206678336023 43.216 35.671697676788796 139.74206678336023 48.341 35.67173263779697 139.74201494677695 48.341</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c4646a5b-e734-4239-a45b-137632889d7b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c4646a5b-e734-4239-a45b-137632889d7b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c4646a5b-e734-4239-a45b-137632889d7b">
											<gml:posList>35.67179499731864 139.74207775216794 48.341 35.67179499731864 139.74207775216794 43.037 35.671787564336285 139.7420702711329 42.998 35.67173263779697 139.74201494677695 42.968 35.67173263779697 139.74201494677695 48.341 35.67179499731864 139.74207775216794 48.341</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c1fa3c9a-35c5-4311-acfb-d10053253530">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c1fa3c9a-35c5-4311-acfb-d10053253530">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c1fa3c9a-35c5-4311-acfb-d10053253530">
											<gml:posList>35.671814275210714 139.7421934970967 7.25 35.67199690585424 139.74191273092512 7.25 35.67199690585424 139.74191273092512 39.7 35.671814275210714 139.7421934970967 39.7 35.671814275210714 139.7421934970967 7.25</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-70d0494d-4673-4891-bc4d-aeaf0a82122e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-70d0494d-4673-4891-bc4d-aeaf0a82122e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-70d0494d-4673-4891-bc4d-aeaf0a82122e">
											<gml:posList>35.67175982018878 139.7421298983107 48.341 35.671697676788796 139.74206678336023 48.341 35.671697676788796 139.74206678336023 43.216 35.671691551749774 139.74206056014043 43.216 35.671691551749774 139.74206056014043 39.7 35.67176176865019 139.74213187340874 39.7 35.67176176865019 139.74213187340874 43.216 35.67175982018878 139.7421298983107 43.216 35.67175982018878 139.7421298983107 48.341</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1f89d8fd-4b70-4c1f-b310-de6a64de547f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1f89d8fd-4b70-4c1f-b310-de6a64de547f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1f89d8fd-4b70-4c1f-b310-de6a64de547f">
											<gml:posList>35.67175982018878 139.7421298983107 48.341 35.67175982018878 139.7421298983107 43.216 35.67176520435277 139.7421219166486 43.216 35.67177147987876 139.74211261944356 43.171 35.67179499731864 139.74207775216794 43.037 35.67179499731864 139.74207775216794 48.341 35.67175982018878 139.7421298983107 48.341</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e48603fc-70a7-49b2-93eb-3580a88cdd94">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e48603fc-70a7-49b2-93eb-3580a88cdd94">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e48603fc-70a7-49b2-93eb-3580a88cdd94">
											<gml:posList>35.671857068616085 139.7421051872096 43.216 35.67186514206412 139.74211331926702 43.216 35.67186514206412 139.74211331926702 39.7 35.671857068616085 139.7421051872096 39.7 35.671857068616085 139.7421051872096 43.216</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-33df4817-404f-4766-b1c9-3d9d08e3c4e1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-33df4817-404f-4766-b1c9-3d9d08e3c4e1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-33df4817-404f-4766-b1c9-3d9d08e3c4e1">
											<gml:posList>35.67167029358536 139.74205555821254 7.25 35.671814275210714 139.7421934970967 7.25 35.671814275210714 139.7421934970967 39.7 35.67167029358536 139.74205555821254 39.7 35.67167029358536 139.74205555821254 7.25</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3f788c08-5f80-4e75-8508-ce32e44483aa">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3f788c08-5f80-4e75-8508-ce32e44483aa">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3f788c08-5f80-4e75-8508-ce32e44483aa">
											<gml:posList>35.67176728784441 139.74212365961748 43.216 35.67176176865019 139.74213187340874 43.216 35.67176176865019 139.74213187340874 39.7 35.67176728784441 139.74212365961748 39.7 35.67176728784441 139.74212365961748 43.216</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3883e381-36d2-4432-89a0-8af7a0fc5f7d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3883e381-36d2-4432-89a0-8af7a0fc5f7d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3883e381-36d2-4432-89a0-8af7a0fc5f7d">
											<gml:posList>35.671799428269956 139.7421560223057 43.216 35.67176728784441 139.74212365961748 43.216 35.67176728784441 139.74212365961748 39.7 35.671799428269956 139.7421560223057 39.7 35.671799428269956 139.7421560223057 43.216</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a29964ef-5a1a-44ac-ab7d-847a02c0c9a3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a29964ef-5a1a-44ac-ab7d-847a02c0c9a3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a29964ef-5a1a-44ac-ab7d-847a02c0c9a3">
											<gml:posList>35.67186514206412 139.74211331926702 43.216 35.67181646880596 139.74218589464027 43.216 35.67181646880596 139.74218589464027 39.7 35.67186514206412 139.74211331926702 39.7 35.67186514206412 139.74211331926702 43.216</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7afe6474-3d82-4648-91e0-ea9b4e2c129a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7afe6474-3d82-4648-91e0-ea9b4e2c129a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7afe6474-3d82-4648-91e0-ea9b4e2c129a">
											<gml:posList>35.67180388503457 139.74214937831732 46.091 35.67180388503457 139.74214937831732 43.216 35.671799428269956 139.7421560223057 43.216 35.671799428269956 139.7421560223057 39.7 35.67179434125543 139.74216360595867 39.7 35.67179434125543 139.74216360595867 46.091 35.67180388503457 139.74214937831732 46.091</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-428f3132-4ce1-4497-baa5-8dd9a17ab10c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-428f3132-4ce1-4497-baa5-8dd9a17ab10c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-428f3132-4ce1-4497-baa5-8dd9a17ab10c">
											<gml:posList>35.67180388503457 139.74214937831732 43.216 35.67180388503457 139.74214937831732 46.091 35.671822747120075 139.74216836781963 46.091 35.671822747120075 139.74216836781963 43.216 35.67180388503457 139.74214937831732 43.216</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-41b6b74d-a96f-400b-8bd2-f5094e5d2ed7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-41b6b74d-a96f-400b-8bd2-f5094e5d2ed7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-41b6b74d-a96f-400b-8bd2-f5094e5d2ed7">
											<gml:posList>35.67181646880596 139.74218589464027 39.7 35.67181646880596 139.74218589464027 43.216 35.67181320333873 139.74218259546208 43.216 35.67181320333873 139.74218259546208 46.091 35.67179434125543 139.74216360595867 46.091 35.67179434125543 139.74216360595867 39.7 35.67181646880596 139.74218589464027 39.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6e579eb9-dc8f-4b76-8fb3-8c94ddcec650">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6e579eb9-dc8f-4b76-8fb3-8c94ddcec650">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6e579eb9-dc8f-4b76-8fb3-8c94ddcec650">
											<gml:posList>35.671822747120075 139.74216836781963 43.216 35.671822747120075 139.74216836781963 46.091 35.67181320333873 139.74218259546208 46.091 35.67181320333873 139.74218259546208 43.216 35.671822747120075 139.74216836781963 43.216</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13101-bldg-4486</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13101</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">557.7616</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1210</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>7</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.01</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.0</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>