<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_d96a59c3-c604-4cbd-b2bb-b077b362df8c">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>3</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001003</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">401</bldg:usage>
			<bldg:measuredHeight uom="m">16.3</bldg:measuredHeight>
			<bldg:storeysAboveGround>5</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.67392491472301 139.73826908237095 0 35.67387051622995 139.73809714913435 0 35.6737432001001 139.7381576154868 0 35.67379768873195 139.7383296588522 0 35.67392491472301 139.73826908237095 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67392491472301 139.73826908237095 8.32 35.67379768873195 139.7383296588522 8.32 35.6737432001001 139.7381576154868 8.32 35.67387051622995 139.73809714913435 8.32 35.67392491472301 139.73826908237095 8.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67392491472301 139.73826908237095 8.32 35.67387051622995 139.73809714913435 8.32 35.67387051622995 139.73809714913435 24.62 35.67392491472301 139.73826908237095 24.62 35.67392491472301 139.73826908237095 8.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67387051622995 139.73809714913435 8.32 35.6737432001001 139.7381576154868 8.32 35.6737432001001 139.7381576154868 24.62 35.67387051622995 139.73809714913435 24.62 35.67387051622995 139.73809714913435 8.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6737432001001 139.7381576154868 8.32 35.67379768873195 139.7383296588522 8.32 35.67379768873195 139.7383296588522 24.62 35.6737432001001 139.7381576154868 24.62 35.6737432001001 139.7381576154868 8.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67379768873195 139.7383296588522 8.32 35.67392491472301 139.73826908237095 8.32 35.67392491472301 139.73826908237095 24.62 35.67379768873195 139.7383296588522 24.62 35.67379768873195 139.7383296588522 8.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67392491472301 139.73826908237095 24.62 35.67387051622995 139.73809714913435 24.62 35.6737432001001 139.7381576154868 24.62 35.67379768873195 139.7383296588522 24.62 35.67392491472301 139.73826908237095 24.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-fc957bae-7a81-43db-bba2-b3282bea2250"/>
							<gml:surfaceMember xlink:href="#poly-dfca0503-3f7a-45de-8a15-98fd098f3694"/>
							<gml:surfaceMember xlink:href="#poly-8c2da1be-7fee-44bf-8be3-ccc1701166c8"/>
							<gml:surfaceMember xlink:href="#poly-f908a64b-3320-4cae-897d-8b660f389714"/>
							<gml:surfaceMember xlink:href="#poly-440581b4-4b22-462e-9b4f-21d56d2d8036"/>
							<gml:surfaceMember xlink:href="#poly-9ccd794e-e4f7-425d-a125-ae43bb75c863"/>
							<gml:surfaceMember xlink:href="#poly-3d35878e-406d-4362-9c50-8b03649dc167"/>
							<gml:surfaceMember xlink:href="#poly-a377e587-8c2e-4b28-8976-27984f1baba8"/>
							<gml:surfaceMember xlink:href="#poly-096d1927-c8d2-4e48-a318-6a37e28c445a"/>
							<gml:surfaceMember xlink:href="#poly-f6afbb45-8f0c-4a3b-9637-127dfe4cfbeb"/>
							<gml:surfaceMember xlink:href="#poly-05c813e6-6fd7-4d83-a457-952d561007d5"/>
							<gml:surfaceMember xlink:href="#poly-15a96854-9d9a-420f-b28e-2f130ed7ceaa"/>
							<gml:surfaceMember xlink:href="#poly-ec40bd66-aef1-4de5-8638-33d5366a7bd5"/>
							<gml:surfaceMember xlink:href="#poly-2f6a791a-2fd4-4fc2-91e3-2f26ee327f18"/>
							<gml:surfaceMember xlink:href="#poly-4a2781ad-abfb-42fb-8d92-3a70d3b40f64"/>
							<gml:surfaceMember xlink:href="#poly-1f8bfc80-bc94-47fc-9a2d-40c0e711c863"/>
							<gml:surfaceMember xlink:href="#poly-7cabf825-8ec8-42a6-bc02-88e7fff3b585"/>
							<gml:surfaceMember xlink:href="#poly-075fac70-e59e-407a-a0ff-af052e3df02e"/>
							<gml:surfaceMember xlink:href="#poly-6b9887b9-4c08-4590-ab62-90b0e0a88656"/>
							<gml:surfaceMember xlink:href="#poly-bedc3052-6c1d-4981-b448-a577b7d64664"/>
							<gml:surfaceMember xlink:href="#poly-94a5b4cf-bdd5-47dc-a7e7-2979604109c1"/>
							<gml:surfaceMember xlink:href="#poly-6c5a5493-bc94-4e91-b55f-1ddf7441ad6f"/>
							<gml:surfaceMember xlink:href="#poly-34a2d3f5-e5f3-4d4d-b34a-aada7c8c0e27"/>
							<gml:surfaceMember xlink:href="#poly-edb7ed02-d51f-421c-b57d-3b8b596b6f0b"/>
							<gml:surfaceMember xlink:href="#poly-aa0ef18c-143f-48dc-961b-4672f1deea88"/>
							<gml:surfaceMember xlink:href="#poly-2b3bd189-3e12-4d81-8f04-d7000ffa8a88"/>
							<gml:surfaceMember xlink:href="#poly-bc875bd8-cb26-4866-a560-dc02cca606ce"/>
							<gml:surfaceMember xlink:href="#poly-da46981e-8b51-40e6-80a0-225a96d70d5b"/>
							<gml:surfaceMember xlink:href="#poly-8a6b5102-ba16-43ad-a951-f65b38d30b71"/>
							<gml:surfaceMember xlink:href="#poly-4b1fb112-90b7-4e85-83c6-ade1e070b39a"/>
							<gml:surfaceMember xlink:href="#poly-ad2bd342-ed91-4d3f-913d-c3f45eaebe27"/>
							<gml:surfaceMember xlink:href="#poly-97d8b73c-b73c-485e-8a08-593286dbb872"/>
							<gml:surfaceMember xlink:href="#poly-31886625-4ae5-455c-9d57-14c6e929f188"/>
							<gml:surfaceMember xlink:href="#poly-da3478d7-1e7f-4ef5-9301-2a5b7ae051e3"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_d96a59c3-c604-4cbd-b2bb-b077b362df8c_BuildingInstallation_1041">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-60bc81fd-9711-42a2-ae1f-10afee4b2e3a">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67382495201339 139.73825703845517 24.857 35.67380072320818 139.73826856683635 24.857 35.67379279841262 139.73824354434493 24.857 35.67381702721546 139.73823201595738 24.857 35.67382495201339 139.73825703845517 24.857</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-dbdf1012-c7fc-4280-9bb6-e459ee0661c4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-dbdf1012-c7fc-4280-9bb6-e459ee0661c4_0">
											<gml:posList>35.67379279841262 139.73824354434493 24.857 35.67380072320818 139.73826856683635 24.857 35.67380072320818 139.73826856683635 27.617 35.67379279841262 139.73824354434493 27.617 35.67379279841262 139.73824354434493 24.857</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0952e1fb-6128-49da-a82f-35906815de7c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0952e1fb-6128-49da-a82f-35906815de7c_0">
											<gml:posList>35.67381702721546 139.73823201595738 27.617 35.67381702721546 139.73823201595738 24.857 35.67379279841262 139.73824354434493 24.857 35.67379279841262 139.73824354434493 27.617 35.67381702721546 139.73823201595738 27.617</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cd564846-2f88-4374-81ca-3fef0ee17565">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cd564846-2f88-4374-81ca-3fef0ee17565_0">
											<gml:posList>35.67379279841262 139.73824354434493 27.617 35.67380072320818 139.73826856683635 27.617 35.67382495201339 139.73825703845517 27.617 35.67381702721546 139.73823201595738 27.617 35.67379279841262 139.73824354434493 27.617</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2b2b80c7-931c-456d-a143-756cd04a4ab8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2b2b80c7-931c-456d-a143-756cd04a4ab8_0">
											<gml:posList>35.67380072320818 139.73826856683635 27.617 35.67380072320818 139.73826856683635 24.857 35.67382495201339 139.73825703845517 24.857 35.67382495201339 139.73825703845517 27.617 35.67380072320818 139.73826856683635 27.617</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f4342f47-d6c6-418b-8016-73af295e30a8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f4342f47-d6c6-418b-8016-73af295e30a8_0">
											<gml:posList>35.67382495201339 139.73825703845517 24.857 35.67381702721546 139.73823201595738 24.857 35.67381702721546 139.73823201595738 27.617 35.67382495201339 139.73825703845517 27.617 35.67382495201339 139.73825703845517 24.857</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_d96a59c3-c604-4cbd-b2bb-b077b362df8c_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-20c1651e-684c-433e-ae28-61a17598c9f8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67376289748038 139.73821767524078 25.303 35.6737662943253 139.73821599210822 25.303 35.67378571323667 139.73827730050434 25.303 35.6737823163909 139.7382789836347 25.303 35.67376289748038 139.73821767524078 25.303</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-993c68b2-00d1-45ca-934e-8954285595ea">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67379130858343 139.73827454323427 24.857 35.67378571323667 139.73827730050434 24.857 35.6737662943253 139.73821599210822 24.857 35.67377188967066 139.73821323483455 24.857 35.67379130858343 139.73827454323427 24.857</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2a28fe20-df17-46cd-a800-05604e7f6213">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2a28fe20-df17-46cd-a800-05604e7f6213_0">
											<gml:posList>35.6737662943253 139.73821599210822 25.303 35.67376289748038 139.73821767524078 25.303 35.67376289748038 139.73821767524078 25.824 35.67377188967066 139.73821323483455 25.824 35.67377188967066 139.73821323483455 24.857 35.6737662943253 139.73821599210822 24.857 35.6737662943253 139.73821599210822 25.303</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bd893808-4e05-4412-b5e3-c98d7aebeeb7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bd893808-4e05-4412-b5e3-c98d7aebeeb7_0">
											<gml:posList>35.67376289748038 139.73821767524078 25.824 35.67376289748038 139.73821767524078 25.303 35.6737823163909 139.7382789836347 25.303 35.6737823163909 139.7382789836347 25.824 35.67376289748038 139.73821767524078 25.824</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1b3aa250-68e9-486d-b1f0-1b2da8aa04d6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1b3aa250-68e9-486d-b1f0-1b2da8aa04d6_0">
											<gml:posList>35.6737662943253 139.73821599210822 24.857 35.67378571323667 139.73827730050434 24.857 35.67378571323667 139.73827730050434 25.303 35.6737662943253 139.73821599210822 25.303 35.6737662943253 139.73821599210822 24.857</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c29d1c86-fdcd-48e8-aa8a-018b08913292">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c29d1c86-fdcd-48e8-aa8a-018b08913292_0">
											<gml:posList>35.67376289748038 139.73821767524078 25.824 35.6737823163909 139.7382789836347 25.824 35.67379130858343 139.73827454323427 25.824 35.67377188967066 139.73821323483455 25.824 35.67376289748038 139.73821767524078 25.824</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-20d0b948-61e7-472a-b643-2589baa4ed73">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-20d0b948-61e7-472a-b643-2589baa4ed73_0">
											<gml:posList>35.67379130858343 139.73827454323427 25.824 35.67379130858343 139.73827454323427 24.857 35.67377188967066 139.73821323483455 24.857 35.67377188967066 139.73821323483455 25.824 35.67379130858343 139.73827454323427 25.824</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-113787b7-8f5f-4140-92a7-86eda335879c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-113787b7-8f5f-4140-92a7-86eda335879c_0">
											<gml:posList>35.67378571323667 139.73827730050434 25.303 35.67378571323667 139.73827730050434 24.857 35.67379130858343 139.73827454323427 24.857 35.67379130858343 139.73827454323427 25.824 35.6737823163909 139.7382789836347 25.824 35.6737823163909 139.7382789836347 25.303 35.67378571323667 139.73827730050434 25.303</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-fc957bae-7a81-43db-bba2-b3282bea2250">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fc957bae-7a81-43db-bba2-b3282bea2250">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fc957bae-7a81-43db-bba2-b3282bea2250">
											<gml:posList>35.67392491472299 139.73826908237095 8.32 35.67379768873193 139.7383296588522 8.32 35.67374320010009 139.7381576154868 8.32 35.67387051622993 139.73809714913435 8.32 35.67392491472299 139.73826908237095 8.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-dfca0503-3f7a-45de-8a15-98fd098f3694">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-dfca0503-3f7a-45de-8a15-98fd098f3694">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-dfca0503-3f7a-45de-8a15-98fd098f3694">
											<gml:posList>35.673750501395745 139.73818065028405 25.095 35.673878513366475 139.73812242562462 25.095 35.67387051622993 139.73809714913435 25.095 35.67374320010009 139.7381576154868 25.095 35.673750501395745 139.73818065028405 25.095</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-8c2da1be-7fee-44bf-8be3-ccc1701166c8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8c2da1be-7fee-44bf-8be3-ccc1701166c8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8c2da1be-7fee-44bf-8be3-ccc1701166c8">
											<gml:posList>35.6738760489275 139.73812915601673 25.303 35.673878513366475 139.73812242562462 25.303 35.673750501395745 139.73818065028405 25.303 35.67375607431714 139.73818373675223 25.303 35.6738760489275 139.73812915601673 25.303</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f908a64b-3320-4cae-897d-8b660f389714">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f908a64b-3320-4cae-897d-8b660f389714">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f908a64b-3320-4cae-897d-8b660f389714">
											<gml:posList>35.673844460250585 139.73818037306083 24.857 35.67388600693241 139.73816062740633 24.857 35.6738760489275 139.73812915601673 24.857 35.67375607431714 139.73818373675223 24.857 35.673844460250585 139.73818037306083 24.857</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-440581b4-4b22-462e-9b4f-21d56d2d8036">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-440581b4-4b22-462e-9b4f-21d56d2d8036">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-440581b4-4b22-462e-9b4f-21d56d2d8036">
											<gml:posList>35.67384912234131 139.73818289723008 28.872 35.67388564124672 139.738165532594 28.872 35.67388770087378 139.73815981898312 28.872 35.673844460250585 139.73818037306083 28.872 35.67384912234131 139.73818289723008 28.872</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-9ccd794e-e4f7-425d-a125-ae43bb75c863">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9ccd794e-e4f7-425d-a125-ae43bb75c863">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9ccd794e-e4f7-425d-a125-ae43bb75c863">
											<gml:posList>35.6738760489275 139.73812915601673 25.303 35.67388600693241 139.73816062740633 25.303 35.67388770087378 139.73815981898312 25.303 35.67390688493328 139.73822046493228 25.303 35.6739051999965 139.73822126229697 25.303 35.67391350434974 139.7382475216066 25.303 35.67391904114465 139.73825051975462 25.303 35.673878513366475 139.73812242562462 25.303 35.6738760489275 139.73812915601673 25.303</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-3d35878e-406d-4362-9c50-8b03649dc167">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3d35878e-406d-4362-9c50-8b03649dc167">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3d35878e-406d-4362-9c50-8b03649dc167">
											<gml:posList>35.67388770087378 139.73815981898312 28.872 35.67388564124672 139.738165532594 28.872 35.673902222852114 139.7382179518058 28.872 35.67390688493328 139.73822046493228 28.872 35.67388770087378 139.73815981898312 28.872</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a377e587-8c2e-4b28-8976-27984f1baba8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a377e587-8c2e-4b28-8976-27984f1baba8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a377e587-8c2e-4b28-8976-27984f1baba8">
											<gml:posList>35.67384912234131 139.73818289723008 28.634 35.67386569491676 139.7382353053856 28.634 35.673902222852114 139.7382179518058 28.634 35.67388564124672 139.738165532594 28.634 35.67384912234131 139.73818289723008 28.634</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-096d1927-c8d2-4e48-a318-6a37e28c445a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-096d1927-c8d2-4e48-a318-6a37e28c445a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-096d1927-c8d2-4e48-a318-6a37e28c445a">
											<gml:posList>35.67386569491676 139.7382353053856 28.872 35.67384912234131 139.73818289723008 28.872 35.673844460250585 139.73818037306083 28.872 35.67386364429111 139.73824100793553 28.872 35.67386569491676 139.7382353053856 28.872</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f6afbb45-8f0c-4a3b-9637-127dfe4cfbeb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f6afbb45-8f0c-4a3b-9637-127dfe4cfbeb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f6afbb45-8f0c-4a3b-9637-127dfe4cfbeb">
											<gml:posList>35.67386569491676 139.7382353053856 28.872 35.67386364429111 139.73824100793553 28.872 35.67390688493328 139.73822046493228 28.872 35.673902222852114 139.7382179518058 28.872 35.67386569491676 139.7382353053856 28.872</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-05c813e6-6fd7-4d83-a457-952d561007d5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-05c813e6-6fd7-4d83-a457-952d561007d5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-05c813e6-6fd7-4d83-a457-952d561007d5">
											<gml:posList>35.67375607431714 139.73818373675223 24.857 35.67379423442139 139.7383042112807 24.857 35.67386364429111 139.73824100793553 24.857 35.673844460250585 139.73818037306083 24.857 35.67375607431714 139.73818373675223 24.857</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-15a96854-9d9a-420f-b28e-2f130ed7ceaa">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-15a96854-9d9a-420f-b28e-2f130ed7ceaa">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-15a96854-9d9a-420f-b28e-2f130ed7ceaa">
											<gml:posList>35.673791779029514 139.7383109968831 25.303 35.67379423442139 139.7383042112807 25.303 35.67375607431714 139.73818373675223 25.303 35.673750501395745 139.73818065028405 25.303 35.673791779029514 139.7383109968831 25.303</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ec40bd66-aef1-4de5-8638-33d5366a7bd5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ec40bd66-aef1-4de5-8638-33d5366a7bd5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ec40bd66-aef1-4de5-8638-33d5366a7bd5">
											<gml:posList>35.67391350434974 139.7382475216066 24.857 35.6739051999965 139.73822126229697 24.857 35.67386364429111 139.73824100793553 24.857 35.67379423442139 139.7383042112807 24.857 35.67391350434974 139.7382475216066 24.857</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-2f6a791a-2fd4-4fc2-91e3-2f26ee327f18">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2f6a791a-2fd4-4fc2-91e3-2f26ee327f18">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2f6a791a-2fd4-4fc2-91e3-2f26ee327f18">
											<gml:posList>35.67391904114465 139.73825051975462 25.303 35.67391350434974 139.7382475216066 25.303 35.67379423442139 139.7383042112807 25.303 35.673791779029514 139.7383109968831 25.303 35.67391904114465 139.73825051975462 25.303</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-4a2781ad-abfb-42fb-8d92-3a70d3b40f64">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4a2781ad-abfb-42fb-8d92-3a70d3b40f64">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4a2781ad-abfb-42fb-8d92-3a70d3b40f64">
											<gml:posList>35.67392491472299 139.73826908237095 25.095 35.67391904114465 139.73825051975462 25.095 35.673791779029514 139.7383109968831 25.095 35.67379768873193 139.7383296588522 25.095 35.67392491472299 139.73826908237095 25.095</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1f8bfc80-bc94-47fc-9a2d-40c0e711c863">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1f8bfc80-bc94-47fc-9a2d-40c0e711c863">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1f8bfc80-bc94-47fc-9a2d-40c0e711c863">
											<gml:posList>35.67387051622993 139.73809714913435 8.32 35.67374320010009 139.7381576154868 8.32 35.67374320010009 139.7381576154868 25.095 35.67387051622993 139.73809714913435 25.095 35.67387051622993 139.73809714913435 8.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7cabf825-8ec8-42a6-bc02-88e7fff3b585">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7cabf825-8ec8-42a6-bc02-88e7fff3b585">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7cabf825-8ec8-42a6-bc02-88e7fff3b585">
											<gml:posList>35.6738760489275 139.73812915601673 24.857 35.67388600693241 139.73816062740633 24.857 35.67388600693241 139.73816062740633 25.303 35.6738760489275 139.73812915601673 25.303 35.6738760489275 139.73812915601673 24.857</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-075fac70-e59e-407a-a0ff-af052e3df02e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-075fac70-e59e-407a-a0ff-af052e3df02e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-075fac70-e59e-407a-a0ff-af052e3df02e">
											<gml:posList>35.673750501395745 139.73818065028405 25.095 35.673750501395745 139.73818065028405 25.303 35.673878513366475 139.73812242562462 25.303 35.673878513366475 139.73812242562462 25.095 35.673750501395745 139.73818065028405 25.095</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6b9887b9-4c08-4590-ab62-90b0e0a88656">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6b9887b9-4c08-4590-ab62-90b0e0a88656">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6b9887b9-4c08-4590-ab62-90b0e0a88656">
											<gml:posList>35.6738760489275 139.73812915601673 24.857 35.6738760489275 139.73812915601673 25.303 35.67375607431714 139.73818373675223 25.303 35.67375607431714 139.73818373675223 24.857 35.6738760489275 139.73812915601673 24.857</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-bedc3052-6c1d-4981-b448-a577b7d64664">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bedc3052-6c1d-4981-b448-a577b7d64664">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bedc3052-6c1d-4981-b448-a577b7d64664">
											<gml:posList>35.67388600693241 139.73816062740633 25.303 35.67388600693241 139.73816062740633 24.857 35.673844460250585 139.73818037306083 24.857 35.673844460250585 139.73818037306083 28.872 35.67388770087378 139.73815981898312 28.872 35.67388770087378 139.73815981898312 25.303 35.67388600693241 139.73816062740633 25.303</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-94a5b4cf-bdd5-47dc-a7e7-2979604109c1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-94a5b4cf-bdd5-47dc-a7e7-2979604109c1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-94a5b4cf-bdd5-47dc-a7e7-2979604109c1">
											<gml:posList>35.67388564124672 139.738165532594 28.634 35.67388564124672 139.738165532594 28.872 35.67384912234131 139.73818289723008 28.872 35.67384912234131 139.73818289723008 28.634 35.67388564124672 139.738165532594 28.634</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6c5a5493-bc94-4e91-b55f-1ddf7441ad6f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6c5a5493-bc94-4e91-b55f-1ddf7441ad6f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6c5a5493-bc94-4e91-b55f-1ddf7441ad6f">
											<gml:posList>35.673878513366475 139.73812242562462 25.303 35.67391904114465 139.73825051975462 25.303 35.67391904114465 139.73825051975462 25.095 35.67392491472299 139.73826908237095 25.095 35.67392491472299 139.73826908237095 8.32 35.67387051622993 139.73809714913435 8.32 35.67387051622993 139.73809714913435 25.095 35.673878513366475 139.73812242562462 25.095 35.673878513366475 139.73812242562462 25.303</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-34a2d3f5-e5f3-4d4d-b34a-aada7c8c0e27">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-34a2d3f5-e5f3-4d4d-b34a-aada7c8c0e27">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-34a2d3f5-e5f3-4d4d-b34a-aada7c8c0e27">
											<gml:posList>35.67390688493328 139.73822046493228 28.872 35.67390688493328 139.73822046493228 25.303 35.67388770087378 139.73815981898312 25.303 35.67388770087378 139.73815981898312 28.872 35.67390688493328 139.73822046493228 28.872</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-edb7ed02-d51f-421c-b57d-3b8b596b6f0b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-edb7ed02-d51f-421c-b57d-3b8b596b6f0b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-edb7ed02-d51f-421c-b57d-3b8b596b6f0b">
											<gml:posList>35.673902222852114 139.7382179518058 28.634 35.673902222852114 139.7382179518058 28.872 35.67388564124672 139.738165532594 28.872 35.67388564124672 139.738165532594 28.634 35.673902222852114 139.7382179518058 28.634</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-aa0ef18c-143f-48dc-961b-4672f1deea88">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-aa0ef18c-143f-48dc-961b-4672f1deea88">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-aa0ef18c-143f-48dc-961b-4672f1deea88">
											<gml:posList>35.67384912234131 139.73818289723008 28.634 35.67384912234131 139.73818289723008 28.872 35.67386569491676 139.7382353053856 28.872 35.67386569491676 139.7382353053856 28.634 35.67384912234131 139.73818289723008 28.634</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2b3bd189-3e12-4d81-8f04-d7000ffa8a88">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2b3bd189-3e12-4d81-8f04-d7000ffa8a88">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2b3bd189-3e12-4d81-8f04-d7000ffa8a88">
											<gml:posList>35.673844460250585 139.73818037306083 28.872 35.673844460250585 139.73818037306083 24.857 35.67386364429111 139.73824100793553 24.857 35.67386364429111 139.73824100793553 28.872 35.673844460250585 139.73818037306083 28.872</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-bc875bd8-cb26-4866-a560-dc02cca606ce">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bc875bd8-cb26-4866-a560-dc02cca606ce">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bc875bd8-cb26-4866-a560-dc02cca606ce">
											<gml:posList>35.67386569491676 139.7382353053856 28.634 35.67386569491676 139.7382353053856 28.872 35.673902222852114 139.7382179518058 28.872 35.673902222852114 139.7382179518058 28.634 35.67386569491676 139.7382353053856 28.634</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-da46981e-8b51-40e6-80a0-225a96d70d5b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-da46981e-8b51-40e6-80a0-225a96d70d5b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-da46981e-8b51-40e6-80a0-225a96d70d5b">
											<gml:posList>35.6739051999965 139.73822126229697 25.303 35.67390688493328 139.73822046493228 25.303 35.67390688493328 139.73822046493228 28.872 35.67386364429111 139.73824100793553 28.872 35.67386364429111 139.73824100793553 24.857 35.6739051999965 139.73822126229697 24.857 35.6739051999965 139.73822126229697 25.303</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8a6b5102-ba16-43ad-a951-f65b38d30b71">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8a6b5102-ba16-43ad-a951-f65b38d30b71">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8a6b5102-ba16-43ad-a951-f65b38d30b71">
											<gml:posList>35.67391350434974 139.7382475216066 25.303 35.6739051999965 139.73822126229697 25.303 35.6739051999965 139.73822126229697 24.857 35.67391350434974 139.7382475216066 24.857 35.67391350434974 139.7382475216066 25.303</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4b1fb112-90b7-4e85-83c6-ade1e070b39a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4b1fb112-90b7-4e85-83c6-ade1e070b39a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4b1fb112-90b7-4e85-83c6-ade1e070b39a">
											<gml:posList>35.67379768873193 139.7383296588522 8.32 35.67379768873193 139.7383296588522 25.095 35.673791779029514 139.7383109968831 25.095 35.673791779029514 139.7383109968831 25.303 35.673750501395745 139.73818065028405 25.303 35.673750501395745 139.73818065028405 25.095 35.67374320010009 139.7381576154868 25.095 35.67374320010009 139.7381576154868 8.32 35.67379768873193 139.7383296588522 8.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ad2bd342-ed91-4d3f-913d-c3f45eaebe27">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ad2bd342-ed91-4d3f-913d-c3f45eaebe27">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ad2bd342-ed91-4d3f-913d-c3f45eaebe27">
											<gml:posList>35.67375607431714 139.73818373675223 24.857 35.67375607431714 139.73818373675223 25.303 35.67379423442139 139.7383042112807 25.303 35.67379423442139 139.7383042112807 24.857 35.67375607431714 139.73818373675223 24.857</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-97d8b73c-b73c-485e-8a08-593286dbb872">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-97d8b73c-b73c-485e-8a08-593286dbb872">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-97d8b73c-b73c-485e-8a08-593286dbb872">
											<gml:posList>35.67379423442139 139.7383042112807 24.857 35.67379423442139 139.7383042112807 25.303 35.67391350434974 139.7382475216066 25.303 35.67391350434974 139.7382475216066 24.857 35.67379423442139 139.7383042112807 24.857</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-31886625-4ae5-455c-9d57-14c6e929f188">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-31886625-4ae5-455c-9d57-14c6e929f188">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-31886625-4ae5-455c-9d57-14c6e929f188">
											<gml:posList>35.673791779029514 139.7383109968831 25.303 35.673791779029514 139.7383109968831 25.095 35.67391904114465 139.73825051975462 25.095 35.67391904114465 139.73825051975462 25.303 35.673791779029514 139.7383109968831 25.303</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-da3478d7-1e7f-4ef5-9301-2a5b7ae051e3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-da3478d7-1e7f-4ef5-9301-2a5b7ae051e3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-da3478d7-1e7f-4ef5-9301-2a5b7ae051e3">
											<gml:posList>35.67392491472299 139.73826908237095 25.095 35.67379768873193 139.7383296588522 25.095 35.67379768873193 139.7383296588522 8.32 35.67392491472299 139.73826908237095 8.32 35.67392491472299 139.73826908237095 25.095</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂三丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-4857</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">252.9235</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1210</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>5</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.01</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>