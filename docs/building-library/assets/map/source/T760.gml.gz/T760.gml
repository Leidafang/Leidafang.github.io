<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_d9751836-303f-4cd3-ba42-2656a2ab542e">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>18</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103018001</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="再開発等促進区を定める地区計画">
				<gen:value>虎ノ門駅南地区</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">402</bldg:usage>
			<bldg:measuredHeight uom="m">15.7</bldg:measuredHeight>
			<bldg:storeysAboveGround>5</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>1</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.668774747742376 139.7496978973287 0 35.66872479481162 139.74967364816183 0 35.668688457501325 139.7497862450928 0 35.668738410409794 139.7498104943189 0 35.668774747742376 139.7496978973287 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668774747742376 139.7496978973287 5.766 35.668738410409794 139.7498104943189 5.766 35.668688457501325 139.7497862450928 5.766 35.66872479481162 139.74967364816183 5.766 35.668774747742376 139.7496978973287 5.766</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668774747742376 139.7496978973287 5.766 35.66872479481162 139.74967364816183 5.766 35.66872479481162 139.74967364816183 21.46 35.668774747742376 139.7496978973287 21.46 35.668774747742376 139.7496978973287 5.766</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66872479481162 139.74967364816183 5.766 35.668688457501325 139.7497862450928 5.766 35.668688457501325 139.7497862450928 21.46 35.66872479481162 139.74967364816183 21.46 35.66872479481162 139.74967364816183 5.766</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668688457501325 139.7497862450928 5.766 35.668738410409794 139.7498104943189 5.766 35.668738410409794 139.7498104943189 21.46 35.668688457501325 139.7497862450928 21.46 35.668688457501325 139.7497862450928 5.766</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668738410409794 139.7498104943189 5.766 35.668774747742376 139.7496978973287 5.766 35.668774747742376 139.7496978973287 21.46 35.668738410409794 139.7498104943189 21.46 35.668738410409794 139.7498104943189 5.766</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668774747742376 139.7496978973287 21.46 35.66872479481162 139.74967364816183 21.46 35.668688457501325 139.7497862450928 21.46 35.668738410409794 139.7498104943189 21.46 35.668774747742376 139.7496978973287 21.46</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-47ea23fd-486a-408e-a633-34ad04ddfa9e"/>
							<gml:surfaceMember xlink:href="#poly-dc207d07-3b40-448e-9c5a-61a457abd11c"/>
							<gml:surfaceMember xlink:href="#poly-620c590f-255d-4822-a519-7ecfccebfb17"/>
							<gml:surfaceMember xlink:href="#poly-2df50bf3-7210-4589-bda8-0feb56af0d4f"/>
							<gml:surfaceMember xlink:href="#poly-fba9d6b4-55d6-4cbc-ac76-329b7eb11956"/>
							<gml:surfaceMember xlink:href="#poly-a3a50805-c37a-461c-9cde-fa82885dd65f"/>
							<gml:surfaceMember xlink:href="#poly-d0fa2d49-d733-4e47-a3ba-bcbc1ad999e8"/>
							<gml:surfaceMember xlink:href="#poly-d49d1e85-fdad-44fe-bf86-d9a8d757f457"/>
							<gml:surfaceMember xlink:href="#poly-b6211792-1d73-44d2-98bc-3c96176b3df3"/>
							<gml:surfaceMember xlink:href="#poly-04c27a0d-94d5-40b8-9196-e16404394fc0"/>
							<gml:surfaceMember xlink:href="#poly-587f327f-f25a-486e-88af-a7c75c01696a"/>
							<gml:surfaceMember xlink:href="#poly-ceeb8e0f-06d7-42b7-b6e4-a36d68a329ba"/>
							<gml:surfaceMember xlink:href="#poly-5f8874e9-9793-4eb2-a3e7-06eedc513aec"/>
							<gml:surfaceMember xlink:href="#poly-8690d1ca-1f8c-4e3d-a8e9-898c6f25b27f"/>
							<gml:surfaceMember xlink:href="#poly-4f1b56a2-9092-451f-aa39-b70d3ef96ca7"/>
							<gml:surfaceMember xlink:href="#poly-6277700f-4998-46f0-baa8-0e5aec4e0cf9"/>
							<gml:surfaceMember xlink:href="#poly-c00fadac-6fa3-4397-bb82-619760f07025"/>
							<gml:surfaceMember xlink:href="#poly-0c167383-92cb-4b6d-be30-d0c2a19e2ed7"/>
							<gml:surfaceMember xlink:href="#poly-61bc496c-95e6-4a82-8129-a662db5b58d6"/>
							<gml:surfaceMember xlink:href="#poly-fcb87072-f165-4e4c-9a70-689eb1c9ba21"/>
							<gml:surfaceMember xlink:href="#poly-d432a495-7986-4c37-b58b-14b1b704e8d7"/>
							<gml:surfaceMember xlink:href="#poly-1238cd6a-d31b-48f5-a656-f9ae5cfe0260"/>
							<gml:surfaceMember xlink:href="#poly-2d209403-dee6-40e7-a49c-65c754349058"/>
							<gml:surfaceMember xlink:href="#poly-372c10fb-00b2-4d48-9db9-99c8acfdd77f"/>
							<gml:surfaceMember xlink:href="#poly-2d4d3e99-6063-4a5c-b60a-d508392c8e86"/>
							<gml:surfaceMember xlink:href="#poly-c96ea823-0020-47a9-a8d8-14e588acc27b"/>
							<gml:surfaceMember xlink:href="#poly-18ff0f0c-942f-4897-879d-6015619c826e"/>
							<gml:surfaceMember xlink:href="#poly-44de08df-8383-4479-be14-e3c3fbabc0f4"/>
							<gml:surfaceMember xlink:href="#poly-8a000904-03b1-4094-9358-0efe2954f7b5"/>
							<gml:surfaceMember xlink:href="#poly-d94248cf-0dc1-43ba-87c9-691af12b6060"/>
							<gml:surfaceMember xlink:href="#poly-e5b99df7-608f-4866-b726-4f7ef3d98df5"/>
							<gml:surfaceMember xlink:href="#poly-a0c0dea7-9a36-4542-a80c-92dbe2e1155c"/>
							<gml:surfaceMember xlink:href="#poly-9140cc7a-2e89-4a49-a2f0-c1b18fdc3dfd"/>
							<gml:surfaceMember xlink:href="#poly-d50e8bd9-b0c7-4629-a207-a33a71b891f5"/>
							<gml:surfaceMember xlink:href="#poly-eb5c670e-8441-4312-b8eb-6731454489f6"/>
							<gml:surfaceMember xlink:href="#poly-b75e2c1b-19d1-4ff2-b091-04e33f8df397"/>
							<gml:surfaceMember xlink:href="#poly-a658d506-f24c-490d-84e6-290300859ea4"/>
							<gml:surfaceMember xlink:href="#poly-f32e19f1-0972-4c52-ad12-650056f2c664"/>
							<gml:surfaceMember xlink:href="#poly-c9324cd1-0b2b-41d5-9b6c-1692ad8d2710"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_d9751836-303f-4cd3-ba42-2656a2ab542e_BuildingInstallation_1060">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-95ed7c35-0042-433f-a6db-61340996e9ca">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66871695925919 139.7497607432471 22.352 35.6687249822446 139.7497358702662 22.352 35.668732403042185 139.74973946353623 22.352 35.66872437103465 139.74976432548243 22.352 35.66871695925919 139.7497607432471 22.352</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-17928d2e-42fb-4c2a-aa5a-021caccffa08">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-17928d2e-42fb-4c2a-aa5a-021caccffa08_0">
											<gml:posList>35.668732403042185 139.74973946353623 24.311 35.668732403042185 139.74973946353623 22.352 35.6687249822446 139.7497358702662 22.352 35.6687249822446 139.7497358702662 24.311 35.668732403042185 139.74973946353623 24.311</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-85593882-6e58-4794-94f0-7476f71118ce">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-85593882-6e58-4794-94f0-7476f71118ce_0">
											<gml:posList>35.6687249822446 139.7497358702662 24.311 35.6687249822446 139.7497358702662 22.352 35.66871695925919 139.7497607432471 22.352 35.66871695925919 139.7497607432471 24.311 35.6687249822446 139.7497358702662 24.311</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cba1c7cd-a5a7-458f-a584-597e0477be4f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cba1c7cd-a5a7-458f-a584-597e0477be4f_0">
											<gml:posList>35.66872437103465 139.74976432548243 24.311 35.668732403042185 139.74973946353623 24.311 35.6687249822446 139.7497358702662 24.311 35.66871695925919 139.7497607432471 24.311 35.66872437103465 139.74976432548243 24.311</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c96bd09a-9cc2-459e-af4d-1a0bdbc78dae">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c96bd09a-9cc2-459e-af4d-1a0bdbc78dae_0">
											<gml:posList>35.66872437103465 139.74976432548243 24.311 35.66872437103465 139.74976432548243 22.352 35.668732403042185 139.74973946353623 22.352 35.668732403042185 139.74973946353623 24.311 35.66872437103465 139.74976432548243 24.311</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ffb64b60-3bcb-47bf-abc8-cb134600a9f2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ffb64b60-3bcb-47bf-abc8-cb134600a9f2_0">
											<gml:posList>35.66871695925919 139.7497607432471 24.311 35.66871695925919 139.7497607432471 22.352 35.66872437103465 139.74976432548243 22.352 35.66872437103465 139.74976432548243 24.311 35.66871695925919 139.7497607432471 24.311</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-47ea23fd-486a-408e-a633-34ad04ddfa9e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-47ea23fd-486a-408e-a633-34ad04ddfa9e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-47ea23fd-486a-408e-a633-34ad04ddfa9e">
											<gml:posList>35.66877474774237 139.74969789732867 5.766 35.66873841040978 139.7498104943189 5.766 35.668688457501304 139.7497862450928 5.766 35.66872479481161 139.74967364816183 5.766 35.66877474774237 139.74969789732867 5.766</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-dc207d07-3b40-448e-9c5a-61a457abd11c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-dc207d07-3b40-448e-9c5a-61a457abd11c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-dc207d07-3b40-448e-9c5a-61a457abd11c">
											<gml:posList>35.66872479481161 139.74967364816183 22.7 35.66872566181776 139.74967607738435 22.7 35.6687727744726 139.74969895980666 22.7 35.66877474774237 139.74969789732867 22.7 35.66872479481161 139.74967364816183 22.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-620c590f-255d-4822-a519-7ecfccebfb17">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-620c590f-255d-4822-a519-7ecfccebfb17">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-620c590f-255d-4822-a519-7ecfccebfb17">
											<gml:posList>35.66877474774237 139.74969789732867 22.7 35.6687727744726 139.74969895980666 22.7 35.66876898782514 139.749710672557 22.7 35.66876984580148 139.7497130796986 22.7 35.66877474774237 139.74969789732867 22.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-2df50bf3-7210-4589-bda8-0feb56af0d4f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2df50bf3-7210-4589-bda8-0feb56af0d4f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2df50bf3-7210-4589-bda8-0feb56af0d4f">
											<gml:posList>35.6687684301707 139.74971239632058 22.7 35.66876984580148 139.7497130796986 22.7 35.66876898782514 139.749710672557 22.7 35.6687684301707 139.74971239632058 22.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-fba9d6b4-55d6-4cbc-ac76-329b7eb11956">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fba9d6b4-55d6-4cbc-ac76-329b7eb11956">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fba9d6b4-55d6-4cbc-ac76-329b7eb11956">
											<gml:posList>35.66874725879689 139.7497021345409 24.311 35.6687356380578 139.74973814568554 24.311 35.66873656678612 139.74973859760468 24.311 35.668747647890804 139.74970429915805 24.311 35.668767890543684 139.74971412006528 24.311 35.668756809436246 139.74974841851923 24.311 35.66875822506684 139.7497491018978 24.311 35.66876984580148 139.7497130796986 24.311 35.66874725879689 139.7497021345409 24.311</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a3a50805-c37a-461c-9cde-fa82885dd65f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a3a50805-c37a-461c-9cde-fa82885dd65f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a3a50805-c37a-461c-9cde-fa82885dd65f">
											<gml:posList>35.668767890543684 139.74971412006528 24.16 35.668747647890804 139.74970429915805 24.16 35.66873656678612 139.74973859760468 24.16 35.668756809436246 139.74974841851923 24.16 35.668767890543684 139.74971412006528 24.16</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d0fa2d49-d733-4e47-a3ba-bcbc1ad999e8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d0fa2d49-d733-4e47-a3ba-bcbc1ad999e8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d0fa2d49-d733-4e47-a3ba-bcbc1ad999e8">
											<gml:posList>35.668688457501304 139.7497862450928 22.7 35.66869043979327 139.7497851936547 22.7 35.66872566181776 139.74967607738435 22.7 35.66872479481161 139.74967364816183 22.7 35.668688457501304 139.7497862450928 22.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d49d1e85-fdad-44fe-bf86-d9a8d757f457">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d49d1e85-fdad-44fe-bf86-d9a8d757f457">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d49d1e85-fdad-44fe-bf86-d9a8d757f457">
											<gml:posList>35.66876898782514 139.749710672557 22.352 35.6687727744726 139.74969895980666 22.352 35.66872566181776 139.74967607738435 22.352 35.66869043979327 139.7497851936547 22.352 35.66873756144145 139.74980807612178 22.352 35.668747419289765 139.74977751251905 22.352 35.66874797693748 139.74977577771037 22.352 35.66872437103465 139.74976432548243 22.352 35.66873320353087 139.74973696629812 22.352 35.6687356380578 139.74973814568554 22.352 35.66874725879689 139.7497021345409 22.352 35.6687684301707 139.74971239632058 22.352 35.66876898782514 139.749710672557 22.352</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b6211792-1d73-44d2-98bc-3c96176b3df3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b6211792-1d73-44d2-98bc-3c96176b3df3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b6211792-1d73-44d2-98bc-3c96176b3df3">
											<gml:posList>35.66873320353087 139.74973696629812 25.053 35.6687338899238 139.7497389096844 25.053 35.66875664824726 139.7497499430403 25.053 35.66875822506684 139.7497491018978 25.053 35.66873320353087 139.74973696629812 25.053</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-04c27a0d-94d5-40b8-9196-e16404394fc0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-04c27a0d-94d5-40b8-9196-e16404394fc0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-04c27a0d-94d5-40b8-9196-e16404394fc0">
											<gml:posList>35.66872437103465 139.74976432548243 25.053 35.66872595687573 139.74976349537718 25.053 35.6687338899238 139.7497389096844 25.053 35.66873320353087 139.74973696629812 25.053 35.66872437103465 139.74976432548243 25.053</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-587f327f-f25a-486e-88af-a7c75c01696a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-587f327f-f25a-486e-88af-a7c75c01696a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-587f327f-f25a-486e-88af-a7c75c01696a">
											<gml:posList>35.66875664824726 139.7497499430403 24.833 35.6687338899238 139.7497389096844 24.833 35.66872595687573 139.74976349537718 24.833 35.66874871519698 139.749774528739 24.833 35.66875664824726 139.7497499430403 24.833</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ceeb8e0f-06d7-42b7-b6e4-a36d68a329ba">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ceeb8e0f-06d7-42b7-b6e4-a36d68a329ba">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ceeb8e0f-06d7-42b7-b6e4-a36d68a329ba">
											<gml:posList>35.66875822506684 139.7497491018978 25.053 35.66875664824726 139.7497499430403 25.053 35.66874871519698 139.749774528739 25.053 35.66874939256791 139.74977646108934 25.053 35.66875822506684 139.7497491018978 25.053</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-5f8874e9-9793-4eb2-a3e7-06eedc513aec">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5f8874e9-9793-4eb2-a3e7-06eedc513aec">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5f8874e9-9793-4eb2-a3e7-06eedc513aec">
											<gml:posList>35.66874939256791 139.74977646108934 25.053 35.66874871519698 139.749774528739 25.053 35.66872595687573 139.74976349537718 25.053 35.66872437103465 139.74976432548243 25.053 35.66874939256791 139.74977646108934 25.053</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-8690d1ca-1f8c-4e3d-a8e9-898c6f25b27f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8690d1ca-1f8c-4e3d-a8e9-898c6f25b27f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8690d1ca-1f8c-4e3d-a8e9-898c6f25b27f">
											<gml:posList>35.668747419289765 139.74977751251905 22.7 35.66874939256791 139.74977646108934 22.7 35.66874797693748 139.74977577771037 22.7 35.668747419289765 139.74977751251905 22.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-4f1b56a2-9092-451f-aa39-b70d3ef96ca7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4f1b56a2-9092-451f-aa39-b70d3ef96ca7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4f1b56a2-9092-451f-aa39-b70d3ef96ca7">
											<gml:posList>35.66874939256791 139.74977646108934 22.7 35.668747419289765 139.74977751251905 22.7 35.66873756144145 139.74980807612178 22.7 35.66873841040978 139.7498104943189 22.7 35.66874939256791 139.74977646108934 22.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-6277700f-4998-46f0-baa8-0e5aec4e0cf9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6277700f-4998-46f0-baa8-0e5aec4e0cf9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6277700f-4998-46f0-baa8-0e5aec4e0cf9">
											<gml:posList>35.66873841040978 139.7498104943189 22.7 35.66873756144145 139.74980807612178 22.7 35.66869043979327 139.7497851936547 22.7 35.668688457501304 139.7497862450928 22.7 35.66873841040978 139.7498104943189 22.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c00fadac-6fa3-4397-bb82-619760f07025">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c00fadac-6fa3-4397-bb82-619760f07025">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c00fadac-6fa3-4397-bb82-619760f07025">
											<gml:posList>35.66873656678612 139.74973859760468 24.311 35.66873656678612 139.74973859760468 24.16 35.668747647890804 139.74970429915805 24.16 35.668747647890804 139.74970429915805 24.311 35.66873656678612 139.74973859760468 24.311</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0c167383-92cb-4b6d-be30-d0c2a19e2ed7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0c167383-92cb-4b6d-be30-d0c2a19e2ed7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0c167383-92cb-4b6d-be30-d0c2a19e2ed7">
											<gml:posList>35.66872479481161 139.74967364816183 5.766 35.668688457501304 139.7497862450928 5.766 35.668688457501304 139.7497862450928 22.7 35.66872479481161 139.74967364816183 22.7 35.66872479481161 139.74967364816183 5.766</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-61bc496c-95e6-4a82-8129-a662db5b58d6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-61bc496c-95e6-4a82-8129-a662db5b58d6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-61bc496c-95e6-4a82-8129-a662db5b58d6">
											<gml:posList>35.66869043979327 139.7497851936547 22.7 35.66869043979327 139.7497851936547 22.352 35.66872566181776 139.74967607738435 22.352 35.66872566181776 139.74967607738435 22.7 35.66869043979327 139.7497851936547 22.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-fcb87072-f165-4e4c-9a70-689eb1c9ba21">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fcb87072-f165-4e4c-9a70-689eb1c9ba21">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fcb87072-f165-4e4c-9a70-689eb1c9ba21">
											<gml:posList>35.668688457501304 139.7497862450928 5.766 35.66873841040978 139.7498104943189 5.766 35.66873841040978 139.7498104943189 22.7 35.668688457501304 139.7497862450928 22.7 35.668688457501304 139.7497862450928 5.766</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d432a495-7986-4c37-b58b-14b1b704e8d7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d432a495-7986-4c37-b58b-14b1b704e8d7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d432a495-7986-4c37-b58b-14b1b704e8d7">
											<gml:posList>35.66873756144145 139.74980807612178 22.7 35.66873756144145 139.74980807612178 22.352 35.66869043979327 139.7497851936547 22.352 35.66869043979327 139.7497851936547 22.7 35.66873756144145 139.74980807612178 22.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1238cd6a-d31b-48f5-a656-f9ae5cfe0260">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1238cd6a-d31b-48f5-a656-f9ae5cfe0260">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1238cd6a-d31b-48f5-a656-f9ae5cfe0260">
											<gml:posList>35.66872437103465 139.74976432548243 25.053 35.66873320353087 139.74973696629812 25.053 35.66873320353087 139.74973696629812 22.352 35.66872437103465 139.74976432548243 22.352 35.66872437103465 139.74976432548243 25.053</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2d209403-dee6-40e7-a49c-65c754349058">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2d209403-dee6-40e7-a49c-65c754349058">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2d209403-dee6-40e7-a49c-65c754349058">
											<gml:posList>35.66872595687573 139.74976349537718 25.053 35.66872595687573 139.74976349537718 24.833 35.6687338899238 139.7497389096844 24.833 35.6687338899238 139.7497389096844 25.053 35.66872595687573 139.74976349537718 25.053</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-372c10fb-00b2-4d48-9db9-99c8acfdd77f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-372c10fb-00b2-4d48-9db9-99c8acfdd77f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-372c10fb-00b2-4d48-9db9-99c8acfdd77f">
											<gml:posList>35.66874939256791 139.74977646108934 25.053 35.66872437103465 139.74976432548243 25.053 35.66872437103465 139.74976432548243 22.352 35.66874797693748 139.74977577771037 22.352 35.66874797693748 139.74977577771037 22.7 35.66874939256791 139.74977646108934 22.7 35.66874939256791 139.74977646108934 25.053</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2d4d3e99-6063-4a5c-b60a-d508392c8e86">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2d4d3e99-6063-4a5c-b60a-d508392c8e86">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2d4d3e99-6063-4a5c-b60a-d508392c8e86">
											<gml:posList>35.66874871519698 139.749774528739 25.053 35.66874871519698 139.749774528739 24.833 35.66872595687573 139.74976349537718 24.833 35.66872595687573 139.74976349537718 25.053 35.66874871519698 139.749774528739 25.053</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c96ea823-0020-47a9-a8d8-14e588acc27b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c96ea823-0020-47a9-a8d8-14e588acc27b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c96ea823-0020-47a9-a8d8-14e588acc27b">
											<gml:posList>35.6687356380578 139.74973814568554 24.311 35.66874725879689 139.7497021345409 24.311 35.66874725879689 139.7497021345409 22.352 35.6687356380578 139.74973814568554 22.352 35.6687356380578 139.74973814568554 24.311</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-18ff0f0c-942f-4897-879d-6015619c826e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-18ff0f0c-942f-4897-879d-6015619c826e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-18ff0f0c-942f-4897-879d-6015619c826e">
											<gml:posList>35.668747419289765 139.74977751251905 22.7 35.668747419289765 139.74977751251905 22.352 35.66873756144145 139.74980807612178 22.352 35.66873756144145 139.74980807612178 22.7 35.668747419289765 139.74977751251905 22.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-44de08df-8383-4479-be14-e3c3fbabc0f4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-44de08df-8383-4479-be14-e3c3fbabc0f4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-44de08df-8383-4479-be14-e3c3fbabc0f4">
											<gml:posList>35.6687338899238 139.7497389096844 25.053 35.6687338899238 139.7497389096844 24.833 35.66875664824726 139.7497499430403 24.833 35.66875664824726 139.7497499430403 25.053 35.6687338899238 139.7497389096844 25.053</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8a000904-03b1-4094-9358-0efe2954f7b5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8a000904-03b1-4094-9358-0efe2954f7b5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8a000904-03b1-4094-9358-0efe2954f7b5">
											<gml:posList>35.668756809436246 139.74974841851923 24.311 35.668756809436246 139.74974841851923 24.16 35.66873656678612 139.74973859760468 24.16 35.66873656678612 139.74973859760468 24.311 35.6687356380578 139.74973814568554 24.311 35.6687356380578 139.74973814568554 22.352 35.66873320353087 139.74973696629812 22.352 35.66873320353087 139.74973696629812 25.053 35.66875822506684 139.7497491018978 25.053 35.66875822506684 139.7497491018978 24.311 35.668756809436246 139.74974841851923 24.311</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d94248cf-0dc1-43ba-87c9-691af12b6060">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d94248cf-0dc1-43ba-87c9-691af12b6060">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d94248cf-0dc1-43ba-87c9-691af12b6060">
											<gml:posList>35.66874797693748 139.74977577771037 22.7 35.66874797693748 139.74977577771037 22.352 35.668747419289765 139.74977751251905 22.352 35.668747419289765 139.74977751251905 22.7 35.66874797693748 139.74977577771037 22.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e5b99df7-608f-4866-b726-4f7ef3d98df5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e5b99df7-608f-4866-b726-4f7ef3d98df5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e5b99df7-608f-4866-b726-4f7ef3d98df5">
											<gml:posList>35.66872566181776 139.74967607738435 22.7 35.66872566181776 139.74967607738435 22.352 35.6687727744726 139.74969895980666 22.352 35.6687727744726 139.74969895980666 22.7 35.66872566181776 139.74967607738435 22.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a0c0dea7-9a36-4542-a80c-92dbe2e1155c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a0c0dea7-9a36-4542-a80c-92dbe2e1155c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a0c0dea7-9a36-4542-a80c-92dbe2e1155c">
											<gml:posList>35.66877474774237 139.74969789732867 5.766 35.66872479481161 139.74967364816183 5.766 35.66872479481161 139.74967364816183 22.7 35.66877474774237 139.74969789732867 22.7 35.66877474774237 139.74969789732867 5.766</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9140cc7a-2e89-4a49-a2f0-c1b18fdc3dfd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9140cc7a-2e89-4a49-a2f0-c1b18fdc3dfd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9140cc7a-2e89-4a49-a2f0-c1b18fdc3dfd">
											<gml:posList>35.66875664824726 139.7497499430403 25.053 35.66875664824726 139.7497499430403 24.833 35.66874871519698 139.749774528739 24.833 35.66874871519698 139.749774528739 25.053 35.66875664824726 139.7497499430403 25.053</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d50e8bd9-b0c7-4629-a207-a33a71b891f5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d50e8bd9-b0c7-4629-a207-a33a71b891f5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d50e8bd9-b0c7-4629-a207-a33a71b891f5">
											<gml:posList>35.66875822506684 139.7497491018978 24.311 35.66875822506684 139.7497491018978 25.053 35.66874939256791 139.74977646108934 25.053 35.66874939256791 139.74977646108934 22.7 35.66873841040978 139.7498104943189 22.7 35.66873841040978 139.7498104943189 5.766 35.66877474774237 139.74969789732867 5.766 35.66877474774237 139.74969789732867 22.7 35.66876984580148 139.7497130796986 22.7 35.66876984580148 139.7497130796986 24.311 35.66875822506684 139.7497491018978 24.311</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-eb5c670e-8441-4312-b8eb-6731454489f6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-eb5c670e-8441-4312-b8eb-6731454489f6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-eb5c670e-8441-4312-b8eb-6731454489f6">
											<gml:posList>35.668747647890804 139.74970429915805 24.311 35.668747647890804 139.74970429915805 24.16 35.668767890543684 139.74971412006528 24.16 35.668767890543684 139.74971412006528 24.311 35.668747647890804 139.74970429915805 24.311</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b75e2c1b-19d1-4ff2-b091-04e33f8df397">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b75e2c1b-19d1-4ff2-b091-04e33f8df397">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b75e2c1b-19d1-4ff2-b091-04e33f8df397">
											<gml:posList>35.66874725879689 139.7497021345409 22.352 35.66874725879689 139.7497021345409 24.311 35.66876984580148 139.7497130796986 24.311 35.66876984580148 139.7497130796986 22.7 35.6687684301707 139.74971239632058 22.7 35.6687684301707 139.74971239632058 22.352 35.66874725879689 139.7497021345409 22.352</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a658d506-f24c-490d-84e6-290300859ea4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a658d506-f24c-490d-84e6-290300859ea4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a658d506-f24c-490d-84e6-290300859ea4">
											<gml:posList>35.668767890543684 139.74971412006528 24.311 35.668767890543684 139.74971412006528 24.16 35.668756809436246 139.74974841851923 24.16 35.668756809436246 139.74974841851923 24.311 35.668767890543684 139.74971412006528 24.311</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f32e19f1-0972-4c52-ad12-650056f2c664">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f32e19f1-0972-4c52-ad12-650056f2c664">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f32e19f1-0972-4c52-ad12-650056f2c664">
											<gml:posList>35.66876898782514 139.749710672557 22.7 35.66876898782514 139.749710672557 22.352 35.6687684301707 139.74971239632058 22.352 35.6687684301707 139.74971239632058 22.7 35.66876898782514 139.749710672557 22.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c9324cd1-0b2b-41d5-9b6c-1692ad8d2710">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c9324cd1-0b2b-41d5-9b6c-1692ad8d2710">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c9324cd1-0b2b-41d5-9b6c-1692ad8d2710">
											<gml:posList>35.6687727744726 139.74969895980666 22.7 35.6687727744726 139.74969895980666 22.352 35.66876898782514 139.749710672557 22.352 35.66876898782514 139.749710672557 22.7 35.6687727744726 139.74969895980666 22.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区虎ノ門一丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-258</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">65.3406</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1242</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>7</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>