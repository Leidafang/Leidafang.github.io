<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_d9c44721-68f4-4775-86e4-97af2536ecdb">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3001</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">412</bldg:usage>
			<bldg:measuredHeight uom="m">11.2</bldg:measuredHeight>
			<bldg:storeysAboveGround>3</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.67202271204633 139.73799561767052 0 35.672024881023894 139.73800279530707 0 35.67208750407007 139.73797455228325 0 35.67206970005018 139.73791525379787 0 35.67199581389364 139.7379485916442 0 35.67201144892 139.73800071244676 0 35.67202271204633 139.73799561767052 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67202271204633 139.73799561767052 9.658 35.67201144892 139.73800071244676 9.658 35.67199581389364 139.7379485916442 9.658 35.67206970005018 139.73791525379787 9.658 35.67208750407007 139.73797455228325 9.658 35.672024881023894 139.73800279530707 9.658 35.67202271204633 139.73799561767052 9.658</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67202271204633 139.73799561767052 9.658 35.672024881023894 139.73800279530707 9.658 35.672024881023894 139.73800279530707 20.9 35.67202271204633 139.73799561767052 20.9 35.67202271204633 139.73799561767052 9.658</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672024881023894 139.73800279530707 9.658 35.67208750407007 139.73797455228325 9.658 35.67208750407007 139.73797455228325 20.9 35.672024881023894 139.73800279530707 20.9 35.672024881023894 139.73800279530707 9.658</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67208750407007 139.73797455228325 9.658 35.67206970005018 139.73791525379787 9.658 35.67206970005018 139.73791525379787 20.9 35.67208750407007 139.73797455228325 20.9 35.67208750407007 139.73797455228325 9.658</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67206970005018 139.73791525379787 9.658 35.67199581389364 139.7379485916442 9.658 35.67199581389364 139.7379485916442 20.9 35.67206970005018 139.73791525379787 20.9 35.67206970005018 139.73791525379787 9.658</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67199581389364 139.7379485916442 9.658 35.67201144892 139.73800071244676 9.658 35.67201144892 139.73800071244676 20.9 35.67199581389364 139.7379485916442 20.9 35.67199581389364 139.7379485916442 9.658</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67201144892 139.73800071244676 9.658 35.67202271204633 139.73799561767052 9.658 35.67202271204633 139.73799561767052 20.9 35.67201144892 139.73800071244676 20.9 35.67201144892 139.73800071244676 9.658</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67202271204633 139.73799561767052 20.9 35.672024881023894 139.73800279530707 20.9 35.67208750407007 139.73797455228325 20.9 35.67206970005018 139.73791525379787 20.9 35.67199581389364 139.7379485916442 20.9 35.67201144892 139.73800071244676 20.9 35.67202271204633 139.73799561767052 20.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-0967a191-6dc8-4e0d-b86a-7cf389013df5"/>
							<gml:surfaceMember xlink:href="#poly-eeaff68d-ae2b-4fbf-aae5-c841d4886ef1"/>
							<gml:surfaceMember xlink:href="#poly-206d3e82-9549-44b3-bc9f-42a5ab0bb51a"/>
							<gml:surfaceMember xlink:href="#poly-9ff0123b-5977-406d-ad46-db904c029f34"/>
							<gml:surfaceMember xlink:href="#poly-ea5b4a7f-8ac9-4a0e-ba10-d27e7bea7fa1"/>
							<gml:surfaceMember xlink:href="#poly-c5a59aa9-8f3d-4b22-8d6b-6108dc938d0e"/>
							<gml:surfaceMember xlink:href="#poly-39f4bd21-cddd-4f1e-a201-c341ec0554dd"/>
							<gml:surfaceMember xlink:href="#poly-6dba5add-7e97-4e5e-b87f-3573c502a908"/>
							<gml:surfaceMember xlink:href="#poly-478ec346-cf8f-4372-8ac1-9f1488bd0004"/>
							<gml:surfaceMember xlink:href="#poly-05a4d60d-aa4f-44db-80f1-ebfec1569b11"/>
							<gml:surfaceMember xlink:href="#poly-c44b37cc-d39c-402c-839d-358f18b8313c"/>
							<gml:surfaceMember xlink:href="#poly-e38860d6-970a-404a-af84-6c83fc67ec35"/>
							<gml:surfaceMember xlink:href="#poly-2fd8557c-366d-4c07-b8c6-542395a7fdd2"/>
							<gml:surfaceMember xlink:href="#poly-874e8a90-dd85-440c-bf5c-44900e380b6d"/>
							<gml:surfaceMember xlink:href="#poly-25411261-7ee1-41ad-a5d2-8170727b0f9b"/>
							<gml:surfaceMember xlink:href="#poly-65edde3e-635d-4420-a5b8-b641be5ab422"/>
							<gml:surfaceMember xlink:href="#poly-e6f8e8c4-5758-4812-906c-5d6653845116"/>
							<gml:surfaceMember xlink:href="#poly-524dca03-49c1-42e2-bade-fa85f3462750"/>
							<gml:surfaceMember xlink:href="#poly-21983630-3bfc-4fdc-a920-984ec4b5bb3c"/>
							<gml:surfaceMember xlink:href="#poly-c41cd219-5974-4942-ac85-918673482ee1"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_d9c44721-68f4-4775-86e4-97af2536ecdb_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e673db5e-a6b1-48c4-8dc1-cd0935d08d55">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67207024199565 139.73792804499064 21.445 35.67207314336303 139.7379267159589 21.445 35.67207899067755 139.7379461950146 21.445 35.67207608027874 139.73794750196348 21.445 35.67207024199565 139.73792804499064 21.445</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0a6a95a9-1743-4654-83a1-093cf283a756">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67206408725329 139.73795286273398 21.165 35.67205826707727 139.73793350516056 21.165 35.67207024199565 139.73792804499064 21.165 35.67207608027874 139.73794750196348 21.165 35.67206408725329 139.73795286273398 21.165</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-97117a36-98a8-4144-9381-5e2f7d0b7986">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-97117a36-98a8-4144-9381-5e2f7d0b7986_0">
											<gml:posList>35.67207608027874 139.73794750196348 21.165 35.67207024199565 139.73792804499064 21.165 35.67207024199565 139.73792804499064 21.445 35.67207608027874 139.73794750196348 21.445 35.67207608027874 139.73794750196348 21.165</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-acfc861a-73f2-4695-ba5c-187cb285ea48">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-acfc861a-73f2-4695-ba5c-187cb285ea48_0">
											<gml:posList>35.67206408725329 139.73795286273398 21.165 35.67206408725329 139.73795286273398 23.177 35.67205826707727 139.73793350516056 23.177 35.67205826707727 139.73793350516056 21.165 35.67206408725329 139.73795286273398 21.165</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d58d752f-9ce3-4fd1-a3e6-1bc64d427c0a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d58d752f-9ce3-4fd1-a3e6-1bc64d427c0a_0">
											<gml:posList>35.67207024199565 139.73792804499064 21.445 35.67207024199565 139.73792804499064 21.165 35.67205826707727 139.73793350516056 21.165 35.67205826707727 139.73793350516056 23.177 35.67207314336303 139.7379267159589 22.462 35.67207314336303 139.7379267159589 21.445 35.67207024199565 139.73792804499064 21.445</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-14d38ba4-64d0-4606-99f5-bc1574d5c418">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-14d38ba4-64d0-4606-99f5-bc1574d5c418_0">
											<gml:posList>35.67207899067755 139.7379461950146 22.462 35.67207314336303 139.7379267159589 22.462 35.67205826707727 139.73793350516056 23.177 35.67206408725329 139.73795286273398 23.177 35.67207899067755 139.7379461950146 22.462</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b7a051fc-9249-497a-ae9d-5fc33d957850">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b7a051fc-9249-497a-ae9d-5fc33d957850_0">
											<gml:posList>35.67207899067755 139.7379461950146 22.462 35.67206408725329 139.73795286273398 23.177 35.67206408725329 139.73795286273398 21.165 35.67207608027874 139.73794750196348 21.165 35.67207608027874 139.73794750196348 21.445 35.67207899067755 139.7379461950146 21.445 35.67207899067755 139.7379461950146 22.462</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bbd442b4-99f8-4df2-bec3-6f0b279b591d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bbd442b4-99f8-4df2-bec3-6f0b279b591d_0">
											<gml:posList>35.67207314336303 139.7379267159589 21.445 35.67207314336303 139.7379267159589 22.462 35.67207899067755 139.7379461950146 22.462 35.67207899067755 139.7379461950146 21.445 35.67207314336303 139.7379267159589 21.445</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_d9c44721-68f4-4775-86e4-97af2536ecdb_BuildingInstallation_1041">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-557fcdf6-fb0d-4b26-b9f8-b5d05c7cb368">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672056007284425 139.73792547705128 21.445 35.67203110223833 139.7379367078265 21.445 35.67203022556205 139.73793374841125 21.445 35.67205513059911 139.73792250658875 21.445 35.672056007284425 139.73792547705128 21.445</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ebfe9ef2-17a8-4b05-a12c-327e7ec3857f">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67206532537912 139.7379569595093 21.165 35.67204042033887 139.73796820132253 21.165 35.67203110223833 139.7379367078265 21.165 35.672056007284425 139.73792547705128 21.165 35.67206532537912 139.7379569595093 21.165</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7349c621-7fe3-4585-858d-881e5f3cb411">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7349c621-7fe3-4585-858d-881e5f3cb411_0">
											<gml:posList>35.67203110223833 139.7379367078265 21.445 35.67203110223833 139.7379367078265 21.165 35.67204042033887 139.73796820132253 21.165 35.67204042033887 139.73796820132253 23.599 35.67203022556205 139.73793374841125 23.599 35.67203022556205 139.73793374841125 21.445 35.67203110223833 139.7379367078265 21.445</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d24b06dc-c8d7-4e67-8e46-1f219282c45b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d24b06dc-c8d7-4e67-8e46-1f219282c45b_0">
											<gml:posList>35.67203022556205 139.73793374841125 21.445 35.67203022556205 139.73793374841125 23.599 35.67205513059911 139.73792250658875 23.599 35.67205513059911 139.73792250658875 21.445 35.67203022556205 139.73793374841125 21.445</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-507518a0-e61b-43b9-ba52-8a682ba1d544">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-507518a0-e61b-43b9-ba52-8a682ba1d544_0">
											<gml:posList>35.67203110223833 139.7379367078265 21.445 35.672056007284425 139.73792547705128 21.445 35.672056007284425 139.73792547705128 21.165 35.67203110223833 139.7379367078265 21.165 35.67203110223833 139.7379367078265 21.445</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1246ac78-d537-4c91-9422-8611c30b8701">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1246ac78-d537-4c91-9422-8611c30b8701_0">
											<gml:posList>35.67203022556205 139.73793374841125 23.599 35.67204042033887 139.73796820132253 23.599 35.67206532537912 139.7379569595093 23.599 35.67205513059911 139.73792250658875 23.599 35.67203022556205 139.73793374841125 23.599</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1cbef2ff-fb78-421f-9688-2083a0bd464f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1cbef2ff-fb78-421f-9688-2083a0bd464f_0">
											<gml:posList>35.67206532537912 139.7379569595093 21.165 35.67206532537912 139.7379569595093 23.599 35.67204042033887 139.73796820132253 23.599 35.67204042033887 139.73796820132253 21.165 35.67206532537912 139.7379569595093 21.165</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-35d2c769-86b3-473d-abfc-d18651397fb3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-35d2c769-86b3-473d-abfc-d18651397fb3_0">
											<gml:posList>35.67205513059911 139.73792250658875 23.599 35.67206532537912 139.7379569595093 23.599 35.67206532537912 139.7379569595093 21.165 35.672056007284425 139.73792547705128 21.165 35.672056007284425 139.73792547705128 21.445 35.67205513059911 139.73792250658875 21.445 35.67205513059911 139.73792250658875 23.599</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-0967a191-6dc8-4e0d-b86a-7cf389013df5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0967a191-6dc8-4e0d-b86a-7cf389013df5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0967a191-6dc8-4e0d-b86a-7cf389013df5">
											<gml:posList>35.671995813893616 139.73794859164417 9.658 35.67206970005016 139.73791525379787 9.658 35.67208750407007 139.73797455228325 9.658 35.67202488102389 139.73800279530707 9.658 35.672022712046314 139.73799561767052 9.658 35.672011448919996 139.73800071244676 9.658 35.671995813893616 139.73794859164417 9.658</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-eeaff68d-ae2b-4fbf-aae5-c841d4886ef1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-eeaff68d-ae2b-4fbf-aae5-c841d4886ef1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-eeaff68d-ae2b-4fbf-aae5-c841d4886ef1">
											<gml:posList>35.672026801022504 139.7379346030656 21.445 35.671995813893616 139.73794859164417 16.166 35.672011448919996 139.73800071244676 16.166 35.672026801022504 139.7379346030656 21.445</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-206d3e82-9549-44b3-bc9f-42a5ab0bb51a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-206d3e82-9549-44b3-bc9f-42a5ab0bb51a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-206d3e82-9549-44b3-bc9f-42a5ab0bb51a">
											<gml:posList>35.672026801022504 139.7379346030656 21.445 35.672011448919996 139.73800071244676 16.166 35.672022712046314 139.73799561767052 18.229 35.672026801022504 139.7379346030656 21.445</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-9ff0123b-5977-406d-ad46-db904c029f34">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9ff0123b-5977-406d-ad46-db904c029f34">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9ff0123b-5977-406d-ad46-db904c029f34">
											<gml:posList>35.672026801022504 139.7379346030656 21.445 35.672022712046314 139.73799561767052 18.229 35.67202488102389 139.73800279530707 18.229 35.672026801022504 139.7379346030656 21.445</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ea5b4a7f-8ac9-4a0e-ba10-d27e7bea7fa1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ea5b4a7f-8ac9-4a0e-ba10-d27e7bea7fa1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ea5b4a7f-8ac9-4a0e-ba10-d27e7bea7fa1">
											<gml:posList>35.672026801022504 139.7379346030656 21.445 35.67202488102389 139.73800279530707 18.229 35.67204321740997 139.73799452177713 21.445 35.672026801022504 139.7379346030656 21.445</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c5a59aa9-8f3d-4b22-8d6b-6108dc938d0e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c5a59aa9-8f3d-4b22-8d6b-6108dc938d0e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c5a59aa9-8f3d-4b22-8d6b-6108dc938d0e">
											<gml:posList>35.672026801022504 139.7379346030656 21.445 35.67204321740997 139.73799452177713 21.445 35.672045133457495 139.73798962590416 21.445 35.672030696769724 139.7379368960992 21.445 35.672026801022504 139.7379346030656 21.445</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-39f4bd21-cddd-4f1e-a201-c341ec0554dd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-39f4bd21-cddd-4f1e-a201-c341ec0554dd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-39f4bd21-cddd-4f1e-a201-c341ec0554dd">
											<gml:posList>35.67206970005016 139.73791525379787 21.445 35.672026801022504 139.7379346030656 21.445 35.672030696769724 139.7379368960992 21.445 35.672067865111636 139.73792012748459 21.445 35.67206970005016 139.73791525379787 21.445</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-6dba5add-7e97-4e5e-b87f-3573c502a908">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6dba5add-7e97-4e5e-b87f-3573c502a908">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6dba5add-7e97-4e5e-b87f-3573c502a908">
											<gml:posList>35.672030696769724 139.7379368960992 21.165 35.672045133457495 139.73798962590416 21.165 35.67208352723512 139.73797230352864 21.165 35.672067865111636 139.73792012748459 21.165 35.672030696769724 139.7379368960992 21.165</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-478ec346-cf8f-4372-8ac1-9f1488bd0004">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-478ec346-cf8f-4372-8ac1-9f1488bd0004">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-478ec346-cf8f-4372-8ac1-9f1488bd0004">
											<gml:posList>35.67204321740997 139.73799452177713 21.445 35.67208750407007 139.73797455228325 21.445 35.67208352723512 139.73797230352864 21.445 35.672045133457495 139.73798962590416 21.445 35.67204321740997 139.73799452177713 21.445</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-05a4d60d-aa4f-44db-80f1-ebfec1569b11">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-05a4d60d-aa4f-44db-80f1-ebfec1569b11">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-05a4d60d-aa4f-44db-80f1-ebfec1569b11">
											<gml:posList>35.67208750407007 139.73797455228325 21.445 35.67206970005016 139.73791525379787 21.445 35.672067865111636 139.73792012748459 21.445 35.67208352723512 139.73797230352864 21.445 35.67208750407007 139.73797455228325 21.445</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c44b37cc-d39c-402c-839d-358f18b8313c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c44b37cc-d39c-402c-839d-358f18b8313c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c44b37cc-d39c-402c-839d-358f18b8313c">
											<gml:posList>35.672067865111636 139.73792012748459 21.445 35.672030696769724 139.7379368960992 21.445 35.672030696769724 139.7379368960992 21.165 35.672067865111636 139.73792012748459 21.165 35.672067865111636 139.73792012748459 21.445</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e38860d6-970a-404a-af84-6c83fc67ec35">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e38860d6-970a-404a-af84-6c83fc67ec35">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e38860d6-970a-404a-af84-6c83fc67ec35">
											<gml:posList>35.67206970005016 139.73791525379787 9.658 35.671995813893616 139.73794859164417 9.658 35.671995813893616 139.73794859164417 16.166 35.672026801022504 139.7379346030656 21.445 35.67206970005016 139.73791525379787 21.445 35.67206970005016 139.73791525379787 9.658</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2fd8557c-366d-4c07-b8c6-542395a7fdd2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2fd8557c-366d-4c07-b8c6-542395a7fdd2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2fd8557c-366d-4c07-b8c6-542395a7fdd2">
											<gml:posList>35.67206970005016 139.73791525379787 9.658 35.67206970005016 139.73791525379787 21.445 35.67208750407007 139.73797455228325 21.445 35.67208750407007 139.73797455228325 9.658 35.67206970005016 139.73791525379787 9.658</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-874e8a90-dd85-440c-bf5c-44900e380b6d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-874e8a90-dd85-440c-bf5c-44900e380b6d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-874e8a90-dd85-440c-bf5c-44900e380b6d">
											<gml:posList>35.67208352723512 139.73797230352864 21.445 35.672067865111636 139.73792012748459 21.445 35.672067865111636 139.73792012748459 21.165 35.67208352723512 139.73797230352864 21.165 35.67208352723512 139.73797230352864 21.445</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-25411261-7ee1-41ad-a5d2-8170727b0f9b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-25411261-7ee1-41ad-a5d2-8170727b0f9b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-25411261-7ee1-41ad-a5d2-8170727b0f9b">
											<gml:posList>35.672030696769724 139.7379368960992 21.445 35.672045133457495 139.73798962590416 21.445 35.672045133457495 139.73798962590416 21.165 35.672030696769724 139.7379368960992 21.165 35.672030696769724 139.7379368960992 21.445</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-65edde3e-635d-4420-a5b8-b641be5ab422">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-65edde3e-635d-4420-a5b8-b641be5ab422">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-65edde3e-635d-4420-a5b8-b641be5ab422">
											<gml:posList>35.671995813893616 139.73794859164417 16.166 35.671995813893616 139.73794859164417 9.658 35.672011448919996 139.73800071244676 9.658 35.672011448919996 139.73800071244676 16.166 35.671995813893616 139.73794859164417 16.166</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e6f8e8c4-5758-4812-906c-5d6653845116">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e6f8e8c4-5758-4812-906c-5d6653845116">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e6f8e8c4-5758-4812-906c-5d6653845116">
											<gml:posList>35.672045133457495 139.73798962590416 21.445 35.67208352723512 139.73797230352864 21.445 35.67208352723512 139.73797230352864 21.165 35.672045133457495 139.73798962590416 21.165 35.672045133457495 139.73798962590416 21.445</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-524dca03-49c1-42e2-bade-fa85f3462750">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-524dca03-49c1-42e2-bade-fa85f3462750">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-524dca03-49c1-42e2-bade-fa85f3462750">
											<gml:posList>35.67204321740997 139.73799452177713 21.445 35.67202488102389 139.73800279530707 18.229 35.67202488102389 139.73800279530707 9.658 35.67208750407007 139.73797455228325 9.658 35.67208750407007 139.73797455228325 21.445 35.67204321740997 139.73799452177713 21.445</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-21983630-3bfc-4fdc-a920-984ec4b5bb3c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-21983630-3bfc-4fdc-a920-984ec4b5bb3c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-21983630-3bfc-4fdc-a920-984ec4b5bb3c">
											<gml:posList>35.672022712046314 139.73799561767052 9.658 35.672022712046314 139.73799561767052 18.229 35.672011448919996 139.73800071244676 16.166 35.672011448919996 139.73800071244676 9.658 35.672022712046314 139.73799561767052 9.658</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c41cd219-5974-4942-ac85-918673482ee1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c41cd219-5974-4942-ac85-918673482ee1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c41cd219-5974-4942-ac85-918673482ee1">
											<gml:posList>35.672022712046314 139.73799561767052 18.229 35.672022712046314 139.73799561767052 9.658 35.67202488102389 139.73800279530707 9.658 35.67202488102389 139.73800279530707 18.229 35.672022712046314 139.73799561767052 18.229</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-9225</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">49.0402</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">211</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1320</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>5</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.02</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>