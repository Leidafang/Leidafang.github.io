<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_da3cbc59-aa3c-4866-983f-e6a07f11d084">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">402</bldg:usage>
			<bldg:measuredHeight uom="m">21.9</bldg:measuredHeight>
			<bldg:storeysAboveGround>6</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.66863357844353 139.73791856976177 0 35.668575977738115 139.73800589074256 0 35.668620014784466 139.73804632203914 0 35.66865188351824 139.73799593640305 0 35.66867608554743 139.7380189054496 0 35.66879939564259 139.7378169587379 0 35.66870365014217 139.7377240431442 0 35.66861518598745 139.73790159182954 0 35.66863357844353 139.73791856976177 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
							<gml:interior>
								<gml:LinearRing>
									<gml:posList>35.66867412653573 139.73798092050123 0 35.66864426042431 139.7379535950261 0 35.668654135643756 139.73793737876585 0 35.66866122557667 139.73794386539186 0 35.668656760561746 139.7379511831701 0 35.66867954576514 139.73797203305273 0 35.66867412653573 139.73798092050123 0</gml:posList>
								</gml:LinearRing>
							</gml:interior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66863357844353 139.73791856976177 22.42 35.66861518598745 139.73790159182954 22.42 35.66870365014217 139.7377240431442 22.42 35.66879939564259 139.7378169587379 22.42 35.66867608554743 139.7380189054496 22.42 35.66865188351824 139.73799593640305 22.42 35.668620014784466 139.73804632203914 22.42 35.668575977738115 139.73800589074256 22.42 35.66863357844353 139.73791856976177 22.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
									<gml:interior>
										<gml:LinearRing>
											<gml:posList>35.66867412653573 139.73798092050123 22.42 35.66867954576514 139.73797203305273 22.42 35.668656760561746 139.7379511831701 22.42 35.66866122557667 139.73794386539186 22.42 35.668654135643756 139.73793737876585 22.42 35.66864426042431 139.7379535950261 22.42 35.66867412653573 139.73798092050123 22.42</gml:posList>
										</gml:LinearRing>
									</gml:interior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66863357844353 139.73791856976177 22.42 35.668575977738115 139.73800589074256 22.42 35.668575977738115 139.73800589074256 44.35 35.66863357844353 139.73791856976177 44.35 35.66863357844353 139.73791856976177 22.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668575977738115 139.73800589074256 22.42 35.668620014784466 139.73804632203914 22.42 35.668620014784466 139.73804632203914 44.35 35.668575977738115 139.73800589074256 44.35 35.668575977738115 139.73800589074256 22.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668620014784466 139.73804632203914 22.42 35.66865188351824 139.73799593640305 22.42 35.66865188351824 139.73799593640305 44.35 35.668620014784466 139.73804632203914 44.35 35.668620014784466 139.73804632203914 22.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66865188351824 139.73799593640305 22.42 35.66867608554743 139.7380189054496 22.42 35.66867608554743 139.7380189054496 44.35 35.66865188351824 139.73799593640305 44.35 35.66865188351824 139.73799593640305 22.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66867608554743 139.7380189054496 22.42 35.66879939564259 139.7378169587379 22.42 35.66879939564259 139.7378169587379 44.35 35.66867608554743 139.7380189054496 44.35 35.66867608554743 139.7380189054496 22.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66879939564259 139.7378169587379 22.42 35.66870365014217 139.7377240431442 22.42 35.66870365014217 139.7377240431442 44.35 35.66879939564259 139.7378169587379 44.35 35.66879939564259 139.7378169587379 22.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66870365014217 139.7377240431442 22.42 35.66861518598745 139.73790159182954 22.42 35.66861518598745 139.73790159182954 44.35 35.66870365014217 139.7377240431442 44.35 35.66870365014217 139.7377240431442 22.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66861518598745 139.73790159182954 22.42 35.66863357844353 139.73791856976177 22.42 35.66863357844353 139.73791856976177 44.35 35.66861518598745 139.73790159182954 44.35 35.66861518598745 139.73790159182954 22.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66867412653573 139.73798092050123 22.42 35.66864426042431 139.7379535950261 22.42 35.66864426042431 139.7379535950261 44.35 35.66867412653573 139.73798092050123 44.35 35.66867412653573 139.73798092050123 22.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66864426042431 139.7379535950261 22.42 35.668654135643756 139.73793737876585 22.42 35.668654135643756 139.73793737876585 44.35 35.66864426042431 139.7379535950261 44.35 35.66864426042431 139.7379535950261 22.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668654135643756 139.73793737876585 22.42 35.66866122557667 139.73794386539186 22.42 35.66866122557667 139.73794386539186 44.35 35.668654135643756 139.73793737876585 44.35 35.668654135643756 139.73793737876585 22.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66866122557667 139.73794386539186 22.42 35.668656760561746 139.7379511831701 22.42 35.668656760561746 139.7379511831701 44.35 35.66866122557667 139.73794386539186 44.35 35.66866122557667 139.73794386539186 22.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668656760561746 139.7379511831701 22.42 35.66867954576514 139.73797203305273 22.42 35.66867954576514 139.73797203305273 44.35 35.668656760561746 139.7379511831701 44.35 35.668656760561746 139.7379511831701 22.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66867954576514 139.73797203305273 22.42 35.66867412653573 139.73798092050123 22.42 35.66867412653573 139.73798092050123 44.35 35.66867954576514 139.73797203305273 44.35 35.66867954576514 139.73797203305273 22.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66863357844353 139.73791856976177 44.35 35.668575977738115 139.73800589074256 44.35 35.668620014784466 139.73804632203914 44.35 35.66865188351824 139.73799593640305 44.35 35.66867608554743 139.7380189054496 44.35 35.66879939564259 139.7378169587379 44.35 35.66870365014217 139.7377240431442 44.35 35.66861518598745 139.73790159182954 44.35 35.66863357844353 139.73791856976177 44.35</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
									<gml:interior>
										<gml:LinearRing>
											<gml:posList>35.66867412653573 139.73798092050123 44.35 35.66864426042431 139.7379535950261 44.35 35.668654135643756 139.73793737876585 44.35 35.66866122557667 139.73794386539186 44.35 35.668656760561746 139.7379511831701 44.35 35.66867954576514 139.73797203305273 44.35 35.66867412653573 139.73798092050123 44.35</gml:posList>
										</gml:LinearRing>
									</gml:interior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-e8359dc5-861f-4bcf-a391-bc638c4217bf"/>
							<gml:surfaceMember xlink:href="#poly-2c26ee38-a4bc-4b85-b89c-f2ff234803f6"/>
							<gml:surfaceMember xlink:href="#poly-241c3552-2025-485a-80a4-ca6f495feb03"/>
							<gml:surfaceMember xlink:href="#poly-2ffaa382-9dcc-4d49-a962-2c3cd9b04a73"/>
							<gml:surfaceMember xlink:href="#poly-fccdaa7e-ee22-44de-a99a-0cd1c7dce88b"/>
							<gml:surfaceMember xlink:href="#poly-0eeeb0c8-3672-416f-8ae6-9d54239d10d1"/>
							<gml:surfaceMember xlink:href="#poly-1660e951-12ed-4d2a-988b-f97e38eafbc2"/>
							<gml:surfaceMember xlink:href="#poly-49a78162-2591-4c9e-ba3b-59cb42450aa5"/>
							<gml:surfaceMember xlink:href="#poly-c47bde1a-0f7a-41be-bb5c-b923ba1d7df6"/>
							<gml:surfaceMember xlink:href="#poly-d07293b1-93ee-4352-9580-ac3d3722a30d"/>
							<gml:surfaceMember xlink:href="#poly-74fd709c-349c-4dc6-98da-bdea14fbbf0a"/>
							<gml:surfaceMember xlink:href="#poly-c60d941a-87b6-4218-9e41-e6339b0aa06b"/>
							<gml:surfaceMember xlink:href="#poly-b0e2a0f8-c00f-43d2-bb33-d2c4f4f557bf"/>
							<gml:surfaceMember xlink:href="#poly-7085efe3-2b42-4deb-807d-123f436cd163"/>
							<gml:surfaceMember xlink:href="#poly-7d7361fe-be7d-468c-9575-8e1c1f4aee59"/>
							<gml:surfaceMember xlink:href="#poly-e700876a-acad-481d-a330-bb4ee1ac744c"/>
							<gml:surfaceMember xlink:href="#poly-0b48b174-c447-4d7d-8708-663cd79482d3"/>
							<gml:surfaceMember xlink:href="#poly-c25d9075-b993-4b6c-8d2f-85aa90470842"/>
							<gml:surfaceMember xlink:href="#poly-aa460c8e-51e8-405e-a56a-644eaee070c7"/>
							<gml:surfaceMember xlink:href="#poly-b7e668c2-ca3b-43d3-83d9-20a3a9ef7417"/>
							<gml:surfaceMember xlink:href="#poly-4ba557eb-f3d1-4399-bc42-86bb29fe3c3e"/>
							<gml:surfaceMember xlink:href="#poly-4817b6c0-0e8f-4e87-9794-0472c0311d90"/>
							<gml:surfaceMember xlink:href="#poly-3a7ba300-18db-41ad-b13f-d4f2622be94a"/>
							<gml:surfaceMember xlink:href="#poly-9783bb18-ce44-434f-9943-d77941d9887b"/>
							<gml:surfaceMember xlink:href="#poly-06e54594-ef9d-4283-a968-4ad5e8153cb1"/>
							<gml:surfaceMember xlink:href="#poly-f6920ea3-3105-413f-8329-0ad4cba7c59a"/>
							<gml:surfaceMember xlink:href="#poly-8d520ee0-6a6b-4e32-89ee-6e6fd9486ce1"/>
							<gml:surfaceMember xlink:href="#poly-3609fd27-52f8-4fbc-8cbb-1ddb65161eae"/>
							<gml:surfaceMember xlink:href="#poly-baf37167-e337-4844-9a74-ffeaa24e8a13"/>
							<gml:surfaceMember xlink:href="#poly-c3ea61e2-3f63-406d-9eb7-d99bd32703a5"/>
							<gml:surfaceMember xlink:href="#poly-c9a06ce1-32b0-4b37-abfd-c64ea38a02ca"/>
							<gml:surfaceMember xlink:href="#poly-9dd78e57-f66d-47cf-b5e8-42410258b821"/>
							<gml:surfaceMember xlink:href="#poly-a42e722c-ddd5-4ac2-b582-8b7622d2b521"/>
							<gml:surfaceMember xlink:href="#poly-448accc8-8142-4b57-b713-bd3669e0cfb8"/>
							<gml:surfaceMember xlink:href="#poly-36c13d48-5379-4c75-8193-2f3005f11f61"/>
							<gml:surfaceMember xlink:href="#poly-5bfaee4b-5968-443c-93ed-643d511e42b1"/>
							<gml:surfaceMember xlink:href="#poly-a7810d56-3181-487b-8af2-16510d1acd05"/>
							<gml:surfaceMember xlink:href="#poly-1b2a1b1c-2209-4529-a8ee-e1e56824961f"/>
							<gml:surfaceMember xlink:href="#poly-61f17b7b-a548-4c65-8363-3291f7539d42"/>
							<gml:surfaceMember xlink:href="#poly-d655ab85-8404-491d-a4aa-afa5ed10bd32"/>
							<gml:surfaceMember xlink:href="#poly-3b1eaf6f-e63e-445d-8c1c-4d7040ff2729"/>
							<gml:surfaceMember xlink:href="#poly-1eb1bd82-fc3a-4f3d-8288-7cabc6218def"/>
							<gml:surfaceMember xlink:href="#poly-365af4c0-be5b-4872-86d1-8ea49121ce9a"/>
							<gml:surfaceMember xlink:href="#poly-37823a8e-9b5a-4bdc-a571-88807c0b3f8c"/>
							<gml:surfaceMember xlink:href="#poly-6546766e-926e-4e53-874f-b86e0b33cde9"/>
							<gml:surfaceMember xlink:href="#poly-25b388c9-f045-410d-a395-ffd57fe24283"/>
							<gml:surfaceMember xlink:href="#poly-6473e315-e419-442d-a2f8-ee6b41a86e18"/>
							<gml:surfaceMember xlink:href="#poly-a32a2de2-937e-4262-b6c9-838229ee21b2"/>
							<gml:surfaceMember xlink:href="#poly-57b07bde-328d-402e-8cd6-324e24a34764"/>
							<gml:surfaceMember xlink:href="#poly-14401a7d-d60a-4f76-8925-4cb6a172ef84"/>
							<gml:surfaceMember xlink:href="#poly-b6702d89-e3c8-4d1b-b914-f182fc6bf25d"/>
							<gml:surfaceMember xlink:href="#poly-a18a7c5f-ce58-40d4-bd0e-141d7ce10c39"/>
							<gml:surfaceMember xlink:href="#poly-d918f4b6-e06f-4d7e-b7aa-88b0a0a4d08f"/>
							<gml:surfaceMember xlink:href="#poly-082bacb2-1fc1-4faf-af16-9f17c5b64bbf"/>
							<gml:surfaceMember xlink:href="#poly-c84aaef8-73da-4973-982d-d44cba1608b8"/>
							<gml:surfaceMember xlink:href="#poly-c54a2f9f-db18-4298-8343-a3a7a63d6ba4"/>
							<gml:surfaceMember xlink:href="#poly-22883392-8d25-4c0b-a937-c89a7233f4bf"/>
							<gml:surfaceMember xlink:href="#poly-2d141fa7-52ca-4502-9bdf-2cf9b99d466d"/>
							<gml:surfaceMember xlink:href="#poly-bc118799-2b32-4fd9-a175-e98cbe7d183f"/>
							<gml:surfaceMember xlink:href="#poly-34851473-a014-4129-991f-6259f8ca13e9"/>
							<gml:surfaceMember xlink:href="#poly-4bfb65fb-81a4-49c1-a63f-30ec1ae56f29"/>
							<gml:surfaceMember xlink:href="#poly-edf085c6-c753-4376-a287-9840e71675b5"/>
							<gml:surfaceMember xlink:href="#poly-9640cc84-9134-404b-895a-2b51025d16c5"/>
							<gml:surfaceMember xlink:href="#poly-53893819-d609-4c06-925a-316072c1a8ee"/>
							<gml:surfaceMember xlink:href="#poly-ff93fc34-6fcd-41d2-83c6-a96229735d24"/>
							<gml:surfaceMember xlink:href="#poly-099166ff-22d3-4ba7-b2d5-a7515c31deae"/>
							<gml:surfaceMember xlink:href="#poly-e7307078-8138-455f-8654-7654096694ec"/>
							<gml:surfaceMember xlink:href="#poly-eec888f7-aa4d-4db4-8681-f806ed2cb3ed"/>
							<gml:surfaceMember xlink:href="#poly-d6aa70f5-770c-4886-ab45-0eeeb590eaa4"/>
							<gml:surfaceMember xlink:href="#poly-b695ead2-5395-4297-a045-be6676523185"/>
							<gml:surfaceMember xlink:href="#poly-294b31d9-75ed-4410-bb0f-78ef94921550"/>
							<gml:surfaceMember xlink:href="#poly-e296f40c-acd3-4ab5-8a03-ea16c46a07f1"/>
							<gml:surfaceMember xlink:href="#poly-057ded90-bf8d-438c-b744-75ac0ddad524"/>
							<gml:surfaceMember xlink:href="#poly-503b20df-ff8c-48c2-94fa-dc891ee68a7a"/>
							<gml:surfaceMember xlink:href="#poly-a513d574-4aed-4ebb-983f-96f7ee9786e7"/>
							<gml:surfaceMember xlink:href="#poly-58be4628-ab96-4c53-986d-891e1b5342ae"/>
							<gml:surfaceMember xlink:href="#poly-d39bbab9-5f2c-4daa-bfc8-308376bb3842"/>
							<gml:surfaceMember xlink:href="#poly-8c78d522-8c3c-4e88-a703-24da2b06c68d"/>
							<gml:surfaceMember xlink:href="#poly-63b43a71-f576-4c8f-842e-5d1ac30a890e"/>
							<gml:surfaceMember xlink:href="#poly-f20b1c66-3fc2-45a8-9d9f-808c125a4824"/>
							<gml:surfaceMember xlink:href="#poly-5b9272d3-3fcf-4188-aca0-a385b9f2e7e0"/>
							<gml:surfaceMember xlink:href="#poly-57642add-358a-4653-8657-240c22522f2f"/>
							<gml:surfaceMember xlink:href="#poly-f487fefd-a0a3-49c6-9751-c2b2a6f623ad"/>
							<gml:surfaceMember xlink:href="#poly-f4e24c13-e31f-4ece-b3cf-436b70f4bd7f"/>
							<gml:surfaceMember xlink:href="#poly-fb11aa10-f591-4529-a530-50f80685c11f"/>
							<gml:surfaceMember xlink:href="#poly-18eff981-c2d5-4313-84e3-73c992b6eb1e"/>
							<gml:surfaceMember xlink:href="#poly-b5599cc2-548b-49c5-bd1c-46acbd35eae4"/>
							<gml:surfaceMember xlink:href="#poly-b8d93144-356c-4ce6-8c69-0f66228fbb2c"/>
							<gml:surfaceMember xlink:href="#poly-6e94458d-06c1-4ef6-9c50-794d6aa70ae2"/>
							<gml:surfaceMember xlink:href="#poly-ddaca70d-17da-4cbf-9887-e531276f08b0"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_da3cbc59-aa3c-4866-983f-e6a07f11d084_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3836978e-7159-4835-9a35-191bc5c5dbc8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66876232725829 139.73782338750422 44.555 35.668754729592095 139.73783590066617 44.555 35.66874599797291 139.73782792478292 44.555 35.66875359564706 139.73781542266764 44.555 35.66876232725829 139.73782338750422 44.555</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-81c3ede6-a9b0-4a26-a16c-79cb748403bf">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66872967078105 139.73783510205888 44.555 35.66872363967971 139.73784531577462 44.555 35.66870779138798 139.73783123991538 44.555 35.66871382249689 139.73782103724662 44.555 35.66872967078105 139.73783510205888 44.555</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9ed055c7-4a5e-4093-8a2e-7e0b9b0c5162">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6686874296801 139.73786573881443 44.555 35.66870618208372 139.73783647764967 44.555 35.66872072332348 139.73785047774393 44.555 35.66870197091651 139.73787973891072 44.555 35.6686874296801 139.73786573881443 44.555</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2e45804c-ea8d-402a-a491-8f2cb35f6917">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668663681703485 139.73786978784167 44.555 35.668692231077124 139.73789616490112 44.555 35.668687946059485 139.73790312899777 44.555 35.66865939669611 139.73787676298323 44.555 35.668663681703485 139.73786978784167 44.555</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a7f7cf04-a58c-424f-8112-4b4b73802e5a">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66871876285956 139.73789030101767 44.555 35.66872002580535 139.7378915918999 44.555 35.668709924111106 139.73790637246492 44.555 35.668701155627446 139.73789736934174 44.555 35.6687179377548 139.73787280508802 44.555 35.668725452308095 139.73788051731745 44.555 35.66871876285956 139.73789030101767 44.555</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-63db7637-0a71-4a34-b10a-2f810086d1c7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66865534536219 139.73788287625624 44.555 35.66866488003109 139.73789190055274 44.555 35.668660009734374 139.7378996385654 44.555 35.66865047506606 139.73789061426854 44.555 35.66865534536219 139.73788287625624 44.555</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c4bee3b8-029c-4b15-a98b-4ea0f21b12e9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668660009734374 139.7378996385654 44.555 35.66866488003109 139.73789190055274 44.555 35.66866488003109 139.73789190055274 46.195 35.668660009734374 139.7378996385654 46.195 35.668660009734374 139.7378996385654 44.555</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-30327536-23b0-45ee-a74b-22d76c9cde86">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66873349793318 139.73791004483 50.632 35.66872438747981 139.73790173801075 50.632 35.66873643214532 139.73788191813873 50.632 35.66874554259128 139.73789021391093 50.632 35.66873349793318 139.73791004483 50.632</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-92a77726-a8ee-4f50-92de-a1de2013912e">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66866616094304 139.7378931140906 44.555 35.66866129064625 139.7379008521033 44.555 35.66866129064625 139.7379008521033 46.195 35.66866616094304 139.7378931140906 46.195 35.66866616094304 139.7378931140906 44.555</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ab2b9be8-7aec-4ef2-b4a2-d4fb73ef6101">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66866129064625 139.7379008521033 44.555 35.66866616094304 139.7378931140906 44.555 35.668675452039245 139.7379018846209 44.555 35.66867058174191 139.73790962263396 44.555 35.66866129064625 139.7379008521033 44.555</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8c0e4f87-3c58-4e22-93e4-22eac0af8cd5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668675452039245 139.7379018846209 44.555 35.668675452039245 139.7379018846209 46.195 35.66867058174191 139.73790962263396 46.195 35.66867058174191 139.73790962263396 44.555 35.668675452039245 139.7379018846209 44.555</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bc50d413-05f7-481b-a964-66a3ab920375">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66867672393736 139.7379030981698 44.555 35.66867185363995 139.73791083618292 44.555 35.66867185363995 139.73791083618292 46.195 35.66867672393736 139.7379030981698 46.195 35.66867672393736 139.7379030981698 44.555</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-41efa6a5-7567-402a-93d7-4bca2afd0b75">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66865271712621 139.7379103839777 44.555 35.66864774775609 139.73791822152015 44.555 35.668637762017745 139.73790871173438 44.555 35.66864273138725 139.73790087419232 44.555 35.66865271712621 139.7379103839777 44.555</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-48a50ed5-73c4-4f5a-8d4d-920fa3c09681">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66868170401465 139.7379201473056 44.555 35.66867185363995 139.73791083618292 44.555 35.66867672393736 139.7379030981698 44.555 35.66868657431266 139.73791240929208 44.555 35.66868170401465 139.7379201473056 44.555</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-78d07f29-2e8a-4daf-a62a-4b03c06144e6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66865271712621 139.7379103839777 44.555 35.66865271712621 139.7379103839777 46.195 35.66864774775609 139.73791822152015 46.195 35.66864774775609 139.73791822152015 44.555 35.66865271712621 139.7379103839777 44.555</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d3f955ce-add7-472b-9bf1-d2fe720babe6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668654358867045 139.73791195055895 44.555 35.66864938949685 139.73791978810146 44.555 35.66864938949685 139.73791978810146 46.195 35.668654358867045 139.73791195055895 46.195 35.668654358867045 139.73791195055895 44.555</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-df5073ee-be68-49bd-b1ed-9524ef9f0fa6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66864938949685 139.73791978810146 44.555 35.668654358867045 139.73791195055895 44.555 35.66866355078468 139.73792068807006 44.555 35.668658572408944 139.73792853666967 44.555 35.66864938949685 139.73791978810146 44.555</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ce6009d8-e62a-4f15-a4cc-ca4758049398">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668658572408944 139.73792853666967 44.555 35.66866355078468 139.73792068807006 44.555 35.66866355078468 139.73792068807006 46.195 35.668658572408944 139.73792853666967 46.195 35.668658572408944 139.73792853666967 44.555</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-48508148-54fd-44f8-876c-e7b2cdf2631d">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66865980822565 139.73792971712362 44.555 35.66865980822565 139.73792971712362 46.195 35.668664786601454 139.73792186852398 46.195 35.668664786601454 139.73792186852398 44.555 35.66865980822565 139.73792971712362 44.555</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9f161928-07c0-4bb2-9743-b2816f1778d0">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66867461899163 139.7379312348987 44.555 35.66866964962019 139.737939072442 44.555 35.66865980822565 139.73792971712362 44.555 35.668664786601454 139.73792186852398 44.555 35.66867461899163 139.7379312348987 44.555</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3073861e-03c2-4c03-a5da-1088751c0f5e">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668713285857166 139.7379286483056 44.555 35.66872196378831 139.73791437755452 44.555 35.66872213517163 139.737914531995 44.555 35.66873102012346 139.73792264025525 44.555 35.66871305213798 139.73795220976464 44.555 35.66869738395817 139.73793791275128 44.555 35.66870667400975 139.737922613995 44.555 35.668713285857166 139.7379286483056 44.555</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e4a8acb2-beb7-420e-b32a-25ef737bf9b9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66867436651588 139.73796525695354 38.393 35.66867474461117 139.73796464897254 38.393 35.66868228555248 139.7379715437692 38.393 35.66868178143124 139.73797236177458 38.393 35.66867436651588 139.73796525695354 38.393</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-32a9dc8b-9147-4c0e-b229-cc6aa7caa6d3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66868228555248 139.7379715437692 37.971 35.66867474461117 139.73796464897254 37.971 35.668675140707634 139.737964007832 37.971 35.66869358740331 139.73798119560126 37.971 35.66867985899128 139.7380033371149 37.971 35.668634224856916 139.73796083105992 37.971 35.668648358362546 139.73793803735447 37.971 35.66864969338264 139.7379392839665 37.971 35.6686364420932 139.73796065168636 37.971 35.668679550522036 139.73800080794192 37.971 35.66869149649036 139.73798154051457 37.971 35.66868173643259 139.73797245019634 37.971 35.66868228555248 139.7379715437692 37.971</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4aa9306f-058a-4916-b3e9-0faaee5c6006">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66864440520664 139.7379770676465 37.971 35.66865070122992 139.73798267153765 37.971 35.66864449904761 139.7379931284481 37.971 35.668631852866895 139.73798185445412 37.971 35.66863956735074 139.73796886620744 37.971 35.668645917500484 139.73797452526335 37.971 35.66864440520664 139.7379770676465 37.971</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c958e636-1a1e-46b1-afea-e90f95ca13c9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668589847518604 139.73801430236068 37.971 35.668619254388624 139.7380422248706 37.971 35.66862530405004 139.73803266287598 37.971 35.66862585429812 139.73803318138482 37.971 35.66861965159564 139.7380429865737 37.971 35.66858761153777 139.73801357598197 37.971 35.6686397897934 139.73793106646445 37.971 35.66864147662887 139.7379326661303 37.971 35.668589847518604 139.73801430236068 37.971</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-42dba211-7403-4dba-af61-0e178f2d034f">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66862509908948 139.73799009176852 37.971 35.66863864726279 139.7380021489578 37.971 35.668626918048865 139.73802195736658 37.971 35.66861336986876 139.7380098891297 37.971 35.66862509908948 139.73799009176852 37.971</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-26c1038d-3cbf-4d76-88de-c287ac02ddda">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66858761153777 139.73801357598197 38.393 35.66861965159564 139.7380429865737 38.393 35.66862585429812 139.73803318138482 38.393 35.66862715326233 139.73803442804095 38.393 35.668620086518374 139.73804584697518 38.393 35.6685867563094 139.73801493565813 38.393 35.66858761153777 139.73801357598197 38.393</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-24b9125f-a18e-458d-94b4-6016424552d5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-24b9125f-a18e-458d-94b4-6016424552d5_0">
											<gml:posList>35.66866488003109 139.73789190055274 44.555 35.66865534536219 139.73788287625624 44.555 35.66865534536219 139.73788287625624 46.195 35.66866488003109 139.73789190055274 46.195 35.66866488003109 139.73789190055274 44.555</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-08b061c5-7e93-4412-a87b-df155670435a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-08b061c5-7e93-4412-a87b-df155670435a_0">
											<gml:posList>35.668675452039245 139.7379018846209 44.555 35.66866616094304 139.7378931140906 44.555 35.66866616094304 139.7378931140906 46.195 35.668675452039245 139.7379018846209 46.195 35.668675452039245 139.7379018846209 44.555</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0383e0f9-4291-4df1-bb17-3025f8f90e29">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0383e0f9-4291-4df1-bb17-3025f8f90e29_0">
											<gml:posList>35.66867474461117 139.73796464897254 37.971 35.66868228555248 139.7379715437692 37.971 35.66868228555248 139.7379715437692 38.393 35.66867474461117 139.73796464897254 38.393 35.66867474461117 139.73796464897254 37.971</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-46a7199d-02c9-4e60-b2aa-8d7e21d0accd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-46a7199d-02c9-4e60-b2aa-8d7e21d0accd_0">
											<gml:posList>35.66868178143124 139.73797236177458 38.393 35.66868173643259 139.73797245019634 37.971 35.66869149649036 139.73798154051457 37.971 35.66869149649036 139.73798154051457 39.604 35.66867424048996 139.73796546697793 39.604 35.66867436651588 139.73796525695354 38.393 35.66868178143124 139.73797236177458 38.393</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c24a674d-c904-413f-8ff1-1b40719af0e6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c24a674d-c904-413f-8ff1-1b40719af0e6_0">
											<gml:posList>35.668631852866895 139.73798185445412 37.971 35.668631852866895 139.73798185445412 40.541 35.66863956735074 139.73796886620744 40.541 35.66863956735074 139.73796886620744 37.971 35.668631852866895 139.73798185445412 37.971</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0a05f4c9-1829-4908-90ee-725cd86b901f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0a05f4c9-1829-4908-90ee-725cd86b901f_0">
											<gml:posList>35.66861336986876 139.7380098891297 37.971 35.66861336986876 139.7380098891297 40.541 35.66862509908948 139.73799009176852 40.541 35.66862509908948 139.73799009176852 37.971 35.66861336986876 139.7380098891297 37.971</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d281494e-16bf-404e-a72d-f00d60fa5e00">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d281494e-16bf-404e-a72d-f00d60fa5e00_0">
											<gml:posList>35.66861336986876 139.7380098891297 40.541 35.66861336986876 139.7380098891297 37.971 35.668626918048865 139.73802195736658 37.971 35.668626918048865 139.73802195736658 40.541 35.66861336986876 139.7380098891297 40.541</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6db7f715-06f1-484b-84fd-7f2583fe30be">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6db7f715-06f1-484b-84fd-7f2583fe30be_0">
											<gml:posList>35.66876232725829 139.73782338750422 44.555 35.66875359564706 139.73781542266764 44.555 35.66875359564706 139.73781542266764 46.681 35.66876232725829 139.73782338750422 46.681 35.66876232725829 139.73782338750422 44.555</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-68e468be-42fd-426d-8018-26b463dea226">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-68e468be-42fd-426d-8018-26b463dea226_0">
											<gml:posList>35.66875359564706 139.73781542266764 44.555 35.66874599797291 139.73782792478292 44.555 35.66874599797291 139.73782792478292 46.681 35.66875359564706 139.73781542266764 46.681 35.66875359564706 139.73781542266764 44.555</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3c66caf7-1a53-4ae6-8130-1bd74411c2fd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3c66caf7-1a53-4ae6-8130-1bd74411c2fd_0">
											<gml:posList>35.66876232725829 139.73782338750422 46.681 35.66875359564706 139.73781542266764 46.681 35.66874599797291 139.73782792478292 46.681 35.668754729592095 139.73783590066617 46.681 35.66876232725829 139.73782338750422 46.681</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-75da8c8e-524d-4c49-ae49-e0b52d7d5fbd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-75da8c8e-524d-4c49-ae49-e0b52d7d5fbd_0">
											<gml:posList>35.66871382249689 139.73782103724662 44.555 35.66870779138798 139.73783123991538 44.555 35.66870779138798 139.73783123991538 47.704 35.66871382249689 139.73782103724662 47.704 35.66871382249689 139.73782103724662 44.555</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a2e9982e-451c-4762-b95b-faa1f0812f74">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a2e9982e-451c-4762-b95b-faa1f0812f74_0">
											<gml:posList>35.66871382249689 139.73782103724662 47.704 35.66872967078105 139.73783510205888 47.704 35.66872967078105 139.73783510205888 44.555 35.66871382249689 139.73782103724662 44.555 35.66871382249689 139.73782103724662 47.704</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8d5999f3-4f23-4dbd-925c-19d60228e9fa">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8d5999f3-4f23-4dbd-925c-19d60228e9fa_0">
											<gml:posList>35.66876232725829 139.73782338750422 44.555 35.66876232725829 139.73782338750422 46.681 35.668754729592095 139.73783590066617 46.681 35.668754729592095 139.73783590066617 44.555 35.66876232725829 139.73782338750422 44.555</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d072be84-432c-4cc5-9421-a29af678a533">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d072be84-432c-4cc5-9421-a29af678a533_0">
											<gml:posList>35.66874599797291 139.73782792478292 44.555 35.668754729592095 139.73783590066617 44.555 35.668754729592095 139.73783590066617 46.681 35.66874599797291 139.73782792478292 46.681 35.66874599797291 139.73782792478292 44.555</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-345ca687-e047-4050-bb6e-4455f5367c75">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-345ca687-e047-4050-bb6e-4455f5367c75_0">
											<gml:posList>35.66870779138798 139.73783123991538 47.704 35.66872363967971 139.73784531577462 47.704 35.66872967078105 139.73783510205888 47.704 35.66871382249689 139.73782103724662 47.704 35.66870779138798 139.73783123991538 47.704</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-85b5f223-777f-4a6a-a325-692883c26442">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-85b5f223-777f-4a6a-a325-692883c26442_0">
											<gml:posList>35.66870779138798 139.73783123991538 44.555 35.66872363967971 139.73784531577462 44.555 35.66872363967971 139.73784531577462 47.704 35.66870779138798 139.73783123991538 47.704 35.66870779138798 139.73783123991538 44.555</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1006ce54-6441-4177-83d0-705218296793">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1006ce54-6441-4177-83d0-705218296793_0">
											<gml:posList>35.66872363967971 139.73784531577462 44.555 35.66872967078105 139.73783510205888 44.555 35.66872967078105 139.73783510205888 47.704 35.66872363967971 139.73784531577462 47.704 35.66872363967971 139.73784531577462 44.555</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cf7529f1-e7a7-491a-9627-6681c56cecb3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cf7529f1-e7a7-491a-9627-6681c56cecb3_0">
											<gml:posList>35.66872072332348 139.73785047774393 44.555 35.66870618208372 139.73783647764967 44.555 35.66870618208372 139.73783647764967 47.704 35.66872072332348 139.73785047774393 47.704 35.66872072332348 139.73785047774393 44.555</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-26f2d228-f806-4ba7-a996-0f8b68b6c4ff">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-26f2d228-f806-4ba7-a996-0f8b68b6c4ff_0">
											<gml:posList>35.66870618208372 139.73783647764967 44.555 35.6686874296801 139.73786573881443 44.555 35.6686874296801 139.73786573881443 47.704 35.66870618208372 139.73783647764967 47.704 35.66870618208372 139.73783647764967 44.555</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-48c77a43-d714-4d2e-91ed-b78b30a17ddc">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-48c77a43-d714-4d2e-91ed-b78b30a17ddc_0">
											<gml:posList>35.66872072332348 139.73785047774393 47.704 35.66870618208372 139.73783647764967 47.704 35.6686874296801 139.73786573881443 47.704 35.66870197091651 139.73787973891072 47.704 35.66872072332348 139.73785047774393 47.704</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f3cc708a-f750-4a00-8b81-f1d0c0841501">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f3cc708a-f750-4a00-8b81-f1d0c0841501_0">
											<gml:posList>35.66870197091651 139.73787973891072 44.555 35.66872072332348 139.73785047774393 44.555 35.66872072332348 139.73785047774393 47.704 35.66870197091651 139.73787973891072 47.704 35.66870197091651 139.73787973891072 44.555</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b7069fe9-3422-4ef5-a4c0-f6eedc48b9f4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b7069fe9-3422-4ef5-a4c0-f6eedc48b9f4_0">
											<gml:posList>35.66870197091651 139.73787973891072 44.555 35.66870197091651 139.73787973891072 47.704 35.6686874296801 139.73786573881443 47.704 35.6686874296801 139.73786573881443 44.555 35.66870197091651 139.73787973891072 44.555</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3e6e5464-906f-4795-8786-22ac8252e001">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3e6e5464-906f-4795-8786-22ac8252e001_0">
											<gml:posList>35.668663681703485 139.73786978784167 44.555 35.66865939669611 139.73787676298323 44.555 35.66865939669611 139.73787676298323 46.256 35.668663681703485 139.73786978784167 46.256 35.668663681703485 139.73786978784167 44.555</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-53add4b4-ecb9-4499-9649-feeae7228ba4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-53add4b4-ecb9-4499-9649-feeae7228ba4_0">
											<gml:posList>35.6687179377548 139.73787280508802 44.555 35.6687179377548 139.73787280508802 45.868 35.668725452308095 139.73788051731745 45.868 35.668725452308095 139.73788051731745 44.555 35.6687179377548 139.73787280508802 44.555</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-87bd5858-dba9-4098-beac-83a21916c12a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-87bd5858-dba9-4098-beac-83a21916c12a_0">
											<gml:posList>35.668692231077124 139.73789616490112 44.555 35.668663681703485 139.73786978784167 44.555 35.668663681703485 139.73786978784167 46.256 35.668692231077124 139.73789616490112 46.256 35.668692231077124 139.73789616490112 44.555</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-163945be-f6fd-4ea2-89ad-7844deb87e28">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-163945be-f6fd-4ea2-89ad-7844deb87e28_0">
											<gml:posList>35.6687179377548 139.73787280508802 44.555 35.668701155627446 139.73789736934174 44.555 35.668701155627446 139.73789736934174 45.868 35.6687179377548 139.73787280508802 45.868 35.6687179377548 139.73787280508802 44.555</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-73cff987-c3bb-4b98-aa2a-331d0294c246">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-73cff987-c3bb-4b98-aa2a-331d0294c246_0">
											<gml:posList>35.66871876285956 139.73789030101767 44.555 35.668725452308095 139.73788051731745 44.555 35.668725452308095 139.73788051731745 45.868 35.66871876285956 139.73789030101767 45.868 35.66871876285956 139.73789030101767 44.555</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c29ac50b-0710-45b8-b761-67c969f84565">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c29ac50b-0710-45b8-b761-67c969f84565_0">
											<gml:posList>35.66874554259128 139.73789021391093 51.745 35.66874554259128 139.73789021391093 50.632 35.66873643214532 139.73788191813873 50.632 35.66873643214532 139.73788191813873 51.745 35.66874554259128 139.73789021391093 51.745</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0000d09e-abac-4de2-b105-f625796f9982">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0000d09e-abac-4de2-b105-f625796f9982_0">
											<gml:posList>35.668663681703485 139.73786978784167 46.256 35.66865939669611 139.73787676298323 46.256 35.668687946059485 139.73790312899777 46.256 35.668692231077124 139.73789616490112 46.256 35.668663681703485 139.73786978784167 46.256</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-192de152-0773-4d05-8faf-3f24f311567b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-192de152-0773-4d05-8faf-3f24f311567b_0">
											<gml:posList>35.66865534536219 139.73788287625624 44.555 35.66865047506606 139.73789061426854 44.555 35.66865047506606 139.73789061426854 46.195 35.66865534536219 139.73788287625624 46.195 35.66865534536219 139.73788287625624 44.555</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e3e5a564-b603-49ed-a663-6a8feafe78db">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e3e5a564-b603-49ed-a663-6a8feafe78db_0">
											<gml:posList>35.6687179377548 139.73787280508802 45.868 35.668701155627446 139.73789736934174 45.868 35.668709924111106 139.73790637246492 45.868 35.66872002580535 139.7378915918999 45.868 35.66871876285956 139.73789030101767 45.868 35.668725452308095 139.73788051731745 45.868 35.6687179377548 139.73787280508802 45.868</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f3bdd893-c700-4d7e-9237-09895f833419">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f3bdd893-c700-4d7e-9237-09895f833419_0">
											<gml:posList>35.668687946059485 139.73790312899777 44.555 35.668687946059485 139.73790312899777 46.256 35.66865939669611 139.73787676298323 46.256 35.66865939669611 139.73787676298323 44.555 35.668687946059485 139.73790312899777 44.555</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2ac0c174-8717-4351-913e-599fa9fe74a1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2ac0c174-8717-4351-913e-599fa9fe74a1_0">
											<gml:posList>35.66872002580535 139.7378915918999 44.555 35.66871876285956 139.73789030101767 44.555 35.66871876285956 139.73789030101767 45.868 35.66872002580535 139.7378915918999 45.868 35.66872002580535 139.7378915918999 44.555</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d1f235a6-4800-43ac-a61e-3d0898dc3756">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d1f235a6-4800-43ac-a61e-3d0898dc3756_0">
											<gml:posList>35.66865534536219 139.73788287625624 46.195 35.66865047506606 139.73789061426854 46.195 35.668660009734374 139.7378996385654 46.195 35.66866488003109 139.73789190055274 46.195 35.66865534536219 139.73788287625624 46.195</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-346fa671-1af9-430d-a583-dcd58882e238">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-346fa671-1af9-430d-a583-dcd58882e238_0">
											<gml:posList>35.66873643214532 139.73788191813873 50.632 35.66872438747981 139.73790173801075 50.632 35.66872438747981 139.73790173801075 51.745 35.66873643214532 139.73788191813873 51.745 35.66873643214532 139.73788191813873 50.632</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5d981ff2-faf2-4afb-be0e-bd498fe5a7b8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5d981ff2-faf2-4afb-be0e-bd498fe5a7b8_0">
											<gml:posList>35.66865047506606 139.73789061426854 44.555 35.668660009734374 139.7378996385654 44.555 35.668660009734374 139.7378996385654 46.195 35.66865047506606 139.73789061426854 46.195 35.66865047506606 139.73789061426854 44.555</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-de91438c-c2e6-4945-a5b4-33b29be4a42b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-de91438c-c2e6-4945-a5b4-33b29be4a42b_0">
											<gml:posList>35.66873643214532 139.73788191813873 51.745 35.66872438747981 139.73790173801075 51.745 35.66873349793318 139.73791004483 51.745 35.66874554259128 139.73789021391093 51.745 35.66873643214532 139.73788191813873 51.745</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-72559bc6-68c1-49d3-a806-7ea59eb69b38">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-72559bc6-68c1-49d3-a806-7ea59eb69b38_0">
											<gml:posList>35.66872002580535 139.7378915918999 44.555 35.66872002580535 139.7378915918999 45.868 35.668709924111106 139.73790637246492 45.868 35.668709924111106 139.73790637246492 44.555 35.66872002580535 139.7378915918999 44.555</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-db8b2f74-962c-4a61-8f60-f76c0c168ab1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-db8b2f74-962c-4a61-8f60-f76c0c168ab1_0">
											<gml:posList>35.668692231077124 139.73789616490112 44.555 35.668692231077124 139.73789616490112 46.256 35.668687946059485 139.73790312899777 46.256 35.668687946059485 139.73790312899777 44.555 35.668692231077124 139.73789616490112 44.555</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6a2c72d5-2b18-4e52-a504-3a1a35e9ffcd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6a2c72d5-2b18-4e52-a504-3a1a35e9ffcd_0">
											<gml:posList>35.66874554259128 139.73789021391093 50.632 35.66874554259128 139.73789021391093 51.745 35.66873349793318 139.73791004483 51.745 35.66873349793318 139.73791004483 50.632 35.66874554259128 139.73789021391093 50.632</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fcb256a6-8644-4b7c-b637-298063b27b57">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fcb256a6-8644-4b7c-b637-298063b27b57_0">
											<gml:posList>35.668675452039245 139.7379018846209 46.195 35.66866616094304 139.7378931140906 46.195 35.66866129064625 139.7379008521033 46.195 35.66867058174191 139.73790962263396 46.195 35.668675452039245 139.7379018846209 46.195</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-783e649e-4f7d-44dc-af46-092b0f6bcd58">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-783e649e-4f7d-44dc-af46-092b0f6bcd58_0">
											<gml:posList>35.668701155627446 139.73789736934174 44.555 35.668709924111106 139.73790637246492 44.555 35.668709924111106 139.73790637246492 45.868 35.668701155627446 139.73789736934174 45.868 35.668701155627446 139.73789736934174 44.555</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0cd24938-612b-4854-966b-fd48769f9689">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0cd24938-612b-4854-966b-fd48769f9689_0">
											<gml:posList>35.66864273138725 139.73790087419232 44.555 35.668637762017745 139.73790871173438 44.555 35.668637762017745 139.73790871173438 46.195 35.66864273138725 139.73790087419232 46.195 35.66864273138725 139.73790087419232 44.555</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8e107343-9868-4d82-ad03-22be96e35475">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8e107343-9868-4d82-ad03-22be96e35475_0">
											<gml:posList>35.66866129064625 139.7379008521033 44.555 35.66867058174191 139.73790962263396 44.555 35.66867058174191 139.73790962263396 46.195 35.66866129064625 139.7379008521033 46.195 35.66866129064625 139.7379008521033 44.555</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fa14ed68-876c-430d-8f41-4e1541897640">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fa14ed68-876c-430d-8f41-4e1541897640_0">
											<gml:posList>35.66864273138725 139.73790087419232 44.555 35.66864273138725 139.73790087419232 46.195 35.66865271712621 139.7379103839777 46.195 35.66865271712621 139.7379103839777 44.555 35.66864273138725 139.73790087419232 44.555</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a21e48a8-8a5c-4420-8fb2-c6bf56544dbc">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a21e48a8-8a5c-4420-8fb2-c6bf56544dbc_0">
											<gml:posList>35.66872438747981 139.73790173801075 51.745 35.66872438747981 139.73790173801075 50.632 35.66873349793318 139.73791004483 50.632 35.66873349793318 139.73791004483 51.745 35.66872438747981 139.73790173801075 51.745</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1addfa84-8fae-460e-8bc4-5563a223300e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1addfa84-8fae-460e-8bc4-5563a223300e_0">
											<gml:posList>35.66867672393736 139.7379030981698 44.555 35.66867672393736 139.7379030981698 46.195 35.66868657431266 139.73791240929208 46.195 35.66868657431266 139.73791240929208 44.555 35.66867672393736 139.7379030981698 44.555</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-943d15d7-8b8a-415c-bbc2-88cf9075e424">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-943d15d7-8b8a-415c-bbc2-88cf9075e424_0">
											<gml:posList>35.66865271712621 139.7379103839777 46.195 35.66864273138725 139.73790087419232 46.195 35.668637762017745 139.73790871173438 46.195 35.66864774775609 139.73791822152015 46.195 35.66865271712621 139.7379103839777 46.195</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-60010d86-3480-4c80-88ca-be9983a8392e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-60010d86-3480-4c80-88ca-be9983a8392e_0">
											<gml:posList>35.66867672393736 139.7379030981698 46.195 35.66867185363995 139.73791083618292 46.195 35.66868170401465 139.7379201473056 46.195 35.66868657431266 139.73791240929208 46.195 35.66867672393736 139.7379030981698 46.195</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4039f4b0-6846-4cb9-8978-2b11d3b60475">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4039f4b0-6846-4cb9-8978-2b11d3b60475_0">
											<gml:posList>35.66864774775609 139.73791822152015 44.555 35.66864774775609 139.73791822152015 46.195 35.668637762017745 139.73790871173438 46.195 35.668637762017745 139.73790871173438 44.555 35.66864774775609 139.73791822152015 44.555</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-10077e26-f399-4682-a555-f503ad4bf1f9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-10077e26-f399-4682-a555-f503ad4bf1f9_0">
											<gml:posList>35.66872196378831 139.73791437755452 45.868 35.66872419178881 139.73791640737286 45.868 35.66872213517163 139.737914531995 44.817 35.66872213517163 139.737914531995 44.555 35.66872196378831 139.73791437755452 44.555 35.66872196378831 139.73791437755452 45.868</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-27fd2ec3-8f58-4319-b832-39cbe8ee1a57">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-27fd2ec3-8f58-4319-b832-39cbe8ee1a57_0">
											<gml:posList>35.66867185363995 139.73791083618292 44.555 35.66868170401465 139.7379201473056 44.555 35.66868170401465 139.7379201473056 46.195 35.66867185363995 139.73791083618292 46.195 35.66867185363995 139.73791083618292 44.555</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d61c9308-7eea-41ac-b7bd-aad0511a76dc">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d61c9308-7eea-41ac-b7bd-aad0511a76dc_0">
											<gml:posList>35.66868657431266 139.73791240929208 44.555 35.66868657431266 139.73791240929208 46.195 35.66868170401465 139.7379201473056 46.195 35.66868170401465 139.7379201473056 44.555 35.66868657431266 139.73791240929208 44.555</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a2fbf7a1-a098-4979-9e74-325f03d55eb2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a2fbf7a1-a098-4979-9e74-325f03d55eb2_0">
											<gml:posList>35.66866355078468 139.73792068807006 44.555 35.668654358867045 139.73791195055895 44.555 35.668654358867045 139.73791195055895 46.195 35.66866355078468 139.73792068807006 46.195 35.66866355078468 139.73792068807006 44.555</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0712e59b-7243-44e1-9c51-2e82dc509d7e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0712e59b-7243-44e1-9c51-2e82dc509d7e_0">
											<gml:posList>35.66872213517163 139.737914531995 44.817 35.66872419178881 139.73791640737286 45.868 35.66873102012346 139.73792264025525 45.868 35.66873102012346 139.73792264025525 44.555 35.66872213517163 139.737914531995 44.555 35.66872213517163 139.737914531995 44.817</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-96d78aa6-f800-4f27-b417-9bfb9c104a3a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-96d78aa6-f800-4f27-b417-9bfb9c104a3a_0">
											<gml:posList>35.66866355078468 139.73792068807006 46.195 35.668654358867045 139.73791195055895 46.195 35.66864938949685 139.73791978810146 46.195 35.668658572408944 139.73792853666967 46.195 35.66866355078468 139.73792068807006 46.195</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fdadd13e-d71f-4975-9179-acba11a26522">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fdadd13e-d71f-4975-9179-acba11a26522_0">
											<gml:posList>35.668713285857166 139.7379286483056 44.555 35.668713285857166 139.7379286483056 45.868 35.66872196378831 139.73791437755452 45.868 35.66872196378831 139.73791437755452 44.555 35.668713285857166 139.7379286483056 44.555</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bb703750-0c19-4871-b421-28a8274ad1ae">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bb703750-0c19-4871-b421-28a8274ad1ae_0">
											<gml:posList>35.66864938949685 139.73791978810146 44.555 35.668658572408944 139.73792853666967 44.555 35.668658572408944 139.73792853666967 46.195 35.66864938949685 139.73791978810146 46.195 35.66864938949685 139.73791978810146 44.555</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-228c1d61-d75e-40b4-a66b-b0dbe61ff75a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-228c1d61-d75e-40b4-a66b-b0dbe61ff75a_0">
											<gml:posList>35.668713285857166 139.7379286483056 44.555 35.66870667400975 139.737922613995 44.555 35.66870667400975 139.737922613995 45.868 35.668713285857166 139.7379286483056 45.868 35.668713285857166 139.7379286483056 44.555</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3b74350d-39c0-43bc-88fd-d9cdf01487c7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3b74350d-39c0-43bc-88fd-d9cdf01487c7_0">
											<gml:posList>35.66867461899163 139.7379312348987 44.555 35.668664786601454 139.73792186852398 44.555 35.668664786601454 139.73792186852398 46.195 35.66867461899163 139.7379312348987 46.195 35.66867461899163 139.7379312348987 44.555</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e5bd7e17-0cb1-4e65-ab78-09341d549fdf">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e5bd7e17-0cb1-4e65-ab78-09341d549fdf_0">
											<gml:posList>35.66870667400975 139.737922613995 44.555 35.66869738395817 139.73793791275128 44.555 35.66869738395817 139.73793791275128 45.868 35.66870667400975 139.737922613995 45.868 35.66870667400975 139.737922613995 44.555</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-eb999a76-7108-4c21-9548-2994ca445b57">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-eb999a76-7108-4c21-9548-2994ca445b57_0">
											<gml:posList>35.66867461899163 139.7379312348987 46.195 35.668664786601454 139.73792186852398 46.195 35.66865980822565 139.73792971712362 46.195 35.66866964962019 139.737939072442 46.195 35.66867461899163 139.7379312348987 46.195</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c1de3b3b-fc79-424b-bba1-a742871b8200">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c1de3b3b-fc79-424b-bba1-a742871b8200_0">
											<gml:posList>35.6686397897934 139.73793106646445 40.742 35.66864147662887 139.7379326661303 40.742 35.66864147662887 139.7379326661303 37.971 35.6686397897934 139.73793106646445 37.971 35.6686397897934 139.73793106646445 40.742</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8a1b3dc9-80c2-4c0e-b20f-babf0c462d22">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8a1b3dc9-80c2-4c0e-b20f-babf0c462d22_0">
											<gml:posList>35.66869738395817 139.73793791275128 45.868 35.66871305213798 139.73795220976464 45.868 35.66873102012346 139.73792264025525 45.868 35.66872419178881 139.73791640737286 45.868 35.66872196378831 139.73791437755452 45.868 35.668713285857166 139.7379286483056 45.868 35.66870667400975 139.737922613995 45.868 35.66869738395817 139.73793791275128 45.868</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-374c980c-ff83-4ce1-bb22-c331e6e23051">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-374c980c-ff83-4ce1-bb22-c331e6e23051_0">
											<gml:posList>35.66865980822565 139.73792971712362 44.555 35.66866964962019 139.737939072442 44.555 35.66866964962019 139.737939072442 46.195 35.66865980822565 139.73792971712362 46.195 35.66865980822565 139.73792971712362 44.555</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9b8d1ff4-87e4-4f97-9db6-160b411b1fb5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9b8d1ff4-87e4-4f97-9db6-160b411b1fb5_0">
											<gml:posList>35.66866964962019 139.737939072442 44.555 35.66867461899163 139.7379312348987 44.555 35.66867461899163 139.7379312348987 46.195 35.66866964962019 139.737939072442 46.195 35.66866964962019 139.737939072442 44.555</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8f84a9f2-4c0b-4756-a2a3-c963fef976ea">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8f84a9f2-4c0b-4756-a2a3-c963fef976ea_0">
											<gml:posList>35.66873102012346 139.73792264025525 45.868 35.66871305213798 139.73795220976464 45.868 35.66871305213798 139.73795220976464 44.555 35.66873102012346 139.73792264025525 44.555 35.66873102012346 139.73792264025525 45.868</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-82c3cf1d-4e07-40ec-b067-96b94b903084">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-82c3cf1d-4e07-40ec-b067-96b94b903084_0">
											<gml:posList>35.66864969338264 139.7379392839665 39.604 35.66864969338264 139.7379392839665 37.971 35.668648358362546 139.73793803735447 37.971 35.668648358362546 139.73793803735447 39.604 35.66864969338264 139.7379392839665 39.604</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7d8bc29f-c3b9-4626-87a9-2ee3b2ba2a1d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7d8bc29f-c3b9-4626-87a9-2ee3b2ba2a1d_0">
											<gml:posList>35.66871305213798 139.73795220976464 44.555 35.66871305213798 139.73795220976464 45.868 35.66869738395817 139.73793791275128 45.868 35.66869738395817 139.73793791275128 44.555 35.66871305213798 139.73795220976464 44.555</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-35a20060-4078-4ac5-bfbc-ab4e2a244ba5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-35a20060-4078-4ac5-bfbc-ab4e2a244ba5_0">
											<gml:posList>35.668634224856916 139.73796083105992 39.604 35.668648358362546 139.73793803735447 39.604 35.668648358362546 139.73793803735447 37.971 35.668634224856916 139.73796083105992 37.971 35.668634224856916 139.73796083105992 39.604</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-307f15fb-f49d-4d44-8c61-4e11df5fe915">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-307f15fb-f49d-4d44-8c61-4e11df5fe915_0">
											<gml:posList>35.66864969338264 139.7379392839665 37.971 35.66864969338264 139.7379392839665 39.604 35.6686364420932 139.73796065168636 39.604 35.6686364420932 139.73796065168636 37.971 35.66864969338264 139.7379392839665 37.971</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0a59e073-c988-4ab9-8045-cd946b9b02ae">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0a59e073-c988-4ab9-8045-cd946b9b02ae_0">
											<gml:posList>35.668675140707634 139.737964007832 39.604 35.668675140707634 139.737964007832 37.971 35.66867474461117 139.73796464897254 37.971 35.66867474461117 139.73796464897254 38.393 35.66867436651588 139.73796525695354 38.393 35.66867424048996 139.73796546697793 39.604 35.668675140707634 139.737964007832 39.604</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cb39c8c5-c99f-468f-bb92-f5623e54738a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cb39c8c5-c99f-468f-bb92-f5623e54738a_0">
											<gml:posList>35.66867424048996 139.73796546697793 39.604 35.66869149649036 139.73798154051457 39.604 35.668679550522036 139.73800080794192 39.604 35.6686364420932 139.73796065168636 39.604 35.66864969338264 139.7379392839665 39.604 35.668648358362546 139.73793803735447 39.604 35.668634224856916 139.73796083105992 39.604 35.66867985899128 139.7380033371149 39.604 35.66869358740331 139.73798119560126 39.604 35.668675140707634 139.737964007832 39.604 35.66867424048996 139.73796546697793 39.604</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7979554b-20a9-42f8-95fd-b5e348874d2a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7979554b-20a9-42f8-95fd-b5e348874d2a_0">
											<gml:posList>35.66863956735074 139.73796886620744 37.971 35.66863956735074 139.73796886620744 40.541 35.668645917500484 139.73797452526335 40.541 35.668645917500484 139.73797452526335 37.971 35.66863956735074 139.73796886620744 37.971</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b6c7ff82-5aad-4ec8-b0cc-1200a9d6c41e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b6c7ff82-5aad-4ec8-b0cc-1200a9d6c41e_0">
											<gml:posList>35.66868173643259 139.73797245019634 37.971 35.66868178143124 139.73797236177458 38.393 35.66868228555248 139.7379715437692 38.393 35.66868228555248 139.7379715437692 37.971 35.66868173643259 139.73797245019634 37.971</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-83a10082-7680-451d-955a-70751cafe29d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-83a10082-7680-451d-955a-70751cafe29d_0">
											<gml:posList>35.66869358740331 139.73798119560126 39.604 35.66869358740331 139.73798119560126 37.971 35.668675140707634 139.737964007832 37.971 35.668675140707634 139.737964007832 39.604 35.66869358740331 139.73798119560126 39.604</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c7d3f7e9-578f-46b8-8e4f-1e2e6ca151a3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c7d3f7e9-578f-46b8-8e4f-1e2e6ca151a3_0">
											<gml:posList>35.6685867563094 139.73801493565813 40.742 35.6686397897934 139.73793106646445 40.742 35.6686397897934 139.73793106646445 37.971 35.66858761153777 139.73801357598197 37.971 35.66858761153777 139.73801357598197 38.393 35.6685867563094 139.73801493565813 38.393 35.6685867563094 139.73801493565813 40.742</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9acaadbf-b9fd-4139-b747-6c57081a526e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9acaadbf-b9fd-4139-b747-6c57081a526e_0">
											<gml:posList>35.66864147662887 139.7379326661303 40.742 35.668589847518604 139.73801430236068 40.742 35.668589847518604 139.73801430236068 37.971 35.66864147662887 139.7379326661303 37.971 35.66864147662887 139.7379326661303 40.742</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2b12d91f-cce7-4077-be00-61a7f86042a8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2b12d91f-cce7-4077-be00-61a7f86042a8_0">
											<gml:posList>35.668645917500484 139.73797452526335 37.971 35.668645917500484 139.73797452526335 40.541 35.66864440520664 139.7379770676465 40.541 35.66864440520664 139.7379770676465 37.971 35.668645917500484 139.73797452526335 37.971</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-60e26ea5-e3fe-473d-b35d-1d03282b4019">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-60e26ea5-e3fe-473d-b35d-1d03282b4019_0">
											<gml:posList>35.66864440520664 139.7379770676465 40.541 35.66865070122992 139.73798267153765 40.541 35.66865070122992 139.73798267153765 37.971 35.66864440520664 139.7379770676465 37.971 35.66864440520664 139.7379770676465 40.541</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bc1a2fd4-9376-4e65-9757-ffc59718ab8e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bc1a2fd4-9376-4e65-9757-ffc59718ab8e_0">
											<gml:posList>35.668679550522036 139.73800080794192 37.971 35.6686364420932 139.73796065168636 37.971 35.6686364420932 139.73796065168636 39.604 35.668679550522036 139.73800080794192 39.604 35.668679550522036 139.73800080794192 37.971</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-928bb179-3532-4f6c-8f42-c2ad6fcd5c84">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-928bb179-3532-4f6c-8f42-c2ad6fcd5c84_0">
											<gml:posList>35.668631852866895 139.73798185445412 40.541 35.66864449904761 139.7379931284481 40.541 35.66865070122992 139.73798267153765 40.541 35.66864440520664 139.7379770676465 40.541 35.668645917500484 139.73797452526335 40.541 35.66863956735074 139.73796886620744 40.541 35.668631852866895 139.73798185445412 40.541</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-265b9ec3-6259-4ed1-a1af-c509dfb76e54">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-265b9ec3-6259-4ed1-a1af-c509dfb76e54_0">
											<gml:posList>35.66867985899128 139.7380033371149 37.971 35.66867985899128 139.7380033371149 39.604 35.668634224856916 139.73796083105992 39.604 35.668634224856916 139.73796083105992 37.971 35.66867985899128 139.7380033371149 37.971</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-20a459a0-04d6-4242-a00b-f850646724b6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-20a459a0-04d6-4242-a00b-f850646724b6_0">
											<gml:posList>35.668631852866895 139.73798185445412 40.541 35.668631852866895 139.73798185445412 37.971 35.66864449904761 139.7379931284481 37.971 35.66864449904761 139.7379931284481 40.541 35.668631852866895 139.73798185445412 40.541</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-21b04bdb-17e7-4d96-8447-45d7274ed3da">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-21b04bdb-17e7-4d96-8447-45d7274ed3da_0">
											<gml:posList>35.66865070122992 139.73798267153765 37.971 35.66865070122992 139.73798267153765 40.541 35.66864449904761 139.7379931284481 40.541 35.66864449904761 139.7379931284481 37.971 35.66865070122992 139.73798267153765 37.971</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fade2c54-4cde-478f-883c-4574f447c11a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fade2c54-4cde-478f-883c-4574f447c11a_0">
											<gml:posList>35.6686397897934 139.73793106646445 40.742 35.6685867563094 139.73801493565813 40.742 35.668620086518374 139.73804584697518 40.742 35.66862715326233 139.73803442804095 40.742 35.66862530405004 139.73803266287598 40.742 35.668619254388624 139.7380422248706 40.742 35.668589847518604 139.73801430236068 40.742 35.66864147662887 139.7379326661303 40.742 35.6686397897934 139.73793106646445 40.742</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5ce50ba9-986b-49e6-aae2-94075bd9fe6f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5ce50ba9-986b-49e6-aae2-94075bd9fe6f_0">
											<gml:posList>35.66869149649036 139.73798154051457 39.604 35.66869149649036 139.73798154051457 37.971 35.668679550522036 139.73800080794192 37.971 35.668679550522036 139.73800080794192 39.604 35.66869149649036 139.73798154051457 39.604</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-eaec0d86-e8bf-4c62-b272-b33d55dd03d8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-eaec0d86-e8bf-4c62-b272-b33d55dd03d8_0">
											<gml:posList>35.66867985899128 139.7380033371149 39.604 35.66867985899128 139.7380033371149 37.971 35.66869358740331 139.73798119560126 37.971 35.66869358740331 139.73798119560126 39.604 35.66867985899128 139.7380033371149 39.604</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-28591e60-e0c5-4dce-9d91-43343187fd6d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-28591e60-e0c5-4dce-9d91-43343187fd6d_0">
											<gml:posList>35.66863864726279 139.7380021489578 37.971 35.66862509908948 139.73799009176852 37.971 35.66862509908948 139.73799009176852 40.541 35.66863864726279 139.7380021489578 40.541 35.66863864726279 139.7380021489578 37.971</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8b0475ab-489c-4493-b090-b2dc4af2c759">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8b0475ab-489c-4493-b090-b2dc4af2c759_0">
											<gml:posList>35.668626918048865 139.73802195736658 40.541 35.66863864726279 139.7380021489578 40.541 35.66862509908948 139.73799009176852 40.541 35.66861336986876 139.7380098891297 40.541 35.668626918048865 139.73802195736658 40.541</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-01da1670-81b0-4641-b3a4-39bff295652a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-01da1670-81b0-4641-b3a4-39bff295652a_0">
											<gml:posList>35.668626918048865 139.73802195736658 40.541 35.668626918048865 139.73802195736658 37.971 35.66863864726279 139.7380021489578 37.971 35.66863864726279 139.7380021489578 40.541 35.668626918048865 139.73802195736658 40.541</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-984fdf9b-3c9d-40a7-b326-9ef6a730fe3d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-984fdf9b-3c9d-40a7-b326-9ef6a730fe3d_0">
											<gml:posList>35.668589847518604 139.73801430236068 40.742 35.668619254388624 139.7380422248706 40.742 35.668619254388624 139.7380422248706 37.971 35.668589847518604 139.73801430236068 37.971 35.668589847518604 139.73801430236068 40.742</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d001d26b-941b-447f-98ed-7e2d32c5a737">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d001d26b-941b-447f-98ed-7e2d32c5a737_0">
											<gml:posList>35.66858761153777 139.73801357598197 37.971 35.66861965159564 139.7380429865737 37.971 35.66861965159564 139.7380429865737 38.393 35.66858761153777 139.73801357598197 38.393 35.66858761153777 139.73801357598197 37.971</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b837d494-ee7d-4286-a5c0-9a3003dff447">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b837d494-ee7d-4286-a5c0-9a3003dff447_0">
											<gml:posList>35.6685867563094 139.73801493565813 38.393 35.668620086518374 139.73804584697518 38.393 35.668620086518374 139.73804584697518 40.742 35.6685867563094 139.73801493565813 40.742 35.6685867563094 139.73801493565813 38.393</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3a0297ad-84eb-43b6-a5ad-561ead6d3fb7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3a0297ad-84eb-43b6-a5ad-561ead6d3fb7_0">
											<gml:posList>35.66862715326233 139.73803442804095 38.393 35.66862585429812 139.73803318138482 38.393 35.66862585429812 139.73803318138482 37.971 35.66862530405004 139.73803266287598 37.971 35.66862530405004 139.73803266287598 40.742 35.66862715326233 139.73803442804095 40.742 35.66862715326233 139.73803442804095 38.393</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-48113e94-8b82-4936-9852-742d82d224f5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-48113e94-8b82-4936-9852-742d82d224f5_0">
											<gml:posList>35.66862530405004 139.73803266287598 40.742 35.66862530405004 139.73803266287598 37.971 35.668619254388624 139.7380422248706 37.971 35.668619254388624 139.7380422248706 40.742 35.66862530405004 139.73803266287598 40.742</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ec3d8be3-2ab6-4255-9ff1-366dee4f75c9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ec3d8be3-2ab6-4255-9ff1-366dee4f75c9_0">
											<gml:posList>35.66861965159564 139.7380429865737 38.393 35.66861965159564 139.7380429865737 37.971 35.66862585429812 139.73803318138482 37.971 35.66862585429812 139.73803318138482 38.393 35.66861965159564 139.7380429865737 38.393</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a1f775cf-e628-4003-bca8-03ad7e447281">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a1f775cf-e628-4003-bca8-03ad7e447281_0">
											<gml:posList>35.66862715326233 139.73803442804095 38.393 35.66862715326233 139.73803442804095 40.742 35.668620086518374 139.73804584697518 40.742 35.668620086518374 139.73804584697518 38.393 35.66862715326233 139.73803442804095 38.393</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_da3cbc59-aa3c-4866-983f-e6a07f11d084_BuildingInstallation_1060">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-26c8522e-20ca-44bc-a46b-fd12e3920ae9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-26c8522e-20ca-44bc-a46b-fd12e3920ae9_0">
											<gml:posList>35.66856947761983 139.73801574046507 22.42 35.66857597772934 139.73800587969654 32.141 35.66857597772934 139.73800587969654 22.42 35.66856947761983 139.73801574046507 22.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e81e3a62-371c-4bad-8ff4-1126adebd2ce">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e81e3a62-371c-4bad-8ff4-1126adebd2ce_0">
											<gml:posList>35.66856947761983 139.73801574046507 22.42 35.66856947761983 139.73801574046507 32.141 35.66857597772934 139.73800587969654 32.141 35.66856947761983 139.73801574046507 22.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9d3581a1-34d2-446a-8488-8addbc39c008">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9d3581a1-34d2-446a-8488-8addbc39c008_0">
											<gml:posList>35.66862001478444 139.73804632203914 22.42 35.66857597772934 139.73800587969654 32.141 35.66862001478444 139.73804632203914 32.141 35.66862001478444 139.73804632203914 22.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c33c5c13-662c-4a3a-8a62-7580752701e1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c33c5c13-662c-4a3a-8a62-7580752701e1_0">
											<gml:posList>35.66862001478444 139.73804632203914 22.42 35.66857597772934 139.73800587969654 22.42 35.66857597772934 139.73800587969654 32.141 35.66862001478444 139.73804632203914 22.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-687a8494-b0e5-4ce7-97ca-054d968ca102">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-687a8494-b0e5-4ce7-97ca-054d968ca102_0">
											<gml:posList>35.66856947761983 139.73801574046507 22.42 35.66863641155187 139.7380814951701 32.141 35.66856947761983 139.73801574046507 32.141 35.66856947761983 139.73801574046507 22.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8b31778c-4d00-410d-8502-dae2028cde3e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8b31778c-4d00-410d-8502-dae2028cde3e_0">
											<gml:posList>35.66856947761983 139.73801574046507 22.42 35.66863641155187 139.7380814951701 22.42 35.66863641155187 139.7380814951701 32.141 35.66856947761983 139.73801574046507 22.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8a441b1c-e340-4bd2-9ac6-c31920000ec7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8a441b1c-e340-4bd2-9ac6-c31920000ec7_0">
											<gml:posList>35.66857597772934 139.73800587969654 32.141 35.66856947761983 139.73801574046507 32.141 35.66862001478444 139.73804632203914 32.141 35.66857597772934 139.73800587969654 32.141</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a2cf5407-7e3b-4570-bafa-0134fdb34102">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a2cf5407-7e3b-4570-bafa-0134fdb34102_0">
											<gml:posList>35.66856947761983 139.73801574046507 32.141 35.66863641155187 139.7380814951701 32.141 35.66862001478444 139.73804632203914 32.141 35.66856947761983 139.73801574046507 32.141</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0848a590-019e-4823-8843-3a99cf878161">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0848a590-019e-4823-8843-3a99cf878161_0">
											<gml:posList>35.66862001478444 139.73804632203914 32.141 35.6686497351998 139.73806041458076 32.141 35.66862558731321 139.73803751174097 32.141 35.66862001478444 139.73804632203914 32.141</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6d363932-f45e-43d1-84c6-e1503676f921">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6d363932-f45e-43d1-84c6-e1503676f921_0">
											<gml:posList>35.66862001478444 139.73804632203914 32.141 35.66863641155187 139.7380814951701 32.141 35.6686497351998 139.73806041458076 32.141 35.66862001478444 139.73804632203914 32.141</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-834af8a7-ea52-4105-b0a9-9f2d884f7ede">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-834af8a7-ea52-4105-b0a9-9f2d884f7ede_0">
											<gml:posList>35.66862558731321 139.73803751174097 22.42 35.66862001478444 139.73804632203914 32.141 35.66862558731321 139.73803751174097 32.141 35.66862558731321 139.73803751174097 22.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-be8bcc43-7980-4acd-98ba-4c57253813fd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-be8bcc43-7980-4acd-98ba-4c57253813fd_0">
											<gml:posList>35.66862558731321 139.73803751174097 22.42 35.66862001478444 139.73804632203914 22.42 35.66862001478444 139.73804632203914 32.141 35.66862558731321 139.73803751174097 22.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-19a77623-04ed-4dbe-827e-07287dca9304">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-19a77623-04ed-4dbe-827e-07287dca9304_0">
											<gml:posList>35.66862558731321 139.73803751174097 32.141 35.6686497351998 139.73806041458076 38.393 35.66862558731321 139.73803751174097 38.393 35.66862558731321 139.73803751174097 32.141</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a8b157d5-1193-4834-b262-905410cfaf46">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a8b157d5-1193-4834-b262-905410cfaf46_0">
											<gml:posList>35.66862558731321 139.73803751174097 32.141 35.6686497351998 139.73806041458076 32.141 35.6686497351998 139.73806041458076 38.393 35.66862558731321 139.73803751174097 32.141</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b76a0325-ee83-43d3-b3f8-8c1684a2f59d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b76a0325-ee83-43d3-b3f8-8c1684a2f59d_0">
											<gml:posList>35.6686497351998 139.73806041458076 22.42 35.66863641155187 139.7380814951701 32.141 35.66863641155187 139.7380814951701 22.42 35.6686497351998 139.73806041458076 22.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e89d75af-f4cc-4bb6-bfd7-d32f80038e6e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e89d75af-f4cc-4bb6-bfd7-d32f80038e6e_0">
											<gml:posList>35.6686497351998 139.73806041458076 22.42 35.6686497351998 139.73806041458076 32.141 35.66863641155187 139.7380814951701 32.141 35.6686497351998 139.73806041458076 22.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e0772942-80ae-4591-a31e-ee618b6a7b9c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e0772942-80ae-4591-a31e-ee618b6a7b9c_0">
											<gml:posList>35.668654135652496 139.73793738981186 38.363 35.66864426042429 139.73795359502608 23.56 35.66864426042429 139.73795359502608 38.363 35.668654135652496 139.73793738981186 38.363</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b14a78ae-0d59-41af-b8ab-2b90c45b84a4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b14a78ae-0d59-41af-b8ab-2b90c45b84a4_0">
											<gml:posList>35.668654135652496 139.73793738981186 38.363 35.668654135652496 139.73793738981186 23.56 35.66864426042429 139.73795359502608 23.56 35.668654135652496 139.73793738981186 38.363</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ed3d2793-01da-4a68-b158-067cbae65ece">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ed3d2793-01da-4a68-b158-067cbae65ece_0">
											<gml:posList>35.668651883518244 139.73799593640305 38.393 35.6686497351998 139.73806041458076 38.393 35.66867600436271 139.73801882822394 38.393 35.668651883518244 139.73799593640305 38.393</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-34d7e8db-4f63-4010-9656-966670e53f56">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-34d7e8db-4f63-4010-9656-966670e53f56_0">
											<gml:posList>35.668651883518244 139.73799593640305 38.393 35.66862558731321 139.73803751174097 38.393 35.6686497351998 139.73806041458076 38.393 35.668651883518244 139.73799593640305 38.393</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5c89d4ae-078c-4439-93f6-16cc359a2fa4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5c89d4ae-078c-4439-93f6-16cc359a2fa4_0">
											<gml:posList>35.66865760675812 139.73794980141074 38.363 35.66865676056172 139.73795118317008 23.56 35.66865760675812 139.73794980141074 23.56 35.66865760675812 139.73794980141074 38.363</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-90ea6fa1-a398-4201-b680-1532847236a8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-90ea6fa1-a398-4201-b680-1532847236a8_0">
											<gml:posList>35.66865760675812 139.73794980141074 38.363 35.66865676056172 139.73795118317008 38.363 35.66865676056172 139.73795118317008 23.56 35.66865760675812 139.73794980141074 38.363</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0f8cd24e-53d6-4e89-950b-a45fff71d346">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0f8cd24e-53d6-4e89-950b-a45fff71d346_0">
											<gml:posList>35.66866122558541 139.73794387643787 38.363 35.668654135652496 139.73793738981186 23.56 35.668654135652496 139.73793738981186 38.363 35.66866122558541 139.73794387643787 38.363</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9e4eaffe-ac6d-44df-a550-79356876ea72">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9e4eaffe-ac6d-44df-a550-79356876ea72_0">
											<gml:posList>35.66866122558541 139.73794387643787 38.363 35.66866122558541 139.73794387643787 23.56 35.668654135652496 139.73793738981186 23.56 35.66866122558541 139.73794387643787 38.363</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1740038e-9255-4e53-b0d4-55bb859ae9e3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1740038e-9255-4e53-b0d4-55bb859ae9e3_0">
											<gml:posList>35.66864426042429 139.73795359502608 23.56 35.668674126535734 139.73798092050123 38.363 35.66864426042429 139.73795359502608 38.363 35.66864426042429 139.73795359502608 23.56</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b456453a-4175-4ffb-a209-3b1ee2ffb19e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b456453a-4175-4ffb-a209-3b1ee2ffb19e_0">
											<gml:posList>35.66864426042429 139.73795359502608 23.56 35.668674126535734 139.73798092050123 23.56 35.668674126535734 139.73798092050123 38.363 35.66864426042429 139.73795359502608 23.56</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-848fed00-0df4-4a26-ab8f-8accef88dded">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-848fed00-0df4-4a26-ab8f-8accef88dded_0">
											<gml:posList>35.66866122558541 139.73794387643787 38.363 35.66865760675812 139.73794980141074 23.56 35.66866122558541 139.73794387643787 23.56 35.66866122558541 139.73794387643787 38.363</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d0913fed-4629-4fd7-9896-d334e4949cf8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d0913fed-4629-4fd7-9896-d334e4949cf8_0">
											<gml:posList>35.66866122558541 139.73794387643787 38.363 35.66865760675812 139.73794980141074 38.363 35.66865760675812 139.73794980141074 23.56 35.66866122558541 139.73794387643787 38.363</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f2bb46f7-fb83-4587-ad53-18f5902dd47b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f2bb46f7-fb83-4587-ad53-18f5902dd47b_0">
											<gml:posList>35.66866122558541 139.73794387643787 38.363 35.668654135652496 139.73793738981186 38.363 35.66865760675812 139.73794980141074 38.363 35.66866122558541 139.73794387643787 38.363</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-27839e60-9498-4d3a-a030-148dba30924b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-27839e60-9498-4d3a-a030-148dba30924b_0">
											<gml:posList>35.66867954576511 139.7379720330527 38.363 35.66865676056172 139.73795118317008 38.363 35.668674126535734 139.73798092050123 38.363 35.66867954576511 139.7379720330527 38.363</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c6731e0d-7959-4a25-9b3b-4222caee6058">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c6731e0d-7959-4a25-9b3b-4222caee6058_0">
											<gml:posList>35.66865760675812 139.73794980141074 38.363 35.668654135652496 139.73793738981186 38.363 35.66865676056172 139.73795118317008 38.363 35.66865760675812 139.73794980141074 38.363</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-00a6c7da-64a7-4a9a-a608-a62225769be0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-00a6c7da-64a7-4a9a-a608-a62225769be0_0">
											<gml:posList>35.668674126535734 139.73798092050123 38.363 35.66865676056172 139.73795118317008 38.363 35.66864426042429 139.73795359502608 38.363 35.668674126535734 139.73798092050123 38.363</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4229e011-19c9-4f36-b66f-f889d50426c6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4229e011-19c9-4f36-b66f-f889d50426c6_0">
											<gml:posList>35.66865676056172 139.73795118317008 38.363 35.668654135652496 139.73793738981186 38.363 35.66864426042429 139.73795359502608 38.363 35.66865676056172 139.73795118317008 38.363</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-de83c61c-0bb0-4d1a-bec7-7b8001f27d36">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-de83c61c-0bb0-4d1a-bec7-7b8001f27d36_0">
											<gml:posList>35.66867600436271 139.73801882822394 22.42 35.668651883518244 139.73799593640305 38.393 35.66867600436271 139.73801882822394 38.393 35.66867600436271 139.73801882822394 22.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8b998c34-71c8-4ba7-80b9-44e573c851e5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8b998c34-71c8-4ba7-80b9-44e573c851e5_0">
											<gml:posList>35.66867600436271 139.73801882822394 22.42 35.668651883518244 139.73799593640305 22.42 35.668651883518244 139.73799593640305 38.393 35.66867600436271 139.73801882822394 22.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-041f5e18-95fd-479b-a8e3-ee13391d6e56">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-041f5e18-95fd-479b-a8e3-ee13391d6e56_0">
											<gml:posList>35.66867954576511 139.7379720330527 23.56 35.66865676056172 139.73795118317008 38.363 35.66867954576511 139.7379720330527 38.363 35.66867954576511 139.7379720330527 23.56</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d925be4b-6078-452d-a1b7-eb335bc3dc42">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d925be4b-6078-452d-a1b7-eb335bc3dc42_0">
											<gml:posList>35.66867954576511 139.7379720330527 23.56 35.66865676056172 139.73795118317008 23.56 35.66865676056172 139.73795118317008 38.363 35.66867954576511 139.7379720330527 23.56</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5f2b3dfc-5e27-4db6-b2d5-ad7342df723c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5f2b3dfc-5e27-4db6-b2d5-ad7342df723c_0">
											<gml:posList>35.66867954576511 139.7379720330527 38.363 35.668674126535734 139.73798092050123 23.56 35.66867954576511 139.7379720330527 23.56 35.66867954576511 139.7379720330527 38.363</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-316cd975-3fb9-443c-924b-21e06313ef25">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-316cd975-3fb9-443c-924b-21e06313ef25_0">
											<gml:posList>35.66867954576511 139.7379720330527 38.363 35.668674126535734 139.73798092050123 38.363 35.668674126535734 139.73798092050123 23.56 35.66867954576511 139.7379720330527 38.363</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-01fb84a5-e968-4d68-975f-3a8e00e87a19">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-01fb84a5-e968-4d68-975f-3a8e00e87a19_0">
											<gml:posList>35.668651883518244 139.73799593640305 22.42 35.66862558731321 139.73803751174097 32.141 35.668651883518244 139.73799593640305 38.393 35.668651883518244 139.73799593640305 22.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-08eba6f4-1d01-434d-816d-c72812aae999">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-08eba6f4-1d01-434d-816d-c72812aae999_0">
											<gml:posList>35.66862558731321 139.73803751174097 32.141 35.66862558731321 139.73803751174097 38.393 35.668651883518244 139.73799593640305 38.393 35.66862558731321 139.73803751174097 32.141</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-01aaaee0-23a8-49d3-aa54-8f0495d758b2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-01aaaee0-23a8-49d3-aa54-8f0495d758b2_0">
											<gml:posList>35.668651883518244 139.73799593640305 22.42 35.66862558731321 139.73803751174097 22.42 35.66862558731321 139.73803751174097 32.141 35.668651883518244 139.73799593640305 22.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a2cd6bd0-c3ad-40aa-bfb9-6df331fd7fbf">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a2cd6bd0-c3ad-40aa-bfb9-6df331fd7fbf_0">
											<gml:posList>35.6686497351998 139.73806041458076 22.42 35.66867600436271 139.73801882822394 22.42 35.6686497351998 139.73806041458076 32.141 35.6686497351998 139.73806041458076 22.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c0e6f18a-8381-4472-b885-69567875221f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c0e6f18a-8381-4472-b885-69567875221f_0">
											<gml:posList>35.6686497351998 139.73806041458076 32.141 35.66867600436271 139.73801882822394 38.393 35.6686497351998 139.73806041458076 38.393 35.6686497351998 139.73806041458076 32.141</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7e926895-5a46-4fb0-89d6-43d42f13de12">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7e926895-5a46-4fb0-89d6-43d42f13de12_0">
											<gml:posList>35.6686497351998 139.73806041458076 32.141 35.66867600436271 139.73801882822394 22.42 35.66867600436271 139.73801882822394 38.393 35.6686497351998 139.73806041458076 32.141</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6bf6ecc4-9f93-45b9-8abe-25b3d9dbddf5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66865760675812 139.73794980141074 23.56 35.668654135652496 139.73793738981186 23.56 35.66866122558541 139.73794387643787 23.56 35.66865760675812 139.73794980141074 23.56</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5823afb8-abd7-4b72-8989-7017050fdc55">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668654135652496 139.73793738981186 23.56 35.66865676056172 139.73795118317008 23.56 35.66864426042429 139.73795359502608 23.56 35.668654135652496 139.73793738981186 23.56</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-acab53aa-a292-4e73-b863-f885170cbb3d">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66864426042429 139.73795359502608 23.56 35.66865676056172 139.73795118317008 23.56 35.668674126535734 139.73798092050123 23.56 35.66864426042429 139.73795359502608 23.56</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1e1900f6-ab45-4162-aa8b-a96b5598fe0f">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668674126535734 139.73798092050123 23.56 35.66865676056172 139.73795118317008 23.56 35.66867954576511 139.7379720330527 23.56 35.668674126535734 139.73798092050123 23.56</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-808a8839-717a-4df9-b321-48a7eca9d55f">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668654135652496 139.73793738981186 23.56 35.66865760675812 139.73794980141074 23.56 35.66865676056172 139.73795118317008 23.56 35.668654135652496 139.73793738981186 23.56</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2eb215b2-f317-4902-9843-0bc438574807">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668651883518244 139.73799593640305 22.42 35.6686497351998 139.73806041458076 22.42 35.66862558731321 139.73803751174097 22.42 35.668651883518244 139.73799593640305 22.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b2aa7678-4ffb-48bc-8dac-66e4dcc472e4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668651883518244 139.73799593640305 22.42 35.66867600436271 139.73801882822394 22.42 35.6686497351998 139.73806041458076 22.42 35.668651883518244 139.73799593640305 22.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6ffce1a6-d168-49f5-8b9d-f3f85535fa6f">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66856947761983 139.73801574046507 22.42 35.66862001478444 139.73804632203914 22.42 35.66863641155187 139.7380814951701 22.42 35.66856947761983 139.73801574046507 22.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-269b67da-d850-4ac3-9cbb-bb7c54fa4c8d">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66863641155187 139.7380814951701 22.42 35.66862001478444 139.73804632203914 22.42 35.6686497351998 139.73806041458076 22.42 35.66863641155187 139.7380814951701 22.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-045141f9-f6f6-4eaa-9417-97f3f71e8718">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66856947761983 139.73801574046507 22.42 35.66857597772934 139.73800587969654 22.42 35.66862001478444 139.73804632203914 22.42 35.66856947761983 139.73801574046507 22.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-dea5f8d6-65dd-4d2d-a001-6873ffc235d3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6686497351998 139.73806041458076 22.42 35.66862001478444 139.73804632203914 22.42 35.66862558731321 139.73803751174097 22.42 35.6686497351998 139.73806041458076 22.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-e8359dc5-861f-4bcf-a391-bc638c4217bf">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e8359dc5-861f-4bcf-a391-bc638c4217bf">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e8359dc5-861f-4bcf-a391-bc638c4217bf">
											<gml:posList>35.668633578443526 139.73791856976177 22.42 35.66861518598745 139.7379015918295 22.42 35.66870365014215 139.7377240431442 22.42 35.66865413564375 139.73793737876585 22.42 35.66864426042429 139.73795359502608 22.42 35.66857597773809 139.73800589074256 22.42 35.668633578443526 139.73791856976177 22.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-2c26ee38-a4bc-4b85-b89c-f2ff234803f6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2c26ee38-a4bc-4b85-b89c-f2ff234803f6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2c26ee38-a4bc-4b85-b89c-f2ff234803f6">
											<gml:posList>35.668799395642544 139.7378169587379 22.42 35.66867608554743 139.7380189054496 22.42 35.668651883518244 139.73799593640305 22.42 35.66862001478444 139.73804632203914 22.42 35.66857597773809 139.73800589074256 22.42 35.66864426042429 139.73795359502608 22.42 35.668674126535734 139.73798092050123 22.42 35.66867954576511 139.7379720330527 22.42 35.66865676056172 139.73795118317008 22.42 35.668661225576656 139.73794386539188 22.42 35.66865413564375 139.73793737876585 22.42 35.66870365014215 139.7377240431442 22.42 35.668799395642544 139.7378169587379 22.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-241c3552-2025-485a-80a4-ca6f495feb03">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-241c3552-2025-485a-80a4-ca6f495feb03">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-241c3552-2025-485a-80a4-ca6f495feb03">
											<gml:posList>35.66857597773809 139.73800589074256 38.393 35.66862001478444 139.73804632203914 38.393 35.66861965159564 139.7380429865737 38.393 35.66857877165172 139.73800545662652 38.393 35.66857597773809 139.73800589074256 38.393</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-2ffaa382-9dcc-4d49-a962-2c3cd9b04a73">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2ffaa382-9dcc-4d49-a962-2c3cd9b04a73">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2ffaa382-9dcc-4d49-a962-2c3cd9b04a73">
											<gml:posList>35.668633578443526 139.73791856976177 38.393 35.66857597773809 139.73800589074256 38.393 35.66857877165172 139.73800545662652 38.393 35.66863391456833 139.73792187212135 38.393 35.668633578443526 139.73791856976177 38.393</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-fccdaa7e-ee22-44de-a99a-0cd1c7dce88b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fccdaa7e-ee22-44de-a99a-0cd1c7dce88b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fccdaa7e-ee22-44de-a99a-0cd1c7dce88b">
											<gml:posList>35.66861965159564 139.7380429865737 38.393 35.66862001478444 139.73804632203914 38.393 35.668651883518244 139.73799593640305 38.393 35.668651547342996 139.73799256776636 38.393 35.66861965159564 139.7380429865737 38.393</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-0eeeb0c8-3672-416f-8ae6-9d54239d10d1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0eeeb0c8-3672-416f-8ae6-9d54239d10d1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0eeeb0c8-3672-416f-8ae6-9d54239d10d1">
											<gml:posList>35.66863391456833 139.73792187212135 37.971 35.66857877165172 139.73800545662652 37.971 35.66861965159564 139.7380429865737 37.971 35.668651547342996 139.73799256776636 37.971 35.668675659174376 139.73801545959682 37.971 35.66869783221157 139.73798036210133 37.971 35.66866161581811 139.7379472118724 37.971 35.66865950034902 139.73795069388595 37.971 35.66868228555248 139.7379715437692 37.971 35.66867452578114 139.73798425592577 37.971 35.66864153866442 139.7379540842886 37.971 35.66865139585649 139.73793786805038 37.971 35.66863391456833 139.73792187212135 37.971</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-1660e951-12ed-4d2a-988b-f97e38eafbc2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1660e951-12ed-4d2a-988b-f97e38eafbc2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1660e951-12ed-4d2a-988b-f97e38eafbc2">
											<gml:posList>35.66865413564375 139.73793737876585 38.393 35.668633578443526 139.73791856976177 38.393 35.66863391456833 139.73792187212135 38.393 35.66865139585649 139.73793786805038 38.393 35.66865413564375 139.73793737876585 38.393</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-49a78162-2591-4c9e-ba3b-59cb42450aa5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-49a78162-2591-4c9e-ba3b-59cb42450aa5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-49a78162-2591-4c9e-ba3b-59cb42450aa5">
											<gml:posList>35.66865139585649 139.73793786805038 38.393 35.66864153866442 139.7379540842886 38.393 35.66864426042429 139.73795359502608 38.393 35.66865413564375 139.73793737876585 38.393 35.66865139585649 139.73793786805038 38.393</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c47bde1a-0f7a-41be-bb5c-b923ba1d7df6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c47bde1a-0f7a-41be-bb5c-b923ba1d7df6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c47bde1a-0f7a-41be-bb5c-b923ba1d7df6">
											<gml:posList>35.668617555782895 139.73790056172953 45.109 35.66868454622089 139.73776464902153 45.109 35.6686833099204 139.73776286103893 45.109 35.66861445544679 139.7379010514442 45.109 35.668617555782895 139.73790056172953 45.109</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d07293b1-93ee-4352-9580-ac3d3722a30d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d07293b1-93ee-4352-9580-ac3d3722a30d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d07293b1-93ee-4352-9580-ac3d3722a30d">
											<gml:posList>35.66861445544679 139.7379010514442 45.109 35.668700391593276 139.73797970734208 45.109 35.6687001634948 139.7379762281146 45.109 35.668617555782895 139.73790056172953 45.109 35.66861445544679 139.7379010514442 45.109</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-74fd709c-349c-4dc6-98da-bdea14fbbf0a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-74fd709c-349c-4dc6-98da-bdea14fbbf0a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-74fd709c-349c-4dc6-98da-bdea14fbbf0a">
											<gml:posList>35.668674126535734 139.73798092050123 38.393 35.66864426042429 139.73795359502608 38.393 35.66864153866442 139.7379540842886 38.393 35.66867452578114 139.73798425592577 38.393 35.668674126535734 139.73798092050123 38.393</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c60d941a-87b6-4218-9e41-e6339b0aa06b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c60d941a-87b6-4218-9e41-e6339b0aa06b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c60d941a-87b6-4218-9e41-e6339b0aa06b">
											<gml:posList>35.668661225576656 139.73794386539188 38.393 35.66865676056172 139.73795118317008 38.393 35.66865950034902 139.73795069388595 38.393 35.66866161581811 139.7379472118724 38.393 35.668661225576656 139.73794386539188 38.393</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b0e2a0f8-c00f-43d2-bb33-d2c4f4f557bf">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b0e2a0f8-c00f-43d2-bb33-d2c4f4f557bf">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b0e2a0f8-c00f-43d2-bb33-d2c4f4f557bf">
											<gml:posList>35.668675659174376 139.73801545959682 38.393 35.668651547342996 139.73799256776636 38.393 35.668651883518244 139.73799593640305 38.393 35.66867625693062 139.7380190598902 38.393 35.668675659174376 139.73801545959682 38.393</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-7085efe3-2b42-4deb-807d-123f436cd163">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7085efe3-2b42-4deb-807d-123f436cd163">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7085efe3-2b42-4deb-807d-123f436cd163">
											<gml:posList>35.66865950034902 139.73795069388595 38.393 35.66865676056172 139.73795118317008 38.393 35.66867954576511 139.7379720330527 38.393 35.66868228555248 139.7379715437692 38.393 35.66865950034902 139.73795069388595 38.393</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-7d7361fe-be7d-468c-9575-8e1c1f4aee59">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7d7361fe-be7d-468c-9575-8e1c1f4aee59">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7d7361fe-be7d-468c-9575-8e1c1f4aee59">
											<gml:posList>35.66867954576511 139.7379720330527 38.393 35.668674126535734 139.73798092050123 38.393 35.66867452578114 139.73798425592577 38.393 35.66868228555248 139.7379715437692 38.393 35.66867954576511 139.7379720330527 38.393</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e700876a-acad-481d-a330-bb4ee1ac744c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e700876a-acad-481d-a330-bb4ee1ac744c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e700876a-acad-481d-a330-bb4ee1ac744c">
											<gml:posList>35.66870031943975 139.73797965219774 38.393 35.668661225576656 139.73794386539188 38.393 35.66866161581811 139.7379472118724 38.393 35.66869783221157 139.73798036210133 38.393 35.66870031943975 139.73797965219774 38.393</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-0b48b174-c447-4d7d-8708-663cd79482d3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0b48b174-c447-4d7d-8708-663cd79482d3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0b48b174-c447-4d7d-8708-663cd79482d3">
											<gml:posList>35.66867625693062 139.7380190598902 38.393 35.66870031943975 139.73797965219774 38.393 35.66869783221157 139.73798036210133 38.393 35.668675659174376 139.73801545959682 38.393 35.66867625693062 139.7380190598902 38.393</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c25d9075-b993-4b6c-8d2f-85aa90470842">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c25d9075-b993-4b6c-8d2f-85aa90470842">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c25d9075-b993-4b6c-8d2f-85aa90470842">
											<gml:posList>35.66868454622089 139.73776464902153 45.109 35.66869279882112 139.73775963533524 45.109 35.66869212980655 139.7377571176386 45.109 35.6686833099204 139.73776286103893 45.109 35.66868454622089 139.73776464902153 45.109</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-aa460c8e-51e8-405e-a56a-644eaee070c7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-aa460c8e-51e8-405e-a56a-644eaee070c7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-aa460c8e-51e8-405e-a56a-644eaee070c7">
											<gml:posList>35.668705377439 139.7377538984994 45.109 35.66869212980655 139.7377571176386 45.109 35.66869279882112 139.73775963533524 45.109 35.668705514740324 139.73775653833655 45.109 35.668705377439 139.7377538984994 45.109</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b7e668c2-ca3b-43d3-83d9-20a3a9ef7417">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b7e668c2-ca3b-43d3-83d9-20a3a9ef7417">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b7e668c2-ca3b-43d3-83d9-20a3a9ef7417">
											<gml:posList>35.66879675481407 139.7378172048967 44.555 35.66874473212174 139.7377661679154 44.555 35.668735944158975 139.73777806392064 44.555 35.66872200625178 139.73776333407974 44.555 35.668712789456016 139.73775733602528 44.555 35.668705514740324 139.73775653833655 44.555 35.66869279882112 139.73775963533524 44.555 35.66868454622089 139.73776464902153 44.555 35.668617555782895 139.73790056172953 44.555 35.6687001634948 139.7379762281146 44.555 35.668732102549356 139.7379236220641 44.555 35.668713214138066 139.73790639064143 44.555 35.66877004366132 139.73781284039313 44.555 35.66878894110828 139.7378300828412 44.555 35.66879675481407 139.7378172048967 44.555</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-4ba557eb-f3d1-4399-bc42-86bb29fe3c3e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4ba557eb-f3d1-4399-bc42-86bb29fe3c3e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4ba557eb-f3d1-4399-bc42-86bb29fe3c3e">
											<gml:posList>35.668712789456016 139.73775733602528 45.109 35.66871340035521 139.73775477261827 45.109 35.668705377439 139.7377538984994 45.109 35.668705514740324 139.73775653833655 45.109 35.668712789456016 139.73775733602528 45.109</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-4817b6c0-0e8f-4e87-9794-0472c0311d90">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4817b6c0-0e8f-4e87-9794-0472c0311d90">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4817b6c0-0e8f-4e87-9794-0472c0311d90">
											<gml:posList>35.668723230399976 139.73776116759862 30.778 35.668735769996765 139.7377744078914 30.778 35.668744179829865 139.7377630756842 30.778 35.668703496566785 139.7377236125322 30.777 35.668683769892134 139.7377632029175 30.778 35.66869212980655 139.7377571176386 30.778 35.668705377439 139.7377538984994 30.778 35.66871340035521 139.73775477261827 30.778 35.668723230399976 139.73776116759862 30.778</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-3a7ba300-18db-41ad-b13f-d4f2622be94a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3a7ba300-18db-41ad-b13f-d4f2622be94a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3a7ba300-18db-41ad-b13f-d4f2622be94a">
											<gml:posList>35.668733726201296 139.73792511134647 45.109 35.668732102549356 139.7379236220641 45.109 35.6687001634948 139.7379762281146 45.109 35.668700391593276 139.73797970734208 45.109 35.668733726201296 139.73792511134647 45.109</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-9783bb18-ce44-434f-9943-d77941d9887b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9783bb18-ce44-434f-9943-d77941d9887b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9783bb18-ce44-434f-9943-d77941d9887b">
											<gml:posList>35.668712789456016 139.73775733602528 45.109 35.66872200625178 139.73776333407974 45.109 35.668723230399976 139.73776116759862 45.109 35.66871340035521 139.73775477261827 45.109 35.668712789456016 139.73775733602528 45.109</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-06e54594-ef9d-4283-a968-4ad5e8153cb1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-06e54594-ef9d-4283-a968-4ad5e8153cb1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-06e54594-ef9d-4283-a968-4ad5e8153cb1">
											<gml:posList>35.668713214138066 139.73790639064143 51.318 35.668733789341125 139.7379251665015 51.318 35.66873352593012 139.7379226262275 51.318 35.66871530501577 139.73790600154197 51.318 35.668713214138066 139.73790639064143 51.318</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f6920ea3-3105-413f-8329-0ad4cba7c59a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f6920ea3-3105-413f-8329-0ad4cba7c59a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f6920ea3-3105-413f-8329-0ad4cba7c59a">
											<gml:posList>35.668737879575076 139.73786577816156 51.318 35.668713214138066 139.73790639064143 51.318 35.66871530501577 139.73790600154197 51.318 35.668738179059694 139.73786834048465 51.318 35.668737879575076 139.73786577816156 51.318</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-8d520ee0-6a6b-4e32-89ee-6e6fd9486ce1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8d520ee0-6a6b-4e32-89ee-6e6fd9486ce1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8d520ee0-6a6b-4e32-89ee-6e6fd9486ce1">
											<gml:posList>35.66872200625178 139.73776333407974 45.109 35.668735944158975 139.73777806392064 45.109 35.668735769996765 139.7377744078914 45.109 35.668723230399976 139.73776116759862 45.109 35.66872200625178 139.73776333407974 45.109</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-3609fd27-52f8-4fbc-8cbb-1ddb65161eae">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3609fd27-52f8-4fbc-8cbb-1ddb65161eae">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3609fd27-52f8-4fbc-8cbb-1ddb65161eae">
											<gml:posList>35.66873352593012 139.7379226262275 50.632 35.66875640898414 139.73788495410955 50.632 35.668738179059694 139.73786834048465 50.632 35.66871530501577 139.73790600154197 50.632 35.66873352593012 139.7379226262275 50.632</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-baf37167-e337-4844-9a74-ffeaa24e8a13">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-baf37167-e337-4844-9a74-ffeaa24e8a13">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-baf37167-e337-4844-9a74-ffeaa24e8a13">
											<gml:posList>35.66874473212174 139.7377661679154 45.109 35.668744377895095 139.7377627772052 45.109 35.668735769996765 139.7377744078914 45.109 35.668735944158975 139.73777806392064 45.109 35.66874473212174 139.7377661679154 45.109</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c3ea61e2-3f63-406d-9eb7-d99bd32703a5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c3ea61e2-3f63-406d-9eb7-d99bd32703a5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c3ea61e2-3f63-406d-9eb7-d99bd32703a5">
											<gml:posList>35.668733789341125 139.7379251665015 51.318 35.668758553987885 139.73788462017507 51.318 35.66875640898414 139.73788495410955 51.318 35.66873352593012 139.7379226262275 51.318 35.668733789341125 139.7379251665015 51.318</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c9a06ce1-32b0-4b37-abfd-c64ea38a02ca">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c9a06ce1-32b0-4b37-abfd-c64ea38a02ca">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c9a06ce1-32b0-4b37-abfd-c64ea38a02ca">
											<gml:posList>35.668758553987885 139.73788462017507 51.318 35.668737879575076 139.73786577816156 51.318 35.668738179059694 139.73786834048465 51.318 35.66875640898414 139.73788495410955 51.318 35.668758553987885 139.73788462017507 51.318</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-9dd78e57-f66d-47cf-b5e8-42410258b821">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9dd78e57-f66d-47cf-b5e8-42410258b821">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9dd78e57-f66d-47cf-b5e8-42410258b821">
											<gml:posList>35.668737879575076 139.73786577816156 49.776 35.668738943965224 139.73786674894518 49.776 35.66877031588684 139.7378151265986 49.776 35.66877004366132 139.73781284039313 49.776 35.668737879575076 139.73786577816156 49.776</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a42e722c-ddd5-4ac2-b582-8b7622d2b521">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a42e722c-ddd5-4ac2-b582-8b7622d2b521">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a42e722c-ddd5-4ac2-b582-8b7622d2b521">
											<gml:posList>35.66875744449425 139.73788360526052 48.952 35.66878880741801 139.73783199396536 48.952 35.66877031588684 139.7378151265986 48.952 35.668738943965224 139.73786674894518 48.952 35.66875744449425 139.73788360526052 48.952</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-448accc8-8142-4b57-b713-bd3669e0cfb8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-448accc8-8142-4b57-b713-bd3669e0cfb8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-448accc8-8142-4b57-b713-bd3669e0cfb8">
											<gml:posList>35.66879993624696 139.7378166819429 45.109 35.668744377895095 139.7377627772052 45.109 35.66874473212174 139.7377661679154 45.109 35.66879675481407 139.7378172048967 45.109 35.66879993624696 139.7378166819429 45.109</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-36c13d48-5379-4c75-8193-2f3005f11f61">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-36c13d48-5379-4c75-8193-2f3005f11f61">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-36c13d48-5379-4c75-8193-2f3005f11f61">
											<gml:posList>35.66875853594292 139.7378845981045 49.776 35.66879079927589 139.73783177067216 49.776 35.66878880741801 139.73783199396536 49.776 35.66875744449425 139.73788360526052 49.776 35.66875853594292 139.7378845981045 49.776</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-5bfaee4b-5968-443c-93ed-643d511e42b1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5bfaee4b-5968-443c-93ed-643d511e42b1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5bfaee4b-5968-443c-93ed-643d511e42b1">
											<gml:posList>35.66879079927589 139.73783177067216 49.776 35.66877004366132 139.73781284039313 49.776 35.66877031588684 139.7378151265986 49.776 35.66878880741801 139.73783199396536 49.776 35.66879079927589 139.73783177067216 49.776</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a7810d56-3181-487b-8af2-16510d1acd05">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a7810d56-3181-487b-8af2-16510d1acd05">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a7810d56-3181-487b-8af2-16510d1acd05">
											<gml:posList>35.6687907451585 139.73783172655243 45.109 35.66879993624696 139.7378166819429 45.109 35.66879675481407 139.7378172048967 45.109 35.66878894110828 139.7378300828412 45.109 35.6687907451585 139.73783172655243 45.109</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1b2a1b1c-2209-4529-a8ee-e1e56824961f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1b2a1b1c-2209-4529-a8ee-e1e56824961f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1b2a1b1c-2209-4529-a8ee-e1e56824961f">
											<gml:posList>35.66868454622089 139.73776464902153 45.109 35.668617555782895 139.73790056172953 45.109 35.668617555782895 139.73790056172953 44.555 35.66868454622089 139.73776464902153 44.555 35.66868454622089 139.73776464902153 45.109</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-61f17b7b-a548-4c65-8363-3291f7539d42">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-61f17b7b-a548-4c65-8363-3291f7539d42">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-61f17b7b-a548-4c65-8363-3291f7539d42">
											<gml:posList>35.66877031588684 139.7378151265986 49.776 35.668738943965224 139.73786674894518 49.776 35.668738943965224 139.73786674894518 48.952 35.66877031588684 139.7378151265986 48.952 35.66877031588684 139.7378151265986 49.776</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d655ab85-8404-491d-a4aa-afa5ed10bd32">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d655ab85-8404-491d-a4aa-afa5ed10bd32">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d655ab85-8404-491d-a4aa-afa5ed10bd32">
											<gml:posList>35.66875744449425 139.73788360526052 49.776 35.66878880741801 139.73783199396536 49.776 35.66878880741801 139.73783199396536 48.952 35.66875744449425 139.73788360526052 48.952 35.66875744449425 139.73788360526052 49.776</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3b1eaf6f-e63e-445d-8c1c-4d7040ff2729">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3b1eaf6f-e63e-445d-8c1c-4d7040ff2729">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3b1eaf6f-e63e-445d-8c1c-4d7040ff2729">
											<gml:posList>35.668738179059694 139.73786834048465 51.318 35.66871530501577 139.73790600154197 51.318 35.66871530501577 139.73790600154197 50.632 35.668738179059694 139.73786834048465 50.632 35.668738179059694 139.73786834048465 51.318</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1eb1bd82-fc3a-4f3d-8288-7cabc6218def">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1eb1bd82-fc3a-4f3d-8288-7cabc6218def">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1eb1bd82-fc3a-4f3d-8288-7cabc6218def">
											<gml:posList>35.66873352593012 139.7379226262275 51.318 35.66875640898414 139.73788495410955 51.318 35.66875640898414 139.73788495410955 50.632 35.66873352593012 139.7379226262275 50.632 35.66873352593012 139.7379226262275 51.318</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-365af4c0-be5b-4872-86d1-8ea49121ce9a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-365af4c0-be5b-4872-86d1-8ea49121ce9a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-365af4c0-be5b-4872-86d1-8ea49121ce9a">
											<gml:posList>35.66865950034902 139.73795069388595 38.393 35.66868228555248 139.7379715437692 38.393 35.66868228555248 139.7379715437692 37.971 35.66865950034902 139.73795069388595 37.971 35.66865950034902 139.73795069388595 38.393</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-37823a8e-9b5a-4bdc-a571-88807c0b3f8c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-37823a8e-9b5a-4bdc-a571-88807c0b3f8c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-37823a8e-9b5a-4bdc-a571-88807c0b3f8c">
											<gml:posList>35.66865676056172 139.73795118317008 38.393 35.66865676056172 139.73795118317008 22.42 35.66867954576511 139.7379720330527 22.42 35.66867954576511 139.7379720330527 38.393 35.66865676056172 139.73795118317008 38.393</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6546766e-926e-4e53-874f-b86e0b33cde9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6546766e-926e-4e53-874f-b86e0b33cde9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6546766e-926e-4e53-874f-b86e0b33cde9">
											<gml:posList>35.66868228555248 139.7379715437692 38.393 35.66867452578114 139.73798425592577 38.393 35.66867452578114 139.73798425592577 37.971 35.66868228555248 139.7379715437692 37.971 35.66868228555248 139.7379715437692 38.393</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-25b388c9-f045-410d-a395-ffd57fe24283">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-25b388c9-f045-410d-a395-ffd57fe24283">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-25b388c9-f045-410d-a395-ffd57fe24283">
											<gml:posList>35.66861965159564 139.7380429865737 38.393 35.668651547342996 139.73799256776636 38.393 35.668651547342996 139.73799256776636 37.971 35.66861965159564 139.7380429865737 37.971 35.66861965159564 139.7380429865737 38.393</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6473e315-e419-442d-a2f8-ee6b41a86e18">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6473e315-e419-442d-a2f8-ee6b41a86e18">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6473e315-e419-442d-a2f8-ee6b41a86e18">
											<gml:posList>35.66871340035521 139.73775477261827 45.109 35.66871340035521 139.73775477261827 30.778 35.668705377439 139.7377538984994 30.778 35.668705377439 139.7377538984994 45.109 35.66871340035521 139.73775477261827 45.109</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a32a2de2-937e-4262-b6c9-838229ee21b2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a32a2de2-937e-4262-b6c9-838229ee21b2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a32a2de2-937e-4262-b6c9-838229ee21b2">
											<gml:posList>35.668705377439 139.7377538984994 45.109 35.668705377439 139.7377538984994 30.778 35.66869212980655 139.7377571176386 30.778 35.66869212980655 139.7377571176386 45.109 35.668705377439 139.7377538984994 45.109</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-57b07bde-328d-402e-8cd6-324e24a34764">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-57b07bde-328d-402e-8cd6-324e24a34764">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-57b07bde-328d-402e-8cd6-324e24a34764">
											<gml:posList>35.668712789456016 139.73775733602528 45.109 35.668705514740324 139.73775653833655 45.109 35.668705514740324 139.73775653833655 44.555 35.668712789456016 139.73775733602528 44.555 35.668712789456016 139.73775733602528 45.109</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-14401a7d-d60a-4f76-8925-4cb6a172ef84">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-14401a7d-d60a-4f76-8925-4cb6a172ef84">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-14401a7d-d60a-4f76-8925-4cb6a172ef84">
											<gml:posList>35.668723230399976 139.73776116759862 45.109 35.668723230399976 139.73776116759862 30.778 35.66871340035521 139.73775477261827 30.778 35.66871340035521 139.73775477261827 45.109 35.668723230399976 139.73776116759862 45.109</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b6702d89-e3c8-4d1b-b914-f182fc6bf25d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b6702d89-e3c8-4d1b-b914-f182fc6bf25d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b6702d89-e3c8-4d1b-b914-f182fc6bf25d">
											<gml:posList>35.668705514740324 139.73775653833655 45.109 35.66869279882112 139.73775963533524 45.109 35.66869279882112 139.73775963533524 44.555 35.668705514740324 139.73775653833655 44.555 35.668705514740324 139.73775653833655 45.109</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a18a7c5f-ce58-40d4-bd0e-141d7ce10c39">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a18a7c5f-ce58-40d4-bd0e-141d7ce10c39">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a18a7c5f-ce58-40d4-bd0e-141d7ce10c39">
											<gml:posList>35.66869212980655 139.7377571176386 45.109 35.66869212980655 139.7377571176386 30.778 35.668683769892134 139.7377632029175 30.778 35.6686833099204 139.73776286103893 45.109 35.66869212980655 139.7377571176386 45.109</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d918f4b6-e06f-4d7e-b7aa-88b0a0a4d08f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d918f4b6-e06f-4d7e-b7aa-88b0a0a4d08f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d918f4b6-e06f-4d7e-b7aa-88b0a0a4d08f">
											<gml:posList>35.66872200625178 139.73776333407974 45.109 35.668712789456016 139.73775733602528 45.109 35.668712789456016 139.73775733602528 44.555 35.66872200625178 139.73776333407974 44.555 35.66872200625178 139.73776333407974 45.109</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-082bacb2-1fc1-4faf-af16-9f17c5b64bbf">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-082bacb2-1fc1-4faf-af16-9f17c5b64bbf">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-082bacb2-1fc1-4faf-af16-9f17c5b64bbf">
											<gml:posList>35.66869279882112 139.73775963533524 45.109 35.66868454622089 139.73776464902153 45.109 35.66868454622089 139.73776464902153 44.555 35.66869279882112 139.73775963533524 44.555 35.66869279882112 139.73775963533524 45.109</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c84aaef8-73da-4973-982d-d44cba1608b8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c84aaef8-73da-4973-982d-d44cba1608b8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c84aaef8-73da-4973-982d-d44cba1608b8">
											<gml:posList>35.668735769996765 139.7377744078914 45.109 35.668735769996765 139.7377744078914 30.778 35.668723230399976 139.73776116759862 30.778 35.668723230399976 139.73776116759862 45.109 35.668735769996765 139.7377744078914 45.109</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c54a2f9f-db18-4298-8343-a3a7a63d6ba4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c54a2f9f-db18-4298-8343-a3a7a63d6ba4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c54a2f9f-db18-4298-8343-a3a7a63d6ba4">
											<gml:posList>35.668744377895095 139.7377627772052 45.109 35.668744179829865 139.7377630756842 30.778 35.668735769996765 139.7377744078914 30.778 35.668735769996765 139.7377744078914 45.109 35.668744377895095 139.7377627772052 45.109</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-22883392-8d25-4c0b-a937-c89a7233f4bf">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-22883392-8d25-4c0b-a937-c89a7233f4bf">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-22883392-8d25-4c0b-a937-c89a7233f4bf">
											<gml:posList>35.668799395642544 139.7378169587379 22.42 35.66870365014215 139.7377240431442 22.42 35.668703496566785 139.7377236125322 30.777 35.668744179829865 139.7377630756842 30.778 35.668744377895095 139.7377627772052 45.109 35.66879993624696 139.7378166819429 45.109 35.668799395642544 139.7378169587379 22.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2d141fa7-52ca-4502-9bdf-2cf9b99d466d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2d141fa7-52ca-4502-9bdf-2cf9b99d466d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2d141fa7-52ca-4502-9bdf-2cf9b99d466d">
											<gml:posList>35.668735944158975 139.73777806392064 45.109 35.66872200625178 139.73776333407974 45.109 35.66872200625178 139.73776333407974 44.555 35.668735944158975 139.73777806392064 44.555 35.668735944158975 139.73777806392064 45.109</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-bc118799-2b32-4fd9-a175-e98cbe7d183f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bc118799-2b32-4fd9-a175-e98cbe7d183f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bc118799-2b32-4fd9-a175-e98cbe7d183f">
											<gml:posList>35.66874473212174 139.7377661679154 45.109 35.668735944158975 139.73777806392064 45.109 35.668735944158975 139.73777806392064 44.555 35.66874473212174 139.7377661679154 44.555 35.66874473212174 139.7377661679154 45.109</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-34851473-a014-4129-991f-6259f8ca13e9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-34851473-a014-4129-991f-6259f8ca13e9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-34851473-a014-4129-991f-6259f8ca13e9">
											<gml:posList>35.66879675481407 139.7378172048967 45.109 35.66874473212174 139.7377661679154 45.109 35.66874473212174 139.7377661679154 44.555 35.66879675481407 139.7378172048967 44.555 35.66879675481407 139.7378172048967 45.109</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4bfb65fb-81a4-49c1-a63f-30ec1ae56f29">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4bfb65fb-81a4-49c1-a63f-30ec1ae56f29">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4bfb65fb-81a4-49c1-a63f-30ec1ae56f29">
											<gml:posList>35.66861445544679 139.7379010514442 45.109 35.6686833099204 139.73776286103893 45.109 35.668683769892134 139.7377632029175 30.778 35.668703496566785 139.7377236125322 30.777 35.66870365014215 139.7377240431442 22.42 35.66861518598745 139.7379015918295 22.42 35.66861445544679 139.7379010514442 45.109</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-edf085c6-c753-4376-a287-9840e71675b5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-edf085c6-c753-4376-a287-9840e71675b5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-edf085c6-c753-4376-a287-9840e71675b5">
											<gml:posList>35.66878894110828 139.7378300828412 45.109 35.66878894110828 139.7378300828412 44.555 35.66877004366132 139.73781284039313 44.555 35.66877004366132 139.73781284039313 49.776 35.66879079927589 139.73783177067216 49.776 35.6687907451585 139.73783172655243 45.109 35.66878894110828 139.7378300828412 45.109</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9640cc84-9134-404b-895a-2b51025d16c5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9640cc84-9134-404b-895a-2b51025d16c5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9640cc84-9134-404b-895a-2b51025d16c5">
											<gml:posList>35.66878880741801 139.73783199396536 49.776 35.66877031588684 139.7378151265986 49.776 35.66877031588684 139.7378151265986 48.952 35.66878880741801 139.73783199396536 48.952 35.66878880741801 139.73783199396536 49.776</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-53893819-d609-4c06-925a-316072c1a8ee">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-53893819-d609-4c06-925a-316072c1a8ee">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-53893819-d609-4c06-925a-316072c1a8ee">
											<gml:posList>35.66878894110828 139.7378300828412 45.109 35.66879675481407 139.7378172048967 45.109 35.66879675481407 139.7378172048967 44.555 35.66878894110828 139.7378300828412 44.555 35.66878894110828 139.7378300828412 45.109</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ff93fc34-6fcd-41d2-83c6-a96229735d24">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ff93fc34-6fcd-41d2-83c6-a96229735d24">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ff93fc34-6fcd-41d2-83c6-a96229735d24">
											<gml:posList>35.668713214138066 139.73790639064143 44.555 35.668713214138066 139.73790639064143 51.318 35.668737879575076 139.73786577816156 51.318 35.668737879575076 139.73786577816156 49.776 35.66877004366132 139.73781284039313 49.776 35.66877004366132 139.73781284039313 44.555 35.668713214138066 139.73790639064143 44.555</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-099166ff-22d3-4ba7-b2d5-a7515c31deae">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-099166ff-22d3-4ba7-b2d5-a7515c31deae">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-099166ff-22d3-4ba7-b2d5-a7515c31deae">
											<gml:posList>35.668738943965224 139.73786674894518 49.776 35.668737879575076 139.73786577816156 49.776 35.668737879575076 139.73786577816156 51.318 35.668758553987885 139.73788462017507 51.318 35.66875853594292 139.7378845981045 49.776 35.66875744449425 139.73788360526052 49.776 35.66875744449425 139.73788360526052 48.952 35.668738943965224 139.73786674894518 48.952 35.668738943965224 139.73786674894518 49.776</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e7307078-8138-455f-8654-7654096694ec">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e7307078-8138-455f-8654-7654096694ec">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e7307078-8138-455f-8654-7654096694ec">
											<gml:posList>35.66875640898414 139.73788495410955 51.318 35.668738179059694 139.73786834048465 51.318 35.668738179059694 139.73786834048465 50.632 35.66875640898414 139.73788495410955 50.632 35.66875640898414 139.73788495410955 51.318</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-eec888f7-aa4d-4db4-8681-f806ed2cb3ed">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-eec888f7-aa4d-4db4-8681-f806ed2cb3ed">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-eec888f7-aa4d-4db4-8681-f806ed2cb3ed">
											<gml:posList>35.66871530501577 139.73790600154197 51.318 35.66873352593012 139.7379226262275 51.318 35.66873352593012 139.7379226262275 50.632 35.66871530501577 139.73790600154197 50.632 35.66871530501577 139.73790600154197 51.318</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d6aa70f5-770c-4886-ab45-0eeeb590eaa4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d6aa70f5-770c-4886-ab45-0eeeb590eaa4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d6aa70f5-770c-4886-ab45-0eeeb590eaa4">
											<gml:posList>35.668732102549356 139.7379236220641 45.109 35.668733726201296 139.73792511134647 45.109 35.668733789341125 139.7379251665015 51.318 35.668713214138066 139.73790639064143 51.318 35.668713214138066 139.73790639064143 44.555 35.668732102549356 139.7379236220641 44.555 35.668732102549356 139.7379236220641 45.109</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b695ead2-5395-4297-a045-be6676523185">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b695ead2-5395-4297-a045-be6676523185">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b695ead2-5395-4297-a045-be6676523185">
											<gml:posList>35.668733726201296 139.73792511134647 45.109 35.668700391593276 139.73797970734208 45.109 35.66870031943975 139.73797965219774 38.393 35.66867625693062 139.7380190598902 38.393 35.66867608554743 139.7380189054496 22.42 35.668799395642544 139.7378169587379 22.42 35.66879993624696 139.7378166819429 45.109 35.6687907451585 139.73783172655243 45.109 35.66879079927589 139.73783177067216 49.776 35.66875853594292 139.7378845981045 49.776 35.668758553987885 139.73788462017507 51.318 35.668733789341125 139.7379251665015 51.318 35.668733726201296 139.73792511134647 45.109</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-294b31d9-75ed-4410-bb0f-78ef94921550">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-294b31d9-75ed-4410-bb0f-78ef94921550">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-294b31d9-75ed-4410-bb0f-78ef94921550">
											<gml:posList>35.66865139585649 139.73793786805038 38.393 35.66863391456833 139.73792187212135 38.393 35.66863391456833 139.73792187212135 37.971 35.66865139585649 139.73793786805038 37.971 35.66865139585649 139.73793786805038 38.393</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e296f40c-acd3-4ab5-8a03-ea16c46a07f1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e296f40c-acd3-4ab5-8a03-ea16c46a07f1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e296f40c-acd3-4ab5-8a03-ea16c46a07f1">
											<gml:posList>35.668617555782895 139.73790056172953 45.109 35.6687001634948 139.7379762281146 45.109 35.6687001634948 139.7379762281146 44.555 35.668617555782895 139.73790056172953 44.555 35.668617555782895 139.73790056172953 45.109</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-057ded90-bf8d-438c-b744-75ac0ddad524">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-057ded90-bf8d-438c-b744-75ac0ddad524">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-057ded90-bf8d-438c-b744-75ac0ddad524">
											<gml:posList>35.66865413564375 139.73793737876585 38.393 35.66865413564375 139.73793737876585 22.42 35.668661225576656 139.73794386539188 22.42 35.668661225576656 139.73794386539188 38.393 35.66870031943975 139.73797965219774 38.393 35.668700391593276 139.73797970734208 45.109 35.66861445544679 139.7379010514442 45.109 35.66861518598745 139.7379015918295 22.42 35.668633578443526 139.73791856976177 22.42 35.668633578443526 139.73791856976177 38.393 35.66865413564375 139.73793737876585 38.393</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-503b20df-ff8c-48c2-94fa-dc891ee68a7a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-503b20df-ff8c-48c2-94fa-dc891ee68a7a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-503b20df-ff8c-48c2-94fa-dc891ee68a7a">
											<gml:posList>35.66864426042429 139.73795359502608 38.393 35.66864426042429 139.73795359502608 22.42 35.66865413564375 139.73793737876585 22.42 35.66865413564375 139.73793737876585 38.393 35.66864426042429 139.73795359502608 38.393</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a513d574-4aed-4ebb-983f-96f7ee9786e7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a513d574-4aed-4ebb-983f-96f7ee9786e7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a513d574-4aed-4ebb-983f-96f7ee9786e7">
											<gml:posList>35.66864153866442 139.7379540842886 38.393 35.66865139585649 139.73793786805038 38.393 35.66865139585649 139.73793786805038 37.971 35.66864153866442 139.7379540842886 37.971 35.66864153866442 139.7379540842886 38.393</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-58be4628-ab96-4c53-986d-891e1b5342ae">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-58be4628-ab96-4c53-986d-891e1b5342ae">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-58be4628-ab96-4c53-986d-891e1b5342ae">
											<gml:posList>35.668661225576656 139.73794386539188 38.393 35.668661225576656 139.73794386539188 22.42 35.66865676056172 139.73795118317008 22.42 35.66865676056172 139.73795118317008 38.393 35.668661225576656 139.73794386539188 38.393</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d39bbab9-5f2c-4daa-bfc8-308376bb3842">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d39bbab9-5f2c-4daa-bfc8-308376bb3842">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d39bbab9-5f2c-4daa-bfc8-308376bb3842">
											<gml:posList>35.66866161581811 139.7379472118724 38.393 35.66865950034902 139.73795069388595 38.393 35.66865950034902 139.73795069388595 37.971 35.66866161581811 139.7379472118724 37.971 35.66866161581811 139.7379472118724 38.393</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8c78d522-8c3c-4e88-a703-24da2b06c68d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8c78d522-8c3c-4e88-a703-24da2b06c68d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8c78d522-8c3c-4e88-a703-24da2b06c68d">
											<gml:posList>35.6687001634948 139.7379762281146 45.109 35.668732102549356 139.7379236220641 45.109 35.668732102549356 139.7379236220641 44.555 35.6687001634948 139.7379762281146 44.555 35.6687001634948 139.7379762281146 45.109</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-63b43a71-f576-4c8f-842e-5d1ac30a890e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-63b43a71-f576-4c8f-842e-5d1ac30a890e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-63b43a71-f576-4c8f-842e-5d1ac30a890e">
											<gml:posList>35.668633578443526 139.73791856976177 38.393 35.668633578443526 139.73791856976177 22.42 35.66857597773809 139.73800589074256 22.42 35.66857597773809 139.73800589074256 38.393 35.668633578443526 139.73791856976177 38.393</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f20b1c66-3fc2-45a8-9d9f-808c125a4824">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f20b1c66-3fc2-45a8-9d9f-808c125a4824">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f20b1c66-3fc2-45a8-9d9f-808c125a4824">
											<gml:posList>35.66863391456833 139.73792187212135 38.393 35.66857877165172 139.73800545662652 38.393 35.66857877165172 139.73800545662652 37.971 35.66863391456833 139.73792187212135 37.971 35.66863391456833 139.73792187212135 38.393</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5b9272d3-3fcf-4188-aca0-a385b9f2e7e0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5b9272d3-3fcf-4188-aca0-a385b9f2e7e0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5b9272d3-3fcf-4188-aca0-a385b9f2e7e0">
											<gml:posList>35.66869783221157 139.73798036210133 38.393 35.66866161581811 139.7379472118724 38.393 35.66866161581811 139.7379472118724 37.971 35.66869783221157 139.73798036210133 37.971 35.66869783221157 139.73798036210133 38.393</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-57642add-358a-4653-8657-240c22522f2f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-57642add-358a-4653-8657-240c22522f2f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-57642add-358a-4653-8657-240c22522f2f">
											<gml:posList>35.668674126535734 139.73798092050123 38.393 35.668674126535734 139.73798092050123 22.42 35.66864426042429 139.73795359502608 22.42 35.66864426042429 139.73795359502608 38.393 35.668674126535734 139.73798092050123 38.393</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f487fefd-a0a3-49c6-9751-c2b2a6f623ad">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f487fefd-a0a3-49c6-9751-c2b2a6f623ad">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f487fefd-a0a3-49c6-9751-c2b2a6f623ad">
											<gml:posList>35.66867452578114 139.73798425592577 38.393 35.66864153866442 139.7379540842886 38.393 35.66864153866442 139.7379540842886 37.971 35.66867452578114 139.73798425592577 37.971 35.66867452578114 139.73798425592577 38.393</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f4e24c13-e31f-4ece-b3cf-436b70f4bd7f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f4e24c13-e31f-4ece-b3cf-436b70f4bd7f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f4e24c13-e31f-4ece-b3cf-436b70f4bd7f">
											<gml:posList>35.66867954576511 139.7379720330527 38.393 35.66867954576511 139.7379720330527 22.42 35.668674126535734 139.73798092050123 22.42 35.668674126535734 139.73798092050123 38.393 35.66867954576511 139.7379720330527 38.393</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-fb11aa10-f591-4529-a530-50f80685c11f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fb11aa10-f591-4529-a530-50f80685c11f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fb11aa10-f591-4529-a530-50f80685c11f">
											<gml:posList>35.668675659174376 139.73801545959682 38.393 35.66869783221157 139.73798036210133 38.393 35.66869783221157 139.73798036210133 37.971 35.668675659174376 139.73801545959682 37.971 35.668675659174376 139.73801545959682 38.393</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-18eff981-c2d5-4313-84e3-73c992b6eb1e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-18eff981-c2d5-4313-84e3-73c992b6eb1e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-18eff981-c2d5-4313-84e3-73c992b6eb1e">
											<gml:posList>35.668651547342996 139.73799256776636 38.393 35.668675659174376 139.73801545959682 38.393 35.668675659174376 139.73801545959682 37.971 35.668651547342996 139.73799256776636 37.971 35.668651547342996 139.73799256776636 38.393</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b5599cc2-548b-49c5-bd1c-46acbd35eae4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b5599cc2-548b-49c5-bd1c-46acbd35eae4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b5599cc2-548b-49c5-bd1c-46acbd35eae4">
											<gml:posList>35.668651883518244 139.73799593640305 38.393 35.668651883518244 139.73799593640305 22.42 35.66867608554743 139.7380189054496 22.42 35.66867625693062 139.7380190598902 38.393 35.668651883518244 139.73799593640305 38.393</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b8d93144-356c-4ce6-8c69-0f66228fbb2c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b8d93144-356c-4ce6-8c69-0f66228fbb2c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b8d93144-356c-4ce6-8c69-0f66228fbb2c">
											<gml:posList>35.668651883518244 139.73799593640305 22.42 35.668651883518244 139.73799593640305 38.393 35.66862001478444 139.73804632203914 38.393 35.66862001478444 139.73804632203914 22.42 35.668651883518244 139.73799593640305 22.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6e94458d-06c1-4ef6-9c50-794d6aa70ae2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6e94458d-06c1-4ef6-9c50-794d6aa70ae2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6e94458d-06c1-4ef6-9c50-794d6aa70ae2">
											<gml:posList>35.66857877165172 139.73800545662652 38.393 35.66861965159564 139.7380429865737 38.393 35.66861965159564 139.7380429865737 37.971 35.66857877165172 139.73800545662652 37.971 35.66857877165172 139.73800545662652 38.393</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ddaca70d-17da-4cbf-9887-e531276f08b0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ddaca70d-17da-4cbf-9887-e531276f08b0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ddaca70d-17da-4cbf-9887-e531276f08b0">
											<gml:posList>35.66857597773809 139.73800589074256 38.393 35.66857597773809 139.73800589074256 22.42 35.66862001478444 139.73804632203914 22.42 35.66862001478444 139.73804632203914 38.393 35.66857597773809 139.73800589074256 38.393</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-8359</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">227.00561</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1242</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>4</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>