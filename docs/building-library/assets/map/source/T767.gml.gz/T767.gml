<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_daad4556-43c4-4366-a05b-bcb8eb49e333">
			<core:creationDate>2024-03-15</core:creationDate>
			<bldg:measuredHeight uom="m">7.9</bldg:measuredHeight>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.67180405195127 139.7389387699849 0 35.67180500420231 139.7389461810355 0 35.67179853332106 139.73894742585648 0 35.67180037432734 139.73896173989473 0 35.67180688125498 139.73896048398595 0 35.671807806264425 139.73896764100058 0 35.67183148174047 139.73896306199282 0 35.671827763472436 139.73893417987992 0 35.67180405195127 139.7389387699849 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67180405195127 139.7389387699849 11.702 35.671827763472436 139.73893417987992 11.702 35.67183148174047 139.73896306199282 11.702 35.671807806264425 139.73896764100058 11.702 35.67180688125498 139.73896048398595 11.702 35.67180037432734 139.73896173989473 11.702 35.67179853332106 139.73894742585648 11.702 35.67180500420231 139.7389461810355 11.702 35.67180405195127 139.7389387699849 11.702</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67180405195127 139.7389387699849 11.702 35.67180500420231 139.7389461810355 11.702 35.67180500420231 139.7389461810355 19.65 35.67180405195127 139.7389387699849 19.65 35.67180405195127 139.7389387699849 11.702</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67180500420231 139.7389461810355 11.702 35.67179853332106 139.73894742585648 11.702 35.67179853332106 139.73894742585648 19.65 35.67180500420231 139.7389461810355 19.65 35.67180500420231 139.7389461810355 11.702</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67179853332106 139.73894742585648 11.702 35.67180037432734 139.73896173989473 11.702 35.67180037432734 139.73896173989473 19.65 35.67179853332106 139.73894742585648 19.65 35.67179853332106 139.73894742585648 11.702</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67180037432734 139.73896173989473 11.702 35.67180688125498 139.73896048398595 11.702 35.67180688125498 139.73896048398595 19.65 35.67180037432734 139.73896173989473 19.65 35.67180037432734 139.73896173989473 11.702</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67180688125498 139.73896048398595 11.702 35.671807806264425 139.73896764100058 11.702 35.671807806264425 139.73896764100058 19.65 35.67180688125498 139.73896048398595 19.65 35.67180688125498 139.73896048398595 11.702</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671807806264425 139.73896764100058 11.702 35.67183148174047 139.73896306199282 11.702 35.67183148174047 139.73896306199282 19.65 35.671807806264425 139.73896764100058 19.65 35.671807806264425 139.73896764100058 11.702</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67183148174047 139.73896306199282 11.702 35.671827763472436 139.73893417987992 11.702 35.671827763472436 139.73893417987992 19.65 35.67183148174047 139.73896306199282 19.65 35.67183148174047 139.73896306199282 11.702</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671827763472436 139.73893417987992 11.702 35.67180405195127 139.7389387699849 11.702 35.67180405195127 139.7389387699849 19.65 35.671827763472436 139.73893417987992 19.65 35.671827763472436 139.73893417987992 11.702</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67180405195127 139.7389387699849 19.65 35.67180500420231 139.7389461810355 19.65 35.67179853332106 139.73894742585648 19.65 35.67180037432734 139.73896173989473 19.65 35.67180688125498 139.73896048398595 19.65 35.671807806264425 139.73896764100058 19.65 35.67183148174047 139.73896306199282 19.65 35.671827763472436 139.73893417987992 19.65 35.67180405195127 139.7389387699849 19.65</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-108f54e6-72a8-487f-ba76-a06658b4e08c"/>
							<gml:surfaceMember xlink:href="#poly-439c7d29-c022-4b9c-bebf-8abe62de154c"/>
							<gml:surfaceMember xlink:href="#poly-73da7aa4-0255-4656-a44a-f96847283e40"/>
							<gml:surfaceMember xlink:href="#poly-b6bf38bf-b338-48c3-8b9b-cd2662f9846f"/>
							<gml:surfaceMember xlink:href="#poly-46d56739-f278-4f12-8b77-8aa8bb37a1f9"/>
							<gml:surfaceMember xlink:href="#poly-8bcd1d7b-95e2-446d-af44-90928cc1fc9f"/>
							<gml:surfaceMember xlink:href="#poly-db710ce5-bde5-4902-85f3-31ef4de00082"/>
							<gml:surfaceMember xlink:href="#poly-f114f353-e456-4c43-ae0a-4e42e4735ed1"/>
							<gml:surfaceMember xlink:href="#poly-ef561683-79e4-4a64-80e9-93787239b72c"/>
							<gml:surfaceMember xlink:href="#poly-16382e13-a8ed-4e1d-8d9c-8a1d7145fab9"/>
							<gml:surfaceMember xlink:href="#poly-04ebd001-65f1-4d7e-80df-62427fd6b520"/>
							<gml:surfaceMember xlink:href="#poly-c22717cb-a8d9-4f78-9b48-b6954f0dfb84"/>
							<gml:surfaceMember xlink:href="#poly-f5adffbc-e6b1-4a03-9e4b-1a4780ca7bdb"/>
							<gml:surfaceMember xlink:href="#poly-3091ffbf-1825-4ed4-9f92-ad9f99f88dd6"/>
							<gml:surfaceMember xlink:href="#poly-a1c92367-670e-4d2f-92ae-7c8e34a92fd0"/>
							<gml:surfaceMember xlink:href="#poly-5586d1db-be1c-4db5-83b6-9c429c3903ee"/>
							<gml:surfaceMember xlink:href="#poly-7f19997c-ba33-4e8f-b3b2-400e1ccd6e5c"/>
							<gml:surfaceMember xlink:href="#poly-e030b235-75fb-4f7f-bcb3-955a8da2bb38"/>
							<gml:surfaceMember xlink:href="#poly-d8de52f7-94db-46df-ab3f-ca44c45eff23"/>
							<gml:surfaceMember xlink:href="#poly-4914e6a4-b54b-4697-9ef0-5e5677d516c3"/>
							<gml:surfaceMember xlink:href="#poly-568a9787-b3d1-4e03-bf1f-5361faedfc20"/>
							<gml:surfaceMember xlink:href="#poly-abbf34c8-eecc-4a01-83dc-ea17a7bd4162"/>
							<gml:surfaceMember xlink:href="#poly-ad0a2f1f-e547-467d-a71d-218ea8e46331"/>
							<gml:surfaceMember xlink:href="#poly-aa0c88f8-8378-4f1e-9047-c5e5cdaf1d80"/>
							<gml:surfaceMember xlink:href="#poly-1289b115-b764-4b65-8b5b-5991b32e22b2"/>
							<gml:surfaceMember xlink:href="#poly-0e50bfa7-7b3c-458b-85d3-b7ffde75e393"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-108f54e6-72a8-487f-ba76-a06658b4e08c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-108f54e6-72a8-487f-ba76-a06658b4e08c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-108f54e6-72a8-487f-ba76-a06658b4e08c">
											<gml:posList>35.67180500420231 139.73894618103546 11.702 35.67180405195127 139.7389387699849 11.702 35.671827763472436 139.73893417987992 11.702 35.671831481740455 139.73896306199282 11.702 35.671807806264404 139.73896764100058 11.702 35.671806881254966 139.73896048398595 11.702 35.67180037432732 139.73896173989473 11.702 35.67179853332103 139.73894742585648 11.702 35.67180500420231 139.73894618103546 11.702</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-439c7d29-c022-4b9c-bebf-8abe62de154c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-439c7d29-c022-4b9c-bebf-8abe62de154c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-439c7d29-c022-4b9c-bebf-8abe62de154c">
											<gml:posList>35.67180037432732 139.73896173989473 20.72 35.67180211168967 139.73895882158553 20.72 35.67180091462297 139.73894956606532 20.72 35.67179853332103 139.73894742585648 20.72 35.67180037432732 139.73896173989473 20.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-73da7aa4-0255-4656-a44a-f96847283e40">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-73da7aa4-0255-4656-a44a-f96847283e40">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-73da7aa4-0255-4656-a44a-f96847283e40">
											<gml:posList>35.67180500420231 139.73894618103546 20.72 35.67179853332103 139.73894742585648 20.72 35.67180091462297 139.73894956606532 20.72 35.671807385504266 139.7389483212444 20.72 35.67180500420231 139.73894618103546 20.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b6bf38bf-b338-48c3-8b9b-cd2662f9846f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b6bf38bf-b338-48c3-8b9b-cd2662f9846f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b6bf38bf-b338-48c3-8b9b-cd2662f9846f">
											<gml:posList>35.671806881254966 139.73896048398595 20.72 35.67180860960357 139.7389575656871 20.72 35.67180211168967 139.73895882158553 20.72 35.67180037432732 139.73896173989473 20.72 35.671806881254966 139.73896048398595 20.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-46d56739-f278-4f12-8b77-8aa8bb37a1f9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-46d56739-f278-4f12-8b77-8aa8bb37a1f9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-46d56739-f278-4f12-8b77-8aa8bb37a1f9">
											<gml:posList>35.67180500420231 139.73894618103546 20.72 35.671807385504266 139.7389483212444 20.72 35.67180643324469 139.73894089914717 20.72 35.67180405195127 139.7389387699849 20.72 35.67180500420231 139.73894618103546 20.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-8bcd1d7b-95e2-446d-af44-90928cc1fc9f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8bcd1d7b-95e2-446d-af44-90928cc1fc9f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8bcd1d7b-95e2-446d-af44-90928cc1fc9f">
											<gml:posList>35.671806881254966 139.73896048398595 20.72 35.671807806264404 139.73896764100058 20.72 35.671809543626914 139.73896472269124 20.72 35.67180860960357 139.7389575656871 20.72 35.671806881254966 139.73896048398595 20.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-db710ce5-bde5-4902-85f3-31ef4de00082">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-db710ce5-bde5-4902-85f3-31ef4de00082">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-db710ce5-bde5-4902-85f3-31ef4de00082">
											<gml:posList>35.67182909144237 139.7389609438863 20.018 35.67182603513307 139.73893710922644 20.018 35.67180643324469 139.73894089914717 20.018 35.671807385504266 139.7389483212444 20.018 35.67180091462297 139.73894956606532 20.018 35.67180211168967 139.73895882158553 20.018 35.67180860960357 139.7389575656871 20.018 35.671809543626914 139.73896472269124 20.018 35.67182909144237 139.7389609438863 20.018</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f114f353-e456-4c43-ae0a-4e42e4735ed1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f114f353-e456-4c43-ae0a-4e42e4735ed1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f114f353-e456-4c43-ae0a-4e42e4735ed1">
											<gml:posList>35.67180405195127 139.7389387699849 20.72 35.67180643324469 139.73894089914717 20.72 35.67182603513307 139.73893710922644 20.72 35.671827763472436 139.73893417987992 20.72 35.67180405195127 139.7389387699849 20.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ef561683-79e4-4a64-80e9-93787239b72c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ef561683-79e4-4a64-80e9-93787239b72c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ef561683-79e4-4a64-80e9-93787239b72c">
											<gml:posList>35.671831481740455 139.73896306199282 20.72 35.67182909144237 139.7389609438863 20.72 35.671809543626914 139.73896472269124 20.72 35.671807806264404 139.73896764100058 20.72 35.671831481740455 139.73896306199282 20.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-16382e13-a8ed-4e1d-8d9c-8a1d7145fab9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-16382e13-a8ed-4e1d-8d9c-8a1d7145fab9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-16382e13-a8ed-4e1d-8d9c-8a1d7145fab9">
											<gml:posList>35.671827763472436 139.73893417987992 20.72 35.67182603513307 139.73893710922644 20.72 35.67182909144237 139.7389609438863 20.72 35.671831481740455 139.73896306199282 20.72 35.671827763472436 139.73893417987992 20.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-04ebd001-65f1-4d7e-80df-62427fd6b520">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-04ebd001-65f1-4d7e-80df-62427fd6b520">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-04ebd001-65f1-4d7e-80df-62427fd6b520">
											<gml:posList>35.671827763472436 139.73893417987992 11.702 35.67180405195127 139.7389387699849 11.702 35.67180405195127 139.7389387699849 20.72 35.671827763472436 139.73893417987992 20.72 35.671827763472436 139.73893417987992 11.702</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c22717cb-a8d9-4f78-9b48-b6954f0dfb84">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c22717cb-a8d9-4f78-9b48-b6954f0dfb84">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c22717cb-a8d9-4f78-9b48-b6954f0dfb84">
											<gml:posList>35.67180643324469 139.73894089914717 20.72 35.67180643324469 139.73894089914717 20.018 35.67182603513307 139.73893710922644 20.018 35.67182603513307 139.73893710922644 20.72 35.67180643324469 139.73894089914717 20.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f5adffbc-e6b1-4a03-9e4b-1a4780ca7bdb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f5adffbc-e6b1-4a03-9e4b-1a4780ca7bdb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f5adffbc-e6b1-4a03-9e4b-1a4780ca7bdb">
											<gml:posList>35.67180405195127 139.7389387699849 11.702 35.67180500420231 139.73894618103546 11.702 35.67180500420231 139.73894618103546 20.72 35.67180405195127 139.7389387699849 20.72 35.67180405195127 139.7389387699849 11.702</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3091ffbf-1825-4ed4-9f92-ad9f99f88dd6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3091ffbf-1825-4ed4-9f92-ad9f99f88dd6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3091ffbf-1825-4ed4-9f92-ad9f99f88dd6">
											<gml:posList>35.671807385504266 139.7389483212444 20.72 35.671807385504266 139.7389483212444 20.018 35.67180643324469 139.73894089914717 20.018 35.67180643324469 139.73894089914717 20.72 35.671807385504266 139.7389483212444 20.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a1c92367-670e-4d2f-92ae-7c8e34a92fd0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a1c92367-670e-4d2f-92ae-7c8e34a92fd0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a1c92367-670e-4d2f-92ae-7c8e34a92fd0">
											<gml:posList>35.67180500420231 139.73894618103546 11.702 35.67179853332103 139.73894742585648 11.702 35.67179853332103 139.73894742585648 20.72 35.67180500420231 139.73894618103546 20.72 35.67180500420231 139.73894618103546 11.702</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5586d1db-be1c-4db5-83b6-9c429c3903ee">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5586d1db-be1c-4db5-83b6-9c429c3903ee">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5586d1db-be1c-4db5-83b6-9c429c3903ee">
											<gml:posList>35.671831481740455 139.73896306199282 11.702 35.671827763472436 139.73893417987992 11.702 35.671827763472436 139.73893417987992 20.72 35.671831481740455 139.73896306199282 20.72 35.671831481740455 139.73896306199282 11.702</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7f19997c-ba33-4e8f-b3b2-400e1ccd6e5c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7f19997c-ba33-4e8f-b3b2-400e1ccd6e5c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7f19997c-ba33-4e8f-b3b2-400e1ccd6e5c">
											<gml:posList>35.67180091462297 139.73894956606532 20.72 35.67180091462297 139.73894956606532 20.018 35.671807385504266 139.7389483212444 20.018 35.671807385504266 139.7389483212444 20.72 35.67180091462297 139.73894956606532 20.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e030b235-75fb-4f7f-bcb3-955a8da2bb38">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e030b235-75fb-4f7f-bcb3-955a8da2bb38">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e030b235-75fb-4f7f-bcb3-955a8da2bb38">
											<gml:posList>35.67182603513307 139.73893710922644 20.72 35.67182603513307 139.73893710922644 20.018 35.67182909144237 139.7389609438863 20.018 35.67182909144237 139.7389609438863 20.72 35.67182603513307 139.73893710922644 20.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d8de52f7-94db-46df-ab3f-ca44c45eff23">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d8de52f7-94db-46df-ab3f-ca44c45eff23">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d8de52f7-94db-46df-ab3f-ca44c45eff23">
											<gml:posList>35.67180211168967 139.73895882158553 20.72 35.67180211168967 139.73895882158553 20.018 35.67180091462297 139.73894956606532 20.018 35.67180091462297 139.73894956606532 20.72 35.67180211168967 139.73895882158553 20.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4914e6a4-b54b-4697-9ef0-5e5677d516c3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4914e6a4-b54b-4697-9ef0-5e5677d516c3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4914e6a4-b54b-4697-9ef0-5e5677d516c3">
											<gml:posList>35.67179853332103 139.73894742585648 11.702 35.67180037432732 139.73896173989473 11.702 35.67180037432732 139.73896173989473 20.72 35.67179853332103 139.73894742585648 20.72 35.67179853332103 139.73894742585648 11.702</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-568a9787-b3d1-4e03-bf1f-5361faedfc20">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-568a9787-b3d1-4e03-bf1f-5361faedfc20">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-568a9787-b3d1-4e03-bf1f-5361faedfc20">
											<gml:posList>35.67180860960357 139.7389575656871 20.72 35.67180860960357 139.7389575656871 20.018 35.67180211168967 139.73895882158553 20.018 35.67180211168967 139.73895882158553 20.72 35.67180860960357 139.7389575656871 20.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-abbf34c8-eecc-4a01-83dc-ea17a7bd4162">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-abbf34c8-eecc-4a01-83dc-ea17a7bd4162">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-abbf34c8-eecc-4a01-83dc-ea17a7bd4162">
											<gml:posList>35.67180037432732 139.73896173989473 11.702 35.671806881254966 139.73896048398595 11.702 35.671806881254966 139.73896048398595 20.72 35.67180037432732 139.73896173989473 20.72 35.67180037432732 139.73896173989473 11.702</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ad0a2f1f-e547-467d-a71d-218ea8e46331">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ad0a2f1f-e547-467d-a71d-218ea8e46331">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ad0a2f1f-e547-467d-a71d-218ea8e46331">
											<gml:posList>35.671809543626914 139.73896472269124 20.72 35.671809543626914 139.73896472269124 20.018 35.67180860960357 139.7389575656871 20.018 35.67180860960357 139.7389575656871 20.72 35.671809543626914 139.73896472269124 20.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-aa0c88f8-8378-4f1e-9047-c5e5cdaf1d80">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-aa0c88f8-8378-4f1e-9047-c5e5cdaf1d80">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-aa0c88f8-8378-4f1e-9047-c5e5cdaf1d80">
											<gml:posList>35.67182909144237 139.7389609438863 20.72 35.67182909144237 139.7389609438863 20.018 35.671809543626914 139.73896472269124 20.018 35.671809543626914 139.73896472269124 20.72 35.67182909144237 139.7389609438863 20.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1289b115-b764-4b65-8b5b-5991b32e22b2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1289b115-b764-4b65-8b5b-5991b32e22b2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1289b115-b764-4b65-8b5b-5991b32e22b2">
											<gml:posList>35.671806881254966 139.73896048398595 11.702 35.671807806264404 139.73896764100058 11.702 35.671807806264404 139.73896764100058 20.72 35.671806881254966 139.73896048398595 20.72 35.671806881254966 139.73896048398595 11.702</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0e50bfa7-7b3c-458b-85d3-b7ffde75e393">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0e50bfa7-7b3c-458b-85d3-b7ffde75e393">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0e50bfa7-7b3c-458b-85d3-b7ffde75e393">
											<gml:posList>35.671807806264404 139.73896764100058 11.702 35.671831481740455 139.73896306199282 11.702 35.671831481740455 139.73896306199282 20.72 35.671807806264404 139.73896764100058 20.72 35.671807806264404 139.73896764100058 11.702</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-4734</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>5</uro:specifiedFloorAreaRate>
					<uro:surveyYear>0001</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.32</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>