<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_dbefd06c-8085-4d57-8359-69304cdd84da">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>18</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103018001</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="再開発等促進区を定める地区計画">
				<gen:value>虎ノ門駅南地区</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">401</bldg:usage>
			<bldg:measuredHeight uom="m">24.3</bldg:measuredHeight>
			<bldg:storeysAboveGround>7</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>1</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.6694009549565 139.74986116864446 0 35.66956912087789 139.74994748491753 0 35.66960456308684 139.7498437246769 0 35.669436307031724 139.74975751913877 0 35.6694009549565 139.74986116864446 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6694009549565 139.74986116864446 6.165 35.669436307031724 139.74975751913877 6.165 35.66960456308684 139.7498437246769 6.165 35.66956912087789 139.74994748491753 6.165 35.6694009549565 139.74986116864446 6.165</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6694009549565 139.74986116864446 6.165 35.66956912087789 139.74994748491753 6.165 35.66956912087789 139.74994748491753 27.48 35.6694009549565 139.74986116864446 27.48 35.6694009549565 139.74986116864446 6.165</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66956912087789 139.74994748491753 6.165 35.66960456308684 139.7498437246769 6.165 35.66960456308684 139.7498437246769 27.48 35.66956912087789 139.74994748491753 27.48 35.66956912087789 139.74994748491753 6.165</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66960456308684 139.7498437246769 6.165 35.669436307031724 139.74975751913877 6.165 35.669436307031724 139.74975751913877 27.48 35.66960456308684 139.7498437246769 27.48 35.66960456308684 139.7498437246769 6.165</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669436307031724 139.74975751913877 6.165 35.6694009549565 139.74986116864446 6.165 35.6694009549565 139.74986116864446 27.48 35.669436307031724 139.74975751913877 27.48 35.669436307031724 139.74975751913877 6.165</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6694009549565 139.74986116864446 27.48 35.66956912087789 139.74994748491753 27.48 35.66960456308684 139.7498437246769 27.48 35.669436307031724 139.74975751913877 27.48 35.6694009549565 139.74986116864446 27.48</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-0c1d87ff-936e-4a91-8263-955b68289a30"/>
							<gml:surfaceMember xlink:href="#poly-0159afdf-59b3-4788-9a11-cc3a26ae8b27"/>
							<gml:surfaceMember xlink:href="#poly-6dc1ae8f-e937-43c9-86bc-90ed23f38a73"/>
							<gml:surfaceMember xlink:href="#poly-bb78d2de-fcdf-44b8-8019-99c4e896755d"/>
							<gml:surfaceMember xlink:href="#poly-4bab059f-4f87-4c2d-92f2-50f731d9e0da"/>
							<gml:surfaceMember xlink:href="#poly-7a79c0fd-d23f-4aec-be68-18dd03483192"/>
							<gml:surfaceMember xlink:href="#poly-92d5936b-af73-4a23-84fd-2e55de241c6b"/>
							<gml:surfaceMember xlink:href="#poly-1b5b92e0-2c91-4c60-9773-a2817b61c1d7"/>
							<gml:surfaceMember xlink:href="#poly-6dfa751b-edba-4d23-b042-bdea06e5cf6d"/>
							<gml:surfaceMember xlink:href="#poly-3c40d4ec-ce5b-4a8a-babb-28236f57d9c1"/>
							<gml:surfaceMember xlink:href="#poly-f6be214a-3bf8-43cc-b203-893aa3d016df"/>
							<gml:surfaceMember xlink:href="#poly-951c3298-185c-4fc2-b06e-f65cb9434567"/>
							<gml:surfaceMember xlink:href="#poly-cb78a590-8e0f-4b22-8220-97474eaf5d59"/>
							<gml:surfaceMember xlink:href="#poly-e30ee16a-19c8-442c-9cd9-f4be9c595d47"/>
							<gml:surfaceMember xlink:href="#poly-5193626f-f4df-4414-ad65-f2c4546d7191"/>
							<gml:surfaceMember xlink:href="#poly-776cf182-28d2-4b52-89c3-ba2e49cc433c"/>
							<gml:surfaceMember xlink:href="#poly-50869af8-7113-4672-ba7f-99e268793dc4"/>
							<gml:surfaceMember xlink:href="#poly-417af2c9-239c-4fdc-890b-370cb9130877"/>
							<gml:surfaceMember xlink:href="#poly-8f2dcb00-a58f-40de-9682-db966d8b8421"/>
							<gml:surfaceMember xlink:href="#poly-c183d168-9d37-473e-95fc-f6c9231359f6"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_dbefd06c-8085-4d57-8359-69304cdd84da_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c6ea8e68-50f0-463a-93fc-84d0d571b73a">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66952944265013 139.74981774504647 34.292 35.66952366798734 139.7498352702431 34.292 35.66950930418838 139.7498281714869 34.292 35.66951507885017 139.74981064629287 34.292 35.66952944265013 139.74981774504647 34.292</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2d8d8773-0c25-45a7-a668-9c59d347814c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2d8d8773-0c25-45a7-a668-9c59d347814c_0">
											<gml:posList>35.66950930418838 139.7498281714869 34.292 35.66950930418838 139.7498281714869 36.626 35.66951507885017 139.74981064629287 36.626 35.66951507885017 139.74981064629287 34.292 35.66950930418838 139.7498281714869 34.292</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-04292c3b-94da-49ea-84e8-fa002081ddfb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-04292c3b-94da-49ea-84e8-fa002081ddfb_0">
											<gml:posList>35.66952366798734 139.7498352702431 34.292 35.66952366798734 139.7498352702431 36.626 35.66950930418838 139.7498281714869 36.626 35.66950930418838 139.7498281714869 34.292 35.66952366798734 139.7498352702431 34.292</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b40340fd-54a6-4abf-a72a-1088de9b70dd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b40340fd-54a6-4abf-a72a-1088de9b70dd_0">
											<gml:posList>35.66950930418838 139.7498281714869 36.626 35.66952366798734 139.7498352702431 36.626 35.66952944265013 139.74981774504647 36.626 35.66951507885017 139.74981064629287 36.626 35.66950930418838 139.7498281714869 36.626</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f1385f46-fb8c-468c-9466-8e814112bf62">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f1385f46-fb8c-468c-9466-8e814112bf62_0">
											<gml:posList>35.66951507885017 139.74981064629287 34.292 35.66951507885017 139.74981064629287 36.626 35.66952944265013 139.74981774504647 36.626 35.66952944265013 139.74981774504647 34.292 35.66951507885017 139.74981064629287 34.292</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3a5843fc-f710-4bcb-8280-02839979b780">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3a5843fc-f710-4bcb-8280-02839979b780_0">
											<gml:posList>35.66952944265013 139.74981774504647 34.292 35.66952944265013 139.74981774504647 36.626 35.66952366798734 139.7498352702431 36.626 35.66952366798734 139.7498352702431 34.292 35.66952944265013 139.74981774504647 34.292</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-0c1d87ff-936e-4a91-8263-955b68289a30">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0c1d87ff-936e-4a91-8263-955b68289a30">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0c1d87ff-936e-4a91-8263-955b68289a30">
											<gml:posList>35.66940095495647 139.74986116864446 6.165 35.66943630703172 139.74975751913877 6.165 35.66960456308685 139.7498437246769 6.165 35.66956912087787 139.74994748491753 6.165 35.66940095495647 139.74986116864446 6.165</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-0159afdf-59b3-4788-9a11-cc3a26ae8b27">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0159afdf-59b3-4788-9a11-cc3a26ae8b27">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0159afdf-59b3-4788-9a11-cc3a26ae8b27">
											<gml:posList>35.66943630703172 139.74975751913877 23.8 35.66940095495647 139.74986116864446 23.8 35.66948068840713 139.7497802610573 34.6 35.66943630703172 139.74975751913877 23.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-6dc1ae8f-e937-43c9-86bc-90ed23f38a73">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6dc1ae8f-e937-43c9-86bc-90ed23f38a73">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6dc1ae8f-e937-43c9-86bc-90ed23f38a73">
											<gml:posList>35.66940095495647 139.74986116864446 23.8 35.669466288227426 139.74982467047752 34.6 35.66948068840713 139.7497802610573 34.6 35.66940095495647 139.74986116864446 23.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-bb78d2de-fcdf-44b8-8019-99c4e896755d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bb78d2de-fcdf-44b8-8019-99c4e896755d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bb78d2de-fcdf-44b8-8019-99c4e896755d">
											<gml:posList>35.66953852178941 139.74986007546104 34.6 35.669466288227426 139.74982467047752 34.6 35.66940095495647 139.74986116864446 23.8 35.66953852178941 139.74986007546104 34.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-4bab059f-4f87-4c2d-92f2-50f731d9e0da">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4bab059f-4f87-4c2d-92f2-50f731d9e0da">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4bab059f-4f87-4c2d-92f2-50f731d9e0da">
											<gml:posList>35.669466288227426 139.74982467047752 34.6 35.66947100970403 139.74982219122577 34.6 35.669482702537906 139.74978612445702 34.6 35.66948068840713 139.7497802610573 34.6 35.669466288227426 139.74982467047752 34.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-7a79c0fd-d23f-4aec-be68-18dd03483192">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7a79c0fd-d23f-4aec-be68-18dd03483192">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7a79c0fd-d23f-4aec-be68-18dd03483192">
											<gml:posList>35.66940095495647 139.74986116864446 23.8 35.66956912087787 139.74994748491753 23.8 35.66953852178941 139.74986007546104 34.6 35.66940095495647 139.74986116864446 23.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-92d5936b-af73-4a23-84fd-2e55de241c6b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-92d5936b-af73-4a23-84fd-2e55de241c6b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-92d5936b-af73-4a23-84fd-2e55de241c6b">
											<gml:posList>35.66953852178941 139.74986007546104 34.6 35.66953655280747 139.74985432246982 34.6 35.66947100970403 139.74982219122577 34.6 35.669466288227426 139.74982467047752 34.6 35.66953852178941 139.74986007546104 34.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-1b5b92e0-2c91-4c60-9773-a2817b61c1d7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1b5b92e0-2c91-4c60-9773-a2817b61c1d7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1b5b92e0-2c91-4c60-9773-a2817b61c1d7">
											<gml:posList>35.669548345843694 139.7498197578477 34.292 35.669482702537906 139.74978612445702 34.292 35.66947100970403 139.74982219122577 34.292 35.66953655280747 139.74985432246982 34.292 35.669548345843694 139.7498197578477 34.292</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-6dfa751b-edba-4d23-b042-bdea06e5cf6d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6dfa751b-edba-4d23-b042-bdea06e5cf6d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6dfa751b-edba-4d23-b042-bdea06e5cf6d">
											<gml:posList>35.66948068840713 139.7497802610573 34.6 35.669482702537906 139.74978612445702 34.6 35.669548345843694 139.7498197578477 34.6 35.66955309441494 139.74981735588793 34.6 35.66948068840713 139.7497802610573 34.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-3c40d4ec-ce5b-4a8a-babb-28236f57d9c1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3c40d4ec-ce5b-4a8a-babb-28236f57d9c1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3c40d4ec-ce5b-4a8a-babb-28236f57d9c1">
											<gml:posList>35.66955309441494 139.74981735588793 34.6 35.669548345843694 139.7498197578477 34.6 35.66953655280747 139.74985432246982 34.6 35.66953852178941 139.74986007546104 34.6 35.66955309441494 139.74981735588793 34.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f6be214a-3bf8-43cc-b203-893aa3d016df">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f6be214a-3bf8-43cc-b203-893aa3d016df">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f6be214a-3bf8-43cc-b203-893aa3d016df">
											<gml:posList>35.66953852178941 139.74986007546104 34.6 35.66956912087787 139.74994748491753 23.8 35.66955309441494 139.74981735588793 34.6 35.66953852178941 139.74986007546104 34.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-951c3298-185c-4fc2-b06e-f65cb9434567">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-951c3298-185c-4fc2-b06e-f65cb9434567">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-951c3298-185c-4fc2-b06e-f65cb9434567">
											<gml:posList>35.66956912087787 139.74994748491753 23.8 35.66960456308685 139.7498437246769 23.8 35.66955309441494 139.74981735588793 34.6 35.66956912087787 139.74994748491753 23.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-cb78a590-8e0f-4b22-8220-97474eaf5d59">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cb78a590-8e0f-4b22-8220-97474eaf5d59">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cb78a590-8e0f-4b22-8220-97474eaf5d59">
											<gml:posList>35.66953655280747 139.74985432246982 34.6 35.66953655280747 139.74985432246982 34.292 35.66947100970403 139.74982219122577 34.292 35.66947100970403 139.74982219122577 34.6 35.66953655280747 139.74985432246982 34.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e30ee16a-19c8-442c-9cd9-f4be9c595d47">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e30ee16a-19c8-442c-9cd9-f4be9c595d47">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e30ee16a-19c8-442c-9cd9-f4be9c595d47">
											<gml:posList>35.66943630703172 139.74975751913877 6.165 35.66940095495647 139.74986116864446 6.165 35.66940095495647 139.74986116864446 23.8 35.66943630703172 139.74975751913877 23.8 35.66943630703172 139.74975751913877 6.165</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5193626f-f4df-4414-ad65-f2c4546d7191">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5193626f-f4df-4414-ad65-f2c4546d7191">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5193626f-f4df-4414-ad65-f2c4546d7191">
											<gml:posList>35.66947100970403 139.74982219122577 34.6 35.66947100970403 139.74982219122577 34.292 35.669482702537906 139.74978612445702 34.292 35.669482702537906 139.74978612445702 34.6 35.66947100970403 139.74982219122577 34.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-776cf182-28d2-4b52-89c3-ba2e49cc433c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-776cf182-28d2-4b52-89c3-ba2e49cc433c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-776cf182-28d2-4b52-89c3-ba2e49cc433c">
											<gml:posList>35.66940095495647 139.74986116864446 6.165 35.66956912087787 139.74994748491753 6.165 35.66956912087787 139.74994748491753 23.8 35.66940095495647 139.74986116864446 23.8 35.66940095495647 139.74986116864446 6.165</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-50869af8-7113-4672-ba7f-99e268793dc4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-50869af8-7113-4672-ba7f-99e268793dc4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-50869af8-7113-4672-ba7f-99e268793dc4">
											<gml:posList>35.669482702537906 139.74978612445702 34.6 35.669482702537906 139.74978612445702 34.292 35.669548345843694 139.7498197578477 34.292 35.669548345843694 139.7498197578477 34.6 35.669482702537906 139.74978612445702 34.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-417af2c9-239c-4fdc-890b-370cb9130877">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-417af2c9-239c-4fdc-890b-370cb9130877">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-417af2c9-239c-4fdc-890b-370cb9130877">
											<gml:posList>35.66960456308685 139.7498437246769 23.8 35.66960456308685 139.7498437246769 6.165 35.66943630703172 139.74975751913877 6.165 35.66943630703172 139.74975751913877 23.8 35.66948068840713 139.7497802610573 34.6 35.66955309441494 139.74981735588793 34.6 35.66960456308685 139.7498437246769 23.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8f2dcb00-a58f-40de-9682-db966d8b8421">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8f2dcb00-a58f-40de-9682-db966d8b8421">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8f2dcb00-a58f-40de-9682-db966d8b8421">
											<gml:posList>35.669548345843694 139.7498197578477 34.6 35.669548345843694 139.7498197578477 34.292 35.66953655280747 139.74985432246982 34.292 35.66953655280747 139.74985432246982 34.6 35.669548345843694 139.7498197578477 34.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c183d168-9d37-473e-95fc-f6c9231359f6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c183d168-9d37-473e-95fc-f6c9231359f6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c183d168-9d37-473e-95fc-f6c9231359f6">
											<gml:posList>35.66956912087787 139.74994748491753 6.165 35.66960456308685 139.7498437246769 6.165 35.66960456308685 139.7498437246769 23.8 35.66956912087787 139.74994748491753 23.8 35.66956912087787 139.74994748491753 6.165</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区虎ノ門一丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-482</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">205.86855</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1210</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>7</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>