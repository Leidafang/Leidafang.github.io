<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_dd0faf38-29dd-4320-b3f3-a42a0a5e1600">
			<core:creationDate>2024-03-15</core:creationDate>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.66707141302756 139.7383351653948 0 35.66704059308606 139.7382983862587 0 35.666989121679514 139.73836316455623 0 35.66701994160147 139.7383999436937 0 35.66707141302756 139.7383351653948 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66707141302756 139.7383351653948 13.26 35.66701994160147 139.7383999436937 13.26 35.666989121679514 139.73836316455623 13.26 35.66704059308606 139.7382983862587 13.26 35.66707141302756 139.7383351653948 13.26</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66707141302756 139.7383351653948 13.26 35.66704059308606 139.7382983862587 13.26 35.66704059308606 139.7382983862587 16.259999999999998 35.66707141302756 139.7383351653948 16.259999999999998 35.66707141302756 139.7383351653948 13.26</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66704059308606 139.7382983862587 13.26 35.666989121679514 139.73836316455623 13.26 35.666989121679514 139.73836316455623 16.259999999999998 35.66704059308606 139.7382983862587 16.259999999999998 35.66704059308606 139.7382983862587 13.26</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.666989121679514 139.73836316455623 13.26 35.66701994160147 139.7383999436937 13.26 35.66701994160147 139.7383999436937 16.259999999999998 35.666989121679514 139.73836316455623 16.259999999999998 35.666989121679514 139.73836316455623 13.26</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66701994160147 139.7383999436937 13.26 35.66707141302756 139.7383351653948 13.26 35.66707141302756 139.7383351653948 16.259999999999998 35.66701994160147 139.7383999436937 16.259999999999998 35.66701994160147 139.7383999436937 13.26</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66707141302756 139.7383351653948 16.259999999999998 35.66704059308606 139.7382983862587 16.259999999999998 35.666989121679514 139.73836316455623 16.259999999999998 35.66701994160147 139.7383999436937 16.259999999999998 35.66707141302756 139.7383351653948 16.259999999999998</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-f5221346-af1c-4080-ac93-c8da6880ac4b"/>
							<gml:surfaceMember xlink:href="#poly-d7f3eb8a-b48e-491c-ad25-fe784d188128"/>
							<gml:surfaceMember xlink:href="#poly-f0a6984d-54da-404c-834c-70a2fb67f0e2"/>
							<gml:surfaceMember xlink:href="#poly-514d119b-3640-42bf-9966-e8443185b451"/>
							<gml:surfaceMember xlink:href="#poly-e8a4e652-9cb8-40a4-b0fe-8491d3cdc9d6"/>
							<gml:surfaceMember xlink:href="#poly-65d77acc-d8bd-4a83-bdd6-ce9d78f21350"/>
							<gml:surfaceMember xlink:href="#poly-f1891767-3d6f-4389-b0bf-9dcdd3762059"/>
							<gml:surfaceMember xlink:href="#poly-76384067-14b8-45d5-ac68-46af291d8041"/>
							<gml:surfaceMember xlink:href="#poly-4629babc-e410-4f83-8299-2da7033f2c6c"/>
							<gml:surfaceMember xlink:href="#poly-fcdad894-48e5-4837-b50b-ea27a1d7a924"/>
							<gml:surfaceMember xlink:href="#poly-9a7c3a06-fc1b-403a-b49a-b78c0dd6250b"/>
							<gml:surfaceMember xlink:href="#poly-3b2f9cd2-d9e4-4f20-922b-3c7d51157d29"/>
							<gml:surfaceMember xlink:href="#poly-890dda46-ce57-4207-b7c7-6855ebedfe66"/>
							<gml:surfaceMember xlink:href="#poly-58e1f05a-12c2-48f5-b576-9e302d3c2444"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-f5221346-af1c-4080-ac93-c8da6880ac4b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f5221346-af1c-4080-ac93-c8da6880ac4b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f5221346-af1c-4080-ac93-c8da6880ac4b">
											<gml:posList>35.66707141302756 139.73833516539483 13.26 35.667019941601474 139.7383999436937 13.26 35.66698912167949 139.7383631645562 13.26 35.667040593086064 139.7382983862587 13.26 35.66707141302756 139.73833516539483 13.26</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d7f3eb8a-b48e-491c-ad25-fe784d188128">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d7f3eb8a-b48e-491c-ad25-fe784d188128">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d7f3eb8a-b48e-491c-ad25-fe784d188128">
											<gml:posList>35.667040593086064 139.7382983862587 18.881 35.667040603756085 139.73830048494787 18.881 35.667069691423116 139.73833518952603 18.881 35.66707141302756 139.73833516539483 18.881 35.667040593086064 139.7382983862587 18.881</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f0a6984d-54da-404c-834c-70a2fb67f0e2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f0a6984d-54da-404c-834c-70a2fb67f0e2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f0a6984d-54da-404c-834c-70a2fb67f0e2">
											<gml:posList>35.66698912167949 139.7383631645562 18.881 35.66699084328397 139.73836314042563 18.881 35.667040603756085 139.73830048494787 18.881 35.667040593086064 139.7382983862587 18.881 35.66698912167949 139.7383631645562 18.881</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-514d119b-3640-42bf-9966-e8443185b451">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-514d119b-3640-42bf-9966-e8443185b451">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-514d119b-3640-42bf-9966-e8443185b451">
											<gml:posList>35.667069691423116 139.73833518952603 17.118 35.667040603756085 139.73830048494787 17.118 35.66699084328397 139.73836314042563 17.118 35.66701993093317 139.73839784500507 17.118 35.667069691423116 139.73833518952603 17.118</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e8a4e652-9cb8-40a4-b0fe-8491d3cdc9d6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e8a4e652-9cb8-40a4-b0fe-8491d3cdc9d6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e8a4e652-9cb8-40a4-b0fe-8491d3cdc9d6">
											<gml:posList>35.66707141302756 139.73833516539483 18.881 35.667069691423116 139.73833518952603 18.881 35.66701993093317 139.73839784500507 18.881 35.667019941601474 139.7383999436937 18.881 35.66707141302756 139.73833516539483 18.881</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-65d77acc-d8bd-4a83-bdd6-ce9d78f21350">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-65d77acc-d8bd-4a83-bdd6-ce9d78f21350">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-65d77acc-d8bd-4a83-bdd6-ce9d78f21350">
											<gml:posList>35.667019941601474 139.7383999436937 18.881 35.66701993093317 139.73839784500507 18.881 35.66699084328397 139.73836314042563 18.881 35.66698912167949 139.7383631645562 18.881 35.667019941601474 139.7383999436937 18.881</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f1891767-3d6f-4389-b0bf-9dcdd3762059">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f1891767-3d6f-4389-b0bf-9dcdd3762059">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f1891767-3d6f-4389-b0bf-9dcdd3762059">
											<gml:posList>35.66699084328397 139.73836314042563 18.881 35.66699084328397 139.73836314042563 17.118 35.667040603756085 139.73830048494787 17.118 35.667040603756085 139.73830048494787 18.881 35.66699084328397 139.73836314042563 18.881</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-76384067-14b8-45d5-ac68-46af291d8041">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-76384067-14b8-45d5-ac68-46af291d8041">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-76384067-14b8-45d5-ac68-46af291d8041">
											<gml:posList>35.667069691423116 139.73833518952603 18.881 35.667069691423116 139.73833518952603 17.118 35.66701993093317 139.73839784500507 17.118 35.66701993093317 139.73839784500507 18.881 35.667069691423116 139.73833518952603 18.881</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4629babc-e410-4f83-8299-2da7033f2c6c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4629babc-e410-4f83-8299-2da7033f2c6c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4629babc-e410-4f83-8299-2da7033f2c6c">
											<gml:posList>35.66707141302756 139.73833516539483 13.26 35.667040593086064 139.7382983862587 13.26 35.667040593086064 139.7382983862587 18.881 35.66707141302756 139.73833516539483 18.881 35.66707141302756 139.73833516539483 13.26</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-fcdad894-48e5-4837-b50b-ea27a1d7a924">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fcdad894-48e5-4837-b50b-ea27a1d7a924">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fcdad894-48e5-4837-b50b-ea27a1d7a924">
											<gml:posList>35.667040603756085 139.73830048494787 18.881 35.667040603756085 139.73830048494787 17.118 35.667069691423116 139.73833518952603 17.118 35.667069691423116 139.73833518952603 18.881 35.667040603756085 139.73830048494787 18.881</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9a7c3a06-fc1b-403a-b49a-b78c0dd6250b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9a7c3a06-fc1b-403a-b49a-b78c0dd6250b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9a7c3a06-fc1b-403a-b49a-b78c0dd6250b">
											<gml:posList>35.667040593086064 139.7382983862587 13.26 35.66698912167949 139.7383631645562 13.26 35.66698912167949 139.7383631645562 18.881 35.667040593086064 139.7382983862587 18.881 35.667040593086064 139.7382983862587 13.26</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3b2f9cd2-d9e4-4f20-922b-3c7d51157d29">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3b2f9cd2-d9e4-4f20-922b-3c7d51157d29">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3b2f9cd2-d9e4-4f20-922b-3c7d51157d29">
											<gml:posList>35.667019941601474 139.7383999436937 13.26 35.66707141302756 139.73833516539483 13.26 35.66707141302756 139.73833516539483 18.881 35.667019941601474 139.7383999436937 18.881 35.667019941601474 139.7383999436937 13.26</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-890dda46-ce57-4207-b7c7-6855ebedfe66">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-890dda46-ce57-4207-b7c7-6855ebedfe66">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-890dda46-ce57-4207-b7c7-6855ebedfe66">
											<gml:posList>35.66701993093317 139.73839784500507 18.881 35.66701993093317 139.73839784500507 17.118 35.66699084328397 139.73836314042563 17.118 35.66699084328397 139.73836314042563 18.881 35.66701993093317 139.73839784500507 18.881</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-58e1f05a-12c2-48f5-b576-9e302d3c2444">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-58e1f05a-12c2-48f5-b576-9e302d3c2444">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-58e1f05a-12c2-48f5-b576-9e302d3c2444">
											<gml:posList>35.66698912167949 139.7383631645562 13.26 35.667019941601474 139.7383999436937 13.26 35.667019941601474 139.7383999436937 18.881 35.66698912167949 139.7383631645562 18.881 35.66698912167949 139.7383631645562 13.26</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-9672</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">222</uro:landUseType>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>7</uro:specifiedFloorAreaRate>
					<uro:surveyYear>0001</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.03</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">0</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>