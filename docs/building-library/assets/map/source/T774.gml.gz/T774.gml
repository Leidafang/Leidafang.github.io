<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_ddc12487-4f75-40ec-9266-d467e1986f27">
			<core:creationDate>2024-03-15</core:creationDate>
			<bldg:measuredHeight uom="m">4</bldg:measuredHeight>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.672330715700866 139.73940062383627 0 35.6722887124347 139.7393437724128 0 35.67223558644708 139.7394027126198 0 35.67227758068069 139.7394595750937 0 35.672330715700866 139.73940062383627 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672330715700866 139.73940062383627 8.36 35.67227758068069 139.7394595750937 8.36 35.67223558644708 139.7394027126198 8.36 35.6722887124347 139.7393437724128 8.36 35.672330715700866 139.73940062383627 8.36</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672330715700866 139.73940062383627 8.36 35.6722887124347 139.7393437724128 8.36 35.6722887124347 139.7393437724128 12.38 35.672330715700866 139.73940062383627 12.38 35.672330715700866 139.73940062383627 8.36</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6722887124347 139.7393437724128 8.36 35.67223558644708 139.7394027126198 8.36 35.67223558644708 139.7394027126198 12.38 35.6722887124347 139.7393437724128 12.38 35.6722887124347 139.7393437724128 8.36</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67223558644708 139.7394027126198 8.36 35.67227758068069 139.7394595750937 8.36 35.67227758068069 139.7394595750937 12.38 35.67223558644708 139.7394027126198 12.38 35.67223558644708 139.7394027126198 8.36</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67227758068069 139.7394595750937 8.36 35.672330715700866 139.73940062383627 8.36 35.672330715700866 139.73940062383627 12.38 35.67227758068069 139.7394595750937 12.38 35.67227758068069 139.7394595750937 8.36</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672330715700866 139.73940062383627 12.38 35.6722887124347 139.7393437724128 12.38 35.67223558644708 139.7394027126198 12.38 35.67227758068069 139.7394595750937 12.38 35.672330715700866 139.73940062383627 12.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-69dadfa5-c6b8-4ccd-b256-dd3063229698"/>
							<gml:surfaceMember xlink:href="#poly-9bd7ce76-91df-45dc-90f7-da560f56d269"/>
							<gml:surfaceMember xlink:href="#poly-847d187a-528f-4978-b704-5b53dfd7beec"/>
							<gml:surfaceMember xlink:href="#poly-243d79ef-ad67-446b-a64b-dacdf51db937"/>
							<gml:surfaceMember xlink:href="#poly-be8bbbca-4610-41e2-a9f2-8c60e97611d9"/>
							<gml:surfaceMember xlink:href="#poly-f38dc235-7dd4-4b75-9856-7d3861f3385c"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-69dadfa5-c6b8-4ccd-b256-dd3063229698">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-69dadfa5-c6b8-4ccd-b256-dd3063229698">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-69dadfa5-c6b8-4ccd-b256-dd3063229698">
											<gml:posList>35.67233071570087 139.73940062383627 8.36 35.672277580680685 139.7394595750937 8.36 35.67223558644705 139.73940271261978 8.36 35.672288712434664 139.7393437724128 8.36 35.67233071570087 139.73940062383627 8.36</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-9bd7ce76-91df-45dc-90f7-da560f56d269">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9bd7ce76-91df-45dc-90f7-da560f56d269">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9bd7ce76-91df-45dc-90f7-da560f56d269">
											<gml:posList>35.672288712434664 139.7393437724128 12.882 35.67223558644705 139.73940271261978 12.882 35.672277580680685 139.7394595750937 12.882 35.67233071570087 139.73940062383627 12.882 35.672288712434664 139.7393437724128 12.882</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-847d187a-528f-4978-b704-5b53dfd7beec">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-847d187a-528f-4978-b704-5b53dfd7beec">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-847d187a-528f-4978-b704-5b53dfd7beec">
											<gml:posList>35.672277580680685 139.7394595750937 12.882 35.672277580680685 139.7394595750937 8.36 35.67233071570087 139.73940062383627 8.36 35.67233071570087 139.73940062383627 12.882 35.672277580680685 139.7394595750937 12.882</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-243d79ef-ad67-446b-a64b-dacdf51db937">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-243d79ef-ad67-446b-a64b-dacdf51db937">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-243d79ef-ad67-446b-a64b-dacdf51db937">
											<gml:posList>35.67233071570087 139.73940062383627 12.882 35.67233071570087 139.73940062383627 8.36 35.672288712434664 139.7393437724128 8.36 35.672288712434664 139.7393437724128 12.882 35.67233071570087 139.73940062383627 12.882</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-be8bbbca-4610-41e2-a9f2-8c60e97611d9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-be8bbbca-4610-41e2-a9f2-8c60e97611d9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-be8bbbca-4610-41e2-a9f2-8c60e97611d9">
											<gml:posList>35.672288712434664 139.7393437724128 12.882 35.672288712434664 139.7393437724128 8.36 35.67223558644705 139.73940271261978 8.36 35.67223558644705 139.73940271261978 12.882 35.672288712434664 139.7393437724128 12.882</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f38dc235-7dd4-4b75-9856-7d3861f3385c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f38dc235-7dd4-4b75-9856-7d3861f3385c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f38dc235-7dd4-4b75-9856-7d3861f3385c">
											<gml:posList>35.67223558644705 139.73940271261978 12.882 35.67223558644705 139.73940271261978 8.36 35.672277580680685 139.7394595750937 8.36 35.672277580680685 139.7394595750937 12.882 35.67223558644705 139.73940271261978 12.882</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-3834</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">222</uro:landUseType>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>6</uro:specifiedFloorAreaRate>
					<uro:surveyYear>0001</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.06</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>