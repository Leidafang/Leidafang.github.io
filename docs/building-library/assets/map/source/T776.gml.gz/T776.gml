<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_de462701-7c48-4698-a58f-1381baabe5e3">
			<core:creationDate>2024-03-15</core:creationDate>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.66759379567593 139.7389894896085 0 35.66758555293052 139.7390071506138 0 35.667630231517954 139.73903849044854 0 35.667638483290276 139.7390208404719 0 35.66759379567593 139.7389894896085 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66759379567593 139.7389894896085 11.775 35.667638483290276 139.7390208404719 11.775 35.667630231517954 139.73903849044854 11.775 35.66758555293052 139.7390071506138 11.775 35.66759379567593 139.7389894896085 11.775</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66759379567593 139.7389894896085 11.775 35.66758555293052 139.7390071506138 11.775 35.66758555293052 139.7390071506138 14.775 35.66759379567593 139.7389894896085 14.775 35.66759379567593 139.7389894896085 11.775</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66758555293052 139.7390071506138 11.775 35.667630231517954 139.73903849044854 11.775 35.667630231517954 139.73903849044854 14.775 35.66758555293052 139.7390071506138 14.775 35.66758555293052 139.7390071506138 11.775</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667630231517954 139.73903849044854 11.775 35.667638483290276 139.7390208404719 11.775 35.667638483290276 139.7390208404719 14.775 35.667630231517954 139.73903849044854 14.775 35.667630231517954 139.73903849044854 11.775</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667638483290276 139.7390208404719 11.775 35.66759379567593 139.7389894896085 11.775 35.66759379567593 139.7389894896085 14.775 35.667638483290276 139.7390208404719 14.775 35.667638483290276 139.7390208404719 11.775</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66759379567593 139.7389894896085 14.775 35.66758555293052 139.7390071506138 14.775 35.667630231517954 139.73903849044854 14.775 35.667638483290276 139.7390208404719 14.775 35.66759379567593 139.7389894896085 14.775</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-c64cce1b-685a-46b8-b94b-127a6bf5b884"/>
							<gml:surfaceMember xlink:href="#poly-f995604f-5468-4202-a106-d7a2d0de3fbb"/>
							<gml:surfaceMember xlink:href="#poly-d7a161b0-01c7-4ee6-b0d7-9cb36058c5d3"/>
							<gml:surfaceMember xlink:href="#poly-40e0bb78-422f-4f55-8b50-cc15ae285a61"/>
							<gml:surfaceMember xlink:href="#poly-4d86f606-dcf8-4b0e-b9bd-045946eba9db"/>
							<gml:surfaceMember xlink:href="#poly-32cefc9a-04c2-4769-a06e-b435fe5c7219"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-c64cce1b-685a-46b8-b94b-127a6bf5b884">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c64cce1b-685a-46b8-b94b-127a6bf5b884">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c64cce1b-685a-46b8-b94b-127a6bf5b884">
											<gml:posList>35.6675937956759 139.7389894896085 11.775 35.66763848329026 139.7390208404719 11.775 35.66763023151794 139.73903849044854 11.775 35.66758555293048 139.73900715061376 11.775 35.6675937956759 139.7389894896085 11.775</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f995604f-5468-4202-a106-d7a2d0de3fbb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f995604f-5468-4202-a106-d7a2d0de3fbb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f995604f-5468-4202-a106-d7a2d0de3fbb">
											<gml:posList>35.66763848329026 139.7390208404719 15.028 35.6675937956759 139.7389894896085 15.028 35.66758555293048 139.73900715061376 15.028 35.66763023151794 139.73903849044854 15.028 35.66763848329026 139.7390208404719 15.028</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d7a161b0-01c7-4ee6-b0d7-9cb36058c5d3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d7a161b0-01c7-4ee6-b0d7-9cb36058c5d3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d7a161b0-01c7-4ee6-b0d7-9cb36058c5d3">
											<gml:posList>35.6675937956759 139.7389894896085 11.775 35.66758555293048 139.73900715061376 11.775 35.66758555293048 139.73900715061376 15.028 35.6675937956759 139.7389894896085 15.028 35.6675937956759 139.7389894896085 11.775</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-40e0bb78-422f-4f55-8b50-cc15ae285a61">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-40e0bb78-422f-4f55-8b50-cc15ae285a61">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-40e0bb78-422f-4f55-8b50-cc15ae285a61">
											<gml:posList>35.66763848329026 139.7390208404719 11.775 35.6675937956759 139.7389894896085 11.775 35.6675937956759 139.7389894896085 15.028 35.66763848329026 139.7390208404719 15.028 35.66763848329026 139.7390208404719 11.775</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4d86f606-dcf8-4b0e-b9bd-045946eba9db">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4d86f606-dcf8-4b0e-b9bd-045946eba9db">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4d86f606-dcf8-4b0e-b9bd-045946eba9db">
											<gml:posList>35.66758555293048 139.73900715061376 11.775 35.66763023151794 139.73903849044854 11.775 35.66763023151794 139.73903849044854 15.028 35.66758555293048 139.73900715061376 15.028 35.66758555293048 139.73900715061376 11.775</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-32cefc9a-04c2-4769-a06e-b435fe5c7219">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-32cefc9a-04c2-4769-a06e-b435fe5c7219">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-32cefc9a-04c2-4769-a06e-b435fe5c7219">
											<gml:posList>35.66763023151794 139.73903849044854 11.775 35.66763848329026 139.7390208404719 11.775 35.66763848329026 139.7390208404719 15.028 35.66763023151794 139.73903849044854 15.028 35.66763023151794 139.73903849044854 11.775</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-1396</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>7</uro:specifiedFloorAreaRate>
					<uro:surveyYear>0001</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.03</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">0</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>