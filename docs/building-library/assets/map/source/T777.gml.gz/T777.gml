<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_de7d9486-42b3-4d9d-a960-26e257724a96">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3001</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">411</bldg:usage>
			<bldg:measuredHeight uom="m">10.3</bldg:measuredHeight>
			<bldg:storeysAboveGround>3</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.67148641073626 139.73973882685206 0 35.67141714110224 139.7396703979298 0 35.6713705141756 139.73974135921586 0 35.67140965477295 139.73977999802202 0 35.67139296305402 139.73980540212378 0 35.67136994232644 139.73978262921787 0 35.67134063721666 139.73982714723155 0 35.67139385899125 139.73987966601942 0 35.67148641073626 139.73973882685206 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67148641073626 139.73973882685206 14.75 35.67139385899125 139.73987966601942 14.75 35.67134063721666 139.73982714723155 14.75 35.67136994232644 139.73978262921787 14.75 35.67139296305402 139.73980540212378 14.75 35.67140965477295 139.73977999802202 14.75 35.6713705141756 139.73974135921586 14.75 35.67141714110224 139.7396703979298 14.75 35.67148641073626 139.73973882685206 14.75</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67148641073626 139.73973882685206 14.75 35.67141714110224 139.7396703979298 14.75 35.67141714110224 139.7396703979298 25 35.67148641073626 139.73973882685206 25 35.67148641073626 139.73973882685206 14.75</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67141714110224 139.7396703979298 14.75 35.6713705141756 139.73974135921586 14.75 35.6713705141756 139.73974135921586 25 35.67141714110224 139.7396703979298 25 35.67141714110224 139.7396703979298 14.75</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6713705141756 139.73974135921586 14.75 35.67140965477295 139.73977999802202 14.75 35.67140965477295 139.73977999802202 25 35.6713705141756 139.73974135921586 25 35.6713705141756 139.73974135921586 14.75</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67140965477295 139.73977999802202 14.75 35.67139296305402 139.73980540212378 14.75 35.67139296305402 139.73980540212378 25 35.67140965477295 139.73977999802202 25 35.67140965477295 139.73977999802202 14.75</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67139296305402 139.73980540212378 14.75 35.67136994232644 139.73978262921787 14.75 35.67136994232644 139.73978262921787 25 35.67139296305402 139.73980540212378 25 35.67139296305402 139.73980540212378 14.75</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67136994232644 139.73978262921787 14.75 35.67134063721666 139.73982714723155 14.75 35.67134063721666 139.73982714723155 25 35.67136994232644 139.73978262921787 25 35.67136994232644 139.73978262921787 14.75</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67134063721666 139.73982714723155 14.75 35.67139385899125 139.73987966601942 14.75 35.67139385899125 139.73987966601942 25 35.67134063721666 139.73982714723155 25 35.67134063721666 139.73982714723155 14.75</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67139385899125 139.73987966601942 14.75 35.67148641073626 139.73973882685206 14.75 35.67148641073626 139.73973882685206 25 35.67139385899125 139.73987966601942 25 35.67139385899125 139.73987966601942 14.75</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67148641073626 139.73973882685206 25 35.67141714110224 139.7396703979298 25 35.6713705141756 139.73974135921586 25 35.67140965477295 139.73977999802202 25 35.67139296305402 139.73980540212378 25 35.67136994232644 139.73978262921787 25 35.67134063721666 139.73982714723155 25 35.67139385899125 139.73987966601942 25 35.67148641073626 139.73973882685206 25</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-997237d4-164d-4c50-b4ed-7a6ff65c3fac"/>
							<gml:surfaceMember xlink:href="#poly-4a721132-ee26-480c-b05a-3fc1b4772357"/>
							<gml:surfaceMember xlink:href="#poly-2ad4677c-7850-4a57-a704-73782fd5c079"/>
							<gml:surfaceMember xlink:href="#poly-249d05e8-7c5d-42e1-92fb-765c03124f90"/>
							<gml:surfaceMember xlink:href="#poly-c6d15d43-4b38-47e4-9ba3-a559d606d18a"/>
							<gml:surfaceMember xlink:href="#poly-f8726476-1030-45a0-8909-fcf20073ceae"/>
							<gml:surfaceMember xlink:href="#poly-9bdab5cc-9c9a-4bbb-8141-4b3437be8383"/>
							<gml:surfaceMember xlink:href="#poly-bdf7bfd4-0916-4c78-b6f5-ed39b249468b"/>
							<gml:surfaceMember xlink:href="#poly-28367529-e3d8-40ce-93d2-8c69dffc3c0f"/>
							<gml:surfaceMember xlink:href="#poly-7b6695b2-555b-46e8-854f-b1c25a8799b6"/>
							<gml:surfaceMember xlink:href="#poly-d104a4c1-ad98-4687-af10-8dddacd812fd"/>
							<gml:surfaceMember xlink:href="#poly-4516e517-c1cf-4627-b344-2c16eee670ff"/>
							<gml:surfaceMember xlink:href="#poly-cdc6ffdc-877e-4211-80f6-1838816c499c"/>
							<gml:surfaceMember xlink:href="#poly-03e55c87-40d2-46b5-aec9-91a6de5a970f"/>
							<gml:surfaceMember xlink:href="#poly-c3446983-1abc-42a7-9eed-9f44f323d865"/>
							<gml:surfaceMember xlink:href="#poly-3c492090-ade7-4c3d-a7ad-793b406ecf17"/>
							<gml:surfaceMember xlink:href="#poly-31f3e4de-1b0f-4287-9cd3-fdbe9e7c80df"/>
							<gml:surfaceMember xlink:href="#poly-e470426e-39cc-4013-9ce8-a4d829011516"/>
							<gml:surfaceMember xlink:href="#poly-c555364b-932a-43d9-b8bc-18e41ee2e0bf"/>
							<gml:surfaceMember xlink:href="#poly-0cc1bb31-0e61-4f20-949c-ad05b238eced"/>
							<gml:surfaceMember xlink:href="#poly-15eb8357-0a6f-4e49-886a-d61b502e62ec"/>
							<gml:surfaceMember xlink:href="#poly-d585e5ba-ac53-46e5-a523-b3f74da7fb0d"/>
							<gml:surfaceMember xlink:href="#poly-92ed054d-9df9-43b0-b1d4-95de7ea859c8"/>
							<gml:surfaceMember xlink:href="#poly-4f62b520-4c02-4c9e-9cf0-432f9c33eb9a"/>
							<gml:surfaceMember xlink:href="#poly-e530f6a4-bdf0-4ffd-b5e0-0841bb9504dd"/>
							<gml:surfaceMember xlink:href="#poly-3c9c4ae8-634e-4541-aa35-5ce7ccee204e"/>
							<gml:surfaceMember xlink:href="#poly-ce7145c7-b01f-41c1-acb8-62990c0b09fe"/>
							<gml:surfaceMember xlink:href="#poly-f668c724-d009-4e6f-b29b-bb80dafa39eb"/>
							<gml:surfaceMember xlink:href="#poly-ee6bb205-ad31-46d3-a114-44b6133a4b86"/>
							<gml:surfaceMember xlink:href="#poly-f1cd4630-50af-44b2-89af-04d05cdb01a3"/>
							<gml:surfaceMember xlink:href="#poly-c91ea261-5497-44f8-ae45-6c0b657447a6"/>
							<gml:surfaceMember xlink:href="#poly-256160bc-ff00-482c-bbf7-b67adece3817"/>
							<gml:surfaceMember xlink:href="#poly-40b2471b-7395-43cb-ada6-db965d05abfd"/>
							<gml:surfaceMember xlink:href="#poly-a2ee35a7-bcd1-4497-b3d8-f9c75aebad08"/>
							<gml:surfaceMember xlink:href="#poly-cc7a6e83-cb02-46f6-b323-85400635d2f5"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-997237d4-164d-4c50-b4ed-7a6ff65c3fac">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-997237d4-164d-4c50-b4ed-7a6ff65c3fac">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-997237d4-164d-4c50-b4ed-7a6ff65c3fac">
											<gml:posList>35.671409654772944 139.73977999802202 14.75 35.67137051417561 139.73974135921586 14.75 35.67141714110224 139.7396703979298 14.75 35.67148641073625 139.73973882685203 14.75 35.671393858991216 139.7398796660194 14.75 35.67134063721663 139.73982714723155 14.75 35.67136994232645 139.73978262921787 14.75 35.67139296305399 139.73980540212378 14.75 35.671409654772944 139.73977999802202 14.75</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-4a721132-ee26-480c-b05a-3fc1b4772357">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4a721132-ee26-480c-b05a-3fc1b4772357">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4a721132-ee26-480c-b05a-3fc1b4772357">
											<gml:posList>35.67134063721663 139.73982714723155 22.169 35.67134401701892 139.73982670143405 22.169 35.671370315107254 139.73978677118134 22.169 35.67136994232645 139.73978262921787 22.169 35.67134063721663 139.73982714723155 22.169</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-2ad4677c-7850-4a57-a704-73782fd5c079">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2ad4677c-7850-4a57-a704-73782fd5c079">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2ad4677c-7850-4a57-a704-73782fd5c079">
											<gml:posList>35.671393858991216 139.7398796660194 22.169 35.6713934952359 139.73987553509016 22.169 35.67134401701892 139.73982670143405 22.169 35.67134063721663 139.73982714723155 22.169 35.671393858991216 139.7398796660194 22.169</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-249d05e8-7c5d-42e1-92fb-765c03124f90">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-249d05e8-7c5d-42e1-92fb-765c03124f90">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-249d05e8-7c5d-42e1-92fb-765c03124f90">
											<gml:posList>35.6713934952359 139.73987553509016 22.011 35.67141496762085 139.73984286794246 22.011 35.67138693146249 139.73981519626867 22.011 35.671391558680995 139.7398076793202 22.011 35.671370315107254 139.73978677118134 22.011 35.67134401701892 139.73982670143405 22.011 35.6713934952359 139.73987553509016 22.011</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c6d15d43-4b38-47e4-9ba3-a559d606d18a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c6d15d43-4b38-47e4-9ba3-a559d606d18a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c6d15d43-4b38-47e4-9ba3-a559d606d18a">
											<gml:posList>35.67139296305399 139.73980540212378 22.169 35.67136994232645 139.73978262921787 22.169 35.671370315107254 139.73978677118134 22.169 35.671391558680995 139.7398076793202 22.169 35.67139296305399 139.73980540212378 22.169</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f8726476-1030-45a0-8909-fcf20073ceae">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f8726476-1030-45a0-8909-fcf20073ceae">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f8726476-1030-45a0-8909-fcf20073ceae">
											<gml:posList>35.67139296305399 139.73980540212378 25.404 35.67138693146249 139.73981519626867 25.404 35.67139002279989 139.7398147176677 25.404 35.67139471303719 139.7398071012278 25.404 35.67139296305399 139.73980540212378 25.404</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-9bdab5cc-9c9a-4bbb-8141-4b3437be8383">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9bdab5cc-9c9a-4bbb-8141-4b3437be8383">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9bdab5cc-9c9a-4bbb-8141-4b3437be8383">
											<gml:posList>35.671409654772944 139.73977999802202 25.404 35.67141280023542 139.73977957458837 25.404 35.67137365964657 139.73974094682734 25.404 35.67137051417561 139.73974135921586 25.404 35.671409654772944 139.73977999802202 25.404</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-bdf7bfd4-0916-4c78-b6f5-ed39b249468b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bdf7bfd4-0916-4c78-b6f5-ed39b249468b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bdf7bfd4-0916-4c78-b6f5-ed39b249468b">
											<gml:posList>35.67137051417561 139.73974135921586 25.404 35.67137365964657 139.73974094682734 25.404 35.671417477600045 139.7396742416847 25.404 35.67141714110224 139.7396703979298 25.404 35.67137051417561 139.73974135921586 25.404</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-28367529-e3d8-40ce-93d2-8c69dffc3c0f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-28367529-e3d8-40ce-93d2-8c69dffc3c0f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-28367529-e3d8-40ce-93d2-8c69dffc3c0f">
											<gml:posList>35.67141683489338 139.7398447105142 25.404 35.67141649839244 139.73984085571226 25.404 35.67139002279989 139.7398147176677 25.404 35.67138693146249 139.73981519626867 25.404 35.67141683489338 139.7398447105142 25.404</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-7b6695b2-555b-46e8-854f-b1c25a8799b6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7b6695b2-555b-46e8-854f-b1c25a8799b6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7b6695b2-555b-46e8-854f-b1c25a8799b6">
											<gml:posList>35.671409654772944 139.73977999802202 25.404 35.67139296305399 139.73980540212378 25.404 35.67139471303719 139.7398071012278 25.404 35.67141280023542 139.73977957458837 25.404 35.671409654772944 139.73977999802202 25.404</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d104a4c1-ad98-4687-af10-8dddacd812fd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d104a4c1-ad98-4687-af10-8dddacd812fd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d104a4c1-ad98-4687-af10-8dddacd812fd">
											<gml:posList>35.67141683489338 139.7398447105142 22.169 35.67141496762085 139.73984286794246 22.169 35.6713934952359 139.73987553509016 22.169 35.671393858991216 139.7398796660194 22.169 35.67141683489338 139.7398447105142 22.169</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-4516e517-c1cf-4627-b344-2c16eee670ff">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4516e517-c1cf-4627-b344-2c16eee670ff">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4516e517-c1cf-4627-b344-2c16eee670ff">
											<gml:posList>35.67139002279989 139.7398147176677 25.029 35.67141649839244 139.73984085571226 25.029 35.671483274279076 139.73973923923072 25.029 35.671417477600045 139.7396742416847 25.029 35.67137365964657 139.73974094682734 25.029 35.67141280023542 139.73977957458837 25.029 35.67139471303719 139.7398071012278 25.029 35.67139002279989 139.7398147176677 25.029</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-cdc6ffdc-877e-4211-80f6-1838816c499c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cdc6ffdc-877e-4211-80f6-1838816c499c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cdc6ffdc-877e-4211-80f6-1838816c499c">
											<gml:posList>35.67148641073625 139.73973882685203 25.404 35.671483274279076 139.73973923923072 25.404 35.67141649839244 139.73984085571226 25.404 35.67141683489338 139.7398447105142 25.404 35.67148641073625 139.73973882685203 25.404</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-03e55c87-40d2-46b5-aec9-91a6de5a970f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-03e55c87-40d2-46b5-aec9-91a6de5a970f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-03e55c87-40d2-46b5-aec9-91a6de5a970f">
											<gml:posList>35.67141714110224 139.7396703979298 25.404 35.671417477600045 139.7396742416847 25.404 35.671483274279076 139.73973923923072 25.404 35.67148641073625 139.73973882685203 25.404 35.67141714110224 139.7396703979298 25.404</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c3446983-1abc-42a7-9eed-9f44f323d865">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c3446983-1abc-42a7-9eed-9f44f323d865">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c3446983-1abc-42a7-9eed-9f44f323d865">
											<gml:posList>35.67139002279989 139.7398147176677 25.404 35.67139002279989 139.7398147176677 25.029 35.67139471303719 139.7398071012278 25.029 35.67139471303719 139.7398071012278 25.404 35.67139002279989 139.7398147176677 25.404</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3c492090-ade7-4c3d-a7ad-793b406ecf17">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3c492090-ade7-4c3d-a7ad-793b406ecf17">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3c492090-ade7-4c3d-a7ad-793b406ecf17">
											<gml:posList>35.67137365964657 139.73974094682734 25.404 35.67137365964657 139.73974094682734 25.029 35.671417477600045 139.7396742416847 25.029 35.671417477600045 139.7396742416847 25.404 35.67137365964657 139.73974094682734 25.404</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-31f3e4de-1b0f-4287-9cd3-fdbe9e7c80df">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-31f3e4de-1b0f-4287-9cd3-fdbe9e7c80df">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-31f3e4de-1b0f-4287-9cd3-fdbe9e7c80df">
											<gml:posList>35.67139471303719 139.7398071012278 25.404 35.67139471303719 139.7398071012278 25.029 35.67141280023542 139.73977957458837 25.029 35.67141280023542 139.73977957458837 25.404 35.67139471303719 139.7398071012278 25.404</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e470426e-39cc-4013-9ce8-a4d829011516">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e470426e-39cc-4013-9ce8-a4d829011516">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e470426e-39cc-4013-9ce8-a4d829011516">
											<gml:posList>35.67148641073625 139.73973882685203 14.75 35.67141714110224 139.7396703979298 14.75 35.67141714110224 139.7396703979298 25.404 35.67148641073625 139.73973882685203 25.404 35.67148641073625 139.73973882685203 14.75</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c555364b-932a-43d9-b8bc-18e41ee2e0bf">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c555364b-932a-43d9-b8bc-18e41ee2e0bf">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c555364b-932a-43d9-b8bc-18e41ee2e0bf">
											<gml:posList>35.67141714110224 139.7396703979298 14.75 35.67137051417561 139.73974135921586 14.75 35.67137051417561 139.73974135921586 25.404 35.67141714110224 139.7396703979298 25.404 35.67141714110224 139.7396703979298 14.75</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0cc1bb31-0e61-4f20-949c-ad05b238eced">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0cc1bb31-0e61-4f20-949c-ad05b238eced">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0cc1bb31-0e61-4f20-949c-ad05b238eced">
											<gml:posList>35.671417477600045 139.7396742416847 25.404 35.671417477600045 139.7396742416847 25.029 35.671483274279076 139.73973923923072 25.029 35.671483274279076 139.73973923923072 25.404 35.671417477600045 139.7396742416847 25.404</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-15eb8357-0a6f-4e49-886a-d61b502e62ec">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-15eb8357-0a6f-4e49-886a-d61b502e62ec">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-15eb8357-0a6f-4e49-886a-d61b502e62ec">
											<gml:posList>35.67141280023542 139.73977957458837 25.404 35.67141280023542 139.73977957458837 25.029 35.67137365964657 139.73974094682734 25.029 35.67137365964657 139.73974094682734 25.404 35.67141280023542 139.73977957458837 25.404</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d585e5ba-ac53-46e5-a523-b3f74da7fb0d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d585e5ba-ac53-46e5-a523-b3f74da7fb0d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d585e5ba-ac53-46e5-a523-b3f74da7fb0d">
											<gml:posList>35.67137051417561 139.73974135921586 14.75 35.671409654772944 139.73977999802202 14.75 35.671409654772944 139.73977999802202 25.404 35.67137051417561 139.73974135921586 25.404 35.67137051417561 139.73974135921586 14.75</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-92ed054d-9df9-43b0-b1d4-95de7ea859c8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-92ed054d-9df9-43b0-b1d4-95de7ea859c8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-92ed054d-9df9-43b0-b1d4-95de7ea859c8">
											<gml:posList>35.671483274279076 139.73973923923072 25.404 35.671483274279076 139.73973923923072 25.029 35.67141649839244 139.73984085571226 25.029 35.67141649839244 139.73984085571226 25.404 35.671483274279076 139.73973923923072 25.404</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4f62b520-4c02-4c9e-9cf0-432f9c33eb9a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4f62b520-4c02-4c9e-9cf0-432f9c33eb9a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4f62b520-4c02-4c9e-9cf0-432f9c33eb9a">
											<gml:posList>35.671409654772944 139.73977999802202 25.404 35.671409654772944 139.73977999802202 14.75 35.67139296305399 139.73980540212378 14.75 35.67139296305399 139.73980540212378 22.169 35.67139296305399 139.73980540212378 25.404 35.671409654772944 139.73977999802202 25.404</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e530f6a4-bdf0-4ffd-b5e0-0841bb9504dd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e530f6a4-bdf0-4ffd-b5e0-0841bb9504dd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e530f6a4-bdf0-4ffd-b5e0-0841bb9504dd">
											<gml:posList>35.67139296305399 139.73980540212378 14.75 35.67136994232645 139.73978262921787 14.75 35.67136994232645 139.73978262921787 22.169 35.67139296305399 139.73980540212378 22.169 35.67139296305399 139.73980540212378 14.75</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3c9c4ae8-634e-4541-aa35-5ce7ccee204e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3c9c4ae8-634e-4541-aa35-5ce7ccee204e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3c9c4ae8-634e-4541-aa35-5ce7ccee204e">
											<gml:posList>35.671370315107254 139.73978677118134 22.169 35.671370315107254 139.73978677118134 22.011 35.671391558680995 139.7398076793202 22.011 35.671391558680995 139.7398076793202 22.169 35.671370315107254 139.73978677118134 22.169</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ce7145c7-b01f-41c1-acb8-62990c0b09fe">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ce7145c7-b01f-41c1-acb8-62990c0b09fe">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ce7145c7-b01f-41c1-acb8-62990c0b09fe">
											<gml:posList>35.67136994232645 139.73978262921787 14.75 35.67134063721663 139.73982714723155 14.75 35.67134063721663 139.73982714723155 22.169 35.67136994232645 139.73978262921787 22.169 35.67136994232645 139.73978262921787 14.75</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f668c724-d009-4e6f-b29b-bb80dafa39eb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f668c724-d009-4e6f-b29b-bb80dafa39eb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f668c724-d009-4e6f-b29b-bb80dafa39eb">
											<gml:posList>35.67134401701892 139.73982670143405 22.169 35.67134401701892 139.73982670143405 22.011 35.671370315107254 139.73978677118134 22.011 35.671370315107254 139.73978677118134 22.169 35.67134401701892 139.73982670143405 22.169</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ee6bb205-ad31-46d3-a114-44b6133a4b86">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ee6bb205-ad31-46d3-a114-44b6133a4b86">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ee6bb205-ad31-46d3-a114-44b6133a4b86">
											<gml:posList>35.67148641073625 139.73973882685203 14.75 35.67148641073625 139.73973882685203 25.404 35.67141683489338 139.7398447105142 25.404 35.67141683489338 139.7398447105142 22.169 35.671393858991216 139.7398796660194 22.169 35.671393858991216 139.7398796660194 14.75 35.67148641073625 139.73973882685203 14.75</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f1cd4630-50af-44b2-89af-04d05cdb01a3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f1cd4630-50af-44b2-89af-04d05cdb01a3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f1cd4630-50af-44b2-89af-04d05cdb01a3">
											<gml:posList>35.67138693146249 139.73981519626867 22.011 35.67138693146249 139.73981519626867 25.404 35.67139296305399 139.73980540212378 25.404 35.67139296305399 139.73980540212378 22.169 35.671391558680995 139.7398076793202 22.169 35.671391558680995 139.7398076793202 22.011 35.67138693146249 139.73981519626867 22.011</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c91ea261-5497-44f8-ae45-6c0b657447a6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c91ea261-5497-44f8-ae45-6c0b657447a6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c91ea261-5497-44f8-ae45-6c0b657447a6">
											<gml:posList>35.67141649839244 139.73984085571226 25.404 35.67141649839244 139.73984085571226 25.029 35.67139002279989 139.7398147176677 25.029 35.67139002279989 139.7398147176677 25.404 35.67141649839244 139.73984085571226 25.404</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-256160bc-ff00-482c-bbf7-b67adece3817">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-256160bc-ff00-482c-bbf7-b67adece3817">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-256160bc-ff00-482c-bbf7-b67adece3817">
											<gml:posList>35.67141683489338 139.7398447105142 25.404 35.67138693146249 139.73981519626867 25.404 35.67138693146249 139.73981519626867 22.011 35.67141496762085 139.73984286794246 22.011 35.67141496762085 139.73984286794246 22.169 35.67141683489338 139.7398447105142 22.169 35.67141683489338 139.7398447105142 25.404</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-40b2471b-7395-43cb-ada6-db965d05abfd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-40b2471b-7395-43cb-ada6-db965d05abfd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-40b2471b-7395-43cb-ada6-db965d05abfd">
											<gml:posList>35.6713934952359 139.73987553509016 22.169 35.6713934952359 139.73987553509016 22.011 35.67134401701892 139.73982670143405 22.011 35.67134401701892 139.73982670143405 22.169 35.6713934952359 139.73987553509016 22.169</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a2ee35a7-bcd1-4497-b3d8-f9c75aebad08">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a2ee35a7-bcd1-4497-b3d8-f9c75aebad08">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a2ee35a7-bcd1-4497-b3d8-f9c75aebad08">
											<gml:posList>35.67134063721663 139.73982714723155 14.75 35.671393858991216 139.7398796660194 14.75 35.671393858991216 139.7398796660194 22.169 35.67134063721663 139.73982714723155 22.169 35.67134063721663 139.73982714723155 14.75</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-cc7a6e83-cb02-46f6-b323-85400635d2f5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cc7a6e83-cb02-46f6-b323-85400635d2f5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cc7a6e83-cb02-46f6-b323-85400635d2f5">
											<gml:posList>35.67141496762085 139.73984286794246 22.169 35.67141496762085 139.73984286794246 22.011 35.6713934952359 139.73987553509016 22.011 35.6713934952359 139.73987553509016 22.169 35.67141496762085 139.73984286794246 22.169</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-1813</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">110.8958</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1002</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">211</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1310</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>6</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.02</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">12</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>