<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_df81564f-aa1c-436d-b92f-256821d388c4">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="地区計画">
				<gen:value>赤坂二・六丁目地区</gen:value>
			</gen:stringAttribute>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.672045366659034 139.73751125743837 0 35.67196480332014 139.73754695652414 0 35.6719738414033 139.73757757761138 0 35.67205439574625 139.73754188960953 0 35.672045366659034 139.73751125743837 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672045366659034 139.73751125743837 9.67 35.67205439574625 139.73754188960953 9.67 35.6719738414033 139.73757757761138 9.67 35.67196480332014 139.73754695652414 9.67 35.672045366659034 139.73751125743837 9.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672045366659034 139.73751125743837 9.67 35.67196480332014 139.73754695652414 9.67 35.67196480332014 139.73754695652414 12.67 35.672045366659034 139.73751125743837 12.67 35.672045366659034 139.73751125743837 9.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67196480332014 139.73754695652414 9.67 35.6719738414033 139.73757757761138 9.67 35.6719738414033 139.73757757761138 12.67 35.67196480332014 139.73754695652414 12.67 35.67196480332014 139.73754695652414 9.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6719738414033 139.73757757761138 9.67 35.67205439574625 139.73754188960953 9.67 35.67205439574625 139.73754188960953 12.67 35.6719738414033 139.73757757761138 12.67 35.6719738414033 139.73757757761138 9.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67205439574625 139.73754188960953 9.67 35.672045366659034 139.73751125743837 9.67 35.672045366659034 139.73751125743837 12.67 35.67205439574625 139.73754188960953 12.67 35.67205439574625 139.73754188960953 9.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672045366659034 139.73751125743837 12.67 35.67196480332014 139.73754695652414 12.67 35.6719738414033 139.73757757761138 12.67 35.67205439574625 139.73754188960953 12.67 35.672045366659034 139.73751125743837 12.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-21acc1f0-4643-4bd2-a614-f3ecb5fcfcf9"/>
							<gml:surfaceMember xlink:href="#poly-70b2b88b-e705-4a29-b210-0f9ef7bdd70b"/>
							<gml:surfaceMember xlink:href="#poly-43dc44d9-ef50-44fe-98aa-90ac1b9c1c04"/>
							<gml:surfaceMember xlink:href="#poly-1bb2000e-9ccc-4ace-a3ad-fdcfefd1b8b5"/>
							<gml:surfaceMember xlink:href="#poly-8655f240-fa22-4b5e-b9e3-e3e69f4ed21d"/>
							<gml:surfaceMember xlink:href="#poly-3ffc1e16-0dba-4e4b-8005-c2e887111b02"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-21acc1f0-4643-4bd2-a614-f3ecb5fcfcf9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-21acc1f0-4643-4bd2-a614-f3ecb5fcfcf9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-21acc1f0-4643-4bd2-a614-f3ecb5fcfcf9">
											<gml:posList>35.672045366659006 139.73751125743834 9.67 35.67205439574625 139.73754188960956 9.67 35.67197384140331 139.73757757761138 9.67 35.67196480332013 139.73754695652414 9.67 35.672045366659006 139.73751125743834 9.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-70b2b88b-e705-4a29-b210-0f9ef7bdd70b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-70b2b88b-e705-4a29-b210-0f9ef7bdd70b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-70b2b88b-e705-4a29-b210-0f9ef7bdd70b">
											<gml:posList>35.67196480332013 139.73754695652414 12.826 35.67197384140331 139.73757757761138 12.826 35.67205439574625 139.73754188960956 12.826 35.672045366659006 139.73751125743834 12.826 35.67196480332013 139.73754695652414 12.826</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-43dc44d9-ef50-44fe-98aa-90ac1b9c1c04">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-43dc44d9-ef50-44fe-98aa-90ac1b9c1c04">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-43dc44d9-ef50-44fe-98aa-90ac1b9c1c04">
											<gml:posList>35.672045366659006 139.73751125743834 12.826 35.672045366659006 139.73751125743834 9.67 35.67196480332013 139.73754695652414 9.67 35.67196480332013 139.73754695652414 12.826 35.672045366659006 139.73751125743834 12.826</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1bb2000e-9ccc-4ace-a3ad-fdcfefd1b8b5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1bb2000e-9ccc-4ace-a3ad-fdcfefd1b8b5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1bb2000e-9ccc-4ace-a3ad-fdcfefd1b8b5">
											<gml:posList>35.67205439574625 139.73754188960956 12.826 35.67205439574625 139.73754188960956 9.67 35.672045366659006 139.73751125743834 9.67 35.672045366659006 139.73751125743834 12.826 35.67205439574625 139.73754188960956 12.826</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8655f240-fa22-4b5e-b9e3-e3e69f4ed21d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8655f240-fa22-4b5e-b9e3-e3e69f4ed21d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8655f240-fa22-4b5e-b9e3-e3e69f4ed21d">
											<gml:posList>35.67197384140331 139.73757757761138 12.826 35.67197384140331 139.73757757761138 9.67 35.67205439574625 139.73754188960956 9.67 35.67205439574625 139.73754188960956 12.826 35.67197384140331 139.73757757761138 12.826</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3ffc1e16-0dba-4e4b-8005-c2e887111b02">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3ffc1e16-0dba-4e4b-8005-c2e887111b02">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3ffc1e16-0dba-4e4b-8005-c2e887111b02">
											<gml:posList>35.67196480332013 139.73754695652414 12.826 35.67196480332013 139.73754695652414 9.67 35.67197384140331 139.73757757761138 9.67 35.67197384140331 139.73757757761138 12.826 35.67196480332013 139.73754695652414 12.826</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-5954</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">215</uro:landUseType>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>5</uro:specifiedFloorAreaRate>
					<uro:surveyYear>0001</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">0</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>