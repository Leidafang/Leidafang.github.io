<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_e06830c7-6324-4ef6-ae8e-74a7da49be31">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">412</bldg:usage>
			<bldg:measuredHeight uom="m">32.4</bldg:measuredHeight>
			<bldg:storeysAboveGround>11</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.67116264298127 139.7385931442236 0 35.67113748978068 139.73847243719223 0 35.67106350549006 139.7384958325336 0 35.67106857205091 139.7385197971289 0 35.671053793114304 139.73852434361044 0 35.67107378941611 139.73862086510547 0 35.67116264298127 139.7385931442236 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67116264298127 139.7385931442236 16.144 35.67107378941611 139.73862086510547 16.144 35.671053793114304 139.73852434361044 16.144 35.67106857205091 139.7385197971289 16.144 35.67106350549006 139.7384958325336 16.144 35.67113748978068 139.73847243719223 16.144 35.67116264298127 139.7385931442236 16.144</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67116264298127 139.7385931442236 16.144 35.67113748978068 139.73847243719223 16.144 35.67113748978068 139.73847243719223 48.59 35.67116264298127 139.7385931442236 48.59 35.67116264298127 139.7385931442236 16.144</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67113748978068 139.73847243719223 16.144 35.67106350549006 139.7384958325336 16.144 35.67106350549006 139.7384958325336 48.59 35.67113748978068 139.73847243719223 48.59 35.67113748978068 139.73847243719223 16.144</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67106350549006 139.7384958325336 16.144 35.67106857205091 139.7385197971289 16.144 35.67106857205091 139.7385197971289 48.59 35.67106350549006 139.7384958325336 48.59 35.67106350549006 139.7384958325336 16.144</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67106857205091 139.7385197971289 16.144 35.671053793114304 139.73852434361044 16.144 35.671053793114304 139.73852434361044 48.59 35.67106857205091 139.7385197971289 48.59 35.67106857205091 139.7385197971289 16.144</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671053793114304 139.73852434361044 16.144 35.67107378941611 139.73862086510547 16.144 35.67107378941611 139.73862086510547 48.59 35.671053793114304 139.73852434361044 48.59 35.671053793114304 139.73852434361044 16.144</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67107378941611 139.73862086510547 16.144 35.67116264298127 139.7385931442236 16.144 35.67116264298127 139.7385931442236 48.59 35.67107378941611 139.73862086510547 48.59 35.67107378941611 139.73862086510547 16.144</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67116264298127 139.7385931442236 48.59 35.67113748978068 139.73847243719223 48.59 35.67106350549006 139.7384958325336 48.59 35.67106857205091 139.7385197971289 48.59 35.671053793114304 139.73852434361044 48.59 35.67107378941611 139.73862086510547 48.59 35.67116264298127 139.7385931442236 48.59</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-8b582461-d50e-4237-976d-eef4a1c95157"/>
							<gml:surfaceMember xlink:href="#poly-3f5678bb-817c-43ac-b9e3-12910ed1e58b"/>
							<gml:surfaceMember xlink:href="#poly-f067810e-544e-407f-935e-0a29381f719e"/>
							<gml:surfaceMember xlink:href="#poly-2a5871b4-5f7d-4b06-8ff5-0c16d2ca8d48"/>
							<gml:surfaceMember xlink:href="#poly-c2e330f2-3c6f-47ff-bd09-b222f9410925"/>
							<gml:surfaceMember xlink:href="#poly-ba718b63-bdcf-4045-8cfb-3c6c8a6df314"/>
							<gml:surfaceMember xlink:href="#poly-a32c2d96-76b6-4868-a3f9-7a613bd67c3c"/>
							<gml:surfaceMember xlink:href="#poly-232cfac9-b09c-4995-aa0c-13f4b75dd312"/>
							<gml:surfaceMember xlink:href="#poly-9b6656ee-556d-4a4e-a885-ee5c5a2e9c5e"/>
							<gml:surfaceMember xlink:href="#poly-787b6ad8-c84b-4377-8363-250c1790205f"/>
							<gml:surfaceMember xlink:href="#poly-090bb90a-5dd4-422d-9700-27d59983e8f5"/>
							<gml:surfaceMember xlink:href="#poly-6af1c254-71ae-46d9-beb0-e761c9fcfb2a"/>
							<gml:surfaceMember xlink:href="#poly-7f7b018b-1f9f-4b3c-b5da-72722d151702"/>
							<gml:surfaceMember xlink:href="#poly-2a749713-a566-4041-bdf5-91edae39362d"/>
							<gml:surfaceMember xlink:href="#poly-b6c716bb-c5ad-4980-8ad5-647c2126191b"/>
							<gml:surfaceMember xlink:href="#poly-28acf131-edeb-4c4b-b1ce-9fe9247a4183"/>
							<gml:surfaceMember xlink:href="#poly-5663da21-87a7-4039-82cc-2ee278d10f19"/>
							<gml:surfaceMember xlink:href="#poly-1306e36f-b4cd-4436-8c67-865aa4f43945"/>
							<gml:surfaceMember xlink:href="#poly-731b87b6-6ae0-4958-bfc7-10d185b32c16"/>
							<gml:surfaceMember xlink:href="#poly-d1a4d0b8-bc34-45e0-bd51-aab13deb7e1c"/>
							<gml:surfaceMember xlink:href="#poly-7684fc95-a168-47d6-9bc3-62599d083bd6"/>
							<gml:surfaceMember xlink:href="#poly-ef22e22e-437a-4109-bdfa-5586db79dc90"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_e06830c7-6324-4ef6-ae8e-74a7da49be31_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e0b1c0a4-53ba-4dff-85e6-36cfcdc96c42">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67110804486146 139.73848760554307 49.183 35.67107103469643 139.73849931427551 49.183 35.67107000277346 139.7384937812726 49.183 35.67110722921506 139.73848200600372 49.183 35.67110804486146 139.73848760554307 49.183</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9ec2d954-1204-4c31-9cd6-a27c08c13adb">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67107309850681 139.7385103360964 48.963 35.67107103469643 139.73849931427551 48.963 35.67110804486146 139.73848760554307 48.963 35.67111012936248 139.73850200753031 48.963 35.67107309850681 139.7385103360964 48.963</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-adadbefd-492a-4cb1-9788-936e94a03959">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-adadbefd-492a-4cb1-9788-936e94a03959_0">
											<gml:posList>35.67107103469643 139.73849931427551 49.183 35.67110804486146 139.73848760554307 49.183 35.67110804486146 139.73848760554307 48.963 35.67107103469643 139.73849931427551 48.963 35.67107103469643 139.73849931427551 49.183</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-17011844-346b-4a96-a493-1a2dac29fe80">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-17011844-346b-4a96-a493-1a2dac29fe80_0">
											<gml:posList>35.67107000277346 139.7384937812726 49.183 35.67107000277346 139.7384937812726 50.128 35.67110722921506 139.73848200600372 50.128 35.67110722921506 139.73848200600372 49.183 35.67107000277346 139.7384937812726 49.183</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-685b37f5-1dd8-417d-aafb-69be868e4d88">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-685b37f5-1dd8-417d-aafb-69be868e4d88_0">
											<gml:posList>35.67110804486146 139.73848760554307 49.183 35.67110722921506 139.73848200600372 49.183 35.67110722921506 139.73848200600372 50.128 35.67111012936248 139.73850200753031 50.128 35.67111012936248 139.73850200753031 48.963 35.67110804486146 139.73848760554307 48.963 35.67110804486146 139.73848760554307 49.183</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b9ca4a07-4dda-4907-acd6-49501d99644b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b9ca4a07-4dda-4907-acd6-49501d99644b_0">
											<gml:posList>35.67107309850681 139.7385103360964 50.128 35.67111012936248 139.73850200753031 50.128 35.67110722921506 139.73848200600372 50.128 35.67107000277346 139.7384937812726 50.128 35.67107309850681 139.7385103360964 50.128</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ba0e8b86-c37d-486a-ae00-3ef60009079c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ba0e8b86-c37d-486a-ae00-3ef60009079c_0">
											<gml:posList>35.67107309850681 139.7385103360964 48.963 35.67107309850681 139.7385103360964 50.128 35.67107000277346 139.7384937812726 50.128 35.67107000277346 139.7384937812726 49.183 35.67107103469643 139.73849931427551 49.183 35.67107103469643 139.73849931427551 48.963 35.67107309850681 139.7385103360964 48.963</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e45a0a5b-d8bb-4dc2-a15b-890f61da7a62">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e45a0a5b-d8bb-4dc2-a15b-890f61da7a62_0">
											<gml:posList>35.67111012936248 139.73850200753031 48.963 35.67111012936248 139.73850200753031 50.128 35.67107309850681 139.7385103360964 50.128 35.67107309850681 139.7385103360964 48.963 35.67111012936248 139.73850200753031 48.963</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-8b582461-d50e-4237-976d-eef4a1c95157">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8b582461-d50e-4237-976d-eef4a1c95157">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8b582461-d50e-4237-976d-eef4a1c95157">
											<gml:posList>35.67116264298126 139.7385931442236 16.144 35.671073789416084 139.73862086510547 16.144 35.67105379311427 139.7385243436104 16.144 35.67106857205091 139.7385197971289 16.144 35.67106350549006 139.7384958325336 16.144 35.671137489780676 139.73847243719223 16.144 35.67116264298126 139.7385931442236 16.144</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-3f5678bb-817c-43ac-b9e3-12910ed1e58b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3f5678bb-817c-43ac-b9e3-12910ed1e58b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3f5678bb-817c-43ac-b9e3-12910ed1e58b">
											<gml:posList>35.67106785385568 139.73859219578227 49.183 35.671071273932974 139.7385856633454 49.183 35.671059420929105 139.73852846829138 49.183 35.67105379311427 139.7385243436104 49.183 35.67106785385568 139.73859219578227 49.183</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f067810e-544e-407f-935e-0a29381f719e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f067810e-544e-407f-935e-0a29381f719e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f067810e-544e-407f-935e-0a29381f719e">
											<gml:posList>35.67106857205091 139.7385197971289 49.183 35.67105379311427 139.7385243436104 49.183 35.671059420929105 139.73852846829138 49.183 35.671074226907045 139.7385239217783 49.183 35.67106857205091 139.7385197971289 49.183</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-2a5871b4-5f7d-4b06-8ff5-0c16d2ca8d48">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2a5871b4-5f7d-4b06-8ff5-0c16d2ca8d48">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2a5871b4-5f7d-4b06-8ff5-0c16d2ca8d48">
											<gml:posList>35.67106857205091 139.7385197971289 49.183 35.671074226907045 139.7385239217783 49.183 35.671069142284786 139.73849991301702 49.183 35.67106350549006 139.7384958325336 49.183 35.67106857205091 139.7385197971289 49.183</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c2e330f2-3c6f-47ff-bd09-b222f9410925">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c2e330f2-3c6f-47ff-bd09-b222f9410925">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c2e330f2-3c6f-47ff-bd09-b222f9410925">
											<gml:posList>35.67106350549006 139.7384958325336 49.183 35.671069142284786 139.73849991301702 49.183 35.671134142123904 139.73847935617638 49.183 35.671137489780676 139.73847243719223 49.183 35.67106350549006 139.7384958325336 49.183</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ba718b63-bdcf-4045-8cfb-3c6c8a6df314">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ba718b63-bdcf-4045-8cfb-3c6c8a6df314">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ba718b63-bdcf-4045-8cfb-3c6c8a6df314">
											<gml:posList>35.671071273932974 139.7385856633454 48.963 35.671152509385 139.7385674844443 48.963 35.671134142123904 139.73847935617638 48.963 35.671069142284786 139.73849991301702 48.963 35.671074226907045 139.7385239217783 48.963 35.671059420929105 139.73852846829138 48.963 35.671071273932974 139.7385856633454 48.963</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a32c2d96-76b6-4868-a3f9-7a613bd67c3c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a32c2d96-76b6-4868-a3f9-7a613bd67c3c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a32c2d96-76b6-4868-a3f9-7a613bd67c3c">
											<gml:posList>35.67106785385568 139.73859219578227 49.183 35.67115823663608 139.7385719735459 49.183 35.671152509385 139.7385674844443 49.183 35.671071273932974 139.7385856633454 49.183 35.67106785385568 139.73859219578227 49.183</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-232cfac9-b09c-4995-aa0c-13f4b75dd312">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-232cfac9-b09c-4995-aa0c-13f4b75dd312">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-232cfac9-b09c-4995-aa0c-13f4b75dd312">
											<gml:posList>35.67115823663608 139.7385719735459 46.979 35.67106785385568 139.73859219578227 46.979 35.671073789416084 139.73862086510547 46.979 35.67116264298126 139.7385931442236 46.979 35.67115823663608 139.7385719735459 46.979</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-9b6656ee-556d-4a4e-a885-ee5c5a2e9c5e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9b6656ee-556d-4a4e-a885-ee5c5a2e9c5e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9b6656ee-556d-4a4e-a885-ee5c5a2e9c5e">
											<gml:posList>35.671137489780676 139.73847243719223 49.183 35.671134142123904 139.73847935617638 49.183 35.671152509385 139.7385674844443 49.183 35.67115823663608 139.7385719735459 49.183 35.671137489780676 139.73847243719223 49.183</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-787b6ad8-c84b-4377-8363-250c1790205f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-787b6ad8-c84b-4377-8363-250c1790205f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-787b6ad8-c84b-4377-8363-250c1790205f">
											<gml:posList>35.67106857205091 139.7385197971289 16.144 35.67105379311427 139.7385243436104 16.144 35.67105379311427 139.7385243436104 49.183 35.67106857205091 139.7385197971289 49.183 35.67106857205091 139.7385197971289 16.144</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-090bb90a-5dd4-422d-9700-27d59983e8f5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-090bb90a-5dd4-422d-9700-27d59983e8f5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-090bb90a-5dd4-422d-9700-27d59983e8f5">
											<gml:posList>35.67106785385568 139.73859219578227 46.979 35.67106785385568 139.73859219578227 49.183 35.67105379311427 139.7385243436104 49.183 35.67105379311427 139.7385243436104 16.144 35.671073789416084 139.73862086510547 16.144 35.671073789416084 139.73862086510547 46.979 35.67106785385568 139.73859219578227 46.979</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6af1c254-71ae-46d9-beb0-e761c9fcfb2a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6af1c254-71ae-46d9-beb0-e761c9fcfb2a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6af1c254-71ae-46d9-beb0-e761c9fcfb2a">
											<gml:posList>35.671071273932974 139.7385856633454 49.183 35.671071273932974 139.7385856633454 48.963 35.671059420929105 139.73852846829138 48.963 35.671059420929105 139.73852846829138 49.183 35.671071273932974 139.7385856633454 49.183</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7f7b018b-1f9f-4b3c-b5da-72722d151702">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7f7b018b-1f9f-4b3c-b5da-72722d151702">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7f7b018b-1f9f-4b3c-b5da-72722d151702">
											<gml:posList>35.67106350549006 139.7384958325336 16.144 35.67106857205091 139.7385197971289 16.144 35.67106857205091 139.7385197971289 49.183 35.67106350549006 139.7384958325336 49.183 35.67106350549006 139.7384958325336 16.144</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2a749713-a566-4041-bdf5-91edae39362d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2a749713-a566-4041-bdf5-91edae39362d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2a749713-a566-4041-bdf5-91edae39362d">
											<gml:posList>35.671059420929105 139.73852846829138 49.183 35.671059420929105 139.73852846829138 48.963 35.671074226907045 139.7385239217783 48.963 35.671074226907045 139.7385239217783 49.183 35.671059420929105 139.73852846829138 49.183</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b6c716bb-c5ad-4980-8ad5-647c2126191b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b6c716bb-c5ad-4980-8ad5-647c2126191b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b6c716bb-c5ad-4980-8ad5-647c2126191b">
											<gml:posList>35.671074226907045 139.7385239217783 49.183 35.671074226907045 139.7385239217783 48.963 35.671069142284786 139.73849991301702 48.963 35.671069142284786 139.73849991301702 49.183 35.671074226907045 139.7385239217783 49.183</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-28acf131-edeb-4c4b-b1ce-9fe9247a4183">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-28acf131-edeb-4c4b-b1ce-9fe9247a4183">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-28acf131-edeb-4c4b-b1ce-9fe9247a4183">
											<gml:posList>35.671137489780676 139.73847243719223 16.144 35.67106350549006 139.7384958325336 16.144 35.67106350549006 139.7384958325336 49.183 35.671137489780676 139.73847243719223 49.183 35.671137489780676 139.73847243719223 16.144</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5663da21-87a7-4039-82cc-2ee278d10f19">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5663da21-87a7-4039-82cc-2ee278d10f19">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5663da21-87a7-4039-82cc-2ee278d10f19">
											<gml:posList>35.671069142284786 139.73849991301702 49.183 35.671069142284786 139.73849991301702 48.963 35.671134142123904 139.73847935617638 48.963 35.671134142123904 139.73847935617638 49.183 35.671069142284786 139.73849991301702 49.183</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1306e36f-b4cd-4436-8c67-865aa4f43945">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1306e36f-b4cd-4436-8c67-865aa4f43945">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1306e36f-b4cd-4436-8c67-865aa4f43945">
											<gml:posList>35.671152509385 139.7385674844443 49.183 35.671152509385 139.7385674844443 48.963 35.671071273932974 139.7385856633454 48.963 35.671071273932974 139.7385856633454 49.183 35.671152509385 139.7385674844443 49.183</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-731b87b6-6ae0-4958-bfc7-10d185b32c16">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-731b87b6-6ae0-4958-bfc7-10d185b32c16">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-731b87b6-6ae0-4958-bfc7-10d185b32c16">
											<gml:posList>35.67115823663608 139.7385719735459 46.979 35.67115823663608 139.7385719735459 49.183 35.67106785385568 139.73859219578227 49.183 35.67106785385568 139.73859219578227 46.979 35.67115823663608 139.7385719735459 46.979</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d1a4d0b8-bc34-45e0-bd51-aab13deb7e1c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d1a4d0b8-bc34-45e0-bd51-aab13deb7e1c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d1a4d0b8-bc34-45e0-bd51-aab13deb7e1c">
											<gml:posList>35.671073789416084 139.73862086510547 16.144 35.67116264298126 139.7385931442236 16.144 35.67116264298126 139.7385931442236 46.979 35.671073789416084 139.73862086510547 46.979 35.671073789416084 139.73862086510547 16.144</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7684fc95-a168-47d6-9bc3-62599d083bd6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7684fc95-a168-47d6-9bc3-62599d083bd6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7684fc95-a168-47d6-9bc3-62599d083bd6">
											<gml:posList>35.671134142123904 139.73847935617638 49.183 35.671134142123904 139.73847935617638 48.963 35.671152509385 139.7385674844443 48.963 35.671152509385 139.7385674844443 49.183 35.671134142123904 139.73847935617638 49.183</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ef22e22e-437a-4109-bdfa-5586db79dc90">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ef22e22e-437a-4109-bdfa-5586db79dc90">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ef22e22e-437a-4109-bdfa-5586db79dc90">
											<gml:posList>35.67116264298126 139.7385931442236 16.144 35.671137489780676 139.73847243719223 16.144 35.671137489780676 139.73847243719223 49.183 35.67115823663608 139.7385719735459 49.183 35.67115823663608 139.7385719735459 46.979 35.67116264298126 139.7385931442236 46.979 35.67116264298126 139.7385931442236 16.144</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-8770</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">110.69695</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">211</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1320</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>4</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.05</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>