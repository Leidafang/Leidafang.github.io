<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_e0efd6ce-ac9c-4726-8185-50e3ac0bdd50">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">401</bldg:usage>
			<bldg:measuredHeight uom="m">11</bldg:measuredHeight>
			<bldg:storeysAboveGround>3</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.67135277941753 139.73815985674486 0 35.67138633108867 139.7383229059341 0 35.67148310593138 139.73829301012677 0 35.67144954519756 139.73812994971772 0 35.67135277941753 139.73815985674486 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67135277941753 139.73815985674486 15.119 35.67144954519756 139.73812994971772 15.119 35.67148310593138 139.73829301012677 15.119 35.67138633108867 139.7383229059341 15.119 35.67135277941753 139.73815985674486 15.119</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67135277941753 139.73815985674486 15.119 35.67138633108867 139.7383229059341 15.119 35.67138633108867 139.7383229059341 26.08 35.67135277941753 139.73815985674486 26.08 35.67135277941753 139.73815985674486 15.119</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67138633108867 139.7383229059341 15.119 35.67148310593138 139.73829301012677 15.119 35.67148310593138 139.73829301012677 26.08 35.67138633108867 139.7383229059341 26.08 35.67138633108867 139.7383229059341 15.119</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67148310593138 139.73829301012677 15.119 35.67144954519756 139.73812994971772 15.119 35.67144954519756 139.73812994971772 26.08 35.67148310593138 139.73829301012677 26.08 35.67148310593138 139.73829301012677 15.119</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67144954519756 139.73812994971772 15.119 35.67135277941753 139.73815985674486 15.119 35.67135277941753 139.73815985674486 26.08 35.67144954519756 139.73812994971772 26.08 35.67144954519756 139.73812994971772 15.119</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67135277941753 139.73815985674486 26.08 35.67138633108867 139.7383229059341 26.08 35.67148310593138 139.73829301012677 26.08 35.67144954519756 139.73812994971772 26.08 35.67135277941753 139.73815985674486 26.08</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-911ba6fb-4c30-4eb9-9e29-5bdc7a26ae03"/>
							<gml:surfaceMember xlink:href="#poly-1a6115e5-756c-45e1-a6fb-9e396e00df11"/>
							<gml:surfaceMember xlink:href="#poly-53ffe4d3-1232-4d21-a8bf-55840c8a3785"/>
							<gml:surfaceMember xlink:href="#poly-8aa92e31-eb4f-4857-8652-e2dabcbec5d3"/>
							<gml:surfaceMember xlink:href="#poly-6868fd03-53f7-4152-8181-74984fea2b90"/>
							<gml:surfaceMember xlink:href="#poly-20667313-196d-43ae-a4ec-6fef21fed171"/>
							<gml:surfaceMember xlink:href="#poly-001cf479-fa23-4465-8b9f-dc5de3f04373"/>
							<gml:surfaceMember xlink:href="#poly-75b8188f-3421-49b2-a166-0b3c65a6bbc9"/>
							<gml:surfaceMember xlink:href="#poly-10432c61-b1c1-4a3d-8019-1a16d8a30764"/>
							<gml:surfaceMember xlink:href="#poly-80c19c2e-44a7-4c7d-8cb9-94a986c5b345"/>
							<gml:surfaceMember xlink:href="#poly-26763566-1d57-4ee3-bb6a-4b7005f222f1"/>
							<gml:surfaceMember xlink:href="#poly-c584ef7c-b30f-40c8-bacb-c5895c66d923"/>
							<gml:surfaceMember xlink:href="#poly-215754c1-3cf8-4969-9d73-57ff175f9c0e"/>
							<gml:surfaceMember xlink:href="#poly-d5c3235c-b4b5-4342-a85d-296a8a029aab"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_e0efd6ce-ac9c-4726-8185-50e3ac0bdd50_BuildingInstallation_1060">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f40ea357-a33b-4fe4-8450-61b7f2afb793">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67135277941752 139.73815985674486 15.119 35.671347060775524 139.73813207081 15.119 35.67139878695431 139.73811610257368 15.119 35.67140095854512 139.73812659407452 15.119 35.67145511781574 139.73810984968557 15.119 35.671492216588135 139.738290193538 15.119 35.67148310593136 139.73829301012677 15.119 35.671449545188814 139.7381299386713 15.119 35.67135277941752 139.73815985674486 15.119</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2ac1998e-00b3-412e-a67e-ee4ff26050bc">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2ac1998e-00b3-412e-a67e-ee4ff26050bc_0">
											<gml:posList>35.671347060775524 139.73813207081 26.5 35.671347060775524 139.73813207081 15.119 35.67135277941752 139.73815985674486 15.119 35.67135277941752 139.73815985674486 26.5 35.671347060775524 139.73813207081 26.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-76b0cbb3-9851-4965-8353-cbe45a9d0255">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-76b0cbb3-9851-4965-8353-cbe45a9d0255_0">
											<gml:posList>35.67139878695431 139.73811610257368 26.5 35.67139878695431 139.73811610257368 15.119 35.671347060775524 139.73813207081 15.119 35.671347060775524 139.73813207081 26.5 35.67139878695431 139.73811610257368 26.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-66f5fe9f-c15b-4ebf-8198-e6fefb49ddf5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-66f5fe9f-c15b-4ebf-8198-e6fefb49ddf5_0">
											<gml:posList>35.67140095854512 139.73812659407452 26.5 35.67140095854512 139.73812659407452 15.119 35.67139878695431 139.73811610257368 15.119 35.67139878695431 139.73811610257368 26.5 35.67140095854512 139.73812659407452 26.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a7b8e40a-8b7f-443c-909c-956aeb01b233">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a7b8e40a-8b7f-443c-909c-956aeb01b233_0">
											<gml:posList>35.67135277941752 139.73815985674486 26.5 35.67135277941752 139.73815985674486 15.119 35.671449545188814 139.7381299386713 15.119 35.671449545188814 139.7381299386713 26.5 35.67135277941752 139.73815985674486 26.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-98c8ab8a-890f-429b-a160-fc76d607d73b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-98c8ab8a-890f-429b-a160-fc76d607d73b_0">
											<gml:posList>35.67135277941752 139.73815985674486 26.5 35.671449545188814 139.7381299386713 26.5 35.67148310593136 139.73829301012677 26.5 35.671492216588135 139.738290193538 26.5 35.67145511781574 139.73810984968557 26.5 35.67140095854512 139.73812659407452 26.5 35.67139878695431 139.73811610257368 26.5 35.671347060775524 139.73813207081 26.5 35.67135277941752 139.73815985674486 26.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e24b3577-8ce8-4ae1-8014-e38ce27d7189">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e24b3577-8ce8-4ae1-8014-e38ce27d7189_0">
											<gml:posList>35.67145511781574 139.73810984968557 26.5 35.67145511781574 139.73810984968557 15.119 35.67140095854512 139.73812659407452 15.119 35.67140095854512 139.73812659407452 26.5 35.67145511781574 139.73810984968557 26.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a8fa27da-92c8-4696-abc1-3cb15a5d2ed5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a8fa27da-92c8-4696-abc1-3cb15a5d2ed5_0">
											<gml:posList>35.671449545188814 139.7381299386713 26.5 35.671449545188814 139.7381299386713 15.119 35.67148310593136 139.73829301012677 15.119 35.67148310593136 139.73829301012677 26.5 35.671449545188814 139.7381299386713 26.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c21baf14-0807-42e2-8504-b06c16030c01">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c21baf14-0807-42e2-8504-b06c16030c01_0">
											<gml:posList>35.671492216588135 139.738290193538 26.5 35.671492216588135 139.738290193538 15.119 35.67145511781574 139.73810984968557 15.119 35.67145511781574 139.73810984968557 26.5 35.671492216588135 139.738290193538 26.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2e438c68-ea34-4fd2-9a75-4ae01c016f28">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2e438c68-ea34-4fd2-9a75-4ae01c016f28_0">
											<gml:posList>35.67148310593136 139.73829301012677 26.5 35.67148310593136 139.73829301012677 15.119 35.671492216588135 139.738290193538 15.119 35.671492216588135 139.738290193538 26.5 35.67148310593136 139.73829301012677 26.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-911ba6fb-4c30-4eb9-9e29-5bdc7a26ae03">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-911ba6fb-4c30-4eb9-9e29-5bdc7a26ae03">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-911ba6fb-4c30-4eb9-9e29-5bdc7a26ae03">
											<gml:posList>35.67135277941752 139.73815985674486 15.119 35.67144954519755 139.7381299497177 15.119 35.67148310593136 139.73829301012677 15.119 35.67138633108865 139.7383229059341 15.119 35.67135277941752 139.73815985674486 15.119</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-1a6115e5-756c-45e1-a6fb-9e396e00df11">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1a6115e5-756c-45e1-a6fb-9e396e00df11">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1a6115e5-756c-45e1-a6fb-9e396e00df11">
											<gml:posList>35.67138633108865 139.7383229059341 26.5 35.671389138819535 139.73831713638694 26.5 35.67135748731246 139.73816330867749 26.5 35.67135277941752 139.73815985674486 26.5 35.67138633108865 139.7383229059341 26.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-53ffe4d3-1232-4d21-a8bf-55840c8a3785">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-53ffe4d3-1232-4d21-a8bf-55840c8a3785">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-53ffe4d3-1232-4d21-a8bf-55840c8a3785">
											<gml:posList>35.67135277941752 139.73815985674486 26.5 35.67135748731246 139.73816330867749 26.5 35.67144672847069 139.73813573033286 26.5 35.67144954519755 139.7381299497177 26.5 35.67135277941752 139.73815985674486 26.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-8aa92e31-eb4f-4857-8652-e2dabcbec5d3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8aa92e31-eb4f-4857-8652-e2dabcbec5d3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8aa92e31-eb4f-4857-8652-e2dabcbec5d3">
											<gml:posList>35.67147838903521 139.7382895692382 26.305 35.67144672847069 139.73813573033286 26.305 35.67135748731246 139.73816330867749 26.305 35.671389138819535 139.73831713638694 26.305 35.67147838903521 139.7382895692382 26.305</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-6868fd03-53f7-4152-8181-74984fea2b90">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6868fd03-53f7-4152-8181-74984fea2b90">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6868fd03-53f7-4152-8181-74984fea2b90">
											<gml:posList>35.67148310593136 139.73829301012677 26.5 35.67147838903521 139.7382895692382 26.5 35.671389138819535 139.73831713638694 26.5 35.67138633108865 139.7383229059341 26.5 35.67148310593136 139.73829301012677 26.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-20667313-196d-43ae-a4ec-6fef21fed171">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-20667313-196d-43ae-a4ec-6fef21fed171">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-20667313-196d-43ae-a4ec-6fef21fed171">
											<gml:posList>35.67144954519755 139.7381299497177 26.5 35.67144672847069 139.73813573033286 26.5 35.67147838903521 139.7382895692382 26.5 35.67148310593136 139.73829301012677 26.5 35.67144954519755 139.7381299497177 26.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-001cf479-fa23-4465-8b9f-dc5de3f04373">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-001cf479-fa23-4465-8b9f-dc5de3f04373">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-001cf479-fa23-4465-8b9f-dc5de3f04373">
											<gml:posList>35.67135277941752 139.73815985674486 15.119 35.67138633108865 139.7383229059341 15.119 35.67138633108865 139.7383229059341 26.5 35.67135277941752 139.73815985674486 26.5 35.67135277941752 139.73815985674486 15.119</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-75b8188f-3421-49b2-a166-0b3c65a6bbc9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-75b8188f-3421-49b2-a166-0b3c65a6bbc9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-75b8188f-3421-49b2-a166-0b3c65a6bbc9">
											<gml:posList>35.671389138819535 139.73831713638694 26.5 35.671389138819535 139.73831713638694 26.305 35.67135748731246 139.73816330867749 26.305 35.67135748731246 139.73816330867749 26.5 35.671389138819535 139.73831713638694 26.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-10432c61-b1c1-4a3d-8019-1a16d8a30764">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-10432c61-b1c1-4a3d-8019-1a16d8a30764">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-10432c61-b1c1-4a3d-8019-1a16d8a30764">
											<gml:posList>35.67144954519755 139.7381299497177 15.119 35.67135277941752 139.73815985674486 15.119 35.67135277941752 139.73815985674486 26.5 35.67144954519755 139.7381299497177 26.5 35.67144954519755 139.7381299497177 15.119</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-80c19c2e-44a7-4c7d-8cb9-94a986c5b345">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-80c19c2e-44a7-4c7d-8cb9-94a986c5b345">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-80c19c2e-44a7-4c7d-8cb9-94a986c5b345">
											<gml:posList>35.67135748731246 139.73816330867749 26.5 35.67135748731246 139.73816330867749 26.305 35.67144672847069 139.73813573033286 26.305 35.67144672847069 139.73813573033286 26.5 35.67135748731246 139.73816330867749 26.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-26763566-1d57-4ee3-bb6a-4b7005f222f1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-26763566-1d57-4ee3-bb6a-4b7005f222f1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-26763566-1d57-4ee3-bb6a-4b7005f222f1">
											<gml:posList>35.67147838903521 139.7382895692382 26.5 35.67147838903521 139.7382895692382 26.305 35.671389138819535 139.73831713638694 26.305 35.671389138819535 139.73831713638694 26.5 35.67147838903521 139.7382895692382 26.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c584ef7c-b30f-40c8-bacb-c5895c66d923">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c584ef7c-b30f-40c8-bacb-c5895c66d923">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c584ef7c-b30f-40c8-bacb-c5895c66d923">
											<gml:posList>35.67138633108865 139.7383229059341 15.119 35.67148310593136 139.73829301012677 15.119 35.67148310593136 139.73829301012677 26.5 35.67138633108865 139.7383229059341 26.5 35.67138633108865 139.7383229059341 15.119</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-215754c1-3cf8-4969-9d73-57ff175f9c0e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-215754c1-3cf8-4969-9d73-57ff175f9c0e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-215754c1-3cf8-4969-9d73-57ff175f9c0e">
											<gml:posList>35.67144672847069 139.73813573033286 26.5 35.67144672847069 139.73813573033286 26.305 35.67147838903521 139.7382895692382 26.305 35.67147838903521 139.7382895692382 26.5 35.67144672847069 139.73813573033286 26.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d5c3235c-b4b5-4342-a85d-296a8a029aab">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d5c3235c-b4b5-4342-a85d-296a8a029aab">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d5c3235c-b4b5-4342-a85d-296a8a029aab">
											<gml:posList>35.67148310593136 139.73829301012677 15.119 35.67144954519755 139.7381299497177 15.119 35.67144954519755 139.7381299497177 26.5 35.67148310593136 139.73829301012677 26.5 35.67148310593136 139.73829301012677 15.119</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-6729</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">203.35517</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1210</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>4</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">2</uro:rank>
					<uro:depth uom="m">1.1</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>