<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_e147dab3-08fd-44b0-8265-30d4ec071c9a">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>29</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103029002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3001</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">411</bldg:usage>
			<bldg:measuredHeight uom="m">8.9</bldg:measuredHeight>
			<bldg:storeysAboveGround>2</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.66794529407907 139.73876963772096 0 35.6679416171208 139.7387704594556 0 35.66794395496128 139.73878611981831 0 35.667939466915 139.7387871302892 0 35.667946362638546 139.73883333830435 0 35.66799851594169 139.73882164547462 0 35.667985177558 139.7387322885821 0 35.667972236112526 139.73873518683737 0 35.66797089503463 139.7387262191265 0 35.667944390309536 139.73873215996767 0 35.667945568289646 139.73874004536754 0 35.6679410261614 139.73874105590485 0 35.66794529407907 139.73876963772096 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66794529407907 139.73876963772096 14.731 35.6679410261614 139.73874105590485 14.731 35.667945568289646 139.73874004536754 14.731 35.667944390309536 139.73873215996767 14.731 35.66797089503463 139.7387262191265 14.731 35.667972236112526 139.73873518683737 14.731 35.667985177558 139.7387322885821 14.731 35.66799851594169 139.73882164547462 14.731 35.667946362638546 139.73883333830435 14.731 35.667939466915 139.7387871302892 14.731 35.66794395496128 139.73878611981831 14.731 35.6679416171208 139.7387704594556 14.731 35.66794529407907 139.73876963772096 14.731</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66794529407907 139.73876963772096 14.731 35.6679416171208 139.7387704594556 14.731 35.6679416171208 139.7387704594556 23.63 35.66794529407907 139.73876963772096 23.63 35.66794529407907 139.73876963772096 14.731</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6679416171208 139.7387704594556 14.731 35.66794395496128 139.73878611981831 14.731 35.66794395496128 139.73878611981831 23.63 35.6679416171208 139.7387704594556 23.63 35.6679416171208 139.7387704594556 14.731</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66794395496128 139.73878611981831 14.731 35.667939466915 139.7387871302892 14.731 35.667939466915 139.7387871302892 23.63 35.66794395496128 139.73878611981831 23.63 35.66794395496128 139.73878611981831 14.731</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667939466915 139.7387871302892 14.731 35.667946362638546 139.73883333830435 14.731 35.667946362638546 139.73883333830435 23.63 35.667939466915 139.7387871302892 23.63 35.667939466915 139.7387871302892 14.731</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667946362638546 139.73883333830435 14.731 35.66799851594169 139.73882164547462 14.731 35.66799851594169 139.73882164547462 23.63 35.667946362638546 139.73883333830435 23.63 35.667946362638546 139.73883333830435 14.731</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66799851594169 139.73882164547462 14.731 35.667985177558 139.7387322885821 14.731 35.667985177558 139.7387322885821 23.63 35.66799851594169 139.73882164547462 23.63 35.66799851594169 139.73882164547462 14.731</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667985177558 139.7387322885821 14.731 35.667972236112526 139.73873518683737 14.731 35.667972236112526 139.73873518683737 23.63 35.667985177558 139.7387322885821 23.63 35.667985177558 139.7387322885821 14.731</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667972236112526 139.73873518683737 14.731 35.66797089503463 139.7387262191265 14.731 35.66797089503463 139.7387262191265 23.63 35.667972236112526 139.73873518683737 23.63 35.667972236112526 139.73873518683737 14.731</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66797089503463 139.7387262191265 14.731 35.667944390309536 139.73873215996767 14.731 35.667944390309536 139.73873215996767 23.63 35.66797089503463 139.7387262191265 23.63 35.66797089503463 139.7387262191265 14.731</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667944390309536 139.73873215996767 14.731 35.667945568289646 139.73874004536754 14.731 35.667945568289646 139.73874004536754 23.63 35.667944390309536 139.73873215996767 23.63 35.667944390309536 139.73873215996767 14.731</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667945568289646 139.73874004536754 14.731 35.6679410261614 139.73874105590485 14.731 35.6679410261614 139.73874105590485 23.63 35.667945568289646 139.73874004536754 23.63 35.667945568289646 139.73874004536754 14.731</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6679410261614 139.73874105590485 14.731 35.66794529407907 139.73876963772096 14.731 35.66794529407907 139.73876963772096 23.63 35.6679410261614 139.73874105590485 23.63 35.6679410261614 139.73874105590485 14.731</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66794529407907 139.73876963772096 23.63 35.6679416171208 139.7387704594556 23.63 35.66794395496128 139.73878611981831 23.63 35.667939466915 139.7387871302892 23.63 35.667946362638546 139.73883333830435 23.63 35.66799851594169 139.73882164547462 23.63 35.667985177558 139.7387322885821 23.63 35.667972236112526 139.73873518683737 23.63 35.66797089503463 139.7387262191265 23.63 35.667944390309536 139.73873215996767 23.63 35.667945568289646 139.73874004536754 23.63 35.6679410261614 139.73874105590485 23.63 35.66794529407907 139.73876963772096 23.63</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-9aed1081-e351-497d-9bc2-d42965b57ec4"/>
							<gml:surfaceMember xlink:href="#poly-08d053e8-30bf-45d3-bb31-e57af30fb6b6"/>
							<gml:surfaceMember xlink:href="#poly-f9a8fb80-ef83-4877-b1ca-1aad4e554dde"/>
							<gml:surfaceMember xlink:href="#poly-06b3d160-557b-42d9-b2bb-6a6e117bf58e"/>
							<gml:surfaceMember xlink:href="#poly-d3e68d84-7c99-4c74-9992-156df6c46b63"/>
							<gml:surfaceMember xlink:href="#poly-fb13c8a8-2f12-4fcd-a689-bb89b53c9af9"/>
							<gml:surfaceMember xlink:href="#poly-f860fae1-58d3-43de-aa23-7231f9924f2b"/>
							<gml:surfaceMember xlink:href="#poly-8bb31a47-b4b2-4d27-9932-50e11c180d25"/>
							<gml:surfaceMember xlink:href="#poly-d8b815c0-2e42-4a3f-8c7a-a24982ac1bea"/>
							<gml:surfaceMember xlink:href="#poly-03f21fb7-fc5d-4e94-8f2f-c987d6dddec1"/>
							<gml:surfaceMember xlink:href="#poly-14e99b7f-9d2a-4bb7-94a1-2e82ab0deb2c"/>
							<gml:surfaceMember xlink:href="#poly-1f37c726-a334-4dde-92cd-ef22484fb56b"/>
							<gml:surfaceMember xlink:href="#poly-dd0f0f29-1a6a-4107-b05d-55ed2b393dde"/>
							<gml:surfaceMember xlink:href="#poly-62d6ed7f-eed0-4776-a2ff-7d38382a303b"/>
							<gml:surfaceMember xlink:href="#poly-9d3f79cc-c785-4659-ac6e-1d9e67d729d9"/>
							<gml:surfaceMember xlink:href="#poly-7d0768ff-a023-452b-8773-1676eff6aa42"/>
							<gml:surfaceMember xlink:href="#poly-9d5159ec-f253-49c3-871d-0d7dc9b608d9"/>
							<gml:surfaceMember xlink:href="#poly-e67ef404-3e39-493b-903b-2a4b98c89f37"/>
							<gml:surfaceMember xlink:href="#poly-fbd8bec2-919f-4957-b655-b58b6eac449f"/>
							<gml:surfaceMember xlink:href="#poly-2f21e64d-8f55-421b-b805-aeb6929e1eb7"/>
							<gml:surfaceMember xlink:href="#poly-8ecfbab8-8a1b-4887-be94-954c2769b225"/>
							<gml:surfaceMember xlink:href="#poly-158e2355-5d41-4c00-9146-b8e62e24b9a5"/>
							<gml:surfaceMember xlink:href="#poly-be681f29-3d84-48b0-a007-fa7d68299601"/>
							<gml:surfaceMember xlink:href="#poly-5fb3194c-9710-4b21-9253-7e2e8d1fca73"/>
							<gml:surfaceMember xlink:href="#poly-7375f9bd-c70a-49c5-8ca4-bc92d0810671"/>
							<gml:surfaceMember xlink:href="#poly-9c4633f4-b868-4862-a54e-85ba28d0457c"/>
							<gml:surfaceMember xlink:href="#poly-81ae8362-ae3c-41b1-948a-71409e6e0fbd"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-9aed1081-e351-497d-9bc2-d42965b57ec4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9aed1081-e351-497d-9bc2-d42965b57ec4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9aed1081-e351-497d-9bc2-d42965b57ec4">
											<gml:posList>35.66794439030956 139.73873215996767 14.731 35.66797089503459 139.73872621912648 14.731 35.66797223611253 139.73873518683735 14.731 35.66798517755798 139.7387322885821 14.731 35.66799851594168 139.73882164547462 14.731 35.667946362638546 139.73883333830435 14.731 35.66793946691498 139.7387871302892 14.731 35.66794395496126 139.7387861198183 14.731 35.667941617120796 139.7387704594556 14.731 35.66794529407907 139.73876963772094 14.731 35.66794102616141 139.73874105590485 14.731 35.667945568289646 139.73874004536754 14.731 35.66794439030956 139.73873215996767 14.731</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-08d053e8-30bf-45d3-bb31-e57af30fb6b6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-08d053e8-30bf-45d3-bb31-e57af30fb6b6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-08d053e8-30bf-45d3-bb31-e57af30fb6b6">
											<gml:posList>35.66794395496126 139.7387861198183 23.74 35.66793946691498 139.7387871302892 23.74 35.667946362638546 139.73883333830435 23.74 35.66794395496126 139.7387861198183 23.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f9a8fb80-ef83-4877-b1ca-1aad4e554dde">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f9a8fb80-ef83-4877-b1ca-1aad4e554dde">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f9a8fb80-ef83-4877-b1ca-1aad4e554dde">
											<gml:posList>35.667970860860564 139.73879747644415 24.56 35.66796796414671 139.7387588301609 24.56 35.66794102616141 139.73874105590485 23.74 35.667970860860564 139.73879747644415 24.56</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-06b3d160-557b-42d9-b2bb-6a6e117bf58e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-06b3d160-557b-42d9-b2bb-6a6e117bf58e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-06b3d160-557b-42d9-b2bb-6a6e117bf58e">
											<gml:posList>35.667970860860564 139.73879747644415 24.56 35.66794102616141 139.73874105590485 23.74 35.66794529407907 139.73876963772094 23.74 35.667970860860564 139.73879747644415 24.56</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d3e68d84-7c99-4c74-9992-156df6c46b63">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d3e68d84-7c99-4c74-9992-156df6c46b63">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d3e68d84-7c99-4c74-9992-156df6c46b63">
											<gml:posList>35.667970860860564 139.73879747644415 24.56 35.66794529407907 139.73876963772094 23.74 35.667941617120796 139.7387704594556 23.74 35.667970860860564 139.73879747644415 24.56</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-fb13c8a8-2f12-4fcd-a689-bb89b53c9af9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fb13c8a8-2f12-4fcd-a689-bb89b53c9af9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fb13c8a8-2f12-4fcd-a689-bb89b53c9af9">
											<gml:posList>35.66794395496126 139.7387861198183 23.74 35.667970860860564 139.73879747644415 24.56 35.667941617120796 139.7387704594556 23.74 35.66794395496126 139.7387861198183 23.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f860fae1-58d3-43de-aa23-7231f9924f2b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f860fae1-58d3-43de-aa23-7231f9924f2b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f860fae1-58d3-43de-aa23-7231f9924f2b">
											<gml:posList>35.66797223611253 139.73873518683735 23.74 35.66794102616141 139.73874105590485 23.74 35.66796796414671 139.7387588301609 24.56 35.66797223611253 139.73873518683735 23.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-8bb31a47-b4b2-4d27-9932-50e11c180d25">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8bb31a47-b4b2-4d27-9932-50e11c180d25">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8bb31a47-b4b2-4d27-9932-50e11c180d25">
											<gml:posList>35.66797223611253 139.73873518683735 23.74 35.667945568289646 139.73874004536754 23.74 35.66794102616141 139.73874105590485 23.74 35.66797223611253 139.73873518683735 23.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d8b815c0-2e42-4a3f-8c7a-a24982ac1bea">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d8b815c0-2e42-4a3f-8c7a-a24982ac1bea">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d8b815c0-2e42-4a3f-8c7a-a24982ac1bea">
											<gml:posList>35.66794395496126 139.7387861198183 23.74 35.667946362638546 139.73883333830435 23.74 35.667970860860564 139.73879747644415 24.56 35.66794395496126 139.7387861198183 23.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-03f21fb7-fc5d-4e94-8f2f-c987d6dddec1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-03f21fb7-fc5d-4e94-8f2f-c987d6dddec1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-03f21fb7-fc5d-4e94-8f2f-c987d6dddec1">
											<gml:posList>35.667945568289646 139.73874004536754 21.26 35.66797223611253 139.73873518683735 21.26 35.66797089503459 139.73872621912648 21.26 35.66794439030956 139.73873215996767 21.26 35.667945568289646 139.73874004536754 21.26</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-14e99b7f-9d2a-4bb7-94a1-2e82ab0deb2c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-14e99b7f-9d2a-4bb7-94a1-2e82ab0deb2c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-14e99b7f-9d2a-4bb7-94a1-2e82ab0deb2c">
											<gml:posList>35.667946362638546 139.73883333830435 23.74 35.66799851594168 139.73882164547462 23.74 35.667970860860564 139.73879747644415 24.56 35.667946362638546 139.73883333830435 23.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-1f37c726-a334-4dde-92cd-ef22484fb56b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1f37c726-a334-4dde-92cd-ef22484fb56b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1f37c726-a334-4dde-92cd-ef22484fb56b">
											<gml:posList>35.66798517755798 139.7387322885821 23.74 35.66796796414671 139.7387588301609 24.56 35.667970860860564 139.73879747644415 24.56 35.66798517755798 139.7387322885821 23.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-dd0f0f29-1a6a-4107-b05d-55ed2b393dde">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-dd0f0f29-1a6a-4107-b05d-55ed2b393dde">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-dd0f0f29-1a6a-4107-b05d-55ed2b393dde">
											<gml:posList>35.66797223611253 139.73873518683735 23.74 35.66796796414671 139.7387588301609 24.56 35.66798517755798 139.7387322885821 23.74 35.66797223611253 139.73873518683735 23.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-62d6ed7f-eed0-4776-a2ff-7d38382a303b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-62d6ed7f-eed0-4776-a2ff-7d38382a303b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-62d6ed7f-eed0-4776-a2ff-7d38382a303b">
											<gml:posList>35.667970860860564 139.73879747644415 24.56 35.66799851594168 139.73882164547462 23.74 35.66798517755798 139.7387322885821 23.74 35.667970860860564 139.73879747644415 24.56</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9d3f79cc-c785-4659-ac6e-1d9e67d729d9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9d3f79cc-c785-4659-ac6e-1d9e67d729d9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9d3f79cc-c785-4659-ac6e-1d9e67d729d9">
											<gml:posList>35.66794395496126 139.7387861198183 14.731 35.66793946691498 139.7387871302892 14.731 35.66793946691498 139.7387871302892 23.74 35.66794395496126 139.7387861198183 23.74 35.66794395496126 139.7387861198183 14.731</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7d0768ff-a023-452b-8773-1676eff6aa42">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7d0768ff-a023-452b-8773-1676eff6aa42">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7d0768ff-a023-452b-8773-1676eff6aa42">
											<gml:posList>35.667941617120796 139.7387704594556 14.731 35.66794395496126 139.7387861198183 14.731 35.66794395496126 139.7387861198183 23.74 35.667941617120796 139.7387704594556 23.74 35.667941617120796 139.7387704594556 14.731</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9d5159ec-f253-49c3-871d-0d7dc9b608d9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9d5159ec-f253-49c3-871d-0d7dc9b608d9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9d5159ec-f253-49c3-871d-0d7dc9b608d9">
											<gml:posList>35.66793946691498 139.7387871302892 14.731 35.667946362638546 139.73883333830435 14.731 35.667946362638546 139.73883333830435 23.74 35.66793946691498 139.7387871302892 23.74 35.66793946691498 139.7387871302892 14.731</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e67ef404-3e39-493b-903b-2a4b98c89f37">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e67ef404-3e39-493b-903b-2a4b98c89f37">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e67ef404-3e39-493b-903b-2a4b98c89f37">
											<gml:posList>35.66794102616141 139.73874105590485 14.731 35.66794529407907 139.73876963772094 14.731 35.66794529407907 139.73876963772094 23.74 35.66794102616141 139.73874105590485 23.74 35.66794102616141 139.73874105590485 14.731</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-fbd8bec2-919f-4957-b655-b58b6eac449f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fbd8bec2-919f-4957-b655-b58b6eac449f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fbd8bec2-919f-4957-b655-b58b6eac449f">
											<gml:posList>35.66794102616141 139.73874105590485 23.74 35.667945568289646 139.73874004536754 23.74 35.667945568289646 139.73874004536754 21.26 35.667945568289646 139.73874004536754 14.731 35.66794102616141 139.73874105590485 14.731 35.66794102616141 139.73874105590485 23.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2f21e64d-8f55-421b-b805-aeb6929e1eb7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2f21e64d-8f55-421b-b805-aeb6929e1eb7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2f21e64d-8f55-421b-b805-aeb6929e1eb7">
											<gml:posList>35.66794529407907 139.73876963772094 14.731 35.667941617120796 139.7387704594556 14.731 35.667941617120796 139.7387704594556 23.74 35.66794529407907 139.73876963772094 23.74 35.66794529407907 139.73876963772094 14.731</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8ecfbab8-8a1b-4887-be94-954c2769b225">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8ecfbab8-8a1b-4887-be94-954c2769b225">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8ecfbab8-8a1b-4887-be94-954c2769b225">
											<gml:posList>35.66794439030956 139.73873215996767 14.731 35.667945568289646 139.73874004536754 14.731 35.667945568289646 139.73874004536754 21.26 35.66794439030956 139.73873215996767 21.26 35.66794439030956 139.73873215996767 14.731</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-158e2355-5d41-4c00-9146-b8e62e24b9a5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-158e2355-5d41-4c00-9146-b8e62e24b9a5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-158e2355-5d41-4c00-9146-b8e62e24b9a5">
											<gml:posList>35.66797089503459 139.73872621912648 14.731 35.66794439030956 139.73873215996767 14.731 35.66794439030956 139.73873215996767 21.26 35.66797089503459 139.73872621912648 21.26 35.66797089503459 139.73872621912648 14.731</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-be681f29-3d84-48b0-a007-fa7d68299601">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-be681f29-3d84-48b0-a007-fa7d68299601">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-be681f29-3d84-48b0-a007-fa7d68299601">
											<gml:posList>35.667945568289646 139.73874004536754 23.74 35.66797223611253 139.73873518683735 23.74 35.66797223611253 139.73873518683735 21.26 35.667945568289646 139.73874004536754 21.26 35.667945568289646 139.73874004536754 23.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5fb3194c-9710-4b21-9253-7e2e8d1fca73">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5fb3194c-9710-4b21-9253-7e2e8d1fca73">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5fb3194c-9710-4b21-9253-7e2e8d1fca73">
											<gml:posList>35.66797223611253 139.73873518683735 14.731 35.66797089503459 139.73872621912648 14.731 35.66797089503459 139.73872621912648 21.26 35.66797223611253 139.73873518683735 21.26 35.66797223611253 139.73873518683735 14.731</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7375f9bd-c70a-49c5-8ca4-bc92d0810671">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7375f9bd-c70a-49c5-8ca4-bc92d0810671">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7375f9bd-c70a-49c5-8ca4-bc92d0810671">
											<gml:posList>35.667946362638546 139.73883333830435 14.731 35.66799851594168 139.73882164547462 14.731 35.66799851594168 139.73882164547462 23.74 35.667946362638546 139.73883333830435 23.74 35.667946362638546 139.73883333830435 14.731</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9c4633f4-b868-4862-a54e-85ba28d0457c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9c4633f4-b868-4862-a54e-85ba28d0457c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9c4633f4-b868-4862-a54e-85ba28d0457c">
											<gml:posList>35.66798517755798 139.7387322885821 23.74 35.66798517755798 139.7387322885821 14.731 35.66797223611253 139.73873518683735 14.731 35.66797223611253 139.73873518683735 21.26 35.66797223611253 139.73873518683735 23.74 35.66798517755798 139.7387322885821 23.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-81ae8362-ae3c-41b1-948a-71409e6e0fbd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-81ae8362-ae3c-41b1-948a-71409e6e0fbd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-81ae8362-ae3c-41b1-948a-71409e6e0fbd">
											<gml:posList>35.66799851594168 139.73882164547462 14.731 35.66798517755798 139.7387322885821 14.731 35.66798517755798 139.7387322885821 23.74 35.66799851594168 139.73882164547462 23.74 35.66799851594168 139.73882164547462 14.731</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区六本木二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-1451</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">58.17865</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1002</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">5</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">211</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1310</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.6</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>3</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingLandSlideRiskAttribute>
					<uro:description codeSpace="../../codelists/LandSlideRiskAttribute_description.xml">1</uro:description>
					<uro:areaType codeSpace="../../codelists/LandSlideRiskAttribute_areaType.xml">1</uro:areaType>
				</uro:BuildingLandSlideRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">12</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">105</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key105.xml">3</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">20</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>