<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_e165778b-91cd-4092-97de-f381087693d9">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">412</bldg:usage>
			<bldg:measuredHeight uom="m">36.8</bldg:measuredHeight>
			<bldg:storeysAboveGround>13</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.67064790549686 139.73863970505474 0 35.670583860140766 139.73835003658013 0 35.67046527057346 139.73838950179396 0 35.67046662750908 139.73839568609898 0 35.67045815678767 139.7383984576966 0 35.67052093524456 139.73868194133559 0 35.67064790549686 139.73863970505474 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67064790549686 139.73863970505474 17.93 35.67052093524456 139.73868194133559 17.93 35.67045815678767 139.7383984576966 17.93 35.67046662750908 139.73839568609898 17.93 35.67046527057346 139.73838950179396 17.93 35.670583860140766 139.73835003658013 17.93 35.67064790549686 139.73863970505474 17.93</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67064790549686 139.73863970505474 17.93 35.670583860140766 139.73835003658013 17.93 35.670583860140766 139.73835003658013 54.75 35.67064790549686 139.73863970505474 54.75 35.67064790549686 139.73863970505474 17.93</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670583860140766 139.73835003658013 17.93 35.67046527057346 139.73838950179396 17.93 35.67046527057346 139.73838950179396 54.75 35.670583860140766 139.73835003658013 54.75 35.670583860140766 139.73835003658013 17.93</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67046527057346 139.73838950179396 17.93 35.67046662750908 139.73839568609898 17.93 35.67046662750908 139.73839568609898 54.75 35.67046527057346 139.73838950179396 54.75 35.67046527057346 139.73838950179396 17.93</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67046662750908 139.73839568609898 17.93 35.67045815678767 139.7383984576966 17.93 35.67045815678767 139.7383984576966 54.75 35.67046662750908 139.73839568609898 54.75 35.67046662750908 139.73839568609898 17.93</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67045815678767 139.7383984576966 17.93 35.67052093524456 139.73868194133559 17.93 35.67052093524456 139.73868194133559 54.75 35.67045815678767 139.7383984576966 54.75 35.67045815678767 139.7383984576966 17.93</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67052093524456 139.73868194133559 17.93 35.67064790549686 139.73863970505474 17.93 35.67064790549686 139.73863970505474 54.75 35.67052093524456 139.73868194133559 54.75 35.67052093524456 139.73868194133559 17.93</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67064790549686 139.73863970505474 54.75 35.670583860140766 139.73835003658013 54.75 35.67046527057346 139.73838950179396 54.75 35.67046662750908 139.73839568609898 54.75 35.67045815678767 139.7383984576966 54.75 35.67052093524456 139.73868194133559 54.75 35.67064790549686 139.73863970505474 54.75</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-6bec677d-0fc0-4efd-9186-426e16330e0c"/>
							<gml:surfaceMember xlink:href="#poly-72c1d61b-032d-4eb9-bbe1-c7624f6bc58d"/>
							<gml:surfaceMember xlink:href="#poly-4fb104ca-e218-46a5-815b-35a74aebdfb4"/>
							<gml:surfaceMember xlink:href="#poly-b0f89551-73a4-48d9-84f4-1793702b130d"/>
							<gml:surfaceMember xlink:href="#poly-6c631590-8b63-466b-a16c-9f41bb4f94e9"/>
							<gml:surfaceMember xlink:href="#poly-4f9f56a8-11e4-468a-ac48-352b84f5a9f0"/>
							<gml:surfaceMember xlink:href="#poly-9143e611-d71c-4591-ac90-f5a1b3371f06"/>
							<gml:surfaceMember xlink:href="#poly-28d382dd-ef99-47ba-94a3-01d25dd4a633"/>
							<gml:surfaceMember xlink:href="#poly-af56239a-46fa-4c4c-b96a-58c0e8d6f057"/>
							<gml:surfaceMember xlink:href="#poly-e78237da-32a2-4cdc-93e4-f3ee3d6eb3a2"/>
							<gml:surfaceMember xlink:href="#poly-f468d2a2-1569-436a-b6c0-c31a6d4b05ae"/>
							<gml:surfaceMember xlink:href="#poly-1f57b83b-7a7b-495e-8066-97d3de056490"/>
							<gml:surfaceMember xlink:href="#poly-56e20eb0-2920-41cf-af50-3709c523c189"/>
							<gml:surfaceMember xlink:href="#poly-0ae5e5dc-49bd-49ac-b73f-1716a3017dfb"/>
							<gml:surfaceMember xlink:href="#poly-0850aa56-8ecc-480d-a2e4-0d0fcfb16ff6"/>
							<gml:surfaceMember xlink:href="#poly-8183c693-e84c-4a02-8385-ffe64fdf8f4d"/>
							<gml:surfaceMember xlink:href="#poly-f4a0132a-3f4a-4772-bf40-dae3fcb935db"/>
							<gml:surfaceMember xlink:href="#poly-25869a88-d6e6-4fc3-b9dc-8e6177d88351"/>
							<gml:surfaceMember xlink:href="#poly-f3329b48-1b28-434d-9b8b-626580480f8b"/>
							<gml:surfaceMember xlink:href="#poly-a9fbe0dd-9196-498c-b892-6edf3c028b2d"/>
							<gml:surfaceMember xlink:href="#poly-8a6046f2-4c8b-4d5e-8dd2-3f9cbfa07c49"/>
							<gml:surfaceMember xlink:href="#poly-c5f16842-6a21-428f-afd1-9ae1ab991844"/>
							<gml:surfaceMember xlink:href="#poly-8787bdf9-ab8f-4786-8899-e595a9980adb"/>
							<gml:surfaceMember xlink:href="#poly-2e7ac782-53df-484d-8399-0546180a1e4a"/>
							<gml:surfaceMember xlink:href="#poly-871143c5-dba8-4957-b5a8-e4424c797f49"/>
							<gml:surfaceMember xlink:href="#poly-15a9826f-e1f8-48e1-989c-ec9e01c22d88"/>
							<gml:surfaceMember xlink:href="#poly-70af5294-46f8-4dd5-abf0-da0137c03ffe"/>
							<gml:surfaceMember xlink:href="#poly-085615b8-5fb8-450e-bcb0-633d80b8cc1a"/>
							<gml:surfaceMember xlink:href="#poly-6d57638f-99a3-443c-9f87-11b4e6c64b47"/>
							<gml:surfaceMember xlink:href="#poly-dce679e1-1836-40c8-982e-29f0bcd728c6"/>
							<gml:surfaceMember xlink:href="#poly-2c6bb468-5666-40f1-8c90-a9f69dd27914"/>
							<gml:surfaceMember xlink:href="#poly-526a3979-2973-4f5c-b20b-16456f1398a2"/>
							<gml:surfaceMember xlink:href="#poly-0aa17f63-a9b7-4043-a600-b467a8f2a41f"/>
							<gml:surfaceMember xlink:href="#poly-47cc902a-db19-418a-959f-bf83dab51023"/>
							<gml:surfaceMember xlink:href="#poly-cf8964b4-488f-47cd-b923-3daff92aec83"/>
							<gml:surfaceMember xlink:href="#poly-a7d3b056-6a06-45e2-b279-6f3d0d68d1ed"/>
							<gml:surfaceMember xlink:href="#poly-749b7b3b-a5bd-4e7e-ab5a-6601397f7865"/>
							<gml:surfaceMember xlink:href="#poly-00973edd-7f00-4fbc-96dd-ba5ac91e1798"/>
							<gml:surfaceMember xlink:href="#poly-73e6c203-b679-4188-a3ec-71482f3a3cd8"/>
							<gml:surfaceMember xlink:href="#poly-638a540b-fe04-42e2-99c7-1dba42c8634c"/>
							<gml:surfaceMember xlink:href="#poly-5aa1add3-f50f-410e-9598-b7a8e342730b"/>
							<gml:surfaceMember xlink:href="#poly-d3fbbb2a-b827-45ed-a38e-73817f7ef8fd"/>
							<gml:surfaceMember xlink:href="#poly-f354e64e-3e4d-4cc5-a198-e82c1f9cae88"/>
							<gml:surfaceMember xlink:href="#poly-d04308ba-1b55-495e-8ba1-e72f593d6400"/>
							<gml:surfaceMember xlink:href="#poly-8aed3e45-a210-4a52-983d-3625dc679751"/>
							<gml:surfaceMember xlink:href="#poly-e2391a5f-8e06-47a6-bc53-5c48c1694385"/>
							<gml:surfaceMember xlink:href="#poly-c3e9b55d-c256-443d-ace5-a38dffc5c39d"/>
							<gml:surfaceMember xlink:href="#poly-eac23d4b-4e8e-44e4-a61c-3dcd5778a417"/>
							<gml:surfaceMember xlink:href="#poly-5cd05355-08f5-4d67-b284-f4b7a4873d1d"/>
							<gml:surfaceMember xlink:href="#poly-2c950b2d-3b2b-4cd8-a346-f20b638d3503"/>
							<gml:surfaceMember xlink:href="#poly-70f6ce16-1171-454d-9463-50673dce7616"/>
							<gml:surfaceMember xlink:href="#poly-200c2f23-d0f3-4d90-a1c9-2db7aae9af98"/>
							<gml:surfaceMember xlink:href="#poly-bb9b1671-42ad-40ea-a95b-61c642c2a633"/>
							<gml:surfaceMember xlink:href="#poly-3c328e45-f65d-4052-8028-3a0786b0aaa5"/>
							<gml:surfaceMember xlink:href="#poly-6f37673a-e920-4b61-a1e2-9cdadb5fe32a"/>
							<gml:surfaceMember xlink:href="#poly-4e70f561-45d3-4720-8155-c7b8604a97d0"/>
							<gml:surfaceMember xlink:href="#poly-e90a28cf-8a43-4089-9f1f-4a4d48c92f7e"/>
							<gml:surfaceMember xlink:href="#poly-a8e15602-5f37-4447-86db-8083a0eccc10"/>
							<gml:surfaceMember xlink:href="#poly-af007edb-bcb6-4474-b005-1ef8b324608e"/>
							<gml:surfaceMember xlink:href="#poly-a2ac0d70-e307-44d6-ad3c-590bd412fa64"/>
							<gml:surfaceMember xlink:href="#poly-a503a38a-a720-4821-a859-08a95e172c23"/>
							<gml:surfaceMember xlink:href="#poly-5c029a4e-eae8-4b1a-b37e-c9170ac7f285"/>
							<gml:surfaceMember xlink:href="#poly-1458b0c1-e308-4a7a-aab7-c003b9479e34"/>
							<gml:surfaceMember xlink:href="#poly-69d65605-d61c-4960-8b9b-544d1cfb2e56"/>
							<gml:surfaceMember xlink:href="#poly-6048a0e5-ab4d-4589-9e66-6dfd79fdaddc"/>
							<gml:surfaceMember xlink:href="#poly-35375c47-ab13-4e58-abf9-87ccbb9aca46"/>
							<gml:surfaceMember xlink:href="#poly-be8162f6-4baf-4f5f-9e66-5c0ac27e7a73"/>
							<gml:surfaceMember xlink:href="#poly-df761823-3b08-4922-928e-2a36d4476fd9"/>
							<gml:surfaceMember xlink:href="#poly-cbfe55aa-dfcf-47f3-88d6-188d204056e6"/>
							<gml:surfaceMember xlink:href="#poly-6b45262e-eafa-4e0f-bc68-04e46f97b925"/>
							<gml:surfaceMember xlink:href="#poly-599b1262-a4b9-4e9f-9a14-73785e99dcbd"/>
							<gml:surfaceMember xlink:href="#poly-202e5f2f-cc4c-4167-9ac2-42bbf4f5be70"/>
							<gml:surfaceMember xlink:href="#poly-ec862023-075b-4cf0-842a-0691c6f12d6c"/>
							<gml:surfaceMember xlink:href="#poly-27db47f2-c05f-4c38-b4dc-9c7c84ac2a9e"/>
							<gml:surfaceMember xlink:href="#poly-82b26cf2-a525-40c4-9eae-158f4dc0eeeb"/>
							<gml:surfaceMember xlink:href="#poly-adc104f4-cc2c-4ddb-91b5-2f5f5461ae59"/>
							<gml:surfaceMember xlink:href="#poly-1040c385-c7f5-41e3-835e-e81e28e74f78"/>
							<gml:surfaceMember xlink:href="#poly-ffc7fd3c-5755-4a70-9dee-03c7764b6c02"/>
							<gml:surfaceMember xlink:href="#poly-9a5e0888-9390-4a65-9fdf-420906943da1"/>
							<gml:surfaceMember xlink:href="#poly-26e307e3-d027-4112-993b-59ff86a87129"/>
							<gml:surfaceMember xlink:href="#poly-6923d87e-2041-447f-b238-671e00f8c403"/>
							<gml:surfaceMember xlink:href="#poly-7b806f0c-9f74-4cad-9040-847034ac8c6d"/>
							<gml:surfaceMember xlink:href="#poly-9e9936e0-a3a9-44d7-9487-24425e27ae09"/>
							<gml:surfaceMember xlink:href="#poly-80d9ee07-fd65-4d81-9cda-5bbd72889cc1"/>
							<gml:surfaceMember xlink:href="#poly-8dafa086-8197-40c4-b76a-70a222c2dfab"/>
							<gml:surfaceMember xlink:href="#poly-24db93cd-d418-4c5d-a8c4-e93f0badfb02"/>
							<gml:surfaceMember xlink:href="#poly-3d429526-05d6-4c19-8529-981b7df5d8f9"/>
							<gml:surfaceMember xlink:href="#poly-5ed1cf51-9ba0-4578-aef0-8d524b12928e"/>
							<gml:surfaceMember xlink:href="#poly-a829e370-448a-41a7-819e-b2e9278221a4"/>
							<gml:surfaceMember xlink:href="#poly-1f8df04d-b60b-41e3-9e99-2527a01c2148"/>
							<gml:surfaceMember xlink:href="#poly-a85a4eb7-a724-43f5-acc2-37263e467866"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_e165778b-91cd-4092-97de-f381087693d9_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-717cec2d-29e0-40f7-9203-3a8bcedd8b4f">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6705612022216 139.73851344901152 54.851 35.67055811031647 139.73850175465364 54.851 35.670568770234894 139.73849753341065 54.851 35.67057185311801 139.73850921673434 54.851 35.6705612022216 139.73851344901152 54.851</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d5df9eb7-ffd0-492a-ada2-fe78a1d0918c">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67059374200121 139.738513719825 54.927 35.67060915121193 139.7385082999654 54.927 35.670616495046275 139.73853965170227 54.927 35.6706007163672 139.73854519350235 54.927 35.67059374200121 139.738513719825 54.927</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d242a53d-5762-4f0f-ba62-76ee619e3c69">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6706007163672 139.73854519350235 55.221 35.6705982653131 139.73854605801066 55.221 35.67059093049414 139.73851470626963 55.221 35.67059374200121 139.738513719825 55.221 35.6706007163672 139.73854519350235 55.221</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8f18a04e-c311-4f7d-8ef9-96319628d409">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8f18a04e-c311-4f7d-8ef9-96319628d409_0">
											<gml:posList>35.670568770234894 139.73849753341065 54.851 35.67055811031647 139.73850175465364 54.851 35.67055811031647 139.73850175465364 57.163 35.670568770234894 139.73849753341065 57.163 35.670568770234894 139.73849753341065 54.851</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3f74e616-e7ef-4fbd-ba5b-fe8baa703427">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3f74e616-e7ef-4fbd-ba5b-fe8baa703427_0">
											<gml:posList>35.67057185311801 139.73850921673434 54.851 35.670568770234894 139.73849753341065 54.851 35.670568770234894 139.73849753341065 57.163 35.67057185311801 139.73850921673434 57.163 35.67057185311801 139.73850921673434 54.851</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3ecbf9fb-7524-4df1-be3c-b1ac5b480942">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3ecbf9fb-7524-4df1-be3c-b1ac5b480942_0">
											<gml:posList>35.6705612022216 139.73851344901152 57.163 35.67057185311801 139.73850921673434 57.163 35.670568770234894 139.73849753341065 57.163 35.67055811031647 139.73850175465364 57.163 35.6705612022216 139.73851344901152 57.163</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-01d02a70-44ff-4c4b-b0a4-7e22ead821d2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-01d02a70-44ff-4c4b-b0a4-7e22ead821d2_0">
											<gml:posList>35.67055811031647 139.73850175465364 54.851 35.6705612022216 139.73851344901152 54.851 35.6705612022216 139.73851344901152 57.163 35.67055811031647 139.73850175465364 57.163 35.67055811031647 139.73850175465364 54.851</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b1bb104e-7b70-4820-baef-a727e642df2a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b1bb104e-7b70-4820-baef-a727e642df2a_0">
											<gml:posList>35.6705612022216 139.73851344901152 54.851 35.67057185311801 139.73850921673434 54.851 35.67057185311801 139.73850921673434 57.163 35.6705612022216 139.73851344901152 57.163 35.6705612022216 139.73851344901152 54.851</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-19dc54b6-8dc9-4818-87c1-7a84b73cd953">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-19dc54b6-8dc9-4818-87c1-7a84b73cd953_0">
											<gml:posList>35.67059374200121 139.738513719825 55.221 35.67059093049414 139.73851470626963 55.221 35.67059093049414 139.73851470626963 56.46 35.67060915121193 139.7385082999654 56.46 35.67060915121193 139.7385082999654 54.927 35.67059374200121 139.738513719825 54.927 35.67059374200121 139.738513719825 55.221</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e2e44fa8-d040-4900-a964-b95af26193df">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e2e44fa8-d040-4900-a964-b95af26193df_0">
											<gml:posList>35.670616495046275 139.73853965170227 54.927 35.67060915121193 139.7385082999654 54.927 35.67060915121193 139.7385082999654 56.46 35.670616495046275 139.73853965170227 56.46 35.670616495046275 139.73853965170227 54.927</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-12cabbe7-7827-4192-9ce9-f83fc3f5ff68">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-12cabbe7-7827-4192-9ce9-f83fc3f5ff68_0">
											<gml:posList>35.670616495046275 139.73853965170227 56.46 35.67060915121193 139.7385082999654 56.46 35.67059093049414 139.73851470626963 56.46 35.6705982653131 139.73854605801066 56.46 35.670616495046275 139.73853965170227 56.46</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f645907c-7c73-4c4c-ba05-e4e2be4d9c9c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f645907c-7c73-4c4c-ba05-e4e2be4d9c9c_0">
											<gml:posList>35.67059374200121 139.738513719825 55.221 35.67059374200121 139.738513719825 54.927 35.6706007163672 139.73854519350235 54.927 35.6706007163672 139.73854519350235 55.221 35.67059374200121 139.738513719825 55.221</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-869e722b-9a47-4107-84b4-45c89530e3f0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-869e722b-9a47-4107-84b4-45c89530e3f0_0">
											<gml:posList>35.67059093049414 139.73851470626963 55.221 35.6705982653131 139.73854605801066 55.221 35.6705982653131 139.73854605801066 56.46 35.67059093049414 139.73851470626963 56.46 35.67059093049414 139.73851470626963 55.221</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e850a2a3-ff31-46aa-9904-2c80b5d09cee">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e850a2a3-ff31-46aa-9904-2c80b5d09cee_0">
											<gml:posList>35.6706007163672 139.73854519350235 55.221 35.6706007163672 139.73854519350235 54.927 35.670616495046275 139.73853965170227 54.927 35.670616495046275 139.73853965170227 56.46 35.6705982653131 139.73854605801066 56.46 35.6705982653131 139.73854605801066 55.221 35.6706007163672 139.73854519350235 55.221</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-6bec677d-0fc0-4efd-9186-426e16330e0c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6bec677d-0fc0-4efd-9186-426e16330e0c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6bec677d-0fc0-4efd-9186-426e16330e0c">
											<gml:posList>35.67046662750907 139.73839568609895 17.93 35.67046527057343 139.73838950179396 17.93 35.67058386014076 139.73835003658013 17.93 35.67064790549685 139.73863970505474 17.93 35.67052093524455 139.73868194133559 17.93 35.670458156787646 139.73839845769658 17.93 35.67046662750907 139.73839568609895 17.93</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-72c1d61b-032d-4eb9-bbe1-c7624f6bc58d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-72c1d61b-032d-4eb9-bbe1-c7624f6bc58d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-72c1d61b-032d-4eb9-bbe1-c7624f6bc58d">
											<gml:posList>35.67061003805693 139.73862727851602 55.221 35.670638973567534 139.73861764510664 55.221 35.67063211935916 139.7386128480659 55.221 35.670603183848925 139.73862248147617 55.221 35.67061003805693 139.73862727851602 55.221</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-4fb104ca-e218-46a5-815b-35a74aebdfb4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4fb104ca-e218-46a5-815b-35a74aebdfb4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4fb104ca-e218-46a5-815b-35a74aebdfb4">
											<gml:posList>35.67062359198114 139.73856652998816 55.221 35.67061965957415 139.73857490772568 55.221 35.6706234353413 139.73857365503216 55.221 35.6706273677482 139.73856527729419 55.221 35.67062359198114 139.73856652998816 55.221</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b0f89551-73a4-48d9-84f4-1793702b130d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b0f89551-73a4-48d9-84f4-1793702b130d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b0f89551-73a4-48d9-84f4-1793702b130d">
											<gml:posList>35.6706273677482 139.73856527729419 55.221 35.6706234353413 139.73857365503216 55.221 35.67063211935916 139.7386128480659 55.221 35.670638973567534 139.73861764510664 55.221 35.6706273677482 139.73856527729419 55.221</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-6c631590-8b63-466b-a16c-9f41bb4f94e9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6c631590-8b63-466b-a16c-9f41bb4f94e9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6c631590-8b63-466b-a16c-9f41bb4f94e9">
											<gml:posList>35.67063117054772 139.7385640135218 55.221 35.6706273677482 139.73856527729419 55.221 35.670638973567534 139.73861764510664 55.221 35.67064274933513 139.73861639241483 55.221 35.67063117054772 139.7385640135218 55.221</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-4f9f56a8-11e4-468a-ac48-352b84f5a9f0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4f9f56a8-11e4-468a-ac48-352b84f5a9f0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4f9f56a8-11e4-468a-ac48-352b84f5a9f0">
											<gml:posList>35.670646801913584 139.73863473552495 55.221 35.67064274933513 139.73861639241483 55.221 35.670638973567534 139.73861764510664 55.221 35.6706430261458 139.73863598821598 55.221 35.670646801913584 139.73863473552495 55.221</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-9143e611-d71c-4591-ac90-f5a1b3371f06">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9143e611-d71c-4591-ac90-f5a1b3371f06">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9143e611-d71c-4591-ac90-f5a1b3371f06">
											<gml:posList>35.67058386014076 139.73835003658013 55.221 35.67054718388562 139.73836224198612 55.221 35.670548830228746 139.73836965209154 55.221 35.67058549747962 139.73835745774562 55.221 35.67058386014076 139.73835003658013 55.221</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-28d382dd-ef99-47ba-94a3-01d25dd4a633">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-28d382dd-ef99-47ba-94a3-01d25dd4a633">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-28d382dd-ef99-47ba-94a3-01d25dd4a633">
											<gml:posList>35.670548830228746 139.73836965209154 55.221 35.67054490686655 139.73837805191275 55.221 35.67058236697734 139.73836541478065 55.221 35.67058549747962 139.73835745774562 55.221 35.670548830228746 139.73836965209154 55.221</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-af56239a-46fa-4c4c-b96a-58c0e8d6f057">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-af56239a-46fa-4c4c-b96a-58c0e8d6f057">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-af56239a-46fa-4c4c-b96a-58c0e8d6f057">
											<gml:posList>35.670548830228746 139.73836965209154 55.221 35.67054718388562 139.73836224198612 55.221 35.67054326953766 139.73837064179682 55.221 35.67054490686655 139.73837805191275 55.221 35.670548830228746 139.73836965209154 55.221</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e78237da-32a2-4cdc-93e4-f3ee3d6eb3a2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e78237da-32a2-4cdc-93e4-f3ee3d6eb3a2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e78237da-32a2-4cdc-93e4-f3ee3d6eb3a2">
											<gml:posList>35.670481797419434 139.7383840032718 55.221 35.67048864264075 139.73838882238718 55.221 35.67054326953766 139.73837064179682 55.221 35.67054718388562 139.73836224198612 55.221 35.670481797419434 139.7383840032718 55.221</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f468d2a2-1569-436a-b6c0-c31a6d4b05ae">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f468d2a2-1569-436a-b6c0-c31a6d4b05ae">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f468d2a2-1569-436a-b6c0-c31a6d4b05ae">
											<gml:posList>35.67058549747962 139.73835745774562 55.221 35.67058236697734 139.73836541478065 55.221 35.670591096262214 139.73840477341247 55.221 35.67059712157351 139.73841002431217 55.221 35.67058549747962 139.73835745774562 55.221</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-1f57b83b-7a7b-495e-8066-97d3de056490">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1f57b83b-7a7b-495e-8066-97d3de056490">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1f57b83b-7a7b-495e-8066-97d3de056490">
											<gml:posList>35.67049559894234 139.73842020766358 55.221 35.67048864264075 139.73838882238718 55.221 35.670481797419434 139.7383840032718 55.221 35.67048263868316 139.73838779114726 55.221 35.67048875372229 139.73841538854506 55.221 35.67049559894234 139.73842020766358 55.221</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-56e20eb0-2920-41cf-af50-3709c523c189">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-56e20eb0-2920-41cf-af50-3709c523c189">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-56e20eb0-2920-41cf-af50-3709c523c189">
											<gml:posList>35.670469391969576 139.73839219220375 55.221 35.67048263868316 139.73838779114726 55.221 35.670481797419434 139.7383840032718 55.221 35.67046527057343 139.73838950179396 55.221 35.67046662750907 139.73839568609895 55.221 35.670458156787646 139.73839845769658 55.221 35.67046374717395 139.73842370285217 55.221 35.67046661278878 139.73842274948066 55.221 35.67046198127069 139.73840183332695 55.221 35.67047087548908 139.73839887344147 55.221 35.670469391969576 139.73839219220375 55.221</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-0ae5e5dc-49bd-49ac-b73f-1716a3017dfb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0ae5e5dc-49bd-49ac-b73f-1716a3017dfb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0ae5e5dc-49bd-49ac-b73f-1716a3017dfb">
											<gml:posList>35.67046661278878 139.73842274948066 54.851 35.67048875372229 139.73841538854506 54.851 35.67048263868316 139.73838779114726 54.851 35.670469391969576 139.73839219220375 54.851 35.67047087548908 139.73839887344147 54.851 35.67046198127069 139.73840183332695 54.851 35.67046661278878 139.73842274948066 54.851</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-0850aa56-8ecc-480d-a2e4-0d0fcfb16ff6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0850aa56-8ecc-480d-a2e4-0d0fcfb16ff6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0850aa56-8ecc-480d-a2e4-0d0fcfb16ff6">
											<gml:posList>35.670591096262214 139.73840477341247 55.221 35.67056868512709 139.7384123997912 55.221 35.670575539343496 139.738417196811 55.221 35.6705894979502 139.73841255189166 55.221 35.67059712157351 139.73841002431217 55.221 35.670591096262214 139.73840477341247 55.221</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-8183c693-e84c-4a02-8385-ffe64fdf8f4d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8183c693-e84c-4a02-8385-ffe64fdf8f4d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8183c693-e84c-4a02-8385-ffe64fdf8f4d">
											<gml:posList>35.670575539343496 139.738417196811 55.221 35.67056868512709 139.7384123997912 55.221 35.67057114559279 139.73842347630267 55.221 35.670577999808735 139.7384282733236 55.221 35.670575539343496 139.738417196811 55.221</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f4a0132a-3f4a-4772-bf40-dae3fcb935db">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f4a0132a-3f4a-4772-bf40-dae3fcb935db">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f4a0132a-3f4a-4772-bf40-dae3fcb935db">
											<gml:posList>35.67046661278878 139.73842274948066 55.221 35.67046374717395 139.73842370285217 55.221 35.670470583379974 139.73842852198055 55.221 35.67049559894234 139.73842020766358 55.221 35.67048875372229 139.73841538854506 55.221 35.67046661278878 139.73842274948066 55.221</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-25869a88-d6e6-4fc3-b9dc-8e6177d88351">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-25869a88-d6e6-4fc3-b9dc-8e6177d88351">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-25869a88-d6e6-4fc3-b9dc-8e6177d88351">
											<gml:posList>35.670575026055374 139.73842925996306 55.221 35.670577999808735 139.7384282733236 55.221 35.67057114559279 139.73842347630267 55.221 35.67056817183946 139.73842446294225 55.221 35.670575026055374 139.73842925996306 55.221</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f3329b48-1b28-434d-9b8b-626580480f8b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f3329b48-1b28-434d-9b8b-626580480f8b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f3329b48-1b28-434d-9b8b-626580480f8b">
											<gml:posList>35.670476845670564 139.73848286222892 55.221 35.670480760043816 139.73847448452315 55.221 35.670470583379974 139.73842852198055 55.221 35.67046374717395 139.73842370285217 55.221 35.670476845670564 139.73848286222892 55.221</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a9fbe0dd-9196-498c-b892-6edf3c028b2d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a9fbe0dd-9196-498c-b892-6edf3c028b2d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a9fbe0dd-9196-498c-b892-6edf3c028b2d">
											<gml:posList>35.670480760043816 139.73847448452315 55.221 35.670476845670564 139.73848286222892 55.221 35.670482829224454 139.7384808778674 55.221 35.67050313183209 139.73847411562022 55.221 35.67050705521843 139.7384657379006 55.221 35.670480760043816 139.73847448452315 55.221</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-8a6046f2-4c8b-4d5e-8dd2-3f9cbfa07c49">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8a6046f2-4c8b-4d5e-8dd2-3f9cbfa07c49">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8a6046f2-4c8b-4d5e-8dd2-3f9cbfa07c49">
											<gml:posList>35.6705894979502 139.73841255189166 54.927 35.670575539343496 139.738417196811 54.927 35.670577999808735 139.7384282733236 54.927 35.670575026055374 139.73842925996306 54.927 35.670600743512715 139.73854532602573 54.927 35.67061764884615 139.7385397055696 54.927 35.6705894979502 139.73841255189166 54.927</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c5f16842-6a21-428f-afd1-9ae1ab991844">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c5f16842-6a21-428f-afd1-9ae1ab991844">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c5f16842-6a21-428f-afd1-9ae1ab991844">
											<gml:posList>35.67061764884615 139.7385397055696 55.221 35.67062359198114 139.73856652998816 55.221 35.6706273677482 139.73856527729419 55.221 35.67063117054772 139.7385640135218 55.221 35.67059712157351 139.73841002431217 55.221 35.6705894979502 139.73841255189166 55.221 35.67061764884615 139.7385397055696 55.221</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-8787bdf9-ab8f-4786-8899-e595a9980adb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8787bdf9-ab8f-4786-8899-e595a9980adb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8787bdf9-ab8f-4786-8899-e595a9980adb">
											<gml:posList>35.670575026055374 139.73842925996306 55.221 35.67056817183946 139.73842446294225 55.221 35.67059681111588 139.73855371480818 55.221 35.670600743512715 139.73854532602573 55.221 35.670575026055374 139.73842925996306 55.221</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-2e7ac782-53df-484d-8399-0546180a1e4a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2e7ac782-53df-484d-8399-0546180a1e4a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2e7ac782-53df-484d-8399-0546180a1e4a">
											<gml:posList>35.67061965957415 139.73857490772568 54.851 35.67061371644102 139.7385480833078 54.851 35.67059681111588 139.73855371480818 54.851 35.67056817183946 139.73842446294225 54.851 35.67057114559279 139.73842347630267 54.851 35.67056868512709 139.7384123997912 54.851 35.670591096262214 139.73840477341247 54.851 35.67058236697734 139.73836541478065 54.851 35.67054490686655 139.73837805191275 54.851 35.67054326953766 139.73837064179682 54.851 35.67048864264075 139.73838882238718 54.851 35.67049559894234 139.73842020766358 54.851 35.670470583379974 139.73842852198055 54.851 35.670480760043816 139.73847448452315 54.851 35.67050705521843 139.7384657379006 54.851 35.67053025791604 139.73857048441164 54.851 35.67050396273386 139.73857923100243 54.851 35.67051383177022 139.73862379106947 54.851 35.670542235610455 139.73861433503913 54.851 35.67054961703566 139.73864767504608 54.851 35.670604712571944 139.73862935046282 54.851 35.670603183848925 139.73862248147617 54.851 35.67063211935916 139.7386128480659 54.851 35.6706234353413 139.73857365503216 54.851 35.67061965957415 139.73857490772568 54.851</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-871143c5-dba8-4957-b5a8-e4424c797f49">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-871143c5-dba8-4957-b5a8-e4424c797f49">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-871143c5-dba8-4957-b5a8-e4424c797f49">
											<gml:posList>35.670523412710715 139.73856567632447 55.221 35.67053025791604 139.73857048441164 55.221 35.67050705521843 139.7384657379006 55.221 35.67050313183209 139.73847411562022 55.221 35.670523412710715 139.73856567632447 55.221</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-15a9826f-e1f8-48e1-989c-ec9e01c22d88">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-15a9826f-e1f8-48e1-989c-ec9e01c22d88">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-15a9826f-e1f8-48e1-989c-ec9e01c22d88">
											<gml:posList>35.670523412710715 139.73856567632447 54.851 35.67050313183209 139.73847411562022 54.851 35.670482829224454 139.7384808778674 54.851 35.67050310107555 139.7385724275146 54.851 35.670523412710715 139.73856567632447 54.851</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-70af5294-46f8-4dd5-abf0-da0137c03ffe">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-70af5294-46f8-4dd5-abf0-da0137c03ffe">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-70af5294-46f8-4dd5-abf0-da0137c03ffe">
											<gml:posList>35.670476845670564 139.73848286222892 55.221 35.670497126542585 139.73857442290543 55.221 35.67050310107555 139.7385724275146 55.221 35.670482829224454 139.7384808778674 55.221 35.670476845670564 139.73848286222892 55.221</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-085615b8-5fb8-450e-bcb0-633d80b8cc1a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-085615b8-5fb8-450e-bcb0-633d80b8cc1a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-085615b8-5fb8-450e-bcb0-633d80b8cc1a">
											<gml:posList>35.670600743512715 139.73854532602573 55.221 35.67059681111588 139.73855371480818 55.221 35.67061371644102 139.7385480833078 55.221 35.67061764884615 139.7385397055696 55.221 35.670600743512715 139.73854532602573 55.221</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-6d57638f-99a3-443c-9f87-11b4e6c64b47">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6d57638f-99a3-443c-9f87-11b4e6c64b47">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6d57638f-99a3-443c-9f87-11b4e6c64b47">
											<gml:posList>35.67062359198114 139.73856652998816 55.221 35.67061764884615 139.7385397055696 55.221 35.67061371644102 139.7385480833078 55.221 35.67061965957415 139.73857490772568 55.221 35.67062359198114 139.73856652998816 55.221</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-dce679e1-1836-40c8-982e-29f0bcd728c6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-dce679e1-1836-40c8-982e-29f0bcd728c6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-dce679e1-1836-40c8-982e-29f0bcd728c6">
											<gml:posList>35.67050310107555 139.7385724275146 55.221 35.670497126542585 139.73857442290543 55.221 35.67050396273386 139.73857923100243 55.221 35.67053025791604 139.73857048441164 55.221 35.670523412710715 139.73856567632447 55.221 35.67050310107555 139.7385724275146 55.221</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-2c6bb468-5666-40f1-8c90-a9f69dd27914">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2c6bb468-5666-40f1-8c90-a9f69dd27914">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2c6bb468-5666-40f1-8c90-a9f69dd27914">
											<gml:posList>35.6705099173866 139.73863216877143 55.221 35.67051383177022 139.73862379106947 55.221 35.67050396273386 139.73857923100243 55.221 35.670497126542585 139.73857442290543 55.221 35.6705099173866 139.73863216877143 55.221</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-526a3979-2973-4f5c-b20b-16456f1398a2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-526a3979-2973-4f5c-b20b-16456f1398a2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-526a3979-2973-4f5c-b20b-16456f1398a2">
											<gml:posList>35.67051383177022 139.73862379106947 55.221 35.6705099173866 139.73863216877143 55.221 35.670514359996105 139.7386306943691 55.221 35.67053831222248 139.73862272380143 55.221 35.670542235610455 139.73861433503913 55.221 35.67051383177022 139.73862379106947 55.221</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-0aa17f63-a9b7-4043-a600-b467a8f2a41f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0aa17f63-a9b7-4043-a600-b467a8f2a41f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0aa17f63-a9b7-4043-a600-b467a8f2a41f">
											<gml:posList>35.67061003805693 139.73862727851602 55.221 35.670603183848925 139.73862248147617 55.221 35.670604712571944 139.73862935046282 55.221 35.67061156677969 139.73863414750335 55.221 35.67061003805693 139.73862727851602 55.221</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-47cc902a-db19-418a-959f-bf83dab51023">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-47cc902a-db19-418a-959f-bf83dab51023">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-47cc902a-db19-418a-959f-bf83dab51023">
											<gml:posList>35.67053831222248 139.73862272380143 55.221 35.670545693645366 139.73865606380753 55.221 35.67054961703566 139.73864767504608 55.221 35.670542235610455 139.73861433503913 55.221 35.67053831222248 139.73862272380143 55.221</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-cf8964b4-488f-47cd-b923-3daff92aec83">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cf8964b4-488f-47cd-b923-3daff92aec83">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cf8964b4-488f-47cd-b923-3daff92aec83">
											<gml:posList>35.67061156677969 139.73863414750335 55.221 35.670604712571944 139.73862935046282 55.221 35.67054961703566 139.73864767504608 55.221 35.670545693645366 139.73865606380753 55.221 35.67061156677969 139.73863414750335 55.221</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a7d3b056-6a06-45e2-b279-6f3d0d68d1ed">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a7d3b056-6a06-45e2-b279-6f3d0d68d1ed">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a7d3b056-6a06-45e2-b279-6f3d0d68d1ed">
											<gml:posList>35.670545693645366 139.73865606380753 54.777 35.67053831222248 139.73862272380143 54.777 35.670514359996105 139.7386306943691 54.777 35.67052426519856 139.73867542009978 54.777 35.6706430261458 139.73863598821598 54.777 35.670638973567534 139.73861764510664 54.777 35.67061003805693 139.73862727851602 54.777 35.67061156677969 139.73863414750335 54.777 35.670545693645366 139.73865606380753 54.777</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-749b7b3b-a5bd-4e7e-ab5a-6601397f7865">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-749b7b3b-a5bd-4e7e-ab5a-6601397f7865">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-749b7b3b-a5bd-4e7e-ab5a-6601397f7865">
											<gml:posList>35.67052093524455 139.73868194133559 55.221 35.67064790549685 139.73863970505474 55.221 35.670646801913584 139.73863473552495 55.221 35.6706430261458 139.73863598821598 55.221 35.67052426519856 139.73867542009978 55.221 35.670514359996105 139.7386306943691 55.221 35.6705099173866 139.73863216877143 55.221 35.67052093524455 139.73868194133559 55.221</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-00973edd-7f00-4fbc-96dd-ba5ac91e1798">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-00973edd-7f00-4fbc-96dd-ba5ac91e1798">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-00973edd-7f00-4fbc-96dd-ba5ac91e1798">
											<gml:posList>35.670600743512715 139.73854532602573 55.221 35.670600743512715 139.73854532602573 54.927 35.670575026055374 139.73842925996306 54.927 35.670575026055374 139.73842925996306 55.221 35.670600743512715 139.73854532602573 55.221</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-73e6c203-b679-4188-a3ec-71482f3a3cd8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-73e6c203-b679-4188-a3ec-71482f3a3cd8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-73e6c203-b679-4188-a3ec-71482f3a3cd8">
											<gml:posList>35.67050313183209 139.73847411562022 54.851 35.670523412710715 139.73856567632447 54.851 35.670523412710715 139.73856567632447 55.221 35.67050313183209 139.73847411562022 55.221 35.67050313183209 139.73847411562022 54.851</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-638a540b-fe04-42e2-99c7-1dba42c8634c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-638a540b-fe04-42e2-99c7-1dba42c8634c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-638a540b-fe04-42e2-99c7-1dba42c8634c">
											<gml:posList>35.670482829224454 139.7384808778674 55.221 35.67050310107555 139.7385724275146 55.221 35.67050310107555 139.7385724275146 54.851 35.670482829224454 139.7384808778674 54.851 35.670482829224454 139.7384808778674 55.221</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5aa1add3-f50f-410e-9598-b7a8e342730b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5aa1add3-f50f-410e-9598-b7a8e342730b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5aa1add3-f50f-410e-9598-b7a8e342730b">
											<gml:posList>35.67061003805693 139.73862727851602 55.221 35.67061156677969 139.73863414750335 55.221 35.67061156677969 139.73863414750335 54.777 35.67061003805693 139.73862727851602 54.777 35.67061003805693 139.73862727851602 55.221</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d3fbbb2a-b827-45ed-a38e-73817f7ef8fd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d3fbbb2a-b827-45ed-a38e-73817f7ef8fd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d3fbbb2a-b827-45ed-a38e-73817f7ef8fd">
											<gml:posList>35.670545693645366 139.73865606380753 54.777 35.67061156677969 139.73863414750335 54.777 35.67061156677969 139.73863414750335 55.221 35.670545693645366 139.73865606380753 55.221 35.670545693645366 139.73865606380753 54.777</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f354e64e-3e4d-4cc5-a198-e82c1f9cae88">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f354e64e-3e4d-4cc5-a198-e82c1f9cae88">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f354e64e-3e4d-4cc5-a198-e82c1f9cae88">
											<gml:posList>35.67046662750907 139.73839568609895 17.93 35.670458156787646 139.73839845769658 17.93 35.670458156787646 139.73839845769658 55.221 35.67046662750907 139.73839568609895 55.221 35.67046662750907 139.73839568609895 17.93</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d04308ba-1b55-495e-8ba1-e72f593d6400">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d04308ba-1b55-495e-8ba1-e72f593d6400">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d04308ba-1b55-495e-8ba1-e72f593d6400">
											<gml:posList>35.67046661278878 139.73842274948066 55.221 35.67046661278878 139.73842274948066 54.851 35.67046198127069 139.73840183332695 54.851 35.67046198127069 139.73840183332695 55.221 35.67046661278878 139.73842274948066 55.221</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8aed3e45-a210-4a52-983d-3625dc679751">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8aed3e45-a210-4a52-983d-3625dc679751">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8aed3e45-a210-4a52-983d-3625dc679751">
											<gml:posList>35.67046527057343 139.73838950179396 17.93 35.67046662750907 139.73839568609895 17.93 35.67046662750907 139.73839568609895 55.221 35.67046527057343 139.73838950179396 55.221 35.67046527057343 139.73838950179396 17.93</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e2391a5f-8e06-47a6-bc53-5c48c1694385">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e2391a5f-8e06-47a6-bc53-5c48c1694385">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e2391a5f-8e06-47a6-bc53-5c48c1694385">
											<gml:posList>35.67046198127069 139.73840183332695 55.221 35.67046198127069 139.73840183332695 54.851 35.67047087548908 139.73839887344147 54.851 35.67047087548908 139.73839887344147 55.221 35.67046198127069 139.73840183332695 55.221</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c3e9b55d-c256-443d-ace5-a38dffc5c39d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c3e9b55d-c256-443d-ace5-a38dffc5c39d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c3e9b55d-c256-443d-ace5-a38dffc5c39d">
											<gml:posList>35.67047087548908 139.73839887344147 55.221 35.67047087548908 139.73839887344147 54.851 35.670469391969576 139.73839219220375 54.851 35.670469391969576 139.73839219220375 55.221 35.67047087548908 139.73839887344147 55.221</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-eac23d4b-4e8e-44e4-a61c-3dcd5778a417">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-eac23d4b-4e8e-44e4-a61c-3dcd5778a417">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-eac23d4b-4e8e-44e4-a61c-3dcd5778a417">
											<gml:posList>35.670480760043816 139.73847448452315 55.221 35.670480760043816 139.73847448452315 54.851 35.670470583379974 139.73842852198055 54.851 35.670470583379974 139.73842852198055 55.221 35.670480760043816 139.73847448452315 55.221</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5cd05355-08f5-4d67-b284-f4b7a4873d1d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5cd05355-08f5-4d67-b284-f4b7a4873d1d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5cd05355-08f5-4d67-b284-f4b7a4873d1d">
											<gml:posList>35.670469391969576 139.73839219220375 55.221 35.670469391969576 139.73839219220375 54.851 35.67048263868316 139.73838779114726 54.851 35.67048263868316 139.73838779114726 55.221 35.670469391969576 139.73839219220375 55.221</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2c950b2d-3b2b-4cd8-a346-f20b638d3503">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2c950b2d-3b2b-4cd8-a346-f20b638d3503">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2c950b2d-3b2b-4cd8-a346-f20b638d3503">
											<gml:posList>35.67048875372229 139.73841538854506 55.221 35.67048875372229 139.73841538854506 54.851 35.67046661278878 139.73842274948066 54.851 35.67046661278878 139.73842274948066 55.221 35.67048875372229 139.73841538854506 55.221</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-70f6ce16-1171-454d-9463-50673dce7616">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-70f6ce16-1171-454d-9463-50673dce7616">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-70f6ce16-1171-454d-9463-50673dce7616">
											<gml:posList>35.670470583379974 139.73842852198055 55.221 35.670470583379974 139.73842852198055 54.851 35.67049559894234 139.73842020766358 54.851 35.67049559894234 139.73842020766358 55.221 35.670470583379974 139.73842852198055 55.221</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-200c2f23-d0f3-4d90-a1c9-2db7aae9af98">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-200c2f23-d0f3-4d90-a1c9-2db7aae9af98">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-200c2f23-d0f3-4d90-a1c9-2db7aae9af98">
											<gml:posList>35.67048263868316 139.73838779114726 55.221 35.67048263868316 139.73838779114726 54.851 35.67048875372229 139.73841538854506 54.851 35.67048875372229 139.73841538854506 55.221 35.67048263868316 139.73838779114726 55.221</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-bb9b1671-42ad-40ea-a95b-61c642c2a633">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bb9b1671-42ad-40ea-a95b-61c642c2a633">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bb9b1671-42ad-40ea-a95b-61c642c2a633">
											<gml:posList>35.670458156787646 139.73839845769658 17.93 35.67052093524455 139.73868194133559 17.93 35.67052093524455 139.73868194133559 55.221 35.6705099173866 139.73863216877143 55.221 35.670497126542585 139.73857442290543 55.221 35.670476845670564 139.73848286222892 55.221 35.67046374717395 139.73842370285217 55.221 35.670458156787646 139.73839845769658 55.221 35.670458156787646 139.73839845769658 17.93</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3c328e45-f65d-4052-8028-3a0786b0aaa5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3c328e45-f65d-4052-8028-3a0786b0aaa5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3c328e45-f65d-4052-8028-3a0786b0aaa5">
											<gml:posList>35.67049559894234 139.73842020766358 55.221 35.67049559894234 139.73842020766358 54.851 35.67048864264075 139.73838882238718 54.851 35.67048864264075 139.73838882238718 55.221 35.67049559894234 139.73842020766358 55.221</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6f37673a-e920-4b61-a1e2-9cdadb5fe32a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6f37673a-e920-4b61-a1e2-9cdadb5fe32a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6f37673a-e920-4b61-a1e2-9cdadb5fe32a">
											<gml:posList>35.670482829224454 139.7384808778674 54.851 35.67050313183209 139.73847411562022 54.851 35.67050313183209 139.73847411562022 55.221 35.670482829224454 139.7384808778674 55.221 35.670482829224454 139.7384808778674 54.851</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4e70f561-45d3-4720-8155-c7b8604a97d0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4e70f561-45d3-4720-8155-c7b8604a97d0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4e70f561-45d3-4720-8155-c7b8604a97d0">
											<gml:posList>35.67050705521843 139.7384657379006 55.221 35.67050705521843 139.7384657379006 54.851 35.670480760043816 139.73847448452315 54.851 35.670480760043816 139.73847448452315 55.221 35.67050705521843 139.7384657379006 55.221</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e90a28cf-8a43-4089-9f1f-4a4d48c92f7e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e90a28cf-8a43-4089-9f1f-4a4d48c92f7e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e90a28cf-8a43-4089-9f1f-4a4d48c92f7e">
											<gml:posList>35.67051383177022 139.73862379106947 55.221 35.67051383177022 139.73862379106947 54.851 35.67050396273386 139.73857923100243 54.851 35.67050396273386 139.73857923100243 55.221 35.67051383177022 139.73862379106947 55.221</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a8e15602-5f37-4447-86db-8083a0eccc10">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a8e15602-5f37-4447-86db-8083a0eccc10">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a8e15602-5f37-4447-86db-8083a0eccc10">
											<gml:posList>35.67050310107555 139.7385724275146 55.221 35.670523412710715 139.73856567632447 55.221 35.670523412710715 139.73856567632447 54.851 35.67050310107555 139.7385724275146 54.851 35.67050310107555 139.7385724275146 55.221</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-af007edb-bcb6-4474-b005-1ef8b324608e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-af007edb-bcb6-4474-b005-1ef8b324608e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-af007edb-bcb6-4474-b005-1ef8b324608e">
											<gml:posList>35.67048864264075 139.73838882238718 55.221 35.67048864264075 139.73838882238718 54.851 35.67054326953766 139.73837064179682 54.851 35.67054326953766 139.73837064179682 55.221 35.67048864264075 139.73838882238718 55.221</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a2ac0d70-e307-44d6-ad3c-590bd412fa64">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a2ac0d70-e307-44d6-ad3c-590bd412fa64">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a2ac0d70-e307-44d6-ad3c-590bd412fa64">
											<gml:posList>35.67050396273386 139.73857923100243 55.221 35.67050396273386 139.73857923100243 54.851 35.67053025791604 139.73857048441164 54.851 35.67053025791604 139.73857048441164 55.221 35.67050396273386 139.73857923100243 55.221</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a503a38a-a720-4821-a859-08a95e172c23">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a503a38a-a720-4821-a859-08a95e172c23">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a503a38a-a720-4821-a859-08a95e172c23">
											<gml:posList>35.67053025791604 139.73857048441164 55.221 35.67053025791604 139.73857048441164 54.851 35.67050705521843 139.7384657379006 54.851 35.67050705521843 139.7384657379006 55.221 35.67053025791604 139.73857048441164 55.221</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5c029a4e-eae8-4b1a-b37e-c9170ac7f285">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5c029a4e-eae8-4b1a-b37e-c9170ac7f285">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5c029a4e-eae8-4b1a-b37e-c9170ac7f285">
											<gml:posList>35.670514359996105 139.7386306943691 55.221 35.67052426519856 139.73867542009978 55.221 35.67052426519856 139.73867542009978 54.777 35.670514359996105 139.7386306943691 54.777 35.670514359996105 139.7386306943691 55.221</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1458b0c1-e308-4a7a-aab7-c003b9479e34">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1458b0c1-e308-4a7a-aab7-c003b9479e34">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1458b0c1-e308-4a7a-aab7-c003b9479e34">
											<gml:posList>35.67058386014076 139.73835003658013 17.93 35.67046527057343 139.73838950179396 17.93 35.67046527057343 139.73838950179396 55.221 35.670481797419434 139.7383840032718 55.221 35.67054718388562 139.73836224198612 55.221 35.67058386014076 139.73835003658013 55.221 35.67058386014076 139.73835003658013 17.93</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-69d65605-d61c-4960-8b9b-544d1cfb2e56">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-69d65605-d61c-4960-8b9b-544d1cfb2e56">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-69d65605-d61c-4960-8b9b-544d1cfb2e56">
											<gml:posList>35.670514359996105 139.7386306943691 54.777 35.67053831222248 139.73862272380143 54.777 35.67053831222248 139.73862272380143 55.221 35.670514359996105 139.7386306943691 55.221 35.670514359996105 139.7386306943691 54.777</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6048a0e5-ab4d-4589-9e66-6dfd79fdaddc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6048a0e5-ab4d-4589-9e66-6dfd79fdaddc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6048a0e5-ab4d-4589-9e66-6dfd79fdaddc">
											<gml:posList>35.670542235610455 139.73861433503913 55.221 35.670542235610455 139.73861433503913 54.851 35.67051383177022 139.73862379106947 54.851 35.67051383177022 139.73862379106947 55.221 35.670542235610455 139.73861433503913 55.221</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-35375c47-ab13-4e58-abf9-87ccbb9aca46">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-35375c47-ab13-4e58-abf9-87ccbb9aca46">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-35375c47-ab13-4e58-abf9-87ccbb9aca46">
											<gml:posList>35.67053831222248 139.73862272380143 54.777 35.670545693645366 139.73865606380753 54.777 35.670545693645366 139.73865606380753 55.221 35.67053831222248 139.73862272380143 55.221 35.67053831222248 139.73862272380143 54.777</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-be8162f6-4baf-4f5f-9e66-5c0ac27e7a73">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-be8162f6-4baf-4f5f-9e66-5c0ac27e7a73">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-be8162f6-4baf-4f5f-9e66-5c0ac27e7a73">
											<gml:posList>35.67054326953766 139.73837064179682 55.221 35.67054326953766 139.73837064179682 54.851 35.67054490686655 139.73837805191275 54.851 35.67054490686655 139.73837805191275 55.221 35.67054326953766 139.73837064179682 55.221</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-df761823-3b08-4922-928e-2a36d4476fd9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-df761823-3b08-4922-928e-2a36d4476fd9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-df761823-3b08-4922-928e-2a36d4476fd9">
											<gml:posList>35.67054961703566 139.73864767504608 55.221 35.67054961703566 139.73864767504608 54.851 35.670542235610455 139.73861433503913 54.851 35.670542235610455 139.73861433503913 55.221 35.67054961703566 139.73864767504608 55.221</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-cbfe55aa-dfcf-47f3-88d6-188d204056e6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cbfe55aa-dfcf-47f3-88d6-188d204056e6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cbfe55aa-dfcf-47f3-88d6-188d204056e6">
											<gml:posList>35.67054490686655 139.73837805191275 55.221 35.67054490686655 139.73837805191275 54.851 35.67058236697734 139.73836541478065 54.851 35.67058236697734 139.73836541478065 55.221 35.67054490686655 139.73837805191275 55.221</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6b45262e-eafa-4e0f-bc68-04e46f97b925">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6b45262e-eafa-4e0f-bc68-04e46f97b925">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6b45262e-eafa-4e0f-bc68-04e46f97b925">
											<gml:posList>35.67057114559279 139.73842347630267 55.221 35.67057114559279 139.73842347630267 54.851 35.67056817183946 139.73842446294225 54.851 35.67056817183946 139.73842446294225 55.221 35.67057114559279 139.73842347630267 55.221</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-599b1262-a4b9-4e9f-9a14-73785e99dcbd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-599b1262-a4b9-4e9f-9a14-73785e99dcbd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-599b1262-a4b9-4e9f-9a14-73785e99dcbd">
											<gml:posList>35.67056868512709 139.7384123997912 55.221 35.67056868512709 139.7384123997912 54.851 35.67057114559279 139.73842347630267 54.851 35.67057114559279 139.73842347630267 55.221 35.67056868512709 139.7384123997912 55.221</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-202e5f2f-cc4c-4167-9ac2-42bbf4f5be70">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-202e5f2f-cc4c-4167-9ac2-42bbf4f5be70">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-202e5f2f-cc4c-4167-9ac2-42bbf4f5be70">
											<gml:posList>35.670575026055374 139.73842925996306 55.221 35.670575026055374 139.73842925996306 54.927 35.670577999808735 139.7384282733236 54.927 35.670577999808735 139.7384282733236 55.221 35.670575026055374 139.73842925996306 55.221</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ec862023-075b-4cf0-842a-0691c6f12d6c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ec862023-075b-4cf0-842a-0691c6f12d6c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ec862023-075b-4cf0-842a-0691c6f12d6c">
											<gml:posList>35.670577999808735 139.7384282733236 55.221 35.670577999808735 139.7384282733236 54.927 35.670575539343496 139.738417196811 54.927 35.670575539343496 139.738417196811 55.221 35.670577999808735 139.7384282733236 55.221</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-27db47f2-c05f-4c38-b4dc-9c7c84ac2a9e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-27db47f2-c05f-4c38-b4dc-9c7c84ac2a9e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-27db47f2-c05f-4c38-b4dc-9c7c84ac2a9e">
											<gml:posList>35.670604712571944 139.73862935046282 55.221 35.670604712571944 139.73862935046282 54.851 35.67054961703566 139.73864767504608 54.851 35.67054961703566 139.73864767504608 55.221 35.670604712571944 139.73862935046282 55.221</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-82b26cf2-a525-40c4-9eae-158f4dc0eeeb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-82b26cf2-a525-40c4-9eae-158f4dc0eeeb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-82b26cf2-a525-40c4-9eae-158f4dc0eeeb">
											<gml:posList>35.670591096262214 139.73840477341247 55.221 35.670591096262214 139.73840477341247 54.851 35.67056868512709 139.7384123997912 54.851 35.67056868512709 139.7384123997912 55.221 35.670591096262214 139.73840477341247 55.221</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-adc104f4-cc2c-4ddb-91b5-2f5f5461ae59">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-adc104f4-cc2c-4ddb-91b5-2f5f5461ae59">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-adc104f4-cc2c-4ddb-91b5-2f5f5461ae59">
											<gml:posList>35.67056817183946 139.73842446294225 55.221 35.67056817183946 139.73842446294225 54.851 35.67059681111588 139.73855371480818 54.851 35.67059681111588 139.73855371480818 55.221 35.67056817183946 139.73842446294225 55.221</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1040c385-c7f5-41e3-835e-e81e28e74f78">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1040c385-c7f5-41e3-835e-e81e28e74f78">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1040c385-c7f5-41e3-835e-e81e28e74f78">
											<gml:posList>35.670575539343496 139.738417196811 55.221 35.670575539343496 139.738417196811 54.927 35.6705894979502 139.73841255189166 54.927 35.6705894979502 139.73841255189166 55.221 35.670575539343496 139.738417196811 55.221</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ffc7fd3c-5755-4a70-9dee-03c7764b6c02">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ffc7fd3c-5755-4a70-9dee-03c7764b6c02">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ffc7fd3c-5755-4a70-9dee-03c7764b6c02">
											<gml:posList>35.67052426519856 139.73867542009978 55.221 35.6706430261458 139.73863598821598 55.221 35.6706430261458 139.73863598821598 54.777 35.67052426519856 139.73867542009978 54.777 35.67052426519856 139.73867542009978 55.221</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9a5e0888-9390-4a65-9fdf-420906943da1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9a5e0888-9390-4a65-9fdf-420906943da1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9a5e0888-9390-4a65-9fdf-420906943da1">
											<gml:posList>35.67052093524455 139.73868194133559 17.93 35.67064790549685 139.73863970505474 17.93 35.67064790549685 139.73863970505474 55.221 35.67052093524455 139.73868194133559 55.221 35.67052093524455 139.73868194133559 17.93</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-26e307e3-d027-4112-993b-59ff86a87129">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-26e307e3-d027-4112-993b-59ff86a87129">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-26e307e3-d027-4112-993b-59ff86a87129">
											<gml:posList>35.67058236697734 139.73836541478065 55.221 35.67058236697734 139.73836541478065 54.851 35.670591096262214 139.73840477341247 54.851 35.670591096262214 139.73840477341247 55.221 35.67058236697734 139.73836541478065 55.221</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6923d87e-2041-447f-b238-671e00f8c403">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6923d87e-2041-447f-b238-671e00f8c403">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6923d87e-2041-447f-b238-671e00f8c403">
											<gml:posList>35.6705894979502 139.73841255189166 55.221 35.6705894979502 139.73841255189166 54.927 35.67061764884615 139.7385397055696 54.927 35.67061764884615 139.7385397055696 55.221 35.6705894979502 139.73841255189166 55.221</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7b806f0c-9f74-4cad-9040-847034ac8c6d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7b806f0c-9f74-4cad-9040-847034ac8c6d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7b806f0c-9f74-4cad-9040-847034ac8c6d">
											<gml:posList>35.670603183848925 139.73862248147617 55.221 35.670603183848925 139.73862248147617 54.851 35.670604712571944 139.73862935046282 54.851 35.670604712571944 139.73862935046282 55.221 35.670603183848925 139.73862248147617 55.221</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9e9936e0-a3a9-44d7-9487-24425e27ae09">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9e9936e0-a3a9-44d7-9487-24425e27ae09">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9e9936e0-a3a9-44d7-9487-24425e27ae09">
											<gml:posList>35.67059681111588 139.73855371480818 55.221 35.67059681111588 139.73855371480818 54.851 35.67061371644102 139.7385480833078 54.851 35.67061371644102 139.7385480833078 55.221 35.67059681111588 139.73855371480818 55.221</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-80d9ee07-fd65-4d81-9cda-5bbd72889cc1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-80d9ee07-fd65-4d81-9cda-5bbd72889cc1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-80d9ee07-fd65-4d81-9cda-5bbd72889cc1">
											<gml:posList>35.67061764884615 139.7385397055696 55.221 35.67061764884615 139.7385397055696 54.927 35.670600743512715 139.73854532602573 54.927 35.670600743512715 139.73854532602573 55.221 35.67061764884615 139.7385397055696 55.221</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8dafa086-8197-40c4-b76a-70a222c2dfab">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8dafa086-8197-40c4-b76a-70a222c2dfab">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8dafa086-8197-40c4-b76a-70a222c2dfab">
											<gml:posList>35.67064790549685 139.73863970505474 17.93 35.67058386014076 139.73835003658013 17.93 35.67058386014076 139.73835003658013 55.221 35.67058549747962 139.73835745774562 55.221 35.67059712157351 139.73841002431217 55.221 35.67063117054772 139.7385640135218 55.221 35.67064274933513 139.73861639241483 55.221 35.670646801913584 139.73863473552495 55.221 35.67064790549685 139.73863970505474 55.221 35.67064790549685 139.73863970505474 17.93</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-24db93cd-d418-4c5d-a8c4-e93f0badfb02">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-24db93cd-d418-4c5d-a8c4-e93f0badfb02">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-24db93cd-d418-4c5d-a8c4-e93f0badfb02">
											<gml:posList>35.67061371644102 139.7385480833078 55.221 35.67061371644102 139.7385480833078 54.851 35.67061965957415 139.73857490772568 54.851 35.67061965957415 139.73857490772568 55.221 35.67061371644102 139.7385480833078 55.221</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3d429526-05d6-4c19-8529-981b7df5d8f9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3d429526-05d6-4c19-8529-981b7df5d8f9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3d429526-05d6-4c19-8529-981b7df5d8f9">
											<gml:posList>35.67063211935916 139.7386128480659 55.221 35.67063211935916 139.7386128480659 54.851 35.670603183848925 139.73862248147617 54.851 35.670603183848925 139.73862248147617 55.221 35.67063211935916 139.7386128480659 55.221</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5ed1cf51-9ba0-4578-aef0-8d524b12928e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5ed1cf51-9ba0-4578-aef0-8d524b12928e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5ed1cf51-9ba0-4578-aef0-8d524b12928e">
											<gml:posList>35.67061965957415 139.73857490772568 55.221 35.67061965957415 139.73857490772568 54.851 35.6706234353413 139.73857365503216 54.851 35.6706234353413 139.73857365503216 55.221 35.67061965957415 139.73857490772568 55.221</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a829e370-448a-41a7-819e-b2e9278221a4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a829e370-448a-41a7-819e-b2e9278221a4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a829e370-448a-41a7-819e-b2e9278221a4">
											<gml:posList>35.67061003805693 139.73862727851602 54.777 35.670638973567534 139.73861764510664 54.777 35.670638973567534 139.73861764510664 55.221 35.67061003805693 139.73862727851602 55.221 35.67061003805693 139.73862727851602 54.777</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1f8df04d-b60b-41e3-9e99-2527a01c2148">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1f8df04d-b60b-41e3-9e99-2527a01c2148">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1f8df04d-b60b-41e3-9e99-2527a01c2148">
											<gml:posList>35.6706234353413 139.73857365503216 55.221 35.6706234353413 139.73857365503216 54.851 35.67063211935916 139.7386128480659 54.851 35.67063211935916 139.7386128480659 55.221 35.6706234353413 139.73857365503216 55.221</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a85a4eb7-a724-43f5-acc2-37263e467866">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a85a4eb7-a724-43f5-acc2-37263e467866">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a85a4eb7-a724-43f5-acc2-37263e467866">
											<gml:posList>35.670638973567534 139.73861764510664 54.777 35.6706430261458 139.73863598821598 54.777 35.6706430261458 139.73863598821598 55.221 35.670638973567534 139.73861764510664 55.221 35.670638973567534 139.73861764510664 54.777</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-11046</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">396.1106</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">211</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1320</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>4</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>