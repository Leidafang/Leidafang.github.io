<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_e23f0170-7278-4c65-a857-311f8b6c0711">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>3</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001003</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3001</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">413</bldg:usage>
			<bldg:measuredHeight uom="m">7.1</bldg:measuredHeight>
			<bldg:storeysAboveGround>2</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.67446999120825 139.73794807813664 0 35.674459418114736 139.73791395603942 0 35.674421664300326 139.73793123401003 0 35.67445175582223 139.73802697413032 0 35.6745518421413 139.73797881245932 0 35.67453331606777 139.73791829785938 0 35.67446999120825 139.73794807813664 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67446999120825 139.73794807813664 8.26 35.67453331606777 139.73791829785938 8.26 35.6745518421413 139.73797881245932 8.26 35.67445175582223 139.73802697413032 8.26 35.674421664300326 139.73793123401003 8.26 35.674459418114736 139.73791395603942 8.26 35.67446999120825 139.73794807813664 8.26</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67446999120825 139.73794807813664 8.26 35.674459418114736 139.73791395603942 8.26 35.674459418114736 139.73791395603942 15.33 35.67446999120825 139.73794807813664 15.33 35.67446999120825 139.73794807813664 8.26</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.674459418114736 139.73791395603942 8.26 35.674421664300326 139.73793123401003 8.26 35.674421664300326 139.73793123401003 15.33 35.674459418114736 139.73791395603942 15.33 35.674459418114736 139.73791395603942 8.26</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.674421664300326 139.73793123401003 8.26 35.67445175582223 139.73802697413032 8.26 35.67445175582223 139.73802697413032 15.33 35.674421664300326 139.73793123401003 15.33 35.674421664300326 139.73793123401003 8.26</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67445175582223 139.73802697413032 8.26 35.6745518421413 139.73797881245932 8.26 35.6745518421413 139.73797881245932 15.33 35.67445175582223 139.73802697413032 15.33 35.67445175582223 139.73802697413032 8.26</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6745518421413 139.73797881245932 8.26 35.67453331606777 139.73791829785938 8.26 35.67453331606777 139.73791829785938 15.33 35.6745518421413 139.73797881245932 15.33 35.6745518421413 139.73797881245932 8.26</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67453331606777 139.73791829785938 8.26 35.67446999120825 139.73794807813664 8.26 35.67446999120825 139.73794807813664 15.33 35.67453331606777 139.73791829785938 15.33 35.67453331606777 139.73791829785938 8.26</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67446999120825 139.73794807813664 15.33 35.674459418114736 139.73791395603942 15.33 35.674421664300326 139.73793123401003 15.33 35.67445175582223 139.73802697413032 15.33 35.6745518421413 139.73797881245932 15.33 35.67453331606777 139.73791829785938 15.33 35.67446999120825 139.73794807813664 15.33</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-73c6b591-3a04-4268-942a-2b3bb8cc2f0f"/>
							<gml:surfaceMember xlink:href="#poly-96bd1cb6-257b-46f6-b7c2-e9714af326a5"/>
							<gml:surfaceMember xlink:href="#poly-e2261c29-f5a6-406a-aff7-4023bb0014d9"/>
							<gml:surfaceMember xlink:href="#poly-60c63d55-dd3b-46b5-9c59-40a4c7750454"/>
							<gml:surfaceMember xlink:href="#poly-0788b9a9-7bab-4555-a74c-02cc5109c1b5"/>
							<gml:surfaceMember xlink:href="#poly-876bb9fd-cb5c-4d2d-86fc-78e9cfb02077"/>
							<gml:surfaceMember xlink:href="#poly-bd07a11c-1f7e-44af-a38f-31c26bf80dc6"/>
							<gml:surfaceMember xlink:href="#poly-3c519550-a60d-435c-87ac-93968e4e2cfb"/>
							<gml:surfaceMember xlink:href="#poly-d6552e96-eedd-42fc-a2d3-b56f696a053b"/>
							<gml:surfaceMember xlink:href="#poly-41f44f9e-81a2-43e5-8909-2926af40b768"/>
							<gml:surfaceMember xlink:href="#poly-fd544612-cda9-4a9b-b527-d289bf9d967e"/>
							<gml:surfaceMember xlink:href="#poly-3c50429c-d751-49c7-ae15-9e03054216f7"/>
							<gml:surfaceMember xlink:href="#poly-0fcb6fd8-6a12-4b90-9c4b-d35682f5cd9b"/>
							<gml:surfaceMember xlink:href="#poly-a26fbca3-3b8a-40b9-ba46-0844c17df156"/>
							<gml:surfaceMember xlink:href="#poly-b33dc714-2d97-4ab3-89af-a6c3e8f83d12"/>
							<gml:surfaceMember xlink:href="#poly-ddc11d03-c1f2-4e8c-af99-e0b08d460865"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-73c6b591-3a04-4268-942a-2b3bb8cc2f0f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-73c6b591-3a04-4268-942a-2b3bb8cc2f0f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-73c6b591-3a04-4268-942a-2b3bb8cc2f0f">
											<gml:posList>35.67455184214128 139.73797881245932 8.26 35.67445175582222 139.7380269741303 8.26 35.67442166430035 139.73793123401003 8.26 35.67445941811473 139.73791395603942 8.26 35.67446999120823 139.7379480781366 8.26 35.67453331606775 139.73791829785935 8.26 35.67455184214128 139.73797881245932 8.26</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-96bd1cb6-257b-46f6-b7c2-e9714af326a5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-96bd1cb6-257b-46f6-b7c2-e9714af326a5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-96bd1cb6-257b-46f6-b7c2-e9714af326a5">
											<gml:posList>35.67446999120823 139.7379480781366 14.589 35.67445941811473 139.73791395603942 14.589 35.674439613127774 139.73792301591044 15.362 35.67446999120823 139.7379480781366 14.589</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e2261c29-f5a6-406a-aff7-4023bb0014d9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e2261c29-f5a6-406a-aff7-4023bb0014d9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e2261c29-f5a6-406a-aff7-4023bb0014d9">
											<gml:posList>35.67454338336801 139.73795112811092 15.638 35.67453331606775 139.73791829785935 14.589 35.67446999120823 139.7379480781366 14.589 35.67454338336801 139.73795112811092 15.638</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-60c63d55-dd3b-46b5-9c59-40a4c7750454">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-60c63d55-dd3b-46b5-9c59-40a4c7750454">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-60c63d55-dd3b-46b5-9c59-40a4c7750454">
											<gml:posList>35.67442166430035 139.73793123401003 14.589 35.67446132698916 139.73799103848785 15.686 35.674439613127774 139.73792301591044 15.362 35.67442166430035 139.73793123401003 14.589</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-0788b9a9-7bab-4555-a74c-02cc5109c1b5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0788b9a9-7bab-4555-a74c-02cc5109c1b5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0788b9a9-7bab-4555-a74c-02cc5109c1b5">
											<gml:posList>35.674439613127774 139.73792301591044 15.362 35.67446132698916 139.73799103848785 15.686 35.67446999120823 139.7379480781366 14.589 35.674439613127774 139.73792301591044 15.362</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-876bb9fd-cb5c-4d2d-86fc-78e9cfb02077">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-876bb9fd-cb5c-4d2d-86fc-78e9cfb02077">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-876bb9fd-cb5c-4d2d-86fc-78e9cfb02077">
											<gml:posList>35.6744430718045 139.73799940054744 15.638 35.67446132698916 139.73799103848785 15.686 35.67442166430035 139.73793123401003 14.589 35.6744430718045 139.73799940054744 15.638</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-bd07a11c-1f7e-44af-a38f-31c26bf80dc6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bd07a11c-1f7e-44af-a38f-31c26bf80dc6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bd07a11c-1f7e-44af-a38f-31c26bf80dc6">
											<gml:posList>35.67446999120823 139.7379480781366 14.589 35.67446132698916 139.73799103848785 15.686 35.67454338336801 139.73795112811092 15.638 35.67446999120823 139.7379480781366 14.589</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-3c519550-a60d-435c-87ac-93968e4e2cfb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3c519550-a60d-435c-87ac-93968e4e2cfb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3c519550-a60d-435c-87ac-93968e4e2cfb">
											<gml:posList>35.67455184214128 139.73797881245932 14.589 35.67454338336801 139.73795112811092 15.638 35.67446132698916 139.73799103848785 15.686 35.67455184214128 139.73797881245932 14.589</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d6552e96-eedd-42fc-a2d3-b56f696a053b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d6552e96-eedd-42fc-a2d3-b56f696a053b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d6552e96-eedd-42fc-a2d3-b56f696a053b">
											<gml:posList>35.67455184214128 139.73797881245932 14.589 35.67446132698916 139.73799103848785 15.686 35.6744430718045 139.73799940054744 15.638 35.67455184214128 139.73797881245932 14.589</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-41f44f9e-81a2-43e5-8909-2926af40b768">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-41f44f9e-81a2-43e5-8909-2926af40b768">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-41f44f9e-81a2-43e5-8909-2926af40b768">
											<gml:posList>35.67455184214128 139.73797881245932 14.589 35.6744430718045 139.73799940054744 15.638 35.67445175582222 139.7380269741303 14.589 35.67455184214128 139.73797881245932 14.589</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-fd544612-cda9-4a9b-b527-d289bf9d967e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fd544612-cda9-4a9b-b527-d289bf9d967e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fd544612-cda9-4a9b-b527-d289bf9d967e">
											<gml:posList>35.67454338336801 139.73795112811092 15.638 35.67455184214128 139.73797881245932 14.589 35.67455184214128 139.73797881245932 8.26 35.67453331606775 139.73791829785935 8.26 35.67453331606775 139.73791829785935 14.589 35.67454338336801 139.73795112811092 15.638</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3c50429c-d751-49c7-ae15-9e03054216f7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3c50429c-d751-49c7-ae15-9e03054216f7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3c50429c-d751-49c7-ae15-9e03054216f7">
											<gml:posList>35.674439613127774 139.73792301591044 15.362 35.67445941811473 139.73791395603942 14.589 35.67445941811473 139.73791395603942 8.26 35.67442166430035 139.73793123401003 8.26 35.67442166430035 139.73793123401003 14.589 35.674439613127774 139.73792301591044 15.362</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0fcb6fd8-6a12-4b90-9c4b-d35682f5cd9b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0fcb6fd8-6a12-4b90-9c4b-d35682f5cd9b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0fcb6fd8-6a12-4b90-9c4b-d35682f5cd9b">
											<gml:posList>35.67446999120823 139.7379480781366 14.589 35.67446999120823 139.7379480781366 8.26 35.67445941811473 139.73791395603942 8.26 35.67445941811473 139.73791395603942 14.589 35.67446999120823 139.7379480781366 14.589</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a26fbca3-3b8a-40b9-ba46-0844c17df156">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a26fbca3-3b8a-40b9-ba46-0844c17df156">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a26fbca3-3b8a-40b9-ba46-0844c17df156">
											<gml:posList>35.67453331606775 139.73791829785935 14.589 35.67453331606775 139.73791829785935 8.26 35.67446999120823 139.7379480781366 8.26 35.67446999120823 139.7379480781366 14.589 35.67453331606775 139.73791829785935 14.589</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b33dc714-2d97-4ab3-89af-a6c3e8f83d12">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b33dc714-2d97-4ab3-89af-a6c3e8f83d12">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b33dc714-2d97-4ab3-89af-a6c3e8f83d12">
											<gml:posList>35.6744430718045 139.73799940054744 15.638 35.67442166430035 139.73793123401003 14.589 35.67442166430035 139.73793123401003 8.26 35.67445175582222 139.7380269741303 8.26 35.67445175582222 139.7380269741303 14.589 35.6744430718045 139.73799940054744 15.638</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ddc11d03-c1f2-4e8c-af99-e0b08d460865">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ddc11d03-c1f2-4e8c-af99-e0b08d460865">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ddc11d03-c1f2-4e8c-af99-e0b08d460865">
											<gml:posList>35.67445175582222 139.7380269741303 14.589 35.67445175582222 139.7380269741303 8.26 35.67455184214128 139.73797881245932 8.26 35.67455184214128 139.73797881245932 14.589 35.67445175582222 139.7380269741303 14.589</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂三丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-7960</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">85.5936</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1003</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">211</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1230</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>7</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.17</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">21</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>