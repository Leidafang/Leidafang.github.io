<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_e2580aaa-4b63-45d4-b296-2cbf414c7298">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">401</bldg:usage>
			<bldg:measuredHeight uom="m">18.5</bldg:measuredHeight>
			<bldg:storeysAboveGround>6</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.67155118240035 139.73778652837083 0 35.671552745519485 139.73777988760915 0 35.67153603892384 139.7377405822709 0 35.67148217922152 139.73779400065365 0 35.67152724160491 139.73789977163207 0 35.67163600174205 139.737854904121 0 35.67161569702751 139.73776805918098 0 35.67160573045775 139.737759996122 0 35.67159482530298 139.73776183178214 0 35.67158864818582 139.73776977047922 0 35.671588710789116 139.73778050753035 0 35.67156654326096 139.73778837691006 0 35.671564528692784 139.73779405717193 0 35.67155118240035 139.73778652837083 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67155118240035 139.73778652837083 10.73 35.671564528692784 139.73779405717193 10.73 35.67156654326096 139.73778837691006 10.73 35.671588710789116 139.73778050753035 10.73 35.67158864818582 139.73776977047922 10.73 35.67159482530298 139.73776183178214 10.73 35.67160573045775 139.737759996122 10.73 35.67161569702751 139.73776805918098 10.73 35.67163600174205 139.737854904121 10.73 35.67152724160491 139.73789977163207 10.73 35.67148217922152 139.73779400065365 10.73 35.67153603892384 139.7377405822709 10.73 35.671552745519485 139.73777988760915 10.73 35.67155118240035 139.73778652837083 10.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67155118240035 139.73778652837083 10.73 35.671552745519485 139.73777988760915 10.73 35.671552745519485 139.73777988760915 29.2 35.67155118240035 139.73778652837083 29.2 35.67155118240035 139.73778652837083 10.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671552745519485 139.73777988760915 10.73 35.67153603892384 139.7377405822709 10.73 35.67153603892384 139.7377405822709 29.2 35.671552745519485 139.73777988760915 29.2 35.671552745519485 139.73777988760915 10.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67153603892384 139.7377405822709 10.73 35.67148217922152 139.73779400065365 10.73 35.67148217922152 139.73779400065365 29.2 35.67153603892384 139.7377405822709 29.2 35.67153603892384 139.7377405822709 10.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67148217922152 139.73779400065365 10.73 35.67152724160491 139.73789977163207 10.73 35.67152724160491 139.73789977163207 29.2 35.67148217922152 139.73779400065365 29.2 35.67148217922152 139.73779400065365 10.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67152724160491 139.73789977163207 10.73 35.67163600174205 139.737854904121 10.73 35.67163600174205 139.737854904121 29.2 35.67152724160491 139.73789977163207 29.2 35.67152724160491 139.73789977163207 10.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67163600174205 139.737854904121 10.73 35.67161569702751 139.73776805918098 10.73 35.67161569702751 139.73776805918098 29.2 35.67163600174205 139.737854904121 29.2 35.67163600174205 139.737854904121 10.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67161569702751 139.73776805918098 10.73 35.67160573045775 139.737759996122 10.73 35.67160573045775 139.737759996122 29.2 35.67161569702751 139.73776805918098 29.2 35.67161569702751 139.73776805918098 10.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67160573045775 139.737759996122 10.73 35.67159482530298 139.73776183178214 10.73 35.67159482530298 139.73776183178214 29.2 35.67160573045775 139.737759996122 29.2 35.67160573045775 139.737759996122 10.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67159482530298 139.73776183178214 10.73 35.67158864818582 139.73776977047922 10.73 35.67158864818582 139.73776977047922 29.2 35.67159482530298 139.73776183178214 29.2 35.67159482530298 139.73776183178214 10.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67158864818582 139.73776977047922 10.73 35.671588710789116 139.73778050753035 10.73 35.671588710789116 139.73778050753035 29.2 35.67158864818582 139.73776977047922 29.2 35.67158864818582 139.73776977047922 10.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671588710789116 139.73778050753035 10.73 35.67156654326096 139.73778837691006 10.73 35.67156654326096 139.73778837691006 29.2 35.671588710789116 139.73778050753035 29.2 35.671588710789116 139.73778050753035 10.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67156654326096 139.73778837691006 10.73 35.671564528692784 139.73779405717193 10.73 35.671564528692784 139.73779405717193 29.2 35.67156654326096 139.73778837691006 29.2 35.67156654326096 139.73778837691006 10.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671564528692784 139.73779405717193 10.73 35.67155118240035 139.73778652837083 10.73 35.67155118240035 139.73778652837083 29.2 35.671564528692784 139.73779405717193 29.2 35.671564528692784 139.73779405717193 10.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67155118240035 139.73778652837083 29.2 35.671552745519485 139.73777988760915 29.2 35.67153603892384 139.7377405822709 29.2 35.67148217922152 139.73779400065365 29.2 35.67152724160491 139.73789977163207 29.2 35.67163600174205 139.737854904121 29.2 35.67161569702751 139.73776805918098 29.2 35.67160573045775 139.737759996122 29.2 35.67159482530298 139.73776183178214 29.2 35.67158864818582 139.73776977047922 29.2 35.671588710789116 139.73778050753035 29.2 35.67156654326096 139.73778837691006 29.2 35.671564528692784 139.73779405717193 29.2 35.67155118240035 139.73778652837083 29.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-aac7be11-4b2f-4742-8d44-b4a58222e762"/>
							<gml:surfaceMember xlink:href="#poly-b6c88f3e-93f8-4065-8d4b-878a4f4acfde"/>
							<gml:surfaceMember xlink:href="#poly-93bdfe61-1a14-4bce-91ce-fd2f8b1a26e8"/>
							<gml:surfaceMember xlink:href="#poly-52646db4-32c3-44c1-b870-0792943c7d0a"/>
							<gml:surfaceMember xlink:href="#poly-93dba22e-061b-4f40-a27c-3708efaef742"/>
							<gml:surfaceMember xlink:href="#poly-080eaf19-1ebb-4f99-b3d5-5dd350f059d1"/>
							<gml:surfaceMember xlink:href="#poly-318048fb-96cd-4454-8c7e-8d3dbf6f32cb"/>
							<gml:surfaceMember xlink:href="#poly-44b55cb7-c9ad-4738-9175-ea6fd8eedb08"/>
							<gml:surfaceMember xlink:href="#poly-e0b48be4-8486-4165-8080-497aa812d1e0"/>
							<gml:surfaceMember xlink:href="#poly-44273365-d3a0-4df4-b571-9d5f19b314ec"/>
							<gml:surfaceMember xlink:href="#poly-c1397efc-b769-4af8-899a-fa493bb6657f"/>
							<gml:surfaceMember xlink:href="#poly-a15f5371-b71d-498f-9e11-98841d4bb422"/>
							<gml:surfaceMember xlink:href="#poly-324b2404-878d-47ac-9ee3-c7daffe6f91f"/>
							<gml:surfaceMember xlink:href="#poly-ef651063-d03d-4234-945e-74f8cf6d9eaa"/>
							<gml:surfaceMember xlink:href="#poly-cb0da5fb-0306-43bc-8cfa-1c2339315b8e"/>
							<gml:surfaceMember xlink:href="#poly-4a15bdaa-2ec5-4cf4-81dd-862c37a1df30"/>
							<gml:surfaceMember xlink:href="#poly-656fe2d3-081f-461d-bab3-8739ca85575e"/>
							<gml:surfaceMember xlink:href="#poly-06b4883b-9626-4d5d-847c-5c685774542d"/>
							<gml:surfaceMember xlink:href="#poly-85e85a70-fc4e-46e1-a68d-bcfa6b4a763c"/>
							<gml:surfaceMember xlink:href="#poly-505ab3f0-4aa1-405e-beed-e7d4d2b469f2"/>
							<gml:surfaceMember xlink:href="#poly-8cf3ea01-a36e-451d-ad48-5e3e7002e1d8"/>
							<gml:surfaceMember xlink:href="#poly-a83ad68a-85f2-44a4-a562-9d488412aa0f"/>
							<gml:surfaceMember xlink:href="#poly-bb7501a4-3767-4db2-b43d-4d51fa347f7f"/>
							<gml:surfaceMember xlink:href="#poly-feef5c8d-e48c-4e97-a86e-8519039927a4"/>
							<gml:surfaceMember xlink:href="#poly-91bbf727-950b-49f8-91cf-e61058510ef8"/>
							<gml:surfaceMember xlink:href="#poly-ecf3c9d3-e3a0-4ac9-bdac-7f951b70decd"/>
							<gml:surfaceMember xlink:href="#poly-320cb63e-9881-42be-baac-a9b33fa287f5"/>
							<gml:surfaceMember xlink:href="#poly-3a7327f0-cecc-4d23-99b1-82956456e457"/>
							<gml:surfaceMember xlink:href="#poly-09a0643d-7fae-423e-9827-6f04465bb557"/>
							<gml:surfaceMember xlink:href="#poly-47b8bfc0-f127-4138-aac1-78d1587277bb"/>
							<gml:surfaceMember xlink:href="#poly-6bc37463-02b0-438d-82f8-7f95da6a94f3"/>
							<gml:surfaceMember xlink:href="#poly-bb1eb0fd-7c34-4e7f-b56d-37553740a699"/>
							<gml:surfaceMember xlink:href="#poly-0c5be6fc-794e-4c73-992e-a8774496ee01"/>
							<gml:surfaceMember xlink:href="#poly-d5b53395-513f-4c4d-befb-6d5fb5a6b6d4"/>
							<gml:surfaceMember xlink:href="#poly-3e79ca57-1f86-45f0-bec2-4786f0f78e1a"/>
							<gml:surfaceMember xlink:href="#poly-92a77750-811a-48ee-8006-d9cdf97bd871"/>
							<gml:surfaceMember xlink:href="#poly-bfd304e9-ba38-4f75-bd21-66a7e10179c4"/>
							<gml:surfaceMember xlink:href="#poly-e1647243-d75e-4d30-8a52-47b4bb0b349d"/>
							<gml:surfaceMember xlink:href="#poly-ee998721-c516-443e-861a-4e5ee10976f9"/>
							<gml:surfaceMember xlink:href="#poly-4713cbe9-41f4-46af-a418-15d9ffc95b69"/>
							<gml:surfaceMember xlink:href="#poly-5a45c391-362a-487c-a666-16d68a7158a5"/>
							<gml:surfaceMember xlink:href="#poly-44f88d8e-151e-4efc-8df3-de1f7c742930"/>
							<gml:surfaceMember xlink:href="#poly-cc1714f5-6290-4abd-a016-3f43b489dc4e"/>
							<gml:surfaceMember xlink:href="#poly-59e0fd7e-acf6-436b-b690-8bbb207615a9"/>
							<gml:surfaceMember xlink:href="#poly-97a3d694-8521-40a2-bbe9-c234567c9f8c"/>
							<gml:surfaceMember xlink:href="#poly-afcb9bfa-e391-49f3-a507-d69283e23024"/>
							<gml:surfaceMember xlink:href="#poly-b1b26f40-6db5-483f-9d37-e238e8836d9b"/>
							<gml:surfaceMember xlink:href="#poly-9285a72f-9ad4-42d4-88a2-c49dc2e32ed3"/>
							<gml:surfaceMember xlink:href="#poly-f0660930-19ff-426f-a223-66f81569976a"/>
							<gml:surfaceMember xlink:href="#poly-4405bef7-2ff3-4ea4-847d-4280f21b0852"/>
							<gml:surfaceMember xlink:href="#poly-8fb64bfc-b8e0-40ac-a2b7-32f580f40a13"/>
							<gml:surfaceMember xlink:href="#poly-9b003a94-f1fa-419a-ac62-ed56bcea2b2d"/>
							<gml:surfaceMember xlink:href="#poly-f7943183-d746-4cb2-84c7-12c77f3a3989"/>
							<gml:surfaceMember xlink:href="#poly-781c0661-b22b-481f-824e-1c8a8aaef09b"/>
							<gml:surfaceMember xlink:href="#poly-61c8725a-3f53-4a8c-8a84-83f80d4bf786"/>
							<gml:surfaceMember xlink:href="#poly-287f9690-7021-484b-9351-ea6bf8f9e457"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_e2580aaa-4b63-45d4-b296-2cbf414c7298_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3beaa53d-a638-4279-87e4-2376c2395882">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67153695909686 139.73779834289635 33.71 35.671543669567725 139.73781507022568 33.71 35.67152601110525 139.7378257179169 33.71 35.67151930061833 139.73780896849755 33.71 35.67153695909686 139.73779834289635 33.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bbb42c5d-43dd-43a0-ba6c-cb200ed6128b">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671583025864784 139.73782940578232 29.546 35.67159052132848 139.73782441491556 29.546 35.671593627603066 139.73783141464946 29.546 35.67158612312535 139.7378364055265 29.546 35.671583025864784 139.73782940578232 29.546</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-46ffcf8a-28ea-4fb6-a34a-971702edf6c4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67157991057886 139.7378565063725 29.546 35.67156084795174 139.73786965222277 29.546 35.67155274865729 139.73785202073273 29.546 35.67157181128251 139.73783887487963 29.546 35.67157991057886 139.7378565063725 29.546</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bf27a074-22b7-49ea-994e-a26ed6274fa5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bf27a074-22b7-49ea-994e-a26ed6274fa5_0">
											<gml:posList>35.67151930061833 139.73780896849755 33.71 35.67151930061833 139.73780896849755 36.47 35.67153695909686 139.73779834289635 36.47 35.67153695909686 139.73779834289635 33.71 35.67151930061833 139.73780896849755 33.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-07d5c8f3-836d-4d08-ab8e-eba141cc2bc5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-07d5c8f3-836d-4d08-ab8e-eba141cc2bc5_0">
											<gml:posList>35.671543669567725 139.73781507022568 33.71 35.67153695909686 139.73779834289635 33.71 35.67153695909686 139.73779834289635 36.47 35.671543669567725 139.73781507022568 36.47 35.671543669567725 139.73781507022568 33.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d6fb0c53-e9fb-4552-88a1-c62d8c58432b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d6fb0c53-e9fb-4552-88a1-c62d8c58432b_0">
											<gml:posList>35.67153695909686 139.73779834289635 36.47 35.67151930061833 139.73780896849755 36.47 35.67152601110525 139.7378257179169 36.47 35.671543669567725 139.73781507022568 36.47 35.67153695909686 139.73779834289635 36.47</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-31f97b5c-4fd1-4ddc-b673-bd91216ae507">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-31f97b5c-4fd1-4ddc-b673-bd91216ae507_0">
											<gml:posList>35.67151930061833 139.73780896849755 33.71 35.67152601110525 139.7378257179169 33.71 35.67152601110525 139.7378257179169 36.47 35.67151930061833 139.73780896849755 36.47 35.67151930061833 139.73780896849755 33.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c63949b4-8101-4f52-a262-574e1fc72f0e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c63949b4-8101-4f52-a262-574e1fc72f0e_0">
											<gml:posList>35.67152601110525 139.7378257179169 33.71 35.671543669567725 139.73781507022568 33.71 35.671543669567725 139.73781507022568 36.47 35.67152601110525 139.7378257179169 36.47 35.67152601110525 139.7378257179169 33.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7d8117e1-bede-40ea-a319-d66c31ba642f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7d8117e1-bede-40ea-a319-d66c31ba642f_0">
											<gml:posList>35.67159052132848 139.73782441491556 29.546 35.671583025864784 139.73782940578232 29.546 35.671583025864784 139.73782940578232 31.266 35.67159052132848 139.73782441491556 31.266 35.67159052132848 139.73782441491556 29.546</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d2f7c7e3-4a76-41c3-8b6c-6c1133df67bd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d2f7c7e3-4a76-41c3-8b6c-6c1133df67bd_0">
											<gml:posList>35.671593627603066 139.73783141464946 29.546 35.67159052132848 139.73782441491556 29.546 35.67159052132848 139.73782441491556 31.266 35.671593627603066 139.73783141464946 31.266 35.671593627603066 139.73783141464946 29.546</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fe455d5f-564c-4f96-b7cb-35f2a95bded5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fe455d5f-564c-4f96-b7cb-35f2a95bded5_0">
											<gml:posList>35.671593627603066 139.73783141464946 31.266 35.67159052132848 139.73782441491556 31.266 35.671583025864784 139.73782940578232 31.266 35.67158612312535 139.7378364055265 31.266 35.671593627603066 139.73783141464946 31.266</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-44bb402f-3b00-4472-9df2-e5dfe29f973c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-44bb402f-3b00-4472-9df2-e5dfe29f973c_0">
											<gml:posList>35.671583025864784 139.73782940578232 29.546 35.67158612312535 139.7378364055265 29.546 35.67158612312535 139.7378364055265 31.266 35.671583025864784 139.73782940578232 31.266 35.671583025864784 139.73782940578232 29.546</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b5c4f4ec-75c8-41e6-9832-83fc05abee61">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b5c4f4ec-75c8-41e6-9832-83fc05abee61_0">
											<gml:posList>35.671593627603066 139.73783141464946 29.546 35.671593627603066 139.73783141464946 31.266 35.67158612312535 139.7378364055265 31.266 35.67158612312535 139.7378364055265 29.546 35.671593627603066 139.73783141464946 29.546</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7a8ba01a-7555-4f53-a73c-8f9ab4a2fb04">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7a8ba01a-7555-4f53-a73c-8f9ab4a2fb04_0">
											<gml:posList>35.67157181128251 139.73783887487963 29.546 35.67155274865729 139.73785202073273 29.546 35.67155274865729 139.73785202073273 32.326 35.67157181128251 139.73783887487963 32.326 35.67157181128251 139.73783887487963 29.546</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e31d019a-a203-462a-9702-df1451cd9c2a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e31d019a-a203-462a-9702-df1451cd9c2a_0">
											<gml:posList>35.67157991057886 139.7378565063725 29.546 35.67157181128251 139.73783887487963 29.546 35.67157181128251 139.73783887487963 32.326 35.67157991057886 139.7378565063725 32.326 35.67157991057886 139.7378565063725 29.546</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-26e5a66d-b64f-40bb-aeca-b5e75f6d002f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-26e5a66d-b64f-40bb-aeca-b5e75f6d002f_0">
											<gml:posList>35.67157991057886 139.7378565063725 32.326 35.67157181128251 139.73783887487963 32.326 35.67155274865729 139.73785202073273 32.326 35.67156084795174 139.73786965222277 32.326 35.67157991057886 139.7378565063725 32.326</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7f7dedf8-5787-4e85-89b4-e2869ef70a79">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7f7dedf8-5787-4e85-89b4-e2869ef70a79_0">
											<gml:posList>35.67155274865729 139.73785202073273 29.546 35.67156084795174 139.73786965222277 29.546 35.67156084795174 139.73786965222277 32.326 35.67155274865729 139.73785202073273 32.326 35.67155274865729 139.73785202073273 29.546</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f84fdba6-10cc-446c-9250-fb0761053328">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f84fdba6-10cc-446c-9250-fb0761053328_0">
											<gml:posList>35.67156084795174 139.73786965222277 29.546 35.67157991057886 139.7378565063725 29.546 35.67157991057886 139.7378565063725 32.326 35.67156084795174 139.73786965222277 32.326 35.67156084795174 139.73786965222277 29.546</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_e2580aaa-4b63-45d4-b296-2cbf414c7298_BuildingInstallation_1060">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a5d93fbe-ca51-4eb6-af2b-a2a78ecd9e27">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67156745457851 139.7377327681319 10.85 35.67157113891854 139.73772990271505 10.85 35.671577350529454 139.737731353436 10.85 35.67158062619337 139.7377359890283 10.85 35.67158224516541 139.73774293529905 10.85 35.671564519679066 139.7377940571827 10.85 35.671551182400336 139.73778652837083 10.85 35.67156745457851 139.7377327681319 10.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fcc93ba8-14a4-4481-ba07-d5497fa62b62">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fcc93ba8-14a4-4481-ba07-d5497fa62b62_0">
											<gml:posList>35.671551182400336 139.73778652837083 10.85 35.671564519679066 139.7377940571827 10.85 35.671564519679066 139.7377940571827 26.832 35.67155785554224 139.7377902872479 26.832 35.67155785554224 139.7377902872479 30.336 35.671551182400336 139.73778652837083 30.336 35.671551182400336 139.73778652837083 10.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5effd336-2a73-41f0-bb7e-80604cac9ff8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5effd336-2a73-41f0-bb7e-80604cac9ff8_0">
											<gml:posList>35.67156745457851 139.7377327681319 30.005 35.67156745457851 139.7377327681319 10.85 35.671551182400336 139.73778652837083 10.85 35.671551182400336 139.73778652837083 30.336 35.67156745457851 139.7377327681319 30.005</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9613c2b9-a696-48d8-b0a4-3b5dfba4e306">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9613c2b9-a696-48d8-b0a4-3b5dfba4e306_0">
											<gml:posList>35.671551182400336 139.73778652837083 30.336 35.67155785554224 139.7377902872479 30.336 35.67157484987207 139.73773785171502 30.005 35.67156745457851 139.7377327681319 30.005 35.671551182400336 139.73778652837083 30.336</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2ca0beb5-c06d-4757-af85-5e0387195c46">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2ca0beb5-c06d-4757-af85-5e0387195c46_0">
											<gml:posList>35.67155785554224 139.7377902872479 26.832 35.67157484987207 139.73773785171502 30.005 35.67155785554224 139.7377902872479 30.336 35.67155785554224 139.7377902872479 26.832</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b0de6def-a767-4bca-8176-0206b3591d50">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b0de6def-a767-4bca-8176-0206b3591d50_0">
											<gml:posList>35.67157113891854 139.73772990271505 10.85 35.67156745457851 139.7377327681319 10.85 35.67156745457851 139.7377327681319 30.005 35.67157113891854 139.73772990271505 30.005 35.67157113891854 139.73772990271505 10.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-85d5b6af-6a1a-4417-bcc6-c81a9e93c18b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-85d5b6af-6a1a-4417-bcc6-c81a9e93c18b_0">
											<gml:posList>35.67155785554224 139.7377902872479 26.832 35.671564519679066 139.7377940571827 26.832 35.67158224516541 139.73774293529905 30.005 35.67157484987207 139.73773785171502 30.005 35.67155785554224 139.7377902872479 26.832</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3bb5b6e8-b522-4956-9935-db8313ca2244">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3bb5b6e8-b522-4956-9935-db8313ca2244_0">
											<gml:posList>35.671564519679066 139.7377940571827 26.832 35.671564519679066 139.7377940571827 10.85 35.67158224516541 139.73774293529905 10.85 35.67158224516541 139.73774293529905 30.005 35.671564519679066 139.7377940571827 26.832</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b89aea5c-cca7-4061-a8d4-5658e26fb9aa">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b89aea5c-cca7-4061-a8d4-5658e26fb9aa_0">
											<gml:posList>35.671577350529454 139.737731353436 10.85 35.67157113891854 139.73772990271505 10.85 35.67157113891854 139.73772990271505 30.005 35.671577350529454 139.737731353436 30.005 35.671577350529454 139.737731353436 10.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bcbeee12-7c72-4385-b599-73b4979dcb35">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bcbeee12-7c72-4385-b599-73b4979dcb35_0">
											<gml:posList>35.67158224516541 139.73774293529905 30.005 35.67158062619337 139.7377359890283 30.005 35.671577350529454 139.737731353436 30.005 35.67157113891854 139.73772990271505 30.005 35.67156745457851 139.7377327681319 30.005 35.67157484987207 139.73773785171502 30.005 35.67158224516541 139.73774293529905 30.005</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-398f7f38-8616-4c87-b4de-bb5052c00179">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-398f7f38-8616-4c87-b4de-bb5052c00179_0">
											<gml:posList>35.67158062619337 139.7377359890283 10.85 35.671577350529454 139.737731353436 10.85 35.671577350529454 139.737731353436 30.005 35.67158062619337 139.7377359890283 30.005 35.67158062619337 139.7377359890283 10.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8d3c68d2-4f16-4065-84b0-5a9b54729e2a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8d3c68d2-4f16-4065-84b0-5a9b54729e2a_0">
											<gml:posList>35.67158224516541 139.73774293529905 30.005 35.67158224516541 139.73774293529905 10.85 35.67158062619337 139.7377359890283 10.85 35.67158062619337 139.7377359890283 30.005 35.67158224516541 139.73774293529905 30.005</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-aac7be11-4b2f-4742-8d44-b4a58222e762">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-aac7be11-4b2f-4742-8d44-b4a58222e762">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-aac7be11-4b2f-4742-8d44-b4a58222e762">
											<gml:posList>35.671605730457735 139.737759996122 10.73 35.67161569702748 139.73776805918098 10.73 35.67163600174204 139.737854904121 10.73 35.67152724160489 139.73789977163207 10.73 35.67148217922152 139.73779400065365 10.73 35.671536038923804 139.73774058227093 10.73 35.671552745519506 139.73777988760912 10.73 35.671551182400336 139.73778652837083 10.73 35.671564528692784 139.73779405717193 10.73 35.671566543260944 139.73778837691006 10.73 35.671588710789116 139.73778050753035 10.73 35.671588648185846 139.7377697704792 10.73 35.671594825302996 139.73776183178214 10.73 35.671605730457735 139.737759996122 10.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b6c88f3e-93f8-4065-8d4b-878a4f4acfde">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b6c88f3e-93f8-4065-8d4b-878a4f4acfde">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b6c88f3e-93f8-4065-8d4b-878a4f4acfde">
											<gml:posList>35.671552745519506 139.73777988760912 30.005 35.671536038923804 139.73774058227093 30.005 35.67153493545393 139.73774715620547 30.005 35.67154904123112 139.73778033388083 30.005 35.671552745519506 139.73777988760912 30.005</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-93bdfe61-1a14-4bce-91ce-fd2f8b1a26e8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-93bdfe61-1a14-4bce-91ce-fd2f8b1a26e8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-93bdfe61-1a14-4bce-91ce-fd2f8b1a26e8">
											<gml:posList>35.671594825302996 139.73776183178214 30.005 35.671596505037535 139.7377658396327 30.005 35.67160490471127 139.7377644267239 30.005 35.671605730457735 139.737759996122 30.005 35.671594825302996 139.73776183178214 30.005</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-52646db4-32c3-44c1-b870-0792943c7d0a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-52646db4-32c3-44c1-b870-0792943c7d0a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-52646db4-32c3-44c1-b870-0792943c7d0a">
											<gml:posList>35.671605730457735 139.737759996122 30.005 35.67160490471127 139.7377644267239 30.005 35.671612706594 139.7377707359813 30.005 35.67161569702748 139.73776805918098 30.005 35.671605730457735 139.737759996122 30.005</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-93dba22e-061b-4f40-a27c-3708efaef742">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-93dba22e-061b-4f40-a27c-3708efaef742">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-93dba22e-061b-4f40-a27c-3708efaef742">
											<gml:posList>35.671594825302996 139.73776183178214 30.005 35.671588648185846 139.7377697704792 30.005 35.671592128823164 139.73777145643365 30.005 35.671596505037535 139.7377658396327 30.005 35.671594825302996 139.73776183178214 30.005</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-080eaf19-1ebb-4f99-b3d5-5dd350f059d1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-080eaf19-1ebb-4f99-b3d5-5dd350f059d1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-080eaf19-1ebb-4f99-b3d5-5dd350f059d1">
											<gml:posList>35.67148217922152 139.73779400065365 30.005 35.67148657880227 139.73779511109848 30.005 35.67153493545393 139.73774715620547 30.005 35.671536038923804 139.73774058227093 30.005 35.67148217922152 139.73779400065365 30.005</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-318048fb-96cd-4454-8c7e-8d3dbf6f32cb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-318048fb-96cd-4454-8c7e-8d3dbf6f32cb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-318048fb-96cd-4454-8c7e-8d3dbf6f32cb">
											<gml:posList>35.67148657880227 139.73779511109848 29.546 35.671507463439006 139.7378062541367 29.546 35.6715411226415 139.7377859769921 29.546 35.67153493545393 139.73774715620547 29.546 35.67148657880227 139.73779511109848 29.546</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-44b55cb7-c9ad-4738-9175-ea6fd8eedb08">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-44b55cb7-c9ad-4738-9175-ea6fd8eedb08">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-44b55cb7-c9ad-4738-9175-ea6fd8eedb08">
											<gml:posList>35.671588710789116 139.73778050753035 30.005 35.67159220163214 139.73778369578704 30.005 35.671592128823164 139.73777145643365 30.005 35.671588648185846 139.7377697704792 30.005 35.671588710789116 139.73778050753035 30.005</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e0b48be4-8486-4165-8080-497aa812d1e0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e0b48be4-8486-4165-8080-497aa812d1e0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e0b48be4-8486-4165-8080-497aa812d1e0">
											<gml:posList>35.671551182400336 139.73778652837083 30.005 35.671552745519506 139.73777988760912 30.005 35.67154904123112 139.73778033388083 30.005 35.67154702892476 139.7377888641153 30.005 35.671551182400336 139.73778652837083 30.005</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-44273365-d3a0-4df4-b571-9d5f19b314ec">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-44273365-d3a0-4df4-b571-9d5f19b314ec">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-44273365-d3a0-4df4-b571-9d5f19b314ec">
											<gml:posList>35.671588710789116 139.73778050753035 30.005 35.671566543260944 139.73778837691006 30.005 35.67156907892113 139.73779190874362 30.005 35.67159220163214 139.73778369578704 30.005 35.671588710789116 139.73778050753035 30.005</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c1397efc-b769-4af8-899a-fa493bb6657f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c1397efc-b769-4af8-899a-fa493bb6657f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c1397efc-b769-4af8-899a-fa493bb6657f">
											<gml:posList>35.671564528692784 139.73779405717193 30.005 35.671551182400336 139.73778652837083 30.005 35.67154702892476 139.7377888641153 30.005 35.671566299886855 139.73779973292253 30.005 35.671564528692784 139.73779405717193 30.005</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a15f5371-b71d-498f-9e11-98841d4bb422">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a15f5371-b71d-498f-9e11-98841d4bb422">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a15f5371-b71d-498f-9e11-98841d4bb422">
											<gml:posList>35.671564528692784 139.73779405717193 30.005 35.671566299886855 139.73779973292253 30.005 35.67156907892113 139.73779190874362 30.005 35.671566543260944 139.73778837691006 30.005 35.671564528692784 139.73779405717193 30.005</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-324b2404-878d-47ac-9ee3-c7daffe6f91f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-324b2404-878d-47ac-9ee3-c7daffe6f91f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-324b2404-878d-47ac-9ee3-c7daffe6f91f">
											<gml:posList>35.671507463439006 139.7378062541367 34.539 35.67151086275081 139.7378076861204 34.539 35.6715399541711 139.73779015393097 34.539 35.6715411226415 139.7377859769921 34.539 35.671507463439006 139.7378062541367 34.539</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ef651063-d03d-4234-945e-74f8cf6d9eaa">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ef651063-d03d-4234-945e-74f8cf6d9eaa">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ef651063-d03d-4234-945e-74f8cf6d9eaa">
											<gml:posList>35.67160490471127 139.7377644267239 29.546 35.671596505037535 139.7377658396327 29.546 35.671592128823164 139.73777145643365 29.546 35.67159220163214 139.73778369578704 29.546 35.67156907892113 139.73779190874362 29.546 35.671566299886855 139.73779973292253 29.546 35.67154702892476 139.7377888641153 29.546 35.67154904123112 139.73778033388083 29.546 35.67153493545393 139.73774715620547 29.546 35.6715411226415 139.7377859769921 29.546 35.67155244823899 139.73781418709964 29.546 35.671631889786376 139.73785276601018 29.546 35.671612706594 139.7377707359813 29.546 35.67160490471127 139.7377644267239 29.546</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-cb0da5fb-0306-43bc-8cfa-1c2339315b8e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cb0da5fb-0306-43bc-8cfa-1c2339315b8e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cb0da5fb-0306-43bc-8cfa-1c2339315b8e">
											<gml:posList>35.6715411226415 139.7377859769921 34.539 35.6715399541711 139.73779015393097 34.539 35.671549039922326 139.7378127661721 34.539 35.67155244823899 139.73781418709964 34.539 35.6715411226415 139.7377859769921 34.539</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-4a15bdaa-2ec5-4cf4-81dd-862c37a1df30">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4a15bdaa-2ec5-4cf4-81dd-862c37a1df30">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4a15bdaa-2ec5-4cf4-81dd-862c37a1df30">
											<gml:posList>35.671549039922326 139.7378127661721 33.71 35.6715399541711 139.73779015393097 33.71 35.67151086275081 139.7378076861204 33.71 35.67151993047133 139.7378302983768 33.71 35.671549039922326 139.7378127661721 33.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-656fe2d3-081f-461d-bab3-8739ca85575e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-656fe2d3-081f-461d-bab3-8739ca85575e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-656fe2d3-081f-461d-bab3-8739ca85575e">
											<gml:posList>35.67161569702748 139.73776805918098 30.005 35.671612706594 139.7377707359813 30.005 35.671631889786376 139.73785276601018 30.005 35.67163600174204 139.737854904121 30.005 35.67161569702748 139.73776805918098 30.005</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-06b4883b-9626-4d5d-847c-5c685774542d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-06b4883b-9626-4d5d-847c-5c685774542d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-06b4883b-9626-4d5d-847c-5c685774542d">
											<gml:posList>35.67151877100436 139.7378344642568 34.539 35.67151993047133 139.7378302983768 34.539 35.67151086275081 139.7378076861204 34.539 35.671507463439006 139.7378062541367 34.539 35.67151877100436 139.7378344642568 34.539</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-85e85a70-fc4e-46e1-a68d-bcfa6b4a763c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-85e85a70-fc4e-46e1-a68d-bcfa6b4a763c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-85e85a70-fc4e-46e1-a68d-bcfa6b4a763c">
											<gml:posList>35.67155244823899 139.73781418709964 34.539 35.671549039922326 139.7378127661721 34.539 35.67151993047133 139.7378302983768 34.539 35.67151877100436 139.7378344642568 34.539 35.67155244823899 139.73781418709964 34.539</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-505ab3f0-4aa1-405e-beed-e7d4d2b469f2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-505ab3f0-4aa1-405e-beed-e7d4d2b469f2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-505ab3f0-4aa1-405e-beed-e7d4d2b469f2">
											<gml:posList>35.67151877100436 139.7378344642568 29.546 35.671507463439006 139.7378062541367 29.546 35.67148657880227 139.73779511109848 29.546 35.6715289500968 139.7378945777822 29.546 35.671631889786376 139.73785276601018 29.546 35.67155244823899 139.73781418709964 29.546 35.67151877100436 139.7378344642568 29.546</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-8cf3ea01-a36e-451d-ad48-5e3e7002e1d8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8cf3ea01-a36e-451d-ad48-5e3e7002e1d8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8cf3ea01-a36e-451d-ad48-5e3e7002e1d8">
											<gml:posList>35.67152724160489 139.73789977163207 30.005 35.6715289500968 139.7378945777822 30.005 35.67148657880227 139.73779511109848 30.005 35.67148217922152 139.73779400065365 30.005 35.67152724160489 139.73789977163207 30.005</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a83ad68a-85f2-44a4-a562-9d488412aa0f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a83ad68a-85f2-44a4-a562-9d488412aa0f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a83ad68a-85f2-44a4-a562-9d488412aa0f">
											<gml:posList>35.67163600174204 139.737854904121 30.005 35.671631889786376 139.73785276601018 30.005 35.6715289500968 139.7378945777822 30.005 35.67152724160489 139.73789977163207 30.005 35.67163600174204 139.737854904121 30.005</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-bb7501a4-3767-4db2-b43d-4d51fa347f7f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bb7501a4-3767-4db2-b43d-4d51fa347f7f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bb7501a4-3767-4db2-b43d-4d51fa347f7f">
											<gml:posList>35.671536038923804 139.73774058227093 10.73 35.67148217922152 139.73779400065365 10.73 35.67148217922152 139.73779400065365 30.005 35.671536038923804 139.73774058227093 30.005 35.671536038923804 139.73774058227093 10.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-feef5c8d-e48c-4e97-a86e-8519039927a4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-feef5c8d-e48c-4e97-a86e-8519039927a4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-feef5c8d-e48c-4e97-a86e-8519039927a4">
											<gml:posList>35.67148217922152 139.73779400065365 10.73 35.67152724160489 139.73789977163207 10.73 35.67152724160489 139.73789977163207 30.005 35.67148217922152 139.73779400065365 30.005 35.67148217922152 139.73779400065365 10.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-91bbf727-950b-49f8-91cf-e61058510ef8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-91bbf727-950b-49f8-91cf-e61058510ef8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-91bbf727-950b-49f8-91cf-e61058510ef8">
											<gml:posList>35.6715289500968 139.7378945777822 30.005 35.6715289500968 139.7378945777822 29.546 35.67148657880227 139.73779511109848 29.546 35.67148657880227 139.73779511109848 30.005 35.6715289500968 139.7378945777822 30.005</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ecf3c9d3-e3a0-4ac9-bdac-7f951b70decd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ecf3c9d3-e3a0-4ac9-bdac-7f951b70decd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ecf3c9d3-e3a0-4ac9-bdac-7f951b70decd">
											<gml:posList>35.67148657880227 139.73779511109848 30.005 35.67148657880227 139.73779511109848 29.546 35.67153493545393 139.73774715620547 29.546 35.67153493545393 139.73774715620547 30.005 35.67148657880227 139.73779511109848 30.005</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-320cb63e-9881-42be-baac-a9b33fa287f5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-320cb63e-9881-42be-baac-a9b33fa287f5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-320cb63e-9881-42be-baac-a9b33fa287f5">
											<gml:posList>35.671507463439006 139.7378062541367 34.539 35.671507463439006 139.7378062541367 29.546 35.67151877100436 139.7378344642568 29.546 35.67151877100436 139.7378344642568 34.539 35.671507463439006 139.7378062541367 34.539</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3a7327f0-cecc-4d23-99b1-82956456e457">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3a7327f0-cecc-4d23-99b1-82956456e457">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3a7327f0-cecc-4d23-99b1-82956456e457">
											<gml:posList>35.67151993047133 139.7378302983768 34.539 35.67151993047133 139.7378302983768 33.71 35.67151086275081 139.7378076861204 33.71 35.67151086275081 139.7378076861204 34.539 35.67151993047133 139.7378302983768 34.539</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-09a0643d-7fae-423e-9827-6f04465bb557">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-09a0643d-7fae-423e-9827-6f04465bb557">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-09a0643d-7fae-423e-9827-6f04465bb557">
											<gml:posList>35.671507463439006 139.7378062541367 34.539 35.6715411226415 139.7377859769921 34.539 35.6715411226415 139.7377859769921 29.546 35.671507463439006 139.7378062541367 29.546 35.671507463439006 139.7378062541367 34.539</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-47b8bfc0-f127-4138-aac1-78d1587277bb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-47b8bfc0-f127-4138-aac1-78d1587277bb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-47b8bfc0-f127-4138-aac1-78d1587277bb">
											<gml:posList>35.67151086275081 139.7378076861204 34.539 35.67151086275081 139.7378076861204 33.71 35.6715399541711 139.73779015393097 33.71 35.6715399541711 139.73779015393097 34.539 35.67151086275081 139.7378076861204 34.539</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6bc37463-02b0-438d-82f8-7f95da6a94f3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6bc37463-02b0-438d-82f8-7f95da6a94f3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6bc37463-02b0-438d-82f8-7f95da6a94f3">
											<gml:posList>35.671549039922326 139.7378127661721 34.539 35.671549039922326 139.7378127661721 33.71 35.67151993047133 139.7378302983768 33.71 35.67151993047133 139.7378302983768 34.539 35.671549039922326 139.7378127661721 34.539</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-bb1eb0fd-7c34-4e7f-b56d-37553740a699">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bb1eb0fd-7c34-4e7f-b56d-37553740a699">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bb1eb0fd-7c34-4e7f-b56d-37553740a699">
											<gml:posList>35.67151877100436 139.7378344642568 34.539 35.67151877100436 139.7378344642568 29.546 35.67155244823899 139.73781418709964 29.546 35.67155244823899 139.73781418709964 34.539 35.67151877100436 139.7378344642568 34.539</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0c5be6fc-794e-4c73-992e-a8774496ee01">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0c5be6fc-794e-4c73-992e-a8774496ee01">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0c5be6fc-794e-4c73-992e-a8774496ee01">
											<gml:posList>35.67153493545393 139.73774715620547 30.005 35.67153493545393 139.73774715620547 29.546 35.67154904123112 139.73778033388083 29.546 35.67154904123112 139.73778033388083 30.005 35.67153493545393 139.73774715620547 30.005</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d5b53395-513f-4c4d-befb-6d5fb5a6b6d4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d5b53395-513f-4c4d-befb-6d5fb5a6b6d4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d5b53395-513f-4c4d-befb-6d5fb5a6b6d4">
											<gml:posList>35.671552745519506 139.73777988760912 10.73 35.671536038923804 139.73774058227093 10.73 35.671536038923804 139.73774058227093 30.005 35.671552745519506 139.73777988760912 30.005 35.671552745519506 139.73777988760912 10.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3e79ca57-1f86-45f0-bec2-4786f0f78e1a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3e79ca57-1f86-45f0-bec2-4786f0f78e1a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3e79ca57-1f86-45f0-bec2-4786f0f78e1a">
											<gml:posList>35.6715399541711 139.73779015393097 34.539 35.6715399541711 139.73779015393097 33.71 35.671549039922326 139.7378127661721 33.71 35.671549039922326 139.7378127661721 34.539 35.6715399541711 139.73779015393097 34.539</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-92a77750-811a-48ee-8006-d9cdf97bd871">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-92a77750-811a-48ee-8006-d9cdf97bd871">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-92a77750-811a-48ee-8006-d9cdf97bd871">
											<gml:posList>35.6715411226415 139.7377859769921 34.539 35.67155244823899 139.73781418709964 34.539 35.67155244823899 139.73781418709964 29.546 35.6715411226415 139.7377859769921 29.546 35.6715411226415 139.7377859769921 34.539</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-bfd304e9-ba38-4f75-bd21-66a7e10179c4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bfd304e9-ba38-4f75-bd21-66a7e10179c4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bfd304e9-ba38-4f75-bd21-66a7e10179c4">
											<gml:posList>35.67154904123112 139.73778033388083 30.005 35.67154904123112 139.73778033388083 29.546 35.67154702892476 139.7377888641153 29.546 35.67154702892476 139.7377888641153 30.005 35.67154904123112 139.73778033388083 30.005</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e1647243-d75e-4d30-8a52-47b4bb0b349d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e1647243-d75e-4d30-8a52-47b4bb0b349d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e1647243-d75e-4d30-8a52-47b4bb0b349d">
											<gml:posList>35.671551182400336 139.73778652837083 10.73 35.671552745519506 139.73777988760912 10.73 35.671552745519506 139.73777988760912 30.005 35.671551182400336 139.73778652837083 30.005 35.671551182400336 139.73778652837083 10.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ee998721-c516-443e-861a-4e5ee10976f9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ee998721-c516-443e-861a-4e5ee10976f9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ee998721-c516-443e-861a-4e5ee10976f9">
											<gml:posList>35.67154702892476 139.7377888641153 30.005 35.67154702892476 139.7377888641153 29.546 35.671566299886855 139.73779973292253 29.546 35.671566299886855 139.73779973292253 30.005 35.67154702892476 139.7377888641153 30.005</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4713cbe9-41f4-46af-a418-15d9ffc95b69">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4713cbe9-41f4-46af-a418-15d9ffc95b69">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4713cbe9-41f4-46af-a418-15d9ffc95b69">
											<gml:posList>35.671564528692784 139.73779405717193 10.73 35.671551182400336 139.73778652837083 10.73 35.671551182400336 139.73778652837083 30.005 35.671564528692784 139.73779405717193 30.005 35.671564528692784 139.73779405717193 10.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5a45c391-362a-487c-a666-16d68a7158a5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5a45c391-362a-487c-a666-16d68a7158a5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5a45c391-362a-487c-a666-16d68a7158a5">
											<gml:posList>35.671566543260944 139.73778837691006 10.73 35.671564528692784 139.73779405717193 10.73 35.671564528692784 139.73779405717193 30.005 35.671566543260944 139.73778837691006 30.005 35.671566543260944 139.73778837691006 10.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-44f88d8e-151e-4efc-8df3-de1f7c742930">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-44f88d8e-151e-4efc-8df3-de1f7c742930">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-44f88d8e-151e-4efc-8df3-de1f7c742930">
											<gml:posList>35.671566299886855 139.73779973292253 30.005 35.671566299886855 139.73779973292253 29.546 35.67156907892113 139.73779190874362 29.546 35.67156907892113 139.73779190874362 30.005 35.671566299886855 139.73779973292253 30.005</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-cc1714f5-6290-4abd-a016-3f43b489dc4e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cc1714f5-6290-4abd-a016-3f43b489dc4e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cc1714f5-6290-4abd-a016-3f43b489dc4e">
											<gml:posList>35.671588710789116 139.73778050753035 10.73 35.671566543260944 139.73778837691006 10.73 35.671566543260944 139.73778837691006 30.005 35.671588710789116 139.73778050753035 30.005 35.671588710789116 139.73778050753035 10.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-59e0fd7e-acf6-436b-b690-8bbb207615a9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-59e0fd7e-acf6-436b-b690-8bbb207615a9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-59e0fd7e-acf6-436b-b690-8bbb207615a9">
											<gml:posList>35.671631889786376 139.73785276601018 30.005 35.671631889786376 139.73785276601018 29.546 35.6715289500968 139.7378945777822 29.546 35.6715289500968 139.7378945777822 30.005 35.671631889786376 139.73785276601018 30.005</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-97a3d694-8521-40a2-bbe9-c234567c9f8c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-97a3d694-8521-40a2-bbe9-c234567c9f8c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-97a3d694-8521-40a2-bbe9-c234567c9f8c">
											<gml:posList>35.67156907892113 139.73779190874362 30.005 35.67156907892113 139.73779190874362 29.546 35.67159220163214 139.73778369578704 29.546 35.67159220163214 139.73778369578704 30.005 35.67156907892113 139.73779190874362 30.005</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-afcb9bfa-e391-49f3-a507-d69283e23024">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-afcb9bfa-e391-49f3-a507-d69283e23024">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-afcb9bfa-e391-49f3-a507-d69283e23024">
											<gml:posList>35.67152724160489 139.73789977163207 10.73 35.67163600174204 139.737854904121 10.73 35.67163600174204 139.737854904121 30.005 35.67152724160489 139.73789977163207 30.005 35.67152724160489 139.73789977163207 10.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b1b26f40-6db5-483f-9d37-e238e8836d9b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b1b26f40-6db5-483f-9d37-e238e8836d9b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b1b26f40-6db5-483f-9d37-e238e8836d9b">
											<gml:posList>35.671588710789116 139.73778050753035 10.73 35.671588710789116 139.73778050753035 30.005 35.671588648185846 139.7377697704792 30.005 35.671588648185846 139.7377697704792 10.73 35.671588710789116 139.73778050753035 10.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9285a72f-9ad4-42d4-88a2-c49dc2e32ed3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9285a72f-9ad4-42d4-88a2-c49dc2e32ed3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9285a72f-9ad4-42d4-88a2-c49dc2e32ed3">
											<gml:posList>35.671594825302996 139.73776183178214 30.005 35.671594825302996 139.73776183178214 10.73 35.671588648185846 139.7377697704792 10.73 35.671588648185846 139.7377697704792 30.005 35.671594825302996 139.73776183178214 30.005</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f0660930-19ff-426f-a223-66f81569976a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f0660930-19ff-426f-a223-66f81569976a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f0660930-19ff-426f-a223-66f81569976a">
											<gml:posList>35.67159220163214 139.73778369578704 30.005 35.67159220163214 139.73778369578704 29.546 35.671592128823164 139.73777145643365 29.546 35.671592128823164 139.73777145643365 30.005 35.67159220163214 139.73778369578704 30.005</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4405bef7-2ff3-4ea4-847d-4280f21b0852">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4405bef7-2ff3-4ea4-847d-4280f21b0852">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4405bef7-2ff3-4ea4-847d-4280f21b0852">
											<gml:posList>35.671592128823164 139.73777145643365 30.005 35.671592128823164 139.73777145643365 29.546 35.671596505037535 139.7377658396327 29.546 35.671596505037535 139.7377658396327 30.005 35.671592128823164 139.73777145643365 30.005</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8fb64bfc-b8e0-40ac-a2b7-32f580f40a13">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8fb64bfc-b8e0-40ac-a2b7-32f580f40a13">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8fb64bfc-b8e0-40ac-a2b7-32f580f40a13">
											<gml:posList>35.671594825302996 139.73776183178214 10.73 35.671594825302996 139.73776183178214 30.005 35.671605730457735 139.737759996122 30.005 35.671605730457735 139.737759996122 10.73 35.671594825302996 139.73776183178214 10.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9b003a94-f1fa-419a-ac62-ed56bcea2b2d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9b003a94-f1fa-419a-ac62-ed56bcea2b2d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9b003a94-f1fa-419a-ac62-ed56bcea2b2d">
											<gml:posList>35.671596505037535 139.7377658396327 30.005 35.671596505037535 139.7377658396327 29.546 35.67160490471127 139.7377644267239 29.546 35.67160490471127 139.7377644267239 30.005 35.671596505037535 139.7377658396327 30.005</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f7943183-d746-4cb2-84c7-12c77f3a3989">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f7943183-d746-4cb2-84c7-12c77f3a3989">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f7943183-d746-4cb2-84c7-12c77f3a3989">
											<gml:posList>35.67160490471127 139.7377644267239 30.005 35.67160490471127 139.7377644267239 29.546 35.671612706594 139.7377707359813 29.546 35.671612706594 139.7377707359813 30.005 35.67160490471127 139.7377644267239 30.005</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-781c0661-b22b-481f-824e-1c8a8aaef09b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-781c0661-b22b-481f-824e-1c8a8aaef09b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-781c0661-b22b-481f-824e-1c8a8aaef09b">
											<gml:posList>35.67161569702748 139.73776805918098 30.005 35.67161569702748 139.73776805918098 10.73 35.671605730457735 139.737759996122 10.73 35.671605730457735 139.737759996122 30.005 35.67161569702748 139.73776805918098 30.005</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-61c8725a-3f53-4a8c-8a84-83f80d4bf786">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-61c8725a-3f53-4a8c-8a84-83f80d4bf786">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-61c8725a-3f53-4a8c-8a84-83f80d4bf786">
											<gml:posList>35.671612706594 139.7377707359813 30.005 35.671612706594 139.7377707359813 29.546 35.671631889786376 139.73785276601018 29.546 35.671631889786376 139.73785276601018 30.005 35.671612706594 139.7377707359813 30.005</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-287f9690-7021-484b-9351-ea6bf8f9e457">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-287f9690-7021-484b-9351-ea6bf8f9e457">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-287f9690-7021-484b-9351-ea6bf8f9e457">
											<gml:posList>35.67163600174204 139.737854904121 10.73 35.67161569702748 139.73776805918098 10.73 35.67161569702748 139.73776805918098 30.005 35.67163600174204 139.737854904121 30.005 35.67163600174204 139.737854904121 10.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-6627</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">143.6528</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1210</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>5</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.03</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>