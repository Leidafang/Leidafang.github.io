<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_e25ce5cd-7a02-4349-897d-5fd86ce74597">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="地区計画">
				<gen:value>赤坂二丁目地区</gen:value>
			</gen:stringAttribute>
			<bldg:measuredHeight uom="m">6</bldg:measuredHeight>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.6703341693633 139.74005471398266 0 35.67033814902278 139.74007229498847 0 35.67037651037815 139.7400592599668 0 35.67037253070824 139.74004166790698 0 35.6703341693633 139.74005471398266 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6703341693633 139.74005471398266 14.37 35.67037253070824 139.74004166790698 14.37 35.67037651037815 139.7400592599668 14.37 35.67033814902278 139.74007229498847 14.37 35.6703341693633 139.74005471398266 14.37</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6703341693633 139.74005471398266 14.37 35.67033814902278 139.74007229498847 14.37 35.67033814902278 139.74007229498847 20.38 35.6703341693633 139.74005471398266 20.38 35.6703341693633 139.74005471398266 14.37</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67033814902278 139.74007229498847 14.37 35.67037651037815 139.7400592599668 14.37 35.67037651037815 139.7400592599668 20.38 35.67033814902278 139.74007229498847 20.38 35.67033814902278 139.74007229498847 14.37</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67037651037815 139.7400592599668 14.37 35.67037253070824 139.74004166790698 14.37 35.67037253070824 139.74004166790698 20.38 35.67037651037815 139.7400592599668 20.38 35.67037651037815 139.7400592599668 14.37</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67037253070824 139.74004166790698 14.37 35.6703341693633 139.74005471398266 14.37 35.6703341693633 139.74005471398266 20.38 35.67037253070824 139.74004166790698 20.38 35.67037253070824 139.74004166790698 14.37</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6703341693633 139.74005471398266 20.38 35.67033814902278 139.74007229498847 20.38 35.67037651037815 139.7400592599668 20.38 35.67037253070824 139.74004166790698 20.38 35.6703341693633 139.74005471398266 20.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-55b3c7a5-0a41-4295-aa6b-94e05bdb3625"/>
							<gml:surfaceMember xlink:href="#poly-f3dfcc3a-6a62-479a-9f32-ed0fb5304194"/>
							<gml:surfaceMember xlink:href="#poly-fe680254-8f5b-43ba-a8f1-b8fd869a7fa8"/>
							<gml:surfaceMember xlink:href="#poly-6790bc31-8f3c-42d9-942d-954bb99c422a"/>
							<gml:surfaceMember xlink:href="#poly-a3467bfd-2d34-4ee5-b537-78289b665b84"/>
							<gml:surfaceMember xlink:href="#poly-53629ea4-d122-4f6f-bfa5-86dbd0ca11de"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-55b3c7a5-0a41-4295-aa6b-94e05bdb3625">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-55b3c7a5-0a41-4295-aa6b-94e05bdb3625">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-55b3c7a5-0a41-4295-aa6b-94e05bdb3625">
											<gml:posList>35.67033416936331 139.74005471398266 14.37 35.670372530708214 139.74004166790698 14.37 35.670376510378134 139.7400592599668 14.37 35.67033814902276 139.74007229498847 14.37 35.67033416936331 139.74005471398266 14.37</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f3dfcc3a-6a62-479a-9f32-ed0fb5304194">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f3dfcc3a-6a62-479a-9f32-ed0fb5304194">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f3dfcc3a-6a62-479a-9f32-ed0fb5304194">
											<gml:posList>35.670372530708214 139.74004166790698 20.686 35.67033416936331 139.74005471398266 20.686 35.67033814902276 139.74007229498847 20.686 35.670376510378134 139.7400592599668 20.686 35.670372530708214 139.74004166790698 20.686</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-fe680254-8f5b-43ba-a8f1-b8fd869a7fa8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fe680254-8f5b-43ba-a8f1-b8fd869a7fa8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fe680254-8f5b-43ba-a8f1-b8fd869a7fa8">
											<gml:posList>35.670372530708214 139.74004166790698 14.37 35.67033416936331 139.74005471398266 14.37 35.67033416936331 139.74005471398266 20.686 35.670372530708214 139.74004166790698 20.686 35.670372530708214 139.74004166790698 14.37</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6790bc31-8f3c-42d9-942d-954bb99c422a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6790bc31-8f3c-42d9-942d-954bb99c422a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6790bc31-8f3c-42d9-942d-954bb99c422a">
											<gml:posList>35.670376510378134 139.7400592599668 14.37 35.670372530708214 139.74004166790698 14.37 35.670372530708214 139.74004166790698 20.686 35.670376510378134 139.7400592599668 20.686 35.670376510378134 139.7400592599668 14.37</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a3467bfd-2d34-4ee5-b537-78289b665b84">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a3467bfd-2d34-4ee5-b537-78289b665b84">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a3467bfd-2d34-4ee5-b537-78289b665b84">
											<gml:posList>35.67033416936331 139.74005471398266 14.37 35.67033814902276 139.74007229498847 14.37 35.67033814902276 139.74007229498847 20.686 35.67033416936331 139.74005471398266 20.686 35.67033416936331 139.74005471398266 14.37</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-53629ea4-d122-4f6f-bfa5-86dbd0ca11de">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-53629ea4-d122-4f6f-bfa5-86dbd0ca11de">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-53629ea4-d122-4f6f-bfa5-86dbd0ca11de">
											<gml:posList>35.67033814902276 139.74007229498847 14.37 35.670376510378134 139.7400592599668 14.37 35.670376510378134 139.7400592599668 20.686 35.67033814902276 139.74007229498847 20.686 35.67033814902276 139.74007229498847 14.37</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-3503</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">211</uro:landUseType>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>4</uro:specifiedFloorAreaRate>
					<uro:surveyYear>0001</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>