<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_e291ea27-d96e-44ee-8e35-32f053223952">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="再開発等促進区を定める地区計画">
				<gen:value>赤坂一丁目地区</gen:value>
			</gen:stringAttribute>
			<bldg:measuredHeight uom="m">4.4</bldg:measuredHeight>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.66967697456465 139.74310183347677 0 35.66967336098342 139.7431391625259 0 35.66970537223509 139.7431438211372 0 35.669708994831495 139.74310649206325 0 35.66967697456465 139.74310183347677 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66967697456465 139.74310183347677 13.16 35.669708994831495 139.74310649206325 13.16 35.66970537223509 139.7431438211372 13.16 35.66967336098342 139.7431391625259 13.16 35.66967697456465 139.74310183347677 13.16</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66967697456465 139.74310183347677 13.16 35.66967336098342 139.7431391625259 13.16 35.66967336098342 139.7431391625259 17.57 35.66967697456465 139.74310183347677 17.57 35.66967697456465 139.74310183347677 13.16</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66967336098342 139.7431391625259 13.16 35.66970537223509 139.7431438211372 13.16 35.66970537223509 139.7431438211372 17.57 35.66967336098342 139.7431391625259 17.57 35.66967336098342 139.7431391625259 13.16</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66970537223509 139.7431438211372 13.16 35.669708994831495 139.74310649206325 13.16 35.669708994831495 139.74310649206325 17.57 35.66970537223509 139.7431438211372 17.57 35.66970537223509 139.7431438211372 13.16</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669708994831495 139.74310649206325 13.16 35.66967697456465 139.74310183347677 13.16 35.66967697456465 139.74310183347677 17.57 35.669708994831495 139.74310649206325 17.57 35.669708994831495 139.74310649206325 13.16</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66967697456465 139.74310183347677 17.57 35.66967336098342 139.7431391625259 17.57 35.66970537223509 139.7431438211372 17.57 35.669708994831495 139.74310649206325 17.57 35.66967697456465 139.74310183347677 17.57</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-d00d3895-6b0b-4fa8-bd60-01f4b6183314"/>
							<gml:surfaceMember xlink:href="#poly-935e6048-a5d4-49a5-b1e2-85e4a415639e"/>
							<gml:surfaceMember xlink:href="#poly-ac20017d-846c-4f7a-b4fc-0103ca57a3b9"/>
							<gml:surfaceMember xlink:href="#poly-c62c0d29-fe2d-40a4-9188-d5a3c239aa97"/>
							<gml:surfaceMember xlink:href="#poly-4f39068f-6202-437c-88e2-9ad96f99b0de"/>
							<gml:surfaceMember xlink:href="#poly-f4b34dbb-232b-4ecb-a1cf-81d798e30959"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-d00d3895-6b0b-4fa8-bd60-01f4b6183314">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d00d3895-6b0b-4fa8-bd60-01f4b6183314">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d00d3895-6b0b-4fa8-bd60-01f4b6183314">
											<gml:posList>35.66967697456465 139.74310183347674 13.16 35.669708994831495 139.74310649206325 13.16 35.6697053722351 139.7431438211372 13.16 35.66967336098339 139.74313916252586 13.16 35.66967697456465 139.74310183347674 13.16</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-935e6048-a5d4-49a5-b1e2-85e4a415639e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-935e6048-a5d4-49a5-b1e2-85e4a415639e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-935e6048-a5d4-49a5-b1e2-85e4a415639e">
											<gml:posList>35.669708994831495 139.74310649206325 17.489 35.66967697456465 139.74310183347674 17.489 35.66967336098339 139.74313916252586 17.489 35.6697053722351 139.7431438211372 17.489 35.669708994831495 139.74310649206325 17.489</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ac20017d-846c-4f7a-b4fc-0103ca57a3b9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ac20017d-846c-4f7a-b4fc-0103ca57a3b9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ac20017d-846c-4f7a-b4fc-0103ca57a3b9">
											<gml:posList>35.66967697456465 139.74310183347674 13.16 35.66967336098339 139.74313916252586 13.16 35.66967336098339 139.74313916252586 17.489 35.66967697456465 139.74310183347674 17.489 35.66967697456465 139.74310183347674 13.16</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c62c0d29-fe2d-40a4-9188-d5a3c239aa97">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c62c0d29-fe2d-40a4-9188-d5a3c239aa97">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c62c0d29-fe2d-40a4-9188-d5a3c239aa97">
											<gml:posList>35.669708994831495 139.74310649206325 13.16 35.66967697456465 139.74310183347674 13.16 35.66967697456465 139.74310183347674 17.489 35.669708994831495 139.74310649206325 17.489 35.669708994831495 139.74310649206325 13.16</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4f39068f-6202-437c-88e2-9ad96f99b0de">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4f39068f-6202-437c-88e2-9ad96f99b0de">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4f39068f-6202-437c-88e2-9ad96f99b0de">
											<gml:posList>35.6697053722351 139.7431438211372 13.16 35.669708994831495 139.74310649206325 13.16 35.669708994831495 139.74310649206325 17.489 35.6697053722351 139.7431438211372 17.489 35.6697053722351 139.7431438211372 13.16</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f4b34dbb-232b-4ecb-a1cf-81d798e30959">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f4b34dbb-232b-4ecb-a1cf-81d798e30959">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f4b34dbb-232b-4ecb-a1cf-81d798e30959">
											<gml:posList>35.66967336098339 139.74313916252586 13.16 35.6697053722351 139.7431438211372 13.16 35.6697053722351 139.7431438211372 17.489 35.66967336098339 139.74313916252586 17.489 35.66967336098339 139.74313916252586 13.16</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-540</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>6</uro:specifiedFloorAreaRate>
					<uro:surveyYear>0001</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">2</uro:rank>
					<uro:depth uom="m">0.74</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>