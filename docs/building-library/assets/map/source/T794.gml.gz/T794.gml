<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_e316cfea-eb49-4c0a-bbf9-bfd597efd5f8">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>0.80</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001002</gen:value>
			</gen:stringAttribute>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">403</bldg:usage>
			<bldg:measuredHeight uom="m">8.2</bldg:measuredHeight>
			<bldg:storeysAboveGround>16</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.67249468925802 139.73891125731467 0 35.67256881443067 139.73901001463966 0 35.67258051289292 139.7389967781408 0 35.672587496806834 139.73900608217588 0 35.672591873649274 139.73900119444488 0 35.67254087069251 139.73888201792064 0 35.67249468925802 139.73891125731467 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67249468925802 139.73891125731467 9.41 35.67254087069251 139.73888201792064 9.41 35.672591873649274 139.73900119444488 9.41 35.672587496806834 139.73900608217588 9.41 35.67258051289292 139.7389967781408 9.41 35.67256881443067 139.73901001463966 9.41 35.67249468925802 139.73891125731467 9.41</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67249468925802 139.73891125731467 9.41 35.67256881443067 139.73901001463966 9.41 35.67256881443067 139.73901001463966 17.62 35.67249468925802 139.73891125731467 17.62 35.67249468925802 139.73891125731467 9.41</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67256881443067 139.73901001463966 9.41 35.67258051289292 139.7389967781408 9.41 35.67258051289292 139.7389967781408 17.62 35.67256881443067 139.73901001463966 17.62 35.67256881443067 139.73901001463966 9.41</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67258051289292 139.7389967781408 9.41 35.672587496806834 139.73900608217588 9.41 35.672587496806834 139.73900608217588 17.62 35.67258051289292 139.7389967781408 17.62 35.67258051289292 139.7389967781408 9.41</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672587496806834 139.73900608217588 9.41 35.672591873649274 139.73900119444488 9.41 35.672591873649274 139.73900119444488 17.62 35.672587496806834 139.73900608217588 17.62 35.672587496806834 139.73900608217588 9.41</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672591873649274 139.73900119444488 9.41 35.67254087069251 139.73888201792064 9.41 35.67254087069251 139.73888201792064 17.62 35.672591873649274 139.73900119444488 17.62 35.672591873649274 139.73900119444488 9.41</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67254087069251 139.73888201792064 9.41 35.67249468925802 139.73891125731467 9.41 35.67249468925802 139.73891125731467 17.62 35.67254087069251 139.73888201792064 17.62 35.67254087069251 139.73888201792064 9.41</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67249468925802 139.73891125731467 17.62 35.67256881443067 139.73901001463966 17.62 35.67258051289292 139.7389967781408 17.62 35.672587496806834 139.73900608217588 17.62 35.672591873649274 139.73900119444488 17.62 35.67254087069251 139.73888201792064 17.62 35.67249468925802 139.73891125731467 17.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-31ba41d8-31fe-45f4-bcb4-a78368c80b2a"/>
							<gml:surfaceMember xlink:href="#poly-5d9a2720-7e7b-4788-96b0-28550a5fd20d"/>
							<gml:surfaceMember xlink:href="#poly-9eb8c472-e306-4f4f-9f4d-849e8e913217"/>
							<gml:surfaceMember xlink:href="#poly-61656802-dc67-41a0-915e-e1a32c28fa1b"/>
							<gml:surfaceMember xlink:href="#poly-f343fe5b-f995-43fe-a635-6d75476cee15"/>
							<gml:surfaceMember xlink:href="#poly-c8218398-2b7f-47e1-9c25-f57bc38e313d"/>
							<gml:surfaceMember xlink:href="#poly-ace1f0a0-9fc0-4b1d-9648-928ca50eb556"/>
							<gml:surfaceMember xlink:href="#poly-965afa57-38de-4f82-a91c-1ad6e79c804a"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-31ba41d8-31fe-45f4-bcb4-a78368c80b2a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-31ba41d8-31fe-45f4-bcb4-a78368c80b2a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-31ba41d8-31fe-45f4-bcb4-a78368c80b2a">
											<gml:posList>35.6725408706925 139.73888201792064 9.41 35.672591873649246 139.73900119444488 9.41 35.67258749680684 139.73900608217585 9.41 35.672580512892914 139.73899677814083 9.41 35.672568814430655 139.73901001463963 9.41 35.672494689257995 139.73891125731464 9.41 35.6725408706925 139.73888201792064 9.41</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-5d9a2720-7e7b-4788-96b0-28550a5fd20d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5d9a2720-7e7b-4788-96b0-28550a5fd20d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5d9a2720-7e7b-4788-96b0-28550a5fd20d">
											<gml:posList>35.6725408706925 139.73888201792064 17.231 35.672494689257995 139.73891125731464 17.231 35.672568814430655 139.73901001463963 17.231 35.672580512892914 139.73899677814083 17.231 35.67258749680684 139.73900608217585 17.231 35.672591873649246 139.73900119444488 17.231 35.6725408706925 139.73888201792064 17.231</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9eb8c472-e306-4f4f-9f4d-849e8e913217">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9eb8c472-e306-4f4f-9f4d-849e8e913217">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9eb8c472-e306-4f4f-9f4d-849e8e913217">
											<gml:posList>35.6725408706925 139.73888201792064 17.231 35.6725408706925 139.73888201792064 9.41 35.672494689257995 139.73891125731464 9.41 35.672494689257995 139.73891125731464 17.231 35.6725408706925 139.73888201792064 17.231</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-61656802-dc67-41a0-915e-e1a32c28fa1b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-61656802-dc67-41a0-915e-e1a32c28fa1b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-61656802-dc67-41a0-915e-e1a32c28fa1b">
											<gml:posList>35.672591873649246 139.73900119444488 17.231 35.672591873649246 139.73900119444488 9.41 35.6725408706925 139.73888201792064 9.41 35.6725408706925 139.73888201792064 17.231 35.672591873649246 139.73900119444488 17.231</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f343fe5b-f995-43fe-a635-6d75476cee15">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f343fe5b-f995-43fe-a635-6d75476cee15">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f343fe5b-f995-43fe-a635-6d75476cee15">
											<gml:posList>35.672494689257995 139.73891125731464 17.231 35.672494689257995 139.73891125731464 9.41 35.672568814430655 139.73901001463963 9.41 35.672568814430655 139.73901001463963 17.231 35.672494689257995 139.73891125731464 17.231</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c8218398-2b7f-47e1-9c25-f57bc38e313d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c8218398-2b7f-47e1-9c25-f57bc38e313d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c8218398-2b7f-47e1-9c25-f57bc38e313d">
											<gml:posList>35.672580512892914 139.73899677814083 17.231 35.672580512892914 139.73899677814083 9.41 35.67258749680684 139.73900608217585 9.41 35.67258749680684 139.73900608217585 17.231 35.672580512892914 139.73899677814083 17.231</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ace1f0a0-9fc0-4b1d-9648-928ca50eb556">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ace1f0a0-9fc0-4b1d-9648-928ca50eb556">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ace1f0a0-9fc0-4b1d-9648-928ca50eb556">
											<gml:posList>35.672568814430655 139.73901001463963 17.231 35.672568814430655 139.73901001463963 9.41 35.672580512892914 139.73899677814083 9.41 35.672580512892914 139.73899677814083 17.231 35.672568814430655 139.73901001463963 17.231</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-965afa57-38de-4f82-a91c-1ad6e79c804a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-965afa57-38de-4f82-a91c-1ad6e79c804a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-965afa57-38de-4f82-a91c-1ad6e79c804a">
											<gml:posList>35.67258749680684 139.73900608217585 17.231 35.67258749680684 139.73900608217585 9.41 35.672591873649246 139.73900119444488 9.41 35.672591873649246 139.73900119444488 17.231 35.67258749680684 139.73900608217585 17.231</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-11034</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">922.78442</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1241</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>6</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.01</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">2</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">2</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>