<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_e54da6aa-8582-47d9-987a-9c25d960b9a1">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>18</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103018001</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="再開発等促進区を定める地区計画">
				<gen:value>虎ノ門駅南地区</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">401</bldg:usage>
			<bldg:measuredHeight uom="m">30</bldg:measuredHeight>
			<bldg:storeysAboveGround>9</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>2</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.66937724741279 139.74946993967865 0 35.66930159485404 139.74943069464828 0 35.669289334807644 139.74946754625432 0 35.669248794951045 139.74944728591734 0 35.66915802714293 139.74972014202766 0 35.66931726605745 139.74980138583157 0 35.66939515794803 139.7495609410122 0 35.669353230209055 139.74954099134305 0 35.66937724741279 139.74946993967865 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66937724741279 139.74946993967865 6.26 35.669353230209055 139.74954099134305 6.26 35.66939515794803 139.7495609410122 6.26 35.66931726605745 139.74980138583157 6.26 35.66915802714293 139.74972014202766 6.26 35.669248794951045 139.74944728591734 6.26 35.669289334807644 139.74946754625432 6.26 35.66930159485404 139.74943069464828 6.26 35.66937724741279 139.74946993967865 6.26</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66937724741279 139.74946993967865 6.26 35.66930159485404 139.74943069464828 6.26 35.66930159485404 139.74943069464828 35.64 35.66937724741279 139.74946993967865 35.64 35.66937724741279 139.74946993967865 6.26</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66930159485404 139.74943069464828 6.26 35.669289334807644 139.74946754625432 6.26 35.669289334807644 139.74946754625432 35.64 35.66930159485404 139.74943069464828 35.64 35.66930159485404 139.74943069464828 6.26</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669289334807644 139.74946754625432 6.26 35.669248794951045 139.74944728591734 6.26 35.669248794951045 139.74944728591734 35.64 35.669289334807644 139.74946754625432 35.64 35.669289334807644 139.74946754625432 6.26</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669248794951045 139.74944728591734 6.26 35.66915802714293 139.74972014202766 6.26 35.66915802714293 139.74972014202766 35.64 35.669248794951045 139.74944728591734 35.64 35.669248794951045 139.74944728591734 6.26</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66915802714293 139.74972014202766 6.26 35.66931726605745 139.74980138583157 6.26 35.66931726605745 139.74980138583157 35.64 35.66915802714293 139.74972014202766 35.64 35.66915802714293 139.74972014202766 6.26</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66931726605745 139.74980138583157 6.26 35.66939515794803 139.7495609410122 6.26 35.66939515794803 139.7495609410122 35.64 35.66931726605745 139.74980138583157 35.64 35.66931726605745 139.74980138583157 6.26</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66939515794803 139.7495609410122 6.26 35.669353230209055 139.74954099134305 6.26 35.669353230209055 139.74954099134305 35.64 35.66939515794803 139.7495609410122 35.64 35.66939515794803 139.7495609410122 6.26</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669353230209055 139.74954099134305 6.26 35.66937724741279 139.74946993967865 6.26 35.66937724741279 139.74946993967865 35.64 35.669353230209055 139.74954099134305 35.64 35.669353230209055 139.74954099134305 6.26</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66937724741279 139.74946993967865 35.64 35.66930159485404 139.74943069464828 35.64 35.669289334807644 139.74946754625432 35.64 35.669248794951045 139.74944728591734 35.64 35.66915802714293 139.74972014202766 35.64 35.66931726605745 139.74980138583157 35.64 35.66939515794803 139.7495609410122 35.64 35.669353230209055 139.74954099134305 35.64 35.66937724741279 139.74946993967865 35.64</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-1030b5f9-98b9-4ff0-aa82-9d78ae5cc615"/>
							<gml:surfaceMember xlink:href="#poly-9aaf9868-3b89-40ee-a27e-7428dd3706fa"/>
							<gml:surfaceMember xlink:href="#poly-6702c512-0e61-4faf-9487-7c5e15f8ff9e"/>
							<gml:surfaceMember xlink:href="#poly-4d3e58de-03d2-48d8-a659-a01ff70a2898"/>
							<gml:surfaceMember xlink:href="#poly-40b5a0f6-d544-4a03-8341-7102a2f65e8c"/>
							<gml:surfaceMember xlink:href="#poly-9df51f47-d585-44ab-9877-731a46ae369e"/>
							<gml:surfaceMember xlink:href="#poly-d6b71e9f-0110-4942-adbc-30a33681e822"/>
							<gml:surfaceMember xlink:href="#poly-84331ce4-fa5c-4c6f-9e0d-df1569cc7c7b"/>
							<gml:surfaceMember xlink:href="#poly-f681637b-f1cc-4041-9a5f-7a09398dc07e"/>
							<gml:surfaceMember xlink:href="#poly-ae560dbe-cc56-4e54-95d6-f9b5720f94c5"/>
							<gml:surfaceMember xlink:href="#poly-a0601e2e-9c2c-4adc-80cc-0849e3179721"/>
							<gml:surfaceMember xlink:href="#poly-f40f6872-2ab5-4ced-ab91-14672ef9039e"/>
							<gml:surfaceMember xlink:href="#poly-101d95cb-7c5f-408a-b014-b2597b15c4bc"/>
							<gml:surfaceMember xlink:href="#poly-3c054479-4da4-44f9-82cb-90c9ddccdf2c"/>
							<gml:surfaceMember xlink:href="#poly-e11e46b2-3ddc-4ab6-805d-5a7f4a15856f"/>
							<gml:surfaceMember xlink:href="#poly-97a86b35-321a-4dc1-864b-51f154817ade"/>
							<gml:surfaceMember xlink:href="#poly-95e6000f-deb6-47cb-b9ff-81914935eecc"/>
							<gml:surfaceMember xlink:href="#poly-7a29dc91-11ba-451a-93b1-3e4e1a7134a3"/>
							<gml:surfaceMember xlink:href="#poly-637ab191-c6ce-4c3c-aaa4-8dcab443d954"/>
							<gml:surfaceMember xlink:href="#poly-2d3ab704-4bdd-40f4-8fbb-efffda735888"/>
							<gml:surfaceMember xlink:href="#poly-bbc094d0-5303-40a0-9fd1-9ade032d7cdb"/>
							<gml:surfaceMember xlink:href="#poly-9449a09a-c32f-40c9-aa7c-d0a61ddf8a06"/>
							<gml:surfaceMember xlink:href="#poly-66513980-b566-4283-8ae4-63a81f0b15dd"/>
							<gml:surfaceMember xlink:href="#poly-ebb8f666-01fa-4483-bcfe-b3a5428b623b"/>
							<gml:surfaceMember xlink:href="#poly-72a4e057-516a-4a53-99a4-31bcf623c9ca"/>
							<gml:surfaceMember xlink:href="#poly-97c08fb2-1981-4489-a0b1-43e7836d2959"/>
							<gml:surfaceMember xlink:href="#poly-26ceb508-2a83-4d2c-93a0-09f95b8d5196"/>
							<gml:surfaceMember xlink:href="#poly-2c3a9d9a-ba99-4d57-81c8-1b5a802dd022"/>
							<gml:surfaceMember xlink:href="#poly-78c15e61-cd0b-4ed1-82f8-9c26b7887eee"/>
							<gml:surfaceMember xlink:href="#poly-0938939a-5e37-478a-b974-4be8b62517a9"/>
							<gml:surfaceMember xlink:href="#poly-fb7a4075-3e63-4ac6-af80-275eab4a4a4f"/>
							<gml:surfaceMember xlink:href="#poly-0b8721c0-87df-49db-889a-a5a5d12313c9"/>
							<gml:surfaceMember xlink:href="#poly-e56b989d-6208-4791-8a46-5001bef7963f"/>
							<gml:surfaceMember xlink:href="#poly-148a5f43-fe78-4bc0-b552-a67cd03ed860"/>
							<gml:surfaceMember xlink:href="#poly-ea423df6-33ab-41cb-af25-80f3fc416315"/>
							<gml:surfaceMember xlink:href="#poly-aa657cb7-cca5-4d6b-96bd-4edf75fde43e"/>
							<gml:surfaceMember xlink:href="#poly-c8fe1499-1e33-4ce0-a841-55cfa2463fe6"/>
							<gml:surfaceMember xlink:href="#poly-6c464ba0-7d5a-4097-910e-63e4bcb94fc1"/>
							<gml:surfaceMember xlink:href="#poly-e482546c-4d81-4bb2-a378-f9dd25c45b0e"/>
							<gml:surfaceMember xlink:href="#poly-57f787f4-5a34-4e2d-b9c8-d4de56846bc4"/>
							<gml:surfaceMember xlink:href="#poly-8829d6db-6eea-45ac-a4e4-e8fa9e496a6b"/>
							<gml:surfaceMember xlink:href="#poly-f49ae821-c0f9-4ab4-8ed2-56770b287d22"/>
							<gml:surfaceMember xlink:href="#poly-004ca533-9b94-4bcd-ab70-da10c5b39509"/>
							<gml:surfaceMember xlink:href="#poly-25ab1b22-26df-419c-a6a9-089bba75f0bd"/>
							<gml:surfaceMember xlink:href="#poly-bd59c63e-777c-42fc-98a5-66be1f07ef68"/>
							<gml:surfaceMember xlink:href="#poly-6a00f9d9-8fc9-4c2e-8e1f-2de5e23a72cb"/>
							<gml:surfaceMember xlink:href="#poly-38cef15a-9f5b-494a-a82f-3f17b1c272b7"/>
							<gml:surfaceMember xlink:href="#poly-66009606-7021-4ad4-b079-10183ba7b8af"/>
							<gml:surfaceMember xlink:href="#poly-1ba999b0-b98d-4ebd-8cd1-5de7ab7814df"/>
							<gml:surfaceMember xlink:href="#poly-bf8e10c3-a489-4f23-83b3-4d6558bc0e12"/>
							<gml:surfaceMember xlink:href="#poly-7c881306-48b3-4f36-94b3-b0d5dac969cb"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_e54da6aa-8582-47d9-987a-9c25d960b9a1_BuildingInstallation_1041">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-28d4acc2-f038-4e64-9c22-0d715b1815cc">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669299128461866 139.74961684629807 35.196 35.66927852490041 139.74960651760648 35.196 35.66930802844639 139.74951811789725 35.196 35.6693286410367 139.74952845760657 35.196 35.669299128461866 139.74961684629807 35.196</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-29ff9a86-ce5d-40b2-b0e9-3c890571f657">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66918882728324 139.74962963133524 35.9 35.66922164963996 139.7495307786539 35.9 35.66922543670432 139.7495326414869 35.9 35.669192551257694 139.7496315052841 35.9 35.66918882728324 139.74962963133524 35.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d086569c-54a4-435e-8963-a63dce2d0b18">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669232180444084 139.74965140212913 35.196 35.669192551257694 139.7496315052841 35.196 35.66922543670432 139.7495326414869 35.196 35.6692651108755 139.7495523946448 35.196 35.669232180444084 139.74965140212913 35.196</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ec4880e8-b009-4e9d-962d-2a91c7392be1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ec4880e8-b009-4e9d-962d-2a91c7392be1_0">
											<gml:posList>35.66922164963996 139.7495307786539 35.9 35.66918882728324 139.74962963133524 35.9 35.66918882728324 139.74962963133524 40.49 35.66922164963996 139.7495307786539 40.49 35.66922164963996 139.7495307786539 35.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7c093f14-5119-417e-896c-0c49d9604aa3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7c093f14-5119-417e-896c-0c49d9604aa3_0">
											<gml:posList>35.66922543670432 139.7495326414869 35.9 35.66922543670432 139.7495326414869 35.196 35.669192551257694 139.7496315052841 35.196 35.669192551257694 139.7496315052841 35.9 35.66922543670432 139.7495326414869 35.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3990051b-484e-4a55-bbad-8a6dea952fdc">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3990051b-484e-4a55-bbad-8a6dea952fdc_0">
											<gml:posList>35.669232180444084 139.74965140212913 35.196 35.669232180444084 139.74965140212913 40.49 35.66918882728324 139.74962963133524 40.49 35.66918882728324 139.74962963133524 35.9 35.669192551257694 139.7496315052841 35.9 35.669192551257694 139.7496315052841 35.196 35.669232180444084 139.74965140212913 35.196</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bddc72a6-f013-4cda-9e22-bbd9516dbcd7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bddc72a6-f013-4cda-9e22-bbd9516dbcd7_0">
											<gml:posList>35.66922164963996 139.7495307786539 40.49 35.66918882728324 139.74962963133524 40.49 35.669232180444084 139.74965140212913 40.49 35.6692651108755 139.7495523946448 40.49 35.66922164963996 139.7495307786539 40.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d6a7ce7a-83bf-4d8c-be0a-86cbd747c4a8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d6a7ce7a-83bf-4d8c-be0a-86cbd747c4a8_0">
											<gml:posList>35.66922543670432 139.7495326414869 35.9 35.66922164963996 139.7495307786539 35.9 35.66922164963996 139.7495307786539 40.49 35.6692651108755 139.7495523946448 40.49 35.6692651108755 139.7495523946448 35.196 35.66922543670432 139.7495326414869 35.196 35.66922543670432 139.7495326414869 35.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-71cde179-e71c-4a1c-b0f8-a01ea97144bf">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-71cde179-e71c-4a1c-b0f8-a01ea97144bf_0">
											<gml:posList>35.6692651108755 139.7495523946448 35.196 35.6692651108755 139.7495523946448 40.49 35.669232180444084 139.74965140212913 40.49 35.669232180444084 139.74965140212913 35.196 35.6692651108755 139.7495523946448 35.196</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f1f5ccf7-6c26-4881-81d6-669ed4d5694d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f1f5ccf7-6c26-4881-81d6-669ed4d5694d_0">
											<gml:posList>35.66927852490041 139.74960651760648 35.196 35.669299128461866 139.74961684629807 35.196 35.669299128461866 139.74961684629807 38.416 35.66927852490041 139.74960651760648 38.416 35.66927852490041 139.74960651760648 35.196</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ce74a8b9-6969-4b02-8e99-a7c9044608d0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ce74a8b9-6969-4b02-8e99-a7c9044608d0_0">
											<gml:posList>35.66930802844639 139.74951811789725 35.196 35.66927852490041 139.74960651760648 35.196 35.66927852490041 139.74960651760648 38.416 35.66930802844639 139.74951811789725 38.416 35.66930802844639 139.74951811789725 35.196</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bdec9e05-8834-4d97-9eeb-8dade7c61ffe">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bdec9e05-8834-4d97-9eeb-8dade7c61ffe_0">
											<gml:posList>35.66930802844639 139.74951811789725 38.416 35.66927852490041 139.74960651760648 38.416 35.669299128461866 139.74961684629807 38.416 35.6693286410367 139.74952845760657 38.416 35.66930802844639 139.74951811789725 38.416</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-530bf60b-990c-45ee-b408-008bda30c30d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-530bf60b-990c-45ee-b408-008bda30c30d_0">
											<gml:posList>35.669299128461866 139.74961684629807 35.196 35.6693286410367 139.74952845760657 35.196 35.6693286410367 139.74952845760657 38.416 35.669299128461866 139.74961684629807 38.416 35.669299128461866 139.74961684629807 35.196</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-48c97a26-8077-4c98-bb0f-e327ed54dbe1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-48c97a26-8077-4c98-bb0f-e327ed54dbe1_0">
											<gml:posList>35.66930802844639 139.74951811789725 35.196 35.66930802844639 139.74951811789725 38.416 35.6693286410367 139.74952845760657 38.416 35.6693286410367 139.74952845760657 35.196 35.66930802844639 139.74951811789725 35.196</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_e54da6aa-8582-47d9-987a-9c25d960b9a1_BuildingInstallation_1060">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9bd85903-b165-49e7-984e-aae7063d37de">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669270733494926 139.74938135084182 6.26 35.66931248021627 139.74940019598517 6.26 35.66930159485401 139.74943069464825 6.26 35.669289334807665 139.74946754625432 6.26 35.66924879495874 139.74944729696344 6.26 35.669270733494926 139.74938135084182 6.26</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-84652e76-edce-4e65-9918-1e256d9aa1b2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-84652e76-edce-4e65-9918-1e256d9aa1b2_0">
											<gml:posList>35.66931248021627 139.74940019598517 20.4 35.66931248021627 139.74940019598517 6.26 35.669270733494926 139.74938135084182 6.26 35.669270733494926 139.74938135084182 20.4 35.66931248021627 139.74940019598517 20.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-82942345-cee3-4719-a734-b5e58f2561dd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-82942345-cee3-4719-a734-b5e58f2561dd_0">
											<gml:posList>35.669270733494926 139.74938135084182 20.4 35.669270733494926 139.74938135084182 6.26 35.66924879495874 139.74944729696344 6.26 35.66924879495874 139.74944729696344 20.4 35.669270733494926 139.74938135084182 20.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1a3b9a66-10d8-460a-8bda-81522ac8e665">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1a3b9a66-10d8-460a-8bda-81522ac8e665_0">
											<gml:posList>35.66930159485401 139.74943069464825 20.4 35.66930159485401 139.74943069464825 6.26 35.66931248021627 139.74940019598517 6.26 35.66931248021627 139.74940019598517 20.4 35.66930159485401 139.74943069464825 20.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-91bbe4b2-d19f-4435-910c-cf0c5acc00c0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-91bbe4b2-d19f-4435-910c-cf0c5acc00c0_0">
											<gml:posList>35.669270733494926 139.74938135084182 20.4 35.66924879495874 139.74944729696344 20.4 35.669289334807665 139.74946754625432 20.4 35.66930159485401 139.74943069464825 20.4 35.66931248021627 139.74940019598517 20.4 35.669270733494926 139.74938135084182 20.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-dbde1c2e-cf7c-4858-a668-1a6191e96669">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-dbde1c2e-cf7c-4858-a668-1a6191e96669_0">
											<gml:posList>35.669289334807665 139.74946754625432 20.4 35.669289334807665 139.74946754625432 6.26 35.66930159485401 139.74943069464825 6.26 35.66930159485401 139.74943069464825 20.4 35.669289334807665 139.74946754625432 20.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f675cd50-0912-47c8-b14a-40a5d6f5f31f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f675cd50-0912-47c8-b14a-40a5d6f5f31f_0">
											<gml:posList>35.66924879495874 139.74944729696344 20.4 35.66924879495874 139.74944729696344 6.26 35.669289334807665 139.74946754625432 6.26 35.669289334807665 139.74946754625432 20.4 35.66924879495874 139.74944729696344 20.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_e54da6aa-8582-47d9-987a-9c25d960b9a1_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-dde92155-3f90-4b2a-9f2d-085fb47122a6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66918083084495 139.74966673247027 35.9 35.66917764789419 139.74966514515398 35.9 35.669189332320684 139.74963001742137 35.9 35.66919251527189 139.74963160473652 35.9 35.66918083084495 139.74966673247027 35.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c0aa9ac9-9d9b-45bd-a222-f65cc91ed8c0">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66919565186287 139.74965727259195 35.196 35.66920376703389 139.7496613180411 35.196 35.66920025001945 139.7496719038729 35.196 35.669192134848785 139.74966785842284 35.196 35.66919084857203 139.7496717258988 35.196 35.66918083084495 139.74966673247027 35.196 35.66919251527189 139.74963160473652 35.196 35.66920253300041 139.74963659816135 35.196 35.66919565186287 139.74965727259195 35.196</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d5502947-8c39-4636-8979-28daed78e211">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669208924144336 139.74966312421967 35.196 35.66921547944923 139.74966646434737 35.196 35.66921100875968 139.7496796138705 35.196 35.66920445345515 139.74967627374195 35.196 35.669208924144336 139.74966312421967 35.196</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5403adc9-5635-4e3f-90f6-7efb3dd7dcb3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66921631974011 139.7496823367162 35.196 35.66922134814512 139.7496675517875 35.196 35.669228146912594 139.74967102421525 35.196 35.669223127520894 139.74968580913563 35.196 35.66921631974011 139.7496823367162 35.196</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5aa8dc91-7354-48ae-878b-b7434aa835fb">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66923834514458 139.74959854009236 40.49 35.66923091532822 139.7496208720236 40.49 35.669208057574885 139.74960945212968 40.49 35.66921549640289 139.74958712019435 40.49 35.66923834514458 139.74959854009236 40.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6a172091-5838-48fa-acf4-d2ad80a50d7f">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66922544570267 139.7495326193853 35.9 35.66922184798807 139.74953084472318 35.9 35.669238155754975 139.74948181611998 35.9 35.669241753477976 139.74948360182628 35.9 35.66922544570267 139.7495326193853 35.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-64f7f54d-992c-42e6-a4af-e90232c9de0b">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66923447156401 139.74953709466956 35.196 35.66922544570267 139.7495326193853 35.196 35.669241753477976 139.74948360182628 35.196 35.66925077933342 139.74948806605985 35.196 35.66923447156401 139.74953709466956 35.196</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d169b08e-ba93-47a6-b2f1-0fc20ddee874">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66922642937623 139.7496898817024 35.196 35.669231565371305 139.74967426820237 35.196 35.66923858046801 139.74967774040542 35.196 35.669237725967356 139.74968033713117 35.196 35.66927592126474 139.7496992303113 35.196 35.66927261120987 139.74970930781416 35.196 35.66923422655671 139.7496903154126 35.196 35.669233255122855 139.74969326573532 35.196 35.66922642937623 139.7496898817024 35.196</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-88f3485e-ff00-45f0-a65f-a8ad6c037200">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66924892647225 139.7496622319265 35.196 35.66924067613379 139.74965824184656 35.196 35.669253861803455 139.7496172912206 35.196 35.66926210312183 139.74962127026026 35.196 35.66924892647225 139.7496622319265 35.196</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e561d32f-b1c9-4a0a-a74b-2f1fcae6a904">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66925138426684 139.7495413186985 35.196 35.66924412582636 139.74953789094556 35.196 35.669257058963034 139.74949678591665 35.196 35.669264317412356 139.7495002247125 35.196 35.66925138426684 139.7495413186985 35.196</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ef34e12d-d318-45a5-923e-4deb4e63f30a">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66925216438604 139.74948366826177 35.196 35.6692552133009 139.74947398868508 35.196 35.6692642750885 139.749478276143 35.196 35.6692612261733 139.7494879557206 35.196 35.66925216438604 139.74948366826177 35.196</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e79e86f2-df3a-4d37-8f4b-633cbcf4c471">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669278021024006 139.74968561931544 35.196 35.66925402804623 139.7496749185777 35.196 35.669256914691026 139.74966518394686 35.196 35.66928090766966 139.74967588468206 35.196 35.669278021024006 139.74968561931544 35.196</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6bb1eb2e-54f1-4253-8480-da8e2ebd0ba8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66925937045166 139.749541343491 35.196 35.66927044186995 139.74950616111488 35.196 35.66927757408068 139.74950953376748 35.196 35.66926649364 139.74954470510957 35.196 35.66925937045166 139.749541343491 35.196</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-05b55a58-6562-4b31-9cac-16828c8ddad3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66927186744266 139.74966369921142 35.196 35.66928238046028 139.74962911391958 35.196 35.6692904412964 139.7496327949053 35.196 35.669279937291456 139.74966738019077 35.196 35.66927186744266 139.74966369921142 35.196</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bea99ff6-146c-45f4-ba01-a3a15d0695df">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66927501281169 139.7497020148781 35.196 35.66927592126474 139.7496992303113 35.196 35.66928290120735 139.74967804763946 35.196 35.669293982891176 139.74968352599458 35.196 35.66928608548838 139.7497075042915 35.196 35.66927501281169 139.7497020148781 35.196</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c82393b9-da6e-4501-90e7-c639761d1072">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66928073165802 139.7495264641513 35.196 35.66928558834472 139.74951104975221 35.196 35.669293225493135 139.74951466489247 35.196 35.66928837781971 139.7495300792834 35.196 35.66928073165802 139.7495264641513 35.196</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-52d786cc-d34c-4844-acd4-50d2267a0dc5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66928468871891 139.7495006121193 35.196 35.66928781857407 139.74949066734808 35.196 35.66929676313645 139.74949488865553 35.196 35.66929362427491 139.74950484448325 35.196 35.66928468871891 139.7495006121193 35.196</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7582f4e6-226c-4b38-beb7-54d7cc716581">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7582f4e6-226c-4b38-beb7-54d7cc716581_0">
											<gml:posList>35.66925937045166 139.749541343491 35.196 35.66925937045166 139.749541343491 37.478 35.66927044186995 139.74950616111488 37.478 35.66927044186995 139.74950616111488 35.196 35.66925937045166 139.749541343491 35.196</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-81a2b282-9fdb-4e32-8998-b010cf594cb7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-81a2b282-9fdb-4e32-8998-b010cf594cb7_0">
											<gml:posList>35.66925402804623 139.7496749185777 35.196 35.669278021024006 139.74968561931544 35.196 35.669278021024006 139.74968561931544 37.258 35.66925402804623 139.7496749185777 37.258 35.66925402804623 139.7496749185777 35.196</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7b0ec93d-1760-4ea5-a58a-58668a1e07b0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7b0ec93d-1760-4ea5-a58a-58668a1e07b0_0">
											<gml:posList>35.66927592126474 139.7496992303113 35.196 35.66927501281169 139.7497020148781 35.196 35.66927501281169 139.7497020148781 36.865 35.66927592126474 139.7496992303113 36.865 35.66927592126474 139.7496992303113 35.196</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6b38dae3-8ab8-48aa-bf08-e48c4b972043">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6b38dae3-8ab8-48aa-bf08-e48c4b972043_0">
											<gml:posList>35.669238155754975 139.74948181611998 37.191 35.66922184798807 139.74953084472318 37.191 35.66923447156401 139.74953709466956 37.191 35.66925077933342 139.74948806605985 37.191 35.669238155754975 139.74948181611998 37.191</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-27ff8b2d-d40d-4226-9b43-c641c063c223">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-27ff8b2d-d40d-4226-9b43-c641c063c223_0">
											<gml:posList>35.669237725967356 139.74968033713117 35.196 35.66923858046801 139.74967774040542 35.196 35.66923858046801 139.74967774040542 37.258 35.669237725967356 139.74968033713117 37.258 35.669237725967356 139.74968033713117 35.196</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3d112f18-c0f2-47a7-bddb-c88552cf9b6b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3d112f18-c0f2-47a7-bddb-c88552cf9b6b_0">
											<gml:posList>35.66923447156401 139.74953709466956 35.196 35.66925077933342 139.74948806605985 35.196 35.66925077933342 139.74948806605985 37.191 35.66923447156401 139.74953709466956 37.191 35.66923447156401 139.74953709466956 35.196</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-475019c4-7cfa-4f61-a247-8f61b9caad0a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-475019c4-7cfa-4f61-a247-8f61b9caad0a_0">
											<gml:posList>35.669241753477976 139.74948360182628 35.9 35.669238155754975 139.74948181611998 35.9 35.669238155754975 139.74948181611998 37.191 35.66925077933342 139.74948806605985 37.191 35.66925077933342 139.74948806605985 35.196 35.669241753477976 139.74948360182628 35.196 35.669241753477976 139.74948360182628 35.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-14d1e67c-1d25-4846-88f3-c4058215e381">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-14d1e67c-1d25-4846-88f3-c4058215e381_0">
											<gml:posList>35.66924067613379 139.74965824184656 35.196 35.66924892647225 139.7496622319265 35.196 35.66924892647225 139.7496622319265 37.258 35.66924067613379 139.74965824184656 37.258 35.66924067613379 139.74965824184656 35.196</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-da37bc56-bc39-4121-a2f4-d7696177e505">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-da37bc56-bc39-4121-a2f4-d7696177e505_0">
											<gml:posList>35.669253861803455 139.7496172912206 35.196 35.66924067613379 139.74965824184656 35.196 35.66924067613379 139.74965824184656 37.258 35.669253861803455 139.7496172912206 37.258 35.669253861803455 139.7496172912206 35.196</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3475524d-07c8-4af6-ad3e-735fdf188a4e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3475524d-07c8-4af6-ad3e-735fdf188a4e_0">
											<gml:posList>35.66924412582636 139.74953789094556 35.196 35.66925138426684 139.7495413186985 35.196 35.66925138426684 139.7495413186985 37.478 35.66924412582636 139.74953789094556 37.478 35.66924412582636 139.74953789094556 35.196</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c7e3f5e3-2355-41b6-8487-dc0cb9ebb7a4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c7e3f5e3-2355-41b6-8487-dc0cb9ebb7a4_0">
											<gml:posList>35.66924412582636 139.74953789094556 37.478 35.669257058963034 139.74949678591665 37.478 35.669257058963034 139.74949678591665 35.196 35.66924412582636 139.74953789094556 35.196 35.66924412582636 139.74953789094556 37.478</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-af393c49-4e2f-4aaa-8dfb-90b31ff14bdb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-af393c49-4e2f-4aaa-8dfb-90b31ff14bdb_0">
											<gml:posList>35.66923422655671 139.7496903154126 37.258 35.66927261120987 139.74970930781416 37.258 35.66927592126474 139.7496992303113 37.258 35.669237725967356 139.74968033713117 37.258 35.66923858046801 139.74967774040542 37.258 35.669231565371305 139.74967426820237 37.258 35.66922642937623 139.7496898817024 37.258 35.669233255122855 139.74969326573532 37.258 35.66923422655671 139.7496903154126 37.258</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a8dad217-2096-4268-acaa-42639dc4d3d1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a8dad217-2096-4268-acaa-42639dc4d3d1_0">
											<gml:posList>35.669253861803455 139.7496172912206 37.258 35.66924067613379 139.74965824184656 37.258 35.66924892647225 139.7496622319265 37.258 35.66926210312183 139.74962127026026 37.258 35.669253861803455 139.7496172912206 37.258</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4aaf3005-a370-4e43-88d1-b958b9f5eda8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4aaf3005-a370-4e43-88d1-b958b9f5eda8_0">
											<gml:posList>35.66923422655671 139.7496903154126 35.196 35.66927261120987 139.74970930781416 35.196 35.66927261120987 139.74970930781416 37.258 35.66923422655671 139.7496903154126 37.258 35.66923422655671 139.7496903154126 35.196</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-54d497e3-6f35-4ed6-b1c1-2b5921f06d6f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-54d497e3-6f35-4ed6-b1c1-2b5921f06d6f_0">
											<gml:posList>35.66925216438604 139.74948366826177 35.196 35.66925216438604 139.74948366826177 37.478 35.6692552133009 139.74947398868508 37.478 35.6692552133009 139.74947398868508 35.196 35.66925216438604 139.74948366826177 35.196</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-11521308-2d4c-4f45-912f-7c48bc889ff7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-11521308-2d4c-4f45-912f-7c48bc889ff7_0">
											<gml:posList>35.66925138426684 139.7495413186985 37.478 35.669264317412356 139.7495002247125 37.478 35.669257058963034 139.74949678591665 37.478 35.66924412582636 139.74953789094556 37.478 35.66925138426684 139.7495413186985 37.478</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-543035c8-c583-4549-9279-737c3e95e471">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-543035c8-c583-4549-9279-737c3e95e471_0">
											<gml:posList>35.669256914691026 139.74966518394686 35.196 35.66925402804623 139.7496749185777 35.196 35.66925402804623 139.7496749185777 37.258 35.669256914691026 139.74966518394686 37.258 35.669256914691026 139.74966518394686 35.196</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-05d86f91-a5cd-454a-bc76-173edea6b8c4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-05d86f91-a5cd-454a-bc76-173edea6b8c4_0">
											<gml:posList>35.66924892647225 139.7496622319265 35.196 35.66926210312183 139.74962127026026 35.196 35.66926210312183 139.74962127026026 37.258 35.66924892647225 139.7496622319265 37.258 35.66924892647225 139.7496622319265 35.196</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-29bbddd2-96a0-4831-a7ab-ac41eeab5d07">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-29bbddd2-96a0-4831-a7ab-ac41eeab5d07_0">
											<gml:posList>35.66927592126474 139.7496992303113 36.865 35.669237725967356 139.74968033713117 35.196 35.669237725967356 139.74968033713117 37.258 35.66927592126474 139.7496992303113 37.258 35.66927592126474 139.7496992303113 36.865</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3b1354d1-18b2-43b0-881f-db4f243f8045">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3b1354d1-18b2-43b0-881f-db4f243f8045_0">
											<gml:posList>35.669237725967356 139.74968033713117 35.196 35.66927592126474 139.7496992303113 36.865 35.66927592126474 139.7496992303113 35.196 35.669237725967356 139.74968033713117 35.196</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1df3e955-e4dc-43ae-8751-aef10dabe1dc">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1df3e955-e4dc-43ae-8751-aef10dabe1dc_0">
											<gml:posList>35.66925216438604 139.74948366826177 35.196 35.6692612261733 139.7494879557206 35.196 35.6692612261733 139.7494879557206 37.478 35.66925216438604 139.74948366826177 37.478 35.66925216438604 139.74948366826177 35.196</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-48419cc6-8a13-4960-901b-4f2b5767113b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-48419cc6-8a13-4960-901b-4f2b5767113b_0">
											<gml:posList>35.669264317412356 139.7495002247125 35.196 35.669264317412356 139.7495002247125 37.478 35.66925138426684 139.7495413186985 37.478 35.66925138426684 139.7495413186985 35.196 35.669264317412356 139.7495002247125 35.196</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-89de6f41-599c-485d-9e95-092160ecfae3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-89de6f41-599c-485d-9e95-092160ecfae3_0">
											<gml:posList>35.669253861803455 139.7496172912206 35.196 35.669253861803455 139.7496172912206 37.258 35.66926210312183 139.74962127026026 37.258 35.66926210312183 139.74962127026026 35.196 35.669253861803455 139.7496172912206 35.196</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d7bfa062-2aae-4ea1-8739-3068ffc6ed33">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d7bfa062-2aae-4ea1-8739-3068ffc6ed33_0">
											<gml:posList>35.66925216438604 139.74948366826177 37.478 35.6692612261733 139.7494879557206 37.478 35.6692642750885 139.749478276143 37.478 35.6692552133009 139.74947398868508 37.478 35.66925216438604 139.74948366826177 37.478</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3f8d2543-6461-4484-8bc8-575034252960">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3f8d2543-6461-4484-8bc8-575034252960_0">
											<gml:posList>35.6692642750885 139.749478276143 35.196 35.6692552133009 139.74947398868508 35.196 35.6692552133009 139.74947398868508 37.478 35.6692642750885 139.749478276143 37.478 35.6692642750885 139.749478276143 35.196</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4ce262c2-a21b-42a1-8915-036d7853a467">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4ce262c2-a21b-42a1-8915-036d7853a467_0">
											<gml:posList>35.669257058963034 139.74949678591665 35.196 35.669257058963034 139.74949678591665 37.478 35.669264317412356 139.7495002247125 37.478 35.669264317412356 139.7495002247125 35.196 35.669257058963034 139.74949678591665 35.196</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-39562109-b478-464c-96d2-a821309fdd87">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-39562109-b478-464c-96d2-a821309fdd87_0">
											<gml:posList>35.6692612261733 139.7494879557206 35.196 35.6692642750885 139.749478276143 35.196 35.6692642750885 139.749478276143 37.478 35.6692612261733 139.7494879557206 37.478 35.6692612261733 139.7494879557206 35.196</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8283b674-c25b-434d-a24b-7bfd3d6688d5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8283b674-c25b-434d-a24b-7bfd3d6688d5_0">
											<gml:posList>35.66925937045166 139.749541343491 35.196 35.66926649364 139.74954470510957 35.196 35.66926649364 139.74954470510957 37.478 35.66925937045166 139.749541343491 37.478 35.66925937045166 139.749541343491 35.196</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-63563ca1-4939-4182-97e3-4d956ba25e8f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-63563ca1-4939-4182-97e3-4d956ba25e8f_0">
											<gml:posList>35.669278021024006 139.74968561931544 37.258 35.66928090766966 139.74967588468206 37.258 35.669256914691026 139.74966518394686 37.258 35.66925402804623 139.7496749185777 37.258 35.669278021024006 139.74968561931544 37.258</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-851c8207-09b3-4323-9a06-3cc4c06950c8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-851c8207-09b3-4323-9a06-3cc4c06950c8_0">
											<gml:posList>35.66927757408068 139.74950953376748 37.478 35.66927044186995 139.74950616111488 37.478 35.66925937045166 139.749541343491 37.478 35.66926649364 139.74954470510957 37.478 35.66927757408068 139.74950953376748 37.478</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fed90f4d-88fd-4f51-a102-09c3469b0fa7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fed90f4d-88fd-4f51-a102-09c3469b0fa7_0">
											<gml:posList>35.669256914691026 139.74966518394686 35.196 35.669256914691026 139.74966518394686 37.258 35.66928090766966 139.74967588468206 37.258 35.66928090766966 139.74967588468206 35.196 35.669256914691026 139.74966518394686 35.196</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8c19d58d-37ce-4795-a8aa-6d209f761474">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8c19d58d-37ce-4795-a8aa-6d209f761474_0">
											<gml:posList>35.66926649364 139.74954470510957 35.196 35.66927757408068 139.74950953376748 35.196 35.66927757408068 139.74950953376748 37.478 35.66926649364 139.74954470510957 37.478 35.66926649364 139.74954470510957 35.196</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-471ad1f8-5138-4f3c-bd57-f66d734e11d6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-471ad1f8-5138-4f3c-bd57-f66d734e11d6_0">
											<gml:posList>35.66927757408068 139.74950953376748 35.196 35.66927044186995 139.74950616111488 35.196 35.66927044186995 139.74950616111488 37.478 35.66927757408068 139.74950953376748 37.478 35.66927757408068 139.74950953376748 35.196</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5f633565-1510-4418-ac80-063546385348">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5f633565-1510-4418-ac80-063546385348_0">
											<gml:posList>35.66927261120987 139.74970930781416 37.258 35.66927261120987 139.74970930781416 35.196 35.66927592126474 139.7496992303113 35.196 35.66927592126474 139.7496992303113 36.865 35.66927592126474 139.7496992303113 37.258 35.66927261120987 139.74970930781416 37.258</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e3f5f0a9-24c7-49d3-884b-9e15a3e4cc88">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e3f5f0a9-24c7-49d3-884b-9e15a3e4cc88_0">
											<gml:posList>35.66927186744266 139.74966369921142 35.196 35.669279937291456 139.74966738019077 35.196 35.669279937291456 139.74966738019077 37.44 35.66927186744266 139.74966369921142 37.44 35.66927186744266 139.74966369921142 35.196</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-58be0c85-0df2-42ea-85e7-468fc75f1dca">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-58be0c85-0df2-42ea-85e7-468fc75f1dca_0">
											<gml:posList>35.66927186744266 139.74966369921142 35.196 35.66927186744266 139.74966369921142 37.44 35.66928238046028 139.74962911391958 37.44 35.66928238046028 139.74962911391958 35.196 35.66927186744266 139.74966369921142 35.196</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c0f3bbe0-4982-452f-a72c-d37f0dbef9cc">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c0f3bbe0-4982-452f-a72c-d37f0dbef9cc_0">
											<gml:posList>35.66928290120735 139.74967804763946 36.865 35.66927592126474 139.7496992303113 35.196 35.66927592126474 139.7496992303113 36.865 35.66928290120735 139.74967804763946 36.865</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-004e3d5e-f5fc-492e-bdda-f8738b423e66">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-004e3d5e-f5fc-492e-bdda-f8738b423e66_0">
											<gml:posList>35.66927592126474 139.7496992303113 35.196 35.66928290120735 139.74967804763946 36.865 35.66928290120735 139.74967804763946 35.196 35.66927592126474 139.7496992303113 35.196</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b59b64e0-1da5-4fc0-abae-a2b909eda3a8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b59b64e0-1da5-4fc0-abae-a2b909eda3a8_0">
											<gml:posList>35.669278021024006 139.74968561931544 35.196 35.66928090766966 139.74967588468206 35.196 35.66928090766966 139.74967588468206 37.258 35.669278021024006 139.74968561931544 37.258 35.669278021024006 139.74968561931544 35.196</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4f6cfde6-b131-4209-b4d9-28e1c027ff5a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4f6cfde6-b131-4209-b4d9-28e1c027ff5a_0">
											<gml:posList>35.66927501281169 139.7497020148781 35.196 35.66928608548838 139.7497075042915 35.196 35.66928608548838 139.7497075042915 36.865 35.66927501281169 139.7497020148781 36.865 35.66927501281169 139.7497020148781 35.196</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-45e74fc8-a0d3-42f3-84d7-dcafaf001839">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-45e74fc8-a0d3-42f3-84d7-dcafaf001839_0">
											<gml:posList>35.6692904412964 139.7496327949053 37.44 35.66928238046028 139.74962911391958 37.44 35.66927186744266 139.74966369921142 37.44 35.669279937291456 139.74966738019077 37.44 35.6692904412964 139.7496327949053 37.44</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-08ff70ea-ab71-4ee6-97c3-547846359e4c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-08ff70ea-ab71-4ee6-97c3-547846359e4c_0">
											<gml:posList>35.66928558834472 139.74951104975221 35.196 35.66928073165802 139.7495264641513 35.196 35.66928073165802 139.7495264641513 37.478 35.66928558834472 139.74951104975221 37.478 35.66928558834472 139.74951104975221 35.196</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-56a7eb7a-f4e9-4fc8-8fc5-22e4c345ea17">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-56a7eb7a-f4e9-4fc8-8fc5-22e4c345ea17_0">
											<gml:posList>35.669293982891176 139.74968352599458 36.865 35.66928290120735 139.74967804763946 36.865 35.66927592126474 139.7496992303113 36.865 35.66927501281169 139.7497020148781 36.865 35.66928608548838 139.7497075042915 36.865 35.669293982891176 139.74968352599458 36.865</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-322f5f6b-da0e-4570-9a00-dcdb1ed155b1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-322f5f6b-da0e-4570-9a00-dcdb1ed155b1_0">
											<gml:posList>35.66928073165802 139.7495264641513 35.196 35.66928837781971 139.7495300792834 35.196 35.66928837781971 139.7495300792834 37.478 35.66928073165802 139.7495264641513 37.478 35.66928073165802 139.7495264641513 35.196</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0820c2eb-66f3-443a-8bf0-4de50719ffa0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0820c2eb-66f3-443a-8bf0-4de50719ffa0_0">
											<gml:posList>35.6692904412964 139.7496327949053 35.196 35.6692904412964 139.7496327949053 37.44 35.669279937291456 139.74966738019077 37.44 35.669279937291456 139.74966738019077 35.196 35.6692904412964 139.7496327949053 35.196</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fe3b3e33-bce2-4dd0-bbc0-4e4bbad5556a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fe3b3e33-bce2-4dd0-bbc0-4e4bbad5556a_0">
											<gml:posList>35.66928781857407 139.74949066734808 35.196 35.66928468871891 139.7495006121193 35.196 35.66928468871891 139.7495006121193 37.478 35.66928781857407 139.74949066734808 37.478 35.66928781857407 139.74949066734808 35.196</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c3fd916d-17bd-434e-9587-ea4f0251801f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c3fd916d-17bd-434e-9587-ea4f0251801f_0">
											<gml:posList>35.6692904412964 139.7496327949053 35.196 35.66928238046028 139.74962911391958 35.196 35.66928238046028 139.74962911391958 37.44 35.6692904412964 139.7496327949053 37.44 35.6692904412964 139.7496327949053 35.196</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-edaf5cc0-2ffd-4ab1-bd99-5230eef03d57">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-edaf5cc0-2ffd-4ab1-bd99-5230eef03d57_0">
											<gml:posList>35.669293225493135 139.74951466489247 37.478 35.66928558834472 139.74951104975221 37.478 35.66928073165802 139.7495264641513 37.478 35.66928837781971 139.7495300792834 37.478 35.669293225493135 139.74951466489247 37.478</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ce67a8fb-263b-4473-bc06-55ade02ce011">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ce67a8fb-263b-4473-bc06-55ade02ce011_0">
											<gml:posList>35.669293982891176 139.74968352599458 35.196 35.66928290120735 139.74967804763946 35.196 35.66928290120735 139.74967804763946 36.865 35.669293982891176 139.74968352599458 36.865 35.669293982891176 139.74968352599458 35.196</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c3684955-e358-4c4f-91d6-db0054ff2cbb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c3684955-e358-4c4f-91d6-db0054ff2cbb_0">
											<gml:posList>35.66929362427491 139.74950484448325 35.196 35.66929362427491 139.74950484448325 37.478 35.66928468871891 139.7495006121193 37.478 35.66928468871891 139.7495006121193 35.196 35.66929362427491 139.74950484448325 35.196</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2499505a-a22e-4900-87c5-a39c6cff6f27">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2499505a-a22e-4900-87c5-a39c6cff6f27_0">
											<gml:posList>35.669293225493135 139.74951466489247 35.196 35.66928558834472 139.74951104975221 35.196 35.66928558834472 139.74951104975221 37.478 35.669293225493135 139.74951466489247 37.478 35.669293225493135 139.74951466489247 35.196</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8e20de18-4e1e-4011-ac85-16d54ecf4c14">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8e20de18-4e1e-4011-ac85-16d54ecf4c14_0">
											<gml:posList>35.66928608548838 139.7497075042915 35.196 35.669293982891176 139.74968352599458 35.196 35.669293982891176 139.74968352599458 36.865 35.66928608548838 139.7497075042915 36.865 35.66928608548838 139.7497075042915 35.196</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e51fbf68-4c31-42f4-abf6-0cfd79329862">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e51fbf68-4c31-42f4-abf6-0cfd79329862_0">
											<gml:posList>35.66929676313645 139.74949488865553 37.478 35.66928781857407 139.74949066734808 37.478 35.66928468871891 139.7495006121193 37.478 35.66929362427491 139.74950484448325 37.478 35.66929676313645 139.74949488865553 37.478</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e01860e0-8ac0-4593-b9a0-446c98c5f2eb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e01860e0-8ac0-4593-b9a0-446c98c5f2eb_0">
											<gml:posList>35.66928837781971 139.7495300792834 35.196 35.669293225493135 139.74951466489247 35.196 35.669293225493135 139.74951466489247 37.478 35.66928837781971 139.7495300792834 37.478 35.66928837781971 139.7495300792834 35.196</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-39a1ecc2-47f9-4102-bc05-e53042e03d80">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-39a1ecc2-47f9-4102-bc05-e53042e03d80_0">
											<gml:posList>35.66928781857407 139.74949066734808 35.196 35.66928781857407 139.74949066734808 37.478 35.66929676313645 139.74949488865553 37.478 35.66929676313645 139.74949488865553 35.196 35.66928781857407 139.74949066734808 35.196</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-79921cc7-690b-467e-9842-6c9af1191799">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-79921cc7-690b-467e-9842-6c9af1191799_0">
											<gml:posList>35.66929676313645 139.74949488865553 35.196 35.66929676313645 139.74949488865553 37.478 35.66929362427491 139.74950484448325 37.478 35.66929362427491 139.74950484448325 35.196 35.66929676313645 139.74949488865553 35.196</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9923dd8c-fe6e-49e3-8143-8037ca3478fc">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9923dd8c-fe6e-49e3-8143-8037ca3478fc_0">
											<gml:posList>35.66922184798807 139.74953084472318 35.9 35.66922184798807 139.74953084472318 37.191 35.669238155754975 139.74948181611998 37.191 35.669238155754975 139.74948181611998 35.9 35.66922184798807 139.74953084472318 35.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-69bb4a8c-9517-45ec-895f-91fb98c2305a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-69bb4a8c-9517-45ec-895f-91fb98c2305a_0">
											<gml:posList>35.669241753477976 139.74948360182628 35.9 35.669241753477976 139.74948360182628 35.196 35.66922544570267 139.7495326193853 35.196 35.66922544570267 139.7495326193853 35.9 35.669241753477976 139.74948360182628 35.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d8124e48-8a3e-42e3-87d3-40a8207b308d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d8124e48-8a3e-42e3-87d3-40a8207b308d_0">
											<gml:posList>35.66923447156401 139.74953709466956 35.196 35.66923447156401 139.74953709466956 37.191 35.66922184798807 139.74953084472318 37.191 35.66922184798807 139.74953084472318 35.9 35.66922544570267 139.7495326193853 35.9 35.66922544570267 139.7495326193853 35.196 35.66923447156401 139.74953709466956 35.196</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-23d2ead9-168e-4bf1-bda5-8f962cddfb46">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-23d2ead9-168e-4bf1-bda5-8f962cddfb46_0">
											<gml:posList>35.66923834514458 139.74959854009236 40.49 35.66921549640289 139.74958712019435 40.49 35.66921549640289 139.74958712019435 42.481 35.66923834514458 139.74959854009236 42.481 35.66923834514458 139.74959854009236 40.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a5720486-b179-43cb-99e2-c881a1d1b596">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a5720486-b179-43cb-99e2-c881a1d1b596_0">
											<gml:posList>35.66921549640289 139.74958712019435 40.49 35.669208057574885 139.74960945212968 40.49 35.669208057574885 139.74960945212968 42.481 35.66921549640289 139.74958712019435 42.481 35.66921549640289 139.74958712019435 40.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-51a59a78-88c0-437c-aa4b-7b0230e0a6a8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-51a59a78-88c0-437c-aa4b-7b0230e0a6a8_0">
											<gml:posList>35.66923834514458 139.74959854009236 42.481 35.66921549640289 139.74958712019435 42.481 35.669208057574885 139.74960945212968 42.481 35.66923091532822 139.7496208720236 42.481 35.66923834514458 139.74959854009236 42.481</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3a6e6ea8-58f6-4d7e-858f-5e185dfd6144">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3a6e6ea8-58f6-4d7e-858f-5e185dfd6144_0">
											<gml:posList>35.66923091532822 139.7496208720236 40.49 35.66923834514458 139.74959854009236 40.49 35.66923834514458 139.74959854009236 42.481 35.66923091532822 139.7496208720236 42.481 35.66923091532822 139.7496208720236 40.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1f090cc8-5f42-4036-8a56-7d194d05ffc9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1f090cc8-5f42-4036-8a56-7d194d05ffc9_0">
											<gml:posList>35.669208057574885 139.74960945212968 40.49 35.66923091532822 139.7496208720236 40.49 35.66923091532822 139.7496208720236 42.481 35.669208057574885 139.74960945212968 42.481 35.669208057574885 139.74960945212968 40.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-11e20789-a1e0-4a68-a5e3-8f51e4961034">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-11e20789-a1e0-4a68-a5e3-8f51e4961034_0">
											<gml:posList>35.66919251527189 139.74963160473652 35.9 35.669189332320684 139.74963001742137 35.9 35.669189332320684 139.74963001742137 37.258 35.66920253300041 139.74963659816135 37.258 35.66920253300041 139.74963659816135 35.196 35.66919251527189 139.74963160473652 35.196 35.66919251527189 139.74963160473652 35.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e23b42b6-d383-41a7-a9c2-f5f0eb8e8cab">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e23b42b6-d383-41a7-a9c2-f5f0eb8e8cab_0">
											<gml:posList>35.66919565186287 139.74965727259195 35.196 35.66920253300041 139.74963659816135 35.196 35.66920253300041 139.74963659816135 37.258 35.66919565186287 139.74965727259195 37.258 35.66919565186287 139.74965727259195 35.196</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-93e5c79c-18a3-4125-92bb-fc5b4a527e32">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-93e5c79c-18a3-4125-92bb-fc5b4a527e32_0">
											<gml:posList>35.669189332320684 139.74963001742137 35.9 35.66917764789419 139.74966514515398 35.9 35.66917764789419 139.74966514515398 37.258 35.669189332320684 139.74963001742137 37.258 35.669189332320684 139.74963001742137 35.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-40ce6a04-d275-4463-a21f-46d26bfcc440">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-40ce6a04-d275-4463-a21f-46d26bfcc440_0">
											<gml:posList>35.66918083084495 139.74966673247027 35.9 35.66919251527189 139.74963160473652 35.9 35.66919251527189 139.74963160473652 35.196 35.66918083084495 139.74966673247027 35.196 35.66918083084495 139.74966673247027 35.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b057a4ea-f209-4f70-ab5c-8cea700e1c23">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b057a4ea-f209-4f70-ab5c-8cea700e1c23_0">
											<gml:posList>35.669189332320684 139.74963001742137 37.258 35.66917764789419 139.74966514515398 37.258 35.66919084857203 139.7496717258988 37.258 35.669192134848785 139.74966785842284 37.258 35.66919565186287 139.74965727259195 37.258 35.66920253300041 139.74963659816135 37.258 35.669189332320684 139.74963001742137 37.258</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-97193177-39b5-4865-a9b8-a978cbcd4f88">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-97193177-39b5-4865-a9b8-a978cbcd4f88_0">
											<gml:posList>35.66920376703389 139.7496613180411 35.196 35.66919565186287 139.74965727259195 35.196 35.66919565186287 139.74965727259195 37.258 35.66920376703389 139.7496613180411 37.258 35.66920376703389 139.7496613180411 35.196</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f789ef49-25ab-4bc1-8c13-da8adc6ccefb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f789ef49-25ab-4bc1-8c13-da8adc6ccefb_0">
											<gml:posList>35.669192134848785 139.74966785842284 37.258 35.66920025001945 139.7496719038729 37.258 35.66920376703389 139.7496613180411 37.258 35.66919565186287 139.74965727259195 37.258 35.669192134848785 139.74966785842284 37.258</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c10a3e31-cd74-4e3a-949c-e936e79a3827">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c10a3e31-cd74-4e3a-949c-e936e79a3827_0">
											<gml:posList>35.669208924144336 139.74966312421967 35.196 35.669208924144336 139.74966312421967 37.258 35.66921547944923 139.74966646434737 37.258 35.66921547944923 139.74966646434737 35.196 35.669208924144336 139.74966312421967 35.196</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ea0f355c-07dd-4950-8f66-873a4f0a08ef">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ea0f355c-07dd-4950-8f66-873a4f0a08ef_0">
											<gml:posList>35.66920025001945 139.7496719038729 35.196 35.66920376703389 139.7496613180411 35.196 35.66920376703389 139.7496613180411 37.258 35.66920025001945 139.7496719038729 37.258 35.66920025001945 139.7496719038729 35.196</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-82f24b94-4e0e-4167-9373-c69ba9df79e3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-82f24b94-4e0e-4167-9373-c69ba9df79e3_0">
											<gml:posList>35.66919084857203 139.7496717258988 35.196 35.66919084857203 139.7496717258988 37.258 35.66917764789419 139.74966514515398 37.258 35.66917764789419 139.74966514515398 35.9 35.66918083084495 139.74966673247027 35.9 35.66918083084495 139.74966673247027 35.196 35.66919084857203 139.7496717258988 35.196</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1b0cdce1-81a2-4dab-a210-3ee50e18dd43">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1b0cdce1-81a2-4dab-a210-3ee50e18dd43_0">
											<gml:posList>35.669228146912594 139.74967102421525 35.196 35.66922134814512 139.7496675517875 35.196 35.66922134814512 139.7496675517875 37.258 35.669228146912594 139.74967102421525 37.258 35.669228146912594 139.74967102421525 35.196</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8aaef405-406b-4513-8161-26ce717e0994">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8aaef405-406b-4513-8161-26ce717e0994_0">
											<gml:posList>35.669208924144336 139.74966312421967 35.196 35.66920445345515 139.74967627374195 35.196 35.66920445345515 139.74967627374195 37.258 35.669208924144336 139.74966312421967 37.258 35.669208924144336 139.74966312421967 35.196</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7a9336bd-1c65-491e-b4ef-fdaa9fadf27d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7a9336bd-1c65-491e-b4ef-fdaa9fadf27d_0">
											<gml:posList>35.66919084857203 139.7496717258988 35.196 35.669192134848785 139.74966785842284 35.196 35.669192134848785 139.74966785842284 37.258 35.66919084857203 139.7496717258988 37.258 35.66919084857203 139.7496717258988 35.196</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9cd5aee1-7213-4e1c-998f-37135d7d2c87">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9cd5aee1-7213-4e1c-998f-37135d7d2c87_0">
											<gml:posList>35.669192134848785 139.74966785842284 35.196 35.66920025001945 139.7496719038729 35.196 35.66920025001945 139.7496719038729 37.258 35.669192134848785 139.74966785842284 37.258 35.669192134848785 139.74966785842284 35.196</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e984f811-ca42-4617-ac82-1047d4bf7dc4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e984f811-ca42-4617-ac82-1047d4bf7dc4_0">
											<gml:posList>35.669208924144336 139.74966312421967 37.258 35.66920445345515 139.74967627374195 37.258 35.66921100875968 139.7496796138705 37.258 35.66921547944923 139.74966646434737 37.258 35.669208924144336 139.74966312421967 37.258</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-84b90943-4d70-4b4a-a6d8-6dfdf0d9fc46">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-84b90943-4d70-4b4a-a6d8-6dfdf0d9fc46_0">
											<gml:posList>35.66921100875968 139.7496796138705 35.196 35.66921547944923 139.74966646434737 35.196 35.66921547944923 139.74966646434737 37.258 35.66921100875968 139.7496796138705 37.258 35.66921100875968 139.7496796138705 35.196</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-40268b5c-97bb-4009-aa3f-b95663bfc4d2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-40268b5c-97bb-4009-aa3f-b95663bfc4d2_0">
											<gml:posList>35.66922134814512 139.7496675517875 35.196 35.66921631974011 139.7496823367162 35.196 35.66921631974011 139.7496823367162 37.258 35.66922134814512 139.7496675517875 37.258 35.66922134814512 139.7496675517875 35.196</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-421e0762-efdc-4ee5-b5e8-5bde1f55b9f2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-421e0762-efdc-4ee5-b5e8-5bde1f55b9f2_0">
											<gml:posList>35.66923858046801 139.74967774040542 35.196 35.669231565371305 139.74967426820237 35.196 35.669231565371305 139.74967426820237 37.258 35.66923858046801 139.74967774040542 37.258 35.66923858046801 139.74967774040542 35.196</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-38ae76f5-7960-484f-ba79-781cac98f63e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-38ae76f5-7960-484f-ba79-781cac98f63e_0">
											<gml:posList>35.669228146912594 139.74967102421525 37.258 35.66922134814512 139.7496675517875 37.258 35.66921631974011 139.7496823367162 37.258 35.669223127520894 139.74968580913563 37.258 35.669228146912594 139.74967102421525 37.258</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-33e98a4b-102f-4733-8986-45ffe7508bc6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-33e98a4b-102f-4733-8986-45ffe7508bc6_0">
											<gml:posList>35.66920445345515 139.74967627374195 35.196 35.66921100875968 139.7496796138705 35.196 35.66921100875968 139.7496796138705 37.258 35.66920445345515 139.74967627374195 37.258 35.66920445345515 139.74967627374195 35.196</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5596ec6b-0fc8-432e-92aa-f8b0388552c5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5596ec6b-0fc8-432e-92aa-f8b0388552c5_0">
											<gml:posList>35.669223127520894 139.74968580913563 35.196 35.669228146912594 139.74967102421525 35.196 35.669228146912594 139.74967102421525 37.258 35.669223127520894 139.74968580913563 37.258 35.669223127520894 139.74968580913563 35.196</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f6b273e5-231c-4efd-92ee-ed22a7a383de">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f6b273e5-231c-4efd-92ee-ed22a7a383de_0">
											<gml:posList>35.669231565371305 139.74967426820237 35.196 35.66922642937623 139.7496898817024 35.196 35.66922642937623 139.7496898817024 37.258 35.669231565371305 139.74967426820237 37.258 35.669231565371305 139.74967426820237 35.196</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-69095ca9-f9a3-46ad-bc02-cd70e6f346ec">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-69095ca9-f9a3-46ad-bc02-cd70e6f346ec_0">
											<gml:posList>35.66921631974011 139.7496823367162 35.196 35.669223127520894 139.74968580913563 35.196 35.669223127520894 139.74968580913563 37.258 35.66921631974011 139.7496823367162 37.258 35.66921631974011 139.7496823367162 35.196</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b605e3d8-8c9c-4d4c-a2bc-5e647e65f8fd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b605e3d8-8c9c-4d4c-a2bc-5e647e65f8fd_0">
											<gml:posList>35.66922642937623 139.7496898817024 35.196 35.669233255122855 139.74969326573532 35.196 35.669233255122855 139.74969326573532 37.258 35.66922642937623 139.7496898817024 37.258 35.66922642937623 139.7496898817024 35.196</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-be75cb02-cae4-4d91-b098-3a9e60ba27a9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-be75cb02-cae4-4d91-b098-3a9e60ba27a9_0">
											<gml:posList>35.669233255122855 139.74969326573532 35.196 35.66923422655671 139.7496903154126 35.196 35.66923422655671 139.7496903154126 37.258 35.669233255122855 139.74969326573532 37.258 35.669233255122855 139.74969326573532 35.196</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-1030b5f9-98b9-4ff0-aa82-9d78ae5cc615">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1030b5f9-98b9-4ff0-aa82-9d78ae5cc615">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1030b5f9-98b9-4ff0-aa82-9d78ae5cc615">
											<gml:posList>35.66931726605745 139.74980138583157 6.26 35.66915802714295 139.74972014202766 6.26 35.669248794951045 139.74944728591734 6.26 35.669289334807665 139.74946754625432 6.26 35.66930159485401 139.74943069464825 6.26 35.66937724741279 139.74946993967865 6.26 35.66935323020908 139.74954099134305 6.26 35.66939515794802 139.74956094101216 6.26 35.66931726605745 139.74980138583157 6.26</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-9aaf9868-3b89-40ee-a27e-7428dd3706fa">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9aaf9868-3b89-40ee-a27e-7428dd3706fa">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9aaf9868-3b89-40ee-a27e-7428dd3706fa">
											<gml:posList>35.66915802714295 139.74972014202766 29.273 35.66916317217076 139.74971752978453 29.273 35.66917193325924 139.74969119780647 29.273 35.669169738580685 139.74968494800692 29.273 35.66915802714295 139.74972014202766 29.273</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-6702c512-0e61-4faf-9487-7c5e15f8ff9e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6702c512-0e61-4faf-9487-7c5e15f8ff9e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6702c512-0e61-4faf-9487-7c5e15f8ff9e">
											<gml:posList>35.669173372324934 139.7496866894989 29.273 35.669169738580685 139.74968494800692 29.273 35.66917193325924 139.74969119780647 29.273 35.669173372324934 139.7496866894989 29.273</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-4d3e58de-03d2-48d8-a659-a01ff70a2898">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4d3e58de-03d2-48d8-a659-a01ff70a2898">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4d3e58de-03d2-48d8-a659-a01ff70a2898">
											<gml:posList>35.669169738580685 139.74968494800692 35.9 35.66917583864837 139.74968173827568 35.9 35.66925136002803 139.74945471726227 35.9 35.669248794951045 139.74944728591734 35.9 35.669169738580685 139.74968494800692 35.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-40b5a0f6-d544-4a03-8341-7102a2f65e8c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-40b5a0f6-d544-4a03-8341-7102a2f65e8c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-40b5a0f6-d544-4a03-8341-7102a2f65e8c">
											<gml:posList>35.66928802918836 139.7497417452049 35.9 35.66928541909114 139.74973435807877 35.9 35.66917583864837 139.74968173827568 35.9 35.669169738580685 139.74968494800692 35.9 35.66928802918836 139.7497417452049 35.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-9df51f47-d585-44ab-9877-731a46ae369e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9df51f47-d585-44ab-9877-731a46ae369e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9df51f47-d585-44ab-9877-731a46ae369e">
											<gml:posList>35.66931726605745 139.74980138583157 29.273 35.66931508032174 139.74979502554723 29.273 35.66916317217076 139.74971752978453 29.273 35.66915802714295 139.74972014202766 29.273 35.66931726605745 139.74980138583157 29.273</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d6b71e9f-0110-4942-adbc-30a33681e822">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d6b71e9f-0110-4942-adbc-30a33681e822">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d6b71e9f-0110-4942-adbc-30a33681e822">
											<gml:posList>35.66932987164304 139.74962598247515 28.464 35.66932621082611 139.74962419682635 28.464 35.66928802918836 139.7497417452049 28.464 35.669173372324934 139.7496866894989 28.464 35.66917193325924 139.74969119780647 28.464 35.66916317217076 139.74971752978453 28.464 35.66931508032174 139.74979502554723 28.464 35.669364405916774 139.74964278070934 28.464 35.66932987164304 139.74962598247515 28.464</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-84331ce4-fa5c-4c6f-9e0d-df1569cc7c7b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-84331ce4-fa5c-4c6f-9e0d-df1569cc7c7b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-84331ce4-fa5c-4c6f-9e0d-df1569cc7c7b">
											<gml:posList>35.66925136002803 139.74945471726227 35.196 35.66917583864837 139.74968173827568 35.196 35.66928541909114 139.74973435807877 35.196 35.6693489111429 139.74953885290975 35.196 35.66935914769794 139.74950857584398 35.196 35.66925136002803 139.74945471726227 35.196</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f681637b-f1cc-4041-9a5f-7a09398dc07e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f681637b-f1cc-4041-9a5f-7a09398dc07e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f681637b-f1cc-4041-9a5f-7a09398dc07e">
											<gml:posList>35.66929295702554 139.74946567567295 26.846 35.669289334807665 139.74946754625432 26.846 35.669291913633565 139.7494688359519 26.846 35.66929295702554 139.74946567567295 26.846</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ae560dbe-cc56-4e54-95d6-f9b5720f94c5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ae560dbe-cc56-4e54-95d6-f9b5720f94c5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ae560dbe-cc56-4e54-95d6-f9b5720f94c5">
											<gml:posList>35.669289334807665 139.74946754625432 26.846 35.66929295702554 139.74946567567295 26.846 35.66930310327111 139.74943517779127 26.846 35.66930159485401 139.74943069464825 26.846 35.669289334807665 139.74946754625432 26.846</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a0601e2e-9c2c-4adc-80cc-0849e3179721">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a0601e2e-9c2c-4adc-80cc-0849e3179721">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a0601e2e-9c2c-4adc-80cc-0849e3179721">
											<gml:posList>35.669248794951045 139.74944728591734 35.9 35.66925136002803 139.74945471726227 35.9 35.66935914769794 139.74950857584398 35.9 35.6693652388162 139.74950546551617 35.9 35.669248794951045 139.74944728591734 35.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f40f6872-2ab5-4ced-ab91-14672ef9039e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f40f6872-2ab5-4ced-ab91-14672ef9039e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f40f6872-2ab5-4ced-ab91-14672ef9039e">
											<gml:posList>35.66935323020908 139.74954099134305 35.9 35.6693489111429 139.74953885290975 35.9 35.66928541909114 139.74973435807877 35.9 35.66928802918836 139.7497417452049 35.9 35.66935323020908 139.74954099134305 35.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-101d95cb-7c5f-408a-b014-b2597b15c4bc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-101d95cb-7c5f-408a-b014-b2597b15c4bc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-101d95cb-7c5f-408a-b014-b2597b15c4bc">
											<gml:posList>35.66932987164304 139.74962598247515 29.273 35.66932766793206 139.74961971058227 29.273 35.66932621082611 139.74962419682635 29.273 35.66932987164304 139.74962598247515 29.273</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-3c054479-4da4-44f9-82cb-90c9ddccdf2c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3c054479-4da4-44f9-82cb-90c9ddccdf2c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3c054479-4da4-44f9-82cb-90c9ddccdf2c">
											<gml:posList>35.66936372141875 139.74950102656223 26.341 35.66937362515643 139.7494717550312 26.341 35.66930310327111 139.74943517779127 26.341 35.66929295702554 139.74946567567295 26.341 35.669291913633565 139.7494688359519 26.341 35.66936267802587 139.7495041868435 26.341 35.66936372141875 139.74950102656223 26.341</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e11e46b2-3ddc-4ab6-805d-5a7f4a15856f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e11e46b2-3ddc-4ab6-805d-5a7f4a15856f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e11e46b2-3ddc-4ab6-805d-5a7f4a15856f">
											<gml:posList>35.66930159485401 139.74943069464825 26.846 35.66930310327111 139.74943517779127 26.846 35.66937362515643 139.7494717550312 26.846 35.66937724741279 139.74946993967865 26.846 35.66930159485401 139.74943069464825 26.846</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-97a86b35-321a-4dc1-864b-51f154817ade">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-97a86b35-321a-4dc1-864b-51f154817ade">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-97a86b35-321a-4dc1-864b-51f154817ade">
											<gml:posList>35.669369523832444 139.74964006906768 29.273 35.669364405916774 139.74964278070934 29.273 35.66931508032174 139.74979502554723 29.273 35.66931726605745 139.74980138583157 29.273 35.669369523832444 139.74964006906768 29.273</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-95e6000f-deb6-47cb-b9ff-81914935eecc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-95e6000f-deb6-47cb-b9ff-81914935eecc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-95e6000f-deb6-47cb-b9ff-81914935eecc">
											<gml:posList>35.66932766793206 139.74961971058227 29.273 35.66932987164304 139.74962598247515 29.273 35.669364405916774 139.74964278070934 29.273 35.669369523832444 139.74964006906768 29.273 35.66932766793206 139.74961971058227 29.273</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-7a29dc91-11ba-451a-93b1-3e4e1a7134a3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7a29dc91-11ba-451a-93b1-3e4e1a7134a3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7a29dc91-11ba-451a-93b1-3e4e1a7134a3">
											<gml:posList>35.66935323020908 139.74954099134305 35.9 35.6693652388162 139.74950546551617 35.9 35.66935914769794 139.74950857584398 35.9 35.6693489111429 139.74953885290975 35.9 35.66935323020908 139.74954099134305 35.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-637ab191-c6ce-4c3c-aaa4-8dcab443d954">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-637ab191-c6ce-4c3c-aaa4-8dcab443d954">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-637ab191-c6ce-4c3c-aaa4-8dcab443d954">
											<gml:posList>35.66932766793206 139.74961971058227 23.058 35.66936648517783 139.7496385920593 23.058 35.669390356359884 139.74956486740288 23.058 35.66935161120487 139.7495459748345 23.058 35.66932766793206 139.74961971058227 23.058</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-2d3ab704-4bdd-40f4-8fbb-efffda735888">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2d3ab704-4bdd-40f4-8fbb-efffda735888">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2d3ab704-4bdd-40f4-8fbb-efffda735888">
											<gml:posList>35.66936267802587 139.7495041868435 26.846 35.6693652388162 139.74950546551617 26.846 35.66936372141875 139.74950102656223 26.846 35.66936267802587 139.7495041868435 26.846</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-bbc094d0-5303-40a0-9fd1-9ade032d7cdb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bbc094d0-5303-40a0-9fd1-9ade032d7cdb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bbc094d0-5303-40a0-9fd1-9ade032d7cdb">
											<gml:posList>35.66937724741279 139.74946993967865 26.846 35.66937362515643 139.7494717550312 26.846 35.66936372141875 139.74950102656223 26.846 35.6693652388162 139.74950546551617 26.846 35.66937724741279 139.74946993967865 26.846</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-9449a09a-c32f-40c9-aa7c-d0a61ddf8a06">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9449a09a-c32f-40c9-aa7c-d0a61ddf8a06">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9449a09a-c32f-40c9-aa7c-d0a61ddf8a06">
											<gml:posList>35.66939515794802 139.74956094101216 23.7 35.66935323020908 139.74954099134305 23.7 35.66935161120487 139.7495459748345 23.7 35.669390356359884 139.74956486740288 23.7 35.66936648517783 139.7496385920593 23.7 35.669369523832444 139.74964006906768 23.7 35.66939515794802 139.74956094101216 23.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-66513980-b566-4283-8ae4-63a81f0b15dd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-66513980-b566-4283-8ae4-63a81f0b15dd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-66513980-b566-4283-8ae4-63a81f0b15dd">
											<gml:posList>35.66916317217076 139.74971752978453 29.273 35.66916317217076 139.74971752978453 28.464 35.66917193325924 139.74969119780647 28.464 35.66917193325924 139.74969119780647 29.273 35.66916317217076 139.74971752978453 29.273</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ebb8f666-01fa-4483-bcfe-b3a5428b623b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ebb8f666-01fa-4483-bcfe-b3a5428b623b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ebb8f666-01fa-4483-bcfe-b3a5428b623b">
											<gml:posList>35.66917193325924 139.74969119780647 29.273 35.66917193325924 139.74969119780647 28.464 35.669173372324934 139.7496866894989 28.464 35.669173372324934 139.7496866894989 29.273 35.66917193325924 139.74969119780647 29.273</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-72a4e057-516a-4a53-99a4-31bcf623c9ca">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-72a4e057-516a-4a53-99a4-31bcf623c9ca">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-72a4e057-516a-4a53-99a4-31bcf623c9ca">
											<gml:posList>35.669248794951045 139.74944728591734 6.26 35.66915802714295 139.74972014202766 6.26 35.66915802714295 139.74972014202766 29.273 35.669169738580685 139.74968494800692 29.273 35.669169738580685 139.74968494800692 35.9 35.669248794951045 139.74944728591734 35.9 35.669248794951045 139.74944728591734 6.26</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-97c08fb2-1981-4489-a0b1-43e7836d2959">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-97c08fb2-1981-4489-a0b1-43e7836d2959">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-97c08fb2-1981-4489-a0b1-43e7836d2959">
											<gml:posList>35.66917583864837 139.74968173827568 35.9 35.66917583864837 139.74968173827568 35.196 35.66925136002803 139.74945471726227 35.196 35.66925136002803 139.74945471726227 35.9 35.66917583864837 139.74968173827568 35.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-26ceb508-2a83-4d2c-93a0-09f95b8d5196">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-26ceb508-2a83-4d2c-93a0-09f95b8d5196">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-26ceb508-2a83-4d2c-93a0-09f95b8d5196">
											<gml:posList>35.669169738580685 139.74968494800692 35.9 35.669169738580685 139.74968494800692 29.273 35.669173372324934 139.7496866894989 29.273 35.669173372324934 139.7496866894989 28.464 35.66928802918836 139.7497417452049 28.464 35.66928802918836 139.7497417452049 35.9 35.669169738580685 139.74968494800692 35.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2c3a9d9a-ba99-4d57-81c8-1b5a802dd022">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2c3a9d9a-ba99-4d57-81c8-1b5a802dd022">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2c3a9d9a-ba99-4d57-81c8-1b5a802dd022">
											<gml:posList>35.66928541909114 139.74973435807877 35.9 35.66928541909114 139.74973435807877 35.196 35.66917583864837 139.74968173827568 35.196 35.66917583864837 139.74968173827568 35.9 35.66928541909114 139.74973435807877 35.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-78c15e61-cd0b-4ed1-82f8-9c26b7887eee">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-78c15e61-cd0b-4ed1-82f8-9c26b7887eee">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-78c15e61-cd0b-4ed1-82f8-9c26b7887eee">
											<gml:posList>35.66915802714295 139.74972014202766 6.26 35.66931726605745 139.74980138583157 6.26 35.66931726605745 139.74980138583157 29.273 35.66915802714295 139.74972014202766 29.273 35.66915802714295 139.74972014202766 6.26</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0938939a-5e37-478a-b974-4be8b62517a9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0938939a-5e37-478a-b974-4be8b62517a9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0938939a-5e37-478a-b974-4be8b62517a9">
											<gml:posList>35.66931508032174 139.74979502554723 29.273 35.66931508032174 139.74979502554723 28.464 35.66916317217076 139.74971752978453 28.464 35.66916317217076 139.74971752978453 29.273 35.66931508032174 139.74979502554723 29.273</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-fb7a4075-3e63-4ac6-af80-275eab4a4a4f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fb7a4075-3e63-4ac6-af80-275eab4a4a4f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fb7a4075-3e63-4ac6-af80-275eab4a4a4f">
											<gml:posList>35.669291913633565 139.7494688359519 26.846 35.669291913633565 139.7494688359519 26.341 35.66929295702554 139.74946567567295 26.341 35.66929295702554 139.74946567567295 26.846 35.669291913633565 139.7494688359519 26.846</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0b8721c0-87df-49db-889a-a5a5d12313c9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0b8721c0-87df-49db-889a-a5a5d12313c9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0b8721c0-87df-49db-889a-a5a5d12313c9">
											<gml:posList>35.66930159485401 139.74943069464825 6.26 35.669289334807665 139.74946754625432 6.26 35.669289334807665 139.74946754625432 26.846 35.66930159485401 139.74943069464825 26.846 35.66930159485401 139.74943069464825 6.26</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e56b989d-6208-4791-8a46-5001bef7963f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e56b989d-6208-4791-8a46-5001bef7963f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e56b989d-6208-4791-8a46-5001bef7963f">
											<gml:posList>35.66929295702554 139.74946567567295 26.846 35.66929295702554 139.74946567567295 26.341 35.66930310327111 139.74943517779127 26.341 35.66930310327111 139.74943517779127 26.846 35.66929295702554 139.74946567567295 26.846</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-148a5f43-fe78-4bc0-b552-a67cd03ed860">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-148a5f43-fe78-4bc0-b552-a67cd03ed860">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-148a5f43-fe78-4bc0-b552-a67cd03ed860">
											<gml:posList>35.66925136002803 139.74945471726227 35.9 35.66925136002803 139.74945471726227 35.196 35.66935914769794 139.74950857584398 35.196 35.66935914769794 139.74950857584398 35.9 35.66925136002803 139.74945471726227 35.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ea423df6-33ab-41cb-af25-80f3fc416315">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ea423df6-33ab-41cb-af25-80f3fc416315">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ea423df6-33ab-41cb-af25-80f3fc416315">
											<gml:posList>35.66936267802587 139.7495041868435 26.846 35.66936267802587 139.7495041868435 26.341 35.669291913633565 139.7494688359519 26.341 35.669291913633565 139.7494688359519 26.846 35.669289334807665 139.74946754625432 26.846 35.669289334807665 139.74946754625432 6.26 35.669248794951045 139.74944728591734 6.26 35.669248794951045 139.74944728591734 35.9 35.6693652388162 139.74950546551617 35.9 35.6693652388162 139.74950546551617 26.846 35.66936267802587 139.7495041868435 26.846</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-aa657cb7-cca5-4d6b-96bd-4edf75fde43e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-aa657cb7-cca5-4d6b-96bd-4edf75fde43e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-aa657cb7-cca5-4d6b-96bd-4edf75fde43e">
											<gml:posList>35.6693489111429 139.74953885290975 35.9 35.6693489111429 139.74953885290975 35.196 35.66928541909114 139.74973435807877 35.196 35.66928541909114 139.74973435807877 35.9 35.6693489111429 139.74953885290975 35.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c8fe1499-1e33-4ce0-a841-55cfa2463fe6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c8fe1499-1e33-4ce0-a841-55cfa2463fe6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c8fe1499-1e33-4ce0-a841-55cfa2463fe6">
											<gml:posList>35.66935161120487 139.7495459748345 23.7 35.66935323020908 139.74954099134305 23.7 35.66935323020908 139.74954099134305 35.9 35.66928802918836 139.7497417452049 35.9 35.66928802918836 139.7497417452049 28.464 35.66932621082611 139.74962419682635 28.464 35.66932621082611 139.74962419682635 29.273 35.66932766793206 139.74961971058227 29.273 35.66932766793206 139.74961971058227 23.058 35.66935161120487 139.7495459748345 23.058 35.66935161120487 139.7495459748345 23.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6c464ba0-7d5a-4097-910e-63e4bcb94fc1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6c464ba0-7d5a-4097-910e-63e4bcb94fc1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6c464ba0-7d5a-4097-910e-63e4bcb94fc1">
											<gml:posList>35.66932621082611 139.74962419682635 29.273 35.66932621082611 139.74962419682635 28.464 35.66932987164304 139.74962598247515 28.464 35.66932987164304 139.74962598247515 29.273 35.66932621082611 139.74962419682635 29.273</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e482546c-4d81-4bb2-a378-f9dd25c45b0e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e482546c-4d81-4bb2-a378-f9dd25c45b0e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e482546c-4d81-4bb2-a378-f9dd25c45b0e">
											<gml:posList>35.66930310327111 139.74943517779127 26.846 35.66930310327111 139.74943517779127 26.341 35.66937362515643 139.7494717550312 26.341 35.66937362515643 139.7494717550312 26.846 35.66930310327111 139.74943517779127 26.846</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-57f787f4-5a34-4e2d-b9c8-d4de56846bc4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-57f787f4-5a34-4e2d-b9c8-d4de56846bc4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-57f787f4-5a34-4e2d-b9c8-d4de56846bc4">
											<gml:posList>35.66937724741279 139.74946993967865 6.26 35.66930159485401 139.74943069464825 6.26 35.66930159485401 139.74943069464825 26.846 35.66937724741279 139.74946993967865 26.846 35.66937724741279 139.74946993967865 6.26</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8829d6db-6eea-45ac-a4e4-e8fa9e496a6b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8829d6db-6eea-45ac-a4e4-e8fa9e496a6b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8829d6db-6eea-45ac-a4e4-e8fa9e496a6b">
											<gml:posList>35.669364405916774 139.74964278070934 29.273 35.669364405916774 139.74964278070934 28.464 35.66931508032174 139.74979502554723 28.464 35.66931508032174 139.74979502554723 29.273 35.669364405916774 139.74964278070934 29.273</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f49ae821-c0f9-4ab4-8ed2-56770b287d22">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f49ae821-c0f9-4ab4-8ed2-56770b287d22">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f49ae821-c0f9-4ab4-8ed2-56770b287d22">
											<gml:posList>35.66932987164304 139.74962598247515 29.273 35.66932987164304 139.74962598247515 28.464 35.669364405916774 139.74964278070934 28.464 35.669364405916774 139.74964278070934 29.273 35.66932987164304 139.74962598247515 29.273</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-004ca533-9b94-4bcd-ab70-da10c5b39509">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-004ca533-9b94-4bcd-ab70-da10c5b39509">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-004ca533-9b94-4bcd-ab70-da10c5b39509">
											<gml:posList>35.66932766793206 139.74961971058227 23.058 35.66932766793206 139.74961971058227 29.273 35.669369523832444 139.74964006906768 29.273 35.669369523832444 139.74964006906768 23.7 35.66936648517783 139.7496385920593 23.7 35.66936648517783 139.7496385920593 23.058 35.66932766793206 139.74961971058227 23.058</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-25ab1b22-26df-419c-a6a9-089bba75f0bd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-25ab1b22-26df-419c-a6a9-089bba75f0bd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-25ab1b22-26df-419c-a6a9-089bba75f0bd">
											<gml:posList>35.66935914769794 139.74950857584398 35.9 35.66935914769794 139.74950857584398 35.196 35.6693489111429 139.74953885290975 35.196 35.6693489111429 139.74953885290975 35.9 35.66935914769794 139.74950857584398 35.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-bd59c63e-777c-42fc-98a5-66be1f07ef68">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bd59c63e-777c-42fc-98a5-66be1f07ef68">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bd59c63e-777c-42fc-98a5-66be1f07ef68">
											<gml:posList>35.669369523832444 139.74964006906768 23.7 35.669369523832444 139.74964006906768 29.273 35.66931726605745 139.74980138583157 29.273 35.66931726605745 139.74980138583157 6.26 35.66939515794802 139.74956094101216 6.26 35.66939515794802 139.74956094101216 23.7 35.669369523832444 139.74964006906768 23.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6a00f9d9-8fc9-4c2e-8e1f-2de5e23a72cb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6a00f9d9-8fc9-4c2e-8e1f-2de5e23a72cb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6a00f9d9-8fc9-4c2e-8e1f-2de5e23a72cb">
											<gml:posList>35.66936372141875 139.74950102656223 26.846 35.66936372141875 139.74950102656223 26.341 35.66936267802587 139.7495041868435 26.341 35.66936267802587 139.7495041868435 26.846 35.66936372141875 139.74950102656223 26.846</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-38cef15a-9f5b-494a-a82f-3f17b1c272b7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-38cef15a-9f5b-494a-a82f-3f17b1c272b7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-38cef15a-9f5b-494a-a82f-3f17b1c272b7">
											<gml:posList>35.6693652388162 139.74950546551617 26.846 35.6693652388162 139.74950546551617 35.9 35.66935323020908 139.74954099134305 35.9 35.66935323020908 139.74954099134305 23.7 35.66935323020908 139.74954099134305 6.26 35.66937724741279 139.74946993967865 6.26 35.66937724741279 139.74946993967865 26.846 35.6693652388162 139.74950546551617 26.846</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-66009606-7021-4ad4-b079-10183ba7b8af">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-66009606-7021-4ad4-b079-10183ba7b8af">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-66009606-7021-4ad4-b079-10183ba7b8af">
											<gml:posList>35.66937362515643 139.7494717550312 26.846 35.66937362515643 139.7494717550312 26.341 35.66936372141875 139.74950102656223 26.341 35.66936372141875 139.74950102656223 26.846 35.66937362515643 139.7494717550312 26.846</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1ba999b0-b98d-4ebd-8cd1-5de7ab7814df">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1ba999b0-b98d-4ebd-8cd1-5de7ab7814df">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1ba999b0-b98d-4ebd-8cd1-5de7ab7814df">
											<gml:posList>35.66935161120487 139.7495459748345 23.7 35.66935161120487 139.7495459748345 23.058 35.669390356359884 139.74956486740288 23.058 35.669390356359884 139.74956486740288 23.7 35.66935161120487 139.7495459748345 23.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-bf8e10c3-a489-4f23-83b3-4d6558bc0e12">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bf8e10c3-a489-4f23-83b3-4d6558bc0e12">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bf8e10c3-a489-4f23-83b3-4d6558bc0e12">
											<gml:posList>35.66939515794802 139.74956094101216 6.26 35.66935323020908 139.74954099134305 6.26 35.66935323020908 139.74954099134305 23.7 35.66939515794802 139.74956094101216 23.7 35.66939515794802 139.74956094101216 6.26</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7c881306-48b3-4f36-94b3-b0d5dac969cb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7c881306-48b3-4f36-94b3-b0d5dac969cb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7c881306-48b3-4f36-94b3-b0d5dac969cb">
											<gml:posList>35.669390356359884 139.74956486740288 23.7 35.669390356359884 139.74956486740288 23.058 35.66936648517783 139.7496385920593 23.058 35.66936648517783 139.7496385920593 23.7 35.669390356359884 139.74956486740288 23.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区虎ノ門一丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-441</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">555.48645</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1210</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>7</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>