<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_e5914395-7a31-4ac8-85eb-0f58e6882ce6">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001001</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">401</bldg:usage>
			<bldg:measuredHeight uom="m">24.7</bldg:measuredHeight>
			<bldg:storeysAboveGround>8</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.669344466120705 139.7420720578457 0 35.669347778675096 139.74204234001962 0 35.66933078598685 139.74203996236 0 35.6693332081768 139.74201288557333 0 35.669230203182394 139.74199431288574 0 35.66922258791963 139.74205551695545 0 35.669344466120705 139.7420720578457 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669344466120705 139.7420720578457 9.858 35.66922258791963 139.74205551695545 9.858 35.669230203182394 139.74199431288574 9.858 35.6693332081768 139.74201288557333 9.858 35.66933078598685 139.74203996236 9.858 35.669347778675096 139.74204234001962 9.858 35.669344466120705 139.7420720578457 9.858</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669344466120705 139.7420720578457 9.858 35.669347778675096 139.74204234001962 9.858 35.669347778675096 139.74204234001962 34.54 35.669344466120705 139.7420720578457 34.54 35.669344466120705 139.7420720578457 9.858</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669347778675096 139.74204234001962 9.858 35.66933078598685 139.74203996236 9.858 35.66933078598685 139.74203996236 34.54 35.669347778675096 139.74204234001962 34.54 35.669347778675096 139.74204234001962 9.858</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66933078598685 139.74203996236 9.858 35.6693332081768 139.74201288557333 9.858 35.6693332081768 139.74201288557333 34.54 35.66933078598685 139.74203996236 34.54 35.66933078598685 139.74203996236 9.858</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6693332081768 139.74201288557333 9.858 35.669230203182394 139.74199431288574 9.858 35.669230203182394 139.74199431288574 34.54 35.6693332081768 139.74201288557333 34.54 35.6693332081768 139.74201288557333 9.858</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669230203182394 139.74199431288574 9.858 35.66922258791963 139.74205551695545 9.858 35.66922258791963 139.74205551695545 34.54 35.669230203182394 139.74199431288574 34.54 35.669230203182394 139.74199431288574 9.858</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66922258791963 139.74205551695545 9.858 35.669344466120705 139.7420720578457 9.858 35.669344466120705 139.7420720578457 34.54 35.66922258791963 139.74205551695545 34.54 35.66922258791963 139.74205551695545 9.858</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669344466120705 139.7420720578457 34.54 35.669347778675096 139.74204234001962 34.54 35.66933078598685 139.74203996236 34.54 35.6693332081768 139.74201288557333 34.54 35.669230203182394 139.74199431288574 34.54 35.66922258791963 139.74205551695545 34.54 35.669344466120705 139.7420720578457 34.54</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-38c1a1b6-fc36-4ad6-a721-e148cbf4fef1"/>
							<gml:surfaceMember xlink:href="#poly-f7d5af91-095b-4274-a90b-0d3fb505c192"/>
							<gml:surfaceMember xlink:href="#poly-ab82ec0b-2207-4f51-bd3f-0a717c491d8a"/>
							<gml:surfaceMember xlink:href="#poly-ad875c6a-402a-48b5-ae44-85f77ab4dec1"/>
							<gml:surfaceMember xlink:href="#poly-38fd3d4b-b5ea-4298-9e09-8656e48eb0b7"/>
							<gml:surfaceMember xlink:href="#poly-265a7e7e-e20c-4021-a2fe-aa8fbcf248db"/>
							<gml:surfaceMember xlink:href="#poly-8aa7108b-c6b1-4254-a2a7-b0a03f7038e8"/>
							<gml:surfaceMember xlink:href="#poly-27195c0c-38e4-49ba-9f21-1143d05383ac"/>
							<gml:surfaceMember xlink:href="#poly-999b3a1a-1f35-46e1-9866-f477d9104c3c"/>
							<gml:surfaceMember xlink:href="#poly-6de0fa09-146b-4b6c-aa7b-66eda29a12d3"/>
							<gml:surfaceMember xlink:href="#poly-03af1150-0d15-4c6b-824d-93704e988466"/>
							<gml:surfaceMember xlink:href="#poly-a5c4c401-159c-43e0-bca7-5353b51c9966"/>
							<gml:surfaceMember xlink:href="#poly-64b40426-338b-4b53-83bb-15f1afadec6a"/>
							<gml:surfaceMember xlink:href="#poly-d85f177b-b52b-4410-9a8f-5f8ee873ac40"/>
							<gml:surfaceMember xlink:href="#poly-4a0fe383-20a3-47cd-bf6f-b734f6c6501e"/>
							<gml:surfaceMember xlink:href="#poly-f1fac56d-4a19-4261-a256-c13a7b2820d5"/>
							<gml:surfaceMember xlink:href="#poly-3cdc749e-b13e-4cf7-a33f-6b7454bd2501"/>
							<gml:surfaceMember xlink:href="#poly-f1d4d5ef-2c96-4c89-9a53-c6fc876804c1"/>
							<gml:surfaceMember xlink:href="#poly-63ed8857-9ea7-446a-ab4e-2020f1d2e2a9"/>
							<gml:surfaceMember xlink:href="#poly-10c5a433-b0ab-4e21-b054-0f89d5f901a0"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_e5914395-7a31-4ac8-85eb-0f58e6882ce6_BuildingInstallation_1060">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5d617cb3-c29b-43b7-a915-70e3b89e691f">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66933320818518 139.74201289661943 9.93 35.669352536266345 139.74201637622545 9.93 35.669356235662924 139.74202134276555 9.93 35.669356692714935 139.74202973729518 9.93 35.66935462592347 139.74203813469862 9.93 35.66935210417425 139.7420408990994 9.93 35.669347778675125 139.74204234001962 9.93 35.66933078598685 139.74203996235997 9.93 35.66933320818518 139.74201289661943 9.93</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4c7984e6-3924-4936-a9cc-41bd49cd9266">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4c7984e6-3924-4936-a9cc-41bd49cd9266_0">
											<gml:posList>35.669352536266345 139.74201637622545 34.241 35.669352536266345 139.74201637622545 9.93 35.66933320818518 139.74201289661943 9.93 35.66933320818518 139.74201289661943 33.349 35.66935070622894 139.74201604692612 34.241 35.669352536266345 139.74201637622545 34.241</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0a5ab850-f292-432d-8d01-512bfc2a7661">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0a5ab850-f292-432d-8d01-512bfc2a7661_0">
											<gml:posList>35.669356235662924 139.74202134276555 34.241 35.669356235662924 139.74202134276555 9.93 35.669352536266345 139.74201637622545 9.93 35.669352536266345 139.74201637622545 34.241 35.669356235662924 139.74202134276555 34.241</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c16da940-726d-48e4-8139-42094423978a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c16da940-726d-48e4-8139-42094423978a_0">
											<gml:posList>35.66933320818518 139.74201289661943 33.349 35.66933201943682 139.74202618644992 33.349 35.669349282754865 139.74202885099757 34.241 35.66935070622894 139.74201604692612 34.241 35.66933320818518 139.74201289661943 33.349</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cfcd0403-b881-4e67-913c-169637da50ff">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cfcd0403-b881-4e67-913c-169637da50ff_0">
											<gml:posList>35.6693566298115 139.74202999142756 34.241 35.669356692714935 139.74202973729518 34.241 35.669356235662924 139.74202134276555 34.241 35.669352536266345 139.74201637622545 34.241 35.66935070622894 139.74201604692612 34.241 35.669349282754865 139.74202885099757 34.241 35.6693566298115 139.74202999142756 34.241</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-14fb198b-0367-4e7c-928d-2f9318b5940f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-14fb198b-0367-4e7c-928d-2f9318b5940f_0">
											<gml:posList>35.669356692714935 139.74202973729518 34.241 35.669356692714935 139.74202973729518 9.93 35.669356235662924 139.74202134276555 9.93 35.669356235662924 139.74202134276555 34.241 35.669356692714935 139.74202973729518 34.241</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-30f62979-7078-429f-8e7c-3c8c9a034c41">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-30f62979-7078-429f-8e7c-3c8c9a034c41_0">
											<gml:posList>35.66933320818518 139.74201289661943 33.349 35.66933320818518 139.74201289661943 9.93 35.66933078598685 139.74203996235997 9.93 35.66933078598685 139.74203996235997 35.109 35.66933201943682 139.74202618644992 35.109 35.66933201943682 139.74202618644992 33.349 35.66933320818518 139.74201289661943 33.349</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-99dec0b6-9e33-4c37-92be-396c19bb8022">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-99dec0b6-9e33-4c37-92be-396c19bb8022_0">
											<gml:posList>35.66933201943682 139.74202618644992 33.349 35.66933201943682 139.74202618644992 35.109 35.669349282754865 139.74202885099757 34.241 35.66933201943682 139.74202618644992 33.349</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d217411f-54a9-44e7-b86c-5749d3bc2fe3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d217411f-54a9-44e7-b86c-5749d3bc2fe3_0">
											<gml:posList>35.66935462592347 139.74203813469862 34.241 35.66935462592347 139.74203813469862 9.93 35.669356692714935 139.74202973729518 9.93 35.669356692714935 139.74202973729518 34.241 35.6693566298115 139.74202999142756 34.241 35.66935462592347 139.74203813469862 34.241</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-380ead6b-4d07-4c34-bb43-e88dcdd0b76d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-380ead6b-4d07-4c34-bb43-e88dcdd0b76d_0">
											<gml:posList>35.66933201943682 139.74202618644992 35.109 35.66933078598685 139.74203996235997 35.109 35.669347778675125 139.74204234001962 34.241 35.669349282754865 139.74202885099757 34.241 35.66933201943682 139.74202618644992 35.109</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-79128f99-7084-4e3c-b729-e1feb86c4bea">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-79128f99-7084-4e3c-b729-e1feb86c4bea_0">
											<gml:posList>35.669347778675125 139.74204234001962 34.241 35.66935210417425 139.7420408990994 34.241 35.66935462592347 139.74203813469862 34.241 35.6693566298115 139.74202999142756 34.241 35.669349282754865 139.74202885099757 34.241 35.669347778675125 139.74204234001962 34.241</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8f47eae7-3745-4ba1-927e-6010255813d1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8f47eae7-3745-4ba1-927e-6010255813d1_0">
											<gml:posList>35.66935210417425 139.7420408990994 34.241 35.66935210417425 139.7420408990994 9.93 35.66935462592347 139.74203813469862 9.93 35.66935462592347 139.74203813469862 34.241 35.66935210417425 139.7420408990994 34.241</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d72acc9a-859e-4fd2-85f3-e5973425963c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d72acc9a-859e-4fd2-85f3-e5973425963c_0">
											<gml:posList>35.66933078598685 139.74203996235997 35.109 35.66933078598685 139.74203996235997 9.93 35.669347778675125 139.74204234001962 9.93 35.669347778675125 139.74204234001962 34.241 35.66933078598685 139.74203996235997 35.109</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9621c8f2-f210-42dd-b5c7-654da778db56">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9621c8f2-f210-42dd-b5c7-654da778db56_0">
											<gml:posList>35.669347778675125 139.74204234001962 34.241 35.669347778675125 139.74204234001962 9.93 35.66935210417425 139.7420408990994 9.93 35.66935210417425 139.7420408990994 34.241 35.669347778675125 139.74204234001962 34.241</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_e5914395-7a31-4ac8-85eb-0f58e6882ce6_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c6fb4c2d-0dd3-4bd6-9a17-b722c6424883">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6692956371542 139.74202241697284 34.489 35.669294356757455 139.7420456042159 34.489 35.669277932704205 139.74204424215162 34.489 35.66927921310069 139.74202105491327 34.489 35.6692956371542 139.74202241697284 34.489</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5bbdc933-c464-427e-9f42-3891e44dba1a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5bbdc933-c464-427e-9f42-3891e44dba1a_0">
											<gml:posList>35.66927921310069 139.74202105491327 37.417 35.6692956371542 139.74202241697284 37.417 35.6692956371542 139.74202241697284 34.489 35.66927921310069 139.74202105491327 34.489 35.66927921310069 139.74202105491327 37.417</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-04772a9a-c891-443a-8c8a-43ea22aae4ab">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-04772a9a-c891-443a-8c8a-43ea22aae4ab_0">
											<gml:posList>35.669277932704205 139.74204424215162 34.489 35.669277932704205 139.74204424215162 37.417 35.66927921310069 139.74202105491327 37.417 35.66927921310069 139.74202105491327 34.489 35.669277932704205 139.74204424215162 34.489</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8d9c6781-17e8-4f6a-9763-cc6115e17cac">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8d9c6781-17e8-4f6a-9763-cc6115e17cac_0">
											<gml:posList>35.6692956371542 139.74202241697284 37.417 35.66927921310069 139.74202105491327 37.417 35.669277932704205 139.74204424215162 37.417 35.669294356757455 139.7420456042159 37.417 35.6692956371542 139.74202241697284 37.417</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8046a316-7175-48b4-905e-4ecae974934d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8046a316-7175-48b4-905e-4ecae974934d_0">
											<gml:posList>35.6692956371542 139.74202241697284 34.489 35.6692956371542 139.74202241697284 37.417 35.669294356757455 139.7420456042159 37.417 35.669294356757455 139.7420456042159 34.489 35.6692956371542 139.74202241697284 34.489</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3a32e35a-77cf-470b-8056-a4c422097c85">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3a32e35a-77cf-470b-8056-a4c422097c85_0">
											<gml:posList>35.669294356757455 139.7420456042159 34.489 35.669294356757455 139.7420456042159 37.417 35.669277932704205 139.74204424215162 37.417 35.669277932704205 139.74204424215162 34.489 35.669294356757455 139.7420456042159 34.489</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-38c1a1b6-fc36-4ad6-a721-e148cbf4fef1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-38c1a1b6-fc36-4ad6-a721-e148cbf4fef1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-38c1a1b6-fc36-4ad6-a721-e148cbf4fef1">
											<gml:posList>35.66922258791961 139.74205551695542 9.858 35.669230203182366 139.74199431288574 9.858 35.6693332081768 139.74201288557333 9.858 35.66933078598685 139.74203996235997 9.858 35.669347778675125 139.74204234001962 9.858 35.669344466120684 139.7420720578457 9.858 35.66922258791961 139.74205551695542 9.858</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f7d5af91-095b-4274-a90b-0d3fb505c192">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f7d5af91-095b-4274-a90b-0d3fb505c192">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f7d5af91-095b-4274-a90b-0d3fb505c192">
											<gml:posList>35.66922258791961 139.74205551695542 35.4 35.66922550628988 139.74205277420023 35.4 35.669232342107954 139.74199783415554 35.4 35.669230203182366 139.74199431288574 35.4 35.66922258791961 139.74205551695542 35.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ab82ec0b-2207-4f51-bd3f-0a717c491d8a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ab82ec0b-2207-4f51-bd3f-0a717c491d8a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ab82ec0b-2207-4f51-bd3f-0a717c491d8a">
											<gml:posList>35.669230203182366 139.74199431288574 35.4 35.669232342107954 139.74199783415554 35.4 35.66933041591591 139.7420155177289 35.4 35.6693332081768 139.74201288557333 35.4 35.669230203182366 139.74199431288574 35.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ad875c6a-402a-48b5-ae44-85f77ab4dec1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ad875c6a-402a-48b5-ae44-85f77ab4dec1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ad875c6a-402a-48b5-ae44-85f77ab4dec1">
											<gml:posList>35.669344466120684 139.7420720578457 35.4 35.66934228219566 139.74206862498917 35.4 35.66922550628988 139.74205277420023 35.4 35.66922258791961 139.74205551695542 35.4 35.669344466120684 139.7420720578457 35.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-38fd3d4b-b5ea-4298-9e09-8656e48eb0b7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-38fd3d4b-b5ea-4298-9e09-8656e48eb0b7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-38fd3d4b-b5ea-4298-9e09-8656e48eb0b7">
											<gml:posList>35.669232342107954 139.74199783415554 34.489 35.66922550628988 139.74205277420023 34.489 35.66934228219566 139.74206862498917 34.489 35.669344914370775 139.7420450606256 34.489 35.66932798478699 139.74204269393974 34.489 35.66933041591591 139.7420155177289 34.489 35.669232342107954 139.74199783415554 34.489</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-265a7e7e-e20c-4021-a2fe-aa8fbcf248db">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-265a7e7e-e20c-4021-a2fe-aa8fbcf248db">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-265a7e7e-e20c-4021-a2fe-aa8fbcf248db">
											<gml:posList>35.66933078598685 139.74203996235997 35.4 35.6693332081768 139.74201288557333 35.4 35.66933041591591 139.7420155177289 35.4 35.66932798478699 139.74204269393974 35.4 35.66933078598685 139.74203996235997 35.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-8aa7108b-c6b1-4254-a2a7-b0a03f7038e8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8aa7108b-c6b1-4254-a2a7-b0a03f7038e8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8aa7108b-c6b1-4254-a2a7-b0a03f7038e8">
											<gml:posList>35.66933078598685 139.74203996235997 35.4 35.66932798478699 139.74204269393974 35.4 35.669344914370775 139.7420450606256 35.4 35.669347778675125 139.74204234001962 35.4 35.66933078598685 139.74203996235997 35.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-27195c0c-38e4-49ba-9f21-1143d05383ac">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-27195c0c-38e4-49ba-9f21-1143d05383ac">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-27195c0c-38e4-49ba-9f21-1143d05383ac">
											<gml:posList>35.669347778675125 139.74204234001962 35.4 35.669344914370775 139.7420450606256 35.4 35.66934228219566 139.74206862498917 35.4 35.669344466120684 139.7420720578457 35.4 35.669347778675125 139.74204234001962 35.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-999b3a1a-1f35-46e1-9866-f477d9104c3c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-999b3a1a-1f35-46e1-9866-f477d9104c3c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-999b3a1a-1f35-46e1-9866-f477d9104c3c">
											<gml:posList>35.6693332081768 139.74201288557333 9.858 35.669230203182366 139.74199431288574 9.858 35.669230203182366 139.74199431288574 35.4 35.6693332081768 139.74201288557333 35.4 35.6693332081768 139.74201288557333 9.858</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6de0fa09-146b-4b6c-aa7b-66eda29a12d3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6de0fa09-146b-4b6c-aa7b-66eda29a12d3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6de0fa09-146b-4b6c-aa7b-66eda29a12d3">
											<gml:posList>35.669232342107954 139.74199783415554 35.4 35.669232342107954 139.74199783415554 34.489 35.66933041591591 139.7420155177289 34.489 35.66933041591591 139.7420155177289 35.4 35.669232342107954 139.74199783415554 35.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-03af1150-0d15-4c6b-824d-93704e988466">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-03af1150-0d15-4c6b-824d-93704e988466">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-03af1150-0d15-4c6b-824d-93704e988466">
											<gml:posList>35.669230203182366 139.74199431288574 9.858 35.66922258791961 139.74205551695542 9.858 35.66922258791961 139.74205551695542 35.4 35.669230203182366 139.74199431288574 35.4 35.669230203182366 139.74199431288574 9.858</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a5c4c401-159c-43e0-bca7-5353b51c9966">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a5c4c401-159c-43e0-bca7-5353b51c9966">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a5c4c401-159c-43e0-bca7-5353b51c9966">
											<gml:posList>35.66922550628988 139.74205277420023 35.4 35.66922550628988 139.74205277420023 34.489 35.669232342107954 139.74199783415554 34.489 35.669232342107954 139.74199783415554 35.4 35.66922550628988 139.74205277420023 35.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-64b40426-338b-4b53-83bb-15f1afadec6a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-64b40426-338b-4b53-83bb-15f1afadec6a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-64b40426-338b-4b53-83bb-15f1afadec6a">
											<gml:posList>35.66933078598685 139.74203996235997 9.858 35.6693332081768 139.74201288557333 9.858 35.6693332081768 139.74201288557333 35.4 35.66933078598685 139.74203996235997 35.4 35.66933078598685 139.74203996235997 9.858</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d85f177b-b52b-4410-9a8f-5f8ee873ac40">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d85f177b-b52b-4410-9a8f-5f8ee873ac40">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d85f177b-b52b-4410-9a8f-5f8ee873ac40">
											<gml:posList>35.66933041591591 139.7420155177289 35.4 35.66933041591591 139.7420155177289 34.489 35.66932798478699 139.74204269393974 34.489 35.66932798478699 139.74204269393974 35.4 35.66933041591591 139.7420155177289 35.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4a0fe383-20a3-47cd-bf6f-b734f6c6501e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4a0fe383-20a3-47cd-bf6f-b734f6c6501e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4a0fe383-20a3-47cd-bf6f-b734f6c6501e">
											<gml:posList>35.669347778675125 139.74204234001962 9.858 35.66933078598685 139.74203996235997 9.858 35.66933078598685 139.74203996235997 35.4 35.669347778675125 139.74204234001962 35.4 35.669347778675125 139.74204234001962 9.858</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f1fac56d-4a19-4261-a256-c13a7b2820d5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f1fac56d-4a19-4261-a256-c13a7b2820d5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f1fac56d-4a19-4261-a256-c13a7b2820d5">
											<gml:posList>35.66932798478699 139.74204269393974 35.4 35.66932798478699 139.74204269393974 34.489 35.669344914370775 139.7420450606256 34.489 35.669344914370775 139.7420450606256 35.4 35.66932798478699 139.74204269393974 35.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3cdc749e-b13e-4cf7-a33f-6b7454bd2501">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3cdc749e-b13e-4cf7-a33f-6b7454bd2501">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3cdc749e-b13e-4cf7-a33f-6b7454bd2501">
											<gml:posList>35.669344914370775 139.7420450606256 35.4 35.669344914370775 139.7420450606256 34.489 35.66934228219566 139.74206862498917 34.489 35.66934228219566 139.74206862498917 35.4 35.669344914370775 139.7420450606256 35.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f1d4d5ef-2c96-4c89-9a53-c6fc876804c1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f1d4d5ef-2c96-4c89-9a53-c6fc876804c1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f1d4d5ef-2c96-4c89-9a53-c6fc876804c1">
											<gml:posList>35.669344466120684 139.7420720578457 9.858 35.669347778675125 139.74204234001962 9.858 35.669347778675125 139.74204234001962 35.4 35.669344466120684 139.7420720578457 35.4 35.669344466120684 139.7420720578457 9.858</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-63ed8857-9ea7-446a-ab4e-2020f1d2e2a9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-63ed8857-9ea7-446a-ab4e-2020f1d2e2a9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-63ed8857-9ea7-446a-ab4e-2020f1d2e2a9">
											<gml:posList>35.66934228219566 139.74206862498917 35.4 35.66934228219566 139.74206862498917 34.489 35.66922550628988 139.74205277420023 34.489 35.66922550628988 139.74205277420023 35.4 35.66934228219566 139.74206862498917 35.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-10c5a433-b0ab-4e21-b054-0f89d5f901a0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-10c5a433-b0ab-4e21-b054-0f89d5f901a0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-10c5a433-b0ab-4e21-b054-0f89d5f901a0">
											<gml:posList>35.66922258791961 139.74205551695542 9.858 35.669344466120684 139.7420720578457 9.858 35.669344466120684 139.7420720578457 35.4 35.66922258791961 139.74205551695542 35.4 35.66922258791961 139.74205551695542 9.858</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂一丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-7453</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">74.20755</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1210</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>6</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.01</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:bldgRealEstateIDAttribute>
				<uro:RealEstateIDAttribute>
					<uro:realEstateIDOfBuilding>0104001168768-0000</uro:realEstateIDOfBuilding>
					<uro:numberOfRealEstateIDOfLand>1</uro:numberOfRealEstateIDOfLand>
					<uro:realEstateIDOfLand>0104001163960-0000</uro:realEstateIDOfLand>
					<uro:matchingScore>54</uro:matchingScore>
				</uro:RealEstateIDAttribute>
			</uro:bldgRealEstateIDAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>