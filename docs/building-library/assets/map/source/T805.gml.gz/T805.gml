<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_e6565d1e-69fa-4139-8ae6-ac89d004bae6">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3001</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">413</bldg:usage>
			<bldg:measuredHeight uom="m">6.3</bldg:measuredHeight>
			<bldg:storeysAboveGround>2</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.6715336556535 139.74065290700196 0 35.671464408525075 139.7405779156563 0 35.67143345240261 139.74062086675184 0 35.671426875905276 139.74061373838 0 35.6714024027196 139.7406476791315 0 35.671478226279156 139.74072977677156 0 35.6715336556535 139.74065290700196 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6715336556535 139.74065290700196 8.46 35.671478226279156 139.74072977677156 8.46 35.6714024027196 139.7406476791315 8.46 35.671426875905276 139.74061373838 8.46 35.67143345240261 139.74062086675184 8.46 35.671464408525075 139.7405779156563 8.46 35.6715336556535 139.74065290700196 8.46</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6715336556535 139.74065290700196 8.46 35.671464408525075 139.7405779156563 8.46 35.671464408525075 139.7405779156563 14.77 35.6715336556535 139.74065290700196 14.77 35.6715336556535 139.74065290700196 8.46</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671464408525075 139.7405779156563 8.46 35.67143345240261 139.74062086675184 8.46 35.67143345240261 139.74062086675184 14.77 35.671464408525075 139.7405779156563 14.77 35.671464408525075 139.7405779156563 8.46</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67143345240261 139.74062086675184 8.46 35.671426875905276 139.74061373838 8.46 35.671426875905276 139.74061373838 14.77 35.67143345240261 139.74062086675184 14.77 35.67143345240261 139.74062086675184 8.46</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671426875905276 139.74061373838 8.46 35.6714024027196 139.7406476791315 8.46 35.6714024027196 139.7406476791315 14.77 35.671426875905276 139.74061373838 14.77 35.671426875905276 139.74061373838 8.46</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6714024027196 139.7406476791315 8.46 35.671478226279156 139.74072977677156 8.46 35.671478226279156 139.74072977677156 14.77 35.6714024027196 139.7406476791315 14.77 35.6714024027196 139.7406476791315 8.46</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671478226279156 139.74072977677156 8.46 35.6715336556535 139.74065290700196 8.46 35.6715336556535 139.74065290700196 14.77 35.671478226279156 139.74072977677156 14.77 35.671478226279156 139.74072977677156 8.46</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6715336556535 139.74065290700196 14.77 35.671464408525075 139.7405779156563 14.77 35.67143345240261 139.74062086675184 14.77 35.671426875905276 139.74061373838 14.77 35.6714024027196 139.7406476791315 14.77 35.671478226279156 139.74072977677156 14.77 35.6715336556535 139.74065290700196 14.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-865e7f2e-ef89-4309-997a-870be223ef1f"/>
							<gml:surfaceMember xlink:href="#poly-e49fdd50-277a-4876-9848-d61fc80d31cf"/>
							<gml:surfaceMember xlink:href="#poly-c3c46603-4eec-4112-b329-8a65b3fcb41f"/>
							<gml:surfaceMember xlink:href="#poly-775e2897-c6ab-41db-a34d-30cd53336602"/>
							<gml:surfaceMember xlink:href="#poly-3750fda8-ff9f-400a-a126-52c9c3b4c943"/>
							<gml:surfaceMember xlink:href="#poly-dbc17b3c-f8f9-4178-a24b-dd05d85f5193"/>
							<gml:surfaceMember xlink:href="#poly-131c6b36-4e23-4d86-b5d6-e0f64f18def0"/>
							<gml:surfaceMember xlink:href="#poly-353e9be4-b953-4db1-857c-729fdf040ad0"/>
							<gml:surfaceMember xlink:href="#poly-298301c2-3351-4479-9da4-d0be6d34ab18"/>
							<gml:surfaceMember xlink:href="#poly-51747820-1814-4028-a969-617985d94364"/>
							<gml:surfaceMember xlink:href="#poly-a9a8e864-9864-4a31-9963-a9c1aa548976"/>
							<gml:surfaceMember xlink:href="#poly-8529138b-f774-49c1-a47d-2fc7aae4a343"/>
							<gml:surfaceMember xlink:href="#poly-7a28a0a8-6b28-48a5-86b7-9ae47265327f"/>
							<gml:surfaceMember xlink:href="#poly-0c9ba08d-042c-461e-8ec3-cff2d7bb4ce3"/>
							<gml:surfaceMember xlink:href="#poly-ccc1ec14-0ae0-4a1f-a224-3c9dc346b665"/>
							<gml:surfaceMember xlink:href="#poly-3cc0e267-7eda-44b1-951b-b226770c9254"/>
							<gml:surfaceMember xlink:href="#poly-4cccc59d-6ae5-4a7e-bc98-826196595383"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-865e7f2e-ef89-4309-997a-870be223ef1f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-865e7f2e-ef89-4309-997a-870be223ef1f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-865e7f2e-ef89-4309-997a-870be223ef1f">
											<gml:posList>35.67147822627914 139.74072977677156 8.46 35.67140240271957 139.7406476791315 8.46 35.671426875905254 139.74061373838 8.46 35.67143345240262 139.74062086675184 8.46 35.671464408525075 139.74057791565627 8.46 35.67153365565348 139.74065290700193 8.46 35.67147822627914 139.74072977677156 8.46</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e49fdd50-277a-4876-9848-d61fc80d31cf">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e49fdd50-277a-4876-9848-d61fc80d31cf">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e49fdd50-277a-4876-9848-d61fc80d31cf">
											<gml:posList>35.671429574712796 139.74067709743252 15.43 35.671426875905254 139.74061373838 14.417 35.67140240271957 139.7406476791315 14.417 35.671429574712796 139.74067709743252 15.43</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c3c46603-4eec-4112-b329-8a65b3fcb41f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c3c46603-4eec-4112-b329-8a65b3fcb41f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c3c46603-4eec-4112-b329-8a65b3fcb41f">
											<gml:posList>35.671429574712796 139.74067709743252 15.43 35.67143345240262 139.74062086675184 14.63 35.671426875905254 139.74061373838 14.417 35.671429574712796 139.74067709743252 15.43</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-775e2897-c6ab-41db-a34d-30cd53336602">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-775e2897-c6ab-41db-a34d-30cd53336602">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-775e2897-c6ab-41db-a34d-30cd53336602">
											<gml:posList>35.67148500404545 139.74060021662686 15.43 35.671464408525075 139.74057791565627 14.63 35.67143345240262 139.74062086675184 14.63 35.671429574712796 139.74067709743252 15.43 35.67148500404545 139.74060021662686 15.43</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-3750fda8-ff9f-400a-a126-52c9c3b4c943">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3750fda8-ff9f-400a-a126-52c9c3b4c943">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3750fda8-ff9f-400a-a126-52c9c3b4c943">
											<gml:posList>35.67148500404545 139.74060021662686 15.43 35.671429574712796 139.74067709743252 15.43 35.67145273224476 139.74070216810696 14.417 35.67150815258798 139.7406252983532 14.417 35.67148500404545 139.74060021662686 15.43</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-dbc17b3c-f8f9-4178-a24b-dd05d85f5193">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-dbc17b3c-f8f9-4178-a24b-dd05d85f5193">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-dbc17b3c-f8f9-4178-a24b-dd05d85f5193">
											<gml:posList>35.67145273224476 139.74070216810696 14.417 35.67146252932039 139.74071278343274 14.634 35.67151795867551 139.74063590262008 14.634 35.67150815258798 139.7406252983532 14.417 35.67145273224476 139.74070216810696 14.417</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-131c6b36-4e23-4d86-b5d6-e0f64f18def0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-131c6b36-4e23-4d86-b5d6-e0f64f18def0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-131c6b36-4e23-4d86-b5d6-e0f64f18def0">
											<gml:posList>35.67153365565348 139.74065290700193 14.417 35.67151795867551 139.74063590262008 14.634 35.67146252932039 139.74071278343274 14.634 35.67147822627914 139.74072977677156 14.417 35.67153365565348 139.74065290700193 14.417</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-353e9be4-b953-4db1-857c-729fdf040ad0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-353e9be4-b953-4db1-857c-729fdf040ad0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-353e9be4-b953-4db1-857c-729fdf040ad0">
											<gml:posList>35.671464408525075 139.74057791565627 14.63 35.671464408525075 139.74057791565627 8.46 35.67143345240262 139.74062086675184 8.46 35.67143345240262 139.74062086675184 14.63 35.671464408525075 139.74057791565627 14.63</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-298301c2-3351-4479-9da4-d0be6d34ab18">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-298301c2-3351-4479-9da4-d0be6d34ab18">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-298301c2-3351-4479-9da4-d0be6d34ab18">
											<gml:posList>35.67148500404545 139.74060021662686 15.43 35.67150815258798 139.7406252983532 14.417 35.671464408525075 139.74057791565627 14.63 35.67148500404545 139.74060021662686 15.43</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-51747820-1814-4028-a969-617985d94364">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-51747820-1814-4028-a969-617985d94364">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-51747820-1814-4028-a969-617985d94364">
											<gml:posList>35.67153365565348 139.74065290700193 8.46 35.671464408525075 139.74057791565627 8.46 35.671464408525075 139.74057791565627 14.63 35.67150815258798 139.7406252983532 14.417 35.67153365565348 139.74065290700193 14.417 35.67153365565348 139.74065290700193 8.46</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a9a8e864-9864-4a31-9963-a9c1aa548976">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a9a8e864-9864-4a31-9963-a9c1aa548976">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a9a8e864-9864-4a31-9963-a9c1aa548976">
											<gml:posList>35.671426875905254 139.74061373838 14.417 35.67143345240262 139.74062086675184 14.63 35.67143345240262 139.74062086675184 8.46 35.671426875905254 139.74061373838 8.46 35.671426875905254 139.74061373838 14.417</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8529138b-f774-49c1-a47d-2fc7aae4a343">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8529138b-f774-49c1-a47d-2fc7aae4a343">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8529138b-f774-49c1-a47d-2fc7aae4a343">
											<gml:posList>35.671426875905254 139.74061373838 14.417 35.671426875905254 139.74061373838 8.46 35.67140240271957 139.7406476791315 8.46 35.67140240271957 139.7406476791315 14.417 35.671426875905254 139.74061373838 14.417</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7a28a0a8-6b28-48a5-86b7-9ae47265327f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7a28a0a8-6b28-48a5-86b7-9ae47265327f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7a28a0a8-6b28-48a5-86b7-9ae47265327f">
											<gml:posList>35.67151795867551 139.74063590262008 14.634 35.67153365565348 139.74065290700193 14.417 35.67150815258798 139.7406252983532 14.417 35.67151795867551 139.74063590262008 14.634</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0c9ba08d-042c-461e-8ec3-cff2d7bb4ce3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0c9ba08d-042c-461e-8ec3-cff2d7bb4ce3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0c9ba08d-042c-461e-8ec3-cff2d7bb4ce3">
											<gml:posList>35.671429574712796 139.74067709743252 15.43 35.67140240271957 139.7406476791315 14.417 35.67145273224476 139.74070216810696 14.417 35.671429574712796 139.74067709743252 15.43</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ccc1ec14-0ae0-4a1f-a224-3c9dc346b665">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ccc1ec14-0ae0-4a1f-a224-3c9dc346b665">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ccc1ec14-0ae0-4a1f-a224-3c9dc346b665">
											<gml:posList>35.67140240271957 139.7406476791315 8.46 35.67147822627914 139.74072977677156 8.46 35.67147822627914 139.74072977677156 14.417 35.67145273224476 139.74070216810696 14.417 35.67140240271957 139.7406476791315 14.417 35.67140240271957 139.7406476791315 8.46</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3cc0e267-7eda-44b1-951b-b226770c9254">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3cc0e267-7eda-44b1-951b-b226770c9254">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3cc0e267-7eda-44b1-951b-b226770c9254">
											<gml:posList>35.67147822627914 139.74072977677156 14.417 35.67147822627914 139.74072977677156 8.46 35.67153365565348 139.74065290700193 8.46 35.67153365565348 139.74065290700193 14.417 35.67147822627914 139.74072977677156 14.417</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4cccc59d-6ae5-4a7e-bc98-826196595383">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4cccc59d-6ae5-4a7e-bc98-826196595383">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4cccc59d-6ae5-4a7e-bc98-826196595383">
											<gml:posList>35.67146252932039 139.74071278343274 14.634 35.67145273224476 139.74070216810696 14.417 35.67147822627914 139.74072977677156 14.417 35.67146252932039 139.74071278343274 14.634</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-5042</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">93.00955</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1003</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">211</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1230</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>6</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.05</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">21</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>