<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_e6f7efe1-9de8-4212-aacb-e978ff608f22">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>46</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13101046002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3001</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">411</bldg:usage>
			<bldg:measuredHeight uom="m">13.9</bldg:measuredHeight>
			<bldg:storeysAboveGround>2</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.67489481265011 139.741904565591 0 35.67490099253986 139.7419711712442 0 35.67492906733226 139.74196727283743 0 35.67495714212437 139.7419633744279 0 35.674944782467264 139.74183038397732 0 35.67491675274802 139.74183428238135 0 35.67488872302852 139.74183818078265 0 35.674889450085544 139.74184602323828 0 35.67487757125809 139.74184768277996 0 35.674730464829395 139.74186818792876 0 35.67470073366114 139.74188678056726 0 35.67470292538883 139.74192422690624 0 35.67472204092519 139.74193271118995 0 35.674726768883794 139.7419865040002 0 35.674741107695425 139.7419838364148 0 35.67474209823578 139.7419944402722 0 35.674889276887995 139.74197405678544 0 35.67488728656269 139.74195255077714 0 35.67488300593995 139.74190623608877 0 35.67489481265011 139.741904565591 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67489481265011 139.741904565591 10.4 35.67488300593995 139.74190623608877 10.4 35.67488728656269 139.74195255077714 10.4 35.674889276887995 139.74197405678544 10.4 35.67474209823578 139.7419944402722 10.4 35.674741107695425 139.7419838364148 10.4 35.674726768883794 139.7419865040002 10.4 35.67472204092519 139.74193271118995 10.4 35.67470292538883 139.74192422690624 10.4 35.67470073366114 139.74188678056726 10.4 35.674730464829395 139.74186818792876 10.4 35.67487757125809 139.74184768277996 10.4 35.674889450085544 139.74184602323828 10.4 35.67488872302852 139.74183818078265 10.4 35.67491675274802 139.74183428238135 10.4 35.674944782467264 139.74183038397732 10.4 35.67495714212437 139.7419633744279 10.4 35.67492906733226 139.74196727283743 10.4 35.67490099253986 139.7419711712442 10.4 35.67489481265011 139.741904565591 10.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67489481265011 139.741904565591 10.4 35.67490099253986 139.7419711712442 10.4 35.67490099253986 139.7419711712442 20.76 35.67489481265011 139.741904565591 20.76 35.67489481265011 139.741904565591 10.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67490099253986 139.7419711712442 10.4 35.67492906733226 139.74196727283743 10.4 35.67492906733226 139.74196727283743 20.76 35.67490099253986 139.7419711712442 20.76 35.67490099253986 139.7419711712442 10.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67492906733226 139.74196727283743 10.4 35.67495714212437 139.7419633744279 10.4 35.67495714212437 139.7419633744279 20.76 35.67492906733226 139.74196727283743 20.76 35.67492906733226 139.74196727283743 10.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67495714212437 139.7419633744279 10.4 35.674944782467264 139.74183038397732 10.4 35.674944782467264 139.74183038397732 20.76 35.67495714212437 139.7419633744279 20.76 35.67495714212437 139.7419633744279 10.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.674944782467264 139.74183038397732 10.4 35.67491675274802 139.74183428238135 10.4 35.67491675274802 139.74183428238135 20.76 35.674944782467264 139.74183038397732 20.76 35.674944782467264 139.74183038397732 10.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67491675274802 139.74183428238135 10.4 35.67488872302852 139.74183818078265 10.4 35.67488872302852 139.74183818078265 20.76 35.67491675274802 139.74183428238135 20.76 35.67491675274802 139.74183428238135 10.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67488872302852 139.74183818078265 10.4 35.674889450085544 139.74184602323828 10.4 35.674889450085544 139.74184602323828 20.76 35.67488872302852 139.74183818078265 20.76 35.67488872302852 139.74183818078265 10.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.674889450085544 139.74184602323828 10.4 35.67487757125809 139.74184768277996 10.4 35.67487757125809 139.74184768277996 20.76 35.674889450085544 139.74184602323828 20.76 35.674889450085544 139.74184602323828 10.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67487757125809 139.74184768277996 10.4 35.674730464829395 139.74186818792876 10.4 35.674730464829395 139.74186818792876 20.76 35.67487757125809 139.74184768277996 20.76 35.67487757125809 139.74184768277996 10.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.674730464829395 139.74186818792876 10.4 35.67470073366114 139.74188678056726 10.4 35.67470073366114 139.74188678056726 20.76 35.674730464829395 139.74186818792876 20.76 35.674730464829395 139.74186818792876 10.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67470073366114 139.74188678056726 10.4 35.67470292538883 139.74192422690624 10.4 35.67470292538883 139.74192422690624 20.76 35.67470073366114 139.74188678056726 20.76 35.67470073366114 139.74188678056726 10.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67470292538883 139.74192422690624 10.4 35.67472204092519 139.74193271118995 10.4 35.67472204092519 139.74193271118995 20.76 35.67470292538883 139.74192422690624 20.76 35.67470292538883 139.74192422690624 10.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67472204092519 139.74193271118995 10.4 35.674726768883794 139.7419865040002 10.4 35.674726768883794 139.7419865040002 20.76 35.67472204092519 139.74193271118995 20.76 35.67472204092519 139.74193271118995 10.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.674726768883794 139.7419865040002 10.4 35.674741107695425 139.7419838364148 10.4 35.674741107695425 139.7419838364148 20.76 35.674726768883794 139.7419865040002 20.76 35.674726768883794 139.7419865040002 10.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.674741107695425 139.7419838364148 10.4 35.67474209823578 139.7419944402722 10.4 35.67474209823578 139.7419944402722 20.76 35.674741107695425 139.7419838364148 20.76 35.674741107695425 139.7419838364148 10.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67474209823578 139.7419944402722 10.4 35.674889276887995 139.74197405678544 10.4 35.674889276887995 139.74197405678544 20.76 35.67474209823578 139.7419944402722 20.76 35.67474209823578 139.7419944402722 10.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.674889276887995 139.74197405678544 10.4 35.67488728656269 139.74195255077714 10.4 35.67488728656269 139.74195255077714 20.76 35.674889276887995 139.74197405678544 20.76 35.674889276887995 139.74197405678544 10.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67488728656269 139.74195255077714 10.4 35.67488300593995 139.74190623608877 10.4 35.67488300593995 139.74190623608877 20.76 35.67488728656269 139.74195255077714 20.76 35.67488728656269 139.74195255077714 10.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67488300593995 139.74190623608877 10.4 35.67489481265011 139.741904565591 10.4 35.67489481265011 139.741904565591 20.76 35.67488300593995 139.74190623608877 20.76 35.67488300593995 139.74190623608877 10.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67489481265011 139.741904565591 20.76 35.67490099253986 139.7419711712442 20.76 35.67492906733226 139.74196727283743 20.76 35.67495714212437 139.7419633744279 20.76 35.674944782467264 139.74183038397732 20.76 35.67491675274802 139.74183428238135 20.76 35.67488872302852 139.74183818078265 20.76 35.674889450085544 139.74184602323828 20.76 35.67487757125809 139.74184768277996 20.76 35.674730464829395 139.74186818792876 20.76 35.67470073366114 139.74188678056726 20.76 35.67470292538883 139.74192422690624 20.76 35.67472204092519 139.74193271118995 20.76 35.674726768883794 139.7419865040002 20.76 35.674741107695425 139.7419838364148 20.76 35.67474209823578 139.7419944402722 20.76 35.674889276887995 139.74197405678544 20.76 35.67488728656269 139.74195255077714 20.76 35.67488300593995 139.74190623608877 20.76 35.67489481265011 139.741904565591 20.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-4fea94b6-5c3e-42a0-823e-1607839bfff6"/>
							<gml:surfaceMember xlink:href="#poly-54b9b575-a12e-4414-8ac2-d74b0563b993"/>
							<gml:surfaceMember xlink:href="#poly-4e1e16c6-ebd6-4665-b3e6-492a91a0dfa4"/>
							<gml:surfaceMember xlink:href="#poly-a99372f5-07ab-4557-8b0e-28a3875efa95"/>
							<gml:surfaceMember xlink:href="#poly-33069bb7-c95a-41e3-8104-57d3bc120fbe"/>
							<gml:surfaceMember xlink:href="#poly-140bc2b7-19ed-481d-92fc-01f0cef23b14"/>
							<gml:surfaceMember xlink:href="#poly-b1e8967e-86cc-49d6-bb15-eb65eca6d3ad"/>
							<gml:surfaceMember xlink:href="#poly-eef19bfa-9160-4def-9b57-6a67b90b4554"/>
							<gml:surfaceMember xlink:href="#poly-298cc2ad-fd36-435c-9353-9e8a57116dc5"/>
							<gml:surfaceMember xlink:href="#poly-2b5ade10-93ae-440b-bae4-458d1cddcade"/>
							<gml:surfaceMember xlink:href="#poly-e181e9ff-06e4-4df9-9582-9a863c592704"/>
							<gml:surfaceMember xlink:href="#poly-076c28dd-5ef8-45e3-b492-c7a46488aa3b"/>
							<gml:surfaceMember xlink:href="#poly-b8a106c2-61b1-4c5e-898f-3ee3b066b661"/>
							<gml:surfaceMember xlink:href="#poly-5e3a75fd-e91e-4ab0-be00-791be338d4b9"/>
							<gml:surfaceMember xlink:href="#poly-bfa40ee9-3177-424a-8774-0e1eed1659cf"/>
							<gml:surfaceMember xlink:href="#poly-58d8d004-a100-4dfe-baa6-07a796fdd87d"/>
							<gml:surfaceMember xlink:href="#poly-71014fd3-952b-441c-897a-b5a554e05cca"/>
							<gml:surfaceMember xlink:href="#poly-4f0a6892-905a-4528-8ba3-6c89629a77fd"/>
							<gml:surfaceMember xlink:href="#poly-7acf99cb-9eb0-4406-aab0-31e8d8ccbf5b"/>
							<gml:surfaceMember xlink:href="#poly-92be4cd2-b73f-4f8a-b9f2-7ca1b5667fbb"/>
							<gml:surfaceMember xlink:href="#poly-998b17dc-5892-409b-97df-bc7e7a41eb54"/>
							<gml:surfaceMember xlink:href="#poly-ab13e260-3d6d-4e15-8f48-169262411a78"/>
							<gml:surfaceMember xlink:href="#poly-6af54ade-e925-4052-98f5-c07b9cab1bcd"/>
							<gml:surfaceMember xlink:href="#poly-24f43221-7593-4f97-bc3b-d5be0e823933"/>
							<gml:surfaceMember xlink:href="#poly-346b1a33-4bcf-4ace-939c-4fb6ea2f4476"/>
							<gml:surfaceMember xlink:href="#poly-a2606741-09c7-4bdb-9d1f-ea20978c8cec"/>
							<gml:surfaceMember xlink:href="#poly-a3626b1a-d8e6-42ad-83da-4f8bbe75f57c"/>
							<gml:surfaceMember xlink:href="#poly-8ad9c145-ea60-4a2c-b445-ec7a9b0ff01c"/>
							<gml:surfaceMember xlink:href="#poly-0536abb6-ecb6-4d32-a9eb-6568ae3bd758"/>
							<gml:surfaceMember xlink:href="#poly-34a9960e-557f-4807-a663-d4cbed41dbb3"/>
							<gml:surfaceMember xlink:href="#poly-1540843d-c127-4e5f-b3cc-fac5f38dbfd4"/>
							<gml:surfaceMember xlink:href="#poly-ec973a7c-cff8-4e7f-bc12-1ffa75fa7ec0"/>
							<gml:surfaceMember xlink:href="#poly-50d28553-9889-4ec3-abe0-f3be4cb38ad3"/>
							<gml:surfaceMember xlink:href="#poly-2b8ad4c2-c5ad-4fbe-b343-16e97df253cf"/>
							<gml:surfaceMember xlink:href="#poly-4942a4bf-a675-4587-ad3b-b90405754607"/>
							<gml:surfaceMember xlink:href="#poly-36779887-88c5-48fd-83e9-027340f2642f"/>
							<gml:surfaceMember xlink:href="#poly-18c486be-3e6e-4e37-b26c-7477262127b8"/>
							<gml:surfaceMember xlink:href="#poly-9a5d6643-08d7-44e5-93cd-bb15bebb62ec"/>
							<gml:surfaceMember xlink:href="#poly-522afc76-80f0-4ec3-9662-6d23c6cc903b"/>
							<gml:surfaceMember xlink:href="#poly-e8b5373b-e5e8-445c-aa87-8f7d51f8ae38"/>
							<gml:surfaceMember xlink:href="#poly-76b8c8a1-fa70-4d83-9bb9-0d4cc891ddbe"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-4fea94b6-5c3e-42a0-823e-1607839bfff6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4fea94b6-5c3e-42a0-823e-1607839bfff6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4fea94b6-5c3e-42a0-823e-1607839bfff6">
											<gml:posList>35.67489481265008 139.74190456559097 10.4 35.674889450085544 139.74184602323825 10.4 35.67488872302852 139.74183818078265 10.4 35.67494478246724 139.74183038397732 10.4 35.67495714212437 139.74196337442788 10.4 35.67490099253985 139.7419711712442 10.4 35.67489481265008 139.74190456559097 10.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-54b9b575-a12e-4414-8ac2-d74b0563b993">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-54b9b575-a12e-4414-8ac2-d74b0563b993">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-54b9b575-a12e-4414-8ac2-d74b0563b993">
											<gml:posList>35.674889276887974 139.74197405678544 10.4 35.674742098235775 139.7419944402722 10.4 35.67474008984479 139.7419728790892 10.4 35.674741098681714 139.74198383642502 10.4 35.6747267688838 139.7419865040002 10.4 35.6747220409252 139.74193271118995 10.4 35.67470292538884 139.74192422690624 10.4 35.67470073366113 139.74188678056723 10.4 35.6747304648294 139.7418681879288 10.4 35.674889450085544 139.74184602323825 10.4 35.67489481265008 139.74190456559097 10.4 35.674883005939954 139.74190623608874 10.4 35.674880288598395 139.74187695390992 10.4 35.674889276887974 139.74197405678544 10.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-4e1e16c6-ebd6-4665-b3e6-492a91a0dfa4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4e1e16c6-ebd6-4665-b3e6-492a91a0dfa4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4e1e16c6-ebd6-4665-b3e6-492a91a0dfa4">
											<gml:posList>35.674889450085544 139.74184602323825 18.653 35.6748775712581 139.74184768278 18.653 35.674880288598395 139.74187695390992 19.514 35.67488084296597 139.74188291859252 19.7 35.67489267674208 139.74188128120113 19.7 35.674889450085544 139.74184602323825 18.653</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a99372f5-07ab-4557-8b0e-28a3875efa95">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a99372f5-07ab-4557-8b0e-28a3875efa95">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a99372f5-07ab-4557-8b0e-28a3875efa95">
											<gml:posList>35.6748435525167 139.74188203319554 21.353 35.674880288598395 139.74187695390992 21.326 35.6748775712581 139.74184768278 18.653 35.6747304648294 139.7418681879288 18.653 35.67473313696188 139.74189728230755 21.326 35.67482325574174 139.74188484016173 21.353 35.6748435525167 139.74188203319554 21.353</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-33069bb7-c95a-41e3-8104-57d3bc120fbe">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-33069bb7-c95a-41e3-8104-57d3bc120fbe">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-33069bb7-c95a-41e3-8104-57d3bc120fbe">
											<gml:posList>35.6748435525167 139.74188203319554 23.4 35.67482325574174 139.74188484016173 23.4 35.674834764215625 139.74189400698506 24.335 35.6748435525167 139.74188203319554 23.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-140bc2b7-19ed-481d-92fc-01f0cef23b14">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-140bc2b7-19ed-481d-92fc-01f0cef23b14">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-140bc2b7-19ed-481d-92fc-01f0cef23b14">
											<gml:posList>35.6748435525167 139.74188203319554 23.4 35.674834764215625 139.74189400698506 24.335 35.67484557019772 139.74190393684663 23.4 35.6748435525167 139.74188203319554 23.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b1e8967e-86cc-49d6-bb15-eb65eca6d3ad">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b1e8967e-86cc-49d6-bb15-eb65eca6d3ad">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b1e8967e-86cc-49d6-bb15-eb65eca6d3ad">
											<gml:posList>35.67489481265008 139.74190456559097 18.653 35.67489267674208 139.74188128120113 19.7 35.67488084296597 139.74188291859252 19.7 35.674883005939954 139.74190623608874 18.653 35.67489481265008 139.74190456559097 18.653</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-eef19bfa-9160-4def-9b57-6a67b90b4554">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-eef19bfa-9160-4def-9b57-6a67b90b4554">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-eef19bfa-9160-4def-9b57-6a67b90b4554">
											<gml:posList>35.67482325574174 139.74188484016173 23.4 35.67482526440853 139.74190674381762 23.4 35.674834764215625 139.74189400698506 24.335 35.67482325574174 139.74188484016173 23.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-298cc2ad-fd36-435c-9353-9e8a57116dc5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-298cc2ad-fd36-435c-9353-9e8a57116dc5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-298cc2ad-fd36-435c-9353-9e8a57116dc5">
											<gml:posList>35.6748435525167 139.74188203319554 21.353 35.67484557019772 139.74190393684663 22.075 35.67485208062855 139.74191912992237 22.6 35.674880288598395 139.74187695390992 21.326 35.6748435525167 139.74188203319554 21.353</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-2b5ade10-93ae-440b-bae4-458d1cddcade">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2b5ade10-93ae-440b-bae4-458d1cddcade">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2b5ade10-93ae-440b-bae4-458d1cddcade">
											<gml:posList>35.67494478246724 139.74183038397732 18.653 35.67491675274801 139.74183428238135 21.94 35.67492906733224 139.74196727283743 21.94 35.67495714212437 139.74196337442788 18.653 35.67494478246724 139.74183038397732 18.653</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e181e9ff-06e4-4df9-9582-9a863c592704">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e181e9ff-06e4-4df9-9582-9a863c592704">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e181e9ff-06e4-4df9-9582-9a863c592704">
											<gml:posList>35.674834764215625 139.74189400698506 24.335 35.67482526440853 139.74190674381762 23.4 35.67484557019772 139.74190393684663 23.4 35.674834764215625 139.74189400698506 24.335</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-076c28dd-5ef8-45e3-b492-c7a46488aa3b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-076c28dd-5ef8-45e3-b492-c7a46488aa3b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-076c28dd-5ef8-45e3-b492-c7a46488aa3b">
											<gml:posList>35.674889450085544 139.74184602323825 18.653 35.67489481265008 139.74190456559097 18.653 35.67490099253985 139.7419711712442 18.653 35.67492906733224 139.74196727283743 21.94 35.67491675274801 139.74183428238135 21.94 35.67488872302852 139.74183818078265 18.653 35.674889450085544 139.74184602323825 18.653</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b8a106c2-61b1-4c5e-898f-3ee3b066b661">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b8a106c2-61b1-4c5e-898f-3ee3b066b661">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b8a106c2-61b1-4c5e-898f-3ee3b066b661">
											<gml:posList>35.67476838799643 139.74193073619242 22.6 35.67482526440853 139.74190674381762 22.075 35.67482325574174 139.74188484016173 21.353 35.67473313696188 139.74189728230755 21.326 35.67476838799643 139.74193073619242 22.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-5e3a75fd-e91e-4ab0-be00-791be338d4b9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5e3a75fd-e91e-4ab0-be00-791be338d4b9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5e3a75fd-e91e-4ab0-be00-791be338d4b9">
											<gml:posList>35.67485208062855 139.74191912992237 22.6 35.67488728656269 139.74195255077714 21.379 35.674880288598395 139.74187695390992 21.326 35.67485208062855 139.74191912992237 22.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-bfa40ee9-3177-424a-8774-0e1eed1659cf">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bfa40ee9-3177-424a-8774-0e1eed1659cf">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bfa40ee9-3177-424a-8774-0e1eed1659cf">
											<gml:posList>35.67482526440853 139.74190674381762 22.075 35.67476838799643 139.74193073619242 22.6 35.67485208062855 139.74191912992237 22.6 35.67484557019772 139.74190393684663 22.075 35.67482526440853 139.74190674381762 22.075</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-58d8d004-a100-4dfe-baa6-07a796fdd87d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-58d8d004-a100-4dfe-baa6-07a796fdd87d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-58d8d004-a100-4dfe-baa6-07a796fdd87d">
											<gml:posList>35.67470073366113 139.74188678056723 15.7 35.67470292538884 139.74192422690624 15.7 35.6747220409252 139.74193271118995 15.7 35.6747267688838 139.7419865040002 15.7 35.674741098681714 139.74198383642502 15.7 35.67474008984479 139.7419728790892 15.7 35.6747304648294 139.7418681879288 15.7 35.67470073366113 139.74188678056723 15.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-71014fd3-952b-441c-897a-b5a554e05cca">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-71014fd3-952b-441c-897a-b5a554e05cca">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-71014fd3-952b-441c-897a-b5a554e05cca">
											<gml:posList>35.67474008984479 139.7419728790892 21.379 35.67476838799643 139.74193073619242 22.6 35.67473313696188 139.74189728230755 21.326 35.67474008984479 139.7419728790892 21.379</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-4f0a6892-905a-4528-8ba3-6c89629a77fd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4f0a6892-905a-4528-8ba3-6c89629a77fd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4f0a6892-905a-4528-8ba3-6c89629a77fd">
											<gml:posList>35.67485208062855 139.74191912992237 22.6 35.67476838799643 139.74193073619242 22.6 35.67474008984479 139.7419728790892 21.379 35.67488728656269 139.74195255077714 21.379 35.67485208062855 139.74191912992237 22.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-7acf99cb-9eb0-4406-aab0-31e8d8ccbf5b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7acf99cb-9eb0-4406-aab0-31e8d8ccbf5b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7acf99cb-9eb0-4406-aab0-31e8d8ccbf5b">
											<gml:posList>35.67488728656269 139.74195255077714 21.379 35.67474008984479 139.7419728790892 21.379 35.674742098235775 139.7419944402722 18.653 35.674889276887974 139.74197405678544 18.653 35.67488728656269 139.74195255077714 21.379</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-92be4cd2-b73f-4f8a-b9f2-7ca1b5667fbb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-92be4cd2-b73f-4f8a-b9f2-7ca1b5667fbb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-92be4cd2-b73f-4f8a-b9f2-7ca1b5667fbb">
											<gml:posList>35.674880288598395 139.74187695390992 10.4 35.674883005939954 139.74190623608874 10.4 35.674883005939954 139.74190623608874 18.653 35.67488084296597 139.74188291859252 19.7 35.674880288598395 139.74187695390992 19.514 35.674880288598395 139.74187695390992 10.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-998b17dc-5892-409b-97df-bc7e7a41eb54">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-998b17dc-5892-409b-97df-bc7e7a41eb54">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-998b17dc-5892-409b-97df-bc7e7a41eb54">
											<gml:posList>35.67474008984479 139.7419728790892 15.7 35.674741098681714 139.74198383642502 15.7 35.674741098681714 139.74198383642502 10.4 35.67474008984479 139.7419728790892 10.4 35.67474008984479 139.7419728790892 15.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ab13e260-3d6d-4e15-8f48-169262411a78">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ab13e260-3d6d-4e15-8f48-169262411a78">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ab13e260-3d6d-4e15-8f48-169262411a78">
											<gml:posList>35.67494478246724 139.74183038397732 18.653 35.67494478246724 139.74183038397732 10.4 35.67488872302852 139.74183818078265 10.4 35.67488872302852 139.74183818078265 18.653 35.67491675274801 139.74183428238135 21.94 35.67494478246724 139.74183038397732 18.653</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6af54ade-e925-4052-98f5-c07b9cab1bcd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6af54ade-e925-4052-98f5-c07b9cab1bcd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6af54ade-e925-4052-98f5-c07b9cab1bcd">
											<gml:posList>35.67488872302852 139.74183818078265 18.653 35.67488872302852 139.74183818078265 10.4 35.674889450085544 139.74184602323825 10.4 35.674889450085544 139.74184602323825 18.653 35.67488872302852 139.74183818078265 18.653</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-24f43221-7593-4f97-bc3b-d5be0e823933">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-24f43221-7593-4f97-bc3b-d5be0e823933">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-24f43221-7593-4f97-bc3b-d5be0e823933">
											<gml:posList>35.6748775712581 139.74184768278 18.653 35.674889450085544 139.74184602323825 18.653 35.674889450085544 139.74184602323825 10.4 35.6747304648294 139.7418681879288 10.4 35.6747304648294 139.7418681879288 15.7 35.6747304648294 139.7418681879288 18.653 35.6748775712581 139.74184768278 18.653</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-346b1a33-4bcf-4ace-939c-4fb6ea2f4476">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-346b1a33-4bcf-4ace-939c-4fb6ea2f4476">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-346b1a33-4bcf-4ace-939c-4fb6ea2f4476">
											<gml:posList>35.674889450085544 139.74184602323825 18.653 35.67489267674208 139.74188128120113 19.7 35.67489481265008 139.74190456559097 18.653 35.674889450085544 139.74184602323825 18.653</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a2606741-09c7-4bdb-9d1f-ea20978c8cec">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a2606741-09c7-4bdb-9d1f-ea20978c8cec">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a2606741-09c7-4bdb-9d1f-ea20978c8cec">
											<gml:posList>35.6747304648294 139.7418681879288 15.7 35.6747304648294 139.7418681879288 10.4 35.67470073366113 139.74188678056723 10.4 35.67470073366113 139.74188678056723 15.7 35.6747304648294 139.7418681879288 15.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a3626b1a-d8e6-42ad-83da-4f8bbe75f57c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a3626b1a-d8e6-42ad-83da-4f8bbe75f57c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a3626b1a-d8e6-42ad-83da-4f8bbe75f57c">
											<gml:posList>35.67482325574174 139.74188484016173 23.4 35.6748435525167 139.74188203319554 23.4 35.6748435525167 139.74188203319554 21.353 35.67482325574174 139.74188484016173 21.353 35.67482325574174 139.74188484016173 23.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8ad9c145-ea60-4a2c-b445-ec7a9b0ff01c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8ad9c145-ea60-4a2c-b445-ec7a9b0ff01c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8ad9c145-ea60-4a2c-b445-ec7a9b0ff01c">
											<gml:posList>35.6748435525167 139.74188203319554 21.353 35.6748435525167 139.74188203319554 23.4 35.67484557019772 139.74190393684663 23.4 35.67484557019772 139.74190393684663 22.075 35.6748435525167 139.74188203319554 21.353</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0536abb6-ecb6-4d32-a9eb-6568ae3bd758">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0536abb6-ecb6-4d32-a9eb-6568ae3bd758">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0536abb6-ecb6-4d32-a9eb-6568ae3bd758">
											<gml:posList>35.67482526440853 139.74190674381762 22.075 35.67482526440853 139.74190674381762 23.4 35.67482325574174 139.74188484016173 23.4 35.67482325574174 139.74188484016173 21.353 35.67482526440853 139.74190674381762 22.075</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-34a9960e-557f-4807-a663-d4cbed41dbb3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-34a9960e-557f-4807-a663-d4cbed41dbb3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-34a9960e-557f-4807-a663-d4cbed41dbb3">
											<gml:posList>35.67495714212437 139.74196337442788 18.653 35.67495714212437 139.74196337442788 10.4 35.67494478246724 139.74183038397732 10.4 35.67494478246724 139.74183038397732 18.653 35.67495714212437 139.74196337442788 18.653</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1540843d-c127-4e5f-b3cc-fac5f38dbfd4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1540843d-c127-4e5f-b3cc-fac5f38dbfd4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1540843d-c127-4e5f-b3cc-fac5f38dbfd4">
											<gml:posList>35.67484557019772 139.74190393684663 22.075 35.67484557019772 139.74190393684663 23.4 35.67482526440853 139.74190674381762 23.4 35.67482526440853 139.74190674381762 22.075 35.67484557019772 139.74190393684663 22.075</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ec973a7c-cff8-4e7f-bc12-1ffa75fa7ec0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ec973a7c-cff8-4e7f-bc12-1ffa75fa7ec0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ec973a7c-cff8-4e7f-bc12-1ffa75fa7ec0">
											<gml:posList>35.67470073366113 139.74188678056723 15.7 35.67470073366113 139.74188678056723 10.4 35.67470292538884 139.74192422690624 10.4 35.67470292538884 139.74192422690624 15.7 35.67470073366113 139.74188678056723 15.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-50d28553-9889-4ec3-abe0-f3be4cb38ad3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-50d28553-9889-4ec3-abe0-f3be4cb38ad3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-50d28553-9889-4ec3-abe0-f3be4cb38ad3">
											<gml:posList>35.674883005939954 139.74190623608874 18.653 35.674883005939954 139.74190623608874 10.4 35.67489481265008 139.74190456559097 10.4 35.67489481265008 139.74190456559097 18.653 35.674883005939954 139.74190623608874 18.653</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2b8ad4c2-c5ad-4fbe-b343-16e97df253cf">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2b8ad4c2-c5ad-4fbe-b343-16e97df253cf">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2b8ad4c2-c5ad-4fbe-b343-16e97df253cf">
											<gml:posList>35.674880288598395 139.74187695390992 19.514 35.6748775712581 139.74184768278 18.653 35.674880288598395 139.74187695390992 21.326 35.67488728656269 139.74195255077714 21.379 35.674889276887974 139.74197405678544 18.653 35.674889276887974 139.74197405678544 10.4 35.674880288598395 139.74187695390992 10.4 35.674880288598395 139.74187695390992 19.514</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4942a4bf-a675-4587-ad3b-b90405754607">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4942a4bf-a675-4587-ad3b-b90405754607">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4942a4bf-a675-4587-ad3b-b90405754607">
											<gml:posList>35.67470292538884 139.74192422690624 15.7 35.67470292538884 139.74192422690624 10.4 35.6747220409252 139.74193271118995 10.4 35.6747220409252 139.74193271118995 15.7 35.67470292538884 139.74192422690624 15.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-36779887-88c5-48fd-83e9-027340f2642f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-36779887-88c5-48fd-83e9-027340f2642f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-36779887-88c5-48fd-83e9-027340f2642f">
											<gml:posList>35.6747304648294 139.7418681879288 18.653 35.6747304648294 139.7418681879288 15.7 35.67474008984479 139.7419728790892 15.7 35.67474008984479 139.7419728790892 10.4 35.674742098235775 139.7419944402722 10.4 35.674742098235775 139.7419944402722 18.653 35.67474008984479 139.7419728790892 21.379 35.67473313696188 139.74189728230755 21.326 35.6747304648294 139.7418681879288 18.653</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-18c486be-3e6e-4e37-b26c-7477262127b8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-18c486be-3e6e-4e37-b26c-7477262127b8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-18c486be-3e6e-4e37-b26c-7477262127b8">
											<gml:posList>35.67489481265008 139.74190456559097 18.653 35.67489481265008 139.74190456559097 10.4 35.67490099253985 139.7419711712442 10.4 35.67490099253985 139.7419711712442 18.653 35.67489481265008 139.74190456559097 18.653</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9a5d6643-08d7-44e5-93cd-bb15bebb62ec">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9a5d6643-08d7-44e5-93cd-bb15bebb62ec">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9a5d6643-08d7-44e5-93cd-bb15bebb62ec">
											<gml:posList>35.6747220409252 139.74193271118995 15.7 35.6747220409252 139.74193271118995 10.4 35.6747267688838 139.7419865040002 10.4 35.6747267688838 139.7419865040002 15.7 35.6747220409252 139.74193271118995 15.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-522afc76-80f0-4ec3-9662-6d23c6cc903b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-522afc76-80f0-4ec3-9662-6d23c6cc903b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-522afc76-80f0-4ec3-9662-6d23c6cc903b">
											<gml:posList>35.67490099253985 139.7419711712442 18.653 35.67490099253985 139.7419711712442 10.4 35.67495714212437 139.74196337442788 10.4 35.67495714212437 139.74196337442788 18.653 35.67492906733224 139.74196727283743 21.94 35.67490099253985 139.7419711712442 18.653</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e8b5373b-e5e8-445c-aa87-8f7d51f8ae38">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e8b5373b-e5e8-445c-aa87-8f7d51f8ae38">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e8b5373b-e5e8-445c-aa87-8f7d51f8ae38">
											<gml:posList>35.674742098235775 139.7419944402722 18.653 35.674742098235775 139.7419944402722 10.4 35.674889276887974 139.74197405678544 10.4 35.674889276887974 139.74197405678544 18.653 35.674742098235775 139.7419944402722 18.653</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-76b8c8a1-fa70-4d83-9bb9-0d4cc891ddbe">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-76b8c8a1-fa70-4d83-9bb9-0d4cc891ddbe">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-76b8c8a1-fa70-4d83-9bb9-0d4cc891ddbe">
											<gml:posList>35.6747267688838 139.7419865040002 15.7 35.6747267688838 139.7419865040002 10.4 35.674741098681714 139.74198383642502 10.4 35.674741098681714 139.74198383642502 15.7 35.6747267688838 139.7419865040002 15.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都千代田区永田町二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13101-bldg-4613</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13101</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">296.6675</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">211</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1310</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>5</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.0</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>