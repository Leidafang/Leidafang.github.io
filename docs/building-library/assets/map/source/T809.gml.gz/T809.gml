<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_e7007615-4634-4d40-955f-327450c0b8c4">
			<core:creationDate>2024-03-15</core:creationDate>
			<bldg:measuredHeight uom="m">5.4</bldg:measuredHeight>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.671570337114325 139.73902201484 0 35.67156407295257 139.73897647780913 0 35.671533782711045 139.73898273259118 0 35.671540046879066 139.73902828065175 0 35.671570337114325 139.73902201484 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671570337114325 139.73902201484 15.77 35.671540046879066 139.73902828065175 15.77 35.671533782711045 139.73898273259118 15.77 35.67156407295257 139.73897647780913 15.77 35.671570337114325 139.73902201484 15.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671570337114325 139.73902201484 15.77 35.67156407295257 139.73897647780913 15.77 35.67156407295257 139.73897647780913 21.13 35.671570337114325 139.73902201484 21.13 35.671570337114325 139.73902201484 15.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67156407295257 139.73897647780913 15.77 35.671533782711045 139.73898273259118 15.77 35.671533782711045 139.73898273259118 21.13 35.67156407295257 139.73897647780913 21.13 35.67156407295257 139.73897647780913 15.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671533782711045 139.73898273259118 15.77 35.671540046879066 139.73902828065175 15.77 35.671540046879066 139.73902828065175 21.13 35.671533782711045 139.73898273259118 21.13 35.671533782711045 139.73898273259118 15.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671540046879066 139.73902828065175 15.77 35.671570337114325 139.73902201484 15.77 35.671570337114325 139.73902201484 21.13 35.671540046879066 139.73902828065175 21.13 35.671540046879066 139.73902828065175 15.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671570337114325 139.73902201484 21.13 35.67156407295257 139.73897647780913 21.13 35.671533782711045 139.73898273259118 21.13 35.671540046879066 139.73902828065175 21.13 35.671570337114325 139.73902201484 21.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-74c26084-3091-44e1-873b-58b9178fff52"/>
							<gml:surfaceMember xlink:href="#poly-cfaef38b-7c9b-41ce-928e-70ad2f76ff8a"/>
							<gml:surfaceMember xlink:href="#poly-900e4f81-5784-4f43-a6d0-f32ac2c1138b"/>
							<gml:surfaceMember xlink:href="#poly-51d7095a-bcbf-4c8b-b2e0-8b9e6f299fed"/>
							<gml:surfaceMember xlink:href="#poly-453574c9-fe12-46d3-b3f0-b82538c0b097"/>
							<gml:surfaceMember xlink:href="#poly-4d9d27f0-839e-45b5-b91d-1d6fd36d2be0"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-74c26084-3091-44e1-873b-58b9178fff52">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-74c26084-3091-44e1-873b-58b9178fff52">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-74c26084-3091-44e1-873b-58b9178fff52">
											<gml:posList>35.671570337114304 139.73902201484 15.77 35.67154004687906 139.73902828065175 15.77 35.67153378271102 139.73898273259118 15.77 35.67156407295255 139.73897647780913 15.77 35.671570337114304 139.73902201484 15.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-cfaef38b-7c9b-41ce-928e-70ad2f76ff8a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cfaef38b-7c9b-41ce-928e-70ad2f76ff8a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cfaef38b-7c9b-41ce-928e-70ad2f76ff8a">
											<gml:posList>35.67154004687906 139.73902828065175 21.88 35.671570337114304 139.73902201484 21.88 35.67156407295255 139.73897647780913 21.88 35.67153378271102 139.73898273259118 21.88 35.67154004687906 139.73902828065175 21.88</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-900e4f81-5784-4f43-a6d0-f32ac2c1138b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-900e4f81-5784-4f43-a6d0-f32ac2c1138b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-900e4f81-5784-4f43-a6d0-f32ac2c1138b">
											<gml:posList>35.67156407295255 139.73897647780913 15.77 35.67153378271102 139.73898273259118 15.77 35.67153378271102 139.73898273259118 21.88 35.67156407295255 139.73897647780913 21.88 35.67156407295255 139.73897647780913 15.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-51d7095a-bcbf-4c8b-b2e0-8b9e6f299fed">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-51d7095a-bcbf-4c8b-b2e0-8b9e6f299fed">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-51d7095a-bcbf-4c8b-b2e0-8b9e6f299fed">
											<gml:posList>35.671570337114304 139.73902201484 15.77 35.67156407295255 139.73897647780913 15.77 35.67156407295255 139.73897647780913 21.88 35.671570337114304 139.73902201484 21.88 35.671570337114304 139.73902201484 15.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-453574c9-fe12-46d3-b3f0-b82538c0b097">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-453574c9-fe12-46d3-b3f0-b82538c0b097">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-453574c9-fe12-46d3-b3f0-b82538c0b097">
											<gml:posList>35.67153378271102 139.73898273259118 15.77 35.67154004687906 139.73902828065175 15.77 35.67154004687906 139.73902828065175 21.88 35.67153378271102 139.73898273259118 21.88 35.67153378271102 139.73898273259118 15.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4d9d27f0-839e-45b5-b91d-1d6fd36d2be0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4d9d27f0-839e-45b5-b91d-1d6fd36d2be0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4d9d27f0-839e-45b5-b91d-1d6fd36d2be0">
											<gml:posList>35.67154004687906 139.73902828065175 15.77 35.671570337114304 139.73902201484 15.77 35.671570337114304 139.73902201484 21.88 35.67154004687906 139.73902828065175 21.88 35.67154004687906 139.73902828065175 15.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-9405</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>4</uro:specifiedFloorAreaRate>
					<uro:surveyYear>0001</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.02</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>