<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_e75cccff-0d7f-4aa3-88f9-a00a568cb686">
			<core:creationDate>2024-03-15</core:creationDate>
			<bldg:measuredHeight uom="m">6.4</bldg:measuredHeight>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.67214255573961 139.74084657736356 0 35.6722921037712 139.74061382030484 0 35.67227737309511 139.74059920070087 0 35.672128276889055 139.74083340431423 0 35.67207302639973 139.74090860630363 0 35.67208775703029 139.7409232148809 0 35.67214255573961 139.74084657736356 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67214255573961 139.74084657736356 7.26 35.67208775703029 139.7409232148809 7.26 35.67207302639973 139.74090860630363 7.26 35.672128276889055 139.74083340431423 7.26 35.67227737309511 139.74059920070087 7.26 35.6722921037712 139.74061382030484 7.26 35.67214255573961 139.74084657736356 7.26</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67214255573961 139.74084657736356 7.26 35.6722921037712 139.74061382030484 7.26 35.6722921037712 139.74061382030484 13.69 35.67214255573961 139.74084657736356 13.69 35.67214255573961 139.74084657736356 7.26</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6722921037712 139.74061382030484 7.26 35.67227737309511 139.74059920070087 7.26 35.67227737309511 139.74059920070087 13.69 35.6722921037712 139.74061382030484 13.69 35.6722921037712 139.74061382030484 7.26</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67227737309511 139.74059920070087 7.26 35.672128276889055 139.74083340431423 7.26 35.672128276889055 139.74083340431423 13.69 35.67227737309511 139.74059920070087 13.69 35.67227737309511 139.74059920070087 7.26</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672128276889055 139.74083340431423 7.26 35.67207302639973 139.74090860630363 7.26 35.67207302639973 139.74090860630363 13.69 35.672128276889055 139.74083340431423 13.69 35.672128276889055 139.74083340431423 7.26</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67207302639973 139.74090860630363 7.26 35.67208775703029 139.7409232148809 7.26 35.67208775703029 139.7409232148809 13.69 35.67207302639973 139.74090860630363 13.69 35.67207302639973 139.74090860630363 7.26</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67208775703029 139.7409232148809 7.26 35.67214255573961 139.74084657736356 7.26 35.67214255573961 139.74084657736356 13.69 35.67208775703029 139.7409232148809 13.69 35.67208775703029 139.7409232148809 7.26</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67214255573961 139.74084657736356 13.69 35.6722921037712 139.74061382030484 13.69 35.67227737309511 139.74059920070087 13.69 35.672128276889055 139.74083340431423 13.69 35.67207302639973 139.74090860630363 13.69 35.67208775703029 139.7409232148809 13.69 35.67214255573961 139.74084657736356 13.69</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-7406f9b1-70ae-442b-8721-aa78a8884b8b"/>
							<gml:surfaceMember xlink:href="#poly-d26bcbeb-8772-4a90-aa96-804fabfa45b0"/>
							<gml:surfaceMember xlink:href="#poly-023afb96-f78e-443c-a26d-5b82a5a5515b"/>
							<gml:surfaceMember xlink:href="#poly-ec0672b6-2ae9-4a66-9faa-815b04b7363b"/>
							<gml:surfaceMember xlink:href="#poly-d3da5042-68cf-4c1a-81b7-c98639b06aec"/>
							<gml:surfaceMember xlink:href="#poly-ec48b527-bc35-4b69-a882-be02b74f9345"/>
							<gml:surfaceMember xlink:href="#poly-5277813f-2f7c-4707-a592-d6cee560bb30"/>
							<gml:surfaceMember xlink:href="#poly-97cbb175-df39-4844-8677-a54aa0922d21"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-7406f9b1-70ae-442b-8721-aa78a8884b8b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7406f9b1-70ae-442b-8721-aa78a8884b8b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7406f9b1-70ae-442b-8721-aa78a8884b8b">
											<gml:posList>35.67214255573958 139.74084657736356 7.26 35.67208775703029 139.7409232148809 7.26 35.672073026399744 139.74090860630366 7.26 35.67212827688906 139.74083340431423 7.26 35.67227737309511 139.74059920070087 7.26 35.67229210377119 139.74061382030484 7.26 35.67214255573958 139.74084657736356 7.26</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d26bcbeb-8772-4a90-aa96-804fabfa45b0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d26bcbeb-8772-4a90-aa96-804fabfa45b0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d26bcbeb-8772-4a90-aa96-804fabfa45b0">
											<gml:posList>35.67214255573958 139.74084657736356 14.516 35.67229210377119 139.74061382030484 14.516 35.67227737309511 139.74059920070087 14.516 35.67212827688906 139.74083340431423 14.516 35.672073026399744 139.74090860630366 14.516 35.67208775703029 139.7409232148809 14.516 35.67214255573958 139.74084657736356 14.516</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-023afb96-f78e-443c-a26d-5b82a5a5515b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-023afb96-f78e-443c-a26d-5b82a5a5515b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-023afb96-f78e-443c-a26d-5b82a5a5515b">
											<gml:posList>35.67229210377119 139.74061382030484 14.516 35.67229210377119 139.74061382030484 7.26 35.67227737309511 139.74059920070087 7.26 35.67227737309511 139.74059920070087 14.516 35.67229210377119 139.74061382030484 14.516</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ec0672b6-2ae9-4a66-9faa-815b04b7363b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ec0672b6-2ae9-4a66-9faa-815b04b7363b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ec0672b6-2ae9-4a66-9faa-815b04b7363b">
											<gml:posList>35.67227737309511 139.74059920070087 14.516 35.67227737309511 139.74059920070087 7.26 35.67212827688906 139.74083340431423 7.26 35.67212827688906 139.74083340431423 14.516 35.67227737309511 139.74059920070087 14.516</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d3da5042-68cf-4c1a-81b7-c98639b06aec">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d3da5042-68cf-4c1a-81b7-c98639b06aec">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d3da5042-68cf-4c1a-81b7-c98639b06aec">
											<gml:posList>35.672073026399744 139.74090860630366 14.516 35.672073026399744 139.74090860630366 7.26 35.67208775703029 139.7409232148809 7.26 35.67208775703029 139.7409232148809 14.516 35.672073026399744 139.74090860630366 14.516</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ec48b527-bc35-4b69-a882-be02b74f9345">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ec48b527-bc35-4b69-a882-be02b74f9345">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ec48b527-bc35-4b69-a882-be02b74f9345">
											<gml:posList>35.67212827688906 139.74083340431423 14.516 35.67212827688906 139.74083340431423 7.26 35.672073026399744 139.74090860630366 7.26 35.672073026399744 139.74090860630366 14.516 35.67212827688906 139.74083340431423 14.516</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5277813f-2f7c-4707-a592-d6cee560bb30">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5277813f-2f7c-4707-a592-d6cee560bb30">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5277813f-2f7c-4707-a592-d6cee560bb30">
											<gml:posList>35.67208775703029 139.7409232148809 14.516 35.67208775703029 139.7409232148809 7.26 35.67214255573958 139.74084657736356 7.26 35.67214255573958 139.74084657736356 14.516 35.67208775703029 139.7409232148809 14.516</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-97cbb175-df39-4844-8677-a54aa0922d21">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-97cbb175-df39-4844-8677-a54aa0922d21">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-97cbb175-df39-4844-8677-a54aa0922d21">
											<gml:posList>35.67214255573958 139.74084657736356 14.516 35.67214255573958 139.74084657736356 7.26 35.67229210377119 139.74061382030484 7.26 35.67229210377119 139.74061382030484 14.516 35.67214255573958 139.74084657736356 14.516</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-10612</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">215</uro:landUseType>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>7</uro:specifiedFloorAreaRate>
					<uro:surveyYear>0001</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">2</uro:rank>
					<uro:depth uom="m">0.51</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>