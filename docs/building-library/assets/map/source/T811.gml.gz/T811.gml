<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_e79b44bf-806c-4afa-9ebd-de49333bbf9b">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">413</bldg:usage>
			<bldg:measuredHeight uom="m">11.8</bldg:measuredHeight>
			<bldg:storeysAboveGround>3</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.66920394102537 139.73845550458844 0 35.669168738781714 139.7385081256426 0 35.66922728376512 139.73856637981518 0 35.66926230602034 139.73851409034407 0 35.66920394102537 139.73845550458844 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66920394102537 139.73845550458844 17.076 35.66926230602034 139.73851409034407 17.076 35.66922728376512 139.73856637981518 17.076 35.669168738781714 139.7385081256426 17.076 35.66920394102537 139.73845550458844 17.076</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66920394102537 139.73845550458844 17.076 35.669168738781714 139.7385081256426 17.076 35.669168738781714 139.7385081256426 28.86 35.66920394102537 139.73845550458844 28.86 35.66920394102537 139.73845550458844 17.076</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669168738781714 139.7385081256426 17.076 35.66922728376512 139.73856637981518 17.076 35.66922728376512 139.73856637981518 28.86 35.669168738781714 139.7385081256426 28.86 35.669168738781714 139.7385081256426 17.076</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66922728376512 139.73856637981518 17.076 35.66926230602034 139.73851409034407 17.076 35.66926230602034 139.73851409034407 28.86 35.66922728376512 139.73856637981518 28.86 35.66922728376512 139.73856637981518 17.076</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66926230602034 139.73851409034407 17.076 35.66920394102537 139.73845550458844 17.076 35.66920394102537 139.73845550458844 28.86 35.66926230602034 139.73851409034407 28.86 35.66926230602034 139.73851409034407 17.076</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66920394102537 139.73845550458844 28.86 35.669168738781714 139.7385081256426 28.86 35.66922728376512 139.73856637981518 28.86 35.66926230602034 139.73851409034407 28.86 35.66920394102537 139.73845550458844 28.86</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-e6f04180-c59b-4261-a36f-f457367c2f54"/>
							<gml:surfaceMember xlink:href="#poly-1d3934cd-e52b-4a6a-b28e-6b7a5433d327"/>
							<gml:surfaceMember xlink:href="#poly-7b071358-9326-4dc7-9694-3b304eb78e4e"/>
							<gml:surfaceMember xlink:href="#poly-00e5d678-1301-414f-8b35-4b3a5b08735a"/>
							<gml:surfaceMember xlink:href="#poly-4bf8b30c-f199-4bb1-bea8-5bce3cc7ac59"/>
							<gml:surfaceMember xlink:href="#poly-d05d074f-6299-4cad-a998-4d8563bc7c95"/>
							<gml:surfaceMember xlink:href="#poly-0d8dd7da-2d43-4ab2-95c7-a0a83f5e3cb3"/>
							<gml:surfaceMember xlink:href="#poly-bd05d437-4137-424b-a3d2-af98d20f86b9"/>
							<gml:surfaceMember xlink:href="#poly-e9d82e57-4e9e-47a4-98f5-dc23c38b4174"/>
							<gml:surfaceMember xlink:href="#poly-5d8a1f4e-744f-4a95-b46e-a72059b620cd"/>
							<gml:surfaceMember xlink:href="#poly-cc6e3c18-70b2-4878-86c3-086bafd6c901"/>
							<gml:surfaceMember xlink:href="#poly-b50283c2-44ec-4a83-b2e6-84e0172bab11"/>
							<gml:surfaceMember xlink:href="#poly-52543a90-80c6-491c-b052-0cea407791fc"/>
							<gml:surfaceMember xlink:href="#poly-451d613f-3d80-4926-8532-1c0e0b398024"/>
							<gml:surfaceMember xlink:href="#poly-7bf63775-8128-49ad-a3cb-5ed065203f7a"/>
							<gml:surfaceMember xlink:href="#poly-6d8ff392-20ab-47d9-be4f-0e473b3f5e5f"/>
							<gml:surfaceMember xlink:href="#poly-3b96b729-53af-49ab-9b9a-4a74d06df5aa"/>
							<gml:surfaceMember xlink:href="#poly-100bce15-d462-4f48-b351-1d01323ede5f"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_e79b44bf-806c-4afa-9ebd-de49333bbf9b_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2dfa31a0-ddac-4fdf-9f4d-85ac65121599">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66922435955052 139.73849290461408 29.272 35.66921891111993 139.73848765311539 29.272 35.66922416867862 139.73847945069008 29.272 35.66922962612329 139.73848470217789 29.272 35.66922435955052 139.73849290461408 29.272</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-59377b81-de18-410f-9d85-ff10b2bb5603">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66924139271677 139.73852370309228 29.272 35.669246354187266 139.7385286790181 29.272 35.669235253335806 139.73854529443412 29.272 35.66923029185729 139.73854030746193 29.272 35.66924139271677 139.73852370309228 29.272</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bf17b750-817a-48ee-a5df-e03a8b0da249">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bf17b750-817a-48ee-a5df-e03a8b0da249_0">
											<gml:posList>35.66922962612329 139.73848470217789 29.272 35.66922416867862 139.73847945069008 29.272 35.66922416867862 139.73847945069008 30.482 35.66922962612329 139.73848470217789 30.482 35.66922962612329 139.73848470217789 29.272</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4a4c4cd8-8b99-4630-aa55-cde9106ad72d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4a4c4cd8-8b99-4630-aa55-cde9106ad72d_0">
											<gml:posList>35.66922416867862 139.73847945069008 29.272 35.66921891111993 139.73848765311539 29.272 35.66921891111993 139.73848765311539 30.482 35.66922416867862 139.73847945069008 30.482 35.66922416867862 139.73847945069008 29.272</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-38178240-f1c8-471d-aa7e-0fd0adae7816">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-38178240-f1c8-471d-aa7e-0fd0adae7816_0">
											<gml:posList>35.66922416867862 139.73847945069008 30.482 35.66921891111993 139.73848765311539 30.482 35.66922435955052 139.73849290461408 30.482 35.66922962612329 139.73848470217789 30.482 35.66922416867862 139.73847945069008 30.482</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-78dd8224-4ccd-4ade-994f-28773bfba7b8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-78dd8224-4ccd-4ade-994f-28773bfba7b8_0">
											<gml:posList>35.66922435955052 139.73849290461408 29.272 35.66922962612329 139.73848470217789 29.272 35.66922962612329 139.73848470217789 30.482 35.66922435955052 139.73849290461408 30.482 35.66922435955052 139.73849290461408 29.272</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-55c210ec-6e00-4215-a9bc-389a3abfeb31">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-55c210ec-6e00-4215-a9bc-389a3abfeb31_0">
											<gml:posList>35.66922435955052 139.73849290461408 29.272 35.66922435955052 139.73849290461408 30.482 35.66921891111993 139.73848765311539 30.482 35.66921891111993 139.73848765311539 29.272 35.66922435955052 139.73849290461408 29.272</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1cb60de4-ed8b-4272-8dff-2141c907796c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1cb60de4-ed8b-4272-8dff-2141c907796c_0">
											<gml:posList>35.669246354187266 139.7385286790181 29.272 35.66924139271677 139.73852370309228 29.272 35.66924139271677 139.73852370309228 30.332 35.669246354187266 139.7385286790181 30.332 35.669246354187266 139.7385286790181 29.272</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-19bb88e9-446a-4179-8d6a-2877c569d4cf">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-19bb88e9-446a-4179-8d6a-2877c569d4cf_0">
											<gml:posList>35.66924139271677 139.73852370309228 29.272 35.66923029185729 139.73854030746193 29.272 35.66923029185729 139.73854030746193 30.332 35.66924139271677 139.73852370309228 30.332 35.66924139271677 139.73852370309228 29.272</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-97189500-abda-44f5-96ab-01d9bf169483">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-97189500-abda-44f5-96ab-01d9bf169483_0">
											<gml:posList>35.669235253335806 139.73854529443412 30.332 35.669246354187266 139.7385286790181 30.332 35.66924139271677 139.73852370309228 30.332 35.66923029185729 139.73854030746193 30.332 35.669235253335806 139.73854529443412 30.332</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0966f900-2edb-414c-bfb8-4f52d8011edb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0966f900-2edb-414c-bfb8-4f52d8011edb_0">
											<gml:posList>35.669246354187266 139.7385286790181 29.272 35.669246354187266 139.7385286790181 30.332 35.669235253335806 139.73854529443412 30.332 35.669235253335806 139.73854529443412 29.272 35.669246354187266 139.7385286790181 29.272</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6af378fa-9291-4bdd-a0ff-9eb82b419ff3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6af378fa-9291-4bdd-a0ff-9eb82b419ff3_0">
											<gml:posList>35.66923029185729 139.73854030746193 29.272 35.669235253335806 139.73854529443412 29.272 35.669235253335806 139.73854529443412 30.332 35.66923029185729 139.73854030746193 30.332 35.66923029185729 139.73854030746193 29.272</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-e6f04180-c59b-4261-a36f-f457367c2f54">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e6f04180-c59b-4261-a36f-f457367c2f54">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e6f04180-c59b-4261-a36f-f457367c2f54">
											<gml:posList>35.66920394102537 139.73845550458842 17.076 35.66926230602033 139.73851409034407 17.076 35.66922728376511 139.73856637981515 17.076 35.66916873878172 139.7385081256426 17.076 35.66920394102537 139.73845550458842 17.076</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-1d3934cd-e52b-4a6a-b28e-6b7a5433d327">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1d3934cd-e52b-4a6a-b28e-6b7a5433d327">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1d3934cd-e52b-4a6a-b28e-6b7a5433d327">
											<gml:posList>35.66922443844644 139.73847863295953 29.528 35.66923495678396 139.73848920268145 29.528 35.669235983139124 139.73848766605929 29.528 35.669224201888134 139.73847583857608 29.528 35.66922443844644 139.73847863295953 29.528</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-7b071358-9326-4dc7-9694-3b304eb78e4e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7b071358-9326-4dc7-9694-3b304eb78e4e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7b071358-9326-4dc7-9694-3b304eb78e4e">
											<gml:posList>35.669224201888134 139.73847583857608 29.528 35.66920394102537 139.73845550458842 24.773 35.66916873878172 139.7385081256426 24.773 35.66918927012571 139.7385285587297 29.528 35.669224201888134 139.73847583857608 29.528</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-00e5d678-1301-414f-8b35-4b3a5b08735a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-00e5d678-1301-414f-8b35-4b3a5b08735a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-00e5d678-1301-414f-8b35-4b3a5b08735a">
											<gml:posList>35.66918927012571 139.7385285587297 29.528 35.66919155036306 139.738528257789 29.528 35.66922443844644 139.73847863295953 29.528 35.669224201888134 139.73847583857608 29.528 35.66918927012571 139.7385285587297 29.528</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-4bf8b30c-f199-4bb1-bea8-5bce3cc7ac59">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4bf8b30c-f199-4bb1-bea8-5bce3cc7ac59">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4bf8b30c-f199-4bb1-bea8-5bce3cc7ac59">
											<gml:posList>35.669250061767244 139.7385324082173 31.819 35.66926230602033 139.73851409034407 31.819 35.669235983139124 139.73848766605929 31.819 35.669223738890004 139.7385059839305 31.819 35.669250061767244 139.7385324082173 31.819</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d05d074f-6299-4cad-a998-4d8563bc7c95">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d05d074f-6299-4cad-a998-4d8563bc7c95">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d05d074f-6299-4cad-a998-4d8563bc7c95">
											<gml:posList>35.66919155036306 139.738528257789 29.272 35.66922704720884 139.73856358543136 29.272 35.66924879885449 139.73853115045472 29.272 35.669223738890004 139.7385059839305 29.272 35.66923495678396 139.73848920268145 29.272 35.66922443844644 139.73847863295953 29.272 35.66919155036306 139.738528257789 29.272</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-0d8dd7da-2d43-4ab2-95c7-a0a83f5e3cb3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0d8dd7da-2d43-4ab2-95c7-a0a83f5e3cb3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0d8dd7da-2d43-4ab2-95c7-a0a83f5e3cb3">
											<gml:posList>35.66922728376511 139.73856637981515 29.528 35.66922704720884 139.73856358543136 29.528 35.66919155036306 139.738528257789 29.528 35.66918927012571 139.7385285587297 29.528 35.66922728376511 139.73856637981515 29.528</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-bd05d437-4137-424b-a3d2-af98d20f86b9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bd05d437-4137-424b-a3d2-af98d20f86b9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bd05d437-4137-424b-a3d2-af98d20f86b9">
											<gml:posList>35.66922704720884 139.73856358543136 29.528 35.66922728376511 139.73856637981515 29.528 35.66925005275352 139.73853240822797 29.528 35.66924879885449 139.73853115045472 29.528 35.66922704720884 139.73856358543136 29.528</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e9d82e57-4e9e-47a4-98f5-dc23c38b4174">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e9d82e57-4e9e-47a4-98f5-dc23c38b4174">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e9d82e57-4e9e-47a4-98f5-dc23c38b4174">
											<gml:posList>35.66919155036306 139.738528257789 29.528 35.66919155036306 139.738528257789 29.272 35.66922443844644 139.73847863295953 29.272 35.66922443844644 139.73847863295953 29.528 35.66919155036306 139.738528257789 29.528</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5d8a1f4e-744f-4a95-b46e-a72059b620cd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5d8a1f4e-744f-4a95-b46e-a72059b620cd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5d8a1f4e-744f-4a95-b46e-a72059b620cd">
											<gml:posList>35.66920394102537 139.73845550458842 17.076 35.66916873878172 139.7385081256426 17.076 35.66916873878172 139.7385081256426 24.773 35.66920394102537 139.73845550458842 24.773 35.66920394102537 139.73845550458842 17.076</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-cc6e3c18-70b2-4878-86c3-086bafd6c901">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cc6e3c18-70b2-4878-86c3-086bafd6c901">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cc6e3c18-70b2-4878-86c3-086bafd6c901">
											<gml:posList>35.66922443844644 139.73847863295953 29.528 35.66922443844644 139.73847863295953 29.272 35.66923495678396 139.73848920268145 29.272 35.66923495678396 139.73848920268145 29.528 35.66922443844644 139.73847863295953 29.528</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b50283c2-44ec-4a83-b2e6-84e0172bab11">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b50283c2-44ec-4a83-b2e6-84e0172bab11">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b50283c2-44ec-4a83-b2e6-84e0172bab11">
											<gml:posList>35.66920394102537 139.73845550458842 24.773 35.669224201888134 139.73847583857608 29.528 35.669235983139124 139.73848766605929 29.528 35.669235983139124 139.73848766605929 31.819 35.66926230602033 139.73851409034407 31.819 35.66926230602033 139.73851409034407 17.076 35.66920394102537 139.73845550458842 17.076 35.66920394102537 139.73845550458842 24.773</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-52543a90-80c6-491c-b052-0cea407791fc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-52543a90-80c6-491c-b052-0cea407791fc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-52543a90-80c6-491c-b052-0cea407791fc">
											<gml:posList>35.669223738890004 139.7385059839305 29.272 35.669223738890004 139.7385059839305 31.819 35.669235983139124 139.73848766605929 31.819 35.669235983139124 139.73848766605929 29.528 35.66923495678396 139.73848920268145 29.528 35.66923495678396 139.73848920268145 29.272 35.669223738890004 139.7385059839305 29.272</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-451d613f-3d80-4926-8532-1c0e0b398024">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-451d613f-3d80-4926-8532-1c0e0b398024">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-451d613f-3d80-4926-8532-1c0e0b398024">
											<gml:posList>35.669250061767244 139.7385324082173 31.819 35.669223738890004 139.7385059839305 31.819 35.669223738890004 139.7385059839305 29.272 35.66924879885449 139.73853115045472 29.272 35.66924879885449 139.73853115045472 29.528 35.66925005275352 139.73853240822797 29.528 35.669250061767244 139.7385324082173 31.819</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7bf63775-8128-49ad-a3cb-5ed065203f7a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7bf63775-8128-49ad-a3cb-5ed065203f7a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7bf63775-8128-49ad-a3cb-5ed065203f7a">
											<gml:posList>35.66922728376511 139.73856637981515 29.528 35.66918927012571 139.7385285587297 29.528 35.66916873878172 139.7385081256426 24.773 35.66916873878172 139.7385081256426 17.076 35.66922728376511 139.73856637981515 17.076 35.66922728376511 139.73856637981515 29.528</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6d8ff392-20ab-47d9-be4f-0e473b3f5e5f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6d8ff392-20ab-47d9-be4f-0e473b3f5e5f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6d8ff392-20ab-47d9-be4f-0e473b3f5e5f">
											<gml:posList>35.66926230602033 139.73851409034407 17.076 35.66926230602033 139.73851409034407 31.819 35.669250061767244 139.7385324082173 31.819 35.66925005275352 139.73853240822797 29.528 35.66922728376511 139.73856637981515 29.528 35.66922728376511 139.73856637981515 17.076 35.66926230602033 139.73851409034407 17.076</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3b96b729-53af-49ab-9b9a-4a74d06df5aa">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3b96b729-53af-49ab-9b9a-4a74d06df5aa">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3b96b729-53af-49ab-9b9a-4a74d06df5aa">
											<gml:posList>35.66922704720884 139.73856358543136 29.528 35.66922704720884 139.73856358543136 29.272 35.66919155036306 139.738528257789 29.272 35.66919155036306 139.738528257789 29.528 35.66922704720884 139.73856358543136 29.528</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-100bce15-d462-4f48-b351-1d01323ede5f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-100bce15-d462-4f48-b351-1d01323ede5f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-100bce15-d462-4f48-b351-1d01323ede5f">
											<gml:posList>35.66924879885449 139.73853115045472 29.528 35.66924879885449 139.73853115045472 29.272 35.66922704720884 139.73856358543136 29.272 35.66922704720884 139.73856358543136 29.528 35.66924879885449 139.73853115045472 29.528</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-4410</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">51.3981</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">211</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1230</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>4</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.08</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>