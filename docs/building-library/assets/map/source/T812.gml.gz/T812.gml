<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_e7d78f60-e502-4c6e-b558-bf6e113e965c">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">412</bldg:usage>
			<bldg:measuredHeight uom="m">22.6</bldg:measuredHeight>
			<bldg:storeysAboveGround>7</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.67117164347938 139.74017041138953 0 35.67117690255261 139.74016402047712 0 35.67117771306102 139.74016308059385 0 35.671193868581184 139.74014355392768 0 35.67113083801669 139.7400652201064 0 35.671044441123215 139.74016963130367 0 35.671114608339835 139.740256838111 0 35.671158428205494 139.74020388619007 0 35.671165176961914 139.74021227359026 0 35.67118552896227 139.74018767177793 0 35.67117164347938 139.74017041138953 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67117164347938 139.74017041138953 12.608 35.67118552896227 139.74018767177793 12.608 35.671165176961914 139.74021227359026 12.608 35.671158428205494 139.74020388619007 12.608 35.671114608339835 139.740256838111 12.608 35.671044441123215 139.74016963130367 12.608 35.67113083801669 139.7400652201064 12.608 35.671193868581184 139.74014355392768 12.608 35.67117771306102 139.74016308059385 12.608 35.67117690255261 139.74016402047712 12.608 35.67117164347938 139.74017041138953 12.608</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67117164347938 139.74017041138953 12.608 35.67117690255261 139.74016402047712 12.608 35.67117690255261 139.74016402047712 35.2 35.67117164347938 139.74017041138953 35.2 35.67117164347938 139.74017041138953 12.608</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67117690255261 139.74016402047712 12.608 35.67117771306102 139.74016308059385 12.608 35.67117771306102 139.74016308059385 35.2 35.67117690255261 139.74016402047712 35.2 35.67117690255261 139.74016402047712 12.608</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67117771306102 139.74016308059385 12.608 35.671193868581184 139.74014355392768 12.608 35.671193868581184 139.74014355392768 35.2 35.67117771306102 139.74016308059385 35.2 35.67117771306102 139.74016308059385 12.608</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671193868581184 139.74014355392768 12.608 35.67113083801669 139.7400652201064 12.608 35.67113083801669 139.7400652201064 35.2 35.671193868581184 139.74014355392768 35.2 35.671193868581184 139.74014355392768 12.608</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67113083801669 139.7400652201064 12.608 35.671044441123215 139.74016963130367 12.608 35.671044441123215 139.74016963130367 35.2 35.67113083801669 139.7400652201064 35.2 35.67113083801669 139.7400652201064 12.608</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671044441123215 139.74016963130367 12.608 35.671114608339835 139.740256838111 12.608 35.671114608339835 139.740256838111 35.2 35.671044441123215 139.74016963130367 35.2 35.671044441123215 139.74016963130367 12.608</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671114608339835 139.740256838111 12.608 35.671158428205494 139.74020388619007 12.608 35.671158428205494 139.74020388619007 35.2 35.671114608339835 139.740256838111 35.2 35.671114608339835 139.740256838111 12.608</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671158428205494 139.74020388619007 12.608 35.671165176961914 139.74021227359026 12.608 35.671165176961914 139.74021227359026 35.2 35.671158428205494 139.74020388619007 35.2 35.671158428205494 139.74020388619007 12.608</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671165176961914 139.74021227359026 12.608 35.67118552896227 139.74018767177793 12.608 35.67118552896227 139.74018767177793 35.2 35.671165176961914 139.74021227359026 35.2 35.671165176961914 139.74021227359026 12.608</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67118552896227 139.74018767177793 12.608 35.67117164347938 139.74017041138953 12.608 35.67117164347938 139.74017041138953 35.2 35.67118552896227 139.74018767177793 35.2 35.67118552896227 139.74018767177793 12.608</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67117164347938 139.74017041138953 35.2 35.67117690255261 139.74016402047712 35.2 35.67117771306102 139.74016308059385 35.2 35.671193868581184 139.74014355392768 35.2 35.67113083801669 139.7400652201064 35.2 35.671044441123215 139.74016963130367 35.2 35.671114608339835 139.740256838111 35.2 35.671158428205494 139.74020388619007 35.2 35.671165176961914 139.74021227359026 35.2 35.67118552896227 139.74018767177793 35.2 35.67117164347938 139.74017041138953 35.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-aa72d282-dfe9-44ec-bae4-d6cd18c723c7"/>
							<gml:surfaceMember xlink:href="#poly-760f1b73-a2df-4562-9d2d-2d9cb63326b9"/>
							<gml:surfaceMember xlink:href="#poly-557c33d7-7fc5-4d52-93fb-08e95556d6a9"/>
							<gml:surfaceMember xlink:href="#poly-5840ec02-7f29-4343-b3b4-61e3cd412758"/>
							<gml:surfaceMember xlink:href="#poly-7d233b04-2bf1-4cdf-b3e0-ed8f6ef3e2b4"/>
							<gml:surfaceMember xlink:href="#poly-7dac914d-4200-484c-9a5b-93b3b1092b6d"/>
							<gml:surfaceMember xlink:href="#poly-17a39eb1-73f7-4fc3-90cb-405f64647e82"/>
							<gml:surfaceMember xlink:href="#poly-5d40cb7d-0358-44ff-b62c-efa94020530b"/>
							<gml:surfaceMember xlink:href="#poly-7dae529d-f688-4ba8-98e3-99f6aa4aece9"/>
							<gml:surfaceMember xlink:href="#poly-24b1509e-5c63-4f6f-ab90-89ce3dda02f2"/>
							<gml:surfaceMember xlink:href="#poly-615f99f8-2ef3-4625-a2b8-a6afe5c33b2f"/>
							<gml:surfaceMember xlink:href="#poly-e8cb34e7-dfa1-4a15-8bf3-ab21026b71a3"/>
							<gml:surfaceMember xlink:href="#poly-9a472739-8423-4130-9f99-341c057fa844"/>
							<gml:surfaceMember xlink:href="#poly-59782307-7427-4041-940d-aaab5feafc3d"/>
							<gml:surfaceMember xlink:href="#poly-c80d2137-e3d5-438f-b483-d9ae9b233604"/>
							<gml:surfaceMember xlink:href="#poly-784f70a3-8901-41fc-a08a-c954413efc21"/>
							<gml:surfaceMember xlink:href="#poly-6a0cb696-8614-492e-9b55-d06aa5cc7f06"/>
							<gml:surfaceMember xlink:href="#poly-00e6eb79-55ab-42e9-9617-d659f912a992"/>
							<gml:surfaceMember xlink:href="#poly-b3208f66-20f4-4b4e-815b-9bc6bbd65dd2"/>
							<gml:surfaceMember xlink:href="#poly-5cbef920-0086-47c0-bc50-265ad26eb0ba"/>
							<gml:surfaceMember xlink:href="#poly-e9b3d6bd-b9e4-433d-bfec-41561fc4b10a"/>
							<gml:surfaceMember xlink:href="#poly-cab91a63-ee85-4081-83dc-0839171892c2"/>
							<gml:surfaceMember xlink:href="#poly-54a6ad8e-7aa0-489b-bafe-f0cb120102f1"/>
							<gml:surfaceMember xlink:href="#poly-47cdae78-931b-412d-9a3d-cd6c2480197f"/>
							<gml:surfaceMember xlink:href="#poly-47847d95-fe5d-40d3-8509-fa5661037bbe"/>
							<gml:surfaceMember xlink:href="#poly-4244e2f3-c0df-469c-9e13-ac55eb695820"/>
							<gml:surfaceMember xlink:href="#poly-725537ec-8894-4a01-86ae-1be31b7e9980"/>
							<gml:surfaceMember xlink:href="#poly-106bc2c2-db81-4147-a46c-db9497875b17"/>
							<gml:surfaceMember xlink:href="#poly-dbfeae07-24db-4203-9e08-0db354b1f8ec"/>
							<gml:surfaceMember xlink:href="#poly-a28dd671-5891-4196-8a4b-58a5960b34cf"/>
							<gml:surfaceMember xlink:href="#poly-e5ea4889-bc33-44a6-aa9d-a2855b5e1f76"/>
							<gml:surfaceMember xlink:href="#poly-2281a0aa-b9da-443e-92de-8e6c25f1714f"/>
							<gml:surfaceMember xlink:href="#poly-6b249369-ad03-4be0-b955-fd27b11f9bd9"/>
							<gml:surfaceMember xlink:href="#poly-63681c38-d58d-47c1-b779-085e9e15ba14"/>
							<gml:surfaceMember xlink:href="#poly-f89d4222-b181-4783-b326-57e036816f8e"/>
							<gml:surfaceMember xlink:href="#poly-25cf72a3-65e3-4997-b15b-052283134bfe"/>
							<gml:surfaceMember xlink:href="#poly-c2719ce6-9c09-4f5b-a950-091345443da7"/>
							<gml:surfaceMember xlink:href="#poly-de7e914b-3f99-4582-85fd-e4732b7f31b4"/>
							<gml:surfaceMember xlink:href="#poly-46db28e1-7fe3-49f4-98d8-a089884521c1"/>
							<gml:surfaceMember xlink:href="#poly-9a0e2712-7d99-4e4c-98ae-1d4b9f9c9e75"/>
							<gml:surfaceMember xlink:href="#poly-836384b0-c92d-4f2b-9ca7-516ebfc6dc16"/>
							<gml:surfaceMember xlink:href="#poly-e2dfc5f6-d9fb-492e-bd9c-08e47c0d20c3"/>
							<gml:surfaceMember xlink:href="#poly-44974df9-fa1f-475e-851c-440c2a731c98"/>
							<gml:surfaceMember xlink:href="#poly-b67d6200-45d3-4683-a98c-ae82dc533e3a"/>
							<gml:surfaceMember xlink:href="#poly-57f395de-90df-4e4b-998d-016be9cca107"/>
							<gml:surfaceMember xlink:href="#poly-f25f653b-9878-4d26-817b-9486e103d5ed"/>
							<gml:surfaceMember xlink:href="#poly-4a13639e-d434-4578-b438-78d87773f34d"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_e7d78f60-e502-4c6e-b558-bf6e113e965c_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-987db4e5-8634-4d41-a4a9-31d388513694">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67116222046814 139.74017732631845 40.955 35.67117035844183 139.7401871370843 40.955 35.67116339753415 139.7401958055233 40.955 35.67115525956971 139.74018600580382 40.955 35.67116222046814 139.74017732631845 40.955</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2657f179-9229-4159-8f2b-bc0791bfa629">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2657f179-9229-4159-8f2b-bc0791bfa629_0">
											<gml:posList>35.67115525956971 139.74018600580382 40.955 35.67115525956971 139.74018600580382 42.617 35.67116222046814 139.74017732631845 42.617 35.67116222046814 139.74017732631845 40.955 35.67115525956971 139.74018600580382 40.955</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a8a0e739-584d-41ce-af27-ead3c57a6b89">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a8a0e739-584d-41ce-af27-ead3c57a6b89_0">
											<gml:posList>35.67116222046814 139.74017732631845 40.955 35.67116222046814 139.74017732631845 42.617 35.67117035844183 139.7401871370843 42.617 35.67117035844183 139.7401871370843 40.955 35.67116222046814 139.74017732631845 40.955</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-25de2139-9b98-46a1-88a9-f934d39cbaa8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-25de2139-9b98-46a1-88a9-f934d39cbaa8_0">
											<gml:posList>35.67116339753415 139.7401958055233 42.617 35.67117035844183 139.7401871370843 42.617 35.67116222046814 139.74017732631845 42.617 35.67115525956971 139.74018600580382 42.617 35.67116339753415 139.7401958055233 42.617</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-df18c3e0-982c-4454-ac15-016270f5c5ae">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-df18c3e0-982c-4454-ac15-016270f5c5ae_0">
											<gml:posList>35.67116339753415 139.7401958055233 40.955 35.67116339753415 139.7401958055233 42.617 35.67115525956971 139.74018600580382 42.617 35.67115525956971 139.74018600580382 40.955 35.67116339753415 139.7401958055233 40.955</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-11352a17-97eb-41a3-90de-c77aa896b9f9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-11352a17-97eb-41a3-90de-c77aa896b9f9_0">
											<gml:posList>35.67117035844183 139.7401871370843 40.955 35.67117035844183 139.7401871370843 42.617 35.67116339753415 139.7401958055233 42.617 35.67116339753415 139.7401958055233 40.955 35.67117035844183 139.7401871370843 40.955</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_e7d78f60-e502-4c6e-b558-bf6e113e965c_BuildingInstallation_1061">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b549053a-0677-46dc-91d1-1f5ea031c3fe">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b549053a-0677-46dc-91d1-1f5ea031c3fe_0">
											<gml:posList>35.671102502954625 139.74023358853233 34.77 35.67110172854324 139.7402345836039 35.095 35.67110172854324 139.7402345836039 34.77 35.671102502954625 139.74023358853233 34.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-474021d2-42af-4cc3-aa00-0ac1a67d0b78">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-474021d2-42af-4cc3-aa00-0ac1a67d0b78_0">
											<gml:posList>35.671102502954625 139.74023358853233 34.77 35.671102502954625 139.74023358853233 35.095 35.67110172854324 139.7402345836039 35.095 35.671102502954625 139.74023358853233 34.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-82fbf521-c7f3-499b-9201-00d45cd02d07">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-82fbf521-c7f3-499b-9201-00d45cd02d07_0">
											<gml:posList>35.67108384482854 139.74021065586965 34.77 35.671123988853616 139.74016000585902 36.454 35.671123988853616 139.74016000585902 34.77 35.67108384482854 139.74021065586965 34.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9946fe3f-b3e8-4b3f-8d5a-d23409b06445">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9946fe3f-b3e8-4b3f-8d5a-d23409b06445_0">
											<gml:posList>35.67108384482854 139.74021065586965 34.77 35.67108384482854 139.74021065586965 36.454 35.671123988853616 139.74016000585902 36.454 35.67108384482854 139.74021065586965 34.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d9d51b3e-9a0e-4018-aac1-e7851d197075">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d9d51b3e-9a0e-4018-aac1-e7851d197075_0">
											<gml:posList>35.67117572813623 139.7401606195602 34.77 35.671175863213826 139.74016045370772 35.095 35.67117572813623 139.7401606195602 35.095 35.67117572813623 139.7401606195602 34.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a3777895-3590-4f57-ae05-5590ed9a967d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a3777895-3590-4f57-ae05-5590ed9a967d_0">
											<gml:posList>35.67117572813623 139.7401606195602 34.77 35.671175863213826 139.74016045370772 34.77 35.671175863213826 139.74016045370772 35.095 35.67117572813623 139.7401606195602 34.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-43340a9f-8aa4-4ac6-8b63-d7fa159d637d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-43340a9f-8aa4-4ac6-8b63-d7fa159d637d_0">
											<gml:posList>35.67114563436474 139.74009471878068 34.77 35.671187532507815 139.7401443013991 36.454 35.671187532507815 139.7401443013991 34.77 35.67114563436474 139.74009471878068 34.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0529a1d1-b07a-446f-8d39-613c0296ec2b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0529a1d1-b07a-446f-8d39-613c0296ec2b_0">
											<gml:posList>35.67114563436474 139.74009471878068 34.77 35.67114563436474 139.74009471878068 36.454 35.671187532507815 139.7401443013991 36.454 35.67114563436474 139.74009471878068 34.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-32b2c9ec-366e-4dfa-ad77-e142b81722d8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-32b2c9ec-366e-4dfa-ad77-e142b81722d8_0">
											<gml:posList>35.67118596416303 139.74014435845388 34.77 35.671145653880494 139.74009664082547 36.454 35.671145653880494 139.74009664082547 34.77 35.67118596416303 139.74014435845388 34.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6d46f07a-6d9c-458d-be9d-9a1eda970bc3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6d46f07a-6d9c-458d-be9d-9a1eda970bc3_0">
											<gml:posList>35.67118596416303 139.74014435845388 34.77 35.67118596416303 139.74014435845388 36.454 35.671145653880494 139.74009664082547 36.454 35.67118596416303 139.74014435845388 34.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-720f8dae-4abb-41de-9149-4124cd98c05c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-720f8dae-4abb-41de-9149-4124cd98c05c_0">
											<gml:posList>35.671067091908654 139.74019200698956 36.454 35.67114563436474 139.74009471878068 34.77 35.671067091908654 139.74019200698956 34.77 35.671067091908654 139.74019200698956 36.454</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1f551bc6-878d-48a1-800f-4016a5a1651c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1f551bc6-878d-48a1-800f-4016a5a1651c_0">
											<gml:posList>35.671067091908654 139.74019200698956 36.454 35.67114563436474 139.74009471878068 36.454 35.67114563436474 139.74009471878068 34.77 35.671067091908654 139.74019200698956 36.454</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d5d7061c-4761-4f95-9d50-18ca45ada231">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d5d7061c-4761-4f95-9d50-18ca45ada231_0">
											<gml:posList>35.671145653880494 139.74009664082547 34.77 35.67106866930994 139.74019200515707 36.454 35.67106866930994 139.74019200515707 34.77 35.671145653880494 139.74009664082547 34.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3402bbdf-65f4-41cd-a441-0e5784f88828">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3402bbdf-65f4-41cd-a441-0e5784f88828_0">
											<gml:posList>35.671145653880494 139.74009664082547 34.77 35.671145653880494 139.74009664082547 36.454 35.67106866930994 139.74019200515707 36.454 35.671145653880494 139.74009664082547 34.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ce3414a4-70c9-4794-ac6e-26281ea984bb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ce3414a4-70c9-4794-ac6e-26281ea984bb_0">
											<gml:posList>35.671187532507815 139.7401443013991 36.454 35.67117561957838 139.7401601115534 34.77 35.671187532507815 139.7401443013991 34.77 35.671187532507815 139.7401443013991 36.454</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1797b98e-8b5f-4a8b-9f01-4baf0943a2f8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1797b98e-8b5f-4a8b-9f01-4baf0943a2f8_0">
											<gml:posList>35.671187532507815 139.7401443013991 36.454 35.67117561957838 139.7401601115534 36.454 35.67117561957838 139.7401601115534 34.77 35.671187532507815 139.7401443013991 36.454</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2c473b60-e86f-49ba-9050-0a75a59e69b7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2c473b60-e86f-49ba-9050-0a75a59e69b7_0">
											<gml:posList>35.67117412327498 139.74016008015317 34.77 35.67118596416303 139.74014435845388 36.454 35.67118596416303 139.74014435845388 34.77 35.67117412327498 139.74016008015317 34.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-57533927-b76b-4244-915c-e711e6db6620">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-57533927-b76b-4244-915c-e711e6db6620_0">
											<gml:posList>35.67117412327498 139.74016008015317 34.77 35.67117412327498 139.74016008015317 36.454 35.67118596416303 139.74014435845388 36.454 35.67117412327498 139.74016008015317 34.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8b9ad21e-3c68-4cdb-89bf-2c36ba2036be">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8b9ad21e-3c68-4cdb-89bf-2c36ba2036be_0">
											<gml:posList>35.67117572813623 139.7401606195602 35.095 35.67117505271399 139.74016140463732 34.77 35.67117572813623 139.7401606195602 34.77 35.67117572813623 139.7401606195602 35.095</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b9314426-b3b0-4b78-8684-1c88600ebfa4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b9314426-b3b0-4b78-8684-1c88600ebfa4_0">
											<gml:posList>35.67117572813623 139.7401606195602 35.095 35.67117505271399 139.74016140463732 35.095 35.67117505271399 139.74016140463732 34.77 35.67117572813623 139.7401606195602 35.095</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-576fd680-8413-4d5f-a22f-73fc0d406e7b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-576fd680-8413-4d5f-a22f-73fc0d406e7b_0">
											<gml:posList>35.671175863213826 139.74016045370772 34.77 35.67117561957838 139.7401601115534 34.77 35.671175863213826 139.74016045370772 35.095 35.671175863213826 139.74016045370772 34.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4fb9afb5-d050-45ad-be0c-4fb8187c32b0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4fb9afb5-d050-45ad-be0c-4fb8187c32b0_0">
											<gml:posList>35.67117771306099 139.74016308059385 35.095 35.671175863213826 139.74016045370772 35.095 35.67117771306099 139.74016308059385 36.454 35.67117771306099 139.74016308059385 35.095</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6fefdbdf-cf89-4580-90b7-b7bd3528babf">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6fefdbdf-cf89-4580-90b7-b7bd3528babf_0">
											<gml:posList>35.67117771306099 139.74016308059385 36.454 35.671175863213826 139.74016045370772 35.095 35.67117561957838 139.7401601115534 36.454 35.67117771306099 139.74016308059385 36.454</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-62e5fec8-e7a4-4dad-914d-881012cc0bd1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-62e5fec8-e7a4-4dad-914d-881012cc0bd1_0">
											<gml:posList>35.671175863213826 139.74016045370772 35.095 35.67117561957838 139.7401601115534 34.77 35.67117561957838 139.7401601115534 36.454 35.671175863213826 139.74016045370772 35.095</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9d2944c2-a675-419e-a670-ad0db296d718">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9d2944c2-a675-419e-a670-ad0db296d718_0">
											<gml:posList>35.67117505271399 139.74016140463732 34.77 35.67117505271399 139.74016140463732 35.095 35.67117412327498 139.74016008015317 34.77 35.67117505271399 139.74016140463732 34.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cf7b8313-5fe0-4f0f-bb2f-0416d68fdacc">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cf7b8313-5fe0-4f0f-bb2f-0416d68fdacc_0">
											<gml:posList>35.67117412327498 139.74016008015317 34.77 35.67117505271399 139.74016140463732 35.095 35.67117412327498 139.74016008015317 36.454 35.67117412327498 139.74016008015317 34.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-28de41d6-8d42-4d1b-a7b1-f00c37c818ec">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-28de41d6-8d42-4d1b-a7b1-f00c37c818ec_0">
											<gml:posList>35.67117412327498 139.74016008015317 36.454 35.67117505271399 139.74016140463732 35.095 35.67117690255258 139.74016402047712 36.454 35.67117412327498 139.74016008015317 36.454</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4087eab6-6882-4a83-94ce-f2ca284acc5c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4087eab6-6882-4a83-94ce-f2ca284acc5c_0">
											<gml:posList>35.67117505271399 139.74016140463732 35.095 35.67117690255258 139.74016402047712 35.095 35.67117690255258 139.74016402047712 36.454 35.67117505271399 139.74016140463732 35.095</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2625231e-8afb-4591-9e4a-36ad64b16626">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2625231e-8afb-4591-9e4a-36ad64b16626_0">
											<gml:posList>35.67117771306099 139.74016308059385 35.095 35.67117690255258 139.74016402047712 36.454 35.67117690255258 139.74016402047712 35.095 35.67117771306099 139.74016308059385 35.095</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bd51ffc9-8f65-437b-ab4e-fe2d1c142ad4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bd51ffc9-8f65-437b-ab4e-fe2d1c142ad4_0">
											<gml:posList>35.67117771306099 139.74016308059385 35.095 35.67117771306099 139.74016308059385 36.454 35.67117690255258 139.74016402047712 36.454 35.67117771306099 139.74016308059385 35.095</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c055a13c-9305-4608-a8fe-c9a8c83986d7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c055a13c-9305-4608-a8fe-c9a8c83986d7_0">
											<gml:posList>35.671102675880775 139.74023574237154 36.454 35.671084521498365 139.74021148356042 36.454 35.671067091908654 139.74019200698956 36.454 35.671102675880775 139.74023574237154 36.454</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-70639fec-f969-40e6-b856-e20919fbdbf2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-70639fec-f969-40e6-b856-e20919fbdbf2_0">
											<gml:posList>35.67114563436474 139.74009471878068 36.454 35.671067091908654 139.74019200698956 36.454 35.67106866930994 139.74019200515707 36.454 35.67114563436474 139.74009471878068 36.454</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-dcd6e58f-1afb-485a-af13-04edf9edde9d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-dcd6e58f-1afb-485a-af13-04edf9edde9d_0">
											<gml:posList>35.671145653880494 139.74009664082547 36.454 35.671187532507815 139.7401443013991 36.454 35.67114563436474 139.74009471878068 36.454 35.671145653880494 139.74009664082547 36.454</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-55a578eb-7263-4ba3-886a-bb43280481d9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-55a578eb-7263-4ba3-886a-bb43280481d9_0">
											<gml:posList>35.671102675880775 139.74023574237154 36.454 35.67114172267762 139.74018824185015 36.454 35.671102674386155 139.74023380926045 36.454 35.671102675880775 139.74023574237154 36.454</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a0580ead-9599-4d36-84a0-21246ffc84d7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a0580ead-9599-4d36-84a0-21246ffc84d7_0">
											<gml:posList>35.67117771306099 139.74016308059385 36.454 35.67117561957838 139.7401601115534 36.454 35.67117690255258 139.74016402047712 36.454 35.67117771306099 139.74016308059385 36.454</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c9f7f11e-0898-484f-ae90-f32b2429d9a6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c9f7f11e-0898-484f-ae90-f32b2429d9a6_0">
											<gml:posList>35.67117561957838 139.7401601115534 36.454 35.67117412327498 139.74016008015317 36.454 35.67117690255258 139.74016402047712 36.454 35.67117561957838 139.7401601115534 36.454</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b69679e3-a9cc-406a-8c12-629e7e18757f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b69679e3-a9cc-406a-8c12-629e7e18757f_0">
											<gml:posList>35.67117561957838 139.7401601115534 36.454 35.671187532507815 139.7401443013991 36.454 35.67118596416303 139.74014435845388 36.454 35.67117561957838 139.7401601115534 36.454</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-71473f56-15d0-4a84-826b-89122f0617af">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-71473f56-15d0-4a84-826b-89122f0617af_0">
											<gml:posList>35.67114172267762 139.74018824185015 36.454 35.67114081142869 139.74018712722605 36.454 35.671102674386155 139.74023380926045 36.454 35.67114172267762 139.74018824185015 36.454</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b3ed93e9-1fe9-448b-abd7-b9c3b1cba2dd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b3ed93e9-1fe9-448b-abd7-b9c3b1cba2dd_0">
											<gml:posList>35.671133419388966 139.7401744656354 36.454 35.671134130866186 139.7401736805169 36.454 35.671123963137305 139.740161718075 36.454 35.671133419388966 139.7401744656354 36.454</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-55a94e4f-2f1d-4aa3-a190-a58b8cc04f21">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-55a94e4f-2f1d-4aa3-a190-a58b8cc04f21_0">
											<gml:posList>35.671134130866186 139.7401736805169 36.454 35.671123988853616 139.74016000585902 36.454 35.671123963137305 139.740161718075 36.454 35.671134130866186 139.7401736805169 36.454</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f843d15c-9daa-4ba9-9064-38d5bac8ae36">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f843d15c-9daa-4ba9-9064-38d5bac8ae36_0">
											<gml:posList>35.671102675880775 139.74023574237154 36.454 35.671102674386155 139.74023380926045 36.454 35.671084521498365 139.74021148356042 36.454 35.671102675880775 139.74023574237154 36.454</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c6555003-7f91-4ebb-bfbc-9da0ea1df343">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c6555003-7f91-4ebb-bfbc-9da0ea1df343_0">
											<gml:posList>35.67118596416303 139.74014435845388 36.454 35.67117412327498 139.74016008015317 36.454 35.67117561957838 139.7401601115534 36.454 35.67118596416303 139.74014435845388 36.454</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b5160290-f4b5-4793-ab39-c58a6a5b3d93">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b5160290-f4b5-4793-ab39-c58a6a5b3d93_0">
											<gml:posList>35.67118596416303 139.74014435845388 36.454 35.671187532507815 139.7401443013991 36.454 35.671145653880494 139.74009664082547 36.454 35.67118596416303 139.74014435845388 36.454</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-02bb15ce-6b6f-4d51-b568-35188e95fd89">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-02bb15ce-6b6f-4d51-b568-35188e95fd89_0">
											<gml:posList>35.671145653880494 139.74009664082547 36.454 35.67114563436474 139.74009471878068 36.454 35.67106866930994 139.74019200515707 36.454 35.671145653880494 139.74009664082547 36.454</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cacb355e-927e-4f23-aa5c-ab84d2bfe91e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cacb355e-927e-4f23-aa5c-ab84d2bfe91e_0">
											<gml:posList>35.671084521498365 139.74021148356042 36.454 35.671123963137305 139.740161718075 36.454 35.67108384482854 139.74021065586965 36.454 35.671084521498365 139.74021148356042 36.454</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e74cb9c2-62d0-4e5e-8e8d-7ae465150b19">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e74cb9c2-62d0-4e5e-8e8d-7ae465150b19_0">
											<gml:posList>35.671067091908654 139.74019200698956 36.454 35.67108384482854 139.74021065586965 36.454 35.67106866930994 139.74019200515707 36.454 35.671067091908654 139.74019200698956 36.454</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9508d1e7-f37d-4f9c-a0dd-d3366b28e12f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9508d1e7-f37d-4f9c-a0dd-d3366b28e12f_0">
											<gml:posList>35.67108384482854 139.74021065586965 36.454 35.671123963137305 139.740161718075 36.454 35.671123988853616 139.74016000585902 36.454 35.67108384482854 139.74021065586965 36.454</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-36781650-d303-4f98-bd06-58eaf2ab1845">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-36781650-d303-4f98-bd06-58eaf2ab1845_0">
											<gml:posList>35.671067091908654 139.74019200698956 36.454 35.671084521498365 139.74021148356042 36.454 35.67108384482854 139.74021065586965 36.454 35.671067091908654 139.74019200698956 36.454</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-756f3e89-8cf5-4459-ba61-555cab7bd3f6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-756f3e89-8cf5-4459-ba61-555cab7bd3f6_0">
											<gml:posList>35.671123988853616 139.74016000585902 34.77 35.671134130866186 139.7401736805169 36.454 35.671134130866186 139.7401736805169 34.77 35.671123988853616 139.74016000585902 34.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5f0ff959-df0f-4f3b-9f36-b9144776d9f8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5f0ff959-df0f-4f3b-9f36-b9144776d9f8_0">
											<gml:posList>35.671123988853616 139.74016000585902 34.77 35.671123988853616 139.74016000585902 36.454 35.671134130866186 139.7401736805169 36.454 35.671123988853616 139.74016000585902 34.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d44bb457-cccb-4500-8cc1-2ca5ae773f07">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d44bb457-cccb-4500-8cc1-2ca5ae773f07_0">
											<gml:posList>35.671133419388966 139.7401744656354 34.77 35.671123963137305 139.740161718075 36.454 35.671123963137305 139.740161718075 34.77 35.671133419388966 139.7401744656354 34.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-02dc0452-c595-4883-a71b-f30b65e4932d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-02dc0452-c595-4883-a71b-f30b65e4932d_0">
											<gml:posList>35.671133419388966 139.7401744656354 34.77 35.671133419388966 139.7401744656354 36.454 35.671123963137305 139.740161718075 36.454 35.671133419388966 139.7401744656354 34.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-78328437-2373-46a2-816f-c348b3da51d1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-78328437-2373-46a2-816f-c348b3da51d1_0">
											<gml:posList>35.671134130866186 139.7401736805169 34.77 35.671133419388966 139.7401744656354 36.454 35.671133419388966 139.7401744656354 34.77 35.671134130866186 139.7401736805169 34.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-28f5c75b-6ce3-4edb-b64d-c4022676d8e0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-28f5c75b-6ce3-4edb-b64d-c4022676d8e0_0">
											<gml:posList>35.671134130866186 139.7401736805169 34.77 35.671134130866186 139.7401736805169 36.454 35.671133419388966 139.7401744656354 36.454 35.671134130866186 139.7401736805169 34.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4e803a78-e37d-4c9e-8c6b-69e6eeac6cf5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4e803a78-e37d-4c9e-8c6b-69e6eeac6cf5_0">
											<gml:posList>35.671123963137305 139.740161718075 34.77 35.671084521498365 139.74021148356042 36.454 35.671084521498365 139.74021148356042 34.77 35.671123963137305 139.740161718075 34.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-74cdc603-3301-4fa1-8855-965bc1e3b505">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-74cdc603-3301-4fa1-8855-965bc1e3b505_0">
											<gml:posList>35.671123963137305 139.740161718075 34.77 35.671123963137305 139.740161718075 36.454 35.671084521498365 139.74021148356042 36.454 35.671123963137305 139.740161718075 34.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d15da936-09fe-4462-a367-502dac2598d8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d15da936-09fe-4462-a367-502dac2598d8_0">
											<gml:posList>35.67114081142869 139.74018712722605 35.095 35.67114172267762 139.74018824185015 36.454 35.67114172267762 139.74018824185015 35.095 35.67114081142869 139.74018712722605 35.095</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b218a59f-d0d3-41cd-954f-2b1d4d86d8fd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b218a59f-d0d3-41cd-954f-2b1d4d86d8fd_0">
											<gml:posList>35.67114081142869 139.74018712722605 35.095 35.67114081142869 139.74018712722605 36.454 35.67114172267762 139.74018824185015 36.454 35.67114081142869 139.74018712722605 35.095</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-93f9ed5d-79cf-4da7-b2c6-ec6296197383">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-93f9ed5d-79cf-4da7-b2c6-ec6296197383_0">
											<gml:posList>35.67106866930994 139.74019200515707 34.77 35.67108384482854 139.74021065586965 36.454 35.67108384482854 139.74021065586965 34.77 35.67106866930994 139.74019200515707 34.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-780c9ff6-8a14-4445-9af2-6fda906916f5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-780c9ff6-8a14-4445-9af2-6fda906916f5_0">
											<gml:posList>35.67106866930994 139.74019200515707 34.77 35.67106866930994 139.74019200515707 36.454 35.67108384482854 139.74021065586965 36.454 35.67106866930994 139.74019200515707 34.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3099e713-59e6-4a0b-80e8-0a70b42b8b14">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3099e713-59e6-4a0b-80e8-0a70b42b8b14_0">
											<gml:posList>35.67114172267762 139.74018824185015 35.095 35.671102675880775 139.74023574237154 36.454 35.671102675880775 139.74023574237154 35.095 35.67114172267762 139.74018824185015 35.095</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c8245948-d9e5-4408-953e-aa0d38a04731">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c8245948-d9e5-4408-953e-aa0d38a04731_0">
											<gml:posList>35.67114172267762 139.74018824185015 35.095 35.67114172267762 139.74018824185015 36.454 35.671102675880775 139.74023574237154 36.454 35.67114172267762 139.74018824185015 35.095</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-acff584f-a8dc-4d08-91de-4d5b8570c8fd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-acff584f-a8dc-4d08-91de-4d5b8570c8fd_0">
											<gml:posList>35.671102675880775 139.74023574237154 35.095 35.671102675880775 139.74023574237154 36.454 35.67110172854324 139.7402345836039 35.095 35.671102675880775 139.74023574237154 35.095</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9706a163-97bb-4000-908d-0c19f183c6ca">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9706a163-97bb-4000-908d-0c19f183c6ca_0">
											<gml:posList>35.67110172854324 139.7402345836039 34.77 35.67110172854324 139.7402345836039 35.095 35.671067091908654 139.74019200698956 34.77 35.67110172854324 139.7402345836039 34.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f74cc009-71fd-49f7-a14c-4f973aaa9bcc">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f74cc009-71fd-49f7-a14c-4f973aaa9bcc_0">
											<gml:posList>35.671067091908654 139.74019200698956 34.77 35.67110172854324 139.7402345836039 35.095 35.671067091908654 139.74019200698956 36.454 35.671067091908654 139.74019200698956 34.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-82349741-c9cb-4737-8a34-e95068c833bf">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-82349741-c9cb-4737-8a34-e95068c833bf_0">
											<gml:posList>35.67110172854324 139.7402345836039 35.095 35.671102675880775 139.74023574237154 36.454 35.671067091908654 139.74019200698956 36.454 35.67110172854324 139.7402345836039 35.095</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7e1c6974-297b-4702-a0bd-0203b8a6ef00">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7e1c6974-297b-4702-a0bd-0203b8a6ef00_0">
											<gml:posList>35.671102674386155 139.74023380926045 35.095 35.671102502954625 139.74023358853233 35.095 35.671102674386155 139.74023380926045 36.454 35.671102674386155 139.74023380926045 35.095</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8a0c16c4-87a8-46f8-9a4b-9a4251fab745">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8a0c16c4-87a8-46f8-9a4b-9a4251fab745_0">
											<gml:posList>35.671102674386155 139.74023380926045 36.454 35.671102502954625 139.74023358853233 35.095 35.671084521498365 139.74021148356042 36.454 35.671102674386155 139.74023380926045 36.454</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3d765688-ea05-4d93-a270-07d7f8a52544">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3d765688-ea05-4d93-a270-07d7f8a52544_0">
											<gml:posList>35.671084521498365 139.74021148356042 36.454 35.671102502954625 139.74023358853233 35.095 35.671084521498365 139.74021148356042 34.77 35.671084521498365 139.74021148356042 36.454</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-934d3918-853d-40eb-b5c3-18d0be413130">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-934d3918-853d-40eb-b5c3-18d0be413130_0">
											<gml:posList>35.671102502954625 139.74023358853233 35.095 35.671102502954625 139.74023358853233 34.77 35.671084521498365 139.74021148356042 34.77 35.671102502954625 139.74023358853233 35.095</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ba31714f-84d1-410e-bc78-dd0f1f9d83cc">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67117505271399 139.74016140463732 35.095 35.67117765902141 139.7401631358885 35.095 35.67117690255258 139.74016402047712 35.095 35.67117505271399 139.74016140463732 35.095</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3ed40515-606c-47f0-aa5f-e4371175c6b4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67117690255258 139.74016402047712 15.302 35.67117700161805 139.74016390989829 15.29 35.67117690255258 139.74016402047712 15.29 35.67117690255258 139.74016402047712 15.302</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a4059801-e2d4-4a44-8c97-bea89f53d484">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671102502954625 139.74023358853233 35.095 35.671102674386155 139.74023380926045 35.095 35.67110172854324 139.7402345836039 35.095 35.671102502954625 139.74023358853233 35.095</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9e614692-29d8-44a7-be69-aa9a8b718278">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67110172854324 139.7402345836039 35.095 35.671102674386155 139.74023380926045 35.095 35.671102675880775 139.74023574237154 35.095 35.67110172854324 139.7402345836039 35.095</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-14372bd2-82d5-4a1a-b80a-731edb392617">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671102675880775 139.74023574237154 35.095 35.671102674386155 139.74023380926045 35.095 35.67114172267762 139.74018824185015 35.095 35.671102675880775 139.74023574237154 35.095</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5b7a1ef0-6fbf-455f-a582-02b8ab4e993a">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671102674386155 139.74023380926045 35.095 35.67114081142869 139.74018712722605 35.095 35.67114172267762 139.74018824185015 35.095 35.671102674386155 139.74023380926045 35.095</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-91813139-a4a5-4d05-a925-dd93d682a260">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671102674386155 139.74023380926045 35.095 35.67114081142869 139.74018712722605 36.454 35.67114081142869 139.74018712722605 35.095 35.671102674386155 139.74023380926045 35.095</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9dc321b5-e68d-4edb-a8ac-d54ab1f16400">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671102674386155 139.74023380926045 35.095 35.671102674386155 139.74023380926045 36.454 35.67114081142869 139.74018712722605 36.454 35.671102674386155 139.74023380926045 35.095</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-93534756-feb4-4346-9fae-557df5386f4e">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67110172854324 139.7402345836039 34.77 35.671067091908654 139.74019200698956 34.77 35.671084521498365 139.74021148356042 34.77 35.67110172854324 139.7402345836039 34.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ba755d10-6894-4f07-a679-f62855b28846">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671102502954625 139.74023358853233 34.77 35.67110172854324 139.7402345836039 34.77 35.671084521498365 139.74021148356042 34.77 35.671102502954625 139.74023358853233 34.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a4ebf5ed-f72e-43ac-9def-db0ab976fa8f">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67117572813623 139.7401606195602 34.77 35.67117505271399 139.74016140463732 34.77 35.67117561957838 139.7401601115534 34.77 35.67117572813623 139.7401606195602 34.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f551633d-d9f5-4ec4-b0b3-2c8f32ad4153">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67114563436474 139.74009471878068 34.77 35.67106866930994 139.74019200515707 34.77 35.671067091908654 139.74019200698956 34.77 35.67114563436474 139.74009471878068 34.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-22147473-b949-4548-83e7-4adcaf56aa3d">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671175863213826 139.74016045370772 34.77 35.67117572813623 139.7401606195602 34.77 35.67117561957838 139.7401601115534 34.77 35.671175863213826 139.74016045370772 34.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-459ab25e-aae0-4a25-87b4-cac56ed7adce">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671145653880494 139.74009664082547 34.77 35.67114563436474 139.74009471878068 34.77 35.671187532507815 139.7401443013991 34.77 35.671145653880494 139.74009664082547 34.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-20b819ab-08c6-4fa5-95e9-8c1b7e5058ab">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671133419388966 139.7401744656354 34.77 35.671123963137305 139.740161718075 34.77 35.671134130866186 139.7401736805169 34.77 35.671133419388966 139.7401744656354 34.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-13d393b3-e1d2-427a-b71c-62f20b204531">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67117505271399 139.74016140463732 34.77 35.67117412327498 139.74016008015317 34.77 35.67117561957838 139.7401601115534 34.77 35.67117505271399 139.74016140463732 34.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-457a2283-4aad-489a-bdbe-f6e12b3d3e74">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67108384482854 139.74021065586965 34.77 35.671123963137305 139.740161718075 34.77 35.671084521498365 139.74021148356042 34.77 35.67108384482854 139.74021065586965 34.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e8c7a1a3-8ce6-4e58-b439-a053a35a5001">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67117561957838 139.7401601115534 34.77 35.67118596416303 139.74014435845388 34.77 35.671187532507815 139.7401443013991 34.77 35.67117561957838 139.7401601115534 34.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c53adddc-2d33-4922-a150-d2717e248f45">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671123988853616 139.74016000585902 34.77 35.671134130866186 139.7401736805169 34.77 35.671123963137305 139.740161718075 34.77 35.671123988853616 139.74016000585902 34.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6e17aa48-1eef-49a2-a1cf-8eebf0cb394f">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67118596416303 139.74014435845388 34.77 35.671145653880494 139.74009664082547 34.77 35.671187532507815 139.7401443013991 34.77 35.67118596416303 139.74014435845388 34.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d0e089b2-ffb0-4669-997a-212c59726bc0">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67118596416303 139.74014435845388 34.77 35.67117561957838 139.7401601115534 34.77 35.67117412327498 139.74016008015317 34.77 35.67118596416303 139.74014435845388 34.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e8b4d688-cc6f-47f2-887d-c89987920389">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671145653880494 139.74009664082547 34.77 35.67106866930994 139.74019200515707 34.77 35.67114563436474 139.74009471878068 34.77 35.671145653880494 139.74009664082547 34.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-07301b95-bcf6-43b1-a443-399eb40914cc">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671067091908654 139.74019200698956 34.77 35.67106866930994 139.74019200515707 34.77 35.67108384482854 139.74021065586965 34.77 35.671067091908654 139.74019200698956 34.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4444c41f-5e1d-4606-88b7-f157bf33f9e1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67108384482854 139.74021065586965 34.77 35.671123988853616 139.74016000585902 34.77 35.671123963137305 139.740161718075 34.77 35.67108384482854 139.74021065586965 34.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3797bd31-d466-4e84-9092-691e85b99f45">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671067091908654 139.74019200698956 34.77 35.67108384482854 139.74021065586965 34.77 35.671084521498365 139.74021148356042 34.77 35.671067091908654 139.74019200698956 34.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-003c7165-8f70-44d3-ab62-3df9496ece67">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67117765902141 139.7401631358885 35.095 35.67117572813623 139.7401606195602 35.095 35.671175863213826 139.74016045370772 35.095 35.67117765902141 139.7401631358885 35.095</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fa3df4c4-48b0-430c-b6c1-dc045bf23345">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67117765902141 139.7401631358885 35.095 35.67117505271399 139.74016140463732 35.095 35.67117572813623 139.7401606195602 35.095 35.67117765902141 139.7401631358885 35.095</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_e7d78f60-e502-4c6e-b558-bf6e113e965c_BuildingInstallation_1060">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-726da5c2-d4f9-4960-9ef0-9ff11791095d">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671141520214235 139.74018286250597 34.77 35.671134130866186 139.7401736805169 34.77 35.6711544828673 139.7401490897507 34.77 35.6711618722172 139.7401582717398 34.77 35.671141520214235 139.74018286250597 34.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bb64389f-8583-4eeb-903d-13688613e106">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67117690255258 139.74016402047712 12.608 35.67117771306099 139.74016308059385 12.608 35.671178091278314 139.74016261620685 12.608 35.67119386858118 139.74014355392768 12.608 35.671210181092334 139.7401638271558 12.608 35.67118773085664 139.74019096103828 12.608 35.67118531284656 139.74018794818826 12.608 35.67118552896225 139.74018767177793 12.608 35.67117164347936 139.7401704113895 12.608 35.67117690255258 139.74016402047712 12.608</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-aa00bcc1-1d0d-4751-ab1a-a3b2cf86d27d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-aa00bcc1-1d0d-4751-ab1a-a3b2cf86d27d_0">
											<gml:posList>35.671178091278314 139.74016261620685 12.608 35.67119386858118 139.74014355392768 35.095 35.67119386858118 139.74014355392768 12.608 35.671178091278314 139.74016261620685 12.608</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-48587771-3252-4912-b3de-0885a226b37c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-48587771-3252-4912-b3de-0885a226b37c_0">
											<gml:posList>35.671178091278314 139.74016261620685 12.608 35.67117771306099 139.74016308059385 12.608 35.67117771306099 139.74016308059385 35.095 35.67119386858118 139.74014355392768 35.095 35.671178091278314 139.74016261620685 12.608</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-98412fd3-33f9-40b4-a7f2-5eb4794db9ba">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-98412fd3-33f9-40b4-a7f2-5eb4794db9ba_0">
											<gml:posList>35.6711618722172 139.7401582717398 34.77 35.6711544828673 139.7401490897507 34.77 35.6711544828673 139.7401490897507 35.657 35.6711618722172 139.7401582717398 35.657 35.6711618722172 139.7401582717398 34.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-964f763b-3ac5-4246-96cc-c8f0016e01f6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-964f763b-3ac5-4246-96cc-c8f0016e01f6_0">
											<gml:posList>35.671210181092334 139.7401638271558 12.608 35.67119386858118 139.74014355392768 12.608 35.67119386858118 139.74014355392768 35.095 35.671210181092334 139.7401638271558 35.095 35.671210181092334 139.7401638271558 12.608</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6463469c-1112-4085-b93a-4afe6c3b7adc">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6463469c-1112-4085-b93a-4afe6c3b7adc_0">
											<gml:posList>35.671134130866186 139.7401736805169 34.77 35.671134130866186 139.7401736805169 35.657 35.6711544828673 139.7401490897507 35.657 35.6711544828673 139.7401490897507 34.77 35.671134130866186 139.7401736805169 34.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-da4858c5-7c70-4e45-bf92-d4aa7ac724a5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-da4858c5-7c70-4e45-bf92-d4aa7ac724a5_0">
											<gml:posList>35.67117690255258 139.74016402047712 12.608 35.67117690255258 139.74016402047712 35.095 35.67117771306099 139.74016308059385 35.095 35.67117771306099 139.74016308059385 12.608 35.67117690255258 139.74016402047712 12.608</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b0a980a1-07cf-43bf-8a7f-b937fc4b73fd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b0a980a1-07cf-43bf-8a7f-b937fc4b73fd_0">
											<gml:posList>35.6711544828673 139.7401490897507 35.657 35.671134130866186 139.7401736805169 35.657 35.671141520214235 139.74018286250597 35.657 35.6711618722172 139.7401582717398 35.657 35.6711544828673 139.7401490897507 35.657</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-dbecef3d-c31c-4d08-8a0b-0f3365904372">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-dbecef3d-c31c-4d08-8a0b-0f3365904372_0">
											<gml:posList>35.67117690255258 139.74016402047712 35.095 35.67117690255258 139.74016402047712 12.608 35.67117164347936 139.7401704113895 12.608 35.67117164347936 139.7401704113895 35.095 35.67117690255258 139.74016402047712 35.095</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-07b0db7e-f80d-4339-8818-11f6c1dc37f3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-07b0db7e-f80d-4339-8818-11f6c1dc37f3_0">
											<gml:posList>35.67118552896225 139.74018767177793 35.095 35.67118531284656 139.74018794818826 35.095 35.67118773085664 139.74019096103828 35.095 35.671210181092334 139.7401638271558 35.095 35.67119386858118 139.74014355392768 35.095 35.67117771306099 139.74016308059385 35.095 35.67117690255258 139.74016402047712 35.095 35.67117164347936 139.7401704113895 35.095 35.67118552896225 139.74018767177793 35.095</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b76710e4-0a45-4288-99af-1601c8b6690a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b76710e4-0a45-4288-99af-1601c8b6690a_0">
											<gml:posList>35.671141520214235 139.74018286250597 35.657 35.671141520214235 139.74018286250597 34.77 35.6711618722172 139.7401582717398 34.77 35.6711618722172 139.7401582717398 35.657 35.671141520214235 139.74018286250597 35.657</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8f32fea0-52ae-4877-80dd-e722cd3439da">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8f32fea0-52ae-4877-80dd-e722cd3439da_0">
											<gml:posList>35.67118773085664 139.74019096103828 12.608 35.671210181092334 139.7401638271558 12.608 35.671210181092334 139.7401638271558 35.095 35.67118773085664 139.74019096103828 35.095 35.67118773085664 139.74019096103828 12.608</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5bad5afa-4ebf-4d06-93c1-d8c1f4c78172">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5bad5afa-4ebf-4d06-93c1-d8c1f4c78172_0">
											<gml:posList>35.671141520214235 139.74018286250597 34.77 35.671141520214235 139.74018286250597 35.657 35.671134130866186 139.7401736805169 35.657 35.671134130866186 139.7401736805169 34.77 35.671141520214235 139.74018286250597 34.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f76b0aa9-dd67-4258-bc9d-d2aff3c46c94">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f76b0aa9-dd67-4258-bc9d-d2aff3c46c94_0">
											<gml:posList>35.67117164347936 139.7401704113895 35.095 35.67117164347936 139.7401704113895 12.608 35.67118552896225 139.74018767177793 12.608 35.67118552896225 139.74018767177793 35.095 35.67117164347936 139.7401704113895 35.095</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-67debb04-bc3a-45cb-b27f-8672d233c55b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-67debb04-bc3a-45cb-b27f-8672d233c55b_0">
											<gml:posList>35.67118552896225 139.74018767177793 12.608 35.67118531284656 139.74018794818826 12.608 35.67118531284656 139.74018794818826 35.095 35.67118552896225 139.74018767177793 35.095 35.67118552896225 139.74018767177793 12.608</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-83140ca0-7b50-4588-af96-0b64e16438e7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-83140ca0-7b50-4588-af96-0b64e16438e7_0">
											<gml:posList>35.67118531284656 139.74018794818826 12.608 35.67118773085664 139.74019096103828 12.608 35.67118773085664 139.74019096103828 35.095 35.67118531284656 139.74018794818826 35.095 35.67118531284656 139.74018794818826 12.608</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-aa72d282-dfe9-44ec-bae4-d6cd18c723c7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-aa72d282-dfe9-44ec-bae4-d6cd18c723c7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-aa72d282-dfe9-44ec-bae4-d6cd18c723c7">
											<gml:posList>35.67115842820548 139.74020388619007 12.608 35.67111460833984 139.740256838111 12.608 35.67104444112321 139.74016963130367 12.608 35.671130838016666 139.7400652201064 12.608 35.67119386858118 139.74014355392768 12.608 35.67117771306099 139.74016308059385 12.608 35.67117690255258 139.74016402047712 12.608 35.67117164347936 139.7401704113895 12.608 35.67118552896225 139.74018767177793 12.608 35.67116517696191 139.74021227359026 12.608 35.67115842820548 139.74020388619007 12.608</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-760f1b73-a2df-4562-9d2d-2d9cb63326b9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-760f1b73-a2df-4562-9d2d-2d9cb63326b9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-760f1b73-a2df-4562-9d2d-2d9cb63326b9">
											<gml:posList>35.67105133423841 139.74017819526296 30.796 35.67106845334067 139.74015751869 30.796 35.671061416132716 139.74014912059346 30.796 35.67104444112321 139.74016963130367 30.796 35.67105133423841 139.74017819526296 30.796</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-557c33d7-7fc5-4d52-93fb-08e95556d6a9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-557c33d7-7fc5-4d52-93fb-08e95556d6a9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-557c33d7-7fc5-4d52-93fb-08e95556d6a9">
											<gml:posList>35.67110124617497 139.7402402398997 35.095 35.67110122428728 139.74023524697094 35.095 35.67105971221586 139.74018365347342 35.095 35.6710557010841 139.7401836249946 35.095 35.67110124617497 139.7402402398997 35.095</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-5840ec02-7f29-4343-b3b4-61e3cd412758">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5840ec02-7f29-4343-b3b4-61e3cd412758">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5840ec02-7f29-4343-b3b4-61e3cd412758">
											<gml:posList>35.6710557010841 139.7401836249946 32.539 35.671142107003256 139.74007921378717 32.539 35.67113772212547 139.7400737840764 32.539 35.67111667648514 139.74009889484213 32.539 35.67110991869851 139.7400904964207 32.539 35.671061416132716 139.74014912059346 32.539 35.67106845334067 139.74015751869 32.539 35.67105133423841 139.74017819526296 32.539 35.6710557010841 139.7401836249946 32.539</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-7d233b04-2bf1-4cdf-b3e0-ed8f6ef3e2b4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7d233b04-2bf1-4cdf-b3e0-ed8f6ef3e2b4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7d233b04-2bf1-4cdf-b3e0-ed8f6ef3e2b4">
											<gml:posList>35.6710557010841 139.7401836249946 35.095 35.67105971221586 139.74018365347342 35.095 35.67114208376037 139.7400841184 35.095 35.671142107003256 139.74007921378717 35.095 35.6710557010841 139.7401836249946 35.095</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-7dac914d-4200-484c-9a5b-93b3b1092b6d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7dac914d-4200-484c-9a5b-93b3b1092b6d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7dac914d-4200-484c-9a5b-93b3b1092b6d">
											<gml:posList>35.671143766792845 139.74018565462603 35.095 35.671141520214235 139.74018286250597 35.095 35.67110122428728 139.74023524697094 35.095 35.67110124617497 139.7402402398997 35.095 35.671143766792845 139.74018565462603 35.095</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-17a39eb1-73f7-4fc3-90cb-405f64647e82">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-17a39eb1-73f7-4fc3-90cb-405f64647e82">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-17a39eb1-73f7-4fc3-90cb-405f64647e82">
											<gml:posList>35.67111667648514 139.74009889484213 30.942 35.67113772212547 139.7400737840764 30.942 35.671130838016666 139.7400652201064 30.942 35.67110991869851 139.7400904964207 30.942 35.67111667648514 139.74009889484213 30.942</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-5d40cb7d-0358-44ff-b62c-efa94020530b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5d40cb7d-0358-44ff-b62c-efa94020530b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5d40cb7d-0358-44ff-b62c-efa94020530b">
											<gml:posList>35.67117493563818 139.7401615373298 34.77 35.67117572813623 139.7401606195602 34.77 35.67118985744951 139.74014352545083 34.77 35.67114208376037 139.7400841184 34.77 35.67105971221586 139.74018365347342 34.77 35.67110122428728 139.74023524697094 34.77 35.671141520214235 139.74018286250597 34.77 35.6711618722172 139.7401582717398 34.77 35.671169649532466 139.74016793932 34.77 35.67117493563818 139.7401615373298 34.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-7dae529d-f688-4ba8-98e3-99f6aa4aece9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7dae529d-f688-4ba8-98e3-99f6aa4aece9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7dae529d-f688-4ba8-98e3-99f6aa4aece9">
											<gml:posList>35.671141520214235 139.74018286250597 41.34 35.67114645075406 139.74018290096294 41.34 35.67116184984292 139.74016430308225 41.34 35.6711618722172 139.7401582717398 41.34 35.671141520214235 139.74018286250597 41.34</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-24b1509e-5c63-4f6f-ab90-89ce3dda02f2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-24b1509e-5c63-4f6f-ab90-89ce3dda02f2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-24b1509e-5c63-4f6f-ab90-89ce3dda02f2">
											<gml:posList>35.67116517696191 139.74021227359026 41.34 35.67116519933004 139.74020623120123 41.34 35.67114645075406 139.74018290096294 41.34 35.671141520214235 139.74018286250597 41.34 35.67116517696191 139.74021227359026 41.34</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-615f99f8-2ef3-4625-a2b8-a6afe5c33b2f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-615f99f8-2ef3-4625-a2b8-a6afe5c33b2f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-615f99f8-2ef3-4625-a2b8-a6afe5c33b2f">
											<gml:posList>35.6711805984139 139.74018762227428 40.955 35.67116184984292 139.74016430308225 40.955 35.67114645075406 139.74018290096294 40.955 35.67116519933004 139.74020623120123 40.955 35.6711805984139 139.74018762227428 40.955</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e8cb34e7-dfa1-4a15-8bf3-ab21026b71a3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e8cb34e7-dfa1-4a15-8bf3-ab21026b71a3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e8cb34e7-dfa1-4a15-8bf3-ab21026b71a3">
											<gml:posList>35.671142107003256 139.74007921378717 35.095 35.67114208376037 139.7400841184 35.095 35.67118985744951 139.74014352545083 35.095 35.67119386858118 139.74014355392768 35.095 35.671142107003256 139.74007921378717 35.095</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-9a472739-8423-4130-9f99-341c057fa844">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9a472739-8423-4130-9f99-341c057fa844">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9a472739-8423-4130-9f99-341c057fa844">
											<gml:posList>35.67117690255258 139.74016402047712 35.095 35.67117493563818 139.7401615373298 35.095 35.671169649532466 139.74016793932 35.095 35.67117164347936 139.7401704113895 35.095 35.67117690255258 139.74016402047712 35.095</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-59782307-7427-4041-940d-aaab5feafc3d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-59782307-7427-4041-940d-aaab5feafc3d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-59782307-7427-4041-940d-aaab5feafc3d">
											<gml:posList>35.6711618722172 139.7401582717398 41.34 35.67116184984292 139.74016430308225 41.34 35.6711805984139 139.74018762227428 41.34 35.67118552896225 139.74018767177793 41.34 35.6711618722172 139.7401582717398 41.34</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c80d2137-e3d5-438f-b483-d9ae9b233604">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c80d2137-e3d5-438f-b483-d9ae9b233604">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c80d2137-e3d5-438f-b483-d9ae9b233604">
											<gml:posList>35.67118552896225 139.74018767177793 41.34 35.6711805984139 139.74018762227428 41.34 35.67116519933004 139.74020623120123 41.34 35.67116517696191 139.74021227359026 41.34 35.67118552896225 139.74018767177793 41.34</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-784f70a3-8901-41fc-a08a-c954413efc21">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-784f70a3-8901-41fc-a08a-c954413efc21">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-784f70a3-8901-41fc-a08a-c954413efc21">
											<gml:posList>35.67117690255258 139.74016402047712 35.095 35.67117771306099 139.74016308059385 35.095 35.67117572813623 139.7401606195602 35.095 35.67117493563818 139.7401615373298 35.095 35.67117690255258 139.74016402047712 35.095</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-6a0cb696-8614-492e-9b55-d06aa5cc7f06">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6a0cb696-8614-492e-9b55-d06aa5cc7f06">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6a0cb696-8614-492e-9b55-d06aa5cc7f06">
											<gml:posList>35.67117771306099 139.74016308059385 35.095 35.67119386858118 139.74014355392768 35.095 35.67118985744951 139.74014352545083 35.095 35.67117572813623 139.7401606195602 35.095 35.67117771306099 139.74016308059385 35.095</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-00e6eb79-55ab-42e9-9617-d659f912a992">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-00e6eb79-55ab-42e9-9617-d659f912a992">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-00e6eb79-55ab-42e9-9617-d659f912a992">
											<gml:posList>35.671143766792845 139.74018565462603 32.852 35.67114171366388 139.74018824186064 32.852 35.67110124617497 139.7402402398997 32.852 35.67111460833984 139.740256838111 32.852 35.67115842820548 139.74020388619007 32.852 35.671143766792845 139.74018565462603 32.852</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b3208f66-20f4-4b4e-815b-9bc6bbd65dd2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b3208f66-20f4-4b4e-815b-9bc6bbd65dd2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b3208f66-20f4-4b4e-815b-9bc6bbd65dd2">
											<gml:posList>35.67116184984292 139.74016430308225 41.34 35.67116184984292 139.74016430308225 40.955 35.6711805984139 139.74018762227428 40.955 35.6711805984139 139.74018762227428 41.34 35.67116184984292 139.74016430308225 41.34</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5cbef920-0086-47c0-bc50-265ad26eb0ba">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5cbef920-0086-47c0-bc50-265ad26eb0ba">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5cbef920-0086-47c0-bc50-265ad26eb0ba">
											<gml:posList>35.67116519933004 139.74020623120123 41.34 35.67116519933004 139.74020623120123 40.955 35.67114645075406 139.74018290096294 40.955 35.67114645075406 139.74018290096294 41.34 35.67116519933004 139.74020623120123 41.34</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e9b3d6bd-b9e4-433d-bfec-41561fc4b10a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e9b3d6bd-b9e4-433d-bfec-41561fc4b10a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e9b3d6bd-b9e4-433d-bfec-41561fc4b10a">
											<gml:posList>35.671141520214235 139.74018286250597 35.095 35.671141520214235 139.74018286250597 34.77 35.67110122428728 139.74023524697094 34.77 35.67110122428728 139.74023524697094 35.095 35.671141520214235 139.74018286250597 35.095</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-cab91a63-ee85-4081-83dc-0839171892c2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cab91a63-ee85-4081-83dc-0839171892c2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cab91a63-ee85-4081-83dc-0839171892c2">
											<gml:posList>35.67105133423841 139.74017819526296 32.539 35.67106845334067 139.74015751869 32.539 35.67106845334067 139.74015751869 30.796 35.67105133423841 139.74017819526296 30.796 35.67105133423841 139.74017819526296 32.539</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-54a6ad8e-7aa0-489b-bafe-f0cb120102f1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-54a6ad8e-7aa0-489b-bafe-f0cb120102f1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-54a6ad8e-7aa0-489b-bafe-f0cb120102f1">
											<gml:posList>35.67106845334067 139.74015751869 32.539 35.671061416132716 139.74014912059346 32.539 35.671061416132716 139.74014912059346 30.796 35.67106845334067 139.74015751869 30.796 35.67106845334067 139.74015751869 32.539</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-47cdae78-931b-412d-9a3d-cd6c2480197f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-47cdae78-931b-412d-9a3d-cd6c2480197f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-47cdae78-931b-412d-9a3d-cd6c2480197f">
											<gml:posList>35.67104444112321 139.74016963130367 30.796 35.67104444112321 139.74016963130367 12.608 35.67111460833984 139.740256838111 12.608 35.67111460833984 139.740256838111 32.852 35.67110124617497 139.7402402398997 32.852 35.67110124617497 139.7402402398997 35.095 35.6710557010841 139.7401836249946 35.095 35.6710557010841 139.7401836249946 32.539 35.67105133423841 139.74017819526296 32.539 35.67105133423841 139.74017819526296 30.796 35.67104444112321 139.74016963130367 30.796</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-47847d95-fe5d-40d3-8509-fa5661037bbe">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-47847d95-fe5d-40d3-8509-fa5661037bbe">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-47847d95-fe5d-40d3-8509-fa5661037bbe">
											<gml:posList>35.67110122428728 139.74023524697094 35.095 35.67110122428728 139.74023524697094 34.77 35.67105971221586 139.74018365347342 34.77 35.67105971221586 139.74018365347342 35.095 35.67110122428728 139.74023524697094 35.095</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4244e2f3-c0df-469c-9e13-ac55eb695820">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4244e2f3-c0df-469c-9e13-ac55eb695820">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4244e2f3-c0df-469c-9e13-ac55eb695820">
											<gml:posList>35.671061416132716 139.74014912059346 30.796 35.671061416132716 139.74014912059346 32.539 35.67110991869851 139.7400904964207 32.539 35.67110991869851 139.7400904964207 30.942 35.671130838016666 139.7400652201064 30.942 35.671130838016666 139.7400652201064 12.608 35.67104444112321 139.74016963130367 12.608 35.67104444112321 139.74016963130367 30.796 35.671061416132716 139.74014912059346 30.796</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-725537ec-8894-4a01-86ae-1be31b7e9980">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-725537ec-8894-4a01-86ae-1be31b7e9980">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-725537ec-8894-4a01-86ae-1be31b7e9980">
											<gml:posList>35.6710557010841 139.7401836249946 32.539 35.6710557010841 139.7401836249946 35.095 35.671142107003256 139.74007921378717 35.095 35.671142107003256 139.74007921378717 32.539 35.6710557010841 139.7401836249946 32.539</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-106bc2c2-db81-4147-a46c-db9497875b17">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-106bc2c2-db81-4147-a46c-db9497875b17">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-106bc2c2-db81-4147-a46c-db9497875b17">
											<gml:posList>35.67105971221586 139.74018365347342 35.095 35.67105971221586 139.74018365347342 34.77 35.67114208376037 139.7400841184 34.77 35.67114208376037 139.7400841184 35.095 35.67105971221586 139.74018365347342 35.095</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-dbfeae07-24db-4203-9e08-0db354b1f8ec">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-dbfeae07-24db-4203-9e08-0db354b1f8ec">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-dbfeae07-24db-4203-9e08-0db354b1f8ec">
											<gml:posList>35.67110991869851 139.7400904964207 30.942 35.67110991869851 139.7400904964207 32.539 35.67111667648514 139.74009889484213 32.539 35.67111667648514 139.74009889484213 30.942 35.67110991869851 139.7400904964207 30.942</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a28dd671-5891-4196-8a4b-58a5960b34cf">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a28dd671-5891-4196-8a4b-58a5960b34cf">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a28dd671-5891-4196-8a4b-58a5960b34cf">
											<gml:posList>35.67114171366388 139.74018824186064 32.852 35.671143766792845 139.74018565462603 35.095 35.67110124617497 139.7402402398997 35.095 35.67110124617497 139.7402402398997 32.852 35.67114171366388 139.74018824186064 32.852</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e5ea4889-bc33-44a6-aa9d-a2855b5e1f76">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e5ea4889-bc33-44a6-aa9d-a2855b5e1f76">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e5ea4889-bc33-44a6-aa9d-a2855b5e1f76">
											<gml:posList>35.67111667648514 139.74009889484213 30.942 35.67111667648514 139.74009889484213 32.539 35.67113772212547 139.7400737840764 32.539 35.67113772212547 139.7400737840764 30.942 35.67111667648514 139.74009889484213 30.942</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2281a0aa-b9da-443e-92de-8e6c25f1714f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2281a0aa-b9da-443e-92de-8e6c25f1714f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2281a0aa-b9da-443e-92de-8e6c25f1714f">
											<gml:posList>35.67111460833984 139.740256838111 12.608 35.67115842820548 139.74020388619007 12.608 35.67115842820548 139.74020388619007 32.852 35.67111460833984 139.740256838111 32.852 35.67111460833984 139.740256838111 12.608</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6b249369-ad03-4be0-b955-fd27b11f9bd9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6b249369-ad03-4be0-b955-fd27b11f9bd9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6b249369-ad03-4be0-b955-fd27b11f9bd9">
											<gml:posList>35.671143766792845 139.74018565462603 32.852 35.671143766792845 139.74018565462603 35.095 35.67114171366388 139.74018824186064 32.852 35.671143766792845 139.74018565462603 32.852</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-63681c38-d58d-47c1-b779-085e9e15ba14">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-63681c38-d58d-47c1-b779-085e9e15ba14">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-63681c38-d58d-47c1-b779-085e9e15ba14">
											<gml:posList>35.6711618722172 139.7401582717398 41.34 35.6711618722172 139.7401582717398 34.77 35.671141520214235 139.74018286250597 34.77 35.671141520214235 139.74018286250597 35.095 35.671141520214235 139.74018286250597 41.34 35.6711618722172 139.7401582717398 41.34</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f89d4222-b181-4783-b326-57e036816f8e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f89d4222-b181-4783-b326-57e036816f8e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f89d4222-b181-4783-b326-57e036816f8e">
											<gml:posList>35.67116517696191 139.74021227359026 41.34 35.671141520214235 139.74018286250597 41.34 35.671141520214235 139.74018286250597 35.095 35.671143766792845 139.74018565462603 35.095 35.671143766792845 139.74018565462603 32.852 35.67115842820548 139.74020388619007 32.852 35.67115842820548 139.74020388619007 12.608 35.67116517696191 139.74021227359026 12.608 35.67116517696191 139.74021227359026 41.34</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-25cf72a3-65e3-4997-b15b-052283134bfe">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-25cf72a3-65e3-4997-b15b-052283134bfe">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-25cf72a3-65e3-4997-b15b-052283134bfe">
											<gml:posList>35.67114645075406 139.74018290096294 41.34 35.67114645075406 139.74018290096294 40.955 35.67116184984292 139.74016430308225 40.955 35.67116184984292 139.74016430308225 41.34 35.67114645075406 139.74018290096294 41.34</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c2719ce6-9c09-4f5b-a950-091345443da7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c2719ce6-9c09-4f5b-a950-091345443da7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c2719ce6-9c09-4f5b-a950-091345443da7">
											<gml:posList>35.671130838016666 139.7400652201064 12.608 35.671130838016666 139.7400652201064 30.942 35.67113772212547 139.7400737840764 30.942 35.67113772212547 139.7400737840764 32.539 35.671142107003256 139.74007921378717 32.539 35.671142107003256 139.74007921378717 35.095 35.67119386858118 139.74014355392768 35.095 35.67119386858118 139.74014355392768 12.608 35.671130838016666 139.7400652201064 12.608</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-de7e914b-3f99-4582-85fd-e4732b7f31b4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-de7e914b-3f99-4582-85fd-e4732b7f31b4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-de7e914b-3f99-4582-85fd-e4732b7f31b4">
											<gml:posList>35.67114208376037 139.7400841184 35.095 35.67114208376037 139.7400841184 34.77 35.67118985744951 139.74014352545083 34.77 35.67118985744951 139.74014352545083 35.095 35.67114208376037 139.7400841184 35.095</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-46db28e1-7fe3-49f4-98d8-a089884521c1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-46db28e1-7fe3-49f4-98d8-a089884521c1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-46db28e1-7fe3-49f4-98d8-a089884521c1">
											<gml:posList>35.67117493563818 139.7401615373298 35.095 35.67117493563818 139.7401615373298 34.77 35.671169649532466 139.74016793932 34.77 35.671169649532466 139.74016793932 35.095 35.67117493563818 139.7401615373298 35.095</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9a0e2712-7d99-4e4c-98ae-1d4b9f9c9e75">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9a0e2712-7d99-4e4c-98ae-1d4b9f9c9e75">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9a0e2712-7d99-4e4c-98ae-1d4b9f9c9e75">
											<gml:posList>35.6711805984139 139.74018762227428 41.34 35.6711805984139 139.74018762227428 40.955 35.67116519933004 139.74020623120123 40.955 35.67116519933004 139.74020623120123 41.34 35.6711805984139 139.74018762227428 41.34</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-836384b0-c92d-4f2b-9ca7-516ebfc6dc16">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-836384b0-c92d-4f2b-9ca7-516ebfc6dc16">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-836384b0-c92d-4f2b-9ca7-516ebfc6dc16">
											<gml:posList>35.67118552896225 139.74018767177793 41.34 35.67118552896225 139.74018767177793 12.608 35.67117164347936 139.7401704113895 12.608 35.67117164347936 139.7401704113895 35.095 35.671169649532466 139.74016793932 35.095 35.671169649532466 139.74016793932 34.77 35.6711618722172 139.7401582717398 34.77 35.6711618722172 139.7401582717398 41.34 35.67118552896225 139.74018767177793 41.34</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e2dfc5f6-d9fb-492e-bd9c-08e47c0d20c3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e2dfc5f6-d9fb-492e-bd9c-08e47c0d20c3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e2dfc5f6-d9fb-492e-bd9c-08e47c0d20c3">
											<gml:posList>35.67117164347936 139.7401704113895 12.608 35.67117690255258 139.74016402047712 12.608 35.67117690255258 139.74016402047712 35.095 35.67117164347936 139.7401704113895 35.095 35.67117164347936 139.7401704113895 12.608</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-44974df9-fa1f-475e-851c-440c2a731c98">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-44974df9-fa1f-475e-851c-440c2a731c98">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-44974df9-fa1f-475e-851c-440c2a731c98">
											<gml:posList>35.67118552896225 139.74018767177793 41.34 35.67116517696191 139.74021227359026 41.34 35.67116517696191 139.74021227359026 12.608 35.67118552896225 139.74018767177793 12.608 35.67118552896225 139.74018767177793 41.34</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b67d6200-45d3-4683-a98c-ae82dc533e3a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b67d6200-45d3-4683-a98c-ae82dc533e3a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b67d6200-45d3-4683-a98c-ae82dc533e3a">
											<gml:posList>35.67117572813623 139.7401606195602 35.095 35.67117572813623 139.7401606195602 34.77 35.67117493563818 139.7401615373298 34.77 35.67117493563818 139.7401615373298 35.095 35.67117572813623 139.7401606195602 35.095</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-57f395de-90df-4e4b-998d-016be9cca107">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-57f395de-90df-4e4b-998d-016be9cca107">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-57f395de-90df-4e4b-998d-016be9cca107">
											<gml:posList>35.67117690255258 139.74016402047712 12.608 35.67117771306099 139.74016308059385 12.608 35.67117771306099 139.74016308059385 35.095 35.67117690255258 139.74016402047712 35.095 35.67117690255258 139.74016402047712 12.608</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f25f653b-9878-4d26-817b-9486e103d5ed">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f25f653b-9878-4d26-817b-9486e103d5ed">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f25f653b-9878-4d26-817b-9486e103d5ed">
											<gml:posList>35.67118985744951 139.74014352545083 35.095 35.67118985744951 139.74014352545083 34.77 35.67117572813623 139.7401606195602 34.77 35.67117572813623 139.7401606195602 35.095 35.67118985744951 139.74014352545083 35.095</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4a13639e-d434-4578-b438-78d87773f34d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4a13639e-d434-4578-b438-78d87773f34d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4a13639e-d434-4578-b438-78d87773f34d">
											<gml:posList>35.67117771306099 139.74016308059385 12.608 35.67119386858118 139.74014355392768 12.608 35.67119386858118 139.74014355392768 35.095 35.67117771306099 139.74016308059385 35.095 35.67117771306099 139.74016308059385 12.608</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-4309</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">153.16245</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">211</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1320</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>6</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.05</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>