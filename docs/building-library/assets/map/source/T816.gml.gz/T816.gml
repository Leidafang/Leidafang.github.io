<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_e8dad93a-f986-4ee0-a15f-9cd35cd0d431">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001001</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">422</bldg:usage>
			<bldg:measuredHeight uom="m">14.7</bldg:measuredHeight>
			<bldg:storeysAboveGround>4</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.66699102202431 139.74248508757154 0 35.66700712517383 139.74244342668047 0 35.66682541879709 139.7423380350772 0 35.66678448641522 139.74244412086333 0 35.66679449598912 139.74244985331612 0 35.66677947256753 139.74248897234648 0 35.66696063774055 139.74259403347057 0 35.667000580826205 139.7424907100969 0 35.66699102202431 139.74248508757154 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66699102202431 139.74248508757154 27.91 35.667000580826205 139.7424907100969 27.91 35.66696063774055 139.74259403347057 27.91 35.66677947256753 139.74248897234648 27.91 35.66679449598912 139.74244985331612 27.91 35.66678448641522 139.74244412086333 27.91 35.66682541879709 139.7423380350772 27.91 35.66700712517383 139.74244342668047 27.91 35.66699102202431 139.74248508757154 27.91</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66699102202431 139.74248508757154 27.91 35.66700712517383 139.74244342668047 27.91 35.66700712517383 139.74244342668047 42.58 35.66699102202431 139.74248508757154 42.58 35.66699102202431 139.74248508757154 27.91</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66700712517383 139.74244342668047 27.91 35.66682541879709 139.7423380350772 27.91 35.66682541879709 139.7423380350772 42.58 35.66700712517383 139.74244342668047 42.58 35.66700712517383 139.74244342668047 27.91</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66682541879709 139.7423380350772 27.91 35.66678448641522 139.74244412086333 27.91 35.66678448641522 139.74244412086333 42.58 35.66682541879709 139.7423380350772 42.58 35.66682541879709 139.7423380350772 27.91</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66678448641522 139.74244412086333 27.91 35.66679449598912 139.74244985331612 27.91 35.66679449598912 139.74244985331612 42.58 35.66678448641522 139.74244412086333 42.58 35.66678448641522 139.74244412086333 27.91</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66679449598912 139.74244985331612 27.91 35.66677947256753 139.74248897234648 27.91 35.66677947256753 139.74248897234648 42.58 35.66679449598912 139.74244985331612 42.58 35.66679449598912 139.74244985331612 27.91</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66677947256753 139.74248897234648 27.91 35.66696063774055 139.74259403347057 27.91 35.66696063774055 139.74259403347057 42.58 35.66677947256753 139.74248897234648 42.58 35.66677947256753 139.74248897234648 27.91</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66696063774055 139.74259403347057 27.91 35.667000580826205 139.7424907100969 27.91 35.667000580826205 139.7424907100969 42.58 35.66696063774055 139.74259403347057 42.58 35.66696063774055 139.74259403347057 27.91</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667000580826205 139.7424907100969 27.91 35.66699102202431 139.74248508757154 27.91 35.66699102202431 139.74248508757154 42.58 35.667000580826205 139.7424907100969 42.58 35.667000580826205 139.7424907100969 27.91</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66699102202431 139.74248508757154 42.58 35.66700712517383 139.74244342668047 42.58 35.66682541879709 139.7423380350772 42.58 35.66678448641522 139.74244412086333 42.58 35.66679449598912 139.74244985331612 42.58 35.66677947256753 139.74248897234648 42.58 35.66696063774055 139.74259403347057 42.58 35.667000580826205 139.7424907100969 42.58 35.66699102202431 139.74248508757154 42.58</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-5a05d15a-a193-490a-aa3d-82e8dacdd5cd"/>
							<gml:surfaceMember xlink:href="#poly-c0522449-89ea-4d7c-a24a-598772af92a5"/>
							<gml:surfaceMember xlink:href="#poly-2e4da8a1-9243-4fac-b82f-f56ccdc17a56"/>
							<gml:surfaceMember xlink:href="#poly-ff77021e-ce95-427a-a8ee-549d03a2b249"/>
							<gml:surfaceMember xlink:href="#poly-90d1b6a8-6231-4600-ab93-b9dc4cfde747"/>
							<gml:surfaceMember xlink:href="#poly-a213b55c-3f55-4c49-9129-e6baa614d935"/>
							<gml:surfaceMember xlink:href="#poly-61919f9f-da85-4024-99d5-a33f0fb56ecb"/>
							<gml:surfaceMember xlink:href="#poly-3170db4c-8999-4106-807e-0508326d50c8"/>
							<gml:surfaceMember xlink:href="#poly-e42eb0ee-83a4-453d-8c55-4f3ad9bfb430"/>
							<gml:surfaceMember xlink:href="#poly-a41a07ef-68e2-49fd-a2de-901bbab3057c"/>
							<gml:surfaceMember xlink:href="#poly-363aaeea-9b6a-469a-a128-5145e25ac317"/>
							<gml:surfaceMember xlink:href="#poly-f720aef1-285b-4a76-8ed9-7221c96d686f"/>
							<gml:surfaceMember xlink:href="#poly-af1d8ba6-50f1-4416-aa7d-ca756b44ebd7"/>
							<gml:surfaceMember xlink:href="#poly-7f967b88-c8f5-4c1b-ac51-99fc9d1ad27b"/>
							<gml:surfaceMember xlink:href="#poly-e93045b3-21d9-462c-a56a-b587531b9604"/>
							<gml:surfaceMember xlink:href="#poly-fe76b0c7-6671-4ae3-8a3e-ede9d0e7e5c9"/>
							<gml:surfaceMember xlink:href="#poly-08322fb9-4425-463e-9ae0-54a44e170d2c"/>
							<gml:surfaceMember xlink:href="#poly-316bc927-23e4-42c0-ad45-30ba3ce44487"/>
							<gml:surfaceMember xlink:href="#poly-cf6b0873-282b-4a76-9353-9f365b50581d"/>
							<gml:surfaceMember xlink:href="#poly-64fb759f-3d28-4149-a715-ddcfbca69d41"/>
							<gml:surfaceMember xlink:href="#poly-fb109f39-7526-4a31-9e24-0333a2197680"/>
							<gml:surfaceMember xlink:href="#poly-dfcf5ddc-d2f2-4136-b4b2-9d5e1e9d74cf"/>
							<gml:surfaceMember xlink:href="#poly-335163ec-91f0-4670-b137-53b251c6ab49"/>
							<gml:surfaceMember xlink:href="#poly-79bdfc4f-0ef3-463e-a07c-d2ada1618933"/>
							<gml:surfaceMember xlink:href="#poly-da30a88f-169a-4180-90fb-bb0d510f195d"/>
							<gml:surfaceMember xlink:href="#poly-141c8aed-bdc9-4d78-ae9a-13607c678e55"/>
							<gml:surfaceMember xlink:href="#poly-c30d40d6-90b8-4327-989c-f6c2a0414ca7"/>
							<gml:surfaceMember xlink:href="#poly-3a105de7-01a9-4ba6-b6b4-4504507b2f6b"/>
							<gml:surfaceMember xlink:href="#poly-02a5b328-c207-4b59-8ad7-fcd732239945"/>
							<gml:surfaceMember xlink:href="#poly-42f0c4ff-193b-4e08-a7de-fcde792dedcf"/>
							<gml:surfaceMember xlink:href="#poly-a6dfc3a2-ba93-4579-96ce-3a436c026dfa"/>
							<gml:surfaceMember xlink:href="#poly-3026f4a2-7f1d-4303-9f6b-291923b72911"/>
							<gml:surfaceMember xlink:href="#poly-261bdf31-ad60-4401-8483-060d9bbb806c"/>
							<gml:surfaceMember xlink:href="#poly-3487ca39-caf5-493c-b1c9-28f7745853b6"/>
							<gml:surfaceMember xlink:href="#poly-371b11ea-4a45-4955-97ae-bf5836850875"/>
							<gml:surfaceMember xlink:href="#poly-4fa8cc32-9e78-4a58-9fa6-69aed6254a3d"/>
							<gml:surfaceMember xlink:href="#poly-4c53d7e6-26da-44cb-a210-78c62945f2d2"/>
							<gml:surfaceMember xlink:href="#poly-06186d0f-ce1d-4306-ab14-e3f48039d381"/>
							<gml:surfaceMember xlink:href="#poly-50f9daf4-108d-4e70-bfd4-5d0aeaa5f4c8"/>
							<gml:surfaceMember xlink:href="#poly-9d52823e-9b8a-4622-a038-130165197f7c"/>
							<gml:surfaceMember xlink:href="#poly-f384695a-f3b8-4f0e-a412-ffef26304ba2"/>
							<gml:surfaceMember xlink:href="#poly-25a30b0f-ebc7-483e-8400-89e2977a2ed8"/>
							<gml:surfaceMember xlink:href="#poly-b2f4e00d-45b0-4f56-9bcb-95bdafb59a68"/>
							<gml:surfaceMember xlink:href="#poly-0389c0d2-3852-448c-a5f1-60448d49ed96"/>
							<gml:surfaceMember xlink:href="#poly-91829bb0-0e87-4428-860e-35bd2ea4163a"/>
							<gml:surfaceMember xlink:href="#poly-50e28a2e-b9e8-4a16-bebe-27ce2bea2219"/>
							<gml:surfaceMember xlink:href="#poly-c81480be-18b6-44db-9845-37c998177437"/>
							<gml:surfaceMember xlink:href="#poly-76104f0f-c9ca-47f7-b34a-9bfd19d09cc4"/>
							<gml:surfaceMember xlink:href="#poly-2a7eaa88-4824-4abd-a61d-801481c5b26c"/>
							<gml:surfaceMember xlink:href="#poly-05e1f829-5f19-426b-aadd-5d64d67a968c"/>
							<gml:surfaceMember xlink:href="#poly-35ccee33-d5d9-4f19-847e-21bcd751f3a8"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_e8dad93a-f986-4ee0-a15f-9cd35cd0d431_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f52759c4-01dc-4c7a-8d4e-8d7e813ef33b">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66682979088348 139.7424937975719 42.73 35.66683792437716 139.74247401642677 42.73 35.66685876482094 139.742486872186 42.73 35.66685064033891 139.74250665332477 42.73 35.66682979088348 139.7424937975719 42.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-dfa2253e-7830-42fa-bd70-49a09ed6b85f">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.666863825940695 139.74250467224184 42.73 35.6668718514547 139.7424851342188 42.73 35.666879345354644 139.74248975390938 42.73 35.666871310826174 139.74250929194397 42.73 35.666863825940695 139.74250467224184 42.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-22aba473-bde9-46ff-a551-36052112a823">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66689444894931 139.74249715956253 42.73 35.666887710030664 139.74251355913165 42.73 35.66687893558235 139.7425081455928 42.73 35.66688567449194 139.74249173497927 42.73 35.66689444894931 139.74249715956253 42.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-939b5d71-96b9-4e2c-a9fc-0610aebbeb2e">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66690819227866 139.74250563820004 42.73 35.666901255423376 139.74252252400976 42.73 35.666893121250084 139.74251750739194 42.73 35.66690005810468 139.7425006215835 42.73 35.66690819227866 139.74250563820004 42.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fcedd302-2618-40cd-9d26-08772d96b4d1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66691878235144 139.7425042233904 42.73 35.66692808885978 139.74250996770238 42.73 35.66692108000237 139.7425269971926 42.73 35.666911782516884 139.7425212639147 42.73 35.66691878235144 139.7425042233904 42.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e5e57b85-062a-4f3c-a2a2-4902d32a9c94">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e5e57b85-062a-4f3c-a2a2-4902d32a9c94_0">
											<gml:posList>35.66682979088348 139.7424937975719 42.73 35.66682979088348 139.7424937975719 45.34 35.66683792437716 139.74247401642677 45.34 35.66683792437716 139.74247401642677 42.73 35.66682979088348 139.7424937975719 42.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7691cfc2-508c-42a8-b6c5-044fdf0b7098">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7691cfc2-508c-42a8-b6c5-044fdf0b7098_0">
											<gml:posList>35.66682979088348 139.7424937975719 42.73 35.66685064033891 139.74250665332477 42.73 35.66685064033891 139.74250665332477 45.34 35.66682979088348 139.7424937975719 45.34 35.66682979088348 139.7424937975719 42.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bd4edde5-787e-4fb9-8ecf-30c13a2736d7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bd4edde5-787e-4fb9-8ecf-30c13a2736d7_0">
											<gml:posList>35.66682979088348 139.7424937975719 45.34 35.66685064033891 139.74250665332477 45.34 35.66685876482094 139.742486872186 45.34 35.66683792437716 139.74247401642677 45.34 35.66682979088348 139.7424937975719 45.34</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1f56c779-8d26-463e-8690-8a2930960263">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1f56c779-8d26-463e-8690-8a2930960263_0">
											<gml:posList>35.66685876482094 139.742486872186 42.73 35.66683792437716 139.74247401642677 42.73 35.66683792437716 139.74247401642677 45.34 35.66685876482094 139.742486872186 45.34 35.66685876482094 139.742486872186 42.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-20782a1f-5d61-4438-a661-2ee894f7d913">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-20782a1f-5d61-4438-a661-2ee894f7d913_0">
											<gml:posList>35.66685876482094 139.742486872186 42.73 35.66685876482094 139.742486872186 45.34 35.66685064033891 139.74250665332477 45.34 35.66685064033891 139.74250665332477 42.73 35.66685876482094 139.742486872186 42.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7a8afda5-a7c2-4046-b508-18516caa3f0d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7a8afda5-a7c2-4046-b508-18516caa3f0d_0">
											<gml:posList>35.666863825940695 139.74250467224184 42.73 35.666871310826174 139.74250929194397 42.73 35.666871310826174 139.74250929194397 44.35 35.666863825940695 139.74250467224184 44.35 35.666863825940695 139.74250467224184 42.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e078f05e-7f98-4be3-be5f-03e6ab14dc59">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e078f05e-7f98-4be3-be5f-03e6ab14dc59_0">
											<gml:posList>35.6668718514547 139.7424851342188 42.73 35.666863825940695 139.74250467224184 42.73 35.666863825940695 139.74250467224184 44.35 35.6668718514547 139.7424851342188 44.35 35.6668718514547 139.7424851342188 42.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2fdc7df3-f0d2-4aab-ac50-1e890ed01918">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2fdc7df3-f0d2-4aab-ac50-1e890ed01918_0">
											<gml:posList>35.666879345354644 139.74248975390938 44.35 35.6668718514547 139.7424851342188 44.35 35.666863825940695 139.74250467224184 44.35 35.666871310826174 139.74250929194397 44.35 35.666879345354644 139.74248975390938 44.35</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-371943cf-df5b-460f-9dff-5d3b55f1a8f5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-371943cf-df5b-460f-9dff-5d3b55f1a8f5_0">
											<gml:posList>35.666879345354644 139.74248975390938 42.73 35.666879345354644 139.74248975390938 44.35 35.666871310826174 139.74250929194397 44.35 35.666871310826174 139.74250929194397 42.73 35.666879345354644 139.74248975390938 42.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d0c2fc5e-b7c5-49f2-9afb-ad787f25353c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d0c2fc5e-b7c5-49f2-9afb-ad787f25353c_0">
											<gml:posList>35.6668718514547 139.7424851342188 44.35 35.666879345354644 139.74248975390938 44.35 35.666879345354644 139.74248975390938 42.73 35.6668718514547 139.7424851342188 42.73 35.6668718514547 139.7424851342188 44.35</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6aeea2c2-434f-403f-9e51-d4f2070201bb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6aeea2c2-434f-403f-9e51-d4f2070201bb_0">
											<gml:posList>35.66688567449194 139.74249173497927 42.73 35.66687893558235 139.7425081455928 42.73 35.66687893558235 139.7425081455928 45.014 35.66688567449194 139.74249173497927 45.014 35.66688567449194 139.74249173497927 42.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a743224c-3f0f-4032-827c-c74c6253046d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a743224c-3f0f-4032-827c-c74c6253046d_0">
											<gml:posList>35.66687893558235 139.7425081455928 42.73 35.666887710030664 139.74251355913165 42.73 35.666887710030664 139.74251355913165 45.014 35.66687893558235 139.7425081455928 45.014 35.66687893558235 139.7425081455928 42.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3824e0a7-3fa3-43e1-a808-342522d105c3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3824e0a7-3fa3-43e1-a808-342522d105c3_0">
											<gml:posList>35.66687893558235 139.7425081455928 45.014 35.666887710030664 139.74251355913165 45.014 35.66689444894931 139.74249715956253 45.014 35.66688567449194 139.74249173497927 45.014 35.66687893558235 139.7425081455928 45.014</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-faa2f0cd-e31e-48d0-9647-daee3cfe5d10">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-faa2f0cd-e31e-48d0-9647-daee3cfe5d10_0">
											<gml:posList>35.66689444894931 139.74249715956253 42.73 35.66688567449194 139.74249173497927 42.73 35.66688567449194 139.74249173497927 45.014 35.66689444894931 139.74249715956253 45.014 35.66689444894931 139.74249715956253 42.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5b22bca2-b9cc-49ef-8148-33ae6f5fe44c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5b22bca2-b9cc-49ef-8148-33ae6f5fe44c_0">
											<gml:posList>35.66689444894931 139.74249715956253 42.73 35.66689444894931 139.74249715956253 45.014 35.666887710030664 139.74251355913165 45.014 35.666887710030664 139.74251355913165 42.73 35.66689444894931 139.74249715956253 42.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2a158f38-eb77-4e1b-890b-45cfbb9b62e2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2a158f38-eb77-4e1b-890b-45cfbb9b62e2_0">
											<gml:posList>35.66690005810468 139.7425006215835 42.73 35.666893121250084 139.74251750739194 42.73 35.666893121250084 139.74251750739194 45.014 35.66690005810468 139.7425006215835 45.014 35.66690005810468 139.7425006215835 42.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ae63541d-c6f6-40de-b5f6-580210261614">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ae63541d-c6f6-40de-b5f6-580210261614_0">
											<gml:posList>35.666901255423376 139.74252252400976 42.73 35.666901255423376 139.74252252400976 45.014 35.666893121250084 139.74251750739194 45.014 35.666893121250084 139.74251750739194 42.73 35.666901255423376 139.74252252400976 42.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e9c83ec7-7972-425e-b33a-eef58314681b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e9c83ec7-7972-425e-b33a-eef58314681b_0">
											<gml:posList>35.666893121250084 139.74251750739194 45.014 35.666901255423376 139.74252252400976 45.014 35.66690819227866 139.74250563820004 45.014 35.66690005810468 139.7425006215835 45.014 35.666893121250084 139.74251750739194 45.014</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2a5d82cd-5adc-43b8-9cbd-e17790d0e037">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2a5d82cd-5adc-43b8-9cbd-e17790d0e037_0">
											<gml:posList>35.66690819227866 139.74250563820004 42.73 35.66690005810468 139.7425006215835 42.73 35.66690005810468 139.7425006215835 45.014 35.66690819227866 139.74250563820004 45.014 35.66690819227866 139.74250563820004 42.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cd592237-bfb0-4d8c-9bcd-ec44f901169b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cd592237-bfb0-4d8c-9bcd-ec44f901169b_0">
											<gml:posList>35.666901255423376 139.74252252400976 42.73 35.66690819227866 139.74250563820004 42.73 35.66690819227866 139.74250563820004 45.014 35.666901255423376 139.74252252400976 45.014 35.666901255423376 139.74252252400976 42.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1ac622f9-6969-46ec-a65e-c68d034d4cde">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1ac622f9-6969-46ec-a65e-c68d034d4cde_0">
											<gml:posList>35.66691878235144 139.7425042233904 42.73 35.666911782516884 139.7425212639147 42.73 35.666911782516884 139.7425212639147 45.014 35.66691878235144 139.7425042233904 45.014 35.66691878235144 139.7425042233904 42.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a52cede3-d97d-4582-a143-24533df78d22">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a52cede3-d97d-4582-a143-24533df78d22_0">
											<gml:posList>35.66692108000237 139.7425269971926 42.73 35.66692108000237 139.7425269971926 45.014 35.666911782516884 139.7425212639147 45.014 35.666911782516884 139.7425212639147 42.73 35.66692108000237 139.7425269971926 42.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c7786ee5-b49c-4d4d-a685-9a0f3de453ef">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c7786ee5-b49c-4d4d-a685-9a0f3de453ef_0">
											<gml:posList>35.66692108000237 139.7425269971926 45.014 35.66692808885978 139.74250996770238 45.014 35.66691878235144 139.7425042233904 45.014 35.666911782516884 139.7425212639147 45.014 35.66692108000237 139.7425269971926 45.014</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bcd473e3-ab27-4755-b794-d4afcc9c95a5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bcd473e3-ab27-4755-b794-d4afcc9c95a5_0">
											<gml:posList>35.66692808885978 139.74250996770238 42.73 35.66691878235144 139.7425042233904 42.73 35.66691878235144 139.7425042233904 45.014 35.66692808885978 139.74250996770238 45.014 35.66692808885978 139.74250996770238 42.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3d8d7338-d2de-4ed6-a33b-9b9030a329f4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3d8d7338-d2de-4ed6-a33b-9b9030a329f4_0">
											<gml:posList>35.66692108000237 139.7425269971926 42.73 35.66692808885978 139.74250996770238 42.73 35.66692808885978 139.74250996770238 45.014 35.66692108000237 139.7425269971926 45.014 35.66692108000237 139.7425269971926 42.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-5a05d15a-a193-490a-aa3d-82e8dacdd5cd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5a05d15a-a193-490a-aa3d-82e8dacdd5cd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5a05d15a-a193-490a-aa3d-82e8dacdd5cd">
											<gml:posList>35.6669910220243 139.7424850875715 27.91 35.66700058082619 139.74249071009686 27.91 35.66696063774051 139.74259403347054 27.91 35.666779472567505 139.7424889723465 27.91 35.666794495989095 139.74244985331612 27.91 35.6667844864152 139.74244412086333 27.91 35.666825418797096 139.74233803507718 27.91 35.667007125173804 139.74244342668047 27.91 35.6669910220243 139.7424850875715 27.91</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c0522449-89ea-4d7c-a24a-598772af92a5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c0522449-89ea-4d7c-a24a-598772af92a5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c0522449-89ea-4d7c-a24a-598772af92a5">
											<gml:posList>35.66679957876612 139.74243662577305 45.8 35.666779472567505 139.7424889723465 45.8 35.6668044335086 139.74250344716063 45.8 35.66682465688354 139.74245108939593 45.8 35.66679957876612 139.74243662577305 45.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-2e4da8a1-9243-4fac-b82f-f56ccdc17a56">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2e4da8a1-9243-4fac-b82f-f56ccdc17a56">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2e4da8a1-9243-4fac-b82f-f56ccdc17a56">
											<gml:posList>35.66679957876612 139.74243662577305 33.33 35.66682465688354 139.74245108939593 33.33 35.66684272994986 139.74240402496827 33.33 35.666861300179775 139.74235884878283 33.33 35.666825418797096 139.74233803507718 33.33 35.6667844864152 139.74244412086333 33.33 35.666794495989095 139.74244985331612 33.33 35.66679957876612 139.74243662577305 33.33</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ff77021e-ce95-427a-a8ee-549d03a2b249">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ff77021e-ce95-427a-a8ee-549d03a2b249">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ff77021e-ce95-427a-a8ee-549d03a2b249">
											<gml:posList>35.666825397726576 139.7424533639849 43.4 35.66682598247685 139.74245185005168 43.4 35.66684341681984 139.74240644321355 43.4 35.66684272994986 139.74240402496827 43.4 35.66682465688354 139.74245108939593 43.4 35.666824072133274 139.74245260332913 43.4 35.666825397726576 139.7424533639849 43.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-90d1b6a8-6231-4600-ab93-b9dc4cfde747">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-90d1b6a8-6231-4600-ab93-b9dc4cfde747">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-90d1b6a8-6231-4600-ab93-b9dc4cfde747">
											<gml:posList>35.66684534314709 139.7424029837024 40.3 35.66684272994986 139.74240402496827 40.3 35.66684447040852 139.74240509443462 40.3 35.66684534314709 139.7424029837024 40.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a213b55c-3f55-4c49-9129-e6baa614d935">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a213b55c-3f55-4c49-9129-e6baa614d935">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a213b55c-3f55-4c49-9129-e6baa614d935">
											<gml:posList>35.66684272994986 139.74240402496827 40.3 35.66684534314709 139.7424029837024 40.3 35.66685506911905 139.74237931262556 40.3 35.66685420138158 139.74237611033536 40.3 35.66684272994986 139.74240402496827 40.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-61919f9f-da85-4024-99d5-a33f0fb56ecb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-61919f9f-da85-4024-99d5-a33f0fb56ecb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-61919f9f-da85-4024-99d5-a33f0fb56ecb">
											<gml:posList>35.666806379824095 139.74250258338617 43.4 35.66680506324484 139.74250182271956 43.4 35.6668044335086 139.74250344716063 43.4 35.66696063774051 139.74259403347054 43.4 35.666959941885544 139.74259164836764 43.4 35.666806379824095 139.74250258338617 43.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-3170db4c-8999-4106-807e-0508326d50c8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3170db4c-8999-4106-807e-0508326d50c8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3170db4c-8999-4106-807e-0508326d50c8">
											<gml:posList>35.666943766914265 139.74246637431816 43.4 35.66684272994986 139.74240402496827 43.4 35.66684341681984 139.74240644321355 43.4 35.666944408697674 139.74246877052653 43.4 35.666943766914265 139.74246637431816 43.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e42eb0ee-83a4-453d-8c55-4f3ad9bfb430">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e42eb0ee-83a4-453d-8c55-4f3ad9bfb430">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e42eb0ee-83a4-453d-8c55-4f3ad9bfb430">
											<gml:posList>35.666825397726576 139.7424533639849 42.73 35.666824072133274 139.74245260332913 42.73 35.66680506324484 139.74250182271956 42.73 35.666806379824095 139.74250258338617 42.73 35.666959941885544 139.74259164836764 42.73 35.666998643491226 139.74249152968036 42.73 35.66694753074344 139.74246118957907 42.73 35.666944408697674 139.74246877052653 42.73 35.66684341681984 139.74240644321355 42.73 35.66682598247685 139.74245185005168 42.73 35.666825397726576 139.7424533639849 42.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a41a07ef-68e2-49fd-a2de-901bbab3057c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a41a07ef-68e2-49fd-a2de-901bbab3057c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a41a07ef-68e2-49fd-a2de-901bbab3057c">
											<gml:posList>35.666960748324506 139.7424418665619 40.3 35.66685420138158 139.74237611033536 40.3 35.66685506911905 139.74237931262556 40.3 35.66696160703814 139.7424450578215 40.3 35.666960748324506 139.7424418665619 40.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-363aaeea-9b6a-469a-a128-5145e25ac317">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-363aaeea-9b6a-469a-a128-5145e25ac317">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-363aaeea-9b6a-469a-a128-5145e25ac317">
											<gml:posList>35.66685420138158 139.74237611033536 36.9 35.666960748324506 139.7424418665619 36.9 35.666969151704244 139.74242140023424 36.9 35.666861300179775 139.74235884878283 36.9 35.66685420138158 139.74237611033536 36.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f720aef1-285b-4a76-8ed9-7221c96d686f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f720aef1-285b-4a76-8ed9-7221c96d686f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f720aef1-285b-4a76-8ed9-7221c96d686f">
											<gml:posList>35.66699010923769 139.74248190741736 39.204 35.667004548097914 139.74244455627255 39.204 35.66697003742624 139.74242454728014 39.204 35.66696160703814 139.7424450578215 39.204 35.66685506911905 139.74237931262556 39.204 35.66684534314709 139.7424029837024 39.204 35.66684447040852 139.74240509443462 39.204 35.666943766914265 139.74246637431816 39.204 35.66694687996283 139.74245881547242 39.204 35.66698926355561 139.74248404021347 39.204 35.66699010923769 139.74248190741736 39.204</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-af1d8ba6-50f1-4416-aa7d-ca756b44ebd7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-af1d8ba6-50f1-4416-aa7d-ca756b44ebd7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-af1d8ba6-50f1-4416-aa7d-ca756b44ebd7">
											<gml:posList>35.666943766914265 139.74246637431816 43.4 35.666944408697674 139.74246877052653 43.4 35.66694753074344 139.74246118957907 43.4 35.66694687996283 139.74245881547242 43.4 35.666943766914265 139.74246637431816 43.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-7f967b88-c8f5-4c1b-ac51-99fc9d1ad27b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7f967b88-c8f5-4c1b-ac51-99fc9d1ad27b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7f967b88-c8f5-4c1b-ac51-99fc9d1ad27b">
											<gml:posList>35.666960748324506 139.7424418665619 40.3 35.66696160703814 139.7424450578215 40.3 35.66697003742624 139.74242454728014 40.3 35.666969151704244 139.74242140023424 40.3 35.666960748324506 139.7424418665619 40.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e93045b3-21d9-462c-a56a-b587531b9604">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e93045b3-21d9-462c-a56a-b587531b9604">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e93045b3-21d9-462c-a56a-b587531b9604">
											<gml:posList>35.66694687996283 139.74245881547242 43.4 35.66694753074344 139.74246118957907 43.4 35.666998643491226 139.74249152968036 43.4 35.66700058082619 139.74249071009686 43.4 35.66694687996283 139.74245881547242 43.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-fe76b0c7-6671-4ae3-8a3e-ede9d0e7e5c9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fe76b0c7-6671-4ae3-8a3e-ede9d0e7e5c9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fe76b0c7-6671-4ae3-8a3e-ede9d0e7e5c9">
											<gml:posList>35.66700058082619 139.74249071009686 43.4 35.666998643491226 139.74249152968036 43.4 35.666959941885544 139.74259164836764 43.4 35.66696063774051 139.74259403347054 43.4 35.66700058082619 139.74249071009686 43.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-08322fb9-4425-463e-9ae0-54a44e170d2c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-08322fb9-4425-463e-9ae0-54a44e170d2c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-08322fb9-4425-463e-9ae0-54a44e170d2c">
											<gml:posList>35.666969151704244 139.74242140023424 40.3 35.66697003742624 139.74242454728014 40.3 35.667004548097914 139.74244455627255 40.3 35.667007125173804 139.74244342668047 40.3 35.666969151704244 139.74242140023424 40.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-316bc927-23e4-42c0-ad45-30ba3ce44487">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-316bc927-23e4-42c0-ad45-30ba3ce44487">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-316bc927-23e4-42c0-ad45-30ba3ce44487">
											<gml:posList>35.66698926355561 139.74248404021347 40.3 35.6669910220243 139.7424850875715 40.3 35.66699010923769 139.74248190741736 40.3 35.66698926355561 139.74248404021347 40.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-cf6b0873-282b-4a76-9353-9f365b50581d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cf6b0873-282b-4a76-9353-9f365b50581d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cf6b0873-282b-4a76-9353-9f365b50581d">
											<gml:posList>35.667007125173804 139.74244342668047 40.3 35.667004548097914 139.74244455627255 40.3 35.66699010923769 139.74248190741736 40.3 35.6669910220243 139.7424850875715 40.3 35.667007125173804 139.74244342668047 40.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-64fb759f-3d28-4149-a715-ddcfbca69d41">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-64fb759f-3d28-4149-a715-ddcfbca69d41">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-64fb759f-3d28-4149-a715-ddcfbca69d41">
											<gml:posList>35.66694753074344 139.74246118957907 43.4 35.66694753074344 139.74246118957907 42.73 35.666998643491226 139.74249152968036 42.73 35.666998643491226 139.74249152968036 43.4 35.66694753074344 139.74246118957907 43.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-fb109f39-7526-4a31-9e24-0333a2197680">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fb109f39-7526-4a31-9e24-0333a2197680">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fb109f39-7526-4a31-9e24-0333a2197680">
											<gml:posList>35.66684272994986 139.74240402496827 33.33 35.66684272994986 139.74240402496827 40.3 35.66685420138158 139.74237611033536 40.3 35.66685420138158 139.74237611033536 36.9 35.666861300179775 139.74235884878283 36.9 35.666861300179775 139.74235884878283 33.33 35.66684272994986 139.74240402496827 33.33</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-dfcf5ddc-d2f2-4136-b4b2-9d5e1e9d74cf">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-dfcf5ddc-d2f2-4136-b4b2-9d5e1e9d74cf">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-dfcf5ddc-d2f2-4136-b4b2-9d5e1e9d74cf">
											<gml:posList>35.667007125173804 139.74244342668047 27.91 35.666825418797096 139.74233803507718 27.91 35.666825418797096 139.74233803507718 33.33 35.666861300179775 139.74235884878283 33.33 35.666861300179775 139.74235884878283 36.9 35.666969151704244 139.74242140023424 36.9 35.666969151704244 139.74242140023424 40.3 35.667007125173804 139.74244342668047 40.3 35.667007125173804 139.74244342668047 27.91</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-335163ec-91f0-4670-b137-53b251c6ab49">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-335163ec-91f0-4670-b137-53b251c6ab49">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-335163ec-91f0-4670-b137-53b251c6ab49">
											<gml:posList>35.666825418797096 139.74233803507718 27.91 35.6667844864152 139.74244412086333 27.91 35.6667844864152 139.74244412086333 33.33 35.666825418797096 139.74233803507718 33.33 35.666825418797096 139.74233803507718 27.91</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-79bdfc4f-0ef3-463e-a07c-d2ada1618933">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-79bdfc4f-0ef3-463e-a07c-d2ada1618933">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-79bdfc4f-0ef3-463e-a07c-d2ada1618933">
											<gml:posList>35.66684534314709 139.7424029837024 40.3 35.66684534314709 139.7424029837024 39.204 35.66685506911905 139.74237931262556 39.204 35.66685506911905 139.74237931262556 40.3 35.66684534314709 139.7424029837024 40.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-da30a88f-169a-4180-90fb-bb0d510f195d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-da30a88f-169a-4180-90fb-bb0d510f195d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-da30a88f-169a-4180-90fb-bb0d510f195d">
											<gml:posList>35.66684447040852 139.74240509443462 40.3 35.66684447040852 139.74240509443462 39.204 35.66684534314709 139.7424029837024 39.204 35.66684534314709 139.7424029837024 40.3 35.66684447040852 139.74240509443462 40.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-141c8aed-bdc9-4d78-ae9a-13607c678e55">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-141c8aed-bdc9-4d78-ae9a-13607c678e55">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-141c8aed-bdc9-4d78-ae9a-13607c678e55">
											<gml:posList>35.66685420138158 139.74237611033536 40.3 35.666960748324506 139.7424418665619 40.3 35.666960748324506 139.7424418665619 36.9 35.66685420138158 139.74237611033536 36.9 35.66685420138158 139.74237611033536 40.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c30d40d6-90b8-4327-989c-f6c2a0414ca7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c30d40d6-90b8-4327-989c-f6c2a0414ca7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c30d40d6-90b8-4327-989c-f6c2a0414ca7">
											<gml:posList>35.66685506911905 139.74237931262556 40.3 35.66685506911905 139.74237931262556 39.204 35.66696160703814 139.7424450578215 39.204 35.66696160703814 139.7424450578215 40.3 35.66685506911905 139.74237931262556 40.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3a105de7-01a9-4ba6-b6b4-4504507b2f6b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3a105de7-01a9-4ba6-b6b4-4504507b2f6b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3a105de7-01a9-4ba6-b6b4-4504507b2f6b">
											<gml:posList>35.66682465688354 139.74245108939593 43.4 35.66684272994986 139.74240402496827 43.4 35.66684272994986 139.74240402496827 40.3 35.66684272994986 139.74240402496827 33.33 35.66682465688354 139.74245108939593 33.33 35.66682465688354 139.74245108939593 43.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-02a5b328-c207-4b59-8ad7-fcd732239945">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-02a5b328-c207-4b59-8ad7-fcd732239945">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-02a5b328-c207-4b59-8ad7-fcd732239945">
											<gml:posList>35.66682598247685 139.74245185005168 43.4 35.66682598247685 139.74245185005168 42.73 35.66684341681984 139.74240644321355 42.73 35.66684341681984 139.74240644321355 43.4 35.66682598247685 139.74245185005168 43.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-42f0c4ff-193b-4e08-a7de-fcde792dedcf">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-42f0c4ff-193b-4e08-a7de-fcde792dedcf">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-42f0c4ff-193b-4e08-a7de-fcde792dedcf">
											<gml:posList>35.666960748324506 139.7424418665619 40.3 35.666969151704244 139.74242140023424 40.3 35.666969151704244 139.74242140023424 36.9 35.666960748324506 139.7424418665619 36.9 35.666960748324506 139.7424418665619 40.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a6dfc3a2-ba93-4579-96ce-3a436c026dfa">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a6dfc3a2-ba93-4579-96ce-3a436c026dfa">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a6dfc3a2-ba93-4579-96ce-3a436c026dfa">
											<gml:posList>35.66697003742624 139.74242454728014 40.3 35.66697003742624 139.74242454728014 39.204 35.667004548097914 139.74244455627255 39.204 35.667004548097914 139.74244455627255 40.3 35.66697003742624 139.74242454728014 40.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3026f4a2-7f1d-4303-9f6b-291923b72911">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3026f4a2-7f1d-4303-9f6b-291923b72911">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3026f4a2-7f1d-4303-9f6b-291923b72911">
											<gml:posList>35.66696160703814 139.7424450578215 40.3 35.66696160703814 139.7424450578215 39.204 35.66697003742624 139.74242454728014 39.204 35.66697003742624 139.74242454728014 40.3 35.66696160703814 139.7424450578215 40.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-261bdf31-ad60-4401-8483-060d9bbb806c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-261bdf31-ad60-4401-8483-060d9bbb806c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-261bdf31-ad60-4401-8483-060d9bbb806c">
											<gml:posList>35.66684447040852 139.74240509443462 40.3 35.66684272994986 139.74240402496827 40.3 35.66684272994986 139.74240402496827 43.4 35.666943766914265 139.74246637431816 43.4 35.666943766914265 139.74246637431816 39.204 35.66684447040852 139.74240509443462 39.204 35.66684447040852 139.74240509443462 40.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3487ca39-caf5-493c-b1c9-28f7745853b6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3487ca39-caf5-493c-b1c9-28f7745853b6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3487ca39-caf5-493c-b1c9-28f7745853b6">
											<gml:posList>35.66684341681984 139.74240644321355 43.4 35.66684341681984 139.74240644321355 42.73 35.666944408697674 139.74246877052653 42.73 35.666944408697674 139.74246877052653 43.4 35.66684341681984 139.74240644321355 43.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-371b11ea-4a45-4955-97ae-bf5836850875">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-371b11ea-4a45-4955-97ae-bf5836850875">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-371b11ea-4a45-4955-97ae-bf5836850875">
											<gml:posList>35.66679957876612 139.74243662577305 45.8 35.66682465688354 139.74245108939593 45.8 35.66682465688354 139.74245108939593 43.4 35.66682465688354 139.74245108939593 33.33 35.66679957876612 139.74243662577305 33.33 35.66679957876612 139.74243662577305 45.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4fa8cc32-9e78-4a58-9fa6-69aed6254a3d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4fa8cc32-9e78-4a58-9fa6-69aed6254a3d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4fa8cc32-9e78-4a58-9fa6-69aed6254a3d">
											<gml:posList>35.6667844864152 139.74244412086333 27.91 35.666794495989095 139.74244985331612 27.91 35.666794495989095 139.74244985331612 33.33 35.6667844864152 139.74244412086333 33.33 35.6667844864152 139.74244412086333 27.91</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4c53d7e6-26da-44cb-a210-78c62945f2d2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4c53d7e6-26da-44cb-a210-78c62945f2d2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4c53d7e6-26da-44cb-a210-78c62945f2d2">
											<gml:posList>35.666825397726576 139.7424533639849 43.4 35.666825397726576 139.7424533639849 42.73 35.66682598247685 139.74245185005168 42.73 35.66682598247685 139.74245185005168 43.4 35.666825397726576 139.7424533639849 43.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-06186d0f-ce1d-4306-ab14-e3f48039d381">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-06186d0f-ce1d-4306-ab14-e3f48039d381">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-06186d0f-ce1d-4306-ab14-e3f48039d381">
											<gml:posList>35.666824072133274 139.74245260332913 43.4 35.666824072133274 139.74245260332913 42.73 35.666825397726576 139.7424533639849 42.73 35.666825397726576 139.7424533639849 43.4 35.666824072133274 139.74245260332913 43.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-50f9daf4-108d-4e70-bfd4-5d0aeaa5f4c8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-50f9daf4-108d-4e70-bfd4-5d0aeaa5f4c8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-50f9daf4-108d-4e70-bfd4-5d0aeaa5f4c8">
											<gml:posList>35.666943766914265 139.74246637431816 43.4 35.66694687996283 139.74245881547242 43.4 35.66694687996283 139.74245881547242 39.204 35.666943766914265 139.74246637431816 39.204 35.666943766914265 139.74246637431816 43.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9d52823e-9b8a-4622-a038-130165197f7c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9d52823e-9b8a-4622-a038-130165197f7c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9d52823e-9b8a-4622-a038-130165197f7c">
											<gml:posList>35.66679957876612 139.74243662577305 45.8 35.66679957876612 139.74243662577305 33.33 35.666794495989095 139.74244985331612 33.33 35.666794495989095 139.74244985331612 27.91 35.666779472567505 139.7424889723465 27.91 35.666779472567505 139.7424889723465 45.8 35.66679957876612 139.74243662577305 45.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f384695a-f3b8-4f0e-a412-ffef26304ba2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f384695a-f3b8-4f0e-a412-ffef26304ba2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f384695a-f3b8-4f0e-a412-ffef26304ba2">
											<gml:posList>35.667004548097914 139.74244455627255 40.3 35.667004548097914 139.74244455627255 39.204 35.66699010923769 139.74248190741736 39.204 35.66699010923769 139.74248190741736 40.3 35.667004548097914 139.74244455627255 40.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-25a30b0f-ebc7-483e-8400-89e2977a2ed8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-25a30b0f-ebc7-483e-8400-89e2977a2ed8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-25a30b0f-ebc7-483e-8400-89e2977a2ed8">
											<gml:posList>35.6669910220243 139.7424850875715 27.91 35.667007125173804 139.74244342668047 27.91 35.667007125173804 139.74244342668047 40.3 35.6669910220243 139.7424850875715 40.3 35.6669910220243 139.7424850875715 27.91</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b2f4e00d-45b0-4f56-9bcb-95bdafb59a68">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b2f4e00d-45b0-4f56-9bcb-95bdafb59a68">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b2f4e00d-45b0-4f56-9bcb-95bdafb59a68">
											<gml:posList>35.666944408697674 139.74246877052653 43.4 35.666944408697674 139.74246877052653 42.73 35.66694753074344 139.74246118957907 42.73 35.66694753074344 139.74246118957907 43.4 35.666944408697674 139.74246877052653 43.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0389c0d2-3852-448c-a5f1-60448d49ed96">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0389c0d2-3852-448c-a5f1-60448d49ed96">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0389c0d2-3852-448c-a5f1-60448d49ed96">
											<gml:posList>35.66700058082619 139.74249071009686 43.4 35.66700058082619 139.74249071009686 27.91 35.6669910220243 139.7424850875715 27.91 35.6669910220243 139.7424850875715 40.3 35.66698926355561 139.74248404021347 40.3 35.66698926355561 139.74248404021347 39.204 35.66694687996283 139.74245881547242 39.204 35.66694687996283 139.74245881547242 43.4 35.66700058082619 139.74249071009686 43.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-91829bb0-0e87-4428-860e-35bd2ea4163a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-91829bb0-0e87-4428-860e-35bd2ea4163a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-91829bb0-0e87-4428-860e-35bd2ea4163a">
											<gml:posList>35.66680506324484 139.74250182271956 43.4 35.66680506324484 139.74250182271956 42.73 35.666824072133274 139.74245260332913 42.73 35.666824072133274 139.74245260332913 43.4 35.66682465688354 139.74245108939593 43.4 35.66682465688354 139.74245108939593 45.8 35.6668044335086 139.74250344716063 45.8 35.6668044335086 139.74250344716063 43.4 35.66680506324484 139.74250182271956 43.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-50e28a2e-b9e8-4a16-bebe-27ce2bea2219">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-50e28a2e-b9e8-4a16-bebe-27ce2bea2219">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-50e28a2e-b9e8-4a16-bebe-27ce2bea2219">
											<gml:posList>35.66699010923769 139.74248190741736 40.3 35.66699010923769 139.74248190741736 39.204 35.66698926355561 139.74248404021347 39.204 35.66698926355561 139.74248404021347 40.3 35.66699010923769 139.74248190741736 40.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c81480be-18b6-44db-9845-37c998177437">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c81480be-18b6-44db-9845-37c998177437">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c81480be-18b6-44db-9845-37c998177437">
											<gml:posList>35.666806379824095 139.74250258338617 43.4 35.666806379824095 139.74250258338617 42.73 35.66680506324484 139.74250182271956 42.73 35.66680506324484 139.74250182271956 43.4 35.666806379824095 139.74250258338617 43.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-76104f0f-c9ca-47f7-b34a-9bfd19d09cc4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-76104f0f-c9ca-47f7-b34a-9bfd19d09cc4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-76104f0f-c9ca-47f7-b34a-9bfd19d09cc4">
											<gml:posList>35.66696063774051 139.74259403347054 27.91 35.66696063774051 139.74259403347054 43.4 35.6668044335086 139.74250344716063 43.4 35.6668044335086 139.74250344716063 45.8 35.666779472567505 139.7424889723465 45.8 35.666779472567505 139.7424889723465 27.91 35.66696063774051 139.74259403347054 27.91</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2a7eaa88-4824-4abd-a61d-801481c5b26c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2a7eaa88-4824-4abd-a61d-801481c5b26c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2a7eaa88-4824-4abd-a61d-801481c5b26c">
											<gml:posList>35.666998643491226 139.74249152968036 43.4 35.666998643491226 139.74249152968036 42.73 35.666959941885544 139.74259164836764 42.73 35.666959941885544 139.74259164836764 43.4 35.666998643491226 139.74249152968036 43.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-05e1f829-5f19-426b-aadd-5d64d67a968c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-05e1f829-5f19-426b-aadd-5d64d67a968c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-05e1f829-5f19-426b-aadd-5d64d67a968c">
											<gml:posList>35.66696063774051 139.74259403347054 27.91 35.66700058082619 139.74249071009686 27.91 35.66700058082619 139.74249071009686 43.4 35.66696063774051 139.74259403347054 43.4 35.66696063774051 139.74259403347054 27.91</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-35ccee33-d5d9-4f19-847e-21bcd751f3a8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-35ccee33-d5d9-4f19-847e-21bcd751f3a8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-35ccee33-d5d9-4f19-847e-21bcd751f3a8">
											<gml:posList>35.666959941885544 139.74259164836764 43.4 35.666959941885544 139.74259164836764 42.73 35.666806379824095 139.74250258338617 42.73 35.666806379824095 139.74250258338617 43.4 35.666959941885544 139.74259164836764 43.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂一丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-8279</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">331.3826</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">6</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">214</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1121</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.6</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>4</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.01</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>