<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_e902bf43-7d1a-4279-a568-c91530cb342e">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>29</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103029002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">412</bldg:usage>
			<bldg:measuredHeight uom="m">35.3</bldg:measuredHeight>
			<bldg:storeysAboveGround>14</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.667162404439814 139.73859546270785 0 35.667166095939955 139.7385902115837 0 35.66716232523843 139.73858644941564 0 35.6671655930669 139.7385811656542 0 35.66717298071529 139.7385880274231 0 35.667228430755095 139.73849329918508 0 35.66718215387565 139.7384470719382 0 35.6670286374495 139.73866021657184 0 35.6670850341832 139.7387376915404 0 35.667153718884464 139.73862306541477 0 35.66716369530309 139.73863225479633 0 35.667165064321125 139.73863089454412 0 35.66717818209159 139.73861151573257 0 35.667162404439814 139.73859546270785 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667162404439814 139.73859546270785 12.1 35.66717818209159 139.73861151573257 12.1 35.667165064321125 139.73863089454412 12.1 35.66716369530309 139.73863225479633 12.1 35.667153718884464 139.73862306541477 12.1 35.6670850341832 139.7387376915404 12.1 35.6670286374495 139.73866021657184 12.1 35.66718215387565 139.7384470719382 12.1 35.667228430755095 139.73849329918508 12.1 35.66717298071529 139.7385880274231 12.1 35.6671655930669 139.7385811656542 12.1 35.66716232523843 139.73858644941564 12.1 35.667166095939955 139.7385902115837 12.1 35.667162404439814 139.73859546270785 12.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667162404439814 139.73859546270785 12.1 35.667166095939955 139.7385902115837 12.1 35.667166095939955 139.7385902115837 45.2 35.667162404439814 139.73859546270785 45.2 35.667162404439814 139.73859546270785 12.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667166095939955 139.7385902115837 12.1 35.66716232523843 139.73858644941564 12.1 35.66716232523843 139.73858644941564 45.2 35.667166095939955 139.7385902115837 45.2 35.667166095939955 139.7385902115837 12.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66716232523843 139.73858644941564 12.1 35.6671655930669 139.7385811656542 12.1 35.6671655930669 139.7385811656542 45.2 35.66716232523843 139.73858644941564 45.2 35.66716232523843 139.73858644941564 12.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6671655930669 139.7385811656542 12.1 35.66717298071529 139.7385880274231 12.1 35.66717298071529 139.7385880274231 45.2 35.6671655930669 139.7385811656542 45.2 35.6671655930669 139.7385811656542 12.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66717298071529 139.7385880274231 12.1 35.667228430755095 139.73849329918508 12.1 35.667228430755095 139.73849329918508 45.2 35.66717298071529 139.7385880274231 45.2 35.66717298071529 139.7385880274231 12.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667228430755095 139.73849329918508 12.1 35.66718215387565 139.7384470719382 12.1 35.66718215387565 139.7384470719382 45.2 35.667228430755095 139.73849329918508 45.2 35.667228430755095 139.73849329918508 12.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66718215387565 139.7384470719382 12.1 35.6670286374495 139.73866021657184 12.1 35.6670286374495 139.73866021657184 45.2 35.66718215387565 139.7384470719382 45.2 35.66718215387565 139.7384470719382 12.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6670286374495 139.73866021657184 12.1 35.6670850341832 139.7387376915404 12.1 35.6670850341832 139.7387376915404 45.2 35.6670286374495 139.73866021657184 45.2 35.6670286374495 139.73866021657184 12.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6670850341832 139.7387376915404 12.1 35.667153718884464 139.73862306541477 12.1 35.667153718884464 139.73862306541477 45.2 35.6670850341832 139.7387376915404 45.2 35.6670850341832 139.7387376915404 12.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667153718884464 139.73862306541477 12.1 35.66716369530309 139.73863225479633 12.1 35.66716369530309 139.73863225479633 45.2 35.667153718884464 139.73862306541477 45.2 35.667153718884464 139.73862306541477 12.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66716369530309 139.73863225479633 12.1 35.667165064321125 139.73863089454412 12.1 35.667165064321125 139.73863089454412 45.2 35.66716369530309 139.73863225479633 45.2 35.66716369530309 139.73863225479633 12.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667165064321125 139.73863089454412 12.1 35.66717818209159 139.73861151573257 12.1 35.66717818209159 139.73861151573257 45.2 35.667165064321125 139.73863089454412 45.2 35.667165064321125 139.73863089454412 12.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66717818209159 139.73861151573257 12.1 35.667162404439814 139.73859546270785 12.1 35.667162404439814 139.73859546270785 45.2 35.66717818209159 139.73861151573257 45.2 35.66717818209159 139.73861151573257 12.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667162404439814 139.73859546270785 45.2 35.667166095939955 139.7385902115837 45.2 35.66716232523843 139.73858644941564 45.2 35.6671655930669 139.7385811656542 45.2 35.66717298071529 139.7385880274231 45.2 35.667228430755095 139.73849329918508 45.2 35.66718215387565 139.7384470719382 45.2 35.6670286374495 139.73866021657184 45.2 35.6670850341832 139.7387376915404 45.2 35.667153718884464 139.73862306541477 45.2 35.66716369530309 139.73863225479633 45.2 35.667165064321125 139.73863089454412 45.2 35.66717818209159 139.73861151573257 45.2 35.667162404439814 139.73859546270785 45.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-3e21fa60-e419-4c7b-87d4-22faec40979c"/>
							<gml:surfaceMember xlink:href="#poly-56086be8-d7a1-44cd-b889-00c7b9bf2651"/>
							<gml:surfaceMember xlink:href="#poly-261d8fc2-d30c-4bd3-96cc-277d5534495b"/>
							<gml:surfaceMember xlink:href="#poly-8af0f85a-40b3-4e8d-9b4c-92cdef6bf52c"/>
							<gml:surfaceMember xlink:href="#poly-7e26a36d-6ef2-44b2-b510-244a5847eeee"/>
							<gml:surfaceMember xlink:href="#poly-6fe0c58e-f07d-48a5-8bde-e151e509f003"/>
							<gml:surfaceMember xlink:href="#poly-c63035c6-4045-47a5-bf03-bc5e736f6ef6"/>
							<gml:surfaceMember xlink:href="#poly-ec0695a5-14a5-47d8-984c-f92cc4a0f68d"/>
							<gml:surfaceMember xlink:href="#poly-dea4738a-1399-4c90-8e81-13ea8ab33ba1"/>
							<gml:surfaceMember xlink:href="#poly-a34dfab5-824e-4cc6-8f41-8aae01b494aa"/>
							<gml:surfaceMember xlink:href="#poly-fb42e7cc-cc4f-44f9-8ac7-d6daa7e2041c"/>
							<gml:surfaceMember xlink:href="#poly-76ab2b34-6290-4f22-be5c-826bddc1cfb3"/>
							<gml:surfaceMember xlink:href="#poly-06962ee8-91f5-496d-8ff8-46f5ade2dd07"/>
							<gml:surfaceMember xlink:href="#poly-3d54cfd7-1866-4666-985d-9b902f5c73d3"/>
							<gml:surfaceMember xlink:href="#poly-1d750ffa-d788-4626-a5e8-5350e49b86fc"/>
							<gml:surfaceMember xlink:href="#poly-242016e5-7f7a-4245-bf80-4e2070ca553f"/>
							<gml:surfaceMember xlink:href="#poly-f09620f8-0e1a-4daf-b5c7-e38853a13486"/>
							<gml:surfaceMember xlink:href="#poly-ed6adc98-6b2d-400d-b6c3-1298eaa176dd"/>
							<gml:surfaceMember xlink:href="#poly-8e02b5d6-f179-4dd0-8e26-6ebe3c2f287e"/>
							<gml:surfaceMember xlink:href="#poly-d1c13474-19f6-4a21-805a-1a334221ce72"/>
							<gml:surfaceMember xlink:href="#poly-79c3e6b3-898d-4926-b856-d87630b30e5b"/>
							<gml:surfaceMember xlink:href="#poly-201376df-b762-4252-950b-ed34e23ce7e0"/>
							<gml:surfaceMember xlink:href="#poly-6994835e-bafd-4029-89a4-89ec9e0d4c07"/>
							<gml:surfaceMember xlink:href="#poly-c4e89d55-54fb-4e95-b7c9-eaebd23ac03f"/>
							<gml:surfaceMember xlink:href="#poly-c001bd25-9939-498a-b871-61beef2e2d05"/>
							<gml:surfaceMember xlink:href="#poly-fdf0b9f9-8dad-4b33-b9e4-eedf60f29b99"/>
							<gml:surfaceMember xlink:href="#poly-5c3e489a-a888-4101-8a70-5891c02d7632"/>
							<gml:surfaceMember xlink:href="#poly-cac8744e-2c41-4e50-aa25-d4a72ba9a5bb"/>
							<gml:surfaceMember xlink:href="#poly-4a403ab6-267e-4754-b7ea-88bce4bdc8cf"/>
							<gml:surfaceMember xlink:href="#poly-83a1a3e2-6cc1-474b-bda4-6f29692a4f8f"/>
							<gml:surfaceMember xlink:href="#poly-bb3933df-00c9-47af-9144-52202f80c5ca"/>
							<gml:surfaceMember xlink:href="#poly-4e7fed4b-c87c-4e2c-9871-b8be11633e48"/>
							<gml:surfaceMember xlink:href="#poly-de590ba5-9365-4a27-a583-6023efc914fd"/>
							<gml:surfaceMember xlink:href="#poly-942e2f1c-d6d9-4cc3-8024-1763e371db68"/>
							<gml:surfaceMember xlink:href="#poly-0f2aa316-87f8-4742-928d-402662aa1d0d"/>
							<gml:surfaceMember xlink:href="#poly-78a96059-8fc7-4d42-b5ff-c72a9dac4291"/>
							<gml:surfaceMember xlink:href="#poly-76ce0f31-e3f6-4d77-b69f-122aec4ef44a"/>
							<gml:surfaceMember xlink:href="#poly-33d678e9-1c55-45b2-a989-6c9ec874b63c"/>
							<gml:surfaceMember xlink:href="#poly-8530f837-0adf-4698-99b2-77a57a2d97d5"/>
							<gml:surfaceMember xlink:href="#poly-6dbc5b79-649d-4ea2-9d00-2c8df75dc134"/>
							<gml:surfaceMember xlink:href="#poly-b32aeaaf-cd13-4d3e-9ba3-68420d931271"/>
							<gml:surfaceMember xlink:href="#poly-b630a269-a698-49cd-b562-3ea1e7845f92"/>
							<gml:surfaceMember xlink:href="#poly-8a5aa826-4b58-4eee-83ed-f8af3a5d9fcc"/>
							<gml:surfaceMember xlink:href="#poly-1ed8f3cd-2055-4afb-ad56-ccd498f82cf2"/>
							<gml:surfaceMember xlink:href="#poly-7ec83b3a-ad5d-46c8-a0fb-3ca325b66a39"/>
							<gml:surfaceMember xlink:href="#poly-a5c52a6f-c787-4d6c-84df-6593907a8449"/>
							<gml:surfaceMember xlink:href="#poly-ab1c04fc-9cf5-4154-9854-7eb40fc5dd14"/>
							<gml:surfaceMember xlink:href="#poly-aafd9560-60b0-4108-8705-b9d0cc080850"/>
							<gml:surfaceMember xlink:href="#poly-dab73ef0-7c39-4ad1-b0fe-bb57a387687d"/>
							<gml:surfaceMember xlink:href="#poly-f9722c3b-3096-471c-a764-78cb714d9966"/>
							<gml:surfaceMember xlink:href="#poly-9587a7de-e49e-448a-a3c1-6199d5cf3401"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_e902bf43-7d1a-4279-a568-c91530cb342e_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1d81c647-b4a7-432c-bd87-c4c85840b19b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1d81c647-b4a7-432c-bd87-c4c85840b19b_0">
											<gml:posList>35.66710789619873 139.73859268833436 59.542 35.66705339844475 139.73867201739063 57.541 35.66710789619873 139.73859268833436 57.541 35.66710789619873 139.73859268833436 59.542</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cab06964-0ec0-4994-9ca5-eb1254e51eb4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cab06964-0ec0-4994-9ca5-eb1254e51eb4_0">
											<gml:posList>35.66710789619873 139.73859268833436 59.542 35.66705339844475 139.73867201739063 59.542 35.66705339844475 139.73867201739063 57.541 35.66710789619873 139.73859268833436 59.542</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d7a7d059-2b29-4da3-b2d8-50285fa5ddde">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d7a7d059-2b29-4da3-b2d8-50285fa5ddde_0">
											<gml:posList>35.66707474224425 139.738694028573 59.542 35.667129230998796 139.73861469952115 57.541 35.66707474224425 139.738694028573 57.541 35.66707474224425 139.738694028573 59.542</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3c57d301-452f-4ff8-8ff0-11fae9745c87">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3c57d301-452f-4ff8-8ff0-11fae9745c87_0">
											<gml:posList>35.66707474224425 139.738694028573 59.542 35.667129230998796 139.73861469952115 59.542 35.667129230998796 139.73861469952115 57.541 35.66707474224425 139.738694028573 59.542</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2fbe6379-65b3-48b0-b0ac-71fa4fbe13ed">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2fbe6379-65b3-48b0-b0ac-71fa4fbe13ed_0">
											<gml:posList>35.66714145403542 139.73855794274127 50.232 35.667134959022505 139.73855143338872 51.932 35.66714145403542 139.73855794274127 51.932 35.66714145403542 139.73855794274127 50.232</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a81b5a6d-81cb-4cc8-b8b4-2b452df4ca63">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a81b5a6d-81cb-4cc8-b8b4-2b452df4ca63_0">
											<gml:posList>35.66714145403542 139.73855794274127 50.232 35.667134959022505 139.73855143338872 50.232 35.667134959022505 139.73855143338872 51.932 35.66714145403542 139.73855794274127 50.232</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bbc79ab6-40bd-4f2d-8097-905fcb2b182a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bbc79ab6-40bd-4f2d-8097-905fcb2b182a_0">
											<gml:posList>35.66712970119593 139.7385593042213 50.232 35.667134959022505 139.73855143338872 51.932 35.667134959022505 139.73855143338872 50.232 35.66712970119593 139.7385593042213 50.232</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-70a97329-19cc-4f4a-8dde-4c2d9951a7ec">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-70a97329-19cc-4f4a-8dde-4c2d9951a7ec_0">
											<gml:posList>35.66712970119593 139.7385593042213 50.232 35.66712970119593 139.7385593042213 51.932 35.667134959022505 139.73855143338872 51.932 35.66712970119593 139.7385593042213 50.232</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5fa47488-0b9a-415b-b00a-58041fa7a59e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5fa47488-0b9a-415b-b00a-58041fa7a59e_0">
											<gml:posList>35.667134959022505 139.73855143338872 51.932 35.66712970119593 139.7385593042213 51.932 35.667136196208446 139.73856581357404 51.932 35.667134959022505 139.73855143338872 51.932</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d3ea0989-5318-44fe-8d5e-9373abb2f324">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d3ea0989-5318-44fe-8d5e-9373abb2f324_0">
											<gml:posList>35.66714145403542 139.73855794274127 51.932 35.667134959022505 139.73855143338872 51.932 35.667136196208446 139.73856581357404 51.932 35.66714145403542 139.73855794274127 51.932</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6397d46c-ff52-4c15-aa04-d6c7c317d205">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6397d46c-ff52-4c15-aa04-d6c7c317d205_0">
											<gml:posList>35.66714145403542 139.73855794274127 50.232 35.667136196208446 139.73856581357404 51.932 35.667136196208446 139.73856581357404 50.232 35.66714145403542 139.73855794274127 50.232</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-47d2e32d-119f-472c-a4cb-55aacc709d0d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-47d2e32d-119f-472c-a4cb-55aacc709d0d_0">
											<gml:posList>35.66714145403542 139.73855794274127 50.232 35.66714145403542 139.73855794274127 51.932 35.667136196208446 139.73856581357404 51.932 35.66714145403542 139.73855794274127 50.232</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1ae1a628-8cb6-4e53-b11a-7b292e5a0e46">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1ae1a628-8cb6-4e53-b11a-7b292e5a0e46_0">
											<gml:posList>35.66712970119593 139.7385593042213 50.232 35.667136196208446 139.73856581357404 51.932 35.66712970119593 139.7385593042213 51.932 35.66712970119593 139.7385593042213 50.232</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a094138f-11e1-4a02-99f8-37d24d80f50e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a094138f-11e1-4a02-99f8-37d24d80f50e_0">
											<gml:posList>35.66712970119593 139.7385593042213 50.232 35.667136196208446 139.73856581357404 50.232 35.667136196208446 139.73856581357404 51.932 35.66712970119593 139.7385593042213 50.232</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-07404297-f338-4045-9048-0d43afd028f7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-07404297-f338-4045-9048-0d43afd028f7_0">
											<gml:posList>35.66710757717248 139.73858818202143 50.232 35.66713289928163 139.7386143085847 59.542 35.66713289928163 139.7386143085847 50.232 35.66710757717248 139.73858818202143 50.232</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b6cde730-1f45-48cd-ab82-366ca82eb2d1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b6cde730-1f45-48cd-ab82-366ca82eb2d1_0">
											<gml:posList>35.66710757717248 139.73858818202143 50.232 35.66710757717248 139.73858818202143 59.542 35.66713289928163 139.7386143085847 59.542 35.66710757717248 139.73858818202143 50.232</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2fd4b04f-bb69-4e10-b8d7-87b707a50233">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2fd4b04f-bb69-4e10-b8d7-87b707a50233_0">
											<gml:posList>35.66716240443981 139.73859546270785 47.807 35.66717818209158 139.73861151573257 47.055 35.66716240443981 139.73859546270785 47.055 35.66716240443981 139.73859546270785 47.807</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0f86429b-f7fe-4218-9be3-0d0084988d5f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0f86429b-f7fe-4218-9be3-0d0084988d5f_0">
											<gml:posList>35.66716240443981 139.73859546270785 47.807 35.66717818209158 139.73861151573257 47.807 35.66717818209158 139.73861151573257 47.055 35.66716240443981 139.73859546270785 47.807</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d11fa292-2e56-479e-8345-b90d99aca242">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d11fa292-2e56-479e-8345-b90d99aca242_0">
											<gml:posList>35.667129230998796 139.73861469952115 59.542 35.66710789619873 139.73859268833436 57.541 35.667129230998796 139.73861469952115 57.541 35.667129230998796 139.73861469952115 59.542</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2cf55138-e3a4-49b0-a6aa-c8ad68f4ba5b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2cf55138-e3a4-49b0-a6aa-c8ad68f4ba5b_0">
											<gml:posList>35.667129230998796 139.73861469952115 59.542 35.66710789619873 139.73859268833436 59.542 35.66710789619873 139.73859268833436 57.541 35.667129230998796 139.73861469952115 59.542</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4eab21b6-e2bb-46a8-9940-d900f8ed53b3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4eab21b6-e2bb-46a8-9940-d900f8ed53b3_0">
											<gml:posList>35.667149277658154 139.73861484152883 47.055 35.66716240443981 139.73859546270785 47.807 35.66716240443981 139.73859546270785 47.055 35.667149277658154 139.73861484152883 47.055</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d8068c41-acc5-42f6-81e3-257d5e834927">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d8068c41-acc5-42f6-81e3-257d5e834927_0">
											<gml:posList>35.667149277658154 139.73861484152883 47.055 35.667149277658154 139.73861484152883 47.807 35.66716240443981 139.73859546270785 47.807 35.667149277658154 139.73861484152883 47.055</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4deb00f8-869b-4711-a628-79aa7a3eb68b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4deb00f8-869b-4711-a628-79aa7a3eb68b_0">
											<gml:posList>35.66717818209158 139.73861151573257 47.807 35.66716240443981 139.73859546270785 47.807 35.667149277658154 139.73861484152883 47.807 35.66717818209158 139.73861151573257 47.807</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-14ff8276-0a55-488c-870b-34f2ba2092e7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-14ff8276-0a55-488c-870b-34f2ba2092e7_0">
											<gml:posList>35.66716506432111 139.73863089454412 47.807 35.66717818209158 139.73861151573257 47.807 35.667149277658154 139.73861484152883 47.807 35.66716506432111 139.73863089454412 47.807</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a9b972c3-ce3e-4817-a044-b561c649e314">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a9b972c3-ce3e-4817-a044-b561c649e314_0">
											<gml:posList>35.66716506432111 139.73863089454412 47.055 35.66717818209158 139.73861151573257 47.807 35.66716506432111 139.73863089454412 47.807 35.66716506432111 139.73863089454412 47.055</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b797e47f-dd05-441c-a334-79993f0739d6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b797e47f-dd05-441c-a334-79993f0739d6_0">
											<gml:posList>35.66716506432111 139.73863089454412 47.055 35.66717818209158 139.73861151573257 47.055 35.66717818209158 139.73861151573257 47.807 35.66716506432111 139.73863089454412 47.055</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b12b9992-73ed-463e-a43a-28b99b03f902">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b12b9992-73ed-463e-a43a-28b99b03f902_0">
											<gml:posList>35.66716506432111 139.73863089454412 47.055 35.667149277658154 139.73861484152883 47.807 35.667149277658154 139.73861484152883 47.055 35.66716506432111 139.73863089454412 47.055</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bbae97ab-7f87-4cd4-b776-d042a81c4fb2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bbae97ab-7f87-4cd4-b776-d042a81c4fb2_0">
											<gml:posList>35.66716506432111 139.73863089454412 47.055 35.66716506432111 139.73863089454412 47.807 35.667149277658154 139.73861484152883 47.807 35.66716506432111 139.73863089454412 47.055</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1c2daf0f-c7a8-495b-a8b7-522d623444d7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1c2daf0f-c7a8-495b-a8b7-522d623444d7_0">
											<gml:posList>35.66710757717248 139.73858818202143 50.232 35.66704973016168 139.73867240832405 59.542 35.66710757717248 139.73858818202143 59.542 35.66710757717248 139.73858818202143 50.232</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d99b08ab-dd54-4d7c-8e4a-21466944ee56">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d99b08ab-dd54-4d7c-8e4a-21466944ee56_0">
											<gml:posList>35.66710757717248 139.73858818202143 50.232 35.66704973016168 139.73867240832405 50.232 35.66704973016168 139.73867240832405 59.542 35.66710757717248 139.73858818202143 50.232</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ff0cb75f-5c70-4466-93a9-57a245e8b0ab">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ff0cb75f-5c70-4466-93a9-57a245e8b0ab_0">
											<gml:posList>35.66707474224425 139.738694028573 59.542 35.66707505224413 139.73869852384934 59.542 35.66713289928163 139.7386143085847 59.542 35.66707474224425 139.738694028573 59.542</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0b3a94ee-8499-4959-b80c-11bbc79395eb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0b3a94ee-8499-4959-b80c-11bbc79395eb_0">
											<gml:posList>35.66713289928163 139.7386143085847 59.542 35.66710757717248 139.73858818202143 59.542 35.66710789619873 139.73859268833436 59.542 35.66713289928163 139.7386143085847 59.542</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-964e835d-dd75-4cda-b9bf-37eb6b2c908b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-964e835d-dd75-4cda-b9bf-37eb6b2c908b_0">
											<gml:posList>35.66707505224413 139.73869852384934 59.542 35.66705339844475 139.73867201739063 59.542 35.66704973016168 139.73867240832405 59.542 35.66707505224413 139.73869852384934 59.542</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-91cc648a-7669-4fb8-93c8-bf2ba978c629">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-91cc648a-7669-4fb8-93c8-bf2ba978c629_0">
											<gml:posList>35.66710757717248 139.73858818202143 59.542 35.66704973016168 139.73867240832405 59.542 35.66705339844475 139.73867201739063 59.542 35.66710757717248 139.73858818202143 59.542</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ce5d7e7e-832d-4d86-84f1-35891ae62699">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ce5d7e7e-832d-4d86-84f1-35891ae62699_0">
											<gml:posList>35.66707474224425 139.738694028573 59.542 35.66713289928163 139.7386143085847 59.542 35.667129230998796 139.73861469952115 59.542 35.66707474224425 139.738694028573 59.542</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-803b0980-5e7d-4fc5-b8f0-e63142c12113">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-803b0980-5e7d-4fc5-b8f0-e63142c12113_0">
											<gml:posList>35.66705339844475 139.73867201739063 59.542 35.66707505224413 139.73869852384934 59.542 35.66707474224425 139.738694028573 59.542 35.66705339844475 139.73867201739063 59.542</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c2718e1d-c782-4999-9c33-7129d50f9de7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c2718e1d-c782-4999-9c33-7129d50f9de7_0">
											<gml:posList>35.66710757717248 139.73858818202143 59.542 35.66705339844475 139.73867201739063 59.542 35.66710789619873 139.73859268833436 59.542 35.66710757717248 139.73858818202143 59.542</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-db349bdd-2f29-4bd5-80e5-0bb143d87c33">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-db349bdd-2f29-4bd5-80e5-0bb143d87c33_0">
											<gml:posList>35.667129230998796 139.73861469952115 59.542 35.66713289928163 139.7386143085847 59.542 35.66710789619873 139.73859268833436 59.542 35.667129230998796 139.73861469952115 59.542</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ca56a384-bbea-4037-b273-a2153cd46fa1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ca56a384-bbea-4037-b273-a2153cd46fa1_0">
											<gml:posList>35.66710789619873 139.73859268833436 57.541 35.66707474224425 139.738694028573 57.541 35.667129230998796 139.73861469952115 57.541 35.66710789619873 139.73859268833436 57.541</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9717747d-6dd8-43d1-b44f-0ee3d9649f48">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9717747d-6dd8-43d1-b44f-0ee3d9649f48_0">
											<gml:posList>35.66710789619873 139.73859268833436 57.541 35.66705339844475 139.73867201739063 57.541 35.66707474224425 139.738694028573 57.541 35.66710789619873 139.73859268833436 57.541</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1044f7b5-a222-4ce0-af0b-22d76e2abbbc">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1044f7b5-a222-4ce0-af0b-22d76e2abbbc_0">
											<gml:posList>35.66713289928163 139.7386143085847 50.232 35.66707505224413 139.73869852384934 59.542 35.66707505224413 139.73869852384934 50.232 35.66713289928163 139.7386143085847 50.232</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-73ebd99c-16f0-46cc-afe2-ca1b0ea924ed">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-73ebd99c-16f0-46cc-afe2-ca1b0ea924ed_0">
											<gml:posList>35.66713289928163 139.7386143085847 50.232 35.66713289928163 139.7386143085847 59.542 35.66707505224413 139.73869852384934 59.542 35.66713289928163 139.7386143085847 50.232</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-035a188f-af93-4946-bc47-5caef66f449f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-035a188f-af93-4946-bc47-5caef66f449f_0">
											<gml:posList>35.66705339844475 139.73867201739063 59.542 35.66707474224425 139.738694028573 57.541 35.66705339844475 139.73867201739063 57.541 35.66705339844475 139.73867201739063 59.542</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7b4002be-9708-4baa-951d-a397ea88e56f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7b4002be-9708-4baa-951d-a397ea88e56f_0">
											<gml:posList>35.66705339844475 139.73867201739063 59.542 35.66707474224425 139.738694028573 59.542 35.66707474224425 139.738694028573 57.541 35.66705339844475 139.73867201739063 59.542</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d3f58f6c-3989-4544-8195-17b3b76e1262">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d3f58f6c-3989-4544-8195-17b3b76e1262_0">
											<gml:posList>35.66704973016168 139.73867240832405 50.232 35.66707505224413 139.73869852384934 59.542 35.66704973016168 139.73867240832405 59.542 35.66704973016168 139.73867240832405 50.232</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d86a49b0-05ca-4881-8dd4-e25eb6675809">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d86a49b0-05ca-4881-8dd4-e25eb6675809_0">
											<gml:posList>35.66704973016168 139.73867240832405 50.232 35.66707505224413 139.73869852384934 50.232 35.66707505224413 139.73869852384934 59.542 35.66704973016168 139.73867240832405 50.232</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7745a283-28ef-4588-ae97-98367c5b1c97">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66713289928163 139.7386143085847 50.232 35.66704973016168 139.73867240832405 50.232 35.66710757717248 139.73858818202143 50.232 35.66713289928163 139.7386143085847 50.232</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f9d102ac-48ec-44a3-8c05-8c34fcebd6b0">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66713289928163 139.7386143085847 50.232 35.66707505224413 139.73869852384934 50.232 35.66704973016168 139.73867240832405 50.232 35.66713289928163 139.7386143085847 50.232</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ab4c8a04-5488-4085-a2c3-138e812828ad">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667134959022505 139.73855143338872 50.232 35.66714145403542 139.73855794274127 50.232 35.667136196208446 139.73856581357404 50.232 35.667134959022505 139.73855143338872 50.232</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-91390921-196d-484f-99fd-73a8c189d705">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66712970119593 139.7385593042213 50.232 35.667134959022505 139.73855143338872 50.232 35.667136196208446 139.73856581357404 50.232 35.66712970119593 139.7385593042213 50.232</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-daa9aeae-7d77-47fb-a1c5-d9733b39b1c2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66717818209158 139.73861151573257 47.055 35.66716506432111 139.73863089454412 47.055 35.667149277658154 139.73861484152883 47.055 35.66717818209158 139.73861151573257 47.055</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ebbc72a8-116c-4d74-85e4-bc96b28ed94b">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66716240443981 139.73859546270785 47.055 35.66717818209158 139.73861151573257 47.055 35.667149277658154 139.73861484152883 47.055 35.66716240443981 139.73859546270785 47.055</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_e902bf43-7d1a-4279-a568-c91530cb342e_BuildingInstallation_1061">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-007c6aef-a665-4a55-baef-4b56d734c1d8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66721542081412 139.73850078154894 22.064 35.667178794856525 139.7384624516919 22.064 35.667142033369004 139.73851526103454 22.064 35.667140418589824 139.7385135839804 22.064 35.66717850360632 139.7384588842372 22.064 35.667218223830915 139.73850045790508 22.064 35.667192338536466 139.7385375361988 22.064 35.667190742002454 139.73853613526708 22.064 35.66721542081412 139.73850078154894 22.064</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-33de8894-54e4-46c3-82b7-1cba14f001c6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-33de8894-54e4-46c3-82b7-1cba14f001c6_0">
											<gml:posList>35.66717850360632 139.7384588842372 22.064 35.66717850360632 139.7384588842372 23.48 35.667218223830915 139.73850045790508 23.48 35.667218223830915 139.73850045790508 22.064 35.66717850360632 139.7384588842372 22.064</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6b45d608-cd21-4215-b66d-46f3e872298c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6b45d608-cd21-4215-b66d-46f3e872298c_0">
											<gml:posList>35.66721542081412 139.73850078154894 23.48 35.667178794856525 139.7384624516919 23.48 35.667178794856525 139.7384624516919 22.064 35.66721542081412 139.73850078154894 22.064 35.66721542081412 139.73850078154894 23.48</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1fccaa60-fe92-4745-86b3-50aefb69f9a7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1fccaa60-fe92-4745-86b3-50aefb69f9a7_0">
											<gml:posList>35.667140418589824 139.7385135839804 22.064 35.667140418589824 139.7385135839804 23.48 35.66717850360632 139.7384588842372 23.48 35.66717850360632 139.7384588842372 22.064 35.667140418589824 139.7385135839804 22.064</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8d464030-c9dc-4373-ace5-011e52e3c23a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8d464030-c9dc-4373-ace5-011e52e3c23a_0">
											<gml:posList>35.667178794856525 139.7384624516919 23.48 35.667142033369004 139.73851526103454 23.48 35.667142033369004 139.73851526103454 22.064 35.667178794856525 139.7384624516919 22.064 35.667178794856525 139.7384624516919 23.48</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-986db786-81f8-4d72-b13c-28c6f6da1276">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-986db786-81f8-4d72-b13c-28c6f6da1276_0">
											<gml:posList>35.667192338536466 139.7385375361988 23.48 35.667218223830915 139.73850045790508 23.48 35.66717850360632 139.7384588842372 23.48 35.667140418589824 139.7385135839804 23.48 35.667142033369004 139.73851526103454 23.48 35.667178794856525 139.7384624516919 23.48 35.66721542081412 139.73850078154894 23.48 35.667190742002454 139.73853613526708 23.48 35.667192338536466 139.7385375361988 23.48</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-233a18fc-85aa-4657-a124-1812bb2490d3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-233a18fc-85aa-4657-a124-1812bb2490d3_0">
											<gml:posList>35.667142033369004 139.73851526103454 23.48 35.667140418589824 139.7385135839804 23.48 35.667140418589824 139.7385135839804 22.064 35.667142033369004 139.73851526103454 22.064 35.667142033369004 139.73851526103454 23.48</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-69f98c16-cff1-4fe4-8840-ca832e8c99d7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-69f98c16-cff1-4fe4-8840-ca832e8c99d7_0">
											<gml:posList>35.667190742002454 139.73853613526708 22.064 35.667190742002454 139.73853613526708 23.48 35.66721542081412 139.73850078154894 23.48 35.66721542081412 139.73850078154894 22.064 35.667190742002454 139.73853613526708 22.064</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-87bab2da-5368-4d16-a021-017345291969">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-87bab2da-5368-4d16-a021-017345291969_0">
											<gml:posList>35.667218223830915 139.73850045790508 23.48 35.667192338536466 139.7385375361988 23.48 35.667192338536466 139.7385375361988 22.064 35.667218223830915 139.73850045790508 22.064 35.667218223830915 139.73850045790508 23.48</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-86895456-5f16-4305-afcc-6c6997952226">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-86895456-5f16-4305-afcc-6c6997952226_0">
											<gml:posList>35.667190742002454 139.73853613526708 22.064 35.667192338536466 139.7385375361988 22.064 35.667192338536466 139.7385375361988 23.48 35.667190742002454 139.73853613526708 23.48 35.667190742002454 139.73853613526708 22.064</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_e902bf43-7d1a-4279-a568-c91530cb342e_BuildingInstallation_1060">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b49223e7-ca58-40d3-902e-fe3e889b76fd">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66717731607868 139.7386106330901 12.1 35.66716240443981 139.73859546270785 12.1 35.66716609593123 139.73859020053789 12.1 35.667165202877 139.7385893179277 12.1 35.66716232523843 139.73858644941564 12.1 35.667165593066905 139.7385811656542 12.1 35.66719228425592 139.73860600930163 12.1 35.667172751660694 139.73864060578452 12.1 35.66716369531178 139.73863226584214 12.1 35.66716506432111 139.73863089454412 12.1 35.66717818209158 139.73861151573257 12.1 35.66717731607868 139.7386106330901 12.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fe943dc7-ef8b-4d57-9661-4a838c1453eb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fe943dc7-ef8b-4d57-9661-4a838c1453eb_0">
											<gml:posList>35.667165593066905 139.7385811656542 12.1 35.66716232523843 139.73858644941564 12.1 35.66716232523843 139.73858644941564 45.289 35.667165593066905 139.7385811656542 45.289 35.667165593066905 139.7385811656542 12.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0b5566b9-b93e-4929-956b-df2e5405989a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0b5566b9-b93e-4929-956b-df2e5405989a_0">
											<gml:posList>35.667165202877 139.7385893179277 12.1 35.667165202877 139.7385893179277 45.289 35.66716232523843 139.73858644941564 45.289 35.66716232523843 139.73858644941564 12.1 35.667165202877 139.7385893179277 12.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-23108bb2-3ecb-440a-b9d8-0bbe1b200b85">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-23108bb2-3ecb-440a-b9d8-0bbe1b200b85_0">
											<gml:posList>35.667165202877 139.7385893179277 12.1 35.66716609593123 139.73859020053789 12.1 35.66716609593123 139.73859020053789 45.289 35.667165202877 139.7385893179277 45.289 35.667165202877 139.7385893179277 12.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-34de895a-735f-4ace-b2d2-0a18081f46d0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-34de895a-735f-4ace-b2d2-0a18081f46d0_0">
											<gml:posList>35.66716609593123 139.73859020053789 12.1 35.66716240443981 139.73859546270785 12.1 35.66716240443981 139.73859546270785 45.289 35.66716609593123 139.73859020053789 45.289 35.66716609593123 139.73859020053789 12.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-de66914d-6d67-4bb1-b5e1-cafc211eb571">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-de66914d-6d67-4bb1-b5e1-cafc211eb571_0">
											<gml:posList>35.66719228425592 139.73860600930163 12.1 35.667165593066905 139.7385811656542 12.1 35.667165593066905 139.7385811656542 45.289 35.66719228425592 139.73860600930163 45.289 35.66719228425592 139.73860600930163 12.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-31a5456a-0b86-4768-b82c-2368200d2917">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-31a5456a-0b86-4768-b82c-2368200d2917_0">
											<gml:posList>35.66717731607868 139.7386106330901 12.1 35.66717731607868 139.7386106330901 45.289 35.66716240443981 139.73859546270785 45.289 35.66716240443981 139.73859546270785 12.1 35.66717731607868 139.7386106330901 12.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f0a99dee-917b-4a20-b917-e803e3123e1b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f0a99dee-917b-4a20-b917-e803e3123e1b_0">
											<gml:posList>35.66717818209158 139.73861151573257 45.289 35.66716506432111 139.73863089454412 45.289 35.66716369531178 139.73863226584214 45.289 35.667172751660694 139.73864060578452 45.289 35.66719228425592 139.73860600930163 45.289 35.667165593066905 139.7385811656542 45.289 35.66716232523843 139.73858644941564 45.289 35.667165202877 139.7385893179277 45.289 35.66716609593123 139.73859020053789 45.289 35.66716240443981 139.73859546270785 45.289 35.66717731607868 139.7386106330901 45.289 35.66717818209158 139.73861151573257 45.289</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8e7683d8-e47b-48ff-bf4b-315b829e78d8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8e7683d8-e47b-48ff-bf4b-315b829e78d8_0">
											<gml:posList>35.66717818209158 139.73861151573257 12.1 35.66717818209158 139.73861151573257 45.289 35.66717731607868 139.7386106330901 45.289 35.66717731607868 139.7386106330901 12.1 35.66717818209158 139.73861151573257 12.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-35e76f07-ef07-4615-9e09-0144d3f1dbe5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-35e76f07-ef07-4615-9e09-0144d3f1dbe5_0">
											<gml:posList>35.66717818209158 139.73861151573257 12.1 35.66716506432111 139.73863089454412 12.1 35.66716506432111 139.73863089454412 45.289 35.66717818209158 139.73861151573257 45.289 35.66717818209158 139.73861151573257 12.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-819a47cf-f4ff-4671-8114-a93926e772f5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-819a47cf-f4ff-4671-8114-a93926e772f5_0">
											<gml:posList>35.667172751660694 139.73864060578452 12.1 35.66719228425592 139.73860600930163 12.1 35.66719228425592 139.73860600930163 45.289 35.667172751660694 139.73864060578452 45.289 35.667172751660694 139.73864060578452 12.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-09ffb12c-b8d0-47bf-bb3b-2089fa067b3c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-09ffb12c-b8d0-47bf-bb3b-2089fa067b3c_0">
											<gml:posList>35.66716506432111 139.73863089454412 12.1 35.66716369531178 139.73863226584214 12.1 35.66716369531178 139.73863226584214 45.289 35.66716506432111 139.73863089454412 45.289 35.66716506432111 139.73863089454412 12.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b1b11b67-12d8-4009-9b26-e9add16cbd54">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b1b11b67-12d8-4009-9b26-e9add16cbd54_0">
											<gml:posList>35.66716369531178 139.73863226584214 12.1 35.667172751660694 139.73864060578452 12.1 35.667172751660694 139.73864060578452 45.289 35.66716369531178 139.73863226584214 45.289 35.66716369531178 139.73863226584214 12.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-3e21fa60-e419-4c7b-87d4-22faec40979c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3e21fa60-e419-4c7b-87d4-22faec40979c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3e21fa60-e419-4c7b-87d4-22faec40979c">
											<gml:posList>35.66715371888448 139.7386230654148 12.1 35.66708503418319 139.7387376915404 12.1 35.66702863744948 139.73866021657184 12.1 35.667182153875665 139.73844707193817 12.1 35.66722843075509 139.73849329918505 12.1 35.66717298071528 139.7385880274231 12.1 35.667165593066905 139.7385811656542 12.1 35.66716232523843 139.73858644941564 12.1 35.66716609593992 139.7385902115837 12.1 35.66716240443981 139.73859546270785 12.1 35.66717818209158 139.73861151573257 12.1 35.66716506432111 139.73863089454412 12.1 35.667163695303095 139.73863225479633 12.1 35.66715371888448 139.7386230654148 12.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-56086be8-d7a1-44cd-b889-00c7b9bf2651">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-56086be8-d7a1-44cd-b889-00c7b9bf2651">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-56086be8-d7a1-44cd-b889-00c7b9bf2651">
											<gml:posList>35.667182153875665 139.73844707193817 22.254 35.66718229990566 139.73844936929567 22.254 35.66722659219839 139.73849361064268 22.254 35.66722843075509 139.73849329918505 22.254 35.667182153875665 139.73844707193817 22.254</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-261d8fc2-d30c-4bd3-96cc-277d5534495b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-261d8fc2-d30c-4bd3-96cc-277d5534495b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-261d8fc2-d30c-4bd3-96cc-277d5534495b">
											<gml:posList>35.667182153875665 139.73844707193817 22.254 35.667133550895194 139.73851456413274 22.254 35.66713565979421 139.7385141639898 22.254 35.66718229990566 139.73844936929567 22.254 35.667182153875665 139.73844707193817 22.254</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-8af0f85a-40b3-4e8d-9b4c-92cdef6bf52c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8af0f85a-40b3-4e8d-9b4c-92cdef6bf52c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8af0f85a-40b3-4e8d-9b4c-92cdef6bf52c">
											<gml:posList>35.66714012993311 139.73851330817638 22.064 35.66715371572964 139.73852741970845 22.064 35.66717106758398 139.73851649697167 22.064 35.66718204675198 139.7385285018401 22.064 35.66719797602871 139.73854250015364 22.064 35.66722659219839 139.73849361064268 22.064 35.66718229990566 139.73844936929567 22.064 35.66713565979421 139.7385141639898 22.064 35.66714012993311 139.73851330817638 22.064</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-7e26a36d-6ef2-44b2-b510-244a5847eeee">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7e26a36d-6ef2-44b2-b510-244a5847eeee">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7e26a36d-6ef2-44b2-b510-244a5847eeee">
											<gml:posList>35.667133550895194 139.73851456413274 51.037 35.667134435806005 139.73851655133254 51.037 35.66713961792499 139.73851556212765 51.037 35.66714012993311 139.73851330817638 51.037 35.667133550895194 139.73851456413274 51.037</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-6fe0c58e-f07d-48a5-8bde-e151e509f003">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6fe0c58e-f07d-48a5-8bde-e151e509f003">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6fe0c58e-f07d-48a5-8bde-e151e509f003">
											<gml:posList>35.66722659219839 139.73849361064268 22.254 35.66719797602871 139.73854250015364 22.254 35.66719906744615 139.73854345984986 22.254 35.66722843075509 139.73849329918505 22.254 35.66722659219839 139.73849361064268 22.254</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c63035c6-4045-47a5-bf03-bc5e736f6ef6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c63035c6-4045-47a5-bf03-bc5e736f6ef6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c63035c6-4045-47a5-bf03-bc5e736f6ef6">
											<gml:posList>35.66715371572964 139.73852741970845 51.037 35.66714012993311 139.73851330817638 51.037 35.66713961792499 139.73851556212765 51.037 35.667153474367865 139.73852997157704 51.037 35.66715371572964 139.73852741970845 51.037</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ec0695a5-14a5-47d8-984c-f92cc4a0f68d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ec0695a5-14a5-47d8-984c-f92cc4a0f68d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ec0695a5-14a5-47d8-984c-f92cc4a0f68d">
											<gml:posList>35.66717106758398 139.73851649697167 51.037 35.667170808203686 139.73851905990793 51.037 35.66717964928323 139.73852873663682 51.037 35.66718204675198 139.7385285018401 51.037 35.66717106758398 139.73851649697167 51.037</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-dea4738a-1399-4c90-8e81-13ea8ab33ba1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-dea4738a-1399-4c90-8e81-13ea8ab33ba1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-dea4738a-1399-4c90-8e81-13ea8ab33ba1">
											<gml:posList>35.66715371572964 139.73852741970845 51.037 35.667153474367865 139.73852997157704 51.037 35.667170808203686 139.73851905990793 51.037 35.66717106758398 139.73851649697167 51.037 35.66715371572964 139.73852741970845 51.037</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a34dfab5-824e-4cc6-8f41-8aae01b494aa">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a34dfab5-824e-4cc6-8f41-8aae01b494aa">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a34dfab5-824e-4cc6-8f41-8aae01b494aa">
											<gml:posList>35.6671809599578 139.73855631649602 45.289 35.667165593066905 139.7385811656542 45.289 35.66717298071528 139.7385880274231 45.289 35.66719906744615 139.73854345984986 45.289 35.66718204675198 139.7385285018401 45.289 35.66717048674377 139.738545813257 45.289 35.6671809599578 139.73855631649602 45.289</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-fb42e7cc-cc4f-44f9-8ac7-d6daa7e2041c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fb42e7cc-cc4f-44f9-8ac7-d6daa7e2041c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fb42e7cc-cc4f-44f9-8ac7-d6daa7e2041c">
											<gml:posList>35.66713003568286 139.73860637002878 51.037 35.66718204675198 139.7385285018401 51.037 35.66717964928323 139.73852873663682 51.037 35.667127656224 139.7386065827101 51.037 35.66713003568286 139.73860637002878 51.037</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-76ab2b34-6290-4f22-be5c-826bddc1cfb3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-76ab2b34-6290-4f22-be5c-826bddc1cfb3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-76ab2b34-6290-4f22-be5c-826bddc1cfb3">
											<gml:posList>35.667133550895194 139.73851456413274 51.037 35.66702863744948 139.73866021657184 51.037 35.66703096298243 139.73866020278038 51.037 35.667134435806005 139.73851655133254 51.037 35.667133550895194 139.73851456413274 51.037</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-06962ee8-91f5-496d-8ff8-46f5ade2dd07">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-06962ee8-91f5-496d-8ff8-46f5ade2dd07">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-06962ee8-91f5-496d-8ff8-46f5ade2dd07">
											<gml:posList>35.66713003568286 139.73860637002878 51.037 35.667127656224 139.7386065827101 51.037 35.66713374585083 139.73861339078232 51.037 35.66713613432342 139.73861317809053 51.037 35.66713003568286 139.73860637002878 51.037</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-3d54cfd7-1866-4666-985d-9b902f5c73d3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3d54cfd7-1866-4666-985d-9b902f5c73d3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3d54cfd7-1866-4666-985d-9b902f5c73d3">
											<gml:posList>35.667134435806005 139.73851655133254 50.232 35.66703096298243 139.73866020278038 50.232 35.667068275072 139.7387114664829 50.232 35.66713374585083 139.73861339078232 50.232 35.667127656224 139.7386065827101 50.232 35.66717964928323 139.73852873663682 50.232 35.667170808203686 139.73851905990793 50.232 35.667153474367865 139.73852997157704 50.232 35.66713961792499 139.73851556212765 50.232 35.667134435806005 139.73851655133254 50.232</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-1d750ffa-d788-4626-a5e8-5350e49b86fc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1d750ffa-d788-4626-a5e8-5350e49b86fc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1d750ffa-d788-4626-a5e8-5350e49b86fc">
											<gml:posList>35.66715371888448 139.7386230654148 47.055 35.667163695303095 139.73863225479633 47.055 35.66716506432111 139.73863089454412 47.055 35.66717818209158 139.73861151573257 47.055 35.66716240443981 139.73859546270785 47.055 35.66716609593992 139.7385902115837 47.055 35.66716232523843 139.73858644941564 47.055 35.6671809599578 139.73855631649602 47.055 35.66717048674377 139.738545813257 47.055 35.66713003568286 139.73860637002878 47.055 35.66713613432342 139.73861317809053 47.055 35.667068322709746 139.73871473598436 47.055 35.66708503418319 139.7387376915404 47.055 35.66715371888448 139.7386230654148 47.055</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-242016e5-7f7a-4245-bf80-4e2070ca553f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-242016e5-7f7a-4245-bf80-4e2070ca553f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-242016e5-7f7a-4245-bf80-4e2070ca553f">
											<gml:posList>35.66713613432342 139.73861317809053 51.037 35.66713374585083 139.73861339078232 51.037 35.667068275072 139.7387114664829 51.037 35.667068322709746 139.73871473598436 51.037 35.66713613432342 139.73861317809053 51.037</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f09620f8-0e1a-4daf-b5c7-e38853a13486">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f09620f8-0e1a-4daf-b5c7-e38853a13486">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f09620f8-0e1a-4daf-b5c7-e38853a13486">
											<gml:posList>35.66702863744948 139.73866021657184 51.037 35.667068322709746 139.73871473598436 51.037 35.667068275072 139.7387114664829 51.037 35.66703096298243 139.73866020278038 51.037 35.66702863744948 139.73866021657184 51.037</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ed6adc98-6b2d-400d-b6c3-1298eaa176dd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ed6adc98-6b2d-400d-b6c3-1298eaa176dd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ed6adc98-6b2d-400d-b6c3-1298eaa176dd">
											<gml:posList>35.66703096298243 139.73866020278038 51.037 35.66703096298243 139.73866020278038 50.232 35.667134435806005 139.73851655133254 50.232 35.667134435806005 139.73851655133254 51.037 35.66703096298243 139.73866020278038 51.037</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8e02b5d6-f179-4dd0-8e26-6ebe3c2f287e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8e02b5d6-f179-4dd0-8e26-6ebe3c2f287e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8e02b5d6-f179-4dd0-8e26-6ebe3c2f287e">
											<gml:posList>35.66713374585083 139.73861339078232 51.037 35.66713374585083 139.73861339078232 50.232 35.667068275072 139.7387114664829 50.232 35.667068275072 139.7387114664829 51.037 35.66713374585083 139.73861339078232 51.037</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d1c13474-19f6-4a21-805a-1a334221ce72">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d1c13474-19f6-4a21-805a-1a334221ce72">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d1c13474-19f6-4a21-805a-1a334221ce72">
											<gml:posList>35.66713565979421 139.7385141639898 22.254 35.66713565979421 139.7385141639898 22.064 35.66718229990566 139.73844936929567 22.064 35.66718229990566 139.73844936929567 22.254 35.66713565979421 139.7385141639898 22.254</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-79c3e6b3-898d-4926-b856-d87630b30e5b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-79c3e6b3-898d-4926-b856-d87630b30e5b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-79c3e6b3-898d-4926-b856-d87630b30e5b">
											<gml:posList>35.667153474367865 139.73852997157704 51.037 35.667153474367865 139.73852997157704 50.232 35.667170808203686 139.73851905990793 50.232 35.667170808203686 139.73851905990793 51.037 35.667153474367865 139.73852997157704 51.037</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-201376df-b762-4252-950b-ed34e23ce7e0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-201376df-b762-4252-950b-ed34e23ce7e0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-201376df-b762-4252-950b-ed34e23ce7e0">
											<gml:posList>35.66722843075509 139.73849329918505 12.1 35.667182153875665 139.73844707193817 12.1 35.667182153875665 139.73844707193817 22.254 35.66722843075509 139.73849329918505 22.254 35.66722843075509 139.73849329918505 12.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6994835e-bafd-4029-89a4-89ec9e0d4c07">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6994835e-bafd-4029-89a4-89ec9e0d4c07">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6994835e-bafd-4029-89a4-89ec9e0d4c07">
											<gml:posList>35.66718229990566 139.73844936929567 22.254 35.66718229990566 139.73844936929567 22.064 35.66722659219839 139.73849361064268 22.064 35.66722659219839 139.73849361064268 22.254 35.66718229990566 139.73844936929567 22.254</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c4e89d55-54fb-4e95-b7c9-eaebd23ac03f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c4e89d55-54fb-4e95-b7c9-eaebd23ac03f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c4e89d55-54fb-4e95-b7c9-eaebd23ac03f">
											<gml:posList>35.66713565979421 139.7385141639898 22.254 35.667133550895194 139.73851456413274 22.254 35.667133550895194 139.73851456413274 51.037 35.66714012993311 139.73851330817638 51.037 35.66714012993311 139.73851330817638 22.064 35.66713565979421 139.7385141639898 22.064 35.66713565979421 139.7385141639898 22.254</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c001bd25-9939-498a-b871-61beef2e2d05">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c001bd25-9939-498a-b871-61beef2e2d05">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c001bd25-9939-498a-b871-61beef2e2d05">
											<gml:posList>35.667134435806005 139.73851655133254 51.037 35.667134435806005 139.73851655133254 50.232 35.66713961792499 139.73851556212765 50.232 35.66713961792499 139.73851556212765 51.037 35.667134435806005 139.73851655133254 51.037</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-fdf0b9f9-8dad-4b33-b9e4-eedf60f29b99">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fdf0b9f9-8dad-4b33-b9e4-eedf60f29b99">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fdf0b9f9-8dad-4b33-b9e4-eedf60f29b99">
											<gml:posList>35.66722659219839 139.73849361064268 22.254 35.66722659219839 139.73849361064268 22.064 35.66719797602871 139.73854250015364 22.064 35.66719797602871 139.73854250015364 22.254 35.66722659219839 139.73849361064268 22.254</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5c3e489a-a888-4101-8a70-5891c02d7632">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5c3e489a-a888-4101-8a70-5891c02d7632">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5c3e489a-a888-4101-8a70-5891c02d7632">
											<gml:posList>35.66714012993311 139.73851330817638 51.037 35.66715371572964 139.73852741970845 51.037 35.66715371572964 139.73852741970845 22.064 35.66714012993311 139.73851330817638 22.064 35.66714012993311 139.73851330817638 51.037</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-cac8744e-2c41-4e50-aa25-d4a72ba9a5bb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cac8744e-2c41-4e50-aa25-d4a72ba9a5bb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cac8744e-2c41-4e50-aa25-d4a72ba9a5bb">
											<gml:posList>35.66715371572964 139.73852741970845 51.037 35.66717106758398 139.73851649697167 51.037 35.66717106758398 139.73851649697167 22.064 35.66715371572964 139.73852741970845 22.064 35.66715371572964 139.73852741970845 51.037</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4a403ab6-267e-4754-b7ea-88bce4bdc8cf">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4a403ab6-267e-4754-b7ea-88bce4bdc8cf">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4a403ab6-267e-4754-b7ea-88bce4bdc8cf">
											<gml:posList>35.66717106758398 139.73851649697167 22.064 35.66717106758398 139.73851649697167 51.037 35.66718204675198 139.7385285018401 51.037 35.66718204675198 139.7385285018401 45.289 35.66718204675198 139.7385285018401 22.064 35.66717106758398 139.73851649697167 22.064</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-83a1a3e2-6cc1-474b-bda4-6f29692a4f8f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-83a1a3e2-6cc1-474b-bda4-6f29692a4f8f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-83a1a3e2-6cc1-474b-bda4-6f29692a4f8f">
											<gml:posList>35.66713961792499 139.73851556212765 51.037 35.66713961792499 139.73851556212765 50.232 35.667153474367865 139.73852997157704 50.232 35.667153474367865 139.73852997157704 51.037 35.66713961792499 139.73851556212765 51.037</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-bb3933df-00c9-47af-9144-52202f80c5ca">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bb3933df-00c9-47af-9144-52202f80c5ca">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bb3933df-00c9-47af-9144-52202f80c5ca">
											<gml:posList>35.667170808203686 139.73851905990793 51.037 35.667170808203686 139.73851905990793 50.232 35.66717964928323 139.73852873663682 50.232 35.66717964928323 139.73852873663682 51.037 35.667170808203686 139.73851905990793 51.037</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4e7fed4b-c87c-4e2c-9871-b8be11633e48">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4e7fed4b-c87c-4e2c-9871-b8be11633e48">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4e7fed4b-c87c-4e2c-9871-b8be11633e48">
											<gml:posList>35.66718204675198 139.7385285018401 22.064 35.66718204675198 139.7385285018401 45.289 35.66719906744615 139.73854345984986 45.289 35.66719906744615 139.73854345984986 22.254 35.66719797602871 139.73854250015364 22.254 35.66719797602871 139.73854250015364 22.064 35.66718204675198 139.7385285018401 22.064</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-de590ba5-9365-4a27-a583-6023efc914fd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-de590ba5-9365-4a27-a583-6023efc914fd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-de590ba5-9365-4a27-a583-6023efc914fd">
											<gml:posList>35.66719906744615 139.73854345984986 22.254 35.66719906744615 139.73854345984986 45.289 35.66717298071528 139.7385880274231 45.289 35.66717298071528 139.7385880274231 12.1 35.66722843075509 139.73849329918505 12.1 35.66722843075509 139.73849329918505 22.254 35.66719906744615 139.73854345984986 22.254</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-942e2f1c-d6d9-4cc3-8024-1763e371db68">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-942e2f1c-d6d9-4cc3-8024-1763e371db68">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-942e2f1c-d6d9-4cc3-8024-1763e371db68">
											<gml:posList>35.66717048674377 139.738545813257 47.055 35.6671809599578 139.73855631649602 47.055 35.6671809599578 139.73855631649602 45.289 35.66717048674377 139.738545813257 45.289 35.66717048674377 139.738545813257 47.055</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0f2aa316-87f8-4742-928d-402662aa1d0d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0f2aa316-87f8-4742-928d-402662aa1d0d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0f2aa316-87f8-4742-928d-402662aa1d0d">
											<gml:posList>35.66702863744948 139.73866021657184 12.1 35.66702863744948 139.73866021657184 51.037 35.667133550895194 139.73851456413274 51.037 35.667133550895194 139.73851456413274 22.254 35.667182153875665 139.73844707193817 22.254 35.667182153875665 139.73844707193817 12.1 35.66702863744948 139.73866021657184 12.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-78a96059-8fc7-4d42-b5ff-c72a9dac4291">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-78a96059-8fc7-4d42-b5ff-c72a9dac4291">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-78a96059-8fc7-4d42-b5ff-c72a9dac4291">
											<gml:posList>35.66718204675198 139.7385285018401 51.037 35.66713003568286 139.73860637002878 51.037 35.66713003568286 139.73860637002878 47.055 35.66717048674377 139.738545813257 47.055 35.66717048674377 139.738545813257 45.289 35.66718204675198 139.7385285018401 45.289 35.66718204675198 139.7385285018401 51.037</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-76ce0f31-e3f6-4d77-b69f-122aec4ef44a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-76ce0f31-e3f6-4d77-b69f-122aec4ef44a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-76ce0f31-e3f6-4d77-b69f-122aec4ef44a">
											<gml:posList>35.66717964928323 139.73852873663682 51.037 35.66717964928323 139.73852873663682 50.232 35.667127656224 139.7386065827101 50.232 35.667127656224 139.7386065827101 51.037 35.66717964928323 139.73852873663682 51.037</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-33d678e9-1c55-45b2-a989-6c9ec874b63c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-33d678e9-1c55-45b2-a989-6c9ec874b63c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-33d678e9-1c55-45b2-a989-6c9ec874b63c">
											<gml:posList>35.66716232523843 139.73858644941564 47.055 35.66716232523843 139.73858644941564 12.1 35.667165593066905 139.7385811656542 12.1 35.667165593066905 139.7385811656542 45.289 35.6671809599578 139.73855631649602 45.289 35.6671809599578 139.73855631649602 47.055 35.66716232523843 139.73858644941564 47.055</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8530f837-0adf-4698-99b2-77a57a2d97d5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8530f837-0adf-4698-99b2-77a57a2d97d5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8530f837-0adf-4698-99b2-77a57a2d97d5">
											<gml:posList>35.667165593066905 139.7385811656542 12.1 35.66717298071528 139.7385880274231 12.1 35.66717298071528 139.7385880274231 45.289 35.667165593066905 139.7385811656542 45.289 35.667165593066905 139.7385811656542 12.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6dbc5b79-649d-4ea2-9d00-2c8df75dc134">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6dbc5b79-649d-4ea2-9d00-2c8df75dc134">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6dbc5b79-649d-4ea2-9d00-2c8df75dc134">
											<gml:posList>35.66716609593992 139.7385902115837 12.1 35.66716232523843 139.73858644941564 12.1 35.66716232523843 139.73858644941564 47.055 35.66716609593992 139.7385902115837 47.055 35.66716609593992 139.7385902115837 12.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b32aeaaf-cd13-4d3e-9ba3-68420d931271">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b32aeaaf-cd13-4d3e-9ba3-68420d931271">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b32aeaaf-cd13-4d3e-9ba3-68420d931271">
											<gml:posList>35.66716240443981 139.73859546270785 12.1 35.66716609593992 139.7385902115837 12.1 35.66716609593992 139.7385902115837 47.055 35.66716240443981 139.73859546270785 47.055 35.66716240443981 139.73859546270785 12.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b630a269-a698-49cd-b562-3ea1e7845f92">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b630a269-a698-49cd-b562-3ea1e7845f92">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b630a269-a698-49cd-b562-3ea1e7845f92">
											<gml:posList>35.66717818209158 139.73861151573257 12.1 35.66716240443981 139.73859546270785 12.1 35.66716240443981 139.73859546270785 47.055 35.66717818209158 139.73861151573257 47.055 35.66717818209158 139.73861151573257 12.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8a5aa826-4b58-4eee-83ed-f8af3a5d9fcc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8a5aa826-4b58-4eee-83ed-f8af3a5d9fcc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8a5aa826-4b58-4eee-83ed-f8af3a5d9fcc">
											<gml:posList>35.66713003568286 139.73860637002878 51.037 35.66713613432342 139.73861317809053 51.037 35.66713613432342 139.73861317809053 47.055 35.66713003568286 139.73860637002878 47.055 35.66713003568286 139.73860637002878 51.037</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1ed8f3cd-2055-4afb-ad56-ccd498f82cf2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1ed8f3cd-2055-4afb-ad56-ccd498f82cf2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1ed8f3cd-2055-4afb-ad56-ccd498f82cf2">
											<gml:posList>35.667127656224 139.7386065827101 51.037 35.667127656224 139.7386065827101 50.232 35.66713374585083 139.73861339078232 50.232 35.66713374585083 139.73861339078232 51.037 35.667127656224 139.7386065827101 51.037</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7ec83b3a-ad5d-46c8-a0fb-3ca325b66a39">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7ec83b3a-ad5d-46c8-a0fb-3ca325b66a39">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7ec83b3a-ad5d-46c8-a0fb-3ca325b66a39">
											<gml:posList>35.66716506432111 139.73863089454412 12.1 35.66717818209158 139.73861151573257 12.1 35.66717818209158 139.73861151573257 47.055 35.66716506432111 139.73863089454412 47.055 35.66716506432111 139.73863089454412 12.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a5c52a6f-c787-4d6c-84df-6593907a8449">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a5c52a6f-c787-4d6c-84df-6593907a8449">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a5c52a6f-c787-4d6c-84df-6593907a8449">
											<gml:posList>35.66715371888448 139.7386230654148 12.1 35.667163695303095 139.73863225479633 12.1 35.667163695303095 139.73863225479633 47.055 35.66715371888448 139.7386230654148 47.055 35.66715371888448 139.7386230654148 12.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ab1c04fc-9cf5-4154-9854-7eb40fc5dd14">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ab1c04fc-9cf5-4154-9854-7eb40fc5dd14">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ab1c04fc-9cf5-4154-9854-7eb40fc5dd14">
											<gml:posList>35.667163695303095 139.73863225479633 12.1 35.66716506432111 139.73863089454412 12.1 35.66716506432111 139.73863089454412 47.055 35.667163695303095 139.73863225479633 47.055 35.667163695303095 139.73863225479633 12.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-aafd9560-60b0-4108-8705-b9d0cc080850">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-aafd9560-60b0-4108-8705-b9d0cc080850">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-aafd9560-60b0-4108-8705-b9d0cc080850">
											<gml:posList>35.66713613432342 139.73861317809053 51.037 35.667068322709746 139.73871473598436 51.037 35.667068322709746 139.73871473598436 47.055 35.66713613432342 139.73861317809053 47.055 35.66713613432342 139.73861317809053 51.037</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-dab73ef0-7c39-4ad1-b0fe-bb57a387687d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-dab73ef0-7c39-4ad1-b0fe-bb57a387687d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-dab73ef0-7c39-4ad1-b0fe-bb57a387687d">
											<gml:posList>35.66708503418319 139.7387376915404 12.1 35.66715371888448 139.7386230654148 12.1 35.66715371888448 139.7386230654148 47.055 35.66708503418319 139.7387376915404 47.055 35.66708503418319 139.7387376915404 12.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f9722c3b-3096-471c-a764-78cb714d9966">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f9722c3b-3096-471c-a764-78cb714d9966">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f9722c3b-3096-471c-a764-78cb714d9966">
											<gml:posList>35.667068275072 139.7387114664829 51.037 35.667068275072 139.7387114664829 50.232 35.66703096298243 139.73866020278038 50.232 35.66703096298243 139.73866020278038 51.037 35.667068275072 139.7387114664829 51.037</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9587a7de-e49e-448a-a3c1-6199d5cf3401">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9587a7de-e49e-448a-a3c1-6199d5cf3401">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9587a7de-e49e-448a-a3c1-6199d5cf3401">
											<gml:posList>35.66702863744948 139.73866021657184 12.1 35.66708503418319 139.7387376915404 12.1 35.66708503418319 139.7387376915404 47.055 35.667068322709746 139.73871473598436 47.055 35.667068322709746 139.73871473598436 51.037 35.66702863744948 139.73866021657184 51.037 35.66702863744948 139.73866021657184 12.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区六本木二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-7605</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">221.5032</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">211</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1320</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>7</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>