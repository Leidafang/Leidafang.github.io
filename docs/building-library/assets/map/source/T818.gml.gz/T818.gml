<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_e914c668-5aac-431c-876d-0521e64bcc67">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001001</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">401</bldg:usage>
			<bldg:measuredHeight uom="m">30</bldg:measuredHeight>
			<bldg:storeysAboveGround>8</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.670618468692794 139.7430308619402 0 35.67058731513798 139.74319648088894 0 35.67066268590212 139.74321782597448 0 35.670673100308036 139.74316236184274 0 35.67064290110079 139.74303779358857 0 35.670618468692794 139.7430308619402 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670618468692794 139.7430308619402 7.2 35.67064290110079 139.74303779358857 7.2 35.670673100308036 139.74316236184274 7.2 35.67066268590212 139.74321782597448 7.2 35.67058731513798 139.74319648088894 7.2 35.670618468692794 139.7430308619402 7.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670618468692794 139.7430308619402 7.2 35.67058731513798 139.74319648088894 7.2 35.67058731513798 139.74319648088894 31.75 35.670618468692794 139.7430308619402 31.75 35.670618468692794 139.7430308619402 7.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67058731513798 139.74319648088894 7.2 35.67066268590212 139.74321782597448 7.2 35.67066268590212 139.74321782597448 31.75 35.67058731513798 139.74319648088894 31.75 35.67058731513798 139.74319648088894 7.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67066268590212 139.74321782597448 7.2 35.670673100308036 139.74316236184274 7.2 35.670673100308036 139.74316236184274 31.75 35.67066268590212 139.74321782597448 31.75 35.67066268590212 139.74321782597448 7.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670673100308036 139.74316236184274 7.2 35.67064290110079 139.74303779358857 7.2 35.67064290110079 139.74303779358857 31.75 35.670673100308036 139.74316236184274 31.75 35.670673100308036 139.74316236184274 7.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67064290110079 139.74303779358857 7.2 35.670618468692794 139.7430308619402 7.2 35.670618468692794 139.7430308619402 31.75 35.67064290110079 139.74303779358857 31.75 35.67064290110079 139.74303779358857 7.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670618468692794 139.7430308619402 31.75 35.67058731513798 139.74319648088894 31.75 35.67066268590212 139.74321782597448 31.75 35.670673100308036 139.74316236184274 31.75 35.67064290110079 139.74303779358857 31.75 35.670618468692794 139.7430308619402 31.75</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-a113a068-8d2a-4076-8a49-14e4b1246359"/>
							<gml:surfaceMember xlink:href="#poly-cf7abef9-f2d9-4f2a-90f7-2571751226e8"/>
							<gml:surfaceMember xlink:href="#poly-3293ffa9-e05f-42a8-be78-96e72fee9a49"/>
							<gml:surfaceMember xlink:href="#poly-21457803-f068-43e7-9b1a-13508aa4cdc0"/>
							<gml:surfaceMember xlink:href="#poly-8cccde70-4075-45e8-a146-9fb49b59fd01"/>
							<gml:surfaceMember xlink:href="#poly-00a351c2-365c-4fb6-9e93-1db58fef771f"/>
							<gml:surfaceMember xlink:href="#poly-103faa62-1cd8-42bb-9b12-94aea9de08e2"/>
							<gml:surfaceMember xlink:href="#poly-4838f852-656b-43e4-9a0f-0c38211115a2"/>
							<gml:surfaceMember xlink:href="#poly-20104c6f-42bd-442d-93c8-396d876afc3a"/>
							<gml:surfaceMember xlink:href="#poly-38c6c2b8-3bc2-4742-95c0-f1279d6e791a"/>
							<gml:surfaceMember xlink:href="#poly-fd280961-93a2-48bc-9341-17b09e7aeeb0"/>
							<gml:surfaceMember xlink:href="#poly-aa120580-43d4-449c-a543-c3cbea43a0e7"/>
							<gml:surfaceMember xlink:href="#poly-d5c533ee-d7c3-4244-b7e5-1014514255ce"/>
							<gml:surfaceMember xlink:href="#poly-65cea8d5-83f3-467a-beaf-00ca5954ca65"/>
							<gml:surfaceMember xlink:href="#poly-a7df5ada-aef1-49a7-8bb2-9833c2c46f08"/>
							<gml:surfaceMember xlink:href="#poly-7ae6e40c-f0bc-450a-9ce1-5643c37cb38b"/>
							<gml:surfaceMember xlink:href="#poly-1cabcc2b-c3fd-4f31-bad4-fb0198713223"/>
							<gml:surfaceMember xlink:href="#poly-7bd78b88-725c-41ee-9b1f-4b9af933af9b"/>
							<gml:surfaceMember xlink:href="#poly-d9fc05de-9224-4b4a-8ae6-73e34d987480"/>
							<gml:surfaceMember xlink:href="#poly-f5c273f4-aa7c-43ef-9a91-cb82595691cd"/>
							<gml:surfaceMember xlink:href="#poly-aad379aa-2dae-41cb-98a9-8b2954ea6386"/>
							<gml:surfaceMember xlink:href="#poly-16956f04-0ef9-4045-ab12-958563853327"/>
							<gml:surfaceMember xlink:href="#poly-d3be6a6b-7949-4f29-9a31-6601d9164680"/>
							<gml:surfaceMember xlink:href="#poly-f71adad7-c63b-4dfb-9c0d-2a7db478b6ca"/>
							<gml:surfaceMember xlink:href="#poly-15591a0f-2846-4214-8993-ce42862bc32e"/>
							<gml:surfaceMember xlink:href="#poly-1034f1b1-6b78-4d5a-88b1-aabf3c2a21c6"/>
							<gml:surfaceMember xlink:href="#poly-464b8c02-6764-4afc-ad6f-4f2120c09823"/>
							<gml:surfaceMember xlink:href="#poly-ff3bc20b-1ec7-4df0-825f-1c775a9ca53b"/>
							<gml:surfaceMember xlink:href="#poly-b0298664-5c9f-41d3-b69e-02d6ac57d4c6"/>
							<gml:surfaceMember xlink:href="#poly-7e264b3a-9577-4ac0-a2ce-0ad3e3e7a5d3"/>
							<gml:surfaceMember xlink:href="#poly-2048ef13-8495-4e39-a962-40a5ea8d5937"/>
							<gml:surfaceMember xlink:href="#poly-09113443-346a-4ce0-a039-5d202dc1e03a"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_e914c668-5aac-431c-876d-0521e64bcc67_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7f77fbda-dc70-4080-a3bf-575c55233649">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67063539175147 139.74313278913522 30.978 35.67063023273421 139.74315263408351 30.978 35.67060679919299 139.74314348097315 30.978 35.67061194920331 139.7431236470865 30.978 35.67063539175147 139.74313278913522 30.978</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-291bf555-bf50-4dc3-aa71-a326833ed81e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-291bf555-bf50-4dc3-aa71-a326833ed81e_0">
											<gml:posList>35.67061194920331 139.7431236470865 30.978 35.67061194920331 139.7431236470865 34.09 35.67063539175147 139.74313278913522 34.09 35.67063539175147 139.74313278913522 30.978 35.67061194920331 139.7431236470865 30.978</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-daa3dd3d-b938-4d07-8534-16493feb48c2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-daa3dd3d-b938-4d07-8534-16493feb48c2_0">
											<gml:posList>35.67060679919299 139.74314348097315 30.978 35.67060679919299 139.74314348097315 34.09 35.67061194920331 139.7431236470865 34.09 35.67061194920331 139.7431236470865 30.978 35.67060679919299 139.74314348097315 30.978</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b06152e6-dfc3-4864-9fa0-d184c7caccf0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b06152e6-dfc3-4864-9fa0-d184c7caccf0_0">
											<gml:posList>35.67060679919299 139.74314348097315 34.09 35.67063023273421 139.74315263408351 34.09 35.67063539175147 139.74313278913522 34.09 35.67061194920331 139.7431236470865 34.09 35.67060679919299 139.74314348097315 34.09</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3f866bc3-b062-4b67-ac72-fc589521b9aa">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3f866bc3-b062-4b67-ac72-fc589521b9aa_0">
											<gml:posList>35.67063539175147 139.74313278913522 30.978 35.67063539175147 139.74313278913522 34.09 35.67063023273421 139.74315263408351 34.09 35.67063023273421 139.74315263408351 30.978 35.67063539175147 139.74313278913522 30.978</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3c8935be-78ce-4fa5-a556-a655df8fec13">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3c8935be-78ce-4fa5-a556-a655df8fec13_0">
											<gml:posList>35.67063023273421 139.74315263408351 30.978 35.67063023273421 139.74315263408351 34.09 35.67060679919299 139.74314348097315 34.09 35.67060679919299 139.74314348097315 30.978 35.67063023273421 139.74315263408351 30.978</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_e914c668-5aac-431c-876d-0521e64bcc67_BuildingInstallation_1051">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-dcd1ccc4-6a0b-40f8-a3cd-2db3332b9acd">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67061646965775 139.7430455668067 37.243 35.67061616442527 139.74304721304796 37.243 35.670615667784276 139.74304603165393 37.243 35.67061646965775 139.7430455668067 37.243</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-dc2eb213-f44f-43f3-9d92-ad3615f7d18f">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67063817943614 139.7430999564095 36.439 35.67061616442527 139.74304721304796 36.439 35.67061646965775 139.7430455668067 36.439 35.670617523791215 139.74304493598095 36.439 35.6706400355429 139.7430989932929 36.439 35.67063817943614 139.7430999564095 36.439</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-770d0055-0318-4414-b482-ccaa91f7404a">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6706400355429 139.7430989932929 37.243 35.67064037867693 139.74309981033258 37.243 35.67063852256187 139.7431007624029 37.243 35.67063817943614 139.7430999564095 37.243 35.6706400355429 139.7430989932929 37.243</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3f65a9a7-bace-42fb-8459-ecd30bb0f62b">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67064037867693 139.74309981033258 30.978 35.67066575289959 139.74316073525375 30.978 35.6706639600042 139.74316185294637 30.978 35.67063852256187 139.7431007624029 30.978 35.67064037867693 139.74309981033258 30.978</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3eb8edc7-edaa-4fed-a9f0-2ae15673e766">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3eb8edc7-edaa-4fed-a9f0-2ae15673e766_0">
											<gml:posList>35.67063852256187 139.7431007624029 37.243 35.67064037867693 139.74309981033258 37.243 35.67064037867693 139.74309981033258 30.978 35.67063852256187 139.7431007624029 30.978 35.67063852256187 139.7431007624029 37.243</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3fa95bb7-584e-47e0-8962-3d6b02435326">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3fa95bb7-584e-47e0-8962-3d6b02435326_0">
											<gml:posList>35.67061646965775 139.7430455668067 36.439 35.67061616442527 139.74304721304796 36.439 35.67061616442527 139.74304721304796 37.243 35.67061646965775 139.7430455668067 37.243 35.67061646965775 139.7430455668067 36.439</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3daf2f3b-3496-4aef-886b-c9598cf868b5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3daf2f3b-3496-4aef-886b-c9598cf868b5_0">
											<gml:posList>35.67061646965775 139.7430455668067 37.243 35.670615667784276 139.74304603165393 37.243 35.670615667784276 139.74304603165393 44.357 35.670617523791215 139.74304493598095 44.357 35.670617523791215 139.74304493598095 36.439 35.67061646965775 139.7430455668067 36.439 35.67061646965775 139.7430455668067 37.243</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-647d705e-1983-4dd4-a70a-959afd3aee30">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-647d705e-1983-4dd4-a70a-959afd3aee30_0">
											<gml:posList>35.67063817943614 139.7430999564095 36.439 35.6706400355429 139.7430989932929 36.439 35.6706400355429 139.7430989932929 37.243 35.67063817943614 139.7430999564095 37.243 35.67063817943614 139.7430999564095 36.439</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-840af613-36f7-4fcc-b9ee-71223cc3dfb6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-840af613-36f7-4fcc-b9ee-71223cc3dfb6_0">
											<gml:posList>35.67061616442527 139.74304721304796 37.243 35.67061616442527 139.74304721304796 36.439 35.67063817943614 139.7430999564095 36.439 35.67063817943614 139.7430999564095 37.243 35.67063852256187 139.7431007624029 37.243 35.67063852256187 139.7431007624029 30.978 35.6706639600042 139.74316185294637 30.978 35.6706639600042 139.74316185294637 44.357 35.670615667784276 139.74304603165393 44.357 35.670615667784276 139.74304603165393 37.243 35.67061616442527 139.74304721304796 37.243</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-36997bea-b3a2-4548-88cd-af0529886b12">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-36997bea-b3a2-4548-88cd-af0529886b12_0">
											<gml:posList>35.6706639600042 139.74316185294637 44.357 35.67066575289959 139.74316073525375 44.357 35.670617523791215 139.74304493598095 44.357 35.670615667784276 139.74304603165393 44.357 35.6706639600042 139.74316185294637 44.357</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ff892171-5fbc-4968-b9e6-889ad5d4baa8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ff892171-5fbc-4968-b9e6-889ad5d4baa8_0">
											<gml:posList>35.670617523791215 139.74304493598095 36.439 35.670617523791215 139.74304493598095 44.357 35.67066575289959 139.74316073525375 44.357 35.67066575289959 139.74316073525375 30.978 35.67064037867693 139.74309981033258 30.978 35.67064037867693 139.74309981033258 37.243 35.6706400355429 139.7430989932929 37.243 35.6706400355429 139.7430989932929 36.439 35.670617523791215 139.74304493598095 36.439</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-017c264d-9c7f-42c2-b0d7-f5328b82d7f0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-017c264d-9c7f-42c2-b0d7-f5328b82d7f0_0">
											<gml:posList>35.67066575289959 139.74316073525375 30.978 35.67066575289959 139.74316073525375 44.357 35.6706639600042 139.74316185294637 44.357 35.6706639600042 139.74316185294637 30.978 35.67066575289959 139.74316073525375 30.978</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-a113a068-8d2a-4076-8a49-14e4b1246359">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a113a068-8d2a-4076-8a49-14e4b1246359">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a113a068-8d2a-4076-8a49-14e4b1246359">
											<gml:posList>35.670618468692794 139.74303086194018 7.2 35.6706429011008 139.74303779358857 7.2 35.67067310030804 139.74316236184274 7.2 35.6706626859021 139.74321782597448 7.2 35.670587315137944 139.74319648088894 7.2 35.670618468692794 139.74303086194018 7.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-cf7abef9-f2d9-4f2a-90f7-2571751226e8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cf7abef9-f2d9-4f2a-90f7-2571751226e8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cf7abef9-f2d9-4f2a-90f7-2571751226e8">
											<gml:posList>35.67060842786717 139.74309160575783 31.8 35.670607129551634 139.7430911543212 31.8 35.67060807746612 139.7430931194941 31.8 35.67060842786717 139.74309160575783 31.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-3293ffa9-e05f-42a8-be78-96e72fee9a49">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3293ffa9-e05f-42a8-be78-96e72fee9a49">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3293ffa9-e05f-42a8-be78-96e72fee9a49">
											<gml:posList>35.67065515672074 139.74309383974648 31.8 35.67065597538008 139.74309171793593 31.8 35.67065465988151 139.7430923932407 31.8 35.67065515672074 139.74309383974648 31.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-21457803-f068-43e7-9b1a-13508aa4cdc0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-21457803-f068-43e7-9b1a-13508aa4cdc0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-21457803-f068-43e7-9b1a-13508aa4cdc0">
											<gml:posList>35.670587315137944 139.74319648088894 31.8 35.67058884659437 139.74319530826065 31.8 35.67060807746612 139.7430931194941 31.8 35.670607129551634 139.7430911543212 31.8 35.670587315137944 139.74319648088894 31.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-8cccde70-4075-45e8-a146-9fb49b59fd01">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8cccde70-4075-45e8-a146-9fb49b59fd01">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8cccde70-4075-45e8-a146-9fb49b59fd01">
											<gml:posList>35.670607129551634 139.7430911543212 37.243 35.67060801241633 139.7430905126426 37.243 35.670619028372016 139.7430319659391 37.243 35.670618468692794 139.74303086194018 37.243 35.670607129551634 139.7430911543212 37.243</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-00a351c2-365c-4fb6-9e93-1db58fef771f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-00a351c2-365c-4fb6-9e93-1db58fef771f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-00a351c2-365c-4fb6-9e93-1db58fef771f">
											<gml:posList>35.67063708092908 139.7431015151734 37.243 35.67063701711286 139.74310055421756 37.243 35.67060801241633 139.7430905126426 37.243 35.670607129551634 139.7430911543212 37.243 35.67063708092908 139.7431015151734 37.243</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-103faa62-1cd8-42bb-9b12-94aea9de08e2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-103faa62-1cd8-42bb-9b12-94aea9de08e2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-103faa62-1cd8-42bb-9b12-94aea9de08e2">
											<gml:posList>35.6706626859021 139.74321782597448 31.8 35.670661720028356 139.74321594918933 31.8 35.67058884659437 139.74319530826065 31.8 35.670587315137944 139.74319648088894 31.8 35.6706626859021 139.74321782597448 31.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-4838f852-656b-43e4-9a0f-0c38211115a2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4838f852-656b-43e4-9a0f-0c38211115a2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4838f852-656b-43e4-9a0f-0c38211115a2">
											<gml:posList>35.67065515672074 139.74309383974648 30.978 35.67065465988151 139.7430923932407 30.978 35.67063708092908 139.7431015151734 30.978 35.67060842786717 139.74309160575783 30.978 35.67060807746612 139.7430931194941 30.978 35.67058884659437 139.74319530826065 30.978 35.670661720028356 139.74321594918933 30.978 35.67067177531559 139.74316239647177 30.978 35.67065515672074 139.74309383974648 30.978</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-20104c6f-42bd-442d-93c8-396d876afc3a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-20104c6f-42bd-442d-93c8-396d876afc3a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-20104c6f-42bd-442d-93c8-396d876afc3a">
											<gml:posList>35.6706429011008 139.74303779358857 37.243 35.670618468692794 139.74303086194018 37.243 35.670619028372016 139.7430319659391 37.243 35.67064230677492 139.74303856749862 37.243 35.6706429011008 139.74303779358857 37.243</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-38c6c2b8-3bc2-4742-95c0-f1279d6e791a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-38c6c2b8-3bc2-4742-95c0-f1279d6e791a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-38c6c2b8-3bc2-4742-95c0-f1279d6e791a">
											<gml:posList>35.67060801241633 139.7430905126426 36.439 35.67063701711286 139.74310055421756 36.439 35.670655064604965 139.74309119978503 36.439 35.67064230677492 139.74303856749862 36.439 35.670619028372016 139.7430319659391 36.439 35.67060801241633 139.7430905126426 36.439</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-fd280961-93a2-48bc-9341-17b09e7aeeb0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fd280961-93a2-48bc-9341-17b09e7aeeb0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fd280961-93a2-48bc-9341-17b09e7aeeb0">
											<gml:posList>35.67063708092908 139.7431015151734 37.243 35.67065597538008 139.74309171793593 37.243 35.670655064604965 139.74309119978503 37.243 35.67063701711286 139.74310055421756 37.243 35.67063708092908 139.7431015151734 37.243</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-aa120580-43d4-449c-a543-c3cbea43a0e7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-aa120580-43d4-449c-a543-c3cbea43a0e7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-aa120580-43d4-449c-a543-c3cbea43a0e7">
											<gml:posList>35.6706429011008 139.74303779358857 37.243 35.67064230677492 139.74303856749862 37.243 35.670655064604965 139.74309119978503 37.243 35.67065597538008 139.74309171793593 37.243 35.6706429011008 139.74303779358857 37.243</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d5c533ee-d7c3-4244-b7e5-1014514255ce">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d5c533ee-d7c3-4244-b7e5-1014514255ce">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d5c533ee-d7c3-4244-b7e5-1014514255ce">
											<gml:posList>35.67067310030804 139.74316236184274 31.8 35.67065597538008 139.74309171793593 31.8 35.67065515672074 139.74309383974648 31.8 35.67067177531559 139.74316239647177 31.8 35.67067310030804 139.74316236184274 31.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-65cea8d5-83f3-467a-beaf-00ca5954ca65">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-65cea8d5-83f3-467a-beaf-00ca5954ca65">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-65cea8d5-83f3-467a-beaf-00ca5954ca65">
											<gml:posList>35.67067310030804 139.74316236184274 31.8 35.67067177531559 139.74316239647177 31.8 35.670661720028356 139.74321594918933 31.8 35.6706626859021 139.74321782597448 31.8 35.67067310030804 139.74316236184274 31.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a7df5ada-aef1-49a7-8bb2-9833c2c46f08">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a7df5ada-aef1-49a7-8bb2-9833c2c46f08">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a7df5ada-aef1-49a7-8bb2-9833c2c46f08">
											<gml:posList>35.6706429011008 139.74303779358857 7.2 35.670618468692794 139.74303086194018 7.2 35.670618468692794 139.74303086194018 37.243 35.6706429011008 139.74303779358857 37.243 35.6706429011008 139.74303779358857 7.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7ae6e40c-f0bc-450a-9ce1-5643c37cb38b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7ae6e40c-f0bc-450a-9ce1-5643c37cb38b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7ae6e40c-f0bc-450a-9ce1-5643c37cb38b">
											<gml:posList>35.670619028372016 139.7430319659391 37.243 35.670619028372016 139.7430319659391 36.439 35.67064230677492 139.74303856749862 36.439 35.67064230677492 139.74303856749862 37.243 35.670619028372016 139.7430319659391 37.243</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1cabcc2b-c3fd-4f31-bad4-fb0198713223">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1cabcc2b-c3fd-4f31-bad4-fb0198713223">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1cabcc2b-c3fd-4f31-bad4-fb0198713223">
											<gml:posList>35.67060801241633 139.7430905126426 37.243 35.67060801241633 139.7430905126426 36.439 35.670619028372016 139.7430319659391 36.439 35.670619028372016 139.7430319659391 37.243 35.67060801241633 139.7430905126426 37.243</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7bd78b88-725c-41ee-9b1f-4b9af933af9b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7bd78b88-725c-41ee-9b1f-4b9af933af9b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7bd78b88-725c-41ee-9b1f-4b9af933af9b">
											<gml:posList>35.67064230677492 139.74303856749862 37.243 35.67064230677492 139.74303856749862 36.439 35.670655064604965 139.74309119978503 36.439 35.670655064604965 139.74309119978503 37.243 35.67064230677492 139.74303856749862 37.243</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d9fc05de-9224-4b4a-8ae6-73e34d987480">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d9fc05de-9224-4b4a-8ae6-73e34d987480">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d9fc05de-9224-4b4a-8ae6-73e34d987480">
											<gml:posList>35.67060807746612 139.7430931194941 31.8 35.67060807746612 139.7430931194941 30.978 35.67060842786717 139.74309160575783 30.978 35.67060842786717 139.74309160575783 31.8 35.67060807746612 139.7430931194941 31.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f5c273f4-aa7c-43ef-9a91-cb82595691cd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f5c273f4-aa7c-43ef-9a91-cb82595691cd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f5c273f4-aa7c-43ef-9a91-cb82595691cd">
											<gml:posList>35.67065465988151 139.7430923932407 31.8 35.67065465988151 139.7430923932407 30.978 35.67065515672074 139.74309383974648 30.978 35.67065515672074 139.74309383974648 31.8 35.67065465988151 139.7430923932407 31.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-aad379aa-2dae-41cb-98a9-8b2954ea6386">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-aad379aa-2dae-41cb-98a9-8b2954ea6386">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-aad379aa-2dae-41cb-98a9-8b2954ea6386">
											<gml:posList>35.67063701711286 139.74310055421756 37.243 35.67063701711286 139.74310055421756 36.439 35.67060801241633 139.7430905126426 36.439 35.67060801241633 139.7430905126426 37.243 35.67063701711286 139.74310055421756 37.243</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-16956f04-0ef9-4045-ab12-958563853327">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-16956f04-0ef9-4045-ab12-958563853327">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-16956f04-0ef9-4045-ab12-958563853327">
											<gml:posList>35.670655064604965 139.74309119978503 37.243 35.670655064604965 139.74309119978503 36.439 35.67063701711286 139.74310055421756 36.439 35.67063701711286 139.74310055421756 37.243 35.670655064604965 139.74309119978503 37.243</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d3be6a6b-7949-4f29-9a31-6601d9164680">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d3be6a6b-7949-4f29-9a31-6601d9164680">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d3be6a6b-7949-4f29-9a31-6601d9164680">
											<gml:posList>35.67063708092908 139.7431015151734 30.978 35.67063708092908 139.7431015151734 37.243 35.670607129551634 139.7430911543212 37.243 35.670607129551634 139.7430911543212 31.8 35.67060842786717 139.74309160575783 31.8 35.67060842786717 139.74309160575783 30.978 35.67063708092908 139.7431015151734 30.978</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f71adad7-c63b-4dfb-9c0d-2a7db478b6ca">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f71adad7-c63b-4dfb-9c0d-2a7db478b6ca">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f71adad7-c63b-4dfb-9c0d-2a7db478b6ca">
											<gml:posList>35.67065465988151 139.7430923932407 31.8 35.67065597538008 139.74309171793593 31.8 35.67065597538008 139.74309171793593 37.243 35.67063708092908 139.7431015151734 37.243 35.67063708092908 139.7431015151734 30.978 35.67065465988151 139.7430923932407 30.978 35.67065465988151 139.7430923932407 31.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-15591a0f-2846-4214-8993-ce42862bc32e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-15591a0f-2846-4214-8993-ce42862bc32e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-15591a0f-2846-4214-8993-ce42862bc32e">
											<gml:posList>35.6706429011008 139.74303779358857 7.2 35.6706429011008 139.74303779358857 37.243 35.67065597538008 139.74309171793593 37.243 35.67065597538008 139.74309171793593 31.8 35.67067310030804 139.74316236184274 31.8 35.67067310030804 139.74316236184274 7.2 35.6706429011008 139.74303779358857 7.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1034f1b1-6b78-4d5a-88b1-aabf3c2a21c6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1034f1b1-6b78-4d5a-88b1-aabf3c2a21c6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1034f1b1-6b78-4d5a-88b1-aabf3c2a21c6">
											<gml:posList>35.670607129551634 139.7430911543212 31.8 35.670607129551634 139.7430911543212 37.243 35.670618468692794 139.74303086194018 37.243 35.670618468692794 139.74303086194018 7.2 35.670587315137944 139.74319648088894 7.2 35.670587315137944 139.74319648088894 31.8 35.670607129551634 139.7430911543212 31.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-464b8c02-6764-4afc-ad6f-4f2120c09823">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-464b8c02-6764-4afc-ad6f-4f2120c09823">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-464b8c02-6764-4afc-ad6f-4f2120c09823">
											<gml:posList>35.67065515672074 139.74309383974648 31.8 35.67065515672074 139.74309383974648 30.978 35.67067177531559 139.74316239647177 30.978 35.67067177531559 139.74316239647177 31.8 35.67065515672074 139.74309383974648 31.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ff3bc20b-1ec7-4df0-825f-1c775a9ca53b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ff3bc20b-1ec7-4df0-825f-1c775a9ca53b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ff3bc20b-1ec7-4df0-825f-1c775a9ca53b">
											<gml:posList>35.67058884659437 139.74319530826065 31.8 35.67058884659437 139.74319530826065 30.978 35.67060807746612 139.7430931194941 30.978 35.67060807746612 139.7430931194941 31.8 35.67058884659437 139.74319530826065 31.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b0298664-5c9f-41d3-b69e-02d6ac57d4c6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b0298664-5c9f-41d3-b69e-02d6ac57d4c6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b0298664-5c9f-41d3-b69e-02d6ac57d4c6">
											<gml:posList>35.67067177531559 139.74316239647177 31.8 35.67067177531559 139.74316239647177 30.978 35.670661720028356 139.74321594918933 30.978 35.670661720028356 139.74321594918933 31.8 35.67067177531559 139.74316239647177 31.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7e264b3a-9577-4ac0-a2ce-0ad3e3e7a5d3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7e264b3a-9577-4ac0-a2ce-0ad3e3e7a5d3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7e264b3a-9577-4ac0-a2ce-0ad3e3e7a5d3">
											<gml:posList>35.6706626859021 139.74321782597448 7.2 35.67067310030804 139.74316236184274 7.2 35.67067310030804 139.74316236184274 31.8 35.6706626859021 139.74321782597448 31.8 35.6706626859021 139.74321782597448 7.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2048ef13-8495-4e39-a962-40a5ea8d5937">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2048ef13-8495-4e39-a962-40a5ea8d5937">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2048ef13-8495-4e39-a962-40a5ea8d5937">
											<gml:posList>35.670661720028356 139.74321594918933 31.8 35.670661720028356 139.74321594918933 30.978 35.67058884659437 139.74319530826065 30.978 35.67058884659437 139.74319530826065 31.8 35.670661720028356 139.74321594918933 31.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-09113443-346a-4ce0-a039-5d202dc1e03a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-09113443-346a-4ce0-a039-5d202dc1e03a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-09113443-346a-4ce0-a039-5d202dc1e03a">
											<gml:posList>35.670587315137944 139.74319648088894 7.2 35.6706626859021 139.74321782597448 7.2 35.6706626859021 139.74321782597448 31.8 35.670587315137944 139.74319648088894 31.8 35.670587315137944 139.74319648088894 7.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂一丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-7355</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">102.3497</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1210</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>7</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">2</uro:rank>
					<uro:depth uom="m">0.54</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>