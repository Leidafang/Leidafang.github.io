<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_e938fa88-6840-456d-808e-31110c8a6869">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001001</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">401</bldg:usage>
			<bldg:measuredHeight uom="m">28.5</bldg:measuredHeight>
			<bldg:storeysAboveGround>8</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.67031300691927 139.74438116825138 0 35.67040289928098 139.74441564332426 0 35.670410166863384 139.74437023511956 0 35.67044613831234 139.74437925314692 0 35.67046876200849 139.744256283039 0 35.67033370062754 139.74420805050192 0 35.67030408306506 139.74433202234223 0 35.67032298987302 139.74433880584593 0 35.67031300691927 139.74438116825138 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67031300691927 139.74438116825138 7.69 35.67032298987302 139.74433880584593 7.69 35.67030408306506 139.74433202234223 7.69 35.67033370062754 139.74420805050192 7.69 35.67046876200849 139.744256283039 7.69 35.67044613831234 139.74437925314692 7.69 35.670410166863384 139.74437023511956 7.69 35.67040289928098 139.74441564332426 7.69 35.67031300691927 139.74438116825138 7.69</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67031300691927 139.74438116825138 7.69 35.67040289928098 139.74441564332426 7.69 35.67040289928098 139.74441564332426 36.14 35.67031300691927 139.74438116825138 36.14 35.67031300691927 139.74438116825138 7.69</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67040289928098 139.74441564332426 7.69 35.670410166863384 139.74437023511956 7.69 35.670410166863384 139.74437023511956 36.14 35.67040289928098 139.74441564332426 36.14 35.67040289928098 139.74441564332426 7.69</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670410166863384 139.74437023511956 7.69 35.67044613831234 139.74437925314692 7.69 35.67044613831234 139.74437925314692 36.14 35.670410166863384 139.74437023511956 36.14 35.670410166863384 139.74437023511956 7.69</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67044613831234 139.74437925314692 7.69 35.67046876200849 139.744256283039 7.69 35.67046876200849 139.744256283039 36.14 35.67044613831234 139.74437925314692 36.14 35.67044613831234 139.74437925314692 7.69</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67046876200849 139.744256283039 7.69 35.67033370062754 139.74420805050192 7.69 35.67033370062754 139.74420805050192 36.14 35.67046876200849 139.744256283039 36.14 35.67046876200849 139.744256283039 7.69</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67033370062754 139.74420805050192 7.69 35.67030408306506 139.74433202234223 7.69 35.67030408306506 139.74433202234223 36.14 35.67033370062754 139.74420805050192 36.14 35.67033370062754 139.74420805050192 7.69</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67030408306506 139.74433202234223 7.69 35.67032298987302 139.74433880584593 7.69 35.67032298987302 139.74433880584593 36.14 35.67030408306506 139.74433202234223 36.14 35.67030408306506 139.74433202234223 7.69</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67032298987302 139.74433880584593 7.69 35.67031300691927 139.74438116825138 7.69 35.67031300691927 139.74438116825138 36.14 35.67032298987302 139.74433880584593 36.14 35.67032298987302 139.74433880584593 7.69</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67031300691927 139.74438116825138 36.14 35.67040289928098 139.74441564332426 36.14 35.670410166863384 139.74437023511956 36.14 35.67044613831234 139.74437925314692 36.14 35.67046876200849 139.744256283039 36.14 35.67033370062754 139.74420805050192 36.14 35.67030408306506 139.74433202234223 36.14 35.67032298987302 139.74433880584593 36.14 35.67031300691927 139.74438116825138 36.14</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-c641b014-9d6f-438e-ac36-7e3d2aafc352"/>
							<gml:surfaceMember xlink:href="#poly-2802c8fa-13a9-4b71-be60-1cbeca7351c0"/>
							<gml:surfaceMember xlink:href="#poly-5fb94526-f6b1-42cb-ab05-6fb82b8b75cb"/>
							<gml:surfaceMember xlink:href="#poly-8df899c6-c67e-41f3-a5bb-6f76598be650"/>
							<gml:surfaceMember xlink:href="#poly-a9e8eb29-c6f7-4fbe-9025-146c3af2c790"/>
							<gml:surfaceMember xlink:href="#poly-23e8d5da-0d4b-42a3-87e3-808ea7bd8d55"/>
							<gml:surfaceMember xlink:href="#poly-22eae298-0759-440c-82c9-3329abf270a0"/>
							<gml:surfaceMember xlink:href="#poly-9a771511-017a-4ada-829b-e28e15e1ce2b"/>
							<gml:surfaceMember xlink:href="#poly-52c64af8-523d-443d-8666-a166d18170d6"/>
							<gml:surfaceMember xlink:href="#poly-bf7c9fdf-e43e-477b-9b90-4230d2f51606"/>
							<gml:surfaceMember xlink:href="#poly-c8366488-6c34-48d3-b467-29b0f600b441"/>
							<gml:surfaceMember xlink:href="#poly-991bca63-3edb-482a-af92-0d97a27ce291"/>
							<gml:surfaceMember xlink:href="#poly-9ed92f02-1ed3-444a-b342-0416a35656c8"/>
							<gml:surfaceMember xlink:href="#poly-1188e086-5e22-43de-aca5-c5de9857911b"/>
							<gml:surfaceMember xlink:href="#poly-481c8565-609c-4a34-a0ff-9ea1772ba8f0"/>
							<gml:surfaceMember xlink:href="#poly-f1a83cc0-d5ea-4762-924a-bfc25d29cb7a"/>
							<gml:surfaceMember xlink:href="#poly-2f9be3de-a5d2-4b73-b742-6da5d8d5cdfd"/>
							<gml:surfaceMember xlink:href="#poly-c466e2df-fb5e-4ea1-a591-4e39170521a0"/>
							<gml:surfaceMember xlink:href="#poly-89c1c4f1-d870-42ee-acc0-5a21af775634"/>
							<gml:surfaceMember xlink:href="#poly-a650b89f-fb3b-4701-bf20-ebc7692e76c3"/>
							<gml:surfaceMember xlink:href="#poly-3e7e422a-8d95-4f4e-9f42-7078fa531dc7"/>
							<gml:surfaceMember xlink:href="#poly-a2a20da1-c99d-40a0-93b1-b32ccbacddfa"/>
							<gml:surfaceMember xlink:href="#poly-09dc0f7e-c1a7-4550-91ee-184117e8fc7a"/>
							<gml:surfaceMember xlink:href="#poly-35c0114b-0d3c-4cb0-950c-5587473e36f7"/>
							<gml:surfaceMember xlink:href="#poly-b0d81395-2211-4081-b387-5c29cb783908"/>
							<gml:surfaceMember xlink:href="#poly-43aec4cc-19f2-4ecc-9338-b486cbccca8e"/>
							<gml:surfaceMember xlink:href="#poly-d694f69b-7ec5-484d-8a97-43a24287547d"/>
							<gml:surfaceMember xlink:href="#poly-c8037bc4-7f06-415d-bbcf-e636edcfb49d"/>
							<gml:surfaceMember xlink:href="#poly-612adcd6-a30b-46b8-b93f-c69f46c304bf"/>
							<gml:surfaceMember xlink:href="#poly-258970af-cc9b-4629-9099-5beff183f890"/>
							<gml:surfaceMember xlink:href="#poly-ed235e2f-5857-4074-863c-a66b3faa64e8"/>
							<gml:surfaceMember xlink:href="#poly-b3464233-5f9e-4e26-97b4-2e30698cd27f"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_e938fa88-6840-456d-808e-31110c8a6869_BuildingInstallation_1060">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4d9adb33-335e-49e0-a541-791f3ca1e8d0">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6702940727134 139.74437389873398 8.26 35.67030408306505 139.74433202234223 8.26 35.67032298987301 139.74433880584593 8.26 35.67031300691927 139.74438116825135 8.26 35.6702940727134 139.74437389873398 8.26</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0a7f8afd-ab43-4125-a0be-70bbfa5bb53d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0a7f8afd-ab43-4125-a0be-70bbfa5bb53d_0">
											<gml:posList>35.67030408306505 139.74433202234223 33.7 35.67030408306505 139.74433202234223 8.26 35.6702940727134 139.74437389873398 8.26 35.6702940727134 139.74437389873398 33.7 35.67030408306505 139.74433202234223 33.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8c4a4f02-682d-4726-b716-badffb19137e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8c4a4f02-682d-4726-b716-badffb19137e_0">
											<gml:posList>35.6702940727134 139.74437389873398 33.7 35.6702940727134 139.74437389873398 8.26 35.67031300691927 139.74438116825135 8.26 35.67031300691927 139.74438116825135 33.7 35.6702940727134 139.74437389873398 33.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d09b6d75-abb4-4aca-aa68-92f651319ecf">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d09b6d75-abb4-4aca-aa68-92f651319ecf_0">
											<gml:posList>35.6702940727134 139.74437389873398 33.7 35.67031300691927 139.74438116825135 33.7 35.67032298987301 139.74433880584593 33.7 35.67030408306505 139.74433202234223 33.7 35.6702940727134 139.74437389873398 33.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-535b6f96-478d-4012-9bad-2050093db21c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-535b6f96-478d-4012-9bad-2050093db21c_0">
											<gml:posList>35.67032298987301 139.74433880584593 33.7 35.67032298987301 139.74433880584593 8.26 35.67030408306505 139.74433202234223 8.26 35.67030408306505 139.74433202234223 33.7 35.67032298987301 139.74433880584593 33.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-88865d7d-8ed5-4b1d-82f4-398be73d515c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-88865d7d-8ed5-4b1d-82f4-398be73d515c_0">
											<gml:posList>35.67031300691927 139.74438116825135 33.7 35.67031300691927 139.74438116825135 8.26 35.67032298987301 139.74433880584593 8.26 35.67032298987301 139.74433880584593 33.7 35.67031300691927 139.74438116825135 33.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_e938fa88-6840-456d-808e-31110c8a6869_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e229061b-cb91-4edf-9e9a-d448837ba03e">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670333818010334 139.74420832652777 36.8 35.67036135319052 139.74421811604248 36.8 35.67036067933578 139.74422105509584 36.8 35.670335506348266 139.744212069331 36.8 35.670332747686246 139.7442236267783 36.8 35.67033036744191 139.7442227899085 36.8 35.670333818010334 139.74420832652777 36.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b7f679e8-11f9-4a28-983d-62135cda1936">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670332747686246 139.7442236267783 36.077 35.670335506348266 139.744212069331 36.077 35.67036067933578 139.74422105509584 36.077 35.67035803776141 139.74423249090754 36.077 35.670332747686246 139.7442236267783 36.077</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2863bb7e-72cd-432d-822f-7f1e37edd56f">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67038565687508 139.74429482740177 39.845 35.670404239517524 139.74430205311404 39.845 35.67039885566631 139.74432284815825 39.845 35.67038027303327 139.7443156334879 39.845 35.67038565687508 139.74429482740177 39.845</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-866d10e6-283d-4df2-a4bd-7988f69e9294">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6703784203115 139.7443577770252 36.077 35.67037013428336 139.74435451652795 36.077 35.67037255216708 139.74434530126484 36.077 35.67038202834985 139.74434902438327 36.077 35.67037961947956 139.74435823963736 36.077 35.6703784203115 139.7443577770252 36.077</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-39b485f7-5161-4718-8e9b-86e2c25b216c">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67039431548372 139.7443509438423 36.077 35.670405748207514 139.74435542698325 36.077 35.67040264723064 139.74436728306472 36.077 35.670391214507276 139.74436279992224 36.077 35.67039431548372 139.7443509438423 36.077</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-57ec9ced-78b0-4781-b572-f0511cfc1eb7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-57ec9ced-78b0-4781-b572-f0511cfc1eb7_0">
											<gml:posList>35.6703784203115 139.7443577770252 36.27 35.6703784203115 139.7443577770252 36.077 35.67037961947956 139.74435823963736 36.077 35.67037961947956 139.74435823963736 36.391 35.6703784203115 139.7443577770252 36.27</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-39562fcc-901b-4691-aaf0-2fc5d889fff5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-39562fcc-901b-4691-aaf0-2fc5d889fff5_0">
											<gml:posList>35.670333818010334 139.74420832652777 36.8 35.670333818010334 139.74420832652777 37.012 35.67036135319052 139.74421811604248 37.012 35.67036135319052 139.74421811604248 36.8 35.670333818010334 139.74420832652777 36.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f8d70209-b6e7-48e8-bf5c-5be7c4dc73dd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f8d70209-b6e7-48e8-bf5c-5be7c4dc73dd_0">
											<gml:posList>35.67033036744191 139.7442227899085 36.8 35.67033036744191 139.7442227899085 37.012 35.670333818010334 139.74420832652777 37.012 35.670333818010334 139.74420832652777 36.8 35.67033036744191 139.7442227899085 36.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0ec8c54e-76ac-422c-9e94-90849bfd13e2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0ec8c54e-76ac-422c-9e94-90849bfd13e2_0">
											<gml:posList>35.670335506348266 139.744212069331 36.8 35.67036067933578 139.74422105509584 36.8 35.67036067933578 139.74422105509584 36.077 35.670335506348266 139.744212069331 36.077 35.670335506348266 139.744212069331 36.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-11a98f55-aebb-4aed-baf0-721c8b53a61f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-11a98f55-aebb-4aed-baf0-721c8b53a61f_0">
											<gml:posList>35.670335506348266 139.744212069331 36.077 35.670332747686246 139.7442236267783 36.077 35.670332747686246 139.7442236267783 36.8 35.670335506348266 139.744212069331 36.8 35.670335506348266 139.744212069331 36.077</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c8ff59ef-1b7b-4a84-b81e-84585f1b303a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c8ff59ef-1b7b-4a84-b81e-84585f1b303a_0">
											<gml:posList>35.67036135319052 139.74421811604248 37.012 35.670333818010334 139.74420832652777 37.012 35.67033036744191 139.7442227899085 37.012 35.67035803776141 139.74423249090754 37.012 35.67036135319052 139.74421811604248 37.012</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ea5e96cb-6aa1-463e-bc9a-fd5f00cc50e3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ea5e96cb-6aa1-463e-bc9a-fd5f00cc50e3_0">
											<gml:posList>35.67036135319052 139.74421811604248 37.012 35.67035803776141 139.74423249090754 37.012 35.67035803776141 139.74423249090754 36.077 35.67036067933578 139.74422105509584 36.077 35.67036067933578 139.74422105509584 36.8 35.67036135319052 139.74421811604248 36.8 35.67036135319052 139.74421811604248 37.012</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-359cdf64-2853-4cb0-8e65-765ef698f8ff">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-359cdf64-2853-4cb0-8e65-765ef698f8ff_0">
											<gml:posList>35.670332747686246 139.7442236267783 36.8 35.670332747686246 139.7442236267783 36.077 35.67035803776141 139.74423249090754 36.077 35.67035803776141 139.74423249090754 37.012 35.67033036744191 139.7442227899085 37.012 35.67033036744191 139.7442227899085 36.8 35.670332747686246 139.7442236267783 36.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6041502d-fd97-4ef0-ace0-4675046bf703">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6041502d-fd97-4ef0-ace0-4675046bf703_0">
											<gml:posList>35.670404239517524 139.74430205311404 39.845 35.67038565687508 139.74429482740177 39.845 35.67038565687508 139.74429482740177 40.605 35.670404239517524 139.74430205311404 40.605 35.670404239517524 139.74430205311404 39.845</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-90b5797b-a1c8-4794-9cbb-a0d82d396018">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-90b5797b-a1c8-4794-9cbb-a0d82d396018_0">
											<gml:posList>35.67038565687508 139.74429482740177 39.845 35.67038027303327 139.7443156334879 39.845 35.67038027303327 139.7443156334879 40.605 35.67038565687508 139.74429482740177 40.605 35.67038565687508 139.74429482740177 39.845</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5ca1c85b-2c45-404a-b4d0-9a15a223bdca">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5ca1c85b-2c45-404a-b4d0-9a15a223bdca_0">
											<gml:posList>35.67038565687508 139.74429482740177 40.605 35.67038027303327 139.7443156334879 40.605 35.67039885566631 139.74432284815825 40.605 35.670404239517524 139.74430205311404 40.605 35.67038565687508 139.74429482740177 40.605</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fe4ecbff-f4cf-4f49-aa88-e5f94da94d4e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fe4ecbff-f4cf-4f49-aa88-e5f94da94d4e_0">
											<gml:posList>35.67039885566631 139.74432284815825 39.845 35.670404239517524 139.74430205311404 39.845 35.670404239517524 139.74430205311404 40.605 35.67039885566631 139.74432284815825 40.605 35.67039885566631 139.74432284815825 39.845</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-55a816b7-3a6b-43d2-8795-13d373bda444">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-55a816b7-3a6b-43d2-8795-13d373bda444_0">
											<gml:posList>35.67038027303327 139.7443156334879 39.845 35.67039885566631 139.74432284815825 39.845 35.67039885566631 139.74432284815825 40.605 35.67038027303327 139.7443156334879 40.605 35.67038027303327 139.7443156334879 39.845</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-91ec988d-844f-48c7-ac6d-b5e964920683">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-91ec988d-844f-48c7-ac6d-b5e964920683_0">
											<gml:posList>35.67037255216708 139.74434530126484 36.077 35.67037255216708 139.74434530126484 38.97 35.67038202834985 139.74434902438327 38.97 35.67038202834985 139.74434902438327 36.077 35.67037255216708 139.74434530126484 36.077</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-510d5673-0dda-4797-8db2-142b4f7bd4ce">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-510d5673-0dda-4797-8db2-142b4f7bd4ce_0">
											<gml:posList>35.67037013428336 139.74435451652795 38.97 35.67037255216708 139.74434530126484 38.97 35.67037255216708 139.74434530126484 36.077 35.67037013428336 139.74435451652795 36.077 35.67037013428336 139.74435451652795 38.97</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1329e7b0-efa5-47e6-bb6d-b916a68996d6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1329e7b0-efa5-47e6-bb6d-b916a68996d6_0">
											<gml:posList>35.67037013428336 139.74435451652795 38.97 35.67037961947956 139.74435823963736 38.97 35.67038202834985 139.74434902438327 38.97 35.67037255216708 139.74434530126484 38.97 35.67037013428336 139.74435451652795 38.97</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f42a21e0-359e-4c12-b3c1-48d9f3835559">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f42a21e0-359e-4c12-b3c1-48d9f3835559_0">
											<gml:posList>35.670405748207514 139.74435542698325 36.077 35.67039431548372 139.7443509438423 36.077 35.67039431548372 139.7443509438423 38.97 35.670405748207514 139.74435542698325 38.97 35.670405748207514 139.74435542698325 36.077</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b15b17fb-f44a-4f73-b1bd-ac6cef2f32a4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b15b17fb-f44a-4f73-b1bd-ac6cef2f32a4_0">
											<gml:posList>35.67038202834985 139.74434902438327 36.077 35.67038202834985 139.74434902438327 38.97 35.67037961947956 139.74435823963736 38.97 35.67037961947956 139.74435823963736 36.391 35.67037961947956 139.74435823963736 36.077 35.67038202834985 139.74434902438327 36.077</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ca89c5de-0256-4812-b80e-ce3755b477ef">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ca89c5de-0256-4812-b80e-ce3755b477ef_0">
											<gml:posList>35.6703784203115 139.7443577770252 36.077 35.6703784203115 139.7443577770252 36.27 35.67037961947956 139.74435823963736 36.391 35.67037961947956 139.74435823963736 38.97 35.67037013428336 139.74435451652795 38.97 35.67037013428336 139.74435451652795 36.077 35.6703784203115 139.7443577770252 36.077</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-55b750de-a5c3-4aeb-9936-b76e3ba516cc">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-55b750de-a5c3-4aeb-9936-b76e3ba516cc_0">
											<gml:posList>35.67039431548372 139.7443509438423 38.97 35.67039431548372 139.7443509438423 36.077 35.670391214507276 139.74436279992224 36.077 35.670391214507276 139.74436279992224 37.409 35.67039121449911 139.74436278887597 38.97 35.67039431548372 139.7443509438423 38.97</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-062cce22-d5da-4887-be06-c2532df4a21e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-062cce22-d5da-4887-be06-c2532df4a21e_0">
											<gml:posList>35.67039121449911 139.74436278887597 38.97 35.67039694890052 139.74436504699642 38.97 35.67040264723064 139.74436728306472 38.97 35.670405748207514 139.74435542698325 38.97 35.67039431548372 139.7443509438423 38.97 35.67039121449911 139.74436278887597 38.97</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-91f1a56f-785e-4227-b3cf-470beda050e2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-91f1a56f-785e-4227-b3cf-470beda050e2_0">
											<gml:posList>35.670405748207514 139.74435542698325 36.077 35.670405748207514 139.74435542698325 38.97 35.67040264723064 139.74436728306472 38.97 35.67040264723064 139.74436728306472 36.077 35.670405748207514 139.74435542698325 36.077</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f664b0b8-a57f-4591-87cd-67b098bdd8e9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f664b0b8-a57f-4591-87cd-67b098bdd8e9_0">
											<gml:posList>35.67039121449911 139.74436278887597 38.97 35.670391214507276 139.74436279992224 37.409 35.67039694890052 139.74436504699642 38.97 35.67039121449911 139.74436278887597 38.97</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-964b7ae1-e1db-42b8-91e2-510fbfa250da">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-964b7ae1-e1db-42b8-91e2-510fbfa250da_0">
											<gml:posList>35.67040264723064 139.74436728306472 36.077 35.67040264723064 139.74436728306472 38.97 35.67039694890052 139.74436504699642 38.97 35.670391214507276 139.74436279992224 37.409 35.670391214507276 139.74436279992224 36.077 35.67040264723064 139.74436728306472 36.077</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_e938fa88-6840-456d-808e-31110c8a6869_BuildingInstallation_1041">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9b168847-d899-43df-be1a-6a17056f553d">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67031798692035 139.74431396837997 36.077 35.670323154612284 139.74429340556748 36.077 35.67035888601281 139.7443069085975 36.077 35.67035371831044 139.74432746037206 36.077 35.67031798692035 139.74431396837997 36.077</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-29d7a456-a3a0-4df7-87a1-d2949d432173">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670412517738825 139.74429475338724 36.077 35.67040159725925 139.74433696223846 36.077 35.67037052701897 139.74432489002683 36.077 35.67038144749438 139.74428268119036 36.077 35.670412517738825 139.74429475338724 36.077</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4ca308dc-a389-4249-8f96-15e8fe02cc53">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67041790805546 139.7442827069723 36.077 35.67041597690128 139.74429189960946 36.077 35.67040376946054 139.74428804697442 36.077 35.670405700614424 139.7442788543386 36.077 35.67041790805546 139.7442827069723 36.077</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-34dfa927-ac29-457a-a4bf-a3f38599fb71">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-34dfa927-ac29-457a-a4bf-a3f38599fb71_0">
											<gml:posList>35.67031798692035 139.74431396837997 36.077 35.67031798692035 139.74431396837997 38.874 35.670323154612284 139.74429340556748 38.874 35.670323154612284 139.74429340556748 36.077 35.67031798692035 139.74431396837997 36.077</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-886c29b7-4e9a-4814-a803-b6659cec35d6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-886c29b7-4e9a-4814-a803-b6659cec35d6_0">
											<gml:posList>35.67035371831044 139.74432746037206 36.077 35.67035371831044 139.74432746037206 38.874 35.67031798692035 139.74431396837997 38.874 35.67031798692035 139.74431396837997 36.077 35.67035371831044 139.74432746037206 36.077</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-742def92-db2e-48e5-a12a-ccaddc2f8c76">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-742def92-db2e-48e5-a12a-ccaddc2f8c76_0">
											<gml:posList>35.67031798692035 139.74431396837997 38.874 35.67035371831044 139.74432746037206 38.874 35.67035888601281 139.7443069085975 38.874 35.670323154612284 139.74429340556748 38.874 35.67031798692035 139.74431396837997 38.874</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-358be8e4-f9d9-4bca-83c9-2a6847da49a2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-358be8e4-f9d9-4bca-83c9-2a6847da49a2_0">
											<gml:posList>35.670323154612284 139.74429340556748 36.077 35.670323154612284 139.74429340556748 38.874 35.67035888601281 139.7443069085975 38.874 35.67035888601281 139.7443069085975 36.077 35.670323154612284 139.74429340556748 36.077</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bbcedd48-27f5-433b-86a0-b7a436bf4109">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bbcedd48-27f5-433b-86a0-b7a436bf4109_0">
											<gml:posList>35.67035371831044 139.74432746037206 36.077 35.67035888601281 139.7443069085975 36.077 35.67035888601281 139.7443069085975 38.874 35.67035371831044 139.74432746037206 38.874 35.67035371831044 139.74432746037206 36.077</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-933d8178-d3d7-4990-839e-69cd763e6b5d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-933d8178-d3d7-4990-839e-69cd763e6b5d_0">
											<gml:posList>35.67037052701897 139.74432489002683 36.077 35.67037052701897 139.74432489002683 39.845 35.67038144749438 139.74428268119036 39.845 35.67038144749438 139.74428268119036 36.077 35.67037052701897 139.74432489002683 36.077</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5a1c3002-f3c5-4c84-8e11-8b12a9b4647f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5a1c3002-f3c5-4c84-8e11-8b12a9b4647f_0">
											<gml:posList>35.67037052701897 139.74432489002683 36.077 35.67040159725925 139.74433696223846 36.077 35.67040159725925 139.74433696223846 39.845 35.67037052701897 139.74432489002683 39.845 35.67037052701897 139.74432489002683 36.077</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cc1a271e-6ac7-4d24-8d03-68930c991ea2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cc1a271e-6ac7-4d24-8d03-68930c991ea2_0">
											<gml:posList>35.67037052701897 139.74432489002683 39.845 35.67040159725925 139.74433696223846 39.845 35.670412517738825 139.74429475338724 39.845 35.67038144749438 139.74428268119036 39.845 35.67037052701897 139.74432489002683 39.845</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5829efea-a8bf-43c8-a22b-9644d9d4fc7b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5829efea-a8bf-43c8-a22b-9644d9d4fc7b_0">
											<gml:posList>35.67038144749438 139.74428268119036 36.077 35.67038144749438 139.74428268119036 39.845 35.670412517738825 139.74429475338724 39.845 35.670412517738825 139.74429475338724 36.077 35.67038144749438 139.74428268119036 36.077</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b5921d85-3628-40b4-8fb4-c3965eed521b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b5921d85-3628-40b4-8fb4-c3965eed521b_0">
											<gml:posList>35.670405700614424 139.7442788543386 36.077 35.67040376946054 139.74428804697442 36.077 35.67040376946054 139.74428804697442 38.023 35.670405700614424 139.7442788543386 38.023 35.670405700614424 139.7442788543386 36.077</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b5d6234d-9b82-4d90-950d-b318690f6d13">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b5d6234d-9b82-4d90-950d-b318690f6d13_0">
											<gml:posList>35.670412517738825 139.74429475338724 36.077 35.670412517738825 139.74429475338724 39.845 35.67040159725925 139.74433696223846 39.845 35.67040159725925 139.74433696223846 36.077 35.670412517738825 139.74429475338724 36.077</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3fd222aa-bdf6-4a77-8960-a2b377108e4b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3fd222aa-bdf6-4a77-8960-a2b377108e4b_0">
											<gml:posList>35.67040376946054 139.74428804697442 36.077 35.67041597690128 139.74429189960946 36.077 35.67041597690128 139.74429189960946 38.023 35.67040376946054 139.74428804697442 38.023 35.67040376946054 139.74428804697442 36.077</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-af9540a7-ac1b-4360-b3fe-d64f214c13a3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-af9540a7-ac1b-4360-b3fe-d64f214c13a3_0">
											<gml:posList>35.67040376946054 139.74428804697442 38.023 35.67041597690128 139.74429189960946 38.023 35.67041790805546 139.7442827069723 38.023 35.670405700614424 139.7442788543386 38.023 35.67040376946054 139.74428804697442 38.023</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f5fd2fb6-cc1b-438d-9e8f-86f3573d74e7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f5fd2fb6-cc1b-438d-9e8f-86f3573d74e7_0">
											<gml:posList>35.670405700614424 139.7442788543386 36.077 35.670405700614424 139.7442788543386 38.023 35.67041790805546 139.7442827069723 38.023 35.67041790805546 139.7442827069723 36.077 35.670405700614424 139.7442788543386 36.077</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a6997fec-7286-4dac-9793-23dbcf6243a8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a6997fec-7286-4dac-9793-23dbcf6243a8_0">
											<gml:posList>35.67041597690128 139.74429189960946 36.077 35.67041790805546 139.7442827069723 36.077 35.67041790805546 139.7442827069723 38.023 35.67041597690128 139.74429189960946 38.023 35.67041597690128 139.74429189960946 36.077</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_e938fa88-6840-456d-808e-31110c8a6869_BuildingInstallation_1051">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8767421d-4ce0-4a32-b8eb-a2c89bc547b8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67035686886019 139.74439489427124 36.8 35.670356203778255 139.74439751297177 36.8 35.670313214128825 139.7443810244202 36.8 35.67031382512807 139.74437840578094 36.8 35.67035686886019 139.74439489427124 36.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-18f3befd-0a88-40c0-b37b-4d7f708f0b3d">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67046849163763 139.74425633857075 36.8 35.67044606599856 139.74437897707043 36.8 35.67041010352248 139.74436990380192 36.8 35.67041046208823 139.7443672191619 36.8 35.670444233862455 139.74437579777774 36.8 35.67044687261821 139.74436052890624 36.8 35.67046563592158 139.74425855099776 36.8 35.67046457202437 139.74425817660648 36.8 35.67046510157871 139.74425512724724 36.8 35.67046849163763 139.74425633857075 36.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b2caab66-1641-4814-bf0b-defa3e7dc284">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67046457202437 139.74425817660648 36.077 35.67046563592158 139.74425855099776 36.077 35.67044687261821 139.74436052890624 36.077 35.67046457202437 139.74425817660648 36.077</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-57b85208-7e24-4759-85b6-d92d27132667">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-57b85208-7e24-4759-85b6-d92d27132667_0">
											<gml:posList>35.670313214128825 139.7443810244202 40.376 35.67031382512807 139.74437840578094 40.376 35.67031382512807 139.74437840578094 36.8 35.670313214128825 139.7443810244202 36.8 35.670313214128825 139.7443810244202 40.376</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-678d7a89-65ab-4601-962b-63f2f52d3e19">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-678d7a89-65ab-4601-962b-63f2f52d3e19_0">
											<gml:posList>35.670313214128825 139.7443810244202 40.376 35.670313214128825 139.7443810244202 36.8 35.670356203778255 139.74439751297177 36.8 35.670356203778255 139.74439751297177 40.376 35.670313214128825 139.7443810244202 40.376</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7816ba44-1fe4-4df3-8868-dac60a3199d6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7816ba44-1fe4-4df3-8868-dac60a3199d6_0">
											<gml:posList>35.670313214128825 139.7443810244202 40.376 35.670356203778255 139.74439751297177 40.376 35.67035686886019 139.74439489427124 40.376 35.67031382512807 139.74437840578094 40.376 35.670313214128825 139.7443810244202 40.376</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8131e242-44b9-4531-84ae-cbdeec9a1e2e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8131e242-44b9-4531-84ae-cbdeec9a1e2e_0">
											<gml:posList>35.67035686886019 139.74439489427124 36.8 35.67031382512807 139.74437840578094 36.8 35.67031382512807 139.74437840578094 40.376 35.67035686886019 139.74439489427124 40.376 35.67035686886019 139.74439489427124 36.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-dc8b684e-799a-40f2-9400-64b19dcce30e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-dc8b684e-799a-40f2-9400-64b19dcce30e_0">
											<gml:posList>35.67035686886019 139.74439489427124 40.376 35.670356203778255 139.74439751297177 40.376 35.670356203778255 139.74439751297177 36.8 35.67035686886019 139.74439489427124 36.8 35.67035686886019 139.74439489427124 40.376</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b3ce3c84-ed2a-4d94-94c6-ba82b10eb069">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b3ce3c84-ed2a-4d94-94c6-ba82b10eb069_0">
											<gml:posList>35.67041010352248 139.74436990380192 36.8 35.67041010352248 139.74436990380192 40.376 35.67041046208823 139.7443672191619 40.376 35.67041046208823 139.7443672191619 36.8 35.67041010352248 139.74436990380192 36.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-354f5d63-2780-4ccb-bd73-e25249ce4cd2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-354f5d63-2780-4ccb-bd73-e25249ce4cd2_0">
											<gml:posList>35.67041046208823 139.7443672191619 40.376 35.670444233862455 139.74437579777774 40.376 35.670444233862455 139.74437579777774 36.8 35.67041046208823 139.7443672191619 36.8 35.67041046208823 139.7443672191619 40.376</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-dbd67519-c9b4-4ce2-b1e6-e579e4e3064c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-dbd67519-c9b4-4ce2-b1e6-e579e4e3064c_0">
											<gml:posList>35.67044606599856 139.74437897707043 36.8 35.67044606599856 139.74437897707043 40.376 35.67041010352248 139.74436990380192 40.376 35.67041010352248 139.74436990380192 36.8 35.67044606599856 139.74437897707043 36.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-830508d9-f4d5-4687-b1b4-77799f3ec3fd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-830508d9-f4d5-4687-b1b4-77799f3ec3fd_0">
											<gml:posList>35.670444233862455 139.74437579777774 40.376 35.67041046208823 139.7443672191619 40.376 35.67041010352248 139.74436990380192 40.376 35.67044606599856 139.74437897707043 40.376 35.67046849163763 139.74425633857075 40.376 35.67046510157871 139.74425512724724 40.376 35.670444233862455 139.74437579777774 40.376</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0d998939-408b-4ffc-97f6-1995d4d599ca">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0d998939-408b-4ffc-97f6-1995d4d599ca_0">
											<gml:posList>35.670444233862455 139.74437579777774 40.376 35.67046510157871 139.74425512724724 40.376 35.67046510157871 139.74425512724724 36.8 35.67046457202437 139.74425817660648 36.8 35.67046457202437 139.74425817660648 36.077 35.67044687261821 139.74436052890624 36.077 35.67044687261821 139.74436052890624 36.8 35.670444233862455 139.74437579777774 36.8 35.670444233862455 139.74437579777774 40.376</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8a1c9928-3237-4fd6-a600-2e5b072cbbe4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8a1c9928-3237-4fd6-a600-2e5b072cbbe4_0">
											<gml:posList>35.67046563592158 139.74425855099776 36.8 35.67044687261821 139.74436052890624 36.8 35.67044687261821 139.74436052890624 36.077 35.67046563592158 139.74425855099776 36.077 35.67046563592158 139.74425855099776 36.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5c86d835-b3e1-4c66-b950-244953f63ed0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5c86d835-b3e1-4c66-b950-244953f63ed0_0">
											<gml:posList>35.67046849163763 139.74425633857075 40.376 35.67044606599856 139.74437897707043 40.376 35.67044606599856 139.74437897707043 36.8 35.67046849163763 139.74425633857075 36.8 35.67046849163763 139.74425633857075 40.376</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-136d4b9b-1fed-42c9-877e-4b5901b5694a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-136d4b9b-1fed-42c9-877e-4b5901b5694a_0">
											<gml:posList>35.67046563592158 139.74425855099776 36.077 35.67046457202437 139.74425817660648 36.077 35.67046457202437 139.74425817660648 36.8 35.67046563592158 139.74425855099776 36.8 35.67046563592158 139.74425855099776 36.077</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c04f7c8a-6a31-4694-90b4-1c9231f8fb9b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c04f7c8a-6a31-4694-90b4-1c9231f8fb9b_0">
											<gml:posList>35.67046510157871 139.74425512724724 40.376 35.67046849163763 139.74425633857075 40.376 35.67046849163763 139.74425633857075 36.8 35.67046510157871 139.74425512724724 36.8 35.67046510157871 139.74425512724724 40.376</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-c641b014-9d6f-438e-ac36-7e3d2aafc352">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c641b014-9d6f-438e-ac36-7e3d2aafc352">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c641b014-9d6f-438e-ac36-7e3d2aafc352">
											<gml:posList>35.67033370062753 139.74420805050192 7.69 35.67046876200848 139.744256283039 7.69 35.67044613831236 139.74437925314692 7.69 35.67041016686338 139.74437023511956 7.69 35.67040289928097 139.74441564332426 7.69 35.67031300691927 139.74438116825135 7.69 35.67032298987301 139.74433880584593 7.69 35.67030408306505 139.74433202234223 7.69 35.67033370062753 139.74420805050192 7.69</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-2802c8fa-13a9-4b71-be60-1cbeca7351c0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2802c8fa-13a9-4b71-be60-1cbeca7351c0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2802c8fa-13a9-4b71-be60-1cbeca7351c0">
											<gml:posList>35.67032298987301 139.74433880584593 36.8 35.67032626923563 139.74433659295548 36.8 35.670307380463164 139.74432982047824 36.8 35.67030408306505 139.74433202234223 36.8 35.67032298987301 139.74433880584593 36.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-5fb94526-f6b1-42cb-ab05-6fb82b8b75cb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5fb94526-f6b1-42cb-ab05-6fb82b8b75cb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5fb94526-f6b1-42cb-ab05-6fb82b8b75cb">
											<gml:posList>35.67032298987301 139.74433880584593 36.8 35.67031300691927 139.74438116825135 36.8 35.67031627730975 139.74437901060412 36.8 35.67032626923563 139.74433659295548 36.8 35.67032298987301 139.74433880584593 36.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-8df899c6-c67e-41f3-a5bb-6f76598be650">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8df899c6-c67e-41f3-a5bb-6f76598be650">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8df899c6-c67e-41f3-a5bb-6f76598be650">
											<gml:posList>35.67030408306505 139.74433202234223 36.8 35.670307380463164 139.74432982047824 36.8 35.670335506348266 139.744212069331 36.8 35.67033370062753 139.74420805050192 36.8 35.67030408306505 139.74433202234223 36.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a9e8eb29-c6f7-4fbe-9025-146c3af2c790">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a9e8eb29-c6f7-4fbe-9025-146c3af2c790">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a9e8eb29-c6f7-4fbe-9025-146c3af2c790">
											<gml:posList>35.67035614984277 139.74439771186422 36.8 35.670354425210945 139.74439363770867 36.8 35.67031627730975 139.74437901060412 36.8 35.67031300691927 139.74438116825135 36.8 35.67035614984277 139.74439771186422 36.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-23e8d5da-0d4b-42a3-87e3-808ea7bd8d55">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-23e8d5da-0d4b-42a3-87e3-808ea7bd8d55">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-23e8d5da-0d4b-42a3-87e3-808ea7bd8d55">
											<gml:posList>35.670354425210945 139.74439363770867 36.8 35.67035614984277 139.74439771186422 36.8 35.670356940757856 139.7443946069888 36.8 35.670354425210945 139.74439363770867 36.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-22eae298-0759-440c-82c9-3329abf270a0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-22eae298-0759-440c-82c9-3329abf270a0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-22eae298-0759-440c-82c9-3329abf270a0">
											<gml:posList>35.67041016686338 139.74437023511956 40.376 35.67036744741008 139.74435345906903 40.376 35.67035614984277 139.74439771186422 40.376 35.67040289928097 139.74441564332426 40.376 35.67041016686338 139.74437023511956 40.376</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-9a771511-017a-4ada-829b-e28e15e1ce2b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9a771511-017a-4ada-829b-e28e15e1ce2b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9a771511-017a-4ada-829b-e28e15e1ce2b">
											<gml:posList>35.670354425210945 139.74439363770867 36.077 35.670356940757856 139.7443946069888 36.077 35.67036744741008 139.74435345906903 36.077 35.670408634089654 139.74436964032205 36.077 35.670409452037006 139.74436652436805 36.077 35.67041084957224 139.74436707513053 36.077 35.670444134434035 139.74437542231496 36.077 35.67046563592158 139.74425855099776 36.077 35.670335506348266 139.744212069331 36.077 35.670307380463164 139.74432982047824 36.077 35.67032626923563 139.74433659295548 36.077 35.67031627730975 139.74437901060412 36.077 35.670354425210945 139.74439363770867 36.077</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-52c64af8-523d-443d-8666-a166d18170d6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-52c64af8-523d-443d-8666-a166d18170d6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-52c64af8-523d-443d-8666-a166d18170d6">
											<gml:posList>35.67033370062753 139.74420805050192 36.8 35.670335506348266 139.744212069331 36.8 35.67046563592158 139.74425855099776 36.8 35.67046876200848 139.744256283039 36.8 35.67033370062753 139.74420805050192 36.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-bf7c9fdf-e43e-477b-9b90-4230d2f51606">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bf7c9fdf-e43e-477b-9b90-4230d2f51606">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bf7c9fdf-e43e-477b-9b90-4230d2f51606">
											<gml:posList>35.670408634089654 139.74436964032205 36.8 35.67041016686338 139.74437023511956 36.8 35.67041084957224 139.74436707513053 36.8 35.670409452037006 139.74436652436805 36.8 35.670408634089654 139.74436964032205 36.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c8366488-6c34-48d3-b467-29b0f600b441">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c8366488-6c34-48d3-b467-29b0f600b441">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c8366488-6c34-48d3-b467-29b0f600b441">
											<gml:posList>35.67041016686338 139.74437023511956 36.8 35.67044613831236 139.74437925314692 36.8 35.670444134434035 139.74437542231496 36.8 35.67041084957224 139.74436707513053 36.8 35.67041016686338 139.74437023511956 36.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-991bca63-3edb-482a-af92-0d97a27ce291">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-991bca63-3edb-482a-af92-0d97a27ce291">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-991bca63-3edb-482a-af92-0d97a27ce291">
											<gml:posList>35.67046876200848 139.744256283039 36.8 35.67046563592158 139.74425855099776 36.8 35.670444134434035 139.74437542231496 36.8 35.67044613831236 139.74437925314692 36.8 35.67046876200848 139.744256283039 36.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9ed92f02-1ed3-444a-b342-0416a35656c8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9ed92f02-1ed3-444a-b342-0416a35656c8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9ed92f02-1ed3-444a-b342-0416a35656c8">
											<gml:posList>35.67033370062753 139.74420805050192 36.8 35.67046876200848 139.744256283039 36.8 35.67046876200848 139.744256283039 7.69 35.67033370062753 139.74420805050192 7.69 35.67033370062753 139.74420805050192 36.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1188e086-5e22-43de-aca5-c5de9857911b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1188e086-5e22-43de-aca5-c5de9857911b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1188e086-5e22-43de-aca5-c5de9857911b">
											<gml:posList>35.670335506348266 139.744212069331 36.8 35.670335506348266 139.744212069331 36.077 35.67046563592158 139.74425855099776 36.077 35.67046563592158 139.74425855099776 36.8 35.670335506348266 139.744212069331 36.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-481c8565-609c-4a34-a0ff-9ea1772ba8f0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-481c8565-609c-4a34-a0ff-9ea1772ba8f0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-481c8565-609c-4a34-a0ff-9ea1772ba8f0">
											<gml:posList>35.67033370062753 139.74420805050192 7.69 35.67030408306505 139.74433202234223 7.69 35.67030408306505 139.74433202234223 36.8 35.67033370062753 139.74420805050192 36.8 35.67033370062753 139.74420805050192 7.69</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f1a83cc0-d5ea-4762-924a-bfc25d29cb7a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f1a83cc0-d5ea-4762-924a-bfc25d29cb7a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f1a83cc0-d5ea-4762-924a-bfc25d29cb7a">
											<gml:posList>35.670307380463164 139.74432982047824 36.8 35.670307380463164 139.74432982047824 36.077 35.670335506348266 139.744212069331 36.077 35.670335506348266 139.744212069331 36.8 35.670307380463164 139.74432982047824 36.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2f9be3de-a5d2-4b73-b742-6da5d8d5cdfd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2f9be3de-a5d2-4b73-b742-6da5d8d5cdfd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2f9be3de-a5d2-4b73-b742-6da5d8d5cdfd">
											<gml:posList>35.67046563592158 139.74425855099776 36.8 35.67046563592158 139.74425855099776 36.077 35.670444134434035 139.74437542231496 36.077 35.670444134434035 139.74437542231496 36.8 35.67046563592158 139.74425855099776 36.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c466e2df-fb5e-4ea1-a591-4e39170521a0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c466e2df-fb5e-4ea1-a591-4e39170521a0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c466e2df-fb5e-4ea1-a591-4e39170521a0">
											<gml:posList>35.67044613831236 139.74437925314692 7.69 35.67046876200848 139.744256283039 7.69 35.67046876200848 139.744256283039 36.8 35.67044613831236 139.74437925314692 36.8 35.67044613831236 139.74437925314692 7.69</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-89c1c4f1-d870-42ee-acc0-5a21af775634">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-89c1c4f1-d870-42ee-acc0-5a21af775634">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-89c1c4f1-d870-42ee-acc0-5a21af775634">
											<gml:posList>35.67032626923563 139.74433659295548 36.8 35.67032626923563 139.74433659295548 36.077 35.670307380463164 139.74432982047824 36.077 35.670307380463164 139.74432982047824 36.8 35.67032626923563 139.74433659295548 36.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a650b89f-fb3b-4701-bf20-ebc7692e76c3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a650b89f-fb3b-4701-bf20-ebc7692e76c3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a650b89f-fb3b-4701-bf20-ebc7692e76c3">
											<gml:posList>35.67030408306505 139.74433202234223 7.69 35.67032298987301 139.74433880584593 7.69 35.67032298987301 139.74433880584593 36.8 35.67030408306505 139.74433202234223 36.8 35.67030408306505 139.74433202234223 7.69</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3e7e422a-8d95-4f4e-9f42-7078fa531dc7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3e7e422a-8d95-4f4e-9f42-7078fa531dc7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3e7e422a-8d95-4f4e-9f42-7078fa531dc7">
											<gml:posList>35.67031627730975 139.74437901060412 36.8 35.67031627730975 139.74437901060412 36.077 35.67032626923563 139.74433659295548 36.077 35.67032626923563 139.74433659295548 36.8 35.67031627730975 139.74437901060412 36.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a2a20da1-c99d-40a0-93b1-b32ccbacddfa">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a2a20da1-c99d-40a0-93b1-b32ccbacddfa">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a2a20da1-c99d-40a0-93b1-b32ccbacddfa">
											<gml:posList>35.67031300691927 139.74438116825135 36.8 35.67032298987301 139.74433880584593 36.8 35.67032298987301 139.74433880584593 7.69 35.67031300691927 139.74438116825135 7.69 35.67031300691927 139.74438116825135 36.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-09dc0f7e-c1a7-4550-91ee-184117e8fc7a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-09dc0f7e-c1a7-4550-91ee-184117e8fc7a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-09dc0f7e-c1a7-4550-91ee-184117e8fc7a">
											<gml:posList>35.670408634089654 139.74436964032205 36.8 35.670408634089654 139.74436964032205 36.077 35.67036744741008 139.74435345906903 36.077 35.67036744741008 139.74435345906903 40.376 35.67041016686338 139.74437023511956 40.376 35.67041016686338 139.74437023511956 36.8 35.670408634089654 139.74436964032205 36.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-35c0114b-0d3c-4cb0-950c-5587473e36f7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-35c0114b-0d3c-4cb0-950c-5587473e36f7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-35c0114b-0d3c-4cb0-950c-5587473e36f7">
											<gml:posList>35.67041084957224 139.74436707513053 36.8 35.67041084957224 139.74436707513053 36.077 35.670409452037006 139.74436652436805 36.077 35.670409452037006 139.74436652436805 36.8 35.67041084957224 139.74436707513053 36.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b0d81395-2211-4081-b387-5c29cb783908">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b0d81395-2211-4081-b387-5c29cb783908">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b0d81395-2211-4081-b387-5c29cb783908">
											<gml:posList>35.670409452037006 139.74436652436805 36.8 35.670409452037006 139.74436652436805 36.077 35.670408634089654 139.74436964032205 36.077 35.670408634089654 139.74436964032205 36.8 35.670409452037006 139.74436652436805 36.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-43aec4cc-19f2-4ecc-9338-b486cbccca8e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-43aec4cc-19f2-4ecc-9338-b486cbccca8e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-43aec4cc-19f2-4ecc-9338-b486cbccca8e">
											<gml:posList>35.670444134434035 139.74437542231496 36.8 35.670444134434035 139.74437542231496 36.077 35.67041084957224 139.74436707513053 36.077 35.67041084957224 139.74436707513053 36.8 35.670444134434035 139.74437542231496 36.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d694f69b-7ec5-484d-8a97-43a24287547d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d694f69b-7ec5-484d-8a97-43a24287547d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d694f69b-7ec5-484d-8a97-43a24287547d">
											<gml:posList>35.67041016686338 139.74437023511956 7.69 35.67044613831236 139.74437925314692 7.69 35.67044613831236 139.74437925314692 36.8 35.67041016686338 139.74437023511956 36.8 35.67041016686338 139.74437023511956 7.69</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c8037bc4-7f06-415d-bbcf-e636edcfb49d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c8037bc4-7f06-415d-bbcf-e636edcfb49d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c8037bc4-7f06-415d-bbcf-e636edcfb49d">
											<gml:posList>35.670356940757856 139.7443946069888 36.8 35.67035614984277 139.74439771186422 36.8 35.67035614984277 139.74439771186422 40.376 35.67036744741008 139.74435345906903 40.376 35.67036744741008 139.74435345906903 36.077 35.670356940757856 139.7443946069888 36.077 35.670356940757856 139.7443946069888 36.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-612adcd6-a30b-46b8-b93f-c69f46c304bf">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-612adcd6-a30b-46b8-b93f-c69f46c304bf">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-612adcd6-a30b-46b8-b93f-c69f46c304bf">
											<gml:posList>35.670354425210945 139.74439363770867 36.8 35.670354425210945 139.74439363770867 36.077 35.67031627730975 139.74437901060412 36.077 35.67031627730975 139.74437901060412 36.8 35.670354425210945 139.74439363770867 36.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-258970af-cc9b-4629-9099-5beff183f890">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-258970af-cc9b-4629-9099-5beff183f890">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-258970af-cc9b-4629-9099-5beff183f890">
											<gml:posList>35.67040289928097 139.74441564332426 40.376 35.67040289928097 139.74441564332426 7.69 35.67041016686338 139.74437023511956 7.69 35.67041016686338 139.74437023511956 36.8 35.67041016686338 139.74437023511956 40.376 35.67040289928097 139.74441564332426 40.376</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ed235e2f-5857-4074-863c-a66b3faa64e8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ed235e2f-5857-4074-863c-a66b3faa64e8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ed235e2f-5857-4074-863c-a66b3faa64e8">
											<gml:posList>35.670356940757856 139.7443946069888 36.8 35.670356940757856 139.7443946069888 36.077 35.670354425210945 139.74439363770867 36.077 35.670354425210945 139.74439363770867 36.8 35.670356940757856 139.7443946069888 36.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b3464233-5f9e-4e26-97b4-2e30698cd27f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b3464233-5f9e-4e26-97b4-2e30698cd27f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b3464233-5f9e-4e26-97b4-2e30698cd27f">
											<gml:posList>35.67035614984277 139.74439771186422 36.8 35.67031300691927 139.74438116825135 36.8 35.67031300691927 139.74438116825135 7.69 35.67040289928097 139.74441564332426 7.69 35.67040289928097 139.74441564332426 40.376 35.67035614984277 139.74439771186422 40.376 35.67035614984277 139.74439771186422 36.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂一丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-1299</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">237.01589</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1210</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>7</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.15</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>