<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_e95a769c-f32b-4627-9ee7-05f06ac77ac4">
			<core:creationDate>2024-03-15</core:creationDate>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:measuredHeight uom="m">22.4</bldg:measuredHeight>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.67142720718535 139.73927435050842 0 35.67138100939262 139.73928277787576 0 35.671385590754696 139.73932046281092 0 35.67143178855006 139.73931203546485 0 35.67142720718535 139.73927435050842 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67142720718535 139.73927435050842 15.596 35.67143178855006 139.73931203546485 15.596 35.671385590754696 139.73932046281092 15.596 35.67138100939262 139.73928277787576 15.596 35.67142720718535 139.73927435050842 15.596</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67142720718535 139.73927435050842 15.596 35.67138100939262 139.73928277787576 15.596 35.67138100939262 139.73928277787576 38.04 35.67142720718535 139.73927435050842 38.04 35.67142720718535 139.73927435050842 15.596</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67138100939262 139.73928277787576 15.596 35.671385590754696 139.73932046281092 15.596 35.671385590754696 139.73932046281092 38.04 35.67138100939262 139.73928277787576 38.04 35.67138100939262 139.73928277787576 15.596</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671385590754696 139.73932046281092 15.596 35.67143178855006 139.73931203546485 15.596 35.67143178855006 139.73931203546485 38.04 35.671385590754696 139.73932046281092 38.04 35.671385590754696 139.73932046281092 15.596</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67143178855006 139.73931203546485 15.596 35.67142720718535 139.73927435050842 15.596 35.67142720718535 139.73927435050842 38.04 35.67143178855006 139.73931203546485 38.04 35.67143178855006 139.73931203546485 15.596</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67142720718535 139.73927435050842 38.04 35.67138100939262 139.73928277787576 38.04 35.671385590754696 139.73932046281092 38.04 35.67143178855006 139.73931203546485 38.04 35.67142720718535 139.73927435050842 38.04</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-3c7544af-1c1b-4b22-a1ec-0e081ec8d71e"/>
							<gml:surfaceMember xlink:href="#poly-64dc15bd-7ca1-4414-b69f-548bfcace558"/>
							<gml:surfaceMember xlink:href="#poly-5fd16056-83bd-4752-ab4e-11eda0561bf7"/>
							<gml:surfaceMember xlink:href="#poly-6c836bde-5273-455b-8c5a-703bf931ba78"/>
							<gml:surfaceMember xlink:href="#poly-cc7e9aa1-c51a-469d-adba-e0cc236957f0"/>
							<gml:surfaceMember xlink:href="#poly-2148dee9-8b1f-4699-a611-fd2907daf1aa"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-3c7544af-1c1b-4b22-a1ec-0e081ec8d71e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3c7544af-1c1b-4b22-a1ec-0e081ec8d71e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3c7544af-1c1b-4b22-a1ec-0e081ec8d71e">
											<gml:posList>35.67142720718536 139.73927435050842 15.596 35.67143178855005 139.73931203546482 15.596 35.671385590754674 139.73932046281092 15.596 35.67138100939261 139.73928277787573 15.596 35.67142720718536 139.73927435050842 15.596</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-64dc15bd-7ca1-4414-b69f-548bfcace558">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-64dc15bd-7ca1-4414-b69f-548bfcace558">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-64dc15bd-7ca1-4414-b69f-548bfcace558">
											<gml:posList>35.67143178855005 139.73931203546482 21.317 35.67142720718536 139.73927435050842 21.317 35.67138100939261 139.73928277787573 21.317 35.671385590754674 139.73932046281092 21.317 35.67143178855005 139.73931203546482 21.317</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5fd16056-83bd-4752-ab4e-11eda0561bf7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5fd16056-83bd-4752-ab4e-11eda0561bf7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5fd16056-83bd-4752-ab4e-11eda0561bf7">
											<gml:posList>35.67142720718536 139.73927435050842 15.596 35.67138100939261 139.73928277787573 15.596 35.67138100939261 139.73928277787573 21.317 35.67142720718536 139.73927435050842 21.317 35.67142720718536 139.73927435050842 15.596</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6c836bde-5273-455b-8c5a-703bf931ba78">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6c836bde-5273-455b-8c5a-703bf931ba78">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6c836bde-5273-455b-8c5a-703bf931ba78">
											<gml:posList>35.67143178855005 139.73931203546482 15.596 35.67142720718536 139.73927435050842 15.596 35.67142720718536 139.73927435050842 21.317 35.67143178855005 139.73931203546482 21.317 35.67143178855005 139.73931203546482 15.596</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-cc7e9aa1-c51a-469d-adba-e0cc236957f0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cc7e9aa1-c51a-469d-adba-e0cc236957f0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cc7e9aa1-c51a-469d-adba-e0cc236957f0">
											<gml:posList>35.67138100939261 139.73928277787573 15.596 35.671385590754674 139.73932046281092 15.596 35.671385590754674 139.73932046281092 21.317 35.67138100939261 139.73928277787573 21.317 35.67138100939261 139.73928277787573 15.596</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2148dee9-8b1f-4699-a611-fd2907daf1aa">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2148dee9-8b1f-4699-a611-fd2907daf1aa">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2148dee9-8b1f-4699-a611-fd2907daf1aa">
											<gml:posList>35.671385590754674 139.73932046281092 15.596 35.67143178855005 139.73931203546482 15.596 35.67143178855005 139.73931203546482 21.317 35.671385590754674 139.73932046281092 21.317 35.671385590754674 139.73932046281092 15.596</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-8832</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">211</uro:landUseType>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>4</uro:specifiedFloorAreaRate>
					<uro:surveyYear>0001</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>