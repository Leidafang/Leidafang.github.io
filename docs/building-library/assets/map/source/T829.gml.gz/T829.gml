<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_ed393fa7-43f1-4294-bd37-d815a8054312">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>6</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001006</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">402</bldg:usage>
			<bldg:measuredHeight uom="m">11.4</bldg:measuredHeight>
			<bldg:storeysAboveGround>4</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>1</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.67029673197959 139.7376835368493 0 35.67030759768471 139.73767742635727 0 35.67027363234312 139.73758467842595 0 35.6702072299277 139.73762087891333 0 35.67024173676678 139.73771450983668 0 35.67026170128918 139.73777015909127 0 35.67031704012505 139.73774055545962 0 35.67029673197959 139.7376835368493 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67029673197959 139.7376835368493 16.448 35.67031704012505 139.73774055545962 16.448 35.67026170128918 139.73777015909127 16.448 35.67024173676678 139.73771450983668 16.448 35.6702072299277 139.73762087891333 16.448 35.67027363234312 139.73758467842595 16.448 35.67030759768471 139.73767742635727 16.448 35.67029673197959 139.7376835368493 16.448</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67029673197959 139.7376835368493 16.448 35.67030759768471 139.73767742635727 16.448 35.67030759768471 139.73767742635727 27.83 35.67029673197959 139.7376835368493 27.83 35.67029673197959 139.7376835368493 16.448</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67030759768471 139.73767742635727 16.448 35.67027363234312 139.73758467842595 16.448 35.67027363234312 139.73758467842595 27.83 35.67030759768471 139.73767742635727 27.83 35.67030759768471 139.73767742635727 16.448</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67027363234312 139.73758467842595 16.448 35.6702072299277 139.73762087891333 16.448 35.6702072299277 139.73762087891333 27.83 35.67027363234312 139.73758467842595 27.83 35.67027363234312 139.73758467842595 16.448</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6702072299277 139.73762087891333 16.448 35.67024173676678 139.73771450983668 16.448 35.67024173676678 139.73771450983668 27.83 35.6702072299277 139.73762087891333 27.83 35.6702072299277 139.73762087891333 16.448</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67024173676678 139.73771450983668 16.448 35.67026170128918 139.73777015909127 16.448 35.67026170128918 139.73777015909127 27.83 35.67024173676678 139.73771450983668 27.83 35.67024173676678 139.73771450983668 16.448</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67026170128918 139.73777015909127 16.448 35.67031704012505 139.73774055545962 16.448 35.67031704012505 139.73774055545962 27.83 35.67026170128918 139.73777015909127 27.83 35.67026170128918 139.73777015909127 16.448</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67031704012505 139.73774055545962 16.448 35.67029673197959 139.7376835368493 16.448 35.67029673197959 139.7376835368493 27.83 35.67031704012505 139.73774055545962 27.83 35.67031704012505 139.73774055545962 16.448</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67029673197959 139.7376835368493 27.83 35.67030759768471 139.73767742635727 27.83 35.67027363234312 139.73758467842595 27.83 35.6702072299277 139.73762087891333 27.83 35.67024173676678 139.73771450983668 27.83 35.67026170128918 139.73777015909127 27.83 35.67031704012505 139.73774055545962 27.83 35.67029673197959 139.7376835368493 27.83</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-78495fdd-7119-4877-9343-c4bb63796972"/>
							<gml:surfaceMember xlink:href="#poly-22b541d3-cf84-46aa-b74d-e1e8adccaf53"/>
							<gml:surfaceMember xlink:href="#poly-bc01b307-d78a-436e-a327-d4019ee012ae"/>
							<gml:surfaceMember xlink:href="#poly-7075ecad-69fc-4ce9-b0b4-69c19bb64833"/>
							<gml:surfaceMember xlink:href="#poly-4e74d4bf-4ada-486c-a168-4a39ce6afff2"/>
							<gml:surfaceMember xlink:href="#poly-d0eace09-0ac4-488d-b4ba-a85c8e64c730"/>
							<gml:surfaceMember xlink:href="#poly-0ccb707c-54f2-479a-90a3-23c5c62ac773"/>
							<gml:surfaceMember xlink:href="#poly-def18879-25a2-4ed0-8e89-a2eaf510bf3c"/>
							<gml:surfaceMember xlink:href="#poly-a65025b4-c7f4-4d25-a511-cf2ab341891a"/>
							<gml:surfaceMember xlink:href="#poly-97a196a7-1771-4d53-9e49-adc56daaf34e"/>
							<gml:surfaceMember xlink:href="#poly-b487b357-c37e-4c4a-9eed-85ccbceeed00"/>
							<gml:surfaceMember xlink:href="#poly-4f9da730-360c-4a81-98a7-bf03c5659275"/>
							<gml:surfaceMember xlink:href="#poly-58b17407-71a5-4a22-bb06-8305dd1c7161"/>
							<gml:surfaceMember xlink:href="#poly-b804165d-8432-4678-8dad-3fecf8e3433d"/>
							<gml:surfaceMember xlink:href="#poly-c6ce3375-6976-47b6-a2d0-457702a0d65f"/>
							<gml:surfaceMember xlink:href="#poly-f1908b9c-8daa-459e-a17f-0fd1ba4b5c0a"/>
							<gml:surfaceMember xlink:href="#poly-e9b185db-8c3d-4592-9c34-bea78245b96c"/>
							<gml:surfaceMember xlink:href="#poly-00c6573f-f851-4314-893e-e064c0b40dde"/>
							<gml:surfaceMember xlink:href="#poly-6f0de40e-0415-4a17-b36d-451af5adeddb"/>
							<gml:surfaceMember xlink:href="#poly-312c0c00-910b-40ce-8297-8b503ae186fe"/>
							<gml:surfaceMember xlink:href="#poly-45b8d895-93ef-436b-a06b-964c0e116ebe"/>
							<gml:surfaceMember xlink:href="#poly-783b3475-4e47-44e8-8eee-3ddbcce5bf86"/>
							<gml:surfaceMember xlink:href="#poly-856e6a61-7e22-4471-b663-b7f4acb9ec78"/>
							<gml:surfaceMember xlink:href="#poly-004ba909-1466-4420-b75e-66d97130364a"/>
							<gml:surfaceMember xlink:href="#poly-672d586e-f0af-45d8-9aa5-ab4b852ef946"/>
							<gml:surfaceMember xlink:href="#poly-a751e8e3-35f4-468a-a97d-d868cdc1f7ab"/>
							<gml:surfaceMember xlink:href="#poly-258aed3b-8f5b-409b-acba-0a12f41671f1"/>
							<gml:surfaceMember xlink:href="#poly-23db8557-de8e-43db-8341-045d5041733c"/>
							<gml:surfaceMember xlink:href="#poly-e98d6e43-d2e6-4a20-9bfb-11ff8624a7a2"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_ed393fa7-43f1-4294-bd37-d815a8054312_BuildingInstallation_1041">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c15c26f2-4445-4b5a-81a3-b618cfb713de">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67027526706548 139.73762276392546 30.783 35.67024615631007 139.7376386279387 30.783 35.670234349500156 139.73760608876395 30.783 35.670263460251306 139.73759022474127 30.783 35.67027526706548 139.73762276392546 30.783</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3e20dafd-3208-4ed0-a587-c1299442e447">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3e20dafd-3208-4ed0-a587-c1299442e447_0">
											<gml:posList>35.670234349500156 139.73760608876395 31.365 35.670263460251306 139.73759022474127 31.365 35.670263460251306 139.73759022474127 30.783 35.670234349500156 139.73760608876395 30.783 35.670234349500156 139.73760608876395 31.365</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-390c0b08-9f64-4096-a6d1-0dd1353268d7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-390c0b08-9f64-4096-a6d1-0dd1353268d7_0">
											<gml:posList>35.670263460251306 139.73759022474127 30.783 35.670263460251306 139.73759022474127 31.365 35.67027526706548 139.73762276392546 31.365 35.67027526706548 139.73762276392546 30.783 35.670263460251306 139.73759022474127 30.783</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3d87182d-d1bc-4926-a171-67241e204ecd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3d87182d-d1bc-4926-a171-67241e204ecd_0">
											<gml:posList>35.67027526706548 139.73762276392546 31.365 35.670263460251306 139.73759022474127 31.365 35.670234349500156 139.73760608876395 31.365 35.67024615631007 139.7376386279387 31.365 35.67027526706548 139.73762276392546 31.365</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7f1d21f7-9295-417c-b52f-8cbf30c8be43">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7f1d21f7-9295-417c-b52f-8cbf30c8be43_0">
											<gml:posList>35.67024615631007 139.7376386279387 30.783 35.67024615631007 139.7376386279387 31.365 35.670234349500156 139.73760608876395 31.365 35.670234349500156 139.73760608876395 30.783 35.67024615631007 139.7376386279387 30.783</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9062e30d-cf1a-45cc-9f29-43d464272129">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9062e30d-cf1a-45cc-9f29-43d464272129_0">
											<gml:posList>35.67027526706548 139.73762276392546 30.783 35.67027526706548 139.73762276392546 31.365 35.67024615631007 139.7376386279387 31.365 35.67024615631007 139.7376386279387 30.783 35.67027526706548 139.73762276392546 30.783</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_ed393fa7-43f1-4294-bd37-d815a8054312_BuildingInstallation_1060">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-11e80aba-ae3e-49ab-af96-3771199a1245">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670296731988344 139.7376835478955 16.35 35.67030759768471 139.73767742635727 16.35 35.67032855478595 139.73773440001497 16.35 35.67031704012503 139.73774055545962 16.35 35.670296731988344 139.7376835478955 16.35</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7cbde3f0-086d-4330-850c-db1455a4da6a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7cbde3f0-086d-4330-850c-db1455a4da6a_0">
											<gml:posList>35.67030759768471 139.73767742635727 27.745 35.670296731988344 139.7376835478955 16.35 35.670296731988344 139.7376835478955 27.745 35.67030759768471 139.73767742635727 27.745</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-585ce1d9-694d-48a1-af72-f47392369225">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-585ce1d9-694d-48a1-af72-f47392369225_0">
											<gml:posList>35.67030759768471 139.73767742635727 27.745 35.67030759768471 139.73767742635727 16.35 35.670296731988344 139.7376835478955 16.35 35.67030759768471 139.73767742635727 27.745</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0c7c91e8-0b16-41db-b303-d561c66a567d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0c7c91e8-0b16-41db-b303-d561c66a567d_0">
											<gml:posList>35.67031704012503 139.73774055545962 27.745 35.67030759768471 139.73767742635727 27.745 35.670296731988344 139.7376835478955 27.745 35.67031704012503 139.73774055545962 27.745</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-54e8ba8b-0b9b-4caf-97ba-792882c014ef">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-54e8ba8b-0b9b-4caf-97ba-792882c014ef_0">
											<gml:posList>35.670296731988344 139.7376835478955 27.745 35.67031704012503 139.73774055545962 16.35 35.67031704012503 139.73774055545962 27.745 35.670296731988344 139.7376835478955 27.745</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e32ee820-0a2b-43b9-aa9c-2c06914f9684">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e32ee820-0a2b-43b9-aa9c-2c06914f9684_0">
											<gml:posList>35.670296731988344 139.7376835478955 27.745 35.670296731988344 139.7376835478955 16.35 35.67031704012503 139.73774055545962 16.35 35.670296731988344 139.7376835478955 27.745</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-38918eea-c2fb-4bc7-8f24-cb08bbe7d568">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-38918eea-c2fb-4bc7-8f24-cb08bbe7d568_0">
											<gml:posList>35.67032855478595 139.73773440001497 27.745 35.67030759768471 139.73767742635727 16.35 35.67030759768471 139.73767742635727 27.745 35.67032855478595 139.73773440001497 27.745</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-95f6ca1e-19c3-45e5-98ff-6ee9fca432e4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-95f6ca1e-19c3-45e5-98ff-6ee9fca432e4_0">
											<gml:posList>35.67031704012503 139.73774055545962 27.745 35.67032855478595 139.73773440001497 27.745 35.67030759768471 139.73767742635727 27.745 35.67031704012503 139.73774055545962 27.745</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bad1f45f-89a4-4b98-a780-f4aee08eae3a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bad1f45f-89a4-4b98-a780-f4aee08eae3a_0">
											<gml:posList>35.67032855478595 139.73773440001497 27.745 35.67032855478595 139.73773440001497 16.35 35.67030759768471 139.73767742635727 16.35 35.67032855478595 139.73773440001497 27.745</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-190ac508-9b55-4b88-ada1-864c1062e595">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-190ac508-9b55-4b88-ada1-864c1062e595_0">
											<gml:posList>35.67031704012503 139.73774055545962 27.745 35.67031704012503 139.73774055545962 16.35 35.67032855478595 139.73773440001497 16.35 35.67031704012503 139.73774055545962 27.745</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0f2aeb54-1477-45a6-8dbe-ec945e3a62c1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0f2aeb54-1477-45a6-8dbe-ec945e3a62c1_0">
											<gml:posList>35.67031704012503 139.73774055545962 27.745 35.67032855478595 139.73773440001497 16.35 35.67032855478595 139.73773440001497 27.745 35.67031704012503 139.73774055545962 27.745</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-78495fdd-7119-4877-9343-c4bb63796972">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-78495fdd-7119-4877-9343-c4bb63796972">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-78495fdd-7119-4877-9343-c4bb63796972">
											<gml:posList>35.67029673197957 139.7376835368493 16.448 35.67031704012503 139.73774055545962 16.448 35.67026170128918 139.73777015909124 16.448 35.67024173676675 139.73771450983668 16.448 35.67020722992768 139.73762087891333 16.448 35.670273632343125 139.73758467842595 16.448 35.67030759768471 139.73767742635727 16.448 35.67029673197957 139.7376835368493 16.448</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-22b541d3-cf84-46aa-b74d-e1e8adccaf53">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-22b541d3-cf84-46aa-b74d-e1e8adccaf53">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-22b541d3-cf84-46aa-b74d-e1e8adccaf53">
											<gml:posList>35.670273632343125 139.73758467842595 30.783 35.670234349500156 139.73760608876395 30.783 35.67024615631007 139.7376386279387 30.783 35.67028552926088 139.7376171733209 30.783 35.670273632343125 139.73758467842595 30.783</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-bc01b307-d78a-436e-a327-d4019ee012ae">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bc01b307-d78a-436e-a327-d4019ee012ae">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bc01b307-d78a-436e-a327-d4019ee012ae">
											<gml:posList>35.67028552926088 139.7376171733209 28.576 35.67025525623652 139.73763366836127 28.576 35.67025652763663 139.73763425229455 28.576 35.6702850527541 139.73761870931796 28.576 35.67028552926088 139.7376171733209 28.576</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-7075ecad-69fc-4ce9-b0b4-69c19bb64833">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7075ecad-69fc-4ce9-b0b4-69c19bb64833">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7075ecad-69fc-4ce9-b0b4-69c19bb64833">
											<gml:posList>35.67030759768471 139.73767742635727 28.576 35.67028552926088 139.7376171733209 28.576 35.6702850527541 139.73761870931796 28.576 35.670306344321034 139.73767685344765 28.576 35.67030759768471 139.73767742635727 28.576</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-4e74d4bf-4ada-486c-a168-4a39ce6afff2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4e74d4bf-4ada-486c-a168-4a39ce6afff2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4e74d4bf-4ada-486c-a168-4a39ce6afff2">
											<gml:posList>35.67025652763663 139.73763425229455 28.334 35.67027839622351 139.7376925835056 28.334 35.67029633453344 139.73768247688363 28.334 35.670306344321034 139.73767685344765 28.334 35.6702850527541 139.73761870931796 28.334 35.67025652763663 139.73763425229455 28.334</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d0eace09-0ac4-488d-b4ba-a85c8e64c730">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d0eace09-0ac4-488d-b4ba-a85c8e64c730">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d0eace09-0ac4-488d-b4ba-a85c8e64c730">
											<gml:posList>35.67024615631007 139.7376386279387 28.576 35.670234349500156 139.73760608876395 28.576 35.67020722992768 139.73762087891333 26.719 35.67024173676675 139.73771450983668 26.719 35.67024615631007 139.7376386279387 28.576</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-0ccb707c-54f2-479a-90a3-23c5c62ac773">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0ccb707c-54f2-479a-90a3-23c5c62ac773">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0ccb707c-54f2-479a-90a3-23c5c62ac773">
											<gml:posList>35.67025525623652 139.73763366836127 28.576 35.67027792873827 139.73769413053753 28.576 35.67027839622351 139.7376925835056 28.576 35.67025652763663 139.73763425229455 28.576 35.67025525623652 139.73763366836127 28.576</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-def18879-25a2-4ed0-8e89-a2eaf510bf3c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-def18879-25a2-4ed0-8e89-a2eaf510bf3c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-def18879-25a2-4ed0-8e89-a2eaf510bf3c">
											<gml:posList>35.67024173676675 139.73771450983668 26.719 35.67027792873827 139.73769413053753 28.576 35.67025525623652 139.73763366836127 28.576 35.67024173676675 139.73771450983668 26.719</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a65025b4-c7f4-4d25-a511-cf2ab341891a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a65025b4-c7f4-4d25-a511-cf2ab341891a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a65025b4-c7f4-4d25-a511-cf2ab341891a">
											<gml:posList>35.67024173676675 139.73771450983668 26.719 35.67025525623652 139.73763366836127 28.576 35.67024615631007 139.7376386279387 28.576 35.67024173676675 139.73771450983668 26.719</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-97a196a7-1771-4d53-9e49-adc56daaf34e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-97a196a7-1771-4d53-9e49-adc56daaf34e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-97a196a7-1771-4d53-9e49-adc56daaf34e">
											<gml:posList>35.67029673197957 139.7376835368493 28.576 35.67030759768471 139.73767742635727 28.576 35.670306344321034 139.73767685344765 28.576 35.67029633453344 139.73768247688363 28.576 35.67029673197957 139.7376835368493 28.576</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b487b357-c37e-4c4a-9eed-85ccbceeed00">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b487b357-c37e-4c4a-9eed-85ccbceeed00">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b487b357-c37e-4c4a-9eed-85ccbceeed00">
											<gml:posList>35.67027792873827 139.73769413053753 28.576 35.67029673197957 139.7376835368493 28.576 35.67029633453344 139.73768247688363 28.576 35.67027839622351 139.7376925835056 28.576 35.67027792873827 139.73769413053753 28.576</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-4f9da730-360c-4a81-98a7-bf03c5659275">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4f9da730-360c-4a81-98a7-bf03c5659275">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4f9da730-360c-4a81-98a7-bf03c5659275">
											<gml:posList>35.67031704012503 139.73774055545962 29.938 35.67029673197957 139.7376835368493 29.938 35.67024173676675 139.73771450983668 29.938 35.67026170128918 139.73777015909124 29.938 35.67031704012503 139.73774055545962 29.938</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-58b17407-71a5-4a22-bb06-8305dd1c7161">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-58b17407-71a5-4a22-bb06-8305dd1c7161">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-58b17407-71a5-4a22-bb06-8305dd1c7161">
											<gml:posList>35.67025652763663 139.73763425229455 28.576 35.67027839622351 139.7376925835056 28.576 35.67027839622351 139.7376925835056 28.334 35.67025652763663 139.73763425229455 28.334 35.67025652763663 139.73763425229455 28.576</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b804165d-8432-4678-8dad-3fecf8e3433d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b804165d-8432-4678-8dad-3fecf8e3433d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b804165d-8432-4678-8dad-3fecf8e3433d">
											<gml:posList>35.67020722992768 139.73762087891333 16.448 35.67024173676675 139.73771450983668 16.448 35.67024173676675 139.73771450983668 26.719 35.67020722992768 139.73762087891333 26.719 35.67020722992768 139.73762087891333 16.448</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c6ce3375-6976-47b6-a2d0-457702a0d65f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c6ce3375-6976-47b6-a2d0-457702a0d65f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c6ce3375-6976-47b6-a2d0-457702a0d65f">
											<gml:posList>35.670234349500156 139.73760608876395 28.576 35.67024615631007 139.7376386279387 28.576 35.67024615631007 139.7376386279387 30.783 35.670234349500156 139.73760608876395 30.783 35.670234349500156 139.73760608876395 28.576</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f1908b9c-8daa-459e-a17f-0fd1ba4b5c0a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f1908b9c-8daa-459e-a17f-0fd1ba4b5c0a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f1908b9c-8daa-459e-a17f-0fd1ba4b5c0a">
											<gml:posList>35.670273632343125 139.73758467842595 16.448 35.67020722992768 139.73762087891333 16.448 35.67020722992768 139.73762087891333 26.719 35.670234349500156 139.73760608876395 28.576 35.670273632343125 139.73758467842595 28.576 35.670273632343125 139.73758467842595 16.448</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e9b185db-8c3d-4592-9c34-bea78245b96c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e9b185db-8c3d-4592-9c34-bea78245b96c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e9b185db-8c3d-4592-9c34-bea78245b96c">
											<gml:posList>35.67026170128918 139.73777015909124 29.938 35.67024173676675 139.73771450983668 29.938 35.67024173676675 139.73771450983668 26.719 35.67024173676675 139.73771450983668 16.448 35.67026170128918 139.73777015909124 16.448 35.67026170128918 139.73777015909124 29.938</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-00c6573f-f851-4314-893e-e064c0b40dde">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-00c6573f-f851-4314-893e-e064c0b40dde">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-00c6573f-f851-4314-893e-e064c0b40dde">
											<gml:posList>35.670273632343125 139.73758467842595 28.576 35.670234349500156 139.73760608876395 28.576 35.670234349500156 139.73760608876395 30.783 35.670273632343125 139.73758467842595 30.783 35.670273632343125 139.73758467842595 28.576</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6f0de40e-0415-4a17-b36d-451af5adeddb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6f0de40e-0415-4a17-b36d-451af5adeddb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6f0de40e-0415-4a17-b36d-451af5adeddb">
											<gml:posList>35.67028552926088 139.7376171733209 30.783 35.67024615631007 139.7376386279387 30.783 35.67024615631007 139.7376386279387 28.576 35.67025525623652 139.73763366836127 28.576 35.67028552926088 139.7376171733209 28.576 35.67028552926088 139.7376171733209 30.783</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-312c0c00-910b-40ce-8297-8b503ae186fe">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-312c0c00-910b-40ce-8297-8b503ae186fe">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-312c0c00-910b-40ce-8297-8b503ae186fe">
											<gml:posList>35.67027792873827 139.73769413053753 28.576 35.67024173676675 139.73771450983668 26.719 35.67024173676675 139.73771450983668 29.938 35.67029673197957 139.7376835368493 29.938 35.67029673197957 139.7376835368493 28.576 35.67027792873827 139.73769413053753 28.576</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-45b8d895-93ef-436b-a06b-964c0e116ebe">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-45b8d895-93ef-436b-a06b-964c0e116ebe">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-45b8d895-93ef-436b-a06b-964c0e116ebe">
											<gml:posList>35.6702850527541 139.73761870931796 28.576 35.67025652763663 139.73763425229455 28.576 35.67025652763663 139.73763425229455 28.334 35.6702850527541 139.73761870931796 28.334 35.6702850527541 139.73761870931796 28.576</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-783b3475-4e47-44e8-8eee-3ddbcce5bf86">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-783b3475-4e47-44e8-8eee-3ddbcce5bf86">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-783b3475-4e47-44e8-8eee-3ddbcce5bf86">
											<gml:posList>35.67028552926088 139.7376171733209 28.576 35.670273632343125 139.73758467842595 28.576 35.670273632343125 139.73758467842595 30.783 35.67028552926088 139.7376171733209 30.783 35.67028552926088 139.7376171733209 28.576</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-856e6a61-7e22-4471-b663-b7f4acb9ec78">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-856e6a61-7e22-4471-b663-b7f4acb9ec78">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-856e6a61-7e22-4471-b663-b7f4acb9ec78">
											<gml:posList>35.67027839622351 139.7376925835056 28.576 35.67029633453344 139.73768247688363 28.576 35.67029633453344 139.73768247688363 28.334 35.67027839622351 139.7376925835056 28.334 35.67027839622351 139.7376925835056 28.576</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-004ba909-1466-4420-b75e-66d97130364a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-004ba909-1466-4420-b75e-66d97130364a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-004ba909-1466-4420-b75e-66d97130364a">
											<gml:posList>35.67026170128918 139.73777015909124 16.448 35.67031704012503 139.73774055545962 16.448 35.67031704012503 139.73774055545962 29.938 35.67026170128918 139.73777015909124 29.938 35.67026170128918 139.73777015909124 16.448</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-672d586e-f0af-45d8-9aa5-ab4b852ef946">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-672d586e-f0af-45d8-9aa5-ab4b852ef946">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-672d586e-f0af-45d8-9aa5-ab4b852ef946">
											<gml:posList>35.67030759768471 139.73767742635727 16.448 35.670273632343125 139.73758467842595 16.448 35.670273632343125 139.73758467842595 28.576 35.67028552926088 139.7376171733209 28.576 35.67030759768471 139.73767742635727 28.576 35.67030759768471 139.73767742635727 16.448</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a751e8e3-35f4-468a-a97d-d868cdc1f7ab">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a751e8e3-35f4-468a-a97d-d868cdc1f7ab">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a751e8e3-35f4-468a-a97d-d868cdc1f7ab">
											<gml:posList>35.670306344321034 139.73767685344765 28.576 35.6702850527541 139.73761870931796 28.576 35.6702850527541 139.73761870931796 28.334 35.670306344321034 139.73767685344765 28.334 35.670306344321034 139.73767685344765 28.576</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-258aed3b-8f5b-409b-acba-0a12f41671f1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-258aed3b-8f5b-409b-acba-0a12f41671f1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-258aed3b-8f5b-409b-acba-0a12f41671f1">
											<gml:posList>35.67029633453344 139.73768247688363 28.576 35.670306344321034 139.73767685344765 28.576 35.670306344321034 139.73767685344765 28.334 35.67029633453344 139.73768247688363 28.334 35.67029633453344 139.73768247688363 28.576</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-23db8557-de8e-43db-8341-045d5041733c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-23db8557-de8e-43db-8341-045d5041733c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-23db8557-de8e-43db-8341-045d5041733c">
											<gml:posList>35.67030759768471 139.73767742635727 16.448 35.67030759768471 139.73767742635727 28.576 35.67029673197957 139.7376835368493 28.576 35.67029673197957 139.7376835368493 16.448 35.67030759768471 139.73767742635727 16.448</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e98d6e43-d2e6-4a20-9bfb-11ff8624a7a2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e98d6e43-d2e6-4a20-9bfb-11ff8624a7a2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e98d6e43-d2e6-4a20-9bfb-11ff8624a7a2">
											<gml:posList>35.67031704012503 139.73774055545962 29.938 35.67031704012503 139.73774055545962 16.448 35.67029673197957 139.7376835368493 16.448 35.67029673197957 139.7376835368493 28.576 35.67029673197957 139.7376835368493 29.938 35.67031704012503 139.73774055545962 29.938</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂六丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-2902</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">54.70036</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1002</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">6</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1242</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.6</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>4</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">12</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>