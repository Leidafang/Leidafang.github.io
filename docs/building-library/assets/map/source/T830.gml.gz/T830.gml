<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_edcc675c-3cb7-4779-9881-b167f9779602">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="地区計画">
				<gen:value>赤坂二丁目地区</gen:value>
			</gen:stringAttribute>
			<bldg:measuredHeight uom="m">6.3</bldg:measuredHeight>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.67012044762931 139.7401515176657 0 35.67012651735833 139.7401793250048 0 35.6701612564836 139.74016794016615 0 35.670155186751934 139.7401401328159 0 35.67012044762931 139.7401515176657 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67012044762931 139.7401515176657 11.234 35.670155186751934 139.7401401328159 11.234 35.6701612564836 139.74016794016615 11.234 35.67012651735833 139.7401793250048 11.234 35.67012044762931 139.7401515176657 11.234</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67012044762931 139.7401515176657 11.234 35.67012651735833 139.7401793250048 11.234 35.67012651735833 139.7401793250048 17.58 35.67012044762931 139.7401515176657 17.58 35.67012044762931 139.7401515176657 11.234</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67012651735833 139.7401793250048 11.234 35.6701612564836 139.74016794016615 11.234 35.6701612564836 139.74016794016615 17.58 35.67012651735833 139.7401793250048 17.58 35.67012651735833 139.7401793250048 11.234</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6701612564836 139.74016794016615 11.234 35.670155186751934 139.7401401328159 11.234 35.670155186751934 139.7401401328159 17.58 35.6701612564836 139.74016794016615 17.58 35.6701612564836 139.74016794016615 11.234</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670155186751934 139.7401401328159 11.234 35.67012044762931 139.7401515176657 11.234 35.67012044762931 139.7401515176657 17.58 35.670155186751934 139.7401401328159 17.58 35.670155186751934 139.7401401328159 11.234</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67012044762931 139.7401515176657 17.58 35.67012651735833 139.7401793250048 17.58 35.6701612564836 139.74016794016615 17.58 35.670155186751934 139.7401401328159 17.58 35.67012044762931 139.7401515176657 17.58</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-f032ed18-7247-4630-bcc6-0f3a002d0c98"/>
							<gml:surfaceMember xlink:href="#poly-865cb137-c962-4388-9230-64fb18610fb0"/>
							<gml:surfaceMember xlink:href="#poly-2789330f-39c8-4d88-9376-a16b86370500"/>
							<gml:surfaceMember xlink:href="#poly-0eb8a056-a573-4c87-a776-200d7fd45b10"/>
							<gml:surfaceMember xlink:href="#poly-16821c2d-bdc0-4ee7-8f3e-6c9ba328b8c9"/>
							<gml:surfaceMember xlink:href="#poly-03141802-21bd-40ac-8314-3fc2915399c2"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-f032ed18-7247-4630-bcc6-0f3a002d0c98">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f032ed18-7247-4630-bcc6-0f3a002d0c98">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f032ed18-7247-4630-bcc6-0f3a002d0c98">
											<gml:posList>35.67012044762931 139.7401515176657 11.234 35.670155186751956 139.7401401328159 11.234 35.67016125648359 139.74016794016612 11.234 35.670126517358334 139.74017932500476 11.234 35.67012044762931 139.7401515176657 11.234</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-865cb137-c962-4388-9230-64fb18610fb0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-865cb137-c962-4388-9230-64fb18610fb0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-865cb137-c962-4388-9230-64fb18610fb0">
											<gml:posList>35.670155186751956 139.7401401328159 17.577 35.67012044762931 139.7401515176657 17.577 35.670126517358334 139.74017932500476 17.577 35.67016125648359 139.74016794016612 17.577 35.670155186751956 139.7401401328159 17.577</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2789330f-39c8-4d88-9376-a16b86370500">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2789330f-39c8-4d88-9376-a16b86370500">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2789330f-39c8-4d88-9376-a16b86370500">
											<gml:posList>35.670155186751956 139.7401401328159 11.234 35.67012044762931 139.7401515176657 11.234 35.67012044762931 139.7401515176657 17.577 35.670155186751956 139.7401401328159 17.577 35.670155186751956 139.7401401328159 11.234</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0eb8a056-a573-4c87-a776-200d7fd45b10">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0eb8a056-a573-4c87-a776-200d7fd45b10">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0eb8a056-a573-4c87-a776-200d7fd45b10">
											<gml:posList>35.67016125648359 139.74016794016612 11.234 35.670155186751956 139.7401401328159 11.234 35.670155186751956 139.7401401328159 17.577 35.67016125648359 139.74016794016612 17.577 35.67016125648359 139.74016794016612 11.234</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-16821c2d-bdc0-4ee7-8f3e-6c9ba328b8c9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-16821c2d-bdc0-4ee7-8f3e-6c9ba328b8c9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-16821c2d-bdc0-4ee7-8f3e-6c9ba328b8c9">
											<gml:posList>35.67012044762931 139.7401515176657 11.234 35.670126517358334 139.74017932500476 11.234 35.670126517358334 139.74017932500476 17.577 35.67012044762931 139.7401515176657 17.577 35.67012044762931 139.7401515176657 11.234</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-03141802-21bd-40ac-8314-3fc2915399c2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-03141802-21bd-40ac-8314-3fc2915399c2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-03141802-21bd-40ac-8314-3fc2915399c2">
											<gml:posList>35.670126517358334 139.74017932500476 11.234 35.67016125648359 139.74016794016612 11.234 35.67016125648359 139.74016794016612 17.577 35.670126517358334 139.74017932500476 17.577 35.670126517358334 139.74017932500476 11.234</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-1261</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">211</uro:landUseType>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>4</uro:specifiedFloorAreaRate>
					<uro:surveyYear>0001</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>