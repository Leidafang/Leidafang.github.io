<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_ee2b6b04-0653-4997-9503-0d8c77966227">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>29</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103029002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">412</bldg:usage>
			<bldg:measuredHeight uom="m">8.4</bldg:measuredHeight>
			<bldg:storeysAboveGround>3</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.66688004886961 139.73826340677448 0 35.66697477815873 139.73837121183334 0 35.667043301509146 139.73828099696033 0 35.66694848191582 139.7381730815655 0 35.66688004886961 139.73826340677448 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66688004886961 139.73826340677448 12.98 35.66694848191582 139.7381730815655 12.98 35.667043301509146 139.73828099696033 12.98 35.66697477815873 139.73837121183334 12.98 35.66688004886961 139.73826340677448 12.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66688004886961 139.73826340677448 12.98 35.66697477815873 139.73837121183334 12.98 35.66697477815873 139.73837121183334 21.35 35.66688004886961 139.73826340677448 21.35 35.66688004886961 139.73826340677448 12.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66697477815873 139.73837121183334 12.98 35.667043301509146 139.73828099696033 12.98 35.667043301509146 139.73828099696033 21.35 35.66697477815873 139.73837121183334 21.35 35.66697477815873 139.73837121183334 12.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667043301509146 139.73828099696033 12.98 35.66694848191582 139.7381730815655 12.98 35.66694848191582 139.7381730815655 21.35 35.667043301509146 139.73828099696033 21.35 35.667043301509146 139.73828099696033 12.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66694848191582 139.7381730815655 12.98 35.66688004886961 139.73826340677448 12.98 35.66688004886961 139.73826340677448 21.35 35.66694848191582 139.7381730815655 21.35 35.66694848191582 139.7381730815655 12.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66688004886961 139.73826340677448 21.35 35.66697477815873 139.73837121183334 21.35 35.667043301509146 139.73828099696033 21.35 35.66694848191582 139.7381730815655 21.35 35.66688004886961 139.73826340677448 21.35</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-5a84fd25-aeb2-4f8e-8716-a5badd1f644d"/>
							<gml:surfaceMember xlink:href="#poly-e2c48ed0-13fd-4368-8c26-af73922846ad"/>
							<gml:surfaceMember xlink:href="#poly-6fa7e51f-e28d-44d6-88e5-564add243a73"/>
							<gml:surfaceMember xlink:href="#poly-d1908b7c-feba-4b84-8a98-0e9a636b2382"/>
							<gml:surfaceMember xlink:href="#poly-0dc3df8b-0d96-4e55-bedc-3d4217226695"/>
							<gml:surfaceMember xlink:href="#poly-03c742ed-425a-48f6-a123-2212690ae62d"/>
							<gml:surfaceMember xlink:href="#poly-46b1dc1f-0e2a-4d53-bf4e-0db71d049f7c"/>
							<gml:surfaceMember xlink:href="#poly-60c42cd9-1cee-445c-bff9-1e8b7a6b11b8"/>
							<gml:surfaceMember xlink:href="#poly-e44a2584-ea28-406b-9d49-74796cf44aba"/>
							<gml:surfaceMember xlink:href="#poly-dd1a14cd-82e3-4a47-9ac0-01f8be3d4fb8"/>
							<gml:surfaceMember xlink:href="#poly-513bd797-1a6d-4346-ae68-ddc3a8ab5ebe"/>
							<gml:surfaceMember xlink:href="#poly-1e24ce53-6a5e-450b-a6ee-0a00df4b24cf"/>
							<gml:surfaceMember xlink:href="#poly-3e604474-3c02-4859-b4ca-61bb1fb0d3d3"/>
							<gml:surfaceMember xlink:href="#poly-80cf5bc2-5b61-43e6-8805-7453822952cf"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_ee2b6b04-0653-4997-9503-0d8c77966227_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d36953ec-efd0-491a-98cd-dc10b3a21b8d">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.666931832349434 139.73826285936593 21.218 35.666931940431674 139.7382513384849 21.218 35.66694455980687 139.7382515223457 21.218 35.666944460729624 139.7382630321721 21.218 35.666931832349434 139.73826285936593 21.218</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fe1984c8-5289-4a22-9304-902194d01f8b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fe1984c8-5289-4a22-9304-902194d01f8b_0">
											<gml:posList>35.666931940431674 139.7382513384849 21.218 35.666931940431674 139.7382513384849 25.159 35.66694455980687 139.7382515223457 25.159 35.66694455980687 139.7382515223457 21.218 35.666931940431674 139.7382513384849 21.218</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8b5cf1cd-05fd-4b20-8f0b-aa48b3c69136">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8b5cf1cd-05fd-4b20-8f0b-aa48b3c69136_0">
											<gml:posList>35.666931832349434 139.73826285936593 21.218 35.666931832349434 139.73826285936593 25.159 35.666931940431674 139.7382513384849 25.159 35.666931940431674 139.7382513384849 21.218 35.666931832349434 139.73826285936593 21.218</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5e629973-f3d0-42a9-a655-cfcb52dffdd4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5e629973-f3d0-42a9-a655-cfcb52dffdd4_0">
											<gml:posList>35.66694455980687 139.7382515223457 25.159 35.666931940431674 139.7382513384849 25.159 35.666931832349434 139.73826285936593 25.159 35.666944460729624 139.7382630321721 25.159 35.66694455980687 139.7382515223457 25.159</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-436482a3-9315-45ec-bd0a-82e592b7150b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-436482a3-9315-45ec-bd0a-82e592b7150b_0">
											<gml:posList>35.66694455980687 139.7382515223457 21.218 35.66694455980687 139.7382515223457 25.159 35.666944460729624 139.7382630321721 25.159 35.666944460729624 139.7382630321721 21.218 35.66694455980687 139.7382515223457 21.218</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-803b7180-e058-44f5-aebb-58a0a99f5e10">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-803b7180-e058-44f5-aebb-58a0a99f5e10_0">
											<gml:posList>35.666944460729624 139.7382630321721 21.218 35.666944460729624 139.7382630321721 25.159 35.666931832349434 139.73826285936593 25.159 35.666931832349434 139.73826285936593 21.218 35.666944460729624 139.7382630321721 21.218</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-5a84fd25-aeb2-4f8e-8716-a5badd1f644d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5a84fd25-aeb2-4f8e-8716-a5badd1f644d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5a84fd25-aeb2-4f8e-8716-a5badd1f644d">
											<gml:posList>35.666880048869594 139.73826340677445 12.98 35.66694848191582 139.73817308156546 12.98 35.667043301509146 139.7382809969603 12.98 35.666974778158696 139.73837121183334 12.98 35.666880048869594 139.73826340677445 12.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e2c48ed0-13fd-4368-8c26-af73922846ad">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e2c48ed0-13fd-4368-8c26-af73922846ad">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e2c48ed0-13fd-4368-8c26-af73922846ad">
											<gml:posList>35.666880048869594 139.73826340677445 22.036 35.66688240137395 139.73826330457337 22.036 35.666948565317576 139.73817596441677 22.036 35.66694848191582 139.73817308156546 22.036 35.666880048869594 139.73826340677445 22.036</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-6fa7e51f-e28d-44d6-88e5-564add243a73">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6fa7e51f-e28d-44d6-88e5-564add243a73">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6fa7e51f-e28d-44d6-88e5-564add243a73">
											<gml:posList>35.66694848191582 139.73817308156546 22.036 35.666948565317576 139.73817596441677 22.036 35.66704093998239 139.738281088126 22.036 35.667043301509146 139.7382809969603 22.036 35.66694848191582 139.73817308156546 22.036</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d1908b7c-feba-4b84-8a98-0e9a636b2382">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d1908b7c-feba-4b84-8a98-0e9a636b2382">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d1908b7c-feba-4b84-8a98-0e9a636b2382">
											<gml:posList>35.66704093998239 139.738281088126 21.218 35.666948565317576 139.73817596441677 21.218 35.66688240137395 139.73826330457337 21.218 35.66697468573916 139.7383683179458 21.218 35.66704093998239 139.738281088126 21.218</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-0dc3df8b-0d96-4e55-bedc-3d4217226695">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0dc3df8b-0d96-4e55-bedc-3d4217226695">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0dc3df8b-0d96-4e55-bedc-3d4217226695">
											<gml:posList>35.666974778158696 139.73837121183334 22.036 35.66697468573916 139.7383683179458 22.036 35.66688240137395 139.73826330457337 22.036 35.666880048869594 139.73826340677445 22.036 35.666974778158696 139.73837121183334 22.036</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-03c742ed-425a-48f6-a123-2212690ae62d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-03c742ed-425a-48f6-a123-2212690ae62d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-03c742ed-425a-48f6-a123-2212690ae62d">
											<gml:posList>35.667043301509146 139.7382809969603 22.036 35.66704093998239 139.738281088126 22.036 35.66697468573916 139.7383683179458 22.036 35.666974778158696 139.73837121183334 22.036 35.667043301509146 139.7382809969603 22.036</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-46b1dc1f-0e2a-4d53-bf4e-0db71d049f7c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-46b1dc1f-0e2a-4d53-bf4e-0db71d049f7c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-46b1dc1f-0e2a-4d53-bf4e-0db71d049f7c">
											<gml:posList>35.66697468573916 139.7383683179458 22.036 35.66697468573916 139.7383683179458 21.218 35.66688240137395 139.73826330457337 21.218 35.66688240137395 139.73826330457337 22.036 35.66697468573916 139.7383683179458 22.036</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-60c42cd9-1cee-445c-bff9-1e8b7a6b11b8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-60c42cd9-1cee-445c-bff9-1e8b7a6b11b8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-60c42cd9-1cee-445c-bff9-1e8b7a6b11b8">
											<gml:posList>35.666948565317576 139.73817596441677 22.036 35.666948565317576 139.73817596441677 21.218 35.66704093998239 139.738281088126 21.218 35.66704093998239 139.738281088126 22.036 35.666948565317576 139.73817596441677 22.036</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e44a2584-ea28-406b-9d49-74796cf44aba">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e44a2584-ea28-406b-9d49-74796cf44aba">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e44a2584-ea28-406b-9d49-74796cf44aba">
											<gml:posList>35.66694848191582 139.73817308156546 12.98 35.666880048869594 139.73826340677445 12.98 35.666880048869594 139.73826340677445 22.036 35.66694848191582 139.73817308156546 22.036 35.66694848191582 139.73817308156546 12.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-dd1a14cd-82e3-4a47-9ac0-01f8be3d4fb8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-dd1a14cd-82e3-4a47-9ac0-01f8be3d4fb8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-dd1a14cd-82e3-4a47-9ac0-01f8be3d4fb8">
											<gml:posList>35.66688240137395 139.73826330457337 22.036 35.66688240137395 139.73826330457337 21.218 35.666948565317576 139.73817596441677 21.218 35.666948565317576 139.73817596441677 22.036 35.66688240137395 139.73826330457337 22.036</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-513bd797-1a6d-4346-ae68-ddc3a8ab5ebe">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-513bd797-1a6d-4346-ae68-ddc3a8ab5ebe">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-513bd797-1a6d-4346-ae68-ddc3a8ab5ebe">
											<gml:posList>35.667043301509146 139.7382809969603 12.98 35.66694848191582 139.73817308156546 12.98 35.66694848191582 139.73817308156546 22.036 35.667043301509146 139.7382809969603 22.036 35.667043301509146 139.7382809969603 12.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1e24ce53-6a5e-450b-a6ee-0a00df4b24cf">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1e24ce53-6a5e-450b-a6ee-0a00df4b24cf">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1e24ce53-6a5e-450b-a6ee-0a00df4b24cf">
											<gml:posList>35.666880048869594 139.73826340677445 12.98 35.666974778158696 139.73837121183334 12.98 35.666974778158696 139.73837121183334 22.036 35.666880048869594 139.73826340677445 22.036 35.666880048869594 139.73826340677445 12.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3e604474-3c02-4859-b4ca-61bb1fb0d3d3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3e604474-3c02-4859-b4ca-61bb1fb0d3d3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3e604474-3c02-4859-b4ca-61bb1fb0d3d3">
											<gml:posList>35.66704093998239 139.738281088126 22.036 35.66704093998239 139.738281088126 21.218 35.66697468573916 139.7383683179458 21.218 35.66697468573916 139.7383683179458 22.036 35.66704093998239 139.738281088126 22.036</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-80cf5bc2-5b61-43e6-8805-7453822952cf">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-80cf5bc2-5b61-43e6-8805-7453822952cf">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-80cf5bc2-5b61-43e6-8805-7453822952cf">
											<gml:posList>35.666974778158696 139.73837121183334 12.98 35.667043301509146 139.7382809969603 12.98 35.667043301509146 139.7382809969603 22.036 35.666974778158696 139.73837121183334 22.036 35.666974778158696 139.73837121183334 12.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区六本木二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-1012</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">160.1122</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">211</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1320</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>7</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>