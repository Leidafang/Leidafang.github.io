<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_eefba394-4e86-4562-ace2-1d3106ea4deb">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">401</bldg:usage>
			<bldg:measuredHeight uom="m">27.1</bldg:measuredHeight>
			<bldg:storeysAboveGround>6</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>3</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.669441916648 139.73847212357015 0 35.669492985218135 139.73845657646683 0 35.66949695801175 139.73847658736713 0 35.66955647071759 139.73845884312757 0 35.669486527405176 139.73812036181764 0 35.669398569547546 139.73825489759506 0 35.669441916648 139.73847212357015 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669441916648 139.73847212357015 17.02 35.669398569547546 139.73825489759506 17.02 35.669486527405176 139.73812036181764 17.02 35.66955647071759 139.73845884312757 17.02 35.66949695801175 139.73847658736713 17.02 35.669492985218135 139.73845657646683 17.02 35.669441916648 139.73847212357015 17.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669441916648 139.73847212357015 17.02 35.669492985218135 139.73845657646683 17.02 35.669492985218135 139.73845657646683 44.07 35.669441916648 139.73847212357015 44.07 35.669441916648 139.73847212357015 17.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669492985218135 139.73845657646683 17.02 35.66949695801175 139.73847658736713 17.02 35.66949695801175 139.73847658736713 44.07 35.669492985218135 139.73845657646683 44.07 35.669492985218135 139.73845657646683 17.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66949695801175 139.73847658736713 17.02 35.66955647071759 139.73845884312757 17.02 35.66955647071759 139.73845884312757 44.07 35.66949695801175 139.73847658736713 44.07 35.66949695801175 139.73847658736713 17.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66955647071759 139.73845884312757 17.02 35.669486527405176 139.73812036181764 17.02 35.669486527405176 139.73812036181764 44.07 35.66955647071759 139.73845884312757 44.07 35.66955647071759 139.73845884312757 17.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669486527405176 139.73812036181764 17.02 35.669398569547546 139.73825489759506 17.02 35.669398569547546 139.73825489759506 44.07 35.669486527405176 139.73812036181764 44.07 35.669486527405176 139.73812036181764 17.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669398569547546 139.73825489759506 17.02 35.669441916648 139.73847212357015 17.02 35.669441916648 139.73847212357015 44.07 35.669398569547546 139.73825489759506 44.07 35.669398569547546 139.73825489759506 17.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669441916648 139.73847212357015 44.07 35.669492985218135 139.73845657646683 44.07 35.66949695801175 139.73847658736713 44.07 35.66955647071759 139.73845884312757 44.07 35.669486527405176 139.73812036181764 44.07 35.669398569547546 139.73825489759506 44.07 35.669441916648 139.73847212357015 44.07</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-cc6c86a0-7e59-4dbe-8f3f-b0a524ce2807"/>
							<gml:surfaceMember xlink:href="#poly-52d2f994-f0c4-4675-ad63-cae46907a5fa"/>
							<gml:surfaceMember xlink:href="#poly-b744f67c-858b-43c5-8ff6-03559ae6cfdb"/>
							<gml:surfaceMember xlink:href="#poly-00de27ce-b9b7-4108-aac2-948bd71ace98"/>
							<gml:surfaceMember xlink:href="#poly-46f1ae35-d8ba-4a84-9eb0-9a303e07b923"/>
							<gml:surfaceMember xlink:href="#poly-f33aeec7-f638-4db3-aa4f-a3ba39599eec"/>
							<gml:surfaceMember xlink:href="#poly-07c187e2-9441-43c1-88d6-bb2c29e3009e"/>
							<gml:surfaceMember xlink:href="#poly-3cb92b95-f780-4b13-aa72-e1e8c42906de"/>
							<gml:surfaceMember xlink:href="#poly-f39abfe8-8c94-4620-b8f0-842ce88b2f89"/>
							<gml:surfaceMember xlink:href="#poly-511dae2a-a30e-428d-a230-93d35f0def54"/>
							<gml:surfaceMember xlink:href="#poly-2ca14893-5603-4e27-b992-4c0c4eb550fe"/>
							<gml:surfaceMember xlink:href="#poly-7fb94823-c218-46b2-9054-c02de786c624"/>
							<gml:surfaceMember xlink:href="#poly-b1912c1a-9d48-4b39-8bad-b9e20779d4f4"/>
							<gml:surfaceMember xlink:href="#poly-186693bf-ad29-40fb-a1ce-9136328b4721"/>
							<gml:surfaceMember xlink:href="#poly-39945ea5-284e-4ff6-bae4-5b3108e4e1cc"/>
							<gml:surfaceMember xlink:href="#poly-6156b700-4c05-4a89-b8e4-65566264cfda"/>
							<gml:surfaceMember xlink:href="#poly-02afbc62-a8a0-4e27-a8d5-65645cabc62d"/>
							<gml:surfaceMember xlink:href="#poly-ebf4cad8-f651-4d97-a264-6c57dee2c6f3"/>
							<gml:surfaceMember xlink:href="#poly-23f44ce8-248b-437d-8980-601a6a3c9124"/>
							<gml:surfaceMember xlink:href="#poly-8b949ffd-7954-4bb7-a1d9-23201ae7ef0e"/>
							<gml:surfaceMember xlink:href="#poly-ee68763b-b6bd-423d-9d41-5989e88dbe8b"/>
							<gml:surfaceMember xlink:href="#poly-c6103ca1-1bf4-4a96-89a9-576d9a7b5bba"/>
							<gml:surfaceMember xlink:href="#poly-5f232ab3-66a2-4d9b-922d-9358b2258bf2"/>
							<gml:surfaceMember xlink:href="#poly-5fe24d24-86c5-4c29-89b3-d1130b3b628a"/>
							<gml:surfaceMember xlink:href="#poly-597254f8-efbe-4375-9655-0b0960ef3416"/>
							<gml:surfaceMember xlink:href="#poly-434f3533-5dc4-41f0-9bb0-11b41f9910c0"/>
							<gml:surfaceMember xlink:href="#poly-0bf4625c-0008-4d32-86a1-6441d27cf190"/>
							<gml:surfaceMember xlink:href="#poly-3d3389ea-5772-4f31-9a78-e6368e3cb0fb"/>
							<gml:surfaceMember xlink:href="#poly-3d8466f6-9822-4444-b96b-14c0a739213a"/>
							<gml:surfaceMember xlink:href="#poly-a37a931e-4a29-47dc-ba67-58fa2fb31cf3"/>
							<gml:surfaceMember xlink:href="#poly-dde145b8-10ac-40b7-83c3-26639eeea22c"/>
							<gml:surfaceMember xlink:href="#poly-3bb4bad4-8a59-40a6-8126-704fd0dee00a"/>
							<gml:surfaceMember xlink:href="#poly-a5fa5b3f-c807-49a2-bf8b-69121af90176"/>
							<gml:surfaceMember xlink:href="#poly-4ea9ea8c-7b7c-4bca-98e7-d46f7da9ec82"/>
							<gml:surfaceMember xlink:href="#poly-fa197772-96b7-4578-ae9c-6f7d4143b2cf"/>
							<gml:surfaceMember xlink:href="#poly-38165097-71da-43e7-afcb-556cae735902"/>
							<gml:surfaceMember xlink:href="#poly-07cd2897-84cc-4015-818e-741902bcb66e"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_eefba394-4e86-4562-ace2-1d3106ea4deb_BuildingInstallation_1041">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d43e2437-cc6f-462b-aa7b-6cd9379b9598">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66945807750588 139.7383225287742 44.216 35.669478948757195 139.73831676005227 44.216 35.66949005620651 139.73837710297985 44.216 35.66946918495231 139.73838287168692 44.216 35.66945807750588 139.7383225287742 44.216</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f972fc61-5fa7-46e8-bf48-25f81dc59759">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f972fc61-5fa7-46e8-bf48-25f81dc59759_0">
											<gml:posList>35.66945807750588 139.7383225287742 44.216 35.66945807750588 139.7383225287742 47.013 35.669478948757195 139.73831676005227 47.013 35.669478948757195 139.73831676005227 44.216 35.66945807750588 139.7383225287742 44.216</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d90ad304-df50-4035-8255-b272c13f5695">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d90ad304-df50-4035-8255-b272c13f5695_0">
											<gml:posList>35.669478948757195 139.73831676005227 44.216 35.669478948757195 139.73831676005227 47.013 35.66949005620651 139.73837710297985 47.013 35.66949005620651 139.73837710297985 44.216 35.669478948757195 139.73831676005227 44.216</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-60c28efc-6908-4f42-abd8-e3774ef91842">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-60c28efc-6908-4f42-abd8-e3774ef91842_0">
											<gml:posList>35.66949005620651 139.73837710297985 47.013 35.669478948757195 139.73831676005227 47.013 35.66945807750588 139.7383225287742 47.013 35.66946918495231 139.73838287168692 47.013 35.66949005620651 139.73837710297985 47.013</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-622b4772-1c83-4d77-8f67-868a8519419c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-622b4772-1c83-4d77-8f67-868a8519419c_0">
											<gml:posList>35.66946918495231 139.73838287168692 44.216 35.66946918495231 139.73838287168692 47.013 35.66945807750588 139.7383225287742 47.013 35.66945807750588 139.7383225287742 44.216 35.66946918495231 139.73838287168692 44.216</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-09519f8d-86d6-453f-8140-7ffeb8f37ec8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-09519f8d-86d6-453f-8140-7ffeb8f37ec8_0">
											<gml:posList>35.66949005620651 139.73837710297985 44.216 35.66949005620651 139.73837710297985 47.013 35.66946918495231 139.73838287168692 47.013 35.66946918495231 139.73838287168692 44.216 35.66949005620651 139.73837710297985 44.216</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_eefba394-4e86-4562-ace2-1d3106ea4deb_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-aae4c85d-0f6f-4da2-9869-7cb580bc358c">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669504077012895 139.73825709217243 49.27 35.66949309148186 139.7382598888254 49.27 35.66948915209011 139.73823656405634 49.27 35.66950013762061 139.73823376740032 49.27 35.669504077012895 139.73825709217243 49.27</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8320ff12-e560-4b26-9e20-ba8dfc0de341">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66951568879867 139.7382940056498 44.216 35.66950821804354 139.73829606908694 44.216 35.66950570146069 139.73828243008847 44.216 35.66951318122933 139.73828036663946 44.216 35.66951568879867 139.7382940056498 44.216</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e7ecc160-85c8-427d-a4d6-d3b98d1883f2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66951882966327 139.7383106042761 44.216 35.6695213010087 139.7383240334546 44.216 35.66951452416159 139.7383259082825 44.216 35.669512052807654 139.73831246805892 44.216 35.66951882966327 139.7383106042761 44.216</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9605bc90-7976-4210-b841-3c204c1868a2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66949666972884 139.73831672800608 44.216 35.66949921348841 139.7383305437101 44.216 35.66949091365308 139.73833284009459 44.216 35.66948836988506 139.7383190133458 44.216 35.66949666972884 139.73831672800608 44.216</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5d968fb0-927e-4592-97cc-f8261535dcc6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66952526605665 139.73834562396274 44.216 35.669527692120454 139.7383587880896 44.216 35.66952091527283 139.73836066291474 44.216 35.66951848920922 139.73834749878887 44.216 35.66952526605665 139.73834562396274 44.216</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-920dc985-1ea8-4c97-8fb8-3176c2a52018">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669505685294936 139.7383647569797 44.216 35.66949716918186 139.73836711989384 44.216 35.66949476121609 139.73835404411935 44.216 35.669503286351365 139.73835169223935 44.216 35.669505685294936 139.7383647569797 44.216</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-aab57bb7-1cde-4cb8-9d76-eeb1e0b727d5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669490110653406 139.73842329785867 44.216 35.6694828924631 139.73842559295298 44.216 35.66948006061488 139.7384122083891 44.216 35.66948727880493 139.73840991329365 44.216 35.669490110653406 139.73842329785867 44.216</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-61ac2c47-63d6-4ece-9431-a166227cbd60">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-61ac2c47-63d6-4ece-9431-a166227cbd60_0">
											<gml:posList>35.66951318122933 139.73828036663946 44.216 35.66950570146069 139.73828243008847 44.216 35.66950570146069 139.73828243008847 46.875 35.66951318122933 139.73828036663946 46.875 35.66951318122933 139.73828036663946 44.216</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-717859db-e09d-419b-9a4a-e094d86e93f7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-717859db-e09d-419b-9a4a-e094d86e93f7_0">
											<gml:posList>35.66951568879867 139.7382940056498 44.216 35.66951318122933 139.73828036663946 44.216 35.66951318122933 139.73828036663946 46.875 35.66951568879867 139.7382940056498 46.875 35.66951568879867 139.7382940056498 44.216</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-59fbf071-7ed5-4ee2-bbac-425975fa13dd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-59fbf071-7ed5-4ee2-bbac-425975fa13dd_0">
											<gml:posList>35.66950570146069 139.73828243008847 46.875 35.66950821804354 139.73829606908694 46.875 35.66951568879867 139.7382940056498 46.875 35.66951318122933 139.73828036663946 46.875 35.66950570146069 139.73828243008847 46.875</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e2d7828d-d639-44c7-bca6-f45ad43e708d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e2d7828d-d639-44c7-bca6-f45ad43e708d_0">
											<gml:posList>35.66950570146069 139.73828243008847 44.216 35.66950821804354 139.73829606908694 44.216 35.66950821804354 139.73829606908694 46.875 35.66950570146069 139.73828243008847 46.875 35.66950570146069 139.73828243008847 44.216</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b877e752-7119-4d51-be6e-7d402f715248">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b877e752-7119-4d51-be6e-7d402f715248_0">
											<gml:posList>35.66950821804354 139.73829606908694 44.216 35.66951568879867 139.7382940056498 44.216 35.66951568879867 139.7382940056498 46.875 35.66950821804354 139.73829606908694 46.875 35.66950821804354 139.73829606908694 44.216</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-60cd238c-b4b9-4f79-9a65-1f43f1365302">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-60cd238c-b4b9-4f79-9a65-1f43f1365302_0">
											<gml:posList>35.66951882966327 139.7383106042761 44.216 35.669512052807654 139.73831246805892 44.216 35.669512052807654 139.73831246805892 46.875 35.66951882966327 139.7383106042761 46.875 35.66951882966327 139.7383106042761 44.216</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c0a76e6f-4319-46a4-964b-4308e3f33daa">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c0a76e6f-4319-46a4-964b-4308e3f33daa_0">
											<gml:posList>35.6695213010087 139.7383240334546 44.216 35.66951882966327 139.7383106042761 44.216 35.66951882966327 139.7383106042761 46.875 35.6695213010087 139.7383240334546 46.875 35.6695213010087 139.7383240334546 44.216</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4b1652d4-22a7-44d7-acb3-e3b61b018734">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4b1652d4-22a7-44d7-acb3-e3b61b018734_0">
											<gml:posList>35.66951452416159 139.7383259082825 46.875 35.6695213010087 139.7383240334546 46.875 35.66951882966327 139.7383106042761 46.875 35.669512052807654 139.73831246805892 46.875 35.66951452416159 139.7383259082825 46.875</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8e48649c-6182-4725-bcab-1a14ca104830">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8e48649c-6182-4725-bcab-1a14ca104830_0">
											<gml:posList>35.669512052807654 139.73831246805892 44.216 35.66951452416159 139.7383259082825 44.216 35.66951452416159 139.7383259082825 46.875 35.669512052807654 139.73831246805892 46.875 35.669512052807654 139.73831246805892 44.216</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f746fc15-aba0-418d-b1a8-a33afb01ea53">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f746fc15-aba0-418d-b1a8-a33afb01ea53_0">
											<gml:posList>35.66951452416159 139.7383259082825 44.216 35.6695213010087 139.7383240334546 44.216 35.6695213010087 139.7383240334546 46.875 35.66951452416159 139.7383259082825 46.875 35.66951452416159 139.7383259082825 44.216</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cf47eef1-badf-4f1d-a325-a54eb2edf5dd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cf47eef1-badf-4f1d-a325-a54eb2edf5dd_0">
											<gml:posList>35.66952526605665 139.73834562396274 44.216 35.66951848920922 139.73834749878887 44.216 35.66951848920922 139.73834749878887 46.875 35.66952526605665 139.73834562396274 46.875 35.66952526605665 139.73834562396274 44.216</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-886361e3-d42c-44cf-9bb1-afb2ae7a60cd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-886361e3-d42c-44cf-9bb1-afb2ae7a60cd_0">
											<gml:posList>35.669527692120454 139.7383587880896 44.216 35.66952526605665 139.73834562396274 44.216 35.66952526605665 139.73834562396274 46.875 35.669527692120454 139.7383587880896 46.875 35.669527692120454 139.7383587880896 44.216</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e2252a7a-005a-433e-be93-bccd8746e098">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e2252a7a-005a-433e-be93-bccd8746e098_0">
											<gml:posList>35.66952091527283 139.73836066291474 46.875 35.669527692120454 139.7383587880896 46.875 35.66952526605665 139.73834562396274 46.875 35.66951848920922 139.73834749878887 46.875 35.66952091527283 139.73836066291474 46.875</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-88dd7544-02e9-45e7-aa5b-39e162c190b8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-88dd7544-02e9-45e7-aa5b-39e162c190b8_0">
											<gml:posList>35.66951848920922 139.73834749878887 44.216 35.66952091527283 139.73836066291474 44.216 35.66952091527283 139.73836066291474 46.875 35.66951848920922 139.73834749878887 46.875 35.66951848920922 139.73834749878887 44.216</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a4ccabf5-3ce4-49e2-879f-548905b2e4c1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a4ccabf5-3ce4-49e2-879f-548905b2e4c1_0">
											<gml:posList>35.66952091527283 139.73836066291474 44.216 35.669527692120454 139.7383587880896 44.216 35.669527692120454 139.7383587880896 46.875 35.66952091527283 139.73836066291474 46.875 35.66952091527283 139.73836066291474 44.216</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8efadefc-e08b-4474-a3bc-dfec709725b9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8efadefc-e08b-4474-a3bc-dfec709725b9_0">
											<gml:posList>35.66949476121609 139.73835404411935 46.875 35.66949716918186 139.73836711989384 46.875 35.669505685294936 139.7383647569797 46.875 35.669503286351365 139.73835169223935 46.875 35.66949476121609 139.73835404411935 46.875</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4ec5446b-c022-4580-87a1-521c3f552c85">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4ec5446b-c022-4580-87a1-521c3f552c85_0">
											<gml:posList>35.66949476121609 139.73835404411935 44.216 35.66949716918186 139.73836711989384 44.216 35.66949716918186 139.73836711989384 46.875 35.66949476121609 139.73835404411935 46.875 35.66949476121609 139.73835404411935 44.216</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2c0b9ea7-4f00-41bd-834f-8c3c15838618">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2c0b9ea7-4f00-41bd-834f-8c3c15838618_0">
											<gml:posList>35.66949716918186 139.73836711989384 44.216 35.669505685294936 139.7383647569797 44.216 35.669505685294936 139.7383647569797 46.875 35.66949716918186 139.73836711989384 46.875 35.66949716918186 139.73836711989384 44.216</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-622d6bc5-6032-4e27-a9cd-878bb525844a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-622d6bc5-6032-4e27-a9cd-878bb525844a_0">
											<gml:posList>35.66948727880493 139.73840991329365 44.216 35.66948006061488 139.7384122083891 44.216 35.66948006061488 139.7384122083891 46.675 35.66948727880493 139.73840991329365 46.675 35.66948727880493 139.73840991329365 44.216</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b373e8de-ec6a-4c23-9f71-d91cc70f48bc">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b373e8de-ec6a-4c23-9f71-d91cc70f48bc_0">
											<gml:posList>35.669490110653406 139.73842329785867 44.216 35.66948727880493 139.73840991329365 44.216 35.66948727880493 139.73840991329365 46.675 35.669490110653406 139.73842329785867 46.675 35.669490110653406 139.73842329785867 44.216</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0e93a238-c5d4-400a-939e-bc8f0e358e45">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0e93a238-c5d4-400a-939e-bc8f0e358e45_0">
											<gml:posList>35.66948006061488 139.7384122083891 46.675 35.6694828924631 139.73842559295298 46.675 35.669490110653406 139.73842329785867 46.675 35.66948727880493 139.73840991329365 46.675 35.66948006061488 139.7384122083891 46.675</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-93125759-1e23-4d44-832b-f4ac820c1410">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-93125759-1e23-4d44-832b-f4ac820c1410_0">
											<gml:posList>35.66948006061488 139.7384122083891 44.216 35.6694828924631 139.73842559295298 44.216 35.6694828924631 139.73842559295298 46.675 35.66948006061488 139.7384122083891 46.675 35.66948006061488 139.7384122083891 44.216</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-15db5161-f909-460f-8997-ee606e521649">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-15db5161-f909-460f-8997-ee606e521649_0">
											<gml:posList>35.669490110653406 139.73842329785867 44.216 35.669490110653406 139.73842329785867 46.675 35.6694828924631 139.73842559295298 46.675 35.6694828924631 139.73842559295298 44.216 35.669490110653406 139.73842329785867 44.216</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d188ea1a-f3f3-447a-b9d4-96928b133313">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d188ea1a-f3f3-447a-b9d4-96928b133313_0">
											<gml:posList>35.66950013762061 139.73823376740032 49.27 35.66948915209011 139.73823656405634 49.27 35.66948915209011 139.73823656405634 50.749 35.66950013762061 139.73823376740032 50.749 35.66950013762061 139.73823376740032 49.27</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8baa98db-bfe9-4ebb-8541-a045672a8513">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8baa98db-bfe9-4ebb-8541-a045672a8513_0">
											<gml:posList>35.669504077012895 139.73825709217243 49.27 35.66950013762061 139.73823376740032 49.27 35.66950013762061 139.73823376740032 50.749 35.669504077012895 139.73825709217243 50.749 35.669504077012895 139.73825709217243 49.27</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-303be3e0-f81a-4166-b0ae-efc5788be0c7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-303be3e0-f81a-4166-b0ae-efc5788be0c7_0">
											<gml:posList>35.66948915209011 139.73823656405634 50.749 35.66949309148186 139.7382598888254 50.749 35.669504077012895 139.73825709217243 50.749 35.66950013762061 139.73823376740032 50.749 35.66948915209011 139.73823656405634 50.749</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-378739af-4089-4cf5-b13d-14cec8c5070a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-378739af-4089-4cf5-b13d-14cec8c5070a_0">
											<gml:posList>35.66949309148186 139.7382598888254 49.27 35.66949309148186 139.7382598888254 50.749 35.66948915209011 139.73823656405634 50.749 35.66948915209011 139.73823656405634 49.27 35.66949309148186 139.7382598888254 49.27</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-eeeb0e8f-fc60-4912-8944-aa839f80c248">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-eeeb0e8f-fc60-4912-8944-aa839f80c248_0">
											<gml:posList>35.66949309148186 139.7382598888254 49.27 35.669504077012895 139.73825709217243 49.27 35.669504077012895 139.73825709217243 50.749 35.66949309148186 139.7382598888254 50.749 35.66949309148186 139.7382598888254 49.27</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cddf24b3-a0ef-414b-a4e1-7dd751359af4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cddf24b3-a0ef-414b-a4e1-7dd751359af4_0">
											<gml:posList>35.66948836988506 139.7383190133458 44.216 35.66948836988506 139.7383190133458 46.875 35.66949666972884 139.73831672800608 46.875 35.66949666972884 139.73831672800608 44.216 35.66948836988506 139.7383190133458 44.216</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ef6c99f3-8288-40a7-8f06-24b4007e6924">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ef6c99f3-8288-40a7-8f06-24b4007e6924_0">
											<gml:posList>35.66949921348841 139.7383305437101 44.216 35.66949666972884 139.73831672800608 44.216 35.66949666972884 139.73831672800608 46.875 35.66949921348841 139.7383305437101 46.875 35.66949921348841 139.7383305437101 44.216</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-528171a6-3ed5-44e4-9544-b83ca7cdc4f5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-528171a6-3ed5-44e4-9544-b83ca7cdc4f5_0">
											<gml:posList>35.66949091365308 139.73833284009459 46.875 35.66949921348841 139.7383305437101 46.875 35.66949666972884 139.73831672800608 46.875 35.66948836988506 139.7383190133458 46.875 35.66949091365308 139.73833284009459 46.875</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-522aab99-1d7c-4fc5-ba7a-102e7ef2436c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-522aab99-1d7c-4fc5-ba7a-102e7ef2436c_0">
											<gml:posList>35.66948836988506 139.7383190133458 44.216 35.66949091365308 139.73833284009459 44.216 35.66949091365308 139.73833284009459 46.875 35.66948836988506 139.7383190133458 46.875 35.66948836988506 139.7383190133458 44.216</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-32fe7e37-e022-4797-9840-7c76719b5df7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-32fe7e37-e022-4797-9840-7c76719b5df7_0">
											<gml:posList>35.66949091365308 139.73833284009459 44.216 35.66949921348841 139.7383305437101 44.216 35.66949921348841 139.7383305437101 46.875 35.66949091365308 139.73833284009459 46.875 35.66949091365308 139.73833284009459 44.216</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cc47f541-4389-4116-9577-a378ca176b86">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cc47f541-4389-4116-9577-a378ca176b86_0">
											<gml:posList>35.669503286351365 139.73835169223935 44.216 35.66949476121609 139.73835404411935 44.216 35.66949476121609 139.73835404411935 46.875 35.669503286351365 139.73835169223935 46.875 35.669503286351365 139.73835169223935 44.216</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8395ba98-2ec5-4e3b-bc3d-5f17bf3aadd2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8395ba98-2ec5-4e3b-bc3d-5f17bf3aadd2_0">
											<gml:posList>35.669505685294936 139.7383647569797 44.216 35.669503286351365 139.73835169223935 44.216 35.669503286351365 139.73835169223935 46.875 35.669505685294936 139.7383647569797 46.875 35.669505685294936 139.7383647569797 44.216</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_eefba394-4e86-4562-ace2-1d3106ea4deb_BuildingInstallation_1060">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-19ac7b47-6c72-4fe4-9afc-8757885c4f9c">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669487733903956 139.73830122982008 44.216 35.66948370573453 139.73827961730677 44.216 35.669495375934076 139.73827634486125 44.216 35.6694994131178 139.7382979573668 44.216 35.669487733903956 139.73830122982008 44.216</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ddad861f-136a-4a82-8950-dab412b48bc7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66949695801174 139.7384765873671 17.02 35.6694660842169 139.73848579218281 17.02 35.669462192826806 139.73846613466972 17.02 35.66949298521813 139.73845657646683 17.02 35.66949695801174 139.7384765873671 17.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8141791e-3503-462d-8bfc-bb99c1177b3c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8141791e-3503-462d-8bfc-bb99c1177b3c_0">
											<gml:posList>35.669462192826806 139.73846613466972 17.02 35.6694660842169 139.73848579218281 17.02 35.6694660842169 139.73848579218281 45.538 35.66946413852225 139.73847596342603 45.538 35.669462192826806 139.73846613466972 45.538 35.669462192826806 139.73846613466972 17.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8a8b558f-a493-4001-82b7-62c2a85dfb09">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8a8b558f-a493-4001-82b7-62c2a85dfb09_0">
											<gml:posList>35.669462192826806 139.73846613466972 45.538 35.66946413852225 139.73847596342603 45.538 35.669469410288784 139.73847435549987 45.538 35.66946744654835 139.73846450467204 45.538 35.669462192826806 139.73846613466972 45.538</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b0f79dd8-8d10-4e91-9641-1a2e694cb630">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b0f79dd8-8d10-4e91-9641-1a2e694cb630_0">
											<gml:posList>35.66946413852225 139.73847596342603 45.538 35.6694660842169 139.73848579218281 45.538 35.66947137403711 139.7384842173743 45.538 35.669469410288784 139.73847435549987 45.538 35.66946413852225 139.73847596342603 45.538</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-06cb3e80-b85b-4657-9432-6ecf75b9bfc7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-06cb3e80-b85b-4657-9432-6ecf75b9bfc7_0">
											<gml:posList>35.669462192826806 139.73846613466972 45.538 35.66946744654835 139.73846450467204 45.538 35.66949298521813 139.73845657646683 45.538 35.66949298521813 139.73845657646683 17.02 35.669462192826806 139.73846613466972 17.02 35.669462192826806 139.73846613466972 45.538</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3b3f0c31-8f8d-417e-997b-31df6c832139">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3b3f0c31-8f8d-417e-997b-31df6c832139_0">
											<gml:posList>35.669469410288784 139.73847435549987 45.538 35.66948923574662 139.73846832294666 46.115 35.66948728091498 139.73845833955238 46.115 35.66946744654835 139.73846450467204 45.538 35.669469410288784 139.73847435549987 45.538</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a711fcbf-6daa-45bb-9c1e-aa6a51ba5ee5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a711fcbf-6daa-45bb-9c1e-aa6a51ba5ee5_0">
											<gml:posList>35.66949298521813 139.73845657646683 45.538 35.66946744654835 139.73846450467204 45.538 35.66948728091498 139.73845833955238 46.115 35.6694929762044 139.73845657647752 46.115 35.66949298521813 139.73845657646683 45.538</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c7a79bc3-a859-4381-80bb-7134b5fc24d2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c7a79bc3-a859-4381-80bb-7134b5fc24d2_0">
											<gml:posList>35.66947137403711 139.7384842173743 45.538 35.669491298716004 139.7384782730751 43.82 35.66948931685272 139.73846830075843 43.82 35.669469410288784 139.73847435549987 45.538 35.66947137403711 139.7384842173743 45.538</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-70df13f5-6f34-438c-a1bc-550f2d8edf52">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-70df13f5-6f34-438c-a1bc-550f2d8edf52_0">
											<gml:posList>35.6694660842169 139.73848579218281 17.02 35.66949695801174 139.7384765873671 17.02 35.66949695801174 139.7384765873671 43.82 35.669491298716004 139.7384782730751 43.82 35.66947137403711 139.7384842173743 45.538 35.6694660842169 139.73848579218281 45.538 35.6694660842169 139.73848579218281 17.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4d4f0761-cc74-4d41-a7db-29390686f22c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4d4f0761-cc74-4d41-a7db-29390686f22c_0">
											<gml:posList>35.669469410288784 139.73847435549987 45.538 35.66948931685272 139.73846830075843 43.82 35.669494967108484 139.73846658192204 43.82 35.669494967108484 139.73846658192204 46.115 35.66948923574662 139.73846832294666 46.115 35.669469410288784 139.73847435549987 45.538</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a2d7e93e-6852-483c-8550-b5cb3bacc34c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a2d7e93e-6852-483c-8550-b5cb3bacc34c_0">
											<gml:posList>35.669487733903956 139.73830122982008 44.216 35.669487733903956 139.73830122982008 44.959 35.66948370573453 139.73827961730677 44.959 35.66948370573453 139.73827961730677 44.216 35.669487733903956 139.73830122982008 44.216</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7e50b690-b7b7-450b-9620-e9f830c0e4f7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7e50b690-b7b7-450b-9620-e9f830c0e4f7_0">
											<gml:posList>35.66948370573453 139.73827961730677 44.959 35.669495375934076 139.73827634486125 44.959 35.669495375934076 139.73827634486125 44.216 35.66948370573453 139.73827961730677 44.216 35.66948370573453 139.73827961730677 44.959</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d510adaf-f2da-4885-9f91-5f9af910db68">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d510adaf-f2da-4885-9f91-5f9af910db68_0">
											<gml:posList>35.66948923574662 139.73846832294666 46.115 35.669494967108484 139.73846658192204 46.115 35.6694929762044 139.73845657647752 46.115 35.66948728091498 139.73845833955238 46.115 35.66948923574662 139.73846832294666 46.115</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-646d6008-875c-4cf0-8f06-7af7a4249cb1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-646d6008-875c-4cf0-8f06-7af7a4249cb1_0">
											<gml:posList>35.669487733903956 139.73830122982008 44.959 35.6694994131178 139.7382979573668 44.959 35.669495375934076 139.73827634486125 44.959 35.66948370573453 139.73827961730677 44.959 35.669487733903956 139.73830122982008 44.959</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-576b76db-f8da-4d5b-965d-faaef1a0be59">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-576b76db-f8da-4d5b-965d-faaef1a0be59_0">
											<gml:posList>35.669491298716004 139.7384782730751 43.82 35.66949695801174 139.7384765873671 43.82 35.669494967108484 139.73846658192204 43.82 35.66948931685272 139.73846830075843 43.82 35.669491298716004 139.7384782730751 43.82</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-11e8c7aa-e4b2-4ead-9419-a09eca119610">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-11e8c7aa-e4b2-4ead-9419-a09eca119610_0">
											<gml:posList>35.669487733903956 139.73830122982008 44.216 35.6694994131178 139.7382979573668 44.216 35.6694994131178 139.7382979573668 44.959 35.669487733903956 139.73830122982008 44.959 35.669487733903956 139.73830122982008 44.216</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-17859fee-b7ad-41fa-9ead-7fb9594f67d3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-17859fee-b7ad-41fa-9ead-7fb9594f67d3_0">
											<gml:posList>35.669494967108484 139.73846658192204 43.82 35.66949298521813 139.73845657646683 45.538 35.6694929762044 139.73845657647752 46.115 35.669494967108484 139.73846658192204 46.115 35.669494967108484 139.73846658192204 43.82</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-be900baa-5f32-445c-bdb1-fc965725ad93">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-be900baa-5f32-445c-bdb1-fc965725ad93_0">
											<gml:posList>35.66949695801174 139.7384765873671 43.82 35.66949695801174 139.7384765873671 17.02 35.66949298521813 139.73845657646683 17.02 35.66949298521813 139.73845657646683 45.538 35.669494967108484 139.73846658192204 43.82 35.66949695801174 139.7384765873671 43.82</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-abeeb923-ab8b-48f3-859b-e1514a787c28">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-abeeb923-ab8b-48f3-859b-e1514a787c28_0">
											<gml:posList>35.6694994131178 139.7382979573668 44.216 35.669495375934076 139.73827634486125 44.216 35.669495375934076 139.73827634486125 44.959 35.6694994131178 139.7382979573668 44.959 35.6694994131178 139.7382979573668 44.216</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-cc6c86a0-7e59-4dbe-8f3f-b0a524ce2807">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cc6c86a0-7e59-4dbe-8f3f-b0a524ce2807">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cc6c86a0-7e59-4dbe-8f3f-b0a524ce2807">
											<gml:posList>35.66955647071758 139.73845884312757 17.02 35.66949695801174 139.7384765873671 17.02 35.66949298521813 139.73845657646683 17.02 35.669441916648 139.73847212357015 17.02 35.669398569547525 139.73825489759506 17.02 35.669486527405155 139.73812036181764 17.02 35.66955647071758 139.73845884312757 17.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-52d2f994-f0c4-4675-ad63-cae46907a5fa">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-52d2f994-f0c4-4675-ad63-cae46907a5fa">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-52d2f994-f0c4-4675-ad63-cae46907a5fa">
											<gml:posList>35.669497132066326 139.7381716806259 47.089 35.669486527405155 139.73812036181764 41.154 35.669398569547525 139.73825489759506 41.154 35.669497132066326 139.7381716806259 47.089</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b744f67c-858b-43c5-8ff6-03559ae6cfdb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b744f67c-858b-43c5-8ff6-03559ae6cfdb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b744f67c-858b-43c5-8ff6-03559ae6cfdb">
											<gml:posList>35.66946968792924 139.73822070280121 51.007 35.669473483457175 139.73822164826635 51.007 35.669495888298094 139.73818324740793 51.007 35.669497439693956 139.7381731493971 51.007 35.66946968792924 139.73822070280121 51.007</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-00de27ce-b9b7-4108-aac2-948bd71ace98">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-00de27ce-b9b7-4108-aac2-948bd71ace98">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-00de27ce-b9b7-4108-aac2-948bd71ace98">
											<gml:posList>35.669497132066326 139.7381716806259 47.089 35.669398569547525 139.73825489759506 41.154 35.6694360942411 139.7382669817478 47.089 35.669497132066326 139.7381716806259 47.089</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-46f1ae35-d8ba-4a84-9eb0-9a303e07b923">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-46f1ae35-d8ba-4a84-9eb0-9a303e07b923">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-46f1ae35-d8ba-4a84-9eb0-9a303e07b923">
											<gml:posList>35.669440863538625 139.7382682905825 47.089 35.66946968792924 139.73822070280121 47.089 35.669497439693956 139.7381731493971 47.089 35.669497132066326 139.7381716806259 47.089 35.6694360942411 139.7382669817478 47.089 35.669440863538625 139.7382682905825 47.089</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f33aeec7-f638-4db3-aa4f-a3ba39599eec">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f33aeec7-f638-4db3-aa4f-a3ba39599eec">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f33aeec7-f638-4db3-aa4f-a3ba39599eec">
											<gml:posList>35.669517481731766 139.73827015490753 51.007 35.669497439693956 139.7381731493971 51.007 35.669495888298094 139.73818324740793 51.007 35.669513179639246 139.73826693453537 51.007 35.669517481731766 139.73827015490753 51.007</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-07c187e2-9441-43c1-88d6-bb2c29e3009e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-07c187e2-9441-43c1-88d6-bb2c29e3009e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-07c187e2-9441-43c1-88d6-bb2c29e3009e">
											<gml:posList>35.669513179639246 139.73826693453537 49.27 35.669495888298094 139.73818324740793 49.27 35.669473483457175 139.73822164826635 49.27 35.669483476938375 139.7382752433083 49.27 35.669513179639246 139.73826693453537 49.27</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-3cb92b95-f780-4b13-aa72-e1e8c42906de">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3cb92b95-f780-4b13-aa72-e1e8c42906de">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3cb92b95-f780-4b13-aa72-e1e8c42906de">
											<gml:posList>35.66946968792924 139.73822070280121 51.007 35.669480821970836 139.73828041604725 51.007 35.669483476938375 139.7382752433083 51.007 35.669473483457175 139.73822164826635 51.007 35.66946968792924 139.73822070280121 51.007</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f39abfe8-8c94-4620-b8f0-842ce88b2f89">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f39abfe8-8c94-4620-b8f0-842ce88b2f89">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f39abfe8-8c94-4620-b8f0-842ce88b2f89">
											<gml:posList>35.669517481731766 139.73827015490753 51.007 35.669513179639246 139.73826693453537 51.007 35.669483476938375 139.7382752433083 51.007 35.669480821970836 139.73828041604725 51.007 35.669517481731766 139.73827015490753 51.007</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-511dae2a-a30e-428d-a230-93d35f0def54">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-511dae2a-a30e-428d-a230-93d35f0def54">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-511dae2a-a30e-428d-a230-93d35f0def54">
											<gml:posList>35.669440863538625 139.7382682905825 44.216 35.6694761652619 139.7384561545244 44.216 35.66949621597484 139.73845001123823 44.216 35.66949656894621 139.73845183343323 44.216 35.66954734037373 139.7384366843192 44.216 35.66951328226102 139.73827133077734 44.216 35.669480821970836 139.73828041604725 44.216 35.66946968792924 139.73822070280121 44.216 35.669440863538625 139.7382682905825 44.216</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-2ca14893-5603-4e27-b992-4c0c4eb550fe">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2ca14893-5603-4e27-b992-4c0c4eb550fe">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2ca14893-5603-4e27-b992-4c0c4eb550fe">
											<gml:posList>35.6694360942411 139.7382669817478 47.089 35.669398569547525 139.73825489759506 41.154 35.669441916648 139.73847212357015 41.154 35.6694360942411 139.7382669817478 47.089</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-7fb94823-c218-46b2-9054-c02de786c624">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7fb94823-c218-46b2-9054-c02de786c624">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7fb94823-c218-46b2-9054-c02de786c624">
											<gml:posList>35.669517481731766 139.73827015490753 47.089 35.66951328226102 139.73827133077734 47.089 35.66954734037373 139.7384366843192 47.089 35.669551104418915 139.73845487286513 47.089 35.66955647071758 139.73845884312757 47.089 35.669517481731766 139.73827015490753 47.089</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b1912c1a-9d48-4b39-8bad-b9e20779d4f4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b1912c1a-9d48-4b39-8bad-b9e20779d4f4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b1912c1a-9d48-4b39-8bad-b9e20779d4f4">
											<gml:posList>35.6694360942411 139.7382669817478 47.089 35.66947287141748 139.73846273087187 47.089 35.6694761652619 139.7384561545244 47.089 35.669440863538625 139.7382682905825 47.089 35.6694360942411 139.7382669817478 47.089</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-186693bf-ad29-40fb-a1ce-9136328b4721">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-186693bf-ad29-40fb-a1ce-9136328b4721">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-186693bf-ad29-40fb-a1ce-9136328b4721">
											<gml:posList>35.669441916648 139.73847212357015 41.154 35.66947287141748 139.73846273087187 47.089 35.6694360942411 139.7382669817478 47.089 35.669441916648 139.73847212357015 41.154</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-39945ea5-284e-4ff6-bae4-5b3108e4e1cc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-39945ea5-284e-4ff6-bae4-5b3108e4e1cc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-39945ea5-284e-4ff6-bae4-5b3108e4e1cc">
											<gml:posList>35.66950019780936 139.7384700552667 47.089 35.669551104418915 139.73845487286513 47.089 35.66954734037373 139.7384366843192 47.089 35.66949656894621 139.73845183343323 47.089 35.66950019780936 139.7384700552667 47.089</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-6156b700-4c05-4a89-b8e4-65566264cfda">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6156b700-4c05-4a89-b8e4-65566264cfda">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6156b700-4c05-4a89-b8e4-65566264cfda">
											<gml:posList>35.66949298521813 139.73845657646683 47.089 35.66949621597484 139.73845001123823 47.089 35.6694761652619 139.7384561545244 47.089 35.66947287141748 139.73846273087187 47.089 35.66949298521813 139.73845657646683 47.089</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-02afbc62-a8a0-4e27-a8d5-65645cabc62d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-02afbc62-a8a0-4e27-a8d5-65645cabc62d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-02afbc62-a8a0-4e27-a8d5-65645cabc62d">
											<gml:posList>35.66949298521813 139.73845657646683 47.089 35.66949695801174 139.7384765873671 47.089 35.66950019780936 139.7384700552667 47.089 35.66949656894621 139.73845183343323 47.089 35.66949621597484 139.73845001123823 47.089 35.66949298521813 139.73845657646683 47.089</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ebf4cad8-f651-4d97-a264-6c57dee2c6f3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ebf4cad8-f651-4d97-a264-6c57dee2c6f3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ebf4cad8-f651-4d97-a264-6c57dee2c6f3">
											<gml:posList>35.66955647071758 139.73845884312757 47.089 35.669551104418915 139.73845487286513 47.089 35.66950019780936 139.7384700552667 47.089 35.66949695801174 139.7384765873671 47.089 35.66955647071758 139.73845884312757 47.089</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-23f44ce8-248b-437d-8980-601a6a3c9124">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-23f44ce8-248b-437d-8980-601a6a3c9124">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-23f44ce8-248b-437d-8980-601a6a3c9124">
											<gml:posList>35.669473483457175 139.73822164826635 49.27 35.669495888298094 139.73818324740793 49.27 35.669495888298094 139.73818324740793 51.007 35.669473483457175 139.73822164826635 51.007 35.669473483457175 139.73822164826635 49.27</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8b949ffd-7954-4bb7-a1d9-23201ae7ef0e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8b949ffd-7954-4bb7-a1d9-23201ae7ef0e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8b949ffd-7954-4bb7-a1d9-23201ae7ef0e">
											<gml:posList>35.669473483457175 139.73822164826635 51.007 35.669483476938375 139.7382752433083 51.007 35.669483476938375 139.7382752433083 49.27 35.669473483457175 139.73822164826635 49.27 35.669473483457175 139.73822164826635 51.007</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ee68763b-b6bd-423d-9d41-5989e88dbe8b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ee68763b-b6bd-423d-9d41-5989e88dbe8b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ee68763b-b6bd-423d-9d41-5989e88dbe8b">
											<gml:posList>35.66949621597484 139.73845001123823 47.089 35.66949656894621 139.73845183343323 47.089 35.66949656894621 139.73845183343323 44.216 35.66949621597484 139.73845001123823 44.216 35.66949621597484 139.73845001123823 47.089</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c6103ca1-1bf4-4a96-89a9-576d9a7b5bba">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c6103ca1-1bf4-4a96-89a9-576d9a7b5bba">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c6103ca1-1bf4-4a96-89a9-576d9a7b5bba">
											<gml:posList>35.669486527405155 139.73812036181764 17.02 35.669398569547525 139.73825489759506 17.02 35.669398569547525 139.73825489759506 41.154 35.669486527405155 139.73812036181764 41.154 35.669486527405155 139.73812036181764 17.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5f232ab3-66a2-4d9b-922d-9358b2258bf2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5f232ab3-66a2-4d9b-922d-9358b2258bf2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5f232ab3-66a2-4d9b-922d-9358b2258bf2">
											<gml:posList>35.66946968792924 139.73822070280121 51.007 35.669497439693956 139.7381731493971 51.007 35.669497439693956 139.7381731493971 47.089 35.66946968792924 139.73822070280121 47.089 35.66946968792924 139.73822070280121 51.007</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5fe24d24-86c5-4c29-89b3-d1130b3b628a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5fe24d24-86c5-4c29-89b3-d1130b3b628a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5fe24d24-86c5-4c29-89b3-d1130b3b628a">
											<gml:posList>35.669495888298094 139.73818324740793 49.27 35.669513179639246 139.73826693453537 49.27 35.669513179639246 139.73826693453537 51.007 35.669495888298094 139.73818324740793 51.007 35.669495888298094 139.73818324740793 49.27</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-597254f8-efbe-4375-9655-0b0960ef3416">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-597254f8-efbe-4375-9655-0b0960ef3416">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-597254f8-efbe-4375-9655-0b0960ef3416">
											<gml:posList>35.669440863538625 139.7382682905825 44.216 35.66946968792924 139.73822070280121 44.216 35.66946968792924 139.73822070280121 47.089 35.669440863538625 139.7382682905825 47.089 35.669440863538625 139.7382682905825 44.216</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-434f3533-5dc4-41f0-9bb0-11b41f9910c0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-434f3533-5dc4-41f0-9bb0-11b41f9910c0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-434f3533-5dc4-41f0-9bb0-11b41f9910c0">
											<gml:posList>35.669480821970836 139.73828041604725 44.216 35.669480821970836 139.73828041604725 51.007 35.66946968792924 139.73822070280121 51.007 35.66946968792924 139.73822070280121 47.089 35.66946968792924 139.73822070280121 44.216 35.669480821970836 139.73828041604725 44.216</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0bf4625c-0008-4d32-86a1-6441d27cf190">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0bf4625c-0008-4d32-86a1-6441d27cf190">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0bf4625c-0008-4d32-86a1-6441d27cf190">
											<gml:posList>35.669483476938375 139.7382752433083 51.007 35.669513179639246 139.73826693453537 51.007 35.669513179639246 139.73826693453537 49.27 35.669483476938375 139.7382752433083 49.27 35.669483476938375 139.7382752433083 51.007</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3d3389ea-5772-4f31-9a78-e6368e3cb0fb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3d3389ea-5772-4f31-9a78-e6368e3cb0fb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3d3389ea-5772-4f31-9a78-e6368e3cb0fb">
											<gml:posList>35.669517481731766 139.73827015490753 51.007 35.669480821970836 139.73828041604725 51.007 35.669480821970836 139.73828041604725 44.216 35.66951328226102 139.73827133077734 44.216 35.66951328226102 139.73827133077734 47.089 35.669517481731766 139.73827015490753 47.089 35.669517481731766 139.73827015490753 51.007</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3d8466f6-9822-4444-b96b-14c0a739213a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3d8466f6-9822-4444-b96b-14c0a739213a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3d8466f6-9822-4444-b96b-14c0a739213a">
											<gml:posList>35.66955647071758 139.73845884312757 17.02 35.669486527405155 139.73812036181764 17.02 35.669486527405155 139.73812036181764 41.154 35.669497132066326 139.7381716806259 47.089 35.669497439693956 139.7381731493971 47.089 35.669497439693956 139.7381731493971 51.007 35.669517481731766 139.73827015490753 51.007 35.669517481731766 139.73827015490753 47.089 35.66955647071758 139.73845884312757 47.089 35.66955647071758 139.73845884312757 17.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a37a931e-4a29-47dc-ba67-58fa2fb31cf3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a37a931e-4a29-47dc-ba67-58fa2fb31cf3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a37a931e-4a29-47dc-ba67-58fa2fb31cf3">
											<gml:posList>35.66951328226102 139.73827133077734 44.216 35.66954734037373 139.7384366843192 44.216 35.66954734037373 139.7384366843192 47.089 35.66951328226102 139.73827133077734 47.089 35.66951328226102 139.73827133077734 44.216</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-dde145b8-10ac-40b7-83c3-26639eeea22c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-dde145b8-10ac-40b7-83c3-26639eeea22c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-dde145b8-10ac-40b7-83c3-26639eeea22c">
											<gml:posList>35.669440863538625 139.7382682905825 47.089 35.6694761652619 139.7384561545244 47.089 35.6694761652619 139.7384561545244 44.216 35.669440863538625 139.7382682905825 44.216 35.669440863538625 139.7382682905825 47.089</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3bb4bad4-8a59-40a6-8126-704fd0dee00a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3bb4bad4-8a59-40a6-8126-704fd0dee00a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3bb4bad4-8a59-40a6-8126-704fd0dee00a">
											<gml:posList>35.669398569547525 139.73825489759506 17.02 35.669441916648 139.73847212357015 17.02 35.669441916648 139.73847212357015 41.154 35.669398569547525 139.73825489759506 41.154 35.669398569547525 139.73825489759506 17.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a5fa5b3f-c807-49a2-bf8b-69121af90176">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a5fa5b3f-c807-49a2-bf8b-69121af90176">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a5fa5b3f-c807-49a2-bf8b-69121af90176">
											<gml:posList>35.66949656894621 139.73845183343323 47.089 35.66954734037373 139.7384366843192 47.089 35.66954734037373 139.7384366843192 44.216 35.66949656894621 139.73845183343323 44.216 35.66949656894621 139.73845183343323 47.089</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4ea9ea8c-7b7c-4bca-98e7-d46f7da9ec82">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4ea9ea8c-7b7c-4bca-98e7-d46f7da9ec82">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4ea9ea8c-7b7c-4bca-98e7-d46f7da9ec82">
											<gml:posList>35.6694761652619 139.7384561545244 47.089 35.66949621597484 139.73845001123823 47.089 35.66949621597484 139.73845001123823 44.216 35.6694761652619 139.7384561545244 44.216 35.6694761652619 139.7384561545244 47.089</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-fa197772-96b7-4578-ae9c-6f7d4143b2cf">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fa197772-96b7-4578-ae9c-6f7d4143b2cf">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fa197772-96b7-4578-ae9c-6f7d4143b2cf">
											<gml:posList>35.66949298521813 139.73845657646683 17.02 35.66949298521813 139.73845657646683 47.089 35.66947287141748 139.73846273087187 47.089 35.669441916648 139.73847212357015 41.154 35.669441916648 139.73847212357015 17.02 35.66949298521813 139.73845657646683 17.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-38165097-71da-43e7-afcb-556cae735902">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-38165097-71da-43e7-afcb-556cae735902">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-38165097-71da-43e7-afcb-556cae735902">
											<gml:posList>35.66949695801174 139.7384765873671 17.02 35.66949695801174 139.7384765873671 47.089 35.66949298521813 139.73845657646683 47.089 35.66949298521813 139.73845657646683 17.02 35.66949695801174 139.7384765873671 17.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-07cd2897-84cc-4015-818e-741902bcb66e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-07cd2897-84cc-4015-818e-741902bcb66e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-07cd2897-84cc-4015-818e-741902bcb66e">
											<gml:posList>35.66949695801174 139.7384765873671 17.02 35.66955647071758 139.73845884312757 17.02 35.66955647071758 139.73845884312757 47.089 35.66949695801174 139.7384765873671 47.089 35.66949695801174 139.7384765873671 17.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-8532</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">331.9714</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1210</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>4</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>