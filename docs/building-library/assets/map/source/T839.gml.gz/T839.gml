<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_ef83f40c-41d4-439e-911e-40d3f15988f1">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>3</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001003</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">401</bldg:usage>
			<bldg:measuredHeight uom="m">15.5</bldg:measuredHeight>
			<bldg:storeysAboveGround>5</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.673411839914486 139.73768289130442 0 35.67337169851733 139.73753137886712 0 35.67335703780436 139.73753718484144 0 35.67336464127558 139.73756600756542 0 35.67333841927344 139.7375759919362 0 35.67336885852129 139.73770061725972 0 35.673411839914486 139.73768289130442 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.673411839914486 139.73768289130442 8.85 35.67336885852129 139.73770061725972 8.85 35.67333841927344 139.7375759919362 8.85 35.67336464127558 139.73756600756542 8.85 35.67335703780436 139.73753718484144 8.85 35.67337169851733 139.73753137886712 8.85 35.673411839914486 139.73768289130442 8.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.673411839914486 139.73768289130442 8.85 35.67337169851733 139.73753137886712 8.85 35.67337169851733 139.73753137886712 24.36 35.673411839914486 139.73768289130442 24.36 35.673411839914486 139.73768289130442 8.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67337169851733 139.73753137886712 8.85 35.67335703780436 139.73753718484144 8.85 35.67335703780436 139.73753718484144 24.36 35.67337169851733 139.73753137886712 24.36 35.67337169851733 139.73753137886712 8.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67335703780436 139.73753718484144 8.85 35.67336464127558 139.73756600756542 8.85 35.67336464127558 139.73756600756542 24.36 35.67335703780436 139.73753718484144 24.36 35.67335703780436 139.73753718484144 8.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67336464127558 139.73756600756542 8.85 35.67333841927344 139.7375759919362 8.85 35.67333841927344 139.7375759919362 24.36 35.67336464127558 139.73756600756542 24.36 35.67336464127558 139.73756600756542 8.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67333841927344 139.7375759919362 8.85 35.67336885852129 139.73770061725972 8.85 35.67336885852129 139.73770061725972 24.36 35.67333841927344 139.7375759919362 24.36 35.67333841927344 139.7375759919362 8.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67336885852129 139.73770061725972 8.85 35.673411839914486 139.73768289130442 8.85 35.673411839914486 139.73768289130442 24.36 35.67336885852129 139.73770061725972 24.36 35.67336885852129 139.73770061725972 8.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.673411839914486 139.73768289130442 24.36 35.67337169851733 139.73753137886712 24.36 35.67335703780436 139.73753718484144 24.36 35.67336464127558 139.73756600756542 24.36 35.67333841927344 139.7375759919362 24.36 35.67336885852129 139.73770061725972 24.36 35.673411839914486 139.73768289130442 24.36</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-51b68f80-4968-4e4b-858f-2db2c2a73ea4"/>
							<gml:surfaceMember xlink:href="#poly-7a8802ec-09c6-4957-b9d7-3ed4122ce88b"/>
							<gml:surfaceMember xlink:href="#poly-8a154670-3f92-4ddc-9954-0ec754d8fde8"/>
							<gml:surfaceMember xlink:href="#poly-5c3ec7ff-8c5e-467c-b2b9-3855c4f2b0d6"/>
							<gml:surfaceMember xlink:href="#poly-0e793a1b-3307-4a37-afe8-f90cf6d176fc"/>
							<gml:surfaceMember xlink:href="#poly-86a21ade-386b-4e3b-829d-4fcea8b07f4d"/>
							<gml:surfaceMember xlink:href="#poly-cb83a74e-3159-4295-8437-d3c6d59d52ab"/>
							<gml:surfaceMember xlink:href="#poly-edc2ac9c-5b75-4cc6-a2c5-b7372ead29f3"/>
							<gml:surfaceMember xlink:href="#poly-06d57d4b-d8e4-45d4-9d39-928118159192"/>
							<gml:surfaceMember xlink:href="#poly-465c4842-26c5-489f-a75e-73aed0d2d8e3"/>
							<gml:surfaceMember xlink:href="#poly-86d76721-4e2f-4534-ab17-dad52d0cd3e6"/>
							<gml:surfaceMember xlink:href="#poly-257c3554-be2d-4d5f-94a1-616f1e2ba38b"/>
							<gml:surfaceMember xlink:href="#poly-ca8caa08-a1f2-4c1b-bc74-2f8d67e08c04"/>
							<gml:surfaceMember xlink:href="#poly-662dda57-0003-415f-80ed-1d30117a52fc"/>
							<gml:surfaceMember xlink:href="#poly-96dd353f-7837-480e-a635-c601dd2d6713"/>
							<gml:surfaceMember xlink:href="#poly-ee9e7bef-bc44-44f9-a476-90f8780f35d3"/>
							<gml:surfaceMember xlink:href="#poly-abf5d9bf-0e27-4060-9afa-a1b35d0b641f"/>
							<gml:surfaceMember xlink:href="#poly-0bda11b3-8b95-4a33-b8f1-a9e4e70770fb"/>
							<gml:surfaceMember xlink:href="#poly-aea8028a-23bc-4a58-abbe-0eefba594628"/>
							<gml:surfaceMember xlink:href="#poly-8e7ba406-16d0-4c61-8db7-2a17183dab1d"/>
							<gml:surfaceMember xlink:href="#poly-73aff979-4806-44e3-a798-8938e825863f"/>
							<gml:surfaceMember xlink:href="#poly-0e3f573e-f077-4df8-8b74-5cf921b30d2b"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_ef83f40c-41d4-439e-911e-40d3f15988f1_BuildingInstallation_1060">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8504f8dd-d966-4bdb-b66f-c8d827f9d325">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67333841927342 139.7375759919362 9.35 35.673331419855465 139.73754733419898 9.35 35.673357037804365 139.73753718484144 9.35 35.673364641275576 139.73756600756542 9.35 35.67333841927342 139.7375759919362 9.35</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2e3eedeb-4cc5-4fba-9def-f6dd0b89f35c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2e3eedeb-4cc5-4fba-9def-f6dd0b89f35c_0">
											<gml:posList>35.67333841927342 139.7375759919362 22.701 35.673331419855465 139.73754733419898 22.701 35.673331419855465 139.73754733419898 9.35 35.67333841927342 139.7375759919362 9.35 35.67333841927342 139.7375759919362 22.701</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-964145f9-fc7e-4384-8a80-c2bf68909f8e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-964145f9-fc7e-4384-8a80-c2bf68909f8e_0">
											<gml:posList>35.673331419855465 139.73754733419898 22.701 35.673357037804365 139.73753718484144 22.701 35.673357037804365 139.73753718484144 9.35 35.673331419855465 139.73754733419898 9.35 35.673331419855465 139.73754733419898 22.701</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f730e74c-643b-4f37-8065-0c311dd7aa16">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f730e74c-643b-4f37-8065-0c311dd7aa16_0">
											<gml:posList>35.673331419855465 139.73754733419898 22.701 35.67333841927342 139.7375759919362 22.701 35.673364641275576 139.73756600756542 22.701 35.673357037804365 139.73753718484144 22.701 35.673331419855465 139.73754733419898 22.701</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-19a73184-9090-4da2-8168-398ddc6d9112">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-19a73184-9090-4da2-8168-398ddc6d9112_0">
											<gml:posList>35.673364641275576 139.73756600756542 22.701 35.67333841927342 139.7375759919362 22.701 35.67333841927342 139.7375759919362 9.35 35.673364641275576 139.73756600756542 9.35 35.673364641275576 139.73756600756542 22.701</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d0f49698-6528-41e8-b2ff-021e47592be8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d0f49698-6528-41e8-b2ff-021e47592be8_0">
											<gml:posList>35.673357037804365 139.73753718484144 22.701 35.673364641275576 139.73756600756542 22.701 35.673364641275576 139.73756600756542 9.35 35.673357037804365 139.73753718484144 9.35 35.673357037804365 139.73753718484144 22.701</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-51b68f80-4968-4e4b-858f-2db2c2a73ea4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-51b68f80-4968-4e4b-858f-2db2c2a73ea4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-51b68f80-4968-4e4b-858f-2db2c2a73ea4">
											<gml:posList>35.673411839914486 139.73768289130442 8.85 35.67336885852129 139.73770061725972 8.85 35.67333841927342 139.7375759919362 8.85 35.673364641275576 139.73756600756542 8.85 35.673357037804365 139.73753718484144 8.85 35.67337169851729 139.73753137886712 8.85 35.673411839914486 139.73768289130442 8.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-7a8802ec-09c6-4957-b9d7-3ed4122ce88b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7a8802ec-09c6-4957-b9d7-3ed4122ce88b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7a8802ec-09c6-4957-b9d7-3ed4122ce88b">
											<gml:posList>35.67336395714307 139.73768055130665 24.905 35.6733663863273 139.73767485937293 24.905 35.67334296455018 139.73757895806065 24.905 35.67333841927342 139.7375759919362 24.905 35.67336395714307 139.73768055130665 24.905</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-8a154670-3f92-4ddc-9954-0ec754d8fde8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8a154670-3f92-4ddc-9954-0ec754d8fde8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8a154670-3f92-4ddc-9954-0ec754d8fde8">
											<gml:posList>35.673364641275576 139.73756600756542 24.905 35.67333841927342 139.7375759919362 24.905 35.67334296455018 139.73757895806065 24.905 35.673369267649655 139.73756894045337 24.905 35.673364641275576 139.73756600756542 24.905</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-5c3ec7ff-8c5e-467c-b2b9-3855c4f2b0d6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5c3ec7ff-8c5e-467c-b2b9-3855c4f2b0d6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5c3ec7ff-8c5e-467c-b2b9-3855c4f2b0d6">
											<gml:posList>35.673364641275576 139.73756600756542 24.905 35.673369267649655 139.73756894045337 24.905 35.67336165513029 139.73754007355157 24.905 35.673357037804365 139.73753718484144 24.905 35.673364641275576 139.73756600756542 24.905</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-0e793a1b-3307-4a37-afe8-f90cf6d176fc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0e793a1b-3307-4a37-afe8-f90cf6d176fc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0e793a1b-3307-4a37-afe8-f90cf6d176fc">
											<gml:posList>35.673357037804365 139.73753718484144 24.905 35.67336165513029 139.73754007355157 24.905 35.67336934141444 139.73753702653275 24.905 35.67337169851729 139.73753137886712 24.905 35.673357037804365 139.73753718484144 24.905</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-86a21ade-386b-4e3b-829d-4fcea8b07f4d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-86a21ade-386b-4e3b-829d-4fcea8b07f4d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-86a21ade-386b-4e3b-829d-4fcea8b07f4d">
											<gml:posList>35.673402105442904 139.7376606438676 24.461 35.67336934141444 139.73753702653275 24.461 35.67336165513029 139.73754007355157 24.461 35.673369267649655 139.73756894045337 24.461 35.67334296455018 139.73757895806065 24.461 35.6733663863273 139.73767485937293 24.461 35.673402105442904 139.7376606438676 24.461</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-cb83a74e-3159-4295-8437-d3c6d59d52ab">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cb83a74e-3159-4295-8437-d3c6d59d52ab">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cb83a74e-3159-4295-8437-d3c6d59d52ab">
											<gml:posList>35.67340671375213 139.73766353259722 24.905 35.673402105442904 139.7376606438676 24.905 35.6733663863273 139.73767485937293 24.905 35.67336395714307 139.73768055130665 24.905 35.67340671375213 139.73766353259722 24.905</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-edc2ac9c-5b75-4cc6-a2c5-b7372ead29f3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-edc2ac9c-5b75-4cc6-a2c5-b7372ead29f3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-edc2ac9c-5b75-4cc6-a2c5-b7372ead29f3">
											<gml:posList>35.67336395714307 139.73768055130665 21.21 35.67336885852129 139.73770061725972 21.21 35.673411839914486 139.73768289130442 21.21 35.67340671375213 139.73766353259722 21.21 35.67336395714307 139.73768055130665 21.21</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-06d57d4b-d8e4-45d4-9d39-928118159192">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-06d57d4b-d8e4-45d4-9d39-928118159192">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-06d57d4b-d8e4-45d4-9d39-928118159192">
											<gml:posList>35.67337169851729 139.73753137886712 24.905 35.67336934141444 139.73753702653275 24.905 35.673402105442904 139.7376606438676 24.905 35.67340671375213 139.73766353259722 24.905 35.67337169851729 139.73753137886712 24.905</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-465c4842-26c5-489f-a75e-73aed0d2d8e3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-465c4842-26c5-489f-a75e-73aed0d2d8e3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-465c4842-26c5-489f-a75e-73aed0d2d8e3">
											<gml:posList>35.673369267649655 139.73756894045337 24.905 35.673369267649655 139.73756894045337 24.461 35.67336165513029 139.73754007355157 24.461 35.67336165513029 139.73754007355157 24.905 35.673369267649655 139.73756894045337 24.905</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-86d76721-4e2f-4534-ab17-dad52d0cd3e6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-86d76721-4e2f-4534-ab17-dad52d0cd3e6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-86d76721-4e2f-4534-ab17-dad52d0cd3e6">
											<gml:posList>35.67337169851729 139.73753137886712 8.85 35.673357037804365 139.73753718484144 8.85 35.673357037804365 139.73753718484144 24.905 35.67337169851729 139.73753137886712 24.905 35.67337169851729 139.73753137886712 8.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-257c3554-be2d-4d5f-94a1-616f1e2ba38b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-257c3554-be2d-4d5f-94a1-616f1e2ba38b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-257c3554-be2d-4d5f-94a1-616f1e2ba38b">
											<gml:posList>35.67336165513029 139.73754007355157 24.905 35.67336165513029 139.73754007355157 24.461 35.67336934141444 139.73753702653275 24.461 35.67336934141444 139.73753702653275 24.905 35.67336165513029 139.73754007355157 24.905</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ca8caa08-a1f2-4c1b-bc74-2f8d67e08c04">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ca8caa08-a1f2-4c1b-bc74-2f8d67e08c04">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ca8caa08-a1f2-4c1b-bc74-2f8d67e08c04">
											<gml:posList>35.673357037804365 139.73753718484144 8.85 35.673364641275576 139.73756600756542 8.85 35.673364641275576 139.73756600756542 24.905 35.673357037804365 139.73753718484144 24.905 35.673357037804365 139.73753718484144 8.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-662dda57-0003-415f-80ed-1d30117a52fc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-662dda57-0003-415f-80ed-1d30117a52fc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-662dda57-0003-415f-80ed-1d30117a52fc">
											<gml:posList>35.673364641275576 139.73756600756542 8.85 35.67333841927342 139.7375759919362 8.85 35.67333841927342 139.7375759919362 24.905 35.673364641275576 139.73756600756542 24.905 35.673364641275576 139.73756600756542 8.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-96dd353f-7837-480e-a635-c601dd2d6713">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-96dd353f-7837-480e-a635-c601dd2d6713">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-96dd353f-7837-480e-a635-c601dd2d6713">
											<gml:posList>35.67334296455018 139.73757895806065 24.905 35.67334296455018 139.73757895806065 24.461 35.673369267649655 139.73756894045337 24.461 35.673369267649655 139.73756894045337 24.905 35.67334296455018 139.73757895806065 24.905</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ee9e7bef-bc44-44f9-a476-90f8780f35d3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ee9e7bef-bc44-44f9-a476-90f8780f35d3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ee9e7bef-bc44-44f9-a476-90f8780f35d3">
											<gml:posList>35.67336934141444 139.73753702653275 24.905 35.67336934141444 139.73753702653275 24.461 35.673402105442904 139.7376606438676 24.461 35.673402105442904 139.7376606438676 24.905 35.67336934141444 139.73753702653275 24.905</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-abf5d9bf-0e27-4060-9afa-a1b35d0b641f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-abf5d9bf-0e27-4060-9afa-a1b35d0b641f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-abf5d9bf-0e27-4060-9afa-a1b35d0b641f">
											<gml:posList>35.673411839914486 139.73768289130442 8.85 35.67337169851729 139.73753137886712 8.85 35.67337169851729 139.73753137886712 24.905 35.67340671375213 139.73766353259722 24.905 35.67340671375213 139.73766353259722 21.21 35.673411839914486 139.73768289130442 21.21 35.673411839914486 139.73768289130442 8.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0bda11b3-8b95-4a33-b8f1-a9e4e70770fb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0bda11b3-8b95-4a33-b8f1-a9e4e70770fb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0bda11b3-8b95-4a33-b8f1-a9e4e70770fb">
											<gml:posList>35.6733663863273 139.73767485937293 24.905 35.6733663863273 139.73767485937293 24.461 35.67334296455018 139.73757895806065 24.461 35.67334296455018 139.73757895806065 24.905 35.6733663863273 139.73767485937293 24.905</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-aea8028a-23bc-4a58-abbe-0eefba594628">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-aea8028a-23bc-4a58-abbe-0eefba594628">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-aea8028a-23bc-4a58-abbe-0eefba594628">
											<gml:posList>35.67336395714307 139.73768055130665 21.21 35.67336395714307 139.73768055130665 24.905 35.67333841927342 139.7375759919362 24.905 35.67333841927342 139.7375759919362 8.85 35.67336885852129 139.73770061725972 8.85 35.67336885852129 139.73770061725972 21.21 35.67336395714307 139.73768055130665 21.21</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8e7ba406-16d0-4c61-8db7-2a17183dab1d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8e7ba406-16d0-4c61-8db7-2a17183dab1d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8e7ba406-16d0-4c61-8db7-2a17183dab1d">
											<gml:posList>35.673402105442904 139.7376606438676 24.905 35.673402105442904 139.7376606438676 24.461 35.6733663863273 139.73767485937293 24.461 35.6733663863273 139.73767485937293 24.905 35.673402105442904 139.7376606438676 24.905</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-73aff979-4806-44e3-a798-8938e825863f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-73aff979-4806-44e3-a798-8938e825863f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-73aff979-4806-44e3-a798-8938e825863f">
											<gml:posList>35.67340671375213 139.73766353259722 21.21 35.67340671375213 139.73766353259722 24.905 35.67336395714307 139.73768055130665 24.905 35.67336395714307 139.73768055130665 21.21 35.67340671375213 139.73766353259722 21.21</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0e3f573e-f077-4df8-8b74-5cf921b30d2b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0e3f573e-f077-4df8-8b74-5cf921b30d2b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0e3f573e-f077-4df8-8b74-5cf921b30d2b">
											<gml:posList>35.67336885852129 139.73770061725972 8.85 35.673411839914486 139.73768289130442 8.85 35.673411839914486 139.73768289130442 21.21 35.67336885852129 139.73770061725972 21.21 35.67336885852129 139.73770061725972 8.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂三丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-1975</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">70.2768</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1210</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>5</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.13</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>