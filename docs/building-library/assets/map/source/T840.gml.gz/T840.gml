<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_f0b4cf1f-1eeb-4f12-aca8-7cd25e4eaa2c">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="説明注記">
				<gen:value>地下駐エレベータ</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>18</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103018002</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="再開発等促進区を定める地区計画">
				<gen:value>虎ノ門二丁目10地区</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3001</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">401</bldg:usage>
			<bldg:measuredHeight uom="m">3.8</bldg:measuredHeight>
			<bldg:storeysAboveGround>0</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.667186910667304 139.74555041203124 0 35.66715071282913 139.7456017042398 0 35.66718959193009 139.74564275215454 0 35.667218495988955 139.74560151962078 0 35.66720765826539 139.7455723705058 0 35.667186910667304 139.74555041203124 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667186910667304 139.74555041203124 8.555 35.66720765826539 139.7455723705058 8.555 35.667218495988955 139.74560151962078 8.555 35.66718959193009 139.74564275215454 8.555 35.66715071282913 139.7456017042398 8.555 35.667186910667304 139.74555041203124 8.555</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667186910667304 139.74555041203124 8.555 35.66715071282913 139.7456017042398 8.555 35.66715071282913 139.7456017042398 12.37 35.667186910667304 139.74555041203124 12.37 35.667186910667304 139.74555041203124 8.555</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66715071282913 139.7456017042398 8.555 35.66718959193009 139.74564275215454 8.555 35.66718959193009 139.74564275215454 12.37 35.66715071282913 139.7456017042398 12.37 35.66715071282913 139.7456017042398 8.555</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66718959193009 139.74564275215454 8.555 35.667218495988955 139.74560151962078 8.555 35.667218495988955 139.74560151962078 12.37 35.66718959193009 139.74564275215454 12.37 35.66718959193009 139.74564275215454 8.555</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667218495988955 139.74560151962078 8.555 35.66720765826539 139.7455723705058 8.555 35.66720765826539 139.7455723705058 12.37 35.667218495988955 139.74560151962078 12.37 35.667218495988955 139.74560151962078 8.555</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66720765826539 139.7455723705058 8.555 35.667186910667304 139.74555041203124 8.555 35.667186910667304 139.74555041203124 12.37 35.66720765826539 139.7455723705058 12.37 35.66720765826539 139.7455723705058 8.555</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667186910667304 139.74555041203124 12.37 35.66715071282913 139.7456017042398 12.37 35.66718959193009 139.74564275215454 12.37 35.667218495988955 139.74560151962078 12.37 35.66720765826539 139.7455723705058 12.37 35.667186910667304 139.74555041203124 12.37</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-3477d09f-bdc0-4072-8178-0f4da7583f76"/>
							<gml:surfaceMember xlink:href="#poly-8175a45d-9a0b-4a15-bac5-6af03c15e948"/>
							<gml:surfaceMember xlink:href="#poly-5e2469e8-6ff6-49ae-9bc3-784c6b0d9fdd"/>
							<gml:surfaceMember xlink:href="#poly-a61ea22e-fad9-408a-892b-ba6e6839bf27"/>
							<gml:surfaceMember xlink:href="#poly-d5a07420-422e-4066-b628-ae7203b4d998"/>
							<gml:surfaceMember xlink:href="#poly-c0f65234-863c-4644-baf9-f27094e84fb6"/>
							<gml:surfaceMember xlink:href="#poly-1cfbe572-e5d4-49ca-b55e-cb99cc87a548"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-3477d09f-bdc0-4072-8178-0f4da7583f76">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3477d09f-bdc0-4072-8178-0f4da7583f76">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3477d09f-bdc0-4072-8178-0f4da7583f76">
											<gml:posList>35.6671869106673 139.7455504120312 8.555 35.667207658265376 139.7455723705058 8.555 35.66721849598897 139.74560151962078 8.555 35.667189591930075 139.74564275215454 8.555 35.6671507128291 139.7456017042398 8.555 35.6671869106673 139.7455504120312 8.555</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-8175a45d-9a0b-4a15-bac5-6af03c15e948">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8175a45d-9a0b-4a15-bac5-6af03c15e948">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8175a45d-9a0b-4a15-bac5-6af03c15e948">
											<gml:posList>35.6671869106673 139.7455504120312 12.1 35.6671507128291 139.7456017042398 12.1 35.667189591930075 139.74564275215454 12.1 35.66721849598897 139.74560151962078 12.1 35.667207658265376 139.7455723705058 12.1 35.6671869106673 139.7455504120312 12.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5e2469e8-6ff6-49ae-9bc3-784c6b0d9fdd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5e2469e8-6ff6-49ae-9bc3-784c6b0d9fdd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5e2469e8-6ff6-49ae-9bc3-784c6b0d9fdd">
											<gml:posList>35.6671869106673 139.7455504120312 8.555 35.6671507128291 139.7456017042398 8.555 35.6671507128291 139.7456017042398 12.1 35.6671869106673 139.7455504120312 12.1 35.6671869106673 139.7455504120312 8.555</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a61ea22e-fad9-408a-892b-ba6e6839bf27">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a61ea22e-fad9-408a-892b-ba6e6839bf27">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a61ea22e-fad9-408a-892b-ba6e6839bf27">
											<gml:posList>35.6671507128291 139.7456017042398 8.555 35.667189591930075 139.74564275215454 8.555 35.667189591930075 139.74564275215454 12.1 35.6671507128291 139.7456017042398 12.1 35.6671507128291 139.7456017042398 8.555</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d5a07420-422e-4066-b628-ae7203b4d998">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d5a07420-422e-4066-b628-ae7203b4d998">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d5a07420-422e-4066-b628-ae7203b4d998">
											<gml:posList>35.667207658265376 139.7455723705058 8.555 35.6671869106673 139.7455504120312 8.555 35.6671869106673 139.7455504120312 12.1 35.667207658265376 139.7455723705058 12.1 35.667207658265376 139.7455723705058 8.555</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c0f65234-863c-4644-baf9-f27094e84fb6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c0f65234-863c-4644-baf9-f27094e84fb6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c0f65234-863c-4644-baf9-f27094e84fb6">
											<gml:posList>35.667189591930075 139.74564275215454 8.555 35.66721849598897 139.74560151962078 8.555 35.66721849598897 139.74560151962078 12.1 35.667189591930075 139.74564275215454 12.1 35.667189591930075 139.74564275215454 8.555</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1cfbe572-e5d4-49ca-b55e-cb99cc87a548">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1cfbe572-e5d4-49ca-b55e-cb99cc87a548">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1cfbe572-e5d4-49ca-b55e-cb99cc87a548">
											<gml:posList>35.66721849598897 139.74560151962078 8.555 35.667207658265376 139.7455723705058 8.555 35.667207658265376 139.7455723705058 12.1 35.66721849598897 139.74560151962078 12.1 35.66721849598897 139.74560151962078 8.555</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区虎ノ門二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-5506</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">33.27705</uro:buildingRoofEdgeArea>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1210</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>6</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.04</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>