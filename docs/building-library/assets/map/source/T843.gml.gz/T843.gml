<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_f279fb2a-9797-4dff-86b2-a71cf515be05">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">403</bldg:usage>
			<bldg:measuredHeight uom="m">19.6</bldg:measuredHeight>
			<bldg:storeysAboveGround>6</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.671847285934206 139.7387717297248 0 35.671775286347035 139.7387973319487 0 35.671796447714556 139.7388855681671 0 35.67186944298953 139.73886526714526 0 35.671847285934206 139.7387717297248 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671847285934206 139.7387717297248 10.388 35.67186944298953 139.73886526714526 10.388 35.671796447714556 139.7388855681671 10.388 35.671775286347035 139.7387973319487 10.388 35.671847285934206 139.7387717297248 10.388</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671847285934206 139.7387717297248 10.388 35.671775286347035 139.7387973319487 10.388 35.671775286347035 139.7387973319487 29.989999999999995 35.671847285934206 139.7387717297248 29.989999999999995 35.671847285934206 139.7387717297248 10.388</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671775286347035 139.7387973319487 10.388 35.671796447714556 139.7388855681671 10.388 35.671796447714556 139.7388855681671 29.989999999999995 35.671775286347035 139.7387973319487 29.989999999999995 35.671775286347035 139.7387973319487 10.388</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671796447714556 139.7388855681671 10.388 35.67186944298953 139.73886526714526 10.388 35.67186944298953 139.73886526714526 29.989999999999995 35.671796447714556 139.7388855681671 29.989999999999995 35.671796447714556 139.7388855681671 10.388</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67186944298953 139.73886526714526 10.388 35.671847285934206 139.7387717297248 10.388 35.671847285934206 139.7387717297248 29.989999999999995 35.67186944298953 139.73886526714526 29.989999999999995 35.67186944298953 139.73886526714526 10.388</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671847285934206 139.7387717297248 29.989999999999995 35.671775286347035 139.7387973319487 29.989999999999995 35.671796447714556 139.7388855681671 29.989999999999995 35.67186944298953 139.73886526714526 29.989999999999995 35.671847285934206 139.7387717297248 29.989999999999995</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-08ecf5d8-6da5-42d0-ab76-77d1e508a719"/>
							<gml:surfaceMember xlink:href="#poly-b9721b97-2b0a-4c4b-868d-bc5bcc19edda"/>
							<gml:surfaceMember xlink:href="#poly-d1050e67-3723-4bd6-ab54-0df03c2f157b"/>
							<gml:surfaceMember xlink:href="#poly-b8479105-891d-468a-a310-a4680f9e5454"/>
							<gml:surfaceMember xlink:href="#poly-44c03f16-65c4-42a8-9b32-721e330079c6"/>
							<gml:surfaceMember xlink:href="#poly-f87cfa0b-97a1-4a61-9e0e-cb9025432f74"/>
							<gml:surfaceMember xlink:href="#poly-74198eb3-8840-48a8-84e2-bb254b27683b"/>
							<gml:surfaceMember xlink:href="#poly-dc83dd9d-d143-4ef5-a7ce-d2a76ab0b589"/>
							<gml:surfaceMember xlink:href="#poly-71c6355b-0757-4797-9ce6-b62d0ff516bf"/>
							<gml:surfaceMember xlink:href="#poly-cda30d0c-8e6f-4e00-8c82-1bef387c4c34"/>
							<gml:surfaceMember xlink:href="#poly-0c2a555d-1def-4f69-b275-c91ed931f67e"/>
							<gml:surfaceMember xlink:href="#poly-ba46f8c3-4ee3-4fac-a096-76729d44d56d"/>
							<gml:surfaceMember xlink:href="#poly-ce5d4e64-04ed-4410-a1ae-12abae5ca1f6"/>
							<gml:surfaceMember xlink:href="#poly-453cf427-4c4a-4af4-98c7-699fee13c183"/>
							<gml:surfaceMember xlink:href="#poly-020a1b38-6b21-4fac-b105-161f7d4ee254"/>
							<gml:surfaceMember xlink:href="#poly-0f4066ab-f687-4b31-9d49-70ffdab764ea"/>
							<gml:surfaceMember xlink:href="#poly-a37b702f-e943-4f94-a495-ecdcc5776050"/>
							<gml:surfaceMember xlink:href="#poly-823f4d9a-e292-413a-b5a7-39fc7b08ab04"/>
							<gml:surfaceMember xlink:href="#poly-06ae32c0-7b39-4cca-ade4-d4bd2eb7fb2e"/>
							<gml:surfaceMember xlink:href="#poly-e070a142-4d9a-4d64-9557-73522d682382"/>
							<gml:surfaceMember xlink:href="#poly-0378fcd8-d374-4494-aaf0-bc874eabd531"/>
							<gml:surfaceMember xlink:href="#poly-00baa319-2a68-4c96-84bd-1be33e54db94"/>
							<gml:surfaceMember xlink:href="#poly-44cd3454-f453-4344-aa9d-b593bb1d7cd4"/>
							<gml:surfaceMember xlink:href="#poly-283cc9b0-4fd9-4feb-a593-c9d78a91bf31"/>
							<gml:surfaceMember xlink:href="#poly-5a311240-3748-4250-817d-4479b346e1fa"/>
							<gml:surfaceMember xlink:href="#poly-0fb9d0a3-7d13-453e-aca3-26b8ba1fc544"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_f279fb2a-9797-4dff-86b2-a71cf515be05_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-43021b48-0b1c-4fb0-9d6e-c05b9d929884">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-43021b48-0b1c-4fb0-9d6e-c05b9d929884_0">
											<gml:posList>35.67178794881126 139.73879500830907 33.661 35.67179071523411 139.7387939998197 33.661 35.67178794881126 139.73879500830907 33.583 35.67178794881126 139.73879500830907 33.661</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bfd6eaa1-9bf0-4545-9725-5f2eac886758">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bfd6eaa1-9bf0-4545-9725-5f2eac886758_0">
											<gml:posList>35.67178794881126 139.73879500830907 33.583 35.67179071523411 139.7387939998197 33.446 35.671788020886325 139.73879496403825 33.446 35.67178794881126 139.73879500830907 33.583</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5b3ba309-4a2f-46b3-902c-38577ccfe4bf">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5b3ba309-4a2f-46b3-902c-38577ccfe4bf_0">
											<gml:posList>35.67178794881126 139.73879500830907 33.583 35.67179071523411 139.7387939998197 33.661 35.67179071523411 139.7387939998197 33.446 35.67178794881126 139.73879500830907 33.583</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2c1634b5-1aee-41d5-92d5-2ac64adbbcff">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2c1634b5-1aee-41d5-92d5-2ac64adbbcff_0">
											<gml:posList>35.67178433998999 139.73880224799103 33.446 35.67178444954218 139.7388040152943 35.261 35.67178433998999 139.73880224799103 35.261 35.67178433998999 139.73880224799103 33.446</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-095f24c0-2de4-4175-bc60-a660bbe04475">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-095f24c0-2de4-4175-bc60-a660bbe04475_0">
											<gml:posList>35.67178433998999 139.73880224799103 33.446 35.67178444954218 139.7388040152943 33.446 35.67178444954218 139.7388040152943 35.261 35.67178433998999 139.73880224799103 33.446</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-69dc1d89-6060-4a68-8123-5e08e92db42b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-69dc1d89-6060-4a68-8123-5e08e92db42b_0">
											<gml:posList>35.67178452789923 139.73880049138347 33.446 35.67178433998999 139.73880224799103 35.261 35.67178452789923 139.73880049138347 35.261 35.67178452789923 139.73880049138347 33.446</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-048c7ee7-c3ab-4043-9171-804c0b78b47a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-048c7ee7-c3ab-4043-9171-804c0b78b47a_0">
											<gml:posList>35.67178452789923 139.73880049138347 33.446 35.67178433998999 139.73880224799103 33.446 35.67178433998999 139.73880224799103 35.261 35.67178452789923 139.73880049138347 33.446</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d6e43719-af6c-4bb8-ac11-a8a8b83ad352">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d6e43719-af6c-4bb8-ac11-a8a8b83ad352_0">
											<gml:posList>35.67178444954218 139.7388040152943 33.446 35.67178486550879 139.7388057159576 35.261 35.67178444954218 139.7388040152943 35.261 35.67178444954218 139.7388040152943 33.446</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5b55a0a3-7359-4f83-a09d-8c2cf9981856">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5b55a0a3-7359-4f83-a09d-8c2cf9981856_0">
											<gml:posList>35.67178444954218 139.7388040152943 33.446 35.67178486550879 139.7388057159576 33.446 35.67178486550879 139.7388057159576 35.261 35.67178444954218 139.7388040152943 33.446</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0b244a28-d632-4f79-abfa-d66fd8636b99">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0b244a28-d632-4f79-abfa-d66fd8636b99_0">
											<gml:posList>35.67178500430818 139.73879881176092 33.446 35.67178452789923 139.73880049138347 35.261 35.67178500430818 139.73879881176092 35.261 35.67178500430818 139.73879881176092 33.446</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cf5fba2c-41a6-4ec3-a218-d267bcea1e84">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cf5fba2c-41a6-4ec3-a218-d267bcea1e84_0">
											<gml:posList>35.67178500430818 139.73879881176092 33.446 35.67178452789923 139.73880049138347 33.446 35.67178452789923 139.73880049138347 35.261 35.67178500430818 139.73879881176092 33.446</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0b848c89-a2ab-4d5b-959e-7d2e96ed9a0d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0b848c89-a2ab-4d5b-959e-7d2e96ed9a0d_0">
											<gml:posList>35.67178486550879 139.7388057159576 33.446 35.671785560787974 139.73880727268767 35.261 35.67178486550879 139.7388057159576 35.261 35.67178486550879 139.7388057159576 33.446</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-66bcad3a-fb75-4602-bbc9-4d015bf661dc">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-66bcad3a-fb75-4602-bbc9-4d015bf661dc_0">
											<gml:posList>35.67178486550879 139.7388057159576 33.446 35.671785560787974 139.73880727268767 33.446 35.671785560787974 139.73880727268767 35.261 35.67178486550879 139.7388057159576 33.446</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1bdcd662-4a16-4ab9-aec0-a4251066342a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1bdcd662-4a16-4ab9-aec0-a4251066342a_0">
											<gml:posList>35.67178576027253 139.7387972975055 33.446 35.67178500430818 139.73879881176092 35.261 35.67178576027253 139.7387972975055 35.261 35.67178576027253 139.7387972975055 33.446</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d676d7b9-30f0-4af2-a5f8-7c297b462162">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d676d7b9-30f0-4af2-a5f8-7c297b462162_0">
											<gml:posList>35.67178576027253 139.7387972975055 33.446 35.67178500430818 139.73879881176092 33.446 35.67178500430818 139.73879881176092 35.261 35.67178576027253 139.7387972975055 33.446</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1fb3ab7e-956d-4ec7-a019-b3b39f1be43d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1fb3ab7e-956d-4ec7-a019-b3b39f1be43d_0">
											<gml:posList>35.671785560787974 139.73880727268767 33.446 35.67178649927281 139.7388086192485 35.261 35.671785560787974 139.73880727268767 35.261 35.671785560787974 139.73880727268767 33.446</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7f65fa33-b0c9-4687-819e-9c1bd4024eac">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7f65fa33-b0c9-4687-819e-9c1bd4024eac_0">
											<gml:posList>35.671785560787974 139.73880727268767 33.446 35.67178649927281 139.7388086192485 33.446 35.67178649927281 139.7388086192485 35.261 35.671785560787974 139.73880727268767 33.446</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-14d51690-aff0-4940-868d-bb5953b9f576">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-14d51690-aff0-4940-868d-bb5953b9f576_0">
											<gml:posList>35.67178675978943 139.73879601493837 33.446 35.67178576027253 139.7387972975055 35.261 35.67178675978943 139.73879601493837 35.261 35.67178675978943 139.73879601493837 33.446</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ae3ba84a-1a1b-44ce-abab-520acb87740c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ae3ba84a-1a1b-44ce-abab-520acb87740c_0">
											<gml:posList>35.67178675978943 139.73879601493837 33.446 35.67178576027253 139.7387972975055 33.446 35.67178576027253 139.7387972975055 35.261 35.67178675978943 139.73879601493837 33.446</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ffc422b8-d0ca-435b-bf33-79df2b207de8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ffc422b8-d0ca-435b-bf33-79df2b207de8_0">
											<gml:posList>35.67178649927281 139.7388086192485 33.446 35.67178765387881 139.7388097004396 35.261 35.67178649927281 139.7388086192485 35.261 35.67178649927281 139.7388086192485 33.446</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b9b05f53-7c90-471b-97fe-96715c5dbd30">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b9b05f53-7c90-471b-97fe-96715c5dbd30_0">
											<gml:posList>35.67178649927281 139.7388086192485 33.446 35.67178765387881 139.7388097004396 33.446 35.67178765387881 139.7388097004396 35.261 35.67178649927281 139.7388086192485 33.446</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-51dc819c-9cca-4228-a057-c8779c560b7f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-51dc819c-9cca-4228-a057-c8779c560b7f_0">
											<gml:posList>35.67178794881126 139.73879500830907 33.446 35.67178675978943 139.73879601493837 33.446 35.67178794881126 139.73879500830907 33.583 35.67178794881126 139.73879500830907 33.446</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5641e729-75e2-4618-9331-0e4b9ceec710">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5641e729-75e2-4618-9331-0e4b9ceec710_0">
											<gml:posList>35.67178794881126 139.73879500830907 33.583 35.67178675978943 139.73879601493837 33.446 35.67178794881126 139.73879500830907 33.661 35.67178794881126 139.73879500830907 33.583</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3ccc0230-b0d1-4e18-b7c8-522b6ccca04a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3ccc0230-b0d1-4e18-b7c8-522b6ccca04a_0">
											<gml:posList>35.67178794881126 139.73879500830907 33.661 35.67178675978943 139.73879601493837 35.261 35.67178794881126 139.73879500830907 35.261 35.67178794881126 139.73879500830907 33.661</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6356df4a-bf1e-4dcf-a8f8-783c8f42c214">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6356df4a-bf1e-4dcf-a8f8-783c8f42c214_0">
											<gml:posList>35.67178794881126 139.73879500830907 33.661 35.67178675978943 139.73879601493837 33.446 35.67178675978943 139.73879601493837 35.261 35.67178794881126 139.73879500830907 33.661</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-289a1686-a0ba-4cec-8b43-bcd705988797">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-289a1686-a0ba-4cec-8b43-bcd705988797_0">
											<gml:posList>35.67178765387881 139.7388097004396 33.446 35.67178896146657 139.73881046110324 35.261 35.67178765387881 139.7388097004396 35.261 35.67178765387881 139.7388097004396 33.446</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-60b34aeb-257a-4d16-b1f6-39001b9d3e25">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-60b34aeb-257a-4d16-b1f6-39001b9d3e25_0">
											<gml:posList>35.67178765387881 139.7388097004396 33.446 35.67178896146657 139.73881046110324 33.446 35.67178896146657 139.73881046110324 35.261 35.67178765387881 139.7388097004396 33.446</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bea14db2-ca55-492c-97c3-f9c1feb4a82b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bea14db2-ca55-492c-97c3-f9c1feb4a82b_0">
											<gml:posList>35.67178794881126 139.73879500830907 33.661 35.671789291317836 139.7387943218459 35.261 35.671789291317836 139.7387943218459 33.661 35.67178794881126 139.73879500830907 33.661</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7719351e-0eff-40d5-b95b-56aea0752ee4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7719351e-0eff-40d5-b95b-56aea0752ee4_0">
											<gml:posList>35.67178794881126 139.73879500830907 33.661 35.67178794881126 139.73879500830907 35.261 35.671789291317836 139.7387943218459 35.261 35.67178794881126 139.73879500830907 33.661</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9146bc4b-20d5-4688-a54b-bee0f276097e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9146bc4b-20d5-4688-a54b-bee0f276097e_0">
											<gml:posList>35.67178896146657 139.73881046110324 33.446 35.67179036793643 139.7388108792103 35.261 35.67178896146657 139.73881046110324 35.261 35.67178896146657 139.73881046110324 33.446</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b88395a0-d64d-4b12-a2f7-f6ed66c573dd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b88395a0-d64d-4b12-a2f7-f6ed66c573dd_0">
											<gml:posList>35.67178896146657 139.73881046110324 33.446 35.67179036793643 139.7388108792103 33.446 35.67179036793643 139.7388108792103 35.261 35.67178896146657 139.73881046110324 33.446</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ffb52cd4-0d42-4283-8c6f-a82b5a149f10">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ffb52cd4-0d42-4283-8c6f-a82b5a149f10_0">
											<gml:posList>35.67179071523411 139.7387939998197 33.661 35.671789291317836 139.7387943218459 35.261 35.67179071523411 139.7387939998197 35.261 35.67179071523411 139.7387939998197 33.661</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b408166a-4978-4189-87f9-3086badc6ffa">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b408166a-4978-4189-87f9-3086badc6ffa_0">
											<gml:posList>35.67179071523411 139.7387939998197 33.661 35.671789291317836 139.7387943218459 33.661 35.671789291317836 139.7387943218459 35.261 35.67179071523411 139.7387939998197 33.661</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a8b48fee-03a6-4ac4-8604-4d7d7c62958d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a8b48fee-03a6-4ac4-8604-4d7d7c62958d_0">
											<gml:posList>35.67179036793643 139.7388108792103 33.446 35.67179181016634 139.73881092169572 35.261 35.67179036793643 139.7388108792103 35.261 35.67179036793643 139.7388108792103 33.446</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-07a38dfe-242b-4913-8ce6-1822aee3a366">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-07a38dfe-242b-4913-8ce6-1822aee3a366_0">
											<gml:posList>35.67179036793643 139.7388108792103 33.446 35.67179181016634 139.73881092169572 33.446 35.67179181016634 139.73881092169572 35.261 35.67179036793643 139.7388108792103 33.446</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cc0ce651-e30f-4e30-a9b7-ff4dc8ad6dd2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cc0ce651-e30f-4e30-a9b7-ff4dc8ad6dd2_0">
											<gml:posList>35.67179487152179 139.73879522107507 35.261 35.67179356393394 139.7387944604116 35.261 35.67179696461287 139.73879764882696 35.261 35.67179487152179 139.73879522107507 35.261</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-420c68cc-5b43-4e8b-af69-4fb1f53bb5cb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-420c68cc-5b43-4e8b-af69-4fb1f53bb5cb_0">
											<gml:posList>35.67179696461287 139.73879764882696 35.261 35.67179602612791 139.73879630226614 35.261 35.67179487152179 139.73879522107507 35.261 35.67179696461287 139.73879764882696 35.261</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4f546c5a-7e6d-479b-93ca-3a1888688eca">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4f546c5a-7e6d-479b-93ca-3a1888688eca_0">
											<gml:posList>35.67179356393394 139.7387944604116 35.261 35.671792157464026 139.73879404230487 35.261 35.67179071523411 139.7387939998197 35.261 35.67179356393394 139.7387944604116 35.261</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4f3d6ed0-9c6f-4256-ac3e-175c24202217">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4f3d6ed0-9c6f-4256-ac3e-175c24202217_0">
											<gml:posList>35.671798185411035 139.7388026735243 35.261 35.67179765989216 139.7387992055572 35.261 35.67179696461287 139.73879764882696 35.261 35.671798185411035 139.7388026735243 35.261</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-18dfa037-6d71-41d0-9ae7-64c922737717">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-18dfa037-6d71-41d0-9ae7-64c922737717_0">
											<gml:posList>35.67178794881126 139.73879500830907 35.261 35.67179071523411 139.7387939998197 35.261 35.671789291317836 139.7387943218459 35.261 35.67178794881126 139.73879500830907 35.261</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-63b63de4-17f8-4aaa-b10e-c61ab855caab">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-63b63de4-17f8-4aaa-b10e-c61ab855caab_0">
											<gml:posList>35.67179807585884 139.73880090622075 35.261 35.67179765989216 139.7387992055572 35.261 35.671798185411035 139.7388026735243 35.261 35.67179807585884 139.73880090622075 35.261</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6a2638d9-977c-4d7b-a0f9-177eaad6a377">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6a2638d9-977c-4d7b-a0f9-177eaad6a377_0">
											<gml:posList>35.67178794881126 139.73879500830907 35.261 35.67178675978943 139.73879601493837 35.261 35.67179356393394 139.7387944604116 35.261 35.67178794881126 139.73879500830907 35.261</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-47fe7fd1-0b69-4cd2-8e6e-d651dae82e91">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-47fe7fd1-0b69-4cd2-8e6e-d651dae82e91_0">
											<gml:posList>35.67179799750178 139.73880443013215 35.261 35.671798185411035 139.7388026735243 35.261 35.67179696461287 139.73879764882696 35.261 35.67179799750178 139.73880443013215 35.261</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1d030ec6-40ff-4b1e-be8f-7f4a1c94fadf">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1d030ec6-40ff-4b1e-be8f-7f4a1c94fadf_0">
											<gml:posList>35.67178576027253 139.7387972975055 35.261 35.67178452789923 139.73880049138347 35.261 35.67178675978943 139.73879601493837 35.261 35.67178576027253 139.7387972975055 35.261</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-efed65f8-7dfc-47ff-a1b2-369fe7aa33ec">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-efed65f8-7dfc-47ff-a1b2-369fe7aa33ec_0">
											<gml:posList>35.67179676512829 139.73880762401052 35.261 35.67179752109274 139.73880610975496 35.261 35.67179799750178 139.73880443013215 35.261 35.67179676512829 139.73880762401052 35.261</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b8461974-46dd-425a-997e-6346bffacefa">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b8461974-46dd-425a-997e-6346bffacefa_0">
											<gml:posList>35.67178576027253 139.7387972975055 35.261 35.67178500430818 139.73879881176092 35.261 35.67178452789923 139.73880049138347 35.261 35.67178576027253 139.7387972975055 35.261</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8e7d80d1-ce41-4243-8a5e-9dd923f84621">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8e7d80d1-ce41-4243-8a5e-9dd923f84621_0">
											<gml:posList>35.67179676512829 139.73880762401052 35.261 35.67179799750178 139.73880443013215 35.261 35.671795765611265 139.73880890657767 35.261 35.67179676512829 139.73880762401052 35.261</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-98f6aa87-5bbc-40e2-b31f-0722dac12f6b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-98f6aa87-5bbc-40e2-b31f-0722dac12f6b_0">
											<gml:posList>35.67178452789923 139.73880049138347 35.261 35.67178433998999 139.73880224799103 35.261 35.671785560787974 139.73880727268767 35.261 35.67178452789923 139.73880049138347 35.261</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ce902ec1-7d1a-4b95-8685-def147320873">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ce902ec1-7d1a-4b95-8685-def147320873_0">
											<gml:posList>35.67178896146657 139.73881046110324 35.261 35.67179457658933 139.73880991320686 35.261 35.671795765611265 139.73880890657767 35.261 35.67178896146657 139.73881046110324 35.261</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f63c12b9-1bec-411f-a91e-8706de9f0798">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f63c12b9-1bec-411f-a91e-8706de9f0798_0">
											<gml:posList>35.67178444954218 139.7388040152943 35.261 35.67178486550879 139.7388057159576 35.261 35.67178433998999 139.73880224799103 35.261 35.67178444954218 139.7388040152943 35.261</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1d249068-04cb-4213-b50b-9974ee75166f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1d249068-04cb-4213-b50b-9974ee75166f_0">
											<gml:posList>35.67179323408265 139.73881059966982 35.261 35.67179457658933 139.73880991320686 35.261 35.67179181016634 139.73881092169572 35.261 35.67179323408265 139.73881059966982 35.261</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0141ddfb-aaa5-49a4-b0c0-816063eecb6a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0141ddfb-aaa5-49a4-b0c0-816063eecb6a_0">
											<gml:posList>35.671785560787974 139.73880727268767 35.261 35.67178433998999 139.73880224799103 35.261 35.67178486550879 139.7388057159576 35.261 35.671785560787974 139.73880727268767 35.261</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1f644717-9f6d-4127-aa8a-bcc2ff591d58">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1f644717-9f6d-4127-aa8a-bcc2ff591d58_0">
											<gml:posList>35.67179036793643 139.7388108792103 35.261 35.67179181016634 139.73881092169572 35.261 35.67178896146657 139.73881046110324 35.261 35.67179036793643 139.7388108792103 35.261</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fcd61663-cac1-4100-bab2-78c3b82fcf1a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fcd61663-cac1-4100-bab2-78c3b82fcf1a_0">
											<gml:posList>35.671785560787974 139.73880727268767 35.261 35.67178649927281 139.7388086192485 35.261 35.67178765387881 139.7388097004396 35.261 35.671785560787974 139.73880727268767 35.261</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b841eef0-a716-4c95-82b3-b2963333e089">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b841eef0-a716-4c95-82b3-b2963333e089_0">
											<gml:posList>35.67178896146657 139.73881046110324 35.261 35.671785560787974 139.73880727268767 35.261 35.67178765387881 139.7388097004396 35.261 35.67178896146657 139.73881046110324 35.261</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d9c3611a-71f6-468f-9e96-54bab0010783">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d9c3611a-71f6-468f-9e96-54bab0010783_0">
											<gml:posList>35.67179696461287 139.73879764882696 35.261 35.67179356393394 139.7387944604116 35.261 35.67179799750178 139.73880443013215 35.261 35.67179696461287 139.73879764882696 35.261</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-426d410e-ac23-4e10-9e5d-99e7183c8dc8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-426d410e-ac23-4e10-9e5d-99e7183c8dc8_0">
											<gml:posList>35.67178794881126 139.73879500830907 35.261 35.67179356393394 139.7387944604116 35.261 35.67179071523411 139.7387939998197 35.261 35.67178794881126 139.73879500830907 35.261</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fed7ffae-8fc7-4767-8ae0-ed7ea7e9ae73">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fed7ffae-8fc7-4767-8ae0-ed7ea7e9ae73_0">
											<gml:posList>35.67178675978943 139.73879601493837 35.261 35.67178452789923 139.73880049138347 35.261 35.67179356393394 139.7387944604116 35.261 35.67178675978943 139.73879601493837 35.261</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f60d0463-67d1-42d7-abfb-0644d1afa286">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f60d0463-67d1-42d7-abfb-0644d1afa286_0">
											<gml:posList>35.67179799750178 139.73880443013215 35.261 35.67178896146657 139.73881046110324 35.261 35.671795765611265 139.73880890657767 35.261 35.67179799750178 139.73880443013215 35.261</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0bda3362-6bcb-464a-a22e-f8304030084c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0bda3362-6bcb-464a-a22e-f8304030084c_0">
											<gml:posList>35.67178896146657 139.73881046110324 35.261 35.67178452789923 139.73880049138347 35.261 35.671785560787974 139.73880727268767 35.261 35.67178896146657 139.73881046110324 35.261</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-27d754e7-e81c-4d1a-8a6d-bd8d00e75a83">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-27d754e7-e81c-4d1a-8a6d-bd8d00e75a83_0">
											<gml:posList>35.67179181016634 139.73881092169572 35.261 35.67179457658933 139.73880991320686 35.261 35.67178896146657 139.73881046110324 35.261 35.67179181016634 139.73881092169572 35.261</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fb2349f4-f274-42a5-89b6-cb8c14b93fe9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fb2349f4-f274-42a5-89b6-cb8c14b93fe9_0">
											<gml:posList>35.67179356393394 139.7387944604116 35.261 35.67178896146657 139.73881046110324 35.261 35.67179799750178 139.73880443013215 35.261 35.67179356393394 139.7387944604116 35.261</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b34256f6-6ea9-4dc0-8d07-0ee5a2737bb7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b34256f6-6ea9-4dc0-8d07-0ee5a2737bb7_0">
											<gml:posList>35.67179356393394 139.7387944604116 35.261 35.67178452789923 139.73880049138347 35.261 35.67178896146657 139.73881046110324 35.261 35.67179356393394 139.7387944604116 35.261</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-11cbaef7-b7ed-47d5-b5ef-cf6602df1b2e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-11cbaef7-b7ed-47d5-b5ef-cf6602df1b2e_0">
											<gml:posList>35.67179071523411 139.7387939998197 33.446 35.67179071523411 139.7387939998197 33.661 35.671792157464026 139.73879404230487 33.446 35.67179071523411 139.7387939998197 33.446</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ba4daafc-081b-4505-9e42-6ad7264a1cd1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ba4daafc-081b-4505-9e42-6ad7264a1cd1_0">
											<gml:posList>35.671792157464026 139.73879404230487 33.446 35.67179071523411 139.7387939998197 33.661 35.671792157464026 139.73879404230487 35.261 35.671792157464026 139.73879404230487 33.446</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-49d3a95e-0af9-46ea-9cc1-d2a614f41f0f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-49d3a95e-0af9-46ea-9cc1-d2a614f41f0f_0">
											<gml:posList>35.67179071523411 139.7387939998197 33.661 35.67179071523411 139.7387939998197 35.261 35.671792157464026 139.73879404230487 35.261 35.67179071523411 139.7387939998197 33.661</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-edf66f59-adb5-496e-adf9-993b949f3efa">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-edf66f59-adb5-496e-adf9-993b949f3efa_0">
											<gml:posList>35.67179181016634 139.73881092169572 33.446 35.67179323408265 139.73881059966982 35.261 35.67179181016634 139.73881092169572 35.261 35.67179181016634 139.73881092169572 33.446</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b355560d-4cf9-49ba-b710-a364682986e4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b355560d-4cf9-49ba-b710-a364682986e4_0">
											<gml:posList>35.67179181016634 139.73881092169572 33.446 35.67179323408265 139.73881059966982 33.446 35.67179323408265 139.73881059966982 35.261 35.67179181016634 139.73881092169572 33.446</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8a6cc808-3e1b-41b6-b7de-728f00eb5d07">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8a6cc808-3e1b-41b6-b7de-728f00eb5d07_0">
											<gml:posList>35.67179356393394 139.7387944604116 33.446 35.671792157464026 139.73879404230487 35.261 35.67179356393394 139.7387944604116 35.261 35.67179356393394 139.7387944604116 33.446</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e6d24066-c777-4e70-92e3-e2605e0a030d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e6d24066-c777-4e70-92e3-e2605e0a030d_0">
											<gml:posList>35.67179356393394 139.7387944604116 33.446 35.671792157464026 139.73879404230487 33.446 35.671792157464026 139.73879404230487 35.261 35.67179356393394 139.7387944604116 33.446</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-78259286-06a4-438c-95dd-06cbdfdcfccd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-78259286-06a4-438c-95dd-06cbdfdcfccd_0">
											<gml:posList>35.67179323408265 139.73881059966982 33.446 35.67179457658933 139.73880991320686 35.261 35.67179323408265 139.73881059966982 35.261 35.67179323408265 139.73881059966982 33.446</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-666f8423-4934-4621-99a8-d76b2d42fe9f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-666f8423-4934-4621-99a8-d76b2d42fe9f_0">
											<gml:posList>35.67179323408265 139.73881059966982 33.446 35.67179457658933 139.73880991320686 33.446 35.67179457658933 139.73880991320686 35.261 35.67179323408265 139.73881059966982 33.446</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-09c37756-7ef0-49b2-8770-37e9e8df83f1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-09c37756-7ef0-49b2-8770-37e9e8df83f1_0">
											<gml:posList>35.67179487152179 139.73879522107507 33.446 35.67179356393394 139.7387944604116 35.261 35.67179487152179 139.73879522107507 35.261 35.67179487152179 139.73879522107507 33.446</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7763438d-9a72-447d-88f4-7bf5d7097e2c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7763438d-9a72-447d-88f4-7bf5d7097e2c_0">
											<gml:posList>35.67179487152179 139.73879522107507 33.446 35.67179356393394 139.7387944604116 33.446 35.67179356393394 139.7387944604116 35.261 35.67179487152179 139.73879522107507 33.446</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a333e548-607f-4480-a175-0bfceb5f6639">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a333e548-607f-4480-a175-0bfceb5f6639_0">
											<gml:posList>35.67179220077755 139.7388262537131 31.539 35.671797390673376 139.73884666144335 33.792 35.67179220077755 139.7388262537131 33.792 35.67179220077755 139.7388262537131 31.539</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b4e1b459-5cff-489a-84fc-7bff53a96c9a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b4e1b459-5cff-489a-84fc-7bff53a96c9a_0">
											<gml:posList>35.67179220077755 139.7388262537131 31.539 35.671797390673376 139.73884666144335 31.539 35.671797390673376 139.73884666144335 33.792 35.67179220077755 139.7388262537131 31.539</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3c56565f-f0b5-4677-a75f-ed2159ff3e89">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3c56565f-f0b5-4677-a75f-ed2159ff3e89_0">
											<gml:posList>35.67179457658933 139.73880991320686 33.446 35.671795765611265 139.73880890657767 35.261 35.67179457658933 139.73880991320686 35.261 35.67179457658933 139.73880991320686 33.446</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d31abc9e-67fb-47df-985b-89e978fd0e51">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d31abc9e-67fb-47df-985b-89e978fd0e51_0">
											<gml:posList>35.67179457658933 139.73880991320686 33.446 35.671795765611265 139.73880890657767 33.446 35.671795765611265 139.73880890657767 35.261 35.67179457658933 139.73880991320686 33.446</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a82e3562-7691-45c5-84ac-083cfc231e95">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a82e3562-7691-45c5-84ac-083cfc231e95_0">
											<gml:posList>35.67179602612791 139.73879630226614 33.446 35.67179487152179 139.73879522107507 35.261 35.67179602612791 139.73879630226614 35.261 35.67179602612791 139.73879630226614 33.446</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-26d89bdb-a465-42d7-8a69-ed3da43ec846">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-26d89bdb-a465-42d7-8a69-ed3da43ec846_0">
											<gml:posList>35.67179602612791 139.73879630226614 33.446 35.67179487152179 139.73879522107507 33.446 35.67179487152179 139.73879522107507 35.261 35.67179602612791 139.73879630226614 33.446</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a37a8f05-1335-4c2e-b2ce-1c7983b72233">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a37a8f05-1335-4c2e-b2ce-1c7983b72233_0">
											<gml:posList>35.671795765611265 139.73880890657767 33.446 35.67179676512829 139.73880762401052 35.261 35.671795765611265 139.73880890657767 35.261 35.671795765611265 139.73880890657767 33.446</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a5549fd2-a867-461c-8404-4f13a0bf8bd9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a5549fd2-a867-461c-8404-4f13a0bf8bd9_0">
											<gml:posList>35.671795765611265 139.73880890657767 33.446 35.67179676512829 139.73880762401052 33.446 35.67179676512829 139.73880762401052 35.261 35.671795765611265 139.73880890657767 33.446</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2af5ac51-a833-4354-8427-ebd8f99768bb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2af5ac51-a833-4354-8427-ebd8f99768bb_0">
											<gml:posList>35.67179696461287 139.73879764882696 33.446 35.67179602612791 139.73879630226614 35.261 35.67179696461287 139.73879764882696 35.261 35.67179696461287 139.73879764882696 33.446</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a1f4525f-fa00-48d6-9e68-9c288c36ea9c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a1f4525f-fa00-48d6-9e68-9c288c36ea9c_0">
											<gml:posList>35.67179696461287 139.73879764882696 33.446 35.67179602612791 139.73879630226614 33.446 35.67179602612791 139.73879630226614 35.261 35.67179696461287 139.73879764882696 33.446</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cd8ec9ea-2a56-49e3-9617-200218b8c00f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cd8ec9ea-2a56-49e3-9617-200218b8c00f_0">
											<gml:posList>35.67179676512829 139.73880762401052 33.446 35.67179752109274 139.73880610975496 35.261 35.67179676512829 139.73880762401052 35.261 35.67179676512829 139.73880762401052 33.446</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1898b8f3-dcde-438f-86d2-384d41cd2b91">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1898b8f3-dcde-438f-86d2-384d41cd2b91_0">
											<gml:posList>35.67179676512829 139.73880762401052 33.446 35.67179752109274 139.73880610975496 33.446 35.67179752109274 139.73880610975496 35.261 35.67179676512829 139.73880762401052 33.446</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-99e4db80-25a5-4443-b3f9-ffb55eb9d53a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-99e4db80-25a5-4443-b3f9-ffb55eb9d53a_0">
											<gml:posList>35.67179696461287 139.73879764882696 33.446 35.67179765989216 139.7387992055572 35.261 35.67179765989216 139.7387992055572 33.446 35.67179696461287 139.73879764882696 33.446</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-23eb7045-983a-46c4-adb4-f78bf8186993">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-23eb7045-983a-46c4-adb4-f78bf8186993_0">
											<gml:posList>35.67179696461287 139.73879764882696 33.446 35.67179696461287 139.73879764882696 35.261 35.67179765989216 139.7387992055572 35.261 35.67179696461287 139.73879764882696 33.446</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6df2a0c1-d579-416b-a391-047066df6dc6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6df2a0c1-d579-416b-a391-047066df6dc6_0">
											<gml:posList>35.67179752109274 139.73880610975496 33.446 35.67179799750178 139.73880443013215 35.261 35.67179752109274 139.73880610975496 35.261 35.67179752109274 139.73880610975496 33.446</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1883902d-f92a-4b64-9b8c-3950d4b1ca57">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1883902d-f92a-4b64-9b8c-3950d4b1ca57_0">
											<gml:posList>35.67179752109274 139.73880610975496 33.446 35.67179799750178 139.73880443013215 33.446 35.67179799750178 139.73880443013215 35.261 35.67179752109274 139.73880610975496 33.446</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6a15e46f-8f34-4ca2-8d6e-b53656015b2f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6a15e46f-8f34-4ca2-8d6e-b53656015b2f_0">
											<gml:posList>35.67179807585884 139.73880090622075 33.446 35.67179765989216 139.7387992055572 35.261 35.67179807585884 139.73880090622075 35.261 35.67179807585884 139.73880090622075 33.446</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9c6eaa88-fcd4-4dfb-bfe2-e3fc2473a688">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9c6eaa88-fcd4-4dfb-bfe2-e3fc2473a688_0">
											<gml:posList>35.67179807585884 139.73880090622075 33.446 35.67179765989216 139.7387992055572 33.446 35.67179765989216 139.7387992055572 35.261 35.67179807585884 139.73880090622075 33.446</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d0d6d4c5-c191-47fc-81a3-e7d6bdb816f2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d0d6d4c5-c191-47fc-81a3-e7d6bdb816f2_0">
											<gml:posList>35.67179799750178 139.73880443013215 33.446 35.671798185411035 139.7388026735243 35.261 35.67179799750178 139.73880443013215 35.261 35.67179799750178 139.73880443013215 33.446</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-314fd3de-40da-4788-9c68-7c1b5554f77a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-314fd3de-40da-4788-9c68-7c1b5554f77a_0">
											<gml:posList>35.67179799750178 139.73880443013215 33.446 35.671798185411035 139.7388026735243 33.446 35.671798185411035 139.7388026735243 35.261 35.67179799750178 139.73880443013215 33.446</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e448daf5-b45a-468b-9256-1450f2511df0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e448daf5-b45a-468b-9256-1450f2511df0_0">
											<gml:posList>35.671798185411035 139.7388026735243 33.446 35.67179807585884 139.73880090622075 35.261 35.671798185411035 139.7388026735243 35.261 35.671798185411035 139.7388026735243 33.446</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7b777e18-cdf4-4d29-8ff9-a53a40282380">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7b777e18-cdf4-4d29-8ff9-a53a40282380_0">
											<gml:posList>35.671798185411035 139.7388026735243 33.446 35.67179807585884 139.73880090622075 33.446 35.67179807585884 139.73880090622075 35.261 35.671798185411035 139.7388026735243 33.446</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-49be6dbd-1433-4dc1-a49b-c8bb7659699e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-49be6dbd-1433-4dc1-a49b-c8bb7659699e_0">
											<gml:posList>35.67180756458381 139.73882039202732 31.539 35.67179220077755 139.7388262537131 33.792 35.67180756458381 139.73882039202732 33.792 35.67180756458381 139.73882039202732 31.539</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ed062320-2106-4342-a91d-d3c7bf0913df">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ed062320-2106-4342-a91d-d3c7bf0913df_0">
											<gml:posList>35.67180756458381 139.73882039202732 31.539 35.67179220077755 139.7388262537131 31.539 35.67179220077755 139.7388262537131 33.792 35.67180756458381 139.73882039202732 31.539</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8a832a4b-9d86-4bf6-a7e1-83e6536d5305">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8a832a4b-9d86-4bf6-a7e1-83e6536d5305_0">
											<gml:posList>35.671797390673376 139.73884666144335 33.792 35.67180756458381 139.73882039202732 33.792 35.67179220077755 139.7388262537131 33.792 35.671797390673376 139.73884666144335 33.792</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b144ab56-23d2-4c88-a35e-76ad3a4862a4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b144ab56-23d2-4c88-a35e-76ad3a4862a4_0">
											<gml:posList>35.671797390673376 139.73884666144335 33.792 35.67181275448063 139.73884079976105 33.792 35.67180756458381 139.73882039202732 33.792 35.671797390673376 139.73884666144335 33.792</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-23634d58-4cdd-4b40-88ad-881e58f2c521">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-23634d58-4cdd-4b40-88ad-881e58f2c521_0">
											<gml:posList>35.671797390673376 139.73884666144335 31.539 35.67181275448063 139.73884079976105 33.792 35.671797390673376 139.73884666144335 33.792 35.671797390673376 139.73884666144335 31.539</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1fcfff2d-e415-436a-9f8c-fbb4af3b80bd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1fcfff2d-e415-436a-9f8c-fbb4af3b80bd_0">
											<gml:posList>35.671797390673376 139.73884666144335 31.539 35.67181275448063 139.73884079976105 31.539 35.67181275448063 139.73884079976105 33.792 35.671797390673376 139.73884666144335 31.539</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-22056d4f-0305-4b41-a705-d7ef46045437">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-22056d4f-0305-4b41-a705-d7ef46045437_0">
											<gml:posList>35.67180756458381 139.73882039202732 31.539 35.67181275448063 139.73884079976105 33.792 35.67181275448063 139.73884079976105 31.539 35.67180756458381 139.73882039202732 31.539</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-37c68b9e-3729-4f5f-8be1-2a95be9cb136">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-37c68b9e-3729-4f5f-8be1-2a95be9cb136_0">
											<gml:posList>35.67180756458381 139.73882039202732 31.539 35.67180756458381 139.73882039202732 33.792 35.67181275448063 139.73884079976105 33.792 35.67180756458381 139.73882039202732 31.539</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9aea9546-c962-40fb-9863-ce6899c6b4c3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671789291317836 139.7387943218459 33.661 35.67179071523411 139.7387939998197 33.661 35.67178794881126 139.73879500830907 33.661 35.671789291317836 139.7387943218459 33.661</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cc599c37-47f7-4259-b056-e681ab5ae096">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671797390673376 139.73884666144335 31.539 35.67180756458381 139.73882039202732 31.539 35.67181275448063 139.73884079976105 31.539 35.671797390673376 139.73884666144335 31.539</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-10879c24-8b35-460a-9eff-fc380ff5ee77">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671797390673376 139.73884666144335 31.539 35.67179220077755 139.7388262537131 31.539 35.67180756458381 139.73882039202732 31.539 35.671797390673376 139.73884666144335 31.539</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e9a714fb-a79d-44ed-af66-a871a6ea4379">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671788020886325 139.73879496403825 33.446 35.67179071523411 139.7387939998197 33.446 35.67179356393394 139.7387944604116 33.446 35.671788020886325 139.73879496403825 33.446</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8296cd87-c2a1-4626-9f11-768034710ef6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67178452789923 139.73880049138347 33.446 35.67178675978943 139.73879601493837 33.446 35.671788020886325 139.73879496403825 33.446 35.67178452789923 139.73880049138347 33.446</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b9d142ba-a036-44b4-8596-23690441a794">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67179071523411 139.7387939998197 33.446 35.671792157464026 139.73879404230487 33.446 35.67179356393394 139.7387944604116 33.446 35.67179071523411 139.7387939998197 33.446</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-47c3ee31-fd94-4496-bed7-6a7c07ef7569">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67178452789923 139.73880049138347 33.446 35.67178576027253 139.7387972975055 33.446 35.67178675978943 139.73879601493837 33.446 35.67178452789923 139.73880049138347 33.446</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-69e8beca-d680-4a8c-ae6e-e6bc88795b2e">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67178500430818 139.73879881176092 33.446 35.67178576027253 139.7387972975055 33.446 35.67178452789923 139.73880049138347 33.446 35.67178500430818 139.73879881176092 33.446</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2f72c305-4283-4432-a2fa-e9d1cd52e590">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67179487152179 139.73879522107507 33.446 35.67179696461287 139.73879764882696 33.446 35.67179356393394 139.7387944604116 33.446 35.67179487152179 139.73879522107507 33.446</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2b38e002-e5d4-4bdf-b3fb-f134d751b16a">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67179602612791 139.73879630226614 33.446 35.67179696461287 139.73879764882696 33.446 35.67179487152179 139.73879522107507 33.446 35.67179602612791 139.73879630226614 33.446</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fb318a95-208b-4f9b-beb7-f21df991217f">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671785560787974 139.73880727268767 33.446 35.67178433998999 139.73880224799103 33.446 35.67178452789923 139.73880049138347 33.446 35.671785560787974 139.73880727268767 33.446</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6c67bb85-7c48-44ee-9d3c-4dca1dba98a4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67178486550879 139.7388057159576 33.446 35.67178444954218 139.7388040152943 33.446 35.67178433998999 139.73880224799103 33.446 35.67178486550879 139.7388057159576 33.446</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1e944d5d-25cc-498f-a3d3-5e2218099e1f">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67179696461287 139.73879764882696 33.446 35.67179765989216 139.7387992055572 33.446 35.671798185411035 139.7388026735243 33.446 35.67179696461287 139.73879764882696 33.446</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0cf14984-1721-4ded-8127-ef5748e53b85">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671798185411035 139.7388026735243 33.446 35.67179765989216 139.7387992055572 33.446 35.67179807585884 139.73880090622075 33.446 35.671798185411035 139.7388026735243 33.446</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6ce571c6-0a04-4bc1-98d4-6f1c89d5cbd9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671785560787974 139.73880727268767 33.446 35.67178486550879 139.7388057159576 33.446 35.67178433998999 139.73880224799103 33.446 35.671785560787974 139.73880727268767 33.446</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-96102e99-3cdf-4082-a18c-380048d27f11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67178765387881 139.7388097004396 33.446 35.67178649927281 139.7388086192485 33.446 35.671785560787974 139.73880727268767 33.446 35.67178765387881 139.7388097004396 33.446</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d57e5b73-8068-4cdd-94e6-d1628ffa993a">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67179696461287 139.73879764882696 33.446 35.671798185411035 139.7388026735243 33.446 35.67179799750178 139.73880443013215 33.446 35.67179696461287 139.73879764882696 33.446</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e0ca3a7a-18e4-49e4-9754-913fd51b924f">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67179752109274 139.73880610975496 33.446 35.67179676512829 139.73880762401052 33.446 35.67179799750178 139.73880443013215 33.446 35.67179752109274 139.73880610975496 33.446</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-be859b52-a39e-48eb-aafb-3e60c1aa3fa4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67178896146657 139.73881046110324 33.446 35.67178765387881 139.7388097004396 33.446 35.671785560787974 139.73880727268767 33.446 35.67178896146657 139.73881046110324 33.446</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-643d9883-37c4-4049-a7d0-9efabb06dc8e">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67179181016634 139.73881092169572 33.446 35.67179036793643 139.7388108792103 33.446 35.67178896146657 139.73881046110324 33.446 35.67179181016634 139.73881092169572 33.446</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5444c515-373f-4544-955a-d55e3302cf57">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67179799750178 139.73880443013215 33.446 35.67179676512829 139.73880762401052 33.446 35.671795765611265 139.73880890657767 33.446 35.67179799750178 139.73880443013215 33.446</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6107a433-3f15-46bb-9167-a1991074a7d3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671795765611265 139.73880890657767 33.446 35.67179457658933 139.73880991320686 33.446 35.67178896146657 139.73881046110324 33.446 35.671795765611265 139.73880890657767 33.446</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-67ec0d5d-28e0-4397-aaa6-7d8ca0745e06">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67179457658933 139.73880991320686 33.446 35.67179323408265 139.73881059966982 33.446 35.67179181016634 139.73881092169572 33.446 35.67179457658933 139.73880991320686 33.446</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-908fc46a-dde0-4b41-91a8-813001633ec3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67178896146657 139.73881046110324 33.446 35.671788020886325 139.73879496403825 33.446 35.67179356393394 139.7387944604116 33.446 35.67178896146657 139.73881046110324 33.446</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a07c86b0-7371-4255-a730-e1ef6f79578f">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671788020886325 139.73879496403825 33.446 35.671785560787974 139.73880727268767 33.446 35.67178452789923 139.73880049138347 33.446 35.671788020886325 139.73879496403825 33.446</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-46d852e5-53d1-4828-a448-c9e158041463">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67179696461287 139.73879764882696 33.446 35.67179799750178 139.73880443013215 33.446 35.67179356393394 139.7387944604116 33.446 35.67179696461287 139.73879764882696 33.446</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a72b5f16-ea6b-431c-89b4-3a4df5784faf">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67178896146657 139.73881046110324 33.446 35.671785560787974 139.73880727268767 33.446 35.671788020886325 139.73879496403825 33.446 35.67178896146657 139.73881046110324 33.446</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1bc9bfb0-a7f6-45b3-971d-2f2f2e84b154">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67178896146657 139.73881046110324 33.446 35.67179457658933 139.73880991320686 33.446 35.67179181016634 139.73881092169572 33.446 35.67178896146657 139.73881046110324 33.446</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-77a3be2e-98a6-469e-be47-87953b63632e">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67179799750178 139.73880443013215 33.446 35.671795765611265 139.73880890657767 33.446 35.67178896146657 139.73881046110324 33.446 35.67179799750178 139.73880443013215 33.446</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ecc645f4-38f7-445b-814a-347bb3f4f932">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67179799750178 139.73880443013215 33.446 35.67178896146657 139.73881046110324 33.446 35.67179356393394 139.7387944604116 33.446 35.67179799750178 139.73880443013215 33.446</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-08ecf5d8-6da5-42d0-ab76-77d1e508a719">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-08ecf5d8-6da5-42d0-ab76-77d1e508a719">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-08ecf5d8-6da5-42d0-ab76-77d1e508a719">
											<gml:posList>35.67184728593418 139.73877172972476 10.388 35.671869442989504 139.73886526714526 10.388 35.67179644771453 139.73888556816706 10.388 35.67177528634704 139.7387973319487 10.388 35.67184728593418 139.73877172972476 10.388</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b9721b97-2b0a-4c4b-868d-bc5bcc19edda">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b9721b97-2b0a-4c4b-868d-bc5bcc19edda">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b9721b97-2b0a-4c4b-868d-bc5bcc19edda">
											<gml:posList>35.67178074850624 139.73882009224607 33.661 35.671781909273214 139.7388175391472 33.661 35.671777396676326 139.73879875445257 33.661 35.67177528634704 139.7387973319487 33.661 35.67178074850624 139.73882009224607 33.661</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d1050e67-3723-4bd6-ab54-0df03c2f157b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d1050e67-3723-4bd6-ab54-0df03c2f157b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d1050e67-3723-4bd6-ab54-0df03c2f157b">
											<gml:posList>35.67178074850624 139.73882009224607 31.934 35.67179644771453 139.73888556816706 31.934 35.671797518588306 139.73888332447527 31.934 35.6717822443676 139.73881956025295 31.934 35.67178074850624 139.73882009224607 31.934</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b8479105-891d-468a-a310-a4680f9e5454">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b8479105-891d-468a-a310-a4680f9e5454">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b8479105-891d-468a-a310-a4680f9e5454">
											<gml:posList>35.67177528634704 139.7387973319487 33.661 35.671777396676326 139.73879875445257 33.661 35.671806592994315 139.73878835845085 33.661 35.67180771769704 139.73878579434674 33.661 35.67177528634704 139.7387973319487 33.661</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-44c03f16-65c4-42a8-9b32-721e330079c6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-44c03f16-65c4-42a8-9b32-721e330079c6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-44c03f16-65c4-42a8-9b32-721e330079c6">
											<gml:posList>35.671781909273214 139.7388175391472 33.446 35.67181142107301 139.73880714277976 33.446 35.671806592994315 139.73878835845085 33.446 35.671777396676326 139.73879875445257 33.446 35.671781909273214 139.7388175391472 33.446</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f87cfa0b-97a1-4a61-9e0e-cb9025432f74">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f87cfa0b-97a1-4a61-9e0e-cb9025432f74">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f87cfa0b-97a1-4a61-9e0e-cb9025432f74">
											<gml:posList>35.67181355842598 139.73880854315976 33.661 35.67181142107301 139.73880714277976 33.661 35.671781909273214 139.7388175391472 33.661 35.67178074850624 139.73882009224607 33.661 35.67181355842598 139.73880854315976 33.661</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-74198eb3-8840-48a8-84e2-bb254b27683b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-74198eb3-8840-48a8-84e2-bb254b27683b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-74198eb3-8840-48a8-84e2-bb254b27683b">
											<gml:posList>35.671797518588306 139.73888332447527 31.539 35.671828897542326 139.73887459394538 31.539 35.67181210761595 139.7388090530073 31.539 35.6717822443676 139.73881956025295 31.539 35.671797518588306 139.73888332447527 31.539</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-dc83dd9d-d143-4ef5-a7ce-d2a76ab0b589">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-dc83dd9d-d143-4ef5-a7ce-d2a76ab0b589">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-dc83dd9d-d143-4ef5-a7ce-d2a76ab0b589">
											<gml:posList>35.67180771769704 139.73878579434674 33.661 35.671806592994315 139.73878835845085 33.661 35.67181142107301 139.73880714277976 33.661 35.67181355842598 139.73880854315976 33.661 35.67180771769704 139.73878579434674 33.661</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-71c6355b-0757-4797-9ce6-b62d0ff516bf">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-71c6355b-0757-4797-9ce6-b62d0ff516bf">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-71c6355b-0757-4797-9ce6-b62d0ff516bf">
											<gml:posList>35.67179644771453 139.73888556816706 31.934 35.671830881661265 139.73887599450808 31.934 35.671828897542326 139.73887459394538 31.934 35.671797518588306 139.73888332447527 31.934 35.67179644771453 139.73888556816706 31.934</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-cda30d0c-8e6f-4e00-8c82-1bef387c4c34">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cda30d0c-8e6f-4e00-8c82-1bef387c4c34">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cda30d0c-8e6f-4e00-8c82-1bef387c4c34">
											<gml:posList>35.67181355842598 139.73880854315976 31.934 35.67181210761595 139.7388090530073 31.934 35.671828897542326 139.73887459394538 31.934 35.671830881661265 139.73887599450808 31.934 35.67181355842598 139.73880854315976 31.934</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-0c2a555d-1def-4f69-b275-c91ed931f67e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0c2a555d-1def-4f69-b275-c91ed931f67e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0c2a555d-1def-4f69-b275-c91ed931f67e">
											<gml:posList>35.67184728593418 139.73877172972476 25.754 35.67180771769704 139.73878579434674 31.934 35.67181355842598 139.73880854315976 31.934 35.67184728593418 139.73877172972476 25.754</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ba46f8c3-4ee3-4fac-a096-76729d44d56d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ba46f8c3-4ee3-4fac-a096-76729d44d56d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ba46f8c3-4ee3-4fac-a096-76729d44d56d">
											<gml:posList>35.67184728593418 139.73877172972476 25.754 35.67181355842598 139.73880854315976 31.934 35.671830881661265 139.73887599450808 31.934 35.67184728593418 139.73877172972476 25.754</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ce5d4e64-04ed-4410-a1ae-12abae5ca1f6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ce5d4e64-04ed-4410-a1ae-12abae5ca1f6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ce5d4e64-04ed-4410-a1ae-12abae5ca1f6">
											<gml:posList>35.67184728593418 139.73877172972476 25.754 35.671830881661265 139.73887599450808 31.934 35.671869442989504 139.73886526714526 25.754 35.67184728593418 139.73877172972476 25.754</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-453cf427-4c4a-4af4-98c7-699fee13c183">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-453cf427-4c4a-4af4-98c7-699fee13c183">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-453cf427-4c4a-4af4-98c7-699fee13c183">
											<gml:posList>35.67177528634704 139.7387973319487 33.661 35.67180771769704 139.73878579434674 33.661 35.67180771769704 139.73878579434674 31.934 35.67184728593418 139.73877172972476 25.754 35.67184728593418 139.73877172972476 10.388 35.67177528634704 139.7387973319487 10.388 35.67177528634704 139.7387973319487 33.661</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-020a1b38-6b21-4fac-b105-161f7d4ee254">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-020a1b38-6b21-4fac-b105-161f7d4ee254">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-020a1b38-6b21-4fac-b105-161f7d4ee254">
											<gml:posList>35.671777396676326 139.73879875445257 33.661 35.671777396676326 139.73879875445257 33.446 35.671806592994315 139.73878835845085 33.446 35.671806592994315 139.73878835845085 33.661 35.671777396676326 139.73879875445257 33.661</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0f4066ab-f687-4b31-9d49-70ffdab764ea">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0f4066ab-f687-4b31-9d49-70ffdab764ea">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0f4066ab-f687-4b31-9d49-70ffdab764ea">
											<gml:posList>35.67180771769704 139.73878579434674 33.661 35.67181355842598 139.73880854315976 33.661 35.67181355842598 139.73880854315976 31.934 35.67180771769704 139.73878579434674 31.934 35.67180771769704 139.73878579434674 33.661</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a37b702f-e943-4f94-a495-ecdcc5776050">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a37b702f-e943-4f94-a495-ecdcc5776050">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a37b702f-e943-4f94-a495-ecdcc5776050">
											<gml:posList>35.671806592994315 139.73878835845085 33.661 35.671806592994315 139.73878835845085 33.446 35.67181142107301 139.73880714277976 33.446 35.67181142107301 139.73880714277976 33.661 35.671806592994315 139.73878835845085 33.661</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-823f4d9a-e292-413a-b5a7-39fc7b08ab04">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-823f4d9a-e292-413a-b5a7-39fc7b08ab04">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-823f4d9a-e292-413a-b5a7-39fc7b08ab04">
											<gml:posList>35.671781909273214 139.7388175391472 33.661 35.671781909273214 139.7388175391472 33.446 35.671777396676326 139.73879875445257 33.446 35.671777396676326 139.73879875445257 33.661 35.671781909273214 139.7388175391472 33.661</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-06ae32c0-7b39-4cca-ade4-d4bd2eb7fb2e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-06ae32c0-7b39-4cca-ade4-d4bd2eb7fb2e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-06ae32c0-7b39-4cca-ade4-d4bd2eb7fb2e">
											<gml:posList>35.67181142107301 139.73880714277976 33.661 35.67181142107301 139.73880714277976 33.446 35.671781909273214 139.7388175391472 33.446 35.671781909273214 139.7388175391472 33.661 35.67181142107301 139.73880714277976 33.661</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e070a142-4d9a-4d64-9557-73522d682382">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e070a142-4d9a-4d64-9557-73522d682382">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e070a142-4d9a-4d64-9557-73522d682382">
											<gml:posList>35.6717822443676 139.73881956025295 31.934 35.6717822443676 139.73881956025295 31.539 35.67181210761595 139.7388090530073 31.539 35.67181210761595 139.7388090530073 31.934 35.67181355842598 139.73880854315976 31.934 35.67181355842598 139.73880854315976 33.661 35.67178074850624 139.73882009224607 33.661 35.67178074850624 139.73882009224607 31.934 35.6717822443676 139.73881956025295 31.934</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0378fcd8-d374-4494-aaf0-bc874eabd531">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0378fcd8-d374-4494-aaf0-bc874eabd531">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0378fcd8-d374-4494-aaf0-bc874eabd531">
											<gml:posList>35.671869442989504 139.73886526714526 10.388 35.67184728593418 139.73877172972476 10.388 35.67184728593418 139.73877172972476 25.754 35.671869442989504 139.73886526714526 25.754 35.671869442989504 139.73886526714526 10.388</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-00baa319-2a68-4c96-84bd-1be33e54db94">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-00baa319-2a68-4c96-84bd-1be33e54db94">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-00baa319-2a68-4c96-84bd-1be33e54db94">
											<gml:posList>35.67177528634704 139.7387973319487 10.388 35.67179644771453 139.73888556816706 10.388 35.67179644771453 139.73888556816706 31.934 35.67178074850624 139.73882009224607 31.934 35.67178074850624 139.73882009224607 33.661 35.67177528634704 139.7387973319487 33.661 35.67177528634704 139.7387973319487 10.388</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-44cd3454-f453-4344-aa9d-b593bb1d7cd4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-44cd3454-f453-4344-aa9d-b593bb1d7cd4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-44cd3454-f453-4344-aa9d-b593bb1d7cd4">
											<gml:posList>35.67181210761595 139.7388090530073 31.934 35.67181210761595 139.7388090530073 31.539 35.671828897542326 139.73887459394538 31.539 35.671828897542326 139.73887459394538 31.934 35.67181210761595 139.7388090530073 31.934</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-283cc9b0-4fd9-4feb-a593-c9d78a91bf31">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-283cc9b0-4fd9-4feb-a593-c9d78a91bf31">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-283cc9b0-4fd9-4feb-a593-c9d78a91bf31">
											<gml:posList>35.671797518588306 139.73888332447527 31.934 35.671797518588306 139.73888332447527 31.539 35.6717822443676 139.73881956025295 31.539 35.6717822443676 139.73881956025295 31.934 35.671797518588306 139.73888332447527 31.934</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5a311240-3748-4250-817d-4479b346e1fa">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5a311240-3748-4250-817d-4479b346e1fa">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5a311240-3748-4250-817d-4479b346e1fa">
											<gml:posList>35.671830881661265 139.73887599450808 31.934 35.67179644771453 139.73888556816706 31.934 35.67179644771453 139.73888556816706 10.388 35.671869442989504 139.73886526714526 10.388 35.671869442989504 139.73886526714526 25.754 35.671830881661265 139.73887599450808 31.934</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0fb9d0a3-7d13-453e-aca3-26b8ba1fc544">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0fb9d0a3-7d13-453e-aca3-26b8ba1fc544">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0fb9d0a3-7d13-453e-aca3-26b8ba1fc544">
											<gml:posList>35.671828897542326 139.73887459394538 31.934 35.671828897542326 139.73887459394538 31.539 35.671797518588306 139.73888332447527 31.539 35.671797518588306 139.73888332447527 31.934 35.671828897542326 139.73887459394538 31.934</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-5196</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">71.168</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1241</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>5</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.02</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>