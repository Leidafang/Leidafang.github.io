<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_f2bc2f82-e927-4896-a267-fe60f98db503">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">401</bldg:usage>
			<bldg:measuredHeight uom="m">21.8</bldg:measuredHeight>
			<bldg:storeysAboveGround>7</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>1</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.66876170805608 139.74016241957077 0 35.66869806157085 139.74026665756816 0 35.66875939757533 139.7403218165569 0 35.66882322574878 139.7402193456796 0 35.66876170805608 139.74016241957077 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66876170805608 139.74016241957077 11.298 35.66882322574878 139.7402193456796 11.298 35.66875939757533 139.7403218165569 11.298 35.66869806157085 139.74026665756816 11.298 35.66876170805608 139.74016241957077 11.298</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66876170805608 139.74016241957077 11.298 35.66869806157085 139.74026665756816 11.298 35.66869806157085 139.74026665756816 33.13 35.66876170805608 139.74016241957077 33.13 35.66876170805608 139.74016241957077 11.298</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66869806157085 139.74026665756816 11.298 35.66875939757533 139.7403218165569 11.298 35.66875939757533 139.7403218165569 33.13 35.66869806157085 139.74026665756816 33.13 35.66869806157085 139.74026665756816 11.298</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66875939757533 139.7403218165569 11.298 35.66882322574878 139.7402193456796 11.298 35.66882322574878 139.7402193456796 33.13 35.66875939757533 139.7403218165569 33.13 35.66875939757533 139.7403218165569 11.298</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66882322574878 139.7402193456796 11.298 35.66876170805608 139.74016241957077 11.298 35.66876170805608 139.74016241957077 33.13 35.66882322574878 139.7402193456796 33.13 35.66882322574878 139.7402193456796 11.298</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66876170805608 139.74016241957077 33.13 35.66869806157085 139.74026665756816 33.13 35.66875939757533 139.7403218165569 33.13 35.66882322574878 139.7402193456796 33.13 35.66876170805608 139.74016241957077 33.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-0226e78a-c59e-42c8-b970-7e7b12f7d0c8"/>
							<gml:surfaceMember xlink:href="#poly-74ec170b-dacf-428c-a7f1-d81a171b3bf9"/>
							<gml:surfaceMember xlink:href="#poly-9d3e40d6-e4f2-4605-8b72-acf0d17e5409"/>
							<gml:surfaceMember xlink:href="#poly-cd78a666-4def-4cd9-8bf2-2ac4b06f1eab"/>
							<gml:surfaceMember xlink:href="#poly-663cfee9-1319-4ec3-9c85-2ca2ccd07ce4"/>
							<gml:surfaceMember xlink:href="#poly-bf219d97-506b-47cb-835a-942b332057dc"/>
							<gml:surfaceMember xlink:href="#poly-83ded298-2327-49ca-84ea-aebc09baf4b2"/>
							<gml:surfaceMember xlink:href="#poly-02493ef7-85cf-45c5-911f-9328898fd183"/>
							<gml:surfaceMember xlink:href="#poly-3aa02873-b6c1-485e-a961-5e8c3a8642fe"/>
							<gml:surfaceMember xlink:href="#poly-1988d2f5-f3ba-4dd6-8fab-2c2b7c0eb99e"/>
							<gml:surfaceMember xlink:href="#poly-a5485b8a-dea1-4c56-a3bc-2dda0396c49f"/>
							<gml:surfaceMember xlink:href="#poly-364ce74c-70b4-4074-95af-e412f04f4dd0"/>
							<gml:surfaceMember xlink:href="#poly-0ecd135e-0e01-489a-a539-7324b0d2ffc0"/>
							<gml:surfaceMember xlink:href="#poly-96c22f75-d21b-4a4a-a7e4-61b9b9b5a888"/>
							<gml:surfaceMember xlink:href="#poly-5a9258af-d279-4b8f-a773-4906198bc21a"/>
							<gml:surfaceMember xlink:href="#poly-50a48520-d39b-403d-8395-66496b127243"/>
							<gml:surfaceMember xlink:href="#poly-dbabb9de-a85d-4729-945c-aa4df63f72c2"/>
							<gml:surfaceMember xlink:href="#poly-8f691f53-2e60-452a-b03c-bb03a8d7bc40"/>
							<gml:surfaceMember xlink:href="#poly-ced7c6ea-d0f7-4908-81db-71e3318f9bca"/>
							<gml:surfaceMember xlink:href="#poly-29189cf4-fc28-40ee-a29f-8a59e52f0419"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_f2bc2f82-e927-4896-a267-fe60f98db503_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-645aa54a-2e93-42c9-8d5e-094fd6ee7368">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66880187829393 139.7402038949652 37.015 35.668803131551975 139.7402043463973 37.015 35.668804285898226 139.74020510723346 37.015 35.66880527820246 139.74020613336288 37.015 35.668806072392684 139.7402074027354 37.015 35.6688066413679 139.74020883806008 37.015 35.66880694903904 139.7402103951948 37.015 35.668806986332584 139.74021199682764 37.015 35.668806753188726 139.74021356563648 37.015 35.66880625857849 139.7402150463806 37.015 35.66880552948326 139.7402163617064 37.015 35.66880458389632 139.74021746740874 37.015 35.66880347585731 139.7402183081947 37.015 35.66880225040924 139.74021885087387 37.015 35.66880095260368 139.74021907330186 37.015 35.66879965453332 139.74021895330281 37.015 35.66879840127534 139.7402185018705 37.015 35.668797255942884 139.7402177410237 37.015 35.66879625461648 139.7402167038587 37.015 35.6687954604349 139.7402154455323 37.015 35.66879489145977 139.74021401020772 37.015 35.66879458378867 139.74021245307324 37.015 35.66879453748142 139.7402108514511 37.015 35.66879477062523 139.7402092826425 37.015 35.66879527424913 139.7402078018881 37.015 35.66879600333572 139.74020647551637 37.015 35.66879694892257 139.740205369814 37.015 35.668798056961485 139.74020452902792 37.015 35.66879928241802 139.7402039973946 37.015 35.66880058022356 139.7402037749664 37.015 35.66880187829393 139.7402038949652 37.015</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f5623c57-6caa-46b3-8834-9e281359ec9f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f5623c57-6caa-46b3-8834-9e281359ec9f_0">
											<gml:posList>35.66879458378867 139.74021245307324 38.952 35.66879453748142 139.7402108514511 38.952 35.66879453748142 139.7402108514511 37.015 35.66879458378867 139.74021245307324 37.015 35.66879458378867 139.74021245307324 38.952</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-62e10031-de40-472e-876b-1e163b24d997">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-62e10031-de40-472e-876b-1e163b24d997_0">
											<gml:posList>35.66879453748142 139.7402108514511 37.015 35.66879453748142 139.7402108514511 38.952 35.66879477062523 139.7402092826425 38.952 35.66879477062523 139.7402092826425 37.015 35.66879453748142 139.7402108514511 37.015</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5b9673f1-7a6e-4d80-a2c1-950012a0267e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5b9673f1-7a6e-4d80-a2c1-950012a0267e_0">
											<gml:posList>35.66879489145977 139.74021401020772 37.015 35.66879489145977 139.74021401020772 38.952 35.66879458378867 139.74021245307324 38.952 35.66879458378867 139.74021245307324 37.015 35.66879489145977 139.74021401020772 37.015</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fde1bf25-ca90-4ecd-990f-91caa71187ed">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fde1bf25-ca90-4ecd-990f-91caa71187ed_0">
											<gml:posList>35.66879477062523 139.7402092826425 37.015 35.66879477062523 139.7402092826425 38.952 35.66879527424913 139.7402078018881 38.952 35.66879527424913 139.7402078018881 37.015 35.66879477062523 139.7402092826425 37.015</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-37a7a82c-fd37-49c2-aad0-3ccc066a456a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-37a7a82c-fd37-49c2-aad0-3ccc066a456a_0">
											<gml:posList>35.6687954604349 139.7402154455323 37.015 35.6687954604349 139.7402154455323 38.952 35.66879489145977 139.74021401020772 38.952 35.66879489145977 139.74021401020772 37.015 35.6687954604349 139.7402154455323 37.015</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bc24045e-a40d-49f5-809c-0dac141db413">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bc24045e-a40d-49f5-809c-0dac141db413_0">
											<gml:posList>35.66879527424913 139.7402078018881 37.015 35.66879527424913 139.7402078018881 38.952 35.66879600333572 139.74020647551637 38.952 35.66879600333572 139.74020647551637 37.015 35.66879527424913 139.7402078018881 37.015</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-81eb11ed-875b-4451-a642-b4f70615363b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-81eb11ed-875b-4451-a642-b4f70615363b_0">
											<gml:posList>35.66879625461648 139.7402167038587 37.015 35.66879625461648 139.7402167038587 38.952 35.6687954604349 139.7402154455323 38.952 35.6687954604349 139.7402154455323 37.015 35.66879625461648 139.7402167038587 37.015</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2098084d-cbdf-49bb-8754-8387d34427a5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2098084d-cbdf-49bb-8754-8387d34427a5_0">
											<gml:posList>35.66879600333572 139.74020647551637 38.952 35.66879694892257 139.740205369814 38.952 35.66879694892257 139.740205369814 37.015 35.66879600333572 139.74020647551637 37.015 35.66879600333572 139.74020647551637 38.952</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d4926704-9172-4bba-b4fd-6346b767ca7e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d4926704-9172-4bba-b4fd-6346b767ca7e_0">
											<gml:posList>35.668797255942884 139.7402177410237 37.015 35.668797255942884 139.7402177410237 38.952 35.66879625461648 139.7402167038587 38.952 35.66879625461648 139.7402167038587 37.015 35.668797255942884 139.7402177410237 37.015</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7d7b350b-cdd0-4110-8580-2c32366c78a8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7d7b350b-cdd0-4110-8580-2c32366c78a8_0">
											<gml:posList>35.66879694892257 139.740205369814 38.952 35.668798056961485 139.74020452902792 38.952 35.668798056961485 139.74020452902792 37.015 35.66879694892257 139.740205369814 37.015 35.66879694892257 139.740205369814 38.952</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-77ca93cd-e310-4a2f-8a0b-5d05e5856fe3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-77ca93cd-e310-4a2f-8a0b-5d05e5856fe3_0">
											<gml:posList>35.66879840127534 139.7402185018705 37.015 35.66879840127534 139.7402185018705 38.952 35.668797255942884 139.7402177410237 38.952 35.668797255942884 139.7402177410237 37.015 35.66879840127534 139.7402185018705 37.015</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b22117d8-b39c-490a-9c60-0a2c3924ebd1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b22117d8-b39c-490a-9c60-0a2c3924ebd1_0">
											<gml:posList>35.668798056961485 139.74020452902792 37.015 35.668798056961485 139.74020452902792 38.952 35.66879928241802 139.7402039973946 38.952 35.66879928241802 139.7402039973946 37.015 35.668798056961485 139.74020452902792 37.015</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-78f9e299-9211-42fa-a7a6-2ead151f3e53">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-78f9e299-9211-42fa-a7a6-2ead151f3e53_0">
											<gml:posList>35.66879965453332 139.74021895330281 37.015 35.66879965453332 139.74021895330281 38.952 35.66879840127534 139.7402185018705 38.952 35.66879840127534 139.7402185018705 37.015 35.66879965453332 139.74021895330281 37.015</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d5bf64e9-b50d-4cb3-8f3c-08d71743cd4f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d5bf64e9-b50d-4cb3-8f3c-08d71743cd4f_0">
											<gml:posList>35.66879928241802 139.7402039973946 37.015 35.66879928241802 139.7402039973946 38.952 35.66880058022356 139.7402037749664 38.952 35.66880058022356 139.7402037749664 37.015 35.66879928241802 139.7402039973946 37.015</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e27c9ccc-5946-4345-9b39-9737fbd92a66">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e27c9ccc-5946-4345-9b39-9737fbd92a66_0">
											<gml:posList>35.66880095260368 139.74021907330186 38.952 35.66879965453332 139.74021895330281 38.952 35.66879965453332 139.74021895330281 37.015 35.66880095260368 139.74021907330186 37.015 35.66880095260368 139.74021907330186 38.952</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-de77b1bf-2284-4211-aafc-fce3511ed720">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-de77b1bf-2284-4211-aafc-fce3511ed720_0">
											<gml:posList>35.66879928241802 139.7402039973946 38.952 35.668798056961485 139.74020452902792 38.952 35.66879694892257 139.740205369814 38.952 35.66879600333572 139.74020647551637 38.952 35.66879527424913 139.7402078018881 38.952 35.66879477062523 139.7402092826425 38.952 35.66879453748142 139.7402108514511 38.952 35.66879458378867 139.74021245307324 38.952 35.66879489145977 139.74021401020772 38.952 35.6687954604349 139.7402154455323 38.952 35.66879625461648 139.7402167038587 38.952 35.668797255942884 139.7402177410237 38.952 35.66879840127534 139.7402185018705 38.952 35.66879965453332 139.74021895330281 38.952 35.66880095260368 139.74021907330186 38.952 35.66880225040924 139.74021885087387 38.952 35.66880347585731 139.7402183081947 38.952 35.66880458389632 139.74021746740874 38.952 35.66880552948326 139.7402163617064 38.952 35.66880625857849 139.7402150463806 38.952 35.668806753188726 139.74021356563648 38.952 35.668806986332584 139.74021199682764 38.952 35.66880694903904 139.7402103951948 38.952 35.6688066413679 139.74020883806008 38.952 35.668806072392684 139.7402074027354 38.952 35.66880527820246 139.74020613336288 38.952 35.668804285898226 139.74020510723346 38.952 35.668803131551975 139.7402043463973 38.952 35.66880187829393 139.7402038949652 38.952 35.66880058022356 139.7402037749664 38.952 35.66879928241802 139.7402039973946 38.952</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-17ea3036-925e-41d7-9a1d-c565a82daa5e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-17ea3036-925e-41d7-9a1d-c565a82daa5e_0">
											<gml:posList>35.66880058022356 139.7402037749664 37.015 35.66880058022356 139.7402037749664 38.952 35.66880187829393 139.7402038949652 38.952 35.66880187829393 139.7402038949652 37.015 35.66880058022356 139.7402037749664 37.015</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a0911856-05e3-492b-9b20-2bc01c34e36a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a0911856-05e3-492b-9b20-2bc01c34e36a_0">
											<gml:posList>35.66880225040924 139.74021885087387 37.015 35.66880225040924 139.74021885087387 38.952 35.66880095260368 139.74021907330186 38.952 35.66880095260368 139.74021907330186 37.015 35.66880225040924 139.74021885087387 37.015</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-61eff2f8-97ad-4b1a-9b16-22888eee45c4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-61eff2f8-97ad-4b1a-9b16-22888eee45c4_0">
											<gml:posList>35.66880187829393 139.7402038949652 37.015 35.66880187829393 139.7402038949652 38.952 35.668803131551975 139.7402043463973 38.952 35.668803131551975 139.7402043463973 37.015 35.66880187829393 139.7402038949652 37.015</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ce17d566-b121-40ae-88bc-d1306ac6a107">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ce17d566-b121-40ae-88bc-d1306ac6a107_0">
											<gml:posList>35.66880347585731 139.7402183081947 37.015 35.66880347585731 139.7402183081947 38.952 35.66880225040924 139.74021885087387 38.952 35.66880225040924 139.74021885087387 37.015 35.66880347585731 139.7402183081947 37.015</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-853c5916-19b7-42f5-b221-d137ce377940">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-853c5916-19b7-42f5-b221-d137ce377940_0">
											<gml:posList>35.668803131551975 139.7402043463973 37.015 35.668803131551975 139.7402043463973 38.952 35.668804285898226 139.74020510723346 38.952 35.668804285898226 139.74020510723346 37.015 35.668803131551975 139.7402043463973 37.015</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ea36c34d-13f4-4e6b-b194-91a0b4429439">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ea36c34d-13f4-4e6b-b194-91a0b4429439_0">
											<gml:posList>35.66880458389632 139.74021746740874 38.952 35.66880347585731 139.7402183081947 38.952 35.66880347585731 139.7402183081947 37.015 35.66880458389632 139.74021746740874 37.015 35.66880458389632 139.74021746740874 38.952</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-10c5a6a3-9543-4057-bb42-b4721816d591">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-10c5a6a3-9543-4057-bb42-b4721816d591_0">
											<gml:posList>35.668804285898226 139.74020510723346 37.015 35.668804285898226 139.74020510723346 38.952 35.66880527820246 139.74020613336288 38.952 35.66880527820246 139.74020613336288 37.015 35.668804285898226 139.74020510723346 37.015</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-756254a7-656e-466f-aad9-e1f12f3578df">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-756254a7-656e-466f-aad9-e1f12f3578df_0">
											<gml:posList>35.66880552948326 139.7402163617064 37.015 35.66880552948326 139.7402163617064 38.952 35.66880458389632 139.74021746740874 38.952 35.66880458389632 139.74021746740874 37.015 35.66880552948326 139.7402163617064 37.015</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-60a0ea33-cc8d-4bfc-8fab-23595de1d735">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-60a0ea33-cc8d-4bfc-8fab-23595de1d735_0">
											<gml:posList>35.66880527820246 139.74020613336288 37.015 35.66880527820246 139.74020613336288 38.952 35.668806072392684 139.7402074027354 38.952 35.668806072392684 139.7402074027354 37.015 35.66880527820246 139.74020613336288 37.015</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5d282283-8bbd-4816-bc06-83d9b301e366">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5d282283-8bbd-4816-bc06-83d9b301e366_0">
											<gml:posList>35.66880625857849 139.7402150463806 37.015 35.66880625857849 139.7402150463806 38.952 35.66880552948326 139.7402163617064 38.952 35.66880552948326 139.7402163617064 37.015 35.66880625857849 139.7402150463806 37.015</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-37c99693-797e-4a7f-85c5-6d14eb8cf3e2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-37c99693-797e-4a7f-85c5-6d14eb8cf3e2_0">
											<gml:posList>35.668806072392684 139.7402074027354 37.015 35.668806072392684 139.7402074027354 38.952 35.6688066413679 139.74020883806008 38.952 35.6688066413679 139.74020883806008 37.015 35.668806072392684 139.7402074027354 37.015</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-987fd6df-2575-4a1b-abfe-41100e6a816d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-987fd6df-2575-4a1b-abfe-41100e6a816d_0">
											<gml:posList>35.668806753188726 139.74021356563648 37.015 35.668806753188726 139.74021356563648 38.952 35.66880625857849 139.7402150463806 38.952 35.66880625857849 139.7402150463806 37.015 35.668806753188726 139.74021356563648 37.015</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-962f06b0-58af-44dd-93ce-731b227ace78">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-962f06b0-58af-44dd-93ce-731b227ace78_0">
											<gml:posList>35.6688066413679 139.74020883806008 37.015 35.6688066413679 139.74020883806008 38.952 35.66880694903904 139.7402103951948 38.952 35.66880694903904 139.7402103951948 37.015 35.6688066413679 139.74020883806008 37.015</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-82df5376-6191-44d2-b64a-4c11764754b3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-82df5376-6191-44d2-b64a-4c11764754b3_0">
											<gml:posList>35.668806986332584 139.74021199682764 37.015 35.668806986332584 139.74021199682764 38.952 35.668806753188726 139.74021356563648 38.952 35.668806753188726 139.74021356563648 37.015 35.668806986332584 139.74021199682764 37.015</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c5561695-99a7-414c-b1da-5594ea0035b1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c5561695-99a7-414c-b1da-5594ea0035b1_0">
											<gml:posList>35.66880694903904 139.7402103951948 38.952 35.668806986332584 139.74021199682764 38.952 35.668806986332584 139.74021199682764 37.015 35.66880694903904 139.7402103951948 37.015 35.66880694903904 139.7402103951948 38.952</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_f2bc2f82-e927-4896-a267-fe60f98db503_BuildingInstallation_1041">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7aac8dc1-f83e-4652-8085-d69e1f6c43c3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668784573996284 139.74022988430272 33.684 35.668797987935214 139.74024348849625 33.684 35.66877769420529 139.74027353518989 33.684 35.6687642802697 139.74025993099477 33.684 35.668784573996284 139.74022988430272 33.684</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d404c23b-e1d5-412f-b3d7-7f5142a8dc83">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d404c23b-e1d5-412f-b3d7-7f5142a8dc83_0">
											<gml:posList>35.668784573996284 139.74022988430272 33.684 35.668784573996284 139.74022988430272 35.66 35.668797987935214 139.74024348849625 35.66 35.668797987935214 139.74024348849625 33.684 35.668784573996284 139.74022988430272 33.684</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0e778796-5af5-43b9-b4a3-11af83281350">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0e778796-5af5-43b9-b4a3-11af83281350_0">
											<gml:posList>35.6687642802697 139.74025993099477 33.684 35.6687642802697 139.74025993099477 35.66 35.668784573996284 139.74022988430272 35.66 35.668784573996284 139.74022988430272 33.684 35.6687642802697 139.74025993099477 33.684</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1a2ce705-bae6-41e6-952f-de698632eecb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1a2ce705-bae6-41e6-952f-de698632eecb_0">
											<gml:posList>35.668784573996284 139.74022988430272 35.66 35.6687642802697 139.74025993099477 35.66 35.66877769420529 139.74027353518989 35.66 35.668797987935214 139.74024348849625 35.66 35.668784573996284 139.74022988430272 35.66</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2f04ee20-8958-49cc-9b59-72030656a919">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2f04ee20-8958-49cc-9b59-72030656a919_0">
											<gml:posList>35.668797987935214 139.74024348849625 33.684 35.668797987935214 139.74024348849625 35.66 35.66877769420529 139.74027353518989 35.66 35.66877769420529 139.74027353518989 33.684 35.668797987935214 139.74024348849625 33.684</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-71566765-2e85-4010-ba4f-76040a925397">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-71566765-2e85-4010-ba4f-76040a925397_0">
											<gml:posList>35.66877769420529 139.74027353518989 33.684 35.66877769420529 139.74027353518989 35.66 35.6687642802697 139.74025993099477 35.66 35.6687642802697 139.74025993099477 33.684 35.66877769420529 139.74027353518989 33.684</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-0226e78a-c59e-42c8-b970-7e7b12f7d0c8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0226e78a-c59e-42c8-b970-7e7b12f7d0c8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0226e78a-c59e-42c8-b970-7e7b12f7d0c8">
											<gml:posList>35.66876170805606 139.74016241957077 11.298 35.668823225748746 139.7402193456796 11.298 35.66875939757533 139.7403218165569 11.298 35.66869806157085 139.74026665756813 11.298 35.66876170805606 139.74016241957077 11.298</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-74ec170b-dacf-428c-a7f1-d81a171b3bf9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-74ec170b-dacf-428c-a7f1-d81a171b3bf9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-74ec170b-dacf-428c-a7f1-d81a171b3bf9">
											<gml:posList>35.66875939757533 139.7403218165569 34.204 35.66875895290793 139.74031793991404 34.204 35.668701279026806 139.7402660794402 34.204 35.66869806157085 139.74026665756813 34.204 35.66875939757533 139.7403218165569 34.204</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-9d3e40d6-e4f2-4605-8b72-acf0d17e5409">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9d3e40d6-e4f2-4605-8b72-acf0d17e5409">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9d3e40d6-e4f2-4605-8b72-acf0d17e5409">
											<gml:posList>35.66869806157085 139.74026665756813 34.204 35.668701279026806 139.7402660794402 34.204 35.668762170798644 139.74016635142206 34.204 35.66876170805606 139.74016241957077 34.204 35.66869806157085 139.74026665756813 34.204</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-cd78a666-4def-4cd9-8bf2-2ac4b06f1eab">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cd78a666-4def-4cd9-8bf2-2ac4b06f1eab">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cd78a666-4def-4cd9-8bf2-2ac4b06f1eab">
											<gml:posList>35.66875895290793 139.74031793991404 33.684 35.66882001728119 139.74021989066173 33.684 35.66881606644234 139.7402162390092 33.684 35.66880530851881 139.74023368215754 33.684 35.66875809684601 139.74018998362664 33.684 35.668768845741035 139.74017252944714 33.684 35.668762170798644 139.74016635142206 33.684 35.668701279026806 139.7402660794402 33.684 35.66875895290793 139.74031793991404 33.684</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-663cfee9-1319-4ec3-9c85-2ca2ccd07ce4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-663cfee9-1319-4ec3-9c85-2ca2ccd07ce4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-663cfee9-1319-4ec3-9c85-2ca2ccd07ce4">
											<gml:posList>35.668762170798644 139.74016635142206 34.204 35.668768845741035 139.74017252944714 34.204 35.66877022311468 139.74017029654723 34.204 35.66876170805606 139.74016241957077 34.204 35.668762170798644 139.74016635142206 34.204</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-bf219d97-506b-47cb-835a-942b332057dc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bf219d97-506b-47cb-835a-942b332057dc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bf219d97-506b-47cb-835a-942b332057dc">
											<gml:posList>35.66875809684601 139.74018998362664 37.015 35.66880530851881 139.74023368215754 37.015 35.668817443808244 139.74021399506267 37.015 35.66877022311468 139.74017029654723 37.015 35.66875809684601 139.74018998362664 37.015</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-83ded298-2327-49ca-84ea-aebc09baf4b2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-83ded298-2327-49ca-84ea-aebc09baf4b2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-83ded298-2327-49ca-84ea-aebc09baf4b2">
											<gml:posList>35.668823225748746 139.7402193456796 34.204 35.66882001728119 139.74021989066173 34.204 35.66875895290793 139.74031793991404 34.204 35.66875939757533 139.7403218165569 34.204 35.668823225748746 139.7402193456796 34.204</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-02493ef7-85cf-45c5-911f-9328898fd183">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-02493ef7-85cf-45c5-911f-9328898fd183">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-02493ef7-85cf-45c5-911f-9328898fd183">
											<gml:posList>35.66882001728119 139.74021989066173 34.204 35.668823225748746 139.7402193456796 34.204 35.668817443808244 139.74021399506267 34.204 35.66881606644234 139.7402162390092 34.204 35.66882001728119 139.74021989066173 34.204</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3aa02873-b6c1-485e-a961-5e8c3a8642fe">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3aa02873-b6c1-485e-a961-5e8c3a8642fe">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3aa02873-b6c1-485e-a961-5e8c3a8642fe">
											<gml:posList>35.668701279026806 139.7402660794402 34.204 35.668701279026806 139.7402660794402 33.684 35.668762170798644 139.74016635142206 33.684 35.668762170798644 139.74016635142206 34.204 35.668701279026806 139.7402660794402 34.204</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1988d2f5-f3ba-4dd6-8fab-2c2b7c0eb99e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1988d2f5-f3ba-4dd6-8fab-2c2b7c0eb99e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1988d2f5-f3ba-4dd6-8fab-2c2b7c0eb99e">
											<gml:posList>35.66882001728119 139.74021989066173 34.204 35.66882001728119 139.74021989066173 33.684 35.66875895290793 139.74031793991404 33.684 35.66875895290793 139.74031793991404 34.204 35.66882001728119 139.74021989066173 34.204</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a5485b8a-dea1-4c56-a3bc-2dda0396c49f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a5485b8a-dea1-4c56-a3bc-2dda0396c49f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a5485b8a-dea1-4c56-a3bc-2dda0396c49f">
											<gml:posList>35.668762170798644 139.74016635142206 34.204 35.668762170798644 139.74016635142206 33.684 35.668768845741035 139.74017252944714 33.684 35.668768845741035 139.74017252944714 34.204 35.668762170798644 139.74016635142206 34.204</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-364ce74c-70b4-4074-95af-e412f04f4dd0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-364ce74c-70b4-4074-95af-e412f04f4dd0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-364ce74c-70b4-4074-95af-e412f04f4dd0">
											<gml:posList>35.66875809684601 139.74018998362664 33.684 35.66875809684601 139.74018998362664 37.015 35.66877022311468 139.74017029654723 37.015 35.66877022311468 139.74017029654723 34.204 35.668768845741035 139.74017252944714 34.204 35.668768845741035 139.74017252944714 33.684 35.66875809684601 139.74018998362664 33.684</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0ecd135e-0e01-489a-a539-7324b0d2ffc0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0ecd135e-0e01-489a-a539-7324b0d2ffc0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0ecd135e-0e01-489a-a539-7324b0d2ffc0">
											<gml:posList>35.66877022311468 139.74017029654723 34.204 35.66877022311468 139.74017029654723 37.015 35.668817443808244 139.74021399506267 37.015 35.668817443808244 139.74021399506267 34.204 35.668823225748746 139.7402193456796 34.204 35.668823225748746 139.7402193456796 11.298 35.66876170805606 139.74016241957077 11.298 35.66876170805606 139.74016241957077 34.204 35.66877022311468 139.74017029654723 34.204</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-96c22f75-d21b-4a4a-a7e4-61b9b9b5a888">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-96c22f75-d21b-4a4a-a7e4-61b9b9b5a888">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-96c22f75-d21b-4a4a-a7e4-61b9b9b5a888">
											<gml:posList>35.66875809684601 139.74018998362664 33.684 35.66880530851881 139.74023368215754 33.684 35.66880530851881 139.74023368215754 37.015 35.66875809684601 139.74018998362664 37.015 35.66875809684601 139.74018998362664 33.684</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5a9258af-d279-4b8f-a773-4906198bc21a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5a9258af-d279-4b8f-a773-4906198bc21a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5a9258af-d279-4b8f-a773-4906198bc21a">
											<gml:posList>35.66876170805606 139.74016241957077 11.298 35.66869806157085 139.74026665756813 11.298 35.66869806157085 139.74026665756813 34.204 35.66876170805606 139.74016241957077 34.204 35.66876170805606 139.74016241957077 11.298</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-50a48520-d39b-403d-8395-66496b127243">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-50a48520-d39b-403d-8395-66496b127243">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-50a48520-d39b-403d-8395-66496b127243">
											<gml:posList>35.66881606644234 139.7402162390092 34.204 35.66881606644234 139.7402162390092 33.684 35.66882001728119 139.74021989066173 33.684 35.66882001728119 139.74021989066173 34.204 35.66881606644234 139.7402162390092 34.204</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-dbabb9de-a85d-4729-945c-aa4df63f72c2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-dbabb9de-a85d-4729-945c-aa4df63f72c2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-dbabb9de-a85d-4729-945c-aa4df63f72c2">
											<gml:posList>35.668817443808244 139.74021399506267 37.015 35.66880530851881 139.74023368215754 37.015 35.66880530851881 139.74023368215754 33.684 35.66881606644234 139.7402162390092 33.684 35.66881606644234 139.7402162390092 34.204 35.668817443808244 139.74021399506267 34.204 35.668817443808244 139.74021399506267 37.015</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8f691f53-2e60-452a-b03c-bb03a8d7bc40">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8f691f53-2e60-452a-b03c-bb03a8d7bc40">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8f691f53-2e60-452a-b03c-bb03a8d7bc40">
											<gml:posList>35.66875939757533 139.7403218165569 11.298 35.668823225748746 139.7402193456796 11.298 35.668823225748746 139.7402193456796 34.204 35.66875939757533 139.7403218165569 34.204 35.66875939757533 139.7403218165569 11.298</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ced7c6ea-d0f7-4908-81db-71e3318f9bca">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ced7c6ea-d0f7-4908-81db-71e3318f9bca">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ced7c6ea-d0f7-4908-81db-71e3318f9bca">
											<gml:posList>35.66875895290793 139.74031793991404 34.204 35.66875895290793 139.74031793991404 33.684 35.668701279026806 139.7402660794402 33.684 35.668701279026806 139.7402660794402 34.204 35.66875895290793 139.74031793991404 34.204</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-29189cf4-fc28-40ee-a29f-8a59e52f0419">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-29189cf4-fc28-40ee-a29f-8a59e52f0419">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-29189cf4-fc28-40ee-a29f-8a59e52f0419">
											<gml:posList>35.66869806157085 139.74026665756813 11.298 35.66875939757533 139.7403218165569 11.298 35.66875939757533 139.7403218165569 34.204 35.66869806157085 139.74026665756813 34.204 35.66869806157085 139.74026665756813 11.298</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-6128</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">99.6399</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1210</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>7</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.07</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>