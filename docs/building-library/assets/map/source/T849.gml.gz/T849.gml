<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_f36755c2-a45f-4f38-b2dc-434c9678840d">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">401</bldg:usage>
			<bldg:measuredHeight uom="m">29.5</bldg:measuredHeight>
			<bldg:storeysAboveGround>11</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.67163658448536 139.74021033420792 0 35.67165704889346 139.74017956820865 0 35.67162966290395 139.74015332056769 0 35.67164119634889 139.74013633984188 0 35.67166908624712 139.74016147120508 0 35.67167576152875 139.74016809131032 0 35.67170484207829 139.74012442407187 0 35.6715827919737 139.74000261343247 0 35.67149176934716 139.74013969490755 0 35.671620224008905 139.74026790511252 0 35.671649754683145 139.74022346416737 0 35.67163658448536 139.74021033420792 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67163658448536 139.74021033420792 9.031 35.671649754683145 139.74022346416737 9.031 35.671620224008905 139.74026790511252 9.031 35.67149176934716 139.74013969490755 9.031 35.6715827919737 139.74000261343247 9.031 35.67170484207829 139.74012442407187 9.031 35.67167576152875 139.74016809131032 9.031 35.67166908624712 139.74016147120508 9.031 35.67164119634889 139.74013633984188 9.031 35.67162966290395 139.74015332056769 9.031 35.67165704889346 139.74017956820865 9.031 35.67163658448536 139.74021033420792 9.031</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67163658448536 139.74021033420792 9.031 35.67165704889346 139.74017956820865 9.031 35.67165704889346 139.74017956820865 31.9 35.67163658448536 139.74021033420792 31.9 35.67163658448536 139.74021033420792 9.031</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67165704889346 139.74017956820865 9.031 35.67162966290395 139.74015332056769 9.031 35.67162966290395 139.74015332056769 31.9 35.67165704889346 139.74017956820865 31.9 35.67165704889346 139.74017956820865 9.031</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67162966290395 139.74015332056769 9.031 35.67164119634889 139.74013633984188 9.031 35.67164119634889 139.74013633984188 31.9 35.67162966290395 139.74015332056769 31.9 35.67162966290395 139.74015332056769 9.031</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67164119634889 139.74013633984188 9.031 35.67166908624712 139.74016147120508 9.031 35.67166908624712 139.74016147120508 31.9 35.67164119634889 139.74013633984188 31.9 35.67164119634889 139.74013633984188 9.031</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67166908624712 139.74016147120508 9.031 35.67167576152875 139.74016809131032 9.031 35.67167576152875 139.74016809131032 31.9 35.67166908624712 139.74016147120508 31.9 35.67166908624712 139.74016147120508 9.031</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67167576152875 139.74016809131032 9.031 35.67170484207829 139.74012442407187 9.031 35.67170484207829 139.74012442407187 31.9 35.67167576152875 139.74016809131032 31.9 35.67167576152875 139.74016809131032 9.031</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67170484207829 139.74012442407187 9.031 35.6715827919737 139.74000261343247 9.031 35.6715827919737 139.74000261343247 31.9 35.67170484207829 139.74012442407187 31.9 35.67170484207829 139.74012442407187 9.031</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6715827919737 139.74000261343247 9.031 35.67149176934716 139.74013969490755 9.031 35.67149176934716 139.74013969490755 31.9 35.6715827919737 139.74000261343247 31.9 35.6715827919737 139.74000261343247 9.031</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67149176934716 139.74013969490755 9.031 35.671620224008905 139.74026790511252 9.031 35.671620224008905 139.74026790511252 31.9 35.67149176934716 139.74013969490755 31.9 35.67149176934716 139.74013969490755 9.031</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671620224008905 139.74026790511252 9.031 35.671649754683145 139.74022346416737 9.031 35.671649754683145 139.74022346416737 31.9 35.671620224008905 139.74026790511252 31.9 35.671620224008905 139.74026790511252 9.031</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671649754683145 139.74022346416737 9.031 35.67163658448536 139.74021033420792 9.031 35.67163658448536 139.74021033420792 31.9 35.671649754683145 139.74022346416737 31.9 35.671649754683145 139.74022346416737 9.031</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67163658448536 139.74021033420792 31.9 35.67165704889346 139.74017956820865 31.9 35.67162966290395 139.74015332056769 31.9 35.67164119634889 139.74013633984188 31.9 35.67166908624712 139.74016147120508 31.9 35.67167576152875 139.74016809131032 31.9 35.67170484207829 139.74012442407187 31.9 35.6715827919737 139.74000261343247 31.9 35.67149176934716 139.74013969490755 31.9 35.671620224008905 139.74026790511252 31.9 35.671649754683145 139.74022346416737 31.9 35.67163658448536 139.74021033420792 31.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-5fe4a44d-910e-453d-b38c-c96c34593e15"/>
							<gml:surfaceMember xlink:href="#poly-f783a16d-d32f-4f1c-8f4e-40b4fa6dabc2"/>
							<gml:surfaceMember xlink:href="#poly-556b6447-43ea-4aad-b04b-3612bdcb627a"/>
							<gml:surfaceMember xlink:href="#poly-533c498b-1765-4bdc-9858-f2eb8954a870"/>
							<gml:surfaceMember xlink:href="#poly-c9f78b3e-b62f-4633-a560-c0c78d473061"/>
							<gml:surfaceMember xlink:href="#poly-27f214ca-a04a-47ab-9857-9ddecf9c03b1"/>
							<gml:surfaceMember xlink:href="#poly-b2237a28-ff7f-4707-94e6-2cfe22fbf35d"/>
							<gml:surfaceMember xlink:href="#poly-289a41ff-e311-4f78-81eb-3669622219ba"/>
							<gml:surfaceMember xlink:href="#poly-a2083d34-9ba4-4c14-a688-4786db80dc52"/>
							<gml:surfaceMember xlink:href="#poly-d047dcdc-6322-44fe-a2ff-f3d642dc297f"/>
							<gml:surfaceMember xlink:href="#poly-b8206501-6692-4b4f-a35d-f0f7243ed90f"/>
							<gml:surfaceMember xlink:href="#poly-677729b5-6836-4627-b9e8-1a4b416bba15"/>
							<gml:surfaceMember xlink:href="#poly-d7466274-9a3f-490d-886b-34e5880bc368"/>
							<gml:surfaceMember xlink:href="#poly-e6232b6a-e259-49b6-b645-ea22b283fe80"/>
							<gml:surfaceMember xlink:href="#poly-c795a809-69bc-4980-aec2-318d48c60d9a"/>
							<gml:surfaceMember xlink:href="#poly-40d85848-3bdf-49df-97ce-3e934c328b42"/>
							<gml:surfaceMember xlink:href="#poly-1fab6981-0434-490b-a793-03c6f6ca6cb4"/>
							<gml:surfaceMember xlink:href="#poly-b38512d8-1d6c-4922-b2d4-e91006dbfcbe"/>
							<gml:surfaceMember xlink:href="#poly-6a7d3c0f-88fe-4854-a623-490f63f95b2f"/>
							<gml:surfaceMember xlink:href="#poly-dede885e-f11c-43a6-b9f5-c8ff7859df1d"/>
							<gml:surfaceMember xlink:href="#poly-404087cc-b181-4311-8200-af30c415e916"/>
							<gml:surfaceMember xlink:href="#poly-93d98f1a-188b-463f-9a59-631a5ede31f4"/>
							<gml:surfaceMember xlink:href="#poly-1dd31a60-897b-41ef-962d-d8996d86894d"/>
							<gml:surfaceMember xlink:href="#poly-7a4e4d7e-099d-40ac-881f-0f5721cacae5"/>
							<gml:surfaceMember xlink:href="#poly-878b39e9-63fa-4d84-ae61-28b3b8cf410d"/>
							<gml:surfaceMember xlink:href="#poly-960f085b-84b4-45ec-858f-ecc93b094de2"/>
							<gml:surfaceMember xlink:href="#poly-5ef21900-d67e-480c-acaa-adea8fcb81de"/>
							<gml:surfaceMember xlink:href="#poly-5be398a4-3c3c-424a-9354-3c9a208894b3"/>
							<gml:surfaceMember xlink:href="#poly-9d79e640-272d-49db-a86b-0652c44bc080"/>
							<gml:surfaceMember xlink:href="#poly-a98d2746-1aa8-422a-be5d-339c4ef3c8ce"/>
							<gml:surfaceMember xlink:href="#poly-9b4b813d-9159-4d68-b8ef-b1961e4ea333"/>
							<gml:surfaceMember xlink:href="#poly-2bcb7d69-a22b-4813-ac01-f33096506d30"/>
							<gml:surfaceMember xlink:href="#poly-2b9f29bb-0d54-4478-91fa-c002937b9eec"/>
							<gml:surfaceMember xlink:href="#poly-69809f63-3e74-4f21-9de3-65da77f81dc2"/>
							<gml:surfaceMember xlink:href="#poly-04245ab8-c454-4812-aa21-0241360b39d9"/>
							<gml:surfaceMember xlink:href="#poly-f457144f-5a03-421f-8c95-9bb9c2c0defe"/>
							<gml:surfaceMember xlink:href="#poly-7b5dcb0c-f6e8-469c-a09b-f58c6fc47102"/>
							<gml:surfaceMember xlink:href="#poly-461230dc-c0b7-45c3-bab6-9f11c3152fc5"/>
							<gml:surfaceMember xlink:href="#poly-e31a2083-207a-44d1-9d59-34d6bc1f2c74"/>
							<gml:surfaceMember xlink:href="#poly-eccfafdf-ffd3-4040-90a6-1347ebe2b094"/>
							<gml:surfaceMember xlink:href="#poly-2820e938-8e85-48f9-80ab-f60b5c371169"/>
							<gml:surfaceMember xlink:href="#poly-0d993b9a-fdeb-4a44-9c85-c0e0c3619e63"/>
							<gml:surfaceMember xlink:href="#poly-c9465864-bb7e-499f-aa52-ecd134c941ce"/>
							<gml:surfaceMember xlink:href="#poly-b73f1adf-dc6f-40e4-9155-6b4ef34fae52"/>
							<gml:surfaceMember xlink:href="#poly-5721a890-78bd-4061-8aa2-02406d5ee524"/>
							<gml:surfaceMember xlink:href="#poly-eabb931f-d47c-4516-bc28-89b6d5448e29"/>
							<gml:surfaceMember xlink:href="#poly-c5f5be2e-ff93-4d09-b857-19dfb3de7600"/>
							<gml:surfaceMember xlink:href="#poly-8e291325-f293-4da7-8696-3b6655627573"/>
							<gml:surfaceMember xlink:href="#poly-fb8c212e-309e-4dbf-b56f-921dc23cc6f8"/>
							<gml:surfaceMember xlink:href="#poly-a2508a49-46f1-4c06-8da4-298473323026"/>
							<gml:surfaceMember xlink:href="#poly-528e8ef8-3fa8-4d68-8ea3-ecb37e3d9b75"/>
							<gml:surfaceMember xlink:href="#poly-b5c80bf7-0745-4efb-8a5d-59d1ab182ae3"/>
							<gml:surfaceMember xlink:href="#poly-cea7dd4a-8702-4b4e-89e7-bf00ac9e9775"/>
							<gml:surfaceMember xlink:href="#poly-5ea02148-f6da-4a7e-91ca-db162e988156"/>
							<gml:surfaceMember xlink:href="#poly-80644ed2-f5af-43f3-9cef-f0c60badfe78"/>
							<gml:surfaceMember xlink:href="#poly-3316e612-7baa-41b5-9770-60af40b8d239"/>
							<gml:surfaceMember xlink:href="#poly-c4888032-8b4a-47d7-bf03-6da5e61c1220"/>
							<gml:surfaceMember xlink:href="#poly-e402a210-3104-46aa-bd4a-7a3e52eed067"/>
							<gml:surfaceMember xlink:href="#poly-301530cc-ba46-4004-84ed-22e6d9bbf0aa"/>
							<gml:surfaceMember xlink:href="#poly-b456c1e8-9b45-4638-9da6-6ff79387a23b"/>
							<gml:surfaceMember xlink:href="#poly-b2a94ad8-d50c-47e6-ae31-15c2c9bc75c2"/>
							<gml:surfaceMember xlink:href="#poly-66701e08-a8e3-403a-a70b-c35c84a0fbbc"/>
							<gml:surfaceMember xlink:href="#poly-14336cc0-504f-427a-91d7-cb40d09c3082"/>
							<gml:surfaceMember xlink:href="#poly-931e5084-b24f-423e-a3e6-06eedcb69475"/>
							<gml:surfaceMember xlink:href="#poly-11f5a785-72f1-48e5-9e25-31123511ca25"/>
							<gml:surfaceMember xlink:href="#poly-da079837-5ae5-4a13-a29d-8013c98698fd"/>
							<gml:surfaceMember xlink:href="#poly-5505256a-6bf3-48d7-8130-01218b186fd2"/>
							<gml:surfaceMember xlink:href="#poly-0e3cd62c-ebf6-46b2-bf97-ab994d6385ef"/>
							<gml:surfaceMember xlink:href="#poly-eec6eec0-3fa0-46c8-8375-862ae2f98338"/>
							<gml:surfaceMember xlink:href="#poly-fba1ec65-58d8-4189-ae8b-f4cbc60177a6"/>
							<gml:surfaceMember xlink:href="#poly-e38f0706-083d-45ad-92fe-2610797b058b"/>
							<gml:surfaceMember xlink:href="#poly-cd5277c4-123e-498f-b987-72015e8a96e2"/>
							<gml:surfaceMember xlink:href="#poly-aab78e4a-5ffa-4ffd-b0db-da9c2d678fc1"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_f36755c2-a45f-4f38-b2dc-434c9678840d_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-12ff5613-5150-4914-a18e-9aa193c05dd8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67159956211711 139.7401831698591 46.527 35.671606026362745 139.74017333102742 46.527 35.67162117197081 139.7401882702954 46.527 35.67161469871026 139.7401981091382 46.527 35.67159956211711 139.7401831698591 46.527</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-47e6a1e6-38a7-4bd2-a680-99434af56544">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-47e6a1e6-38a7-4bd2-a680-99434af56544_0">
											<gml:posList>35.67159956211711 139.7401831698591 46.527 35.67159956211711 139.7401831698591 47.514 35.671606026362745 139.74017333102742 47.514 35.671606026362745 139.74017333102742 46.527 35.67159956211711 139.7401831698591 46.527</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3d35b73f-1943-474d-8d99-f43026c4477d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3d35b73f-1943-474d-8d99-f43026c4477d_0">
											<gml:posList>35.671606026362745 139.74017333102742 47.514 35.67162117197081 139.7401882702954 47.514 35.67162117197081 139.7401882702954 46.527 35.671606026362745 139.74017333102742 46.527 35.671606026362745 139.74017333102742 47.514</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e50e0426-5bd1-4f8c-98d3-5bee1ddad3ae">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e50e0426-5bd1-4f8c-98d3-5bee1ddad3ae_0">
											<gml:posList>35.67159956211711 139.7401831698591 47.514 35.67161469871026 139.7401981091382 47.514 35.67162117197081 139.7401882702954 47.514 35.671606026362745 139.74017333102742 47.514 35.67159956211711 139.7401831698591 47.514</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6afcabef-2909-43a9-85d6-c913ad4d51d8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6afcabef-2909-43a9-85d6-c913ad4d51d8_0">
											<gml:posList>35.67161469871026 139.7401981091382 47.514 35.67159956211711 139.7401831698591 47.514 35.67159956211711 139.7401831698591 46.527 35.67161469871026 139.7401981091382 46.527 35.67161469871026 139.7401981091382 47.514</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2a66df69-c3ea-4642-8ee8-b347cea4acbb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2a66df69-c3ea-4642-8ee8-b347cea4acbb_0">
											<gml:posList>35.67162117197081 139.7401882702954 46.527 35.67162117197081 139.7401882702954 47.514 35.67161469871026 139.7401981091382 47.514 35.67161469871026 139.7401981091382 46.527 35.67162117197081 139.7401882702954 46.527</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_f36755c2-a45f-4f38-b2dc-434c9678840d_BuildingInstallation_1060">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8e458b58-89e8-412b-bbef-f76405988be4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8e458b58-89e8-412b-bbef-f76405988be4_0">
											<gml:posList>35.67159118372337 139.74018882431739 40.36 35.671590651503685 139.74018829470725 40.149 35.671590651503685 139.74018829470725 40.437 35.67159118372337 139.74018882431739 40.36</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-59a57282-4fc5-43a7-b89e-2dcc444d5b01">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-59a57282-4fc5-43a7-b89e-2dcc444d5b01_0">
											<gml:posList>35.67159118372337 139.74018882431739 40.36 35.67159118372337 139.74018882431739 40.149 35.671590651503685 139.74018829470725 40.149 35.67159118372337 139.74018882431739 40.36</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-10bc991b-d71d-414e-ad48-cd161a744694">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-10bc991b-d71d-414e-ad48-cd161a744694_0">
											<gml:posList>35.671632725758585 139.74020923404666 40.149 35.671631573335034 139.7402109586286 40.375 35.671631573335034 139.7402109586286 40.149 35.671632725758585 139.74020923404666 40.149</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7063545b-8a88-4b6f-8ab6-e23af60f544c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7063545b-8a88-4b6f-8ab6-e23af60f544c_0">
											<gml:posList>35.671632725758585 139.74020923404666 40.149 35.671632725758585 139.74020923404666 40.375 35.671631573335034 139.7402109586286 40.375 35.671632725758585 139.74020923404666 40.149</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d87bc799-be0e-4847-b5ef-2b1fa02b35cd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d87bc799-be0e-4847-b5ef-2b1fa02b35cd_0">
											<gml:posList>35.67163190709899 139.7402112896339 40.375 35.671631573335034 139.7402109586286 40.149 35.671631573335034 139.7402109586286 40.375 35.67163190709899 139.7402112896339 40.375</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-15f96a15-1383-4442-bb43-ae6241ec6630">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-15f96a15-1383-4442-bb43-ae6241ec6630_0">
											<gml:posList>35.67163190709899 139.7402112896339 40.375 35.67163190709899 139.7402112896339 40.149 35.671631573335034 139.7402109586286 40.149 35.67163190709899 139.7402112896339 40.375</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f812a540-6cc4-4740-84b5-8580ca405cb2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f812a540-6cc4-4740-84b5-8580ca405cb2_0">
											<gml:posList>35.671641205362604 139.74013633983142 40.375 35.67162966290392 139.74015332056769 9.031 35.67162966290392 139.74015332056769 40.375 35.671641205362604 139.74013633983142 40.375</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e5ccbcb4-faa6-41f5-975c-dea0632d857d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e5ccbcb4-faa6-41f5-975c-dea0632d857d_0">
											<gml:posList>35.671641205362604 139.74013633983142 40.375 35.671641205362604 139.74013633983142 9.031 35.67162966290392 139.74015332056769 9.031 35.671641205362604 139.74013633983142 40.375</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-dbfa8d7e-b242-4db8-8ea8-c821b5d16ccd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-dbfa8d7e-b242-4db8-8ea8-c821b5d16ccd_0">
											<gml:posList>35.67166908624712 139.74016147120508 40.375 35.671641205362604 139.74013633983142 9.031 35.671641205362604 139.74013633983142 40.375 35.67166908624712 139.74016147120508 40.375</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ca38880f-960a-4f49-b5c3-a5533a0a5867">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ca38880f-960a-4f49-b5c3-a5533a0a5867_0">
											<gml:posList>35.67166908624712 139.74016147120508 40.375 35.67166908624712 139.74016147120508 9.031 35.671641205362604 139.74013633983142 9.031 35.67166908624712 139.74016147120508 40.375</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5e9cca48-1558-48f9-80ab-1d1204b89a32">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5e9cca48-1558-48f9-80ab-1d1204b89a32_0">
											<gml:posList>35.671641205362604 139.74013633983142 40.375 35.67162966290392 139.74015332056769 40.375 35.671657048893444 139.74017956820865 40.375 35.671641205362604 139.74013633983142 40.375</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d27627c6-7d2a-4c25-9843-488b3d60d8c7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d27627c6-7d2a-4c25-9843-488b3d60d8c7_0">
											<gml:posList>35.67166908624712 139.74016147120508 40.375 35.671641205362604 139.74013633983142 40.375 35.671657048893444 139.74017956820865 40.375 35.67166908624712 139.74016147120508 40.375</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-76e11871-5acb-4e79-a672-ee913a6e288b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-76e11871-5acb-4e79-a672-ee913a6e288b_0">
											<gml:posList>35.67162966290392 139.74015332056769 40.375 35.671657048893444 139.74017956820865 9.031 35.671657048893444 139.74017956820865 40.375 35.67162966290392 139.74015332056769 40.375</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c73fcc82-1bd1-42be-8eaa-d9c76dfe08e0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c73fcc82-1bd1-42be-8eaa-d9c76dfe08e0_0">
											<gml:posList>35.67162966290392 139.74015332056769 40.375 35.67162966290392 139.74015332056769 9.031 35.671657048893444 139.74017956820865 9.031 35.67162966290392 139.74015332056769 40.375</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3018337e-004e-44ac-b25c-db8a8cb29618">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3018337e-004e-44ac-b25c-db8a8cb29618_0">
											<gml:posList>35.671657048893444 139.74017956820865 40.375 35.67166908624712 139.74016147120508 9.031 35.67166908624712 139.74016147120508 40.375 35.671657048893444 139.74017956820865 40.375</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8ec82e63-f9b9-4d70-b3df-8a5d9dccae90">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8ec82e63-f9b9-4d70-b3df-8a5d9dccae90_0">
											<gml:posList>35.671657048893444 139.74017956820865 40.375 35.671657048893444 139.74017956820865 9.031 35.67166908624712 139.74016147120508 9.031 35.671657048893444 139.74017956820865 40.375</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9392e31c-3647-4ae6-8e52-e91d2d90aa16">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9392e31c-3647-4ae6-8e52-e91d2d90aa16_0">
											<gml:posList>35.671590651503685 139.74018829470725 40.149 35.671585843764994 139.74019552465512 40.149 35.671590651503685 139.74018829470725 40.437 35.671590651503685 139.74018829470725 40.149</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f934975c-0c04-42ef-bbc9-4269828a5f19">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f934975c-0c04-42ef-bbc9-4269828a5f19_0">
											<gml:posList>35.671590651503685 139.74018829470725 40.437 35.671585843764994 139.74019552465512 43.619 35.671590651503685 139.74018829470725 43.619 35.671590651503685 139.74018829470725 40.437</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e3268fef-bf15-4e9e-81b8-2cf1b247c542">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e3268fef-bf15-4e9e-81b8-2cf1b247c542_0">
											<gml:posList>35.671590651503685 139.74018829470725 40.437 35.671585843764994 139.74019552465512 40.149 35.671585843764994 139.74019552465512 43.619 35.671590651503685 139.74018829470725 40.437</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2b3f0cb5-576f-42e2-afb9-7bc2b482825b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2b3f0cb5-576f-42e2-afb9-7bc2b482825b_0">
											<gml:posList>35.671616649142116 139.74021424570634 40.149 35.67159118372337 139.74018882431739 40.36 35.671616649142116 139.74021424570634 43.619 35.671616649142116 139.74021424570634 40.149</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4fcbf698-fe8b-43da-a030-d1660ab36eca">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4fcbf698-fe8b-43da-a030-d1660ab36eca_0">
											<gml:posList>35.671616649142116 139.74021424570634 43.619 35.67159118372337 139.74018882431739 40.36 35.671590651503685 139.74018829470725 43.619 35.671616649142116 139.74021424570634 43.619</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2fbbd5b6-e9b8-4bf1-9acd-a87ed91829d4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2fbbd5b6-e9b8-4bf1-9acd-a87ed91829d4_0">
											<gml:posList>35.671616649142116 139.74021424570634 40.149 35.67159118372337 139.74018882431739 40.149 35.67159118372337 139.74018882431739 40.36 35.671616649142116 139.74021424570634 40.149</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-320a8ee5-ec5b-48cb-943c-3e7e35361eb7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-320a8ee5-ec5b-48cb-943c-3e7e35361eb7_0">
											<gml:posList>35.671590651503685 139.74018829470725 43.619 35.67159118372337 139.74018882431739 40.36 35.671590651503685 139.74018829470725 40.437 35.671590651503685 139.74018829470725 43.619</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-535b21f7-5f03-4861-af10-c93f5e2f207d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-535b21f7-5f03-4861-af10-c93f5e2f207d_0">
											<gml:posList>35.671632725758585 139.74020923404666 40.149 35.67162506718904 139.74020158776565 40.149 35.671632725758585 139.74020923404666 40.375 35.671632725758585 139.74020923404666 40.149</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c2d4e7f8-9805-48ef-a73e-bdec9b7dbef0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c2d4e7f8-9805-48ef-a73e-bdec9b7dbef0_0">
											<gml:posList>35.67163305952254 139.74020956505194 40.375 35.671632725758585 139.74020923404666 40.375 35.67163305952254 139.74020956505194 43.619 35.67163305952254 139.74020956505194 40.375</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4cf3f8b4-39de-4bd3-b633-374bb223b649">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4cf3f8b4-39de-4bd3-b633-374bb223b649_0">
											<gml:posList>35.67163305952254 139.74020956505194 43.619 35.671632725758585 139.74020923404666 40.375 35.67162506718904 139.74020158776565 43.619 35.67163305952254 139.74020956505194 43.619</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-82487b44-313b-4b33-807a-516db12d5d29">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-82487b44-313b-4b33-807a-516db12d5d29_0">
											<gml:posList>35.671632725758585 139.74020923404666 40.375 35.67162506718904 139.74020158776565 40.149 35.67162506718904 139.74020158776565 43.619 35.671632725758585 139.74020923404666 40.375</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8a6b3a8b-87e4-4299-9da1-da3f64d91dab">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8a6b3a8b-87e4-4299-9da1-da3f64d91dab_0">
											<gml:posList>35.671616658155834 139.74021424569588 40.149 35.67162506718904 139.74020158776565 43.619 35.67162506718904 139.74020158776565 40.149 35.671616658155834 139.74021424569588 40.149</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b44cd000-844b-4935-87b7-a690080055d3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b44cd000-844b-4935-87b7-a690080055d3_0">
											<gml:posList>35.671616658155834 139.74021424569588 40.149 35.671616658155834 139.74021424569588 43.619 35.67162506718904 139.74020158776565 43.619 35.671616658155834 139.74021424569588 40.149</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2642c536-31e8-4b75-888a-bf9405fc2160">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2642c536-31e8-4b75-888a-bf9405fc2160_0">
											<gml:posList>35.6716198337341 139.74022945294195 40.149 35.671585843764994 139.74019552465512 43.619 35.671585843764994 139.74019552465512 40.149 35.6716198337341 139.74022945294195 40.149</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-051a9b5a-ae0a-4469-98f3-9424fed1804d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-051a9b5a-ae0a-4469-98f3-9424fed1804d_0">
											<gml:posList>35.6716198337341 139.74022945294195 40.149 35.6716198337341 139.74022945294195 43.619 35.671585843764994 139.74019552465512 43.619 35.6716198337341 139.74022945294195 40.149</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b55c1a03-4bc2-49b2-80ca-97c3678d46b9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b55c1a03-4bc2-49b2-80ca-97c3678d46b9_0">
											<gml:posList>35.67163190709899 139.7402112896339 40.149 35.67163190709899 139.7402112896339 40.375 35.6716198337341 139.74022945294195 40.149 35.67163190709899 139.7402112896339 40.149</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a997f541-1b38-4561-a65f-f15c33d76c60">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a997f541-1b38-4561-a65f-f15c33d76c60_0">
											<gml:posList>35.6716198337341 139.74022945294195 40.149 35.67163190709899 139.7402112896339 40.375 35.6716198337341 139.74022945294195 43.619 35.6716198337341 139.74022945294195 40.149</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9a413c4b-9ab6-43d7-8fdd-c6993da3c0ed">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9a413c4b-9ab6-43d7-8fdd-c6993da3c0ed_0">
											<gml:posList>35.6716198337341 139.74022945294195 43.619 35.67163190709899 139.7402112896339 40.375 35.67163305952254 139.74020956505194 43.619 35.6716198337341 139.74022945294195 43.619</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-413c6e53-7937-4d4c-9ab7-e645d73f5a7d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-413c6e53-7937-4d4c-9ab7-e645d73f5a7d_0">
											<gml:posList>35.67163190709899 139.7402112896339 40.375 35.67163305952254 139.74020956505194 40.375 35.67163305952254 139.74020956505194 43.619 35.67163190709899 139.7402112896339 40.375</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d9dfb72a-b8bf-42c6-bc89-c73a286b6310">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d9dfb72a-b8bf-42c6-bc89-c73a286b6310_0">
											<gml:posList>35.671590651503685 139.74018829470725 43.619 35.671585843764994 139.74019552465512 43.619 35.671616649142116 139.74021424570634 43.619 35.671590651503685 139.74018829470725 43.619</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-75a9e94e-ce71-481d-a1a9-45653f484d78">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-75a9e94e-ce71-481d-a1a9-45653f484d78_0">
											<gml:posList>35.67162506718904 139.74020158776565 43.619 35.671616649142116 139.74021424570634 43.619 35.67163305952254 139.74020956505194 43.619 35.67162506718904 139.74020158776565 43.619</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2030b343-24d1-4b2e-8be5-cd9c05f1c4aa">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2030b343-24d1-4b2e-8be5-cd9c05f1c4aa_0">
											<gml:posList>35.67163305952254 139.74020956505194 43.619 35.671616649142116 139.74021424570634 43.619 35.6716198337341 139.74022945294195 43.619 35.67163305952254 139.74020956505194 43.619</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5dff0152-f801-4732-8521-f65c67040eeb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5dff0152-f801-4732-8521-f65c67040eeb_0">
											<gml:posList>35.671616649142116 139.74021424570634 43.619 35.671585843764994 139.74019552465512 43.619 35.6716198337341 139.74022945294195 43.619 35.671616649142116 139.74021424570634 43.619</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1140fd42-65db-411c-8d78-a4c6a1e74441">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671657048893444 139.74017956820865 9.031 35.671641205362604 139.74013633983142 9.031 35.67166908624712 139.74016147120508 9.031 35.671657048893444 139.74017956820865 9.031</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-120a6ae8-4d39-4195-812f-a131b22e6f86">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671657048893444 139.74017956820865 9.031 35.67162966290392 139.74015332056769 9.031 35.671641205362604 139.74013633983142 9.031 35.671657048893444 139.74017956820865 9.031</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cd244f53-7df4-4074-a626-b45cde9331db">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67162506718904 139.74020158776565 40.149 35.671632725758585 139.74020923404666 40.149 35.671631573335034 139.7402109586286 40.149 35.67162506718904 139.74020158776565 40.149</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c1b93e1f-7eee-4f4c-8150-55d77a424c26">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671585843764994 139.74019552465512 40.149 35.671590651503685 139.74018829470725 40.149 35.67159118372337 139.74018882431739 40.149 35.671585843764994 139.74019552465512 40.149</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-37b05daf-9034-42cd-b33e-bec8f292e056">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671616649142116 139.74021424570634 40.149 35.671585843764994 139.74019552465512 40.149 35.67159118372337 139.74018882431739 40.149 35.671616649142116 139.74021424570634 40.149</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-92260993-816f-4a81-9933-9bcba73b2114">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671585843764994 139.74019552465512 40.149 35.671616649142116 139.74021424570634 40.149 35.6716198337341 139.74022945294195 40.149 35.671585843764994 139.74019552465512 40.149</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ca0e8d6f-ca7c-4bbd-b542-4df8bfa07db4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671631573335034 139.7402109586286 40.149 35.67163190709899 139.7402112896339 40.149 35.6716198337341 139.74022945294195 40.149 35.671631573335034 139.7402109586286 40.149</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-54c8998f-9008-4811-9e28-396951aaf794">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67162506718904 139.74020158776565 40.149 35.671631573335034 139.7402109586286 40.149 35.671616658155834 139.74021424569588 40.149 35.67162506718904 139.74020158776565 40.149</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c1e8193e-d4a1-41d9-9854-763226a06c36">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671631573335034 139.7402109586286 40.149 35.6716198337341 139.74022945294195 40.149 35.671616658155834 139.74021424569588 40.149 35.671631573335034 139.7402109586286 40.149</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7c5d0fa1-0bd5-4dd8-83b9-98ae28e5ba40">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67163190709899 139.7402112896339 40.375 35.671632725758585 139.74020923404666 40.375 35.67163305952254 139.74020956505194 40.375 35.67163190709899 139.7402112896339 40.375</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-37e87b9b-affd-4c43-9288-76095e3ff0fc">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67163190709899 139.7402112896339 40.375 35.671631573335034 139.7402109586286 40.375 35.671632725758585 139.74020923404666 40.375 35.67163190709899 139.7402112896339 40.375</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-5fe4a44d-910e-453d-b38c-c96c34593e15">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5fe4a44d-910e-453d-b38c-c96c34593e15">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5fe4a44d-910e-453d-b38c-c96c34593e15">
											<gml:posList>35.67158279197368 139.74000261343247 9.031 35.67170484207829 139.74012442407187 9.031 35.67167576152874 139.74016809131032 9.031 35.67166908624712 139.74016147120508 9.031 35.67164119634888 139.7401363398419 9.031 35.67162966290392 139.74015332056769 9.031 35.671657048893444 139.74017956820865 9.031 35.67163658448536 139.74021033420792 9.031 35.671649754683116 139.74022346416737 9.031 35.67162022400889 139.7402679051125 9.031 35.67149176934719 139.74013969490755 9.031 35.67158279197368 139.74000261343247 9.031</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f783a16d-d32f-4f1c-8f4e-40b4fa6dabc2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f783a16d-d32f-4f1c-8f4e-40b4fa6dabc2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f783a16d-d32f-4f1c-8f4e-40b4fa6dabc2">
											<gml:posList>35.67153636186117 139.74017670380843 32.809 35.67152969235721 139.74017755108568 32.809 35.67155144124629 139.7401992541249 32.809 35.671554439372024 139.7401947989344 32.809 35.67153636186117 139.74017670380843 32.809</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-556b6447-43ea-4aad-b04b-3612bdcb627a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-556b6447-43ea-4aad-b04b-3612bdcb627a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-556b6447-43ea-4aad-b04b-3612bdcb627a">
											<gml:posList>35.67162076012047 139.7400405026753 32.809 35.67158279197368 139.74000261343247 24.453 35.67149176934719 139.74013969490755 24.453 35.67152969235721 139.74017755108568 32.809 35.67162076012047 139.7400405026753 32.809</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-533c498b-1765-4bdc-9858-f2eb8954a870">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-533c498b-1765-4bdc-9858-f2eb8954a870">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-533c498b-1765-4bdc-9858-f2eb8954a870">
											<gml:posList>35.67159149889415 139.74017677230012 37.627 35.671576605720055 139.74016189902505 37.627 35.67155144124629 139.7401992541249 37.627 35.67156654188519 139.7402143259969 37.627 35.67159149889415 139.74017677230012 37.627</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c9f78b3e-b62f-4633-a560-c0c78d473061">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c9f78b3e-b62f-4633-a560-c0c78d473061">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c9f78b3e-b62f-4633-a560-c0c78d473061">
											<gml:posList>35.67152969235721 139.74017755108568 32.809 35.67153636186117 139.74017670380843 32.809 35.67162144247404 139.7400486651934 32.809 35.67162076012047 139.7400405026753 32.809 35.67152969235721 139.74017755108568 32.809</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-27f214ca-a04a-47ab-9857-9ddecf9c03b1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-27f214ca-a04a-47ab-9857-9ddecf9c03b1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-27f214ca-a04a-47ab-9857-9ddecf9c03b1">
											<gml:posList>35.671576974175444 139.7401488196305 35.435 35.67155659820293 139.74017737621978 35.435 35.67156120992281 139.74018474987128 35.435 35.671576605720055 139.74016189902505 35.435 35.67159149889415 139.74017677230012 35.435 35.67159693685714 139.74016859162558 35.435 35.671576974175444 139.7401488196305 35.435</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b2237a28-ff7f-4707-94e6-2cfe22fbf35d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b2237a28-ff7f-4707-94e6-2cfe22fbf35d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b2237a28-ff7f-4707-94e6-2cfe22fbf35d">
											<gml:posList>35.67157157106303 139.740213701556 40.375 35.67158932546132 139.7401869706767 40.375 35.67158655611271 139.74018421228774 40.375 35.67156654188519 139.7402143259969 40.375 35.67157157106303 139.740213701556 40.375</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-289a41ff-e311-4f78-81eb-3669622219ba">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-289a41ff-e311-4f78-81eb-3669622219ba">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-289a41ff-e311-4f78-81eb-3669622219ba">
											<gml:posList>35.67162486164464 139.7400757691565 32.259 35.671629876934965 139.74008049119547 32.259 35.67163898758684 139.74006597663222 32.259 35.67162144247404 139.7400486651934 32.259 35.67153636186117 139.74017670380843 32.259 35.671554439372024 139.7401947989344 32.259 35.67156120992281 139.74018474987128 32.259 35.67155659820293 139.74017737621978 32.259 35.671576974175444 139.7401488196305 32.259 35.67159693685714 139.74016859162558 32.259 35.67162708871468 139.74012321098797 32.259 35.67160764029523 139.74010406804524 32.259 35.67162486164464 139.7400757691565 32.259</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a2083d34-9ba4-4c14-a688-4786db80dc52">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a2083d34-9ba4-4c14-a688-4786db80dc52">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a2083d34-9ba4-4c14-a688-4786db80dc52">
											<gml:posList>35.67158655611271 139.74018421228774 47.073 35.6715897106159 139.74018382199782 47.073 35.67160512417535 139.74016062868333 47.073 35.671604796689685 139.74015676281408 47.073 35.67158655611271 139.74018421228774 47.073</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d047dcdc-6322-44fe-a2ff-f3d642dc297f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d047dcdc-6322-44fe-a2ff-f3d642dc297f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d047dcdc-6322-44fe-a2ff-f3d642dc297f">
											<gml:posList>35.671616649142116 139.74021424570634 47.073 35.67161632164964 139.74021036878986 47.073 35.6715897106159 139.74018382199782 47.073 35.67158655611271 139.74018421228774 47.073 35.671616649142116 139.74021424570634 47.073</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b8206501-6692-4b4f-a35d-f0f7243ed90f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b8206501-6692-4b4f-a35d-f0f7243ed90f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b8206501-6692-4b4f-a35d-f0f7243ed90f">
											<gml:posList>35.6716317262004 139.74018717548327 46.527 35.67160512417535 139.74016062868333 46.527 35.6715897106159 139.74018382199782 46.527 35.67161632164964 139.74021036878986 46.527 35.6716317262004 139.74018717548327 46.527</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-677729b5-6836-4627-b9e8-1a4b416bba15">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-677729b5-6836-4627-b9e8-1a4b416bba15">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-677729b5-6836-4627-b9e8-1a4b416bba15">
											<gml:posList>35.67160764029523 139.74010406804524 35.435 35.67162708871468 139.74012321098797 35.435 35.67163160834343 139.74011641217788 35.435 35.67161667908999 139.74010151685573 35.435 35.671629876934965 139.74008049119547 35.435 35.67162486164464 139.7400757691565 35.435 35.67160764029523 139.74010406804524 35.435</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d7466274-9a3f-490d-886b-34e5880bc368">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d7466274-9a3f-490d-886b-34e5880bc368">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d7466274-9a3f-490d-886b-34e5880bc368">
											<gml:posList>35.671604796689685 139.74015676281408 47.073 35.67160512417535 139.74016062868333 47.073 35.6716317262004 139.74018717548327 47.073 35.67163488972585 139.74018679622918 47.073 35.671604796689685 139.74015676281408 47.073</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e6232b6a-e259-49b6-b645-ea22b283fe80">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e6232b6a-e259-49b6-b645-ea22b283fe80">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e6232b6a-e259-49b6-b645-ea22b283fe80">
											<gml:posList>35.67163488972585 139.74018679622918 47.073 35.6716317262004 139.74018717548327 47.073 35.67161632164964 139.74021036878986 47.073 35.671616649142116 139.74021424570634 47.073 35.67163488972585 139.74018679622918 47.073</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c795a809-69bc-4980-aec2-318d48c60d9a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c795a809-69bc-4980-aec2-318d48c60d9a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c795a809-69bc-4980-aec2-318d48c60d9a">
											<gml:posList>35.67162144247404 139.7400486651934 32.809 35.67163898758684 139.74006597663222 32.809 35.671641787388616 139.74006149956972 32.809 35.67162076012047 139.7400405026753 32.809 35.67162144247404 139.7400486651934 32.809</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-40d85848-3bdf-49df-97ce-3e934c328b42">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-40d85848-3bdf-49df-97ce-3e934c328b42">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-40d85848-3bdf-49df-97ce-3e934c328b42">
											<gml:posList>35.6716098258672 139.74015613836926 40.375 35.67165811924028 139.74008345192988 40.375 35.671657609698265 139.7400772886116 40.375 35.671604796689685 139.74015676281408 40.375 35.67160756604746 139.74015953224912 40.375 35.6716098258672 139.74015613836926 40.375</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-1fab6981-0434-490b-a793-03c6f6ca6cb4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1fab6981-0434-490b-a793-03c6f6ca6cb4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1fab6981-0434-490b-a793-03c6f6ca6cb4">
											<gml:posList>35.67162966290392 139.74015332056769 40.375 35.67164119634888 139.7401363398419 40.375 35.671640605848545 139.74013038650088 40.375 35.67162457067314 139.74015400031826 40.375 35.67162966290392 139.74015332056769 40.375</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b38512d8-1d6c-4922-b2d4-e91006dbfcbe">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b38512d8-1d6c-4922-b2d4-e91006dbfcbe">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b38512d8-1d6c-4922-b2d4-e91006dbfcbe">
											<gml:posList>35.6716098258672 139.74015613836926 40.149 35.67160756604746 139.74015953224912 40.149 35.67163488972585 139.74018679622918 40.149 35.671616649142116 139.74021424570634 40.149 35.67158932546132 139.7401869706767 40.149 35.67157157106303 139.740213701556 40.149 35.67161971448486 139.74026175284234 40.149 35.671644734519006 139.74022408859784 40.149 35.671631573335034 139.7402109586286 40.149 35.67165197469852 139.7401802589833 40.149 35.67162457067314 139.74015400031826 40.149 35.671640605848545 139.74013038650088 40.149 35.67167126490066 139.74015802218477 40.149 35.67167524300299 139.74016196113988 40.149 35.67169981290958 139.74012505956588 40.149 35.67165811924028 139.74008345192988 40.149 35.6716098258672 139.74015613836926 40.149</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-6a7d3c0f-88fe-4854-a623-490f63f95b2f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6a7d3c0f-88fe-4854-a623-490f63f95b2f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6a7d3c0f-88fe-4854-a623-490f63f95b2f">
											<gml:posList>35.67161667908999 139.74010151685573 37.627 35.67163160834343 139.74011641217788 37.627 35.671657609698265 139.7400772886116 37.627 35.671641787388616 139.74006149956972 37.627 35.67161667908999 139.74010151685573 37.627</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-dede885e-f11c-43a6-b9f5-c8ff7859df1d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-dede885e-f11c-43a6-b9f5-c8ff7859df1d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-dede885e-f11c-43a6-b9f5-c8ff7859df1d">
											<gml:posList>35.67163658448536 139.74021033420792 40.375 35.671631573335034 139.7402109586286 40.375 35.671644734519006 139.74022408859784 40.375 35.671649754683116 139.74022346416737 40.375 35.67163658448536 139.74021033420792 40.375</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-404087cc-b181-4311-8200-af30c415e916">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-404087cc-b181-4311-8200-af30c415e916">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-404087cc-b181-4311-8200-af30c415e916">
											<gml:posList>35.67162966290392 139.74015332056769 40.375 35.67162457067314 139.74015400031826 40.375 35.67165197469852 139.7401802589833 40.375 35.671657048893444 139.74017956820865 40.375 35.67162966290392 139.74015332056769 40.375</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-93d98f1a-188b-463f-9a59-631a5ede31f4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-93d98f1a-188b-463f-9a59-631a5ede31f4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-93d98f1a-188b-463f-9a59-631a5ede31f4">
											<gml:posList>35.67163658448536 139.74021033420792 40.375 35.671657048893444 139.74017956820865 40.375 35.67165197469852 139.7401802589833 40.375 35.671631573335034 139.7402109586286 40.375 35.67163658448536 139.74021033420792 40.375</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-1dd31a60-897b-41ef-962d-d8996d86894d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1dd31a60-897b-41ef-962d-d8996d86894d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1dd31a60-897b-41ef-962d-d8996d86894d">
											<gml:posList>35.67164119634888 139.7401363398419 40.375 35.67166908624712 139.74016147120508 40.375 35.67167126490066 139.74015802218477 40.375 35.671640605848545 139.74013038650088 40.375 35.67164119634888 139.7401363398419 40.375</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-7a4e4d7e-099d-40ac-881f-0f5721cacae5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7a4e4d7e-099d-40ac-881f-0f5721cacae5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7a4e4d7e-099d-40ac-881f-0f5721cacae5">
											<gml:posList>35.67166908624712 139.74016147120508 40.375 35.67167576152874 139.74016809131032 40.375 35.67167524300299 139.74016196113988 40.375 35.67167126490066 139.74015802218477 40.375 35.67166908624712 139.74016147120508 40.375</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-878b39e9-63fa-4d84-ae61-28b3b8cf410d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-878b39e9-63fa-4d84-ae61-28b3b8cf410d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-878b39e9-63fa-4d84-ae61-28b3b8cf410d">
											<gml:posList>35.671657609698265 139.7400772886116 40.375 35.67165811924028 139.74008345192988 40.375 35.67169981290958 139.74012505956588 40.375 35.67170484207829 139.74012442407187 40.375 35.671657609698265 139.7400772886116 40.375</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-960f085b-84b4-45ec-858f-ecc93b094de2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-960f085b-84b4-45ec-858f-ecc93b094de2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-960f085b-84b4-45ec-858f-ecc93b094de2">
											<gml:posList>35.67170484207829 139.74012442407187 40.375 35.67169981290958 139.74012505956588 40.375 35.67167524300299 139.74016196113988 40.375 35.67167576152874 139.74016809131032 40.375 35.67170484207829 139.74012442407187 40.375</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-5ef21900-d67e-480c-acaa-adea8fcb81de">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5ef21900-d67e-480c-acaa-adea8fcb81de">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5ef21900-d67e-480c-acaa-adea8fcb81de">
											<gml:posList>35.67162022400889 139.7402679051125 40.375 35.67161971448486 139.74026175284234 40.375 35.67157157106303 139.740213701556 40.375 35.67156654188519 139.7402143259969 40.375 35.67162022400889 139.7402679051125 40.375</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-5be398a4-3c3c-424a-9354-3c9a208894b3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5be398a4-3c3c-424a-9354-3c9a208894b3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5be398a4-3c3c-424a-9354-3c9a208894b3">
											<gml:posList>35.671649754683116 139.74022346416737 40.375 35.671644734519006 139.74022408859784 40.375 35.67161971448486 139.74026175284234 40.375 35.67162022400889 139.7402679051125 40.375 35.671649754683116 139.74022346416737 40.375</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9d79e640-272d-49db-a86b-0652c44bc080">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9d79e640-272d-49db-a86b-0652c44bc080">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9d79e640-272d-49db-a86b-0652c44bc080">
											<gml:posList>35.671640605848545 139.74013038650088 40.375 35.671640605848545 139.74013038650088 40.149 35.67162457067314 139.74015400031826 40.149 35.67162457067314 139.74015400031826 40.375 35.671640605848545 139.74013038650088 40.375</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a98d2746-1aa8-422a-be5d-339c4ef3c8ce">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a98d2746-1aa8-422a-be5d-339c4ef3c8ce">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a98d2746-1aa8-422a-be5d-339c4ef3c8ce">
											<gml:posList>35.671657048893444 139.74017956820865 9.031 35.67162966290392 139.74015332056769 9.031 35.67162966290392 139.74015332056769 40.375 35.671657048893444 139.74017956820865 40.375 35.671657048893444 139.74017956820865 9.031</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9b4b813d-9159-4d68-b8ef-b1961e4ea333">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9b4b813d-9159-4d68-b8ef-b1961e4ea333">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9b4b813d-9159-4d68-b8ef-b1961e4ea333">
											<gml:posList>35.67160512417535 139.74016062868333 47.073 35.67160512417535 139.74016062868333 46.527 35.6716317262004 139.74018717548327 46.527 35.6716317262004 139.74018717548327 47.073 35.67160512417535 139.74016062868333 47.073</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2bcb7d69-a22b-4813-ac01-f33096506d30">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2bcb7d69-a22b-4813-ac01-f33096506d30">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2bcb7d69-a22b-4813-ac01-f33096506d30">
											<gml:posList>35.67165197469852 139.7401802589833 40.375 35.67165197469852 139.7401802589833 40.149 35.671631573335034 139.7402109586286 40.149 35.671631573335034 139.7402109586286 40.375 35.67165197469852 139.7401802589833 40.375</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2b9f29bb-0d54-4478-91fa-c002937b9eec">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2b9f29bb-0d54-4478-91fa-c002937b9eec">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2b9f29bb-0d54-4478-91fa-c002937b9eec">
											<gml:posList>35.67161632164964 139.74021036878986 47.073 35.67161632164964 139.74021036878986 46.527 35.6715897106159 139.74018382199782 46.527 35.6715897106159 139.74018382199782 47.073 35.67161632164964 139.74021036878986 47.073</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-69809f63-3e74-4f21-9de3-65da77f81dc2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-69809f63-3e74-4f21-9de3-65da77f81dc2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-69809f63-3e74-4f21-9de3-65da77f81dc2">
											<gml:posList>35.6716317262004 139.74018717548327 47.073 35.6716317262004 139.74018717548327 46.527 35.67161632164964 139.74021036878986 46.527 35.67161632164964 139.74021036878986 47.073 35.6716317262004 139.74018717548327 47.073</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-04245ab8-c454-4812-aa21-0241360b39d9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-04245ab8-c454-4812-aa21-0241360b39d9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-04245ab8-c454-4812-aa21-0241360b39d9">
											<gml:posList>35.67158279197368 139.74000261343247 9.031 35.67149176934719 139.74013969490755 9.031 35.67149176934719 139.74013969490755 24.453 35.67158279197368 139.74000261343247 24.453 35.67158279197368 139.74000261343247 9.031</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f457144f-5a03-421f-8c95-9bb9c2c0defe">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f457144f-5a03-421f-8c95-9bb9c2c0defe">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f457144f-5a03-421f-8c95-9bb9c2c0defe">
											<gml:posList>35.671554439372024 139.7401947989344 32.809 35.671554439372024 139.7401947989344 32.259 35.67153636186117 139.74017670380843 32.259 35.67153636186117 139.74017670380843 32.809 35.671554439372024 139.7401947989344 32.809</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7b5dcb0c-f6e8-469c-a09b-f58c6fc47102">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7b5dcb0c-f6e8-469c-a09b-f58c6fc47102">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7b5dcb0c-f6e8-469c-a09b-f58c6fc47102">
											<gml:posList>35.67155144124629 139.7401992541249 32.809 35.67152969235721 139.74017755108568 32.809 35.67149176934719 139.74013969490755 24.453 35.67149176934719 139.74013969490755 9.031 35.67162022400889 139.7402679051125 9.031 35.67162022400889 139.7402679051125 40.375 35.67156654188519 139.7402143259969 40.375 35.67156654188519 139.7402143259969 37.627 35.67155144124629 139.7401992541249 37.627 35.67155144124629 139.7401992541249 32.809</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-461230dc-c0b7-45c3-bab6-9f11c3152fc5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-461230dc-c0b7-45c3-bab6-9f11c3152fc5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-461230dc-c0b7-45c3-bab6-9f11c3152fc5">
											<gml:posList>35.67155659820293 139.74017737621978 32.259 35.67156120992281 139.74018474987128 32.259 35.67156120992281 139.74018474987128 35.435 35.67155659820293 139.74017737621978 35.435 35.67155659820293 139.74017737621978 32.259</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e31a2083-207a-44d1-9d59-34d6bc1f2c74">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e31a2083-207a-44d1-9d59-34d6bc1f2c74">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e31a2083-207a-44d1-9d59-34d6bc1f2c74">
											<gml:posList>35.67155144124629 139.7401992541249 37.627 35.671576605720055 139.74016189902505 37.627 35.671576605720055 139.74016189902505 35.435 35.67156120992281 139.74018474987128 35.435 35.67156120992281 139.74018474987128 32.259 35.671554439372024 139.7401947989344 32.259 35.671554439372024 139.7401947989344 32.809 35.67155144124629 139.7401992541249 32.809 35.67155144124629 139.7401992541249 37.627</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-eccfafdf-ffd3-4040-90a6-1347ebe2b094">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-eccfafdf-ffd3-4040-90a6-1347ebe2b094">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-eccfafdf-ffd3-4040-90a6-1347ebe2b094">
											<gml:posList>35.67155659820293 139.74017737621978 35.435 35.671576974175444 139.7401488196305 35.435 35.671576974175444 139.7401488196305 32.259 35.67155659820293 139.74017737621978 32.259 35.67155659820293 139.74017737621978 35.435</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2820e938-8e85-48f9-80ab-f60b5c371169">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2820e938-8e85-48f9-80ab-f60b5c371169">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2820e938-8e85-48f9-80ab-f60b5c371169">
											<gml:posList>35.67153636186117 139.74017670380843 32.809 35.67153636186117 139.74017670380843 32.259 35.67162144247404 139.7400486651934 32.259 35.67162144247404 139.7400486651934 32.809 35.67153636186117 139.74017670380843 32.809</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0d993b9a-fdeb-4a44-9c85-c0e0c3619e63">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0d993b9a-fdeb-4a44-9c85-c0e0c3619e63">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0d993b9a-fdeb-4a44-9c85-c0e0c3619e63">
											<gml:posList>35.67157157106303 139.740213701556 40.375 35.67157157106303 139.740213701556 40.149 35.67158932546132 139.7401869706767 40.149 35.67158932546132 139.7401869706767 40.375 35.67157157106303 139.740213701556 40.375</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c9465864-bb7e-499f-aa52-ecd134c941ce">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c9465864-bb7e-499f-aa52-ecd134c941ce">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c9465864-bb7e-499f-aa52-ecd134c941ce">
											<gml:posList>35.671576605720055 139.74016189902505 37.627 35.67159149889415 139.74017677230012 37.627 35.67159149889415 139.74017677230012 35.435 35.671576605720055 139.74016189902505 35.435 35.671576605720055 139.74016189902505 37.627</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b73f1adf-dc6f-40e4-9155-6b4ef34fae52">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b73f1adf-dc6f-40e4-9155-6b4ef34fae52">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b73f1adf-dc6f-40e4-9155-6b4ef34fae52">
											<gml:posList>35.671576974175444 139.7401488196305 35.435 35.67159693685714 139.74016859162558 35.435 35.67159693685714 139.74016859162558 32.259 35.671576974175444 139.7401488196305 32.259 35.671576974175444 139.7401488196305 35.435</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5721a890-78bd-4061-8aa2-02406d5ee524">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5721a890-78bd-4061-8aa2-02406d5ee524">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5721a890-78bd-4061-8aa2-02406d5ee524">
											<gml:posList>35.67161971448486 139.74026175284234 40.375 35.67161971448486 139.74026175284234 40.149 35.67157157106303 139.740213701556 40.149 35.67157157106303 139.740213701556 40.375 35.67161971448486 139.74026175284234 40.375</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-eabb931f-d47c-4516-bc28-89b6d5448e29">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-eabb931f-d47c-4516-bc28-89b6d5448e29">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-eabb931f-d47c-4516-bc28-89b6d5448e29">
											<gml:posList>35.6715897106159 139.74018382199782 47.073 35.6715897106159 139.74018382199782 46.527 35.67160512417535 139.74016062868333 46.527 35.67160512417535 139.74016062868333 47.073 35.6715897106159 139.74018382199782 47.073</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c5f5be2e-ff93-4d09-b857-19dfb3de7600">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c5f5be2e-ff93-4d09-b857-19dfb3de7600">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c5f5be2e-ff93-4d09-b857-19dfb3de7600">
											<gml:posList>35.67162144247404 139.7400486651934 32.809 35.67162144247404 139.7400486651934 32.259 35.67163898758684 139.74006597663222 32.259 35.67163898758684 139.74006597663222 32.809 35.67162144247404 139.7400486651934 32.809</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8e291325-f293-4da7-8696-3b6655627573">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8e291325-f293-4da7-8696-3b6655627573">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8e291325-f293-4da7-8696-3b6655627573">
											<gml:posList>35.67158279197368 139.74000261343247 9.031 35.67158279197368 139.74000261343247 24.453 35.67162076012047 139.7400405026753 32.809 35.671641787388616 139.74006149956972 32.809 35.671641787388616 139.74006149956972 37.627 35.671657609698265 139.7400772886116 37.627 35.671657609698265 139.7400772886116 40.375 35.67170484207829 139.74012442407187 40.375 35.67170484207829 139.74012442407187 9.031 35.67158279197368 139.74000261343247 9.031</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-fb8c212e-309e-4dbf-b56f-921dc23cc6f8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fb8c212e-309e-4dbf-b56f-921dc23cc6f8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fb8c212e-309e-4dbf-b56f-921dc23cc6f8">
											<gml:posList>35.67162486164464 139.7400757691565 35.435 35.671629876934965 139.74008049119547 35.435 35.671629876934965 139.74008049119547 32.259 35.67162486164464 139.7400757691565 32.259 35.67162486164464 139.7400757691565 35.435</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a2508a49-46f1-4c06-8da4-298473323026">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a2508a49-46f1-4c06-8da4-298473323026">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a2508a49-46f1-4c06-8da4-298473323026">
											<gml:posList>35.67163898758684 139.74006597663222 32.809 35.67163898758684 139.74006597663222 32.259 35.671629876934965 139.74008049119547 32.259 35.671629876934965 139.74008049119547 35.435 35.67161667908999 139.74010151685573 35.435 35.67161667908999 139.74010151685573 37.627 35.671641787388616 139.74006149956972 37.627 35.671641787388616 139.74006149956972 32.809 35.67163898758684 139.74006597663222 32.809</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-528e8ef8-3fa8-4d68-8ea3-ecb37e3d9b75">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-528e8ef8-3fa8-4d68-8ea3-ecb37e3d9b75">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-528e8ef8-3fa8-4d68-8ea3-ecb37e3d9b75">
											<gml:posList>35.67160764029523 139.74010406804524 35.435 35.67162486164464 139.7400757691565 35.435 35.67162486164464 139.7400757691565 32.259 35.67160764029523 139.74010406804524 32.259 35.67160764029523 139.74010406804524 35.435</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b5c80bf7-0745-4efb-8a5d-59d1ab182ae3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b5c80bf7-0745-4efb-8a5d-59d1ab182ae3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b5c80bf7-0745-4efb-8a5d-59d1ab182ae3">
											<gml:posList>35.67165811924028 139.74008345192988 40.375 35.67165811924028 139.74008345192988 40.149 35.67169981290958 139.74012505956588 40.149 35.67169981290958 139.74012505956588 40.375 35.67165811924028 139.74008345192988 40.375</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-cea7dd4a-8702-4b4e-89e7-bf00ac9e9775">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cea7dd4a-8702-4b4e-89e7-bf00ac9e9775">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cea7dd4a-8702-4b4e-89e7-bf00ac9e9775">
											<gml:posList>35.67163160834343 139.74011641217788 37.627 35.67161667908999 139.74010151685573 37.627 35.67161667908999 139.74010151685573 35.435 35.67163160834343 139.74011641217788 35.435 35.67163160834343 139.74011641217788 37.627</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5ea02148-f6da-4a7e-91ca-db162e988156">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5ea02148-f6da-4a7e-91ca-db162e988156">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5ea02148-f6da-4a7e-91ca-db162e988156">
											<gml:posList>35.67160764029523 139.74010406804524 32.259 35.67162708871468 139.74012321098797 32.259 35.67162708871468 139.74012321098797 35.435 35.67160764029523 139.74010406804524 35.435 35.67160764029523 139.74010406804524 32.259</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-80644ed2-f5af-43f3-9cef-f0c60badfe78">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-80644ed2-f5af-43f3-9cef-f0c60badfe78">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-80644ed2-f5af-43f3-9cef-f0c60badfe78">
											<gml:posList>35.6716098258672 139.74015613836926 40.375 35.6716098258672 139.74015613836926 40.149 35.67165811924028 139.74008345192988 40.149 35.67165811924028 139.74008345192988 40.375 35.6716098258672 139.74015613836926 40.375</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3316e612-7baa-41b5-9770-60af40b8d239">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3316e612-7baa-41b5-9770-60af40b8d239">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3316e612-7baa-41b5-9770-60af40b8d239">
											<gml:posList>35.67169981290958 139.74012505956588 40.375 35.67169981290958 139.74012505956588 40.149 35.67167524300299 139.74016196113988 40.149 35.67167524300299 139.74016196113988 40.375 35.67169981290958 139.74012505956588 40.375</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c4888032-8b4a-47d7-bf03-6da5e61c1220">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c4888032-8b4a-47d7-bf03-6da5e61c1220">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c4888032-8b4a-47d7-bf03-6da5e61c1220">
											<gml:posList>35.67167126490066 139.74015802218477 40.375 35.67167126490066 139.74015802218477 40.149 35.671640605848545 139.74013038650088 40.149 35.671640605848545 139.74013038650088 40.375 35.67167126490066 139.74015802218477 40.375</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e402a210-3104-46aa-bd4a-7a3e52eed067">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e402a210-3104-46aa-bd4a-7a3e52eed067">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e402a210-3104-46aa-bd4a-7a3e52eed067">
											<gml:posList>35.67162966290392 139.74015332056769 9.031 35.67164119634888 139.7401363398419 9.031 35.67164119634888 139.7401363398419 40.375 35.67162966290392 139.74015332056769 40.375 35.67162966290392 139.74015332056769 9.031</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-301530cc-ba46-4004-84ed-22e6d9bbf0aa">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-301530cc-ba46-4004-84ed-22e6d9bbf0aa">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-301530cc-ba46-4004-84ed-22e6d9bbf0aa">
											<gml:posList>35.67158655611271 139.74018421228774 40.375 35.67158655611271 139.74018421228774 47.073 35.671604796689685 139.74015676281408 47.073 35.671604796689685 139.74015676281408 40.375 35.671657609698265 139.7400772886116 40.375 35.671657609698265 139.7400772886116 37.627 35.67163160834343 139.74011641217788 37.627 35.67163160834343 139.74011641217788 35.435 35.67162708871468 139.74012321098797 35.435 35.67162708871468 139.74012321098797 32.259 35.67159693685714 139.74016859162558 32.259 35.67159693685714 139.74016859162558 35.435 35.67159149889415 139.74017677230012 35.435 35.67159149889415 139.74017677230012 37.627 35.67156654188519 139.7402143259969 37.627 35.67156654188519 139.7402143259969 40.375 35.67158655611271 139.74018421228774 40.375</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b456c1e8-9b45-4638-9da6-6ff79387a23b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b456c1e8-9b45-4638-9da6-6ff79387a23b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b456c1e8-9b45-4638-9da6-6ff79387a23b">
											<gml:posList>35.67167576152874 139.74016809131032 9.031 35.67170484207829 139.74012442407187 9.031 35.67170484207829 139.74012442407187 40.375 35.67167576152874 139.74016809131032 40.375 35.67167576152874 139.74016809131032 9.031</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b2a94ad8-d50c-47e6-ae31-15c2c9bc75c2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b2a94ad8-d50c-47e6-ae31-15c2c9bc75c2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b2a94ad8-d50c-47e6-ae31-15c2c9bc75c2">
											<gml:posList>35.67164119634888 139.7401363398419 9.031 35.67166908624712 139.74016147120508 9.031 35.67166908624712 139.74016147120508 40.375 35.67164119634888 139.7401363398419 40.375 35.67164119634888 139.7401363398419 9.031</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-66701e08-a8e3-403a-a70b-c35c84a0fbbc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-66701e08-a8e3-403a-a70b-c35c84a0fbbc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-66701e08-a8e3-403a-a70b-c35c84a0fbbc">
											<gml:posList>35.67160756604746 139.74015953224912 40.375 35.67160756604746 139.74015953224912 40.149 35.6716098258672 139.74015613836926 40.149 35.6716098258672 139.74015613836926 40.375 35.67160756604746 139.74015953224912 40.375</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-14336cc0-504f-427a-91d7-cb40d09c3082">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-14336cc0-504f-427a-91d7-cb40d09c3082">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-14336cc0-504f-427a-91d7-cb40d09c3082">
											<gml:posList>35.67167524300299 139.74016196113988 40.375 35.67167524300299 139.74016196113988 40.149 35.67167126490066 139.74015802218477 40.149 35.67167126490066 139.74015802218477 40.375 35.67167524300299 139.74016196113988 40.375</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-931e5084-b24f-423e-a3e6-06eedcb69475">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-931e5084-b24f-423e-a3e6-06eedcb69475">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-931e5084-b24f-423e-a3e6-06eedcb69475">
											<gml:posList>35.67166908624712 139.74016147120508 9.031 35.67167576152874 139.74016809131032 9.031 35.67167576152874 139.74016809131032 40.375 35.67166908624712 139.74016147120508 40.375 35.67166908624712 139.74016147120508 9.031</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-11f5a785-72f1-48e5-9e25-31123511ca25">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-11f5a785-72f1-48e5-9e25-31123511ca25">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-11f5a785-72f1-48e5-9e25-31123511ca25">
											<gml:posList>35.67162457067314 139.74015400031826 40.375 35.67162457067314 139.74015400031826 40.149 35.67165197469852 139.7401802589833 40.149 35.67165197469852 139.7401802589833 40.375 35.67162457067314 139.74015400031826 40.375</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-da079837-5ae5-4a13-a29d-8013c98698fd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-da079837-5ae5-4a13-a29d-8013c98698fd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-da079837-5ae5-4a13-a29d-8013c98698fd">
											<gml:posList>35.67160756604746 139.74015953224912 40.375 35.671604796689685 139.74015676281408 40.375 35.671604796689685 139.74015676281408 47.073 35.67163488972585 139.74018679622918 47.073 35.67163488972585 139.74018679622918 40.149 35.67160756604746 139.74015953224912 40.149 35.67160756604746 139.74015953224912 40.375</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5505256a-6bf3-48d7-8130-01218b186fd2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5505256a-6bf3-48d7-8130-01218b186fd2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5505256a-6bf3-48d7-8130-01218b186fd2">
											<gml:posList>35.67163658448536 139.74021033420792 9.031 35.671657048893444 139.74017956820865 9.031 35.671657048893444 139.74017956820865 40.375 35.67163658448536 139.74021033420792 40.375 35.67163658448536 139.74021033420792 9.031</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0e3cd62c-ebf6-46b2-bf97-ab994d6385ef">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0e3cd62c-ebf6-46b2-bf97-ab994d6385ef">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0e3cd62c-ebf6-46b2-bf97-ab994d6385ef">
											<gml:posList>35.67158655611271 139.74018421228774 47.073 35.67158655611271 139.74018421228774 40.375 35.67158932546132 139.7401869706767 40.375 35.67158932546132 139.7401869706767 40.149 35.671616649142116 139.74021424570634 40.149 35.671616649142116 139.74021424570634 47.073 35.67158655611271 139.74018421228774 47.073</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-eec6eec0-3fa0-46c8-8375-862ae2f98338">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-eec6eec0-3fa0-46c8-8375-862ae2f98338">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-eec6eec0-3fa0-46c8-8375-862ae2f98338">
											<gml:posList>35.671616649142116 139.74021424570634 40.149 35.67163488972585 139.74018679622918 40.149 35.67163488972585 139.74018679622918 47.073 35.671616649142116 139.74021424570634 47.073 35.671616649142116 139.74021424570634 40.149</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-fba1ec65-58d8-4189-ae8b-f4cbc60177a6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fba1ec65-58d8-4189-ae8b-f4cbc60177a6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fba1ec65-58d8-4189-ae8b-f4cbc60177a6">
											<gml:posList>35.671649754683116 139.74022346416737 9.031 35.67163658448536 139.74021033420792 9.031 35.67163658448536 139.74021033420792 40.375 35.671649754683116 139.74022346416737 40.375 35.671649754683116 139.74022346416737 9.031</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e38f0706-083d-45ad-92fe-2610797b058b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e38f0706-083d-45ad-92fe-2610797b058b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e38f0706-083d-45ad-92fe-2610797b058b">
											<gml:posList>35.671631573335034 139.7402109586286 40.375 35.671631573335034 139.7402109586286 40.149 35.671644734519006 139.74022408859784 40.149 35.671644734519006 139.74022408859784 40.375 35.671631573335034 139.7402109586286 40.375</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-cd5277c4-123e-498f-b987-72015e8a96e2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cd5277c4-123e-498f-b987-72015e8a96e2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cd5277c4-123e-498f-b987-72015e8a96e2">
											<gml:posList>35.671644734519006 139.74022408859784 40.375 35.671644734519006 139.74022408859784 40.149 35.67161971448486 139.74026175284234 40.149 35.67161971448486 139.74026175284234 40.375 35.671644734519006 139.74022408859784 40.375</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-aab78e4a-5ffa-4ffd-b0db-da9c2d678fc1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-aab78e4a-5ffa-4ffd-b0db-da9c2d678fc1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-aab78e4a-5ffa-4ffd-b0db-da9c2d678fc1">
											<gml:posList>35.67162022400889 139.7402679051125 9.031 35.671649754683116 139.74022346416737 9.031 35.671649754683116 139.74022346416737 40.375 35.67162022400889 139.7402679051125 40.375 35.67162022400889 139.7402679051125 9.031</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-4674</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">278.63935</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1210</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>6</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.01</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>