<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_f39a63f6-9b5d-4933-b0e0-ff726afa2acb">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>18</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103018001</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="再開発等促進区を定める地区計画">
				<gen:value>虎ノ門駅南地区</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">401</bldg:usage>
			<bldg:measuredHeight uom="m">26</bldg:measuredHeight>
			<bldg:storeysAboveGround>9</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.668633492701524 139.74890880656204 0 35.668657597967695 139.74883532512902 0 35.668519010219136 139.74876886377177 0 35.668506959666374 139.7488085316286 0 35.66854933891574 139.74882947436984 0 35.66853836565127 139.74886295533418 0 35.668633492701524 139.74890880656204 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668633492701524 139.74890880656204 5.43 35.66853836565127 139.74886295533418 5.43 35.66854933891574 139.74882947436984 5.43 35.668506959666374 139.7488085316286 5.43 35.668519010219136 139.74876886377177 5.43 35.668657597967695 139.74883532512902 5.43 35.668633492701524 139.74890880656204 5.43</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668633492701524 139.74890880656204 5.43 35.668657597967695 139.74883532512902 5.43 35.668657597967695 139.74883532512902 30.98 35.668633492701524 139.74890880656204 30.98 35.668633492701524 139.74890880656204 5.43</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668657597967695 139.74883532512902 5.43 35.668519010219136 139.74876886377177 5.43 35.668519010219136 139.74876886377177 30.98 35.668657597967695 139.74883532512902 30.98 35.668657597967695 139.74883532512902 5.43</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668519010219136 139.74876886377177 5.43 35.668506959666374 139.7488085316286 5.43 35.668506959666374 139.7488085316286 30.98 35.668519010219136 139.74876886377177 30.98 35.668519010219136 139.74876886377177 5.43</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668506959666374 139.7488085316286 5.43 35.66854933891574 139.74882947436984 5.43 35.66854933891574 139.74882947436984 30.98 35.668506959666374 139.7488085316286 30.98 35.668506959666374 139.7488085316286 5.43</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66854933891574 139.74882947436984 5.43 35.66853836565127 139.74886295533418 5.43 35.66853836565127 139.74886295533418 30.98 35.66854933891574 139.74882947436984 30.98 35.66854933891574 139.74882947436984 5.43</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66853836565127 139.74886295533418 5.43 35.668633492701524 139.74890880656204 5.43 35.668633492701524 139.74890880656204 30.98 35.66853836565127 139.74886295533418 30.98 35.66853836565127 139.74886295533418 5.43</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668633492701524 139.74890880656204 30.98 35.668657597967695 139.74883532512902 30.98 35.668519010219136 139.74876886377177 30.98 35.668506959666374 139.7488085316286 30.98 35.66854933891574 139.74882947436984 30.98 35.66853836565127 139.74886295533418 30.98 35.668633492701524 139.74890880656204 30.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-0bd38b29-328a-47f3-ad8a-bb737f3debfc"/>
							<gml:surfaceMember xlink:href="#poly-3d955de1-f339-4158-96e7-b6c741ac8c48"/>
							<gml:surfaceMember xlink:href="#poly-bd788dd5-1cf9-43a1-8b70-05cd1b435822"/>
							<gml:surfaceMember xlink:href="#poly-5389f315-68e8-4db3-8285-2514044d0c3a"/>
							<gml:surfaceMember xlink:href="#poly-be99b440-68eb-4cdf-9d4d-08b478d14059"/>
							<gml:surfaceMember xlink:href="#poly-4e1a649b-e325-4aa9-a876-8226e2e540c1"/>
							<gml:surfaceMember xlink:href="#poly-724f9137-f352-4a89-8774-a71290e20a75"/>
							<gml:surfaceMember xlink:href="#poly-9a3430b0-d423-4cd6-a4c6-ecb924657b66"/>
							<gml:surfaceMember xlink:href="#poly-88f7a6d4-b9e7-483d-bc22-5a8a1ed86a89"/>
							<gml:surfaceMember xlink:href="#poly-2c50a908-acc1-4946-961c-be0fb4cce022"/>
							<gml:surfaceMember xlink:href="#poly-48f615e0-8edd-4a2f-8846-09da9dbd05e5"/>
							<gml:surfaceMember xlink:href="#poly-53104e85-6d6d-4e6a-95e5-fd4ddc553873"/>
							<gml:surfaceMember xlink:href="#poly-41eb64e1-7412-46fc-860c-372d32720e2f"/>
							<gml:surfaceMember xlink:href="#poly-b1c27fcc-fbf2-427c-8f41-ab955f405cec"/>
							<gml:surfaceMember xlink:href="#poly-e818e998-9505-4c3d-b692-849b39471b3a"/>
							<gml:surfaceMember xlink:href="#poly-7d17a139-4e70-43da-9c20-98a6cd45dd08"/>
							<gml:surfaceMember xlink:href="#poly-bf720a6e-8699-4b3b-8961-7bd23a7d054e"/>
							<gml:surfaceMember xlink:href="#poly-6153d42b-dddc-47b9-9e4e-4b8aa5d83f69"/>
							<gml:surfaceMember xlink:href="#poly-14546a33-4667-49e0-95e8-9e43b05ad5e8"/>
							<gml:surfaceMember xlink:href="#poly-c6372322-be68-41c0-8dfe-97eeb71260d9"/>
							<gml:surfaceMember xlink:href="#poly-8cc20f35-edd2-43b3-b5d0-c8f4e9bf6324"/>
							<gml:surfaceMember xlink:href="#poly-3ef77ad8-3ef1-4c85-b802-ac377e25d6f9"/>
							<gml:surfaceMember xlink:href="#poly-4cd742ef-2dc4-46ca-ad23-ec0f06ca1613"/>
							<gml:surfaceMember xlink:href="#poly-0894c253-771a-4049-859b-34bb06d0367a"/>
							<gml:surfaceMember xlink:href="#poly-d52385ad-62b8-4b52-bc70-38ca21d04504"/>
							<gml:surfaceMember xlink:href="#poly-5a8698e3-8365-434a-8b34-0b8969d743fc"/>
							<gml:surfaceMember xlink:href="#poly-a3670cb3-93d5-40f6-a6f5-0cc8ff27e43b"/>
							<gml:surfaceMember xlink:href="#poly-92a1450f-10c6-4e53-81f7-a0d55c882b7c"/>
							<gml:surfaceMember xlink:href="#poly-47cf4c84-4251-483d-aa94-aab4a394b431"/>
							<gml:surfaceMember xlink:href="#poly-a8b94cce-e119-46ea-80c4-533d2117170b"/>
							<gml:surfaceMember xlink:href="#poly-d8296c52-5318-4670-ac58-dff37da67358"/>
							<gml:surfaceMember xlink:href="#poly-6821882f-6550-4deb-a106-9e6c0a043619"/>
							<gml:surfaceMember xlink:href="#poly-86330a00-9fea-4ec1-b482-00fd9edcc8a9"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_f39a63f6-9b5d-4933-b0e0-ff726afa2acb_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4cb277e5-a927-42c0-9423-be165daf9d84">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66852696235279 139.7488102558116 34.951 35.66851790040863 139.74880578068655 34.951 35.66852213684033 139.74879290762559 34.951 35.66853119878496 139.74879738274944 34.951 35.66852696235279 139.7488102558116 34.951</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f91b8279-8c96-419f-b2e0-68a164cb42a7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668564505330565 139.74883704699508 30.931 35.668576467492365 139.74879985351384 30.931 35.66857868562149 139.74880092263854 30.931 35.668597197045806 139.7488097951647 30.931 35.66859516481243 139.74881673420396 30.931 35.66860089934947 139.74881930188099 30.931 35.66859605234571 139.74883554463108 30.931 35.66858898335103 139.74883237082858 30.931 35.6685817533262 139.74885662444538 30.931 35.668561249654495 139.74884744472098 30.931 35.668564505330565 139.74883704699508 30.931</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ec910639-9c3f-4ff9-97a7-dd9e64b1c9c2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66857868562149 139.74880092263854 31.3 35.668576467492365 139.74879985351384 31.3 35.66857732192762 139.7487971905242 31.3 35.668597988354165 139.74880708805694 31.3 35.668597197045806 139.7488097951647 31.3 35.66857868562149 139.74880092263854 31.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-564ab859-8451-47fe-93ad-5660db2b467f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-564ab859-8451-47fe-93ad-5660db2b467f_0">
											<gml:posList>35.66857868562149 139.74880092263854 30.931 35.668576467492365 139.74879985351384 30.931 35.668576467492365 139.74879985351384 31.3 35.66857868562149 139.74880092263854 31.3 35.66857868562149 139.74880092263854 30.931</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-02fbc440-7f71-4f76-a5d0-dc70a868f512">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-02fbc440-7f71-4f76-a5d0-dc70a868f512_0">
											<gml:posList>35.66853119878496 139.74879738274944 34.951 35.66852213684033 139.74879290762559 34.951 35.66852213684033 139.74879290762559 36.882 35.66853119878496 139.74879738274944 36.882 35.66853119878496 139.74879738274944 34.951</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4c156bec-2100-4906-ab5f-81dbc2716b26">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4c156bec-2100-4906-ab5f-81dbc2716b26_0">
											<gml:posList>35.66852213684033 139.74879290762559 34.951 35.66851790040863 139.74880578068655 34.951 35.66851790040863 139.74880578068655 36.882 35.66852213684033 139.74879290762559 36.882 35.66852213684033 139.74879290762559 34.951</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c196a122-4f6a-43ad-8a9d-992ac3552682">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c196a122-4f6a-43ad-8a9d-992ac3552682_0">
											<gml:posList>35.66852696235279 139.7488102558116 36.882 35.66853119878496 139.74879738274944 36.882 35.66852213684033 139.74879290762559 36.882 35.66851790040863 139.74880578068655 36.882 35.66852696235279 139.7488102558116 36.882</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-93e4e93f-48b8-414f-bc13-5b39f87c185c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-93e4e93f-48b8-414f-bc13-5b39f87c185c_0">
											<gml:posList>35.66853119878496 139.74879738274944 34.951 35.66853119878496 139.74879738274944 36.882 35.66852696235279 139.7488102558116 36.882 35.66852696235279 139.7488102558116 34.951 35.66853119878496 139.74879738274944 34.951</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2f0cadde-8cb3-4a72-aaa5-317ff3d8ddc1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2f0cadde-8cb3-4a72-aaa5-317ff3d8ddc1_0">
											<gml:posList>35.66852696235279 139.7488102558116 36.882 35.66851790040863 139.74880578068655 36.882 35.66851790040863 139.74880578068655 34.951 35.66852696235279 139.7488102558116 34.951 35.66852696235279 139.7488102558116 36.882</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fe6d0f04-a21d-49d8-801a-dd7ffbba8713">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fe6d0f04-a21d-49d8-801a-dd7ffbba8713_0">
											<gml:posList>35.66857732192762 139.7487971905242 31.3 35.66857732192762 139.7487971905242 33.388 35.668597988354165 139.74880708805694 33.388 35.668597988354165 139.74880708805694 31.3 35.66857732192762 139.7487971905242 31.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6653c9c8-c506-4bbc-9acd-308075c8e0f2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6653c9c8-c506-4bbc-9acd-308075c8e0f2_0">
											<gml:posList>35.66857868562149 139.74880092263854 31.3 35.668597197045806 139.7488097951647 31.3 35.668597197045806 139.7488097951647 30.931 35.66857868562149 139.74880092263854 30.931 35.66857868562149 139.74880092263854 31.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-66b15f13-defe-40c9-9f74-e64e3825c352">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-66b15f13-defe-40c9-9f74-e64e3825c352_0">
											<gml:posList>35.668597197045806 139.7488097951647 31.3 35.668597988354165 139.74880708805694 31.3 35.668597988354165 139.74880708805694 33.388 35.66859516481243 139.74881673420396 33.388 35.66859516481243 139.74881673420396 30.931 35.668597197045806 139.7488097951647 30.931 35.668597197045806 139.7488097951647 31.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e8677068-c96d-4723-9887-57aedd376848">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e8677068-c96d-4723-9887-57aedd376848_0">
											<gml:posList>35.668576467492365 139.74879985351384 31.3 35.668576467492365 139.74879985351384 30.931 35.668564505330565 139.74883704699508 30.931 35.668564505330565 139.74883704699508 33.388 35.66857732192762 139.7487971905242 33.388 35.66857732192762 139.7487971905242 31.3 35.668576467492365 139.74879985351384 31.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9ea78052-fd0f-4fdf-9d5a-4e5f5b2ed789">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9ea78052-fd0f-4fdf-9d5a-4e5f5b2ed789_0">
											<gml:posList>35.66860089934947 139.74881930188099 30.931 35.66859516481243 139.74881673420396 30.931 35.66859516481243 139.74881673420396 33.388 35.66860089934947 139.74881930188099 33.388 35.66860089934947 139.74881930188099 30.931</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-89a23814-2884-4843-a6db-5510643ebb6d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-89a23814-2884-4843-a6db-5510643ebb6d_0">
											<gml:posList>35.6685817533262 139.74885662444538 33.388 35.66858898335103 139.74883237082858 33.388 35.66859605234571 139.74883554463108 33.388 35.66860089934947 139.74881930188099 33.388 35.66859516481243 139.74881673420396 33.388 35.668597988354165 139.74880708805694 33.388 35.66857732192762 139.7487971905242 33.388 35.668564505330565 139.74883704699508 33.388 35.668561249654495 139.74884744472098 33.388 35.6685817533262 139.74885662444538 33.388</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-82b1ae02-9c2a-4e95-bb99-59b3fc1f9fb5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-82b1ae02-9c2a-4e95-bb99-59b3fc1f9fb5_0">
											<gml:posList>35.66859605234571 139.74883554463108 30.931 35.66860089934947 139.74881930188099 30.931 35.66860089934947 139.74881930188099 33.388 35.66859605234571 139.74883554463108 33.388 35.66859605234571 139.74883554463108 30.931</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-473e90e1-10ae-4702-a8ea-0c55100970f5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-473e90e1-10ae-4702-a8ea-0c55100970f5_0">
											<gml:posList>35.66859605234571 139.74883554463108 30.931 35.66859605234571 139.74883554463108 33.388 35.66858898335103 139.74883237082858 33.388 35.66858898335103 139.74883237082858 30.931 35.66859605234571 139.74883554463108 30.931</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c8c5244b-eedc-4d83-97d0-f7c55b5d3f0e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c8c5244b-eedc-4d83-97d0-f7c55b5d3f0e_0">
											<gml:posList>35.668561249654495 139.74884744472098 30.931 35.668561249654495 139.74884744472098 33.388 35.668564505330565 139.74883704699508 33.388 35.668564505330565 139.74883704699508 30.931 35.668561249654495 139.74884744472098 30.931</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d930cce8-852e-43d6-b313-2f9de4b54e03">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d930cce8-852e-43d6-b313-2f9de4b54e03_0">
											<gml:posList>35.6685817533262 139.74885662444538 30.931 35.66858898335103 139.74883237082858 30.931 35.66858898335103 139.74883237082858 33.388 35.6685817533262 139.74885662444538 33.388 35.6685817533262 139.74885662444538 30.931</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b3c73068-2802-47ae-8196-f22b2da085e1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b3c73068-2802-47ae-8196-f22b2da085e1_0">
											<gml:posList>35.6685817533262 139.74885662444538 30.931 35.6685817533262 139.74885662444538 33.388 35.668561249654495 139.74884744472098 33.388 35.668561249654495 139.74884744472098 30.931 35.6685817533262 139.74885662444538 30.931</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_f39a63f6-9b5d-4933-b0e0-ff726afa2acb_BuildingInstallation_1041">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c23bc052-787f-4c2e-a1d2-dc3bf71be509">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66863114150749 139.74883368506042 30.931 35.66862468382676 139.74885389503342 30.931 35.66860171811309 139.7488428732145 30.931 35.66860816677827 139.7488226632559 30.931 35.66863114150749 139.74883368506042 30.931</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a5a6d4de-0902-4558-abfd-5625ab184728">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a5a6d4de-0902-4558-abfd-5625ab184728_0">
											<gml:posList>35.66860171811309 139.7488428732145 30.931 35.66860171811309 139.7488428732145 33.388 35.66860816677827 139.7488226632559 33.388 35.66860816677827 139.7488226632559 30.931 35.66860171811309 139.7488428732145 30.931</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-24ff0438-dab0-40c8-a12d-c8762425d276">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-24ff0438-dab0-40c8-a12d-c8762425d276_0">
											<gml:posList>35.66862468382676 139.74885389503342 30.931 35.66862468382676 139.74885389503342 33.388 35.66860171811309 139.7488428732145 33.388 35.66860171811309 139.7488428732145 30.931 35.66862468382676 139.74885389503342 30.931</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-08360097-a036-4325-9efc-5cc3942430ef">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-08360097-a036-4325-9efc-5cc3942430ef_0">
											<gml:posList>35.66860171811309 139.7488428732145 33.388 35.66862468382676 139.74885389503342 33.388 35.66863114150749 139.74883368506042 33.388 35.66860816677827 139.7488226632559 33.388 35.66860171811309 139.7488428732145 33.388</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5126aa20-6f7a-4c9a-a2e1-940bcfb8528e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5126aa20-6f7a-4c9a-a2e1-940bcfb8528e_0">
											<gml:posList>35.66860816677827 139.7488226632559 30.931 35.66860816677827 139.7488226632559 33.388 35.66863114150749 139.74883368506042 33.388 35.66863114150749 139.74883368506042 30.931 35.66860816677827 139.7488226632559 30.931</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-365859b4-8e2a-42ce-9d67-da9c46774f63">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-365859b4-8e2a-42ce-9d67-da9c46774f63_0">
											<gml:posList>35.66863114150749 139.74883368506042 30.931 35.66863114150749 139.74883368506042 33.388 35.66862468382676 139.74885389503342 33.388 35.66862468382676 139.74885389503342 30.931 35.66863114150749 139.74883368506042 30.931</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-0bd38b29-328a-47f3-ad8a-bb737f3debfc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0bd38b29-328a-47f3-ad8a-bb737f3debfc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0bd38b29-328a-47f3-ad8a-bb737f3debfc">
											<gml:posList>35.668657597967695 139.748835325129 5.43 35.66863349270148 139.74890880656204 5.43 35.66853836565127 139.74886295533415 5.43 35.66854933891575 139.74882947436984 5.43 35.66850695966635 139.7488085316286 5.43 35.668519010219136 139.74876886377177 5.43 35.668657597967695 139.748835325129 5.43</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-3d955de1-f339-4158-96e7-b6c741ac8c48">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3d955de1-f339-4158-96e7-b6c741ac8c48">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3d955de1-f339-4158-96e7-b6c741ac8c48">
											<gml:posList>35.668519010219136 139.74876886377177 35.267 35.66852033778918 139.748772496507 35.267 35.66857424003932 139.7487983425586 35.267 35.668577195440754 139.74879677090908 35.267 35.668519010219136 139.74876886377177 35.267</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-bd788dd5-1cf9-43a1-8b70-05cd1b435822">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bd788dd5-1cf9-43a1-8b70-05cd1b435822">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bd788dd5-1cf9-43a1-8b70-05cd1b435822">
											<gml:posList>35.66850695966635 139.7488085316286 35.267 35.66850986999931 139.74880696002833 35.267 35.66852033778918 139.748772496507 35.267 35.668519010219136 139.74876886377177 35.267 35.66850695966635 139.7488085316286 35.267</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-5389f315-68e8-4db3-8285-2514044d0c3a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5389f315-68e8-4db3-8285-2514044d0c3a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5389f315-68e8-4db3-8285-2514044d0c3a">
											<gml:posList>35.66857868562149 139.74880092263854 31.3 35.668577195440754 139.74879677090908 31.3 35.66857624207164 139.74879974329139 31.3 35.66857868562149 139.74880092263854 31.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-be99b440-68eb-4cdf-9d4d-08b478d14059">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-be99b440-68eb-4cdf-9d4d-08b478d14059">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-be99b440-68eb-4cdf-9d4d-08b478d14059">
											<gml:posList>35.66857424003932 139.7487983425586 34.951 35.66852033778918 139.748772496507 34.951 35.66850986999931 139.74880696002833 34.951 35.66856298838894 139.74883329295025 34.951 35.66857424003932 139.7487983425586 34.951</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-4e1a649b-e325-4aa9-a876-8226e2e540c1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4e1a649b-e325-4aa9-a876-8226e2e540c1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4e1a649b-e325-4aa9-a876-8226e2e540c1">
											<gml:posList>35.668577195440754 139.74879677090908 31.3 35.66857868562149 139.74880092263854 31.3 35.66863845778604 139.7488295903227 31.3 35.668641845668475 139.74882776415882 31.3 35.668577195440754 139.74879677090908 31.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-724f9137-f352-4a89-8774-a71290e20a75">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-724f9137-f352-4a89-8774-a71290e20a75">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-724f9137-f352-4a89-8774-a71290e20a75">
											<gml:posList>35.668577195440754 139.74879677090908 35.267 35.66857424003932 139.7487983425586 35.267 35.66856298838894 139.74883329295025 35.267 35.668564261874664 139.7488369257455 35.267 35.668577195440754 139.74879677090908 35.267</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-9a3430b0-d423-4cd6-a4c6-ecb924657b66">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9a3430b0-d423-4cd6-a4c6-ecb924657b66">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9a3430b0-d423-4cd6-a4c6-ecb924657b66">
											<gml:posList>35.668564261874664 139.7488369257455 35.267 35.66856298838894 139.74883329295025 35.267 35.66850986999931 139.74880696002833 35.267 35.66850695966635 139.7488085316286 35.267 35.668564261874664 139.7488369257455 35.267</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-88f7a6d4-b9e7-483d-bc22-5a8a1ed86a89">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-88f7a6d4-b9e7-483d-bc22-5a8a1ed86a89">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-88f7a6d4-b9e7-483d-bc22-5a8a1ed86a89">
											<gml:posList>35.66855177347486 139.748830686865 31.3 35.66854933891575 139.74882947436984 31.3 35.668550793063716 139.74883365927442 31.3 35.66855177347486 139.748830686865 31.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-2c50a908-acc1-4946-961c-be0fb4cce022">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2c50a908-acc1-4946-961c-be0fb4cce022">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2c50a908-acc1-4946-961c-be0fb4cce022">
											<gml:posList>35.66853836565127 139.74886295533415 31.3 35.66854178059095 139.74886115123746 31.3 35.668550793063716 139.74883365927442 31.3 35.66854933891575 139.74882947436984 31.3 35.66853836565127 139.74886295533415 31.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-48f615e0-8edd-4a2f-8846-09da9dbd05e5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-48f615e0-8edd-4a2f-8846-09da9dbd05e5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-48f615e0-8edd-4a2f-8846-09da9dbd05e5">
											<gml:posList>35.66857868562149 139.74880092263854 30.931 35.66857624207164 139.74879974329139 30.931 35.668564261874664 139.7488369257455 30.931 35.66855177347486 139.748830686865 30.931 35.668550793063716 139.74883365927442 30.931 35.66854178059095 139.74886115123746 30.931 35.66861681826475 139.74889733626057 30.931 35.66863845778604 139.7488295903227 30.931 35.66857868562149 139.74880092263854 30.931</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-53104e85-6d6d-4e6a-95e5-fd4ddc553873">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-53104e85-6d6d-4e6a-95e5-fd4ddc553873">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-53104e85-6d6d-4e6a-95e5-fd4ddc553873">
											<gml:posList>35.668641845668475 139.74882776415882 31.3 35.66863845778604 139.7488295903227 31.3 35.66861681826475 139.74889733626057 31.3 35.66861829942828 139.7489014880034 31.3 35.668641845668475 139.74882776415882 31.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-41eb64e1-7412-46fc-860c-372d32720e2f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-41eb64e1-7412-46fc-860c-372d32720e2f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-41eb64e1-7412-46fc-860c-372d32720e2f">
											<gml:posList>35.668641845668475 139.74882776415882 30.471 35.66861829942828 139.7489014880034 30.471 35.66863349270148 139.74890880656204 28.5 35.668641845668475 139.74882776415882 30.471</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b1c27fcc-fbf2-427c-8f41-ab955f405cec">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b1c27fcc-fbf2-427c-8f41-ab955f405cec">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b1c27fcc-fbf2-427c-8f41-ab955f405cec">
											<gml:posList>35.66863349270148 139.74890880656204 28.5 35.668657597967695 139.748835325129 28.5 35.668641845668475 139.74882776415882 30.471 35.66863349270148 139.74890880656204 28.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e818e998-9505-4c3d-b692-849b39471b3a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e818e998-9505-4c3d-b692-849b39471b3a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e818e998-9505-4c3d-b692-849b39471b3a">
											<gml:posList>35.66861829942828 139.7489014880034 31.3 35.66861681826475 139.74889733626057 31.3 35.66854178059095 139.74886115123746 31.3 35.66853836565127 139.74886295533415 31.3 35.66861829942828 139.7489014880034 31.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7d17a139-4e70-43da-9c20-98a6cd45dd08">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7d17a139-4e70-43da-9c20-98a6cd45dd08">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7d17a139-4e70-43da-9c20-98a6cd45dd08">
											<gml:posList>35.66856298838894 139.74883329295025 35.267 35.66856298838894 139.74883329295025 34.951 35.66850986999931 139.74880696002833 34.951 35.66850986999931 139.74880696002833 35.267 35.66856298838894 139.74883329295025 35.267</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-bf720a6e-8699-4b3b-8961-7bd23a7d054e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bf720a6e-8699-4b3b-8961-7bd23a7d054e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bf720a6e-8699-4b3b-8961-7bd23a7d054e">
											<gml:posList>35.66852033778918 139.748772496507 35.267 35.66852033778918 139.748772496507 34.951 35.66857424003932 139.7487983425586 34.951 35.66857424003932 139.7487983425586 35.267 35.66852033778918 139.748772496507 35.267</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6153d42b-dddc-47b9-9e4e-4b8aa5d83f69">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6153d42b-dddc-47b9-9e4e-4b8aa5d83f69">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6153d42b-dddc-47b9-9e4e-4b8aa5d83f69">
											<gml:posList>35.668519010219136 139.74876886377177 5.43 35.66850695966635 139.7488085316286 5.43 35.66850695966635 139.7488085316286 35.267 35.668519010219136 139.74876886377177 35.267 35.668519010219136 139.74876886377177 5.43</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-14546a33-4667-49e0-95e8-9e43b05ad5e8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-14546a33-4667-49e0-95e8-9e43b05ad5e8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-14546a33-4667-49e0-95e8-9e43b05ad5e8">
											<gml:posList>35.66850986999931 139.74880696002833 35.267 35.66850986999931 139.74880696002833 34.951 35.66852033778918 139.748772496507 34.951 35.66852033778918 139.748772496507 35.267 35.66850986999931 139.74880696002833 35.267</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c6372322-be68-41c0-8dfe-97eeb71260d9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c6372322-be68-41c0-8dfe-97eeb71260d9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c6372322-be68-41c0-8dfe-97eeb71260d9">
											<gml:posList>35.66855177347486 139.748830686865 31.3 35.66855177347486 139.748830686865 30.931 35.668564261874664 139.7488369257455 30.931 35.668564261874664 139.7488369257455 35.267 35.66850695966635 139.7488085316286 35.267 35.66850695966635 139.7488085316286 5.43 35.66854933891575 139.74882947436984 5.43 35.66854933891575 139.74882947436984 31.3 35.66855177347486 139.748830686865 31.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8cc20f35-edd2-43b3-b5d0-c8f4e9bf6324">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8cc20f35-edd2-43b3-b5d0-c8f4e9bf6324">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8cc20f35-edd2-43b3-b5d0-c8f4e9bf6324">
											<gml:posList>35.66854933891575 139.74882947436984 5.43 35.66853836565127 139.74886295533415 5.43 35.66853836565127 139.74886295533415 31.3 35.66854933891575 139.74882947436984 31.3 35.66854933891575 139.74882947436984 5.43</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3ef77ad8-3ef1-4c85-b802-ac377e25d6f9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3ef77ad8-3ef1-4c85-b802-ac377e25d6f9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3ef77ad8-3ef1-4c85-b802-ac377e25d6f9">
											<gml:posList>35.66854178059095 139.74886115123746 31.3 35.66854178059095 139.74886115123746 30.931 35.668550793063716 139.74883365927442 30.931 35.668550793063716 139.74883365927442 31.3 35.66854178059095 139.74886115123746 31.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4cd742ef-2dc4-46ca-ad23-ec0f06ca1613">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4cd742ef-2dc4-46ca-ad23-ec0f06ca1613">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4cd742ef-2dc4-46ca-ad23-ec0f06ca1613">
											<gml:posList>35.668550793063716 139.74883365927442 31.3 35.668550793063716 139.74883365927442 30.931 35.66855177347486 139.748830686865 30.931 35.66855177347486 139.748830686865 31.3 35.668550793063716 139.74883365927442 31.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0894c253-771a-4049-859b-34bb06d0367a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0894c253-771a-4049-859b-34bb06d0367a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0894c253-771a-4049-859b-34bb06d0367a">
											<gml:posList>35.66857424003932 139.7487983425586 35.267 35.66857424003932 139.7487983425586 34.951 35.66856298838894 139.74883329295025 34.951 35.66856298838894 139.74883329295025 35.267 35.66857424003932 139.7487983425586 35.267</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d52385ad-62b8-4b52-bc70-38ca21d04504">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d52385ad-62b8-4b52-bc70-38ca21d04504">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d52385ad-62b8-4b52-bc70-38ca21d04504">
											<gml:posList>35.668577195440754 139.74879677090908 35.267 35.668564261874664 139.7488369257455 35.267 35.668564261874664 139.7488369257455 30.931 35.66857624207164 139.74879974329139 30.931 35.66857624207164 139.74879974329139 31.3 35.668577195440754 139.74879677090908 31.3 35.668577195440754 139.74879677090908 35.267</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5a8698e3-8365-434a-8b34-0b8969d743fc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5a8698e3-8365-434a-8b34-0b8969d743fc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5a8698e3-8365-434a-8b34-0b8969d743fc">
											<gml:posList>35.66857624207164 139.74879974329139 31.3 35.66857624207164 139.74879974329139 30.931 35.66857868562149 139.74880092263854 30.931 35.66857868562149 139.74880092263854 31.3 35.66857624207164 139.74879974329139 31.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a3670cb3-93d5-40f6-a6f5-0cc8ff27e43b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a3670cb3-93d5-40f6-a6f5-0cc8ff27e43b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a3670cb3-93d5-40f6-a6f5-0cc8ff27e43b">
											<gml:posList>35.66861681826475 139.74889733626057 31.3 35.66861681826475 139.74889733626057 30.931 35.66854178059095 139.74886115123746 30.931 35.66854178059095 139.74886115123746 31.3 35.66861681826475 139.74889733626057 31.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-92a1450f-10c6-4e53-81f7-a0d55c882b7c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-92a1450f-10c6-4e53-81f7-a0d55c882b7c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-92a1450f-10c6-4e53-81f7-a0d55c882b7c">
											<gml:posList>35.66861829942828 139.7489014880034 30.471 35.66861829942828 139.7489014880034 31.3 35.66853836565127 139.74886295533415 31.3 35.66853836565127 139.74886295533415 5.43 35.66863349270148 139.74890880656204 5.43 35.66863349270148 139.74890880656204 28.5 35.66861829942828 139.7489014880034 30.471</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-47cf4c84-4251-483d-aa94-aab4a394b431">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-47cf4c84-4251-483d-aa94-aab4a394b431">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-47cf4c84-4251-483d-aa94-aab4a394b431">
											<gml:posList>35.668657597967695 139.748835325129 5.43 35.668519010219136 139.74876886377177 5.43 35.668519010219136 139.74876886377177 35.267 35.668577195440754 139.74879677090908 35.267 35.668577195440754 139.74879677090908 31.3 35.668641845668475 139.74882776415882 31.3 35.668641845668475 139.74882776415882 30.471 35.668657597967695 139.748835325129 28.5 35.668657597967695 139.748835325129 5.43</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a8b94cce-e119-46ea-80c4-533d2117170b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a8b94cce-e119-46ea-80c4-533d2117170b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a8b94cce-e119-46ea-80c4-533d2117170b">
											<gml:posList>35.66857868562149 139.74880092263854 31.3 35.66857868562149 139.74880092263854 30.931 35.66863845778604 139.7488295903227 30.931 35.66863845778604 139.7488295903227 31.3 35.66857868562149 139.74880092263854 31.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d8296c52-5318-4670-ac58-dff37da67358">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d8296c52-5318-4670-ac58-dff37da67358">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d8296c52-5318-4670-ac58-dff37da67358">
											<gml:posList>35.66863845778604 139.7488295903227 31.3 35.66863845778604 139.7488295903227 30.931 35.66861681826475 139.74889733626057 30.931 35.66861681826475 139.74889733626057 31.3 35.66863845778604 139.7488295903227 31.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6821882f-6550-4deb-a106-9e6c0a043619">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6821882f-6550-4deb-a106-9e6c0a043619">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6821882f-6550-4deb-a106-9e6c0a043619">
											<gml:posList>35.668641845668475 139.74882776415882 30.471 35.668641845668475 139.74882776415882 31.3 35.66861829942828 139.7489014880034 31.3 35.66861829942828 139.7489014880034 30.471 35.668641845668475 139.74882776415882 30.471</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-86330a00-9fea-4ec1-b482-00fd9edcc8a9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-86330a00-9fea-4ec1-b482-00fd9edcc8a9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-86330a00-9fea-4ec1-b482-00fd9edcc8a9">
											<gml:posList>35.66863349270148 139.74890880656204 5.43 35.668657597967695 139.748835325129 5.43 35.668657597967695 139.748835325129 28.5 35.66863349270148 139.74890880656204 28.5 35.66863349270148 139.74890880656204 5.43</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区虎ノ門一丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-9165</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">100.94745</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1210</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>7</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.12</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>