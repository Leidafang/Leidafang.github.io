<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_f3c20589-6b11-40e6-ac27-ff75190dbd1f">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">402</bldg:usage>
			<bldg:measuredHeight uom="m">26.4</bldg:measuredHeight>
			<bldg:storeysAboveGround>6</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>2</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.67274690212406 139.73757553857038 0 35.672742564205805 139.7375612936575 0 35.67281329632244 139.73752906357086 0 35.67280299378378 139.737495273308 0 35.67271288930055 139.737536474301 0 35.67270891289326 139.73752344408808 0 35.67258835301158 139.73757848958576 0 35.672635708484776 139.73773396872963 0 35.67283438911259 139.73764326018073 0 35.672805650305094 139.73754873564403 0 35.67274690212406 139.73757553857038 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67274690212406 139.73757553857038 9.126 35.672805650305094 139.73754873564403 9.126 35.67283438911259 139.73764326018073 9.126 35.672635708484776 139.73773396872963 9.126 35.67258835301158 139.73757848958576 9.126 35.67270891289326 139.73752344408808 9.126 35.67271288930055 139.737536474301 9.126 35.67280299378378 139.737495273308 9.126 35.67281329632244 139.73752906357086 9.126 35.672742564205805 139.7375612936575 9.126 35.67274690212406 139.73757553857038 9.126</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67274690212406 139.73757553857038 9.126 35.672742564205805 139.7375612936575 9.126 35.672742564205805 139.7375612936575 35.5 35.67274690212406 139.73757553857038 35.5 35.67274690212406 139.73757553857038 9.126</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672742564205805 139.7375612936575 9.126 35.67281329632244 139.73752906357086 9.126 35.67281329632244 139.73752906357086 35.5 35.672742564205805 139.7375612936575 35.5 35.672742564205805 139.7375612936575 9.126</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67281329632244 139.73752906357086 9.126 35.67280299378378 139.737495273308 9.126 35.67280299378378 139.737495273308 35.5 35.67281329632244 139.73752906357086 35.5 35.67281329632244 139.73752906357086 9.126</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67280299378378 139.737495273308 9.126 35.67271288930055 139.737536474301 9.126 35.67271288930055 139.737536474301 35.5 35.67280299378378 139.737495273308 35.5 35.67280299378378 139.737495273308 9.126</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67271288930055 139.737536474301 9.126 35.67270891289326 139.73752344408808 9.126 35.67270891289326 139.73752344408808 35.5 35.67271288930055 139.737536474301 35.5 35.67271288930055 139.737536474301 9.126</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67270891289326 139.73752344408808 9.126 35.67258835301158 139.73757848958576 9.126 35.67258835301158 139.73757848958576 35.5 35.67270891289326 139.73752344408808 35.5 35.67270891289326 139.73752344408808 9.126</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67258835301158 139.73757848958576 9.126 35.672635708484776 139.73773396872963 9.126 35.672635708484776 139.73773396872963 35.5 35.67258835301158 139.73757848958576 35.5 35.67258835301158 139.73757848958576 9.126</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672635708484776 139.73773396872963 9.126 35.67283438911259 139.73764326018073 9.126 35.67283438911259 139.73764326018073 35.5 35.672635708484776 139.73773396872963 35.5 35.672635708484776 139.73773396872963 9.126</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67283438911259 139.73764326018073 9.126 35.672805650305094 139.73754873564403 9.126 35.672805650305094 139.73754873564403 35.5 35.67283438911259 139.73764326018073 35.5 35.67283438911259 139.73764326018073 9.126</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672805650305094 139.73754873564403 9.126 35.67274690212406 139.73757553857038 9.126 35.67274690212406 139.73757553857038 35.5 35.672805650305094 139.73754873564403 35.5 35.672805650305094 139.73754873564403 9.126</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67274690212406 139.73757553857038 35.5 35.672742564205805 139.7375612936575 35.5 35.67281329632244 139.73752906357086 35.5 35.67280299378378 139.737495273308 35.5 35.67271288930055 139.737536474301 35.5 35.67270891289326 139.73752344408808 35.5 35.67258835301158 139.73757848958576 35.5 35.672635708484776 139.73773396872963 35.5 35.67283438911259 139.73764326018073 35.5 35.672805650305094 139.73754873564403 35.5 35.67274690212406 139.73757553857038 35.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-2d1ac242-e86b-44d5-aed1-bfcd67306038"/>
							<gml:surfaceMember xlink:href="#poly-7602fcf7-b88b-4618-82ac-aa698cbfddcb"/>
							<gml:surfaceMember xlink:href="#poly-a6d79f27-b0bf-497b-b2b7-b352d4b00b71"/>
							<gml:surfaceMember xlink:href="#poly-ac2f89f2-5ca7-4675-8298-2ce4f4db6d9f"/>
							<gml:surfaceMember xlink:href="#poly-231acbe3-f9f9-4e59-824e-d8828fd7451e"/>
							<gml:surfaceMember xlink:href="#poly-c73c4572-213f-4175-ae2f-e32ceb509fb6"/>
							<gml:surfaceMember xlink:href="#poly-b4f00717-85ed-4cab-98f9-e4ee8b280dc2"/>
							<gml:surfaceMember xlink:href="#poly-813d669c-89c8-405a-9e4e-75a23742228c"/>
							<gml:surfaceMember xlink:href="#poly-e0f5f8e3-3d95-42ac-85e3-aa6aa6cf3479"/>
							<gml:surfaceMember xlink:href="#poly-fa65a21a-87e5-4b68-bc3e-7b5baab5ea4c"/>
							<gml:surfaceMember xlink:href="#poly-0d5bda93-ad0c-4f82-8269-61bb1eb2c5b1"/>
							<gml:surfaceMember xlink:href="#poly-44760d0b-0075-4341-8450-3ebc7349da66"/>
							<gml:surfaceMember xlink:href="#poly-3aa8ea07-b432-47d4-9293-6515dd1ad69d"/>
							<gml:surfaceMember xlink:href="#poly-a2999732-7fb7-4c17-a02e-fd6026791d58"/>
							<gml:surfaceMember xlink:href="#poly-e549ead8-a2bd-454d-8e69-28c392069239"/>
							<gml:surfaceMember xlink:href="#poly-11fd2a99-4baa-4ce9-b0a0-2aa408e81b2e"/>
							<gml:surfaceMember xlink:href="#poly-ab54fa19-c601-4eed-8b01-1b51476ad948"/>
							<gml:surfaceMember xlink:href="#poly-488f0c5c-5f52-4ac3-8f49-3abb4cadea11"/>
							<gml:surfaceMember xlink:href="#poly-b0b5b80f-ed74-4eae-86eb-fc7c98f908f3"/>
							<gml:surfaceMember xlink:href="#poly-f0518b16-ca61-4813-b64b-97c3ecfa9c48"/>
							<gml:surfaceMember xlink:href="#poly-c8ac2a69-b98e-408b-b50b-50e0ad7428ab"/>
							<gml:surfaceMember xlink:href="#poly-c73b88f6-0e8a-452c-a9c6-2fdaf3be78b6"/>
							<gml:surfaceMember xlink:href="#poly-1bf7b3b2-bec8-44b9-9351-12b707c867d7"/>
							<gml:surfaceMember xlink:href="#poly-6cc36b4e-dfeb-435f-851a-19fd26596196"/>
							<gml:surfaceMember xlink:href="#poly-f41ff702-f74a-4d28-a0b0-eba5c132098a"/>
							<gml:surfaceMember xlink:href="#poly-9e54126a-4374-412f-8b31-271906c57472"/>
							<gml:surfaceMember xlink:href="#poly-9446393c-a4ee-4da8-8fc7-9fb2fa53bbb7"/>
							<gml:surfaceMember xlink:href="#poly-c1f95edf-3980-4e6c-b075-5663c75cbe8f"/>
							<gml:surfaceMember xlink:href="#poly-a88f61fa-46f9-45e0-b175-1c2cf53e013d"/>
							<gml:surfaceMember xlink:href="#poly-9c6517d9-1cb4-4a74-aab1-3c9e1e12fb5a"/>
							<gml:surfaceMember xlink:href="#poly-756cbe72-005a-4a14-ad57-f3eaf0a1b981"/>
							<gml:surfaceMember xlink:href="#poly-e2427310-20a5-4cf4-a718-21ce182c1cfb"/>
							<gml:surfaceMember xlink:href="#poly-1df20ec3-cd90-4d5f-be0c-74d2fafe6881"/>
							<gml:surfaceMember xlink:href="#poly-7f0352ee-d028-43e6-aab6-694349f9ca93"/>
							<gml:surfaceMember xlink:href="#poly-0efca00a-64a0-48c3-a5de-f4c561994205"/>
							<gml:surfaceMember xlink:href="#poly-f179de4a-9eec-4001-a26e-2459753303f4"/>
							<gml:surfaceMember xlink:href="#poly-d5bdd545-fd8a-4517-b732-ff34e44dde5a"/>
							<gml:surfaceMember xlink:href="#poly-8c4076d5-3806-4010-bb11-8088508483e3"/>
							<gml:surfaceMember xlink:href="#poly-b95df10b-1297-450c-9889-e443494fdfc8"/>
							<gml:surfaceMember xlink:href="#poly-0af1dc29-35d2-4d5e-ba0f-fa7588920d18"/>
							<gml:surfaceMember xlink:href="#poly-3fd2a279-e99d-4657-ac02-89977a810ae6"/>
							<gml:surfaceMember xlink:href="#poly-c9a55009-cc16-4b08-a9fe-d136a209c857"/>
							<gml:surfaceMember xlink:href="#poly-2dde5c91-d1c5-4305-81ef-4b21eff1d6c2"/>
							<gml:surfaceMember xlink:href="#poly-0fa3ad9b-9630-4b8a-a4de-4578854a6e7b"/>
							<gml:surfaceMember xlink:href="#poly-846e7c27-e7c6-4061-b0bd-d358624166b3"/>
							<gml:surfaceMember xlink:href="#poly-8ad3bf47-2f84-4d85-a2c9-69b06963ee0b"/>
							<gml:surfaceMember xlink:href="#poly-70f7ae78-5703-49f8-ad0b-85de79ae8c9d"/>
							<gml:surfaceMember xlink:href="#poly-51763f51-c10d-4d1f-a090-4e43ee5af930"/>
							<gml:surfaceMember xlink:href="#poly-818f1ab0-29ae-4a5e-b9a4-6d5df745d053"/>
							<gml:surfaceMember xlink:href="#poly-50fe46bd-aadf-4e12-a91f-d50e6c5c34b6"/>
							<gml:surfaceMember xlink:href="#poly-b2c7ae7f-3c2d-4597-bf9b-8ab30c245c7d"/>
							<gml:surfaceMember xlink:href="#poly-34896f07-2809-45e0-8013-fb5b79f7ed46"/>
							<gml:surfaceMember xlink:href="#poly-46ef1ffc-5e25-4d31-8d2c-787b34b92244"/>
							<gml:surfaceMember xlink:href="#poly-92a41434-84db-4bbf-9c2d-1862972e889b"/>
							<gml:surfaceMember xlink:href="#poly-a5d76172-2aba-450e-ab1b-0a94045d839d"/>
							<gml:surfaceMember xlink:href="#poly-717367af-5751-4907-bf03-d3fb4598879c"/>
							<gml:surfaceMember xlink:href="#poly-11b276a8-1f1b-40b0-ba62-7b30478267a0"/>
							<gml:surfaceMember xlink:href="#poly-81e8d1c1-c301-4a48-a249-7a5b19cbed60"/>
							<gml:surfaceMember xlink:href="#poly-d2a64e32-725d-46c4-8083-ac69a10f0bcc"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_f3c20589-6b11-40e6-ac27-ff75190dbd1f_BuildingInstallation_1031">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f8d68576-8a84-45e2-9666-49acd2c20f96">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672696348045804 139.73767118499524 35.444 35.672698381450644 139.73767787679552 35.444 35.67270198563046 139.73767622655492 35.444 35.67270796844533 139.73769602593416 35.444 35.67267323312363 139.7377118860662 35.444 35.67267292582381 139.73771083700808 35.444 35.67269620885038 139.73770020452244 35.444 35.67268848191297 139.73767477347238 35.444 35.672696348045804 139.73767118499524 35.444</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7f07203e-12a2-4a90-9cdd-a3c5a5312957">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67267323312363 139.7377118860662 36.561 35.67270796844533 139.73769602593416 36.561 35.67270903486293 139.73769954852102 36.561 35.67267427249961 139.737715408684 36.561 35.67267323312363 139.7377118860662 36.561</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b09154c6-4a1f-4b28-9805-af3c580ad9e5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b09154c6-4a1f-4b28-9805-af3c580ad9e5_0">
											<gml:posList>35.67268848191297 139.73767477347238 35.444 35.67268848191297 139.73767477347238 37.036 35.672696348045804 139.73767118499524 37.036 35.672696348045804 139.73767118499524 35.444 35.67268848191297 139.73767477347238 35.444</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-af3fba02-c64d-4080-8156-f5fd287ab590">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-af3fba02-c64d-4080-8156-f5fd287ab590_0">
											<gml:posList>35.672696348045804 139.73767118499524 35.444 35.672696348045804 139.73767118499524 37.036 35.672698381450644 139.73767787679552 37.036 35.672698381450644 139.73767787679552 35.444 35.672696348045804 139.73767118499524 35.444</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6dc189e6-9dc4-450e-b476-84bbb6d4c404">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6dc189e6-9dc4-450e-b476-84bbb6d4c404_0">
											<gml:posList>35.672698381450644 139.73767787679552 35.444 35.672698381450644 139.73767787679552 37.036 35.67270198563046 139.73767622655492 37.036 35.67270198563046 139.73767622655492 35.444 35.672698381450644 139.73767787679552 35.444</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2c3dd8af-922c-4651-9296-078913cf73af">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2c3dd8af-922c-4651-9296-078913cf73af_0">
											<gml:posList>35.67269620885038 139.73770020452244 35.444 35.67269620885038 139.73770020452244 37.036 35.67268848191297 139.73767477347238 37.036 35.67268848191297 139.73767477347238 35.444 35.67269620885038 139.73770020452244 35.444</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-65a07579-7193-4586-9c03-d7d9b7f1d681">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-65a07579-7193-4586-9c03-d7d9b7f1d681_0">
											<gml:posList>35.67270796844533 139.73769602593416 36.561 35.67270796844533 139.73769602593416 35.444 35.67270198563046 139.73767622655492 35.444 35.67270198563046 139.73767622655492 37.036 35.67270903486293 139.73769954852102 37.036 35.67270903486293 139.73769954852102 36.561 35.67270796844533 139.73769602593416 36.561</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ad65484b-20ce-48ba-8fdb-76b45d485daf">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ad65484b-20ce-48ba-8fdb-76b45d485daf_0">
											<gml:posList>35.67269620885038 139.73770020452244 37.036 35.67267292582381 139.73771083700808 37.036 35.67267427249961 139.737715408684 37.036 35.67270903486293 139.73769954852102 37.036 35.67270198563046 139.73767622655492 37.036 35.672698381450644 139.73767787679552 37.036 35.672696348045804 139.73767118499524 37.036 35.67268848191297 139.73767477347238 37.036 35.67269620885038 139.73770020452244 37.036</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0aa36b7c-2321-4ba0-bbfc-178eeadafafa">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0aa36b7c-2321-4ba0-bbfc-178eeadafafa_0">
											<gml:posList>35.67270796844533 139.73769602593416 36.561 35.67267323312363 139.7377118860662 36.561 35.67267323312363 139.7377118860662 35.444 35.67270796844533 139.73769602593416 35.444 35.67270796844533 139.73769602593416 36.561</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-370e6d33-447f-4d2e-bf15-974fcf204c92">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-370e6d33-447f-4d2e-bf15-974fcf204c92_0">
											<gml:posList>35.67267292582381 139.73771083700808 35.444 35.67267292582381 139.73771083700808 37.036 35.67269620885038 139.73770020452244 37.036 35.67269620885038 139.73770020452244 35.444 35.67267292582381 139.73771083700808 35.444</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1ac43222-b8b9-469f-950d-3038d9c92e54">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1ac43222-b8b9-469f-950d-3038d9c92e54_0">
											<gml:posList>35.67270903486293 139.73769954852102 36.561 35.67270903486293 139.73769954852102 37.036 35.67267427249961 139.737715408684 37.036 35.67267427249961 139.737715408684 36.561 35.67270903486293 139.73769954852102 36.561</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d4fee845-a27d-4f32-9182-681482c76f62">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d4fee845-a27d-4f32-9182-681482c76f62_0">
											<gml:posList>35.67267427249961 139.737715408684 37.036 35.67267292582381 139.73771083700808 37.036 35.67267292582381 139.73771083700808 35.444 35.67267323312363 139.7377118860662 35.444 35.67267323312363 139.7377118860662 36.561 35.67267427249961 139.737715408684 36.561 35.67267427249961 139.737715408684 37.036</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_f3c20589-6b11-40e6-ac27-ff75190dbd1f_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-959111c4-e166-4bf3-bb02-98ea1f242cd3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67268499391998 139.73756178220103 35.444 35.67267949926506 139.73754379389268 35.444 35.672697457076325 139.7375355648286 35.444 35.67270295174124 139.73755356418692 35.444 35.67268499391998 139.73756178220103 35.444</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b24ae96a-34e2-4307-9c0c-d4edff7bb126">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67268759666234 139.73757031809586 35.444 35.67270555447539 139.73756208903686 35.444 35.672710579210715 139.73757856453204 35.444 35.67269262139654 139.7375867935879 35.444 35.67268759666234 139.73757031809586 35.444</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-92ef097c-59ae-4a4b-bb19-b57e3afa0493">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67261506629059 139.73758553852934 35.444 35.672597072482255 139.7375938449427 35.444 35.67259379193824 139.73758307846026 35.444 35.6726117948035 139.73757482726683 35.444 35.67261506629059 139.73758553852934 35.444</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2329c4f9-c143-4d21-9990-3e716e42570c">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67262566531236 139.73760680156195 35.444 35.672615398973164 139.73757316597684 35.444 35.672621706292006 139.73757028633537 35.444 35.6726319636095 139.737603910887 35.444 35.67262566531236 139.73760680156195 35.444</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-40901821-a977-4eff-b256-9917a9640e65">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672592999012096 139.73758343289734 36.561 35.67259379193824 139.73758307846026 36.561 35.672597072482255 139.7375938449427 36.561 35.67259627956486 139.7375942104262 36.561 35.672592999012096 139.73758343289734 36.561</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9cc2bfb8-fea0-4c3f-82f7-5c6628cf5cc0">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67273394055272 139.73765512259263 35.444 35.672754205365436 139.73764623904574 35.444 35.67275659147411 139.73765439962528 35.444 35.67273632666957 139.73766329421696 35.444 35.67273394055272 139.73765512259263 35.444</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-322d4574-78b1-48f6-96c7-bba78d9e9958">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67273882016064 139.73767047152108 35.444 35.672758507929736 139.737661378781 35.444 35.672760975046764 139.73766939565914 35.444 35.67274128728583 139.73767849944412 35.444 35.67273882016064 139.73767047152108 35.444</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c6080874-1b14-47d4-8a05-516c12e06827">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c6080874-1b14-47d4-8a05-516c12e06827_0">
											<gml:posList>35.67261506629059 139.73758553852934 35.444 35.6726117948035 139.73757482726683 35.444 35.6726117948035 139.73757482726683 37.215 35.67261506629059 139.73758553852934 37.215 35.67261506629059 139.73758553852934 35.444</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7df7feb1-dfc6-4eb5-a314-b258dccc56c0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7df7feb1-dfc6-4eb5-a314-b258dccc56c0_0">
											<gml:posList>35.672697457076325 139.7375355648286 35.444 35.67267949926506 139.73754379389268 35.444 35.67267949926506 139.73754379389268 38.221 35.672697457076325 139.7375355648286 38.221 35.672697457076325 139.7375355648286 35.444</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-34809a80-da3d-43ff-8bf1-368c14ff46bd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-34809a80-da3d-43ff-8bf1-368c14ff46bd_0">
											<gml:posList>35.67270295174124 139.73755356418692 35.444 35.672697457076325 139.7375355648286 35.444 35.672697457076325 139.7375355648286 38.221 35.67270295174124 139.73755356418692 38.221 35.67270295174124 139.73755356418692 35.444</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-97e6d316-8271-430c-a88a-dd9ce8dc42a2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-97e6d316-8271-430c-a88a-dd9ce8dc42a2_0">
											<gml:posList>35.67268499391998 139.73756178220103 38.221 35.67270295174124 139.73755356418692 38.221 35.672697457076325 139.7375355648286 38.221 35.67267949926506 139.73754379389268 38.221 35.67268499391998 139.73756178220103 38.221</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ae814c27-4a89-479e-ad16-8f768808e7f6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ae814c27-4a89-479e-ad16-8f768808e7f6_0">
											<gml:posList>35.67267949926506 139.73754379389268 35.444 35.67268499391998 139.73756178220103 35.444 35.67268499391998 139.73756178220103 38.221 35.67267949926506 139.73754379389268 38.221 35.67267949926506 139.73754379389268 35.444</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-247078c6-30ca-4b41-914f-4dd57e355995">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-247078c6-30ca-4b41-914f-4dd57e355995_0">
											<gml:posList>35.67270295174124 139.73755356418692 35.444 35.67270295174124 139.73755356418692 38.221 35.67268499391998 139.73756178220103 38.221 35.67268499391998 139.73756178220103 35.444 35.67270295174124 139.73755356418692 35.444</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f6b7d330-c6a7-4d0b-b2ea-84f32b7d6b1b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f6b7d330-c6a7-4d0b-b2ea-84f32b7d6b1b_0">
											<gml:posList>35.67268759666234 139.73757031809586 35.444 35.67268759666234 139.73757031809586 38.221 35.67270555447539 139.73756208903686 38.221 35.67270555447539 139.73756208903686 35.444 35.67268759666234 139.73757031809586 35.444</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-20e8d948-9d61-4ef3-bf9a-faf171bd5bab">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-20e8d948-9d61-4ef3-bf9a-faf171bd5bab_0">
											<gml:posList>35.672710579210715 139.73757856453204 35.444 35.67270555447539 139.73756208903686 35.444 35.67270555447539 139.73756208903686 38.221 35.672710579210715 139.73757856453204 38.221 35.672710579210715 139.73757856453204 35.444</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0ad8a15c-939e-4e5c-9eac-c1b404a730fe">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0ad8a15c-939e-4e5c-9eac-c1b404a730fe_0">
											<gml:posList>35.672615398973164 139.73757316597684 35.444 35.672615398973164 139.73757316597684 37.485 35.672621706292006 139.73757028633537 37.485 35.672621706292006 139.73757028633537 35.444 35.672615398973164 139.73757316597684 35.444</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9e25ba60-bdd5-4fc7-8184-448538b8f1ce">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9e25ba60-bdd5-4fc7-8184-448538b8f1ce_0">
											<gml:posList>35.672710579210715 139.73757856453204 38.221 35.67270555447539 139.73756208903686 38.221 35.67268759666234 139.73757031809586 38.221 35.67269262139654 139.7375867935879 38.221 35.672710579210715 139.73757856453204 38.221</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bbf1e936-4121-4029-9a16-379363ba08c7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bbf1e936-4121-4029-9a16-379363ba08c7_0">
											<gml:posList>35.67269262139654 139.7375867935879 38.221 35.67268759666234 139.73757031809586 38.221 35.67268759666234 139.73757031809586 35.444 35.67269262139654 139.7375867935879 35.444 35.67269262139654 139.7375867935879 38.221</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c7509891-025f-4baf-9fa0-119ba76bac87">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c7509891-025f-4baf-9fa0-119ba76bac87_0">
											<gml:posList>35.67259379193824 139.73758307846026 36.561 35.672592999012096 139.73758343289734 36.561 35.672592999012096 139.73758343289734 37.215 35.6726117948035 139.73757482726683 37.215 35.6726117948035 139.73757482726683 35.444 35.67259379193824 139.73758307846026 35.444 35.67259379193824 139.73758307846026 36.561</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1eb0073b-e78d-4ada-8307-8a213ca7e3d8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1eb0073b-e78d-4ada-8307-8a213ca7e3d8_0">
											<gml:posList>35.67269262139654 139.7375867935879 35.444 35.672710579210715 139.73757856453204 35.444 35.672710579210715 139.73757856453204 38.221 35.67269262139654 139.7375867935879 38.221 35.67269262139654 139.7375867935879 35.444</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-aee5c134-6d45-4e7c-86a7-f9c7dffaaa33">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-aee5c134-6d45-4e7c-86a7-f9c7dffaaa33_0">
											<gml:posList>35.67261506629059 139.73758553852934 37.215 35.6726117948035 139.73757482726683 37.215 35.672592999012096 139.73758343289734 37.215 35.67259627956486 139.7375942104262 37.215 35.67261506629059 139.73758553852934 37.215</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f48dbdfc-d419-4e1f-bd68-a10818638820">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f48dbdfc-d419-4e1f-bd68-a10818638820_0">
											<gml:posList>35.6726319636095 139.737603910887 35.444 35.672621706292006 139.73757028633537 35.444 35.672621706292006 139.73757028633537 37.485 35.6726319636095 139.737603910887 37.485 35.6726319636095 139.737603910887 35.444</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ba8de741-d262-4956-bfa2-78d2214b0ccc">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ba8de741-d262-4956-bfa2-78d2214b0ccc_0">
											<gml:posList>35.67259379193824 139.73758307846026 35.444 35.672597072482255 139.7375938449427 35.444 35.672597072482255 139.7375938449427 36.561 35.67259379193824 139.73758307846026 36.561 35.67259379193824 139.73758307846026 35.444</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-36c92009-e465-4b03-9106-37000f63a21d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-36c92009-e465-4b03-9106-37000f63a21d_0">
											<gml:posList>35.67262566531236 139.73760680156195 37.485 35.6726319636095 139.737603910887 37.485 35.672621706292006 139.73757028633537 37.485 35.672615398973164 139.73757316597684 37.485 35.67262566531236 139.73760680156195 37.485</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7976cb5e-8823-46d6-9b71-5fa3715aa5d1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7976cb5e-8823-46d6-9b71-5fa3715aa5d1_0">
											<gml:posList>35.672592999012096 139.73758343289734 36.561 35.67259627956486 139.7375942104262 36.561 35.67259627956486 139.7375942104262 37.215 35.672592999012096 139.73758343289734 37.215 35.672592999012096 139.73758343289734 36.561</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7e0122b5-1d63-430a-8829-6610e71c8de0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7e0122b5-1d63-430a-8829-6610e71c8de0_0">
											<gml:posList>35.672597072482255 139.7375938449427 36.561 35.672597072482255 139.7375938449427 35.444 35.67261506629059 139.73758553852934 35.444 35.67261506629059 139.73758553852934 37.215 35.67259627956486 139.7375942104262 37.215 35.67259627956486 139.7375942104262 36.561 35.672597072482255 139.7375938449427 36.561</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4cc4ec70-1e93-4584-8a66-0d5f86262388">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4cc4ec70-1e93-4584-8a66-0d5f86262388_0">
											<gml:posList>35.672615398973164 139.73757316597684 35.444 35.67262566531236 139.73760680156195 35.444 35.67262566531236 139.73760680156195 37.485 35.672615398973164 139.73757316597684 37.485 35.672615398973164 139.73757316597684 35.444</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1fc43b4f-a4f3-4ec7-8d32-3090adc9299c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1fc43b4f-a4f3-4ec7-8d32-3090adc9299c_0">
											<gml:posList>35.67262566531236 139.73760680156195 35.444 35.6726319636095 139.737603910887 35.444 35.6726319636095 139.737603910887 37.485 35.67262566531236 139.73760680156195 37.485 35.67262566531236 139.73760680156195 35.444</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-14a1a2b2-b1e9-47ba-80ce-3ea013a9a1a2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-14a1a2b2-b1e9-47ba-80ce-3ea013a9a1a2_0">
											<gml:posList>35.67275659147411 139.73765439962528 35.444 35.672754205365436 139.73764623904574 35.444 35.672754205365436 139.73764623904574 37.413 35.67275659147411 139.73765439962528 37.413 35.67275659147411 139.73765439962528 35.444</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-345d0871-dec3-45da-bcbc-3907cfd275f4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-345d0871-dec3-45da-bcbc-3907cfd275f4_0">
											<gml:posList>35.672754205365436 139.73764623904574 35.444 35.67273394055272 139.73765512259263 35.444 35.67273394055272 139.73765512259263 37.413 35.672754205365436 139.73764623904574 37.413 35.672754205365436 139.73764623904574 35.444</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7dd5806b-f5a8-46ff-b7e2-6709c077c84f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7dd5806b-f5a8-46ff-b7e2-6709c077c84f_0">
											<gml:posList>35.67275659147411 139.73765439962528 37.413 35.672754205365436 139.73764623904574 37.413 35.67273394055272 139.73765512259263 37.413 35.67273632666957 139.73766329421696 37.413 35.67275659147411 139.73765439962528 37.413</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a2069ead-9749-448b-8b4c-4f0f1ed94ff0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a2069ead-9749-448b-8b4c-4f0f1ed94ff0_0">
											<gml:posList>35.67275659147411 139.73765439962528 35.444 35.67275659147411 139.73765439962528 37.413 35.67273632666957 139.73766329421696 37.413 35.67273632666957 139.73766329421696 35.444 35.67275659147411 139.73765439962528 35.444</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ef07d1b0-00d7-43f7-94e4-a08eb52787c4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ef07d1b0-00d7-43f7-94e4-a08eb52787c4_0">
											<gml:posList>35.67273394055272 139.73765512259263 35.444 35.67273632666957 139.73766329421696 35.444 35.67273632666957 139.73766329421696 37.413 35.67273394055272 139.73765512259263 37.413 35.67273394055272 139.73765512259263 35.444</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-47ec9294-7d06-41e0-9d62-a65130b22bc4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-47ec9294-7d06-41e0-9d62-a65130b22bc4_0">
											<gml:posList>35.672760975046764 139.73766939565914 35.444 35.672758507929736 139.737661378781 35.444 35.672758507929736 139.737661378781 37.413 35.672760975046764 139.73766939565914 37.413 35.672760975046764 139.73766939565914 35.444</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-de4254e0-0379-478f-9d5a-716fd28ecd7c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-de4254e0-0379-478f-9d5a-716fd28ecd7c_0">
											<gml:posList>35.672758507929736 139.737661378781 35.444 35.67273882016064 139.73767047152108 35.444 35.67273882016064 139.73767047152108 37.413 35.672758507929736 139.737661378781 37.413 35.672758507929736 139.737661378781 35.444</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c4c3f00b-b838-4fc4-9e5a-6ba96d999c0a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c4c3f00b-b838-4fc4-9e5a-6ba96d999c0a_0">
											<gml:posList>35.672760975046764 139.73766939565914 37.413 35.672758507929736 139.737661378781 37.413 35.67273882016064 139.73767047152108 37.413 35.67274128728583 139.73767849944412 37.413 35.672760975046764 139.73766939565914 37.413</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8790c10c-7777-435e-94ca-f8692d92560c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8790c10c-7777-435e-94ca-f8692d92560c_0">
											<gml:posList>35.67274128728583 139.73767849944412 35.444 35.672760975046764 139.73766939565914 35.444 35.672760975046764 139.73766939565914 37.413 35.67274128728583 139.73767849944412 37.413 35.67274128728583 139.73767849944412 35.444</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9af4ffdf-f8d3-4458-bb44-7487a283a950">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9af4ffdf-f8d3-4458-bb44-7487a283a950_0">
											<gml:posList>35.67274128728583 139.73767849944412 35.444 35.67274128728583 139.73767849944412 37.413 35.67273882016064 139.73767047152108 37.413 35.67273882016064 139.73767047152108 35.444 35.67274128728583 139.73767849944412 35.444</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-2d1ac242-e86b-44d5-aed1-bfcd67306038">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2d1ac242-e86b-44d5-aed1-bfcd67306038">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2d1ac242-e86b-44d5-aed1-bfcd67306038">
											<gml:posList>35.672635708484755 139.73773396872963 9.126 35.67258835301158 139.73757848958576 9.126 35.67270891289325 139.73752344408805 9.126 35.67271288930054 139.737536474301 9.126 35.67280299378376 139.737495273308 9.126 35.67281329632241 139.73752906357083 9.126 35.67274256420579 139.7375612936575 9.126 35.67274690212406 139.73757553857035 9.126 35.6728056503051 139.73754873564403 9.126 35.672834389112595 139.73764326018076 9.126 35.672635708484755 139.73773396872963 9.126</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-7602fcf7-b88b-4618-82ac-aa698cbfddcb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7602fcf7-b88b-4618-82ac-aa698cbfddcb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7602fcf7-b88b-4618-82ac-aa698cbfddcb">
											<gml:posList>35.67280148294319 139.73749962747166 39.678 35.67276043133456 139.73751838946225 39.678 35.672765995286376 139.7375215089969 39.678 35.67279893748534 139.73750644626193 39.678 35.67280148294319 139.73749962747166 39.678</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a6d79f27-b0bf-497b-b2b7-b352d4b00b71">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a6d79f27-b0bf-497b-b2b7-b352d4b00b71">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a6d79f27-b0bf-497b-b2b7-b352d4b00b71">
											<gml:posList>35.67280148294319 139.73749962747166 36.561 35.672810249158275 139.7375284044166 36.561 35.67281329632241 139.73752906357083 36.561 35.67280299378376 139.737495273308 36.561 35.67280148294319 139.73749962747166 36.561</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ac2f89f2-5ca7-4675-8298-2ce4f4db6d9f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ac2f89f2-5ca7-4675-8298-2ce4f4db6d9f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ac2f89f2-5ca7-4675-8298-2ce4f4db6d9f">
											<gml:posList>35.67279893748534 139.73750644626193 39.678 35.67280468521547 139.7375252959263 39.678 35.672810249158275 139.7375284044166 39.678 35.67280148294319 139.73749962747166 39.678 35.67279893748534 139.73750644626193 39.678</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-231acbe3-f9f9-4e59-824e-d8828fd7451e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-231acbe3-f9f9-4e59-824e-d8828fd7451e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-231acbe3-f9f9-4e59-824e-d8828fd7451e">
											<gml:posList>35.67280299378376 139.737495273308 36.561 35.67271288930054 139.737536474301 36.561 35.67271066764896 139.73754243106245 36.561 35.67276077476125 139.7375195268503 36.561 35.67276043133456 139.73751838946225 36.561 35.67280148294319 139.73749962747166 36.561 35.67280299378376 139.737495273308 36.561</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c73c4572-213f-4175-ae2f-e32ceb509fb6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c73c4572-213f-4175-ae2f-e32ceb509fb6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c73c4572-213f-4175-ae2f-e32ceb509fb6">
											<gml:posList>35.672765995286376 139.7375215089969 38.542 35.672771743031745 139.73754038074776 38.542 35.67280468521547 139.7375252959263 38.542 35.67279893748534 139.73750644626193 38.542 35.672765995286376 139.7375215089969 38.542</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b4f00717-85ed-4cab-98f9-e4ee8b280dc2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b4f00717-85ed-4cab-98f9-e4ee8b280dc2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b4f00717-85ed-4cab-98f9-e4ee8b280dc2">
											<gml:posList>35.67276043133456 139.73751838946225 39.678 35.672769197562786 139.73754718848767 39.678 35.672771743031745 139.73754038074776 39.678 35.672765995286376 139.7375215089969 39.678 35.67276043133456 139.73751838946225 39.678</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-813d669c-89c8-405a-9e4e-75a23742228c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-813d669c-89c8-405a-9e4e-75a23742228c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-813d669c-89c8-405a-9e4e-75a23742228c">
											<gml:posList>35.67271288930054 139.737536474301 36.561 35.67270891289325 139.73752344408805 36.561 35.67270669124231 139.73752940084955 36.561 35.67271066764896 139.73754243106245 36.561 35.67271288930054 139.737536474301 36.561</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e0f5f8e3-3d95-42ac-85e3-aa6aa6cf3479">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e0f5f8e3-3d95-42ac-85e3-aa6aa6cf3479">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e0f5f8e3-3d95-42ac-85e3-aa6aa6cf3479">
											<gml:posList>35.672771743031745 139.73754038074776 39.678 35.672769197562786 139.73754718848767 39.678 35.672810249158275 139.7375284044166 39.678 35.67280468521547 139.7375252959263 39.678 35.672771743031745 139.73754038074776 39.678</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-fa65a21a-87e5-4b68-bc3e-7b5baab5ea4c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fa65a21a-87e5-4b68-bc3e-7b5baab5ea4c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fa65a21a-87e5-4b68-bc3e-7b5baab5ea4c">
											<gml:posList>35.672710402307914 139.73754880525624 39.624 35.67272951375234 139.73754042015946 39.624 35.672730872029135 139.73753690572315 39.624 35.672707525604814 139.73754714065967 39.624 35.672710402307914 139.73754880525624 39.624</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-0d5bda93-ad0c-4f82-8269-61bb1eb2c5b1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0d5bda93-ad0c-4f82-8269-61bb1eb2c5b1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0d5bda93-ad0c-4f82-8269-61bb1eb2c5b1">
											<gml:posList>35.67274256420579 139.7375612936575 36.561 35.67281329632241 139.73752906357083 36.561 35.672810249158275 139.7375284044166 36.561 35.672769197562786 139.73754718848767 36.561 35.67276840228167 139.73754458244304 36.561 35.672737694627614 139.7375585709685 36.561 35.67274256420579 139.7375612936575 36.561</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-44760d0b-0075-4341-8450-3ebc7349da66">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-44760d0b-0075-4341-8450-3ebc7349da66">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-44760d0b-0075-4341-8450-3ebc7349da66">
											<gml:posList>35.67270891289325 139.73752344408805 36.561 35.67258835301158 139.73757848958576 36.561 35.67259322258942 139.73758121227095 36.561 35.67270669124231 139.73752940084955 36.561 35.67270891289325 139.73752344408805 36.561</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-3aa8ea07-b432-47d4-9293-6515dd1ad69d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3aa8ea07-b432-47d4-9293-6515dd1ad69d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3aa8ea07-b432-47d4-9293-6515dd1ad69d">
											<gml:posList>35.67272951375234 139.73754042015946 39.624 35.672741561855766 139.73758166475673 39.624 35.67274442953587 139.73758331831945 39.624 35.672730872029135 139.73753690572315 39.624 35.67272951375234 139.73754042015946 39.624</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a2999732-7fb7-4c17-a02e-fd6026791d58">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a2999732-7fb7-4c17-a02e-fd6026791d58">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a2999732-7fb7-4c17-a02e-fd6026791d58">
											<gml:posList>35.672744671456854 139.737581495344 36.561 35.672803419639244 139.73755469242278 36.561 35.6728056503051 139.73754873564403 36.561 35.67274690212406 139.73757553857035 36.561 35.672744671456854 139.737581495344 36.561</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e549ead8-a2bd-454d-8e69-28c392069239">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e549ead8-a2bd-454d-8e69-28c392069239">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e549ead8-a2bd-454d-8e69-28c392069239">
											<gml:posList>35.672722459422204 139.7375900498342 38.977 35.672741561855766 139.73758166475673 38.977 35.67272951375234 139.73754042015946 38.977 35.672710402307914 139.73754880525624 38.977 35.672722459422204 139.7375900498342 38.977</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-11fd2a99-4baa-4ce9-b0a0-2aa408e81b2e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-11fd2a99-4baa-4ce9-b0a0-2aa408e81b2e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-11fd2a99-4baa-4ce9-b0a0-2aa408e81b2e">
											<gml:posList>35.672737694627614 139.7375585709685 36.561 35.672744671456854 139.737581495344 36.561 35.67274690212406 139.73757553857035 36.561 35.67274256420579 139.7375612936575 36.561 35.672737694627614 139.7375585709685 36.561</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ab54fa19-c601-4eed-8b01-1b51476ad948">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ab54fa19-c601-4eed-8b01-1b51476ad948">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ab54fa19-c601-4eed-8b01-1b51476ad948">
											<gml:posList>35.672707525604814 139.73754714065967 39.624 35.67272109212136 139.73759355323347 39.624 35.672722459422204 139.7375900498342 39.624 35.672710402307914 139.73754880525624 39.624 35.672707525604814 139.73754714065967 39.624</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-488f0c5c-5f52-4ac3-8f49-3abb4cadea11">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-488f0c5c-5f52-4ac3-8f49-3abb4cadea11">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-488f0c5c-5f52-4ac3-8f49-3abb4cadea11">
											<gml:posList>35.67276077476125 139.7375195268503 35.444 35.67271066764896 139.73754243106245 35.444 35.672707525604814 139.73754714065967 35.444 35.672730872029135 139.73753690572315 35.444 35.67274442953587 139.73758331831945 35.444 35.672829528541286 139.7376405264263 35.444 35.672803419639244 139.73755469242278 35.444 35.672744671456854 139.737581495344 35.444 35.672737694627614 139.7375585709685 35.444 35.67276840228167 139.73754458244304 35.444 35.67276077476125 139.7375195268503 35.444</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b0b5b80f-ed74-4eae-86eb-fc7c98f908f3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b0b5b80f-ed74-4eae-86eb-fc7c98f908f3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b0b5b80f-ed74-4eae-86eb-fc7c98f908f3">
											<gml:posList>35.67274442953587 139.73758331831945 39.624 35.672741561855766 139.73758166475673 39.624 35.672722459422204 139.7375900498342 39.624 35.67272109212136 139.73759355323347 39.624 35.67274442953587 139.73758331831945 39.624</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f0518b16-ca61-4813-b64b-97c3ecfa9c48">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f0518b16-ca61-4813-b64b-97c3ecfa9c48">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f0518b16-ca61-4813-b64b-97c3ecfa9c48">
											<gml:posList>35.672803419639244 139.73755469242278 36.561 35.672829528541286 139.7376405264263 36.561 35.672834389112595 139.73764326018076 36.561 35.6728056503051 139.73754873564403 36.561 35.672803419639244 139.73755469242278 36.561</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c8ac2a69-b98e-408b-b50b-50e0ad7428ab">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c8ac2a69-b98e-408b-b50b-50e0ad7428ab">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c8ac2a69-b98e-408b-b50b-50e0ad7428ab">
											<gml:posList>35.67259322258942 139.73758121227095 35.444 35.672637939150796 139.73772800092175 35.444 35.67272109212136 139.73759355323347 35.444 35.672707525604814 139.73754714065967 35.444 35.67271066764896 139.73754243106245 35.444 35.67270669124231 139.73752940084955 35.444 35.67259322258942 139.73758121227095 35.444</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c73b88f6-0e8a-452c-a9c6-2fdaf3be78b6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c73b88f6-0e8a-452c-a9c6-2fdaf3be78b6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c73b88f6-0e8a-452c-a9c6-2fdaf3be78b6">
											<gml:posList>35.672829528541286 139.7376405264263 35.444 35.67274442953587 139.73758331831945 35.444 35.67272109212136 139.73759355323347 35.444 35.672637939150796 139.73772800092175 35.444 35.672829528541286 139.7376405264263 35.444</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-1bf7b3b2-bec8-44b9-9351-12b707c867d7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1bf7b3b2-bec8-44b9-9351-12b707c867d7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1bf7b3b2-bec8-44b9-9351-12b707c867d7">
											<gml:posList>35.67258835301158 139.73757848958576 36.561 35.672635708484755 139.73773396872963 36.561 35.672637939150796 139.73772800092175 36.561 35.67259322258942 139.73758121227095 36.561 35.67258835301158 139.73757848958576 36.561</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-6cc36b4e-dfeb-435f-851a-19fd26596196">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6cc36b4e-dfeb-435f-851a-19fd26596196">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6cc36b4e-dfeb-435f-851a-19fd26596196">
											<gml:posList>35.672637939150796 139.73772800092175 36.561 35.672635708484755 139.73773396872963 36.561 35.672834389112595 139.73764326018076 36.561 35.672829528541286 139.7376405264263 36.561 35.672637939150796 139.73772800092175 36.561</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f41ff702-f74a-4d28-a0b0-eba5c132098a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f41ff702-f74a-4d28-a0b0-eba5c132098a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f41ff702-f74a-4d28-a0b0-eba5c132098a">
											<gml:posList>35.672707525604814 139.73754714065967 39.624 35.672730872029135 139.73753690572315 39.624 35.672730872029135 139.73753690572315 35.444 35.672707525604814 139.73754714065967 35.444 35.672707525604814 139.73754714065967 39.624</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9e54126a-4374-412f-8b31-271906c57472">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9e54126a-4374-412f-8b31-271906c57472">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9e54126a-4374-412f-8b31-271906c57472">
											<gml:posList>35.67270891289325 139.73752344408805 36.561 35.67270891289325 139.73752344408805 9.126 35.67258835301158 139.73757848958576 9.126 35.67258835301158 139.73757848958576 36.561 35.67270891289325 139.73752344408805 36.561</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9446393c-a4ee-4da8-8fc7-9fb2fa53bbb7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9446393c-a4ee-4da8-8fc7-9fb2fa53bbb7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9446393c-a4ee-4da8-8fc7-9fb2fa53bbb7">
											<gml:posList>35.672737694627614 139.7375585709685 36.561 35.67276840228167 139.73754458244304 36.561 35.67276840228167 139.73754458244304 35.444 35.672737694627614 139.7375585709685 35.444 35.672737694627614 139.7375585709685 36.561</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c1f95edf-3980-4e6c-b075-5663c75cbe8f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c1f95edf-3980-4e6c-b075-5663c75cbe8f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c1f95edf-3980-4e6c-b075-5663c75cbe8f">
											<gml:posList>35.672737694627614 139.7375585709685 35.444 35.672744671456854 139.737581495344 35.444 35.672744671456854 139.737581495344 36.561 35.672737694627614 139.7375585709685 36.561 35.672737694627614 139.7375585709685 35.444</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a88f61fa-46f9-45e0-b175-1c2cf53e013d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a88f61fa-46f9-45e0-b175-1c2cf53e013d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a88f61fa-46f9-45e0-b175-1c2cf53e013d">
											<gml:posList>35.67258835301158 139.73757848958576 36.561 35.67258835301158 139.73757848958576 9.126 35.672635708484755 139.73773396872963 9.126 35.672635708484755 139.73773396872963 36.561 35.67258835301158 139.73757848958576 36.561</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9c6517d9-1cb4-4a74-aab1-3c9e1e12fb5a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9c6517d9-1cb4-4a74-aab1-3c9e1e12fb5a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9c6517d9-1cb4-4a74-aab1-3c9e1e12fb5a">
											<gml:posList>35.672637939150796 139.73772800092175 35.444 35.67259322258942 139.73758121227095 35.444 35.67259322258942 139.73758121227095 36.561 35.672637939150796 139.73772800092175 36.561 35.672637939150796 139.73772800092175 35.444</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-756cbe72-005a-4a14-ad57-f3eaf0a1b981">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-756cbe72-005a-4a14-ad57-f3eaf0a1b981">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-756cbe72-005a-4a14-ad57-f3eaf0a1b981">
											<gml:posList>35.67259322258942 139.73758121227095 35.444 35.67270669124231 139.73752940084955 35.444 35.67270669124231 139.73752940084955 36.561 35.67259322258942 139.73758121227095 36.561 35.67259322258942 139.73758121227095 35.444</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e2427310-20a5-4cf4-a718-21ce182c1cfb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e2427310-20a5-4cf4-a718-21ce182c1cfb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e2427310-20a5-4cf4-a718-21ce182c1cfb">
											<gml:posList>35.67270669124231 139.73752940084955 35.444 35.67271066764896 139.73754243106245 35.444 35.67271066764896 139.73754243106245 36.561 35.67270669124231 139.73752940084955 36.561 35.67270669124231 139.73752940084955 35.444</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1df20ec3-cd90-4d5f-be0c-74d2fafe6881">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1df20ec3-cd90-4d5f-be0c-74d2fafe6881">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1df20ec3-cd90-4d5f-be0c-74d2fafe6881">
											<gml:posList>35.67271288930054 139.737536474301 36.561 35.67271288930054 139.737536474301 9.126 35.67270891289325 139.73752344408805 9.126 35.67270891289325 139.73752344408805 36.561 35.67271288930054 139.737536474301 36.561</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7f0352ee-d028-43e6-aab6-694349f9ca93">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7f0352ee-d028-43e6-aab6-694349f9ca93">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7f0352ee-d028-43e6-aab6-694349f9ca93">
											<gml:posList>35.67272109212136 139.73759355323347 35.444 35.67272109212136 139.73759355323347 39.624 35.672707525604814 139.73754714065967 39.624 35.672707525604814 139.73754714065967 35.444 35.67272109212136 139.73759355323347 35.444</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0efca00a-64a0-48c3-a5de-f4c561994205">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0efca00a-64a0-48c3-a5de-f4c561994205">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0efca00a-64a0-48c3-a5de-f4c561994205">
											<gml:posList>35.672710402307914 139.73754880525624 39.624 35.672722459422204 139.7375900498342 39.624 35.672722459422204 139.7375900498342 38.977 35.672710402307914 139.73754880525624 38.977 35.672710402307914 139.73754880525624 39.624</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f179de4a-9eec-4001-a26e-2459753303f4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f179de4a-9eec-4001-a26e-2459753303f4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f179de4a-9eec-4001-a26e-2459753303f4">
											<gml:posList>35.672710402307914 139.73754880525624 38.977 35.67272951375234 139.73754042015946 38.977 35.67272951375234 139.73754042015946 39.624 35.672710402307914 139.73754880525624 39.624 35.672710402307914 139.73754880525624 38.977</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d5bdd545-fd8a-4517-b732-ff34e44dde5a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d5bdd545-fd8a-4517-b732-ff34e44dde5a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d5bdd545-fd8a-4517-b732-ff34e44dde5a">
											<gml:posList>35.672722459422204 139.7375900498342 39.624 35.672741561855766 139.73758166475673 39.624 35.672741561855766 139.73758166475673 38.977 35.672722459422204 139.7375900498342 38.977 35.672722459422204 139.7375900498342 39.624</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8c4076d5-3806-4010-bb11-8088508483e3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8c4076d5-3806-4010-bb11-8088508483e3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8c4076d5-3806-4010-bb11-8088508483e3">
											<gml:posList>35.67274442953587 139.73758331831945 35.444 35.67274442953587 139.73758331831945 39.624 35.67272109212136 139.73759355323347 39.624 35.67272109212136 139.73759355323347 35.444 35.67274442953587 139.73758331831945 35.444</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b95df10b-1297-450c-9889-e443494fdfc8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b95df10b-1297-450c-9889-e443494fdfc8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b95df10b-1297-450c-9889-e443494fdfc8">
											<gml:posList>35.672637939150796 139.73772800092175 36.561 35.672829528541286 139.7376405264263 36.561 35.672829528541286 139.7376405264263 35.444 35.672637939150796 139.73772800092175 35.444 35.672637939150796 139.73772800092175 36.561</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0af1dc29-35d2-4d5e-ba0f-fa7588920d18">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0af1dc29-35d2-4d5e-ba0f-fa7588920d18">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0af1dc29-35d2-4d5e-ba0f-fa7588920d18">
											<gml:posList>35.672635708484755 139.73773396872963 36.561 35.672635708484755 139.73773396872963 9.126 35.672834389112595 139.73764326018076 9.126 35.672834389112595 139.73764326018076 36.561 35.672635708484755 139.73773396872963 36.561</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3fd2a279-e99d-4657-ac02-89977a810ae6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3fd2a279-e99d-4657-ac02-89977a810ae6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3fd2a279-e99d-4657-ac02-89977a810ae6">
											<gml:posList>35.67272951375234 139.73754042015946 38.977 35.672741561855766 139.73758166475673 38.977 35.672741561855766 139.73758166475673 39.624 35.67272951375234 139.73754042015946 39.624 35.67272951375234 139.73754042015946 38.977</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c9a55009-cc16-4b08-a9fe-d136a209c857">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c9a55009-cc16-4b08-a9fe-d136a209c857">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c9a55009-cc16-4b08-a9fe-d136a209c857">
											<gml:posList>35.67271066764896 139.73754243106245 36.561 35.67271066764896 139.73754243106245 35.444 35.67276077476125 139.7375195268503 35.444 35.67276077476125 139.7375195268503 36.561 35.67271066764896 139.73754243106245 36.561</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2dde5c91-d1c5-4305-81ef-4b21eff1d6c2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2dde5c91-d1c5-4305-81ef-4b21eff1d6c2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2dde5c91-d1c5-4305-81ef-4b21eff1d6c2">
											<gml:posList>35.672730872029135 139.73753690572315 39.624 35.67274442953587 139.73758331831945 39.624 35.67274442953587 139.73758331831945 35.444 35.672730872029135 139.73753690572315 35.444 35.672730872029135 139.73753690572315 39.624</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0fa3ad9b-9630-4b8a-a4de-4578854a6e7b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0fa3ad9b-9630-4b8a-a4de-4578854a6e7b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0fa3ad9b-9630-4b8a-a4de-4578854a6e7b">
											<gml:posList>35.67274690212406 139.73757553857035 36.561 35.67274690212406 139.73757553857035 9.126 35.67274256420579 139.7375612936575 9.126 35.67274256420579 139.7375612936575 36.561 35.67274690212406 139.73757553857035 36.561</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-846e7c27-e7c6-4061-b0bd-d358624166b3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-846e7c27-e7c6-4061-b0bd-d358624166b3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-846e7c27-e7c6-4061-b0bd-d358624166b3">
											<gml:posList>35.67280299378376 139.737495273308 36.561 35.67280299378376 139.737495273308 9.126 35.67271288930054 139.737536474301 9.126 35.67271288930054 139.737536474301 36.561 35.67280299378376 139.737495273308 36.561</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8ad3bf47-2f84-4d85-a2c9-69b06963ee0b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8ad3bf47-2f84-4d85-a2c9-69b06963ee0b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8ad3bf47-2f84-4d85-a2c9-69b06963ee0b">
											<gml:posList>35.67276840228167 139.73754458244304 36.561 35.672769197562786 139.73754718848767 36.561 35.672769197562786 139.73754718848767 39.678 35.67276043133456 139.73751838946225 39.678 35.67276043133456 139.73751838946225 36.561 35.67276077476125 139.7375195268503 36.561 35.67276077476125 139.7375195268503 35.444 35.67276840228167 139.73754458244304 35.444 35.67276840228167 139.73754458244304 36.561</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-70f7ae78-5703-49f8-ad0b-85de79ae8c9d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-70f7ae78-5703-49f8-ad0b-85de79ae8c9d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-70f7ae78-5703-49f8-ad0b-85de79ae8c9d">
											<gml:posList>35.672771743031745 139.73754038074776 38.542 35.672765995286376 139.7375215089969 38.542 35.672765995286376 139.7375215089969 39.678 35.672771743031745 139.73754038074776 39.678 35.672771743031745 139.73754038074776 38.542</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-51763f51-c10d-4d1f-a090-4e43ee5af930">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-51763f51-c10d-4d1f-a090-4e43ee5af930">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-51763f51-c10d-4d1f-a090-4e43ee5af930">
											<gml:posList>35.672744671456854 139.737581495344 35.444 35.672803419639244 139.73755469242278 35.444 35.672803419639244 139.73755469242278 36.561 35.672744671456854 139.737581495344 36.561 35.672744671456854 139.737581495344 35.444</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-818f1ab0-29ae-4a5e-b9a4-6d5df745d053">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-818f1ab0-29ae-4a5e-b9a4-6d5df745d053">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-818f1ab0-29ae-4a5e-b9a4-6d5df745d053">
											<gml:posList>35.6728056503051 139.73754873564403 36.561 35.6728056503051 139.73754873564403 9.126 35.67274690212406 139.73757553857035 9.126 35.67274690212406 139.73757553857035 36.561 35.6728056503051 139.73754873564403 36.561</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-50fe46bd-aadf-4e12-a91f-d50e6c5c34b6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-50fe46bd-aadf-4e12-a91f-d50e6c5c34b6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-50fe46bd-aadf-4e12-a91f-d50e6c5c34b6">
											<gml:posList>35.67274256420579 139.7375612936575 36.561 35.67274256420579 139.7375612936575 9.126 35.67281329632241 139.73752906357083 9.126 35.67281329632241 139.73752906357083 36.561 35.67274256420579 139.7375612936575 36.561</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b2c7ae7f-3c2d-4597-bf9b-8ab30c245c7d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b2c7ae7f-3c2d-4597-bf9b-8ab30c245c7d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b2c7ae7f-3c2d-4597-bf9b-8ab30c245c7d">
											<gml:posList>35.67276043133456 139.73751838946225 39.678 35.67280148294319 139.73749962747166 39.678 35.67280148294319 139.73749962747166 36.561 35.67276043133456 139.73751838946225 36.561 35.67276043133456 139.73751838946225 39.678</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-34896f07-2809-45e0-8013-fb5b79f7ed46">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-34896f07-2809-45e0-8013-fb5b79f7ed46">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-34896f07-2809-45e0-8013-fb5b79f7ed46">
											<gml:posList>35.672765995286376 139.7375215089969 38.542 35.67279893748534 139.73750644626193 38.542 35.67279893748534 139.73750644626193 39.678 35.672765995286376 139.7375215089969 39.678 35.672765995286376 139.7375215089969 38.542</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-46ef1ffc-5e25-4d31-8d2c-787b34b92244">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-46ef1ffc-5e25-4d31-8d2c-787b34b92244">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-46ef1ffc-5e25-4d31-8d2c-787b34b92244">
											<gml:posList>35.67280468521547 139.7375252959263 38.542 35.672771743031745 139.73754038074776 38.542 35.672771743031745 139.73754038074776 39.678 35.67280468521547 139.7375252959263 39.678 35.67280468521547 139.7375252959263 38.542</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-92a41434-84db-4bbf-9c2d-1862972e889b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-92a41434-84db-4bbf-9c2d-1862972e889b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-92a41434-84db-4bbf-9c2d-1862972e889b">
											<gml:posList>35.672810249158275 139.7375284044166 36.561 35.672810249158275 139.7375284044166 39.678 35.672769197562786 139.73754718848767 39.678 35.672769197562786 139.73754718848767 36.561 35.672810249158275 139.7375284044166 36.561</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a5d76172-2aba-450e-ab1b-0a94045d839d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a5d76172-2aba-450e-ab1b-0a94045d839d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a5d76172-2aba-450e-ab1b-0a94045d839d">
											<gml:posList>35.67279893748534 139.73750644626193 38.542 35.67280468521547 139.7375252959263 38.542 35.67280468521547 139.7375252959263 39.678 35.67279893748534 139.73750644626193 39.678 35.67279893748534 139.73750644626193 38.542</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-717367af-5751-4907-bf03-d3fb4598879c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-717367af-5751-4907-bf03-d3fb4598879c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-717367af-5751-4907-bf03-d3fb4598879c">
											<gml:posList>35.67280148294319 139.73749962747166 39.678 35.672810249158275 139.7375284044166 39.678 35.672810249158275 139.7375284044166 36.561 35.67280148294319 139.73749962747166 36.561 35.67280148294319 139.73749962747166 39.678</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-11b276a8-1f1b-40b0-ba62-7b30478267a0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-11b276a8-1f1b-40b0-ba62-7b30478267a0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-11b276a8-1f1b-40b0-ba62-7b30478267a0">
											<gml:posList>35.67281329632241 139.73752906357083 36.561 35.67281329632241 139.73752906357083 9.126 35.67280299378376 139.737495273308 9.126 35.67280299378376 139.737495273308 36.561 35.67281329632241 139.73752906357083 36.561</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-81e8d1c1-c301-4a48-a249-7a5b19cbed60">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-81e8d1c1-c301-4a48-a249-7a5b19cbed60">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-81e8d1c1-c301-4a48-a249-7a5b19cbed60">
											<gml:posList>35.672829528541286 139.7376405264263 36.561 35.672803419639244 139.73755469242278 36.561 35.672803419639244 139.73755469242278 35.444 35.672829528541286 139.7376405264263 35.444 35.672829528541286 139.7376405264263 36.561</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d2a64e32-725d-46c4-8083-ac69a10f0bcc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d2a64e32-725d-46c4-8083-ac69a10f0bcc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d2a64e32-725d-46c4-8083-ac69a10f0bcc">
											<gml:posList>35.672834389112595 139.73764326018076 36.561 35.672834389112595 139.73764326018076 9.126 35.6728056503051 139.73754873564403 9.126 35.6728056503051 139.73754873564403 36.561 35.672834389112595 139.73764326018076 36.561</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-11509</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">336.8708</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1221</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>6</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.05</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>