<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_f3f85971-c586-4799-8201-0cb498da19e9">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>18</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103018002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">402</bldg:usage>
			<bldg:measuredHeight uom="m">9.5</bldg:measuredHeight>
			<bldg:storeysAboveGround>3</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.668858357030096 139.74797363208168 0 35.668933107911805 139.7480117718741 0 35.66894534098108 139.74797563823253 0 35.66887059008812 139.747937498468 0 35.668858357030096 139.74797363208168 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668858357030096 139.74797363208168 5.81 35.66887059008812 139.747937498468 5.81 35.66894534098108 139.74797563823253 5.81 35.668933107911805 139.7480117718741 5.81 35.668858357030096 139.74797363208168 5.81</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668858357030096 139.74797363208168 5.81 35.668933107911805 139.7480117718741 5.81 35.668933107911805 139.7480117718741 15.27 35.668858357030096 139.74797363208168 15.27 35.668858357030096 139.74797363208168 5.81</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668933107911805 139.7480117718741 5.81 35.66894534098108 139.74797563823253 5.81 35.66894534098108 139.74797563823253 15.27 35.668933107911805 139.7480117718741 15.27 35.668933107911805 139.7480117718741 5.81</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66894534098108 139.74797563823253 5.81 35.66887059008812 139.747937498468 5.81 35.66887059008812 139.747937498468 15.27 35.66894534098108 139.74797563823253 15.27 35.66894534098108 139.74797563823253 5.81</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66887059008812 139.747937498468 5.81 35.668858357030096 139.74797363208168 5.81 35.668858357030096 139.74797363208168 15.27 35.66887059008812 139.747937498468 15.27 35.66887059008812 139.747937498468 5.81</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668858357030096 139.74797363208168 15.27 35.668933107911805 139.7480117718741 15.27 35.66894534098108 139.74797563823253 15.27 35.66887059008812 139.747937498468 15.27 35.668858357030096 139.74797363208168 15.27</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-04b02072-79f3-4938-b65e-641efb3d3447"/>
							<gml:surfaceMember xlink:href="#poly-5beeb8a6-9238-47a4-87f3-4cf7c057873f"/>
							<gml:surfaceMember xlink:href="#poly-42ace5cd-6871-407a-9bf7-632323a018a3"/>
							<gml:surfaceMember xlink:href="#poly-b0ccd6ac-5ceb-4ddf-a7ca-f3c598e429ee"/>
							<gml:surfaceMember xlink:href="#poly-271c5ccd-f20f-400f-b088-2304a7274239"/>
							<gml:surfaceMember xlink:href="#poly-433ec788-af70-4117-93e6-8ed046307693"/>
							<gml:surfaceMember xlink:href="#poly-fd2a0c68-42b1-4245-b281-4b985bb555da"/>
							<gml:surfaceMember xlink:href="#poly-ed097367-0f7e-4983-8eb9-59966d87a82c"/>
							<gml:surfaceMember xlink:href="#poly-14a3cd4e-4b2a-4205-a90e-8437dc7b5c81"/>
							<gml:surfaceMember xlink:href="#poly-eeb28ca9-29c7-4f6f-8a6c-cae59893e2c6"/>
							<gml:surfaceMember xlink:href="#poly-92cd7676-8349-4e46-85d0-572e3604a335"/>
							<gml:surfaceMember xlink:href="#poly-093f4c19-cedc-4c70-8daf-3d1b32e41e50"/>
							<gml:surfaceMember xlink:href="#poly-33584c18-0894-4fb1-bc06-e9e04c12cd56"/>
							<gml:surfaceMember xlink:href="#poly-cfba8a60-8201-44c6-9f8a-62d4650dcef3"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-04b02072-79f3-4938-b65e-641efb3d3447">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-04b02072-79f3-4938-b65e-641efb3d3447">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-04b02072-79f3-4938-b65e-641efb3d3447">
											<gml:posList>35.66885835703011 139.74797363208165 5.81 35.668870590088105 139.747937498468 5.81 35.668945340981054 139.7479756382325 5.81 35.66893310791181 139.7480117718741 5.81 35.66885835703011 139.74797363208165 5.81</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-5beeb8a6-9238-47a4-87f3-4cf7c057873f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5beeb8a6-9238-47a4-87f3-4cf7c057873f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5beeb8a6-9238-47a4-87f3-4cf7c057873f">
											<gml:posList>35.66885835703011 139.74797363208165 15 35.668860888994686 139.7479723701364 15 35.66887164689533 139.74794060128318 15 35.668870590088105 139.747937498468 15 35.66885835703011 139.74797363208165 15</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-42ace5cd-6871-407a-9bf7-632323a018a3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-42ace5cd-6871-407a-9bf7-632323a018a3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-42ace5cd-6871-407a-9bf7-632323a018a3">
											<gml:posList>35.66893310791181 139.7480117718741 15 35.66893206012797 139.74800868009208 15 35.668860888994686 139.7479723701364 15 35.66885835703011 139.74797363208165 15 35.66893310791181 139.7480117718741 15</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b0ccd6ac-5ceb-4ddf-a7ca-f3c598e429ee">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b0ccd6ac-5ceb-4ddf-a7ca-f3c598e429ee">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b0ccd6ac-5ceb-4ddf-a7ca-f3c598e429ee">
											<gml:posList>35.66894282705177 139.74797691120588 14.735 35.66887164689533 139.74794060128318 14.735 35.668860888994686 139.7479723701364 14.735 35.66893206012797 139.74800868009208 14.735 35.66894282705177 139.74797691120588 14.735</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-271c5ccd-f20f-400f-b088-2304a7274239">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-271c5ccd-f20f-400f-b088-2304a7274239">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-271c5ccd-f20f-400f-b088-2304a7274239">
											<gml:posList>35.668870590088105 139.747937498468 15 35.66887164689533 139.74794060128318 15 35.66894282705177 139.74797691120588 15 35.668945340981054 139.7479756382325 15 35.668870590088105 139.747937498468 15</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-433ec788-af70-4117-93e6-8ed046307693">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-433ec788-af70-4117-93e6-8ed046307693">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-433ec788-af70-4117-93e6-8ed046307693">
											<gml:posList>35.668945340981054 139.7479756382325 15 35.66894282705177 139.74797691120588 15 35.66893206012797 139.74800868009208 15 35.66893310791181 139.7480117718741 15 35.668945340981054 139.7479756382325 15</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-fd2a0c68-42b1-4245-b281-4b985bb555da">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fd2a0c68-42b1-4245-b281-4b985bb555da">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fd2a0c68-42b1-4245-b281-4b985bb555da">
											<gml:posList>35.66887164689533 139.74794060128318 15 35.66887164689533 139.74794060128318 14.735 35.66894282705177 139.74797691120588 14.735 35.66894282705177 139.74797691120588 15 35.66887164689533 139.74794060128318 15</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ed097367-0f7e-4983-8eb9-59966d87a82c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ed097367-0f7e-4983-8eb9-59966d87a82c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ed097367-0f7e-4983-8eb9-59966d87a82c">
											<gml:posList>35.66893206012797 139.74800868009208 15 35.66893206012797 139.74800868009208 14.735 35.668860888994686 139.7479723701364 14.735 35.668860888994686 139.7479723701364 15 35.66893206012797 139.74800868009208 15</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-14a3cd4e-4b2a-4205-a90e-8437dc7b5c81">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-14a3cd4e-4b2a-4205-a90e-8437dc7b5c81">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-14a3cd4e-4b2a-4205-a90e-8437dc7b5c81">
											<gml:posList>35.668870590088105 139.747937498468 5.81 35.66885835703011 139.74797363208165 5.81 35.66885835703011 139.74797363208165 15 35.668870590088105 139.747937498468 15 35.668870590088105 139.747937498468 5.81</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-eeb28ca9-29c7-4f6f-8a6c-cae59893e2c6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-eeb28ca9-29c7-4f6f-8a6c-cae59893e2c6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-eeb28ca9-29c7-4f6f-8a6c-cae59893e2c6">
											<gml:posList>35.668860888994686 139.7479723701364 15 35.668860888994686 139.7479723701364 14.735 35.66887164689533 139.74794060128318 14.735 35.66887164689533 139.74794060128318 15 35.668860888994686 139.7479723701364 15</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-92cd7676-8349-4e46-85d0-572e3604a335">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-92cd7676-8349-4e46-85d0-572e3604a335">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-92cd7676-8349-4e46-85d0-572e3604a335">
											<gml:posList>35.668945340981054 139.7479756382325 5.81 35.668870590088105 139.747937498468 5.81 35.668870590088105 139.747937498468 15 35.668945340981054 139.7479756382325 15 35.668945340981054 139.7479756382325 5.81</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-093f4c19-cedc-4c70-8daf-3d1b32e41e50">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-093f4c19-cedc-4c70-8daf-3d1b32e41e50">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-093f4c19-cedc-4c70-8daf-3d1b32e41e50">
											<gml:posList>35.66885835703011 139.74797363208165 5.81 35.66893310791181 139.7480117718741 5.81 35.66893310791181 139.7480117718741 15 35.66885835703011 139.74797363208165 15 35.66885835703011 139.74797363208165 5.81</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-33584c18-0894-4fb1-bc06-e9e04c12cd56">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-33584c18-0894-4fb1-bc06-e9e04c12cd56">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-33584c18-0894-4fb1-bc06-e9e04c12cd56">
											<gml:posList>35.66894282705177 139.74797691120588 15 35.66894282705177 139.74797691120588 14.735 35.66893206012797 139.74800868009208 14.735 35.66893206012797 139.74800868009208 15 35.66894282705177 139.74797691120588 15</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-cfba8a60-8201-44c6-9f8a-62d4650dcef3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cfba8a60-8201-44c6-9f8a-62d4650dcef3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cfba8a60-8201-44c6-9f8a-62d4650dcef3">
											<gml:posList>35.66893310791181 139.7480117718741 5.81 35.668945340981054 139.7479756382325 5.81 35.668945340981054 139.7479756382325 15 35.66893310791181 139.7480117718741 15 35.66893310791181 139.7480117718741 5.81</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区虎ノ門二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-10907</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">24.08943</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1221</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>7</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.04</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>