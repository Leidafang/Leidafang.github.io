<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_f40ad798-d23b-4d45-a3b3-6028f4920c03">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>18</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103018001</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">401</bldg:usage>
			<bldg:measuredHeight uom="m">53.4</bldg:measuredHeight>
			<bldg:storeysAboveGround>13</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.67010616645671 139.7487946838713 0 35.67007399171046 139.74877509971247 0 35.66999491298945 139.74894034600038 0 35.670242986467834 139.74909131897675 0 35.67033669049482 139.7490487808139 0 35.670377316187114 139.74893411106854 0 35.67019205156671 139.7487337506567 0 35.67018544812581 139.74875174089226 0 35.67014239135433 139.7487286776058 0 35.670120316301386 139.74871524659824 0 35.670102059100074 139.74876031235937 0 35.670116532327555 139.74876912302577 0 35.67010616645671 139.7487946838713 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67010616645671 139.7487946838713 6.65 35.670116532327555 139.74876912302577 6.65 35.670102059100074 139.74876031235937 6.65 35.670120316301386 139.74871524659824 6.65 35.67014239135433 139.7487286776058 6.65 35.67018544812581 139.74875174089226 6.65 35.67019205156671 139.7487337506567 6.65 35.670377316187114 139.74893411106854 6.65 35.67033669049482 139.7490487808139 6.65 35.670242986467834 139.74909131897675 6.65 35.66999491298945 139.74894034600038 6.65 35.67007399171046 139.74877509971247 6.65 35.67010616645671 139.7487946838713 6.65</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67010616645671 139.7487946838713 6.65 35.67007399171046 139.74877509971247 6.65 35.67007399171046 139.74877509971247 59.57 35.67010616645671 139.7487946838713 59.57 35.67010616645671 139.7487946838713 6.65</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67007399171046 139.74877509971247 6.65 35.66999491298945 139.74894034600038 6.65 35.66999491298945 139.74894034600038 59.57 35.67007399171046 139.74877509971247 59.57 35.67007399171046 139.74877509971247 6.65</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66999491298945 139.74894034600038 6.65 35.670242986467834 139.74909131897675 6.65 35.670242986467834 139.74909131897675 59.57 35.66999491298945 139.74894034600038 59.57 35.66999491298945 139.74894034600038 6.65</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670242986467834 139.74909131897675 6.65 35.67033669049482 139.7490487808139 6.65 35.67033669049482 139.7490487808139 59.57 35.670242986467834 139.74909131897675 59.57 35.670242986467834 139.74909131897675 6.65</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67033669049482 139.7490487808139 6.65 35.670377316187114 139.74893411106854 6.65 35.670377316187114 139.74893411106854 59.57 35.67033669049482 139.7490487808139 59.57 35.67033669049482 139.7490487808139 6.65</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670377316187114 139.74893411106854 6.65 35.67019205156671 139.7487337506567 6.65 35.67019205156671 139.7487337506567 59.57 35.670377316187114 139.74893411106854 59.57 35.670377316187114 139.74893411106854 6.65</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67019205156671 139.7487337506567 6.65 35.67018544812581 139.74875174089226 6.65 35.67018544812581 139.74875174089226 59.57 35.67019205156671 139.7487337506567 59.57 35.67019205156671 139.7487337506567 6.65</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67018544812581 139.74875174089226 6.65 35.67014239135433 139.7487286776058 6.65 35.67014239135433 139.7487286776058 59.57 35.67018544812581 139.74875174089226 59.57 35.67018544812581 139.74875174089226 6.65</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67014239135433 139.7487286776058 6.65 35.670120316301386 139.74871524659824 6.65 35.670120316301386 139.74871524659824 59.57 35.67014239135433 139.7487286776058 59.57 35.67014239135433 139.7487286776058 6.65</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670120316301386 139.74871524659824 6.65 35.670102059100074 139.74876031235937 6.65 35.670102059100074 139.74876031235937 59.57 35.670120316301386 139.74871524659824 59.57 35.670120316301386 139.74871524659824 6.65</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670102059100074 139.74876031235937 6.65 35.670116532327555 139.74876912302577 6.65 35.670116532327555 139.74876912302577 59.57 35.670102059100074 139.74876031235937 59.57 35.670102059100074 139.74876031235937 6.65</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670116532327555 139.74876912302577 6.65 35.67010616645671 139.7487946838713 6.65 35.67010616645671 139.7487946838713 59.57 35.670116532327555 139.74876912302577 59.57 35.670116532327555 139.74876912302577 6.65</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67010616645671 139.7487946838713 59.57 35.67007399171046 139.74877509971247 59.57 35.66999491298945 139.74894034600038 59.57 35.670242986467834 139.74909131897675 59.57 35.67033669049482 139.7490487808139 59.57 35.670377316187114 139.74893411106854 59.57 35.67019205156671 139.7487337506567 59.57 35.67018544812581 139.74875174089226 59.57 35.67014239135433 139.7487286776058 59.57 35.670120316301386 139.74871524659824 59.57 35.670102059100074 139.74876031235937 59.57 35.670116532327555 139.74876912302577 59.57 35.67010616645671 139.7487946838713 59.57</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-7d8bfdfd-064e-4797-8e93-72cc07ff391f"/>
							<gml:surfaceMember xlink:href="#poly-26ed7b0b-27b7-4846-8699-6f67a0077d3e"/>
							<gml:surfaceMember xlink:href="#poly-0ce4ad7c-e6bb-4950-a8a3-9b0efbc90bc1"/>
							<gml:surfaceMember xlink:href="#poly-0d7f0d5d-31b0-4712-9cda-08dccb8dbbdc"/>
							<gml:surfaceMember xlink:href="#poly-1b155e9c-22b9-4b93-bdd0-9761527648d0"/>
							<gml:surfaceMember xlink:href="#poly-5401003d-e3ce-47b3-8919-d1fedf0db130"/>
							<gml:surfaceMember xlink:href="#poly-16fb9670-49a1-4c00-acec-676c2d268c44"/>
							<gml:surfaceMember xlink:href="#poly-df750ff0-fc20-4c12-9ad1-f8238a2277fb"/>
							<gml:surfaceMember xlink:href="#poly-d9a67342-0c92-4d3a-889a-4d26673b08ff"/>
							<gml:surfaceMember xlink:href="#poly-4d75e14f-e554-4cf5-9eec-f8c8e9cfa792"/>
							<gml:surfaceMember xlink:href="#poly-5df650ac-c6bf-436b-b64f-974c231a2c9e"/>
							<gml:surfaceMember xlink:href="#poly-68550d63-d414-4693-9459-6c2d0619f714"/>
							<gml:surfaceMember xlink:href="#poly-d60d40eb-cd69-4c29-b16a-a412d9e447dc"/>
							<gml:surfaceMember xlink:href="#poly-af56486a-5df5-430d-85d2-429dc7b504ba"/>
							<gml:surfaceMember xlink:href="#poly-3a965802-f8a7-45e0-835a-cf3111e9304f"/>
							<gml:surfaceMember xlink:href="#poly-81ab014c-69cc-444b-a482-9a9aee42f228"/>
							<gml:surfaceMember xlink:href="#poly-61875039-368b-43ec-bee1-642ee8d9c806"/>
							<gml:surfaceMember xlink:href="#poly-2e351c48-0cbb-4829-b4a6-aa593c050b26"/>
							<gml:surfaceMember xlink:href="#poly-f4d8c291-9cd2-48df-b380-2c8b540ecb56"/>
							<gml:surfaceMember xlink:href="#poly-a116ffeb-e7ff-45d1-b6fb-d87a046f2f29"/>
							<gml:surfaceMember xlink:href="#poly-809e961d-053f-4bd5-908b-ce7aaf01d1b5"/>
							<gml:surfaceMember xlink:href="#poly-f2e0da0a-ab2c-4d27-8392-7e7b401def02"/>
							<gml:surfaceMember xlink:href="#poly-b830954f-e619-439f-bc24-e68a2f2306cb"/>
							<gml:surfaceMember xlink:href="#poly-52bfb742-71c2-493d-b4eb-ad36737201d3"/>
							<gml:surfaceMember xlink:href="#poly-1008b36c-ecb3-4861-9b0a-74cc78263487"/>
							<gml:surfaceMember xlink:href="#poly-3dd5ce45-f24c-4972-b92e-dbafe61bd2aa"/>
							<gml:surfaceMember xlink:href="#poly-1cf274a7-e4c5-4e6f-a000-cf83ab159b58"/>
							<gml:surfaceMember xlink:href="#poly-e30a5015-c62a-4ea8-ab27-c39880d90936"/>
							<gml:surfaceMember xlink:href="#poly-b1b210a0-41f2-4c79-a781-0c0952421e81"/>
							<gml:surfaceMember xlink:href="#poly-eec7d452-db05-46f4-b0ef-4f6838f33be2"/>
							<gml:surfaceMember xlink:href="#poly-2a3b69cf-8bd2-412a-a7fe-9831479d1655"/>
							<gml:surfaceMember xlink:href="#poly-3a20d197-84a7-4cb9-a22c-3bd79c1871ac"/>
							<gml:surfaceMember xlink:href="#poly-b4450cbe-7af0-4254-b3e3-2515b03400b2"/>
							<gml:surfaceMember xlink:href="#poly-035ffc0a-208c-4ab8-a6b4-9150c3d6fd62"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_f40ad798-d23b-4d45-a3b3-6028f4920c03_BuildingInstallation_1060">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-dc5dd44d-b788-4a92-86cb-5ebc75337b11">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-dc5dd44d-b788-4a92-86cb-5ebc75337b11_0">
											<gml:posList>35.67014923892318 139.74871176965075 54.169 35.67014923892318 139.74871176965075 57.084 35.67017658357219 139.7487331373424 55.6 35.67014923892318 139.74871176965075 54.169</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-255becf2-70a4-4366-bc2a-f2b9e589de73">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-255becf2-70a4-4366-bc2a-f2b9e589de73_0">
											<gml:posList>35.670156095503366 139.74869486168325 54.169 35.670156095503366 139.74869486168325 6.65 35.67014923892318 139.74871176965075 54.169 35.670156095503366 139.74869486168325 54.169</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5cc4869a-19be-4fa4-b786-e1aec2d74d9b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5cc4869a-19be-4fa4-b786-e1aec2d74d9b_0">
											<gml:posList>35.670156095503366 139.74869486168325 6.65 35.67014239135433 139.7487286776058 6.65 35.67014923892318 139.74871176965075 54.169 35.670156095503366 139.74869486168325 6.65</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b716a381-ce49-412d-8b81-28658989fc61">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b716a381-ce49-412d-8b81-28658989fc61_0">
											<gml:posList>35.67014923892318 139.74871176965075 54.169 35.67014239135433 139.7487286776058 57.084 35.67014923892318 139.74871176965075 57.084 35.67014923892318 139.74871176965075 54.169</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-32f5a3a2-d8e3-43e4-aad7-19656336873e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-32f5a3a2-d8e3-43e4-aad7-19656336873e_0">
											<gml:posList>35.67014923892318 139.74871176965075 54.169 35.67014239135433 139.7487286776058 6.65 35.67014239135433 139.7487286776058 57.084 35.67014923892318 139.74871176965075 54.169</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-769b15db-ad9d-4fec-8ace-da38c1b18f71">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-769b15db-ad9d-4fec-8ace-da38c1b18f71_0">
											<gml:posList>35.67018073073444 139.74872151232967 55.6 35.670156095503366 139.74869486168325 54.169 35.67014923892318 139.74871176965075 54.169 35.67018073073444 139.74872151232967 55.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f294fa26-8457-4818-81e1-5709f1c506aa">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f294fa26-8457-4818-81e1-5709f1c506aa_0">
											<gml:posList>35.67017658357219 139.7487331373424 55.6 35.67018073073444 139.74872151232967 55.6 35.67014923892318 139.74871176965075 54.169 35.67017658357219 139.7487331373424 55.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ab84fe0d-e9d2-45ee-b8a6-73fe27cd0ae4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ab84fe0d-e9d2-45ee-b8a6-73fe27cd0ae4_0">
											<gml:posList>35.67014239135433 139.7487286776058 57.084 35.670172436416586 139.7487447734002 55.6 35.67017658357219 139.7487331373424 55.6 35.67014239135433 139.7487286776058 57.084</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6d13961f-9262-4cac-b0e0-a35f7ece54a0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6d13961f-9262-4cac-b0e0-a35f7ece54a0_0">
											<gml:posList>35.67014923892318 139.74871176965075 57.084 35.67014239135433 139.7487286776058 57.084 35.67017658357219 139.7487331373424 55.6 35.67014923892318 139.74871176965075 57.084</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ed2f1889-99ab-41d6-abf9-2fa0bbfdfd82">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ed2f1889-99ab-41d6-abf9-2fa0bbfdfd82_0">
											<gml:posList>35.67018073073444 139.74872151232967 55.6 35.67017658357219 139.7487331373424 55.6 35.67019205156668 139.7487337506567 55.6 35.67018073073444 139.74872151232967 55.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-99a7b142-0942-4562-aae5-ad992d7e5bd6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-99a7b142-0942-4562-aae5-ad992d7e5bd6_0">
											<gml:posList>35.67017658357219 139.7487331373424 55.6 35.670172436416586 139.7487447734002 55.6 35.670185448125785 139.74875174089226 55.6 35.67017658357219 139.7487331373424 55.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1d18d813-48c8-4e6b-a4f5-160fbb3b09a5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1d18d813-48c8-4e6b-a4f5-160fbb3b09a5_0">
											<gml:posList>35.67017658357219 139.7487331373424 55.6 35.670185448125785 139.74875174089226 55.6 35.67019205156668 139.7487337506567 55.6 35.67017658357219 139.7487331373424 55.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e00dad56-a96c-4ece-a73a-290d5cebc267">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e00dad56-a96c-4ece-a73a-290d5cebc267_0">
											<gml:posList>35.670185448125785 139.74875174089226 55.6 35.67019205156668 139.7487337506567 6.65 35.67019205156668 139.7487337506567 55.6 35.670185448125785 139.74875174089226 55.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5f115f3a-f9c5-4395-b699-529a74759010">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5f115f3a-f9c5-4395-b699-529a74759010_0">
											<gml:posList>35.670185448125785 139.74875174089226 55.6 35.670185448125785 139.74875174089226 6.65 35.67019205156668 139.7487337506567 6.65 35.670185448125785 139.74875174089226 55.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f6e842c9-933f-465d-8601-ef740ef1ac23">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f6e842c9-933f-465d-8601-ef740ef1ac23_0">
											<gml:posList>35.67016179294025 139.7487857550968 55.816 35.67017120710831 139.74879121305418 65.94 35.67017120710831 139.74879121305418 55.816 35.67016179294025 139.7487857550968 55.816</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-673df36b-7e2f-4bf0-9b46-277e0c96b926">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-673df36b-7e2f-4bf0-9b46-277e0c96b926_0">
											<gml:posList>35.67016179294025 139.7487857550968 55.816 35.67016179294025 139.7487857550968 65.94 35.67017120710831 139.74879121305418 65.94 35.67016179294025 139.7487857550968 55.816</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d55aeb53-9e60-479c-adc2-62beb09bacb8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d55aeb53-9e60-479c-adc2-62beb09bacb8_0">
											<gml:posList>35.67014692925129 139.74882421164432 55.816 35.67016179294025 139.7487857550968 65.94 35.67016179294025 139.7487857550968 55.816 35.67014692925129 139.74882421164432 55.816</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6c0b4eef-f750-4efe-9496-a29d5511642f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6c0b4eef-f750-4efe-9496-a29d5511642f_0">
											<gml:posList>35.67014692925129 139.74882421164432 55.816 35.67014692925129 139.74882421164432 65.94 35.67016179294025 139.7487857550968 65.94 35.67014692925129 139.74882421164432 55.816</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2a318b55-287a-40a7-ba71-fb962775c227">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2a318b55-287a-40a7-ba71-fb962775c227_0">
											<gml:posList>35.67017120710831 139.74879121305418 65.94 35.67016179294025 139.7487857550968 65.94 35.67014692925129 139.74882421164432 65.94 35.67017120710831 139.74879121305418 65.94</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-29a665ee-bd1b-4d23-8523-23774973495e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-29a665ee-bd1b-4d23-8523-23774973495e_0">
											<gml:posList>35.670156334411665 139.74882968066092 65.94 35.67017120710831 139.74879121305418 65.94 35.67014692925129 139.74882421164432 65.94 35.670156334411665 139.74882968066092 65.94</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4755f5b4-41e4-4ceb-b3ea-66e9ca9c5143">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4755f5b4-41e4-4ceb-b3ea-66e9ca9c5143_0">
											<gml:posList>35.67017120710831 139.74879121305418 55.816 35.670156334411665 139.74882968066092 65.94 35.670156334411665 139.74882968066092 55.816 35.67017120710831 139.74879121305418 55.816</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-708a4420-bc1d-4084-bd9e-d473a87f3201">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-708a4420-bc1d-4084-bd9e-d473a87f3201_0">
											<gml:posList>35.67017120710831 139.74879121305418 55.816 35.67017120710831 139.74879121305418 65.94 35.670156334411665 139.74882968066092 65.94 35.67017120710831 139.74879121305418 55.816</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-83b040ce-14a4-4e80-98c0-e65c711ea00d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-83b040ce-14a4-4e80-98c0-e65c711ea00d_0">
											<gml:posList>35.670156334411665 139.74882968066092 55.816 35.67014692925129 139.74882421164432 65.94 35.67014692925129 139.74882421164432 55.816 35.670156334411665 139.74882968066092 55.816</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9a840dd3-a54d-4cd1-9941-821357b8c813">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9a840dd3-a54d-4cd1-9941-821357b8c813_0">
											<gml:posList>35.670156334411665 139.74882968066092 55.816 35.670156334411665 139.74882968066092 65.94 35.67014692925129 139.74882421164432 65.94 35.670156334411665 139.74882968066092 55.816</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4588a1f3-20c6-426f-ad6b-014b1f90aa2d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4588a1f3-20c6-426f-ad6b-014b1f90aa2d_0">
											<gml:posList>35.670156095503366 139.74869486168325 6.65 35.670156095503366 139.74869486168325 54.169 35.67019205156668 139.7487337506567 6.65 35.670156095503366 139.74869486168325 6.65</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b2456d4b-1b3a-4788-a7cf-4ed2e0e33a7d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b2456d4b-1b3a-4788-a7cf-4ed2e0e33a7d_0">
											<gml:posList>35.67019205156668 139.7487337506567 6.65 35.670156095503366 139.74869486168325 54.169 35.67019205156668 139.7487337506567 55.6 35.67019205156668 139.7487337506567 6.65</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-956beef2-d98d-4949-8a25-f724ceecbe47">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-956beef2-d98d-4949-8a25-f724ceecbe47_0">
											<gml:posList>35.670156095503366 139.74869486168325 54.169 35.67018073073444 139.74872151232967 55.6 35.67019205156668 139.7487337506567 55.6 35.670156095503366 139.74869486168325 54.169</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-87a06965-314c-4e83-9267-da3bc60aaa45">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-87a06965-314c-4e83-9267-da3bc60aaa45_0">
											<gml:posList>35.670185448125785 139.74875174089226 55.6 35.670172436416586 139.7487447734002 55.6 35.670185448125785 139.74875174089226 6.65 35.670185448125785 139.74875174089226 55.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8eb31af7-f2f6-4159-b1ba-9dd04a83e42f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8eb31af7-f2f6-4159-b1ba-9dd04a83e42f_0">
											<gml:posList>35.670185448125785 139.74875174089226 6.65 35.670172436416586 139.7487447734002 55.6 35.67014239135433 139.7487286776058 6.65 35.670185448125785 139.74875174089226 6.65</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b08f8aec-27a6-4961-a275-b95d853f43f5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b08f8aec-27a6-4961-a275-b95d853f43f5_0">
											<gml:posList>35.670172436416586 139.7487447734002 55.6 35.67014239135433 139.7487286776058 57.084 35.67014239135433 139.7487286776058 6.65 35.670172436416586 139.7487447734002 55.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0a76839e-30ba-4e7c-a74b-13fc5ca7ce93">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67019205156668 139.7487337506567 6.65 35.670185448125785 139.74875174089226 6.65 35.67014239135433 139.7487286776058 6.65 35.67019205156668 139.7487337506567 6.65</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fd5f6c2e-92c0-4534-b4ee-db10190bdf6f">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670156095503366 139.74869486168325 6.65 35.67019205156668 139.7487337506567 6.65 35.67014239135433 139.7487286776058 6.65 35.670156095503366 139.74869486168325 6.65</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-da0c7e4d-0f01-47a5-b502-22c715a6508d">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67014692925129 139.74882421164432 55.816 35.67016179294025 139.7487857550968 55.816 35.67017120710831 139.74879121305418 55.816 35.67014692925129 139.74882421164432 55.816</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0c5dc20c-bef6-4219-b067-0f3d1790a255">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670156334411665 139.74882968066092 55.816 35.67014692925129 139.74882421164432 55.816 35.67017120710831 139.74879121305418 55.816 35.670156334411665 139.74882968066092 55.816</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_f40ad798-d23b-4d45-a3b3-6028f4920c03_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6d28b54a-de19-477e-8eb0-f3f04e90b15f">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67016373748972 139.7489879542944 55.816 35.6701793324574 139.74895108765696 55.816 35.67018631220008 139.74895553194335 55.816 35.670170717223336 139.74899238753693 55.816 35.67016373748972 139.7489879542944 55.816</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e0659eef-9008-4593-a452-2417aec3b889">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67019476182995 139.74896090256743 55.816 35.67018014772291 139.74899543742325 55.816 35.67017295155944 139.7489908608066 55.816 35.67018755665145 139.74895632596252 55.816 35.67019476182995 139.74896090256743 55.816</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0737a808-9593-45d1-9012-72bf5f33bc03">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670187769759806 139.74899032604577 55.816 35.670187769759806 139.74899032604577 64.657 35.67019891932435 139.7489639911383 64.657 35.67019891932435 139.7489639911383 55.816 35.670187769759806 139.74899032604577 55.816</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-dad8afbc-2ff1-4e79-8fde-bc526bca484e">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67020614254546 139.74896858981805 55.816 35.67019500199366 139.74899492471772 55.816 35.670187769759806 139.74899032604577 55.816 35.67019891932435 139.7489639911383 55.816 35.67020614254546 139.74896858981805 55.816</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b9178e90-01cc-49a8-933b-bf8fb5b1e689">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67021627529664 139.74885475872318 55.816 35.67020909012936 139.74887871453487 55.816 35.67017946077033 139.74886412053263 55.816 35.670186235550815 139.74884621849696 55.816 35.67016360243527 139.74883389266083 55.816 35.670174893781414 139.74880413325823 55.816 35.670241984912856 139.74884540860697 55.816 35.670234445926404 139.74886610615906 55.816 35.67021627529664 139.74885475872318 55.816</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b7c3234b-dfbf-4c11-8936-40399b5b8263">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67020760771019 139.74902712228354 55.816 35.670200032948294 139.74902251292187 55.816 35.670224689200424 139.7489634448481 55.816 35.670232218981056 139.74896817576155 55.816 35.67020760771019 139.74902712228354 55.816</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4656f770-1cc5-4864-b5ad-d4feb0fe2988">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67020760771019 139.74902712228354 55.816 35.670232218981056 139.74896817576155 55.816 35.670232218981056 139.74896817576155 57.472 35.67020760771019 139.74902712228354 57.472 35.67020760771019 139.74902712228354 55.816</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4d1ae1d7-c14f-4953-aaea-338d487fa242">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67021015968485 139.74902867711955 55.816 35.67021015968485 139.74902867711955 57.472 35.67023476196595 139.74896976374436 57.472 35.67023476196595 139.74896976374436 55.816 35.67021015968485 139.74902867711955 55.816</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-98fd7d7f-0883-4d0d-b89a-eba65df7c98b">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670200115826574 139.74890923369017 55.816 35.67020610861185 139.74889445856212 55.816 35.670252008097336 139.74892240140213 55.816 35.67024602431466 139.74893716548084 55.816 35.670200115826574 139.74890923369017 55.816</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-264d5a39-929a-4615-b774-55fa8365bd73">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670218203361266 139.74903357319153 55.816 35.67021015968485 139.74902867711955 55.816 35.67023476196595 139.74896976374436 55.816 35.670242760661225 139.7489747813679 55.816 35.670218203361266 139.74903357319153 55.816</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1b178bf3-5d64-421d-ad02-70940bf827a8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6702223334105 139.74903608739154 55.816 35.6702223334105 139.74903608739154 57.472 35.67024686370918 139.7489773508253 57.472 35.67024686370918 139.7489773508253 55.816 35.6702223334105 139.74903608739154 55.816</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e2953bb6-367e-4da0-9550-10b7b61360da">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67023797889667 139.74904560384797 55.816 35.6702223334105 139.74903608739154 55.816 35.67024686370918 139.7489773508253 55.816 35.67026241021144 139.7489870993484 55.816 35.67023797889667 139.74904560384797 55.816</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-aac826c6-3f3a-4c82-848e-1b048e1b71f7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670266116485 139.74898942620703 55.816 35.67024685039453 139.7490355645341 55.816 35.67024685039453 139.7490355645341 57.472 35.670266116485 139.74898942620703 57.472 35.670266116485 139.74898942620703 55.816</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-25c9b8cc-0242-4c5c-bdc2-61850acaaa80">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670254262932026 139.7490402072089 55.816 35.67024685039453 139.7490355645341 55.816 35.670266116485 139.74898942620703 55.816 35.67027352903198 139.74899407992496 55.816 35.670254262932026 139.7490402072089 55.816</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8167c0c7-6dd6-4a8c-ac57-021f0ecc5ca2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670244249219266 139.74888660870184 55.816 35.670251573855715 139.7488687281668 55.816 35.67028001543963 139.74888622859768 55.816 35.670272690800616 139.74890410913747 55.816 35.670244249219266 139.74888660870184 55.816</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-df7c8bc3-d6d3-4811-a2c3-1e0863130a0e">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670277713458354 139.7489970138248 55.816 35.670269597830455 139.74901808755064 55.816 35.670269597830455 139.74901808755064 57.12 35.670277713458354 139.7489970138248 57.12 35.670277713458354 139.7489970138248 55.816</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0d529b0d-fe4b-4689-9502-8870790bc123">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67028992253819 139.74895195438387 55.816 35.670257946461 139.74893285594274 55.816 35.67026805107903 139.7489074610354 55.816 35.67029125312776 139.74892132173778 55.816 35.6702886617358 139.7489278307059 55.816 35.67029743576794 139.74893306843742 55.816 35.67028992253819 139.74895195438387 55.816</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-10364169-4703-4d48-a82f-e30d78a91b4d">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670269597830455 139.74901808755064 55.816 35.670277713458354 139.7489970138248 55.816 35.67029536948774 139.74900721303297 55.816 35.67028725386582 139.74902829780865 55.816 35.670269597830455 139.74901808755064 55.816</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0a2d7bd3-d8ef-4b2d-b3bd-5d9c111bfa8c">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67028992253819 139.74895195438387 55.816 35.67029743576794 139.74893306843742 55.816 35.67029743576794 139.74893306843742 56.658 35.67028992253819 139.74895195438387 56.658 35.67028992253819 139.74895195438387 55.816</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-50dd22cc-e8f5-4809-816e-24d37eebebee">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670302189069695 139.74901463998648 55.816 35.67031088188172 139.7490197452588 55.816 35.670297888212815 139.74902564657341 55.816 35.670302189069695 139.74901463998648 55.816</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-18c6399c-a3fc-4e8f-aa3c-dc1c152f25fd">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6702907595746 139.74897591281473 55.816 35.670315299445825 139.74891801568492 55.816 35.67032190250253 139.74892515565807 55.816 35.67029834349892 139.74898073204625 55.816 35.6702907595746 139.74897591281473 55.816</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a6163a84-3544-427e-b887-dac11e29d041">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67032190250253 139.74892515565807 57.472 35.67029834349892 139.74898073204625 57.472 35.67029834349892 139.74898073204625 55.816 35.67032190250253 139.74892515565807 55.816 35.67032190250253 139.74892515565807 57.472</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e4d4b49e-7967-4711-93ef-9514399ead80">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670324374136975 139.74892782624914 57.472 35.670324374136975 139.74892782624914 55.816 35.6703011840913 139.7489825406427 55.816 35.6703011840913 139.7489825406427 57.472 35.670324374136975 139.74892782624914 57.472</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a8855de1-82ee-426a-8659-494d6ffcc456">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6703011840913 139.7489825406427 55.816 35.670324374136975 139.74892782624914 55.816 35.670339041579254 139.74894368427613 55.816 35.67031802024427 139.74899327093314 55.816 35.6703011840913 139.7489825406427 55.816</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-92cb678a-fd9c-4b54-8131-765a6246033b">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67012120184378 139.7488852912446 55.816 35.670089812584926 139.74886752884458 55.816 35.670095057830515 139.74885361612664 55.816 35.67012643807766 139.74887137853187 55.816 35.67012120184378 139.7488852912446 55.816</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b3510f64-bb79-4ed2-839b-9ca83380af25">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67014348668402 139.74895371019952 55.816 35.67014003124197 139.7489620316451 55.816 35.67012036369234 139.74894975789334 55.816 35.670123765144105 139.7489415690608 55.816 35.67011370142161 139.74893529435218 55.816 35.670119505495 139.74892133686132 55.816 35.67012911834611 139.74892734693384 55.816 35.670131853911265 139.74892077154956 55.816 35.67014183647998 139.7489270021583 55.816 35.67013929887577 139.7489330913008 55.816 35.670157983497475 139.74894474749703 55.816 35.67015203544178 139.74895904757756 55.816 35.67014348668402 139.74895371019952 55.816</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-27acdd89-dfec-4330-b542-2b842fc324b0">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670133938954464 139.7489120096969 55.816 35.67014278400181 139.74888997420607 55.816 35.6701650753802 139.74890342713022 55.816 35.67015623032268 139.7489254515795 55.816 35.670133938954464 139.7489120096969 55.816</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-769abcde-6f3a-4d0e-ab42-32dd57a7e786">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-769abcde-6f3a-4d0e-ab42-32dd57a7e786_0">
											<gml:posList>35.67017295155944 139.7489908608066 55.816 35.67017295155944 139.7489908608066 64.657 35.67018755665145 139.74895632596252 64.657 35.67018755665145 139.74895632596252 55.816 35.67017295155944 139.7489908608066 55.816</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-969c9391-2e49-42e6-8fc8-fd54490d7fb1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-969c9391-2e49-42e6-8fc8-fd54490d7fb1_0">
											<gml:posList>35.670218203361266 139.74903357319153 55.816 35.670242760661225 139.7489747813679 55.816 35.670242760661225 139.7489747813679 57.472 35.670218203361266 139.74903357319153 57.472 35.670218203361266 139.74903357319153 55.816</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-afc9b6fc-e3a8-49ef-be7f-b9e42f15e8e5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-afc9b6fc-e3a8-49ef-be7f-b9e42f15e8e5_0">
											<gml:posList>35.670095057830515 139.74885361612664 55.816 35.670089812584926 139.74886752884458 55.816 35.670089812584926 139.74886752884458 65.138 35.670095057830515 139.74885361612664 65.138 35.670095057830515 139.74885361612664 55.816</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2f97e668-b516-46a9-84fd-dcdefc33df95">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2f97e668-b516-46a9-84fd-dcdefc33df95_0">
											<gml:posList>35.670089812584926 139.74886752884458 55.816 35.67012120184378 139.7488852912446 55.816 35.67012120184378 139.7488852912446 65.138 35.670089812584926 139.74886752884458 65.138 35.670089812584926 139.74886752884458 55.816</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c89c14d8-61eb-4044-b071-50397545377b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c89c14d8-61eb-4044-b071-50397545377b_0">
											<gml:posList>35.67012120184378 139.7488852912446 65.138 35.67012643807766 139.74887137853187 65.138 35.670095057830515 139.74885361612664 65.138 35.670089812584926 139.74886752884458 65.138 35.67012120184378 139.7488852912446 65.138</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-816095ae-9e01-43dd-8ea2-71bdfc88dbb2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-816095ae-9e01-43dd-8ea2-71bdfc88dbb2_0">
											<gml:posList>35.670095057830515 139.74885361612664 65.138 35.67012643807766 139.74887137853187 65.138 35.67012643807766 139.74887137853187 55.816 35.670095057830515 139.74885361612664 55.816 35.670095057830515 139.74885361612664 65.138</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8f662024-a647-4a6c-a671-8a98cdbc770d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8f662024-a647-4a6c-a671-8a98cdbc770d_0">
											<gml:posList>35.670119505495 139.74892133686132 55.816 35.67011370142161 139.74893529435218 55.816 35.67011370142161 139.74893529435218 65.73 35.670119505495 139.74892133686132 65.73 35.670119505495 139.74892133686132 55.816</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4a18e0da-6041-43b4-95dd-4a54ada86207">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4a18e0da-6041-43b4-95dd-4a54ada86207_0">
											<gml:posList>35.67011370142161 139.74893529435218 55.816 35.670123765144105 139.7489415690608 55.816 35.670123765144105 139.7489415690608 65.73 35.67011370142161 139.74893529435218 65.73 35.67011370142161 139.74893529435218 55.816</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0038b272-74a8-488a-aab3-b8e0468f6e4f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0038b272-74a8-488a-aab3-b8e0468f6e4f_0">
											<gml:posList>35.67012036369234 139.74894975789334 55.816 35.67012036369234 139.74894975789334 65.73 35.670123765144105 139.7489415690608 65.73 35.670123765144105 139.7489415690608 55.816 35.67012036369234 139.74894975789334 55.816</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-14a7cfb0-b7b8-4669-9179-7124a8515996">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-14a7cfb0-b7b8-4669-9179-7124a8515996_0">
											<gml:posList>35.67012120184378 139.7488852912446 55.816 35.67012643807766 139.74887137853187 55.816 35.67012643807766 139.74887137853187 65.138 35.67012120184378 139.7488852912446 65.138 35.67012120184378 139.7488852912446 55.816</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ea366be7-81f5-4ba6-86d1-e66fbb2872c6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ea366be7-81f5-4ba6-86d1-e66fbb2872c6_0">
											<gml:posList>35.670119505495 139.74892133686132 55.816 35.670119505495 139.74892133686132 65.73 35.67012911834611 139.74892734693384 65.73 35.67012911834611 139.74892734693384 55.816 35.670119505495 139.74892133686132 55.816</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1da6ce8a-416b-403f-982a-5e6af53c1092">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1da6ce8a-416b-403f-982a-5e6af53c1092_0">
											<gml:posList>35.67012036369234 139.74894975789334 55.816 35.67014003124197 139.7489620316451 55.816 35.67014003124197 139.7489620316451 65.73 35.67012036369234 139.74894975789334 65.73 35.67012036369234 139.74894975789334 55.816</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-24228aef-ae0b-43d2-9c93-9da04385541a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-24228aef-ae0b-43d2-9c93-9da04385541a_0">
											<gml:posList>35.670131853911265 139.74892077154956 55.816 35.67012911834611 139.74892734693384 55.816 35.67012911834611 139.74892734693384 65.73 35.670131853911265 139.74892077154956 65.73 35.670131853911265 139.74892077154956 55.816</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-686a578d-2fd3-48b3-b7b8-14e78525430a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-686a578d-2fd3-48b3-b7b8-14e78525430a_0">
											<gml:posList>35.670157983497475 139.74894474749703 65.73 35.67013929887577 139.7489330913008 65.73 35.67014183647998 139.7489270021583 65.73 35.670131853911265 139.74892077154956 65.73 35.67012911834611 139.74892734693384 65.73 35.670119505495 139.74892133686132 65.73 35.67011370142161 139.74893529435218 65.73 35.670123765144105 139.7489415690608 65.73 35.67012036369234 139.74894975789334 65.73 35.67014003124197 139.7489620316451 65.73 35.67014348668402 139.74895371019952 65.73 35.67015203544178 139.74895904757756 65.73 35.670157983497475 139.74894474749703 65.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-236be437-ee06-4442-8488-63d82bc4abd8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-236be437-ee06-4442-8488-63d82bc4abd8_0">
											<gml:posList>35.67014183647998 139.7489270021583 55.816 35.670131853911265 139.74892077154956 55.816 35.670131853911265 139.74892077154956 65.73 35.67014183647998 139.7489270021583 65.73 35.67014183647998 139.7489270021583 55.816</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2410eaf1-1203-4b2d-9a00-3e2ad6033aaf">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2410eaf1-1203-4b2d-9a00-3e2ad6033aaf_0">
											<gml:posList>35.670133938954464 139.7489120096969 55.816 35.670133938954464 139.7489120096969 66.477 35.67014278400181 139.74888997420607 66.477 35.67014278400181 139.74888997420607 55.816 35.670133938954464 139.7489120096969 55.816</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cc905fb4-0abf-4d3c-a4cb-26fd51a3c871">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cc905fb4-0abf-4d3c-a4cb-26fd51a3c871_0">
											<gml:posList>35.67013929887577 139.7489330913008 55.816 35.67014183647998 139.7489270021583 55.816 35.67014183647998 139.7489270021583 65.73 35.67013929887577 139.7489330913008 65.73 35.67013929887577 139.7489330913008 55.816</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8b9e8b33-af6d-44e3-9941-f2c474e57a4d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8b9e8b33-af6d-44e3-9941-f2c474e57a4d_0">
											<gml:posList>35.67014003124197 139.7489620316451 55.816 35.67014348668402 139.74895371019952 55.816 35.67014348668402 139.74895371019952 65.73 35.67014003124197 139.7489620316451 65.73 35.67014003124197 139.7489620316451 55.816</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b3a7e9b1-8af3-404c-9997-996a00e3301f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b3a7e9b1-8af3-404c-9997-996a00e3301f_0">
											<gml:posList>35.670133938954464 139.7489120096969 55.816 35.67015623032268 139.7489254515795 55.816 35.67015623032268 139.7489254515795 66.477 35.670133938954464 139.7489120096969 66.477 35.670133938954464 139.7489120096969 55.816</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-401904b2-aa94-45e8-88c5-c7b481ba1697">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-401904b2-aa94-45e8-88c5-c7b481ba1697_0">
											<gml:posList>35.67014348668402 139.74895371019952 55.816 35.67015203544178 139.74895904757756 55.816 35.67015203544178 139.74895904757756 65.73 35.67014348668402 139.74895371019952 65.73 35.67014348668402 139.74895371019952 55.816</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e9500d7c-192d-45d3-8b61-d8e288ca0059">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e9500d7c-192d-45d3-8b61-d8e288ca0059_0">
											<gml:posList>35.67013929887577 139.7489330913008 55.816 35.67013929887577 139.7489330913008 65.73 35.670157983497475 139.74894474749703 65.73 35.670157983497475 139.74894474749703 55.816 35.67013929887577 139.7489330913008 55.816</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-09a63591-df25-456d-8b6b-7bf96692cd50">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-09a63591-df25-456d-8b6b-7bf96692cd50_0">
											<gml:posList>35.670133938954464 139.7489120096969 66.477 35.67015623032268 139.7489254515795 66.477 35.6701650753802 139.74890342713022 66.477 35.67014278400181 139.74888997420607 66.477 35.670133938954464 139.7489120096969 66.477</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cb5ba168-5a18-4fc9-860a-e9da476e9777">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cb5ba168-5a18-4fc9-860a-e9da476e9777_0">
											<gml:posList>35.67014278400181 139.74888997420607 55.816 35.67014278400181 139.74888997420607 66.477 35.6701650753802 139.74890342713022 66.477 35.6701650753802 139.74890342713022 55.816 35.67014278400181 139.74888997420607 55.816</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4c27c3fb-252a-4211-b422-a809dbec233b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4c27c3fb-252a-4211-b422-a809dbec233b_0">
											<gml:posList>35.67015203544178 139.74895904757756 55.816 35.670157983497475 139.74894474749703 55.816 35.670157983497475 139.74894474749703 65.73 35.67015203544178 139.74895904757756 65.73 35.67015203544178 139.74895904757756 55.816</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-15863283-6e16-4a4d-8b46-24b8ad243215">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-15863283-6e16-4a4d-8b46-24b8ad243215_0">
											<gml:posList>35.67015623032268 139.7489254515795 55.816 35.6701650753802 139.74890342713022 55.816 35.6701650753802 139.74890342713022 66.477 35.67015623032268 139.7489254515795 66.477 35.67015623032268 139.7489254515795 55.816</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-71d58a0e-8edc-47b0-a657-93c520876965">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-71d58a0e-8edc-47b0-a657-93c520876965_0">
											<gml:posList>35.67016373748972 139.7489879542944 55.816 35.670170717223336 139.74899238753693 55.816 35.670170717223336 139.74899238753693 64.657 35.67016373748972 139.7489879542944 64.657 35.67016373748972 139.7489879542944 55.816</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-dd1dd7c0-1b87-4d5a-baed-0f22b3c31f49">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-dd1dd7c0-1b87-4d5a-baed-0f22b3c31f49_0">
											<gml:posList>35.670174893781414 139.74880413325823 55.816 35.67016360243527 139.74883389266083 55.816 35.67016360243527 139.74883389266083 60.189 35.670174893781414 139.74880413325823 60.189 35.670174893781414 139.74880413325823 55.816</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4ef9cf1c-7ceb-4b6f-9191-4b3573873feb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4ef9cf1c-7ceb-4b6f-9191-4b3573873feb_0">
											<gml:posList>35.67016373748972 139.7489879542944 55.816 35.67016373748972 139.7489879542944 64.657 35.6701793324574 139.74895108765696 64.657 35.6701793324574 139.74895108765696 55.816 35.67016373748972 139.7489879542944 55.816</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9c7fc513-d2de-4608-899f-1e5b8bd1a803">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9c7fc513-d2de-4608-899f-1e5b8bd1a803_0">
											<gml:posList>35.67016360243527 139.74883389266083 55.816 35.670186235550815 139.74884621849696 55.816 35.670186235550815 139.74884621849696 60.189 35.67016360243527 139.74883389266083 60.189 35.67016360243527 139.74883389266083 55.816</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-47d7af5a-fa9a-4e7c-99bc-f9e9b76fbcc7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-47d7af5a-fa9a-4e7c-99bc-f9e9b76fbcc7_0">
											<gml:posList>35.67018631220008 139.74895553194335 64.657 35.6701793324574 139.74895108765696 64.657 35.67016373748972 139.7489879542944 64.657 35.670170717223336 139.74899238753693 64.657 35.67018631220008 139.74895553194335 64.657</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5f4de0de-06f4-4b64-b0c8-edbf9714a841">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5f4de0de-06f4-4b64-b0c8-edbf9714a841_0">
											<gml:posList>35.67017295155944 139.7489908608066 55.816 35.67018014772291 139.74899543742325 55.816 35.67018014772291 139.74899543742325 64.657 35.67017295155944 139.7489908608066 64.657 35.67017295155944 139.7489908608066 55.816</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0409e351-7d7f-471b-8d34-31b00abb0a20">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0409e351-7d7f-471b-8d34-31b00abb0a20_0">
											<gml:posList>35.670170717223336 139.74899238753693 55.816 35.67018631220008 139.74895553194335 55.816 35.67018631220008 139.74895553194335 64.657 35.670170717223336 139.74899238753693 64.657 35.670170717223336 139.74899238753693 55.816</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5c906aaf-d85b-4131-8f82-927b6a1b090d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5c906aaf-d85b-4131-8f82-927b6a1b090d_0">
											<gml:posList>35.67018631220008 139.74895553194335 55.816 35.6701793324574 139.74895108765696 55.816 35.6701793324574 139.74895108765696 64.657 35.67018631220008 139.74895553194335 64.657 35.67018631220008 139.74895553194335 55.816</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5a2192b9-c737-4143-8c26-7c0d9b6f6f3d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5a2192b9-c737-4143-8c26-7c0d9b6f6f3d_0">
											<gml:posList>35.670186235550815 139.74884621849696 55.816 35.67017946077033 139.74886412053263 55.816 35.67017946077033 139.74886412053263 60.189 35.670186235550815 139.74884621849696 60.189 35.670186235550815 139.74884621849696 55.816</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1a3ae447-5960-4626-9217-df8eed4e7a8f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1a3ae447-5960-4626-9217-df8eed4e7a8f_0">
											<gml:posList>35.67019476182995 139.74896090256743 64.657 35.67018755665145 139.74895632596252 64.657 35.67017295155944 139.7489908608066 64.657 35.67018014772291 139.74899543742325 64.657 35.67019476182995 139.74896090256743 64.657</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1d29288b-eab2-4f38-9d60-b5a430522852">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1d29288b-eab2-4f38-9d60-b5a430522852_0">
											<gml:posList>35.67018014772291 139.74899543742325 55.816 35.67019476182995 139.74896090256743 55.816 35.67019476182995 139.74896090256743 64.657 35.67018014772291 139.74899543742325 64.657 35.67018014772291 139.74899543742325 55.816</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f53b829b-c4c5-4172-9236-e5b66a40e2d9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f53b829b-c4c5-4172-9236-e5b66a40e2d9_0">
											<gml:posList>35.67018755665145 139.74895632596252 64.657 35.67019476182995 139.74896090256743 64.657 35.67019476182995 139.74896090256743 55.816 35.67018755665145 139.74895632596252 55.816 35.67018755665145 139.74895632596252 64.657</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-97f9309e-7538-4473-a011-2f7a367048b4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-97f9309e-7538-4473-a011-2f7a367048b4_0">
											<gml:posList>35.670187769759806 139.74899032604577 55.816 35.67019500199366 139.74899492471772 55.816 35.67019500199366 139.74899492471772 64.657 35.670187769759806 139.74899032604577 64.657 35.670187769759806 139.74899032604577 55.816</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-efe85c7a-42e4-429c-9094-fda032339795">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-efe85c7a-42e4-429c-9094-fda032339795_0">
											<gml:posList>35.67017946077033 139.74886412053263 55.816 35.67020909012936 139.74887871453487 55.816 35.67020909012936 139.74887871453487 60.189 35.67017946077033 139.74886412053263 60.189 35.67017946077033 139.74886412053263 55.816</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d45e06ae-77a8-4c57-b83d-493e20b016ed">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d45e06ae-77a8-4c57-b83d-493e20b016ed_0">
											<gml:posList>35.67020614254546 139.74896858981805 64.657 35.67019891932435 139.7489639911383 64.657 35.670187769759806 139.74899032604577 64.657 35.67019500199366 139.74899492471772 64.657 35.67020614254546 139.74896858981805 64.657</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3f6d0341-3701-45d7-80c1-e56901d389d4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3f6d0341-3701-45d7-80c1-e56901d389d4_0">
											<gml:posList>35.67019500199366 139.74899492471772 55.816 35.67020614254546 139.74896858981805 55.816 35.67020614254546 139.74896858981805 64.657 35.67019500199366 139.74899492471772 64.657 35.67019500199366 139.74899492471772 55.816</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ada316d9-597f-455e-9ff3-8b228862f21c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ada316d9-597f-455e-9ff3-8b228862f21c_0">
											<gml:posList>35.67020614254546 139.74896858981805 55.816 35.67019891932435 139.7489639911383 55.816 35.67019891932435 139.7489639911383 64.657 35.67020614254546 139.74896858981805 64.657 35.67020614254546 139.74896858981805 55.816</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bf459801-f7ba-4601-bf57-c239fc516807">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bf459801-f7ba-4601-bf57-c239fc516807_0">
											<gml:posList>35.670234445926404 139.74886610615906 60.189 35.670241984912856 139.74884540860697 60.189 35.670174893781414 139.74880413325823 60.189 35.67016360243527 139.74883389266083 60.189 35.670186235550815 139.74884621849696 60.189 35.67017946077033 139.74886412053263 60.189 35.67020909012936 139.74887871453487 60.189 35.67021627529664 139.74885475872318 60.189 35.670234445926404 139.74886610615906 60.189</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-76efa7dd-453f-4e48-a156-59bc994d8788">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-76efa7dd-453f-4e48-a156-59bc994d8788_0">
											<gml:posList>35.67020610861185 139.74889445856212 55.816 35.670200115826574 139.74890923369017 55.816 35.670200115826574 139.74890923369017 56.559 35.67020610861185 139.74889445856212 56.559 35.67020610861185 139.74889445856212 55.816</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f01a51c6-ccc7-4c0a-92c5-35b4a8fb2732">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f01a51c6-ccc7-4c0a-92c5-35b4a8fb2732_0">
											<gml:posList>35.67020760771019 139.74902712228354 57.472 35.670200032948294 139.74902251292187 57.472 35.670200032948294 139.74902251292187 55.816 35.67020760771019 139.74902712228354 55.816 35.67020760771019 139.74902712228354 57.472</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c220d8b9-ff77-4ab2-972c-65e69b2e1f4c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c220d8b9-ff77-4ab2-972c-65e69b2e1f4c_0">
											<gml:posList>35.670241984912856 139.74884540860697 55.816 35.670174893781414 139.74880413325823 55.816 35.670174893781414 139.74880413325823 60.189 35.670241984912856 139.74884540860697 60.189 35.670241984912856 139.74884540860697 55.816</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d01f03fd-f13a-4254-bbfb-1fba42e969fa">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d01f03fd-f13a-4254-bbfb-1fba42e969fa_0">
											<gml:posList>35.670200032948294 139.74902251292187 55.816 35.670200032948294 139.74902251292187 57.472 35.670224689200424 139.7489634448481 57.472 35.670224689200424 139.7489634448481 55.816 35.670200032948294 139.74902251292187 55.816</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-140e56a5-ddca-4194-bcdc-10025109df3b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-140e56a5-ddca-4194-bcdc-10025109df3b_0">
											<gml:posList>35.67020909012936 139.74887871453487 55.816 35.67021627529664 139.74885475872318 55.816 35.67021627529664 139.74885475872318 60.189 35.67020909012936 139.74887871453487 60.189 35.67020909012936 139.74887871453487 55.816</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3dd442f8-e0b7-4729-9618-203536dc9208">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3dd442f8-e0b7-4729-9618-203536dc9208_0">
											<gml:posList>35.670218203361266 139.74903357319153 57.472 35.67021015968485 139.74902867711955 57.472 35.67021015968485 139.74902867711955 55.816 35.670218203361266 139.74903357319153 55.816 35.670218203361266 139.74903357319153 57.472</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d38097c2-cb93-4f5b-bddb-c290998e6880">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d38097c2-cb93-4f5b-bddb-c290998e6880_0">
											<gml:posList>35.67020760771019 139.74902712228354 57.472 35.670232218981056 139.74896817576155 57.472 35.670224689200424 139.7489634448481 57.472 35.670200032948294 139.74902251292187 57.472 35.67020760771019 139.74902712228354 57.472</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c40d82a3-777c-4b4f-b2b4-74d345bff587">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c40d82a3-777c-4b4f-b2b4-74d345bff587_0">
											<gml:posList>35.67024602431466 139.74893716548084 55.816 35.67024602431466 139.74893716548084 56.559 35.670200115826574 139.74890923369017 56.559 35.670200115826574 139.74890923369017 55.816 35.67024602431466 139.74893716548084 55.816</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a94dfc7c-8db9-4562-a801-0e6b1a2a84d2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a94dfc7c-8db9-4562-a801-0e6b1a2a84d2_0">
											<gml:posList>35.67021627529664 139.74885475872318 55.816 35.670234445926404 139.74886610615906 55.816 35.670234445926404 139.74886610615906 60.189 35.67021627529664 139.74885475872318 60.189 35.67021627529664 139.74885475872318 55.816</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ec780543-ee5f-4657-b2c8-afa6fbdf5e16">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ec780543-ee5f-4657-b2c8-afa6fbdf5e16_0">
											<gml:posList>35.670200115826574 139.74890923369017 56.559 35.67024602431466 139.74893716548084 56.559 35.670252008097336 139.74892240140213 56.559 35.67020610861185 139.74889445856212 56.559 35.670200115826574 139.74890923369017 56.559</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-89860a7d-94df-4253-95ee-770cfd48dbff">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-89860a7d-94df-4253-95ee-770cfd48dbff_0">
											<gml:posList>35.670218203361266 139.74903357319153 57.472 35.670242760661225 139.7489747813679 57.472 35.67023476196595 139.74896976374436 57.472 35.67021015968485 139.74902867711955 57.472 35.670218203361266 139.74903357319153 57.472</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8377113a-5a24-4b9e-ae2b-2eb02290da61">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8377113a-5a24-4b9e-ae2b-2eb02290da61_0">
											<gml:posList>35.670224689200424 139.7489634448481 55.816 35.670224689200424 139.7489634448481 57.472 35.670232218981056 139.74896817576155 57.472 35.670232218981056 139.74896817576155 55.816 35.670224689200424 139.7489634448481 55.816</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-31fb4f5b-9945-46b6-9e25-3e58bb16397d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-31fb4f5b-9945-46b6-9e25-3e58bb16397d_0">
											<gml:posList>35.67020610861185 139.74889445856212 55.816 35.67020610861185 139.74889445856212 56.559 35.670252008097336 139.74892240140213 56.559 35.670252008097336 139.74892240140213 55.816 35.67020610861185 139.74889445856212 55.816</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c704683b-9306-422f-b43f-d5053ca6015c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c704683b-9306-422f-b43f-d5053ca6015c_0">
											<gml:posList>35.67023797889667 139.74904560384797 57.472 35.6702223334105 139.74903608739154 57.472 35.6702223334105 139.74903608739154 55.816 35.67023797889667 139.74904560384797 55.816 35.67023797889667 139.74904560384797 57.472</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-dfefa546-af2d-43a6-9610-6522afb8de12">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-dfefa546-af2d-43a6-9610-6522afb8de12_0">
											<gml:posList>35.670234445926404 139.74886610615906 55.816 35.670241984912856 139.74884540860697 55.816 35.670241984912856 139.74884540860697 60.189 35.670234445926404 139.74886610615906 60.189 35.670234445926404 139.74886610615906 55.816</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4ddc99fc-3088-47b0-b60c-4554ecac0963">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4ddc99fc-3088-47b0-b60c-4554ecac0963_0">
											<gml:posList>35.670242760661225 139.7489747813679 55.816 35.67023476196595 139.74896976374436 55.816 35.67023476196595 139.74896976374436 57.472 35.670242760661225 139.7489747813679 57.472 35.670242760661225 139.7489747813679 55.816</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0710cc94-05b3-4728-b87d-02e62f39f1cb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0710cc94-05b3-4728-b87d-02e62f39f1cb_0">
											<gml:posList>35.67023797889667 139.74904560384797 57.472 35.67026241021144 139.7489870993484 57.472 35.67024686370918 139.7489773508253 57.472 35.6702223334105 139.74903608739154 57.472 35.67023797889667 139.74904560384797 57.472</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-df531293-ef47-45af-92ac-ad351e659f68">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-df531293-ef47-45af-92ac-ad351e659f68_0">
											<gml:posList>35.670251573855715 139.7488687281668 55.816 35.670244249219266 139.74888660870184 55.816 35.670244249219266 139.74888660870184 56.959 35.670251573855715 139.7488687281668 56.959 35.670251573855715 139.7488687281668 55.816</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4a4ca6af-dacc-45d2-865f-aab4493bd0d2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4a4ca6af-dacc-45d2-865f-aab4493bd0d2_0">
											<gml:posList>35.67024602431466 139.74893716548084 55.816 35.670252008097336 139.74892240140213 55.816 35.670252008097336 139.74892240140213 56.559 35.67024602431466 139.74893716548084 56.559 35.67024602431466 139.74893716548084 55.816</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-590fbfc2-c2de-44a9-bc79-880f2af1e661">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-590fbfc2-c2de-44a9-bc79-880f2af1e661_0">
											<gml:posList>35.67023797889667 139.74904560384797 57.472 35.67023797889667 139.74904560384797 55.816 35.67026241021144 139.7489870993484 55.816 35.67026241021144 139.7489870993484 57.472 35.67023797889667 139.74904560384797 57.472</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-00d6d681-95f6-4bca-b6e4-c393d6ce42f2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-00d6d681-95f6-4bca-b6e4-c393d6ce42f2_0">
											<gml:posList>35.67024685039453 139.7490355645341 55.816 35.670254262932026 139.7490402072089 55.816 35.670254262932026 139.7490402072089 57.472 35.67024685039453 139.7490355645341 57.472 35.67024685039453 139.7490355645341 55.816</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6aed4f5e-08d4-441a-9797-3b11b91eb03e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6aed4f5e-08d4-441a-9797-3b11b91eb03e_0">
											<gml:posList>35.67026241021144 139.7489870993484 55.816 35.67024686370918 139.7489773508253 55.816 35.67024686370918 139.7489773508253 57.472 35.67026241021144 139.7489870993484 57.472 35.67026241021144 139.7489870993484 55.816</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ae5e3acd-e8f2-4283-9d56-2df2a1122e8e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ae5e3acd-e8f2-4283-9d56-2df2a1122e8e_0">
											<gml:posList>35.670272690800616 139.74890410913747 55.816 35.670272690800616 139.74890410913747 56.959 35.670244249219266 139.74888660870184 56.959 35.670244249219266 139.74888660870184 55.816 35.670272690800616 139.74890410913747 55.816</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0a9851d6-7b6d-48c3-8804-f3abb0a11407">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0a9851d6-7b6d-48c3-8804-f3abb0a11407_0">
											<gml:posList>35.670254262932026 139.7490402072089 57.472 35.67027352903198 139.74899407992496 57.472 35.670266116485 139.74898942620703 57.472 35.67024685039453 139.7490355645341 57.472 35.670254262932026 139.7490402072089 57.472</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-960ac0a1-55a1-4ac6-a686-9fc2685bd7e0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-960ac0a1-55a1-4ac6-a686-9fc2685bd7e0_0">
											<gml:posList>35.67028001543963 139.74888622859768 56.959 35.670251573855715 139.7488687281668 56.959 35.670244249219266 139.74888660870184 56.959 35.670272690800616 139.74890410913747 56.959 35.67028001543963 139.74888622859768 56.959</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a1f52f95-cc05-4fc0-a198-cd08cb1b6f16">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a1f52f95-cc05-4fc0-a198-cd08cb1b6f16_0">
											<gml:posList>35.67026805107903 139.7489074610354 55.816 35.670257946461 139.74893285594274 55.816 35.670257946461 139.74893285594274 56.658 35.67026805107903 139.7489074610354 56.658 35.67026805107903 139.7489074610354 55.816</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c12a46d0-a35a-4a37-9d7e-8e4dfa61ef67">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c12a46d0-a35a-4a37-9d7e-8e4dfa61ef67_0">
											<gml:posList>35.67027352903198 139.74899407992496 55.816 35.67027352903198 139.74899407992496 57.472 35.670254262932026 139.7490402072089 57.472 35.670254262932026 139.7490402072089 55.816 35.67027352903198 139.74899407992496 55.816</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1b45a5be-3697-4c59-bf42-3b42a39ab2e1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1b45a5be-3697-4c59-bf42-3b42a39ab2e1_0">
											<gml:posList>35.670251573855715 139.7488687281668 55.816 35.670251573855715 139.7488687281668 56.959 35.67028001543963 139.74888622859768 56.959 35.67028001543963 139.74888622859768 55.816 35.670251573855715 139.7488687281668 55.816</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-18462ebd-f918-425c-84e0-fc2ec3ce76ea">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-18462ebd-f918-425c-84e0-fc2ec3ce76ea_0">
											<gml:posList>35.67027352903198 139.74899407992496 55.816 35.670266116485 139.74898942620703 55.816 35.670266116485 139.74898942620703 57.472 35.67027352903198 139.74899407992496 57.472 35.67027352903198 139.74899407992496 55.816</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a50f4557-98a1-4ec9-8b49-6ad01508a1fa">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a50f4557-98a1-4ec9-8b49-6ad01508a1fa_0">
											<gml:posList>35.670257946461 139.74893285594274 55.816 35.67028992253819 139.74895195438387 55.816 35.67028992253819 139.74895195438387 56.658 35.670257946461 139.74893285594274 56.658 35.670257946461 139.74893285594274 55.816</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c359587a-7093-4e86-b76f-6999b69f3fc7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c359587a-7093-4e86-b76f-6999b69f3fc7_0">
											<gml:posList>35.67028001543963 139.74888622859768 55.816 35.67028001543963 139.74888622859768 56.959 35.670272690800616 139.74890410913747 56.959 35.670272690800616 139.74890410913747 55.816 35.67028001543963 139.74888622859768 55.816</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-79e32f7f-8b59-4a05-9fcf-708cdc45daac">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-79e32f7f-8b59-4a05-9fcf-708cdc45daac_0">
											<gml:posList>35.6702886617358 139.7489278307059 56.658 35.67029125312776 139.74892132173778 56.658 35.67026805107903 139.7489074610354 56.658 35.670257946461 139.74893285594274 56.658 35.67028992253819 139.74895195438387 56.658 35.67029743576794 139.74893306843742 56.658 35.6702886617358 139.7489278307059 56.658</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1b78f9aa-2099-4b8c-837e-1b9030e2c90a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1b78f9aa-2099-4b8c-837e-1b9030e2c90a_0">
											<gml:posList>35.670269597830455 139.74901808755064 55.816 35.67028725386582 139.74902829780865 55.816 35.67028725386582 139.74902829780865 57.12 35.670269597830455 139.74901808755064 57.12 35.670269597830455 139.74901808755064 55.816</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4adc1001-40c5-4670-a14a-ab238da9930f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4adc1001-40c5-4670-a14a-ab238da9930f_0">
											<gml:posList>35.67029125312776 139.74892132173778 55.816 35.67026805107903 139.7489074610354 55.816 35.67026805107903 139.7489074610354 56.658 35.67029125312776 139.74892132173778 56.658 35.67029125312776 139.74892132173778 55.816</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6192af65-a271-4820-9df6-ac46d9aa9d39">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6192af65-a271-4820-9df6-ac46d9aa9d39_0">
											<gml:posList>35.670269597830455 139.74901808755064 57.12 35.67028725386582 139.74902829780865 57.12 35.67029536948774 139.74900721303297 57.12 35.670277713458354 139.7489970138248 57.12 35.670269597830455 139.74901808755064 57.12</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e851f1d8-a1d7-4506-8fbe-e4d9a61484ea">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e851f1d8-a1d7-4506-8fbe-e4d9a61484ea_0">
											<gml:posList>35.670277713458354 139.7489970138248 57.12 35.67029536948774 139.74900721303297 57.12 35.67029536948774 139.74900721303297 55.816 35.670277713458354 139.7489970138248 55.816 35.670277713458354 139.7489970138248 57.12</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-109becc1-4fbe-432b-8687-19d03fdb2cb1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-109becc1-4fbe-432b-8687-19d03fdb2cb1_0">
											<gml:posList>35.6702886617358 139.7489278307059 55.816 35.67029125312776 139.74892132173778 55.816 35.67029125312776 139.74892132173778 56.658 35.6702886617358 139.7489278307059 56.658 35.6702886617358 139.7489278307059 55.816</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0b65f9a8-bfa3-45ef-ae63-7e0d5b4832b8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0b65f9a8-bfa3-45ef-ae63-7e0d5b4832b8_0">
											<gml:posList>35.67028725386582 139.74902829780865 55.816 35.67029536948774 139.74900721303297 55.816 35.67029536948774 139.74900721303297 57.12 35.67028725386582 139.74902829780865 57.12 35.67028725386582 139.74902829780865 55.816</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6cead58f-a35c-4f38-80e0-3904bf06c919">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6cead58f-a35c-4f38-80e0-3904bf06c919_0">
											<gml:posList>35.67029743576794 139.74893306843742 55.816 35.6702886617358 139.7489278307059 55.816 35.6702886617358 139.7489278307059 56.658 35.67029743576794 139.74893306843742 56.658 35.67029743576794 139.74893306843742 55.816</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f9f17638-af7c-4c10-aeda-8075c4b658cb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f9f17638-af7c-4c10-aeda-8075c4b658cb_0">
											<gml:posList>35.6702907595746 139.74897591281473 55.816 35.67029834349892 139.74898073204625 55.816 35.67029834349892 139.74898073204625 57.472 35.6702907595746 139.74897591281473 57.472 35.6702907595746 139.74897591281473 55.816</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f62d474d-a2c5-414b-9bc8-f24334138613">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f62d474d-a2c5-414b-9bc8-f24334138613_0">
											<gml:posList>35.670297888212815 139.74902564657341 55.816 35.670297888212815 139.74902564657341 57.12 35.670302189069695 139.74901463998648 57.12 35.670302189069695 139.74901463998648 55.816 35.670297888212815 139.74902564657341 55.816</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c9203915-2beb-45d6-a6f6-2a296af1416c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c9203915-2beb-45d6-a6f6-2a296af1416c_0">
											<gml:posList>35.670315299445825 139.74891801568492 55.816 35.6702907595746 139.74897591281473 55.816 35.6702907595746 139.74897591281473 57.472 35.670315299445825 139.74891801568492 57.472 35.670315299445825 139.74891801568492 55.816</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1e27b8a1-f094-47c6-9033-b4b9f3b4b3ab">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1e27b8a1-f094-47c6-9033-b4b9f3b4b3ab_0">
											<gml:posList>35.670297888212815 139.74902564657341 57.12 35.67031088188172 139.7490197452588 57.12 35.670302189069695 139.74901463998648 57.12 35.670297888212815 139.74902564657341 57.12</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e9791d65-554d-451e-b755-3c7c4da0f764">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e9791d65-554d-451e-b755-3c7c4da0f764_0">
											<gml:posList>35.67031088188172 139.7490197452588 57.12 35.670297888212815 139.74902564657341 57.12 35.670297888212815 139.74902564657341 55.816 35.67031088188172 139.7490197452588 55.816 35.67031088188172 139.7490197452588 57.12</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0e8251f6-f97b-432c-bc3c-ef7ecfd87119">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0e8251f6-f97b-432c-bc3c-ef7ecfd87119_0">
											<gml:posList>35.67032190250253 139.74892515565807 57.472 35.670315299445825 139.74891801568492 57.472 35.6702907595746 139.74897591281473 57.472 35.67029834349892 139.74898073204625 57.472 35.67032190250253 139.74892515565807 57.472</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-37c09105-40d0-4e97-b8fd-73d77a4abfee">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-37c09105-40d0-4e97-b8fd-73d77a4abfee_0">
											<gml:posList>35.67031088188172 139.7490197452588 57.12 35.67031088188172 139.7490197452588 55.816 35.670302189069695 139.74901463998648 55.816 35.670302189069695 139.74901463998648 57.12 35.67031088188172 139.7490197452588 57.12</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-322ddeb0-3be1-4284-a14e-69878d1c0c3c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-322ddeb0-3be1-4284-a14e-69878d1c0c3c_0">
											<gml:posList>35.6703011840913 139.7489825406427 55.816 35.67031802024427 139.74899327093314 55.816 35.67031802024427 139.74899327093314 57.472 35.6703011840913 139.7489825406427 57.472 35.6703011840913 139.7489825406427 55.816</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-30e795ce-d8b2-435b-a138-31460a9a23a5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-30e795ce-d8b2-435b-a138-31460a9a23a5_0">
											<gml:posList>35.67032190250253 139.74892515565807 57.472 35.67032190250253 139.74892515565807 55.816 35.670315299445825 139.74891801568492 55.816 35.670315299445825 139.74891801568492 57.472 35.67032190250253 139.74892515565807 57.472</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c1aca328-0e20-4113-a44b-ea91524dde9c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c1aca328-0e20-4113-a44b-ea91524dde9c_0">
											<gml:posList>35.670339041579254 139.74894368427613 57.472 35.670324374136975 139.74892782624914 57.472 35.6703011840913 139.7489825406427 57.472 35.67031802024427 139.74899327093314 57.472 35.670339041579254 139.74894368427613 57.472</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-deb35248-79c4-44f2-be1c-638b25b4a429">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-deb35248-79c4-44f2-be1c-638b25b4a429_0">
											<gml:posList>35.670339041579254 139.74894368427613 57.472 35.67031802024427 139.74899327093314 57.472 35.67031802024427 139.74899327093314 55.816 35.670339041579254 139.74894368427613 55.816 35.670339041579254 139.74894368427613 57.472</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7fc68f47-a18c-4aa9-aae2-9cb43b551a61">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7fc68f47-a18c-4aa9-aae2-9cb43b551a61_0">
											<gml:posList>35.670324374136975 139.74892782624914 57.472 35.670339041579254 139.74894368427613 57.472 35.670339041579254 139.74894368427613 55.816 35.670324374136975 139.74892782624914 55.816 35.670324374136975 139.74892782624914 57.472</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-7d8bfdfd-064e-4797-8e93-72cc07ff391f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7d8bfdfd-064e-4797-8e93-72cc07ff391f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7d8bfdfd-064e-4797-8e93-72cc07ff391f">
											<gml:posList>35.67011653232753 139.74876912302577 6.65 35.67010205910009 139.74876031235937 6.65 35.67012031630134 139.7487152465982 6.65 35.67014239135433 139.7487286776058 6.65 35.670185448125785 139.74875174089226 6.65 35.67019205156668 139.7487337506567 6.65 35.670377316187114 139.74893411106854 6.65 35.67033669049481 139.74904878081387 6.65 35.67024298646783 139.74909131897672 6.65 35.66999491298946 139.74894034600038 6.65 35.67007399171047 139.74877509971247 6.65 35.67010616645669 139.7487946838713 6.65 35.67011653232753 139.74876912302577 6.65</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-26ed7b0b-27b7-4846-8699-6f67a0077d3e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-26ed7b0b-27b7-4846-8699-6f67a0077d3e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-26ed7b0b-27b7-4846-8699-6f67a0077d3e">
											<gml:posList>35.67007399171047 139.74877509971247 66.735 35.66999491298946 139.74894034600038 66.735 35.67003873555538 139.74892434914253 66.735 35.670086186401065 139.7488251925044 66.735 35.67007399171047 139.74877509971247 66.735</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-0ce4ad7c-e6bb-4950-a8a3-9b0efbc90bc1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0ce4ad7c-e6bb-4950-a8a3-9b0efbc90bc1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0ce4ad7c-e6bb-4950-a8a3-9b0efbc90bc1">
											<gml:posList>35.67010616645669 139.7487946838713 66.735 35.67007399171047 139.74877509971247 66.735 35.670086186401065 139.7488251925044 66.735 35.67012023679999 139.74884592351714 66.735 35.67010616645669 139.7487946838713 66.735</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-0d7f0d5d-31b0-4712-9cda-08dccb8dbbdc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0d7f0d5d-31b0-4712-9cda-08dccb8dbbdc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0d7f0d5d-31b0-4712-9cda-08dccb8dbbdc">
											<gml:posList>35.670134789532035 139.74872405725847 52.1 35.67012031630134 139.7487152465982 52.1 35.67010205910009 139.74876031235937 52.1 35.67011653232753 139.74876912302577 52.1 35.670134789532035 139.74872405725847 52.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-1b155e9c-22b9-4b93-bdd0-9761527648d0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1b155e9c-22b9-4b93-bdd0-9761527648d0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1b155e9c-22b9-4b93-bdd0-9761527648d0">
											<gml:posList>35.67024298646783 139.74909131897672 66.735 35.67024478716629 139.74904975007755 66.735 35.67003873555538 139.74892434914253 66.735 35.66999491298946 139.74894034600038 66.735 35.67024298646783 139.74909131897672 66.735</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-5401003d-e3ce-47b3-8919-d1fedf0db130">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5401003d-e3ce-47b3-8919-d1fedf0db130">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5401003d-e3ce-47b3-8919-d1fedf0db130">
											<gml:posList>35.67010616645669 139.7487946838713 66.735 35.67012023679999 139.74884592351714 66.735 35.670149336802744 139.74877411446073 66.735 35.670134789532035 139.74872405725847 66.735 35.67010616645669 139.7487946838713 66.735</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-16fb9670-49a1-4c00-acec-676c2d268c44">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-16fb9670-49a1-4c00-acec-676c2d268c44">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-16fb9670-49a1-4c00-acec-676c2d268c44">
											<gml:posList>35.67014239135433 139.7487286776058 66.735 35.670134789532035 139.74872405725847 66.735 35.670149336802744 139.74877411446073 66.735 35.67014239135433 139.7487286776058 66.735</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-df750ff0-fc20-4c12-9ad1-f8238a2277fb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-df750ff0-fc20-4c12-9ad1-f8238a2277fb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-df750ff0-fc20-4c12-9ad1-f8238a2277fb">
											<gml:posList>35.670185448125785 139.74875174089226 66.735 35.67014239135433 139.7487286776058 66.735 35.670149336802744 139.74877411446073 66.735 35.67020123035055 139.7488019183378 66.735 35.670185448125785 139.74875174089226 66.735</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d9a67342-0c92-4d3a-889a-4d26673b08ff">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d9a67342-0c92-4d3a-889a-4d26673b08ff">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d9a67342-0c92-4d3a-889a-4d26673b08ff">
											<gml:posList>35.67020123035055 139.7488019183378 55.816 35.670149336802744 139.74877411446073 55.816 35.67012023679999 139.74884592351714 55.816 35.670086186401065 139.7488251925044 55.816 35.67003873555538 139.74892434914253 55.816 35.67024478716629 139.74904975007755 55.816 35.670313386900574 139.7490186048607 55.816 35.67033968204144 139.74894437951605 55.816 35.670203137607736 139.74879671354986 55.816 35.67020123035055 139.7488019183378 55.816</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-4d75e14f-e554-4cf5-9eec-f8c8e9cfa792">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4d75e14f-e554-4cf5-9eec-f8c8e9cfa792">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4d75e14f-e554-4cf5-9eec-f8c8e9cfa792">
											<gml:posList>35.670185448125785 139.74875174089226 66.735 35.67020123035055 139.7488019183378 66.735 35.670203137607736 139.74879671354986 66.735 35.67019205156668 139.7487337506567 66.735 35.670185448125785 139.74875174089226 66.735</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-5df650ac-c6bf-436b-b64f-974c231a2c9e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5df650ac-c6bf-436b-b64f-974c231a2c9e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5df650ac-c6bf-436b-b64f-974c231a2c9e">
											<gml:posList>35.670377316187114 139.74893411106854 66.735 35.67019205156668 139.7487337506567 66.735 35.670203137607736 139.74879671354986 66.735 35.67033968204144 139.74894437951605 66.735 35.670377316187114 139.74893411106854 66.735</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-68550d63-d414-4693-9459-6c2d0619f714">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-68550d63-d414-4693-9459-6c2d0619f714">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-68550d63-d414-4693-9459-6c2d0619f714">
											<gml:posList>35.67033669049481 139.74904878081387 66.735 35.670313386900574 139.7490186048607 66.735 35.67024478716629 139.74904975007755 66.735 35.67024298646783 139.74909131897672 66.735 35.67033669049481 139.74904878081387 66.735</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d60d40eb-cd69-4c29-b16a-a412d9e447dc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d60d40eb-cd69-4c29-b16a-a412d9e447dc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d60d40eb-cd69-4c29-b16a-a412d9e447dc">
											<gml:posList>35.67033669049481 139.74904878081387 66.735 35.670377316187114 139.74893411106854 66.735 35.67033968204144 139.74894437951605 66.735 35.670313386900574 139.7490186048607 66.735 35.67033669049481 139.74904878081387 66.735</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-af56486a-5df5-430d-85d2-429dc7b504ba">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-af56486a-5df5-430d-85d2-429dc7b504ba">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-af56486a-5df5-430d-85d2-429dc7b504ba">
											<gml:posList>35.67020123035055 139.7488019183378 66.735 35.67020123035055 139.7488019183378 55.816 35.670203137607736 139.74879671354986 55.816 35.670203137607736 139.74879671354986 66.735 35.67020123035055 139.7488019183378 66.735</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3a965802-f8a7-45e0-835a-cf3111e9304f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3a965802-f8a7-45e0-835a-cf3111e9304f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3a965802-f8a7-45e0-835a-cf3111e9304f">
											<gml:posList>35.670203137607736 139.74879671354986 66.735 35.670203137607736 139.74879671354986 55.816 35.67033968204144 139.74894437951605 55.816 35.67033968204144 139.74894437951605 66.735 35.670203137607736 139.74879671354986 66.735</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-81ab014c-69cc-444b-a482-9a9aee42f228">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-81ab014c-69cc-444b-a482-9a9aee42f228">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-81ab014c-69cc-444b-a482-9a9aee42f228">
											<gml:posList>35.670134789532035 139.74872405725847 52.1 35.670134789532035 139.74872405725847 66.735 35.67014239135433 139.7487286776058 66.735 35.67014239135433 139.7487286776058 6.65 35.67012031630134 139.7487152465982 6.65 35.67012031630134 139.7487152465982 52.1 35.670134789532035 139.74872405725847 52.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-61875039-368b-43ec-bee1-642ee8d9c806">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-61875039-368b-43ec-bee1-642ee8d9c806">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-61875039-368b-43ec-bee1-642ee8d9c806">
											<gml:posList>35.67012031630134 139.7487152465982 6.65 35.67010205910009 139.74876031235937 6.65 35.67010205910009 139.74876031235937 52.1 35.67012031630134 139.7487152465982 52.1 35.67012031630134 139.7487152465982 6.65</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2e351c48-0cbb-4829-b4a6-aa593c050b26">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2e351c48-0cbb-4829-b4a6-aa593c050b26">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2e351c48-0cbb-4829-b4a6-aa593c050b26">
											<gml:posList>35.670185448125785 139.74875174089226 6.65 35.67014239135433 139.7487286776058 6.65 35.67014239135433 139.7487286776058 66.735 35.670185448125785 139.74875174089226 66.735 35.670185448125785 139.74875174089226 6.65</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f4d8c291-9cd2-48df-b380-2c8b540ecb56">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f4d8c291-9cd2-48df-b380-2c8b540ecb56">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f4d8c291-9cd2-48df-b380-2c8b540ecb56">
											<gml:posList>35.67019205156668 139.7487337506567 6.65 35.670185448125785 139.74875174089226 6.65 35.670185448125785 139.74875174089226 66.735 35.67019205156668 139.7487337506567 66.735 35.67019205156668 139.7487337506567 6.65</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a116ffeb-e7ff-45d1-b6fb-d87a046f2f29">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a116ffeb-e7ff-45d1-b6fb-d87a046f2f29">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a116ffeb-e7ff-45d1-b6fb-d87a046f2f29">
											<gml:posList>35.67010616645669 139.7487946838713 66.735 35.670134789532035 139.74872405725847 66.735 35.670134789532035 139.74872405725847 52.1 35.67011653232753 139.74876912302577 52.1 35.67011653232753 139.74876912302577 6.65 35.67010616645669 139.7487946838713 6.65 35.67010616645669 139.7487946838713 66.735</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-809e961d-053f-4bd5-908b-ce7aaf01d1b5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-809e961d-053f-4bd5-908b-ce7aaf01d1b5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-809e961d-053f-4bd5-908b-ce7aaf01d1b5">
											<gml:posList>35.67010205910009 139.74876031235937 6.65 35.67011653232753 139.74876912302577 6.65 35.67011653232753 139.74876912302577 52.1 35.67010205910009 139.74876031235937 52.1 35.67010205910009 139.74876031235937 6.65</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f2e0da0a-ab2c-4d27-8392-7e7b401def02">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f2e0da0a-ab2c-4d27-8392-7e7b401def02">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f2e0da0a-ab2c-4d27-8392-7e7b401def02">
											<gml:posList>35.67010616645669 139.7487946838713 6.65 35.67007399171047 139.74877509971247 6.65 35.67007399171047 139.74877509971247 66.735 35.67010616645669 139.7487946838713 66.735 35.67010616645669 139.7487946838713 6.65</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b830954f-e619-439f-bc24-e68a2f2306cb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b830954f-e619-439f-bc24-e68a2f2306cb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b830954f-e619-439f-bc24-e68a2f2306cb">
											<gml:posList>35.670149336802744 139.74877411446073 66.735 35.670149336802744 139.74877411446073 55.816 35.67020123035055 139.7488019183378 55.816 35.67020123035055 139.7488019183378 66.735 35.670149336802744 139.74877411446073 66.735</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-52bfb742-71c2-493d-b4eb-ad36737201d3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-52bfb742-71c2-493d-b4eb-ad36737201d3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-52bfb742-71c2-493d-b4eb-ad36737201d3">
											<gml:posList>35.67012023679999 139.74884592351714 66.735 35.67012023679999 139.74884592351714 55.816 35.670149336802744 139.74877411446073 55.816 35.670149336802744 139.74877411446073 66.735 35.67012023679999 139.74884592351714 66.735</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1008b36c-ecb3-4861-9b0a-74cc78263487">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1008b36c-ecb3-4861-9b0a-74cc78263487">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1008b36c-ecb3-4861-9b0a-74cc78263487">
											<gml:posList>35.670377316187114 139.74893411106854 6.65 35.67019205156668 139.7487337506567 6.65 35.67019205156668 139.7487337506567 66.735 35.670377316187114 139.74893411106854 66.735 35.670377316187114 139.74893411106854 6.65</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3dd5ce45-f24c-4972-b92e-dbafe61bd2aa">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3dd5ce45-f24c-4972-b92e-dbafe61bd2aa">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3dd5ce45-f24c-4972-b92e-dbafe61bd2aa">
											<gml:posList>35.670086186401065 139.7488251925044 66.735 35.670086186401065 139.7488251925044 55.816 35.67012023679999 139.74884592351714 55.816 35.67012023679999 139.74884592351714 66.735 35.670086186401065 139.7488251925044 66.735</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1cf274a7-e4c5-4e6f-a000-cf83ab159b58">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1cf274a7-e4c5-4e6f-a000-cf83ab159b58">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1cf274a7-e4c5-4e6f-a000-cf83ab159b58">
											<gml:posList>35.67007399171047 139.74877509971247 6.65 35.66999491298946 139.74894034600038 6.65 35.66999491298946 139.74894034600038 66.735 35.67007399171047 139.74877509971247 66.735 35.67007399171047 139.74877509971247 6.65</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e30a5015-c62a-4ea8-ab27-c39880d90936">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e30a5015-c62a-4ea8-ab27-c39880d90936">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e30a5015-c62a-4ea8-ab27-c39880d90936">
											<gml:posList>35.67003873555538 139.74892434914253 66.735 35.67003873555538 139.74892434914253 55.816 35.670086186401065 139.7488251925044 55.816 35.670086186401065 139.7488251925044 66.735 35.67003873555538 139.74892434914253 66.735</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b1b210a0-41f2-4c79-a781-0c0952421e81">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b1b210a0-41f2-4c79-a781-0c0952421e81">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b1b210a0-41f2-4c79-a781-0c0952421e81">
											<gml:posList>35.67033968204144 139.74894437951605 66.735 35.67033968204144 139.74894437951605 55.816 35.670313386900574 139.7490186048607 55.816 35.670313386900574 139.7490186048607 66.735 35.67033968204144 139.74894437951605 66.735</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-eec7d452-db05-46f4-b0ef-4f6838f33be2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-eec7d452-db05-46f4-b0ef-4f6838f33be2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-eec7d452-db05-46f4-b0ef-4f6838f33be2">
											<gml:posList>35.67024478716629 139.74904975007755 66.735 35.67024478716629 139.74904975007755 55.816 35.67003873555538 139.74892434914253 55.816 35.67003873555538 139.74892434914253 66.735 35.67024478716629 139.74904975007755 66.735</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2a3b69cf-8bd2-412a-a7fe-9831479d1655">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2a3b69cf-8bd2-412a-a7fe-9831479d1655">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2a3b69cf-8bd2-412a-a7fe-9831479d1655">
											<gml:posList>35.67033669049481 139.74904878081387 6.65 35.670377316187114 139.74893411106854 6.65 35.670377316187114 139.74893411106854 66.735 35.67033669049481 139.74904878081387 66.735 35.67033669049481 139.74904878081387 6.65</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3a20d197-84a7-4cb9-a22c-3bd79c1871ac">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3a20d197-84a7-4cb9-a22c-3bd79c1871ac">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3a20d197-84a7-4cb9-a22c-3bd79c1871ac">
											<gml:posList>35.66999491298946 139.74894034600038 6.65 35.67024298646783 139.74909131897672 6.65 35.67024298646783 139.74909131897672 66.735 35.66999491298946 139.74894034600038 66.735 35.66999491298946 139.74894034600038 6.65</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b4450cbe-7af0-4254-b3e3-2515b03400b2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b4450cbe-7af0-4254-b3e3-2515b03400b2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b4450cbe-7af0-4254-b3e3-2515b03400b2">
											<gml:posList>35.670313386900574 139.7490186048607 66.735 35.670313386900574 139.7490186048607 55.816 35.67024478716629 139.74904975007755 55.816 35.67024478716629 139.74904975007755 66.735 35.670313386900574 139.7490186048607 66.735</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-035ffc0a-208c-4ab8-a6b4-9150c3d6fd62">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-035ffc0a-208c-4ab8-a6b4-9150c3d6fd62">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-035ffc0a-208c-4ab8-a6b4-9150c3d6fd62">
											<gml:posList>35.67024298646783 139.74909131897672 6.65 35.67033669049481 139.74904878081387 6.65 35.67033669049481 139.74904878081387 66.735 35.67024298646783 139.74909131897672 66.735 35.67024298646783 139.74909131897672 6.65</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区虎ノ門一丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-8098</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">848.6644</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1210</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>8</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>