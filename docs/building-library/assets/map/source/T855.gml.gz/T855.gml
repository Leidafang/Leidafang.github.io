<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_f5343d0c-ae37-47a4-b5f4-72b7baa79378">
			<core:creationDate>2024-03-15</core:creationDate>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3001</bldg:class>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.669970738584304 139.74708367028572 0 35.66998679852055 139.74710530357333 0 35.67001021545534 139.74707909887402 0 35.6699941555936 139.74705757604735 0 35.669970738584304 139.74708367028572 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669970738584304 139.74708367028572 5.88 35.6699941555936 139.74705757604735 5.88 35.67001021545534 139.74707909887402 5.88 35.66998679852055 139.74710530357333 5.88 35.669970738584304 139.74708367028572 5.88</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669970738584304 139.74708367028572 5.88 35.66998679852055 139.74710530357333 5.88 35.66998679852055 139.74710530357333 8.879999999999999 35.669970738584304 139.74708367028572 8.879999999999999 35.669970738584304 139.74708367028572 5.88</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66998679852055 139.74710530357333 5.88 35.67001021545534 139.74707909887402 5.88 35.67001021545534 139.74707909887402 8.879999999999999 35.66998679852055 139.74710530357333 8.879999999999999 35.66998679852055 139.74710530357333 5.88</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67001021545534 139.74707909887402 5.88 35.6699941555936 139.74705757604735 5.88 35.6699941555936 139.74705757604735 8.879999999999999 35.67001021545534 139.74707909887402 8.879999999999999 35.67001021545534 139.74707909887402 5.88</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6699941555936 139.74705757604735 5.88 35.669970738584304 139.74708367028572 5.88 35.669970738584304 139.74708367028572 8.879999999999999 35.6699941555936 139.74705757604735 8.879999999999999 35.6699941555936 139.74705757604735 5.88</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669970738584304 139.74708367028572 8.879999999999999 35.66998679852055 139.74710530357333 8.879999999999999 35.67001021545534 139.74707909887402 8.879999999999999 35.6699941555936 139.74705757604735 8.879999999999999 35.669970738584304 139.74708367028572 8.879999999999999</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-a5c82905-e18d-4baa-aabe-85095bfdff44"/>
							<gml:surfaceMember xlink:href="#poly-2801df44-b9b2-4873-b1c1-c94ebcd8467a"/>
							<gml:surfaceMember xlink:href="#poly-67b6460a-e013-4f68-9dc1-d24580ee05fc"/>
							<gml:surfaceMember xlink:href="#poly-2d8b5122-3f9d-4730-9663-1bc52b669369"/>
							<gml:surfaceMember xlink:href="#poly-4e6ce78e-21ec-425b-a6a2-14279b20b144"/>
							<gml:surfaceMember xlink:href="#poly-64eb46ba-7728-4638-ab14-0fc912fd5fae"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-a5c82905-e18d-4baa-aabe-85095bfdff44">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a5c82905-e18d-4baa-aabe-85095bfdff44">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a5c82905-e18d-4baa-aabe-85095bfdff44">
											<gml:posList>35.669970738584276 139.74708367028572 5.88 35.6699941555936 139.74705757604735 5.88 35.670010215455335 139.747079098874 5.88 35.66998679852051 139.74710530357333 5.88 35.669970738584276 139.74708367028572 5.88</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-2801df44-b9b2-4873-b1c1-c94ebcd8467a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2801df44-b9b2-4873-b1c1-c94ebcd8467a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2801df44-b9b2-4873-b1c1-c94ebcd8467a">
											<gml:posList>35.6699941555936 139.74705757604735 8.4 35.669970738584276 139.74708367028572 8.4 35.66998679852051 139.74710530357333 8.4 35.670010215455335 139.747079098874 8.4 35.6699941555936 139.74705757604735 8.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-67b6460a-e013-4f68-9dc1-d24580ee05fc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-67b6460a-e013-4f68-9dc1-d24580ee05fc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-67b6460a-e013-4f68-9dc1-d24580ee05fc">
											<gml:posList>35.6699941555936 139.74705757604735 5.88 35.669970738584276 139.74708367028572 5.88 35.669970738584276 139.74708367028572 8.4 35.6699941555936 139.74705757604735 8.4 35.6699941555936 139.74705757604735 5.88</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2d8b5122-3f9d-4730-9663-1bc52b669369">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2d8b5122-3f9d-4730-9663-1bc52b669369">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2d8b5122-3f9d-4730-9663-1bc52b669369">
											<gml:posList>35.669970738584276 139.74708367028572 5.88 35.66998679852051 139.74710530357333 5.88 35.66998679852051 139.74710530357333 8.4 35.669970738584276 139.74708367028572 8.4 35.669970738584276 139.74708367028572 5.88</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4e6ce78e-21ec-425b-a6a2-14279b20b144">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4e6ce78e-21ec-425b-a6a2-14279b20b144">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4e6ce78e-21ec-425b-a6a2-14279b20b144">
											<gml:posList>35.670010215455335 139.747079098874 5.88 35.6699941555936 139.74705757604735 5.88 35.6699941555936 139.74705757604735 8.4 35.670010215455335 139.747079098874 8.4 35.670010215455335 139.747079098874 5.88</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-64eb46ba-7728-4638-ab14-0fc912fd5fae">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-64eb46ba-7728-4638-ab14-0fc912fd5fae">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-64eb46ba-7728-4638-ab14-0fc912fd5fae">
											<gml:posList>35.66998679852051 139.74710530357333 5.88 35.670010215455335 139.747079098874 5.88 35.670010215455335 139.747079098874 8.4 35.66998679852051 139.74710530357333 8.4 35.66998679852051 139.74710530357333 5.88</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13101-bldg-759</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13101</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>7</uro:specifiedFloorAreaRate>
					<uro:surveyYear>0001</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.01</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">0</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>