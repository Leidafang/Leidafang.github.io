<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_f5956a68-6714-4527-aaf0-5254c2e51d63">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">402</bldg:usage>
			<bldg:measuredHeight uom="m">19.4</bldg:measuredHeight>
			<bldg:storeysAboveGround>6</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.67195360859099 139.73814979818508 0 35.67201199292727 139.73834690860963 0 35.672077226982516 139.73831479649215 0 35.67201974614981 139.738120446479 0 35.67195360859099 139.73814979818508 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67195360859099 139.73814979818508 9.86 35.67201974614981 139.738120446479 9.86 35.672077226982516 139.73831479649215 9.86 35.67201199292727 139.73834690860963 9.86 35.67195360859099 139.73814979818508 9.86</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67195360859099 139.73814979818508 9.86 35.67201199292727 139.73834690860963 9.86 35.67201199292727 139.73834690860963 29.22 35.67195360859099 139.73814979818508 29.22 35.67195360859099 139.73814979818508 9.86</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67201199292727 139.73834690860963 9.86 35.672077226982516 139.73831479649215 9.86 35.672077226982516 139.73831479649215 29.22 35.67201199292727 139.73834690860963 29.22 35.67201199292727 139.73834690860963 9.86</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672077226982516 139.73831479649215 9.86 35.67201974614981 139.738120446479 9.86 35.67201974614981 139.738120446479 29.22 35.672077226982516 139.73831479649215 29.22 35.672077226982516 139.73831479649215 9.86</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67201974614981 139.738120446479 9.86 35.67195360859099 139.73814979818508 9.86 35.67195360859099 139.73814979818508 29.22 35.67201974614981 139.738120446479 29.22 35.67201974614981 139.738120446479 9.86</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67195360859099 139.73814979818508 29.22 35.67201199292727 139.73834690860963 29.22 35.672077226982516 139.73831479649215 29.22 35.67201974614981 139.738120446479 29.22 35.67195360859099 139.73814979818508 29.22</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-15813d26-f412-455b-a533-e507fa4f012d"/>
							<gml:surfaceMember xlink:href="#poly-a1607173-e378-428b-b405-fdd3bc9c9e64"/>
							<gml:surfaceMember xlink:href="#poly-81639fa3-110c-4279-9134-f1394e5434f4"/>
							<gml:surfaceMember xlink:href="#poly-53bd6ff2-4143-445e-badb-93f2d25b8d58"/>
							<gml:surfaceMember xlink:href="#poly-bb8e7528-4dd3-4170-9c9c-36204931d084"/>
							<gml:surfaceMember xlink:href="#poly-c9f165ac-efc5-4f55-9c4c-361fa5b0864a"/>
							<gml:surfaceMember xlink:href="#poly-1fcc95a4-abda-4b61-a59d-7e1674f7d4ee"/>
							<gml:surfaceMember xlink:href="#poly-3f6e16c1-c300-4fb4-bc33-7f9a86c51616"/>
							<gml:surfaceMember xlink:href="#poly-ddceb11c-48d8-4ce0-89b3-78cc4b0aa1be"/>
							<gml:surfaceMember xlink:href="#poly-a139c6a1-259b-4371-be32-02885db627bf"/>
							<gml:surfaceMember xlink:href="#poly-df23bebb-d0dd-4cb1-8423-107464d052be"/>
							<gml:surfaceMember xlink:href="#poly-7d90b189-b938-49fc-ba41-50d0522364c0"/>
							<gml:surfaceMember xlink:href="#poly-df6014f6-e4a7-4811-84d7-bf3f1d83f2f7"/>
							<gml:surfaceMember xlink:href="#poly-5ed2fc09-5d8e-4490-8d2e-c11929090ca3"/>
							<gml:surfaceMember xlink:href="#poly-2ad09cfa-944e-42b2-a9ae-4389813b3124"/>
							<gml:surfaceMember xlink:href="#poly-6eae1111-16c3-41c1-acac-362c8f8d1298"/>
							<gml:surfaceMember xlink:href="#poly-e91c6fad-71da-477e-99ba-db1a50d4b65b"/>
							<gml:surfaceMember xlink:href="#poly-8e049a6e-dc9b-45ff-bec2-a0f94995ef03"/>
							<gml:surfaceMember xlink:href="#poly-d4d2d7e0-c07b-4721-a718-e4efea8cd328"/>
							<gml:surfaceMember xlink:href="#poly-34fa7a76-8ab5-42c2-9093-b72626d80b7c"/>
							<gml:surfaceMember xlink:href="#poly-086ea57c-a99d-4bc5-b3d4-ca0ed714814b"/>
							<gml:surfaceMember xlink:href="#poly-666cd10d-3c00-477a-8aef-c7728819a85d"/>
							<gml:surfaceMember xlink:href="#poly-aa994b51-998b-4a8d-82f1-f1c8c332a1c3"/>
							<gml:surfaceMember xlink:href="#poly-c76a5586-00aa-4f77-9848-704ded349dab"/>
							<gml:surfaceMember xlink:href="#poly-ff2f1cc6-44af-4571-8cfc-d752c37aa728"/>
							<gml:surfaceMember xlink:href="#poly-db4db552-2ef3-4689-a562-e85dd321b7f5"/>
							<gml:surfaceMember xlink:href="#poly-06e840cb-6e81-4a32-8b2e-78b8fae5f05b"/>
							<gml:surfaceMember xlink:href="#poly-fbf34ae2-6d1e-458e-9319-cb3edf9e8267"/>
							<gml:surfaceMember xlink:href="#poly-296401fb-e343-456a-a37d-9c3f1bb0241a"/>
							<gml:surfaceMember xlink:href="#poly-c543a3b4-2483-4c2d-88a1-b93df8a13090"/>
							<gml:surfaceMember xlink:href="#poly-09e5b31e-8b68-4838-9406-9b3013ff350f"/>
							<gml:surfaceMember xlink:href="#poly-9ed61c5d-4eef-4846-a4b1-30f40a82534f"/>
							<gml:surfaceMember xlink:href="#poly-e45d596e-ac27-424f-8904-b0902336ce43"/>
							<gml:surfaceMember xlink:href="#poly-a1d7515d-f6c9-48df-a2dd-d5d0d660f45f"/>
							<gml:surfaceMember xlink:href="#poly-40f819c3-b9c9-457d-b0a7-9818ade7cfbc"/>
							<gml:surfaceMember xlink:href="#poly-736e9152-9b3b-4dd5-bf5f-4ba0bca38a9b"/>
							<gml:surfaceMember xlink:href="#poly-c0886cea-213b-4e8d-8226-b64db4dcf994"/>
							<gml:surfaceMember xlink:href="#poly-f3ce7178-b064-48e9-875a-2484d9a426fc"/>
							<gml:surfaceMember xlink:href="#poly-92bde449-7e52-4725-aee6-a267c14db705"/>
							<gml:surfaceMember xlink:href="#poly-b019e39e-f04d-4447-baa4-b159b7859068"/>
							<gml:surfaceMember xlink:href="#poly-67dee024-085d-43b5-bf6c-780a1cf785ec"/>
							<gml:surfaceMember xlink:href="#poly-9fc5aeae-f59b-4d33-b86e-2b84db7cdac9"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_f5956a68-6714-4527-aaf0-5254c2e51d63_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-68d86221-d787-4ba5-abf7-75489c7bd885">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67202558616896 139.73818775682855 33.364 35.672006510810284 139.73819624107256 33.364 35.6720059775869 139.73819445217504 33.364 35.67202505295416 139.7381859789771 33.364 35.67202558616896 139.73818775682855 33.364</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7134fc21-cfe7-4b0b-8c1f-361b400e30e4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672006510810284 139.73819624107256 33.202 35.67202558616896 139.73818775682855 33.202 35.67203184038516 139.73820891447497 33.202 35.672012765016284 139.73821738766816 33.202 35.672006510810284 139.73819624107256 33.202</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-99b9a136-e1f7-441d-a194-4ca9ac7c738d">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67204664589263 139.73827227061463 26.019 35.67202821928042 139.73828045581655 26.019 35.67203018952065 139.73828710346552 26.019 35.67200279738624 139.7382992649775 26.019 35.67199865809046 139.73828531817705 26.019 35.67204448584018 139.73826496040044 26.019 35.67204664589263 139.73827227061463 26.019</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f4829198-f7d2-42f0-b6b6-68bdffb1ab13">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67199865809046 139.73828531817705 26.439 35.67200279738624 139.7382992649775 26.439 35.67200164403989 139.73829978552934 26.439 35.67199751374917 139.7382858276719 26.439 35.67199865809046 139.73828531817705 26.439</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3bc8dd5f-6326-4f5e-9ef9-6df45ddf958d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3bc8dd5f-6326-4f5e-9ef9-6df45ddf958d_0">
											<gml:posList>35.67199865809046 139.73828531817705 26.439 35.67199865809046 139.73828531817705 26.019 35.67200279738624 139.7382992649775 26.019 35.67200279738624 139.7382992649775 26.439 35.67199865809046 139.73828531817705 26.439</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-450892b2-36ed-49e4-a994-5bbca5e3e6a2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-450892b2-36ed-49e4-a994-5bbca5e3e6a2_0">
											<gml:posList>35.67199751374917 139.7382858276719 26.439 35.67200164403989 139.73829978552934 26.439 35.67200164403989 139.73829978552934 28.338 35.67199751374917 139.7382858276719 28.338 35.67199751374917 139.7382858276719 26.439</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-52bc8202-5c46-4670-a8ea-402542a8988f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-52bc8202-5c46-4670-a8ea-402542a8988f_0">
											<gml:posList>35.672006510810284 139.73819624107256 33.364 35.672006510810284 139.73819624107256 33.202 35.672012765016284 139.73821738766816 33.202 35.672012765016284 139.73821738766816 35.347 35.6720059775869 139.73819445217504 35.347 35.6720059775869 139.73819445217504 33.364 35.672006510810284 139.73819624107256 33.364</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-638dd94d-1ac0-480f-85cd-96a20022c631">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-638dd94d-1ac0-480f-85cd-96a20022c631_0">
											<gml:posList>35.67202505295416 139.7381859789771 33.364 35.6720059775869 139.73819445217504 33.364 35.6720059775869 139.73819445217504 35.347 35.67202505295416 139.7381859789771 35.347 35.67202505295416 139.7381859789771 33.364</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9539af9b-4095-4816-88bb-8ac0d069d93a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9539af9b-4095-4816-88bb-8ac0d069d93a_0">
											<gml:posList>35.67203018952065 139.73828710346552 26.019 35.67203018952065 139.73828710346552 28.338 35.67200164403989 139.73829978552934 28.338 35.67200164403989 139.73829978552934 26.439 35.67200279738624 139.7382992649775 26.439 35.67200279738624 139.7382992649775 26.019 35.67203018952065 139.73828710346552 26.019</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6373ce25-d332-41fa-8f25-9ae7f180a7fc">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6373ce25-d332-41fa-8f25-9ae7f180a7fc_0">
											<gml:posList>35.672006510810284 139.73819624107256 33.364 35.67202558616896 139.73818775682855 33.364 35.67202558616896 139.73818775682855 33.202 35.672006510810284 139.73819624107256 33.202 35.672006510810284 139.73819624107256 33.364</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d175ce68-a19e-4828-8cb6-803eb13dda67">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d175ce68-a19e-4828-8cb6-803eb13dda67_0">
											<gml:posList>35.6720059775869 139.73819445217504 35.347 35.672012765016284 139.73821738766816 35.347 35.67203184038516 139.73820891447497 35.347 35.67202505295416 139.7381859789771 35.347 35.6720059775869 139.73819445217504 35.347</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-34e4525b-d127-43a8-b25a-bda520311071">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-34e4525b-d127-43a8-b25a-bda520311071_0">
											<gml:posList>35.67199865809046 139.73828531817705 26.439 35.67199751374917 139.7382858276719 26.439 35.67199751374917 139.7382858276719 28.338 35.672005821495034 139.73828213934388 28.338 35.672005821495034 139.73828213934388 27.431 35.672014660867106 139.7382782184086 27.992 35.67203343889218 139.7382698781401 27.62 35.67204448584018 139.73826496040044 26.727 35.67204448584018 139.73826496040044 26.019 35.67199865809046 139.73828531817705 26.019 35.67199865809046 139.73828531817705 26.439</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b4f2ca35-61a0-47e3-ab0c-7afc09707d15">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b4f2ca35-61a0-47e3-ab0c-7afc09707d15_0">
											<gml:posList>35.67202821928042 139.73828045581655 28.338 35.67204664589263 139.73827227061463 28.338 35.67204448584891 139.7382649714469 28.338 35.672005821495034 139.73828213934388 28.338 35.67199751374917 139.7382858276719 28.338 35.67200164403989 139.73829978552934 28.338 35.67203018952065 139.73828710346552 28.338 35.67202821928042 139.73828045581655 28.338</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e0c56e2c-dfb7-4453-a6a5-8a2afc8cad1b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e0c56e2c-dfb7-4453-a6a5-8a2afc8cad1b_0">
											<gml:posList>35.672012765016284 139.73821738766816 33.202 35.67203184038516 139.73820891447497 33.202 35.67203184038516 139.73820891447497 35.347 35.672012765016284 139.73821738766816 35.347 35.672012765016284 139.73821738766816 33.202</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-81d53e93-0894-440c-8b72-750c2ea5c90a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-81d53e93-0894-440c-8b72-750c2ea5c90a_0">
											<gml:posList>35.67204448584891 139.7382649714469 28.338 35.67204448584018 139.73826496040044 26.727 35.67203343889218 139.7382698781401 27.62 35.672014660867106 139.7382782184086 27.992 35.672005821495034 139.73828213934388 27.431 35.672005821495034 139.73828213934388 28.338 35.67204448584891 139.7382649714469 28.338</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bedd6cbc-a70d-4af7-b53d-9989921ead07">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bedd6cbc-a70d-4af7-b53d-9989921ead07_0">
											<gml:posList>35.67202558616896 139.73818775682855 33.364 35.67202505295416 139.7381859789771 33.364 35.67202505295416 139.7381859789771 35.347 35.67203184038516 139.73820891447497 35.347 35.67203184038516 139.73820891447497 33.202 35.67202558616896 139.73818775682855 33.202 35.67202558616896 139.73818775682855 33.364</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c1903968-5166-4ef0-a1e5-dfe68c96587b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c1903968-5166-4ef0-a1e5-dfe68c96587b_0">
											<gml:posList>35.67203018952065 139.73828710346552 26.019 35.67202821928042 139.73828045581655 26.019 35.67202821928042 139.73828045581655 28.338 35.67203018952065 139.73828710346552 28.338 35.67203018952065 139.73828710346552 26.019</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-16916d9d-3658-4697-9fcf-cd5f08de7d47">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-16916d9d-3658-4697-9fcf-cd5f08de7d47_0">
											<gml:posList>35.67204664589263 139.73827227061463 26.019 35.67204664589263 139.73827227061463 28.338 35.67202821928042 139.73828045581655 28.338 35.67202821928042 139.73828045581655 26.019 35.67204664589263 139.73827227061463 26.019</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-51aab6f8-c431-4cc8-88f7-29b377a560bd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-51aab6f8-c431-4cc8-88f7-29b377a560bd_0">
											<gml:posList>35.67204664589263 139.73827227061463 28.338 35.67204664589263 139.73827227061463 26.019 35.67204448584018 139.73826496040044 26.019 35.67204448584018 139.73826496040044 26.727 35.67204448584891 139.7382649714469 28.338 35.67204664589263 139.73827227061463 28.338</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_f5956a68-6714-4527-aaf0-5254c2e51d63_BuildingInstallation_1041">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-38e568ec-bb9e-4780-88e5-459eb1eb739d">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67197778965176 139.73819191179524 29.421 35.67197054127807 139.73816740826152 29.421 35.67200205121967 139.73815340810478 29.421 35.672009299596176 139.73817791164686 29.421 35.67197778965176 139.73819191179524 29.421</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-340c190e-813d-4000-a3fd-6268eb0a4c62">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-340c190e-813d-4000-a3fd-6268eb0a4c62_0">
											<gml:posList>35.67197054127807 139.73816740826152 29.421 35.67197054127807 139.73816740826152 31.526 35.67200205121967 139.73815340810478 31.526 35.67200205121967 139.73815340810478 29.421 35.67197054127807 139.73816740826152 29.421</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ce1c83a3-d4c1-48da-bc11-feb28e0447c6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ce1c83a3-d4c1-48da-bc11-feb28e0447c6_0">
											<gml:posList>35.67200205121967 139.73815340810478 29.421 35.67200205121967 139.73815340810478 31.526 35.672009299596176 139.73817791164686 31.526 35.672009299596176 139.73817791164686 29.421 35.67200205121967 139.73815340810478 29.421</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f5988a69-4b70-47e9-b149-dbd9b8837d41">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f5988a69-4b70-47e9-b149-dbd9b8837d41_0">
											<gml:posList>35.67200205121967 139.73815340810478 31.526 35.67197054127807 139.73816740826152 31.526 35.67197778965176 139.73819191179524 31.526 35.672009299596176 139.73817791164686 31.526 35.67200205121967 139.73815340810478 31.526</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5119e48e-a387-467e-a222-ff78be58e6f5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5119e48e-a387-467e-a222-ff78be58e6f5_0">
											<gml:posList>35.67197778965176 139.73819191179524 29.421 35.67197778965176 139.73819191179524 31.526 35.67197054127807 139.73816740826152 31.526 35.67197054127807 139.73816740826152 29.421 35.67197778965176 139.73819191179524 29.421</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e22dc94a-6d1e-438f-9dc2-8284086a7ffa">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e22dc94a-6d1e-438f-9dc2-8284086a7ffa_0">
											<gml:posList>35.672009299596176 139.73817791164686 29.421 35.672009299596176 139.73817791164686 31.526 35.67197778965176 139.73819191179524 31.526 35.67197778965176 139.73819191179524 29.421 35.672009299596176 139.73817791164686 29.421</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-15813d26-f412-455b-a533-e507fa4f012d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-15813d26-f412-455b-a533-e507fa4f012d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-15813d26-f412-455b-a533-e507fa4f012d">
											<gml:posList>35.67195360859098 139.73814979818508 9.86 35.67201974614979 139.73812044647903 9.86 35.6720772269825 139.73831479649215 9.86 35.672011992927246 139.73834690860963 9.86 35.67195360859098 139.73814979818508 9.86</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a1607173-e378-428b-b405-fdd3bc9c9e64">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a1607173-e378-428b-b405-fdd3bc9c9e64">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a1607173-e378-428b-b405-fdd3bc9c9e64">
											<gml:posList>35.671994324008494 139.7382872454031 29.814 35.6719963928739 139.73828180808133 29.814 35.67196136225566 139.73816355289011 29.814 35.671956952590975 139.73816108371392 29.814 35.671994324008494 139.7382872454031 29.814</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-81639fa3-110c-4279-9134-f1394e5434f4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-81639fa3-110c-4279-9134-f1394e5434f4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-81639fa3-110c-4279-9134-f1394e5434f4">
											<gml:posList>35.67202256596808 139.7381299762472 26.667 35.67201974614979 139.73812044647903 26.667 35.67195360859098 139.73814979818508 26.667 35.671956952590975 139.73816108371392 26.667 35.67202256596808 139.7381299762472 26.667</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-53bd6ff2-4143-445e-badb-93f2d25b8d58">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-53bd6ff2-4143-445e-badb-93f2d25b8d58">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-53bd6ff2-4143-445e-badb-93f2d25b8d58">
											<gml:posList>35.671956952590975 139.73816108371392 29.814 35.67196136225566 139.73816355289011 29.814 35.67202050620186 139.73813551298218 29.814 35.67202256596808 139.7381299762472 29.814 35.671956952590975 139.73816108371392 29.814</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-bb8e7528-4dd3-4170-9c9c-36204931d084">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bb8e7528-4dd3-4170-9c9c-36204931d084">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bb8e7528-4dd3-4170-9c9c-36204931d084">
											<gml:posList>35.672032191815596 139.7382658476511 29.421 35.672019621542404 139.73822510102673 29.421 35.67201060196748 139.73822911055373 29.421 35.672000497638095 139.73819495576964 29.421 35.67203329609946 139.73818039071838 29.421 35.67203387274182 139.73818009177884 29.421 35.67202050620186 139.73813551298218 29.421 35.67196136225566 139.73816355289011 29.421 35.6719963928739 139.73828180808133 29.421 35.672032191815596 139.7382658476511 29.421</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c9f165ac-efc5-4f55-9c4c-361fa5b0864a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c9f165ac-efc5-4f55-9c4c-361fa5b0864a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c9f165ac-efc5-4f55-9c4c-361fa5b0864a">
											<gml:posList>35.67200665652286 139.73831228420684 26.439 35.67199865809046 139.73828531817705 26.439 35.671994324008494 139.7382872454031 26.439 35.67200388601546 139.73831953398326 26.439 35.67200665652286 139.73831228420684 26.439</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-1fcc95a4-abda-4b61-a59d-7e1674f7d4ee">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1fcc95a4-abda-4b61-a59d-7e1674f7d4ee">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1fcc95a4-abda-4b61-a59d-7e1674f7d4ee">
											<gml:posList>35.67201060196748 139.73822911055373 33.364 35.67201241898708 139.73822435841012 33.364 35.672004384314306 139.73819718254703 33.364 35.672000497638095 139.73819495576964 33.364 35.67201060196748 139.73822911055373 33.364</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-3f6e16c1-c300-4fb4-bc33-7f9a86c51616">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3f6e16c1-c300-4fb4-bc33-7f9a86c51616">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3f6e16c1-c300-4fb4-bc33-7f9a86c51616">
											<gml:posList>35.6719963928739 139.73828180808133 29.814 35.671994324008494 139.7382872454031 29.814 35.67203343889218 139.7382698781401 29.814 35.672032191815596 139.7382658476511 29.814 35.6719963928739 139.73828180808133 29.814</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ddceb11c-48d8-4ce0-89b3-78cc4b0aa1be">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ddceb11c-48d8-4ce0-89b3-78cc4b0aa1be">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ddceb11c-48d8-4ce0-89b3-78cc4b0aa1be">
											<gml:posList>35.672000497638095 139.73819495576964 33.364 35.672004384314306 139.73819718254703 33.364 35.672031470067886 139.7381851428749 33.364 35.67203329609946 139.73818039071838 33.364 35.672000497638095 139.73819495576964 33.364</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a139c6a1-259b-4371-be32-02885db627bf">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a139c6a1-259b-4371-be32-02885db627bf">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a139c6a1-259b-4371-be32-02885db627bf">
											<gml:posList>35.67203947770219 139.73821231877804 33.202 35.672031470067886 139.7381851428749 33.202 35.672004384314306 139.73819718254703 33.202 35.67201241898708 139.73822435841012 33.202 35.67203947770219 139.73821231877804 33.202</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-df23bebb-d0dd-4cb1-8423-107464d052be">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-df23bebb-d0dd-4cb1-8423-107464d052be">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-df23bebb-d0dd-4cb1-8423-107464d052be">
											<gml:posList>35.67204336437806 139.73821454555735 33.364 35.67203947770219 139.73821231877804 33.364 35.67201241898708 139.73822435841012 33.364 35.67201060196748 139.73822911055373 33.364 35.67204336437806 139.73821454555735 33.364</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-7d90b189-b938-49fc-ba41-50d0522364c0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7d90b189-b938-49fc-ba41-50d0522364c0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7d90b189-b938-49fc-ba41-50d0522364c0">
											<gml:posList>35.67205606442298 139.73825982109918 26.019 35.67199865809046 139.73828531817705 26.019 35.67200665652286 139.73831228420684 26.019 35.67206402678 139.738286754049 26.019 35.67205606442298 139.73825982109918 26.019</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-df6014f6-e4a7-4811-84d7-bf3f1d83f2f7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-df6014f6-e4a7-4811-84d7-bf3f1d83f2f7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-df6014f6-e4a7-4811-84d7-bf3f1d83f2f7">
											<gml:posList>35.67206994246564 139.73829014935535 26.439 35.67206402678 139.738286754049 26.439 35.67200665652286 139.73831228420684 26.439 35.67200388601546 139.73831953398326 26.439 35.67206994246564 139.73829014935535 26.439</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-5ed2fc09-5d8e-4490-8d2e-c11929090ca3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5ed2fc09-5d8e-4490-8d2e-c11929090ca3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5ed2fc09-5d8e-4490-8d2e-c11929090ca3">
											<gml:posList>35.67203329609946 139.73818039071838 33.364 35.672031470067886 139.7381851428749 33.364 35.67203947770219 139.73821231877804 33.364 35.67204336437806 139.73821454555735 33.364 35.67203329609946 139.73818039071838 33.364</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-2ad09cfa-944e-42b2-a9ae-4389813b3124">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2ad09cfa-944e-42b2-a9ae-4389813b3124">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2ad09cfa-944e-42b2-a9ae-4389813b3124">
											<gml:posList>35.67203343889218 139.7382698781401 32.008 35.67205665911915 139.73825955527818 32.008 35.67204336437806 139.73821454555735 32.008 35.672019621542404 139.73822510102673 32.008 35.67203343889218 139.7382698781401 32.008</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-6eae1111-16c3-41c1-acac-362c8f8d1298">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6eae1111-16c3-41c1-acac-362c8f8d1298">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6eae1111-16c3-41c1-acac-362c8f8d1298">
											<gml:posList>35.67203387274182 139.73818009177884 29.814 35.67203329609946 139.73818039071838 29.814 35.67205665911915 139.73825955527818 29.814 35.67206039850447 139.73825789387018 29.814 35.67202256596808 139.7381299762472 29.814 35.67202050620186 139.73813551298218 29.814 35.67203387274182 139.73818009177884 29.814</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e91c6fad-71da-477e-99ba-db1a50d4b65b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e91c6fad-71da-477e-99ba-db1a50d4b65b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e91c6fad-71da-477e-99ba-db1a50d4b65b">
											<gml:posList>35.67200388601546 139.73831953398326 26.439 35.672011992927246 139.73834690860963 22.494 35.6720772269825 139.73831479649215 22.494 35.67200388601546 139.73831953398326 26.439</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-8e049a6e-dc9b-45ff-bec2-a0f94995ef03">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8e049a6e-dc9b-45ff-bec2-a0f94995ef03">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8e049a6e-dc9b-45ff-bec2-a0f94995ef03">
											<gml:posList>35.6720772269825 139.73831479649215 22.494 35.67206994246564 139.73829014935535 26.439 35.67200388601546 139.73831953398326 26.439 35.6720772269825 139.73831479649215 22.494</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d4d2d7e0-c07b-4721-a718-e4efea8cd328">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d4d2d7e0-c07b-4721-a718-e4efea8cd328">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d4d2d7e0-c07b-4721-a718-e4efea8cd328">
											<gml:posList>35.67206402678 139.738286754049 26.439 35.67206994246564 139.73829014935535 26.439 35.67206039850447 139.73825789387018 26.439 35.67205606442298 139.73825982109918 26.439 35.67206402678 139.738286754049 26.439</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-34fa7a76-8ab5-42c2-9093-b72626d80b7c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-34fa7a76-8ab5-42c2-9093-b72626d80b7c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-34fa7a76-8ab5-42c2-9093-b72626d80b7c">
											<gml:posList>35.6719963928739 139.73828180808133 29.814 35.6719963928739 139.73828180808133 29.421 35.67196136225566 139.73816355289011 29.421 35.67196136225566 139.73816355289011 29.814 35.6719963928739 139.73828180808133 29.814</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-086ea57c-a99d-4bc5-b3d4-ca0ed714814b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-086ea57c-a99d-4bc5-b3d4-ca0ed714814b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-086ea57c-a99d-4bc5-b3d4-ca0ed714814b">
											<gml:posList>35.672011992927246 139.73834690860963 22.494 35.67200388601546 139.73831953398326 26.439 35.671994324008494 139.7382872454031 26.439 35.671994324008494 139.7382872454031 29.814 35.671956952590975 139.73816108371392 29.814 35.671956952590975 139.73816108371392 26.667 35.67195360859098 139.73814979818508 26.667 35.67195360859098 139.73814979818508 9.86 35.672011992927246 139.73834690860963 9.86 35.672011992927246 139.73834690860963 22.494</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-666cd10d-3c00-477a-8aef-c7728819a85d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-666cd10d-3c00-477a-8aef-c7728819a85d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-666cd10d-3c00-477a-8aef-c7728819a85d">
											<gml:posList>35.67201974614979 139.73812044647903 9.86 35.67195360859098 139.73814979818508 9.86 35.67195360859098 139.73814979818508 26.667 35.67201974614979 139.73812044647903 26.667 35.67201974614979 139.73812044647903 9.86</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-aa994b51-998b-4a8d-82f1-f1c8c332a1c3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-aa994b51-998b-4a8d-82f1-f1c8c332a1c3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-aa994b51-998b-4a8d-82f1-f1c8c332a1c3">
											<gml:posList>35.671956952590975 139.73816108371392 26.667 35.671956952590975 139.73816108371392 29.814 35.67202256596808 139.7381299762472 29.814 35.67202256596808 139.7381299762472 26.667 35.671956952590975 139.73816108371392 26.667</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c76a5586-00aa-4f77-9848-704ded349dab">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c76a5586-00aa-4f77-9848-704ded349dab">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c76a5586-00aa-4f77-9848-704ded349dab">
											<gml:posList>35.67196136225566 139.73816355289011 29.814 35.67196136225566 139.73816355289011 29.421 35.67202050620186 139.73813551298218 29.421 35.67202050620186 139.73813551298218 29.814 35.67196136225566 139.73816355289011 29.814</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ff2f1cc6-44af-4571-8cfc-d752c37aa728">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ff2f1cc6-44af-4571-8cfc-d752c37aa728">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ff2f1cc6-44af-4571-8cfc-d752c37aa728">
											<gml:posList>35.67200665652286 139.73831228420684 26.439 35.67200665652286 139.73831228420684 26.019 35.67199865809046 139.73828531817705 26.019 35.67199865809046 139.73828531817705 26.439 35.67200665652286 139.73831228420684 26.439</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-db4db552-2ef3-4689-a562-e85dd321b7f5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-db4db552-2ef3-4689-a562-e85dd321b7f5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-db4db552-2ef3-4689-a562-e85dd321b7f5">
											<gml:posList>35.672000497638095 139.73819495576964 29.421 35.67201060196748 139.73822911055373 29.421 35.67201060196748 139.73822911055373 33.364 35.672000497638095 139.73819495576964 33.364 35.672000497638095 139.73819495576964 29.421</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-06e840cb-6e81-4a32-8b2e-78b8fae5f05b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-06e840cb-6e81-4a32-8b2e-78b8fae5f05b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-06e840cb-6e81-4a32-8b2e-78b8fae5f05b">
											<gml:posList>35.67201241898708 139.73822435841012 33.364 35.67201241898708 139.73822435841012 33.202 35.672004384314306 139.73819718254703 33.202 35.672004384314306 139.73819718254703 33.364 35.67201241898708 139.73822435841012 33.364</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-fbf34ae2-6d1e-458e-9319-cb3edf9e8267">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fbf34ae2-6d1e-458e-9319-cb3edf9e8267">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fbf34ae2-6d1e-458e-9319-cb3edf9e8267">
											<gml:posList>35.672032191815596 139.7382658476511 29.814 35.672032191815596 139.7382658476511 29.421 35.6719963928739 139.73828180808133 29.421 35.6719963928739 139.73828180808133 29.814 35.672032191815596 139.7382658476511 29.814</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-296401fb-e343-456a-a37d-9c3f1bb0241a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-296401fb-e343-456a-a37d-9c3f1bb0241a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-296401fb-e343-456a-a37d-9c3f1bb0241a">
											<gml:posList>35.672000497638095 139.73819495576964 29.421 35.672000497638095 139.73819495576964 33.364 35.67203329609946 139.73818039071838 33.364 35.67203329609946 139.73818039071838 29.814 35.67203329609946 139.73818039071838 29.421 35.672000497638095 139.73819495576964 29.421</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c543a3b4-2483-4c2d-88a1-b93df8a13090">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c543a3b4-2483-4c2d-88a1-b93df8a13090">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c543a3b4-2483-4c2d-88a1-b93df8a13090">
											<gml:posList>35.672004384314306 139.73819718254703 33.364 35.672004384314306 139.73819718254703 33.202 35.672031470067886 139.7381851428749 33.202 35.672031470067886 139.7381851428749 33.364 35.672004384314306 139.73819718254703 33.364</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-09e5b31e-8b68-4838-9406-9b3013ff350f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-09e5b31e-8b68-4838-9406-9b3013ff350f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-09e5b31e-8b68-4838-9406-9b3013ff350f">
											<gml:posList>35.67203947770219 139.73821231877804 33.364 35.67203947770219 139.73821231877804 33.202 35.67201241898708 139.73822435841012 33.202 35.67201241898708 139.73822435841012 33.364 35.67203947770219 139.73821231877804 33.364</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9ed61c5d-4eef-4846-a4b1-30f40a82534f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9ed61c5d-4eef-4846-a4b1-30f40a82534f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9ed61c5d-4eef-4846-a4b1-30f40a82534f">
											<gml:posList>35.67203343889218 139.7382698781401 32.008 35.672019621542404 139.73822510102673 32.008 35.672019621542404 139.73822510102673 29.421 35.672032191815596 139.7382658476511 29.421 35.672032191815596 139.7382658476511 29.814 35.67203343889218 139.7382698781401 29.814 35.67203343889218 139.7382698781401 32.008</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e45d596e-ac27-424f-8904-b0902336ce43">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e45d596e-ac27-424f-8904-b0902336ce43">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e45d596e-ac27-424f-8904-b0902336ce43">
											<gml:posList>35.67201060196748 139.73822911055373 33.364 35.67201060196748 139.73822911055373 29.421 35.672019621542404 139.73822510102673 29.421 35.672019621542404 139.73822510102673 32.008 35.67204336437806 139.73821454555735 32.008 35.67204336437806 139.73821454555735 33.364 35.67201060196748 139.73822911055373 33.364</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a1d7515d-f6c9-48df-a2dd-d5d0d660f45f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a1d7515d-f6c9-48df-a2dd-d5d0d660f45f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a1d7515d-f6c9-48df-a2dd-d5d0d660f45f">
											<gml:posList>35.67202050620186 139.73813551298218 29.814 35.67202050620186 139.73813551298218 29.421 35.67203387274182 139.73818009177884 29.421 35.67203387274182 139.73818009177884 29.814 35.67202050620186 139.73813551298218 29.814</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-40f819c3-b9c9-457d-b0a7-9818ade7cfbc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-40f819c3-b9c9-457d-b0a7-9818ade7cfbc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-40f819c3-b9c9-457d-b0a7-9818ade7cfbc">
											<gml:posList>35.67205665911915 139.73825955527818 29.814 35.67205665911915 139.73825955527818 32.008 35.67203343889218 139.7382698781401 32.008 35.67203343889218 139.7382698781401 29.814 35.671994324008494 139.7382872454031 29.814 35.671994324008494 139.7382872454031 26.439 35.67199865809046 139.73828531817705 26.439 35.67199865809046 139.73828531817705 26.019 35.67205606442298 139.73825982109918 26.019 35.67205606442298 139.73825982109918 26.439 35.67206039850447 139.73825789387018 26.439 35.67206039850447 139.73825789387018 29.814 35.67205665911915 139.73825955527818 29.814</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-736e9152-9b3b-4dd5-bf5f-4ba0bca38a9b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-736e9152-9b3b-4dd5-bf5f-4ba0bca38a9b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-736e9152-9b3b-4dd5-bf5f-4ba0bca38a9b">
											<gml:posList>35.67203387274182 139.73818009177884 29.814 35.67203387274182 139.73818009177884 29.421 35.67203329609946 139.73818039071838 29.421 35.67203329609946 139.73818039071838 29.814 35.67203387274182 139.73818009177884 29.814</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c0886cea-213b-4e8d-8226-b64db4dcf994">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c0886cea-213b-4e8d-8226-b64db4dcf994">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c0886cea-213b-4e8d-8226-b64db4dcf994">
											<gml:posList>35.67206402678 139.738286754049 26.439 35.67206402678 139.738286754049 26.019 35.67200665652286 139.73831228420684 26.019 35.67200665652286 139.73831228420684 26.439 35.67206402678 139.738286754049 26.439</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f3ce7178-b064-48e9-875a-2484d9a426fc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f3ce7178-b064-48e9-875a-2484d9a426fc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f3ce7178-b064-48e9-875a-2484d9a426fc">
											<gml:posList>35.672031470067886 139.7381851428749 33.364 35.672031470067886 139.7381851428749 33.202 35.67203947770219 139.73821231877804 33.202 35.67203947770219 139.73821231877804 33.364 35.672031470067886 139.7381851428749 33.364</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-92bde449-7e52-4725-aee6-a267c14db705">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-92bde449-7e52-4725-aee6-a267c14db705">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-92bde449-7e52-4725-aee6-a267c14db705">
											<gml:posList>35.672011992927246 139.73834690860963 9.86 35.6720772269825 139.73831479649215 9.86 35.6720772269825 139.73831479649215 22.494 35.672011992927246 139.73834690860963 22.494 35.672011992927246 139.73834690860963 9.86</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b019e39e-f04d-4447-baa4-b159b7859068">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b019e39e-f04d-4447-baa4-b159b7859068">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b019e39e-f04d-4447-baa4-b159b7859068">
											<gml:posList>35.67203329609946 139.73818039071838 33.364 35.67204336437806 139.73821454555735 33.364 35.67204336437806 139.73821454555735 32.008 35.67205665911915 139.73825955527818 32.008 35.67205665911915 139.73825955527818 29.814 35.67203329609946 139.73818039071838 29.814 35.67203329609946 139.73818039071838 33.364</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-67dee024-085d-43b5-bf6c-780a1cf785ec">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-67dee024-085d-43b5-bf6c-780a1cf785ec">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-67dee024-085d-43b5-bf6c-780a1cf785ec">
											<gml:posList>35.67201974614979 139.73812044647903 9.86 35.67201974614979 139.73812044647903 26.667 35.67202256596808 139.7381299762472 26.667 35.67202256596808 139.7381299762472 29.814 35.67206039850447 139.73825789387018 29.814 35.67206039850447 139.73825789387018 26.439 35.67206994246564 139.73829014935535 26.439 35.6720772269825 139.73831479649215 22.494 35.6720772269825 139.73831479649215 9.86 35.67201974614979 139.73812044647903 9.86</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9fc5aeae-f59b-4d33-b86e-2b84db7cdac9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9fc5aeae-f59b-4d33-b86e-2b84db7cdac9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9fc5aeae-f59b-4d33-b86e-2b84db7cdac9">
											<gml:posList>35.67205606442298 139.73825982109918 26.439 35.67205606442298 139.73825982109918 26.019 35.67206402678 139.738286754049 26.019 35.67206402678 139.738286754049 26.439 35.67205606442298 139.73825982109918 26.439</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-298</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">147.003</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1242</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>5</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.01</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>