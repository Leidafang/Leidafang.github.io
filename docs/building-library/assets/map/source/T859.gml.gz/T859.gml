<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_f62ad6e6-8af1-407a-884c-ea6009acca0a">
			<core:creationDate>2024-03-15</core:creationDate>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.667567882490346 139.74213849938462 0 35.66756977937452 139.74215568460482 0 35.66759340140977 139.74215176959646 0 35.667591504524985 139.74213458437129 0 35.667567882490346 139.74213849938462 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667567882490346 139.74213849938462 29.249 35.667591504524985 139.74213458437129 29.249 35.66759340140977 139.74215176959646 29.249 35.66756977937452 139.74215568460482 29.249 35.667567882490346 139.74213849938462 29.249</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667567882490346 139.74213849938462 29.249 35.66756977937452 139.74215568460482 29.249 35.66756977937452 139.74215568460482 32.248999999999995 35.667567882490346 139.74213849938462 32.248999999999995 35.667567882490346 139.74213849938462 29.249</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66756977937452 139.74215568460482 29.249 35.66759340140977 139.74215176959646 29.249 35.66759340140977 139.74215176959646 32.248999999999995 35.66756977937452 139.74215568460482 32.248999999999995 35.66756977937452 139.74215568460482 29.249</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66759340140977 139.74215176959646 29.249 35.667591504524985 139.74213458437129 29.249 35.667591504524985 139.74213458437129 32.248999999999995 35.66759340140977 139.74215176959646 32.248999999999995 35.66759340140977 139.74215176959646 29.249</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667591504524985 139.74213458437129 29.249 35.667567882490346 139.74213849938462 29.249 35.667567882490346 139.74213849938462 32.248999999999995 35.667591504524985 139.74213458437129 32.248999999999995 35.667591504524985 139.74213458437129 29.249</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667567882490346 139.74213849938462 32.248999999999995 35.66756977937452 139.74215568460482 32.248999999999995 35.66759340140977 139.74215176959646 32.248999999999995 35.667591504524985 139.74213458437129 32.248999999999995 35.667567882490346 139.74213849938462 32.248999999999995</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-085d1dbb-b244-41d1-87a9-d74d75834fe1"/>
							<gml:surfaceMember xlink:href="#poly-13e4fba0-3f55-48ce-b899-b71bf52392ec"/>
							<gml:surfaceMember xlink:href="#poly-39eb1f89-07dd-4afd-8be7-d818a25399c6"/>
							<gml:surfaceMember xlink:href="#poly-5f7a78a7-1f2f-4a7f-ad2c-6925f058bce6"/>
							<gml:surfaceMember xlink:href="#poly-90db5d5b-e1a4-4f8a-aeb6-5a0770653ca4"/>
							<gml:surfaceMember xlink:href="#poly-426196ea-37d5-4b74-af92-cda05774bd41"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-085d1dbb-b244-41d1-87a9-d74d75834fe1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-085d1dbb-b244-41d1-87a9-d74d75834fe1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-085d1dbb-b244-41d1-87a9-d74d75834fe1">
											<gml:posList>35.667567882490324 139.7421384993846 29.249 35.667591504524985 139.74213458437129 29.249 35.66759340140974 139.74215176959643 29.249 35.667569779374524 139.7421556846048 29.249 35.667567882490324 139.7421384993846 29.249</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-13e4fba0-3f55-48ce-b899-b71bf52392ec">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-13e4fba0-3f55-48ce-b899-b71bf52392ec">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-13e4fba0-3f55-48ce-b899-b71bf52392ec">
											<gml:posList>35.667591504524985 139.74213458437129 33.016 35.667567882490324 139.7421384993846 33.016 35.667569779374524 139.7421556846048 33.016 35.66759340140974 139.74215176959643 33.016 35.667591504524985 139.74213458437129 33.016</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-39eb1f89-07dd-4afd-8be7-d818a25399c6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-39eb1f89-07dd-4afd-8be7-d818a25399c6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-39eb1f89-07dd-4afd-8be7-d818a25399c6">
											<gml:posList>35.667591504524985 139.74213458437129 29.249 35.667567882490324 139.7421384993846 29.249 35.667567882490324 139.7421384993846 33.016 35.667591504524985 139.74213458437129 33.016 35.667591504524985 139.74213458437129 29.249</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5f7a78a7-1f2f-4a7f-ad2c-6925f058bce6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5f7a78a7-1f2f-4a7f-ad2c-6925f058bce6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5f7a78a7-1f2f-4a7f-ad2c-6925f058bce6">
											<gml:posList>35.66759340140974 139.74215176959643 29.249 35.667591504524985 139.74213458437129 29.249 35.667591504524985 139.74213458437129 33.016 35.66759340140974 139.74215176959643 33.016 35.66759340140974 139.74215176959643 29.249</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-90db5d5b-e1a4-4f8a-aeb6-5a0770653ca4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-90db5d5b-e1a4-4f8a-aeb6-5a0770653ca4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-90db5d5b-e1a4-4f8a-aeb6-5a0770653ca4">
											<gml:posList>35.667567882490324 139.7421384993846 29.249 35.667569779374524 139.7421556846048 29.249 35.667569779374524 139.7421556846048 33.016 35.667567882490324 139.7421384993846 33.016 35.667567882490324 139.7421384993846 29.249</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-426196ea-37d5-4b74-af92-cda05774bd41">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-426196ea-37d5-4b74-af92-cda05774bd41">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-426196ea-37d5-4b74-af92-cda05774bd41">
											<gml:posList>35.667569779374524 139.7421556846048 29.249 35.66759340140974 139.74215176959643 29.249 35.66759340140974 139.74215176959643 33.016 35.667569779374524 139.7421556846048 33.016 35.667569779374524 139.7421556846048 29.249</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-29</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">6</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">214</uro:landUseType>
					<uro:specifiedBuildingCoverageRate>0.6</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>4</uro:specifiedFloorAreaRate>
					<uro:surveyYear>0001</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.14</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">0</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>