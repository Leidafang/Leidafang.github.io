<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_f718e376-eb37-4789-8a3d-cb63e3e55acb">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="地区計画">
				<gen:value>赤坂二・六丁目地区</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3001</bldg:class>
			<bldg:measuredHeight uom="m">8.7</bldg:measuredHeight>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.67160322042702 139.73755050361353 0 35.671615734997985 139.73753226205403 0 35.671593723326204 139.7375094222536 0 35.67158120875862 139.73752766381165 0 35.67160322042702 139.73755050361353 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67160322042702 139.73755050361353 10.401 35.67158120875862 139.73752766381165 10.401 35.671593723326204 139.7375094222536 10.401 35.671615734997985 139.73753226205403 10.401 35.67160322042702 139.73755050361353 10.401</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67160322042702 139.73755050361353 10.401 35.671615734997985 139.73753226205403 10.401 35.671615734997985 139.73753226205403 19.08 35.67160322042702 139.73755050361353 19.08 35.67160322042702 139.73755050361353 10.401</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671615734997985 139.73753226205403 10.401 35.671593723326204 139.7375094222536 10.401 35.671593723326204 139.7375094222536 19.08 35.671615734997985 139.73753226205403 19.08 35.671615734997985 139.73753226205403 10.401</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671593723326204 139.7375094222536 10.401 35.67158120875862 139.73752766381165 10.401 35.67158120875862 139.73752766381165 19.08 35.671593723326204 139.7375094222536 19.08 35.671593723326204 139.7375094222536 10.401</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67158120875862 139.73752766381165 10.401 35.67160322042702 139.73755050361353 10.401 35.67160322042702 139.73755050361353 19.08 35.67158120875862 139.73752766381165 19.08 35.67158120875862 139.73752766381165 10.401</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67160322042702 139.73755050361353 19.08 35.671615734997985 139.73753226205403 19.08 35.671593723326204 139.7375094222536 19.08 35.67158120875862 139.73752766381165 19.08 35.67160322042702 139.73755050361353 19.08</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-60e27f10-6267-48b0-9c8b-b5c6dac295cf"/>
							<gml:surfaceMember xlink:href="#poly-11f9246d-c204-49dd-817c-ea3f3ab26f7e"/>
							<gml:surfaceMember xlink:href="#poly-df41d250-0f55-4a62-ac63-65a646a8c00b"/>
							<gml:surfaceMember xlink:href="#poly-817de04f-4f23-4bd8-9404-968cd118050d"/>
							<gml:surfaceMember xlink:href="#poly-94193978-3a48-476f-9442-90d1521998c3"/>
							<gml:surfaceMember xlink:href="#poly-dcfa03d5-664d-436b-9141-4e8448d474cd"/>
							<gml:surfaceMember xlink:href="#poly-e8b5ffd5-d69b-419f-854c-8436e651e9c7"/>
							<gml:surfaceMember xlink:href="#poly-6bf9154f-86fc-4275-9e6a-6d96f7b046b2"/>
							<gml:surfaceMember xlink:href="#poly-44541690-8826-46fc-af35-c437ef63dec7"/>
							<gml:surfaceMember xlink:href="#poly-d5288fd9-81f8-45ef-99ce-f1e79f323767"/>
							<gml:surfaceMember xlink:href="#poly-0b9d2be1-836b-4e6a-8a34-437c059d7770"/>
							<gml:surfaceMember xlink:href="#poly-dd4ca97f-3570-4e9c-abaf-6586f7ee54a8"/>
							<gml:surfaceMember xlink:href="#poly-41817efd-c924-448d-81a0-55cefc144921"/>
							<gml:surfaceMember xlink:href="#poly-872ac443-e8d0-4275-8c41-3fcc289bb007"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-60e27f10-6267-48b0-9c8b-b5c6dac295cf">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-60e27f10-6267-48b0-9c8b-b5c6dac295cf">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-60e27f10-6267-48b0-9c8b-b5c6dac295cf">
											<gml:posList>35.671603220426995 139.73755050361353 10.401 35.67158120875862 139.73752766381165 10.401 35.67159372332619 139.7375094222536 10.401 35.67161573499797 139.73753226205403 10.401 35.671603220426995 139.73755050361353 10.401</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-11f9246d-c204-49dd-817c-ea3f3ab26f7e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-11f9246d-c204-49dd-817c-ea3f3ab26f7e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-11f9246d-c204-49dd-817c-ea3f3ab26f7e">
											<gml:posList>35.67158120875862 139.73752766381165 15.038 35.67158520152023 139.73752726136908 15.038 35.67159406073683 139.73751432646364 15.038 35.67159372332619 139.7375094222536 15.038 35.67158120875862 139.73752766381165 15.038</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-df41d250-0f55-4a62-ac63-65a646a8c00b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-df41d250-0f55-4a62-ac63-65a646a8c00b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-df41d250-0f55-4a62-ac63-65a646a8c00b">
											<gml:posList>35.671603220426995 139.73755050361353 15.038 35.67160288301782 139.73754559940275 15.038 35.67158520152023 139.73752726136908 15.038 35.67158120875862 139.73752766381165 15.038 35.671603220426995 139.73755050361353 15.038</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-817de04f-4f23-4bd8-9404-968cd118050d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-817de04f-4f23-4bd8-9404-968cd118050d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-817de04f-4f23-4bd8-9404-968cd118050d">
											<gml:posList>35.671611742236365 139.73753266449648 14.723 35.67159406073683 139.73751432646364 14.723 35.67158520152023 139.73752726136908 14.723 35.67160288301782 139.73754559940275 14.723 35.671611742236365 139.73753266449648 14.723</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-94193978-3a48-476f-9442-90d1521998c3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-94193978-3a48-476f-9442-90d1521998c3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-94193978-3a48-476f-9442-90d1521998c3">
											<gml:posList>35.67159372332619 139.7375094222536 15.038 35.67159406073683 139.73751432646364 15.038 35.671611742236365 139.73753266449648 15.038 35.67161573499797 139.73753226205403 15.038 35.67159372332619 139.7375094222536 15.038</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-dcfa03d5-664d-436b-9141-4e8448d474cd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-dcfa03d5-664d-436b-9141-4e8448d474cd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-dcfa03d5-664d-436b-9141-4e8448d474cd">
											<gml:posList>35.67161573499797 139.73753226205403 15.038 35.671611742236365 139.73753266449648 15.038 35.67160288301782 139.73754559940275 15.038 35.671603220426995 139.73755050361353 15.038 35.67161573499797 139.73753226205403 15.038</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e8b5ffd5-d69b-419f-854c-8436e651e9c7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e8b5ffd5-d69b-419f-854c-8436e651e9c7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e8b5ffd5-d69b-419f-854c-8436e651e9c7">
											<gml:posList>35.67160288301782 139.73754559940275 15.038 35.67160288301782 139.73754559940275 14.723 35.67158520152023 139.73752726136908 14.723 35.67158520152023 139.73752726136908 15.038 35.67160288301782 139.73754559940275 15.038</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6bf9154f-86fc-4275-9e6a-6d96f7b046b2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6bf9154f-86fc-4275-9e6a-6d96f7b046b2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6bf9154f-86fc-4275-9e6a-6d96f7b046b2">
											<gml:posList>35.67159406073683 139.73751432646364 15.038 35.67159406073683 139.73751432646364 14.723 35.671611742236365 139.73753266449648 14.723 35.671611742236365 139.73753266449648 15.038 35.67159406073683 139.73751432646364 15.038</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-44541690-8826-46fc-af35-c437ef63dec7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-44541690-8826-46fc-af35-c437ef63dec7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-44541690-8826-46fc-af35-c437ef63dec7">
											<gml:posList>35.67159372332619 139.7375094222536 10.401 35.67158120875862 139.73752766381165 10.401 35.67158120875862 139.73752766381165 15.038 35.67159372332619 139.7375094222536 15.038 35.67159372332619 139.7375094222536 10.401</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d5288fd9-81f8-45ef-99ce-f1e79f323767">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d5288fd9-81f8-45ef-99ce-f1e79f323767">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d5288fd9-81f8-45ef-99ce-f1e79f323767">
											<gml:posList>35.67158520152023 139.73752726136908 15.038 35.67158520152023 139.73752726136908 14.723 35.67159406073683 139.73751432646364 14.723 35.67159406073683 139.73751432646364 15.038 35.67158520152023 139.73752726136908 15.038</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0b9d2be1-836b-4e6a-8a34-437c059d7770">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0b9d2be1-836b-4e6a-8a34-437c059d7770">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0b9d2be1-836b-4e6a-8a34-437c059d7770">
											<gml:posList>35.67158120875862 139.73752766381165 10.401 35.671603220426995 139.73755050361353 10.401 35.671603220426995 139.73755050361353 15.038 35.67158120875862 139.73752766381165 15.038 35.67158120875862 139.73752766381165 10.401</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-dd4ca97f-3570-4e9c-abaf-6586f7ee54a8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-dd4ca97f-3570-4e9c-abaf-6586f7ee54a8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-dd4ca97f-3570-4e9c-abaf-6586f7ee54a8">
											<gml:posList>35.67161573499797 139.73753226205403 10.401 35.67159372332619 139.7375094222536 10.401 35.67159372332619 139.7375094222536 15.038 35.67161573499797 139.73753226205403 15.038 35.67161573499797 139.73753226205403 10.401</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-41817efd-c924-448d-81a0-55cefc144921">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-41817efd-c924-448d-81a0-55cefc144921">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-41817efd-c924-448d-81a0-55cefc144921">
											<gml:posList>35.671611742236365 139.73753266449648 15.038 35.671611742236365 139.73753266449648 14.723 35.67160288301782 139.73754559940275 14.723 35.67160288301782 139.73754559940275 15.038 35.671611742236365 139.73753266449648 15.038</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-872ac443-e8d0-4275-8c41-3fcc289bb007">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-872ac443-e8d0-4275-8c41-3fcc289bb007">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-872ac443-e8d0-4275-8c41-3fcc289bb007">
											<gml:posList>35.671603220426995 139.73755050361353 10.401 35.67161573499797 139.73753226205403 10.401 35.67161573499797 139.73753226205403 15.038 35.671603220426995 139.73755050361353 15.038 35.671603220426995 139.73755050361353 10.401</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-5724</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>5</uro:specifiedFloorAreaRate>
					<uro:surveyYear>0001</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>