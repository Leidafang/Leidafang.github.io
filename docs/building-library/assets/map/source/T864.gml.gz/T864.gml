<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_f8189da4-1a27-4720-b3ed-30d15159eb37">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="再開発等促進区を定める地区計画">
				<gen:value>虎ノ門二丁目10地区</gen:value>
			</gen:stringAttribute>
			<bldg:measuredHeight uom="m">5.5</bldg:measuredHeight>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.667230410879256 139.7448115312016 0 35.66720828636901 139.7448417880431 0 35.66722828594842 139.7448637361195 0 35.66725030239679 139.7448336119457 0 35.66725960305956 139.74484381907357 0 35.66727097597688 139.74482826503808 0 35.66726188279906 139.74481828964397 0 35.66729614560023 139.74477141748216 0 35.667275938517875 139.74474923767704 0 35.66724174776192 139.74479601034452 0 35.667232221565015 139.7447855494195 0 35.66722087566999 139.7448010702862 0 35.667230410879256 139.7448115312016 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667230410879256 139.7448115312016 8.92 35.66722087566999 139.7448010702862 8.92 35.667232221565015 139.7447855494195 8.92 35.66724174776192 139.74479601034452 8.92 35.667275938517875 139.74474923767704 8.92 35.66729614560023 139.74477141748216 8.92 35.66726188279906 139.74481828964397 8.92 35.66727097597688 139.74482826503808 8.92 35.66725960305956 139.74484381907357 8.92 35.66725030239679 139.7448336119457 8.92 35.66722828594842 139.7448637361195 8.92 35.66720828636901 139.7448417880431 8.92 35.667230410879256 139.7448115312016 8.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667230410879256 139.7448115312016 8.92 35.66720828636901 139.7448417880431 8.92 35.66720828636901 139.7448417880431 14.41 35.667230410879256 139.7448115312016 14.41 35.667230410879256 139.7448115312016 8.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66720828636901 139.7448417880431 8.92 35.66722828594842 139.7448637361195 8.92 35.66722828594842 139.7448637361195 14.41 35.66720828636901 139.7448417880431 14.41 35.66720828636901 139.7448417880431 8.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66722828594842 139.7448637361195 8.92 35.66725030239679 139.7448336119457 8.92 35.66725030239679 139.7448336119457 14.41 35.66722828594842 139.7448637361195 14.41 35.66722828594842 139.7448637361195 8.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66725030239679 139.7448336119457 8.92 35.66725960305956 139.74484381907357 8.92 35.66725960305956 139.74484381907357 14.41 35.66725030239679 139.7448336119457 14.41 35.66725030239679 139.7448336119457 8.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66725960305956 139.74484381907357 8.92 35.66727097597688 139.74482826503808 8.92 35.66727097597688 139.74482826503808 14.41 35.66725960305956 139.74484381907357 14.41 35.66725960305956 139.74484381907357 8.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66727097597688 139.74482826503808 8.92 35.66726188279906 139.74481828964397 8.92 35.66726188279906 139.74481828964397 14.41 35.66727097597688 139.74482826503808 14.41 35.66727097597688 139.74482826503808 8.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66726188279906 139.74481828964397 8.92 35.66729614560023 139.74477141748216 8.92 35.66729614560023 139.74477141748216 14.41 35.66726188279906 139.74481828964397 14.41 35.66726188279906 139.74481828964397 8.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66729614560023 139.74477141748216 8.92 35.667275938517875 139.74474923767704 8.92 35.667275938517875 139.74474923767704 14.41 35.66729614560023 139.74477141748216 14.41 35.66729614560023 139.74477141748216 8.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667275938517875 139.74474923767704 8.92 35.66724174776192 139.74479601034452 8.92 35.66724174776192 139.74479601034452 14.41 35.667275938517875 139.74474923767704 14.41 35.667275938517875 139.74474923767704 8.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66724174776192 139.74479601034452 8.92 35.667232221565015 139.7447855494195 8.92 35.667232221565015 139.7447855494195 14.41 35.66724174776192 139.74479601034452 14.41 35.66724174776192 139.74479601034452 8.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667232221565015 139.7447855494195 8.92 35.66722087566999 139.7448010702862 8.92 35.66722087566999 139.7448010702862 14.41 35.667232221565015 139.7447855494195 14.41 35.667232221565015 139.7447855494195 8.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66722087566999 139.7448010702862 8.92 35.667230410879256 139.7448115312016 8.92 35.667230410879256 139.7448115312016 14.41 35.66722087566999 139.7448010702862 14.41 35.66722087566999 139.7448010702862 8.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667230410879256 139.7448115312016 14.41 35.66720828636901 139.7448417880431 14.41 35.66722828594842 139.7448637361195 14.41 35.66725030239679 139.7448336119457 14.41 35.66725960305956 139.74484381907357 14.41 35.66727097597688 139.74482826503808 14.41 35.66726188279906 139.74481828964397 14.41 35.66729614560023 139.74477141748216 14.41 35.667275938517875 139.74474923767704 14.41 35.66724174776192 139.74479601034452 14.41 35.667232221565015 139.7447855494195 14.41 35.66722087566999 139.7448010702862 14.41 35.667230410879256 139.7448115312016 14.41</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-c10f1afa-ecbc-4459-930a-194a0a001171"/>
							<gml:surfaceMember xlink:href="#poly-2898db5c-4147-4980-91b3-1494d714a9c1"/>
							<gml:surfaceMember xlink:href="#poly-02e025e3-7c8e-4b32-9fc5-a75b23ce8124"/>
							<gml:surfaceMember xlink:href="#poly-e86d6996-5a48-467f-a7a2-6599cb0d0db1"/>
							<gml:surfaceMember xlink:href="#poly-142ecd44-b73d-4c2a-a2a7-9880f8275200"/>
							<gml:surfaceMember xlink:href="#poly-e2f587c1-eca4-450a-8df0-eacc30f84b4d"/>
							<gml:surfaceMember xlink:href="#poly-cc7ca7a3-1ee5-417e-91ec-403e83f52bf8"/>
							<gml:surfaceMember xlink:href="#poly-5a88b3da-bdbb-48bf-8a7f-7c8782cf3697"/>
							<gml:surfaceMember xlink:href="#poly-9fb71f75-42a6-4fcc-9d33-102220d615f7"/>
							<gml:surfaceMember xlink:href="#poly-54acd916-f7b8-4ab3-b2ea-680c9b0ef657"/>
							<gml:surfaceMember xlink:href="#poly-aedb0c73-8c89-4ab0-a3fa-5478a3c51655"/>
							<gml:surfaceMember xlink:href="#poly-e8703120-f3fe-4c77-a472-40033b413b27"/>
							<gml:surfaceMember xlink:href="#poly-0c264bcf-d076-4b64-9fe7-d5b4bb9512b7"/>
							<gml:surfaceMember xlink:href="#poly-3354cd0f-a1aa-4c72-893d-5c07eb117e8f"/>
							<gml:surfaceMember xlink:href="#poly-4a6ebc1c-054e-46d3-a20c-75f279963540"/>
							<gml:surfaceMember xlink:href="#poly-04b893c4-d693-42af-a453-91fdb3d95c4a"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-c10f1afa-ecbc-4459-930a-194a0a001171">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c10f1afa-ecbc-4459-930a-194a0a001171">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c10f1afa-ecbc-4459-930a-194a0a001171">
											<gml:posList>35.667250302396766 139.7448336119457 8.92 35.667228285948404 139.7448637361195 8.92 35.66720828636901 139.7448417880431 8.92 35.667230410879256 139.7448115312016 8.92 35.667220875669976 139.74480107028617 8.92 35.66723222156502 139.74478554941948 8.92 35.667241747761906 139.7447960103445 8.92 35.66727593851784 139.74474923767704 8.92 35.667296145600226 139.74477141748216 8.92 35.667261882799046 139.74481828964397 8.92 35.66727097597688 139.74482826503808 8.92 35.66725960305956 139.74484381907357 8.92 35.667250302396766 139.7448336119457 8.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-2898db5c-4147-4980-91b3-1494d714a9c1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2898db5c-4147-4980-91b3-1494d714a9c1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2898db5c-4147-4980-91b3-1494d714a9c1">
											<gml:posList>35.667250302396766 139.7448336119457 14.1 35.66725960305956 139.74484381907357 14.1 35.66727097597688 139.74482826503808 14.1 35.667261882799046 139.74481828964397 14.1 35.66726884341182 139.7448087604539 14.1 35.66724864534994 139.7447865806369 14.1 35.667241747761906 139.7447960103445 14.1 35.66723222156502 139.74478554941948 14.1 35.667220875669976 139.74480107028617 14.1 35.667230410879256 139.7448115312016 14.1 35.66720828636901 139.7448417880431 14.1 35.667228285948404 139.7448637361195 14.1 35.667250302396766 139.7448336119457 14.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-02e025e3-7c8e-4b32-9fc5-a75b23ce8124">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-02e025e3-7c8e-4b32-9fc5-a75b23ce8124">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-02e025e3-7c8e-4b32-9fc5-a75b23ce8124">
											<gml:posList>35.66726884341182 139.7448087604539 16.726 35.667296145600226 139.74477141748216 16.726 35.66727593851784 139.74474923767704 16.726 35.66724864534994 139.7447865806369 16.726 35.66726884341182 139.7448087604539 16.726</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e86d6996-5a48-467f-a7a2-6599cb0d0db1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e86d6996-5a48-467f-a7a2-6599cb0d0db1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e86d6996-5a48-467f-a7a2-6599cb0d0db1">
											<gml:posList>35.66720828636901 139.7448417880431 8.92 35.667228285948404 139.7448637361195 8.92 35.667228285948404 139.7448637361195 14.1 35.66720828636901 139.7448417880431 14.1 35.66720828636901 139.7448417880431 8.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-142ecd44-b73d-4c2a-a2a7-9880f8275200">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-142ecd44-b73d-4c2a-a2a7-9880f8275200">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-142ecd44-b73d-4c2a-a2a7-9880f8275200">
											<gml:posList>35.667230410879256 139.7448115312016 8.92 35.66720828636901 139.7448417880431 8.92 35.66720828636901 139.7448417880431 14.1 35.667230410879256 139.7448115312016 14.1 35.667230410879256 139.7448115312016 8.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e2f587c1-eca4-450a-8df0-eacc30f84b4d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e2f587c1-eca4-450a-8df0-eacc30f84b4d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e2f587c1-eca4-450a-8df0-eacc30f84b4d">
											<gml:posList>35.667220875669976 139.74480107028617 8.92 35.667230410879256 139.7448115312016 8.92 35.667230410879256 139.7448115312016 14.1 35.667220875669976 139.74480107028617 14.1 35.667220875669976 139.74480107028617 8.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-cc7ca7a3-1ee5-417e-91ec-403e83f52bf8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cc7ca7a3-1ee5-417e-91ec-403e83f52bf8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cc7ca7a3-1ee5-417e-91ec-403e83f52bf8">
											<gml:posList>35.66723222156502 139.74478554941948 8.92 35.667220875669976 139.74480107028617 8.92 35.667220875669976 139.74480107028617 14.1 35.66723222156502 139.74478554941948 14.1 35.66723222156502 139.74478554941948 8.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5a88b3da-bdbb-48bf-8a7f-7c8782cf3697">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5a88b3da-bdbb-48bf-8a7f-7c8782cf3697">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5a88b3da-bdbb-48bf-8a7f-7c8782cf3697">
											<gml:posList>35.667241747761906 139.7447960103445 8.92 35.66723222156502 139.74478554941948 8.92 35.66723222156502 139.74478554941948 14.1 35.667241747761906 139.7447960103445 14.1 35.667241747761906 139.7447960103445 8.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9fb71f75-42a6-4fcc-9d33-102220d615f7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9fb71f75-42a6-4fcc-9d33-102220d615f7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9fb71f75-42a6-4fcc-9d33-102220d615f7">
											<gml:posList>35.667228285948404 139.7448637361195 8.92 35.667250302396766 139.7448336119457 8.92 35.667250302396766 139.7448336119457 14.1 35.667228285948404 139.7448637361195 14.1 35.667228285948404 139.7448637361195 8.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-54acd916-f7b8-4ab3-b2ea-680c9b0ef657">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-54acd916-f7b8-4ab3-b2ea-680c9b0ef657">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-54acd916-f7b8-4ab3-b2ea-680c9b0ef657">
											<gml:posList>35.667250302396766 139.7448336119457 8.92 35.66725960305956 139.74484381907357 8.92 35.66725960305956 139.74484381907357 14.1 35.667250302396766 139.7448336119457 14.1 35.667250302396766 139.7448336119457 8.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-aedb0c73-8c89-4ab0-a3fa-5478a3c51655">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-aedb0c73-8c89-4ab0-a3fa-5478a3c51655">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-aedb0c73-8c89-4ab0-a3fa-5478a3c51655">
											<gml:posList>35.66726884341182 139.7448087604539 14.1 35.66726884341182 139.7448087604539 16.726 35.66724864534994 139.7447865806369 16.726 35.66724864534994 139.7447865806369 14.1 35.66726884341182 139.7448087604539 14.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e8703120-f3fe-4c77-a472-40033b413b27">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e8703120-f3fe-4c77-a472-40033b413b27">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e8703120-f3fe-4c77-a472-40033b413b27">
											<gml:posList>35.667241747761906 139.7447960103445 8.92 35.667241747761906 139.7447960103445 14.1 35.66724864534994 139.7447865806369 14.1 35.66724864534994 139.7447865806369 16.726 35.66727593851784 139.74474923767704 16.726 35.66727593851784 139.74474923767704 8.92 35.667241747761906 139.7447960103445 8.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0c264bcf-d076-4b64-9fe7-d5b4bb9512b7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0c264bcf-d076-4b64-9fe7-d5b4bb9512b7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0c264bcf-d076-4b64-9fe7-d5b4bb9512b7">
											<gml:posList>35.66725960305956 139.74484381907357 8.92 35.66727097597688 139.74482826503808 8.92 35.66727097597688 139.74482826503808 14.1 35.66725960305956 139.74484381907357 14.1 35.66725960305956 139.74484381907357 8.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3354cd0f-a1aa-4c72-893d-5c07eb117e8f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3354cd0f-a1aa-4c72-893d-5c07eb117e8f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3354cd0f-a1aa-4c72-893d-5c07eb117e8f">
											<gml:posList>35.66727097597688 139.74482826503808 8.92 35.667261882799046 139.74481828964397 8.92 35.667261882799046 139.74481828964397 14.1 35.66727097597688 139.74482826503808 14.1 35.66727097597688 139.74482826503808 8.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4a6ebc1c-054e-46d3-a20c-75f279963540">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4a6ebc1c-054e-46d3-a20c-75f279963540">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4a6ebc1c-054e-46d3-a20c-75f279963540">
											<gml:posList>35.667296145600226 139.74477141748216 8.92 35.667296145600226 139.74477141748216 16.726 35.66726884341182 139.7448087604539 16.726 35.66726884341182 139.7448087604539 14.1 35.667261882799046 139.74481828964397 14.1 35.667261882799046 139.74481828964397 8.92 35.667296145600226 139.74477141748216 8.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-04b893c4-d693-42af-a453-91fdb3d95c4a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-04b893c4-d693-42af-a453-91fdb3d95c4a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-04b893c4-d693-42af-a453-91fdb3d95c4a">
											<gml:posList>35.667296145600226 139.74477141748216 8.92 35.66727593851784 139.74474923767704 8.92 35.66727593851784 139.74474923767704 16.726 35.667296145600226 139.74477141748216 16.726 35.667296145600226 139.74477141748216 8.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-8450</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>6</uro:specifiedFloorAreaRate>
					<uro:surveyYear>0001</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.04</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>