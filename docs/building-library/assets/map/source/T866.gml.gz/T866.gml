<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_f87dfdfd-ddc2-49e6-a33e-78b82a6c1234">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>3</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001003</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">401</bldg:usage>
			<bldg:measuredHeight uom="m">36.4</bldg:measuredHeight>
			<bldg:storeysAboveGround>9</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.673471626983485 139.73863958441956 0 35.67345670869156 139.73859301817802 0 35.673357793429275 139.73864059156466 0 35.673389962319085 139.73874240390168 0 35.67351871872257 139.7387938400318 0 35.67354241413074 139.73878022465385 0 35.67349345888939 139.738628964858 0 35.673471626983485 139.73863958441956 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.673471626983485 139.73863958441956 7.53 35.67349345888939 139.738628964858 7.53 35.67354241413074 139.73878022465385 7.53 35.67351871872257 139.7387938400318 7.53 35.673389962319085 139.73874240390168 7.53 35.673357793429275 139.73864059156466 7.53 35.67345670869156 139.73859301817802 7.53 35.673471626983485 139.73863958441956 7.53</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.673471626983485 139.73863958441956 7.53 35.67345670869156 139.73859301817802 7.53 35.67345670869156 139.73859301817802 37.93 35.673471626983485 139.73863958441956 37.93 35.673471626983485 139.73863958441956 7.53</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67345670869156 139.73859301817802 7.53 35.673357793429275 139.73864059156466 7.53 35.673357793429275 139.73864059156466 37.93 35.67345670869156 139.73859301817802 37.93 35.67345670869156 139.73859301817802 7.53</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.673357793429275 139.73864059156466 7.53 35.673389962319085 139.73874240390168 7.53 35.673389962319085 139.73874240390168 37.93 35.673357793429275 139.73864059156466 37.93 35.673357793429275 139.73864059156466 7.53</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.673389962319085 139.73874240390168 7.53 35.67351871872257 139.7387938400318 7.53 35.67351871872257 139.7387938400318 37.93 35.673389962319085 139.73874240390168 37.93 35.673389962319085 139.73874240390168 7.53</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67351871872257 139.7387938400318 7.53 35.67354241413074 139.73878022465385 7.53 35.67354241413074 139.73878022465385 37.93 35.67351871872257 139.7387938400318 37.93 35.67351871872257 139.7387938400318 7.53</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67354241413074 139.73878022465385 7.53 35.67349345888939 139.738628964858 7.53 35.67349345888939 139.738628964858 37.93 35.67354241413074 139.73878022465385 37.93 35.67354241413074 139.73878022465385 7.53</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67349345888939 139.738628964858 7.53 35.673471626983485 139.73863958441956 7.53 35.673471626983485 139.73863958441956 37.93 35.67349345888939 139.738628964858 37.93 35.67349345888939 139.738628964858 7.53</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.673471626983485 139.73863958441956 37.93 35.67345670869156 139.73859301817802 37.93 35.673357793429275 139.73864059156466 37.93 35.673389962319085 139.73874240390168 37.93 35.67351871872257 139.7387938400318 37.93 35.67354241413074 139.73878022465385 37.93 35.67349345888939 139.738628964858 37.93 35.673471626983485 139.73863958441956 37.93</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-fcc070b0-16ca-4cae-9d81-44e95e486ea4"/>
							<gml:surfaceMember xlink:href="#poly-c9976a41-4d2f-4b35-b1ea-03902a6d2a39"/>
							<gml:surfaceMember xlink:href="#poly-4182c683-4c7a-460d-bb9d-8b5be25deb5f"/>
							<gml:surfaceMember xlink:href="#poly-765f3c37-782a-4c94-9b0f-f91c64d4c2e5"/>
							<gml:surfaceMember xlink:href="#poly-3f3dd70f-fa17-446f-8779-ceddc0827b96"/>
							<gml:surfaceMember xlink:href="#poly-6a534daf-466d-4ff8-bc40-d79eb467bbf6"/>
							<gml:surfaceMember xlink:href="#poly-9f6676a3-f31c-4b3d-af0b-daa0e5bcafb9"/>
							<gml:surfaceMember xlink:href="#poly-a4c2f33e-bff2-42c5-a1f5-64d9f2f294e6"/>
							<gml:surfaceMember xlink:href="#poly-5f9ad90f-ab7f-44e4-a15c-16ab53eb5f98"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_f87dfdfd-ddc2-49e6-a33e-78b82a6c1234_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7d49367a-25ee-4f0a-ac0a-15b8a623c66c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7d49367a-25ee-4f0a-ac0a-15b8a623c66c_0">
											<gml:posList>35.67339285083832 139.73865590503328 48.546 35.67339285083832 139.73865590503328 46.552 35.67339705181445 139.73866810664782 46.552 35.67339705181445 139.73866810664782 48.546 35.67339285083832 139.73865590503328 48.546</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9e23e910-7d85-4220-ba5d-1e1f06ed470a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9e23e910-7d85-4220-ba5d-1e1f06ed470a_0">
											<gml:posList>35.67339705181445 139.73866810664782 48.546 35.67339705181445 139.73866810664782 46.552 35.673398673640946 139.73866728727876 46.552 35.673398673640946 139.73866728727876 48.546 35.67339705181445 139.73866810664782 48.546</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c7aadf1b-990d-4c17-995b-2478f5bbd890">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c7aadf1b-990d-4c17-995b-2478f5bbd890_0">
											<gml:posList>35.67340665429459 139.73864881885888 48.546 35.67340665429459 139.73864881885888 46.552 35.67339285083832 139.73865590503328 46.552 35.67339285083832 139.73865590503328 48.546 35.67340665429459 139.73864881885888 48.546</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6cf97cb9-d6d2-4124-893c-12917b36543c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6cf97cb9-d6d2-4124-893c-12917b36543c_0">
											<gml:posList>35.673398673640946 139.73866728727876 48.546 35.6734003631577 139.73867231152101 48.546 35.67341057159197 139.73866707438904 48.546 35.67340894540554 139.7386623483317 48.546 35.67341091861064 139.7386613297073 48.546 35.67340665429459 139.73864881885888 48.546 35.67339285083832 139.73865590503328 48.546 35.67339705181445 139.73866810664782 48.546 35.673398673640946 139.73866728727876 48.546</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-94cc55c4-fcec-4fb3-bd7c-e9e1c3a2e2e6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-94cc55c4-fcec-4fb3-bd7c-e9e1c3a2e2e6_0">
											<gml:posList>35.6734003631577 139.73867231152101 48.546 35.6734003631577 139.73867231152101 46.552 35.67341057159197 139.73866707438904 46.552 35.67341057159197 139.73866707438904 48.546 35.6734003631577 139.73867231152101 48.546</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-027315b0-05ab-4dc5-a5bd-37c81c588f69">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-027315b0-05ab-4dc5-a5bd-37c81c588f69_0">
											<gml:posList>35.67336065979153 139.738640588179 46.552 35.67336065979153 139.738640588179 51.413 35.67345635828649 139.7385944546609 51.413 35.67345635828649 139.7385944546609 46.552 35.67336065979153 139.738640588179 46.552</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3d16bca8-6d14-4b5c-8091-998b1f209d9d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3d16bca8-6d14-4b5c-8091-998b1f209d9d_0">
											<gml:posList>35.67341091861064 139.7386613297073 48.546 35.67341091861064 139.7386613297073 46.552 35.67340665429459 139.73864881885888 46.552 35.67340665429459 139.73864881885888 48.546 35.67341091861064 139.7386613297073 48.546</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3144ee53-35e7-4fc3-b806-49930f5afa4d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3144ee53-35e7-4fc3-b806-49930f5afa4d_0">
											<gml:posList>35.67336411269698 139.73864141260083 51.413 35.67336411269698 139.73864141260083 46.552 35.67345506283169 139.73859765972983 46.552 35.67345506283169 139.73859765972983 51.413 35.67336411269698 139.73864141260083 51.413</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-90ca0660-4912-4f17-9c86-fa3c033f2728">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-90ca0660-4912-4f17-9c86-fa3c033f2728_0">
											<gml:posList>35.67341057159197 139.73866707438904 48.546 35.67341057159197 139.73866707438904 46.552 35.67340894540554 139.7386623483317 46.552 35.67340894540554 139.7386623483317 48.546 35.67341057159197 139.73866707438904 48.546</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-60353381-7433-4498-8787-db5327c0d2b7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-60353381-7433-4498-8787-db5327c0d2b7_0">
											<gml:posList>35.67340894540554 139.7386623483317 48.546 35.67340894540554 139.7386623483317 46.552 35.67341091861064 139.7386613297073 46.552 35.67341091861064 139.7386613297073 48.546 35.67340894540554 139.7386623483317 48.546</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8eafac40-7b04-4bf9-ae57-4b013d4319bb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8eafac40-7b04-4bf9-ae57-4b013d4319bb_0">
											<gml:posList>35.67345506283169 139.73859765972983 46.552 35.67348367959852 139.73868704884336 46.552 35.67348367959852 139.73868704884336 51.413 35.67345506283169 139.73859765972983 51.413 35.67345506283169 139.73859765972983 46.552</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-834257b7-fd51-4ff5-8e2a-dc83339b17f7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-834257b7-fd51-4ff5-8e2a-dc83339b17f7_0">
											<gml:posList>35.67348491105658 139.7386826949948 51.413 35.67348491105658 139.7386826949948 46.552 35.67345635828649 139.7385944546609 46.552 35.67345635828649 139.7385944546609 51.413 35.67348491105658 139.7386826949948 51.413</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-971992b4-b6aa-4e1a-a658-3208917a89da">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-971992b4-b6aa-4e1a-a658-3208917a89da_0">
											<gml:posList>35.673398673640946 139.73866728727876 48.546 35.673398673640946 139.73866728727876 46.552 35.6734003631577 139.73867231152101 46.552 35.6734003631577 139.73867231152101 48.546 35.673398673640946 139.73866728727876 48.546</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-69d9bdcf-4857-4d93-acd2-d20d420dc995">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-69d9bdcf-4857-4d93-acd2-d20d420dc995_0">
											<gml:posList>35.673491280871914 139.7386790199739 51.413 35.673491280871914 139.7386790199739 46.552 35.67348491105658 139.7386826949948 46.552 35.67348491105658 139.7386826949948 51.413 35.673491280871914 139.7386790199739 51.413</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-efe04ccb-7415-400c-bab1-fd4927e6bd8c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-efe04ccb-7415-400c-bab1-fd4927e6bd8c_0">
											<gml:posList>35.67348367959852 139.73868704884336 51.413 35.67348367959852 139.73868704884336 46.552 35.67348973424647 139.7386837718757 46.552 35.67348973424647 139.7386837718757 51.413 35.67348367959852 139.73868704884336 51.413</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4695c3fe-45a5-4b2c-8908-107fd93e65dd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4695c3fe-45a5-4b2c-8908-107fd93e65dd_0">
											<gml:posList>35.67339457030432 139.7387334396116 51.413 35.67339457030432 139.7387334396116 46.552 35.67336411269698 139.73864141260083 46.552 35.67336411269698 139.73864141260083 51.413 35.67339457030432 139.7387334396116 51.413</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fdebc6e1-3443-482c-97d7-d31ecda6e6a8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fdebc6e1-3443-482c-97d7-d31ecda6e6a8_0">
											<gml:posList>35.673392355177555 139.73873630331414 46.552 35.673392355177555 139.73873630331414 51.413 35.67336065979153 139.738640588179 51.413 35.67336065979153 139.738640588179 46.552 35.673392355177555 139.73873630331414 46.552</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8a08ed95-90f8-403c-9d36-e086cdbf7370">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8a08ed95-90f8-403c-9d36-e086cdbf7370_0">
											<gml:posList>35.67339457030432 139.7387334396116 51.413 35.673392355177555 139.73873630331414 51.413 35.67351724589578 139.73878926843838 51.413 35.67351710767148 139.73878542435276 51.413 35.67339457030432 139.7387334396116 51.413</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b9e0d6a1-7635-48c1-8dfc-a8f03b495f98">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b9e0d6a1-7635-48c1-8dfc-a8f03b495f98_0">
											<gml:posList>35.673491280871914 139.7386790199739 46.552 35.673491280871914 139.7386790199739 51.413 35.67352695860651 139.73878406503835 51.413 35.67352695860651 139.73878406503835 46.552 35.673491280871914 139.7386790199739 46.552</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f555f5c2-67d4-4acd-8e3a-a16e69ff34c8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f555f5c2-67d4-4acd-8e3a-a16e69ff34c8_0">
											<gml:posList>35.67348973424647 139.7386837718757 46.552 35.67352316235678 139.73878219157788 46.552 35.67352316235678 139.73878219157788 51.413 35.67348973424647 139.7386837718757 51.413 35.67348973424647 139.7386837718757 46.552</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-63d44b71-6101-4165-8ecc-e51b32c3c53a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-63d44b71-6101-4165-8ecc-e51b32c3c53a_0">
											<gml:posList>35.67339457030432 139.7387334396116 46.552 35.67339457030432 139.7387334396116 51.413 35.67351710767148 139.73878542435276 51.413 35.67351710767148 139.73878542435276 46.552 35.67339457030432 139.7387334396116 46.552</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5a502156-e1a8-472b-aff1-66ac418212c2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5a502156-e1a8-472b-aff1-66ac418212c2_0">
											<gml:posList>35.673392355177555 139.73873630331414 51.413 35.673392355177555 139.73873630331414 46.552 35.67351724589578 139.73878926843838 46.552 35.67351724589578 139.73878926843838 51.413 35.673392355177555 139.73873630331414 51.413</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7624d363-83e7-494c-956c-70d61d705bd3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7624d363-83e7-494c-956c-70d61d705bd3_0">
											<gml:posList>35.67352316235678 139.73878219157788 51.413 35.67352316235678 139.73878219157788 46.552 35.67351710767148 139.73878542435276 46.552 35.67351710767148 139.73878542435276 51.413 35.67352316235678 139.73878219157788 51.413</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9d123def-93da-46c6-99ca-0d8dab7da93d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9d123def-93da-46c6-99ca-0d8dab7da93d_0">
											<gml:posList>35.67351724589578 139.73878926843838 51.413 35.67351724589578 139.73878926843838 46.552 35.67352695860651 139.73878406503835 46.552 35.67352695860651 139.73878406503835 51.413 35.67351724589578 139.73878926843838 51.413</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e1923bb8-9bf0-4e0c-8c81-2cb38ebf9846">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e1923bb8-9bf0-4e0c-8c81-2cb38ebf9846_0">
											<gml:posList>35.67352695860651 139.73878406503835 51.413 35.673491280871914 139.7386790199739 51.413 35.67348973424647 139.7386837718757 51.413 35.67352316235678 139.73878219157788 51.413 35.67352695860651 139.73878406503835 51.413</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-85987325-ba04-407c-a561-d5efe3719790">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-85987325-ba04-407c-a561-d5efe3719790_0">
											<gml:posList>35.67352695860651 139.73878406503835 51.413 35.67352316235678 139.73878219157788 51.413 35.67351710767148 139.73878542435276 51.413 35.67352695860651 139.73878406503835 51.413</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3616cafb-404b-4822-8dd5-152c1cb6c367">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3616cafb-404b-4822-8dd5-152c1cb6c367_0">
											<gml:posList>35.67351724589578 139.73878926843838 51.413 35.67352695860651 139.73878406503835 51.413 35.67351710767148 139.73878542435276 51.413 35.67351724589578 139.73878926843838 51.413</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-59afd605-e1f1-4051-9a94-e88912d73d75">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-59afd605-e1f1-4051-9a94-e88912d73d75_0">
											<gml:posList>35.673491280871914 139.7386790199739 51.413 35.67348491105658 139.7386826949948 51.413 35.67348367959852 139.73868704884336 51.413 35.67348973424647 139.7386837718757 51.413 35.673491280871914 139.7386790199739 51.413</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-31b6d2a2-1d8e-47d0-ad1d-1d159d01d238">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-31b6d2a2-1d8e-47d0-ad1d-1d159d01d238_0">
											<gml:posList>35.67348491105658 139.7386826949948 51.413 35.67345635828649 139.7385944546609 51.413 35.67345506283169 139.73859765972983 51.413 35.67348367959852 139.73868704884336 51.413 35.67348491105658 139.7386826949948 51.413</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-faac7106-84b9-48b1-8655-469d1b652f67">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-faac7106-84b9-48b1-8655-469d1b652f67_0">
											<gml:posList>35.67339457030432 139.7387334396116 51.413 35.67336411269698 139.73864141260083 51.413 35.67336065979153 139.738640588179 51.413 35.673392355177555 139.73873630331414 51.413 35.67339457030432 139.7387334396116 51.413</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d86752c8-8b55-4be2-b885-96741d03156b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d86752c8-8b55-4be2-b885-96741d03156b_0">
											<gml:posList>35.67345635828649 139.7385944546609 51.413 35.67336065979153 139.738640588179 51.413 35.67336411269698 139.73864141260083 51.413 35.67345506283169 139.73859765972983 51.413 35.67345635828649 139.7385944546609 51.413</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6999706e-960b-4a86-8b4a-28cf2b7b8e68">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67339285083832 139.73865590503328 46.552 35.67340665429459 139.73864881885888 46.552 35.67341091861064 139.7386613297073 46.552 35.67340894540554 139.7386623483317 46.552 35.67341057159197 139.73866707438904 46.552 35.6734003631577 139.73867231152101 46.552 35.673398673640946 139.73866728727876 46.552 35.67339705181445 139.73866810664782 46.552 35.67339285083832 139.73865590503328 46.552</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a9dc1cd0-9c48-4e04-b15f-fee811b1b012">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67336065979153 139.738640588179 46.552 35.67336411269698 139.73864141260083 46.552 35.67339457030432 139.7387334396116 46.552 35.673392355177555 139.73873630331414 46.552 35.67336065979153 139.738640588179 46.552</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f0ade299-39c9-41b5-9f2d-301fe46932fe">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67348367959852 139.73868704884336 46.552 35.67345506283169 139.73859765972983 46.552 35.67345635828649 139.7385944546609 46.552 35.67348491105658 139.7386826949948 46.552 35.67348367959852 139.73868704884336 46.552</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-acc4034c-97c3-4ca1-9db6-aafc59ce39e9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67348973424647 139.7386837718757 46.552 35.67348367959852 139.73868704884336 46.552 35.67348491105658 139.7386826949948 46.552 35.67348973424647 139.7386837718757 46.552</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c7a51330-01ab-430c-a78f-a2aaa6a494dd">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67348973424647 139.7386837718757 46.552 35.67348491105658 139.7386826949948 46.552 35.673491280871914 139.7386790199739 46.552 35.67348973424647 139.7386837718757 46.552</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c9f96f43-6a6c-4d9f-ad88-0572f5c11a01">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67351710767148 139.73878542435276 46.552 35.67352316235678 139.73878219157788 46.552 35.67352695860651 139.73878406503835 46.552 35.67351724589578 139.73878926843838 46.552 35.67351710767148 139.73878542435276 46.552</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4129ea09-f83d-4c66-b632-304820288148">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67352316235678 139.73878219157788 46.552 35.67348973424647 139.7386837718757 46.552 35.673491280871914 139.7386790199739 46.552 35.67352695860651 139.73878406503835 46.552 35.67352316235678 139.73878219157788 46.552</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ca29f6e0-6e37-4555-823e-aa6781764c81">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67339457030432 139.7387334396116 46.552 35.67351710767148 139.73878542435276 46.552 35.67351724589578 139.73878926843838 46.552 35.673392355177555 139.73873630331414 46.552 35.67339457030432 139.7387334396116 46.552</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-51a4377d-e0a2-4277-9b98-0543627089da">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67336065979153 139.738640588179 46.552 35.67345506283169 139.73859765972983 46.552 35.67336411269698 139.73864141260083 46.552 35.67336065979153 139.738640588179 46.552</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-41eda230-883d-4343-8a37-5c1602a50ae6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67345506283169 139.73859765972983 46.552 35.67336065979153 139.738640588179 46.552 35.67345635828649 139.7385944546609 46.552 35.67345506283169 139.73859765972983 46.552</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_f87dfdfd-ddc2-49e6-a33e-78b82a6c1234_BuildingInstallation_1060">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f03174d3-9261-4c34-8d5e-2d21cfdb2cc4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67345671770528 139.73859301816734 8.05 35.673478441572875 139.73858256442307 8.05 35.67349345888937 139.738628964858 8.05 35.67347162698347 139.73863958441956 8.05 35.67345671770528 139.73859301816734 8.05</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-01dce49f-788a-45ea-96c0-b6c0351b4e16">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-01dce49f-788a-45ea-96c0-b6c0351b4e16_0">
											<gml:posList>35.67347162698347 139.73863958441956 46.552 35.67345671770528 139.73859301816734 46.552 35.67345671770528 139.73859301816734 8.05 35.67347162698347 139.73863958441956 8.05 35.67347162698347 139.73863958441956 46.552</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cc42e19c-0def-4b2f-8afc-8b2341359843">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cc42e19c-0def-4b2f-8afc-8b2341359843_0">
											<gml:posList>35.67345671770528 139.73859301816734 46.552 35.673478441572875 139.73858256442307 46.552 35.673478441572875 139.73858256442307 8.05 35.67345671770528 139.73859301816734 8.05 35.67345671770528 139.73859301816734 46.552</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-79bf37bd-ec43-4b37-a86c-4b74498c8300">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-79bf37bd-ec43-4b37-a86c-4b74498c8300_0">
											<gml:posList>35.673478441572875 139.73858256442307 46.552 35.67345671770528 139.73859301816734 46.552 35.67347162698347 139.73863958441956 46.552 35.67349345888937 139.738628964858 46.552 35.673478441572875 139.73858256442307 46.552</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cd98a36a-a16e-4ee2-8911-24898ce16cd9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cd98a36a-a16e-4ee2-8911-24898ce16cd9_0">
											<gml:posList>35.67349345888937 139.738628964858 46.552 35.67347162698347 139.73863958441956 46.552 35.67347162698347 139.73863958441956 8.05 35.67349345888937 139.738628964858 8.05 35.67349345888937 139.738628964858 46.552</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3c76cd2a-77c8-4461-a150-de6e0a2a6faf">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3c76cd2a-77c8-4461-a150-de6e0a2a6faf_0">
											<gml:posList>35.673478441572875 139.73858256442307 46.552 35.67349345888937 139.738628964858 46.552 35.67349345888937 139.738628964858 8.05 35.673478441572875 139.73858256442307 8.05 35.673478441572875 139.73858256442307 46.552</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_f87dfdfd-ddc2-49e6-a33e-78b82a6c1234_BuildingInstallation_1041">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-82b7baca-d811-4af7-b820-b89eaaff0569">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67346144137557 139.7386967851327 46.552 35.67342552697793 139.73871499931536 46.552 35.67341759446796 139.738691512394 46.552 35.673453517875785 139.73867329819205 46.552 35.67346144137557 139.7386967851327 46.552</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-683c37b7-6764-4821-a728-70c6ec678088">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-683c37b7-6764-4821-a728-70c6ec678088_0">
											<gml:posList>35.67341759446796 139.738691512394 48.661 35.67341759446796 139.738691512394 46.552 35.67342552697793 139.73871499931536 46.552 35.67342552697793 139.73871499931536 48.661 35.67341759446796 139.738691512394 48.661</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d8fc2266-1ae4-4c71-b7c5-3c97990483e3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d8fc2266-1ae4-4c71-b7c5-3c97990483e3_0">
											<gml:posList>35.673453517875785 139.73867329819205 46.552 35.67341759446796 139.738691512394 46.552 35.67341759446796 139.738691512394 48.661 35.673453517875785 139.73867329819205 48.661 35.673453517875785 139.73867329819205 46.552</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-087c5873-332a-4735-8038-80fbe7c1f4db">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-087c5873-332a-4735-8038-80fbe7c1f4db_0">
											<gml:posList>35.67341759446796 139.738691512394 48.661 35.67342552697793 139.73871499931536 48.661 35.67346144137557 139.7386967851327 48.661 35.673453517875785 139.73867329819205 48.661 35.67341759446796 139.738691512394 48.661</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-20b408ef-9cf4-41ce-a23a-0bf93b605579">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-20b408ef-9cf4-41ce-a23a-0bf93b605579_0">
											<gml:posList>35.67342552697793 139.73871499931536 46.552 35.67346144137557 139.7386967851327 46.552 35.67346144137557 139.7386967851327 48.661 35.67342552697793 139.73871499931536 48.661 35.67342552697793 139.73871499931536 46.552</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cd280416-e89e-44a8-be16-730bbe1fe68f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cd280416-e89e-44a8-be16-730bbe1fe68f_0">
											<gml:posList>35.67346144137557 139.7386967851327 48.661 35.67346144137557 139.7386967851327 46.552 35.673453517875785 139.73867329819205 46.552 35.673453517875785 139.73867329819205 48.661 35.67346144137557 139.7386967851327 48.661</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-fcc070b0-16ca-4cae-9d81-44e95e486ea4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fcc070b0-16ca-4cae-9d81-44e95e486ea4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fcc070b0-16ca-4cae-9d81-44e95e486ea4">
											<gml:posList>35.67338996231907 139.73874240390165 7.53 35.67335779342928 139.73864059156466 7.53 35.67345670869156 139.738593018178 7.53 35.67347162698347 139.73863958441956 7.53 35.67349345888937 139.738628964858 7.53 35.67354241413072 139.73878022465385 7.53 35.67351871872259 139.7387938400318 7.53 35.67338996231907 139.73874240390165 7.53</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c9976a41-4d2f-4b35-b1ea-03902a6d2a39">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c9976a41-4d2f-4b35-b1ea-03902a6d2a39">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c9976a41-4d2f-4b35-b1ea-03902a6d2a39">
											<gml:posList>35.67347162698347 139.73863958441956 46.552 35.67345670869156 139.738593018178 46.552 35.67335779342928 139.73864059156466 46.552 35.67338996231907 139.73874240390165 46.552 35.67351871872259 139.7387938400318 46.552 35.67354241413072 139.73878022465385 46.552 35.67349345888937 139.738628964858 46.552 35.67347162698347 139.73863958441956 46.552</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4182c683-4c7a-460d-bb9d-8b5be25deb5f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4182c683-4c7a-460d-bb9d-8b5be25deb5f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4182c683-4c7a-460d-bb9d-8b5be25deb5f">
											<gml:posList>35.67347162698347 139.73863958441956 7.53 35.67345670869156 139.738593018178 7.53 35.67345670869156 139.738593018178 46.552 35.67347162698347 139.73863958441956 46.552 35.67347162698347 139.73863958441956 7.53</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-765f3c37-782a-4c94-9b0f-f91c64d4c2e5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-765f3c37-782a-4c94-9b0f-f91c64d4c2e5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-765f3c37-782a-4c94-9b0f-f91c64d4c2e5">
											<gml:posList>35.67345670869156 139.738593018178 7.53 35.67335779342928 139.73864059156466 7.53 35.67335779342928 139.73864059156466 46.552 35.67345670869156 139.738593018178 46.552 35.67345670869156 139.738593018178 7.53</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3f3dd70f-fa17-446f-8779-ceddc0827b96">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3f3dd70f-fa17-446f-8779-ceddc0827b96">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3f3dd70f-fa17-446f-8779-ceddc0827b96">
											<gml:posList>35.67349345888937 139.738628964858 7.53 35.67347162698347 139.73863958441956 7.53 35.67347162698347 139.73863958441956 46.552 35.67349345888937 139.738628964858 46.552 35.67349345888937 139.738628964858 7.53</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6a534daf-466d-4ff8-bc40-d79eb467bbf6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6a534daf-466d-4ff8-bc40-d79eb467bbf6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6a534daf-466d-4ff8-bc40-d79eb467bbf6">
											<gml:posList>35.67335779342928 139.73864059156466 7.53 35.67338996231907 139.73874240390165 7.53 35.67338996231907 139.73874240390165 46.552 35.67335779342928 139.73864059156466 46.552 35.67335779342928 139.73864059156466 7.53</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9f6676a3-f31c-4b3d-af0b-daa0e5bcafb9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9f6676a3-f31c-4b3d-af0b-daa0e5bcafb9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9f6676a3-f31c-4b3d-af0b-daa0e5bcafb9">
											<gml:posList>35.67338996231907 139.73874240390165 7.53 35.67351871872259 139.7387938400318 7.53 35.67351871872259 139.7387938400318 46.552 35.67338996231907 139.73874240390165 46.552 35.67338996231907 139.73874240390165 7.53</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a4c2f33e-bff2-42c5-a1f5-64d9f2f294e6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a4c2f33e-bff2-42c5-a1f5-64d9f2f294e6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a4c2f33e-bff2-42c5-a1f5-64d9f2f294e6">
											<gml:posList>35.67354241413072 139.73878022465385 7.53 35.67349345888937 139.738628964858 7.53 35.67349345888937 139.738628964858 46.552 35.67354241413072 139.73878022465385 46.552 35.67354241413072 139.73878022465385 7.53</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5f9ad90f-ab7f-44e4-a15c-16ab53eb5f98">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5f9ad90f-ab7f-44e4-a15c-16ab53eb5f98">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5f9ad90f-ab7f-44e4-a15c-16ab53eb5f98">
											<gml:posList>35.67351871872259 139.7387938400318 7.53 35.67354241413072 139.73878022465385 7.53 35.67354241413072 139.73878022465385 46.552 35.67351871872259 139.7387938400318 46.552 35.67351871872259 139.7387938400318 7.53</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂三丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-10450</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">160.82785</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1210</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>7</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.37</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>