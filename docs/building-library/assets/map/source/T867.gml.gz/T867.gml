<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_f8980b4f-cee6-4439-8bd3-a1744a22ba12">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="地区計画">
				<gen:value>赤坂二・六丁目地区</gen:value>
			</gen:stringAttribute>
			<bldg:measuredHeight uom="m">3.2</bldg:measuredHeight>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.67202742245661 139.73768399069547 0 35.67197887575018 139.73770824040358 0 35.67199007954056 139.7377419519468 0 35.67203862626249 139.73771771330212 0 35.67202742245661 139.73768399069547 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67202742245661 139.73768399069547 9.72 35.67203862626249 139.73771771330212 9.72 35.67199007954056 139.7377419519468 9.72 35.67197887575018 139.73770824040358 9.72 35.67202742245661 139.73768399069547 9.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67202742245661 139.73768399069547 9.72 35.67197887575018 139.73770824040358 9.72 35.67197887575018 139.73770824040358 12.89 35.67202742245661 139.73768399069547 12.89 35.67202742245661 139.73768399069547 9.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67197887575018 139.73770824040358 9.72 35.67199007954056 139.7377419519468 9.72 35.67199007954056 139.7377419519468 12.89 35.67197887575018 139.73770824040358 12.89 35.67197887575018 139.73770824040358 9.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67199007954056 139.7377419519468 9.72 35.67203862626249 139.73771771330212 9.72 35.67203862626249 139.73771771330212 12.89 35.67199007954056 139.7377419519468 12.89 35.67199007954056 139.7377419519468 9.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67203862626249 139.73771771330212 9.72 35.67202742245661 139.73768399069547 9.72 35.67202742245661 139.73768399069547 12.89 35.67203862626249 139.73771771330212 12.89 35.67203862626249 139.73771771330212 9.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67202742245661 139.73768399069547 12.89 35.67197887575018 139.73770824040358 12.89 35.67199007954056 139.7377419519468 12.89 35.67203862626249 139.73771771330212 12.89 35.67202742245661 139.73768399069547 12.89</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-e69facf5-2e31-4bb6-ac30-6f9d915a8de8"/>
							<gml:surfaceMember xlink:href="#poly-39158abc-9dcc-48e0-905a-79475544188a"/>
							<gml:surfaceMember xlink:href="#poly-3544887f-b5ce-40d6-8339-f47795974134"/>
							<gml:surfaceMember xlink:href="#poly-973a6ddb-22ef-42be-ac19-abfc59b77eaa"/>
							<gml:surfaceMember xlink:href="#poly-1b3ce49e-593d-4919-b11e-9f906d792b19"/>
							<gml:surfaceMember xlink:href="#poly-5fe0cc26-089b-40b5-865d-7e7da9ab8472"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-e69facf5-2e31-4bb6-ac30-6f9d915a8de8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e69facf5-2e31-4bb6-ac30-6f9d915a8de8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e69facf5-2e31-4bb6-ac30-6f9d915a8de8">
											<gml:posList>35.67202742245657 139.73768399069544 9.72 35.672038626262456 139.73771771330212 9.72 35.67199007954054 139.7377419519468 9.72 35.67197887575016 139.73770824040355 9.72 35.67202742245657 139.73768399069544 9.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-39158abc-9dcc-48e0-905a-79475544188a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-39158abc-9dcc-48e0-905a-79475544188a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-39158abc-9dcc-48e0-905a-79475544188a">
											<gml:posList>35.67197887575016 139.73770824040355 13.817 35.67199007954054 139.7377419519468 13.817 35.672038626262456 139.73771771330212 13.817 35.67202742245657 139.73768399069544 13.817 35.67197887575016 139.73770824040355 13.817</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3544887f-b5ce-40d6-8339-f47795974134">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3544887f-b5ce-40d6-8339-f47795974134">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3544887f-b5ce-40d6-8339-f47795974134">
											<gml:posList>35.67197887575016 139.73770824040355 13.817 35.67197887575016 139.73770824040355 9.72 35.67199007954054 139.7377419519468 9.72 35.67199007954054 139.7377419519468 13.817 35.67197887575016 139.73770824040355 13.817</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-973a6ddb-22ef-42be-ac19-abfc59b77eaa">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-973a6ddb-22ef-42be-ac19-abfc59b77eaa">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-973a6ddb-22ef-42be-ac19-abfc59b77eaa">
											<gml:posList>35.67202742245657 139.73768399069544 13.817 35.67202742245657 139.73768399069544 9.72 35.67197887575016 139.73770824040355 9.72 35.67197887575016 139.73770824040355 13.817 35.67202742245657 139.73768399069544 13.817</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1b3ce49e-593d-4919-b11e-9f906d792b19">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1b3ce49e-593d-4919-b11e-9f906d792b19">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1b3ce49e-593d-4919-b11e-9f906d792b19">
											<gml:posList>35.67199007954054 139.7377419519468 13.817 35.67199007954054 139.7377419519468 9.72 35.672038626262456 139.73771771330212 9.72 35.672038626262456 139.73771771330212 13.817 35.67199007954054 139.7377419519468 13.817</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5fe0cc26-089b-40b5-865d-7e7da9ab8472">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5fe0cc26-089b-40b5-865d-7e7da9ab8472">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5fe0cc26-089b-40b5-865d-7e7da9ab8472">
											<gml:posList>35.672038626262456 139.73771771330212 13.817 35.672038626262456 139.73771771330212 9.72 35.67202742245657 139.73768399069544 9.72 35.67202742245657 139.73768399069544 13.817 35.672038626262456 139.73771771330212 13.817</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-10409</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>5</uro:specifiedFloorAreaRate>
					<uro:surveyYear>0001</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.11</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>