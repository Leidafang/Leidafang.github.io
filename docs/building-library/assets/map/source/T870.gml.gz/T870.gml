<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_f96933a1-3b84-4c30-8f49-a0db69332a95">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">413</bldg:usage>
			<bldg:measuredHeight uom="m">11.4</bldg:measuredHeight>
			<bldg:storeysAboveGround>4</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.670349445215045 139.73804853059715 0 35.67036988446385 139.73813477757997 0 35.670373308717586 139.7381335584258 0 35.67039564576038 139.73822609957367 0 35.67052946200586 139.7381784418361 0 35.670508386585674 139.7380855676601 0 35.670511991025876 139.73808423782486 0 35.670491461603945 139.73799799080942 0 35.670349445215045 139.73804853059715 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670349445215045 139.73804853059715 17.739 35.670491461603945 139.73799799080942 17.739 35.670511991025876 139.73808423782486 17.739 35.670508386585674 139.7380855676601 17.739 35.67052946200586 139.7381784418361 17.739 35.67039564576038 139.73822609957367 17.739 35.670373308717586 139.7381335584258 17.739 35.67036988446385 139.73813477757997 17.739 35.670349445215045 139.73804853059715 17.739</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670349445215045 139.73804853059715 17.739 35.67036988446385 139.73813477757997 17.739 35.67036988446385 139.73813477757997 29.1 35.670349445215045 139.73804853059715 29.1 35.670349445215045 139.73804853059715 17.739</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67036988446385 139.73813477757997 17.739 35.670373308717586 139.7381335584258 17.739 35.670373308717586 139.7381335584258 29.1 35.67036988446385 139.73813477757997 29.1 35.67036988446385 139.73813477757997 17.739</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670373308717586 139.7381335584258 17.739 35.67039564576038 139.73822609957367 17.739 35.67039564576038 139.73822609957367 29.1 35.670373308717586 139.7381335584258 29.1 35.670373308717586 139.7381335584258 17.739</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67039564576038 139.73822609957367 17.739 35.67052946200586 139.7381784418361 17.739 35.67052946200586 139.7381784418361 29.1 35.67039564576038 139.73822609957367 29.1 35.67039564576038 139.73822609957367 17.739</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67052946200586 139.7381784418361 17.739 35.670508386585674 139.7380855676601 17.739 35.670508386585674 139.7380855676601 29.1 35.67052946200586 139.7381784418361 29.1 35.67052946200586 139.7381784418361 17.739</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670508386585674 139.7380855676601 17.739 35.670511991025876 139.73808423782486 17.739 35.670511991025876 139.73808423782486 29.1 35.670508386585674 139.7380855676601 29.1 35.670508386585674 139.7380855676601 17.739</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670511991025876 139.73808423782486 17.739 35.670491461603945 139.73799799080942 17.739 35.670491461603945 139.73799799080942 29.1 35.670511991025876 139.73808423782486 29.1 35.670511991025876 139.73808423782486 17.739</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670491461603945 139.73799799080942 17.739 35.670349445215045 139.73804853059715 17.739 35.670349445215045 139.73804853059715 29.1 35.670491461603945 139.73799799080942 29.1 35.670491461603945 139.73799799080942 17.739</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670349445215045 139.73804853059715 29.1 35.67036988446385 139.73813477757997 29.1 35.670373308717586 139.7381335584258 29.1 35.67039564576038 139.73822609957367 29.1 35.67052946200586 139.7381784418361 29.1 35.670508386585674 139.7380855676601 29.1 35.670511991025876 139.73808423782486 29.1 35.670491461603945 139.73799799080942 29.1 35.670349445215045 139.73804853059715 29.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-f7baa0fb-aa6c-4f64-96b6-100cf66b9150"/>
							<gml:surfaceMember xlink:href="#poly-85a8a3cc-5f62-4add-8f25-b51572448b4b"/>
							<gml:surfaceMember xlink:href="#poly-c283a986-d253-414f-b00c-0f1a6fdeba16"/>
							<gml:surfaceMember xlink:href="#poly-a035da59-fb7d-4dea-9a90-3fbf3fcecfb7"/>
							<gml:surfaceMember xlink:href="#poly-d5ed115f-f39c-4964-9601-5da788dbc201"/>
							<gml:surfaceMember xlink:href="#poly-0393aa2e-23f4-49d2-89e9-ff689cad66b6"/>
							<gml:surfaceMember xlink:href="#poly-da3d9453-9ee1-4476-a0d8-08c668ce90d6"/>
							<gml:surfaceMember xlink:href="#poly-ff618290-d9a5-4056-b692-8be9a1aadf3c"/>
							<gml:surfaceMember xlink:href="#poly-642e4ddc-4c67-474f-b311-ccf1d7b531cd"/>
							<gml:surfaceMember xlink:href="#poly-49052fce-7dc2-45a3-a9b3-4691ff84d36c"/>
							<gml:surfaceMember xlink:href="#poly-11e25d23-058f-4e08-95db-25eb2a71821b"/>
							<gml:surfaceMember xlink:href="#poly-4966b583-3d60-4cbd-8bc2-e57de485881e"/>
							<gml:surfaceMember xlink:href="#poly-2faa54a9-77db-4f73-9553-3706cab4412d"/>
							<gml:surfaceMember xlink:href="#poly-d4e9e40f-3730-4cf6-97d2-d337ea46dedd"/>
							<gml:surfaceMember xlink:href="#poly-562f183b-73d1-4639-b905-213577b5985e"/>
							<gml:surfaceMember xlink:href="#poly-127be44a-385c-4b4a-b52e-2f724ea02d01"/>
							<gml:surfaceMember xlink:href="#poly-e1945b38-ec32-4259-8d85-6d018dfffd87"/>
							<gml:surfaceMember xlink:href="#poly-5d03b92c-9aae-480e-bbb2-3a8e8ed6bebf"/>
							<gml:surfaceMember xlink:href="#poly-d5021f54-230e-4236-82d3-f5c15bfef506"/>
							<gml:surfaceMember xlink:href="#poly-07e7a842-6b24-4559-88b2-bb6f076a7f88"/>
							<gml:surfaceMember xlink:href="#poly-26701a3b-e404-43ba-96d9-dcdbe10e375f"/>
							<gml:surfaceMember xlink:href="#poly-0458a3cf-3c37-49e1-a237-b30559e1a3e2"/>
							<gml:surfaceMember xlink:href="#poly-5e08642f-8320-4dff-90b6-edcdaa16209a"/>
							<gml:surfaceMember xlink:href="#poly-002d07c8-d6c2-4a6e-b7e9-fcff71df8434"/>
							<gml:surfaceMember xlink:href="#poly-f3566c78-d52e-486d-a62d-ff1464e73c06"/>
							<gml:surfaceMember xlink:href="#poly-ee3ef332-1220-451e-9882-67bb9d9e7ddf"/>
							<gml:surfaceMember xlink:href="#poly-ba88b057-6848-45a2-9c7b-6668b790d7d9"/>
							<gml:surfaceMember xlink:href="#poly-16440649-50ea-490b-944a-c13ff4338556"/>
							<gml:surfaceMember xlink:href="#poly-9f3cf221-13eb-46af-9cdc-1b03a9e8ac65"/>
							<gml:surfaceMember xlink:href="#poly-b5656728-708a-4348-939b-a0327ea0cf20"/>
							<gml:surfaceMember xlink:href="#poly-eb707e69-7861-4e4d-a376-557c38df72f1"/>
							<gml:surfaceMember xlink:href="#poly-c52a8e6a-79bb-4a5b-ae88-3345912b1b10"/>
							<gml:surfaceMember xlink:href="#poly-80252afc-6032-4a01-9994-130a3a7e4a4f"/>
							<gml:surfaceMember xlink:href="#poly-91fcc235-1d8c-4120-81a7-97fe0a19bee1"/>
							<gml:surfaceMember xlink:href="#poly-82abfe3c-ce4a-45e2-a022-5b73a51d4eda"/>
							<gml:surfaceMember xlink:href="#poly-38d6ad57-782d-4b52-92cc-c5e0d37ec057"/>
							<gml:surfaceMember xlink:href="#poly-96bbc903-1e39-448c-9671-89c6d2eb55df"/>
							<gml:surfaceMember xlink:href="#poly-04730ba0-6f38-4c46-ac00-6a49e1f9ee17"/>
							<gml:surfaceMember xlink:href="#poly-75be8cfa-bd06-4555-ad0f-0fbc0eff93d9"/>
							<gml:surfaceMember xlink:href="#poly-ab4a48b6-c161-4062-a66b-fee42c9498fc"/>
							<gml:surfaceMember xlink:href="#poly-a6cc0021-2631-4335-b9f3-7cfd9bb0cf98"/>
							<gml:surfaceMember xlink:href="#poly-9a77e9c1-ea6e-4817-91a7-99c603920860"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_f96933a1-3b84-4c30-8f49-a0db69332a95_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-77b865cc-2012-4b1c-a0ae-7d3fb3c90662">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67047153722004 139.73810679818516 33.988 35.67047171809724 139.7381075601631 33.988 35.67044626146064 139.73811660415262 33.988 35.670446089614686 139.7381158642567 33.988 35.67047153722004 139.73810679818516 33.988</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6b6fd4b5-9110-448a-b287-14022b42f7f6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67047171809724 139.7381075601631 33.128 35.67048975158864 139.73818360338973 33.128 35.670464303977546 139.73819266943897 33.128 35.67044626146064 139.73811660415262 33.128 35.67047171809724 139.7381075601631 33.128</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-150611ad-cce0-4d64-bd5a-4c3e74b578ba">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67051415399128 139.7381750246114 33.988 35.67049253613914 139.73818272742946 33.988 35.670492509010685 139.73818261699893 33.988 35.67051264903144 139.7381754461561 33.988 35.67049936320083 139.73811894917822 33.988 35.67050074190722 139.73811845045856 33.988 35.67051415399128 139.7381750246114 33.988</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e5ac0328-9fb0-41c4-80d0-0ab2d5c5986b">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67050251140985 139.7381676153319 33.128 35.67049162257985 139.7381216978467 33.128 35.67049936320083 139.73811894917822 33.128 35.67051264903144 139.7381754461561 33.128 35.670492509010685 139.73818261699893 33.128 35.67049000387326 139.7381720707799 33.128 35.67050251140985 139.7381676153319 33.128</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-dc5c44de-2a5b-4a4e-a1bf-353af044dec2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670464303977546 139.73819266943897 33.988 35.67048975158864 139.73818360338973 33.988 35.670491714112536 139.73819188576664 33.988 35.67046626650083 139.7382009518135 33.988 35.670464303977546 139.73819266943897 33.988</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0869901e-8b6e-49cd-9d15-634365c9e271">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0869901e-8b6e-49cd-9d15-634365c9e271_0">
											<gml:posList>35.670492509010685 139.73818261699893 33.988 35.67049253613914 139.73818272742946 33.988 35.67049253613914 139.73818272742946 35.975 35.67049000387326 139.7381720707799 35.975 35.67049000387326 139.7381720707799 33.128 35.670492509010685 139.73818261699893 33.128 35.670492509010685 139.73818261699893 33.988</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b25c60e4-a5d3-4db5-88a9-9e44e05d4a37">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b25c60e4-a5d3-4db5-88a9-9e44e05d4a37_0">
											<gml:posList>35.67047153722004 139.73810679818516 33.988 35.670446089614686 139.7381158642567 33.988 35.670446089614686 139.7381158642567 36.826 35.67047153722004 139.73810679818516 36.826 35.67047153722004 139.73810679818516 33.988</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-70f2abb8-8e3e-4e69-8f2c-94ece524903d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-70f2abb8-8e3e-4e69-8f2c-94ece524903d_0">
											<gml:posList>35.67047171809724 139.7381075601631 33.988 35.67047171809724 139.7381075601631 33.128 35.67044626146064 139.73811660415262 33.128 35.67044626146064 139.73811660415262 33.988 35.67047171809724 139.7381075601631 33.988</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-286d763a-5123-414e-9353-941b90e5b245">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-286d763a-5123-414e-9353-941b90e5b245_0">
											<gml:posList>35.67049162257985 139.7381216978467 33.128 35.67049162257985 139.7381216978467 35.975 35.67050074190722 139.73811845045856 35.975 35.67050074190722 139.73811845045856 33.988 35.67049936320083 139.73811894917822 33.988 35.67049936320083 139.73811894917822 33.128 35.67049162257985 139.7381216978467 33.128</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-60879812-6b2a-4e2f-b051-ce1a615b7bde">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-60879812-6b2a-4e2f-b051-ce1a615b7bde_0">
											<gml:posList>35.67049162257985 139.7381216978467 33.128 35.67050251140985 139.7381676153319 33.128 35.67050251140985 139.7381676153319 35.975 35.67049162257985 139.7381216978467 35.975 35.67049162257985 139.7381216978467 33.128</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b192da13-fe84-429f-b36e-f413e28adbc9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b192da13-fe84-429f-b36e-f413e28adbc9_0">
											<gml:posList>35.67051415399128 139.7381750246114 33.988 35.67050074190722 139.73811845045856 33.988 35.67050074190722 139.73811845045856 35.975 35.67051415399128 139.7381750246114 35.975 35.67051415399128 139.7381750246114 33.988</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-449102ce-ddf9-40ad-8875-5b3d65e7723f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-449102ce-ddf9-40ad-8875-5b3d65e7723f_0">
											<gml:posList>35.67051264903144 139.7381754461561 33.128 35.67049936320083 139.73811894917822 33.128 35.67049936320083 139.73811894917822 33.988 35.67051264903144 139.7381754461561 33.988 35.67051264903144 139.7381754461561 33.128</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-152a33d3-3918-414c-aa04-25eb66fac097">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-152a33d3-3918-414c-aa04-25eb66fac097_0">
											<gml:posList>35.67048975158864 139.73818360338973 33.988 35.67048975158864 139.73818360338973 33.128 35.67047171809724 139.7381075601631 33.128 35.67047171809724 139.7381075601631 33.988 35.67047153722004 139.73810679818516 33.988 35.67047153722004 139.73810679818516 36.826 35.670491714112536 139.73819188576664 36.826 35.670491714112536 139.73819188576664 33.988 35.67048975158864 139.73818360338973 33.988</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-be03eb94-4f95-4f03-8f44-e8a52f111e9b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-be03eb94-4f95-4f03-8f44-e8a52f111e9b_0">
											<gml:posList>35.67049253613914 139.73818272742946 35.975 35.67051415399128 139.7381750246114 35.975 35.67050074190722 139.73811845045856 35.975 35.67049162257985 139.7381216978467 35.975 35.67050251140985 139.7381676153319 35.975 35.67049000387326 139.7381720707799 35.975 35.67049253613914 139.73818272742946 35.975</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e8f5b2a8-cfb8-4290-b6b4-16cdf92fed6d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e8f5b2a8-cfb8-4290-b6b4-16cdf92fed6d_0">
											<gml:posList>35.67047153722004 139.73810679818516 36.826 35.670446089614686 139.7381158642567 36.826 35.67046626650083 139.7382009518135 36.826 35.670491714112536 139.73819188576664 36.826 35.67047153722004 139.73810679818516 36.826</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-17f84e98-2623-4091-bcda-d4d747d6b20a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-17f84e98-2623-4091-bcda-d4d747d6b20a_0">
											<gml:posList>35.67044626146064 139.73811660415262 33.988 35.67044626146064 139.73811660415262 33.128 35.670464303977546 139.73819266943897 33.128 35.670464303977546 139.73819266943897 33.988 35.67046626650083 139.7382009518135 33.988 35.67046626650083 139.7382009518135 36.826 35.670446089614686 139.7381158642567 36.826 35.670446089614686 139.7381158642567 33.988 35.67044626146064 139.73811660415262 33.988</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d2597c63-86fe-43d7-8e4d-02613dba11ff">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d2597c63-86fe-43d7-8e4d-02613dba11ff_0">
											<gml:posList>35.67049000387326 139.7381720707799 33.128 35.67049000387326 139.7381720707799 35.975 35.67050251140985 139.7381676153319 35.975 35.67050251140985 139.7381676153319 33.128 35.67049000387326 139.7381720707799 33.128</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5f0ae2d5-b57e-4894-8590-e9ab81318e50">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5f0ae2d5-b57e-4894-8590-e9ab81318e50_0">
											<gml:posList>35.67051415399128 139.7381750246114 33.988 35.67051415399128 139.7381750246114 35.975 35.67049253613914 139.73818272742946 35.975 35.67049253613914 139.73818272742946 33.988 35.67051415399128 139.7381750246114 33.988</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ade7dbe2-1fa7-4a76-be90-b95a14fd6a5f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ade7dbe2-1fa7-4a76-be90-b95a14fd6a5f_0">
											<gml:posList>35.67051264903144 139.7381754461561 33.988 35.670492509010685 139.73818261699893 33.988 35.670492509010685 139.73818261699893 33.128 35.67051264903144 139.7381754461561 33.128 35.67051264903144 139.7381754461561 33.988</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5844dd37-82ae-4cc7-b24f-3e5438e16846">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5844dd37-82ae-4cc7-b24f-3e5438e16846_0">
											<gml:posList>35.670464303977546 139.73819266943897 33.128 35.67048975158864 139.73818360338973 33.128 35.67048975158864 139.73818360338973 33.988 35.670464303977546 139.73819266943897 33.988 35.670464303977546 139.73819266943897 33.128</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8a7ba19a-4e9f-42aa-9e2d-90a7d616ac3c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8a7ba19a-4e9f-42aa-9e2d-90a7d616ac3c_0">
											<gml:posList>35.67046626650083 139.7382009518135 33.988 35.670491714112536 139.73819188576664 33.988 35.670491714112536 139.73819188576664 36.826 35.67046626650083 139.7382009518135 36.826 35.67046626650083 139.7382009518135 33.988</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-f7baa0fb-aa6c-4f64-96b6-100cf66b9150">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f7baa0fb-aa6c-4f64-96b6-100cf66b9150">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f7baa0fb-aa6c-4f64-96b6-100cf66b9150">
											<gml:posList>35.67034944521504 139.73804853059715 17.739 35.670491461603945 139.7379979908094 17.739 35.670511991025876 139.73808423782486 17.739 35.67050838658566 139.7380855676601 17.739 35.67052946200589 139.73817844183608 17.739 35.67039564576038 139.73822609957367 17.739 35.67037330871758 139.7381335584258 17.739 35.670369884463824 139.73813477757997 17.739 35.67034944521504 139.73804853059715 17.739</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-85a8a3cc-5f62-4add-8f25-b51572448b4b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-85a8a3cc-5f62-4add-8f25-b51572448b4b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-85a8a3cc-5f62-4add-8f25-b51572448b4b">
											<gml:posList>35.67034944521504 139.73804853059715 29.687 35.670352827178945 139.7380508241991 29.687 35.670489590038116 139.73800214643393 29.687 35.670491461603945 139.7379979908094 29.687 35.67034944521504 139.73804853059715 29.687</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c283a986-d253-414f-b00c-0f1a6fdeba16">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c283a986-d253-414f-b00c-0f1a6fdeba16">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c283a986-d253-414f-b00c-0f1a6fdeba16">
											<gml:posList>35.670491461603945 139.7379979908094 29.687 35.670489590038116 139.73800214643393 29.687 35.67050860008391 139.73808198841277 29.687 35.670511991025876 139.73808423782486 29.687 35.670491461603945 139.7379979908094 29.687</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a035da59-fb7d-4dea-9a90-3fbf3fcecfb7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a035da59-fb7d-4dea-9a90-3fbf3fcecfb7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a035da59-fb7d-4dea-9a90-3fbf3fcecfb7">
											<gml:posList>35.670393608196626 139.73812286363477 29.399 35.67050759084416 139.73808236518516 29.399 35.67050860008391 139.73808198841277 29.399 35.670489590038116 139.73800214643393 29.399 35.670352827178945 139.7380508241991 29.399 35.67037174702929 139.7381306330217 29.399 35.670393608196626 139.73812286363477 29.399</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d5ed115f-f39c-4964-9601-5da788dbc201">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d5ed115f-f39c-4964-9601-5da788dbc201">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d5ed115f-f39c-4964-9601-5da788dbc201">
											<gml:posList>35.67050838658566 139.7380855676601 29.687 35.670511991025876 139.73808423782486 29.687 35.67050860008391 139.73808198841277 29.687 35.67050759084416 139.73808236518516 29.687 35.67050838658566 139.7380855676601 29.687</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-0393aa2e-23f4-49d2-89e9-ff689cad66b6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0393aa2e-23f4-49d2-89e9-ff689cad66b6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0393aa2e-23f4-49d2-89e9-ff689cad66b6">
											<gml:posList>35.670369884463824 139.73813477757997 29.687 35.67037174702929 139.7381306330217 29.687 35.670352827178945 139.7380508241991 29.687 35.67034944521504 139.73804853059715 29.687 35.670369884463824 139.73813477757997 29.687</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-da3d9453-9ee1-4476-a0d8-08c668ce90d6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-da3d9453-9ee1-4476-a0d8-08c668ce90d6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-da3d9453-9ee1-4476-a0d8-08c668ce90d6">
											<gml:posList>35.67050838658566 139.7380855676601 29.687 35.67050759084416 139.73808236518516 29.687 35.670393608196626 139.73812286363477 29.687 35.67039436789091 139.73812607719464 29.687 35.67050838658566 139.7380855676601 29.687</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ff618290-d9a5-4056-b692-8be9a1aadf3c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ff618290-d9a5-4056-b692-8be9a1aadf3c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ff618290-d9a5-4056-b692-8be9a1aadf3c">
											<gml:posList>35.67039436789091 139.73812607719464 33.988 35.67040307078775 139.73813195451817 33.988 35.670494759728285 139.73809936959952 33.988 35.67049956462465 139.7380887042363 33.988 35.67039436789091 139.73812607719464 33.988</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-642e4ddc-4c67-474f-b311-ccf1d7b531cd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-642e4ddc-4c67-474f-b311-ccf1d7b531cd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-642e4ddc-4c67-474f-b311-ccf1d7b531cd">
											<gml:posList>35.67039436789091 139.73812607719464 29.687 35.670393608196626 139.73812286363477 29.687 35.67037174702929 139.7381306330217 29.687 35.670369884463824 139.73813477757997 29.687 35.67039436789091 139.73812607719464 29.687</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-49052fce-7dc2-45a3-a9b3-4691ff84d36c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-49052fce-7dc2-45a3-a9b3-4691ff84d36c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-49052fce-7dc2-45a3-a9b3-4691ff84d36c">
											<gml:posList>35.67039436789091 139.73812607719464 28.284 35.67037330871758 139.7381335584258 28.284 35.6703771866791 139.73813616073832 28.284 35.670395236116576 139.7381297545687 28.284 35.67039436789091 139.73812607719464 28.284</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-11e25d23-058f-4e08-95db-25eb2a71821b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-11e25d23-058f-4e08-95db-25eb2a71821b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-11e25d23-058f-4e08-95db-25eb2a71821b">
											<gml:posList>35.67052946200589 139.73817844183608 31.387 35.67050838658566 139.7380855676601 31.387 35.67049956462465 139.7380887042363 31.387 35.670521351934454 139.73818133453992 31.387 35.67052946200589 139.73817844183608 31.387</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-4966b583-3d60-4cbd-8bc2-e57de485881e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4966b583-3d60-4cbd-8bc2-e57de485881e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4966b583-3d60-4cbd-8bc2-e57de485881e">
											<gml:posList>35.67049956462465 139.7380887042363 33.988 35.670494759728285 139.73809936959952 33.988 35.67051264903144 139.7381754461561 33.988 35.670521351934454 139.73818133453992 33.988 35.67049956462465 139.7380887042363 33.988</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-2faa54a9-77db-4f73-9553-3706cab4412d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2faa54a9-77db-4f73-9553-3706cab4412d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2faa54a9-77db-4f73-9553-3706cab4412d">
											<gml:posList>35.67051264903144 139.7381754461561 33.128 35.670494759728285 139.73809936959952 33.128 35.67040307078775 139.73813195451817 33.128 35.67042107728376 139.73820807504111 33.128 35.67051264903144 139.7381754461561 33.128</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d4e9e40f-3730-4cf6-97d2-d337ea46dedd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d4e9e40f-3730-4cf6-97d2-d337ea46dedd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d4e9e40f-3730-4cf6-97d2-d337ea46dedd">
											<gml:posList>35.6704162904129 139.73821875141164 33.988 35.67042107728376 139.73820807504111 33.988 35.67040307078775 139.73813195451817 33.988 35.67039436789091 139.73812607719464 33.988 35.6704162904129 139.73821875141164 33.988</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-562f183b-73d1-4639-b905-213577b5985e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-562f183b-73d1-4639-b905-213577b5985e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-562f183b-73d1-4639-b905-213577b5985e">
											<gml:posList>35.6704154222074 139.73821509612816 27.98 35.670395236116576 139.7381297545687 27.98 35.6703771866791 139.73813616073832 27.98 35.67039775123704 139.73822136927615 27.98 35.6704154222074 139.73821509612816 27.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-127be44a-385c-4b4a-b52e-2f724ea02d01">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-127be44a-385c-4b4a-b52e-2f724ea02d01">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-127be44a-385c-4b4a-b52e-2f724ea02d01">
											<gml:posList>35.67039564576038 139.73822609957367 28.284 35.67039775123704 139.73822136927615 28.284 35.6703771866791 139.73813616073832 28.284 35.67037330871758 139.7381335584258 28.284 35.67039564576038 139.73822609957367 28.284</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e1945b38-ec32-4259-8d85-6d018dfffd87">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e1945b38-ec32-4259-8d85-6d018dfffd87">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e1945b38-ec32-4259-8d85-6d018dfffd87">
											<gml:posList>35.670521351934454 139.73818133453992 33.988 35.67051264903144 139.7381754461561 33.988 35.67042107728376 139.73820807504111 33.988 35.6704162904129 139.73821875141164 33.988 35.670521351934454 139.73818133453992 33.988</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-5d03b92c-9aae-480e-bbb2-3a8e8ed6bebf">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5d03b92c-9aae-480e-bbb2-3a8e8ed6bebf">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5d03b92c-9aae-480e-bbb2-3a8e8ed6bebf">
											<gml:posList>35.6704162904129 139.73821875141164 28.284 35.6704154222074 139.73821509612816 28.284 35.67039775123704 139.73822136927615 28.284 35.67039564576038 139.73822609957367 28.284 35.6704162904129 139.73821875141164 28.284</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d5021f54-230e-4236-82d3-f5c15bfef506">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d5021f54-230e-4236-82d3-f5c15bfef506">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d5021f54-230e-4236-82d3-f5c15bfef506">
											<gml:posList>35.67034944521504 139.73804853059715 17.739 35.670369884463824 139.73813477757997 17.739 35.670369884463824 139.73813477757997 29.687 35.67034944521504 139.73804853059715 29.687 35.67034944521504 139.73804853059715 17.739</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-07e7a842-6b24-4559-88b2-bb6f076a7f88">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-07e7a842-6b24-4559-88b2-bb6f076a7f88">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-07e7a842-6b24-4559-88b2-bb6f076a7f88">
											<gml:posList>35.67037174702929 139.7381306330217 29.687 35.67037174702929 139.7381306330217 29.399 35.670352827178945 139.7380508241991 29.399 35.670352827178945 139.7380508241991 29.687 35.67037174702929 139.7381306330217 29.687</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-26701a3b-e404-43ba-96d9-dcdbe10e375f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-26701a3b-e404-43ba-96d9-dcdbe10e375f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-26701a3b-e404-43ba-96d9-dcdbe10e375f">
											<gml:posList>35.670369884463824 139.73813477757997 29.687 35.670369884463824 139.73813477757997 17.739 35.67037330871758 139.7381335584258 17.739 35.67037330871758 139.7381335584258 28.284 35.67039436789091 139.73812607719464 28.284 35.67039436789091 139.73812607719464 29.687 35.670369884463824 139.73813477757997 29.687</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0458a3cf-3c37-49e1-a237-b30559e1a3e2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0458a3cf-3c37-49e1-a237-b30559e1a3e2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0458a3cf-3c37-49e1-a237-b30559e1a3e2">
											<gml:posList>35.670393608196626 139.73812286363477 29.687 35.670393608196626 139.73812286363477 29.399 35.67037174702929 139.7381306330217 29.399 35.67037174702929 139.7381306330217 29.687 35.670393608196626 139.73812286363477 29.687</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5e08642f-8320-4dff-90b6-edcdaa16209a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5e08642f-8320-4dff-90b6-edcdaa16209a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5e08642f-8320-4dff-90b6-edcdaa16209a">
											<gml:posList>35.67037330871758 139.7381335584258 17.739 35.67039564576038 139.73822609957367 17.739 35.67039564576038 139.73822609957367 28.284 35.67037330871758 139.7381335584258 28.284 35.67037330871758 139.7381335584258 17.739</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-002d07c8-d6c2-4a6e-b7e9-fcff71df8434">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-002d07c8-d6c2-4a6e-b7e9-fcff71df8434">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-002d07c8-d6c2-4a6e-b7e9-fcff71df8434">
											<gml:posList>35.6703771866791 139.73813616073832 28.284 35.6703771866791 139.73813616073832 27.98 35.670395236116576 139.7381297545687 27.98 35.670395236116576 139.7381297545687 28.284 35.6703771866791 139.73813616073832 28.284</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f3566c78-d52e-486d-a62d-ff1464e73c06">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f3566c78-d52e-486d-a62d-ff1464e73c06">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f3566c78-d52e-486d-a62d-ff1464e73c06">
											<gml:posList>35.67039775123704 139.73822136927615 28.284 35.67039775123704 139.73822136927615 27.98 35.6703771866791 139.73813616073832 27.98 35.6703771866791 139.73813616073832 28.284 35.67039775123704 139.73822136927615 28.284</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ee3ef332-1220-451e-9882-67bb9d9e7ddf">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ee3ef332-1220-451e-9882-67bb9d9e7ddf">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ee3ef332-1220-451e-9882-67bb9d9e7ddf">
											<gml:posList>35.670395236116576 139.7381297545687 28.284 35.670395236116576 139.7381297545687 27.98 35.6704154222074 139.73821509612816 27.98 35.6704154222074 139.73821509612816 28.284 35.6704162904129 139.73821875141164 28.284 35.6704162904129 139.73821875141164 33.988 35.67039436789091 139.73812607719464 33.988 35.67039436789091 139.73812607719464 29.687 35.67039436789091 139.73812607719464 28.284 35.670395236116576 139.7381297545687 28.284</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ba88b057-6848-45a2-9c7b-6668b790d7d9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ba88b057-6848-45a2-9c7b-6668b790d7d9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ba88b057-6848-45a2-9c7b-6668b790d7d9">
											<gml:posList>35.6704154222074 139.73821509612816 28.284 35.6704154222074 139.73821509612816 27.98 35.67039775123704 139.73822136927615 27.98 35.67039775123704 139.73822136927615 28.284 35.6704154222074 139.73821509612816 28.284</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-16440649-50ea-490b-944a-c13ff4338556">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-16440649-50ea-490b-944a-c13ff4338556">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-16440649-50ea-490b-944a-c13ff4338556">
											<gml:posList>35.67042107728376 139.73820807504111 33.988 35.67042107728376 139.73820807504111 33.128 35.67040307078775 139.73813195451817 33.128 35.67040307078775 139.73813195451817 33.988 35.67042107728376 139.73820807504111 33.988</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9f3cf221-13eb-46af-9cdc-1b03a9e8ac65">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9f3cf221-13eb-46af-9cdc-1b03a9e8ac65">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9f3cf221-13eb-46af-9cdc-1b03a9e8ac65">
											<gml:posList>35.670491461603945 139.7379979908094 17.739 35.67034944521504 139.73804853059715 17.739 35.67034944521504 139.73804853059715 29.687 35.670491461603945 139.7379979908094 29.687 35.670491461603945 139.7379979908094 17.739</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b5656728-708a-4348-939b-a0327ea0cf20">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b5656728-708a-4348-939b-a0327ea0cf20">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b5656728-708a-4348-939b-a0327ea0cf20">
											<gml:posList>35.670352827178945 139.7380508241991 29.687 35.670352827178945 139.7380508241991 29.399 35.670489590038116 139.73800214643393 29.399 35.670489590038116 139.73800214643393 29.687 35.670352827178945 139.7380508241991 29.687</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-eb707e69-7861-4e4d-a376-557c38df72f1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-eb707e69-7861-4e4d-a376-557c38df72f1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-eb707e69-7861-4e4d-a376-557c38df72f1">
											<gml:posList>35.67040307078775 139.73813195451817 33.988 35.67040307078775 139.73813195451817 33.128 35.670494759728285 139.73809936959952 33.128 35.670494759728285 139.73809936959952 33.988 35.67040307078775 139.73813195451817 33.988</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c52a8e6a-79bb-4a5b-ae88-3345912b1b10">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c52a8e6a-79bb-4a5b-ae88-3345912b1b10">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c52a8e6a-79bb-4a5b-ae88-3345912b1b10">
											<gml:posList>35.67050759084416 139.73808236518516 29.687 35.67050759084416 139.73808236518516 29.399 35.670393608196626 139.73812286363477 29.399 35.670393608196626 139.73812286363477 29.687 35.67050759084416 139.73808236518516 29.687</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-80252afc-6032-4a01-9994-130a3a7e4a4f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-80252afc-6032-4a01-9994-130a3a7e4a4f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-80252afc-6032-4a01-9994-130a3a7e4a4f">
											<gml:posList>35.67039436789091 139.73812607719464 29.687 35.67039436789091 139.73812607719464 33.988 35.67049956462465 139.7380887042363 33.988 35.67049956462465 139.7380887042363 31.387 35.67050838658566 139.7380855676601 31.387 35.67050838658566 139.7380855676601 29.687 35.67039436789091 139.73812607719464 29.687</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-91fcc235-1d8c-4120-81a7-97fe0a19bee1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-91fcc235-1d8c-4120-81a7-97fe0a19bee1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-91fcc235-1d8c-4120-81a7-97fe0a19bee1">
											<gml:posList>35.6704162904129 139.73821875141164 28.284 35.67039564576038 139.73822609957367 28.284 35.67039564576038 139.73822609957367 17.739 35.67052946200589 139.73817844183608 17.739 35.67052946200589 139.73817844183608 31.387 35.670521351934454 139.73818133453992 31.387 35.670521351934454 139.73818133453992 33.988 35.6704162904129 139.73821875141164 33.988 35.6704162904129 139.73821875141164 28.284</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-82abfe3c-ce4a-45e2-a022-5b73a51d4eda">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-82abfe3c-ce4a-45e2-a022-5b73a51d4eda">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-82abfe3c-ce4a-45e2-a022-5b73a51d4eda">
											<gml:posList>35.67051264903144 139.7381754461561 33.988 35.67051264903144 139.7381754461561 33.128 35.67042107728376 139.73820807504111 33.128 35.67042107728376 139.73820807504111 33.988 35.67051264903144 139.7381754461561 33.988</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-38d6ad57-782d-4b52-92cc-c5e0d37ec057">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-38d6ad57-782d-4b52-92cc-c5e0d37ec057">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-38d6ad57-782d-4b52-92cc-c5e0d37ec057">
											<gml:posList>35.670489590038116 139.73800214643393 29.687 35.670489590038116 139.73800214643393 29.399 35.67050860008391 139.73808198841277 29.399 35.67050860008391 139.73808198841277 29.687 35.670489590038116 139.73800214643393 29.687</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-96bbc903-1e39-448c-9671-89c6d2eb55df">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-96bbc903-1e39-448c-9671-89c6d2eb55df">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-96bbc903-1e39-448c-9671-89c6d2eb55df">
											<gml:posList>35.670511991025876 139.73808423782486 17.739 35.670491461603945 139.7379979908094 17.739 35.670491461603945 139.7379979908094 29.687 35.670511991025876 139.73808423782486 29.687 35.670511991025876 139.73808423782486 17.739</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-04730ba0-6f38-4c46-ac00-6a49e1f9ee17">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-04730ba0-6f38-4c46-ac00-6a49e1f9ee17">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-04730ba0-6f38-4c46-ac00-6a49e1f9ee17">
											<gml:posList>35.670494759728285 139.73809936959952 33.988 35.670494759728285 139.73809936959952 33.128 35.67051264903144 139.7381754461561 33.128 35.67051264903144 139.7381754461561 33.988 35.670494759728285 139.73809936959952 33.988</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-75be8cfa-bd06-4555-ad0f-0fbc0eff93d9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-75be8cfa-bd06-4555-ad0f-0fbc0eff93d9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-75be8cfa-bd06-4555-ad0f-0fbc0eff93d9">
											<gml:posList>35.67050860008391 139.73808198841277 29.687 35.67050860008391 139.73808198841277 29.399 35.67050759084416 139.73808236518516 29.399 35.67050759084416 139.73808236518516 29.687 35.67050860008391 139.73808198841277 29.687</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ab4a48b6-c161-4062-a66b-fee42c9498fc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ab4a48b6-c161-4062-a66b-fee42c9498fc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ab4a48b6-c161-4062-a66b-fee42c9498fc">
											<gml:posList>35.67050838658566 139.7380855676601 17.739 35.670511991025876 139.73808423782486 17.739 35.670511991025876 139.73808423782486 29.687 35.67050838658566 139.7380855676601 29.687 35.67050838658566 139.7380855676601 17.739</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a6cc0021-2631-4335-b9f3-7cfd9bb0cf98">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a6cc0021-2631-4335-b9f3-7cfd9bb0cf98">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a6cc0021-2631-4335-b9f3-7cfd9bb0cf98">
											<gml:posList>35.67049956462465 139.7380887042363 31.387 35.67049956462465 139.7380887042363 33.988 35.670521351934454 139.73818133453992 33.988 35.670521351934454 139.73818133453992 31.387 35.67049956462465 139.7380887042363 31.387</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9a77e9c1-ea6e-4817-91a7-99c603920860">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9a77e9c1-ea6e-4817-91a7-99c603920860">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9a77e9c1-ea6e-4817-91a7-99c603920860">
											<gml:posList>35.67052946200589 139.73817844183608 31.387 35.67052946200589 139.73817844183608 17.739 35.67050838658566 139.7380855676601 17.739 35.67050838658566 139.7380855676601 29.687 35.67050838658566 139.7380855676601 31.387 35.67052946200589 139.73817844183608 31.387</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-7666</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">135.33386</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">211</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1230</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>4</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>