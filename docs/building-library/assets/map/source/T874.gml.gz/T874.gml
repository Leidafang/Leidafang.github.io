<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_f9d00e70-81e3-4cd2-89be-eedb5c3a4eed">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>3</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001003</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">401</bldg:usage>
			<bldg:measuredHeight uom="m">15.3</bldg:measuredHeight>
			<bldg:storeysAboveGround>5</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>1</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.673582004162554 139.73834725777095 0 35.67365228483548 139.7383138134352 0 35.67361912058479 139.73820758343652 0 35.67354901960478 139.73824025436957 0 35.673582004162554 139.73834725777095 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.673582004162554 139.73834725777095 8.73 35.67354901960478 139.73824025436957 8.73 35.67361912058479 139.73820758343652 8.73 35.67365228483548 139.7383138134352 8.73 35.673582004162554 139.73834725777095 8.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.673582004162554 139.73834725777095 8.73 35.67365228483548 139.7383138134352 8.73 35.67365228483548 139.7383138134352 24.03 35.673582004162554 139.73834725777095 24.03 35.673582004162554 139.73834725777095 8.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67365228483548 139.7383138134352 8.73 35.67361912058479 139.73820758343652 8.73 35.67361912058479 139.73820758343652 24.03 35.67365228483548 139.7383138134352 24.03 35.67365228483548 139.7383138134352 8.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67361912058479 139.73820758343652 8.73 35.67354901960478 139.73824025436957 8.73 35.67354901960478 139.73824025436957 24.03 35.67361912058479 139.73820758343652 24.03 35.67361912058479 139.73820758343652 8.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67354901960478 139.73824025436957 8.73 35.673582004162554 139.73834725777095 8.73 35.673582004162554 139.73834725777095 24.03 35.67354901960478 139.73824025436957 24.03 35.67354901960478 139.73824025436957 8.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.673582004162554 139.73834725777095 24.03 35.67365228483548 139.7383138134352 24.03 35.67361912058479 139.73820758343652 24.03 35.67354901960478 139.73824025436957 24.03 35.673582004162554 139.73834725777095 24.03</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-2d6abbec-24a0-47e1-87f7-510bf246f2d9"/>
							<gml:surfaceMember xlink:href="#poly-90cf9d2d-674b-4f33-a81c-811926cf5d17"/>
							<gml:surfaceMember xlink:href="#poly-7c1c6d44-510e-4e73-82d2-314128222275"/>
							<gml:surfaceMember xlink:href="#poly-7964e5cb-0938-45ec-8954-b7af4960d469"/>
							<gml:surfaceMember xlink:href="#poly-12cea7d8-3a90-48c7-99fc-c0c7a36f2daf"/>
							<gml:surfaceMember xlink:href="#poly-9c35aed8-da90-4515-b9b8-0b24b4319156"/>
							<gml:surfaceMember xlink:href="#poly-2812b753-eb97-4941-8803-8e3fdb7720d6"/>
							<gml:surfaceMember xlink:href="#poly-335824d0-cf29-4720-9511-f92929074de6"/>
							<gml:surfaceMember xlink:href="#poly-d7d89078-d3c0-4cda-b323-192c6f8957a8"/>
							<gml:surfaceMember xlink:href="#poly-6ad4dedd-a1eb-4878-9d41-911100c8918a"/>
							<gml:surfaceMember xlink:href="#poly-f09d8f2a-d226-4f8d-bc29-59e1e46c49a9"/>
							<gml:surfaceMember xlink:href="#poly-9ea2e816-8558-42b5-b40e-8a4e401a454b"/>
							<gml:surfaceMember xlink:href="#poly-6d04bcef-5930-4196-bd27-dc63ea6b82b2"/>
							<gml:surfaceMember xlink:href="#poly-4c3c2590-753b-4329-9a11-8376cec02ac6"/>
							<gml:surfaceMember xlink:href="#poly-ce12244e-e61e-4bbd-8c0e-f7822df6f66a"/>
							<gml:surfaceMember xlink:href="#poly-f1473b2f-e66f-47e4-869b-1fe703356a3b"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_f9d00e70-81e3-4cd2-89be-eedb5c3a4eed_BuildingInstallation_1060">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-15326e3c-2df8-415b-ac59-f3cbc09f361f">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.673573614998205 139.73828203695177 24.205 35.673582407866384 139.73831056015374 24.205 35.67357584824261 139.7383135615844 24.205 35.673567055375145 139.73828503838442 24.205 35.673573614998205 139.73828203695177 24.205</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e8855e25-e9a3-4b0c-8743-872a11a6ddb0">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67357286578312 139.73831493491005 24.616 35.67356407290726 139.73828640066432 24.616 35.673567055375145 139.73828503838442 24.616 35.67357584824261 139.7383135615844 24.616 35.67357286578312 139.73831493491005 24.616</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b0b22ff1-9ccb-43fa-a659-a82883f86817">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b0b22ff1-9ccb-43fa-a659-a82883f86817_0">
											<gml:posList>35.67356407290726 139.73828640066432 25.111 35.67356407290726 139.73828640066432 24.616 35.67357286578312 139.73831493491005 24.616 35.67357286578312 139.73831493491005 25.111 35.67356407290726 139.73828640066432 25.111</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2abf62b8-f674-4abb-85b5-42b7f0a5bcca">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2abf62b8-f674-4abb-85b5-42b7f0a5bcca_0">
											<gml:posList>35.673567055375145 139.73828503838442 24.616 35.67356407290726 139.73828640066432 24.616 35.67356407290726 139.73828640066432 25.111 35.673573614998205 139.73828203695177 25.111 35.673573614998205 139.73828203695177 24.205 35.673567055375145 139.73828503838442 24.205 35.673567055375145 139.73828503838442 24.616</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4a519e70-ce60-4a5b-8b03-47acc90c5e33">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4a519e70-ce60-4a5b-8b03-47acc90c5e33_0">
											<gml:posList>35.673567055375145 139.73828503838442 24.205 35.67357584824261 139.7383135615844 24.205 35.67357584824261 139.7383135615844 24.616 35.673567055375145 139.73828503838442 24.616 35.673567055375145 139.73828503838442 24.205</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9841b737-8d85-4f72-bc6a-80772cf3ea6c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9841b737-8d85-4f72-bc6a-80772cf3ea6c_0">
											<gml:posList>35.67357286578312 139.73831493491005 25.111 35.673582407866384 139.73831056015374 25.111 35.673573614998205 139.73828203695177 25.111 35.67356407290726 139.73828640066432 25.111 35.67357286578312 139.73831493491005 25.111</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2207802e-4851-4199-8ea7-665c76b36048">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2207802e-4851-4199-8ea7-665c76b36048_0">
											<gml:posList>35.67357584824261 139.7383135615844 24.616 35.67357584824261 139.7383135615844 24.205 35.673582407866384 139.73831056015374 24.205 35.673582407866384 139.73831056015374 25.111 35.67357286578312 139.73831493491005 25.111 35.67357286578312 139.73831493491005 24.616 35.67357584824261 139.7383135615844 24.616</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3e669af1-90c1-4eae-ab8e-79ebb51a4d78">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3e669af1-90c1-4eae-ab8e-79ebb51a4d78_0">
											<gml:posList>35.673582407866384 139.73831056015374 24.205 35.673573614998205 139.73828203695177 24.205 35.673573614998205 139.73828203695177 25.111 35.673582407866384 139.73831056015374 25.111 35.673582407866384 139.73831056015374 24.205</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_f9d00e70-81e3-4cd2-89be-eedb5c3a4eed_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8648b2fd-64e9-4ba6-b035-5899326cb44d">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67358429770188 139.73834096948073 24.616 35.673590947332755 139.7383378022448 24.616 35.67359223048775 139.7383418659106 24.616 35.673582463278294 139.738346517098 24.616 35.67357260451609 139.7383151009202 24.616 35.673575857282486 139.7383135947138 24.616 35.67358429770188 139.73834096948073 24.616</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-450dcb78-c3df-4fe5-b92f-a1760d259287">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67358239885266 139.73831056016442 24.205 35.673590947332755 139.7383378022448 24.205 35.67358429770188 139.73834096948073 24.205 35.673575857282486 139.7383135947138 24.205 35.67358239885266 139.73831056016442 24.205</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e130434f-ab18-4317-bc58-9a77bff1fdee">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e130434f-ab18-4317-bc58-9a77bff1fdee_0">
											<gml:posList>35.673575857282486 139.7383135947138 24.616 35.67357260451609 139.7383151009202 24.616 35.67357260451609 139.7383151009202 26.535 35.67358239885266 139.73831056016442 26.535 35.67358239885266 139.73831056016442 24.205 35.673575857282486 139.7383135947138 24.205 35.673575857282486 139.7383135947138 24.616</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5c52b88c-ac07-4dd0-ba02-6d3874e5908b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5c52b88c-ac07-4dd0-ba02-6d3874e5908b_0">
											<gml:posList>35.67357260451609 139.7383151009202 24.616 35.673582463278294 139.738346517098 24.616 35.673582463278294 139.738346517098 26.535 35.67357260451609 139.7383151009202 26.535 35.67357260451609 139.7383151009202 24.616</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2c4e445d-6ee4-4f5a-9e66-a43996f0b958">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2c4e445d-6ee4-4f5a-9e66-a43996f0b958_0">
											<gml:posList>35.67358429770188 139.73834096948073 24.205 35.67358429770188 139.73834096948073 24.616 35.673575857282486 139.7383135947138 24.616 35.673575857282486 139.7383135947138 24.205 35.67358429770188 139.73834096948073 24.205</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-35455722-9e31-42e4-8d49-35537e4d2502">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-35455722-9e31-42e4-8d49-35537e4d2502_0">
											<gml:posList>35.67358239885266 139.73831056016442 26.535 35.67357260451609 139.7383151009202 26.535 35.673582463278294 139.738346517098 26.535 35.67359223048775 139.7383418659106 26.535 35.67358239885266 139.73831056016442 26.535</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a952563f-f99b-459d-96a6-8854145728b3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a952563f-f99b-459d-96a6-8854145728b3_0">
											<gml:posList>35.673590947332755 139.7383378022448 24.205 35.67358239885266 139.73831056016442 24.205 35.67358239885266 139.73831056016442 26.535 35.67359223048775 139.7383418659106 26.535 35.67359223048775 139.7383418659106 24.616 35.673590947332755 139.7383378022448 24.616 35.673590947332755 139.7383378022448 24.205</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-724b2f85-94ce-46c2-b7fe-65f7944c3589">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-724b2f85-94ce-46c2-b7fe-65f7944c3589_0">
											<gml:posList>35.673582463278294 139.738346517098 24.616 35.67359223048775 139.7383418659106 24.616 35.67359223048775 139.7383418659106 26.535 35.673582463278294 139.738346517098 26.535 35.673582463278294 139.738346517098 24.616</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-33d2d91b-22fe-4d56-8342-2c0572dc443a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-33d2d91b-22fe-4d56-8342-2c0572dc443a_0">
											<gml:posList>35.673590947332755 139.7383378022448 24.616 35.67358429770188 139.73834096948073 24.616 35.67358429770188 139.73834096948073 24.205 35.673590947332755 139.7383378022448 24.205 35.673590947332755 139.7383378022448 24.616</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_f9d00e70-81e3-4cd2-89be-eedb5c3a4eed_BuildingInstallation_1041">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-26897aac-42d8-47db-b207-8a7a10668797">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.673574194740645 139.73825141481393 24.616 35.67359776602364 139.7382404948089 24.616 35.67359822691842 139.73824200766046 24.616 35.67357470079111 139.73825303807854 24.616 35.673574194740645 139.73825141481393 24.616</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fc32a03d-2a92-48c2-ae4e-395921bfe183">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67360594441641 139.73826705243027 24.205 35.673582382136026 139.73827796137124 24.205 35.67357470079111 139.73825303807854 24.205 35.67359822691842 139.73824200766046 24.205 35.67360594441641 139.73826705243027 24.205</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-302ced21-8b33-4a30-8574-f6b1abe784cb">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67358565348182 139.73828857337196 24.205 35.67360648560097 139.73827892699504 24.205 35.673612675875866 139.7382990357044 24.205 35.673591843755126 139.73830868207682 24.205 35.67358565348182 139.73828857337196 24.205</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-333fae36-c057-4592-8cd2-93f26da36c8f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-333fae36-c057-4592-8cd2-93f26da36c8f_0">
											<gml:posList>35.67357470079111 139.73825303807854 24.616 35.67357470079111 139.73825303807854 24.205 35.673582382136026 139.73827796137124 24.205 35.673582382136026 139.73827796137124 25.935 35.673574194740645 139.73825141481393 25.935 35.673574194740645 139.73825141481393 24.616 35.67357470079111 139.73825303807854 24.616</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-65fa4015-e5e5-40a1-b751-b7d1eca93bb9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-65fa4015-e5e5-40a1-b751-b7d1eca93bb9_0">
											<gml:posList>35.673574194740645 139.73825141481393 25.935 35.67359776602364 139.7382404948089 25.935 35.67359776602364 139.7382404948089 24.616 35.673574194740645 139.73825141481393 24.616 35.673574194740645 139.73825141481393 25.935</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c1d23e5c-8eac-4b0c-9aa8-d274d48d1cf7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c1d23e5c-8eac-4b0c-9aa8-d274d48d1cf7_0">
											<gml:posList>35.67357470079111 139.73825303807854 24.205 35.67357470079111 139.73825303807854 24.616 35.67359822691842 139.73824200766046 24.616 35.67359822691842 139.73824200766046 24.205 35.67357470079111 139.73825303807854 24.205</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-849c3114-c803-497a-ac19-17b0c9954509">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-849c3114-c803-497a-ac19-17b0c9954509_0">
											<gml:posList>35.673591843755126 139.73830868207682 26.828 35.67358565348182 139.73828857337196 26.828 35.67358565348182 139.73828857337196 24.205 35.673591843755126 139.73830868207682 24.205 35.673591843755126 139.73830868207682 26.828</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-11af3819-9380-4207-bcac-829d899d4079">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-11af3819-9380-4207-bcac-829d899d4079_0">
											<gml:posList>35.673574194740645 139.73825141481393 25.935 35.673582382136026 139.73827796137124 25.935 35.67360594441641 139.73826705243027 25.935 35.67359776602364 139.7382404948089 25.935 35.673574194740645 139.73825141481393 25.935</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d9791143-dfdb-4687-adaf-ba5452d0dbda">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d9791143-dfdb-4687-adaf-ba5452d0dbda_0">
											<gml:posList>35.673582382136026 139.73827796137124 25.935 35.673582382136026 139.73827796137124 24.205 35.67360594441641 139.73826705243027 24.205 35.67360594441641 139.73826705243027 25.935 35.673582382136026 139.73827796137124 25.935</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3470f162-e022-4328-9b33-2c548dd43be8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3470f162-e022-4328-9b33-2c548dd43be8_0">
											<gml:posList>35.67360648560097 139.73827892699504 26.828 35.67360648560097 139.73827892699504 24.205 35.67358565348182 139.73828857337196 24.205 35.67358565348182 139.73828857337196 26.828 35.67360648560097 139.73827892699504 26.828</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7e26dd40-d94d-47a5-90d2-bbfda0872d95">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7e26dd40-d94d-47a5-90d2-bbfda0872d95_0">
											<gml:posList>35.673612675875866 139.7382990357044 26.828 35.67360648560097 139.73827892699504 26.828 35.67358565348182 139.73828857337196 26.828 35.673591843755126 139.73830868207682 26.828 35.673612675875866 139.7382990357044 26.828</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5be74dbd-dc82-4015-b49d-99182ae1db3d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5be74dbd-dc82-4015-b49d-99182ae1db3d_0">
											<gml:posList>35.67359822691842 139.73824200766046 24.616 35.67359776602364 139.7382404948089 24.616 35.67359776602364 139.7382404948089 25.935 35.67360594441641 139.73826705243027 25.935 35.67360594441641 139.73826705243027 24.205 35.67359822691842 139.73824200766046 24.205 35.67359822691842 139.73824200766046 24.616</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ed72955c-3929-4d74-a21a-a52d46121eae">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ed72955c-3929-4d74-a21a-a52d46121eae_0">
											<gml:posList>35.673612675875866 139.7382990357044 26.828 35.673591843755126 139.73830868207682 26.828 35.673591843755126 139.73830868207682 24.205 35.673612675875866 139.7382990357044 24.205 35.673612675875866 139.7382990357044 26.828</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-89180ac6-d8d0-4284-ac23-d54064f1169a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-89180ac6-d8d0-4284-ac23-d54064f1169a_0">
											<gml:posList>35.67360648560097 139.73827892699504 26.828 35.673612675875866 139.7382990357044 26.828 35.673612675875866 139.7382990357044 24.205 35.67360648560097 139.73827892699504 24.205 35.67360648560097 139.73827892699504 26.828</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-2d6abbec-24a0-47e1-87f7-510bf246f2d9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2d6abbec-24a0-47e1-87f7-510bf246f2d9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2d6abbec-24a0-47e1-87f7-510bf246f2d9">
											<gml:posList>35.673582004162576 139.73834725777093 8.73 35.67354901960476 139.73824025436957 8.73 35.67361912058476 139.73820758343652 8.73 35.67365228483547 139.7383138134352 8.73 35.673582004162576 139.73834725777093 8.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-90cf9d2d-674b-4f33-a81c-811926cf5d17">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-90cf9d2d-674b-4f33-a81c-811926cf5d17">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-90cf9d2d-674b-4f33-a81c-811926cf5d17">
											<gml:posList>35.67362441602679 139.7382245448938 22.878 35.67361912058476 139.73820758343652 22.878 35.67354901960476 139.73824025436957 22.878 35.67355430618552 139.73825741466524 22.878 35.67362441602679 139.7382245448938 22.878</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-7c1c6d44-510e-4e73-82d2-314128222275">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7c1c6d44-510e-4e73-82d2-314128222275">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7c1c6d44-510e-4e73-82d2-314128222275">
											<gml:posList>35.67355430618552 139.73825741466524 24.616 35.67355940115134 139.73826021448394 24.616 35.67362214049485 139.738230800029 24.616 35.67362441602679 139.7382245448938 24.616 35.67355430618552 139.73825741466524 24.616</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-7964e5cb-0938-45ec-8954-b7af4960d469">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7964e5cb-0938-45ec-8954-b7af4960d469">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7964e5cb-0938-45ec-8954-b7af4960d469">
											<gml:posList>35.673582004162576 139.73834725777093 24.616 35.67358429770188 139.73834096948073 24.616 35.67355940115134 139.73826021448394 24.616 35.67355430618552 139.73825741466524 24.616 35.673582004162576 139.73834725777093 24.616</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-12cea7d8-3a90-48c7-99fc-c0c7a36f2daf">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-12cea7d8-3a90-48c7-99fc-c0c7a36f2daf">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-12cea7d8-3a90-48c7-99fc-c0c7a36f2daf">
											<gml:posList>35.67364719891085 139.73831104673928 24.205 35.67362214049485 139.738230800029 24.205 35.67355940115134 139.73826021448394 24.205 35.67358429770188 139.73834096948073 24.205 35.67364719891085 139.73831104673928 24.205</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-9c35aed8-da90-4515-b9b8-0b24b4319156">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9c35aed8-da90-4515-b9b8-0b24b4319156">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9c35aed8-da90-4515-b9b8-0b24b4319156">
											<gml:posList>35.67365228483547 139.7383138134352 24.616 35.67364719891085 139.73831104673928 24.616 35.67358429770188 139.73834096948073 24.616 35.673582004162576 139.73834725777093 24.616 35.67365228483547 139.7383138134352 24.616</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-2812b753-eb97-4941-8803-8e3fdb7720d6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2812b753-eb97-4941-8803-8e3fdb7720d6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2812b753-eb97-4941-8803-8e3fdb7720d6">
											<gml:posList>35.67362441602679 139.7382245448938 24.616 35.67362214049485 139.738230800029 24.616 35.67364719891085 139.73831104673928 24.616 35.67365228483547 139.7383138134352 24.616 35.67362441602679 139.7382245448938 24.616</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-335824d0-cf29-4720-9511-f92929074de6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-335824d0-cf29-4720-9511-f92929074de6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-335824d0-cf29-4720-9511-f92929074de6">
											<gml:posList>35.67361912058476 139.73820758343652 8.73 35.67354901960476 139.73824025436957 8.73 35.67354901960476 139.73824025436957 22.878 35.67361912058476 139.73820758343652 22.878 35.67361912058476 139.73820758343652 8.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d7d89078-d3c0-4cda-b323-192c6f8957a8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d7d89078-d3c0-4cda-b323-192c6f8957a8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d7d89078-d3c0-4cda-b323-192c6f8957a8">
											<gml:posList>35.67355430618552 139.73825741466524 22.878 35.67355430618552 139.73825741466524 24.616 35.67362441602679 139.7382245448938 24.616 35.67362441602679 139.7382245448938 22.878 35.67355430618552 139.73825741466524 22.878</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6ad4dedd-a1eb-4878-9d41-911100c8918a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6ad4dedd-a1eb-4878-9d41-911100c8918a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6ad4dedd-a1eb-4878-9d41-911100c8918a">
											<gml:posList>35.67355940115134 139.73826021448394 24.616 35.67355940115134 139.73826021448394 24.205 35.67362214049485 139.738230800029 24.205 35.67362214049485 139.738230800029 24.616 35.67355940115134 139.73826021448394 24.616</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f09d8f2a-d226-4f8d-bc29-59e1e46c49a9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f09d8f2a-d226-4f8d-bc29-59e1e46c49a9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f09d8f2a-d226-4f8d-bc29-59e1e46c49a9">
											<gml:posList>35.67361912058476 139.73820758343652 8.73 35.67361912058476 139.73820758343652 22.878 35.67362441602679 139.7382245448938 22.878 35.67362441602679 139.7382245448938 24.616 35.67365228483547 139.7383138134352 24.616 35.67365228483547 139.7383138134352 8.73 35.67361912058476 139.73820758343652 8.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9ea2e816-8558-42b5-b40e-8a4e401a454b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9ea2e816-8558-42b5-b40e-8a4e401a454b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9ea2e816-8558-42b5-b40e-8a4e401a454b">
											<gml:posList>35.67362214049485 139.738230800029 24.616 35.67362214049485 139.738230800029 24.205 35.67364719891085 139.73831104673928 24.205 35.67364719891085 139.73831104673928 24.616 35.67362214049485 139.738230800029 24.616</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6d04bcef-5930-4196-bd27-dc63ea6b82b2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6d04bcef-5930-4196-bd27-dc63ea6b82b2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6d04bcef-5930-4196-bd27-dc63ea6b82b2">
											<gml:posList>35.673582004162576 139.73834725777093 8.73 35.673582004162576 139.73834725777093 24.616 35.67355430618552 139.73825741466524 24.616 35.67355430618552 139.73825741466524 22.878 35.67354901960476 139.73824025436957 22.878 35.67354901960476 139.73824025436957 8.73 35.673582004162576 139.73834725777093 8.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4c3c2590-753b-4329-9a11-8376cec02ac6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4c3c2590-753b-4329-9a11-8376cec02ac6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4c3c2590-753b-4329-9a11-8376cec02ac6">
											<gml:posList>35.67358429770188 139.73834096948073 24.616 35.67358429770188 139.73834096948073 24.205 35.67355940115134 139.73826021448394 24.205 35.67355940115134 139.73826021448394 24.616 35.67358429770188 139.73834096948073 24.616</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ce12244e-e61e-4bbd-8c0e-f7822df6f66a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ce12244e-e61e-4bbd-8c0e-f7822df6f66a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ce12244e-e61e-4bbd-8c0e-f7822df6f66a">
											<gml:posList>35.67364719891085 139.73831104673928 24.616 35.67364719891085 139.73831104673928 24.205 35.67358429770188 139.73834096948073 24.205 35.67358429770188 139.73834096948073 24.616 35.67364719891085 139.73831104673928 24.616</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f1473b2f-e66f-47e4-869b-1fe703356a3b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f1473b2f-e66f-47e4-869b-1fe703356a3b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f1473b2f-e66f-47e4-869b-1fe703356a3b">
											<gml:posList>35.67365228483547 139.7383138134352 24.616 35.673582004162576 139.73834725777093 24.616 35.673582004162576 139.73834725777093 8.73 35.67365228483547 139.7383138134352 8.73 35.67365228483547 139.7383138134352 24.616</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂三丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-2421</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">86.13755</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1210</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>5</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.01</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>