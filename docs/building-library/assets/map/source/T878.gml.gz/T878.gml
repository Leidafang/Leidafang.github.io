<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_fa92bcd4-faba-4269-a88e-ab9569f995d5">
			<core:creationDate>2024-03-15</core:creationDate>
			<bldg:measuredHeight uom="m">3.9</bldg:measuredHeight>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.67277282193646 139.74642372618393 0 35.672799793148116 139.74638923157408 0 35.672739322830125 139.74631821237864 0 35.67271235163054 139.7463526959397 0 35.67277282193646 139.74642372618393 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67277282193646 139.74642372618393 11.073 35.67271235163054 139.7463526959397 11.073 35.672739322830125 139.74631821237864 11.073 35.672799793148116 139.74638923157408 11.073 35.67277282193646 139.74642372618393 11.073</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67277282193646 139.74642372618393 11.073 35.672799793148116 139.74638923157408 11.073 35.672799793148116 139.74638923157408 14.81 35.67277282193646 139.74642372618393 14.81 35.67277282193646 139.74642372618393 11.073</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672799793148116 139.74638923157408 11.073 35.672739322830125 139.74631821237864 11.073 35.672739322830125 139.74631821237864 14.81 35.672799793148116 139.74638923157408 14.81 35.672799793148116 139.74638923157408 11.073</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672739322830125 139.74631821237864 11.073 35.67271235163054 139.7463526959397 11.073 35.67271235163054 139.7463526959397 14.81 35.672739322830125 139.74631821237864 14.81 35.672739322830125 139.74631821237864 11.073</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67271235163054 139.7463526959397 11.073 35.67277282193646 139.74642372618393 11.073 35.67277282193646 139.74642372618393 14.81 35.67271235163054 139.7463526959397 14.81 35.67271235163054 139.7463526959397 11.073</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67277282193646 139.74642372618393 14.81 35.672799793148116 139.74638923157408 14.81 35.672739322830125 139.74631821237864 14.81 35.67271235163054 139.7463526959397 14.81 35.67277282193646 139.74642372618393 14.81</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-0fa23d09-3309-47b1-abf5-995cf2af855b"/>
							<gml:surfaceMember xlink:href="#poly-eb5fed67-e534-4b87-83ab-0673c503be86"/>
							<gml:surfaceMember xlink:href="#poly-2fbcc340-983b-48e5-ab33-6601c468b5d9"/>
							<gml:surfaceMember xlink:href="#poly-69f39e80-f3e2-48a4-bafe-5275b77801da"/>
							<gml:surfaceMember xlink:href="#poly-e4743f7c-2137-4ac3-a18a-6fe9c072e92d"/>
							<gml:surfaceMember xlink:href="#poly-f602aa12-c4ef-4a1b-bd46-726ec2f8f0f9"/>
							<gml:surfaceMember xlink:href="#poly-ae1de1c9-f035-4dd2-a0f0-85bb07599055"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-0fa23d09-3309-47b1-abf5-995cf2af855b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0fa23d09-3309-47b1-abf5-995cf2af855b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0fa23d09-3309-47b1-abf5-995cf2af855b">
											<gml:posList>35.67273932283011 139.74631821237864 11.073 35.672799793148094 139.74638923157406 11.073 35.67277282193642 139.7464237261839 11.073 35.67271235163052 139.7463526959397 11.073 35.67273932283011 139.74631821237864 11.073</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-eb5fed67-e534-4b87-83ab-0673c503be86">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-eb5fed67-e534-4b87-83ab-0673c503be86">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-eb5fed67-e534-4b87-83ab-0673c503be86">
											<gml:posList>35.672799793148094 139.74638923157406 14.937 35.67273932283011 139.74631821237864 14.737 35.67271235163052 139.7463526959397 14.937 35.672799793148094 139.74638923157406 14.937</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-2fbcc340-983b-48e5-ab33-6601c468b5d9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2fbcc340-983b-48e5-ab33-6601c468b5d9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2fbcc340-983b-48e5-ab33-6601c468b5d9">
											<gml:posList>35.67271235163052 139.7463526959397 14.937 35.67277282193642 139.7464237261839 14.937 35.672799793148094 139.74638923157406 14.937 35.67271235163052 139.7463526959397 14.937</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-69f39e80-f3e2-48a4-bafe-5275b77801da">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-69f39e80-f3e2-48a4-bafe-5275b77801da">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-69f39e80-f3e2-48a4-bafe-5275b77801da">
											<gml:posList>35.67273932283011 139.74631821237864 14.737 35.67273932283011 139.74631821237864 11.073 35.67271235163052 139.7463526959397 11.073 35.67271235163052 139.7463526959397 14.937 35.67273932283011 139.74631821237864 14.737</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e4743f7c-2137-4ac3-a18a-6fe9c072e92d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e4743f7c-2137-4ac3-a18a-6fe9c072e92d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e4743f7c-2137-4ac3-a18a-6fe9c072e92d">
											<gml:posList>35.672799793148094 139.74638923157406 14.937 35.672799793148094 139.74638923157406 11.073 35.67273932283011 139.74631821237864 11.073 35.67273932283011 139.74631821237864 14.737 35.672799793148094 139.74638923157406 14.937</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f602aa12-c4ef-4a1b-bd46-726ec2f8f0f9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f602aa12-c4ef-4a1b-bd46-726ec2f8f0f9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f602aa12-c4ef-4a1b-bd46-726ec2f8f0f9">
											<gml:posList>35.67271235163052 139.7463526959397 11.073 35.67277282193642 139.7464237261839 11.073 35.67277282193642 139.7464237261839 14.937 35.67271235163052 139.7463526959397 14.937 35.67271235163052 139.7463526959397 11.073</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ae1de1c9-f035-4dd2-a0f0-85bb07599055">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ae1de1c9-f035-4dd2-a0f0-85bb07599055">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ae1de1c9-f035-4dd2-a0f0-85bb07599055">
											<gml:posList>35.67277282193642 139.7464237261839 11.073 35.672799793148094 139.74638923157406 11.073 35.672799793148094 139.74638923157406 14.937 35.67277282193642 139.7464237261839 14.937 35.67277282193642 139.7464237261839 11.073</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13101-bldg-4516</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13101</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">215</uro:landUseType>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>5</uro:specifiedFloorAreaRate>
					<uro:surveyYear>0001</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.08</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.0</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>