<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_faf8961a-5244-4c11-93cc-3f5b193b5bf3">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3001</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">411</bldg:usage>
			<bldg:measuredHeight uom="m">5.7</bldg:measuredHeight>
			<bldg:storeysAboveGround>2</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.6690638701681 139.73866488304856 0 35.669134316588654 139.7387389191218 0 35.66917447967816 139.73867889145322 0 35.669184824984654 139.73866429839563 0 35.669113297567215 139.73859114730556 0 35.6690638701681 139.73866488304856 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6690638701681 139.73866488304856 15.953 35.669113297567215 139.73859114730556 15.953 35.669184824984654 139.73866429839563 15.953 35.66917447967816 139.73867889145322 15.953 35.669134316588654 139.7387389191218 15.953 35.6690638701681 139.73866488304856 15.953</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6690638701681 139.73866488304856 15.953 35.669134316588654 139.7387389191218 15.953 35.669134316588654 139.7387389191218 21.7 35.6690638701681 139.73866488304856 21.7 35.6690638701681 139.73866488304856 15.953</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669134316588654 139.7387389191218 15.953 35.66917447967816 139.73867889145322 15.953 35.66917447967816 139.73867889145322 21.7 35.669134316588654 139.7387389191218 21.7 35.669134316588654 139.7387389191218 15.953</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66917447967816 139.73867889145322 15.953 35.669184824984654 139.73866429839563 15.953 35.669184824984654 139.73866429839563 21.7 35.66917447967816 139.73867889145322 21.7 35.66917447967816 139.73867889145322 15.953</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669184824984654 139.73866429839563 15.953 35.669113297567215 139.73859114730556 15.953 35.669113297567215 139.73859114730556 21.7 35.669184824984654 139.73866429839563 21.7 35.669184824984654 139.73866429839563 15.953</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669113297567215 139.73859114730556 15.953 35.6690638701681 139.73866488304856 15.953 35.6690638701681 139.73866488304856 21.7 35.669113297567215 139.73859114730556 21.7 35.669113297567215 139.73859114730556 15.953</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6690638701681 139.73866488304856 21.7 35.669134316588654 139.7387389191218 21.7 35.66917447967816 139.73867889145322 21.7 35.669184824984654 139.73866429839563 21.7 35.669113297567215 139.73859114730556 21.7 35.6690638701681 139.73866488304856 21.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-756f62a8-e71e-41ad-acbc-9e05b0bc2f99"/>
							<gml:surfaceMember xlink:href="#poly-4dcf944f-fd08-4dd2-96bb-99fa5016a479"/>
							<gml:surfaceMember xlink:href="#poly-c7460607-7997-414a-a6d5-ebe1b52b650b"/>
							<gml:surfaceMember xlink:href="#poly-54aa1681-9ab9-4adf-a8f2-869e0d685c05"/>
							<gml:surfaceMember xlink:href="#poly-277f2dbc-3a9c-4e1e-aa41-bdcb93bb9c3c"/>
							<gml:surfaceMember xlink:href="#poly-eb81f283-866a-49ce-b446-d621780d3541"/>
							<gml:surfaceMember xlink:href="#poly-ad36d286-bf7a-429c-aeee-2ecba8a80e39"/>
							<gml:surfaceMember xlink:href="#poly-ec379082-6df9-4367-bdd0-d135fa86a050"/>
							<gml:surfaceMember xlink:href="#poly-8531ccaf-c55b-4f6d-a2bb-73f64dfc3137"/>
							<gml:surfaceMember xlink:href="#poly-af06fe0c-caf1-4a90-aec4-a27f62f297e6"/>
							<gml:surfaceMember xlink:href="#poly-3ecfc4fa-0272-428f-844c-234d57e257d0"/>
							<gml:surfaceMember xlink:href="#poly-f5ad469d-8f09-4eb4-ac22-d1fee6eb58ff"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_faf8961a-5244-4c11-93cc-3f5b193b5bf3_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c7d18bc0-15b5-41b3-a98c-02580dea487d">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66913797975159 139.73870906827005 18.732 35.66912866146603 139.73872297524406 18.732 35.669109952185764 139.73870414165435 18.732 35.669119270469174 139.73869023468137 18.732 35.66913797975159 139.73870906827005 18.732</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-368279b6-44a0-4296-ac77-0e98d37bfdd3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-368279b6-44a0-4296-ac77-0e98d37bfdd3_0">
											<gml:posList>35.669109952185764 139.73870414165435 18.732 35.669109952185764 139.73870414165435 20.609 35.669119270469174 139.73869023468137 20.609 35.669119270469174 139.73869023468137 18.732 35.669109952185764 139.73870414165435 18.732</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4ddce512-adde-457b-8d03-1c8c99222b55">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4ddce512-adde-457b-8d03-1c8c99222b55_0">
											<gml:posList>35.669119270469174 139.73869023468137 18.732 35.669119270469174 139.73869023468137 20.609 35.66913797975159 139.73870906827005 20.609 35.66913797975159 139.73870906827005 18.732 35.669119270469174 139.73869023468137 18.732</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5845d219-ebcc-4c9d-888f-fdef3b04fef5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5845d219-ebcc-4c9d-888f-fdef3b04fef5_0">
											<gml:posList>35.669109952185764 139.73870414165435 20.609 35.66912866146603 139.73872297524406 20.609 35.66913797975159 139.73870906827005 20.609 35.669119270469174 139.73869023468137 20.609 35.669109952185764 139.73870414165435 20.609</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-37d04926-105c-4761-8914-d8d0b08e2636">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-37d04926-105c-4761-8914-d8d0b08e2636_0">
											<gml:posList>35.66912866146603 139.73872297524406 18.732 35.66912866146603 139.73872297524406 20.609 35.669109952185764 139.73870414165435 20.609 35.669109952185764 139.73870414165435 18.732 35.66912866146603 139.73872297524406 18.732</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-231f8361-854b-41d5-a15a-b7771df3bfbf">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-231f8361-854b-41d5-a15a-b7771df3bfbf_0">
											<gml:posList>35.66913797975159 139.73870906827005 18.732 35.66913797975159 139.73870906827005 20.609 35.66912866146603 139.73872297524406 20.609 35.66912866146603 139.73872297524406 18.732 35.66913797975159 139.73870906827005 18.732</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-756f62a8-e71e-41ad-acbc-9e05b0bc2f99">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-756f62a8-e71e-41ad-acbc-9e05b0bc2f99">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-756f62a8-e71e-41ad-acbc-9e05b0bc2f99">
											<gml:posList>35.669113297567186 139.73859114730556 15.953 35.669184824984626 139.73866429839563 15.953 35.66917447967815 139.7386788914532 15.953 35.66913431658866 139.7387389191218 15.953 35.66906387016809 139.73866488304853 15.953 35.669113297567186 139.73859114730556 15.953</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-4dcf944f-fd08-4dd2-96bb-99fa5016a479">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4dcf944f-fd08-4dd2-96bb-99fa5016a479">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4dcf944f-fd08-4dd2-96bb-99fa5016a479">
											<gml:posList>35.6691704577251 139.73866509963148 22.056 35.66910673426215 139.738600941891 22.056 35.66909138384888 139.73862382541628 23.328 35.669155062309315 139.73868808263066 23.328 35.6691704577251 139.73866509963148 22.056</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c7460607-7997-414a-a6d5-ebe1b52b650b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c7460607-7997-414a-a6d5-ebe1b52b650b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c7460607-7997-414a-a6d5-ebe1b52b650b">
											<gml:posList>35.66913978391996 139.7387108776994 18.732 35.669076033439886 139.73864671997885 18.732 35.66906387016809 139.73866488304853 18.732 35.66913431658866 139.7387389191218 18.732 35.66917447967815 139.7386788914532 18.732 35.669184824984626 139.73866429839563 18.732 35.669113297567186 139.73859114730556 18.732 35.66910673426215 139.738600941891 18.732 35.6691704577251 139.73866509963148 18.732 35.66913978391996 139.7387108776994 18.732</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-54aa1681-9ab9-4adf-a8f2-869e0d685c05">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-54aa1681-9ab9-4adf-a8f2-869e0d685c05">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-54aa1681-9ab9-4adf-a8f2-869e0d685c05">
											<gml:posList>35.669076033439886 139.73864671997885 22.056 35.66913978391996 139.7387108776994 22.056 35.669155062309315 139.73868808263066 23.328 35.66909138384888 139.73862382541628 23.328 35.669076033439886 139.73864671997885 22.056</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-277f2dbc-3a9c-4e1e-aa41-bdcb93bb9c3c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-277f2dbc-3a9c-4e1e-aa41-bdcb93bb9c3c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-277f2dbc-3a9c-4e1e-aa41-bdcb93bb9c3c">
											<gml:posList>35.669184824984626 139.73866429839563 15.953 35.669113297567186 139.73859114730556 15.953 35.669113297567186 139.73859114730556 18.732 35.669184824984626 139.73866429839563 18.732 35.669184824984626 139.73866429839563 15.953</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-eb81f283-866a-49ce-b446-d621780d3541">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-eb81f283-866a-49ce-b446-d621780d3541">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-eb81f283-866a-49ce-b446-d621780d3541">
											<gml:posList>35.66909138384888 139.73862382541628 23.328 35.66910673426215 139.738600941891 22.056 35.66910673426215 139.738600941891 18.732 35.669113297567186 139.73859114730556 18.732 35.669113297567186 139.73859114730556 15.953 35.66906387016809 139.73866488304853 15.953 35.66906387016809 139.73866488304853 18.732 35.669076033439886 139.73864671997885 18.732 35.669076033439886 139.73864671997885 22.056 35.66909138384888 139.73862382541628 23.328</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ad36d286-bf7a-429c-aeee-2ecba8a80e39">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ad36d286-bf7a-429c-aeee-2ecba8a80e39">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ad36d286-bf7a-429c-aeee-2ecba8a80e39">
											<gml:posList>35.66910673426215 139.738600941891 22.056 35.6691704577251 139.73866509963148 22.056 35.6691704577251 139.73866509963148 18.732 35.66910673426215 139.738600941891 18.732 35.66910673426215 139.738600941891 22.056</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ec379082-6df9-4367-bdd0-d135fa86a050">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ec379082-6df9-4367-bdd0-d135fa86a050">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ec379082-6df9-4367-bdd0-d135fa86a050">
											<gml:posList>35.66917447967815 139.7386788914532 15.953 35.669184824984626 139.73866429839563 15.953 35.669184824984626 139.73866429839563 18.732 35.66917447967815 139.7386788914532 18.732 35.66917447967815 139.7386788914532 15.953</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8531ccaf-c55b-4f6d-a2bb-73f64dfc3137">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8531ccaf-c55b-4f6d-a2bb-73f64dfc3137">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8531ccaf-c55b-4f6d-a2bb-73f64dfc3137">
											<gml:posList>35.66913978391996 139.7387108776994 22.056 35.669076033439886 139.73864671997885 22.056 35.669076033439886 139.73864671997885 18.732 35.66913978391996 139.7387108776994 18.732 35.66913978391996 139.7387108776994 22.056</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-af06fe0c-caf1-4a90-aec4-a27f62f297e6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-af06fe0c-caf1-4a90-aec4-a27f62f297e6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-af06fe0c-caf1-4a90-aec4-a27f62f297e6">
											<gml:posList>35.66913978391996 139.7387108776994 18.732 35.6691704577251 139.73866509963148 18.732 35.6691704577251 139.73866509963148 22.056 35.669155062309315 139.73868808263066 23.328 35.66913978391996 139.7387108776994 22.056 35.66913978391996 139.7387108776994 18.732</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3ecfc4fa-0272-428f-844c-234d57e257d0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3ecfc4fa-0272-428f-844c-234d57e257d0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3ecfc4fa-0272-428f-844c-234d57e257d0">
											<gml:posList>35.66906387016809 139.73866488304853 15.953 35.66913431658866 139.7387389191218 15.953 35.66913431658866 139.7387389191218 18.732 35.66906387016809 139.73866488304853 18.732 35.66906387016809 139.73866488304853 15.953</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f5ad469d-8f09-4eb4-ac22-d1fee6eb58ff">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f5ad469d-8f09-4eb4-ac22-d1fee6eb58ff">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f5ad469d-8f09-4eb4-ac22-d1fee6eb58ff">
											<gml:posList>35.66913431658866 139.7387389191218 15.953 35.66917447967815 139.7386788914532 15.953 35.66917447967815 139.7386788914532 18.732 35.66913431658866 139.7387389191218 18.732 35.66913431658866 139.7387389191218 15.953</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-4399</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">89.65395</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1003</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">211</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1310</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>4</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.01</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">21</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>