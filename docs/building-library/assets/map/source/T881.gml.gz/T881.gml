<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_fb5f3b2c-0fe6-4aca-b84e-85db4b1148fe">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>29</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103029002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">401</bldg:usage>
			<bldg:measuredHeight uom="m">15.7</bldg:measuredHeight>
			<bldg:storeysAboveGround>5</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.667314395604876 139.73891879360727 0 35.66725397426921 139.7388814193904 0 35.66724164876574 139.73891114718296 0 35.667234253958384 139.73890662710193 0 35.66723092528875 139.7389148049326 0 35.667293254126776 139.73897084437826 0 35.667314395604876 139.73891879360727 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667314395604876 139.73891879360727 12.06 35.667293254126776 139.73897084437826 12.06 35.66723092528875 139.7389148049326 12.06 35.667234253958384 139.73890662710193 12.06 35.66724164876574 139.73891114718296 12.06 35.66725397426921 139.7388814193904 12.06 35.667314395604876 139.73891879360727 12.06</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667314395604876 139.73891879360727 12.06 35.66725397426921 139.7388814193904 12.06 35.66725397426921 139.7388814193904 27.76 35.667314395604876 139.73891879360727 27.76 35.667314395604876 139.73891879360727 12.06</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66725397426921 139.7388814193904 12.06 35.66724164876574 139.73891114718296 12.06 35.66724164876574 139.73891114718296 27.76 35.66725397426921 139.7388814193904 27.76 35.66725397426921 139.7388814193904 12.06</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66724164876574 139.73891114718296 12.06 35.667234253958384 139.73890662710193 12.06 35.667234253958384 139.73890662710193 27.76 35.66724164876574 139.73891114718296 27.76 35.66724164876574 139.73891114718296 12.06</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667234253958384 139.73890662710193 12.06 35.66723092528875 139.7389148049326 12.06 35.66723092528875 139.7389148049326 27.76 35.667234253958384 139.73890662710193 27.76 35.667234253958384 139.73890662710193 12.06</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66723092528875 139.7389148049326 12.06 35.667293254126776 139.73897084437826 12.06 35.667293254126776 139.73897084437826 27.76 35.66723092528875 139.7389148049326 27.76 35.66723092528875 139.7389148049326 12.06</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667293254126776 139.73897084437826 12.06 35.667314395604876 139.73891879360727 12.06 35.667314395604876 139.73891879360727 27.76 35.667293254126776 139.73897084437826 27.76 35.667293254126776 139.73897084437826 12.06</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667314395604876 139.73891879360727 27.76 35.66725397426921 139.7388814193904 27.76 35.66724164876574 139.73891114718296 27.76 35.667234253958384 139.73890662710193 27.76 35.66723092528875 139.7389148049326 27.76 35.667293254126776 139.73897084437826 27.76 35.667314395604876 139.73891879360727 27.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-6ff07a68-1779-4867-8afa-03faf44ded4e"/>
							<gml:surfaceMember xlink:href="#poly-ad97ff5c-9509-49d5-84d1-23a2aa6c7f6a"/>
							<gml:surfaceMember xlink:href="#poly-7d0c87c5-4f88-4dbc-9a0b-03ea40fc1b93"/>
							<gml:surfaceMember xlink:href="#poly-e788829b-17ec-4dbc-b8d7-50025236f4f0"/>
							<gml:surfaceMember xlink:href="#poly-36775500-e457-4e06-a966-7857802f2d2e"/>
							<gml:surfaceMember xlink:href="#poly-1db6e890-5d43-4e6b-ad2a-0a166540f2d4"/>
							<gml:surfaceMember xlink:href="#poly-43fcfc81-54e6-403c-aa9d-2f8061256653"/>
							<gml:surfaceMember xlink:href="#poly-1ba9bcdb-7800-407f-a720-532fd35697e7"/>
							<gml:surfaceMember xlink:href="#poly-fb5e8e67-b7e6-4ac7-9650-161076eb5183"/>
							<gml:surfaceMember xlink:href="#poly-26df9763-0127-4321-b785-e20ad0a7be30"/>
							<gml:surfaceMember xlink:href="#poly-e6e76343-1bb2-40be-9b31-4725ad04071d"/>
							<gml:surfaceMember xlink:href="#poly-4ce2b793-41e9-4c74-b869-1ef69aab67ac"/>
							<gml:surfaceMember xlink:href="#poly-691cb9ee-5c8a-4f89-b8b0-88943a20011b"/>
							<gml:surfaceMember xlink:href="#poly-0d806137-d06e-48be-bebe-9c125eab3b2a"/>
							<gml:surfaceMember xlink:href="#poly-50b49d8b-e956-4b39-a4e4-ec94c97ca28d"/>
							<gml:surfaceMember xlink:href="#poly-36333fe8-9421-46d2-8112-842101ab438f"/>
							<gml:surfaceMember xlink:href="#poly-9f4d26ca-1628-4476-bc45-7c70c3ec2900"/>
							<gml:surfaceMember xlink:href="#poly-687d0ccf-856a-4c75-95a5-2337973f7bfc"/>
							<gml:surfaceMember xlink:href="#poly-5e45e4a7-d6ea-462e-9a94-91cccc2ae922"/>
							<gml:surfaceMember xlink:href="#poly-3e994f4a-3c0b-44dd-bcac-9e42932be539"/>
							<gml:surfaceMember xlink:href="#poly-ffc0a398-7f9d-4571-92d8-3f8be3a4f3ff"/>
							<gml:surfaceMember xlink:href="#poly-9558a525-9faa-410a-9969-ecbd937a6e67"/>
							<gml:surfaceMember xlink:href="#poly-ecda35e6-2a92-46fd-931e-fe129a7b5273"/>
							<gml:surfaceMember xlink:href="#poly-388c6051-3be1-4087-964c-77190be9c51f"/>
							<gml:surfaceMember xlink:href="#poly-81fa9b79-8fce-4d87-aa5f-bd14d3a5dd26"/>
							<gml:surfaceMember xlink:href="#poly-72f4de3b-3f14-49e1-94c2-1f3c49abbe48"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_fb5f3b2c-0fe6-4aca-b84e-85db4b1148fe_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-70d405b4-c8e8-418b-a398-3088b22404f4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66726609838447 139.7389167186288 30.64 35.667283529712954 139.73892663935354 30.64 35.6672794908972 139.73893729229076 30.64 35.66726205957822 139.73892738261003 30.64 35.66726609838447 139.7389167186288 30.64</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c13f0c6a-69e2-426c-a6ab-b76b03cb398b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c13f0c6a-69e2-426c-a6ab-b76b03cb398b_0">
											<gml:posList>35.66726609838447 139.7389167186288 31.845 35.667283529712954 139.73892663935354 31.845 35.667283529712954 139.73892663935354 30.64 35.66726609838447 139.7389167186288 30.64 35.66726609838447 139.7389167186288 31.845</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4ddae156-30f9-4017-9ee0-f96ed311f25d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4ddae156-30f9-4017-9ee0-f96ed311f25d_0">
											<gml:posList>35.66726205957822 139.73892738261003 30.64 35.66726205957822 139.73892738261003 31.845 35.66726609838447 139.7389167186288 31.845 35.66726609838447 139.7389167186288 30.64 35.66726205957822 139.73892738261003 30.64</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-444e811f-72b3-461a-a451-60a6872c220e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-444e811f-72b3-461a-a451-60a6872c220e_0">
											<gml:posList>35.6672794908972 139.73893729229076 31.845 35.667283529712954 139.73892663935354 31.845 35.66726609838447 139.7389167186288 31.845 35.66726205957822 139.73892738261003 31.845 35.6672794908972 139.73893729229076 31.845</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cd30952a-a52b-4e6f-9daa-e3d211a575df">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cd30952a-a52b-4e6f-9daa-e3d211a575df_0">
											<gml:posList>35.667283529712954 139.73892663935354 30.64 35.667283529712954 139.73892663935354 31.845 35.6672794908972 139.73893729229076 31.845 35.6672794908972 139.73893729229076 30.64 35.667283529712954 139.73892663935354 30.64</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0d6b2f75-af24-4c2a-ab6f-940f07df1166">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0d6b2f75-af24-4c2a-ab6f-940f07df1166_0">
											<gml:posList>35.6672794908972 139.73893729229076 30.64 35.6672794908972 139.73893729229076 31.845 35.66726205957822 139.73892738261003 31.845 35.66726205957822 139.73892738261003 30.64 35.6672794908972 139.73893729229076 30.64</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-6ff07a68-1779-4867-8afa-03faf44ded4e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6ff07a68-1779-4867-8afa-03faf44ded4e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6ff07a68-1779-4867-8afa-03faf44ded4e">
											<gml:posList>35.66729325412676 139.73897084437826 12.06 35.66723092528875 139.73891480493256 12.06 35.66723425395838 139.73890662710193 12.06 35.66724164876574 139.73891114718296 12.06 35.66725397426921 139.73888141939037 12.06 35.66731439560488 139.73891879360727 12.06 35.66729325412676 139.73897084437826 12.06</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ad97ff5c-9509-49d5-84d1-23a2aa6c7f6a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ad97ff5c-9509-49d5-84d1-23a2aa6c7f6a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ad97ff5c-9509-49d5-84d1-23a2aa6c7f6a">
											<gml:posList>35.66725462515494 139.73888383766018 28.487 35.66727200306218 139.73889459792244 28.487 35.66727266881319 139.738892984447 28.487 35.66725397426921 139.73888141939037 28.487 35.66725462515494 139.73888383766018 28.487</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-7d0c87c5-4f88-4dbc-9a0b-03ea40fc1b93">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7d0c87c5-4f88-4dbc-9a0b-03ea40fc1b93">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7d0c87c5-4f88-4dbc-9a0b-03ea40fc1b93">
											<gml:posList>35.66724164876574 139.73891114718296 28.487 35.66724229965087 139.73891356545263 28.487 35.66725462515494 139.73888383766018 28.487 35.66725397426921 139.73888141939037 28.487 35.66724164876574 139.73891114718296 28.487</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e788829b-17ec-4dbc-b8d7-50025236f4f0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e788829b-17ec-4dbc-b8d7-50025236f4f0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e788829b-17ec-4dbc-b8d7-50025236f4f0">
											<gml:posList>35.66724164876574 139.73891114718296 28.487 35.66723425395838 139.73890662710193 28.487 35.667234913857335 139.73890904536074 28.487 35.66724229965087 139.73891356545263 28.487 35.66724164876574 139.73891114718296 28.487</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-36775500-e457-4e06-a966-7857802f2d2e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-36775500-e457-4e06-a966-7857802f2d2e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-36775500-e457-4e06-a966-7857802f2d2e">
											<gml:posList>35.66723092528875 139.73891480493256 28.487 35.667232781692135 139.7389142615012 28.487 35.667234913857335 139.73890904536074 28.487 35.66723425395838 139.73890662710193 28.487 35.66723092528875 139.73891480493256 28.487</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-1db6e890-5d43-4e6b-ad2a-0a166540f2d4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1db6e890-5d43-4e6b-ad2a-0a166540f2d4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1db6e890-5d43-4e6b-ad2a-0a166540f2d4">
											<gml:posList>35.66731243123597 139.73891959122042 28.487 35.66731439560488 139.73891879360727 28.487 35.6672951690024 139.738906908836 28.487 35.66729450324255 139.73890851126592 28.487 35.66731243123597 139.73891959122042 28.487</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-43fcfc81-54e6-403c-aa9d-2f8061256653">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-43fcfc81-54e6-403c-aa9d-2f8061256653">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-43fcfc81-54e6-403c-aa9d-2f8061256653">
											<gml:posList>35.66725651990305 139.73893219406762 30.64 35.66727902007914 139.738946107419 30.64 35.6672951690024 139.738906908836 30.64 35.66727266881319 139.738892984447 30.64 35.66725651990305 139.73893219406762 30.64</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-1ba9bcdb-7800-407f-a720-532fd35697e7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1ba9bcdb-7800-407f-a720-532fd35697e7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1ba9bcdb-7800-407f-a720-532fd35697e7">
											<gml:posList>35.66729271118244 139.73896813878787 28.345 35.66731243123597 139.73891959122042 28.345 35.66729450324255 139.73890851126592 28.345 35.66727902007914 139.738946107419 28.345 35.66725651990305 139.73893219406762 28.345 35.66727200306218 139.73889459792244 28.345 35.66725462515494 139.73888383766018 28.345 35.66724229965087 139.73891356545263 28.345 35.667234913857335 139.73890904536074 28.345 35.667232781692135 139.7389142615012 28.345 35.66729271118244 139.73896813878787 28.345</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-fb5e8e67-b7e6-4ac7-9650-161076eb5183">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fb5e8e67-b7e6-4ac7-9650-161076eb5183">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fb5e8e67-b7e6-4ac7-9650-161076eb5183">
											<gml:posList>35.66723092528875 139.73891480493256 28.487 35.66729325412676 139.73897084437826 28.487 35.66729271118244 139.73896813878787 28.487 35.667232781692135 139.7389142615012 28.487 35.66723092528875 139.73891480493256 28.487</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-26df9763-0127-4321-b785-e20ad0a7be30">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-26df9763-0127-4321-b785-e20ad0a7be30">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-26df9763-0127-4321-b785-e20ad0a7be30">
											<gml:posList>35.66731439560488 139.73891879360727 28.487 35.66731243123597 139.73891959122042 28.487 35.66729271118244 139.73896813878787 28.487 35.66729325412676 139.73897084437826 28.487 35.66731439560488 139.73891879360727 28.487</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e6e76343-1bb2-40be-9b31-4725ad04071d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e6e76343-1bb2-40be-9b31-4725ad04071d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e6e76343-1bb2-40be-9b31-4725ad04071d">
											<gml:posList>35.667234913857335 139.73890904536074 28.487 35.667234913857335 139.73890904536074 28.345 35.66724229965087 139.73891356545263 28.345 35.66724229965087 139.73891356545263 28.487 35.667234913857335 139.73890904536074 28.487</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4ce2b793-41e9-4c74-b869-1ef69aab67ac">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4ce2b793-41e9-4c74-b869-1ef69aab67ac">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4ce2b793-41e9-4c74-b869-1ef69aab67ac">
											<gml:posList>35.66729271118244 139.73896813878787 28.487 35.66729271118244 139.73896813878787 28.345 35.667232781692135 139.7389142615012 28.345 35.667232781692135 139.7389142615012 28.487 35.66729271118244 139.73896813878787 28.487</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-691cb9ee-5c8a-4f89-b8b0-88943a20011b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-691cb9ee-5c8a-4f89-b8b0-88943a20011b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-691cb9ee-5c8a-4f89-b8b0-88943a20011b">
											<gml:posList>35.66729450324255 139.73890851126592 28.487 35.66729450324255 139.73890851126592 28.345 35.66731243123597 139.73891959122042 28.345 35.66731243123597 139.73891959122042 28.487 35.66729450324255 139.73890851126592 28.487</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0d806137-d06e-48be-bebe-9c125eab3b2a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0d806137-d06e-48be-bebe-9c125eab3b2a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0d806137-d06e-48be-bebe-9c125eab3b2a">
											<gml:posList>35.66725462515494 139.73888383766018 28.487 35.66725462515494 139.73888383766018 28.345 35.66727200306218 139.73889459792244 28.345 35.66727200306218 139.73889459792244 28.487 35.66725462515494 139.73888383766018 28.487</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-50b49d8b-e956-4b39-a4e4-ec94c97ca28d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-50b49d8b-e956-4b39-a4e4-ec94c97ca28d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-50b49d8b-e956-4b39-a4e4-ec94c97ca28d">
											<gml:posList>35.66725397426921 139.73888141939037 12.06 35.66724164876574 139.73891114718296 12.06 35.66724164876574 139.73891114718296 28.487 35.66725397426921 139.73888141939037 28.487 35.66725397426921 139.73888141939037 12.06</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-36333fe8-9421-46d2-8112-842101ab438f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-36333fe8-9421-46d2-8112-842101ab438f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-36333fe8-9421-46d2-8112-842101ab438f">
											<gml:posList>35.66724229965087 139.73891356545263 28.487 35.66724229965087 139.73891356545263 28.345 35.66725462515494 139.73888383766018 28.345 35.66725462515494 139.73888383766018 28.487 35.66724229965087 139.73891356545263 28.487</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9f4d26ca-1628-4476-bc45-7c70c3ec2900">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9f4d26ca-1628-4476-bc45-7c70c3ec2900">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9f4d26ca-1628-4476-bc45-7c70c3ec2900">
											<gml:posList>35.66727266881319 139.738892984447 28.487 35.66727266881319 139.738892984447 30.64 35.6672951690024 139.738906908836 30.64 35.6672951690024 139.738906908836 28.487 35.66731439560488 139.73891879360727 28.487 35.66731439560488 139.73891879360727 12.06 35.66725397426921 139.73888141939037 12.06 35.66725397426921 139.73888141939037 28.487 35.66727266881319 139.738892984447 28.487</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-687d0ccf-856a-4c75-95a5-2337973f7bfc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-687d0ccf-856a-4c75-95a5-2337973f7bfc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-687d0ccf-856a-4c75-95a5-2337973f7bfc">
											<gml:posList>35.66724164876574 139.73891114718296 12.06 35.66723425395838 139.73890662710193 12.06 35.66723425395838 139.73890662710193 28.487 35.66724164876574 139.73891114718296 28.487 35.66724164876574 139.73891114718296 12.06</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5e45e4a7-d6ea-462e-9a94-91cccc2ae922">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5e45e4a7-d6ea-462e-9a94-91cccc2ae922">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5e45e4a7-d6ea-462e-9a94-91cccc2ae922">
											<gml:posList>35.66723425395838 139.73890662710193 12.06 35.66723092528875 139.73891480493256 12.06 35.66723092528875 139.73891480493256 28.487 35.66723425395838 139.73890662710193 28.487 35.66723425395838 139.73890662710193 12.06</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3e994f4a-3c0b-44dd-bcac-9e42932be539">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3e994f4a-3c0b-44dd-bcac-9e42932be539">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3e994f4a-3c0b-44dd-bcac-9e42932be539">
											<gml:posList>35.667232781692135 139.7389142615012 28.487 35.667232781692135 139.7389142615012 28.345 35.667234913857335 139.73890904536074 28.345 35.667234913857335 139.73890904536074 28.487 35.667232781692135 139.7389142615012 28.487</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ffc0a398-7f9d-4571-92d8-3f8be3a4f3ff">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ffc0a398-7f9d-4571-92d8-3f8be3a4f3ff">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ffc0a398-7f9d-4571-92d8-3f8be3a4f3ff">
											<gml:posList>35.66725651990305 139.73893219406762 28.345 35.66725651990305 139.73893219406762 30.64 35.66727266881319 139.738892984447 30.64 35.66727266881319 139.738892984447 28.487 35.66727200306218 139.73889459792244 28.487 35.66727200306218 139.73889459792244 28.345 35.66725651990305 139.73893219406762 28.345</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9558a525-9faa-410a-9969-ecbd937a6e67">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9558a525-9faa-410a-9969-ecbd937a6e67">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9558a525-9faa-410a-9969-ecbd937a6e67">
											<gml:posList>35.6672951690024 139.738906908836 30.64 35.66727902007914 139.738946107419 30.64 35.66727902007914 139.738946107419 28.345 35.66729450324255 139.73890851126592 28.345 35.66729450324255 139.73890851126592 28.487 35.6672951690024 139.738906908836 28.487 35.6672951690024 139.738906908836 30.64</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ecda35e6-2a92-46fd-931e-fe129a7b5273">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ecda35e6-2a92-46fd-931e-fe129a7b5273">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ecda35e6-2a92-46fd-931e-fe129a7b5273">
											<gml:posList>35.66725651990305 139.73893219406762 28.345 35.66727902007914 139.738946107419 28.345 35.66727902007914 139.738946107419 30.64 35.66725651990305 139.73893219406762 30.64 35.66725651990305 139.73893219406762 28.345</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-388c6051-3be1-4087-964c-77190be9c51f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-388c6051-3be1-4087-964c-77190be9c51f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-388c6051-3be1-4087-964c-77190be9c51f">
											<gml:posList>35.66723092528875 139.73891480493256 12.06 35.66729325412676 139.73897084437826 12.06 35.66729325412676 139.73897084437826 28.487 35.66723092528875 139.73891480493256 28.487 35.66723092528875 139.73891480493256 12.06</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-81fa9b79-8fce-4d87-aa5f-bd14d3a5dd26">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-81fa9b79-8fce-4d87-aa5f-bd14d3a5dd26">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-81fa9b79-8fce-4d87-aa5f-bd14d3a5dd26">
											<gml:posList>35.66731243123597 139.73891959122042 28.487 35.66731243123597 139.73891959122042 28.345 35.66729271118244 139.73896813878787 28.345 35.66729271118244 139.73896813878787 28.487 35.66731243123597 139.73891959122042 28.487</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-72f4de3b-3f14-49e1-94c2-1f3c49abbe48">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-72f4de3b-3f14-49e1-94c2-1f3c49abbe48">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-72f4de3b-3f14-49e1-94c2-1f3c49abbe48">
											<gml:posList>35.66729325412676 139.73897084437826 12.06 35.66731439560488 139.73891879360727 12.06 35.66731439560488 139.73891879360727 28.487 35.66729325412676 139.73897084437826 28.487 35.66729325412676 139.73897084437826 12.06</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区六本木二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-2802</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">35.703</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1210</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>7</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.03</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>