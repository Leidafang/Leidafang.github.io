<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_ffaae9ea-707a-4aed-9788-e1408fb811cb">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>3</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001003</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">402</bldg:usage>
			<bldg:measuredHeight uom="m">16.5</bldg:measuredHeight>
			<bldg:storeysAboveGround>5</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.674621934120225 139.737946262413 0 35.6746076889291 139.7378963365919 0 35.67461046409408 139.73789499662016 0 35.674626899087045 139.737887376825 0 35.67458945894767 139.7377659945459 0 35.674499896098915 139.7378083001948 0 35.67455222070859 139.73797880096217 0 35.674621934120225 139.737946262413 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.674621934120225 139.737946262413 8.35 35.67455222070859 139.73797880096217 8.35 35.674499896098915 139.7378083001948 8.35 35.67458945894767 139.7377659945459 8.35 35.674626899087045 139.737887376825 8.35 35.67461046409408 139.73789499662016 8.35 35.6746076889291 139.7378963365919 8.35 35.674621934120225 139.737946262413 8.35</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.674621934120225 139.737946262413 8.35 35.6746076889291 139.7378963365919 8.35 35.6746076889291 139.7378963365919 24.54 35.674621934120225 139.737946262413 24.54 35.674621934120225 139.737946262413 8.35</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6746076889291 139.7378963365919 8.35 35.67461046409408 139.73789499662016 8.35 35.67461046409408 139.73789499662016 24.54 35.6746076889291 139.7378963365919 24.54 35.6746076889291 139.7378963365919 8.35</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67461046409408 139.73789499662016 8.35 35.674626899087045 139.737887376825 8.35 35.674626899087045 139.737887376825 24.54 35.67461046409408 139.73789499662016 24.54 35.67461046409408 139.73789499662016 8.35</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.674626899087045 139.737887376825 8.35 35.67458945894767 139.7377659945459 8.35 35.67458945894767 139.7377659945459 24.54 35.674626899087045 139.737887376825 24.54 35.674626899087045 139.737887376825 8.35</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67458945894767 139.7377659945459 8.35 35.674499896098915 139.7378083001948 8.35 35.674499896098915 139.7378083001948 24.54 35.67458945894767 139.7377659945459 24.54 35.67458945894767 139.7377659945459 8.35</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.674499896098915 139.7378083001948 8.35 35.67455222070859 139.73797880096217 8.35 35.67455222070859 139.73797880096217 24.54 35.674499896098915 139.7378083001948 24.54 35.674499896098915 139.7378083001948 8.35</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67455222070859 139.73797880096217 8.35 35.674621934120225 139.737946262413 8.35 35.674621934120225 139.737946262413 24.54 35.67455222070859 139.73797880096217 24.54 35.67455222070859 139.73797880096217 8.35</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.674621934120225 139.737946262413 24.54 35.6746076889291 139.7378963365919 24.54 35.67461046409408 139.73789499662016 24.54 35.674626899087045 139.737887376825 24.54 35.67458945894767 139.7377659945459 24.54 35.674499896098915 139.7378083001948 24.54 35.67455222070859 139.73797880096217 24.54 35.674621934120225 139.737946262413 24.54</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-44d1d8f7-4c69-469b-8b4f-da0d3dd57818"/>
							<gml:surfaceMember xlink:href="#poly-15c54351-3193-4664-9bda-abb74a642ced"/>
							<gml:surfaceMember xlink:href="#poly-3bfe2793-90d9-4e11-8739-8231ede5b7d1"/>
							<gml:surfaceMember xlink:href="#poly-74c1b4a6-fad4-483c-96f1-379475f96684"/>
							<gml:surfaceMember xlink:href="#poly-8c5a6e51-cb01-402d-ad86-cc496837bf3b"/>
							<gml:surfaceMember xlink:href="#poly-00e29f31-370d-48bf-a369-2b9733c8e1f2"/>
							<gml:surfaceMember xlink:href="#poly-1df11f95-7656-4cfa-91ee-269d8ab2b012"/>
							<gml:surfaceMember xlink:href="#poly-5383c3c6-5399-4f7f-9249-1e0fd3a34d74"/>
							<gml:surfaceMember xlink:href="#poly-9bb879b6-833b-4a73-9743-cdddb4f4db9c"/>
							<gml:surfaceMember xlink:href="#poly-6da35a3d-b704-452b-ba6c-2f8a4ca1065e"/>
							<gml:surfaceMember xlink:href="#poly-21706f3e-309b-469b-b2de-56b2b3096e9d"/>
							<gml:surfaceMember xlink:href="#poly-33ab3b8d-3edb-4869-a1a6-0c2b6f81915a"/>
							<gml:surfaceMember xlink:href="#poly-ba77e541-f8e9-425e-b903-531e64e6ed9a"/>
							<gml:surfaceMember xlink:href="#poly-262e74a7-a0ea-469b-b528-97cac95efef5"/>
							<gml:surfaceMember xlink:href="#poly-0b4bf8b1-d5ee-4524-bf46-146204999c03"/>
							<gml:surfaceMember xlink:href="#poly-66a7891c-afc2-4394-a2f5-7e958c1c2b6d"/>
							<gml:surfaceMember xlink:href="#poly-045fceb2-c948-42c2-8daa-8e7afaf5bbd9"/>
							<gml:surfaceMember xlink:href="#poly-56faacc0-ea92-4d7c-974a-3f90438898b0"/>
							<gml:surfaceMember xlink:href="#poly-7fee8ac0-1482-4c8c-adc7-b71595454a7b"/>
							<gml:surfaceMember xlink:href="#poly-96344758-2252-487f-b070-aa408601fda3"/>
							<gml:surfaceMember xlink:href="#poly-9a88b8d8-8881-4f03-af1e-43a7a5d7577b"/>
							<gml:surfaceMember xlink:href="#poly-a97019dd-4c27-4ec9-9674-3fc0819d0d3e"/>
							<gml:surfaceMember xlink:href="#poly-d578f591-a1a5-4428-a0e0-96b0715e333a"/>
							<gml:surfaceMember xlink:href="#poly-efc1ac79-2c32-4888-85c1-ce28d7fc37d3"/>
							<gml:surfaceMember xlink:href="#poly-9d5cea37-eaf4-465b-95e1-53d7a000e98f"/>
							<gml:surfaceMember xlink:href="#poly-15232518-9a10-47f8-81f3-e74fd3cd5094"/>
							<gml:surfaceMember xlink:href="#poly-6e3ba8fa-4874-4e94-921f-5f25a6bef59a"/>
							<gml:surfaceMember xlink:href="#poly-738d85e6-285e-4978-adee-e12e59d3b96d"/>
							<gml:surfaceMember xlink:href="#poly-12285c59-9acc-4b35-acd1-759f94b8ec6f"/>
							<gml:surfaceMember xlink:href="#poly-7b20d736-c92f-473f-8e6e-888896807328"/>
							<gml:surfaceMember xlink:href="#poly-69d8397d-0901-4cc7-aeba-b618539db8f3"/>
							<gml:surfaceMember xlink:href="#poly-16e3d910-bb1a-4682-8135-c5daff949209"/>
							<gml:surfaceMember xlink:href="#poly-208cd5ac-4245-48e0-b977-5ff116549a12"/>
							<gml:surfaceMember xlink:href="#poly-0e30b4a0-c1a5-4761-90b0-4d929fb7311e"/>
							<gml:surfaceMember xlink:href="#poly-b5cb3241-49b9-4375-8fd8-ca99b44d3d84"/>
							<gml:surfaceMember xlink:href="#poly-ab96ca8f-b3b0-4b5d-8a45-5d0479883ae7"/>
							<gml:surfaceMember xlink:href="#poly-3876a72b-ac9b-466e-846f-c18c981a6c39"/>
							<gml:surfaceMember xlink:href="#poly-7a5c5adb-7deb-4d16-a08f-d0d0c9bc05f8"/>
							<gml:surfaceMember xlink:href="#poly-0f5a7435-b826-46e1-94be-6253b2c13ab3"/>
							<gml:surfaceMember xlink:href="#poly-2665120d-1e86-4739-8ec2-317c99c20b2c"/>
							<gml:surfaceMember xlink:href="#poly-913a9cce-0d86-4027-bedc-b6eb8311431e"/>
							<gml:surfaceMember xlink:href="#poly-442b127c-2954-4a8e-a00e-60e90064f72c"/>
							<gml:surfaceMember xlink:href="#poly-71e2e573-043a-4772-9a67-ad8e9e8b9aad"/>
							<gml:surfaceMember xlink:href="#poly-9fb42a9c-7730-408b-b43e-7bdf97b31716"/>
							<gml:surfaceMember xlink:href="#poly-98848e05-511d-4c87-b780-6b25ea1eb8fb"/>
							<gml:surfaceMember xlink:href="#poly-c37b0895-0517-4697-8135-f50a18f2fc74"/>
							<gml:surfaceMember xlink:href="#poly-1b1efef6-23f3-468e-87dc-232e5b0610d5"/>
							<gml:surfaceMember xlink:href="#poly-b404c451-d35c-408a-949c-b4a6abef3a6d"/>
							<gml:surfaceMember xlink:href="#poly-5c33e150-68b7-4faa-bc43-490a83f56b0e"/>
							<gml:surfaceMember xlink:href="#poly-113d6d2a-16e5-43f9-8acc-a4c4f15be748"/>
							<gml:surfaceMember xlink:href="#poly-43164960-cd99-4962-9eed-86fb0d601385"/>
							<gml:surfaceMember xlink:href="#poly-51dd511b-f689-481e-8c4d-365f1cfa708f"/>
							<gml:surfaceMember xlink:href="#poly-1b58fffa-9010-4235-9b1b-a62979490830"/>
							<gml:surfaceMember xlink:href="#poly-36ed177e-d9ba-47df-b827-dc5e7ee49b77"/>
							<gml:surfaceMember xlink:href="#poly-b2ff56f6-4978-48eb-9440-e0dc793f59fc"/>
							<gml:surfaceMember xlink:href="#poly-d62027d0-95cf-453b-9b64-eecea001ae85"/>
							<gml:surfaceMember xlink:href="#poly-4222e464-9f15-46b1-b330-277afb729aee"/>
							<gml:surfaceMember xlink:href="#poly-1d846e46-ad57-4729-9898-713f03f4068d"/>
							<gml:surfaceMember xlink:href="#poly-df3b395d-bb37-4fdd-ab03-ccdb4e940907"/>
							<gml:surfaceMember xlink:href="#poly-7ba33695-382c-4cbb-9fea-c4454c8763b8"/>
							<gml:surfaceMember xlink:href="#poly-153e60cf-4dff-41e9-8ba2-a63d2842f74c"/>
							<gml:surfaceMember xlink:href="#poly-f2177dd6-d4e8-41c2-acd4-9c8ed75b4e4e"/>
							<gml:surfaceMember xlink:href="#poly-4cd13ddf-fcee-49bc-a019-b0973220f405"/>
							<gml:surfaceMember xlink:href="#poly-f493bf4c-bec0-4f77-bc5a-ba837c03ed76"/>
							<gml:surfaceMember xlink:href="#poly-6f8fa6f9-6412-483d-b975-f7a4654ec4cf"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_ffaae9ea-707a-4aed-9788-e1408fb811cb_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ad193618-df9c-489c-abcc-010246d612fb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ad193618-df9c-489c-abcc-010246d612fb_0">
											<gml:posList>35.67456601588165 139.73790442830042 29.321 35.674550933203456 139.73785551982778 26.07 35.67456601588165 139.73790442830042 26.07 35.67456601588165 139.73790442830042 29.321</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3de78c23-206d-466f-ab4e-bc8571e030f7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3de78c23-206d-466f-ab4e-bc8571e030f7_0">
											<gml:posList>35.67456601588165 139.73790442830042 29.321 35.674550933203456 139.73785551982778 29.321 35.674550933203456 139.73785551982778 26.07 35.67456601588165 139.73790442830042 29.321</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0533eed4-f2a1-4326-b3f9-b8d6663cdc77">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0533eed4-f2a1-4326-b3f9-b8d6663cdc77_0">
											<gml:posList>35.674577567988294 139.73784318192835 29.321 35.674550933203456 139.73785551982778 26.07 35.674550933203456 139.73785551982778 29.321 35.674577567988294 139.73784318192835 29.321</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-08bc9ac6-9d1a-4832-908b-74fea9c72a3c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-08bc9ac6-9d1a-4832-908b-74fea9c72a3c_0">
											<gml:posList>35.674577567988294 139.73784318192835 29.321 35.674577567988294 139.73784318192835 26.07 35.674550933203456 139.73785551982778 26.07 35.674577567988294 139.73784318192835 29.321</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ee12781f-ce01-4220-b138-cd694c775e50">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ee12781f-ce01-4220-b138-cd694c775e50_0">
											<gml:posList>35.674550933203456 139.73785551982778 29.321 35.67456601588165 139.73790442830042 29.321 35.67459265067146 139.73789209041493 29.321 35.674550933203456 139.73785551982778 29.321</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fc9ee665-7b4f-4647-95d2-530595228a6e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fc9ee665-7b4f-4647-95d2-530595228a6e_0">
											<gml:posList>35.674577567988294 139.73784318192835 29.321 35.674550933203456 139.73785551982778 29.321 35.67459265067146 139.73789209041493 29.321 35.674577567988294 139.73784318192835 29.321</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f7937183-1488-4b5e-b1ca-63e6ed9b3b1f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f7937183-1488-4b5e-b1ca-63e6ed9b3b1f_0">
											<gml:posList>35.67459265067146 139.73789209041493 26.07 35.67459265067146 139.73789209041493 28.136 35.67456601588165 139.73790442830042 26.07 35.67459265067146 139.73789209041493 26.07</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-99e29b63-00ec-4ad2-b651-99a5ffc7b4f4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-99e29b63-00ec-4ad2-b651-99a5ffc7b4f4_0">
											<gml:posList>35.67456601588165 139.73790442830042 26.07 35.67459265067146 139.73789209041493 28.136 35.67456601588165 139.73790442830042 29.321 35.67456601588165 139.73790442830042 26.07</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-38201c75-36bb-4d00-9563-9590a93b3dd8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-38201c75-36bb-4d00-9563-9590a93b3dd8_0">
											<gml:posList>35.67459265067146 139.73789209041493 28.136 35.67459265067146 139.73789209041493 29.321 35.67456601588165 139.73790442830042 29.321 35.67459265067146 139.73789209041493 28.136</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1af99f7e-a2b3-49f3-a63e-6e013bf544ae">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1af99f7e-a2b3-49f3-a63e-6e013bf544ae_0">
											<gml:posList>35.6745876622713 139.7378759127349 26.07 35.674577567988294 139.73784318192835 26.07 35.6745876622713 139.7378759127349 28.136 35.6745876622713 139.7378759127349 26.07</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-78b72df3-01e3-42c9-9b59-d97d4d6fc5b6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-78b72df3-01e3-42c9-9b59-d97d4d6fc5b6_0">
											<gml:posList>35.67459265067146 139.73789209041493 28.136 35.6745876622713 139.7378759127349 28.136 35.67459265067146 139.73789209041493 29.321 35.67459265067146 139.73789209041493 28.136</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1703a061-a4d2-4193-83ec-035cc7407e62">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1703a061-a4d2-4193-83ec-035cc7407e62_0">
											<gml:posList>35.67459265067146 139.73789209041493 29.321 35.6745876622713 139.7378759127349 28.136 35.674577567988294 139.73784318192835 29.321 35.67459265067146 139.73789209041493 29.321</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7297f10e-aa64-462e-9191-a9b9178a5e8a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7297f10e-aa64-462e-9191-a9b9178a5e8a_0">
											<gml:posList>35.6745876622713 139.7378759127349 28.136 35.674577567988294 139.73784318192835 26.07 35.674577567988294 139.73784318192835 29.321 35.6745876622713 139.7378759127349 28.136</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1128ae21-147d-4f25-b354-97e848fcc2ba">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1128ae21-147d-4f25-b354-97e848fcc2ba_0">
											<gml:posList>35.674590547966794 139.73786618808015 33.183 35.67458540594455 139.73784952452422 30.455 35.674590547966794 139.73786618808015 30.455 35.674590547966794 139.73786618808015 33.183</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2c897800-4aaa-4eca-b2a5-744988ea0313">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2c897800-4aaa-4eca-b2a5-744988ea0313_0">
											<gml:posList>35.674590547966794 139.73786618808015 33.183 35.67458540594455 139.73784952452422 33.183 35.67458540594455 139.73784952452422 30.455 35.674590547966794 139.73786618808015 33.183</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-aa6f612e-de30-4465-8634-f2f60de058f1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-aa6f612e-de30-4465-8634-f2f60de058f1_0">
											<gml:posList>35.67459388846304 139.7378730220958 26.07 35.6745876622713 139.7378759127349 28.136 35.674593897476754 139.73787302208507 28.136 35.67459388846304 139.7378730220958 26.07</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b7ecc8c9-af23-47d7-a41f-c5e379de8970">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b7ecc8c9-af23-47d7-a41f-c5e379de8970_0">
											<gml:posList>35.67459388846304 139.7378730220958 26.07 35.6745876622713 139.7378759127349 26.07 35.6745876622713 139.7378759127349 28.136 35.67459388846304 139.7378730220958 26.07</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d50730cf-aa56-4d33-a7e2-ca278d151ed0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d50730cf-aa56-4d33-a7e2-ca278d151ed0_0">
											<gml:posList>35.67459289468974 139.73789290759055 28.136 35.67459265067146 139.73789209041493 26.07 35.67459289468974 139.73789290759055 26.07 35.67459289468974 139.73789290759055 28.136</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f91d0b4d-73b6-46c8-a7ce-87ba8fd3836e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f91d0b4d-73b6-46c8-a7ce-87ba8fd3836e_0">
											<gml:posList>35.67459289468974 139.73789290759055 28.136 35.67459265067146 139.73789209041493 28.136 35.67459265067146 139.73789209041493 26.07 35.67459289468974 139.73789290759055 28.136</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-959c0adb-3997-4703-81c3-206440472244">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-959c0adb-3997-4703-81c3-206440472244_0">
											<gml:posList>35.67458540594455 139.73784952452422 33.183 35.674604246720705 139.73784079717228 30.455 35.67458540594455 139.73784952452422 30.455 35.67458540594455 139.73784952452422 33.183</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d56202c5-4709-4f48-a600-537ce0ab752e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d56202c5-4709-4f48-a600-537ce0ab752e_0">
											<gml:posList>35.67458540594455 139.73784952452422 33.183 35.674604246720705 139.73784079717228 33.183 35.674604246720705 139.73784079717228 30.455 35.67458540594455 139.73784952452422 33.183</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-21c815f8-ec15-40ed-a17c-06695222d91a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-21c815f8-ec15-40ed-a17c-06695222d91a_0">
											<gml:posList>35.674604246720705 139.73784079717228 33.183 35.674590547966794 139.73786618808015 33.183 35.67460938874415 139.73785746073156 33.183 35.674604246720705 139.73784079717228 33.183</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6fae3d93-21be-48fc-80df-12cde0f58b11">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6fae3d93-21be-48fc-80df-12cde0f58b11_0">
											<gml:posList>35.674604246720705 139.73784079717228 33.183 35.67458540594455 139.73784952452422 33.183 35.674590547966794 139.73786618808015 33.183 35.674604246720705 139.73784079717228 33.183</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3b776d1f-3460-4a7c-bb40-3088167bc1dc">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3b776d1f-3460-4a7c-bb40-3088167bc1dc_0">
											<gml:posList>35.67460245737121 139.7378690571229 26.07 35.674593897476754 139.73787302208507 28.136 35.67460245737121 139.7378690571229 28.136 35.67460245737121 139.7378690571229 26.07</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0c1b770f-6bf1-4dbf-b5e3-8db2edcb3c8b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0c1b770f-6bf1-4dbf-b5e3-8db2edcb3c8b_0">
											<gml:posList>35.67460245737121 139.7378690571229 26.07 35.67459388846304 139.7378730220958 26.07 35.674593897476754 139.73787302208507 28.136 35.67460245737121 139.7378690571229 26.07</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1d85bbd1-54a5-4ae1-9cd1-6dd52d642b63">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1d85bbd1-54a5-4ae1-9cd1-6dd52d642b63_0">
											<gml:posList>35.674590547966794 139.73786618808015 33.183 35.67460938874415 139.73785746073156 30.455 35.67460938874415 139.73785746073156 33.183 35.674590547966794 139.73786618808015 33.183</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-35974e12-dec9-44a4-b648-8a0751d10425">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-35974e12-dec9-44a4-b648-8a0751d10425_0">
											<gml:posList>35.674590547966794 139.73786618808015 33.183 35.674590547966794 139.73786618808015 30.455 35.67460938874415 139.73785746073156 30.455 35.674590547966794 139.73786618808015 33.183</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1e302b35-abcf-4502-be2f-ae2e3a2fb4ef">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1e302b35-abcf-4502-be2f-ae2e3a2fb4ef_0">
											<gml:posList>35.67459289468974 139.73789290759055 28.136 35.67459289468974 139.73789290759055 26.07 35.67460769880434 139.73788605197052 26.07 35.67459289468974 139.73789290759055 28.136</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-48ad9204-8955-41f1-bfc4-6fb07f214082">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-48ad9204-8955-41f1-bfc4-6fb07f214082_0">
											<gml:posList>35.674607698795576 139.73788604092368 28.136 35.67459289468974 139.73789290759055 28.136 35.67460769880434 139.73788605197052 26.07 35.674607698795576 139.73788604092368 28.136</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-91105a35-31b4-499e-85f4-1e353ce29092">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-91105a35-31b4-499e-85f4-1e353ce29092_0">
											<gml:posList>35.67460245737121 139.7378690571229 26.07 35.67460245737121 139.7378690571229 28.136 35.674607698795576 139.73788604092368 28.136 35.67460245737121 139.7378690571229 26.07</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3f9c41ef-3016-471e-a9fd-407a80de6006">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3f9c41ef-3016-471e-a9fd-407a80de6006_0">
											<gml:posList>35.67460769880434 139.73788605197052 26.07 35.67460245737121 139.7378690571229 26.07 35.674607698795576 139.73788604092368 28.136 35.67460769880434 139.73788605197052 26.07</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bfe203c2-9c3d-45c3-9741-665b55d562c7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bfe203c2-9c3d-45c3-9741-665b55d562c7_0">
											<gml:posList>35.674604246720705 139.73784079717228 33.183 35.67460938874415 139.73785746073156 30.455 35.674604246720705 139.73784079717228 30.455 35.674604246720705 139.73784079717228 33.183</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-62a36149-bc64-4ffb-a8a3-46a1c58f8c5b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-62a36149-bc64-4ffb-a8a3-46a1c58f8c5b_0">
											<gml:posList>35.674604246720705 139.73784079717228 33.183 35.67460938874415 139.73785746073156 33.183 35.67460938874415 139.73785746073156 30.455 35.674604246720705 139.73784079717228 33.183</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-01e54173-26a0-46ef-8e6a-6f443faa1c7a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-01e54173-26a0-46ef-8e6a-6f443faa1c7a_0">
											<gml:posList>35.67459289468974 139.73789290759055 28.136 35.674607698795576 139.73788604092368 28.136 35.67459265067146 139.73789209041493 28.136 35.67459289468974 139.73789290759055 28.136</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c352c052-0221-4e7a-90b1-9f7fdedc2406">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c352c052-0221-4e7a-90b1-9f7fdedc2406_0">
											<gml:posList>35.674607698795576 139.73788604092368 28.136 35.67460245737121 139.7378690571229 28.136 35.674593897476754 139.73787302208507 28.136 35.674607698795576 139.73788604092368 28.136</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1fba5e88-6fb7-4373-bee4-990fcc2374d7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1fba5e88-6fb7-4373-bee4-990fcc2374d7_0">
											<gml:posList>35.67459265067146 139.73789209041493 28.136 35.674593897476754 139.73787302208507 28.136 35.6745876622713 139.7378759127349 28.136 35.67459265067146 139.73789209041493 28.136</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8fd209c1-8b99-412d-b56e-930c39ad5482">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8fd209c1-8b99-412d-b56e-930c39ad5482_0">
											<gml:posList>35.67459265067146 139.73789209041493 28.136 35.674607698795576 139.73788604092368 28.136 35.674593897476754 139.73787302208507 28.136 35.67459265067146 139.73789209041493 28.136</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a4ce54b0-6604-4e23-b37e-41827a58e3f4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.674604246720705 139.73784079717228 30.455 35.674590547966794 139.73786618808015 30.455 35.67458540594455 139.73784952452422 30.455 35.674604246720705 139.73784079717228 30.455</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d06118f7-65eb-4f07-80ed-b779f3e5db35">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.674604246720705 139.73784079717228 30.455 35.67460938874415 139.73785746073156 30.455 35.674590547966794 139.73786618808015 30.455 35.674604246720705 139.73784079717228 30.455</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4924cb95-1f15-49a3-89ee-f11dbda46d41">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.674577567988294 139.73784318192835 26.07 35.6745876622713 139.7378759127349 26.07 35.674550933203456 139.73785551982778 26.07 35.674577567988294 139.73784318192835 26.07</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e2dc13ac-ea77-4b11-899d-f0cf1a83aaab">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.674550933203456 139.73785551982778 26.07 35.6745876622713 139.7378759127349 26.07 35.67456601588165 139.73790442830042 26.07 35.674550933203456 139.73785551982778 26.07</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-dbfa6101-87fd-41f1-b59d-460fd20df245">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67460769880434 139.73788605197052 26.07 35.67459388846304 139.7378730220958 26.07 35.67460245737121 139.7378690571229 26.07 35.67460769880434 139.73788605197052 26.07</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d7c8ebc6-85b9-473f-a10f-95ec919ca519">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67456601588165 139.73790442830042 26.07 35.6745876622713 139.7378759127349 26.07 35.67459265067146 139.73789209041493 26.07 35.67456601588165 139.73790442830042 26.07</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-edde0101-2326-4ecf-b014-8526973a5a14">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67460769880434 139.73788605197052 26.07 35.67459289468974 139.73789290759055 26.07 35.67459265067146 139.73789209041493 26.07 35.67460769880434 139.73788605197052 26.07</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9bc54390-3a22-4a8d-b457-87fbc8ee306d">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67459265067146 139.73789209041493 26.07 35.6745876622713 139.7378759127349 26.07 35.67459388846304 139.7378730220958 26.07 35.67459265067146 139.73789209041493 26.07</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8dde9f09-6699-447e-a584-6c673fb545f1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67460769880434 139.73788605197052 26.07 35.67459265067146 139.73789209041493 26.07 35.67459388846304 139.7378730220958 26.07 35.67460769880434 139.73788605197052 26.07</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_ffaae9ea-707a-4aed-9788-e1408fb811cb_BuildingInstallation_1060">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2c5df953-2ae9-4cee-921a-ceee59b62a34">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6746219341202 139.737946262413 8.36 35.67460767991538 139.7378963366026 8.36 35.67461045508035 139.73789499663087 8.36 35.67462689008208 139.73788738788252 8.36 35.67464214442793 139.73793682645186 8.36 35.6746219341202 139.737946262413 8.36</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-13e27eb7-5957-4835-be11-93f9f67ad276">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-13e27eb7-5957-4835-be11-93f9f67ad276_0">
											<gml:posList>35.67460767991538 139.7378963366026 23.082 35.67461045508035 139.73789499663087 23.082 35.67461045508035 139.73789499663087 8.36 35.67460767991538 139.7378963366026 8.36 35.67460767991538 139.7378963366026 23.082</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-deb3aaab-2073-41ca-bde2-460420677b9e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-deb3aaab-2073-41ca-bde2-460420677b9e_0">
											<gml:posList>35.6746219341202 139.737946262413 23.082 35.67460767991538 139.7378963366026 23.082 35.67460767991538 139.7378963366026 8.36 35.6746219341202 139.737946262413 8.36 35.6746219341202 139.737946262413 23.082</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f34dbb64-6aa9-4c3f-9a6f-9adaef5d62fd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f34dbb64-6aa9-4c3f-9a6f-9adaef5d62fd_0">
											<gml:posList>35.67461045508035 139.73789499663087 23.082 35.67462689008208 139.73788738788252 23.082 35.67462689008208 139.73788738788252 8.36 35.67461045508035 139.73789499663087 8.36 35.67461045508035 139.73789499663087 23.082</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a0fb7b96-31dc-4a3c-8181-f6fe9a87d942">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a0fb7b96-31dc-4a3c-8181-f6fe9a87d942_0">
											<gml:posList>35.67461045508035 139.73789499663087 23.082 35.67460767991538 139.7378963366026 23.082 35.6746219341202 139.737946262413 23.082 35.67464214442793 139.73793682645186 23.082 35.67462689008208 139.73788738788252 23.082 35.67461045508035 139.73789499663087 23.082</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fcb8f925-36bd-415e-b849-4a1b33b69e91">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fcb8f925-36bd-415e-b849-4a1b33b69e91_0">
											<gml:posList>35.67464214442793 139.73793682645186 23.082 35.6746219341202 139.737946262413 23.082 35.6746219341202 139.737946262413 8.36 35.67464214442793 139.73793682645186 8.36 35.67464214442793 139.73793682645186 23.082</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8da6c2c3-2e04-460e-a94c-5b38b8e7e87e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8da6c2c3-2e04-460e-a94c-5b38b8e7e87e_0">
											<gml:posList>35.67462689008208 139.73788738788252 23.082 35.67464214442793 139.73793682645186 23.082 35.67464214442793 139.73793682645186 8.36 35.67462689008208 139.73788738788252 8.36 35.67462689008208 139.73788738788252 23.082</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_ffaae9ea-707a-4aed-9788-e1408fb811cb_BuildingInstallation_1041">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-26eac6bf-4eb2-447b-9f7d-8b25aa0d5e91">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.674543593594585 139.73792067174261 26.07 35.67453218018623 139.73788398775338 26.07 35.67454982252621 139.7378757479031 26.07 35.6745612359283 139.7379124208524 26.07 35.674543593594585 139.73792067174261 26.07</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8e3fb49b-c545-4637-90e7-e1f279b1bb7d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8e3fb49b-c545-4637-90e7-e1f279b1bb7d_0">
											<gml:posList>35.67453218018623 139.73788398775338 28.939 35.67453218018623 139.73788398775338 26.07 35.674543593594585 139.73792067174261 26.07 35.674543593594585 139.73792067174261 28.939 35.67453218018623 139.73788398775338 28.939</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ceaa61fd-6d9f-4576-b341-e7d5764ab92b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ceaa61fd-6d9f-4576-b341-e7d5764ab92b_0">
											<gml:posList>35.67454982252621 139.7378757479031 26.07 35.67453218018623 139.73788398775338 26.07 35.67453218018623 139.73788398775338 28.939 35.67454982252621 139.7378757479031 28.939 35.67454982252621 139.7378757479031 26.07</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e8b28530-3087-420a-96f2-3b35d2628881">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e8b28530-3087-420a-96f2-3b35d2628881_0">
											<gml:posList>35.67454982252621 139.7378757479031 28.939 35.67453218018623 139.73788398775338 28.939 35.674543593594585 139.73792067174261 28.939 35.6745612359283 139.7379124208524 28.939 35.67454982252621 139.7378757479031 28.939</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3f0d62f9-e91c-4335-9226-c482e04aecb1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3f0d62f9-e91c-4335-9226-c482e04aecb1_0">
											<gml:posList>35.674543593594585 139.73792067174261 28.939 35.674543593594585 139.73792067174261 26.07 35.6745612359283 139.7379124208524 26.07 35.6745612359283 139.7379124208524 28.939 35.674543593594585 139.73792067174261 28.939</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1ea076fb-6608-44fd-9f4d-3f5d903b5926">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1ea076fb-6608-44fd-9f4d-3f5d903b5926_0">
											<gml:posList>35.6745612359283 139.7379124208524 26.07 35.67454982252621 139.7378757479031 26.07 35.67454982252621 139.7378757479031 28.939 35.6745612359283 139.7379124208524 28.939 35.6745612359283 139.7379124208524 26.07</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-44d1d8f7-4c69-469b-8b4f-da0d3dd57818">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-44d1d8f7-4c69-469b-8b4f-da0d3dd57818">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-44d1d8f7-4c69-469b-8b4f-da0d3dd57818">
											<gml:posList>35.67458945894767 139.7377659945459 8.35 35.67462689908705 139.73788737682497 8.35 35.674610464094066 139.73789499662013 8.35 35.6746076889291 139.7378963365919 8.35 35.6746219341202 139.737946262413 8.35 35.67455222070859 139.73797880096217 8.35 35.67449989609891 139.7378083001948 8.35 35.67458945894767 139.7377659945459 8.35</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-15c54351-3193-4664-9bda-abb74a642ced">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-15c54351-3193-4664-9bda-abb74a642ced">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-15c54351-3193-4664-9bda-abb74a642ced">
											<gml:posList>35.674539116913245 139.73793601007392 25.905 35.6746219341202 139.737946262413 20.716 35.674593422847906 139.73791104587255 25.905 35.674539116913245 139.73793601007392 25.905</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-3bfe2793-90d9-4e11-8739-8231ede5b7d1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3bfe2793-90d9-4e11-8739-8231ede5b7d1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3bfe2793-90d9-4e11-8739-8231ede5b7d1">
											<gml:posList>35.674539116913245 139.73793601007392 25.905 35.67455222070859 139.73797880096217 20.716 35.6746219341202 139.737946262413 20.716 35.674539116913245 139.73793601007392 25.905</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-74c1b4a6-fad4-483c-96f1-379475f96684">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-74c1b4a6-fad4-483c-96f1-379475f96684">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-74c1b4a6-fad4-483c-96f1-379475f96684">
											<gml:posList>35.6746219341202 139.737946262413 20.716 35.674591326255346 139.73790422142142 26.714 35.674593422847906 139.73791104587255 25.905 35.6746219341202 139.737946262413 20.716</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-8c5a6e51-cb01-402d-ad86-cc496837bf3b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8c5a6e51-cb01-402d-ad86-cc496837bf3b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8c5a6e51-cb01-402d-ad86-cc496837bf3b">
											<gml:posList>35.6746219341202 139.737946262413 20.716 35.6746076889291 139.7378963365919 26.714 35.674591326255346 139.73790422142142 26.714 35.6746219341202 139.737946262413 20.716</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-00e29f31-370d-48bf-a369-2b9733c8e1f2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-00e29f31-370d-48bf-a369-2b9733c8e1f2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-00e29f31-370d-48bf-a369-2b9733c8e1f2">
											<gml:posList>35.674539116913245 139.73793601007392 26.789 35.67454144651168 139.73792975479444 26.789 35.67451701042124 139.73785030193955 26.789 35.67451192451297 139.73784756838378 26.789 35.674539116913245 139.73793601007392 26.789</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-1df11f95-7656-4cfa-91ee-269d8ab2b012">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1df11f95-7656-4cfa-91ee-269d8ab2b012">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1df11f95-7656-4cfa-91ee-269d8ab2b012">
											<gml:posList>35.67458945894767 139.7377659945459 23.082 35.67449989609891 139.7378083001948 23.082 35.67450487557333 139.737824577285 23.082 35.674594167201015 139.7377812446188 23.082 35.67458945894767 139.7377659945459 23.082</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-5383c3c6-5399-4f7f-9249-1e0fd3a34d74">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5383c3c6-5399-4f7f-9249-1e0fd3a34d74">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5383c3c6-5399-4f7f-9249-1e0fd3a34d74">
											<gml:posList>35.67460100820236 139.7378034406146 26.574 35.674594167201015 139.7377812446188 23.082 35.67450487557333 139.737824577285 23.082 35.67460100820236 139.7378034406146 26.574</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-9bb879b6-833b-4a73-9743-cdddb4f4db9c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9bb879b6-833b-4a73-9743-cdddb4f4db9c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9bb879b6-833b-4a73-9743-cdddb4f4db9c">
											<gml:posList>35.67459873279797 139.7378098283999 26.789 35.67460526653039 139.73783101950292 26.789 35.67460897882314 139.7378293028199 26.789 35.67460100820236 139.7378034406146 26.789 35.67459873279797 139.7378098283999 26.789</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-6da35a3d-b704-452b-ba6c-2f8a4ca1065e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6da35a3d-b704-452b-ba6c-2f8a4ca1065e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6da35a3d-b704-452b-ba6c-2f8a4ca1065e">
											<gml:posList>35.67460100820236 139.7378034406146 26.574 35.67450487557333 139.737824577285 23.082 35.67451192451297 139.73784756838378 26.574 35.67460100820236 139.7378034406146 26.574</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-21706f3e-309b-469b-b2de-56b2b3096e9d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-21706f3e-309b-469b-b2de-56b2b3096e9d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-21706f3e-309b-469b-b2de-56b2b3096e9d">
											<gml:posList>35.67451192451297 139.73784756838378 26.789 35.67451701042124 139.73785030193955 26.789 35.67459873279797 139.7378098283999 26.789 35.67460100820236 139.7378034406146 26.789 35.67451192451297 139.73784756838378 26.789</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-33ab3b8d-3edb-4869-a1a6-0c2b6f81915a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-33ab3b8d-3edb-4869-a1a6-0c2b6f81915a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-33ab3b8d-3edb-4869-a1a6-0c2b6f81915a">
											<gml:posList>35.67457774872694 139.73784376719547 30.933 35.67458104920991 139.73784560808602 30.933 35.67460747674823 139.73783335880026 30.933 35.67460897882314 139.7378293028199 30.933 35.67457774872694 139.73784376719547 30.933</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ba77e541-f8e9-425e-b903-531e64e6ed9a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ba77e541-f8e9-425e-b903-531e64e6ed9a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ba77e541-f8e9-425e-b903-531e64e6ed9a">
											<gml:posList>35.67460897882314 139.7378293028199 30.933 35.67460747674823 139.73783335880026 30.933 35.67462358959976 139.73788554698925 30.933 35.67462689908705 139.73788737682497 30.933 35.67460897882314 139.7378293028199 30.933</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-262e74a7-a0ea-469b-b528-97cac95efef5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-262e74a7-a0ea-469b-b528-97cac95efef5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-262e74a7-a0ea-469b-b528-97cac95efef5">
											<gml:posList>35.6745876622713 139.7378759127349 30.933 35.67458915534269 139.7378718678139 30.933 35.67458104920991 139.73784560808602 30.933 35.67457774872694 139.73784376719547 30.933 35.6745876622713 139.7378759127349 30.933</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-0b4bf8b1-d5ee-4524-bf46-146204999c03">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0b4bf8b1-d5ee-4524-bf46-146204999c03">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0b4bf8b1-d5ee-4524-bf46-146204999c03">
											<gml:posList>35.67460393240618 139.73786500117566 30.455 35.674611948152375 139.73789095170906 30.455 35.67462358959976 139.73788554698925 30.455 35.67460747674823 139.73783335880026 30.455 35.67458104920991 139.73784560808602 30.455 35.67458915534269 139.7378718678139 30.455 35.67460393240618 139.73786500117566 30.455</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-66a7891c-afc2-4394-a2f5-7e958c1c2b6d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-66a7891c-afc2-4394-a2f5-7e958c1c2b6d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-66a7891c-afc2-4394-a2f5-7e958c1c2b6d">
											<gml:posList>35.67457774872694 139.73784376719547 26.07 35.67460526653039 139.73783101950292 26.07 35.67459873279797 139.7378098283999 26.07 35.67451701042124 139.73785030193955 26.07 35.67454144651168 139.73792975479444 26.07 35.674588309812385 139.73790820187426 26.07 35.67458623129962 139.73790144368314 26.07 35.67460907241805 139.7378905022123 26.07 35.674602457362454 139.7378690460761 26.07 35.6745876622713 139.7378759127349 26.07 35.67457774872694 139.73784376719547 26.07</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-045fceb2-c948-42c2-8daa-8e7afaf5bbd9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-045fceb2-c948-42c2-8daa-8e7afaf5bbd9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-045fceb2-c948-42c2-8daa-8e7afaf5bbd9">
											<gml:posList>35.674602457362454 139.7378690460761 30.933 35.67460393240618 139.73786500117566 30.933 35.67458915534269 139.7378718678139 30.933 35.6745876622713 139.7378759127349 30.933 35.674602457362454 139.7378690460761 30.933</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-56faacc0-ea92-4d7c-974a-3f90438898b0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-56faacc0-ea92-4d7c-974a-3f90438898b0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-56faacc0-ea92-4d7c-974a-3f90438898b0">
											<gml:posList>35.674602457362454 139.7378690460761 30.933 35.674610464094066 139.73789499662013 30.933 35.674611948152375 139.73789095170906 30.933 35.67460393240618 139.73786500117566 30.933 35.674602457362454 139.7378690460761 30.933</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-7fee8ac0-1482-4c8c-adc7-b71595454a7b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7fee8ac0-1482-4c8c-adc7-b71595454a7b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7fee8ac0-1482-4c8c-adc7-b71595454a7b">
											<gml:posList>35.67462689908705 139.73788737682497 30.933 35.67462358959976 139.73788554698925 30.933 35.674611948152375 139.73789095170906 30.933 35.674610464094066 139.73789499662013 30.933 35.67462689908705 139.73788737682497 30.933</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-96344758-2252-487f-b070-aa408601fda3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-96344758-2252-487f-b070-aa408601fda3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-96344758-2252-487f-b070-aa408601fda3">
											<gml:posList>35.674591326255346 139.73790422142142 26.789 35.674610464094066 139.73789499662013 26.789 35.67460907241805 139.7378905022123 26.789 35.67458623129962 139.73790144368314 26.789 35.674591326255346 139.73790422142142 26.789</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-9a88b8d8-8881-4f03-af1e-43a7a5d7577b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9a88b8d8-8881-4f03-af1e-43a7a5d7577b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9a88b8d8-8881-4f03-af1e-43a7a5d7577b">
											<gml:posList>35.674591326255346 139.73790422142142 26.789 35.67458623129962 139.73790144368314 26.789 35.674588309812385 139.73790820187426 26.789 35.674593422847906 139.73791104587255 26.789 35.674591326255346 139.73790422142142 26.789</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a97019dd-4c27-4ec9-9674-3fc0819d0d3e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a97019dd-4c27-4ec9-9674-3fc0819d0d3e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a97019dd-4c27-4ec9-9674-3fc0819d0d3e">
											<gml:posList>35.674593422847906 139.73791104587255 26.789 35.674588309812385 139.73790820187426 26.789 35.67454144651168 139.73792975479444 26.789 35.674539116913245 139.73793601007392 26.789 35.674593422847906 139.73791104587255 26.789</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d578f591-a1a5-4428-a0e0-96b0715e333a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d578f591-a1a5-4428-a0e0-96b0715e333a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d578f591-a1a5-4428-a0e0-96b0715e333a">
											<gml:posList>35.674611948152375 139.73789095170906 30.933 35.674611948152375 139.73789095170906 30.455 35.67460393240618 139.73786500117566 30.455 35.67460393240618 139.73786500117566 30.933 35.674611948152375 139.73789095170906 30.933</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-efc1ac79-2c32-4888-85c1-ce28d7fc37d3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-efc1ac79-2c32-4888-85c1-ce28d7fc37d3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-efc1ac79-2c32-4888-85c1-ce28d7fc37d3">
											<gml:posList>35.67458945894767 139.7377659945459 8.35 35.67458945894767 139.7377659945459 23.082 35.674594167201015 139.7377812446188 23.082 35.67458945894767 139.7377659945459 8.35</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9d5cea37-eaf4-465b-95e1-53d7a000e98f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9d5cea37-eaf4-465b-95e1-53d7a000e98f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9d5cea37-eaf4-465b-95e1-53d7a000e98f">
											<gml:posList>35.67460100820236 139.7378034406146 26.574 35.67458945894767 139.7377659945459 8.35 35.674594167201015 139.7377812446188 23.082 35.67460100820236 139.7378034406146 26.574</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-15232518-9a10-47f8-81f3-e74fd3cd5094">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-15232518-9a10-47f8-81f3-e74fd3cd5094">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-15232518-9a10-47f8-81f3-e74fd3cd5094">
											<gml:posList>35.67458945894767 139.7377659945459 23.082 35.67449989609891 139.7378083001948 8.35 35.67449989609891 139.7378083001948 23.082 35.67458945894767 139.7377659945459 23.082</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6e3ba8fa-4874-4e94-921f-5f25a6bef59a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6e3ba8fa-4874-4e94-921f-5f25a6bef59a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6e3ba8fa-4874-4e94-921f-5f25a6bef59a">
											<gml:posList>35.67458945894767 139.7377659945459 23.082 35.67458945894767 139.7377659945459 8.35 35.67449989609891 139.7378083001948 8.35 35.67458945894767 139.7377659945459 23.082</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-738d85e6-285e-4978-adee-e12e59d3b96d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-738d85e6-285e-4978-adee-e12e59d3b96d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-738d85e6-285e-4978-adee-e12e59d3b96d">
											<gml:posList>35.67460897882314 139.7378293028199 26.789 35.67458945894767 139.7377659945459 8.35 35.67460100820236 139.7378034406146 26.574 35.67460100820236 139.7378034406146 26.789 35.67460897882314 139.7378293028199 26.789</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-12285c59-9acc-4b35-acd1-759f94b8ec6f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-12285c59-9acc-4b35-acd1-759f94b8ec6f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-12285c59-9acc-4b35-acd1-759f94b8ec6f">
											<gml:posList>35.67450487557333 139.737824577285 23.082 35.67449989609891 139.7378083001948 23.082 35.67449989609891 139.7378083001948 8.35 35.67450487557333 139.737824577285 23.082</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7b20d736-c92f-473f-8e6e-888896807328">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7b20d736-c92f-473f-8e6e-888896807328">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7b20d736-c92f-473f-8e6e-888896807328">
											<gml:posList>35.67459873279797 139.7378098283999 26.789 35.67459873279797 139.7378098283999 26.07 35.67460526653039 139.73783101950292 26.07 35.67460526653039 139.73783101950292 26.789 35.67459873279797 139.7378098283999 26.789</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-69d8397d-0901-4cc7-aeba-b618539db8f3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-69d8397d-0901-4cc7-aeba-b618539db8f3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-69d8397d-0901-4cc7-aeba-b618539db8f3">
											<gml:posList>35.67451192451297 139.73784756838378 26.574 35.67451192451297 139.73784756838378 26.789 35.67460100820236 139.7378034406146 26.789 35.67460100820236 139.7378034406146 26.574 35.67451192451297 139.73784756838378 26.574</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-16e3d910-bb1a-4682-8135-c5daff949209">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-16e3d910-bb1a-4682-8135-c5daff949209">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-16e3d910-bb1a-4682-8135-c5daff949209">
											<gml:posList>35.67460897882314 139.7378293028199 26.789 35.67462689908705 139.73788737682497 8.35 35.67458945894767 139.7377659945459 8.35 35.67460897882314 139.7378293028199 26.789</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-208cd5ac-4245-48e0-b977-5ff116549a12">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-208cd5ac-4245-48e0-b977-5ff116549a12">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-208cd5ac-4245-48e0-b977-5ff116549a12">
											<gml:posList>35.67451192451297 139.73784756838378 26.574 35.67450487557333 139.737824577285 23.082 35.67449989609891 139.7378083001948 8.35 35.67451192451297 139.73784756838378 26.574</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0e30b4a0-c1a5-4761-90b0-4d929fb7311e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0e30b4a0-c1a5-4761-90b0-4d929fb7311e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0e30b4a0-c1a5-4761-90b0-4d929fb7311e">
											<gml:posList>35.67451701042124 139.73785030193955 26.789 35.67451701042124 139.73785030193955 26.07 35.67459873279797 139.7378098283999 26.07 35.67459873279797 139.7378098283999 26.789 35.67451701042124 139.73785030193955 26.789</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b5cb3241-49b9-4375-8fd8-ca99b44d3d84">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b5cb3241-49b9-4375-8fd8-ca99b44d3d84">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b5cb3241-49b9-4375-8fd8-ca99b44d3d84">
											<gml:posList>35.67460526653039 139.73783101950292 26.789 35.67460526653039 139.73783101950292 26.07 35.67457774872694 139.73784376719547 26.07 35.67457774872694 139.73784376719547 30.933 35.67460897882314 139.7378293028199 30.933 35.67460897882314 139.7378293028199 26.789 35.67460526653039 139.73783101950292 26.789</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ab96ca8f-b3b0-4b5d-8a45-5d0479883ae7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ab96ca8f-b3b0-4b5d-8a45-5d0479883ae7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ab96ca8f-b3b0-4b5d-8a45-5d0479883ae7">
											<gml:posList>35.67458104920991 139.73784560808602 30.933 35.67458104920991 139.73784560808602 30.455 35.67460747674823 139.73783335880026 30.455 35.67460747674823 139.73783335880026 30.933 35.67458104920991 139.73784560808602 30.933</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3876a72b-ac9b-466e-846f-c18c981a6c39">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3876a72b-ac9b-466e-846f-c18c981a6c39">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3876a72b-ac9b-466e-846f-c18c981a6c39">
											<gml:posList>35.67462689908705 139.73788737682497 30.933 35.67462689908705 139.73788737682497 8.35 35.67460897882314 139.7378293028199 30.933 35.67462689908705 139.73788737682497 30.933</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7a5c5adb-7deb-4d16-a08f-d0d0c9bc05f8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7a5c5adb-7deb-4d16-a08f-d0d0c9bc05f8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7a5c5adb-7deb-4d16-a08f-d0d0c9bc05f8">
											<gml:posList>35.67462689908705 139.73788737682497 8.35 35.67460897882314 139.7378293028199 26.789 35.67460897882314 139.7378293028199 30.933 35.67462689908705 139.73788737682497 8.35</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0f5a7435-b826-46e1-94be-6253b2c13ab3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0f5a7435-b826-46e1-94be-6253b2c13ab3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0f5a7435-b826-46e1-94be-6253b2c13ab3">
											<gml:posList>35.67458915534269 139.7378718678139 30.933 35.67458915534269 139.7378718678139 30.455 35.67458104920991 139.73784560808602 30.455 35.67458104920991 139.73784560808602 30.933 35.67458915534269 139.7378718678139 30.933</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2665120d-1e86-4739-8ec2-317c99c20b2c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2665120d-1e86-4739-8ec2-317c99c20b2c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2665120d-1e86-4739-8ec2-317c99c20b2c">
											<gml:posList>35.67460747674823 139.73783335880026 30.933 35.67460747674823 139.73783335880026 30.455 35.67462358959976 139.73788554698925 30.455 35.67462358959976 139.73788554698925 30.933 35.67460747674823 139.73783335880026 30.933</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-913a9cce-0d86-4027-bedc-b6eb8311431e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-913a9cce-0d86-4027-bedc-b6eb8311431e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-913a9cce-0d86-4027-bedc-b6eb8311431e">
											<gml:posList>35.67457774872694 139.73784376719547 26.07 35.6745876622713 139.7378759127349 26.07 35.6745876622713 139.7378759127349 30.933 35.67457774872694 139.73784376719547 30.933 35.67457774872694 139.73784376719547 26.07</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-442b127c-2954-4a8e-a00e-60e90064f72c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-442b127c-2954-4a8e-a00e-60e90064f72c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-442b127c-2954-4a8e-a00e-60e90064f72c">
											<gml:posList>35.67460393240618 139.73786500117566 30.933 35.67460393240618 139.73786500117566 30.455 35.67458915534269 139.7378718678139 30.455 35.67458915534269 139.7378718678139 30.933 35.67460393240618 139.73786500117566 30.933</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-71e2e573-043a-4772-9a67-ad8e9e8b9aad">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-71e2e573-043a-4772-9a67-ad8e9e8b9aad">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-71e2e573-043a-4772-9a67-ad8e9e8b9aad">
											<gml:posList>35.674539116913245 139.73793601007392 25.905 35.67451192451297 139.73784756838378 26.574 35.67449989609891 139.7378083001948 8.35 35.674539116913245 139.73793601007392 25.905</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9fb42a9c-7730-408b-b43e-7bdf97b31716">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9fb42a9c-7730-408b-b43e-7bdf97b31716">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9fb42a9c-7730-408b-b43e-7bdf97b31716">
											<gml:posList>35.6745876622713 139.7378759127349 26.07 35.674602457362454 139.7378690460761 26.07 35.674602457362454 139.7378690460761 30.933 35.6745876622713 139.7378759127349 30.933 35.6745876622713 139.7378759127349 26.07</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-98848e05-511d-4c87-b780-6b25ea1eb8fb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-98848e05-511d-4c87-b780-6b25ea1eb8fb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-98848e05-511d-4c87-b780-6b25ea1eb8fb">
											<gml:posList>35.67460907241805 139.7378905022123 26.789 35.674610464094066 139.73789499662013 26.789 35.674610464094066 139.73789499662013 30.933 35.674602457362454 139.7378690460761 30.933 35.674602457362454 139.7378690460761 26.07 35.67460907241805 139.7378905022123 26.07 35.67460907241805 139.7378905022123 26.789</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c37b0895-0517-4697-8135-f50a18f2fc74">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c37b0895-0517-4697-8135-f50a18f2fc74">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c37b0895-0517-4697-8135-f50a18f2fc74">
											<gml:posList>35.67462358959976 139.73788554698925 30.933 35.67462358959976 139.73788554698925 30.455 35.674611948152375 139.73789095170906 30.455 35.674611948152375 139.73789095170906 30.933 35.67462358959976 139.73788554698925 30.933</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1b1efef6-23f3-468e-87dc-232e5b0610d5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1b1efef6-23f3-468e-87dc-232e5b0610d5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1b1efef6-23f3-468e-87dc-232e5b0610d5">
											<gml:posList>35.67454144651168 139.73792975479444 26.789 35.67454144651168 139.73792975479444 26.07 35.67451701042124 139.73785030193955 26.07 35.67451701042124 139.73785030193955 26.789 35.67454144651168 139.73792975479444 26.789</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b404c451-d35c-408a-949c-b4a6abef3a6d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b404c451-d35c-408a-949c-b4a6abef3a6d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b404c451-d35c-408a-949c-b4a6abef3a6d">
											<gml:posList>35.67462689908705 139.73788737682497 30.933 35.674610464094066 139.73789499662013 8.35 35.67462689908705 139.73788737682497 8.35 35.67462689908705 139.73788737682497 30.933</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5c33e150-68b7-4faa-bc43-490a83f56b0e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5c33e150-68b7-4faa-bc43-490a83f56b0e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5c33e150-68b7-4faa-bc43-490a83f56b0e">
											<gml:posList>35.67462689908705 139.73788737682497 30.933 35.674610464094066 139.73789499662013 30.933 35.674610464094066 139.73789499662013 26.789 35.674610464094066 139.73789499662013 26.714 35.674610464094066 139.73789499662013 8.35 35.67462689908705 139.73788737682497 30.933</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-113d6d2a-16e5-43f9-8acc-a4c4f15be748">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-113d6d2a-16e5-43f9-8acc-a4c4f15be748">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-113d6d2a-16e5-43f9-8acc-a4c4f15be748">
											<gml:posList>35.674539116913245 139.73793601007392 26.789 35.67451192451297 139.73784756838378 26.574 35.674539116913245 139.73793601007392 25.905 35.674539116913245 139.73793601007392 26.789</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-43164960-cd99-4962-9eed-86fb0d601385">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-43164960-cd99-4962-9eed-86fb0d601385">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-43164960-cd99-4962-9eed-86fb0d601385">
											<gml:posList>35.674539116913245 139.73793601007392 26.789 35.67451192451297 139.73784756838378 26.789 35.67451192451297 139.73784756838378 26.574 35.674539116913245 139.73793601007392 26.789</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-51dd511b-f689-481e-8c4d-365f1cfa708f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-51dd511b-f689-481e-8c4d-365f1cfa708f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-51dd511b-f689-481e-8c4d-365f1cfa708f">
											<gml:posList>35.674539116913245 139.73793601007392 25.905 35.67449989609891 139.7378083001948 8.35 35.67455222070859 139.73797880096217 20.716 35.674539116913245 139.73793601007392 25.905</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1b58fffa-9010-4235-9b1b-a62979490830">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1b58fffa-9010-4235-9b1b-a62979490830">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1b58fffa-9010-4235-9b1b-a62979490830">
											<gml:posList>35.67449989609891 139.7378083001948 8.35 35.67455222070859 139.73797880096217 8.35 35.67455222070859 139.73797880096217 20.716 35.67449989609891 139.7378083001948 8.35</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-36ed177e-d9ba-47df-b827-dc5e7ee49b77">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-36ed177e-d9ba-47df-b827-dc5e7ee49b77">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-36ed177e-d9ba-47df-b827-dc5e7ee49b77">
											<gml:posList>35.6746076889291 139.7378963365919 26.714 35.6746076889291 139.7378963365919 8.35 35.674610464094066 139.73789499662013 8.35 35.674610464094066 139.73789499662013 26.714 35.6746076889291 139.7378963365919 26.714</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b2ff56f6-4978-48eb-9440-e0dc793f59fc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b2ff56f6-4978-48eb-9440-e0dc793f59fc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b2ff56f6-4978-48eb-9440-e0dc793f59fc">
											<gml:posList>35.67460907241805 139.7378905022123 26.789 35.67460907241805 139.7378905022123 26.07 35.67458623129962 139.73790144368314 26.07 35.67458623129962 139.73790144368314 26.789 35.67460907241805 139.7378905022123 26.789</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d62027d0-95cf-453b-9b64-eecea001ae85">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d62027d0-95cf-453b-9b64-eecea001ae85">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d62027d0-95cf-453b-9b64-eecea001ae85">
											<gml:posList>35.6746076889291 139.7378963365919 26.714 35.674610464094066 139.73789499662013 26.789 35.674591326255346 139.73790422142142 26.789 35.6746076889291 139.7378963365919 26.714</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4222e464-9f15-46b1-b330-277afb729aee">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4222e464-9f15-46b1-b330-277afb729aee">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4222e464-9f15-46b1-b330-277afb729aee">
											<gml:posList>35.6746076889291 139.7378963365919 26.714 35.674591326255346 139.73790422142142 26.789 35.674591326255346 139.73790422142142 26.714 35.6746076889291 139.7378963365919 26.714</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1d846e46-ad57-4729-9898-713f03f4068d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1d846e46-ad57-4729-9898-713f03f4068d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1d846e46-ad57-4729-9898-713f03f4068d">
											<gml:posList>35.67458623129962 139.73790144368314 26.789 35.67458623129962 139.73790144368314 26.07 35.674588309812385 139.73790820187426 26.07 35.674588309812385 139.73790820187426 26.789 35.67458623129962 139.73790144368314 26.789</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-df3b395d-bb37-4fdd-ab03-ccdb4e940907">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-df3b395d-bb37-4fdd-ab03-ccdb4e940907">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-df3b395d-bb37-4fdd-ab03-ccdb4e940907">
											<gml:posList>35.674591326255346 139.73790422142142 26.714 35.674591326255346 139.73790422142142 26.789 35.674593422847906 139.73791104587255 26.789 35.674593422847906 139.73791104587255 25.905 35.674591326255346 139.73790422142142 26.714</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7ba33695-382c-4cbb-9fea-c4454c8763b8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7ba33695-382c-4cbb-9fea-c4454c8763b8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7ba33695-382c-4cbb-9fea-c4454c8763b8">
											<gml:posList>35.674588309812385 139.73790820187426 26.789 35.674588309812385 139.73790820187426 26.07 35.67454144651168 139.73792975479444 26.07 35.67454144651168 139.73792975479444 26.789 35.674588309812385 139.73790820187426 26.789</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-153e60cf-4dff-41e9-8ba2-a63d2842f74c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-153e60cf-4dff-41e9-8ba2-a63d2842f74c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-153e60cf-4dff-41e9-8ba2-a63d2842f74c">
											<gml:posList>35.6746219341202 139.737946262413 20.716 35.6746219341202 139.737946262413 8.35 35.6746076889291 139.7378963365919 8.35 35.6746076889291 139.7378963365919 26.714 35.6746219341202 139.737946262413 20.716</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f2177dd6-d4e8-41c2-acd4-9c8ed75b4e4e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f2177dd6-d4e8-41c2-acd4-9c8ed75b4e4e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f2177dd6-d4e8-41c2-acd4-9c8ed75b4e4e">
											<gml:posList>35.674539116913245 139.73793601007392 25.905 35.674593422847906 139.73791104587255 25.905 35.674593422847906 139.73791104587255 26.789 35.674539116913245 139.73793601007392 25.905</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4cd13ddf-fcee-49bc-a019-b0973220f405">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4cd13ddf-fcee-49bc-a019-b0973220f405">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4cd13ddf-fcee-49bc-a019-b0973220f405">
											<gml:posList>35.674539116913245 139.73793601007392 26.789 35.674539116913245 139.73793601007392 25.905 35.674593422847906 139.73791104587255 26.789 35.674539116913245 139.73793601007392 26.789</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f493bf4c-bec0-4f77-bc5a-ba837c03ed76">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f493bf4c-bec0-4f77-bc5a-ba837c03ed76">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f493bf4c-bec0-4f77-bc5a-ba837c03ed76">
											<gml:posList>35.67455222070859 139.73797880096217 8.35 35.6746219341202 139.737946262413 8.35 35.6746219341202 139.737946262413 20.716 35.67455222070859 139.73797880096217 20.716 35.67455222070859 139.73797880096217 8.35</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6f8fa6f9-6412-483d-b975-f7a4654ec4cf">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6f8fa6f9-6412-483d-b975-f7a4654ec4cf">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6f8fa6f9-6412-483d-b975-f7a4654ec4cf">
											<gml:posList>35.6746076889291 139.7378963365919 26.714 35.674610464094066 139.73789499662013 26.714 35.674610464094066 139.73789499662013 26.789 35.6746076889291 139.7378963365919 26.714</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂三丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-6330</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">176.02345</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1242</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>5</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.01</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>