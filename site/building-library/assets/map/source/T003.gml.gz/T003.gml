<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_0077bacf-fdae-4638-9d2d-3e2687f7568d">
			<core:creationDate>2024-03-15</core:creationDate>
			<bldg:measuredHeight uom="m">3.5</bldg:measuredHeight>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.67140644040265 139.73894139216887 0 35.67140308730365 139.73891840855774 0 35.67137485214936 139.7389246056971 0 35.67137821425229 139.73894757824343 0 35.67140644040265 139.73894139216887 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67140644040265 139.73894139216887 16.78 35.67137821425229 139.73894757824343 16.78 35.67137485214936 139.7389246056971 16.78 35.67140308730365 139.73891840855774 16.78 35.67140644040265 139.73894139216887 16.78</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67140644040265 139.73894139216887 16.78 35.67140308730365 139.73891840855774 16.78 35.67140308730365 139.73891840855774 20.23 35.67140644040265 139.73894139216887 20.23 35.67140644040265 139.73894139216887 16.78</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67140308730365 139.73891840855774 16.78 35.67137485214936 139.7389246056971 16.78 35.67137485214936 139.7389246056971 20.23 35.67140308730365 139.73891840855774 20.23 35.67140308730365 139.73891840855774 16.78</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67137485214936 139.7389246056971 16.78 35.67137821425229 139.73894757824343 16.78 35.67137821425229 139.73894757824343 20.23 35.67137485214936 139.7389246056971 20.23 35.67137485214936 139.7389246056971 16.78</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67137821425229 139.73894757824343 16.78 35.67140644040265 139.73894139216887 16.78 35.67140644040265 139.73894139216887 20.23 35.67137821425229 139.73894757824343 20.23 35.67137821425229 139.73894757824343 16.78</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67140644040265 139.73894139216887 20.23 35.67140308730365 139.73891840855774 20.23 35.67137485214936 139.7389246056971 20.23 35.67137821425229 139.73894757824343 20.23 35.67140644040265 139.73894139216887 20.23</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-574009be-0883-44ef-86b1-e689a8809936"/>
							<gml:surfaceMember xlink:href="#poly-4c56460e-7557-4046-af7d-c6aed32202be"/>
							<gml:surfaceMember xlink:href="#poly-ac8b1622-3d8f-499a-9071-c0b9bf70944f"/>
							<gml:surfaceMember xlink:href="#poly-985ce001-a764-4e7f-90ed-b6224e8f77fa"/>
							<gml:surfaceMember xlink:href="#poly-2171d9ee-6931-413d-99bf-cf7ba14b5aa2"/>
							<gml:surfaceMember xlink:href="#poly-6b69e9a0-8c5b-4306-b9f1-071770cc0864"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-574009be-0883-44ef-86b1-e689a8809936">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-574009be-0883-44ef-86b1-e689a8809936">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-574009be-0883-44ef-86b1-e689a8809936">
											<gml:posList>35.67140644040267 139.73894139216887 16.78 35.67137821425227 139.7389475782434 16.78 35.671374852149356 139.73892460569706 16.78 35.671403087303624 139.73891840855774 16.78 35.67140644040267 139.73894139216887 16.78</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-4c56460e-7557-4046-af7d-c6aed32202be">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4c56460e-7557-4046-af7d-c6aed32202be">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4c56460e-7557-4046-af7d-c6aed32202be">
											<gml:posList>35.67137821425227 139.7389475782434 20.576 35.67140644040267 139.73894139216887 20.576 35.671403087303624 139.73891840855774 20.576 35.671374852149356 139.73892460569706 20.576 35.67137821425227 139.7389475782434 20.576</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ac8b1622-3d8f-499a-9071-c0b9bf70944f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ac8b1622-3d8f-499a-9071-c0b9bf70944f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ac8b1622-3d8f-499a-9071-c0b9bf70944f">
											<gml:posList>35.671403087303624 139.73891840855774 16.78 35.671374852149356 139.73892460569706 16.78 35.671374852149356 139.73892460569706 20.576 35.671403087303624 139.73891840855774 20.576 35.671403087303624 139.73891840855774 16.78</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-985ce001-a764-4e7f-90ed-b6224e8f77fa">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-985ce001-a764-4e7f-90ed-b6224e8f77fa">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-985ce001-a764-4e7f-90ed-b6224e8f77fa">
											<gml:posList>35.67140644040267 139.73894139216887 16.78 35.671403087303624 139.73891840855774 16.78 35.671403087303624 139.73891840855774 20.576 35.67140644040267 139.73894139216887 20.576 35.67140644040267 139.73894139216887 16.78</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2171d9ee-6931-413d-99bf-cf7ba14b5aa2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2171d9ee-6931-413d-99bf-cf7ba14b5aa2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2171d9ee-6931-413d-99bf-cf7ba14b5aa2">
											<gml:posList>35.671374852149356 139.73892460569706 16.78 35.67137821425227 139.7389475782434 16.78 35.67137821425227 139.7389475782434 20.576 35.671374852149356 139.73892460569706 20.576 35.671374852149356 139.73892460569706 16.78</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6b69e9a0-8c5b-4306-b9f1-071770cc0864">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6b69e9a0-8c5b-4306-b9f1-071770cc0864">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6b69e9a0-8c5b-4306-b9f1-071770cc0864">
											<gml:posList>35.67137821425227 139.7389475782434 16.78 35.67140644040267 139.73894139216887 16.78 35.67140644040267 139.73894139216887 20.576 35.67137821425227 139.7389475782434 20.576 35.67137821425227 139.7389475782434 16.78</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-3475</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>4</uro:specifiedFloorAreaRate>
					<uro:surveyYear>0001</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.04</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>