<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_00bd7a97-e689-4d28-8770-0e9e1c6ecf8e">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">401</bldg:usage>
			<bldg:measuredHeight uom="m">19.9</bldg:measuredHeight>
			<bldg:storeysAboveGround>7</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.669088190514444 139.73932232813897 0 35.6690547887479 139.7393725275363 0 35.66903018911504 139.73934794571198 0 35.669062725277904 139.73929739386054 0 35.66900932312112 139.73924508706986 0 35.668937388600966 139.73935419609822 0 35.66908749309555 139.73950292133893 0 35.669135209176055 139.73943018224233 0 35.66912285089764 139.73941804602083 0 35.66914742898132 139.73938035006762 0 35.669088190514444 139.73932232813897 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669088190514444 139.73932232813897 11.49 35.66914742898132 139.73938035006762 11.49 35.66912285089764 139.73941804602083 11.49 35.669135209176055 139.73943018224233 11.49 35.66908749309555 139.73950292133893 11.49 35.668937388600966 139.73935419609822 11.49 35.66900932312112 139.73924508706986 11.49 35.669062725277904 139.73929739386054 11.49 35.66903018911504 139.73934794571198 11.49 35.6690547887479 139.7393725275363 11.49 35.669088190514444 139.73932232813897 11.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669088190514444 139.73932232813897 11.49 35.6690547887479 139.7393725275363 11.49 35.6690547887479 139.7393725275363 31.4 35.669088190514444 139.73932232813897 31.4 35.669088190514444 139.73932232813897 11.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6690547887479 139.7393725275363 11.49 35.66903018911504 139.73934794571198 11.49 35.66903018911504 139.73934794571198 31.4 35.6690547887479 139.7393725275363 31.4 35.6690547887479 139.7393725275363 11.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66903018911504 139.73934794571198 11.49 35.669062725277904 139.73929739386054 11.49 35.669062725277904 139.73929739386054 31.4 35.66903018911504 139.73934794571198 31.4 35.66903018911504 139.73934794571198 11.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669062725277904 139.73929739386054 11.49 35.66900932312112 139.73924508706986 11.49 35.66900932312112 139.73924508706986 31.4 35.669062725277904 139.73929739386054 31.4 35.669062725277904 139.73929739386054 11.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66900932312112 139.73924508706986 11.49 35.668937388600966 139.73935419609822 11.49 35.668937388600966 139.73935419609822 31.4 35.66900932312112 139.73924508706986 31.4 35.66900932312112 139.73924508706986 11.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668937388600966 139.73935419609822 11.49 35.66908749309555 139.73950292133893 11.49 35.66908749309555 139.73950292133893 31.4 35.668937388600966 139.73935419609822 31.4 35.668937388600966 139.73935419609822 11.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66908749309555 139.73950292133893 11.49 35.669135209176055 139.73943018224233 11.49 35.669135209176055 139.73943018224233 31.4 35.66908749309555 139.73950292133893 31.4 35.66908749309555 139.73950292133893 11.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669135209176055 139.73943018224233 11.49 35.66912285089764 139.73941804602083 11.49 35.66912285089764 139.73941804602083 31.4 35.669135209176055 139.73943018224233 31.4 35.669135209176055 139.73943018224233 11.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66912285089764 139.73941804602083 11.49 35.66914742898132 139.73938035006762 11.49 35.66914742898132 139.73938035006762 31.4 35.66912285089764 139.73941804602083 31.4 35.66912285089764 139.73941804602083 11.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66914742898132 139.73938035006762 11.49 35.669088190514444 139.73932232813897 11.49 35.669088190514444 139.73932232813897 31.4 35.66914742898132 139.73938035006762 31.4 35.66914742898132 139.73938035006762 11.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669088190514444 139.73932232813897 31.4 35.6690547887479 139.7393725275363 31.4 35.66903018911504 139.73934794571198 31.4 35.669062725277904 139.73929739386054 31.4 35.66900932312112 139.73924508706986 31.4 35.668937388600966 139.73935419609822 31.4 35.66908749309555 139.73950292133893 31.4 35.669135209176055 139.73943018224233 31.4 35.66912285089764 139.73941804602083 31.4 35.66914742898132 139.73938035006762 31.4 35.669088190514444 139.73932232813897 31.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-17dfff1b-4e46-4ed5-86a3-cd33e948a931"/>
							<gml:surfaceMember xlink:href="#poly-4d3910fe-64e7-458a-b8cf-d9feba51c368"/>
							<gml:surfaceMember xlink:href="#poly-709e7300-de46-48a0-8f56-16b161c2aba0"/>
							<gml:surfaceMember xlink:href="#poly-9219f58e-2600-4db9-8b29-6787051cfc0a"/>
							<gml:surfaceMember xlink:href="#poly-1da63d74-b585-4854-8018-661b9040c106"/>
							<gml:surfaceMember xlink:href="#poly-dfec07c6-4787-4525-a5eb-87522225a8a0"/>
							<gml:surfaceMember xlink:href="#poly-8401f3da-94f7-404c-b69f-ee34cc813814"/>
							<gml:surfaceMember xlink:href="#poly-40fed912-c132-4247-91a0-47036e0cf43d"/>
							<gml:surfaceMember xlink:href="#poly-8779edd3-03ab-42d7-8c81-6ffc5a95911e"/>
							<gml:surfaceMember xlink:href="#poly-bc95a4d2-1110-4dd0-83f4-83e5f0b15f7f"/>
							<gml:surfaceMember xlink:href="#poly-e66b679b-d1ee-4bbd-9060-f407ffebc82c"/>
							<gml:surfaceMember xlink:href="#poly-0e5002ee-fbc1-41e7-9060-2f07a067a5db"/>
							<gml:surfaceMember xlink:href="#poly-dfa463a3-ee70-4488-982f-eca67b0f90c0"/>
							<gml:surfaceMember xlink:href="#poly-00910fe6-85b2-4a7e-addd-5ec38de288de"/>
							<gml:surfaceMember xlink:href="#poly-9d6a33d0-acfe-42a7-96fb-fa783772e586"/>
							<gml:surfaceMember xlink:href="#poly-9a926d5b-7b92-4aef-bdb4-6afdc9c065cf"/>
							<gml:surfaceMember xlink:href="#poly-20f1e63e-2977-4aa1-bd88-61b0265b5300"/>
							<gml:surfaceMember xlink:href="#poly-a977e4af-11fe-4289-8c73-41d2781f3f95"/>
							<gml:surfaceMember xlink:href="#poly-cd2e781e-7fd7-4e93-949e-e6339be523ec"/>
							<gml:surfaceMember xlink:href="#poly-b8cf0e7c-7e54-40f7-9822-35e798e04ed5"/>
							<gml:surfaceMember xlink:href="#poly-5475c729-5f90-4d2b-80ef-c0d9da77e302"/>
							<gml:surfaceMember xlink:href="#poly-4ef89160-b43f-4008-98d6-fb7f5f011559"/>
							<gml:surfaceMember xlink:href="#poly-3c121194-490b-4932-b9ba-4aee68f5f056"/>
							<gml:surfaceMember xlink:href="#poly-51c1436d-2c1c-4970-8571-f2f63d2fd843"/>
							<gml:surfaceMember xlink:href="#poly-1235ab3f-eacf-4ead-a426-6f2f7551cada"/>
							<gml:surfaceMember xlink:href="#poly-efd869e0-9f68-451e-8d08-1aa8473b881c"/>
							<gml:surfaceMember xlink:href="#poly-84dc5f83-178c-4f59-82da-fd26f64b09ba"/>
							<gml:surfaceMember xlink:href="#poly-76951e3c-811c-4a64-a8b0-1309041d17d1"/>
							<gml:surfaceMember xlink:href="#poly-fdf9cb9f-8ac4-4464-98b5-5ea00f9dd1f6"/>
							<gml:surfaceMember xlink:href="#poly-88001d2a-f99d-49ac-829f-0d4cc778f989"/>
							<gml:surfaceMember xlink:href="#poly-2a945ba1-a3a4-4869-922d-49bd01653e16"/>
							<gml:surfaceMember xlink:href="#poly-8b9d04bf-f003-46df-9ea6-417e5191d866"/>
							<gml:surfaceMember xlink:href="#poly-3060df5c-e978-43cc-8dbf-e03725e4ccaf"/>
							<gml:surfaceMember xlink:href="#poly-cd389f4c-7298-46f7-8bb8-cd5f8d058f8b"/>
							<gml:surfaceMember xlink:href="#poly-397e5624-c9ce-4ad2-98b7-878b3fa5b1ba"/>
							<gml:surfaceMember xlink:href="#poly-26195f00-4e2b-4859-b9a1-640cff0dccd0"/>
							<gml:surfaceMember xlink:href="#poly-bf7b08c2-8372-4c39-b387-7c3b1fde93d8"/>
							<gml:surfaceMember xlink:href="#poly-11e26956-6bff-4eee-be3e-dbbccb03b340"/>
							<gml:surfaceMember xlink:href="#poly-6610e2a9-5418-4092-9cae-b9ccc5fe78d7"/>
							<gml:surfaceMember xlink:href="#poly-20be120b-4bdb-478f-bfd1-cbc8a9cdac2f"/>
							<gml:surfaceMember xlink:href="#poly-53cf3dbc-342d-42a7-b7d2-d2a7d9da1715"/>
							<gml:surfaceMember xlink:href="#poly-eeed2eff-e466-497d-b534-432d78d4b0ef"/>
							<gml:surfaceMember xlink:href="#poly-e9be99ec-15fd-4cc2-8094-caf0f870bf75"/>
							<gml:surfaceMember xlink:href="#poly-4f4cee0a-524f-4ead-b100-b01ded50c7f2"/>
							<gml:surfaceMember xlink:href="#poly-4243a6fc-4be0-43e8-97f6-d5a254c46364"/>
							<gml:surfaceMember xlink:href="#poly-364d0d2c-d3ce-47b8-a8de-fcc3355cb646"/>
							<gml:surfaceMember xlink:href="#poly-c0daacbb-622c-49e0-a80e-ac4660ce577e"/>
							<gml:surfaceMember xlink:href="#poly-e5063028-d524-4bb3-beb8-6335f23a03c0"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_00bd7a97-e689-4d28-8770-0e9e1c6ecf8e_BuildingInstallation_1060">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9a32810a-cb81-48ab-940f-ddb2231ca080">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669088190514444 139.73932232813897 11.49 35.66905478874789 139.73937252753626 11.49 35.66903018911501 139.73934794571196 11.49 35.66906272527789 139.73929739386054 11.49 35.669088190514444 139.73932232813897 11.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-77ef5640-2d0d-440e-ab49-50047b31a7b2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-77ef5640-2d0d-440e-ab49-50047b31a7b2_0">
											<gml:posList>35.66906272527789 139.73929739386054 32.139 35.669088190514444 139.73932232813897 32.139 35.669088190514444 139.73932232813897 11.49 35.66906272527789 139.73929739386054 11.49 35.66906272527789 139.73929739386054 32.139</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8739b3e0-9040-4a0b-b11f-81430843e811">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8739b3e0-9040-4a0b-b11f-81430843e811_0">
											<gml:posList>35.66906272527789 139.73929739386054 11.49 35.66903018911501 139.73934794571196 11.49 35.66903018911501 139.73934794571196 32.139 35.66906272527789 139.73929739386054 32.139 35.66906272527789 139.73929739386054 11.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c2bea2d1-aff4-4641-b15a-b1fab68efece">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c2bea2d1-aff4-4641-b15a-b1fab68efece_0">
											<gml:posList>35.669088190514444 139.73932232813897 32.139 35.66906272527789 139.73929739386054 32.139 35.66903018911501 139.73934794571196 32.139 35.66905478874789 139.73937252753626 32.139 35.669088190514444 139.73932232813897 32.139</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-61541d24-37ff-408e-b643-76204c9e9c7e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-61541d24-37ff-408e-b643-76204c9e9c7e_0">
											<gml:posList>35.66905478874789 139.73937252753626 32.139 35.66905478874789 139.73937252753626 11.49 35.669088190514444 139.73932232813897 11.49 35.669088190514444 139.73932232813897 32.139 35.66905478874789 139.73937252753626 32.139</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ffbf4a09-60c1-4d2c-8eac-0455ef6bab47">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ffbf4a09-60c1-4d2c-8eac-0455ef6bab47_0">
											<gml:posList>35.66903018911501 139.73934794571196 11.49 35.66905478874789 139.73937252753626 11.49 35.66905478874789 139.73937252753626 32.139 35.66903018911501 139.73934794571196 32.139 35.66903018911501 139.73934794571196 11.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-17dfff1b-4e46-4ed5-86a3-cd33e948a931">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-17dfff1b-4e46-4ed5-86a3-cd33e948a931">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-17dfff1b-4e46-4ed5-86a3-cd33e948a931">
											<gml:posList>35.66905478874789 139.73937252753626 11.49 35.669088190514444 139.73932232813897 11.49 35.669147428981326 139.73938035006762 11.49 35.669122850897644 139.73941804602083 11.49 35.66913520917603 139.73943018224233 11.49 35.66908749309554 139.73950292133893 11.49 35.668937388600945 139.73935419609822 11.49 35.66900932312112 139.73924508706986 11.49 35.66906272527789 139.73929739386054 11.49 35.66903018911501 139.73934794571196 11.49 35.66905478874789 139.73937252753626 11.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-4d3910fe-64e7-458a-b8cf-d9feba51c368">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4d3910fe-64e7-458a-b8cf-d9feba51c368">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4d3910fe-64e7-458a-b8cf-d9feba51c368">
											<gml:posList>35.66899020483614 139.73940652569328 32.139 35.6689897962545 139.73940272632458 32.139 35.668940425933016 139.73935381697217 32.139 35.668937388600945 139.73935419609822 32.139 35.66899020483614 139.73940652569328 32.139</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-709e7300-de46-48a0-8f56-16b161c2aba0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-709e7300-de46-48a0-8f56-16b161c2aba0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-709e7300-de46-48a0-8f56-16b161c2aba0">
											<gml:posList>35.668937388600945 139.73935419609822 32.139 35.668940425933016 139.73935381697217 32.139 35.66900965052378 139.73924880921146 32.139 35.66900932312112 139.73924508706986 32.139 35.668937388600945 139.73935419609822 32.139</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-9219f58e-2600-4db9-8b29-6787051cfc0a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9219f58e-2600-4db9-8b29-6787051cfc0a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9219f58e-2600-4db9-8b29-6787051cfc0a">
											<gml:posList>35.66900932312112 139.73924508706986 32.139 35.66900965052378 139.73924880921146 32.139 35.66905969701155 139.73929783925516 32.139 35.66906272527789 139.73929739386054 32.139 35.66900932312112 139.73924508706986 32.139</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-1da63d74-b585-4854-8018-661b9040c106">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1da63d74-b585-4854-8018-661b9040c106">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1da63d74-b585-4854-8018-661b9040c106">
											<gml:posList>35.66905969701155 139.73929783925516 32.139 35.669028673619515 139.73934642313029 32.139 35.66903018911501 139.73934794571196 32.139 35.66906272527789 139.73929739386054 32.139 35.66905969701155 139.73929783925516 32.139</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-dfec07c6-4787-4525-a5eb-87522225a8a0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-dfec07c6-4787-4525-a5eb-87522225a8a0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-dfec07c6-4787-4525-a5eb-87522225a8a0">
											<gml:posList>35.66908849987867 139.7393260392596 32.139 35.669088190514444 139.73932232813897 32.139 35.66905478874789 139.73937252753626 32.139 35.66905645758841 139.73937419353825 32.139 35.66908849987867 139.7393260392596 32.139</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-8401f3da-94f7-404c-b69f-ee34cc813814">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8401f3da-94f7-404c-b69f-ee34cc813814">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8401f3da-94f7-404c-b69f-ee34cc813814">
											<gml:posList>35.669088190514444 139.73932232813897 32.139 35.66908849987867 139.7393260392596 32.139 35.6691443826614 139.73938076234248 32.139 35.669147428981326 139.73938035006762 32.139 35.669088190514444 139.73932232813897 32.139</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-40fed912-c132-4247-91a0-47036e0cf43d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-40fed912-c132-4247-91a0-47036e0cf43d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-40fed912-c132-4247-91a0-47036e0cf43d">
											<gml:posList>35.669060101977344 139.7393778344732 36.283 35.669028673619515 139.73934642313029 36.283 35.669013800377776 139.73936877572007 36.283 35.66904522872986 139.73940018706597 36.283 35.669060101977344 139.7393778344732 36.283</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-8779edd3-03ab-42d7-8c81-6ffc5a95911e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8779edd3-03ab-42d7-8c81-6ffc5a95911e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8779edd3-03ab-42d7-8c81-6ffc5a95911e">
											<gml:posList>35.66900965052378 139.73924880921146 31.57 35.668940425933016 139.73935381697217 31.57 35.6689897962545 139.73940272632458 31.57 35.669001705788546 139.73938268584902 31.57 35.669029471540824 139.73941022431404 31.57 35.66901677717941 139.7394294593484 31.57 35.669087165700724 139.73949919919272 31.57 35.66913216285594 139.73943059451523 31.57 35.669119813591315 139.73941845828355 31.57 35.6691443826614 139.73938076234248 31.57 35.66908849987867 139.7393260392596 31.57 35.66905645758841 139.73937419353825 31.57 35.669060101977344 139.7393778344732 31.57 35.66904522872986 139.73940018706597 31.57 35.669013800377776 139.73936877572007 31.57 35.66905969701155 139.73929783925516 31.57 35.66900965052378 139.73924880921146 31.57</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-bc95a4d2-1110-4dd0-83f4-83e5f0b15f7f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bc95a4d2-1110-4dd0-83f4-83e5f0b15f7f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bc95a4d2-1110-4dd0-83f4-83e5f0b15f7f">
											<gml:posList>35.66900211437943 139.73938649626425 32.139 35.669001705788546 139.73938268584902 32.139 35.6689897962545 139.73940272632458 32.139 35.66899020483614 139.73940652569328 32.139 35.66900211437943 139.73938649626425 32.139</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e66b679b-d1ee-4bbd-9060-f407ffebc82c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e66b679b-d1ee-4bbd-9060-f407ffebc82c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e66b679b-d1ee-4bbd-9060-f407ffebc82c">
											<gml:posList>35.66902643421723 139.73941061448446 32.139 35.669029471540824 139.73941022431404 32.139 35.669001705788546 139.73938268584902 32.139 35.66900211437943 139.73938649626425 32.139 35.66902643421723 139.73941061448446 32.139</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-0e5002ee-fbc1-41e7-9060-2f07a067a5db">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0e5002ee-fbc1-41e7-9060-2f07a067a5db">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0e5002ee-fbc1-41e7-9060-2f07a067a5db">
											<gml:posList>35.669122850897644 139.73941804602083 32.139 35.669147428981326 139.73938035006762 32.139 35.6691443826614 139.73938076234248 32.139 35.669119813591315 139.73941845828355 32.139 35.669122850897644 139.73941804602083 32.139</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-dfa463a3-ee70-4488-982f-eca67b0f90c0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-dfa463a3-ee70-4488-982f-eca67b0f90c0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-dfa463a3-ee70-4488-982f-eca67b0f90c0">
											<gml:posList>35.66902643421723 139.73941061448446 12.683 35.66900211437943 139.73938649626425 12.683 35.66899020483614 139.73940652569328 12.683 35.66901373985574 139.73942984951802 12.683 35.66902643421723 139.73941061448446 12.683</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-00910fe6-85b2-4a7e-addd-5ec38de288de">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-00910fe6-85b2-4a7e-addd-5ec38de288de">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-00910fe6-85b2-4a7e-addd-5ec38de288de">
											<gml:posList>35.66902643421723 139.73941061448446 32.139 35.66901373985574 139.73942984951802 32.139 35.66901677717941 139.7394294593484 32.139 35.669029471540824 139.73941022431404 32.139 35.66902643421723 139.73941061448446 32.139</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-9d6a33d0-acfe-42a7-96fb-fa783772e586">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9d6a33d0-acfe-42a7-96fb-fa783772e586">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9d6a33d0-acfe-42a7-96fb-fa783772e586">
											<gml:posList>35.669122850897644 139.73941804602083 32.139 35.669119813591315 139.73941845828355 32.139 35.66913216285594 139.73943059451523 32.139 35.66913520917603 139.73943018224233 32.139 35.669122850897644 139.73941804602083 32.139</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-9a926d5b-7b92-4aef-bdb4-6afdc9c065cf">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9a926d5b-7b92-4aef-bdb4-6afdc9c065cf">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9a926d5b-7b92-4aef-bdb4-6afdc9c065cf">
											<gml:posList>35.66908749309554 139.73950292133893 32.139 35.669087165700724 139.73949919919272 32.139 35.66901677717941 139.7394294593484 32.139 35.66901373985574 139.73942984951802 32.139 35.66908749309554 139.73950292133893 32.139</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-20f1e63e-2977-4aa1-bd88-61b0265b5300">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-20f1e63e-2977-4aa1-bd88-61b0265b5300">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-20f1e63e-2977-4aa1-bd88-61b0265b5300">
											<gml:posList>35.66913520917603 139.73943018224233 32.139 35.66913216285594 139.73943059451523 32.139 35.669087165700724 139.73949919919272 32.139 35.66908749309554 139.73950292133893 32.139 35.66913520917603 139.73943018224233 32.139</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a977e4af-11fe-4289-8c73-41d2781f3f95">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a977e4af-11fe-4289-8c73-41d2781f3f95">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a977e4af-11fe-4289-8c73-41d2781f3f95">
											<gml:posList>35.66908849987867 139.7393260392596 32.139 35.66908849987867 139.7393260392596 31.57 35.6691443826614 139.73938076234248 31.57 35.6691443826614 139.73938076234248 32.139 35.66908849987867 139.7393260392596 32.139</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-cd2e781e-7fd7-4e93-949e-e6339be523ec">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cd2e781e-7fd7-4e93-949e-e6339be523ec">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cd2e781e-7fd7-4e93-949e-e6339be523ec">
											<gml:posList>35.66906272527789 139.73929739386054 11.49 35.66900932312112 139.73924508706986 11.49 35.66900932312112 139.73924508706986 32.139 35.66906272527789 139.73929739386054 32.139 35.66906272527789 139.73929739386054 11.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b8cf0e7c-7e54-40f7-9822-35e798e04ed5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b8cf0e7c-7e54-40f7-9822-35e798e04ed5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b8cf0e7c-7e54-40f7-9822-35e798e04ed5">
											<gml:posList>35.66900965052378 139.73924880921146 32.139 35.66900965052378 139.73924880921146 31.57 35.66905969701155 139.73929783925516 31.57 35.66905969701155 139.73929783925516 32.139 35.66900965052378 139.73924880921146 32.139</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5475c729-5f90-4d2b-80ef-c0d9da77e302">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5475c729-5f90-4d2b-80ef-c0d9da77e302">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5475c729-5f90-4d2b-80ef-c0d9da77e302">
											<gml:posList>35.66900932312112 139.73924508706986 11.49 35.668937388600945 139.73935419609822 11.49 35.668937388600945 139.73935419609822 32.139 35.66900932312112 139.73924508706986 32.139 35.66900932312112 139.73924508706986 11.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4ef89160-b43f-4008-98d6-fb7f5f011559">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4ef89160-b43f-4008-98d6-fb7f5f011559">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4ef89160-b43f-4008-98d6-fb7f5f011559">
											<gml:posList>35.668940425933016 139.73935381697217 32.139 35.668940425933016 139.73935381697217 31.57 35.66900965052378 139.73924880921146 31.57 35.66900965052378 139.73924880921146 32.139 35.668940425933016 139.73935381697217 32.139</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3c121194-490b-4932-b9ba-4aee68f5f056">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3c121194-490b-4932-b9ba-4aee68f5f056">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3c121194-490b-4932-b9ba-4aee68f5f056">
											<gml:posList>35.669028673619515 139.73934642313029 32.139 35.66905969701155 139.73929783925516 32.139 35.66905969701155 139.73929783925516 31.57 35.669028673619515 139.73934642313029 32.139</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-51c1436d-2c1c-4970-8571-f2f63d2fd843">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-51c1436d-2c1c-4970-8571-f2f63d2fd843">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-51c1436d-2c1c-4970-8571-f2f63d2fd843">
											<gml:posList>35.66903018911501 139.73934794571196 11.49 35.66906272527789 139.73929739386054 11.49 35.66906272527789 139.73929739386054 32.139 35.66903018911501 139.73934794571196 32.139 35.66903018911501 139.73934794571196 11.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1235ab3f-eacf-4ead-a426-6f2f7551cada">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1235ab3f-eacf-4ead-a426-6f2f7551cada">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1235ab3f-eacf-4ead-a426-6f2f7551cada">
											<gml:posList>35.669028673619515 139.73934642313029 32.139 35.66905969701155 139.73929783925516 31.57 35.669013800377776 139.73936877572007 31.57 35.669028673619515 139.73934642313029 32.139</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-efd869e0-9f68-451e-8d08-1aa8473b881c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-efd869e0-9f68-451e-8d08-1aa8473b881c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-efd869e0-9f68-451e-8d08-1aa8473b881c">
											<gml:posList>35.669088190514444 139.73932232813897 11.49 35.66905478874789 139.73937252753626 11.49 35.66905478874789 139.73937252753626 32.139 35.669088190514444 139.73932232813897 32.139 35.669088190514444 139.73932232813897 11.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-84dc5f83-178c-4f59-82da-fd26f64b09ba">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-84dc5f83-178c-4f59-82da-fd26f64b09ba">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-84dc5f83-178c-4f59-82da-fd26f64b09ba">
											<gml:posList>35.66905645758841 139.73937419353825 32.139 35.66905645758841 139.73937419353825 31.57 35.66908849987867 139.7393260392596 31.57 35.66908849987867 139.7393260392596 32.139 35.66905645758841 139.73937419353825 32.139</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-76951e3c-811c-4a64-a8b0-1309041d17d1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-76951e3c-811c-4a64-a8b0-1309041d17d1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-76951e3c-811c-4a64-a8b0-1309041d17d1">
											<gml:posList>35.669147428981326 139.73938035006762 11.49 35.669088190514444 139.73932232813897 11.49 35.669088190514444 139.73932232813897 32.139 35.669147428981326 139.73938035006762 32.139 35.669147428981326 139.73938035006762 11.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-fdf9cb9f-8ac4-4464-98b5-5ea00f9dd1f6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fdf9cb9f-8ac4-4464-98b5-5ea00f9dd1f6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fdf9cb9f-8ac4-4464-98b5-5ea00f9dd1f6">
											<gml:posList>35.669013800377776 139.73936877572007 31.57 35.669013800377776 139.73936877572007 36.283 35.669028673619515 139.73934642313029 36.283 35.669013800377776 139.73936877572007 31.57</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-88001d2a-f99d-49ac-829f-0d4cc778f989">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-88001d2a-f99d-49ac-829f-0d4cc778f989">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-88001d2a-f99d-49ac-829f-0d4cc778f989">
											<gml:posList>35.669028673619515 139.73934642313029 32.139 35.669013800377776 139.73936877572007 31.57 35.669028673619515 139.73934642313029 36.283 35.669028673619515 139.73934642313029 32.139</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2a945ba1-a3a4-4869-922d-49bd01653e16">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2a945ba1-a3a4-4869-922d-49bd01653e16">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2a945ba1-a3a4-4869-922d-49bd01653e16">
											<gml:posList>35.669060101977344 139.7393778344732 36.283 35.669060101977344 139.7393778344732 31.57 35.66905645758841 139.73937419353825 31.57 35.66905645758841 139.73937419353825 32.139 35.66905478874789 139.73937252753626 32.139 35.66905478874789 139.73937252753626 11.49 35.66903018911501 139.73934794571196 11.49 35.66903018911501 139.73934794571196 32.139 35.669028673619515 139.73934642313029 32.139 35.669028673619515 139.73934642313029 36.283 35.669060101977344 139.7393778344732 36.283</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8b9d04bf-f003-46df-9ea6-417e5191d866">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8b9d04bf-f003-46df-9ea6-417e5191d866">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8b9d04bf-f003-46df-9ea6-417e5191d866">
											<gml:posList>35.6689897962545 139.73940272632458 32.139 35.6689897962545 139.73940272632458 31.57 35.668940425933016 139.73935381697217 31.57 35.668940425933016 139.73935381697217 32.139 35.6689897962545 139.73940272632458 32.139</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3060df5c-e978-43cc-8dbf-e03725e4ccaf">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3060df5c-e978-43cc-8dbf-e03725e4ccaf">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3060df5c-e978-43cc-8dbf-e03725e4ccaf">
											<gml:posList>35.669013800377776 139.73936877572007 31.57 35.66904522872986 139.73940018706597 31.57 35.66904522872986 139.73940018706597 36.283 35.669013800377776 139.73936877572007 36.283 35.669013800377776 139.73936877572007 31.57</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-cd389f4c-7298-46f7-8bb8-cd5f8d058f8b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cd389f4c-7298-46f7-8bb8-cd5f8d058f8b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cd389f4c-7298-46f7-8bb8-cd5f8d058f8b">
											<gml:posList>35.66904522872986 139.73940018706597 31.57 35.669060101977344 139.7393778344732 31.57 35.669060101977344 139.7393778344732 36.283 35.66904522872986 139.73940018706597 36.283 35.66904522872986 139.73940018706597 31.57</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-397e5624-c9ce-4ad2-98b7-878b3fa5b1ba">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-397e5624-c9ce-4ad2-98b7-878b3fa5b1ba">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-397e5624-c9ce-4ad2-98b7-878b3fa5b1ba">
											<gml:posList>35.669001705788546 139.73938268584902 32.139 35.669001705788546 139.73938268584902 31.57 35.6689897962545 139.73940272632458 31.57 35.6689897962545 139.73940272632458 32.139 35.669001705788546 139.73938268584902 32.139</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-26195f00-4e2b-4859-b9a1-640cff0dccd0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-26195f00-4e2b-4859-b9a1-640cff0dccd0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-26195f00-4e2b-4859-b9a1-640cff0dccd0">
											<gml:posList>35.669029471540824 139.73941022431404 32.139 35.669029471540824 139.73941022431404 31.57 35.669001705788546 139.73938268584902 31.57 35.669001705788546 139.73938268584902 32.139 35.669029471540824 139.73941022431404 32.139</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-bf7b08c2-8372-4c39-b387-7c3b1fde93d8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bf7b08c2-8372-4c39-b387-7c3b1fde93d8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bf7b08c2-8372-4c39-b387-7c3b1fde93d8">
											<gml:posList>35.66900211437943 139.73938649626425 12.683 35.66900211437943 139.73938649626425 32.139 35.66899020483614 139.73940652569328 32.139 35.66899020483614 139.73940652569328 12.683 35.66900211437943 139.73938649626425 12.683</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-11e26956-6bff-4eee-be3e-dbbccb03b340">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-11e26956-6bff-4eee-be3e-dbbccb03b340">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-11e26956-6bff-4eee-be3e-dbbccb03b340">
											<gml:posList>35.66902643421723 139.73941061448446 12.683 35.66902643421723 139.73941061448446 32.139 35.66900211437943 139.73938649626425 32.139 35.66900211437943 139.73938649626425 12.683 35.66902643421723 139.73941061448446 12.683</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6610e2a9-5418-4092-9cae-b9ccc5fe78d7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6610e2a9-5418-4092-9cae-b9ccc5fe78d7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6610e2a9-5418-4092-9cae-b9ccc5fe78d7">
											<gml:posList>35.669122850897644 139.73941804602083 11.49 35.669147428981326 139.73938035006762 11.49 35.669147428981326 139.73938035006762 32.139 35.669122850897644 139.73941804602083 32.139 35.669122850897644 139.73941804602083 11.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-20be120b-4bdb-478f-bfd1-cbc8a9cdac2f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-20be120b-4bdb-478f-bfd1-cbc8a9cdac2f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-20be120b-4bdb-478f-bfd1-cbc8a9cdac2f">
											<gml:posList>35.6691443826614 139.73938076234248 32.139 35.6691443826614 139.73938076234248 31.57 35.669119813591315 139.73941845828355 31.57 35.669119813591315 139.73941845828355 32.139 35.6691443826614 139.73938076234248 32.139</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-53cf3dbc-342d-42a7-b7d2-d2a7d9da1715">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-53cf3dbc-342d-42a7-b7d2-d2a7d9da1715">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-53cf3dbc-342d-42a7-b7d2-d2a7d9da1715">
											<gml:posList>35.66901677717941 139.7394294593484 32.139 35.66901677717941 139.7394294593484 31.57 35.669029471540824 139.73941022431404 31.57 35.669029471540824 139.73941022431404 32.139 35.66901677717941 139.7394294593484 32.139</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-eeed2eff-e466-497d-b534-432d78d4b0ef">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-eeed2eff-e466-497d-b534-432d78d4b0ef">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-eeed2eff-e466-497d-b534-432d78d4b0ef">
											<gml:posList>35.66901373985574 139.73942984951802 12.683 35.66901373985574 139.73942984951802 32.139 35.66902643421723 139.73941061448446 32.139 35.66902643421723 139.73941061448446 12.683 35.66901373985574 139.73942984951802 12.683</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e9be99ec-15fd-4cc2-8094-caf0f870bf75">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e9be99ec-15fd-4cc2-8094-caf0f870bf75">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e9be99ec-15fd-4cc2-8094-caf0f870bf75">
											<gml:posList>35.66913520917603 139.73943018224233 11.49 35.669122850897644 139.73941804602083 11.49 35.669122850897644 139.73941804602083 32.139 35.66913520917603 139.73943018224233 32.139 35.66913520917603 139.73943018224233 11.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4f4cee0a-524f-4ead-b100-b01ded50c7f2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4f4cee0a-524f-4ead-b100-b01ded50c7f2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4f4cee0a-524f-4ead-b100-b01ded50c7f2">
											<gml:posList>35.669119813591315 139.73941845828355 32.139 35.669119813591315 139.73941845828355 31.57 35.66913216285594 139.73943059451523 31.57 35.66913216285594 139.73943059451523 32.139 35.669119813591315 139.73941845828355 32.139</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4243a6fc-4be0-43e8-97f6-d5a254c46364">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4243a6fc-4be0-43e8-97f6-d5a254c46364">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4243a6fc-4be0-43e8-97f6-d5a254c46364">
											<gml:posList>35.66908749309554 139.73950292133893 11.49 35.66908749309554 139.73950292133893 32.139 35.66901373985574 139.73942984951802 32.139 35.66901373985574 139.73942984951802 12.683 35.66899020483614 139.73940652569328 12.683 35.66899020483614 139.73940652569328 32.139 35.668937388600945 139.73935419609822 32.139 35.668937388600945 139.73935419609822 11.49 35.66908749309554 139.73950292133893 11.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-364d0d2c-d3ce-47b8-a8de-fcc3355cb646">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-364d0d2c-d3ce-47b8-a8de-fcc3355cb646">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-364d0d2c-d3ce-47b8-a8de-fcc3355cb646">
											<gml:posList>35.669087165700724 139.73949919919272 32.139 35.669087165700724 139.73949919919272 31.57 35.66901677717941 139.7394294593484 31.57 35.66901677717941 139.7394294593484 32.139 35.669087165700724 139.73949919919272 32.139</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c0daacbb-622c-49e0-a80e-ac4660ce577e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c0daacbb-622c-49e0-a80e-ac4660ce577e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c0daacbb-622c-49e0-a80e-ac4660ce577e">
											<gml:posList>35.66913216285594 139.73943059451523 32.139 35.66913216285594 139.73943059451523 31.57 35.669087165700724 139.73949919919272 31.57 35.669087165700724 139.73949919919272 32.139 35.66913216285594 139.73943059451523 32.139</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e5063028-d524-4bb3-beb8-6335f23a03c0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e5063028-d524-4bb3-beb8-6335f23a03c0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e5063028-d524-4bb3-beb8-6335f23a03c0">
											<gml:posList>35.66908749309554 139.73950292133893 11.49 35.66913520917603 139.73943018224233 11.49 35.66913520917603 139.73943018224233 32.139 35.66908749309554 139.73950292133893 32.139 35.66908749309554 139.73950292133893 11.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-8885</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">265.3305</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1210</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>4</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.11</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>