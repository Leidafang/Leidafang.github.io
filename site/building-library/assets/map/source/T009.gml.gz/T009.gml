<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_01487517-fa1c-4c3e-9918-b693ce4e8ef6">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>18</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103018002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">401</bldg:usage>
			<bldg:measuredHeight uom="m">38.4</bldg:measuredHeight>
			<bldg:storeysAboveGround>9</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>1</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.66889451692867 139.7481218316516 0 35.66889469282572 139.74811564567355 0 35.66889297623069 139.74811001400974 0 35.6688875644765 139.74810504903724 0 35.668819309216644 139.74807496588483 0 35.66883297871118 139.74803065670133 0 35.66868501632644 139.74796431703194 0 35.668660014601016 139.74804398547806 0 35.66879544285869 139.74810326912927 0 35.66879067574644 139.74811763405006 0 35.668823766520084 139.7481322901228 0 35.66880263098174 139.74819836791755 0 35.668800024731965 139.74820930626686 0 35.66880436334505 139.74822631256723 0 35.66881491619738 139.74823591142496 0 35.66882618632234 139.7482400969615 0 35.66884475335086 139.74823830988947 0 35.66886385042941 139.74822127870323 0 35.66889451692867 139.7481218316516 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66889451692867 139.7481218316516 5.62 35.66886385042941 139.74822127870323 5.62 35.66884475335086 139.74823830988947 5.62 35.66882618632234 139.7482400969615 5.62 35.66881491619738 139.74823591142496 5.62 35.66880436334505 139.74822631256723 5.62 35.668800024731965 139.74820930626686 5.62 35.66880263098174 139.74819836791755 5.62 35.668823766520084 139.7481322901228 5.62 35.66879067574644 139.74811763405006 5.62 35.66879544285869 139.74810326912927 5.62 35.668660014601016 139.74804398547806 5.62 35.66868501632644 139.74796431703194 5.62 35.66883297871118 139.74803065670133 5.62 35.668819309216644 139.74807496588483 5.62 35.6688875644765 139.74810504903724 5.62 35.66889297623069 139.74811001400974 5.62 35.66889469282572 139.74811564567355 5.62 35.66889451692867 139.7481218316516 5.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66889451692867 139.7481218316516 5.62 35.66889469282572 139.74811564567355 5.62 35.66889469282572 139.74811564567355 36.94 35.66889451692867 139.7481218316516 36.94 35.66889451692867 139.7481218316516 5.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66889469282572 139.74811564567355 5.62 35.66889297623069 139.74811001400974 5.62 35.66889297623069 139.74811001400974 36.94 35.66889469282572 139.74811564567355 36.94 35.66889469282572 139.74811564567355 5.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66889297623069 139.74811001400974 5.62 35.6688875644765 139.74810504903724 5.62 35.6688875644765 139.74810504903724 36.94 35.66889297623069 139.74811001400974 36.94 35.66889297623069 139.74811001400974 5.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6688875644765 139.74810504903724 5.62 35.668819309216644 139.74807496588483 5.62 35.668819309216644 139.74807496588483 36.94 35.6688875644765 139.74810504903724 36.94 35.6688875644765 139.74810504903724 5.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668819309216644 139.74807496588483 5.62 35.66883297871118 139.74803065670133 5.62 35.66883297871118 139.74803065670133 36.94 35.668819309216644 139.74807496588483 36.94 35.668819309216644 139.74807496588483 5.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66883297871118 139.74803065670133 5.62 35.66868501632644 139.74796431703194 5.62 35.66868501632644 139.74796431703194 36.94 35.66883297871118 139.74803065670133 36.94 35.66883297871118 139.74803065670133 5.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66868501632644 139.74796431703194 5.62 35.668660014601016 139.74804398547806 5.62 35.668660014601016 139.74804398547806 36.94 35.66868501632644 139.74796431703194 36.94 35.66868501632644 139.74796431703194 5.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668660014601016 139.74804398547806 5.62 35.66879544285869 139.74810326912927 5.62 35.66879544285869 139.74810326912927 36.94 35.668660014601016 139.74804398547806 36.94 35.668660014601016 139.74804398547806 5.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66879544285869 139.74810326912927 5.62 35.66879067574644 139.74811763405006 5.62 35.66879067574644 139.74811763405006 36.94 35.66879544285869 139.74810326912927 36.94 35.66879544285869 139.74810326912927 5.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66879067574644 139.74811763405006 5.62 35.668823766520084 139.7481322901228 5.62 35.668823766520084 139.7481322901228 36.94 35.66879067574644 139.74811763405006 36.94 35.66879067574644 139.74811763405006 5.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668823766520084 139.7481322901228 5.62 35.66880263098174 139.74819836791755 5.62 35.66880263098174 139.74819836791755 36.94 35.668823766520084 139.7481322901228 36.94 35.668823766520084 139.7481322901228 5.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66880263098174 139.74819836791755 5.62 35.668800024731965 139.74820930626686 5.62 35.668800024731965 139.74820930626686 36.94 35.66880263098174 139.74819836791755 36.94 35.66880263098174 139.74819836791755 5.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668800024731965 139.74820930626686 5.62 35.66880436334505 139.74822631256723 5.62 35.66880436334505 139.74822631256723 36.94 35.668800024731965 139.74820930626686 36.94 35.668800024731965 139.74820930626686 5.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66880436334505 139.74822631256723 5.62 35.66881491619738 139.74823591142496 5.62 35.66881491619738 139.74823591142496 36.94 35.66880436334505 139.74822631256723 36.94 35.66880436334505 139.74822631256723 5.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66881491619738 139.74823591142496 5.62 35.66882618632234 139.7482400969615 5.62 35.66882618632234 139.7482400969615 36.94 35.66881491619738 139.74823591142496 36.94 35.66881491619738 139.74823591142496 5.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66882618632234 139.7482400969615 5.62 35.66884475335086 139.74823830988947 5.62 35.66884475335086 139.74823830988947 36.94 35.66882618632234 139.7482400969615 36.94 35.66882618632234 139.7482400969615 5.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66884475335086 139.74823830988947 5.62 35.66886385042941 139.74822127870323 5.62 35.66886385042941 139.74822127870323 36.94 35.66884475335086 139.74823830988947 36.94 35.66884475335086 139.74823830988947 5.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66886385042941 139.74822127870323 5.62 35.66889451692867 139.7481218316516 5.62 35.66889451692867 139.7481218316516 36.94 35.66886385042941 139.74822127870323 36.94 35.66886385042941 139.74822127870323 5.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66889451692867 139.7481218316516 36.94 35.66889469282572 139.74811564567355 36.94 35.66889297623069 139.74811001400974 36.94 35.6688875644765 139.74810504903724 36.94 35.668819309216644 139.74807496588483 36.94 35.66883297871118 139.74803065670133 36.94 35.66868501632644 139.74796431703194 36.94 35.668660014601016 139.74804398547806 36.94 35.66879544285869 139.74810326912927 36.94 35.66879067574644 139.74811763405006 36.94 35.668823766520084 139.7481322901228 36.94 35.66880263098174 139.74819836791755 36.94 35.668800024731965 139.74820930626686 36.94 35.66880436334505 139.74822631256723 36.94 35.66881491619738 139.74823591142496 36.94 35.66882618632234 139.7482400969615 36.94 35.66884475335086 139.74823830988947 36.94 35.66886385042941 139.74822127870323 36.94 35.66889451692867 139.7481218316516 36.94</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-214177ce-4c91-4338-8576-c8f97961a287"/>
							<gml:surfaceMember xlink:href="#poly-21812210-f039-4e18-b4a5-9295aa65fc28"/>
							<gml:surfaceMember xlink:href="#poly-6b97799d-4629-4bb0-933e-b6e709cf65c3"/>
							<gml:surfaceMember xlink:href="#poly-3cc93346-46eb-4f7b-bc01-184c631bddb9"/>
							<gml:surfaceMember xlink:href="#poly-b711e233-b109-47ff-8839-38a401754147"/>
							<gml:surfaceMember xlink:href="#poly-f599aafd-48d7-4a48-b915-816b0d0239a4"/>
							<gml:surfaceMember xlink:href="#poly-53525968-7812-4062-aead-4858a24df982"/>
							<gml:surfaceMember xlink:href="#poly-b9d16a82-4cdd-41d7-99f7-e7ac89d00d3d"/>
							<gml:surfaceMember xlink:href="#poly-4d8b3f64-fe9f-4c10-bcfa-a1767d5d6d63"/>
							<gml:surfaceMember xlink:href="#poly-c4b09e4e-19e7-4df5-8bec-914299069cc9"/>
							<gml:surfaceMember xlink:href="#poly-54765790-9551-401b-8824-d72cceac7ae7"/>
							<gml:surfaceMember xlink:href="#poly-13ff1519-43ba-4bd2-a5fd-c18afdda89f7"/>
							<gml:surfaceMember xlink:href="#poly-32cb03ca-5d8d-491f-a081-9293431fb5d2"/>
							<gml:surfaceMember xlink:href="#poly-16263fda-9005-4843-8cb3-d59a6d477539"/>
							<gml:surfaceMember xlink:href="#poly-cc21bb7c-dd6f-4c1f-a20a-6654ef731b1c"/>
							<gml:surfaceMember xlink:href="#poly-f91c4ece-a62c-4eb4-9097-cec0ea8646b9"/>
							<gml:surfaceMember xlink:href="#poly-20dbfe17-714b-415a-8a14-f4b60c07df04"/>
							<gml:surfaceMember xlink:href="#poly-bc5a7f4f-2a8f-4058-8910-cc70edebaa24"/>
							<gml:surfaceMember xlink:href="#poly-bf4d38bd-32b0-477b-894b-26b3d7f523f0"/>
							<gml:surfaceMember xlink:href="#poly-0b7231d7-fb76-4c7f-ab17-59f2df6984cd"/>
							<gml:surfaceMember xlink:href="#poly-37a5b14f-e916-43fd-bf7d-1e7f80e30989"/>
							<gml:surfaceMember xlink:href="#poly-b0b4be20-76ca-4a76-86c6-3d55e450ecc7"/>
							<gml:surfaceMember xlink:href="#poly-27673680-44fd-4769-994a-f89bbfff4584"/>
							<gml:surfaceMember xlink:href="#poly-1372e97d-4725-44d3-bb83-dab3b1dc35fb"/>
							<gml:surfaceMember xlink:href="#poly-285327bb-c938-4de8-b748-33b85c97c16b"/>
							<gml:surfaceMember xlink:href="#poly-5f305951-db92-47c7-bd58-ca014a157b66"/>
							<gml:surfaceMember xlink:href="#poly-4a8b47bd-96dd-47a8-82d7-35b186974d57"/>
							<gml:surfaceMember xlink:href="#poly-444b8493-713d-41ac-9ce1-b7023f306dec"/>
							<gml:surfaceMember xlink:href="#poly-7cd76414-373a-42ef-8703-66d21cbcd134"/>
							<gml:surfaceMember xlink:href="#poly-7a67e22c-5939-4b84-b87b-ff99a1744717"/>
							<gml:surfaceMember xlink:href="#poly-c44f0404-254c-4f3e-8194-e63a18f51414"/>
							<gml:surfaceMember xlink:href="#poly-f7980ba7-8d40-4b98-9602-5711d524ef3c"/>
							<gml:surfaceMember xlink:href="#poly-da3d2b7c-5bb7-4772-9fb9-1c076a3429aa"/>
							<gml:surfaceMember xlink:href="#poly-a50d06be-f3f3-4596-b1b5-27ec4eb16c61"/>
							<gml:surfaceMember xlink:href="#poly-19d85d53-084c-4c68-be32-197c6ccc8e9b"/>
							<gml:surfaceMember xlink:href="#poly-1224f85e-bf21-4434-ae1e-d9a8a3f09095"/>
							<gml:surfaceMember xlink:href="#poly-3d027792-bf70-46c3-8bde-cdf0e15e5ee8"/>
							<gml:surfaceMember xlink:href="#poly-adcd7921-3d64-47f8-8e4d-f92b6006717d"/>
							<gml:surfaceMember xlink:href="#poly-705fb28f-9454-455d-bc0c-1ebae84b63e9"/>
							<gml:surfaceMember xlink:href="#poly-25f19c7b-8366-427b-b906-3e1f7ae20f21"/>
							<gml:surfaceMember xlink:href="#poly-7f8fde74-3de4-4371-bf49-4b83af615a4b"/>
							<gml:surfaceMember xlink:href="#poly-ad8336b7-8c91-4574-a2ee-de98edc07632"/>
							<gml:surfaceMember xlink:href="#poly-88896163-a484-496b-92a9-4d0efcfdbc48"/>
							<gml:surfaceMember xlink:href="#poly-1cdf3467-07b1-47cb-b47e-7696c9a33949"/>
							<gml:surfaceMember xlink:href="#poly-4e7dc469-8d51-4c58-8d3f-d277bc5ad8b9"/>
							<gml:surfaceMember xlink:href="#poly-9783459b-621b-4dac-8c01-14cae9c58d7f"/>
							<gml:surfaceMember xlink:href="#poly-4d17d2f5-dc13-4bbc-9ce9-e483d0752d9d"/>
							<gml:surfaceMember xlink:href="#poly-ef46685a-293e-43d3-ad85-7b90fa516afc"/>
							<gml:surfaceMember xlink:href="#poly-de7e0230-bd21-4e5a-9d52-7d98c836abf8"/>
							<gml:surfaceMember xlink:href="#poly-ad28e1db-5553-4bdd-8f49-a07129b2a334"/>
							<gml:surfaceMember xlink:href="#poly-2bd1ba47-9f4c-4ccc-9733-934727a397d5"/>
							<gml:surfaceMember xlink:href="#poly-799b902c-81e1-4c61-93eb-e3deb201050f"/>
							<gml:surfaceMember xlink:href="#poly-d8f1aab5-b015-4c2c-87f7-34089562dfd4"/>
							<gml:surfaceMember xlink:href="#poly-356d1a64-1681-4102-8474-788da886003c"/>
							<gml:surfaceMember xlink:href="#poly-ff747c10-1200-4830-b003-f8eef17e89b6"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_01487517-fa1c-4c3e-9918-b693ce4e8ef6_BuildingInstallation_1061">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4698e149-e553-4d64-9b8b-0ec3f8da33fe">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668671507869824 139.7480450557632 37.8 35.66875958132471 139.74808361216458 37.8 35.66875905976412 139.74808535799292 37.8 35.66867121112879 139.7480460612671 37.8 35.668671507869824 139.7480450557632 37.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-06c4d596-257c-46cf-bb12-b11a8ab73871">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66878666740181 139.74801970411366 37.253 35.66869368830624 139.7479781153338 37.253 35.66867377026839 139.7480449870806 37.253 35.668759644272214 139.74808340222296 37.253 35.66875958132471 139.74808361216458 37.253 35.668671507869824 139.7480450557632 37.253 35.66869243304135 139.74797479181572 37.253 35.66878937943795 139.7480181547823 37.253 35.66878604328833 139.7480293700632 37.253 35.66878404164623 139.7480285326936 37.253 35.66878666740181 139.74801970411366 37.253</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ffb1b7fc-7f0a-4e87-ba06-15f1c91bfc21">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668801552649164 139.74811385578977 37.253 35.6688336156864 139.74812826994207 37.253 35.668810352112594 139.74820597044376 37.253 35.668853289152146 139.74822526649183 37.253 35.66888645344294 139.74811447250258 37.253 35.668816953469985 139.74808323083124 37.253 35.6688174120283 139.74808161762112 37.253 35.66888848990417 139.7481135645617 37.253 35.66885430047738 139.7482277949638 37.253 35.668808225653926 139.74820707730572 37.253 35.66883123744594 139.74813022761955 37.253 35.66879916539519 139.7481158134765 37.253 35.66880207894753 139.74810606777024 37.253 35.66880367486192 139.74810675092857 37.253 35.668801552649164 139.74811385578977 37.253</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7c629843-8d5f-4ed8-8457-ef90d2cbc963">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7c629843-8d5f-4ed8-8457-ef90d2cbc963_0">
											<gml:posList>35.66869243304135 139.74797479181572 38.185 35.66878937943795 139.7480181547823 38.185 35.66878937943795 139.7480181547823 37.253 35.66869243304135 139.74797479181572 37.253 35.66869243304135 139.74797479181572 38.185</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d1c79d52-b5c8-46b5-9296-3f9a7a8967aa">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d1c79d52-b5c8-46b5-9296-3f9a7a8967aa_0">
											<gml:posList>35.66869368830624 139.7479781153338 37.253 35.66878666740181 139.74801970411366 37.253 35.66878666740181 139.74801970411366 38.185 35.66869368830624 139.7479781153338 38.185 35.66869368830624 139.7479781153338 37.253</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bda391c1-5bbc-4dbb-96cc-f7edc64fdccc">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bda391c1-5bbc-4dbb-96cc-f7edc64fdccc_0">
											<gml:posList>35.66867121112879 139.7480460612671 38.185 35.66869243304135 139.74797479181572 38.185 35.66869243304135 139.74797479181572 37.253 35.668671507869824 139.7480450557632 37.253 35.668671507869824 139.7480450557632 37.8 35.66867121112879 139.7480460612671 37.8 35.66867121112879 139.7480460612671 38.185</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-424481d4-1faf-4418-a156-0c38548908ba">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-424481d4-1faf-4418-a156-0c38548908ba_0">
											<gml:posList>35.66867377026839 139.7480449870806 37.253 35.66869368830624 139.7479781153338 37.253 35.66869368830624 139.7479781153338 38.185 35.66867377026839 139.7480449870806 38.185 35.66867377026839 139.7480449870806 37.253</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-86f1b084-8d2e-4e88-9f66-619895205806">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-86f1b084-8d2e-4e88-9f66-619895205806_0">
											<gml:posList>35.66878604328833 139.7480293700632 37.253 35.66878937943795 139.7480181547823 37.253 35.66878937943795 139.7480181547823 38.185 35.66878604328833 139.7480293700632 38.185 35.66878604328833 139.7480293700632 37.253</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-43c5318a-2e49-4305-9cfa-4707a1389f73">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-43c5318a-2e49-4305-9cfa-4707a1389f73_0">
											<gml:posList>35.66878666740181 139.74801970411366 37.253 35.66878404164623 139.7480285326936 37.253 35.66878404164623 139.7480285326936 38.185 35.66878666740181 139.74801970411366 38.185 35.66878666740181 139.74801970411366 37.253</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c23ab183-e9b3-4d64-bcf9-a5c977f86151">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c23ab183-e9b3-4d64-bcf9-a5c977f86151_0">
											<gml:posList>35.66878404164623 139.7480285326936 37.253 35.66878604328833 139.7480293700632 37.253 35.66878604328833 139.7480293700632 38.185 35.66878404164623 139.7480285326936 38.185 35.66878404164623 139.7480285326936 37.253</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1205b642-db74-449c-b722-90778f31f4fd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1205b642-db74-449c-b722-90778f31f4fd_0">
											<gml:posList>35.66878604328833 139.7480293700632 38.185 35.66878937943795 139.7480181547823 38.185 35.66869243304135 139.74797479181572 38.185 35.66867121112879 139.7480460612671 38.185 35.66875905976412 139.74808535799292 38.185 35.668759644272214 139.74808340222296 38.185 35.66867377026839 139.7480449870806 38.185 35.66869368830624 139.7479781153338 38.185 35.66878666740181 139.74801970411366 38.185 35.66878404164623 139.7480285326936 38.185 35.66878604328833 139.7480293700632 38.185</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2cca6c9b-f1bb-460c-ac73-7a0fdfcf8ca5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2cca6c9b-f1bb-460c-ac73-7a0fdfcf8ca5_0">
											<gml:posList>35.668759644272214 139.74808340222296 37.253 35.66867377026839 139.7480449870806 37.253 35.66867377026839 139.7480449870806 38.185 35.668759644272214 139.74808340222296 38.185 35.668759644272214 139.74808340222296 37.253</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3208a247-20c8-483c-9969-19e711577fb6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3208a247-20c8-483c-9969-19e711577fb6_0">
											<gml:posList>35.66875958132471 139.74808361216458 37.253 35.66875958132471 139.74808361216458 37.8 35.668671507869824 139.7480450557632 37.8 35.668671507869824 139.7480450557632 37.253 35.66875958132471 139.74808361216458 37.253</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bd7c75a4-dd7e-44c0-994e-24d8aa992bbd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bd7c75a4-dd7e-44c0-994e-24d8aa992bbd_0">
											<gml:posList>35.66875905976412 139.74808535799292 37.8 35.66875905976412 139.74808535799292 38.185 35.66867121112879 139.7480460612671 38.185 35.66867121112879 139.7480460612671 37.8 35.66875905976412 139.74808535799292 37.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3988aaad-f2cb-468d-a640-de29f36e46af">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3988aaad-f2cb-468d-a640-de29f36e46af_0">
											<gml:posList>35.6688174120283 139.74808161762112 37.253 35.668816953469985 139.74808323083124 37.253 35.668816953469985 139.74808323083124 38.302 35.6688174120283 139.74808161762112 38.302 35.6688174120283 139.74808161762112 37.253</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d73beedb-8aca-4e84-b627-eaace9c6a0a5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d73beedb-8aca-4e84-b627-eaace9c6a0a5_0">
											<gml:posList>35.668759644272214 139.74808340222296 37.253 35.668759644272214 139.74808340222296 38.185 35.66875905976412 139.74808535799292 38.185 35.66875905976412 139.74808535799292 37.8 35.66875958132471 139.74808361216458 37.8 35.66875958132471 139.74808361216458 37.253 35.668759644272214 139.74808340222296 37.253</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c1cfb2a0-9797-42ca-9d00-43614c710828">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c1cfb2a0-9797-42ca-9d00-43614c710828_0">
											<gml:posList>35.6688174120283 139.74808161762112 37.253 35.6688174120283 139.74808161762112 38.302 35.66888848990417 139.7481135645617 38.302 35.66888848990417 139.7481135645617 37.253 35.6688174120283 139.74808161762112 37.253</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d6d0c804-bffd-4171-bc8a-48d67658e52d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d6d0c804-bffd-4171-bc8a-48d67658e52d_0">
											<gml:posList>35.668816953469985 139.74808323083124 37.253 35.66888645344294 139.74811447250258 37.253 35.66888645344294 139.74811447250258 38.302 35.668816953469985 139.74808323083124 38.302 35.668816953469985 139.74808323083124 37.253</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-dbc84da0-0d15-46f3-b6c4-d9942d2f0827">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-dbc84da0-0d15-46f3-b6c4-d9942d2f0827_0">
											<gml:posList>35.66880367486192 139.74810675092857 37.253 35.66880207894753 139.74810606777024 37.253 35.66880207894753 139.74810606777024 38.302 35.66880367486192 139.74810675092857 38.302 35.66880367486192 139.74810675092857 37.253</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-eac5e671-a82c-468f-ac90-c4199c07dd83">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-eac5e671-a82c-468f-ac90-c4199c07dd83_0">
											<gml:posList>35.668801552649164 139.74811385578977 37.253 35.66880367486192 139.74810675092857 37.253 35.66880367486192 139.74810675092857 38.302 35.668801552649164 139.74811385578977 38.302 35.668801552649164 139.74811385578977 37.253</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-244d1a7d-97ed-486e-b684-c32e295b2d2e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-244d1a7d-97ed-486e-b684-c32e295b2d2e_0">
											<gml:posList>35.66880207894753 139.74810606777024 37.253 35.66879916539519 139.7481158134765 37.253 35.66879916539519 139.7481158134765 38.302 35.66880207894753 139.74810606777024 38.302 35.66880207894753 139.74810606777024 37.253</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0e856f90-3044-40be-9e19-8cb622572fb8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0e856f90-3044-40be-9e19-8cb622572fb8_0">
											<gml:posList>35.668801552649164 139.74811385578977 37.253 35.668801552649164 139.74811385578977 38.302 35.6688336156864 139.74812826994207 38.302 35.6688336156864 139.74812826994207 37.253 35.668801552649164 139.74811385578977 37.253</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1626a0d5-eade-4b06-93dc-481be1187130">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1626a0d5-eade-4b06-93dc-481be1187130_0">
											<gml:posList>35.66883123744594 139.74813022761955 37.253 35.66883123744594 139.74813022761955 38.302 35.66879916539519 139.7481158134765 38.302 35.66879916539519 139.7481158134765 37.253 35.66883123744594 139.74813022761955 37.253</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e06c54d4-2893-48f4-9e0d-9c4f3ae39885">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e06c54d4-2893-48f4-9e0d-9c4f3ae39885_0">
											<gml:posList>35.66880207894753 139.74810606777024 38.302 35.66879916539519 139.7481158134765 38.302 35.66883123744594 139.74813022761955 38.302 35.668808225653926 139.74820707730572 38.302 35.66885430047738 139.7482277949638 38.302 35.66888848990417 139.7481135645617 38.302 35.6688174120283 139.74808161762112 38.302 35.668816953469985 139.74808323083124 38.302 35.66888645344294 139.74811447250258 38.302 35.668853289152146 139.74822526649183 38.302 35.668810352112594 139.74820597044376 38.302 35.6688336156864 139.74812826994207 38.302 35.668801552649164 139.74811385578977 38.302 35.66880367486192 139.74810675092857 38.302 35.66880207894753 139.74810606777024 38.302</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0acc5855-8949-4416-82ca-e61c621ce97a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0acc5855-8949-4416-82ca-e61c621ce97a_0">
											<gml:posList>35.6688336156864 139.74812826994207 37.253 35.6688336156864 139.74812826994207 38.302 35.668810352112594 139.74820597044376 38.302 35.668810352112594 139.74820597044376 37.253 35.6688336156864 139.74812826994207 37.253</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-68bd63dc-0a18-41cc-bbff-5a9711ed849b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-68bd63dc-0a18-41cc-bbff-5a9711ed849b_0">
											<gml:posList>35.66883123744594 139.74813022761955 37.253 35.668808225653926 139.74820707730572 37.253 35.668808225653926 139.74820707730572 38.302 35.66883123744594 139.74813022761955 38.302 35.66883123744594 139.74813022761955 37.253</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8efbb1c4-90f8-4e0f-ab24-62c9fe4c7b39">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8efbb1c4-90f8-4e0f-ab24-62c9fe4c7b39_0">
											<gml:posList>35.668853289152146 139.74822526649183 37.253 35.668853289152146 139.74822526649183 38.302 35.66888645344294 139.74811447250258 38.302 35.66888645344294 139.74811447250258 37.253 35.668853289152146 139.74822526649183 37.253</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-209e13bc-2211-40d6-8068-a97dcb8208c5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-209e13bc-2211-40d6-8068-a97dcb8208c5_0">
											<gml:posList>35.66888848990417 139.7481135645617 38.302 35.66885430047738 139.7482277949638 38.302 35.66885430047738 139.7482277949638 37.253 35.66888848990417 139.7481135645617 37.253 35.66888848990417 139.7481135645617 38.302</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-301db9c3-d683-4cef-abcc-a155e9c54526">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-301db9c3-d683-4cef-abcc-a155e9c54526_0">
											<gml:posList>35.668810352112594 139.74820597044376 38.302 35.668853289152146 139.74822526649183 38.302 35.668853289152146 139.74822526649183 37.253 35.668810352112594 139.74820597044376 37.253 35.668810352112594 139.74820597044376 38.302</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-90cc69cf-627f-4def-8a5a-d1dd9d46b3e9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-90cc69cf-627f-4def-8a5a-d1dd9d46b3e9_0">
											<gml:posList>35.66885430047738 139.7482277949638 38.302 35.668808225653926 139.74820707730572 38.302 35.668808225653926 139.74820707730572 37.253 35.66885430047738 139.7482277949638 37.253 35.66885430047738 139.7482277949638 38.302</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_01487517-fa1c-4c3e-9918-b693ce4e8ef6_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4b58e868-d9d0-4294-b74a-d42fa0773215">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4b58e868-d9d0-4294-b74a-d42fa0773215_0">
											<gml:posList>35.66878344821138 139.74803060998053 49.677 35.66877789408882 139.74802826308294 37.253 35.66878344821138 139.74803060998053 37.253 35.66878344821138 139.74803060998053 49.677</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ce5a2597-a6ed-4566-8cc8-c5ad4c9e3469">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ce5a2597-a6ed-4566-8cc8-c5ad4c9e3469_0">
											<gml:posList>35.66878344821138 139.74803060998053 49.677 35.66877789408882 139.74802826308294 49.677 35.66877789408882 139.74802826308294 37.253 35.66878344821138 139.74803060998053 49.677</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0d20210f-b338-4e66-b2ed-ccf0d99a0309">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0d20210f-b338-4e66-b2ed-ccf0d99a0309_0">
											<gml:posList>35.66878544986129 139.74803145839616 49.677 35.66878344821138 139.74803060998053 37.253 35.66878544986129 139.74803145839616 37.253 35.66878544986129 139.74803145839616 49.677</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e2d39459-a24e-41ad-943c-c9efd329681d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e2d39459-a24e-41ad-943c-c9efd329681d_0">
											<gml:posList>35.66878544986129 139.74803145839616 49.677 35.66878344821138 139.74803060998053 49.677 35.66878344821138 139.74803060998053 37.253 35.66878544986129 139.74803145839616 49.677</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ebec8d11-93bb-4502-b6a5-d3e5c7bf2fb5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ebec8d11-93bb-4502-b6a5-d3e5c7bf2fb5_0">
											<gml:posList>35.668825012344854 139.74804588662775 37.8 35.668776810453934 139.74802545854183 49.677 35.668827672192286 139.74804701049527 49.677 35.668825012344854 139.74804588662775 37.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9d3da55b-a032-44f4-be4c-132ee6f3a0e8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9d3da55b-a032-44f4-be4c-132ee6f3a0e8_0">
											<gml:posList>35.668827672192286 139.74804701049527 49.677 35.668827672192286 139.74804701049527 37.8 35.668825012344854 139.74804588662775 37.8 35.668827672192286 139.74804701049527 49.677</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-23f96416-55c5-4ffd-aa11-b414359f8128">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-23f96416-55c5-4ffd-aa11-b414359f8128_0">
											<gml:posList>35.668776810453934 139.74802545854183 37.253 35.668776810453934 139.74802545854183 49.677 35.668825012344854 139.74804588662775 37.8 35.668776810453934 139.74802545854183 37.253</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ca18d784-29f5-4a90-9394-077f4824ee66">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ca18d784-29f5-4a90-9394-077f4824ee66_0">
											<gml:posList>35.668825012344854 139.74804588662775 37.253 35.668776810453934 139.74802545854183 37.253 35.668825012344854 139.74804588662775 37.8 35.668825012344854 139.74804588662775 37.253</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e898c2b9-07b9-461a-8e58-fa254af1ac29">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e898c2b9-07b9-461a-8e58-fa254af1ac29_0">
											<gml:posList>35.66882437383325 139.7480479529175 37.253 35.66882437383325 139.7480479529175 37.8 35.66878544986129 139.74803145839616 37.253 35.66882437383325 139.7480479529175 37.253</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3cad02a7-47c8-4fa3-be8f-4e6bc5f1e386">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3cad02a7-47c8-4fa3-be8f-4e6bc5f1e386_0">
											<gml:posList>35.66878544986129 139.74803145839616 37.253 35.66882437383325 139.7480479529175 37.8 35.66878544986129 139.74803145839616 49.677 35.66878544986129 139.74803145839616 37.253</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-87d72449-bce5-4b8d-afdc-b2e3c89eb3cb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-87d72449-bce5-4b8d-afdc-b2e3c89eb3cb_0">
											<gml:posList>35.66878544986129 139.74803145839616 49.677 35.66882437383325 139.7480479529175 37.8 35.668825329577764 139.74804836060463 49.677 35.66878544986129 139.74803145839616 49.677</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cd0d6ad7-7318-45a8-abe3-11164cc4ae32">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cd0d6ad7-7318-45a8-abe3-11164cc4ae32_0">
											<gml:posList>35.66882437383325 139.7480479529175 37.8 35.668825329577764 139.74804836060463 37.8 35.668825329577764 139.74804836060463 49.677 35.66882437383325 139.7480479529175 37.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9fffa4c9-53c9-4ff2-a14b-d2fea13f2db6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9fffa4c9-53c9-4ff2-a14b-d2fea13f2db6_0">
											<gml:posList>35.668825012344854 139.74804588662775 37.253 35.66882437383325 139.7480479529175 37.8 35.66882437383325 139.7480479529175 37.253 35.668825012344854 139.74804588662775 37.253</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-58f74cd3-aaf7-449c-9e26-36c51abb16c6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-58f74cd3-aaf7-449c-9e26-36c51abb16c6_0">
											<gml:posList>35.668825012344854 139.74804588662775 37.253 35.668825012344854 139.74804588662775 37.8 35.66882437383325 139.7480479529175 37.8 35.668825012344854 139.74804588662775 37.253</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f7d4fb77-3c00-43ea-b35d-b1a668da4b2e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f7d4fb77-3c00-43ea-b35d-b1a668da4b2e_0">
											<gml:posList>35.66877789408882 139.74802826308294 37.253 35.66876142038308 139.74808397472853 49.677 35.66876142038308 139.74808397472853 37.253 35.66877789408882 139.74802826308294 37.253</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f7ed3226-355b-4221-991d-78d532f99882">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f7ed3226-355b-4221-991d-78d532f99882_0">
											<gml:posList>35.66877789408882 139.74802826308294 37.253 35.66877789408882 139.74802826308294 49.677 35.66876142038308 139.74808397472853 49.677 35.66877789408882 139.74802826308294 37.253</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-597195e9-22b5-461b-9119-c97a01d5c246">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-597195e9-22b5-461b-9119-c97a01d5c246_0">
											<gml:posList>35.66875960837371 139.74808362318183 37.253 35.66875960837371 139.74808362318183 37.8 35.668776810453934 139.74802545854183 37.253 35.66875960837371 139.74808362318183 37.253</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7b63ff34-f6bd-433a-b7f4-ae8641b96b45">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7b63ff34-f6bd-433a-b7f4-ae8641b96b45_0">
											<gml:posList>35.668776810453934 139.74802545854183 37.253 35.66875960837371 139.74808362318183 37.8 35.668776810453934 139.74802545854183 49.677 35.668776810453934 139.74802545854183 37.253</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-889f8d92-37a3-46d3-8a83-1898d8575604">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-889f8d92-37a3-46d3-8a83-1898d8575604_0">
											<gml:posList>35.668776810453934 139.74802545854183 49.677 35.66875960837371 139.74808362318183 37.8 35.66875914977627 139.74808518116063 49.677 35.668776810453934 139.74802545854183 49.677</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-02319e38-84e6-497c-bd3c-3246b99b0aa2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-02319e38-84e6-497c-bd3c-3246b99b0aa2_0">
											<gml:posList>35.66875914977627 139.74808518116063 49.677 35.66875960837371 139.74808362318183 37.8 35.66875862822348 139.748086938035 37.8 35.66875914977627 139.74808518116063 49.677</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fb606c7f-70a9-4d30-9d23-73786ce28be8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fb606c7f-70a9-4d30-9d23-73786ce28be8_0">
											<gml:posList>35.66875914977627 139.74808518116063 49.677 35.66875862822348 139.748086938035 37.8 35.66875862822348 139.748086938035 49.677 35.66875914977627 139.74808518116063 49.677</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a26a5154-a753-4d59-99d5-44ea052bc897">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a26a5154-a753-4d59-99d5-44ea052bc897_0">
											<gml:posList>35.668809475462865 139.7480625605879 47.07 35.6687909196667 139.74805474867807 37.253 35.6687909196667 139.74805474867807 47.07 35.668809475462865 139.7480625605879 47.07</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-872f4e15-4909-4568-853f-a7db20f26f94">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-872f4e15-4909-4568-853f-a7db20f26f94_0">
											<gml:posList>35.668809475462865 139.7480625605879 47.07 35.668809475462865 139.7480625605879 37.253 35.6687909196667 139.74805474867807 37.253 35.668809475462865 139.7480625605879 47.07</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-df279e62-bf7c-420e-bfb8-4a0f64e7d168">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-df279e62-bf7c-420e-bfb8-4a0f64e7d168_0">
											<gml:posList>35.6687909196667 139.74805474867807 47.07 35.66878778177655 139.7480659085166 37.253 35.66878778177655 139.7480659085166 47.07 35.6687909196667 139.74805474867807 47.07</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3eae4c45-1396-4db5-aa13-3afc27cc8950">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3eae4c45-1396-4db5-aa13-3afc27cc8950_0">
											<gml:posList>35.6687909196667 139.74805474867807 47.07 35.6687909196667 139.74805474867807 37.253 35.66878778177655 139.7480659085166 37.253 35.6687909196667 139.74805474867807 47.07</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-97bad6d5-5174-40cf-b95e-e3ff776e5b40">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-97bad6d5-5174-40cf-b95e-e3ff776e5b40_0">
											<gml:posList>35.668827672192286 139.74804701049527 37.8 35.668819038765704 139.74807491094217 49.677 35.668819038765704 139.74807491094217 37.8 35.668827672192286 139.74804701049527 37.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7224dbf0-ac21-4864-ad63-b82357265574">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7224dbf0-ac21-4864-ad63-b82357265574_0">
											<gml:posList>35.668827672192286 139.74804701049527 37.8 35.668827672192286 139.74804701049527 49.677 35.668819038765704 139.74807491094217 49.677 35.668827672192286 139.74804701049527 37.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c08b04cb-1afd-4fb0-8a19-210f7202db26">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c08b04cb-1afd-4fb0-8a19-210f7202db26_0">
											<gml:posList>35.66881735265912 139.74807415055793 37.8 35.668825329577764 139.74804836060463 49.677 35.668825329577764 139.74804836060463 37.8 35.66881735265912 139.74807415055793 37.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-531fa373-b84b-48c3-a9e4-b82fc64839d3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-531fa373-b84b-48c3-a9e4-b82fc64839d3_0">
											<gml:posList>35.66881735265912 139.74807415055793 37.8 35.66881735265912 139.74807415055793 49.677 35.668825329577764 139.74804836060463 49.677 35.66881735265912 139.74807415055793 37.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-570fddf2-32bc-4d5f-99ed-4bcfdaa8ac73">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-570fddf2-32bc-4d5f-99ed-4bcfdaa8ac73_0">
											<gml:posList>35.6687909196667 139.74805474867807 47.07 35.66880634659354 139.74807373146518 47.07 35.668809475462865 139.7480625605879 47.07 35.6687909196667 139.74805474867807 47.07</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-634f4f06-caa9-4c09-b6b3-eafc4c2fdc40">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-634f4f06-caa9-4c09-b6b3-eafc4c2fdc40_0">
											<gml:posList>35.6687909196667 139.74805474867807 47.07 35.66878778177655 139.7480659085166 47.07 35.66880634659354 139.74807373146518 47.07 35.6687909196667 139.74805474867807 47.07</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-35be7f2d-cba4-41ca-ada8-f3d4003dfd3c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-35be7f2d-cba4-41ca-ada8-f3d4003dfd3c_0">
											<gml:posList>35.66875862822348 139.748086938035 49.677 35.6687956498851 139.74810286020562 49.677 35.66876093479919 139.74808561005827 49.677 35.66875862822348 139.748086938035 49.677</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-75c3eedd-1e41-4b7e-8c5c-ccc43f738ec0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-75c3eedd-1e41-4b7e-8c5c-ccc43f738ec0_0">
											<gml:posList>35.66875914977627 139.74808518116063 49.677 35.66877789408882 139.74802826308294 49.677 35.668776810453934 139.74802545854183 49.677 35.66875914977627 139.74808518116063 49.677</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-94631176-c629-4633-855f-bb05d1e49109">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-94631176-c629-4633-855f-bb05d1e49109_0">
											<gml:posList>35.66875914977627 139.74808518116063 49.677 35.66875862822348 139.748086938035 49.677 35.66876093479919 139.74808561005827 49.677 35.66875914977627 139.74808518116063 49.677</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9d71940a-8bd9-445b-8d3f-426cdeb7493d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9d71940a-8bd9-445b-8d3f-426cdeb7493d_0">
											<gml:posList>35.668776810453934 139.74802545854183 49.677 35.66878544986129 139.74803145839616 49.677 35.668827672192286 139.74804701049527 49.677 35.668776810453934 139.74802545854183 49.677</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-30b3a1a8-5566-41e1-98d2-d6c8b7f0e3bc">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-30b3a1a8-5566-41e1-98d2-d6c8b7f0e3bc_0">
											<gml:posList>35.66880863189574 139.74810601662082 49.677 35.6687956498851 139.74810286020562 49.677 35.66880974256993 139.7481088211354 49.677 35.66880863189574 139.74810601662082 49.677</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a03f38c7-e347-422a-ab1d-07c6faf806c1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a03f38c7-e347-422a-ab1d-07c6faf806c1_0">
											<gml:posList>35.668825329577764 139.74804836060463 49.677 35.668819038765704 139.74807491094217 49.677 35.668827672192286 139.74804701049527 49.677 35.668825329577764 139.74804836060463 49.677</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f3be3020-5ffb-49bc-a1c6-9b62ef0cae0e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f3be3020-5ffb-49bc-a1c6-9b62ef0cae0e_0">
											<gml:posList>35.66880974256993 139.7481088211354 49.677 35.668819038765704 139.74807491094217 49.677 35.668814978900734 139.7480824376154 49.677 35.66880974256993 139.7481088211354 49.677</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0fdcdcc3-f852-4e7d-a9d7-f58a16cbcccd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0fdcdcc3-f852-4e7d-a9d7-f58a16cbcccd_0">
											<gml:posList>35.6687956498851 139.74810286020562 49.677 35.6687962433212 139.74810078291895 49.677 35.66876093479919 139.74808561005827 49.677 35.6687956498851 139.74810286020562 49.677</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ff790c4e-2d8b-4cfd-891c-a32811587866">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ff790c4e-2d8b-4cfd-891c-a32811587866_0">
											<gml:posList>35.66877789408882 139.74802826308294 49.677 35.66878344821138 139.74803060998053 49.677 35.668776810453934 139.74802545854183 49.677 35.66877789408882 139.74802826308294 49.677</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6881b271-ce11-4a77-8dac-c06afd8124b5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6881b271-ce11-4a77-8dac-c06afd8124b5_0">
											<gml:posList>35.66875914977627 139.74808518116063 49.677 35.66876142038308 139.74808397472853 49.677 35.66877789408882 139.74802826308294 49.677 35.66875914977627 139.74808518116063 49.677</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b6e7299d-3c7b-476d-8559-b51ee8762908">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b6e7299d-3c7b-476d-8559-b51ee8762908_0">
											<gml:posList>35.66878544986129 139.74803145839616 49.677 35.668825329577764 139.74804836060463 49.677 35.668827672192286 139.74804701049527 49.677 35.66878544986129 139.74803145839616 49.677</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d78520eb-11bc-497f-9144-f942a6dbb448">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d78520eb-11bc-497f-9144-f942a6dbb448_0">
											<gml:posList>35.668776810453934 139.74802545854183 49.677 35.66878344821138 139.74803060998053 49.677 35.66878544986129 139.74803145839616 49.677 35.668776810453934 139.74802545854183 49.677</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e69189f5-fc63-49b1-8035-0a0ce898e929">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e69189f5-fc63-49b1-8035-0a0ce898e929_0">
											<gml:posList>35.66880974256993 139.7481088211354 49.677 35.668814978900734 139.7480824376154 49.677 35.66880863189574 139.74810601662082 49.677 35.66880974256993 139.7481088211354 49.677</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-52a1b8e6-365c-407a-ac73-56861719daeb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-52a1b8e6-365c-407a-ac73-56861719daeb_0">
											<gml:posList>35.66880863189574 139.74810601662082 49.677 35.6687962433212 139.74810078291895 49.677 35.6687956498851 139.74810286020562 49.677 35.66880863189574 139.74810601662082 49.677</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1879a239-7d7d-4b7d-9a35-2827c37f42f1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1879a239-7d7d-4b7d-9a35-2827c37f42f1_0">
											<gml:posList>35.668825329577764 139.74804836060463 49.677 35.66881735265912 139.74807415055793 49.677 35.668819038765704 139.74807491094217 49.677 35.668825329577764 139.74804836060463 49.677</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8da52e7a-3304-4606-be62-51125056a9af">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8da52e7a-3304-4606-be62-51125056a9af_0">
											<gml:posList>35.668815446472756 139.74808082439574 49.677 35.668814978900734 139.7480824376154 49.677 35.668819038765704 139.74807491094217 49.677 35.668815446472756 139.74808082439574 49.677</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-23c6dba2-4c6b-456d-a220-30b2d9f43434">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-23c6dba2-4c6b-456d-a220-30b2d9f43434_0">
											<gml:posList>35.66875914977627 139.74808518116063 49.677 35.66876097076808 139.74808548851362 49.677 35.66876142038308 139.74808397472853 49.677 35.66875914977627 139.74808518116063 49.677</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3fd8898f-c1d4-41dd-87e7-bcaee7ef8f6f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3fd8898f-c1d4-41dd-87e7-bcaee7ef8f6f_0">
											<gml:posList>35.66881735265912 139.74807415055793 49.677 35.668815446472756 139.74808082439574 49.677 35.668819038765704 139.74807491094217 49.677 35.66881735265912 139.74807415055793 49.677</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2115d1e0-c824-4687-87b2-07241366753e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2115d1e0-c824-4687-87b2-07241366753e_0">
											<gml:posList>35.66876093479919 139.74808561005827 49.677 35.66876097076808 139.74808548851362 49.677 35.66875914977627 139.74808518116063 49.677 35.66876093479919 139.74808561005827 49.677</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b1dd0b53-a70c-49b9-9881-b5da5f7b1554">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b1dd0b53-a70c-49b9-9881-b5da5f7b1554_0">
											<gml:posList>35.66880634659354 139.74807373146518 47.07 35.668809475462865 139.7480625605879 37.253 35.668809475462865 139.7480625605879 47.07 35.66880634659354 139.74807373146518 47.07</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-46039d96-fc42-4688-bf59-3698fe127b5f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-46039d96-fc42-4688-bf59-3698fe127b5f_0">
											<gml:posList>35.66880634659354 139.74807373146518 47.07 35.66880634659354 139.74807373146518 37.253 35.668809475462865 139.7480625605879 37.253 35.66880634659354 139.74807373146518 47.07</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-027ae3ad-621d-492e-a2a4-c06d5f31a823">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-027ae3ad-621d-492e-a2a4-c06d5f31a823_0">
											<gml:posList>35.66878778177655 139.7480659085166 47.07 35.66880634659354 139.74807373146518 37.253 35.66880634659354 139.74807373146518 47.07 35.66878778177655 139.7480659085166 47.07</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-06e8f6a3-2a85-4b35-9c89-fa4500cccc4d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-06e8f6a3-2a85-4b35-9c89-fa4500cccc4d_0">
											<gml:posList>35.66878778177655 139.7480659085166 47.07 35.66878778177655 139.7480659085166 37.253 35.66880634659354 139.74807373146518 37.253 35.66878778177655 139.7480659085166 47.07</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6e68f15d-cd2b-4916-b218-03781dcc10c5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6e68f15d-cd2b-4916-b218-03781dcc10c5_0">
											<gml:posList>35.66881635460684 139.7480776421693 37.253 35.668815446472756 139.74808082439574 37.253 35.66881635460684 139.7480776421693 37.8 35.66881635460684 139.7480776421693 37.253</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f011a55f-9278-49ab-af80-815d784e9995">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f011a55f-9278-49ab-af80-815d784e9995_0">
											<gml:posList>35.66881735265912 139.74807415055793 37.8 35.66881635460684 139.7480776421693 37.8 35.66881735265912 139.74807415055793 49.677 35.66881735265912 139.74807415055793 37.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-99d63480-29ba-4ce0-a70b-e46e521527d6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-99d63480-29ba-4ce0-a70b-e46e521527d6_0">
											<gml:posList>35.66881735265912 139.74807415055793 49.677 35.66881635460684 139.7480776421693 37.8 35.668815446472756 139.74808082439574 49.677 35.66881735265912 139.74807415055793 49.677</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-20560e69-8737-4300-a947-8b3a8ad8eaaf">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-20560e69-8737-4300-a947-8b3a8ad8eaaf_0">
											<gml:posList>35.66881635460684 139.7480776421693 37.8 35.668815446472756 139.74808082439574 37.253 35.668815446472756 139.74808082439574 49.677 35.66881635460684 139.7480776421693 37.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3008e865-bed2-403c-9266-aca108d61e79">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3008e865-bed2-403c-9266-aca108d61e79_0">
											<gml:posList>35.66881635460684 139.7480776421693 37.8 35.66881804971149 139.74807838045197 37.253 35.66881635460684 139.7480776421693 37.253 35.66881635460684 139.7480776421693 37.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b490742a-c956-4884-a5d3-4b49bb8bffd1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b490742a-c956-4884-a5d3-4b49bb8bffd1_0">
											<gml:posList>35.66881635460684 139.7480776421693 37.8 35.66881804971149 139.74807838045197 37.8 35.66881804971149 139.74807838045197 37.253 35.66881635460684 139.7480776421693 37.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-dc4cceef-d5e7-447b-bfa3-049d64e150a0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-dc4cceef-d5e7-447b-bfa3-049d64e150a0_0">
											<gml:posList>35.668814978900734 139.7480824376154 37.253 35.668815446472756 139.74808082439574 49.677 35.668815446472756 139.74808082439574 37.253 35.668814978900734 139.7480824376154 37.253</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-20bcdd83-fcd1-470a-874c-7fcecc7e27a9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-20bcdd83-fcd1-470a-874c-7fcecc7e27a9_0">
											<gml:posList>35.668814978900734 139.7480824376154 37.253 35.668814978900734 139.7480824376154 49.677 35.668815446472756 139.74808082439574 49.677 35.668814978900734 139.7480824376154 37.253</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3d0ef283-40f0-4960-b5c5-c98ea22131b0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3d0ef283-40f0-4960-b5c5-c98ea22131b0_0">
											<gml:posList>35.66876130347834 139.7480843614641 37.8 35.66875960837371 139.74808362318183 37.253 35.66876130347834 139.7480843614641 37.253 35.66876130347834 139.7480843614641 37.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d8150075-c1bb-4f6a-8ce0-c2d256bf563f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d8150075-c1bb-4f6a-8ce0-c2d256bf563f_0">
											<gml:posList>35.66876130347834 139.7480843614641 37.8 35.66875960837371 139.74808362318183 37.8 35.66875960837371 139.74808362318183 37.253 35.66876130347834 139.7480843614641 37.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-75a4027c-bb08-402a-8ea5-f94a3a686061">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-75a4027c-bb08-402a-8ea5-f94a3a686061_0">
											<gml:posList>35.66876130347834 139.7480843614641 37.253 35.66876142038308 139.74808397472853 37.253 35.66876130347834 139.7480843614641 37.8 35.66876130347834 139.7480843614641 37.253</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fe423381-6de0-489d-9961-2f269a9f6c13">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fe423381-6de0-489d-9961-2f269a9f6c13_0">
											<gml:posList>35.66876097076808 139.74808548851362 37.8 35.66876130347834 139.7480843614641 37.8 35.66876097076808 139.74808548851362 49.677 35.66876097076808 139.74808548851362 37.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d40e9578-0f8b-4285-add5-9668e9b3a79d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d40e9578-0f8b-4285-add5-9668e9b3a79d_0">
											<gml:posList>35.66876097076808 139.74808548851362 49.677 35.66876130347834 139.7480843614641 37.8 35.66876142038308 139.74808397472853 49.677 35.66876097076808 139.74808548851362 49.677</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2abb2af1-0bab-45e9-b598-69c67ba7d78f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2abb2af1-0bab-45e9-b598-69c67ba7d78f_0">
											<gml:posList>35.66876130347834 139.7480843614641 37.8 35.66876142038308 139.74808397472853 37.253 35.66876142038308 139.74808397472853 49.677 35.66876130347834 139.7480843614641 37.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bc76c2dd-71cb-41a0-98a1-3c1f34bbc8a2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bc76c2dd-71cb-41a0-98a1-3c1f34bbc8a2_0">
											<gml:posList>35.66876097076808 139.74808548851362 49.677 35.66876093479919 139.74808561005827 37.8 35.66876097076808 139.74808548851362 37.8 35.66876097076808 139.74808548851362 49.677</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9778bdec-2d1d-4b5d-91a5-b55419e77282">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9778bdec-2d1d-4b5d-91a5-b55419e77282_0">
											<gml:posList>35.66876097076808 139.74808548851362 49.677 35.66876093479919 139.74808561005827 49.677 35.66876093479919 139.74808561005827 37.8 35.66876097076808 139.74808548851362 49.677</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a24c92ac-c0f3-4912-822b-da550e0ca398">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a24c92ac-c0f3-4912-822b-da550e0ca398_0">
											<gml:posList>35.66881804971149 139.74807838045197 37.8 35.66880974256993 139.7481088211354 49.677 35.66880974256993 139.7481088211354 37.253 35.66881804971149 139.74807838045197 37.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-458a363d-bec7-4ec6-9855-22756fedaf12">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-458a363d-bec7-4ec6-9855-22756fedaf12_0">
											<gml:posList>35.66880974256993 139.7481088211354 37.253 35.66881804971149 139.74807838045197 37.253 35.66881804971149 139.74807838045197 37.8 35.66880974256993 139.7481088211354 37.253</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-90ceb7f2-9fb4-4305-b253-d7ddf7da2039">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-90ceb7f2-9fb4-4305-b253-d7ddf7da2039_0">
											<gml:posList>35.668819038765704 139.74807491094217 49.677 35.66880974256993 139.7481088211354 49.677 35.66881804971149 139.74807838045197 37.8 35.668819038765704 139.74807491094217 49.677</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-96a96a0e-3458-487d-ac37-553f9d5555d9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-96a96a0e-3458-487d-ac37-553f9d5555d9_0">
											<gml:posList>35.668819038765704 139.74807491094217 37.8 35.668819038765704 139.74807491094217 49.677 35.66881804971149 139.74807838045197 37.8 35.668819038765704 139.74807491094217 37.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-97e65d30-1ad4-4c15-8755-9b89b3ab22d1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-97e65d30-1ad4-4c15-8755-9b89b3ab22d1_0">
											<gml:posList>35.66876093479919 139.74808561005827 49.677 35.6687962433212 139.74810078291895 37.8 35.66876093479919 139.74808561005827 37.8 35.66876093479919 139.74808561005827 49.677</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9c75774b-9876-4063-8150-4b52c156f48b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9c75774b-9876-4063-8150-4b52c156f48b_0">
											<gml:posList>35.66876093479919 139.74808561005827 49.677 35.6687962433212 139.74810078291895 49.677 35.6687962433212 139.74810078291895 37.8 35.66876093479919 139.74808561005827 49.677</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8281e32a-7fea-4c00-b7e1-58f29fd092c1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8281e32a-7fea-4c00-b7e1-58f29fd092c1_0">
											<gml:posList>35.66880863189574 139.74810601662082 37.253 35.668814978900734 139.7480824376154 49.677 35.668814978900734 139.7480824376154 37.253 35.66880863189574 139.74810601662082 37.253</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2ba17bd6-8cb3-4cbd-b06a-c00800902afd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2ba17bd6-8cb3-4cbd-b06a-c00800902afd_0">
											<gml:posList>35.66880863189574 139.74810601662082 37.253 35.66880863189574 139.74810601662082 49.677 35.668814978900734 139.7480824376154 49.677 35.66880863189574 139.74810601662082 37.253</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fae34dde-f787-428d-967b-5666c95d520b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fae34dde-f787-428d-967b-5666c95d520b_0">
											<gml:posList>35.6687956498851 139.74810286020562 37.8 35.66875862822348 139.748086938035 49.677 35.66875862822348 139.748086938035 37.8 35.6687956498851 139.74810286020562 37.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cb6d87d4-fd57-4604-bb8f-1e8e3892a75f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cb6d87d4-fd57-4604-bb8f-1e8e3892a75f_0">
											<gml:posList>35.6687956498851 139.74810286020562 37.8 35.6687956498851 139.74810286020562 49.677 35.66875862822348 139.748086938035 49.677 35.6687956498851 139.74810286020562 37.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f46bf815-49a4-4793-8f43-2c60293d0314">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f46bf815-49a4-4793-8f43-2c60293d0314_0">
											<gml:posList>35.66879914660913 139.7481020059435 37.253 35.668798472033835 139.7481040612244 37.8 35.66879914660913 139.7481020059435 37.8 35.66879914660913 139.7481020059435 37.253</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-06e10209-e71b-4d7e-9a3d-9be5947294e0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-06e10209-e71b-4d7e-9a3d-9be5947294e0_0">
											<gml:posList>35.66879914660913 139.7481020059435 37.253 35.668798472033835 139.7481040612244 37.253 35.668798472033835 139.7481040612244 37.8 35.66879914660913 139.7481020059435 37.253</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f746cf24-3325-4f29-b040-9588938f4924">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f746cf24-3325-4f29-b040-9588938f4924_0">
											<gml:posList>35.66879914660913 139.7481020059435 37.253 35.66879914660913 139.7481020059435 37.8 35.66880863189574 139.74810601662082 37.253 35.66879914660913 139.7481020059435 37.253</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8b834f17-7f5e-48fe-8cce-ba2bf4b7bff2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8b834f17-7f5e-48fe-8cce-ba2bf4b7bff2_0">
											<gml:posList>35.66880863189574 139.74810601662082 37.253 35.66879914660913 139.7481020059435 37.8 35.66880863189574 139.74810601662082 49.677 35.66880863189574 139.74810601662082 37.253</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-07355238-a064-4c32-b8e6-b771a59cc969">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-07355238-a064-4c32-b8e6-b771a59cc969_0">
											<gml:posList>35.66880863189574 139.74810601662082 49.677 35.66879914660913 139.7481020059435 37.8 35.6687962433212 139.74810078291895 49.677 35.66880863189574 139.74810601662082 49.677</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9030fd00-a4bc-4972-b4a0-05fb1edcec73">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9030fd00-a4bc-4972-b4a0-05fb1edcec73_0">
											<gml:posList>35.66879914660913 139.7481020059435 37.8 35.6687962433212 139.74810078291895 37.8 35.6687962433212 139.74810078291895 49.677 35.66879914660913 139.7481020059435 37.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7e8fbebb-1638-4e71-b4f7-d6b5e2a25d85">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7e8fbebb-1638-4e71-b4f7-d6b5e2a25d85_0">
											<gml:posList>35.668798472033835 139.7481040612244 37.253 35.66880974256993 139.7481088211354 37.253 35.668798472033835 139.7481040612244 37.8 35.668798472033835 139.7481040612244 37.253</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fdcdcea5-c1f8-4049-a827-5e7e6b91fcee">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fdcdcea5-c1f8-4049-a827-5e7e6b91fcee_0">
											<gml:posList>35.6687956498851 139.74810286020562 37.8 35.668798472033835 139.7481040612244 37.8 35.6687956498851 139.74810286020562 49.677 35.6687956498851 139.74810286020562 37.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-21627482-39e5-4a92-afe0-c522bf323026">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-21627482-39e5-4a92-afe0-c522bf323026_0">
											<gml:posList>35.6687956498851 139.74810286020562 49.677 35.668798472033835 139.7481040612244 37.8 35.66880974256993 139.7481088211354 49.677 35.6687956498851 139.74810286020562 49.677</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3281582b-438d-4cf8-ae52-34ddc881235c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3281582b-438d-4cf8-ae52-34ddc881235c_0">
											<gml:posList>35.668798472033835 139.7481040612244 37.8 35.66880974256993 139.7481088211354 37.253 35.66880974256993 139.7481088211354 49.677 35.668798472033835 139.7481040612244 37.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-16da7e0d-2660-4700-8834-00d983e59451">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-16da7e0d-2660-4700-8834-00d983e59451_0">
											<gml:posList>35.66886678376838 139.74813753547167 39.464 35.66885267289351 139.74813134258494 37.253 35.66885267289351 139.74813134258494 39.464 35.66886678376838 139.74813753547167 39.464</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-82aa22b7-11b0-4e6b-9384-1a565b8ba13d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-82aa22b7-11b0-4e6b-9384-1a565b8ba13d_0">
											<gml:posList>35.66886678376838 139.74813753547167 39.464 35.66886678376838 139.74813753547167 37.253 35.66885267289351 139.74813134258494 37.253 35.66886678376838 139.74813753547167 39.464</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b48cc797-6649-48b5-b835-9db9e54dac8c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b48cc797-6649-48b5-b835-9db9e54dac8c_0">
											<gml:posList>35.66885267289351 139.74813134258494 39.464 35.66884157681153 139.74816931964344 37.253 35.66884157681153 139.74816931964344 39.464 35.66885267289351 139.74813134258494 39.464</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cea653ba-cb15-4303-b8bc-141a2542cbc2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cea653ba-cb15-4303-b8bc-141a2542cbc2_0">
											<gml:posList>35.66885267289351 139.74813134258494 39.464 35.66885267289351 139.74813134258494 37.253 35.66884157681153 139.74816931964344 37.253 35.66885267289351 139.74813134258494 39.464</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b72dbaee-807e-4b57-b82f-8d9a86950270">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b72dbaee-807e-4b57-b82f-8d9a86950270_0">
											<gml:posList>35.66886678376838 139.74813753547167 39.464 35.66885267289351 139.74813134258494 39.464 35.66884157681153 139.74816931964344 39.464 35.66886678376838 139.74813753547167 39.464</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6c706725-18c5-47df-8927-25ead37c224d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6c706725-18c5-47df-8927-25ead37c224d_0">
											<gml:posList>35.66885568768447 139.748175512536 39.464 35.66886678376838 139.74813753547167 39.464 35.66884157681153 139.74816931964344 39.464 35.66885568768447 139.748175512536 39.464</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3aec84ab-0909-482e-82e2-41457813384f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3aec84ab-0909-482e-82e2-41457813384f_0">
											<gml:posList>35.66885568768447 139.748175512536 39.464 35.66886678376838 139.74813753547167 37.253 35.66886678376838 139.74813753547167 39.464 35.66885568768447 139.748175512536 39.464</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-21c9824d-1ab6-4bc7-8397-1055968f5364">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-21c9824d-1ab6-4bc7-8397-1055968f5364_0">
											<gml:posList>35.66885568768447 139.748175512536 39.464 35.66885568768447 139.748175512536 37.253 35.66886678376838 139.74813753547167 37.253 35.66885568768447 139.748175512536 39.464</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-39a1c13b-9013-4c5b-8c1d-43b5b7fd85ea">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-39a1c13b-9013-4c5b-8c1d-43b5b7fd85ea_0">
											<gml:posList>35.66884157681153 139.74816931964344 39.464 35.66885568768447 139.748175512536 37.253 35.66885568768447 139.748175512536 39.464 35.66884157681153 139.74816931964344 39.464</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f6c79e5b-678a-4a3c-bb56-58f1d06c427b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f6c79e5b-678a-4a3c-bb56-58f1d06c427b_0">
											<gml:posList>35.66884157681153 139.74816931964344 39.464 35.66884157681153 139.74816931964344 37.253 35.66885568768447 139.748175512536 37.253 35.66884157681153 139.74816931964344 39.464</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a55f798d-0189-4948-a945-a56778694ca7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668776810453934 139.74802545854183 37.253 35.668825012344854 139.74804588662775 37.253 35.66878544986129 139.74803145839616 37.253 35.668776810453934 139.74802545854183 37.253</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9db72ce7-642e-4201-a2df-4aba367bb832">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66877789408882 139.74802826308294 37.253 35.66875960837371 139.74808362318183 37.253 35.668776810453934 139.74802545854183 37.253 35.66877789408882 139.74802826308294 37.253</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-518142a7-b47b-4d1a-bfe5-e554970f6dea">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66882437383325 139.7480479529175 37.253 35.66878544986129 139.74803145839616 37.253 35.668825012344854 139.74804588662775 37.253 35.66882437383325 139.7480479529175 37.253</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e4027a9a-2e45-4f79-a975-0cba769be4ff">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66875960837371 139.74808362318183 37.253 35.66876142038308 139.74808397472853 37.253 35.66876130347834 139.7480843614641 37.253 35.66875960837371 139.74808362318183 37.253</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9655e55c-171a-4168-800c-a592fb3cc0c7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668776810453934 139.74802545854183 37.253 35.66878544986129 139.74803145839616 37.253 35.66878344821138 139.74803060998053 37.253 35.668776810453934 139.74802545854183 37.253</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-dff527bb-de14-4898-80da-f20d620f0641">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66877789408882 139.74802826308294 37.253 35.66876142038308 139.74808397472853 37.253 35.66875960837371 139.74808362318183 37.253 35.66877789408882 139.74802826308294 37.253</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-090a8dbd-031c-45b8-b080-818f7aeb8c51">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66878344821138 139.74803060998053 37.253 35.66877789408882 139.74802826308294 37.253 35.668776810453934 139.74802545854183 37.253 35.66878344821138 139.74803060998053 37.253</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c4b9355c-9268-422f-80f8-32c1234ce2ec">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668825329577764 139.74804836060463 37.8 35.66882437383325 139.7480479529175 37.8 35.668825012344854 139.74804588662775 37.8 35.668825329577764 139.74804836060463 37.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5b6cf50e-067e-476e-97ee-3b92880608ff">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668827672192286 139.74804701049527 37.8 35.668825329577764 139.74804836060463 37.8 35.668825012344854 139.74804588662775 37.8 35.668827672192286 139.74804701049527 37.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-79dea74f-2ada-4dd4-ba9d-ea528d84c7c0">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668819038765704 139.74807491094217 37.8 35.66881635460684 139.7480776421693 37.8 35.66881735265912 139.74807415055793 37.8 35.668819038765704 139.74807491094217 37.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a5ddd8d6-457f-4ff1-9e64-377874ac5e7d">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66881804971149 139.74807838045197 37.8 35.66881635460684 139.7480776421693 37.8 35.668819038765704 139.74807491094217 37.8 35.66881804971149 139.74807838045197 37.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d7d4d3db-efcb-4d2e-bf3d-0e9fc309b2b6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668827672192286 139.74804701049527 37.8 35.668819038765704 139.74807491094217 37.8 35.668825329577764 139.74804836060463 37.8 35.668827672192286 139.74804701049527 37.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bf850256-4945-4184-a44e-e18dbcfc1b4f">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66881735265912 139.74807415055793 37.8 35.668825329577764 139.74804836060463 37.8 35.668819038765704 139.74807491094217 37.8 35.66881735265912 139.74807415055793 37.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-70450a35-5bc1-4460-9d20-cb0ad88bea21">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66880634659354 139.74807373146518 37.253 35.66878778177655 139.7480659085166 37.253 35.6687909196667 139.74805474867807 37.253 35.66880634659354 139.74807373146518 37.253</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e386b12c-7840-4017-8c68-76aabde7f173">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668809475462865 139.7480625605879 37.253 35.66880634659354 139.74807373146518 37.253 35.6687909196667 139.74805474867807 37.253 35.668809475462865 139.7480625605879 37.253</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b912269c-2a37-40c0-817f-ec735f6add71">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66880863189574 139.74810601662082 37.253 35.668798472033835 139.7481040612244 37.253 35.66879914660913 139.7481020059435 37.253 35.66880863189574 139.74810601662082 37.253</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c5683aed-624c-462d-a6c6-f0685dcdfc56">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668798472033835 139.7481040612244 37.253 35.66880863189574 139.74810601662082 37.253 35.66880974256993 139.7481088211354 37.253 35.668798472033835 139.7481040612244 37.253</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fa48da9d-1be6-4527-a8ae-c2a59ac6c93b">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668815446472756 139.74808082439574 37.253 35.66881635460684 139.7480776421693 37.253 35.66881804971149 139.74807838045197 37.253 35.668815446472756 139.74808082439574 37.253</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f8787efa-994c-4789-a684-e2ca002632ce">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668814978900734 139.7480824376154 37.253 35.66881804971149 139.74807838045197 37.253 35.66880974256993 139.7481088211354 37.253 35.668814978900734 139.7480824376154 37.253</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f7b807c9-cd35-41d6-b092-461a1455507e">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668815446472756 139.74808082439574 37.253 35.66881804971149 139.74807838045197 37.253 35.668814978900734 139.7480824376154 37.253 35.668815446472756 139.74808082439574 37.253</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b44a921e-5099-431f-a00c-29f3c1a4b273">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668814978900734 139.7480824376154 37.253 35.66880974256993 139.7481088211354 37.253 35.66880863189574 139.74810601662082 37.253 35.668814978900734 139.7480824376154 37.253</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-676b4953-11ea-428f-beb5-07cd78b5d9ae">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66879914660913 139.7481020059435 37.8 35.668798472033835 139.7481040612244 37.8 35.6687962433212 139.74810078291895 37.8 35.66879914660913 139.7481020059435 37.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-22ab844d-600b-4622-b135-8c7edf5e88c4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66875960837371 139.74808362318183 37.8 35.66876130347834 139.7480843614641 37.8 35.66876097076808 139.74808548851362 37.8 35.66875960837371 139.74808362318183 37.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e3c5bcbe-5db7-40cf-8b66-3772273fc20f">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66875862822348 139.748086938035 37.8 35.66875960837371 139.74808362318183 37.8 35.66876093479919 139.74808561005827 37.8 35.66875862822348 139.748086938035 37.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0290e3c9-24ae-429c-b794-117f13ae8a4e">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6687962433212 139.74810078291895 37.8 35.668798472033835 139.7481040612244 37.8 35.6687956498851 139.74810286020562 37.8 35.6687962433212 139.74810078291895 37.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b63aef57-b37b-4c82-9827-af801bb0d89e">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66876093479919 139.74808561005827 37.8 35.6687962433212 139.74810078291895 37.8 35.6687956498851 139.74810286020562 37.8 35.66876093479919 139.74808561005827 37.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6e827f35-6354-466d-a4e7-f64ea2910df0">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66876093479919 139.74808561005827 37.8 35.66875960837371 139.74808362318183 37.8 35.66876097076808 139.74808548851362 37.8 35.66876093479919 139.74808561005827 37.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b3155d6c-4b3e-471f-948b-3a3a90bb0915">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66875862822348 139.748086938035 37.8 35.66876093479919 139.74808561005827 37.8 35.6687956498851 139.74810286020562 37.8 35.66875862822348 139.748086938035 37.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4e17e128-67e2-44b5-96d6-132f5707a5c4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66884157681153 139.74816931964344 37.253 35.66886678376838 139.74813753547167 37.253 35.66885568768447 139.748175512536 37.253 35.66884157681153 139.74816931964344 37.253</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b832e632-bafd-4217-9407-dcf6385b3086">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66884157681153 139.74816931964344 37.253 35.66885267289351 139.74813134258494 37.253 35.66886678376838 139.74813753547167 37.253 35.66884157681153 139.74816931964344 37.253</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-214177ce-4c91-4338-8576-c8f97961a287">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-214177ce-4c91-4338-8576-c8f97961a287">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-214177ce-4c91-4338-8576-c8f97961a287">
											<gml:posList>35.66886385042939 139.74822127870326 5.62 35.66884475335083 139.74823830988944 5.62 35.668826186322335 139.7482400969615 5.62 35.66881491619737 139.74823591142496 5.62 35.66880436334503 139.74822631256723 5.62 35.66880002473196 139.74820930626686 5.62 35.66880263098171 139.74819836791755 5.62 35.668823766520084 139.7481322901228 5.62 35.668790675746415 139.74811763405003 5.62 35.668795442858666 139.74810326912925 5.62 35.66866001460101 139.74804398547803 5.62 35.66868501632642 139.74796431703194 5.62 35.66883297871118 139.74803065670136 5.62 35.66881930921662 139.74807496588483 5.62 35.66888756447648 139.74810504903724 5.62 35.668892976230666 139.74811001400974 5.62 35.668894692825695 139.74811564567355 5.62 35.66889451692867 139.7481218316516 5.62 35.66886385042939 139.74822127870326 5.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-21812210-f039-4e18-b4a5-9295aa65fc28">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-21812210-f039-4e18-b4a5-9295aa65fc28">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-21812210-f039-4e18-b4a5-9295aa65fc28">
											<gml:posList>35.66883297871118 139.74803065670136 37.8 35.66868501632642 139.74796431703194 37.8 35.668686786392044 139.74796907598494 37.8 35.66882903225597 139.7480328590631 37.8 35.66883297871118 139.74803065670136 37.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-6b97799d-4629-4bb0-933e-b6e709cf65c3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6b97799d-4629-4bb0-933e-b6e709cf65c3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6b97799d-4629-4bb0-933e-b6e709cf65c3">
											<gml:posList>35.66868501632642 139.74796431703194 37.8 35.66866001460101 139.74804398547803 37.8 35.66866397906835 139.7480417610103 37.8 35.668686786392044 139.74796907598494 37.8 35.66868501632642 139.74796431703194 37.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-3cc93346-46eb-4f7b-bc01-184c631bddb9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3cc93346-46eb-4f7b-bc01-184c631bddb9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3cc93346-46eb-4f7b-bc01-184c631bddb9">
											<gml:posList>35.66866397906835 139.7480417610103 37.8 35.66866001460101 139.74804398547803 37.8 35.668795442858666 139.74810326912925 37.8 35.668799461424996 139.74810106669526 37.8 35.66866397906835 139.7480417610103 37.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b711e233-b109-47ff-8839-38a401754147">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b711e233-b109-47ff-8839-38a401754147">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b711e233-b109-47ff-8839-38a401754147">
											<gml:posList>35.66889164661598 139.7481162564441 37.253 35.668890372709896 139.74811206029713 37.253 35.668886377103775 139.74810849666827 37.253 35.66881536278405 139.7480772013821 37.253 35.66882903225597 139.7480328590631 37.253 35.668686786392044 139.74796907598494 37.253 35.66866397906835 139.7480417610103 37.253 35.668799461424996 139.74810106669526 37.253 35.66879469432084 139.7481154426629 37.253 35.66882774902421 139.74813007668178 37.253 35.66880552523149 139.7481995578172 37.253 35.668804015415695 139.748205910895 37.253 35.668808401170416 139.74821309721318 37.253 35.6688499582577 139.74823119070982 37.253 35.66886111802872 139.74821952528154 37.253 35.66889152374603 139.7481209511481 37.253 35.66889164661598 139.7481162564441 37.253</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f599aafd-48d7-4a48-b915-816b0d0239a4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f599aafd-48d7-4a48-b915-816b0d0239a4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f599aafd-48d7-4a48-b915-816b0d0239a4">
											<gml:posList>35.66879469432084 139.7481154426629 37.8 35.668799461424996 139.74810106669526 37.8 35.668795442858666 139.74810326912925 37.8 35.668790675746415 139.74811763405003 37.8 35.66879469432084 139.7481154426629 37.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-53525968-7812-4062-aead-4858a24df982">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-53525968-7812-4062-aead-4858a24df982">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-53525968-7812-4062-aead-4858a24df982">
											<gml:posList>35.668804015415695 139.748205910895 37.8 35.66880552523149 139.7481995578172 37.8 35.66880263098171 139.74819836791755 37.8 35.668800680805255 139.74820657719783 37.8 35.668804015415695 139.748205910895 37.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b9d16a82-4cdd-41d7-99f7-e7ac89d00d3d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b9d16a82-4cdd-41d7-99f7-e7ac89d00d3d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b9d16a82-4cdd-41d7-99f7-e7ac89d00d3d">
											<gml:posList>35.668804015415695 139.748205910895 37.8 35.668800680805255 139.74820657719783 37.8 35.66880660969532 139.74821629142153 37.8 35.668808401170416 139.74821309721318 37.8 35.668804015415695 139.748205910895 37.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-4d8b3f64-fe9f-4c10-bcfa-a1767d5d6d63">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4d8b3f64-fe9f-4c10-bcfa-a1767d5d6d63">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4d8b3f64-fe9f-4c10-bcfa-a1767d5d6d63">
											<gml:posList>35.66879469432084 139.7481154426629 37.8 35.668790675746415 139.74811763405003 37.8 35.668823766520084 139.7481322901228 37.8 35.66882774902421 139.74813007668178 37.8 35.66879469432084 139.7481154426629 37.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c4b09e4e-19e7-4df5-8bec-914299069cc9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c4b09e4e-19e7-4df5-8bec-914299069cc9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c4b09e4e-19e7-4df5-8bec-914299069cc9">
											<gml:posList>35.66880552523149 139.7481995578172 37.8 35.66882774902421 139.74813007668178 37.8 35.668823766520084 139.7481322901228 37.8 35.66880263098171 139.74819836791755 37.8 35.66880552523149 139.7481995578172 37.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-54765790-9551-401b-8824-d72cceac7ae7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-54765790-9551-401b-8824-d72cceac7ae7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-54765790-9551-401b-8824-d72cceac7ae7">
											<gml:posList>35.66882903225597 139.7480328590631 37.8 35.66881536278405 139.7480772013821 37.8 35.66881930921662 139.74807496588483 37.8 35.66883297871118 139.74803065670136 37.8 35.66882903225597 139.7480328590631 37.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-13ff1519-43ba-4bd2-a5fd-c18afdda89f7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-13ff1519-43ba-4bd2-a5fd-c18afdda89f7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-13ff1519-43ba-4bd2-a5fd-c18afdda89f7">
											<gml:posList>35.66880660969532 139.74821629142153 12.2 35.668800680805255 139.74820657719783 12.2 35.66880002473196 139.74820930626686 12.2 35.66880436334503 139.74822631256723 12.2 35.66881491619737 139.74823591142496 12.2 35.668826186322335 139.7482400969615 12.2 35.66884475335083 139.74823830988944 12.2 35.6688497078328 139.748233963534 12.2 35.66880660969532 139.74821629142153 12.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-32cb03ca-5d8d-491f-a081-9293431fb5d2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-32cb03ca-5d8d-491f-a081-9293431fb5d2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-32cb03ca-5d8d-491f-a081-9293431fb5d2">
											<gml:posList>35.668808401170416 139.74821309721318 37.8 35.66880660969532 139.74821629142153 37.8 35.66884969881907 139.74823396354356 37.8 35.6688499582577 139.74823119070982 37.8 35.668808401170416 139.74821309721318 37.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-16263fda-9005-4843-8cb3-d59a6d477539">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-16263fda-9005-4843-8cb3-d59a6d477539">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-16263fda-9005-4843-8cb3-d59a6d477539">
											<gml:posList>35.668886377103775 139.74810849666827 37.8 35.66888756447648 139.74810504903724 37.8 35.66881930921662 139.74807496588483 37.8 35.66881536278405 139.7480772013821 37.8 35.668886377103775 139.74810849666827 37.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-cc21bb7c-dd6f-4c1f-a20a-6654ef731b1c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cc21bb7c-dd6f-4c1f-a20a-6654ef731b1c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cc21bb7c-dd6f-4c1f-a20a-6654ef731b1c">
											<gml:posList>35.6688499582577 139.74823119070982 37.8 35.66884969881907 139.74823396354356 37.8 35.66886385042939 139.74822127870326 37.8 35.66886111802872 139.74821952528154 37.8 35.6688499582577 139.74823119070982 37.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f91c4ece-a62c-4eb4-9097-cec0ea8646b9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f91c4ece-a62c-4eb4-9097-cec0ea8646b9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f91c4ece-a62c-4eb4-9097-cec0ea8646b9">
											<gml:posList>35.66886385042939 139.74822127870326 37.8 35.66889451692867 139.7481218316516 37.8 35.66889152374603 139.7481209511481 37.8 35.66886111802872 139.74821952528154 37.8 35.66886385042939 139.74822127870326 37.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-20dbfe17-714b-415a-8a14-f4b60c07df04">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-20dbfe17-714b-415a-8a14-f4b60c07df04">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-20dbfe17-714b-415a-8a14-f4b60c07df04">
											<gml:posList>35.668892976230666 139.74811001400974 37.8 35.66888756447648 139.74810504903724 37.8 35.668886377103775 139.74810849666827 37.8 35.668890372709896 139.74811206029713 37.8 35.668892976230666 139.74811001400974 37.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-bc5a7f4f-2a8f-4058-8910-cc70edebaa24">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bc5a7f4f-2a8f-4058-8910-cc70edebaa24">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bc5a7f4f-2a8f-4058-8910-cc70edebaa24">
											<gml:posList>35.668894692825695 139.74811564567355 37.8 35.668892976230666 139.74811001400974 37.8 35.668890372709896 139.74811206029713 37.8 35.66889164661598 139.7481162564441 37.8 35.668894692825695 139.74811564567355 37.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-bf4d38bd-32b0-477b-894b-26b3d7f523f0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bf4d38bd-32b0-477b-894b-26b3d7f523f0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bf4d38bd-32b0-477b-894b-26b3d7f523f0">
											<gml:posList>35.66889451692867 139.7481218316516 37.8 35.668894692825695 139.74811564567355 37.8 35.66889164661598 139.7481162564441 37.8 35.66889152374603 139.7481209511481 37.8 35.66889451692867 139.7481218316516 37.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0b7231d7-fb76-4c7f-ab17-59f2df6984cd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0b7231d7-fb76-4c7f-ab17-59f2df6984cd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0b7231d7-fb76-4c7f-ab17-59f2df6984cd">
											<gml:posList>35.66883297871118 139.74803065670136 37.8 35.66883297871118 139.74803065670136 5.62 35.66868501632642 139.74796431703194 5.62 35.66868501632642 139.74796431703194 37.8 35.66883297871118 139.74803065670136 37.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-37a5b14f-e916-43fd-bf7d-1e7f80e30989">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-37a5b14f-e916-43fd-bf7d-1e7f80e30989">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-37a5b14f-e916-43fd-bf7d-1e7f80e30989">
											<gml:posList>35.66882903225597 139.7480328590631 37.8 35.668686786392044 139.74796907598494 37.8 35.668686786392044 139.74796907598494 37.253 35.66882903225597 139.7480328590631 37.253 35.66882903225597 139.7480328590631 37.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b0b4be20-76ca-4a76-86c6-3d55e450ecc7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b0b4be20-76ca-4a76-86c6-3d55e450ecc7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b0b4be20-76ca-4a76-86c6-3d55e450ecc7">
											<gml:posList>35.66868501632642 139.74796431703194 37.8 35.66868501632642 139.74796431703194 5.62 35.66866001460101 139.74804398547803 5.62 35.66866001460101 139.74804398547803 37.8 35.66868501632642 139.74796431703194 37.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-27673680-44fd-4769-994a-f89bbfff4584">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-27673680-44fd-4769-994a-f89bbfff4584">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-27673680-44fd-4769-994a-f89bbfff4584">
											<gml:posList>35.668686786392044 139.74796907598494 37.8 35.66866397906835 139.7480417610103 37.8 35.66866397906835 139.7480417610103 37.253 35.668686786392044 139.74796907598494 37.253 35.668686786392044 139.74796907598494 37.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1372e97d-4725-44d3-bb83-dab3b1dc35fb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1372e97d-4725-44d3-bb83-dab3b1dc35fb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1372e97d-4725-44d3-bb83-dab3b1dc35fb">
											<gml:posList>35.66881930921662 139.74807496588483 37.8 35.66881930921662 139.74807496588483 5.62 35.66883297871118 139.74803065670136 5.62 35.66883297871118 139.74803065670136 37.8 35.66881930921662 139.74807496588483 37.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-285327bb-c938-4de8-b748-33b85c97c16b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-285327bb-c938-4de8-b748-33b85c97c16b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-285327bb-c938-4de8-b748-33b85c97c16b">
											<gml:posList>35.66881536278405 139.7480772013821 37.8 35.66882903225597 139.7480328590631 37.8 35.66882903225597 139.7480328590631 37.253 35.66881536278405 139.7480772013821 37.253 35.66881536278405 139.7480772013821 37.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5f305951-db92-47c7-bd58-ca014a157b66">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5f305951-db92-47c7-bd58-ca014a157b66">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5f305951-db92-47c7-bd58-ca014a157b66">
											<gml:posList>35.66866397906835 139.7480417610103 37.8 35.668799461424996 139.74810106669526 37.8 35.668799461424996 139.74810106669526 37.253 35.66866397906835 139.7480417610103 37.253 35.66866397906835 139.7480417610103 37.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4a8b47bd-96dd-47a8-82d7-35b186974d57">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4a8b47bd-96dd-47a8-82d7-35b186974d57">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4a8b47bd-96dd-47a8-82d7-35b186974d57">
											<gml:posList>35.668795442858666 139.74810326912925 5.62 35.668795442858666 139.74810326912925 37.8 35.66866001460101 139.74804398547803 37.8 35.66866001460101 139.74804398547803 5.62 35.668795442858666 139.74810326912925 5.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-444b8493-713d-41ac-9ce1-b7023f306dec">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-444b8493-713d-41ac-9ce1-b7023f306dec">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-444b8493-713d-41ac-9ce1-b7023f306dec">
											<gml:posList>35.66888756447648 139.74810504903724 37.8 35.66888756447648 139.74810504903724 5.62 35.66881930921662 139.74807496588483 5.62 35.66881930921662 139.74807496588483 37.8 35.66888756447648 139.74810504903724 37.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7cd76414-373a-42ef-8703-66d21cbcd134">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7cd76414-373a-42ef-8703-66d21cbcd134">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7cd76414-373a-42ef-8703-66d21cbcd134">
											<gml:posList>35.668886377103775 139.74810849666827 37.8 35.66881536278405 139.7480772013821 37.8 35.66881536278405 139.7480772013821 37.253 35.668886377103775 139.74810849666827 37.253 35.668886377103775 139.74810849666827 37.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7a67e22c-5939-4b84-b87b-ff99a1744717">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7a67e22c-5939-4b84-b87b-ff99a1744717">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7a67e22c-5939-4b84-b87b-ff99a1744717">
											<gml:posList>35.668892976230666 139.74811001400974 5.62 35.66888756447648 139.74810504903724 5.62 35.66888756447648 139.74810504903724 37.8 35.668892976230666 139.74811001400974 37.8 35.668892976230666 139.74811001400974 5.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c44f0404-254c-4f3e-8194-e63a18f51414">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c44f0404-254c-4f3e-8194-e63a18f51414">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c44f0404-254c-4f3e-8194-e63a18f51414">
											<gml:posList>35.668799461424996 139.74810106669526 37.8 35.66879469432084 139.7481154426629 37.8 35.66879469432084 139.7481154426629 37.253 35.668799461424996 139.74810106669526 37.253 35.668799461424996 139.74810106669526 37.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f7980ba7-8d40-4b98-9602-5711d524ef3c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f7980ba7-8d40-4b98-9602-5711d524ef3c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f7980ba7-8d40-4b98-9602-5711d524ef3c">
											<gml:posList>35.668890372709896 139.74811206029713 37.8 35.668886377103775 139.74810849666827 37.8 35.668886377103775 139.74810849666827 37.253 35.668890372709896 139.74811206029713 37.253 35.668890372709896 139.74811206029713 37.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-da3d2b7c-5bb7-4772-9fb9-1c076a3429aa">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-da3d2b7c-5bb7-4772-9fb9-1c076a3429aa">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-da3d2b7c-5bb7-4772-9fb9-1c076a3429aa">
											<gml:posList>35.668795442858666 139.74810326912925 37.8 35.668795442858666 139.74810326912925 5.62 35.668790675746415 139.74811763405003 5.62 35.668790675746415 139.74811763405003 37.8 35.668795442858666 139.74810326912925 37.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a50d06be-f3f3-4596-b1b5-27ec4eb16c61">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a50d06be-f3f3-4596-b1b5-27ec4eb16c61">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a50d06be-f3f3-4596-b1b5-27ec4eb16c61">
											<gml:posList>35.668894692825695 139.74811564567355 37.8 35.668894692825695 139.74811564567355 5.62 35.668892976230666 139.74811001400974 5.62 35.668892976230666 139.74811001400974 37.8 35.668894692825695 139.74811564567355 37.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-19d85d53-084c-4c68-be32-197c6ccc8e9b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-19d85d53-084c-4c68-be32-197c6ccc8e9b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-19d85d53-084c-4c68-be32-197c6ccc8e9b">
											<gml:posList>35.66889164661598 139.7481162564441 37.8 35.668890372709896 139.74811206029713 37.8 35.668890372709896 139.74811206029713 37.253 35.66889164661598 139.7481162564441 37.253 35.66889164661598 139.7481162564441 37.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1224f85e-bf21-4434-ae1e-d9a8a3f09095">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1224f85e-bf21-4434-ae1e-d9a8a3f09095">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1224f85e-bf21-4434-ae1e-d9a8a3f09095">
											<gml:posList>35.66889152374603 139.7481209511481 37.8 35.66889164661598 139.7481162564441 37.8 35.66889164661598 139.7481162564441 37.253 35.66889152374603 139.7481209511481 37.253 35.66889152374603 139.7481209511481 37.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3d027792-bf70-46c3-8bde-cdf0e15e5ee8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3d027792-bf70-46c3-8bde-cdf0e15e5ee8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3d027792-bf70-46c3-8bde-cdf0e15e5ee8">
											<gml:posList>35.66889451692867 139.7481218316516 37.8 35.66889451692867 139.7481218316516 5.62 35.668894692825695 139.74811564567355 5.62 35.668894692825695 139.74811564567355 37.8 35.66889451692867 139.7481218316516 37.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-adcd7921-3d64-47f8-8e4d-f92b6006717d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-adcd7921-3d64-47f8-8e4d-f92b6006717d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-adcd7921-3d64-47f8-8e4d-f92b6006717d">
											<gml:posList>35.66879469432084 139.7481154426629 37.8 35.66882774902421 139.74813007668178 37.8 35.66882774902421 139.74813007668178 37.253 35.66879469432084 139.7481154426629 37.253 35.66879469432084 139.7481154426629 37.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-705fb28f-9454-455d-bc0c-1ebae84b63e9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-705fb28f-9454-455d-bc0c-1ebae84b63e9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-705fb28f-9454-455d-bc0c-1ebae84b63e9">
											<gml:posList>35.668823766520084 139.7481322901228 5.62 35.668823766520084 139.7481322901228 37.8 35.668790675746415 139.74811763405003 37.8 35.668790675746415 139.74811763405003 5.62 35.668823766520084 139.7481322901228 5.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-25f19c7b-8366-427b-b906-3e1f7ae20f21">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-25f19c7b-8366-427b-b906-3e1f7ae20f21">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-25f19c7b-8366-427b-b906-3e1f7ae20f21">
											<gml:posList>35.66882774902421 139.74813007668178 37.8 35.66880552523149 139.7481995578172 37.8 35.66880552523149 139.7481995578172 37.253 35.66882774902421 139.74813007668178 37.253 35.66882774902421 139.74813007668178 37.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7f8fde74-3de4-4371-bf49-4b83af615a4b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7f8fde74-3de4-4371-bf49-4b83af615a4b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7f8fde74-3de4-4371-bf49-4b83af615a4b">
											<gml:posList>35.668823766520084 139.7481322901228 37.8 35.668823766520084 139.7481322901228 5.62 35.66880263098171 139.74819836791755 5.62 35.66880263098171 139.74819836791755 37.8 35.668823766520084 139.7481322901228 37.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ad8336b7-8c91-4574-a2ee-de98edc07632">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ad8336b7-8c91-4574-a2ee-de98edc07632">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ad8336b7-8c91-4574-a2ee-de98edc07632">
											<gml:posList>35.66886111802872 139.74821952528154 37.8 35.66889152374603 139.7481209511481 37.8 35.66889152374603 139.7481209511481 37.253 35.66886111802872 139.74821952528154 37.253 35.66886111802872 139.74821952528154 37.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-88896163-a484-496b-92a9-4d0efcfdbc48">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-88896163-a484-496b-92a9-4d0efcfdbc48">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-88896163-a484-496b-92a9-4d0efcfdbc48">
											<gml:posList>35.66886385042939 139.74822127870326 37.8 35.66886385042939 139.74822127870326 5.62 35.66889451692867 139.7481218316516 5.62 35.66889451692867 139.7481218316516 37.8 35.66886385042939 139.74822127870326 37.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1cdf3467-07b1-47cb-b47e-7696c9a33949">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1cdf3467-07b1-47cb-b47e-7696c9a33949">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1cdf3467-07b1-47cb-b47e-7696c9a33949">
											<gml:posList>35.66880552523149 139.7481995578172 37.8 35.668804015415695 139.748205910895 37.8 35.668804015415695 139.748205910895 37.253 35.66880552523149 139.7481995578172 37.253 35.66880552523149 139.7481995578172 37.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4e7dc469-8d51-4c58-8d3f-d277bc5ad8b9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4e7dc469-8d51-4c58-8d3f-d277bc5ad8b9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4e7dc469-8d51-4c58-8d3f-d277bc5ad8b9">
											<gml:posList>35.66880263098171 139.74819836791755 5.62 35.66880002473196 139.74820930626686 5.62 35.66880002473196 139.74820930626686 12.2 35.668800680805255 139.74820657719783 12.2 35.668800680805255 139.74820657719783 37.8 35.66880263098171 139.74819836791755 37.8 35.66880263098171 139.74819836791755 5.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9783459b-621b-4dac-8c01-14cae9c58d7f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9783459b-621b-4dac-8c01-14cae9c58d7f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9783459b-621b-4dac-8c01-14cae9c58d7f">
											<gml:posList>35.668804015415695 139.748205910895 37.8 35.668808401170416 139.74821309721318 37.8 35.668808401170416 139.74821309721318 37.253 35.668804015415695 139.748205910895 37.253 35.668804015415695 139.748205910895 37.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4d17d2f5-dc13-4bbc-9ce9-e483d0752d9d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4d17d2f5-dc13-4bbc-9ce9-e483d0752d9d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4d17d2f5-dc13-4bbc-9ce9-e483d0752d9d">
											<gml:posList>35.66880660969532 139.74821629142153 37.8 35.668800680805255 139.74820657719783 37.8 35.668800680805255 139.74820657719783 12.2 35.66880660969532 139.74821629142153 12.2 35.66880660969532 139.74821629142153 37.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ef46685a-293e-43d3-ad85-7b90fa516afc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ef46685a-293e-43d3-ad85-7b90fa516afc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ef46685a-293e-43d3-ad85-7b90fa516afc">
											<gml:posList>35.66880002473196 139.74820930626686 12.2 35.66880002473196 139.74820930626686 5.62 35.66880436334503 139.74822631256723 5.62 35.66880436334503 139.74822631256723 12.2 35.66880002473196 139.74820930626686 12.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-de7e0230-bd21-4e5a-9d52-7d98c836abf8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-de7e0230-bd21-4e5a-9d52-7d98c836abf8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-de7e0230-bd21-4e5a-9d52-7d98c836abf8">
											<gml:posList>35.668808401170416 139.74821309721318 37.8 35.6688499582577 139.74823119070982 37.8 35.6688499582577 139.74823119070982 37.253 35.668808401170416 139.74821309721318 37.253 35.668808401170416 139.74821309721318 37.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ad28e1db-5553-4bdd-8f49-a07129b2a334">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ad28e1db-5553-4bdd-8f49-a07129b2a334">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ad28e1db-5553-4bdd-8f49-a07129b2a334">
											<gml:posList>35.6688497078328 139.748233963534 12.2 35.66884969881907 139.74823396354356 37.8 35.66880660969532 139.74821629142153 37.8 35.66880660969532 139.74821629142153 12.2 35.6688497078328 139.748233963534 12.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2bd1ba47-9f4c-4ccc-9733-934727a397d5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2bd1ba47-9f4c-4ccc-9733-934727a397d5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2bd1ba47-9f4c-4ccc-9733-934727a397d5">
											<gml:posList>35.6688499582577 139.74823119070982 37.8 35.66886111802872 139.74821952528154 37.8 35.66886111802872 139.74821952528154 37.253 35.6688499582577 139.74823119070982 37.253 35.6688499582577 139.74823119070982 37.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-799b902c-81e1-4c61-93eb-e3deb201050f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-799b902c-81e1-4c61-93eb-e3deb201050f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-799b902c-81e1-4c61-93eb-e3deb201050f">
											<gml:posList>35.6688497078328 139.748233963534 12.2 35.66884475335083 139.74823830988944 12.2 35.66884475335083 139.74823830988944 5.62 35.66886385042939 139.74822127870326 5.62 35.66886385042939 139.74822127870326 37.8 35.66884969881907 139.74823396354356 37.8 35.6688497078328 139.748233963534 12.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d8f1aab5-b015-4c2c-87f7-34089562dfd4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d8f1aab5-b015-4c2c-87f7-34089562dfd4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d8f1aab5-b015-4c2c-87f7-34089562dfd4">
											<gml:posList>35.66880436334503 139.74822631256723 12.2 35.66880436334503 139.74822631256723 5.62 35.66881491619737 139.74823591142496 5.62 35.66881491619737 139.74823591142496 12.2 35.66880436334503 139.74822631256723 12.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-356d1a64-1681-4102-8474-788da886003c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-356d1a64-1681-4102-8474-788da886003c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-356d1a64-1681-4102-8474-788da886003c">
											<gml:posList>35.66881491619737 139.74823591142496 5.62 35.668826186322335 139.7482400969615 5.62 35.668826186322335 139.7482400969615 12.2 35.66881491619737 139.74823591142496 12.2 35.66881491619737 139.74823591142496 5.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ff747c10-1200-4830-b003-f8eef17e89b6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ff747c10-1200-4830-b003-f8eef17e89b6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ff747c10-1200-4830-b003-f8eef17e89b6">
											<gml:posList>35.668826186322335 139.7482400969615 5.62 35.66884475335083 139.74823830988944 5.62 35.66884475335083 139.74823830988944 12.2 35.668826186322335 139.7482400969615 12.2 35.668826186322335 139.7482400969615 5.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区虎ノ門二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-7141</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">241.26005</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1210</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>7</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.03</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>