<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_01bdff45-ab13-42ad-b943-f8ceade71da6">
			<core:creationDate>2024-03-15</core:creationDate>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.67022902095702 139.73874488497958 0 35.670213835183176 139.73867906732607 0 35.67014149265735 139.73870413929404 0 35.67015668743135 139.73876995688235 0 35.67022902095702 139.73874488497958 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67022902095702 139.73874488497958 20.685 35.67015668743135 139.73876995688235 20.685 35.67014149265735 139.73870413929404 20.685 35.670213835183176 139.73867906732607 20.685 35.67022902095702 139.73874488497958 20.685</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67022902095702 139.73874488497958 20.685 35.670213835183176 139.73867906732607 20.685 35.670213835183176 139.73867906732607 23.685 35.67022902095702 139.73874488497958 23.685 35.67022902095702 139.73874488497958 20.685</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670213835183176 139.73867906732607 20.685 35.67014149265735 139.73870413929404 20.685 35.67014149265735 139.73870413929404 23.685 35.670213835183176 139.73867906732607 23.685 35.670213835183176 139.73867906732607 20.685</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67014149265735 139.73870413929404 20.685 35.67015668743135 139.73876995688235 20.685 35.67015668743135 139.73876995688235 23.685 35.67014149265735 139.73870413929404 23.685 35.67014149265735 139.73870413929404 20.685</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67015668743135 139.73876995688235 20.685 35.67022902095702 139.73874488497958 20.685 35.67022902095702 139.73874488497958 23.685 35.67015668743135 139.73876995688235 23.685 35.67015668743135 139.73876995688235 20.685</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67022902095702 139.73874488497958 23.685 35.670213835183176 139.73867906732607 23.685 35.67014149265735 139.73870413929404 23.685 35.67015668743135 139.73876995688235 23.685 35.67022902095702 139.73874488497958 23.685</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-9d9b780e-60e2-4a3d-8722-4d31c86f6950"/>
							<gml:surfaceMember xlink:href="#poly-20661656-93cd-4249-930c-392ad108d53a"/>
							<gml:surfaceMember xlink:href="#poly-c5b28a6a-4527-469e-a1a9-83ed0df40546"/>
							<gml:surfaceMember xlink:href="#poly-511200b8-4ce9-47fa-8c0f-aaf662f0b15c"/>
							<gml:surfaceMember xlink:href="#poly-b011e63e-2eb9-409d-99c1-ad57c8774438"/>
							<gml:surfaceMember xlink:href="#poly-7c2a4757-ade2-40d6-b4fb-bd136007ff23"/>
							<gml:surfaceMember xlink:href="#poly-8249f60e-b62a-40b7-9649-aa4136a10d77"/>
							<gml:surfaceMember xlink:href="#poly-9e9db93a-8644-4303-8109-e07818e29f0d"/>
							<gml:surfaceMember xlink:href="#poly-d7b27f7c-079e-4949-b1c8-ae237c430455"/>
							<gml:surfaceMember xlink:href="#poly-5b56b180-58fb-434b-9b1b-c403595dcd83"/>
							<gml:surfaceMember xlink:href="#poly-f395ed90-6eea-4f67-9863-e293f705d5b9"/>
							<gml:surfaceMember xlink:href="#poly-f1a4399d-d160-46c8-a7e2-e24d217bfc9b"/>
							<gml:surfaceMember xlink:href="#poly-5035c4d4-41ce-4eef-adcb-e050a5bc9214"/>
							<gml:surfaceMember xlink:href="#poly-fee993ab-5650-49fb-a554-69d8afc32721"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-9d9b780e-60e2-4a3d-8722-4d31c86f6950">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9d9b780e-60e2-4a3d-8722-4d31c86f6950">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9d9b780e-60e2-4a3d-8722-4d31c86f6950">
											<gml:posList>35.67022902095704 139.73874488497955 20.685 35.67015668743134 139.73876995688232 20.685 35.670141492657336 139.73870413929401 20.685 35.67021383518315 139.73867906732607 20.685 35.67022902095704 139.73874488497955 20.685</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-20661656-93cd-4249-930c-392ad108d53a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-20661656-93cd-4249-930c-392ad108d53a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-20661656-93cd-4249-930c-392ad108d53a">
											<gml:posList>35.670141492657336 139.73870413929401 25.674 35.670145641209366 139.7387069843243 25.674 35.67021152264196 139.73868414027845 25.674 35.67021383518315 139.73867906732607 25.674 35.670141492657336 139.73870413929401 25.674</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c5b28a6a-4527-469e-a1a9-83ed0df40546">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c5b28a6a-4527-469e-a1a9-83ed0df40546">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c5b28a6a-4527-469e-a1a9-83ed0df40546">
											<gml:posList>35.67021383518315 139.73867906732607 25.674 35.67021152264196 139.73868414027845 25.674 35.67022488141968 139.73874203993373 25.674 35.67022902095704 139.73874488497955 25.674 35.67021383518315 139.73867906732607 25.674</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-511200b8-4ce9-47fa-8c0f-aaf662f0b15c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-511200b8-4ce9-47fa-8c0f-aaf662f0b15c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-511200b8-4ce9-47fa-8c0f-aaf662f0b15c">
											<gml:posList>35.67022488141968 139.73874203993373 23.772 35.67021152264196 139.73868414027845 23.772 35.670145641209366 139.7387069843243 23.772 35.6701590089899 139.73876488392523 23.772 35.67022488141968 139.73874203993373 23.772</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b011e63e-2eb9-409d-99c1-ad57c8774438">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b011e63e-2eb9-409d-99c1-ad57c8774438">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b011e63e-2eb9-409d-99c1-ad57c8774438">
											<gml:posList>35.67015668743134 139.73876995688232 25.674 35.6701590089899 139.73876488392523 25.674 35.670145641209366 139.7387069843243 25.674 35.670141492657336 139.73870413929401 25.674 35.67015668743134 139.73876995688232 25.674</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-7c2a4757-ade2-40d6-b4fb-bd136007ff23">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7c2a4757-ade2-40d6-b4fb-bd136007ff23">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7c2a4757-ade2-40d6-b4fb-bd136007ff23">
											<gml:posList>35.67022902095704 139.73874488497955 25.674 35.67022488141968 139.73874203993373 25.674 35.6701590089899 139.73876488392523 25.674 35.67015668743134 139.73876995688232 25.674 35.67022902095704 139.73874488497955 25.674</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8249f60e-b62a-40b7-9649-aa4136a10d77">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8249f60e-b62a-40b7-9649-aa4136a10d77">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8249f60e-b62a-40b7-9649-aa4136a10d77">
											<gml:posList>35.670141492657336 139.73870413929401 20.685 35.67015668743134 139.73876995688232 20.685 35.67015668743134 139.73876995688232 25.674 35.670141492657336 139.73870413929401 25.674 35.670141492657336 139.73870413929401 20.685</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9e9db93a-8644-4303-8109-e07818e29f0d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9e9db93a-8644-4303-8109-e07818e29f0d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9e9db93a-8644-4303-8109-e07818e29f0d">
											<gml:posList>35.6701590089899 139.73876488392523 25.674 35.6701590089899 139.73876488392523 23.772 35.670145641209366 139.7387069843243 23.772 35.670145641209366 139.7387069843243 25.674 35.6701590089899 139.73876488392523 25.674</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d7b27f7c-079e-4949-b1c8-ae237c430455">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d7b27f7c-079e-4949-b1c8-ae237c430455">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d7b27f7c-079e-4949-b1c8-ae237c430455">
											<gml:posList>35.67021383518315 139.73867906732607 20.685 35.670141492657336 139.73870413929401 20.685 35.670141492657336 139.73870413929401 25.674 35.67021383518315 139.73867906732607 25.674 35.67021383518315 139.73867906732607 20.685</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5b56b180-58fb-434b-9b1b-c403595dcd83">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5b56b180-58fb-434b-9b1b-c403595dcd83">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5b56b180-58fb-434b-9b1b-c403595dcd83">
											<gml:posList>35.670145641209366 139.7387069843243 25.674 35.670145641209366 139.7387069843243 23.772 35.67021152264196 139.73868414027845 23.772 35.67021152264196 139.73868414027845 25.674 35.670145641209366 139.7387069843243 25.674</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f395ed90-6eea-4f67-9863-e293f705d5b9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f395ed90-6eea-4f67-9863-e293f705d5b9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f395ed90-6eea-4f67-9863-e293f705d5b9">
											<gml:posList>35.67021152264196 139.73868414027845 25.674 35.67021152264196 139.73868414027845 23.772 35.67022488141968 139.73874203993373 23.772 35.67022488141968 139.73874203993373 25.674 35.67021152264196 139.73868414027845 25.674</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f1a4399d-d160-46c8-a7e2-e24d217bfc9b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f1a4399d-d160-46c8-a7e2-e24d217bfc9b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f1a4399d-d160-46c8-a7e2-e24d217bfc9b">
											<gml:posList>35.67022902095704 139.73874488497955 20.685 35.67021383518315 139.73867906732607 20.685 35.67021383518315 139.73867906732607 25.674 35.67022902095704 139.73874488497955 25.674 35.67022902095704 139.73874488497955 20.685</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5035c4d4-41ce-4eef-adcb-e050a5bc9214">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5035c4d4-41ce-4eef-adcb-e050a5bc9214">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5035c4d4-41ce-4eef-adcb-e050a5bc9214">
											<gml:posList>35.67022488141968 139.73874203993373 25.674 35.67022488141968 139.73874203993373 23.772 35.6701590089899 139.73876488392523 23.772 35.6701590089899 139.73876488392523 25.674 35.67022488141968 139.73874203993373 25.674</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-fee993ab-5650-49fb-a554-69d8afc32721">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fee993ab-5650-49fb-a554-69d8afc32721">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fee993ab-5650-49fb-a554-69d8afc32721">
											<gml:posList>35.67015668743134 139.73876995688232 20.685 35.67022902095704 139.73874488497955 20.685 35.67022902095704 139.73874488497955 25.674 35.67015668743134 139.73876995688232 25.674 35.67015668743134 139.73876995688232 20.685</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-6460</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>4</uro:specifiedFloorAreaRate>
					<uro:surveyYear>0001</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">0</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>