<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_027fb3e9-119e-4bf2-a84c-1320b0eeb6f2">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">413</bldg:usage>
			<bldg:measuredHeight uom="m">14.1</bldg:measuredHeight>
			<bldg:storeysAboveGround>5</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.66884483529502 139.73985175229564 0 35.66890852617814 139.7399096256536 0 35.668965780585324 139.73981566739525 0 35.668902278739864 139.7397575287448 0 35.66884483529502 139.73985175229564 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66884483529502 139.73985175229564 11.455 35.668902278739864 139.7397575287448 11.455 35.668965780585324 139.73981566739525 11.455 35.66890852617814 139.7399096256536 11.455 35.66884483529502 139.73985175229564 11.455</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66884483529502 139.73985175229564 11.455 35.66890852617814 139.7399096256536 11.455 35.66890852617814 139.7399096256536 25.56 35.66884483529502 139.73985175229564 25.56 35.66884483529502 139.73985175229564 11.455</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66890852617814 139.7399096256536 11.455 35.668965780585324 139.73981566739525 11.455 35.668965780585324 139.73981566739525 25.56 35.66890852617814 139.7399096256536 25.56 35.66890852617814 139.7399096256536 11.455</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668965780585324 139.73981566739525 11.455 35.668902278739864 139.7397575287448 11.455 35.668902278739864 139.7397575287448 25.56 35.668965780585324 139.73981566739525 25.56 35.668965780585324 139.73981566739525 11.455</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668902278739864 139.7397575287448 11.455 35.66884483529502 139.73985175229564 11.455 35.66884483529502 139.73985175229564 25.56 35.668902278739864 139.7397575287448 25.56 35.668902278739864 139.7397575287448 11.455</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66884483529502 139.73985175229564 25.56 35.66890852617814 139.7399096256536 25.56 35.668965780585324 139.73981566739525 25.56 35.668902278739864 139.7397575287448 25.56 35.66884483529502 139.73985175229564 25.56</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-31cae1c1-a407-4eb0-bc00-d593539ba75f"/>
							<gml:surfaceMember xlink:href="#poly-e5f7d498-4794-41cc-beed-d09661682986"/>
							<gml:surfaceMember xlink:href="#poly-0ad1c36c-0c36-40f9-9be7-b1991889fabf"/>
							<gml:surfaceMember xlink:href="#poly-cbc26cff-4fb2-4c29-a32d-2999f09f57ac"/>
							<gml:surfaceMember xlink:href="#poly-5310aa66-a0b3-43fc-82c4-ad427831c15b"/>
							<gml:surfaceMember xlink:href="#poly-4df8c713-05d0-49ce-a62e-1d72d50be80b"/>
							<gml:surfaceMember xlink:href="#poly-32a46b5c-0b99-4bd3-8c9b-637507e300f3"/>
							<gml:surfaceMember xlink:href="#poly-8933aff3-a6bc-4286-87e2-7e4f9b720cef"/>
							<gml:surfaceMember xlink:href="#poly-e4aec66c-7d42-48ce-8d57-65438e216d59"/>
							<gml:surfaceMember xlink:href="#poly-6df9ff97-1a17-46f9-9e1a-b9f3e02065b5"/>
							<gml:surfaceMember xlink:href="#poly-c8760b0a-810e-4e5c-9062-0258b3a99092"/>
							<gml:surfaceMember xlink:href="#poly-14dcd7b5-adb5-48f5-92e9-a25821969d9b"/>
							<gml:surfaceMember xlink:href="#poly-22236cb4-816d-4f45-a3e4-8463f6d8a5bd"/>
							<gml:surfaceMember xlink:href="#poly-18830a11-60b8-4563-a46f-c9467f2497c0"/>
							<gml:surfaceMember xlink:href="#poly-1808ec9b-e594-4796-94fa-7f3e0df16ee1"/>
							<gml:surfaceMember xlink:href="#poly-ba11fff5-ba2c-401d-b43c-f36d3ac31b17"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-31cae1c1-a407-4eb0-bc00-d593539ba75f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-31cae1c1-a407-4eb0-bc00-d593539ba75f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-31cae1c1-a407-4eb0-bc00-d593539ba75f">
											<gml:posList>35.668844835295 139.73985175229564 11.455 35.66890227873987 139.7397575287448 11.455 35.66896578058528 139.73981566739522 11.455 35.668908526178114 139.73990962565358 11.455 35.668844835295 139.73985175229564 11.455</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e5f7d498-4794-41cc-beed-d09661682986">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e5f7d498-4794-41cc-beed-d09661682986">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e5f7d498-4794-41cc-beed-d09661682986">
											<gml:posList>35.6688642352652 139.73982003855886 26.36 35.668866091869475 139.73981974919627 26.36 35.66890255094565 139.7397598370528 26.36 35.66890227873987 139.7397575287448 26.36 35.6688642352652 139.73982003855886 26.36</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-0ad1c36c-0c36-40f9-9be7-b1991889fabf">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0ad1c36c-0c36-40f9-9be7-b1991889fabf">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0ad1c36c-0c36-40f9-9be7-b1991889fabf">
											<gml:posList>35.668844835295 139.73985175229564 21.544 35.668908526178114 139.73990962565358 21.544 35.66892611660788 139.73988075285186 26.36 35.668844835295 139.73985175229564 21.544</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-cbc26cff-4fb2-4c29-a32d-2999f09f57ac">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cbc26cff-4fb2-4c29-a32d-2999f09f57ac">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cbc26cff-4fb2-4c29-a32d-2999f09f57ac">
											<gml:posList>35.66892611660788 139.73988075285186 26.36 35.6688642352652 139.73982003855886 26.36 35.668844835295 139.73985175229564 21.544 35.66892611660788 139.73988075285186 26.36</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-5310aa66-a0b3-43fc-82c4-ad427831c15b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5310aa66-a0b3-43fc-82c4-ad427831c15b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5310aa66-a0b3-43fc-82c4-ad427831c15b">
											<gml:posList>35.66892611660788 139.73988075285186 26.36 35.66892587141988 139.7398784113731 26.36 35.668866091869475 139.73981974919627 26.36 35.6688642352652 139.73982003855886 26.36 35.66892611660788 139.73988075285186 26.36</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-4df8c713-05d0-49ce-a62e-1d72d50be80b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4df8c713-05d0-49ce-a62e-1d72d50be80b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4df8c713-05d0-49ce-a62e-1d72d50be80b">
											<gml:posList>35.6689639059965 139.73981601200958 25.79 35.66890255094565 139.7397598370528 25.79 35.668866091869475 139.73981974919627 25.79 35.66892587141988 139.7398784113731 25.79 35.6689639059965 139.73981601200958 25.79</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-32a46b5c-0b99-4bd3-8c9b-637507e300f3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-32a46b5c-0b99-4bd3-8c9b-637507e300f3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-32a46b5c-0b99-4bd3-8c9b-637507e300f3">
											<gml:posList>35.66890227873987 139.7397575287448 26.36 35.66890255094565 139.7397598370528 26.36 35.6689639059965 139.73981601200958 26.36 35.66896578058528 139.73981566739522 26.36 35.66890227873987 139.7397575287448 26.36</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-8933aff3-a6bc-4286-87e2-7e4f9b720cef">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8933aff3-a6bc-4286-87e2-7e4f9b720cef">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8933aff3-a6bc-4286-87e2-7e4f9b720cef">
											<gml:posList>35.66896578058528 139.73981566739522 26.36 35.6689639059965 139.73981601200958 26.36 35.66892587141988 139.7398784113731 26.36 35.66892611660788 139.73988075285186 26.36 35.66896578058528 139.73981566739522 26.36</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e4aec66c-7d42-48ce-8d57-65438e216d59">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e4aec66c-7d42-48ce-8d57-65438e216d59">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e4aec66c-7d42-48ce-8d57-65438e216d59">
											<gml:posList>35.66892587141988 139.7398784113731 26.36 35.66892587141988 139.7398784113731 25.79 35.668866091869475 139.73981974919627 25.79 35.668866091869475 139.73981974919627 26.36 35.66892587141988 139.7398784113731 26.36</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6df9ff97-1a17-46f9-9e1a-b9f3e02065b5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6df9ff97-1a17-46f9-9e1a-b9f3e02065b5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6df9ff97-1a17-46f9-9e1a-b9f3e02065b5">
											<gml:posList>35.66896578058528 139.73981566739522 11.455 35.66890227873987 139.7397575287448 11.455 35.66890227873987 139.7397575287448 26.36 35.66896578058528 139.73981566739522 26.36 35.66896578058528 139.73981566739522 11.455</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c8760b0a-810e-4e5c-9062-0258b3a99092">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c8760b0a-810e-4e5c-9062-0258b3a99092">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c8760b0a-810e-4e5c-9062-0258b3a99092">
											<gml:posList>35.66890255094565 139.7397598370528 26.36 35.66890255094565 139.7397598370528 25.79 35.6689639059965 139.73981601200958 25.79 35.6689639059965 139.73981601200958 26.36 35.66890255094565 139.7397598370528 26.36</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-14dcd7b5-adb5-48f5-92e9-a25821969d9b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-14dcd7b5-adb5-48f5-92e9-a25821969d9b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-14dcd7b5-adb5-48f5-92e9-a25821969d9b">
											<gml:posList>35.668866091869475 139.73981974919627 26.36 35.668866091869475 139.73981974919627 25.79 35.66890255094565 139.7397598370528 25.79 35.66890255094565 139.7397598370528 26.36 35.668866091869475 139.73981974919627 26.36</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-22236cb4-816d-4f45-a3e4-8463f6d8a5bd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-22236cb4-816d-4f45-a3e4-8463f6d8a5bd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-22236cb4-816d-4f45-a3e4-8463f6d8a5bd">
											<gml:posList>35.66890227873987 139.7397575287448 26.36 35.66890227873987 139.7397575287448 11.455 35.668844835295 139.73985175229564 11.455 35.668844835295 139.73985175229564 21.544 35.6688642352652 139.73982003855886 26.36 35.66890227873987 139.7397575287448 26.36</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-18830a11-60b8-4563-a46f-c9467f2497c0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-18830a11-60b8-4563-a46f-c9467f2497c0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-18830a11-60b8-4563-a46f-c9467f2497c0">
											<gml:posList>35.6689639059965 139.73981601200958 26.36 35.6689639059965 139.73981601200958 25.79 35.66892587141988 139.7398784113731 25.79 35.66892587141988 139.7398784113731 26.36 35.6689639059965 139.73981601200958 26.36</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1808ec9b-e594-4796-94fa-7f3e0df16ee1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1808ec9b-e594-4796-94fa-7f3e0df16ee1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1808ec9b-e594-4796-94fa-7f3e0df16ee1">
											<gml:posList>35.66896578058528 139.73981566739522 26.36 35.66892611660788 139.73988075285186 26.36 35.668908526178114 139.73990962565358 21.544 35.668908526178114 139.73990962565358 11.455 35.66896578058528 139.73981566739522 11.455 35.66896578058528 139.73981566739522 26.36</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ba11fff5-ba2c-401d-b43c-f36d3ac31b17">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ba11fff5-ba2c-401d-b43c-f36d3ac31b17">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ba11fff5-ba2c-401d-b43c-f36d3ac31b17">
											<gml:posList>35.668844835295 139.73985175229564 11.455 35.668908526178114 139.73990962565358 11.455 35.668908526178114 139.73990962565358 21.544 35.668844835295 139.73985175229564 21.544 35.668844835295 139.73985175229564 11.455</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-8778</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">87.0284</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">211</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1230</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>4</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.01</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>