<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_050284a6-7128-4d9d-95b8-4fa44a83f81e">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>18</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103018002</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="地区計画">
				<gen:value>虎ノ門二丁目地区</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">401</bldg:usage>
			<bldg:measuredHeight uom="m">26.7</bldg:measuredHeight>
			<bldg:storeysAboveGround>2</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.66953641396712 139.74593644315166 0 35.669619057395835 139.74583235351906 0 35.669501743502956 139.7456957855751 0 35.66947112874509 139.7457396721921 0 35.669343195970114 139.745577544493 0 35.669533384544 139.745328908573 0 35.66947310191595 139.745256600462 0 35.66948849219101 139.74523719758548 0 35.669528128801865 139.74520465628427 0 35.66954539055927 139.7451806561307 0 35.6695596344311 139.74514669566122 0 35.66956464486405 139.74510813909552 0 35.66956319294309 139.74508256886202 0 35.66955604216406 139.7450540334904 0 35.6695391963742 139.74501835090038 0 35.66948418149436 139.7450865661588 0 35.66945331311905 139.74505466576448 0 35.66899972236218 139.74557025444116 0 35.66950938737759 139.7461679997057 0 35.66957287622334 139.74608795656852 0 35.66963305073126 139.74616101665112 0 35.669661058381955 139.74612641171717 0 35.66963651936601 139.74609650331993 0 35.66962427166234 139.7461116498791 0 35.66956418742188 139.74603881066628 0 35.66957589477351 139.74602432746468 0 35.66955153624682 139.74599475031818 0 35.66956999787686 139.74597197514262 0 35.66953641396712 139.74593644315166 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66953641396712 139.74593644315166 6.92 35.66956999787686 139.74597197514262 6.92 35.66955153624682 139.74599475031818 6.92 35.66957589477351 139.74602432746468 6.92 35.66956418742188 139.74603881066628 6.92 35.66962427166234 139.7461116498791 6.92 35.66963651936601 139.74609650331993 6.92 35.669661058381955 139.74612641171717 6.92 35.66963305073126 139.74616101665112 6.92 35.66957287622334 139.74608795656852 6.92 35.66950938737759 139.7461679997057 6.92 35.66899972236218 139.74557025444116 6.92 35.66945331311905 139.74505466576448 6.92 35.66948418149436 139.7450865661588 6.92 35.6695391963742 139.74501835090038 6.92 35.66955604216406 139.7450540334904 6.92 35.66956319294309 139.74508256886202 6.92 35.66956464486405 139.74510813909552 6.92 35.6695596344311 139.74514669566122 6.92 35.66954539055927 139.7451806561307 6.92 35.669528128801865 139.74520465628427 6.92 35.66948849219101 139.74523719758548 6.92 35.66947310191595 139.745256600462 6.92 35.669533384544 139.745328908573 6.92 35.669343195970114 139.745577544493 6.92 35.66947112874509 139.7457396721921 6.92 35.669501743502956 139.7456957855751 6.92 35.669619057395835 139.74583235351906 6.92 35.66953641396712 139.74593644315166 6.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66953641396712 139.74593644315166 6.92 35.669619057395835 139.74583235351906 6.92 35.669619057395835 139.74583235351906 26.370000000000005 35.66953641396712 139.74593644315166 26.370000000000005 35.66953641396712 139.74593644315166 6.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669619057395835 139.74583235351906 6.92 35.669501743502956 139.7456957855751 6.92 35.669501743502956 139.7456957855751 26.370000000000005 35.669619057395835 139.74583235351906 26.370000000000005 35.669619057395835 139.74583235351906 6.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669501743502956 139.7456957855751 6.92 35.66947112874509 139.7457396721921 6.92 35.66947112874509 139.7457396721921 26.370000000000005 35.669501743502956 139.7456957855751 26.370000000000005 35.669501743502956 139.7456957855751 6.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66947112874509 139.7457396721921 6.92 35.669343195970114 139.745577544493 6.92 35.669343195970114 139.745577544493 26.370000000000005 35.66947112874509 139.7457396721921 26.370000000000005 35.66947112874509 139.7457396721921 6.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669343195970114 139.745577544493 6.92 35.669533384544 139.745328908573 6.92 35.669533384544 139.745328908573 26.370000000000005 35.669343195970114 139.745577544493 26.370000000000005 35.669343195970114 139.745577544493 6.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669533384544 139.745328908573 6.92 35.66947310191595 139.745256600462 6.92 35.66947310191595 139.745256600462 26.370000000000005 35.669533384544 139.745328908573 26.370000000000005 35.669533384544 139.745328908573 6.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66947310191595 139.745256600462 6.92 35.66948849219101 139.74523719758548 6.92 35.66948849219101 139.74523719758548 26.370000000000005 35.66947310191595 139.745256600462 26.370000000000005 35.66947310191595 139.745256600462 6.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66948849219101 139.74523719758548 6.92 35.669528128801865 139.74520465628427 6.92 35.669528128801865 139.74520465628427 26.370000000000005 35.66948849219101 139.74523719758548 26.370000000000005 35.66948849219101 139.74523719758548 6.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669528128801865 139.74520465628427 6.92 35.66954539055927 139.7451806561307 6.92 35.66954539055927 139.7451806561307 26.370000000000005 35.669528128801865 139.74520465628427 26.370000000000005 35.669528128801865 139.74520465628427 6.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66954539055927 139.7451806561307 6.92 35.6695596344311 139.74514669566122 6.92 35.6695596344311 139.74514669566122 26.370000000000005 35.66954539055927 139.7451806561307 26.370000000000005 35.66954539055927 139.7451806561307 6.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6695596344311 139.74514669566122 6.92 35.66956464486405 139.74510813909552 6.92 35.66956464486405 139.74510813909552 26.370000000000005 35.6695596344311 139.74514669566122 26.370000000000005 35.6695596344311 139.74514669566122 6.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66956464486405 139.74510813909552 6.92 35.66956319294309 139.74508256886202 6.92 35.66956319294309 139.74508256886202 26.370000000000005 35.66956464486405 139.74510813909552 26.370000000000005 35.66956464486405 139.74510813909552 6.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66956319294309 139.74508256886202 6.92 35.66955604216406 139.7450540334904 6.92 35.66955604216406 139.7450540334904 26.370000000000005 35.66956319294309 139.74508256886202 26.370000000000005 35.66956319294309 139.74508256886202 6.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66955604216406 139.7450540334904 6.92 35.6695391963742 139.74501835090038 6.92 35.6695391963742 139.74501835090038 26.370000000000005 35.66955604216406 139.7450540334904 26.370000000000005 35.66955604216406 139.7450540334904 6.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6695391963742 139.74501835090038 6.92 35.66948418149436 139.7450865661588 6.92 35.66948418149436 139.7450865661588 26.370000000000005 35.6695391963742 139.74501835090038 26.370000000000005 35.6695391963742 139.74501835090038 6.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66948418149436 139.7450865661588 6.92 35.66945331311905 139.74505466576448 6.92 35.66945331311905 139.74505466576448 26.370000000000005 35.66948418149436 139.7450865661588 26.370000000000005 35.66948418149436 139.7450865661588 6.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66945331311905 139.74505466576448 6.92 35.66899972236218 139.74557025444116 6.92 35.66899972236218 139.74557025444116 26.370000000000005 35.66945331311905 139.74505466576448 26.370000000000005 35.66945331311905 139.74505466576448 6.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66899972236218 139.74557025444116 6.92 35.66950938737759 139.7461679997057 6.92 35.66950938737759 139.7461679997057 26.370000000000005 35.66899972236218 139.74557025444116 26.370000000000005 35.66899972236218 139.74557025444116 6.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66950938737759 139.7461679997057 6.92 35.66957287622334 139.74608795656852 6.92 35.66957287622334 139.74608795656852 26.370000000000005 35.66950938737759 139.7461679997057 26.370000000000005 35.66950938737759 139.7461679997057 6.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66957287622334 139.74608795656852 6.92 35.66963305073126 139.74616101665112 6.92 35.66963305073126 139.74616101665112 26.370000000000005 35.66957287622334 139.74608795656852 26.370000000000005 35.66957287622334 139.74608795656852 6.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66963305073126 139.74616101665112 6.92 35.669661058381955 139.74612641171717 6.92 35.669661058381955 139.74612641171717 26.370000000000005 35.66963305073126 139.74616101665112 26.370000000000005 35.66963305073126 139.74616101665112 6.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669661058381955 139.74612641171717 6.92 35.66963651936601 139.74609650331993 6.92 35.66963651936601 139.74609650331993 26.370000000000005 35.669661058381955 139.74612641171717 26.370000000000005 35.669661058381955 139.74612641171717 6.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66963651936601 139.74609650331993 6.92 35.66962427166234 139.7461116498791 6.92 35.66962427166234 139.7461116498791 26.370000000000005 35.66963651936601 139.74609650331993 26.370000000000005 35.66963651936601 139.74609650331993 6.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66962427166234 139.7461116498791 6.92 35.66956418742188 139.74603881066628 6.92 35.66956418742188 139.74603881066628 26.370000000000005 35.66962427166234 139.7461116498791 26.370000000000005 35.66962427166234 139.7461116498791 6.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66956418742188 139.74603881066628 6.92 35.66957589477351 139.74602432746468 6.92 35.66957589477351 139.74602432746468 26.370000000000005 35.66956418742188 139.74603881066628 26.370000000000005 35.66956418742188 139.74603881066628 6.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66957589477351 139.74602432746468 6.92 35.66955153624682 139.74599475031818 6.92 35.66955153624682 139.74599475031818 26.370000000000005 35.66957589477351 139.74602432746468 26.370000000000005 35.66957589477351 139.74602432746468 6.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66955153624682 139.74599475031818 6.92 35.66956999787686 139.74597197514262 6.92 35.66956999787686 139.74597197514262 26.370000000000005 35.66955153624682 139.74599475031818 26.370000000000005 35.66955153624682 139.74599475031818 6.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66956999787686 139.74597197514262 6.92 35.66953641396712 139.74593644315166 6.92 35.66953641396712 139.74593644315166 26.370000000000005 35.66956999787686 139.74597197514262 26.370000000000005 35.66956999787686 139.74597197514262 6.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66953641396712 139.74593644315166 26.370000000000005 35.669619057395835 139.74583235351906 26.370000000000005 35.669501743502956 139.7456957855751 26.370000000000005 35.66947112874509 139.7457396721921 26.370000000000005 35.669343195970114 139.745577544493 26.370000000000005 35.669533384544 139.745328908573 26.370000000000005 35.66947310191595 139.745256600462 26.370000000000005 35.66948849219101 139.74523719758548 26.370000000000005 35.669528128801865 139.74520465628427 26.370000000000005 35.66954539055927 139.7451806561307 26.370000000000005 35.6695596344311 139.74514669566122 26.370000000000005 35.66956464486405 139.74510813909552 26.370000000000005 35.66956319294309 139.74508256886202 26.370000000000005 35.66955604216406 139.7450540334904 26.370000000000005 35.6695391963742 139.74501835090038 26.370000000000005 35.66948418149436 139.7450865661588 26.370000000000005 35.66945331311905 139.74505466576448 26.370000000000005 35.66899972236218 139.74557025444116 26.370000000000005 35.66950938737759 139.7461679997057 26.370000000000005 35.66957287622334 139.74608795656852 26.370000000000005 35.66963305073126 139.74616101665112 26.370000000000005 35.669661058381955 139.74612641171717 26.370000000000005 35.66963651936601 139.74609650331993 26.370000000000005 35.66962427166234 139.7461116498791 26.370000000000005 35.66956418742188 139.74603881066628 26.370000000000005 35.66957589477351 139.74602432746468 26.370000000000005 35.66955153624682 139.74599475031818 26.370000000000005 35.66956999787686 139.74597197514262 26.370000000000005 35.66953641396712 139.74593644315166 26.370000000000005</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-9c35a6cb-4b3c-416f-8da0-3a4229b3d7f6"/>
							<gml:surfaceMember xlink:href="#poly-0f161f07-f302-4efd-8426-c37128c15ee6"/>
							<gml:surfaceMember xlink:href="#poly-957ec286-a81d-4258-beb5-070b05ea7fc9"/>
							<gml:surfaceMember xlink:href="#poly-a0b36f6e-b624-4404-91b2-a3e65327abc5"/>
							<gml:surfaceMember xlink:href="#poly-cd7da57e-15b4-4d23-8da5-1d141f8710ba"/>
							<gml:surfaceMember xlink:href="#poly-e513d8e0-1f64-49d6-aa23-eccb7035c03a"/>
							<gml:surfaceMember xlink:href="#poly-5fe21183-9675-432c-8d89-191597537ffd"/>
							<gml:surfaceMember xlink:href="#poly-bb7f100d-8a12-4fcc-b4c7-4dd972bb7049"/>
							<gml:surfaceMember xlink:href="#poly-6695a851-88f8-4b46-8883-a743b0c7c877"/>
							<gml:surfaceMember xlink:href="#poly-510211fb-2e2b-4a52-a40a-a1f77e63506a"/>
							<gml:surfaceMember xlink:href="#poly-a46f0a45-494a-4d17-a6d1-3c578285b634"/>
							<gml:surfaceMember xlink:href="#poly-6612ff60-398f-45cc-b5fd-3685b4aa9be2"/>
							<gml:surfaceMember xlink:href="#poly-79be70d3-fc58-4016-8d6a-3050d5dd796c"/>
							<gml:surfaceMember xlink:href="#poly-dd98025c-f7b0-45ef-ac74-ae00d001058b"/>
							<gml:surfaceMember xlink:href="#poly-a15a16da-1bce-4999-9b2b-ed6583feb32c"/>
							<gml:surfaceMember xlink:href="#poly-e1d73248-201f-49dc-810b-efdc38b9a4e5"/>
							<gml:surfaceMember xlink:href="#poly-bab5a26c-4b6a-4c8a-ae26-991b34ef79bb"/>
							<gml:surfaceMember xlink:href="#poly-ccc5dee7-8847-40d7-be8a-06dad55ffbea"/>
							<gml:surfaceMember xlink:href="#poly-949b4708-74d8-47b0-b85d-c70de8685887"/>
							<gml:surfaceMember xlink:href="#poly-aa30b27e-d0e3-4322-81dc-2d25ca9c7302"/>
							<gml:surfaceMember xlink:href="#poly-29dc2d69-8f56-4e71-8f80-f031eb996687"/>
							<gml:surfaceMember xlink:href="#poly-06b23ce4-8ddb-442f-b02a-6c2ada516a3b"/>
							<gml:surfaceMember xlink:href="#poly-f81a0337-6353-4ef5-8bd0-392e9a699bf6"/>
							<gml:surfaceMember xlink:href="#poly-72d230ca-0898-4c0a-953d-13412ea2603d"/>
							<gml:surfaceMember xlink:href="#poly-baa66822-92ed-432a-bfb2-20a3b470f522"/>
							<gml:surfaceMember xlink:href="#poly-f9ad22ad-ac52-4e95-8abd-340379c05c96"/>
							<gml:surfaceMember xlink:href="#poly-6c72a418-db5a-48ce-b138-d0e98301a3d2"/>
							<gml:surfaceMember xlink:href="#poly-cd71bea3-55c8-4676-9e27-4587d8ed11f6"/>
							<gml:surfaceMember xlink:href="#poly-f9d03f28-cee1-418d-8a74-4e5758f05774"/>
							<gml:surfaceMember xlink:href="#poly-89454df4-16fc-4951-b32f-953631903e2d"/>
							<gml:surfaceMember xlink:href="#poly-538c255c-b8a7-4348-be05-bc0f9f7374e9"/>
							<gml:surfaceMember xlink:href="#poly-50984a96-87f2-476e-85cd-6775e50186e1"/>
							<gml:surfaceMember xlink:href="#poly-bdabe5f5-c062-494b-b830-48e6517478f7"/>
							<gml:surfaceMember xlink:href="#poly-56d8ba36-c6d4-42cb-886f-c9b9365fc12e"/>
							<gml:surfaceMember xlink:href="#poly-e2d217e3-71bd-4d41-93fc-c162e3d8ee60"/>
							<gml:surfaceMember xlink:href="#poly-8599a4fe-9fde-4187-99fa-10ade7a58c14"/>
							<gml:surfaceMember xlink:href="#poly-7394c9ba-d3d1-41b0-90f7-66334e3ff119"/>
							<gml:surfaceMember xlink:href="#poly-e2a18771-8055-4543-bfbb-c3e61fdf7084"/>
							<gml:surfaceMember xlink:href="#poly-4c8bb515-e4c4-43a4-aa3f-b223a696e48c"/>
							<gml:surfaceMember xlink:href="#poly-dd3d2cf1-3476-4448-b4b6-7bf0bac23160"/>
							<gml:surfaceMember xlink:href="#poly-370438f2-6620-488c-989e-72605a71b565"/>
							<gml:surfaceMember xlink:href="#poly-71d31c65-932f-42ab-8ada-a4bd71b8bbd5"/>
							<gml:surfaceMember xlink:href="#poly-d93e959d-d7d9-4580-af87-0b387871cbb0"/>
							<gml:surfaceMember xlink:href="#poly-b74a1043-66ef-465c-ba37-ec603c1653a8"/>
							<gml:surfaceMember xlink:href="#poly-c47f729b-d4af-4901-ab23-7ae1baf30dc6"/>
							<gml:surfaceMember xlink:href="#poly-719df742-5e02-4ebd-b1cf-e619b4d5fa74"/>
							<gml:surfaceMember xlink:href="#poly-e96df56c-1255-452d-90f7-d227a7ac9619"/>
							<gml:surfaceMember xlink:href="#poly-7fb6bd0e-17de-4d7f-b913-8e16fa3f0c13"/>
							<gml:surfaceMember xlink:href="#poly-998142e9-3c63-4f3b-b882-69ab72716cda"/>
							<gml:surfaceMember xlink:href="#poly-9f4a2c35-0522-472c-a17d-04c7ea9ae09e"/>
							<gml:surfaceMember xlink:href="#poly-5cbf211a-e98e-4f8b-ba4b-35dd17dd447f"/>
							<gml:surfaceMember xlink:href="#poly-d386757e-2ba5-4f51-862f-d3a64e33b0d2"/>
							<gml:surfaceMember xlink:href="#poly-96812c54-f1d3-4b05-b940-793c1f605fae"/>
							<gml:surfaceMember xlink:href="#poly-11e25880-dc92-4ea5-bc30-b935a188fd54"/>
							<gml:surfaceMember xlink:href="#poly-6e8b72ad-c5f6-47fe-b147-bd1c47eaa72c"/>
							<gml:surfaceMember xlink:href="#poly-2cadb5d8-3a90-46f0-803b-4eb037edd318"/>
							<gml:surfaceMember xlink:href="#poly-d44c7c9b-742f-4dff-9cd0-47a2f4ad5f96"/>
							<gml:surfaceMember xlink:href="#poly-0940e8e7-5eb6-4a07-99e8-c11b0885fecc"/>
							<gml:surfaceMember xlink:href="#poly-ee6da736-a22f-45c7-970f-eca000c23f34"/>
							<gml:surfaceMember xlink:href="#poly-194d5cd0-e31a-4a91-8b68-61f30d360370"/>
							<gml:surfaceMember xlink:href="#poly-c605232b-db90-40da-9fa5-abf273743e4e"/>
							<gml:surfaceMember xlink:href="#poly-f9e82d72-989e-4449-b719-d6311190ad05"/>
							<gml:surfaceMember xlink:href="#poly-df7a820b-1871-4bc6-b783-d800b1d001d9"/>
							<gml:surfaceMember xlink:href="#poly-98c5cbe5-fe1c-4345-b462-e1a7e064ffec"/>
							<gml:surfaceMember xlink:href="#poly-c1ff7425-5e56-4bd1-b54f-b882cdb82591"/>
							<gml:surfaceMember xlink:href="#poly-5a83fb32-a9a1-421c-b030-d5957434a99f"/>
							<gml:surfaceMember xlink:href="#poly-dfd72bd9-e526-4aaa-8b4a-5579dc18be1c"/>
							<gml:surfaceMember xlink:href="#poly-8c5ac006-5a61-4175-b237-97623e29c62d"/>
							<gml:surfaceMember xlink:href="#poly-1f664fa9-40fd-421d-9406-de7ac28a3071"/>
							<gml:surfaceMember xlink:href="#poly-65dd1327-f58b-4915-9637-db31e2a39e47"/>
							<gml:surfaceMember xlink:href="#poly-bb86fb54-151d-4275-97cc-6bc0412b0015"/>
							<gml:surfaceMember xlink:href="#poly-76db92a0-5bda-463e-9ee4-27b7dfef779e"/>
							<gml:surfaceMember xlink:href="#poly-2893e43d-57b6-4d71-920c-895ed4f41cfa"/>
							<gml:surfaceMember xlink:href="#poly-7f837516-09be-4dd9-93c6-a4030a2a3cec"/>
							<gml:surfaceMember xlink:href="#poly-bce64ad4-fc3d-45a9-b826-4bb3de59f589"/>
							<gml:surfaceMember xlink:href="#poly-21ee5381-6038-4e42-b3b7-13e2c663e349"/>
							<gml:surfaceMember xlink:href="#poly-9556a54d-37c9-4d80-8e66-30d467e18798"/>
							<gml:surfaceMember xlink:href="#poly-7ba15af7-6eaf-4675-8e93-9e3c55184e49"/>
							<gml:surfaceMember xlink:href="#poly-7d5d1a3d-4c6f-43e7-9086-ce2cc30d2a51"/>
							<gml:surfaceMember xlink:href="#poly-5a67cef0-6547-47c4-91e8-d5313b86f96b"/>
							<gml:surfaceMember xlink:href="#poly-0f47888b-6298-46de-9759-4b4ebe128b40"/>
							<gml:surfaceMember xlink:href="#poly-dcf243c7-c6e6-4a61-9f42-90d3eb0697e3"/>
							<gml:surfaceMember xlink:href="#poly-0a0fb9e2-a94c-4ea0-92c6-c140003c1b9e"/>
							<gml:surfaceMember xlink:href="#poly-93acea27-fc2f-457d-85a5-59759fe47028"/>
							<gml:surfaceMember xlink:href="#poly-eccabd26-bc2a-413d-a885-ef4f78eeca21"/>
							<gml:surfaceMember xlink:href="#poly-019f1b13-e2fe-45eb-b11c-dc008fcfeec4"/>
							<gml:surfaceMember xlink:href="#poly-b146db20-66e8-403e-a788-8ab1537c0e03"/>
							<gml:surfaceMember xlink:href="#poly-fe937141-9a08-471f-9a7d-a51662893124"/>
							<gml:surfaceMember xlink:href="#poly-c2494138-7067-4108-a1a1-68288acc8999"/>
							<gml:surfaceMember xlink:href="#poly-46c209f0-cb53-4591-a4ed-3900e322177b"/>
							<gml:surfaceMember xlink:href="#poly-2a33c658-95a1-4080-984e-102f1e0b46a8"/>
							<gml:surfaceMember xlink:href="#poly-aa833631-c367-47ee-a89b-027a2cee7d26"/>
							<gml:surfaceMember xlink:href="#poly-c48dbb44-f34c-4aa2-ad3a-f5d407abbb64"/>
							<gml:surfaceMember xlink:href="#poly-16052105-1cdb-4889-a7da-a03ceaf88fa9"/>
							<gml:surfaceMember xlink:href="#poly-bc25f380-1ea5-4d5f-a2e6-6be63660ed3b"/>
							<gml:surfaceMember xlink:href="#poly-b2f05dfb-37c0-40b2-bbde-450fc53f8880"/>
							<gml:surfaceMember xlink:href="#poly-0708f072-2704-4240-ac35-f6a596bd8f97"/>
							<gml:surfaceMember xlink:href="#poly-e640fce9-e95e-4574-9de0-cb0f48d8214b"/>
							<gml:surfaceMember xlink:href="#poly-95ae98bf-1017-42a5-a37d-a3e0e743f67c"/>
							<gml:surfaceMember xlink:href="#poly-6696f61e-893d-466d-aad7-4bc19d24a7ca"/>
							<gml:surfaceMember xlink:href="#poly-bced5dba-667f-4563-a979-37baad0c9e32"/>
							<gml:surfaceMember xlink:href="#poly-08505dd0-1f4f-4f0c-bcb7-03c2beb3ea3a"/>
							<gml:surfaceMember xlink:href="#poly-1402d06c-80a7-4cf0-8847-36ea47279ba8"/>
							<gml:surfaceMember xlink:href="#poly-a1d81554-d361-4db9-924b-bcc8f5e62c64"/>
							<gml:surfaceMember xlink:href="#poly-1f209671-44b1-449b-bb18-791509e507bd"/>
							<gml:surfaceMember xlink:href="#poly-ce5aa022-f5c0-46f7-98ed-d00d0303f78c"/>
							<gml:surfaceMember xlink:href="#poly-c4a1baee-53e3-4994-8172-01b82e254ec4"/>
							<gml:surfaceMember xlink:href="#poly-dd0c0156-8d7c-4ee9-a541-c1e0f2e1794f"/>
							<gml:surfaceMember xlink:href="#poly-66b748d5-8589-4ce7-9cb2-3842fd76c867"/>
							<gml:surfaceMember xlink:href="#poly-f5c120f3-803b-404e-953f-b59981152750"/>
							<gml:surfaceMember xlink:href="#poly-8cb5160b-e15f-46f1-9f36-753592729ed3"/>
							<gml:surfaceMember xlink:href="#poly-3695b1bc-e88c-42c6-951b-855ff3589fdb"/>
							<gml:surfaceMember xlink:href="#poly-112334ec-d4c8-449a-a54e-6a0c7b4f2ef9"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_050284a6-7128-4d9d-95b8-4fa44a83f81e_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-985ce519-35ae-44ab-9145-928bdab16f7f">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669237149175416 139.74530555087046 29.017 35.66924879600443 139.7453193678061 29.017 35.66920561510274 139.74537403816055 29.017 35.66919201962849 139.7453579147283 29.017 35.669237149175416 139.74530555087046 29.017</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b7ddb847-ef81-4a25-a3b2-d9b71511d5cb">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66917239314622 139.74553825269354 30.917 35.66916157807422 139.74555254713263 30.897 35.66914424833979 139.7455328598809 31.93 35.66915506340949 139.74551856544227 31.95 35.66917239314622 139.74553825269354 30.917</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-84a3a599-08b4-4fe8-bb8f-7d4571a98084">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669047123159984 139.74555456131438 29.017 35.66905533275228 139.74556429496718 29.017 35.669027956253224 139.74559894332916 29.017 35.669019755677425 139.7455892096662 29.017 35.669047123159984 139.74555456131438 29.017</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1ab8ee60-0685-4dbb-920f-0b0de8fbc135">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669019755677425 139.7455892096662 29.739 35.669027956253224 139.74559894332916 29.739 35.66902619119669 139.74560118761335 29.739 35.669017936570896 139.74559149819385 29.739 35.669019755677425 139.7455892096662 29.739</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0bc8d9f6-e606-4190-a089-2e7bad6b0924">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66966105838194 139.74612641171714 19.326 35.66963305073125 139.7461610166511 19.326 35.66956022784672 139.74607260514094 19.326 35.66949704905418 139.7459958811454 19.326 35.66952449827996 139.74596192854352 19.326 35.66957589477349 139.74602432746465 19.326 35.66956418742185 139.74603881066625 19.326 35.66962427166235 139.7461116498791 19.326 35.66963651936599 139.7460965033199 19.326 35.66966105838194 139.74612641171714 19.326</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c24b8fb5-4c2e-4dfc-a32e-b247f7199c3e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c24b8fb5-4c2e-4dfc-a32e-b247f7199c3e_0">
											<gml:posList>35.66920561510274 139.74537403816055 33.809 35.66919201962849 139.7453579147283 33.809 35.66919201962849 139.7453579147283 29.017 35.66920561510274 139.74537403816055 29.017 35.66920561510274 139.74537403816055 33.809</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-78cf765a-b38b-4047-8465-2574caf253dd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-78cf765a-b38b-4047-8465-2574caf253dd_0">
											<gml:posList>35.66919201962849 139.7453579147283 29.017 35.66919201962849 139.7453579147283 33.809 35.669237149175416 139.74530555087046 33.809 35.669237149175416 139.74530555087046 29.017 35.66919201962849 139.7453579147283 29.017</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2fb3d86d-81e9-4aad-afb6-ad566436a740">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2fb3d86d-81e9-4aad-afb6-ad566436a740_0">
											<gml:posList>35.669237149175416 139.74530555087046 33.809 35.66919201962849 139.7453579147283 33.809 35.66920561510274 139.74537403816055 33.809 35.66924879600443 139.7453193678061 33.809 35.669237149175416 139.74530555087046 33.809</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-61516cd7-8ce0-407f-91ce-de96b7f96966">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-61516cd7-8ce0-407f-91ce-de96b7f96966_0">
											<gml:posList>35.66924879600443 139.7453193678061 33.809 35.66920561510274 139.74537403816055 33.809 35.66920561510274 139.74537403816055 29.017 35.66924879600443 139.7453193678061 29.017 35.66924879600443 139.7453193678061 33.809</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-23114ece-cd8f-42cf-99d6-099199073c31">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-23114ece-cd8f-42cf-99d6-099199073c31_0">
											<gml:posList>35.66924879600443 139.7453193678061 29.017 35.669237149175416 139.74530555087046 29.017 35.669237149175416 139.74530555087046 33.809 35.66924879600443 139.7453193678061 33.809 35.66924879600443 139.7453193678061 29.017</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-dcb7cca0-2a6c-46f4-88c2-bb45433d3be3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-dcb7cca0-2a6c-46f4-88c2-bb45433d3be3_0">
											<gml:posList>35.669017936570896 139.74559149819385 29.739 35.66902619119669 139.74560118761335 29.739 35.66902619119669 139.74560118761335 30.008 35.669017936570896 139.74559149819385 30.008 35.669017936570896 139.74559149819385 29.739</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a8e9cd14-6c73-48a1-83fe-3bf30e08d337">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a8e9cd14-6c73-48a1-83fe-3bf30e08d337_0">
											<gml:posList>35.669019755677425 139.7455892096662 29.739 35.669019755677425 139.7455892096662 29.017 35.669027956253224 139.74559894332916 29.017 35.669027956253224 139.74559894332916 29.739 35.669019755677425 139.7455892096662 29.739</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-80753567-8f1d-42e2-8112-cb17ad4944f6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-80753567-8f1d-42e2-8112-cb17ad4944f6_0">
											<gml:posList>35.669019755677425 139.7455892096662 29.739 35.669017936570896 139.74559149819385 29.739 35.669017936570896 139.74559149819385 30.008 35.669047123159984 139.74555456131438 30.008 35.669047123159984 139.74555456131438 29.017 35.669019755677425 139.7455892096662 29.017 35.669019755677425 139.7455892096662 29.739</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6e80d9f1-e8d8-4d50-9bdf-e41828d03006">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6e80d9f1-e8d8-4d50-9bdf-e41828d03006_0">
											<gml:posList>35.669047123159984 139.74555456131438 30.008 35.669017936570896 139.74559149819385 30.008 35.66902619119669 139.74560118761335 30.008 35.66905533275228 139.74556429496718 30.008 35.669047123159984 139.74555456131438 30.008</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fb5762a5-d6ce-44f3-b02e-8c3a43d502a7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fb5762a5-d6ce-44f3-b02e-8c3a43d502a7_0">
											<gml:posList>35.669027956253224 139.74559894332916 29.739 35.669027956253224 139.74559894332916 29.017 35.66905533275228 139.74556429496718 29.017 35.66905533275228 139.74556429496718 30.008 35.66902619119669 139.74560118761335 30.008 35.66902619119669 139.74560118761335 29.739 35.669027956253224 139.74559894332916 29.739</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d7821ee3-52c3-40f0-a0e1-603dd47bc027">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d7821ee3-52c3-40f0-a0e1-603dd47bc027_0">
											<gml:posList>35.66905533275228 139.74556429496718 29.017 35.669047123159984 139.74555456131438 29.017 35.669047123159984 139.74555456131438 30.008 35.66905533275228 139.74556429496718 30.008 35.66905533275228 139.74556429496718 29.017</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-936c1835-46d0-493e-878a-227aa685a986">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-936c1835-46d0-493e-878a-227aa685a986_0">
											<gml:posList>35.66914424833979 139.7455328598809 33.696 35.66915506340949 139.74551856544227 33.696 35.66915506340949 139.74551856544227 31.95 35.66914424833979 139.7455328598809 31.93 35.66914424833979 139.7455328598809 33.696</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bfe3d150-ae7c-462b-987c-4a26622fcd5c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bfe3d150-ae7c-462b-987c-4a26622fcd5c_0">
											<gml:posList>35.66916157807422 139.74555254713263 33.696 35.66914424833979 139.7455328598809 33.696 35.66914424833979 139.7455328598809 31.93 35.66916157807422 139.74555254713263 30.897 35.66916157807422 139.74555254713263 33.696</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-dea67817-6f18-4aba-885c-f0a9af81619a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-dea67817-6f18-4aba-885c-f0a9af81619a_0">
											<gml:posList>35.66916157807422 139.74555254713263 33.696 35.66917239314622 139.74553825269354 33.696 35.66915506340949 139.74551856544227 33.696 35.66914424833979 139.7455328598809 33.696 35.66916157807422 139.74555254713263 33.696</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c4c1a249-0451-4437-a124-6f57953c6053">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c4c1a249-0451-4437-a124-6f57953c6053_0">
											<gml:posList>35.66915506340949 139.74551856544227 31.95 35.66915506340949 139.74551856544227 33.696 35.66917239314622 139.74553825269354 33.696 35.66917239314622 139.74553825269354 30.917 35.66915506340949 139.74551856544227 31.95</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-034705c2-95a1-434b-a897-2d38b75f3477">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-034705c2-95a1-434b-a897-2d38b75f3477_0">
											<gml:posList>35.66917239314622 139.74553825269354 30.917 35.66917239314622 139.74553825269354 33.696 35.66916157807422 139.74555254713263 33.696 35.66916157807422 139.74555254713263 30.897 35.66917239314622 139.74553825269354 30.917</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-992e0756-b7c3-4267-bcb0-980620b0124c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-992e0756-b7c3-4267-bcb0-980620b0124c_0">
											<gml:posList>35.66949704905418 139.7459958811454 19.326 35.66949704905418 139.7459958811454 21.736 35.66952449827996 139.74596192854352 21.736 35.66952449827996 139.74596192854352 19.326 35.66949704905418 139.7459958811454 19.326</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-37f9d50b-3111-4024-b2b6-f666cd821e33">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-37f9d50b-3111-4024-b2b6-f666cd821e33_0">
											<gml:posList>35.669527118306505 139.74603240007738 21.736 35.66949704905418 139.7459958811454 21.736 35.66949704905418 139.7459958811454 19.326 35.66956022784672 139.74607260514094 19.326 35.669527118306505 139.74603240007738 21.736</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b6bd8538-f60a-486e-b155-529b66f24d86">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b6bd8538-f60a-486e-b155-529b66f24d86_0">
											<gml:posList>35.66952449827996 139.74596192854352 19.326 35.66952449827996 139.74596192854352 21.736 35.66957589477349 139.74602432746465 21.736 35.66957589477349 139.74602432746465 19.326 35.66952449827996 139.74596192854352 19.326</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8114c15f-7882-4246-8d5f-6aa558bfd676">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8114c15f-7882-4246-8d5f-6aa558bfd676_0">
											<gml:posList>35.66956418742185 139.74603881066625 19.326 35.66957589477349 139.74602432746465 19.326 35.66957589477349 139.74602432746465 21.736 35.66956418742185 139.74603881066625 21.736 35.66956418742185 139.74603881066625 19.326</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0559f74f-b903-4a05-976b-8e1014eef47a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0559f74f-b903-4a05-976b-8e1014eef47a_0">
											<gml:posList>35.66962427166235 139.7461116498791 21.736 35.66956418742185 139.74603881066625 21.736 35.66957589477349 139.74602432746465 21.736 35.66952449827996 139.74596192854352 21.736 35.66949704905418 139.7459958811454 21.736 35.669527118306505 139.74603240007738 21.736 35.66963305073125 139.7461610166511 21.736 35.66966105838194 139.74612641171714 21.736 35.66963651936599 139.7460965033199 21.736 35.66962427166235 139.7461116498791 21.736</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5af2d0bd-16f2-40ac-b1f7-405b6b432e20">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5af2d0bd-16f2-40ac-b1f7-405b6b432e20_0">
											<gml:posList>35.669527118306505 139.74603240007738 21.736 35.66956022784672 139.74607260514094 19.326 35.66963305073125 139.7461610166511 19.326 35.66963305073125 139.7461610166511 21.736 35.669527118306505 139.74603240007738 21.736</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-41f84237-d2a6-4920-bf33-c0486368af62">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-41f84237-d2a6-4920-bf33-c0486368af62_0">
											<gml:posList>35.66962427166235 139.7461116498791 19.326 35.66956418742185 139.74603881066625 19.326 35.66956418742185 139.74603881066625 21.736 35.66962427166235 139.7461116498791 21.736 35.66962427166235 139.7461116498791 19.326</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9fe3819e-caab-42ad-9525-53d7e1e60930">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9fe3819e-caab-42ad-9525-53d7e1e60930_0">
											<gml:posList>35.66963651936599 139.7460965033199 19.326 35.66962427166235 139.7461116498791 19.326 35.66962427166235 139.7461116498791 21.736 35.66963651936599 139.7460965033199 21.736 35.66963651936599 139.7460965033199 19.326</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-dd9b889a-13f4-4e2e-8f3c-122145a726d3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-dd9b889a-13f4-4e2e-8f3c-122145a726d3_0">
											<gml:posList>35.66963305073125 139.7461610166511 19.326 35.66966105838194 139.74612641171714 19.326 35.66966105838194 139.74612641171714 21.736 35.66963305073125 139.7461610166511 21.736 35.66963305073125 139.7461610166511 19.326</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b80375d0-3e1f-44b6-8c2f-86b3a7177772">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b80375d0-3e1f-44b6-8c2f-86b3a7177772_0">
											<gml:posList>35.66966105838194 139.74612641171714 19.326 35.66963651936599 139.7460965033199 19.326 35.66963651936599 139.7460965033199 21.736 35.66966105838194 139.74612641171714 21.736 35.66966105838194 139.74612641171714 19.326</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_050284a6-7128-4d9d-95b8-4fa44a83f81e_BuildingInstallation_1030">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d1dfa15e-469a-40fc-b2a1-042cf68e6510">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669202258833494 139.74535737328105 33.809 35.669202185456626 139.74535563912423 33.809 35.66920224813305 139.74535506465838 33.809 35.66920266155383 139.7453534072901 33.809 35.66920312953312 139.7453524015817 33.809 35.669203408619644 139.74535193733936 33.809 35.669204075038095 139.74535111919687 33.809 35.66920444433452 139.7453507542704 33.809 35.66920525514206 139.74535016793752 33.809 35.66920613819662 139.745349769309 33.809 35.669206606813496 139.7453496362416 33.809 35.66920801289014 139.7453495463299 33.809 35.66920848166037 139.7453496231382 33.809 35.66920940127024 139.74534990932767 33.809 35.66920983409049 139.74535012977472 33.809 35.669211033585896 139.74535104528468 33.809 35.669211710212565 139.74535186195354 33.809 35.669211998982696 139.74535231452677 33.809 35.669212667112156 139.7453538381553 33.809 35.66921292031967 139.74535496457958 33.809 35.66921299368848 139.74535668769053 33.809 35.669212931012055 139.74535726215646 33.809 35.66921251759122 139.74535891952493 33.809 35.66921204961187 139.7453599252334 33.809 35.66921177052532 139.74536038947576 33.809 35.66921110411488 139.74536121866433 33.809 35.66921073481036 139.7453615725447 33.809 35.66920992400275 139.74536215887753 33.809 35.66920948249967 139.74536239133 33.809 35.66920857233933 139.74536270161934 33.809 35.669207634984495 139.74536280206266 33.809 35.669207166254616 139.74536278048473 33.809 35.669206697492456 139.74536271472243 33.809 35.669205777882624 139.74536242853281 33.809 35.66920492122361 139.7453619434444 33.809 35.669204515379995 139.74536163459894 33.809 35.66920346894047 139.74536047590678 33.809 35.66920318017037 139.7453600233336 33.809 35.66920270170852 139.74535901866366 33.809 35.669202258833494 139.74535737328105 33.809</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b708e09b-a6dd-4eec-be1d-8f972940b267">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66923868668953 139.74532496823096 33.809 35.669238813495255 139.74532580759558 33.809 35.66923888684026 139.74532749756878 33.809 35.66923883337953 139.74532834817737 33.809 35.66923855516498 139.74533000539813 33.809 35.66923803351523 139.74533157451722 33.809 35.669237304452906 139.74533301131075 33.809 35.66923637695943 139.74533427158434 33.809 35.669235287065504 139.74533532216023 33.809 35.66923469247444 139.74533575361076 33.809 35.66923275516922 139.74533663942506 33.809 35.66923207925281 139.74533679481232 33.809 35.66923069120363 139.74533688470444 33.809 35.669228653794896 139.74533646718862 33.809 35.66922799559111 139.74533619175847 33.809 35.66922676915936 139.74533541987736 33.809 35.66922565972845 139.74533440485368 33.809 35.669224712383134 139.7453331687301 33.809 35.66922396320254 139.74533174460538 33.809 35.66922366519257 139.7453309827515 33.809 35.669223231355105 139.745329370497 33.809 35.669223104557474 139.7453285421786 33.809 35.66922303120441 139.74532684115965 33.809 35.669223084673206 139.74532600159733 33.809 35.669223371901424 139.74532434436696 33.809 35.66922388452928 139.74532276421192 33.809 35.66922462260521 139.74532132740867 33.809 35.66922506380142 139.74532067520443 33.809 35.66922607249902 139.74531952530273 33.809 35.6692272255777 139.7453185961645 33.809 35.669228505042305 139.74531793199395 33.809 35.669229847804836 139.74531754390645 33.809 35.66923192094558 139.74531751953853 33.809 35.66923259707997 139.74531766239565 33.809 35.6692332732628 139.74531787152932 33.809 35.66923392246097 139.74531815801535 33.809 35.66923515789847 139.74531891884027 33.809 35.66923625831579 139.74531993387376 33.809 35.66923720566931 139.7453211810434 33.809 35.669237963855686 139.7453225941123 33.809 35.66923826187379 139.74532336701236 33.809 35.66923868668953 139.74532496823096 33.809</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-06fe2333-bcba-4f13-82a3-46051a36f778">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-06fe2333-bcba-4f13-82a3-46051a36f778_0">
											<gml:posList>35.669205777882624 139.74536242853281 33.809 35.669205777882624 139.74536242853281 40.524 35.66920492122361 139.7453619434444 40.524 35.66920492122361 139.7453619434444 33.809 35.669205777882624 139.74536242853281 33.809</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0fedab34-84b5-4642-b206-7fca914fab8d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0fedab34-84b5-4642-b206-7fca914fab8d_0">
											<gml:posList>35.669206697492456 139.74536271472243 33.809 35.669206697492456 139.74536271472243 40.524 35.669205777882624 139.74536242853281 40.524 35.669205777882624 139.74536242853281 33.809 35.669206697492456 139.74536271472243 33.809</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-787eba96-0804-4298-8e25-48542b34ab7d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-787eba96-0804-4298-8e25-48542b34ab7d_0">
											<gml:posList>35.669206697492456 139.74536271472243 33.809 35.669207166254616 139.74536278048473 33.809 35.669207166254616 139.74536278048473 40.524 35.669206697492456 139.74536271472243 40.524 35.669206697492456 139.74536271472243 33.809</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-33a13c03-1015-406e-a3e6-8d6b1abe5d7d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-33a13c03-1015-406e-a3e6-8d6b1abe5d7d_0">
											<gml:posList>35.669207166254616 139.74536278048473 33.809 35.669207634984495 139.74536280206266 33.809 35.669207634984495 139.74536280206266 40.524 35.669207166254616 139.74536278048473 40.524 35.669207166254616 139.74536278048473 33.809</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3e110eb4-862e-4ade-8395-72745d6089a9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3e110eb4-862e-4ade-8395-72745d6089a9_0">
											<gml:posList>35.66920857233933 139.74536270161934 33.809 35.66920857233933 139.74536270161934 40.524 35.669207634984495 139.74536280206266 40.524 35.669207634984495 139.74536280206266 33.809 35.66920857233933 139.74536270161934 33.809</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4dc1852c-24cc-4f22-af56-8ffa9d826c9d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4dc1852c-24cc-4f22-af56-8ffa9d826c9d_0">
											<gml:posList>35.66920948249967 139.74536239133 33.809 35.66920948249967 139.74536239133 40.524 35.66920857233933 139.74536270161934 40.524 35.66920857233933 139.74536270161934 33.809 35.66920948249967 139.74536239133 33.809</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1d77a4c2-4f9e-4b86-ac1a-a42e77a4b282">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1d77a4c2-4f9e-4b86-ac1a-a42e77a4b282_0">
											<gml:posList>35.669204515379995 139.74536163459894 33.809 35.66920492122361 139.7453619434444 33.809 35.66920492122361 139.7453619434444 40.524 35.669204515379995 139.74536163459894 40.524 35.669204515379995 139.74536163459894 33.809</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1cbaf912-9a84-48bd-9717-adde5f56cbe4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1cbaf912-9a84-48bd-9717-adde5f56cbe4_0">
											<gml:posList>35.669204515379995 139.74536163459894 33.809 35.669204515379995 139.74536163459894 40.524 35.66920346894047 139.74536047590678 40.524 35.66920346894047 139.74536047590678 33.809 35.669204515379995 139.74536163459894 33.809</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a6fa6205-987e-4e75-ba23-bea2efb87ac2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a6fa6205-987e-4e75-ba23-bea2efb87ac2_0">
											<gml:posList>35.66920318017037 139.7453600233336 33.809 35.66920346894047 139.74536047590678 33.809 35.66920346894047 139.74536047590678 40.524 35.66920318017037 139.7453600233336 40.524 35.66920318017037 139.7453600233336 33.809</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f7c8ab36-22fe-4dfa-9113-cff802985ad0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f7c8ab36-22fe-4dfa-9113-cff802985ad0_0">
											<gml:posList>35.66920318017037 139.7453600233336 33.809 35.66920318017037 139.7453600233336 40.524 35.66920270170852 139.74535901866366 40.524 35.66920270170852 139.74535901866366 33.809 35.66920318017037 139.7453600233336 33.809</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c15168fe-7b1d-4f98-9e0f-2f8e2f97a484">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c15168fe-7b1d-4f98-9e0f-2f8e2f97a484_0">
											<gml:posList>35.66920270170852 139.74535901866366 33.809 35.66920270170852 139.74535901866366 40.524 35.669202258833494 139.74535737328105 40.524 35.669202258833494 139.74535737328105 33.809 35.66920270170852 139.74535901866366 33.809</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6e0b3e7f-f316-4ba3-bec9-8872f8ab2724">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6e0b3e7f-f316-4ba3-bec9-8872f8ab2724_0">
											<gml:posList>35.669202258833494 139.74535737328105 33.809 35.669202258833494 139.74535737328105 40.524 35.669202185456626 139.74535563912423 40.524 35.669202185456626 139.74535563912423 33.809 35.669202258833494 139.74535737328105 33.809</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bdbed47b-36f1-48ef-8e0a-0f9f93653b22">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bdbed47b-36f1-48ef-8e0a-0f9f93653b22_0">
											<gml:posList>35.66920224813305 139.74535506465838 33.809 35.669202185456626 139.74535563912423 33.809 35.669202185456626 139.74535563912423 40.524 35.66920224813305 139.74535506465838 40.524 35.66920224813305 139.74535506465838 33.809</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4eeef348-b205-4159-b4ef-6c3fb4ccfb5e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4eeef348-b205-4159-b4ef-6c3fb4ccfb5e_0">
											<gml:posList>35.66920224813305 139.74535506465838 33.809 35.66920224813305 139.74535506465838 40.524 35.66920266155383 139.7453534072901 40.524 35.66920266155383 139.7453534072901 33.809 35.66920224813305 139.74535506465838 33.809</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ef871860-fa8b-44a0-99d6-30f837ffb2ed">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ef871860-fa8b-44a0-99d6-30f837ffb2ed_0">
											<gml:posList>35.66920266155383 139.7453534072901 33.809 35.66920266155383 139.7453534072901 40.524 35.66920312953312 139.7453524015817 40.524 35.66920312953312 139.7453524015817 33.809 35.66920266155383 139.7453534072901 33.809</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-835f65f7-2802-4d83-84ca-7be85155963e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-835f65f7-2802-4d83-84ca-7be85155963e_0">
											<gml:posList>35.669203408619644 139.74535193733936 33.809 35.66920312953312 139.7453524015817 33.809 35.66920312953312 139.7453524015817 40.524 35.669203408619644 139.74535193733936 40.524 35.669203408619644 139.74535193733936 33.809</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-79aa95bc-3129-4dbd-b369-f79880e2dc1c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-79aa95bc-3129-4dbd-b369-f79880e2dc1c_0">
											<gml:posList>35.669203408619644 139.74535193733936 33.809 35.669203408619644 139.74535193733936 40.524 35.669204075038095 139.74535111919687 40.524 35.669204075038095 139.74535111919687 33.809 35.669203408619644 139.74535193733936 33.809</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9ee0bee2-7aae-4dcc-8057-696d53685418">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9ee0bee2-7aae-4dcc-8057-696d53685418_0">
											<gml:posList>35.66920444433452 139.7453507542704 33.809 35.669204075038095 139.74535111919687 33.809 35.669204075038095 139.74535111919687 40.524 35.66920444433452 139.7453507542704 40.524 35.66920444433452 139.7453507542704 33.809</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-223f81bf-8814-4a8a-a68a-fe2a7ff99293">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-223f81bf-8814-4a8a-a68a-fe2a7ff99293_0">
											<gml:posList>35.66920444433452 139.7453507542704 33.809 35.66920444433452 139.7453507542704 40.524 35.66920525514206 139.74535016793752 40.524 35.66920525514206 139.74535016793752 33.809 35.66920444433452 139.7453507542704 33.809</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-572da4c4-6ba8-4661-8bfa-27f9c25b446f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-572da4c4-6ba8-4661-8bfa-27f9c25b446f_0">
											<gml:posList>35.66920525514206 139.74535016793752 33.809 35.66920525514206 139.74535016793752 40.524 35.66920613819662 139.745349769309 40.524 35.66920613819662 139.745349769309 33.809 35.66920525514206 139.74535016793752 33.809</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-405408d9-efaa-4815-82b6-709510d1b18c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-405408d9-efaa-4815-82b6-709510d1b18c_0">
											<gml:posList>35.669206606813496 139.7453496362416 33.809 35.66920613819662 139.745349769309 33.809 35.66920613819662 139.745349769309 40.524 35.669206606813496 139.7453496362416 40.524 35.669206606813496 139.7453496362416 33.809</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-811b3717-5aed-47c0-b34f-65abb3e72194">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-811b3717-5aed-47c0-b34f-65abb3e72194_0">
											<gml:posList>35.669206606813496 139.7453496362416 33.809 35.669206606813496 139.7453496362416 40.524 35.66920801289014 139.7453495463299 40.524 35.66920801289014 139.7453495463299 33.809 35.669206606813496 139.7453496362416 33.809</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8f149d73-52b9-42c1-a466-eeddf970327b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8f149d73-52b9-42c1-a466-eeddf970327b_0">
											<gml:posList>35.66920848166037 139.7453496231382 33.809 35.66920801289014 139.7453495463299 33.809 35.66920801289014 139.7453495463299 40.524 35.66920848166037 139.7453496231382 40.524 35.66920848166037 139.7453496231382 33.809</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c17a9c5e-e773-4e3e-9fdd-a873c99226c3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c17a9c5e-e773-4e3e-9fdd-a873c99226c3_0">
											<gml:posList>35.66920940127024 139.74534990932767 33.809 35.66920848166037 139.7453496231382 33.809 35.66920848166037 139.7453496231382 40.524 35.66920940127024 139.74534990932767 40.524 35.66920940127024 139.74534990932767 33.809</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5df994f3-9726-464c-af94-22cd3d16c50c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5df994f3-9726-464c-af94-22cd3d16c50c_0">
											<gml:posList>35.66920983409049 139.74535012977472 33.809 35.66920940127024 139.74534990932767 33.809 35.66920940127024 139.74534990932767 40.524 35.66920983409049 139.74535012977472 40.524 35.66920983409049 139.74535012977472 33.809</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-820b5960-441a-4250-8e34-565f38c66c47">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-820b5960-441a-4250-8e34-565f38c66c47_0">
											<gml:posList>35.66920983409049 139.74535012977472 33.809 35.66920983409049 139.74535012977472 40.524 35.669211033585896 139.74535104528468 40.524 35.669211033585896 139.74535104528468 33.809 35.66920983409049 139.74535012977472 33.809</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-da89faf3-f991-4a46-a999-1ff705473513">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-da89faf3-f991-4a46-a999-1ff705473513_0">
											<gml:posList>35.669211033585896 139.74535104528468 33.809 35.669211033585896 139.74535104528468 40.524 35.669211710212565 139.74535186195354 40.524 35.669211710212565 139.74535186195354 33.809 35.669211033585896 139.74535104528468 33.809</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8bfb701a-ee01-48ee-ae01-dc0b90ae82ea">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8bfb701a-ee01-48ee-ae01-dc0b90ae82ea_0">
											<gml:posList>35.669211998982696 139.74535231452677 33.809 35.669211710212565 139.74535186195354 33.809 35.669211710212565 139.74535186195354 40.524 35.669211998982696 139.74535231452677 40.524 35.669211998982696 139.74535231452677 33.809</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c697a1ee-51e4-480f-bebf-ddca24bb6b7b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c697a1ee-51e4-480f-bebf-ddca24bb6b7b_0">
											<gml:posList>35.669211998982696 139.74535231452677 33.809 35.669211998982696 139.74535231452677 40.524 35.669212667112156 139.7453538381553 40.524 35.669212667112156 139.7453538381553 33.809 35.669211998982696 139.74535231452677 33.809</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b3a81b79-833a-4bd9-96a0-d6d247891af4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b3a81b79-833a-4bd9-96a0-d6d247891af4_0">
											<gml:posList>35.669212667112156 139.7453538381553 33.809 35.669212667112156 139.7453538381553 40.524 35.66921292031967 139.74535496457958 40.524 35.66921292031967 139.74535496457958 33.809 35.669212667112156 139.7453538381553 33.809</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f48dfd29-3e18-4c00-bbc8-439957537d94">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f48dfd29-3e18-4c00-bbc8-439957537d94_0">
											<gml:posList>35.66921292031967 139.74535496457958 33.809 35.66921292031967 139.74535496457958 40.524 35.66921299368848 139.74535668769053 40.524 35.66921299368848 139.74535668769053 33.809 35.66921292031967 139.74535496457958 33.809</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-74b633de-60f1-449e-8002-675efed33526">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-74b633de-60f1-449e-8002-675efed33526_0">
											<gml:posList>35.669212931012055 139.74535726215646 33.809 35.66921299368848 139.74535668769053 33.809 35.66921299368848 139.74535668769053 40.524 35.669212931012055 139.74535726215646 40.524 35.669212931012055 139.74535726215646 33.809</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5280ae9b-64bd-4530-8a75-b67628ff7ade">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5280ae9b-64bd-4530-8a75-b67628ff7ade_0">
											<gml:posList>35.66920948249967 139.74536239133 33.809 35.66920992400275 139.74536215887753 33.809 35.66920992400275 139.74536215887753 40.524 35.66920948249967 139.74536239133 40.524 35.66920948249967 139.74536239133 33.809</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2a3613ca-5d54-485e-8104-4a30072d30ae">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2a3613ca-5d54-485e-8104-4a30072d30ae_0">
											<gml:posList>35.66920992400275 139.74536215887753 33.809 35.66921073481036 139.7453615725447 33.809 35.66921073481036 139.7453615725447 40.524 35.66920992400275 139.74536215887753 40.524 35.66920992400275 139.74536215887753 33.809</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4b475fd2-83fa-4f40-9c74-c3e8be34dc8e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4b475fd2-83fa-4f40-9c74-c3e8be34dc8e_0">
											<gml:posList>35.66921073481036 139.7453615725447 33.809 35.66921110411488 139.74536121866433 33.809 35.66921110411488 139.74536121866433 40.524 35.66921073481036 139.7453615725447 40.524 35.66921073481036 139.7453615725447 33.809</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f8c4f5ad-9555-4d8a-964a-57b933db19e4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f8c4f5ad-9555-4d8a-964a-57b933db19e4_0">
											<gml:posList>35.66921110411488 139.74536121866433 33.809 35.66921177052532 139.74536038947576 33.809 35.66921177052532 139.74536038947576 40.524 35.66921110411488 139.74536121866433 40.524 35.66921110411488 139.74536121866433 33.809</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d5e4f649-2cde-4e08-81a6-a4c5b22ac36f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d5e4f649-2cde-4e08-81a6-a4c5b22ac36f_0">
											<gml:posList>35.66921177052532 139.74536038947576 33.809 35.66921204961187 139.7453599252334 33.809 35.66921204961187 139.7453599252334 40.524 35.66921177052532 139.74536038947576 40.524 35.66921177052532 139.74536038947576 33.809</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e48bd3fb-da45-4a9f-989e-b57b438db1fa">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e48bd3fb-da45-4a9f-989e-b57b438db1fa_0">
											<gml:posList>35.66921204961187 139.7453599252334 33.809 35.66921251759122 139.74535891952493 33.809 35.66921251759122 139.74535891952493 40.524 35.66921204961187 139.7453599252334 40.524 35.66921204961187 139.7453599252334 33.809</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e8911a68-7cfd-4eaa-ac79-4e67a6d54c7b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e8911a68-7cfd-4eaa-ac79-4e67a6d54c7b_0">
											<gml:posList>35.669212931012055 139.74535726215646 33.809 35.669212931012055 139.74535726215646 40.524 35.66921251759122 139.74535891952493 40.524 35.66921251759122 139.74535891952493 33.809 35.669212931012055 139.74535726215646 33.809</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-472055c1-bd83-4e4b-84e0-9f7ca31c94f1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-472055c1-bd83-4e4b-84e0-9f7ca31c94f1_0">
											<gml:posList>35.66920318017037 139.7453600233336 40.524 35.66920346894047 139.74536047590678 40.524 35.669204515379995 139.74536163459894 40.524 35.66920492122361 139.7453619434444 40.524 35.669205777882624 139.74536242853281 40.524 35.669206697492456 139.74536271472243 40.524 35.669207166254616 139.74536278048473 40.524 35.669207634984495 139.74536280206266 40.524 35.66920857233933 139.74536270161934 40.524 35.66920948249967 139.74536239133 40.524 35.66920992400275 139.74536215887753 40.524 35.66921073481036 139.7453615725447 40.524 35.66921110411488 139.74536121866433 40.524 35.66921177052532 139.74536038947576 40.524 35.66921204961187 139.7453599252334 40.524 35.66921251759122 139.74535891952493 40.524 35.669212931012055 139.74535726215646 40.524 35.66921299368848 139.74535668769053 40.524 35.66921292031967 139.74535496457958 40.524 35.669212667112156 139.7453538381553 40.524 35.669211998982696 139.74535231452677 40.524 35.669211710212565 139.74535186195354 40.524 35.669211033585896 139.74535104528468 40.524 35.66920983409049 139.74535012977472 40.524 35.66920940127024 139.74534990932767 40.524 35.66920848166037 139.7453496231382 40.524 35.66920801289014 139.7453495463299 40.524 35.669206606813496 139.7453496362416 40.524 35.66920613819662 139.745349769309 40.524 35.66920525514206 139.74535016793752 40.524 35.66920444433452 139.7453507542704 40.524 35.669204075038095 139.74535111919687 40.524 35.669203408619644 139.74535193733936 40.524 35.66920312953312 139.7453524015817 40.524 35.66920266155383 139.7453534072901 40.524 35.66920224813305 139.74535506465838 40.524 35.669202185456626 139.74535563912423 40.524 35.669202258833494 139.74535737328105 40.524 35.66920270170852 139.74535901866366 40.524 35.66920318017037 139.7453600233336 40.524</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c32e8c70-b696-44ed-937f-380f886139e6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c32e8c70-b696-44ed-937f-380f886139e6_0">
											<gml:posList>35.66922366519257 139.7453309827515 33.809 35.66922396320254 139.74533174460538 33.809 35.66922396320254 139.74533174460538 40.524 35.66922366519257 139.7453309827515 40.524 35.66922366519257 139.7453309827515 33.809</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-82cdacd1-1be2-4c27-9d5a-ab881303007d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-82cdacd1-1be2-4c27-9d5a-ab881303007d_0">
											<gml:posList>35.669223231355105 139.745329370497 33.809 35.66922366519257 139.7453309827515 33.809 35.66922366519257 139.7453309827515 40.524 35.669223231355105 139.745329370497 40.524 35.669223231355105 139.745329370497 33.809</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fef82ad2-b5bc-410a-bf5d-52715e6d06fd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fef82ad2-b5bc-410a-bf5d-52715e6d06fd_0">
											<gml:posList>35.669223231355105 139.745329370497 33.809 35.669223231355105 139.745329370497 40.524 35.669223104557474 139.7453285421786 40.524 35.669223104557474 139.7453285421786 33.809 35.669223231355105 139.745329370497 33.809</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-83521161-09dd-4468-8744-dd6e339ba76d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-83521161-09dd-4468-8744-dd6e339ba76d_0">
											<gml:posList>35.66922303120441 139.74532684115965 33.809 35.669223104557474 139.7453285421786 33.809 35.669223104557474 139.7453285421786 40.524 35.66922303120441 139.74532684115965 40.524 35.66922303120441 139.74532684115965 33.809</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fa27b121-6949-41b6-9b90-7a0aeb10dded">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fa27b121-6949-41b6-9b90-7a0aeb10dded_0">
											<gml:posList>35.669223084673206 139.74532600159733 33.809 35.66922303120441 139.74532684115965 33.809 35.66922303120441 139.74532684115965 40.524 35.669223084673206 139.74532600159733 40.524 35.669223084673206 139.74532600159733 33.809</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a38fdcdc-574b-4f0d-8b7e-427cda5f0fbe">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a38fdcdc-574b-4f0d-8b7e-427cda5f0fbe_0">
											<gml:posList>35.669223371901424 139.74532434436696 33.809 35.669223084673206 139.74532600159733 33.809 35.669223084673206 139.74532600159733 40.524 35.669223371901424 139.74532434436696 40.524 35.669223371901424 139.74532434436696 33.809</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7c1ae59c-0b79-4835-81e1-258d95e102dd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7c1ae59c-0b79-4835-81e1-258d95e102dd_0">
											<gml:posList>35.66922388452928 139.74532276421192 33.809 35.669223371901424 139.74532434436696 33.809 35.669223371901424 139.74532434436696 40.524 35.66922388452928 139.74532276421192 40.524 35.66922388452928 139.74532276421192 33.809</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ea1fe4ad-45fa-4273-b37b-f56dd50e2837">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ea1fe4ad-45fa-4273-b37b-f56dd50e2837_0">
											<gml:posList>35.66922462260521 139.74532132740867 33.809 35.66922388452928 139.74532276421192 33.809 35.66922388452928 139.74532276421192 40.524 35.66922462260521 139.74532132740867 40.524 35.66922462260521 139.74532132740867 33.809</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6af30541-406c-46da-ac9f-95db5232e0a4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6af30541-406c-46da-ac9f-95db5232e0a4_0">
											<gml:posList>35.66922506380142 139.74532067520443 33.809 35.66922462260521 139.74532132740867 33.809 35.66922462260521 139.74532132740867 40.524 35.66922506380142 139.74532067520443 40.524 35.66922506380142 139.74532067520443 33.809</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-30479960-4f28-4731-8a09-9697ea2caa38">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-30479960-4f28-4731-8a09-9697ea2caa38_0">
											<gml:posList>35.66922607249902 139.74531952530273 33.809 35.66922607249902 139.74531952530273 40.524 35.6692272255777 139.7453185961645 40.524 35.6692272255777 139.7453185961645 33.809 35.66922607249902 139.74531952530273 33.809</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fd7a5193-cf9d-4cda-93f7-3e4edeec0de2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fd7a5193-cf9d-4cda-93f7-3e4edeec0de2_0">
											<gml:posList>35.66922607249902 139.74531952530273 33.809 35.66922506380142 139.74532067520443 33.809 35.66922506380142 139.74532067520443 40.524 35.66922607249902 139.74531952530273 40.524 35.66922607249902 139.74531952530273 33.809</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-717ed17c-3bf8-4afa-a007-7f6d05c5d21a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-717ed17c-3bf8-4afa-a007-7f6d05c5d21a_0">
											<gml:posList>35.669228505042305 139.74531793199395 33.809 35.669228505042305 139.74531793199395 40.524 35.669229847804836 139.74531754390645 40.524 35.669229847804836 139.74531754390645 33.809 35.669228505042305 139.74531793199395 33.809</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5c9bf4fe-7d69-47a8-bc5b-a91de599d4f3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5c9bf4fe-7d69-47a8-bc5b-a91de599d4f3_0">
											<gml:posList>35.6692272255777 139.7453185961645 33.809 35.6692272255777 139.7453185961645 40.524 35.669228505042305 139.74531793199395 40.524 35.669228505042305 139.74531793199395 33.809 35.6692272255777 139.7453185961645 33.809</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c2fbd7c7-5f0a-4851-8afc-46d8e36f6834">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c2fbd7c7-5f0a-4851-8afc-46d8e36f6834_0">
											<gml:posList>35.66923069120363 139.74533688470444 33.809 35.66923207925281 139.74533679481232 33.809 35.66923207925281 139.74533679481232 40.524 35.66923069120363 139.74533688470444 40.524 35.66923069120363 139.74533688470444 33.809</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ee145593-fe6c-492a-bdda-caba1c8f0d26">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ee145593-fe6c-492a-bdda-caba1c8f0d26_0">
											<gml:posList>35.669228653794896 139.74533646718862 33.809 35.66923069120363 139.74533688470444 33.809 35.66923069120363 139.74533688470444 40.524 35.669228653794896 139.74533646718862 40.524 35.669228653794896 139.74533646718862 33.809</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2eac37aa-3c63-4ed0-be9a-ef86b94e0e41">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2eac37aa-3c63-4ed0-be9a-ef86b94e0e41_0">
											<gml:posList>35.66922799559111 139.74533619175847 33.809 35.669228653794896 139.74533646718862 33.809 35.669228653794896 139.74533646718862 40.524 35.66922799559111 139.74533619175847 40.524 35.66922799559111 139.74533619175847 33.809</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-88c51d11-b2f6-45e0-b084-d423c5c59de0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-88c51d11-b2f6-45e0-b084-d423c5c59de0_0">
											<gml:posList>35.66922676915936 139.74533541987736 33.809 35.66922799559111 139.74533619175847 33.809 35.66922799559111 139.74533619175847 40.524 35.66922676915936 139.74533541987736 40.524 35.66922676915936 139.74533541987736 33.809</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-83998a59-769c-42b6-9a43-16680a75197b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-83998a59-769c-42b6-9a43-16680a75197b_0">
											<gml:posList>35.66922565972845 139.74533440485368 33.809 35.66922676915936 139.74533541987736 33.809 35.66922676915936 139.74533541987736 40.524 35.66922565972845 139.74533440485368 40.524 35.66922565972845 139.74533440485368 33.809</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ac3e3ed5-cca6-4825-9130-6f049e3f2f61">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ac3e3ed5-cca6-4825-9130-6f049e3f2f61_0">
											<gml:posList>35.669224712383134 139.7453331687301 33.809 35.66922565972845 139.74533440485368 33.809 35.66922565972845 139.74533440485368 40.524 35.669224712383134 139.7453331687301 40.524 35.669224712383134 139.7453331687301 33.809</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8f0782a2-c1e5-4a1f-bed2-6f1e754fbda3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8f0782a2-c1e5-4a1f-bed2-6f1e754fbda3_0">
											<gml:posList>35.669224712383134 139.7453331687301 33.809 35.669224712383134 139.7453331687301 40.524 35.66922396320254 139.74533174460538 40.524 35.66922396320254 139.74533174460538 33.809 35.669224712383134 139.7453331687301 33.809</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-052f82e3-9e46-451a-a3de-564d6a065fa1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-052f82e3-9e46-451a-a3de-564d6a065fa1_0">
											<gml:posList>35.66923192094558 139.74531751953853 33.809 35.669229847804836 139.74531754390645 33.809 35.669229847804836 139.74531754390645 40.524 35.66923192094558 139.74531751953853 40.524 35.66923192094558 139.74531751953853 33.809</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-da0a2c71-f4bc-4b21-9a57-daa15e59385f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-da0a2c71-f4bc-4b21-9a57-daa15e59385f_0">
											<gml:posList>35.66923259707997 139.74531766239565 33.809 35.66923192094558 139.74531751953853 33.809 35.66923192094558 139.74531751953853 40.524 35.66923259707997 139.74531766239565 40.524 35.66923259707997 139.74531766239565 33.809</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a0eedffb-5ef7-4346-b79b-27fdb32843cb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a0eedffb-5ef7-4346-b79b-27fdb32843cb_0">
											<gml:posList>35.6692332732628 139.74531787152932 33.809 35.66923259707997 139.74531766239565 33.809 35.66923259707997 139.74531766239565 40.524 35.6692332732628 139.74531787152932 40.524 35.6692332732628 139.74531787152932 33.809</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c143924d-4512-4a76-a8a2-ebbd01c806b5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c143924d-4512-4a76-a8a2-ebbd01c806b5_0">
											<gml:posList>35.66923637695943 139.74533427158434 33.809 35.66923637695943 139.74533427158434 40.524 35.669235287065504 139.74533532216023 40.524 35.669235287065504 139.74533532216023 33.809 35.66923637695943 139.74533427158434 33.809</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9e2ea42a-7b0c-4a66-9100-86960d238a73">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9e2ea42a-7b0c-4a66-9100-86960d238a73_0">
											<gml:posList>35.669237304452906 139.74533301131075 33.809 35.669237304452906 139.74533301131075 40.524 35.66923637695943 139.74533427158434 40.524 35.66923637695943 139.74533427158434 33.809 35.669237304452906 139.74533301131075 33.809</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1c85bdbb-036c-43c2-a589-9acbccfabaed">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1c85bdbb-036c-43c2-a589-9acbccfabaed_0">
											<gml:posList>35.66923803351523 139.74533157451722 33.809 35.66923803351523 139.74533157451722 40.524 35.669237304452906 139.74533301131075 40.524 35.669237304452906 139.74533301131075 33.809 35.66923803351523 139.74533157451722 33.809</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b163d05c-7dd0-44b9-b1d6-dfabee79cde4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b163d05c-7dd0-44b9-b1d6-dfabee79cde4_0">
											<gml:posList>35.66923855516498 139.74533000539813 33.809 35.66923855516498 139.74533000539813 40.524 35.66923803351523 139.74533157451722 40.524 35.66923803351523 139.74533157451722 33.809 35.66923855516498 139.74533000539813 33.809</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b293668f-284e-4719-bc14-fc6a120f6841">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b293668f-284e-4719-bc14-fc6a120f6841_0">
											<gml:posList>35.66923883337953 139.74532834817737 33.809 35.66923883337953 139.74532834817737 40.524 35.66923855516498 139.74533000539813 40.524 35.66923855516498 139.74533000539813 33.809 35.66923883337953 139.74532834817737 33.809</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7d4f66f5-cc7d-4869-b823-7697dd753fb8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7d4f66f5-cc7d-4869-b823-7697dd753fb8_0">
											<gml:posList>35.66923883337953 139.74532834817737 33.809 35.66923888684026 139.74532749756878 33.809 35.66923888684026 139.74532749756878 40.524 35.66923883337953 139.74532834817737 40.524 35.66923883337953 139.74532834817737 33.809</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-13804f8c-2a88-45c2-8a51-f16286bd80c0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-13804f8c-2a88-45c2-8a51-f16286bd80c0_0">
											<gml:posList>35.669238813495255 139.74532580759558 33.809 35.669238813495255 139.74532580759558 40.524 35.66923888684026 139.74532749756878 40.524 35.66923888684026 139.74532749756878 33.809 35.669238813495255 139.74532580759558 33.809</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-826e3e1c-4e70-4778-8420-abee240daa17">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-826e3e1c-4e70-4778-8420-abee240daa17_0">
											<gml:posList>35.66923868668953 139.74532496823096 33.809 35.66923868668953 139.74532496823096 40.524 35.669238813495255 139.74532580759558 40.524 35.669238813495255 139.74532580759558 33.809 35.66923868668953 139.74532496823096 33.809</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f008c608-9509-4d87-81f2-766876f3d136">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f008c608-9509-4d87-81f2-766876f3d136_0">
											<gml:posList>35.66923392246097 139.74531815801535 33.809 35.6692332732628 139.74531787152932 33.809 35.6692332732628 139.74531787152932 40.524 35.66923392246097 139.74531815801535 40.524 35.66923392246097 139.74531815801535 33.809</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ef53d7f9-021b-44a9-ace7-8f0a82c9e841">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ef53d7f9-021b-44a9-ace7-8f0a82c9e841_0">
											<gml:posList>35.66923515789847 139.74531891884027 33.809 35.66923392246097 139.74531815801535 33.809 35.66923392246097 139.74531815801535 40.524 35.66923515789847 139.74531891884027 40.524 35.66923515789847 139.74531891884027 33.809</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1d573f02-2aa4-4fd7-8bb8-2a70823ea953">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1d573f02-2aa4-4fd7-8bb8-2a70823ea953_0">
											<gml:posList>35.66923625831579 139.74531993387376 33.809 35.66923515789847 139.74531891884027 33.809 35.66923515789847 139.74531891884027 40.524 35.66923625831579 139.74531993387376 40.524 35.66923625831579 139.74531993387376 33.809</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8fe145c3-353b-4a0a-bad7-c97a779a711e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8fe145c3-353b-4a0a-bad7-c97a779a711e_0">
											<gml:posList>35.66923720566931 139.7453211810434 33.809 35.66923625831579 139.74531993387376 33.809 35.66923625831579 139.74531993387376 40.524 35.66923720566931 139.7453211810434 40.524 35.66923720566931 139.7453211810434 33.809</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9c394177-38e6-4ee9-897f-44c0e0bbda27">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9c394177-38e6-4ee9-897f-44c0e0bbda27_0">
											<gml:posList>35.669237963855686 139.7453225941123 33.809 35.66923720566931 139.7453211810434 33.809 35.66923720566931 139.7453211810434 40.524 35.669237963855686 139.7453225941123 40.524 35.669237963855686 139.7453225941123 33.809</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2ced4926-0b1c-43f7-92aa-b170917e4d50">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2ced4926-0b1c-43f7-92aa-b170917e4d50_0">
											<gml:posList>35.66923826187379 139.74532336701236 33.809 35.669237963855686 139.7453225941123 33.809 35.669237963855686 139.7453225941123 40.524 35.66923826187379 139.74532336701236 40.524 35.66923826187379 139.74532336701236 33.809</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f973540a-2f79-4300-9ef2-829ed5784e65">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f973540a-2f79-4300-9ef2-829ed5784e65_0">
											<gml:posList>35.66923826187379 139.74532336701236 33.809 35.66923826187379 139.74532336701236 40.524 35.66923868668953 139.74532496823096 40.524 35.66923868668953 139.74532496823096 33.809 35.66923826187379 139.74532336701236 33.809</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9e02ba44-3b02-47e5-8e33-72c067ae6e44">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9e02ba44-3b02-47e5-8e33-72c067ae6e44_0">
											<gml:posList>35.66923469247444 139.74533575361076 33.809 35.66923469247444 139.74533575361076 40.524 35.66923342202347 139.7453364177712 40.524 35.66923207925281 139.74533679481232 40.524 35.66923207925281 139.74533679481232 33.809 35.66923275516922 139.74533663942506 33.809 35.66923469247444 139.74533575361076 33.809</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-626ee24f-87e2-4e71-bef7-ca2497d29d5e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-626ee24f-87e2-4e71-bef7-ca2497d29d5e_0">
											<gml:posList>35.66923469247444 139.74533575361076 33.809 35.669235287065504 139.74533532216023 33.809 35.669235287065504 139.74533532216023 40.524 35.66923469247444 139.74533575361076 40.524 35.66923469247444 139.74533575361076 33.809</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6ae86095-0ae8-4286-8798-63ab35c23625">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6ae86095-0ae8-4286-8798-63ab35c23625_0">
											<gml:posList>35.669237963855686 139.7453225941123 40.524 35.66923720566931 139.7453211810434 40.524 35.66923625831579 139.74531993387376 40.524 35.66923515789847 139.74531891884027 40.524 35.66923392246097 139.74531815801535 40.524 35.6692332732628 139.74531787152932 40.524 35.66923259707997 139.74531766239565 40.524 35.66923192094558 139.74531751953853 40.524 35.669229847804836 139.74531754390645 40.524 35.669228505042305 139.74531793199395 40.524 35.6692272255777 139.7453185961645 40.524 35.66922607249902 139.74531952530273 40.524 35.66922506380142 139.74532067520443 40.524 35.66922462260521 139.74532132740867 40.524 35.66922388452928 139.74532276421192 40.524 35.669223371901424 139.74532434436696 40.524 35.669223084673206 139.74532600159733 40.524 35.66922303120441 139.74532684115965 40.524 35.669223104557474 139.7453285421786 40.524 35.669223231355105 139.745329370497 40.524 35.66922366519257 139.7453309827515 40.524 35.66922396320254 139.74533174460538 40.524 35.669224712383134 139.7453331687301 40.524 35.66922565972845 139.74533440485368 40.524 35.66922676915936 139.74533541987736 40.524 35.66922799559111 139.74533619175847 40.524 35.669228653794896 139.74533646718862 40.524 35.66923069120363 139.74533688470444 40.524 35.66923207925281 139.74533679481232 40.524 35.66923342202347 139.7453364177712 40.524 35.66923469247444 139.74533575361076 40.524 35.669235287065504 139.74533532216023 40.524 35.66923637695943 139.74533427158434 40.524 35.669237304452906 139.74533301131075 40.524 35.66923803351523 139.74533157451722 40.524 35.66923855516498 139.74533000539813 40.524 35.66923883337953 139.74532834817737 40.524 35.66923888684026 139.74532749756878 40.524 35.669238813495255 139.74532580759558 40.524 35.66923868668953 139.74532496823096 40.524 35.66923826187379 139.74532336701236 40.524 35.669237963855686 139.7453225941123 40.524</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-9c35a6cb-4b3c-416f-8da0-3a4229b3d7f6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9c35a6cb-4b3c-416f-8da0-3a4229b3d7f6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9c35a6cb-4b3c-416f-8da0-3a4229b3d7f6">
											<gml:posList>35.66899972236216 139.74557025444116 6.92 35.669453313119064 139.74505466576446 6.92 35.66948418149434 139.7450865661588 6.92 35.6695391963742 139.74501835090035 6.92 35.66955604216404 139.7450540334904 6.92 35.66956319294307 139.74508256886202 6.92 35.66956464486404 139.74510813909552 6.92 35.6695596344311 139.7451466956612 6.92 35.669545390559264 139.7451806561307 6.92 35.66952812880186 139.7452046562843 6.92 35.66948849219099 139.74523719758545 6.92 35.66947310191592 139.745256600462 6.92 35.66953338454398 139.74532890857296 6.92 35.669343195970086 139.745577544493 6.92 35.669471128745066 139.74573967219206 6.92 35.66950174350295 139.7456957855751 6.92 35.66961905739582 139.74583235351906 6.92 35.669536413967116 139.74593644315166 6.92 35.66956999787687 139.74597197514262 6.92 35.66955153624679 139.74599475031818 6.92 35.66957589477349 139.74602432746465 6.92 35.66956418742185 139.74603881066625 6.92 35.66962427166235 139.7461116498791 6.92 35.66963651936599 139.7460965033199 6.92 35.66966105838194 139.74612641171714 6.92 35.66963305073125 139.7461610166511 6.92 35.66957287622332 139.7460879565685 6.92 35.669509387377566 139.74616799970568 6.92 35.66899972236216 139.74557025444116 6.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-0f161f07-f302-4efd-8426-c37128c15ee6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0f161f07-f302-4efd-8426-c37128c15ee6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0f161f07-f302-4efd-8426-c37128c15ee6">
											<gml:posList>35.66945325212848 139.745057537826 29.739 35.66945414376656 139.74505655373855 29.739 35.6694528989331 139.74505527375777 29.739 35.66899970434276 139.74557026550696 29.739 35.66900239272755 139.74557341069436 29.739 35.669004455156035 139.745571055624 29.739 35.66945325212848 139.745057537826 29.739</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-957ec286-a81d-4258-beb5-070b05ea7fc9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-957ec286-a81d-4258-beb5-070b05ea7fc9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-957ec286-a81d-4258-beb5-070b05ea7fc9">
											<gml:posList>35.6690262634755 139.7456014195018 33.876 35.669455379586275 139.7450578337293 29.739 35.6694544700341 139.74505897248233 29.739 35.6690262634755 139.7456014195018 33.876</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a0b36f6e-b624-4404-91b2-a3e65327abc5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a0b36f6e-b624-4404-91b2-a3e65327abc5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a0b36f6e-b624-4404-91b2-a3e65327abc5">
											<gml:posList>35.66942883757657 139.74586541229417 20.1 35.66934882491399 139.7459678308151 20.1 35.66937653443225 139.74593236466407 20.1 35.66942883757657 139.74586541229417 20.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-cd7da57e-15b4-4d23-8da5-1d141f8710ba">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cd7da57e-15b4-4d23-8da5-1d141f8710ba">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cd7da57e-15b4-4d23-8da5-1d141f8710ba">
											<gml:posList>35.66942883757657 139.74586541229417 20.1 35.66945080163711 139.74583728697417 20.1 35.66934882491399 139.7459678308151 20.1 35.66942883757657 139.74586541229417 20.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e513d8e0-1f64-49d6-aa23-eccb7035c03a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e513d8e0-1f64-49d6-aa23-eccb7035c03a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e513d8e0-1f64-49d6-aa23-eccb7035c03a">
											<gml:posList>35.66942883757657 139.74586541229417 20.1 35.669445929746395 139.74584353335473 20.1 35.66945080163711 139.74583728697417 20.1 35.66942883757657 139.74586541229417 20.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-5fe21183-9675-432c-8d89-191597537ffd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5fe21183-9675-432c-8d89-191597537ffd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5fe21183-9675-432c-8d89-191597537ffd">
											<gml:posList>35.66900239272755 139.74557341069436 29.739 35.66902611912712 139.74560124292256 29.739 35.669027947231456 139.74559893229292 29.739 35.669004455156035 139.745571055624 29.739 35.66900239272755 139.74557341069436 29.739</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-bb7f100d-8a12-4fcc-b4c7-4dd972bb7049">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bb7f100d-8a12-4fcc-b4c7-4dd972bb7049">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bb7f100d-8a12-4fcc-b4c7-4dd972bb7049">
											<gml:posList>35.669163290045375 139.74576212276764 29.258 35.66927281416945 139.74562349600808 29.239 35.6692134518485 139.74555219209748 29.336 35.66910378468723 139.74569233232145 29.295 35.669163290045375 139.74576212276764 29.258</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-6695a851-88f8-4b46-8883-a743b0c7c877">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6695a851-88f8-4b46-8883-a743b0c7c877">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6695a851-88f8-4b46-8883-a743b0c7c877">
											<gml:posList>35.6694544700341 139.74505897248233 29.017 35.66945325212848 139.745057537826 29.017 35.669004455156035 139.745571055624 29.017 35.669027947231456 139.74559893229292 29.017 35.6694544700341 139.74505897248233 29.017</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-510211fb-2e2b-4a52-a40a-a1f77e63506a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-510211fb-2e2b-4a52-a40a-a1f77e63506a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-510211fb-2e2b-4a52-a40a-a1f77e63506a">
											<gml:posList>35.6690262634755 139.7456014195018 33.876 35.66910378468723 139.74569233232145 29.295 35.66945520834169 139.7450578560101 33.926 35.6690262634755 139.7456014195018 33.876</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a46f0a45-494a-4d17-a6d1-3c578285b634">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a46f0a45-494a-4d17-a6d1-3c578285b634">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a46f0a45-494a-4d17-a6d1-3c578285b634">
											<gml:posList>35.66922279535459 139.74583190227136 29.22 35.66933227569521 139.74569493246915 29.186 35.66927281416945 139.74562349600808 29.239 35.669163290045375 139.74576212276764 29.258 35.66922279535459 139.74583190227136 29.22</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-6612ff60-398f-45cc-b5fd-3685b4aa9be2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6612ff60-398f-45cc-b5fd-3685b4aa9be2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6612ff60-398f-45cc-b5fd-3685b4aa9be2">
											<gml:posList>35.669271962094264 139.7458895755724 27.165 35.669380884162784 139.74575331332636 27.131 35.66933227569521 139.74569493246915 29.186 35.66922279535459 139.74583190227136 29.22 35.669271962094264 139.7458895755724 27.165</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-79be70d3-fc58-4016-8d6a-3050d5dd796c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-79be70d3-fc58-4016-8d6a-3050d5dd796c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-79be70d3-fc58-4016-8d6a-3050d5dd796c">
											<gml:posList>35.66945520834169 139.7450578560101 33.926 35.66910378468723 139.74569233232145 29.295 35.6692134518485 139.74555219209748 29.336 35.669536808184255 139.74514194883275 29.385 35.66945520834169 139.7450578560101 33.926</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-dd98025c-f7b0-45ef-ac74-ae00d001058b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-dd98025c-f7b0-45ef-ac74-ae00d001058b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-dd98025c-f7b0-45ef-ac74-ae00d001058b">
											<gml:posList>35.66947312898133 139.74525663357068 23.825 35.66922622666125 139.74556778625242 23.675 35.66925657522036 139.74560396216572 25.365 35.66947312898133 139.74525663357068 23.825</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a15a16da-1bce-4999-9b2b-ed6583feb32c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a15a16da-1bce-4999-9b2b-ed6583feb32c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a15a16da-1bce-4999-9b2b-ed6583feb32c">
											<gml:posList>35.66934882491399 139.7459678308151 20.1 35.66945080163711 139.74583728697417 20.1 35.669271962094264 139.7458895755724 27.165 35.66934398903925 139.7459740329561 20.1 35.66934882491399 139.7459678308151 20.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e1d73248-201f-49dc-810b-efdc38b9a4e5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e1d73248-201f-49dc-810b-efdc38b9a4e5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e1d73248-201f-49dc-810b-efdc38b9a4e5">
											<gml:posList>35.66945080163711 139.74583728697417 20.1 35.669380884162784 139.74575331332636 27.131 35.669271962094264 139.7458895755724 27.165 35.66945080163711 139.74583728697417 20.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-bab5a26c-4b6a-4c8a-ae26-991b34ef79bb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bab5a26c-4b6a-4c8a-ae26-991b34ef79bb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bab5a26c-4b6a-4c8a-ae26-991b34ef79bb">
											<gml:posList>35.669536808184255 139.74514194883275 29.385 35.6692134518485 139.74555219209748 29.336 35.66922622667735 139.7455678083446 26.5 35.669536808184255 139.74514194883275 29.385</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ccc5dee7-8847-40d7-be8a-06dad55ffbea">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ccc5dee7-8847-40d7-be8a-06dad55ffbea">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ccc5dee7-8847-40d7-be8a-06dad55ffbea">
											<gml:posList>35.66925657522036 139.74560396216572 25.365 35.66950057256406 139.74528918953357 25.239 35.66947312898133 139.74525663357068 23.825 35.66925657522036 139.74560396216572 25.365</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-949b4708-74d8-47b0-b85d-c70de8685887">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-949b4708-74d8-47b0-b85d-c70de8685887">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-949b4708-74d8-47b0-b85d-c70de8685887">
											<gml:posList>35.669536808184255 139.74514194883275 29.385 35.66922622667735 139.7455678083446 26.5 35.669551863424836 139.74515740792347 26.5 35.669536808184255 139.74514194883275 29.385</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-aa30b27e-d0e3-4322-81dc-2d25ca9c7302">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-aa30b27e-d0e3-4322-81dc-2d25ca9c7302">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-aa30b27e-d0e3-4322-81dc-2d25ca9c7302">
											<gml:posList>35.66953336650039 139.7453288865005 20.097 35.66950057256406 139.74528918953357 25.239 35.66925657522036 139.74560396216572 25.365 35.66953336650039 139.7453288865005 20.097</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-29dc2d69-8f56-4e71-8f80-f031eb996687">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-29dc2d69-8f56-4e71-8f80-f031eb996687">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-29dc2d69-8f56-4e71-8f80-f031eb996687">
											<gml:posList>35.66933762942413 139.74558295213635 20.098 35.669342546361975 139.74557669465295 20.09 35.66953336650039 139.7453288865005 20.097 35.66925657522036 139.74560396216572 25.365 35.66929011761983 139.74564424376618 20.121 35.66933762942413 139.74558295213635 20.098</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-06b23ce4-8ddb-442f-b02a-6c2ada516a3b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-06b23ce4-8ddb-442f-b02a-6c2ada516a3b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-06b23ce4-8ddb-442f-b02a-6c2ada516a3b">
											<gml:posList>35.669471128745066 139.74573967219206 20.1 35.669342546361975 139.74557669465295 20.09 35.66933762942413 139.74558295213635 20.098 35.66947144436333 139.74575225339478 20.1 35.669471128745066 139.74573967219206 20.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f81a0337-6353-4ef5-8bd0-392e9a699bf6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f81a0337-6353-4ef5-8bd0-392e9a699bf6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f81a0337-6353-4ef5-8bd0-392e9a699bf6">
											<gml:posList>35.66937653443225 139.74593236466407 19.326 35.669446743604574 139.74598371892 19.326 35.66946669111902 139.74595904221746 19.326 35.66942883757657 139.74586541229417 19.326 35.66937653443225 139.74593236466407 19.326</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-72d230ca-0898-4c0a-953d-13412ea2603d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-72d230ca-0898-4c0a-953d-13412ea2603d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-72d230ca-0898-4c0a-953d-13412ea2603d">
											<gml:posList>35.669509207408495 139.74615597065485 20.1 35.66934882491399 139.7459678308151 20.1 35.66934398903925 139.7459740329561 20.1 35.66950937837184 139.7461680107616 20.1 35.669509207408495 139.74615597065485 20.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-baa66822-92ed-432a-bfb2-20a3b470f522">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-baa66822-92ed-432a-bfb2-20a3b470f522">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-baa66822-92ed-432a-bfb2-20a3b470f522">
											<gml:posList>35.66945080163711 139.74583728697417 19.326 35.669505553763805 139.74590307326372 19.326 35.66958236684166 139.74580113295514 19.326 35.66950227523013 139.74570805725435 19.326 35.66947144436333 139.74575225339478 19.326 35.66933764746767 139.74558297420882 19.326 35.669289973279554 139.7456440782324 19.326 35.66945080163711 139.74583728697417 19.326</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f9ad22ad-ac52-4e95-8abd-340379c05c96">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f9ad22ad-ac52-4e95-8abd-340379c05c96">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f9ad22ad-ac52-4e95-8abd-340379c05c96">
											<gml:posList>35.6694544700341 139.74505897248233 29.739 35.669455379586275 139.7450578337293 29.739 35.66945414376656 139.74505655373855 29.739 35.66945325212848 139.745057537826 29.739 35.6694544700341 139.74505897248233 29.739</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-6c72a418-db5a-48ce-b138-d0e98301a3d2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6c72a418-db5a-48ce-b138-d0e98301a3d2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6c72a418-db5a-48ce-b138-d0e98301a3d2">
											<gml:posList>35.669471128745066 139.74573967219206 20.1 35.66947144436333 139.74575225339478 20.1 35.66950227523013 139.74570805725435 20.1 35.66950174350295 139.7456957855751 20.1 35.669471128745066 139.74573967219206 20.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-cd71bea3-55c8-4676-9e27-4587d8ed11f6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cd71bea3-55c8-4676-9e27-4587d8ed11f6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cd71bea3-55c8-4676-9e27-4587d8ed11f6">
											<gml:posList>35.66946669111902 139.74595904221746 26.134 35.669446743604574 139.74598371892 26.134 35.66954028030931 139.74609728184407 26.134 35.66956022784672 139.74607260514094 26.134 35.66946669111902 139.74595904221746 26.134</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f9d03f28-cee1-418d-8a74-4e5758f05774">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f9d03f28-cee1-418d-8a74-4e5758f05774">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f9d03f28-cee1-418d-8a74-4e5758f05774">
											<gml:posList>35.66937653443225 139.74593236466407 19.326 35.66934882491399 139.7459678308151 19.326 35.669509207408495 139.74615597065485 19.326 35.66956787830552 139.74608200813302 19.326 35.66957287622332 139.7460879565685 19.326 35.66963305073125 139.7461610166511 19.326 35.66966105838194 139.74612641171714 19.326 35.66963651936599 139.7460965033199 19.326 35.66962427166235 139.7461116498791 19.326 35.66956418742185 139.74603881066625 19.326 35.66957589477349 139.74602432746465 19.326 35.66955153624679 139.74599475031818 19.326 35.66954659235866 139.74598873555436 19.326 35.66955979467644 139.74597245019785 19.326 35.669445929746395 139.74584353335473 19.326 35.66942883757657 139.74586541229417 19.326 35.66946669111902 139.74595904221746 19.326 35.66956022784672 139.74607260514094 19.326 35.66954028030931 139.74609728184407 19.326 35.669446743604574 139.74598371892 19.326 35.66937653443225 139.74593236466407 19.326</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-89454df4-16fc-4951-b32f-953631903e2d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-89454df4-16fc-4951-b32f-953631903e2d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-89454df4-16fc-4951-b32f-953631903e2d">
											<gml:posList>35.66955979467644 139.74597245019785 20.1 35.66956999787687 139.74597197514262 20.1 35.669510641948015 139.7459091872771 20.1 35.669505553763805 139.74590307326372 20.1 35.66945080163711 139.74583728697417 20.1 35.669445929746395 139.74584353335473 20.1 35.66955979467644 139.74597245019785 20.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-538c255c-b8a7-4348-be05-bc0f9f7374e9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-538c255c-b8a7-4348-be05-bc0f9f7374e9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-538c255c-b8a7-4348-be05-bc0f9f7374e9">
											<gml:posList>35.66949282384897 139.74523180231097 20.906 35.66948851924834 139.745237219648 20.906 35.66952812880186 139.7452046562843 20.906 35.66952689308073 139.7452035088437 20.906 35.66949282384897 139.74523180231097 20.906</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-50984a96-87f2-476e-85cd-6775e50186e1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-50984a96-87f2-476e-85cd-6775e50186e1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-50984a96-87f2-476e-85cd-6775e50186e1">
											<gml:posList>35.6695376294119 139.74502029674758 20.158 35.669483938374704 139.7450869088566 20.158 35.669551980481934 139.74515724210258 20.158 35.66949282384897 139.74523180231097 20.158 35.66952689308073 139.7452035088437 20.158 35.66954388461216 139.7451797630487 20.158 35.66955798466054 139.74514634399904 20.158 35.66956223894401 139.7451091579884 20.158 35.66956087673145 139.7450830022111 20.158 35.669553995408684 139.7450531630984 20.158 35.6695376294119 139.74502029674758 20.158</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-bdabe5f5-c062-494b-b830-48e6517478f7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bdabe5f5-c062-494b-b830-48e6517478f7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bdabe5f5-c062-494b-b830-48e6517478f7">
											<gml:posList>35.66954388461216 139.7451797630487 20.906 35.66952689308073 139.7452035088437 20.906 35.66952812880186 139.7452046562843 20.906 35.669545390559264 139.7451806561307 20.906 35.66954388461216 139.7451797630487 20.906</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-56d8ba36-c6d4-42cb-886f-c9b9365fc12e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-56d8ba36-c6d4-42cb-886f-c9b9365fc12e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-56d8ba36-c6d4-42cb-886f-c9b9365fc12e">
											<gml:posList>35.669509207408495 139.74615597065485 20.1 35.66950937837184 139.7461680107616 20.1 35.66957287622332 139.7460879565685 20.1 35.66956787830552 139.74608200813302 20.1 35.669509207408495 139.74615597065485 20.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e2d217e3-71bd-4d41-93fc-c162e3d8ee60">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e2d217e3-71bd-4d41-93fc-c162e3d8ee60">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e2d217e3-71bd-4d41-93fc-c162e3d8ee60">
											<gml:posList>35.66950174350295 139.7456957855751 20.1 35.66950227523013 139.74570805725435 20.1 35.66958236684166 139.74580113295514 20.1 35.6695920473015 139.7458007357717 20.1 35.66950174350295 139.7456957855751 20.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-8599a4fe-9fde-4187-99fa-10ade7a58c14">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8599a4fe-9fde-4187-99fa-10ade7a58c14">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8599a4fe-9fde-4187-99fa-10ade7a58c14">
											<gml:posList>35.6695391963742 139.74501835090035 20.906 35.6695376294119 139.74502029674758 20.906 35.669553995408684 139.7450531630984 20.906 35.66955604216404 139.7450540334904 20.906 35.6695391963742 139.74501835090035 20.906</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-7394c9ba-d3d1-41b0-90f7-66334e3ff119">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7394c9ba-d3d1-41b0-90f7-66334e3ff119">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7394c9ba-d3d1-41b0-90f7-66334e3ff119">
											<gml:posList>35.66958236684166 139.74580113295514 20.1 35.669505553763805 139.74590307326372 20.1 35.669510641948015 139.7459091872771 20.1 35.6695920473015 139.7458007357717 20.1 35.66958236684166 139.74580113295514 20.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e2a18771-8055-4543-bfbb-c3e61fdf7084">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e2a18771-8055-4543-bfbb-c3e61fdf7084">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e2a18771-8055-4543-bfbb-c3e61fdf7084">
											<gml:posList>35.66955798466054 139.74514634399904 20.906 35.66954388461216 139.7451797630487 20.906 35.669545390559264 139.7451806561307 20.906 35.6695596344311 139.7451466956612 20.906 35.66955798466054 139.74514634399904 20.906</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-4c8bb515-e4c4-43a4-aa3f-b223a696e48c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4c8bb515-e4c4-43a4-aa3f-b223a696e48c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4c8bb515-e4c4-43a4-aa3f-b223a696e48c">
											<gml:posList>35.66955153624679 139.74599475031818 20.1 35.66956999787687 139.74597197514262 20.1 35.66955979467644 139.74597245019785 20.1 35.66954659235866 139.74598873555436 20.1 35.66955153624679 139.74599475031818 20.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-dd3d2cf1-3476-4448-b4b6-7bf0bac23160">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-dd3d2cf1-3476-4448-b4b6-7bf0bac23160">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-dd3d2cf1-3476-4448-b4b6-7bf0bac23160">
											<gml:posList>35.66956087673145 139.7450830022111 20.906 35.66956321114053 139.74508280081108 20.906 35.66956319294307 139.74508256886202 20.906 35.66955604216404 139.7450540334904 20.906 35.669553995408684 139.7450531630984 20.906 35.66956087673145 139.7450830022111 20.906</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-370438f2-6620-488c-989e-72605a71b565">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-370438f2-6620-488c-989e-72605a71b565">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-370438f2-6620-488c-989e-72605a71b565">
											<gml:posList>35.66956223894401 139.7451091579884 20.906 35.66955798466054 139.74514634399904 20.906 35.6695596344311 139.7451466956612 20.906 35.66956464486404 139.74510813909552 20.906 35.66956223894401 139.7451091579884 20.906</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-71d31c65-932f-42ab-8ada-a4bd71b8bbd5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-71d31c65-932f-42ab-8ada-a4bd71b8bbd5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-71d31c65-932f-42ab-8ada-a4bd71b8bbd5">
											<gml:posList>35.66956087673145 139.7450830022111 20.906 35.66956223894401 139.7451091579884 20.906 35.66956464486404 139.74510813909552 20.906 35.66956321114053 139.74508280081108 20.906 35.66956087673145 139.7450830022111 20.906</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d93e959d-d7d9-4580-af87-0b387871cbb0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d93e959d-d7d9-4580-af87-0b387871cbb0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d93e959d-d7d9-4580-af87-0b387871cbb0">
											<gml:posList>35.669536413967116 139.74593644315166 13.817 35.66961905739582 139.74583235351906 13.817 35.6695920473015 139.7458007357717 13.817 35.669510641948015 139.7459091872771 13.817 35.669536413967116 139.74593644315166 13.817</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b74a1043-66ef-465c-ba37-ec603c1653a8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b74a1043-66ef-465c-ba37-ec603c1653a8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b74a1043-66ef-465c-ba37-ec603c1653a8">
											<gml:posList>35.6694544700341 139.74505897248233 29.739 35.669027947231456 139.74559893229292 29.017 35.669027947231456 139.74559893229292 29.739 35.6694544700341 139.74505897248233 29.739</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c47f729b-d4af-4901-ab23-7ae1baf30dc6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c47f729b-d4af-4901-ab23-7ae1baf30dc6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c47f729b-d4af-4901-ab23-7ae1baf30dc6">
											<gml:posList>35.6694544700341 139.74505897248233 29.739 35.6694544700341 139.74505897248233 29.017 35.669027947231456 139.74559893229292 29.017 35.6694544700341 139.74505897248233 29.739</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-719df742-5e02-4ebd-b1cf-e619b4d5fa74">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-719df742-5e02-4ebd-b1cf-e619b4d5fa74">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-719df742-5e02-4ebd-b1cf-e619b4d5fa74">
											<gml:posList>35.66933762942413 139.74558295213635 20.098 35.66933764746767 139.74558297420882 19.326 35.66947144436333 139.74575225339478 19.326 35.66947144436333 139.74575225339478 20.1 35.66933762942413 139.74558295213635 20.098</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e96df56c-1255-452d-90f7-d227a7ac9619">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e96df56c-1255-452d-90f7-d227a7ac9619">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e96df56c-1255-452d-90f7-d227a7ac9619">
											<gml:posList>35.669445929746395 139.74584353335473 20.1 35.669445929746395 139.74584353335473 19.326 35.66955979467644 139.74597245019785 19.326 35.66955979467644 139.74597245019785 20.1 35.669445929746395 139.74584353335473 20.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7fb6bd0e-17de-4d7f-b913-8e16fa3f0c13">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7fb6bd0e-17de-4d7f-b913-8e16fa3f0c13">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7fb6bd0e-17de-4d7f-b913-8e16fa3f0c13">
											<gml:posList>35.6695376294119 139.74502029674758 20.158 35.6695376294119 139.74502029674758 20.906 35.6695391963742 139.74501835090035 20.906 35.6695391963742 139.74501835090035 6.92 35.66948418149434 139.7450865661588 6.92 35.669483938374704 139.7450869088566 20.158 35.6695376294119 139.74502029674758 20.158</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-998142e9-3c63-4f3b-b882-69ab72716cda">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-998142e9-3c63-4f3b-b882-69ab72716cda">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-998142e9-3c63-4f3b-b882-69ab72716cda">
											<gml:posList>35.66950227523013 139.74570805725435 20.1 35.66950227523013 139.74570805725435 19.326 35.66958236684166 139.74580113295514 19.326 35.66958236684166 139.74580113295514 20.1 35.66950227523013 139.74570805725435 20.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9f4a2c35-0522-472c-a17d-04c7ea9ae09e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9f4a2c35-0522-472c-a17d-04c7ea9ae09e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9f4a2c35-0522-472c-a17d-04c7ea9ae09e">
											<gml:posList>35.66961905739582 139.74583235351906 6.92 35.66950174350295 139.7456957855751 6.92 35.66950174350295 139.7456957855751 20.1 35.6695920473015 139.7458007357717 20.1 35.6695920473015 139.7458007357717 13.817 35.66961905739582 139.74583235351906 13.817 35.66961905739582 139.74583235351906 6.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5cbf211a-e98e-4f8b-ba4b-35dd17dd447f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5cbf211a-e98e-4f8b-ba4b-35dd17dd447f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5cbf211a-e98e-4f8b-ba4b-35dd17dd447f">
											<gml:posList>35.66955604216404 139.7450540334904 6.92 35.6695391963742 139.74501835090035 6.92 35.6695391963742 139.74501835090035 20.906 35.66955604216404 139.7450540334904 20.906 35.66955604216404 139.7450540334904 6.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d386757e-2ba5-4f51-862f-d3a64e33b0d2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d386757e-2ba5-4f51-862f-d3a64e33b0d2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d386757e-2ba5-4f51-862f-d3a64e33b0d2">
											<gml:posList>35.6695376294119 139.74502029674758 20.906 35.6695376294119 139.74502029674758 20.158 35.669553995408684 139.7450531630984 20.158 35.669553995408684 139.7450531630984 20.906 35.6695376294119 139.74502029674758 20.906</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-96812c54-f1d3-4b05-b940-793c1f605fae">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-96812c54-f1d3-4b05-b940-793c1f605fae">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-96812c54-f1d3-4b05-b940-793c1f605fae">
											<gml:posList>35.66945325212848 139.745057537826 29.739 35.66945325212848 139.745057537826 29.017 35.6694544700341 139.74505897248233 29.017 35.6694544700341 139.74505897248233 29.739 35.66945325212848 139.745057537826 29.739</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-11e25880-dc92-4ea5-bc30-b935a188fd54">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-11e25880-dc92-4ea5-bc30-b935a188fd54">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-11e25880-dc92-4ea5-bc30-b935a188fd54">
											<gml:posList>35.669553995408684 139.7450531630984 20.906 35.669553995408684 139.7450531630984 20.158 35.66956087673145 139.7450830022111 20.158 35.66956087673145 139.7450830022111 20.906 35.669553995408684 139.7450531630984 20.906</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6e8b72ad-c5f6-47fe-b147-bd1c47eaa72c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6e8b72ad-c5f6-47fe-b147-bd1c47eaa72c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6e8b72ad-c5f6-47fe-b147-bd1c47eaa72c">
											<gml:posList>35.66956319294307 139.74508256886202 6.92 35.66955604216404 139.7450540334904 6.92 35.66955604216404 139.7450540334904 20.906 35.66956319294307 139.74508256886202 20.906 35.66956319294307 139.74508256886202 6.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2cadb5d8-3a90-46f0-803b-4eb037edd318">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2cadb5d8-3a90-46f0-803b-4eb037edd318">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2cadb5d8-3a90-46f0-803b-4eb037edd318">
											<gml:posList>35.66956464486404 139.74510813909552 6.92 35.66956319294307 139.74508256886202 6.92 35.66956319294307 139.74508256886202 20.906 35.66956464486404 139.74510813909552 6.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d44c7c9b-742f-4dff-9cd0-47a2f4ad5f96">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d44c7c9b-742f-4dff-9cd0-47a2f4ad5f96">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d44c7c9b-742f-4dff-9cd0-47a2f4ad5f96">
											<gml:posList>35.66956464486404 139.74510813909552 6.92 35.66956321114053 139.74508280081108 20.906 35.66956464486404 139.74510813909552 20.906 35.66956464486404 139.74510813909552 6.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0940e8e7-5eb6-4a07-99e8-c11b0885fecc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0940e8e7-5eb6-4a07-99e8-c11b0885fecc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0940e8e7-5eb6-4a07-99e8-c11b0885fecc">
											<gml:posList>35.66956087673145 139.7450830022111 20.906 35.66956087673145 139.7450830022111 20.158 35.66956223894401 139.7451091579884 20.158 35.66956223894401 139.7451091579884 20.906 35.66956087673145 139.7450830022111 20.906</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ee6da736-a22f-45c7-970f-eca000c23f34">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ee6da736-a22f-45c7-970f-eca000c23f34">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ee6da736-a22f-45c7-970f-eca000c23f34">
											<gml:posList>35.669453313119064 139.74505466576446 6.92 35.6694528989331 139.74505527375777 29.739 35.66945414376656 139.74505655373855 29.739 35.669455379586275 139.7450578337293 29.739 35.66945520834169 139.7450578560101 33.926 35.669536808184255 139.74514194883275 29.385 35.669483938374704 139.7450869088566 20.158 35.66948418149434 139.7450865661588 6.92 35.669453313119064 139.74505466576446 6.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-194d5cd0-e31a-4a91-8b68-61f30d360370">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-194d5cd0-e31a-4a91-8b68-61f30d360370">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-194d5cd0-e31a-4a91-8b68-61f30d360370">
											<gml:posList>35.669551863424836 139.74515740792347 26.5 35.669551980481934 139.74515724210258 20.158 35.669483938374704 139.7450869088566 20.158 35.669536808184255 139.74514194883275 29.385 35.669551863424836 139.74515740792347 26.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c605232b-db90-40da-9fa5-abf273743e4e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c605232b-db90-40da-9fa5-abf273743e4e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c605232b-db90-40da-9fa5-abf273743e4e">
											<gml:posList>35.6695596344311 139.7451466956612 6.92 35.66956464486404 139.74510813909552 6.92 35.66956464486404 139.74510813909552 20.906 35.6695596344311 139.7451466956612 20.906 35.6695596344311 139.7451466956612 6.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f9e82d72-989e-4449-b719-d6311190ad05">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f9e82d72-989e-4449-b719-d6311190ad05">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f9e82d72-989e-4449-b719-d6311190ad05">
											<gml:posList>35.66956223894401 139.7451091579884 20.906 35.66956223894401 139.7451091579884 20.158 35.66955798466054 139.74514634399904 20.158 35.66955798466054 139.74514634399904 20.906 35.66956223894401 139.7451091579884 20.906</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-df7a820b-1871-4bc6-b783-d800b1d001d9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-df7a820b-1871-4bc6-b783-d800b1d001d9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-df7a820b-1871-4bc6-b783-d800b1d001d9">
											<gml:posList>35.66955798466054 139.74514634399904 20.906 35.66955798466054 139.74514634399904 20.158 35.66954388461216 139.7451797630487 20.158 35.66954388461216 139.7451797630487 20.906 35.66955798466054 139.74514634399904 20.906</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-98c5cbe5-fe1c-4345-b462-e1a7e064ffec">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-98c5cbe5-fe1c-4345-b462-e1a7e064ffec">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-98c5cbe5-fe1c-4345-b462-e1a7e064ffec">
											<gml:posList>35.669545390559264 139.7451806561307 6.92 35.6695596344311 139.7451466956612 6.92 35.6695596344311 139.7451466956612 20.906 35.669545390559264 139.7451806561307 20.906 35.669545390559264 139.7451806561307 6.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c1ff7425-5e56-4bd1-b54f-b882cdb82591">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c1ff7425-5e56-4bd1-b54f-b882cdb82591">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c1ff7425-5e56-4bd1-b54f-b882cdb82591">
											<gml:posList>35.66954388461216 139.7451797630487 20.906 35.66954388461216 139.7451797630487 20.158 35.66952689308073 139.7452035088437 20.158 35.66952689308073 139.7452035088437 20.906 35.66954388461216 139.7451797630487 20.906</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5a83fb32-a9a1-421c-b030-d5957434a99f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5a83fb32-a9a1-421c-b030-d5957434a99f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5a83fb32-a9a1-421c-b030-d5957434a99f">
											<gml:posList>35.66952812880186 139.7452046562843 6.92 35.669545390559264 139.7451806561307 6.92 35.669545390559264 139.7451806561307 20.906 35.66952812880186 139.7452046562843 20.906 35.66952812880186 139.7452046562843 6.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-dfd72bd9-e526-4aaa-8b4a-5579dc18be1c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-dfd72bd9-e526-4aaa-8b4a-5579dc18be1c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-dfd72bd9-e526-4aaa-8b4a-5579dc18be1c">
											<gml:posList>35.66952689308073 139.7452035088437 20.906 35.66952689308073 139.7452035088437 20.158 35.66949282384897 139.74523180231097 20.158 35.66949282384897 139.74523180231097 20.906 35.66952689308073 139.7452035088437 20.906</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8c5ac006-5a61-4175-b237-97623e29c62d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8c5ac006-5a61-4175-b237-97623e29c62d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8c5ac006-5a61-4175-b237-97623e29c62d">
											<gml:posList>35.66948849219099 139.74523719758545 6.92 35.66952812880186 139.7452046562843 6.92 35.66952812880186 139.7452046562843 20.906 35.66948851924834 139.745237219648 20.906 35.66948849219099 139.74523719758545 6.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1f664fa9-40fd-421d-9406-de7ac28a3071">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1f664fa9-40fd-421d-9406-de7ac28a3071">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1f664fa9-40fd-421d-9406-de7ac28a3071">
											<gml:posList>35.66950057256406 139.74528918953357 25.239 35.66953336650039 139.7453288865005 20.097 35.66953338454398 139.74532890857296 6.92 35.66947310191592 139.745256600462 6.92 35.66947312898133 139.74525663357068 23.825 35.66950057256406 139.74528918953357 25.239</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-65dd1327-f58b-4915-9637-db31e2a39e47">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-65dd1327-f58b-4915-9637-db31e2a39e47">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-65dd1327-f58b-4915-9637-db31e2a39e47">
											<gml:posList>35.66899972236216 139.74557025444116 6.92 35.66899970434276 139.74557026550696 29.739 35.6694528989331 139.74505527375777 29.739 35.669453313119064 139.74505466576446 6.92 35.66899972236216 139.74557025444116 6.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-bb86fb54-151d-4275-97cc-6bc0412b0015">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bb86fb54-151d-4275-97cc-6bc0412b0015">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bb86fb54-151d-4275-97cc-6bc0412b0015">
											<gml:posList>35.669004455156035 139.745571055624 29.739 35.669004455156035 139.745571055624 29.017 35.66945325212848 139.745057537826 29.017 35.66945325212848 139.745057537826 29.739 35.669004455156035 139.745571055624 29.739</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-76db92a0-5bda-463e-9ee4-27b7dfef779e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-76db92a0-5bda-463e-9ee4-27b7dfef779e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-76db92a0-5bda-463e-9ee4-27b7dfef779e">
											<gml:posList>35.6690262634755 139.7456014195018 33.876 35.66945520834169 139.7450578560101 33.926 35.669455379586275 139.7450578337293 29.739 35.6690262634755 139.7456014195018 33.876</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2893e43d-57b6-4d71-920c-895ed4f41cfa">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2893e43d-57b6-4d71-920c-895ed4f41cfa">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2893e43d-57b6-4d71-920c-895ed4f41cfa">
											<gml:posList>35.6690262634755 139.7456014195018 33.876 35.6694544700341 139.74505897248233 29.739 35.669027947231456 139.74559893229292 29.739 35.6690262634755 139.7456014195018 33.876</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7f837516-09be-4dd9-93c6-a4030a2a3cec">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7f837516-09be-4dd9-93c6-a4030a2a3cec">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7f837516-09be-4dd9-93c6-a4030a2a3cec">
											<gml:posList>35.66947312898133 139.74525663357068 23.825 35.66947310191592 139.745256600462 6.92 35.66948849219099 139.74523719758545 6.92 35.66948851924834 139.745237219648 20.906 35.66949282384897 139.74523180231097 20.906 35.66949282384897 139.74523180231097 20.158 35.669551980481934 139.74515724210258 20.158 35.669551863424836 139.74515740792347 26.5 35.66922622667735 139.7455678083446 26.5 35.66922622666125 139.74556778625242 23.675 35.66947312898133 139.74525663357068 23.825</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-bce64ad4-fc3d-45a9-b826-4bb3de59f589">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bce64ad4-fc3d-45a9-b826-4bb3de59f589">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bce64ad4-fc3d-45a9-b826-4bb3de59f589">
											<gml:posList>35.66953336650039 139.7453288865005 20.097 35.669342546361975 139.74557669465295 20.09 35.66953338454398 139.74532890857296 6.92 35.66953336650039 139.7453288865005 20.097</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-21ee5381-6038-4e42-b3b7-13e2c663e349">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-21ee5381-6038-4e42-b3b7-13e2c663e349">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-21ee5381-6038-4e42-b3b7-13e2c663e349">
											<gml:posList>35.669342546361975 139.74557669465295 20.09 35.669343195970086 139.745577544493 6.92 35.66953338454398 139.74532890857296 6.92 35.669342546361975 139.74557669465295 20.09</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9556a54d-37c9-4d80-8e66-30d467e18798">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9556a54d-37c9-4d80-8e66-30d467e18798">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9556a54d-37c9-4d80-8e66-30d467e18798">
											<gml:posList>35.669027947231456 139.74559893229292 29.739 35.669027947231456 139.74559893229292 29.017 35.669004455156035 139.745571055624 29.017 35.669004455156035 139.745571055624 29.739 35.669027947231456 139.74559893229292 29.739</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7ba15af7-6eaf-4675-8e93-9e3c55184e49">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7ba15af7-6eaf-4675-8e93-9e3c55184e49">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7ba15af7-6eaf-4675-8e93-9e3c55184e49">
											<gml:posList>35.6690262634755 139.7456014195018 33.876 35.669027947231456 139.74559893229292 29.739 35.66902611912712 139.74560124292256 29.739 35.6690262634755 139.7456014195018 33.876</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7d5d1a3d-4c6f-43e7-9086-ce2cc30d2a51">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7d5d1a3d-4c6f-43e7-9086-ce2cc30d2a51">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7d5d1a3d-4c6f-43e7-9086-ce2cc30d2a51">
											<gml:posList>35.66933764746767 139.74558297420882 19.326 35.66933762942413 139.74558295213635 20.098 35.66929011761983 139.74564424376618 20.121 35.66933764746767 139.74558297420882 19.326</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5a67cef0-6547-47c4-91e8-d5313b86f96b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5a67cef0-6547-47c4-91e8-d5313b86f96b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5a67cef0-6547-47c4-91e8-d5313b86f96b">
											<gml:posList>35.66929011761983 139.74564424376618 20.121 35.669289973279554 139.7456440782324 19.326 35.66933764746767 139.74558297420882 19.326 35.66929011761983 139.74564424376618 20.121</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0f47888b-6298-46de-9759-4b4ebe128b40">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0f47888b-6298-46de-9759-4b4ebe128b40">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0f47888b-6298-46de-9759-4b4ebe128b40">
											<gml:posList>35.66910378468723 139.74569233232145 29.295 35.6690262634755 139.7456014195018 33.876 35.66902611912712 139.74560124292256 29.739 35.66910378468723 139.74569233232145 29.295</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-dcf243c7-c6e6-4a61-9f42-90d3eb0697e3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-dcf243c7-c6e6-4a61-9f42-90d3eb0697e3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-dcf243c7-c6e6-4a61-9f42-90d3eb0697e3">
											<gml:posList>35.669471128745066 139.74573967219206 6.92 35.669343195970086 139.745577544493 6.92 35.669342546361975 139.74557669465295 20.09 35.669471128745066 139.74573967219206 20.1 35.669471128745066 139.74573967219206 6.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0a0fb9e2-a94c-4ea0-92c6-c140003c1b9e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0a0fb9e2-a94c-4ea0-92c6-c140003c1b9e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0a0fb9e2-a94c-4ea0-92c6-c140003c1b9e">
											<gml:posList>35.66922622667735 139.7455678083446 26.5 35.6692134518485 139.74555219209748 29.336 35.66927281416945 139.74562349600808 29.239 35.66933227569521 139.74569493246915 29.186 35.669380884162784 139.74575331332636 27.131 35.66945080163711 139.74583728697417 20.1 35.66945080163711 139.74583728697417 19.326 35.669289973279554 139.7456440782324 19.326 35.66929011761983 139.74564424376618 20.121 35.66925657522036 139.74560396216572 25.365 35.66922622666125 139.74556778625242 23.675 35.66922622667735 139.7455678083446 26.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-93acea27-fc2f-457d-85a5-59759fe47028">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-93acea27-fc2f-457d-85a5-59759fe47028">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-93acea27-fc2f-457d-85a5-59759fe47028">
											<gml:posList>35.66950174350295 139.7456957855751 6.92 35.669471128745066 139.74573967219206 6.92 35.669471128745066 139.74573967219206 20.1 35.66950174350295 139.7456957855751 20.1 35.66950174350295 139.7456957855751 6.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-eccabd26-bc2a-413d-a885-ef4f78eeca21">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-eccabd26-bc2a-413d-a885-ef4f78eeca21">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-eccabd26-bc2a-413d-a885-ef4f78eeca21">
											<gml:posList>35.66947144436333 139.74575225339478 20.1 35.66947144436333 139.74575225339478 19.326 35.66950227523013 139.74570805725435 19.326 35.66950227523013 139.74570805725435 20.1 35.66947144436333 139.74575225339478 20.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-019f1b13-e2fe-45eb-b11c-dc008fcfeec4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-019f1b13-e2fe-45eb-b11c-dc008fcfeec4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-019f1b13-e2fe-45eb-b11c-dc008fcfeec4">
											<gml:posList>35.66958236684166 139.74580113295514 20.1 35.66958236684166 139.74580113295514 19.326 35.669505553763805 139.74590307326372 19.326 35.669505553763805 139.74590307326372 20.1 35.66958236684166 139.74580113295514 20.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b146db20-66e8-403e-a788-8ab1537c0e03">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b146db20-66e8-403e-a788-8ab1537c0e03">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b146db20-66e8-403e-a788-8ab1537c0e03">
											<gml:posList>35.66942883757657 139.74586541229417 20.1 35.66942883757657 139.74586541229417 19.326 35.669445929746395 139.74584353335473 19.326 35.669445929746395 139.74584353335473 20.1 35.66942883757657 139.74586541229417 20.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-fe937141-9a08-471f-9a7d-a51662893124">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fe937141-9a08-471f-9a7d-a51662893124">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fe937141-9a08-471f-9a7d-a51662893124">
											<gml:posList>35.6695920473015 139.7458007357717 20.1 35.669510641948015 139.7459091872771 20.1 35.669510641948015 139.7459091872771 13.817 35.6695920473015 139.7458007357717 13.817 35.6695920473015 139.7458007357717 20.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c2494138-7067-4108-a1a1-68288acc8999">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c2494138-7067-4108-a1a1-68288acc8999">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c2494138-7067-4108-a1a1-68288acc8999">
											<gml:posList>35.66934398903925 139.7459740329561 20.1 35.669271962094264 139.7458895755724 27.165 35.66922279535459 139.74583190227136 29.22 35.669163290045375 139.74576212276764 29.258 35.66910378468723 139.74569233232145 29.295 35.66902611912712 139.74560124292256 29.739 35.66900239272755 139.74557341069436 29.739 35.66899970434276 139.74557026550696 29.739 35.66899972236216 139.74557025444116 6.92 35.669509387377566 139.74616799970568 6.92 35.66950937837184 139.7461680107616 20.1 35.66934398903925 139.7459740329561 20.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-46c209f0-cb53-4591-a4ed-3900e322177b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-46c209f0-cb53-4591-a4ed-3900e322177b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-46c209f0-cb53-4591-a4ed-3900e322177b">
											<gml:posList>35.669505553763805 139.74590307326372 20.1 35.669505553763805 139.74590307326372 19.326 35.66945080163711 139.74583728697417 19.326 35.66945080163711 139.74583728697417 20.1 35.669505553763805 139.74590307326372 20.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2a33c658-95a1-4080-984e-102f1e0b46a8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2a33c658-95a1-4080-984e-102f1e0b46a8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2a33c658-95a1-4080-984e-102f1e0b46a8">
											<gml:posList>35.669536413967116 139.74593644315166 6.92 35.66961905739582 139.74583235351906 6.92 35.66961905739582 139.74583235351906 13.817 35.669536413967116 139.74593644315166 13.817 35.669536413967116 139.74593644315166 6.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-aa833631-c367-47ee-a89b-027a2cee7d26">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-aa833631-c367-47ee-a89b-027a2cee7d26">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-aa833631-c367-47ee-a89b-027a2cee7d26">
											<gml:posList>35.66937653443225 139.74593236466407 20.1 35.66937653443225 139.74593236466407 19.326 35.66942883757657 139.74586541229417 19.326 35.66942883757657 139.74586541229417 20.1 35.66937653443225 139.74593236466407 20.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c48dbb44-f34c-4aa2-ad3a-f5d407abbb64">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c48dbb44-f34c-4aa2-ad3a-f5d407abbb64">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c48dbb44-f34c-4aa2-ad3a-f5d407abbb64">
											<gml:posList>35.66956999787687 139.74597197514262 20.1 35.66956999787687 139.74597197514262 6.92 35.669536413967116 139.74593644315166 6.92 35.669536413967116 139.74593644315166 13.817 35.669510641948015 139.7459091872771 13.817 35.669510641948015 139.7459091872771 20.1 35.66956999787687 139.74597197514262 20.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-16052105-1cdb-4889-a7da-a03ceaf88fa9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-16052105-1cdb-4889-a7da-a03ceaf88fa9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-16052105-1cdb-4889-a7da-a03ceaf88fa9">
											<gml:posList>35.66934882491399 139.7459678308151 20.1 35.66934882491399 139.7459678308151 19.326 35.66937653443225 139.74593236466407 19.326 35.66937653443225 139.74593236466407 20.1 35.66934882491399 139.7459678308151 20.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-bc25f380-1ea5-4d5f-a2e6-6be63660ed3b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bc25f380-1ea5-4d5f-a2e6-6be63660ed3b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bc25f380-1ea5-4d5f-a2e6-6be63660ed3b">
											<gml:posList>35.669446743604574 139.74598371892 26.134 35.66946669111902 139.74595904221746 26.134 35.66946669111902 139.74595904221746 19.326 35.669446743604574 139.74598371892 19.326 35.669446743604574 139.74598371892 26.134</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b2f05dfb-37c0-40b2-bbde-450fc53f8880">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b2f05dfb-37c0-40b2-bbde-450fc53f8880">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b2f05dfb-37c0-40b2-bbde-450fc53f8880">
											<gml:posList>35.66955979467644 139.74597245019785 20.1 35.66955979467644 139.74597245019785 19.326 35.66954659235866 139.74598873555436 19.326 35.66954659235866 139.74598873555436 20.1 35.66955979467644 139.74597245019785 20.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0708f072-2704-4240-ac35-f6a596bd8f97">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0708f072-2704-4240-ac35-f6a596bd8f97">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0708f072-2704-4240-ac35-f6a596bd8f97">
											<gml:posList>35.66956999787687 139.74597197514262 6.92 35.66956999787687 139.74597197514262 20.1 35.66955153624679 139.74599475031818 20.1 35.66955153624679 139.74599475031818 19.326 35.66955153624679 139.74599475031818 6.92 35.66956999787687 139.74597197514262 6.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e640fce9-e95e-4574-9de0-cb0f48d8214b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e640fce9-e95e-4574-9de0-cb0f48d8214b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e640fce9-e95e-4574-9de0-cb0f48d8214b">
											<gml:posList>35.66954659235866 139.74598873555436 20.1 35.66954659235866 139.74598873555436 19.326 35.66955153624679 139.74599475031818 19.326 35.66955153624679 139.74599475031818 20.1 35.66954659235866 139.74598873555436 20.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-95ae98bf-1017-42a5-a37d-a3e0e743f67c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-95ae98bf-1017-42a5-a37d-a3e0e743f67c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-95ae98bf-1017-42a5-a37d-a3e0e743f67c">
											<gml:posList>35.66957589477349 139.74602432746465 6.92 35.66955153624679 139.74599475031818 6.92 35.66955153624679 139.74599475031818 19.326 35.66957589477349 139.74602432746465 19.326 35.66957589477349 139.74602432746465 6.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6696f61e-893d-466d-aad7-4bc19d24a7ca">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6696f61e-893d-466d-aad7-4bc19d24a7ca">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6696f61e-893d-466d-aad7-4bc19d24a7ca">
											<gml:posList>35.66946669111902 139.74595904221746 26.134 35.66956022784672 139.74607260514094 26.134 35.66956022784672 139.74607260514094 19.326 35.66946669111902 139.74595904221746 19.326 35.66946669111902 139.74595904221746 26.134</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-bced5dba-667f-4563-a979-37baad0c9e32">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bced5dba-667f-4563-a979-37baad0c9e32">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bced5dba-667f-4563-a979-37baad0c9e32">
											<gml:posList>35.66957589477349 139.74602432746465 6.92 35.66957589477349 139.74602432746465 19.326 35.66956418742185 139.74603881066625 19.326 35.66956418742185 139.74603881066625 6.92 35.66957589477349 139.74602432746465 6.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-08505dd0-1f4f-4f0c-bcb7-03c2beb3ea3a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-08505dd0-1f4f-4f0c-bcb7-03c2beb3ea3a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-08505dd0-1f4f-4f0c-bcb7-03c2beb3ea3a">
											<gml:posList>35.669446743604574 139.74598371892 19.326 35.66954028030931 139.74609728184407 19.326 35.66954028030931 139.74609728184407 26.134 35.669446743604574 139.74598371892 26.134 35.669446743604574 139.74598371892 19.326</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1402d06c-80a7-4cf0-8847-36ea47279ba8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1402d06c-80a7-4cf0-8847-36ea47279ba8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1402d06c-80a7-4cf0-8847-36ea47279ba8">
											<gml:posList>35.669509207408495 139.74615597065485 20.1 35.669509207408495 139.74615597065485 19.326 35.66934882491399 139.7459678308151 19.326 35.66934882491399 139.7459678308151 20.1 35.669509207408495 139.74615597065485 20.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a1d81554-d361-4db9-924b-bcc8f5e62c64">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a1d81554-d361-4db9-924b-bcc8f5e62c64">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a1d81554-d361-4db9-924b-bcc8f5e62c64">
											<gml:posList>35.66962427166235 139.7461116498791 19.326 35.66962427166235 139.7461116498791 6.92 35.66956418742185 139.74603881066625 6.92 35.66956418742185 139.74603881066625 19.326 35.66962427166235 139.7461116498791 19.326</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1f209671-44b1-449b-bb18-791509e507bd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1f209671-44b1-449b-bb18-791509e507bd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1f209671-44b1-449b-bb18-791509e507bd">
											<gml:posList>35.66954028030931 139.74609728184407 19.326 35.66956022784672 139.74607260514094 19.326 35.66956022784672 139.74607260514094 26.134 35.66954028030931 139.74609728184407 26.134 35.66954028030931 139.74609728184407 19.326</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ce5aa022-f5c0-46f7-98ed-d00d0303f78c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ce5aa022-f5c0-46f7-98ed-d00d0303f78c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ce5aa022-f5c0-46f7-98ed-d00d0303f78c">
											<gml:posList>35.66957287622332 139.7460879565685 20.1 35.66957287622332 139.7460879565685 19.326 35.66956787830552 139.74608200813302 19.326 35.66956787830552 139.74608200813302 20.1 35.66957287622332 139.7460879565685 20.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c4a1baee-53e3-4994-8172-01b82e254ec4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c4a1baee-53e3-4994-8172-01b82e254ec4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c4a1baee-53e3-4994-8172-01b82e254ec4">
											<gml:posList>35.66963651936599 139.7460965033199 19.326 35.66963651936599 139.7460965033199 6.92 35.66962427166235 139.7461116498791 6.92 35.66962427166235 139.7461116498791 19.326 35.66963651936599 139.7460965033199 19.326</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-dd0c0156-8d7c-4ee9-a541-c1e0f2e1794f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-dd0c0156-8d7c-4ee9-a541-c1e0f2e1794f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-dd0c0156-8d7c-4ee9-a541-c1e0f2e1794f">
											<gml:posList>35.66966105838194 139.74612641171714 19.326 35.66966105838194 139.74612641171714 6.92 35.66963651936599 139.7460965033199 6.92 35.66963651936599 139.7460965033199 19.326 35.66966105838194 139.74612641171714 19.326</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-66b748d5-8589-4ce7-9cb2-3842fd76c867">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-66b748d5-8589-4ce7-9cb2-3842fd76c867">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-66b748d5-8589-4ce7-9cb2-3842fd76c867">
											<gml:posList>35.66956787830552 139.74608200813302 20.1 35.66956787830552 139.74608200813302 19.326 35.669509207408495 139.74615597065485 19.326 35.669509207408495 139.74615597065485 20.1 35.66956787830552 139.74608200813302 20.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f5c120f3-803b-404e-953f-b59981152750">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f5c120f3-803b-404e-953f-b59981152750">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f5c120f3-803b-404e-953f-b59981152750">
											<gml:posList>35.66963305073125 139.7461610166511 19.326 35.66957287622332 139.7460879565685 19.326 35.66957287622332 139.7460879565685 6.92 35.66963305073125 139.7461610166511 6.92 35.66963305073125 139.7461610166511 19.326</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8cb5160b-e15f-46f1-9f36-753592729ed3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8cb5160b-e15f-46f1-9f36-753592729ed3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8cb5160b-e15f-46f1-9f36-753592729ed3">
											<gml:posList>35.66950937837184 139.7461680107616 20.1 35.669509387377566 139.74616799970568 6.92 35.66957287622332 139.7460879565685 6.92 35.66957287622332 139.7460879565685 19.326 35.66957287622332 139.7460879565685 20.1 35.66950937837184 139.7461680107616 20.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3695b1bc-e88c-42c6-951b-855ff3589fdb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3695b1bc-e88c-42c6-951b-855ff3589fdb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3695b1bc-e88c-42c6-951b-855ff3589fdb">
											<gml:posList>35.66966105838194 139.74612641171714 6.92 35.66966105838194 139.74612641171714 19.326 35.66963305073125 139.7461610166511 19.326 35.66963305073125 139.7461610166511 6.92 35.66966105838194 139.74612641171714 6.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-112334ec-d4c8-449a-a54e-6a0c7b4f2ef9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-112334ec-d4c8-449a-a54e-6a0c7b4f2ef9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-112334ec-d4c8-449a-a54e-6a0c7b4f2ef9">
											<gml:posList>35.66956464486404 139.74510813909552 6.92 35.66956319294307 139.74508256886202 20.906 35.66956321114053 139.74508280081108 20.906 35.66956464486404 139.74510813909552 6.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区虎ノ門二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-5344</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">2868.28595</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1210</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>6</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>