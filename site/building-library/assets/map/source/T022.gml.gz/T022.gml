<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_051df56c-a3cf-4f0b-9570-535902d48d31">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>18</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103018001</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="再開発等促進区を定める地区計画">
				<gen:value>虎ノ門駅南地区</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">401</bldg:usage>
			<bldg:measuredHeight uom="m">27.8</bldg:measuredHeight>
			<bldg:storeysAboveGround>8</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>1</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.66886744494496 139.7487814533133 0 35.66887803962499 139.74874799469185 0 35.668845011285 139.7487322889145 0 35.66879401107319 139.74888566178447 0 35.668920067581105 139.74894915432222 0 35.66895523666226 139.7488427437141 0 35.66891051245339 139.7488198150415 0 35.6689174827007 139.7487978812681 0 35.66887779094286 139.74877893494937 0 35.66887573134447 139.74878541010835 0 35.66886744494496 139.7487814533133 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66886744494496 139.7487814533133 5.45 35.66887573134447 139.74878541010835 5.45 35.66887779094286 139.74877893494937 5.45 35.6689174827007 139.7487978812681 5.45 35.66891051245339 139.7488198150415 5.45 35.66895523666226 139.7488427437141 5.45 35.668920067581105 139.74894915432222 5.45 35.66879401107319 139.74888566178447 5.45 35.668845011285 139.7487322889145 5.45 35.66887803962499 139.74874799469185 5.45 35.66886744494496 139.7487814533133 5.45</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66886744494496 139.7487814533133 5.45 35.66887803962499 139.74874799469185 5.45 35.66887803962499 139.74874799469185 33.26 35.66886744494496 139.7487814533133 33.26 35.66886744494496 139.7487814533133 5.45</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66887803962499 139.74874799469185 5.45 35.668845011285 139.7487322889145 5.45 35.668845011285 139.7487322889145 33.26 35.66887803962499 139.74874799469185 33.26 35.66887803962499 139.74874799469185 5.45</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668845011285 139.7487322889145 5.45 35.66879401107319 139.74888566178447 5.45 35.66879401107319 139.74888566178447 33.26 35.668845011285 139.7487322889145 33.26 35.668845011285 139.7487322889145 5.45</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66879401107319 139.74888566178447 5.45 35.668920067581105 139.74894915432222 5.45 35.668920067581105 139.74894915432222 33.26 35.66879401107319 139.74888566178447 33.26 35.66879401107319 139.74888566178447 5.45</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668920067581105 139.74894915432222 5.45 35.66895523666226 139.7488427437141 5.45 35.66895523666226 139.7488427437141 33.26 35.668920067581105 139.74894915432222 33.26 35.668920067581105 139.74894915432222 5.45</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66895523666226 139.7488427437141 5.45 35.66891051245339 139.7488198150415 5.45 35.66891051245339 139.7488198150415 33.26 35.66895523666226 139.7488427437141 33.26 35.66895523666226 139.7488427437141 5.45</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66891051245339 139.7488198150415 5.45 35.6689174827007 139.7487978812681 5.45 35.6689174827007 139.7487978812681 33.26 35.66891051245339 139.7488198150415 33.26 35.66891051245339 139.7488198150415 5.45</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6689174827007 139.7487978812681 5.45 35.66887779094286 139.74877893494937 5.45 35.66887779094286 139.74877893494937 33.26 35.6689174827007 139.7487978812681 33.26 35.6689174827007 139.7487978812681 5.45</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66887779094286 139.74877893494937 5.45 35.66887573134447 139.74878541010835 5.45 35.66887573134447 139.74878541010835 33.26 35.66887779094286 139.74877893494937 33.26 35.66887779094286 139.74877893494937 5.45</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66887573134447 139.74878541010835 5.45 35.66886744494496 139.7487814533133 5.45 35.66886744494496 139.7487814533133 33.26 35.66887573134447 139.74878541010835 33.26 35.66887573134447 139.74878541010835 5.45</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66886744494496 139.7487814533133 33.26 35.66887803962499 139.74874799469185 33.26 35.668845011285 139.7487322889145 33.26 35.66879401107319 139.74888566178447 33.26 35.668920067581105 139.74894915432222 33.26 35.66895523666226 139.7488427437141 33.26 35.66891051245339 139.7488198150415 33.26 35.6689174827007 139.7487978812681 33.26 35.66887779094286 139.74877893494937 33.26 35.66887573134447 139.74878541010835 33.26 35.66886744494496 139.7487814533133 33.26</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-217f059e-37a3-4c73-af2c-7946a47c0512"/>
							<gml:surfaceMember xlink:href="#poly-38188d87-0e74-4a18-bd6c-14020e940ab2"/>
							<gml:surfaceMember xlink:href="#poly-fa30f7f4-0e97-4132-90eb-612215c77155"/>
							<gml:surfaceMember xlink:href="#poly-95b1c741-0bbc-41a3-8043-cb799e337d14"/>
							<gml:surfaceMember xlink:href="#poly-3777d9d9-46e7-4941-9530-b3ca38738888"/>
							<gml:surfaceMember xlink:href="#poly-8dfd2853-b6c5-4578-890d-30efe474903e"/>
							<gml:surfaceMember xlink:href="#poly-d22494af-94de-4f90-bdd6-bf9e980dcf7e"/>
							<gml:surfaceMember xlink:href="#poly-edd0454d-0c36-43fe-acde-a9bba1d2914e"/>
							<gml:surfaceMember xlink:href="#poly-53129abf-a4d0-46d4-b4dd-c0aed75d6095"/>
							<gml:surfaceMember xlink:href="#poly-ab84b94c-4b24-4ddc-9223-259e53540ac5"/>
							<gml:surfaceMember xlink:href="#poly-9d656fff-5c09-41b1-a0b0-d7898395c31e"/>
							<gml:surfaceMember xlink:href="#poly-8fc8a3f0-6825-4352-bea8-98f9d278e623"/>
							<gml:surfaceMember xlink:href="#poly-ec5d57f0-cfe6-4e16-9069-95365725b4d2"/>
							<gml:surfaceMember xlink:href="#poly-b9d0243e-d3c3-457b-a815-242b0ee8e605"/>
							<gml:surfaceMember xlink:href="#poly-73649f09-b857-4d40-96ba-88a2a7d7b82a"/>
							<gml:surfaceMember xlink:href="#poly-d5a2957f-6ea9-4a1a-8e7c-972fee3ee735"/>
							<gml:surfaceMember xlink:href="#poly-9edbe45c-b824-4c30-b0ca-c40d6ecf1a96"/>
							<gml:surfaceMember xlink:href="#poly-1eb4d762-bb04-40b1-8412-07cb47b19041"/>
							<gml:surfaceMember xlink:href="#poly-a604d3c6-9aa9-48be-aaf3-cd76c70b6aa4"/>
							<gml:surfaceMember xlink:href="#poly-8e67cc4e-f5c9-455d-923f-80fac97e3e0d"/>
							<gml:surfaceMember xlink:href="#poly-c67ca088-b744-4083-aabe-8e3c6caa97d1"/>
							<gml:surfaceMember xlink:href="#poly-f86adfdf-403d-4d22-8270-ce8fccb08a73"/>
							<gml:surfaceMember xlink:href="#poly-5e5316b4-fba5-4177-8482-622b5c67b556"/>
							<gml:surfaceMember xlink:href="#poly-1689c482-1418-4c24-a2b3-79f215d0ee75"/>
							<gml:surfaceMember xlink:href="#poly-1f0f33c3-54f5-4d2c-b3ec-7dba5a34d046"/>
							<gml:surfaceMember xlink:href="#poly-caced02d-3211-48f0-854e-994c9eb89ce4"/>
							<gml:surfaceMember xlink:href="#poly-6cb10914-1517-447f-bdbb-60aac88cef1a"/>
							<gml:surfaceMember xlink:href="#poly-65e41d14-3e62-4988-9ef2-c3322657d313"/>
							<gml:surfaceMember xlink:href="#poly-83025a7e-3021-4eec-a368-f506cd98e3bb"/>
							<gml:surfaceMember xlink:href="#poly-50cfb4cf-7f80-47c0-a8f9-d76b0d4f0a5d"/>
							<gml:surfaceMember xlink:href="#poly-f9ea50f1-f20d-4d6c-a3ce-d964ffc9fbfd"/>
							<gml:surfaceMember xlink:href="#poly-32947599-5364-4b67-b9ab-df131590f937"/>
							<gml:surfaceMember xlink:href="#poly-aec51a3f-0b06-44f7-bd74-5aa361e10c86"/>
							<gml:surfaceMember xlink:href="#poly-5b222b76-d36f-4e85-a07f-70a9e42e36c2"/>
							<gml:surfaceMember xlink:href="#poly-ee7f2d1d-9678-4089-a00f-6ca18f5cf2e9"/>
							<gml:surfaceMember xlink:href="#poly-12447158-ed7c-4297-9575-3731510039db"/>
							<gml:surfaceMember xlink:href="#poly-bd33d877-c311-4138-b7ca-8351f2f93885"/>
							<gml:surfaceMember xlink:href="#poly-1f92f2f0-a399-477f-9a87-32b8853a4a10"/>
							<gml:surfaceMember xlink:href="#poly-0250ba3b-2d03-4338-aa21-b1ae54d24b52"/>
							<gml:surfaceMember xlink:href="#poly-e21e976a-cdf4-4d16-8a67-e6458331fa05"/>
							<gml:surfaceMember xlink:href="#poly-b75910ad-9500-46a9-9bbf-83a732110de8"/>
							<gml:surfaceMember xlink:href="#poly-6e570c99-ae11-4978-b568-f1a7055e9b3b"/>
							<gml:surfaceMember xlink:href="#poly-8e0ca092-32d3-46f7-ab57-91d97a3ec620"/>
							<gml:surfaceMember xlink:href="#poly-0f22f653-c325-499c-94cb-268a1113ea0d"/>
							<gml:surfaceMember xlink:href="#poly-8c296a73-c108-4234-bffb-294fbb1276f2"/>
							<gml:surfaceMember xlink:href="#poly-559922c0-ea3c-4e30-a81c-cdaa956cf05c"/>
							<gml:surfaceMember xlink:href="#poly-9d51181e-8f54-421d-b725-71628c5ead76"/>
							<gml:surfaceMember xlink:href="#poly-15d0815b-ffbf-48cf-8a4c-5c4fd1754b96"/>
							<gml:surfaceMember xlink:href="#poly-da53d958-7f46-4d4f-bdf4-7ac9e2d47b95"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_051df56c-a3cf-4f0b-9570-535902d48d31_BuildingInstallation_1060">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cb7dcba9-9366-4ae5-b1bd-85f5c1520a01">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cb7dcba9-9366-4ae5-b1bd-85f5c1520a01_0">
											<gml:posList>35.66889298037504 139.74875510363628 34.21 35.66887803962495 139.74874799469183 5.45 35.66887803962495 139.74874799469183 34.21 35.66889298037504 139.74875510363628 34.21</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6f660207-31b9-465e-9399-470b59bdef85">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6f660207-31b9-465e-9399-470b59bdef85_0">
											<gml:posList>35.66889298037504 139.74875510363628 34.21 35.66889298037504 139.74875510363628 5.45 35.66887803962495 139.74874799469183 5.45 35.66889298037504 139.74875510363628 34.21</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c104778e-2da7-4094-8730-21610a08f158">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c104778e-2da7-4094-8730-21610a08f158_0">
											<gml:posList>35.66889091109702 139.74876062884655 34.21 35.66889298037504 139.74875510363628 5.45 35.66889298037504 139.74875510363628 34.21 35.66889091109702 139.74876062884655 34.21</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d4d89a44-6d47-4d82-81aa-af9da35008ca">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d4d89a44-6d47-4d82-81aa-af9da35008ca_0">
											<gml:posList>35.66889091109702 139.74876062884655 34.21 35.66889091109702 139.74876062884655 5.45 35.66889298037504 139.74875510363628 5.45 35.66889091109702 139.74876062884655 34.21</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8f7042a3-ab01-446e-94f1-5d25491c96f0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8f7042a3-ab01-446e-94f1-5d25491c96f0_0">
											<gml:posList>35.66887803962495 139.74874799469183 34.21 35.66886744494495 139.7487814533133 5.45 35.66886744494495 139.7487814533133 34.21 35.66887803962495 139.74874799469183 34.21</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cc8f79bf-a213-462f-8928-c441e15410b1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cc8f79bf-a213-462f-8928-c441e15410b1_0">
											<gml:posList>35.66887803962495 139.74874799469183 34.21 35.66887803962495 139.74874799469183 5.45 35.66886744494495 139.7487814533133 5.45 35.66887803962495 139.74874799469183 34.21</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-dea52866-77ae-4f1f-b5d4-498f54498ab2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-dea52866-77ae-4f1f-b5d4-498f54498ab2_0">
											<gml:posList>35.66888310181199 139.7487814699413 34.21 35.66889091109702 139.74876062884655 34.21 35.66887779094285 139.74877893494934 34.21 35.66888310181199 139.7487814699413 34.21</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ea89b872-fe85-4607-91d0-95e647162846">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ea89b872-fe85-4607-91d0-95e647162846_0">
											<gml:posList>35.66887573134445 139.74878541010833 34.21 35.66887779094285 139.74877893494934 34.21 35.66886744494495 139.7487814533133 34.21 35.66887573134445 139.74878541010833 34.21</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6c24b4c6-28e8-4922-8121-109285a6f6ce">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6c24b4c6-28e8-4922-8121-109285a6f6ce_0">
											<gml:posList>35.66886744494495 139.7487814533133 34.21 35.66887779094285 139.74877893494934 34.21 35.66887803962495 139.74874799469183 34.21 35.66886744494495 139.7487814533133 34.21</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1bb2c23a-14ea-4d03-9405-da416c00c4b8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1bb2c23a-14ea-4d03-9405-da416c00c4b8_0">
											<gml:posList>35.66889091109702 139.74876062884655 34.21 35.66889298037504 139.74875510363628 34.21 35.66887803962495 139.74874799469183 34.21 35.66889091109702 139.74876062884655 34.21</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d2245660-3d49-45ab-9b89-2e7278aa423b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d2245660-3d49-45ab-9b89-2e7278aa423b_0">
											<gml:posList>35.66887779094285 139.74877893494934 34.21 35.66889091109702 139.74876062884655 34.21 35.66887803962495 139.74874799469183 34.21 35.66887779094285 139.74877893494934 34.21</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6b9318a6-04aa-480c-b1f5-da7f218a37cb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6b9318a6-04aa-480c-b1f5-da7f218a37cb_0">
											<gml:posList>35.668924452944005 139.7487759474909 31.186 35.66889091109702 139.74876062884655 5.45 35.66889091109702 139.74876062884655 34.21 35.668924452944005 139.7487759474909 31.186</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5948ab7e-9221-4e02-b5db-ae4a5ad99289">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5948ab7e-9221-4e02-b5db-ae4a5ad99289_0">
											<gml:posList>35.668924452944005 139.7487759474909 31.186 35.668924452944005 139.7487759474909 5.45 35.66889091109702 139.74876062884655 5.45 35.668924452944005 139.7487759474909 31.186</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bbb46aaf-9bd1-4cbd-8a8d-06021b76d5f3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bbb46aaf-9bd1-4cbd-8a8d-06021b76d5f3_0">
											<gml:posList>35.66891748270071 139.7487978812681 31.186 35.668924452944005 139.7487759474909 31.186 35.66889091109702 139.74876062884655 34.21 35.66891748270071 139.7487978812681 31.186</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e635a35e-55c9-4408-a74e-94c9f06b6a35">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e635a35e-55c9-4408-a74e-94c9f06b6a35_0">
											<gml:posList>35.66888310181199 139.7487814699413 34.21 35.66891748270071 139.7487978812681 31.186 35.66889091109702 139.74876062884655 34.21 35.66888310181199 139.7487814699413 34.21</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5b9a8e2f-d670-4ed9-986c-c44db973485b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5b9a8e2f-d670-4ed9-986c-c44db973485b_0">
											<gml:posList>35.66887573134445 139.74878541010833 34.21 35.66887779094285 139.74877893494934 5.45 35.66887779094285 139.74877893494934 34.21 35.66887573134445 139.74878541010833 34.21</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-020f456e-d9a4-464a-9adc-c1fe32797c57">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-020f456e-d9a4-464a-9adc-c1fe32797c57_0">
											<gml:posList>35.66887573134445 139.74878541010833 34.21 35.66887573134445 139.74878541010833 5.45 35.66887779094285 139.74877893494934 5.45 35.66887573134445 139.74878541010833 34.21</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-aee90d13-f58f-4239-a396-a0591f22030d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-aee90d13-f58f-4239-a396-a0591f22030d_0">
											<gml:posList>35.66886744494495 139.7487814533133 34.21 35.66887573134445 139.74878541010833 5.45 35.66887573134445 139.74878541010833 34.21 35.66886744494495 139.7487814533133 34.21</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d30a38d2-79da-4724-9a71-09440494f0aa">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d30a38d2-79da-4724-9a71-09440494f0aa_0">
											<gml:posList>35.66886744494495 139.7487814533133 34.21 35.66886744494495 139.7487814533133 5.45 35.66887573134445 139.74878541010833 5.45 35.66886744494495 139.7487814533133 34.21</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c1f36d5e-cd53-4681-8e49-47b20a038fd7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c1f36d5e-cd53-4681-8e49-47b20a038fd7_0">
											<gml:posList>35.66891748270071 139.7487978812681 31.186 35.668924452944005 139.7487759474909 5.45 35.668924452944005 139.7487759474909 31.186 35.66891748270071 139.7487978812681 31.186</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-564bb21c-3ff8-4f2e-8e97-3ba9c136bc2e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-564bb21c-3ff8-4f2e-8e97-3ba9c136bc2e_0">
											<gml:posList>35.66891748270071 139.7487978812681 31.186 35.66891748270071 139.7487978812681 5.45 35.668924452944005 139.7487759474909 5.45 35.66891748270071 139.7487978812681 31.186</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-83fe128d-d5f6-401c-98a7-f9a5672981a5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-83fe128d-d5f6-401c-98a7-f9a5672981a5_0">
											<gml:posList>35.66888310181199 139.7487814699413 34.21 35.66887779094285 139.74877893494934 34.21 35.66891748270071 139.7487978812681 31.186 35.66888310181199 139.7487814699413 34.21</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c5a0dbe9-98fd-442e-a7a7-627e046c7e5c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c5a0dbe9-98fd-442e-a7a7-627e046c7e5c_0">
											<gml:posList>35.66891748270071 139.7487978812681 31.186 35.66887779094285 139.74877893494934 5.45 35.66891748270071 139.7487978812681 5.45 35.66891748270071 139.7487978812681 31.186</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-438eedd0-733b-4ae4-9b5a-72371d3bf7c5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-438eedd0-733b-4ae4-9b5a-72371d3bf7c5_0">
											<gml:posList>35.66891748270071 139.7487978812681 31.186 35.66887779094285 139.74877893494934 34.21 35.66887779094285 139.74877893494934 5.45 35.66891748270071 139.7487978812681 31.186</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2ddb2ff8-6225-4ee5-928f-5bea30033caf">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66887573134445 139.74878541010833 5.45 35.66886744494495 139.7487814533133 5.45 35.66887779094285 139.74877893494934 5.45 35.66887573134445 139.74878541010833 5.45</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-50178135-061b-4a99-a2f4-afbe3c8629a1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66891748270071 139.7487978812681 5.45 35.66887779094285 139.74877893494934 5.45 35.66889091109702 139.74876062884655 5.45 35.66891748270071 139.7487978812681 5.45</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2012cced-ddaa-4fc6-ba57-99c0758a34f4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668924452944005 139.7487759474909 5.45 35.66891748270071 139.7487978812681 5.45 35.66889091109702 139.74876062884655 5.45 35.668924452944005 139.7487759474909 5.45</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4d7b2d58-7357-4360-8971-dd0868e846cd">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66887779094285 139.74877893494934 5.45 35.66886744494495 139.7487814533133 5.45 35.66887803962495 139.74874799469183 5.45 35.66887779094285 139.74877893494934 5.45</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-951bf28d-70c8-41b7-81d8-8f8dfa1debd2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66889091109702 139.74876062884655 5.45 35.66887803962495 139.74874799469183 5.45 35.66889298037504 139.74875510363628 5.45 35.66889091109702 139.74876062884655 5.45</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1da01c50-852c-40b6-bc67-3b45da0e6293">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66889091109702 139.74876062884655 5.45 35.66887779094285 139.74877893494934 5.45 35.66887803962495 139.74874799469183 5.45 35.66889091109702 139.74876062884655 5.45</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_051df56c-a3cf-4f0b-9570-535902d48d31_BuildingInstallation_1041">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cc0660ef-29eb-4a0b-b0da-5ca1cf466e8d">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668891527244604 139.7488550940604 32.286 35.66887986145059 139.74889076301213 32.286 35.66885965471639 139.74888084284686 32.286 35.66887132050751 139.74884517390268 32.286 35.668891527244604 139.7488550940604 32.286</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a204ce9a-bef0-4c76-8442-d3df5657b744">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a204ce9a-bef0-4c76-8442-d3df5657b744_0">
											<gml:posList>35.66887132050751 139.74884517390268 35.642 35.66887132050751 139.74884517390268 32.286 35.66885965471639 139.74888084284686 32.286 35.66885965471639 139.74888084284686 35.642 35.66887132050751 139.74884517390268 35.642</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e8379210-55b0-4573-a087-0918d4ca36c6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e8379210-55b0-4573-a087-0918d4ca36c6_0">
											<gml:posList>35.66885965471639 139.74888084284686 35.642 35.66885965471639 139.74888084284686 32.286 35.66887986145059 139.74889076301213 32.286 35.66887986145059 139.74889076301213 35.642 35.66885965471639 139.74888084284686 35.642</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-05f023c3-9204-41cf-8d1c-1dda9beb41da">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-05f023c3-9204-41cf-8d1c-1dda9beb41da_0">
											<gml:posList>35.66887132050751 139.74884517390268 35.642 35.66885965471639 139.74888084284686 35.642 35.66887986145059 139.74889076301213 35.642 35.668891527244604 139.7488550940604 35.642 35.66887132050751 139.74884517390268 35.642</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bd879b80-ee89-4124-9ef2-d977316b5c35">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bd879b80-ee89-4124-9ef2-d977316b5c35_0">
											<gml:posList>35.668891527244604 139.7488550940604 35.642 35.668891527244604 139.7488550940604 32.286 35.66887132050751 139.74884517390268 32.286 35.66887132050751 139.74884517390268 35.642 35.668891527244604 139.7488550940604 35.642</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bc4ab71a-31ac-420e-8427-307091d3b227">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bc4ab71a-31ac-420e-8427-307091d3b227_0">
											<gml:posList>35.66887986145059 139.74889076301213 35.642 35.66887986145059 139.74889076301213 32.286 35.668891527244604 139.7488550940604 32.286 35.668891527244604 139.7488550940604 35.642 35.66887986145059 139.74889076301213 35.642</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-217f059e-37a3-4c73-af2c-7946a47c0512">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-217f059e-37a3-4c73-af2c-7946a47c0512">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-217f059e-37a3-4c73-af2c-7946a47c0512">
											<gml:posList>35.66887573134445 139.74878541010833 5.45 35.66887779094285 139.74877893494934 5.45 35.66891748270071 139.7487978812681 5.45 35.66891051245339 139.7488198150415 5.45 35.66895523666226 139.7488427437141 5.45 35.66892006758108 139.7489491543222 5.45 35.668794011073196 139.74888566178447 5.45 35.66884501128499 139.7487322889145 5.45 35.66887803962495 139.74874799469183 5.45 35.66886744494495 139.7487814533133 5.45 35.66887573134445 139.74878541010833 5.45</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-38188d87-0e74-4a18-bd6c-14020e940ab2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-38188d87-0e74-4a18-bd6c-14020e940ab2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-38188d87-0e74-4a18-bd6c-14020e940ab2">
											<gml:posList>35.668794011073196 139.74888566178447 32.9 35.668798236992856 139.74888349230946 32.9 35.668846817623496 139.7487374013293 32.9 35.66884501128499 139.7487322889145 32.9 35.668794011073196 139.74888566178447 32.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-fa30f7f4-0e97-4132-90eb-612215c77155">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fa30f7f4-0e97-4132-90eb-612215c77155">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fa30f7f4-0e97-4132-90eb-612215c77155">
											<gml:posList>35.66892006758108 139.7489491543222 32.9 35.668918288230834 139.74894395350108 32.9 35.668798236992856 139.74888349230946 32.9 35.668794011073196 139.74888566178447 32.9 35.66892006758108 139.7489491543222 32.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-95b1c741-0bbc-41a3-8043-cb799e337d14">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-95b1c741-0bbc-41a3-8043-cb799e337d14">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-95b1c741-0bbc-41a3-8043-cb799e337d14">
											<gml:posList>35.66884501128499 139.7487322889145 32.9 35.668846817623496 139.7487374013293 32.9 35.66887385884626 139.74875026354303 32.9 35.66887803962495 139.74874799469183 32.9 35.66884501128499 139.7487322889145 32.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-3777d9d9-46e7-4941-9530-b3ca38738888">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3777d9d9-46e7-4941-9530-b3ca38738888">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3777d9d9-46e7-4941-9530-b3ca38738888">
											<gml:posList>35.66886154054102 139.74879370961008 37.176 35.66886330656458 139.74879275778767 37.176 35.668866481414646 139.7487827909016 37.176 35.668865704706164 139.74878061564846 37.176 35.66886154054102 139.74879370961008 37.176</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-8dfd2853-b6c5-4578-890d-30efe474903e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8dfd2853-b6c5-4578-890d-30efe474903e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8dfd2853-b6c5-4578-890d-30efe474903e">
											<gml:posList>35.668865704706164 139.74878061564846 32.9 35.66886744494495 139.7487814533133 32.9 35.66886561154387 139.74877630778658 32.9 35.668865704706164 139.74878061564846 32.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d22494af-94de-4f90-bdd6-bf9e980dcf7e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d22494af-94de-4f90-bdd6-bf9e980dcf7e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d22494af-94de-4f90-bdd6-bf9e980dcf7e">
											<gml:posList>35.66887101714759 139.7487982284999 37.176 35.6688727921849 139.748797276668 37.176 35.66886330656458 139.74879275778767 37.176 35.66886154054102 139.74879370961008 37.176 35.66887101714759 139.7487982284999 37.176</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-edd0454d-0c36-43fe-acde-a9bba1d2914e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-edd0454d-0c36-43fe-acde-a9bba1d2914e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-edd0454d-0c36-43fe-acde-a9bba1d2914e">
											<gml:posList>35.66887101714759 139.7487982284999 37.176 35.66886715876495 139.7488103500866 37.176 35.66886894281609 139.74880939824547 37.176 35.6688727921849 139.748797276668 37.176 35.66887101714759 139.7487982284999 37.176</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-53129abf-a4d0-46d4-b4dd-c0aed75d6095">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-53129abf-a4d0-46d4-b4dd-c0aed75d6095">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-53129abf-a4d0-46d4-b4dd-c0aed75d6095">
											<gml:posList>35.66887573134445 139.74878541010833 37.176 35.668865704706164 139.74878061564846 37.176 35.668866481414646 139.7487827909016 37.176 35.66887651707434 139.74878759639833 37.176 35.66887573134445 139.74878541010833 37.176</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ab84b94c-4b24-4ddc-9223-259e53540ac5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ab84b94c-4b24-4ddc-9223-259e53540ac5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ab84b94c-4b24-4ddc-9223-259e53540ac5">
											<gml:posList>35.66887803962495 139.74874799469183 32.9 35.66887385884626 139.74875026354303 32.9 35.66886561154387 139.74877630778658 32.9 35.66886744494495 139.7487814533133 32.9 35.66887803962495 139.74874799469183 32.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-9d656fff-5c09-41b1-a0b0-d7898395c31e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9d656fff-5c09-41b1-a0b0-d7898395c31e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9d656fff-5c09-41b1-a0b0-d7898395c31e">
											<gml:posList>35.66886561154387 139.74877630778658 32.286 35.66887385884626 139.74875026354303 32.286 35.668846817623496 139.7487374013293 32.286 35.668798236992856 139.74888349230946 32.286 35.668918288230834 139.74894395350108 32.286 35.66895103776138 139.74884488002886 32.286 35.668912327879404 139.74882503791343 32.286 35.66890930727308 139.74882360510952 32.286 35.66890741856879 139.7488295609251 32.286 35.66886715876495 139.7488103500866 32.286 35.66887101714759 139.7487982284999 32.286 35.66886154054102 139.74879370961008 32.286 35.668865704706164 139.74878061564846 32.286 35.66886561154387 139.74877630778658 32.286</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-8fc8a3f0-6825-4352-bea8-98f9d278e623">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8fc8a3f0-6825-4352-bea8-98f9d278e623">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8fc8a3f0-6825-4352-bea8-98f9d278e623">
											<gml:posList>35.66887573134445 139.74878541010833 37.176 35.66887651707434 139.74878759639833 37.176 35.66887857667285 139.74878112123935 37.176 35.66887779094285 139.74877893494934 37.176 35.66887573134445 139.74878541010833 37.176</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ec5d57f0-cfe6-4e16-9069-95365725b4d2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ec5d57f0-cfe6-4e16-9069-95365725b4d2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ec5d57f0-cfe6-4e16-9069-95365725b4d2">
											<gml:posList>35.66890741856879 139.7488295609251 37.176 35.668906632847424 139.7488273856799 37.176 35.66886894281609 139.74880939824547 37.176 35.66886715876495 139.7488103500866 37.176 35.66890741856879 139.7488295609251 37.176</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b9d0243e-d3c3-457b-a815-242b0ee8e605">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b9d0243e-d3c3-457b-a815-242b0ee8e605">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b9d0243e-d3c3-457b-a815-242b0ee8e605">
											<gml:posList>35.668906632847424 139.7488273856799 36.952 35.66891571668487 139.7487988441371 36.952 35.66887857667285 139.74878112123935 36.952 35.66887651707434 139.74878759639833 36.952 35.668866481414646 139.7487827909016 36.952 35.66886330656458 139.74879275778767 36.952 35.6688727921849 139.748797276668 36.952 35.66886894281609 139.74880939824547 36.952 35.668906632847424 139.7488273856799 36.952</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-73649f09-b857-4d40-96ba-88a2a7d7b82a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-73649f09-b857-4d40-96ba-88a2a7d7b82a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-73649f09-b857-4d40-96ba-88a2a7d7b82a">
											<gml:posList>35.66887779094285 139.74877893494934 37.176 35.66887857667285 139.74878112123935 37.176 35.66891571668487 139.7487988441371 37.176 35.66891748270071 139.7487978812681 37.176 35.66887779094285 139.74877893494934 37.176</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d5a2957f-6ea9-4a1a-8e7c-972fee3ee735">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d5a2957f-6ea9-4a1a-8e7c-972fee3ee735">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d5a2957f-6ea9-4a1a-8e7c-972fee3ee735">
											<gml:posList>35.668912327879404 139.74882503791343 32.9 35.66891051245339 139.7488198150415 32.9 35.66890930727308 139.74882360510952 32.9 35.668912327879404 139.74882503791343 32.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-9edbe45c-b824-4c30-b0ca-c40d6ecf1a96">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9edbe45c-b824-4c30-b0ca-c40d6ecf1a96">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9edbe45c-b824-4c30-b0ca-c40d6ecf1a96">
											<gml:posList>35.66891748270071 139.7487978812681 37.176 35.66891571668487 139.7487988441371 37.176 35.668906632847424 139.7488273856799 37.176 35.66890741856879 139.7488295609251 37.176 35.66891748270071 139.7487978812681 37.176</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-1eb4d762-bb04-40b1-8412-07cb47b19041">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1eb4d762-bb04-40b1-8412-07cb47b19041">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1eb4d762-bb04-40b1-8412-07cb47b19041">
											<gml:posList>35.66891051245339 139.7488198150415 32.9 35.668912327879404 139.74882503791343 32.9 35.66895103776138 139.74884488002886 32.9 35.66895523666226 139.7488427437141 32.9 35.66891051245339 139.7488198150415 32.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a604d3c6-9aa9-48be-aaf3-cd76c70b6aa4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a604d3c6-9aa9-48be-aaf3-cd76c70b6aa4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a604d3c6-9aa9-48be-aaf3-cd76c70b6aa4">
											<gml:posList>35.66895523666226 139.7488427437141 32.9 35.66895103776138 139.74884488002886 32.9 35.668918288230834 139.74894395350108 32.9 35.66892006758108 139.7489491543222 32.9 35.66895523666226 139.7488427437141 32.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8e67cc4e-f5c9-455d-923f-80fac97e3e0d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8e67cc4e-f5c9-455d-923f-80fac97e3e0d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8e67cc4e-f5c9-455d-923f-80fac97e3e0d">
											<gml:posList>35.66887803962495 139.74874799469183 5.45 35.66884501128499 139.7487322889145 5.45 35.66884501128499 139.7487322889145 32.9 35.66887803962495 139.74874799469183 32.9 35.66887803962495 139.74874799469183 5.45</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c67ca088-b744-4083-aabe-8e3c6caa97d1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c67ca088-b744-4083-aabe-8e3c6caa97d1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c67ca088-b744-4083-aabe-8e3c6caa97d1">
											<gml:posList>35.668846817623496 139.7487374013293 32.9 35.668846817623496 139.7487374013293 32.286 35.66887385884626 139.74875026354303 32.286 35.66887385884626 139.74875026354303 32.9 35.668846817623496 139.7487374013293 32.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f86adfdf-403d-4d22-8270-ce8fccb08a73">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f86adfdf-403d-4d22-8270-ce8fccb08a73">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f86adfdf-403d-4d22-8270-ce8fccb08a73">
											<gml:posList>35.66887385884626 139.74875026354303 32.9 35.66887385884626 139.74875026354303 32.286 35.66886561154387 139.74877630778658 32.286 35.66886561154387 139.74877630778658 32.9 35.66887385884626 139.74875026354303 32.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5e5316b4-fba5-4177-8482-622b5c67b556">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5e5316b4-fba5-4177-8482-622b5c67b556">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5e5316b4-fba5-4177-8482-622b5c67b556">
											<gml:posList>35.66886744494495 139.7487814533133 5.45 35.66887803962495 139.74874799469183 5.45 35.66887803962495 139.74874799469183 32.9 35.66886744494495 139.7487814533133 32.9 35.66886744494495 139.7487814533133 5.45</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1689c482-1418-4c24-a2b3-79f215d0ee75">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1689c482-1418-4c24-a2b3-79f215d0ee75">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1689c482-1418-4c24-a2b3-79f215d0ee75">
											<gml:posList>35.66886561154387 139.74877630778658 32.9 35.66886561154387 139.74877630778658 32.286 35.668865704706164 139.74878061564846 32.286 35.668865704706164 139.74878061564846 32.9 35.66886561154387 139.74877630778658 32.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1f0f33c3-54f5-4d2c-b3ec-7dba5a34d046">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1f0f33c3-54f5-4d2c-b3ec-7dba5a34d046">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1f0f33c3-54f5-4d2c-b3ec-7dba5a34d046">
											<gml:posList>35.66887779094285 139.74877893494934 37.176 35.66887779094285 139.74877893494934 5.45 35.66887573134445 139.74878541010833 5.45 35.66887573134445 139.74878541010833 37.176 35.66887779094285 139.74877893494934 37.176</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-caced02d-3211-48f0-854e-994c9eb89ce4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-caced02d-3211-48f0-854e-994c9eb89ce4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-caced02d-3211-48f0-854e-994c9eb89ce4">
											<gml:posList>35.66887573134445 139.74878541010833 37.176 35.66887573134445 139.74878541010833 5.45 35.66886744494495 139.7487814533133 5.45 35.66886744494495 139.7487814533133 32.9 35.668865704706164 139.74878061564846 32.9 35.668865704706164 139.74878061564846 37.176 35.66887573134445 139.74878541010833 37.176</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6cb10914-1517-447f-bdbb-60aac88cef1a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6cb10914-1517-447f-bdbb-60aac88cef1a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6cb10914-1517-447f-bdbb-60aac88cef1a">
											<gml:posList>35.66887651707434 139.74878759639833 37.176 35.66887651707434 139.74878759639833 36.952 35.66887857667285 139.74878112123935 36.952 35.66887857667285 139.74878112123935 37.176 35.66887651707434 139.74878759639833 37.176</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-65e41d14-3e62-4988-9ef2-c3322657d313">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-65e41d14-3e62-4988-9ef2-c3322657d313">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-65e41d14-3e62-4988-9ef2-c3322657d313">
											<gml:posList>35.668866481414646 139.7487827909016 37.176 35.668866481414646 139.7487827909016 36.952 35.66887651707434 139.74878759639833 36.952 35.66887651707434 139.74878759639833 37.176 35.668866481414646 139.7487827909016 37.176</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-83025a7e-3021-4eec-a368-f506cd98e3bb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-83025a7e-3021-4eec-a368-f506cd98e3bb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-83025a7e-3021-4eec-a368-f506cd98e3bb">
											<gml:posList>35.66886154054102 139.74879370961008 32.286 35.66886154054102 139.74879370961008 37.176 35.668865704706164 139.74878061564846 37.176 35.668865704706164 139.74878061564846 32.9 35.668865704706164 139.74878061564846 32.286 35.66886154054102 139.74879370961008 32.286</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-50cfb4cf-7f80-47c0-a8f9-d76b0d4f0a5d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-50cfb4cf-7f80-47c0-a8f9-d76b0d4f0a5d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-50cfb4cf-7f80-47c0-a8f9-d76b0d4f0a5d">
											<gml:posList>35.66886330656458 139.74879275778767 37.176 35.66886330656458 139.74879275778767 36.952 35.668866481414646 139.7487827909016 36.952 35.668866481414646 139.7487827909016 37.176 35.66886330656458 139.74879275778767 37.176</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f9ea50f1-f20d-4d6c-a3ce-d964ffc9fbfd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f9ea50f1-f20d-4d6c-a3ce-d964ffc9fbfd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f9ea50f1-f20d-4d6c-a3ce-d964ffc9fbfd">
											<gml:posList>35.66891748270071 139.7487978812681 37.176 35.66891748270071 139.7487978812681 5.45 35.66887779094285 139.74877893494934 5.45 35.66887779094285 139.74877893494934 37.176 35.66891748270071 139.7487978812681 37.176</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-32947599-5364-4b67-b9ab-df131590f937">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-32947599-5364-4b67-b9ab-df131590f937">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-32947599-5364-4b67-b9ab-df131590f937">
											<gml:posList>35.66887857667285 139.74878112123935 37.176 35.66887857667285 139.74878112123935 36.952 35.66891571668487 139.7487988441371 36.952 35.66891571668487 139.7487988441371 37.176 35.66887857667285 139.74878112123935 37.176</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-aec51a3f-0b06-44f7-bd74-5aa361e10c86">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-aec51a3f-0b06-44f7-bd74-5aa361e10c86">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-aec51a3f-0b06-44f7-bd74-5aa361e10c86">
											<gml:posList>35.66884501128499 139.7487322889145 5.45 35.668794011073196 139.74888566178447 5.45 35.668794011073196 139.74888566178447 32.9 35.66884501128499 139.7487322889145 32.9 35.66884501128499 139.7487322889145 5.45</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5b222b76-d36f-4e85-a07f-70a9e42e36c2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5b222b76-d36f-4e85-a07f-70a9e42e36c2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5b222b76-d36f-4e85-a07f-70a9e42e36c2">
											<gml:posList>35.668798236992856 139.74888349230946 32.9 35.668798236992856 139.74888349230946 32.286 35.668846817623496 139.7487374013293 32.286 35.668846817623496 139.7487374013293 32.9 35.668798236992856 139.74888349230946 32.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ee7f2d1d-9678-4089-a00f-6ca18f5cf2e9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ee7f2d1d-9678-4089-a00f-6ca18f5cf2e9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ee7f2d1d-9678-4089-a00f-6ca18f5cf2e9">
											<gml:posList>35.668794011073196 139.74888566178447 5.45 35.66892006758108 139.7489491543222 5.45 35.66892006758108 139.7489491543222 32.9 35.668794011073196 139.74888566178447 32.9 35.668794011073196 139.74888566178447 5.45</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-12447158-ed7c-4297-9575-3731510039db">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-12447158-ed7c-4297-9575-3731510039db">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-12447158-ed7c-4297-9575-3731510039db">
											<gml:posList>35.668918288230834 139.74894395350108 32.9 35.668918288230834 139.74894395350108 32.286 35.668798236992856 139.74888349230946 32.286 35.668798236992856 139.74888349230946 32.9 35.668918288230834 139.74894395350108 32.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-bd33d877-c311-4138-b7ca-8351f2f93885">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bd33d877-c311-4138-b7ca-8351f2f93885">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bd33d877-c311-4138-b7ca-8351f2f93885">
											<gml:posList>35.66886154054102 139.74879370961008 32.286 35.66887101714759 139.7487982284999 32.286 35.66887101714759 139.7487982284999 37.176 35.66886154054102 139.74879370961008 37.176 35.66886154054102 139.74879370961008 32.286</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1f92f2f0-a399-477f-9a87-32b8853a4a10">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1f92f2f0-a399-477f-9a87-32b8853a4a10">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1f92f2f0-a399-477f-9a87-32b8853a4a10">
											<gml:posList>35.6688727921849 139.748797276668 37.176 35.6688727921849 139.748797276668 36.952 35.66886330656458 139.74879275778767 36.952 35.66886330656458 139.74879275778767 37.176 35.6688727921849 139.748797276668 37.176</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0250ba3b-2d03-4338-aa21-b1ae54d24b52">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0250ba3b-2d03-4338-aa21-b1ae54d24b52">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0250ba3b-2d03-4338-aa21-b1ae54d24b52">
											<gml:posList>35.66886715876495 139.7488103500866 37.176 35.66887101714759 139.7487982284999 37.176 35.66887101714759 139.7487982284999 32.286 35.66886715876495 139.7488103500866 32.286 35.66886715876495 139.7488103500866 37.176</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e21e976a-cdf4-4d16-8a67-e6458331fa05">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e21e976a-cdf4-4d16-8a67-e6458331fa05">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e21e976a-cdf4-4d16-8a67-e6458331fa05">
											<gml:posList>35.66886894281609 139.74880939824547 37.176 35.66886894281609 139.74880939824547 36.952 35.6688727921849 139.748797276668 36.952 35.6688727921849 139.748797276668 37.176 35.66886894281609 139.74880939824547 37.176</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b75910ad-9500-46a9-9bbf-83a732110de8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b75910ad-9500-46a9-9bbf-83a732110de8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b75910ad-9500-46a9-9bbf-83a732110de8">
											<gml:posList>35.66886715876495 139.7488103500866 32.286 35.66890741856879 139.7488295609251 32.286 35.66890741856879 139.7488295609251 37.176 35.66886715876495 139.7488103500866 37.176 35.66886715876495 139.7488103500866 32.286</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6e570c99-ae11-4978-b568-f1a7055e9b3b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6e570c99-ae11-4978-b568-f1a7055e9b3b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6e570c99-ae11-4978-b568-f1a7055e9b3b">
											<gml:posList>35.668906632847424 139.7488273856799 37.176 35.668906632847424 139.7488273856799 36.952 35.66886894281609 139.74880939824547 36.952 35.66886894281609 139.74880939824547 37.176 35.668906632847424 139.7488273856799 37.176</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8e0ca092-32d3-46f7-ab57-91d97a3ec620">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8e0ca092-32d3-46f7-ab57-91d97a3ec620">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8e0ca092-32d3-46f7-ab57-91d97a3ec620">
											<gml:posList>35.66890930727308 139.74882360510952 32.9 35.66890930727308 139.74882360510952 32.286 35.668912327879404 139.74882503791343 32.286 35.668912327879404 139.74882503791343 32.9 35.66890930727308 139.74882360510952 32.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0f22f653-c325-499c-94cb-268a1113ea0d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0f22f653-c325-499c-94cb-268a1113ea0d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0f22f653-c325-499c-94cb-268a1113ea0d">
											<gml:posList>35.66891571668487 139.7487988441371 37.176 35.66891571668487 139.7487988441371 36.952 35.668906632847424 139.7488273856799 36.952 35.668906632847424 139.7488273856799 37.176 35.66891571668487 139.7487988441371 37.176</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8c296a73-c108-4234-bffb-294fbb1276f2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8c296a73-c108-4234-bffb-294fbb1276f2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8c296a73-c108-4234-bffb-294fbb1276f2">
											<gml:posList>35.66890741856879 139.7488295609251 32.286 35.66890930727308 139.74882360510952 32.286 35.66890930727308 139.74882360510952 32.9 35.66891051245339 139.7488198150415 32.9 35.66891051245339 139.7488198150415 5.45 35.66891748270071 139.7487978812681 5.45 35.66891748270071 139.7487978812681 37.176 35.66890741856879 139.7488295609251 37.176 35.66890741856879 139.7488295609251 32.286</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-559922c0-ea3c-4e30-a81c-cdaa956cf05c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-559922c0-ea3c-4e30-a81c-cdaa956cf05c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-559922c0-ea3c-4e30-a81c-cdaa956cf05c">
											<gml:posList>35.668912327879404 139.74882503791343 32.9 35.668912327879404 139.74882503791343 32.286 35.66895103776138 139.74884488002886 32.286 35.66895103776138 139.74884488002886 32.9 35.668912327879404 139.74882503791343 32.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9d51181e-8f54-421d-b725-71628c5ead76">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9d51181e-8f54-421d-b725-71628c5ead76">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9d51181e-8f54-421d-b725-71628c5ead76">
											<gml:posList>35.66895523666226 139.7488427437141 5.45 35.66891051245339 139.7488198150415 5.45 35.66891051245339 139.7488198150415 32.9 35.66895523666226 139.7488427437141 32.9 35.66895523666226 139.7488427437141 5.45</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-15d0815b-ffbf-48cf-8a4c-5c4fd1754b96">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-15d0815b-ffbf-48cf-8a4c-5c4fd1754b96">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-15d0815b-ffbf-48cf-8a4c-5c4fd1754b96">
											<gml:posList>35.66895103776138 139.74884488002886 32.9 35.66895103776138 139.74884488002886 32.286 35.668918288230834 139.74894395350108 32.286 35.668918288230834 139.74894395350108 32.9 35.66895103776138 139.74884488002886 32.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-da53d958-7f46-4d4f-bdf4-7ac9e2d47b95">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-da53d958-7f46-4d4f-bdf4-7ac9e2d47b95">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-da53d958-7f46-4d4f-bdf4-7ac9e2d47b95">
											<gml:posList>35.66892006758108 139.7489491543222 5.45 35.66895523666226 139.7488427437141 5.45 35.66895523666226 139.7488427437141 32.9 35.66892006758108 139.7489491543222 32.9 35.66892006758108 139.7489491543222 5.45</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区虎ノ門一丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-779</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">200.5259</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1210</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>7</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.1</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>