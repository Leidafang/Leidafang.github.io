<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_05a27ad4-34b0-4569-91f5-9f90a3f04da9">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">412</bldg:usage>
			<bldg:measuredHeight uom="m">18.6</bldg:measuredHeight>
			<bldg:storeysAboveGround>7</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.669990367790845 139.7379720757385 0 35.66997885191778 139.7379994840207 0 35.66999611012323 139.73807530675273 0 35.67003443515589 139.7380622045977 0 35.67003583754404 139.7380688527508 0 35.67007620806144 139.7380549528278 0 35.67007997081832 139.73807144035968 0 35.67014339222316 139.73804965917185 0 35.670120236547014 139.73794795097268 0 35.669990367790845 139.7379720757385 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669990367790845 139.7379720757385 18.454 35.670120236547014 139.73794795097268 18.454 35.67014339222316 139.73804965917185 18.454 35.67007997081832 139.73807144035968 18.454 35.67007620806144 139.7380549528278 18.454 35.67003583754404 139.7380688527508 18.454 35.67003443515589 139.7380622045977 18.454 35.66999611012323 139.73807530675273 18.454 35.66997885191778 139.7379994840207 18.454 35.669990367790845 139.7379720757385 18.454</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669990367790845 139.7379720757385 18.454 35.66997885191778 139.7379994840207 18.454 35.66997885191778 139.7379994840207 37.03 35.669990367790845 139.7379720757385 37.03 35.669990367790845 139.7379720757385 18.454</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66997885191778 139.7379994840207 18.454 35.66999611012323 139.73807530675273 18.454 35.66999611012323 139.73807530675273 37.03 35.66997885191778 139.7379994840207 37.03 35.66997885191778 139.7379994840207 18.454</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66999611012323 139.73807530675273 18.454 35.67003443515589 139.7380622045977 18.454 35.67003443515589 139.7380622045977 37.03 35.66999611012323 139.73807530675273 37.03 35.66999611012323 139.73807530675273 18.454</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67003443515589 139.7380622045977 18.454 35.67003583754404 139.7380688527508 18.454 35.67003583754404 139.7380688527508 37.03 35.67003443515589 139.7380622045977 37.03 35.67003443515589 139.7380622045977 18.454</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67003583754404 139.7380688527508 18.454 35.67007620806144 139.7380549528278 18.454 35.67007620806144 139.7380549528278 37.03 35.67003583754404 139.7380688527508 37.03 35.67003583754404 139.7380688527508 18.454</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67007620806144 139.7380549528278 18.454 35.67007997081832 139.73807144035968 18.454 35.67007997081832 139.73807144035968 37.03 35.67007620806144 139.7380549528278 37.03 35.67007620806144 139.7380549528278 18.454</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67007997081832 139.73807144035968 18.454 35.67014339222316 139.73804965917185 18.454 35.67014339222316 139.73804965917185 37.03 35.67007997081832 139.73807144035968 37.03 35.67007997081832 139.73807144035968 18.454</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67014339222316 139.73804965917185 18.454 35.670120236547014 139.73794795097268 18.454 35.670120236547014 139.73794795097268 37.03 35.67014339222316 139.73804965917185 37.03 35.67014339222316 139.73804965917185 18.454</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670120236547014 139.73794795097268 18.454 35.669990367790845 139.7379720757385 18.454 35.669990367790845 139.7379720757385 37.03 35.670120236547014 139.73794795097268 37.03 35.670120236547014 139.73794795097268 18.454</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669990367790845 139.7379720757385 37.03 35.66997885191778 139.7379994840207 37.03 35.66999611012323 139.73807530675273 37.03 35.67003443515589 139.7380622045977 37.03 35.67003583754404 139.7380688527508 37.03 35.67007620806144 139.7380549528278 37.03 35.67007997081832 139.73807144035968 37.03 35.67014339222316 139.73804965917185 37.03 35.670120236547014 139.73794795097268 37.03 35.669990367790845 139.7379720757385 37.03</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-1212d25f-53f0-4407-8ab3-2d987458b780"/>
							<gml:surfaceMember xlink:href="#poly-e590db6d-e8bb-470e-9d9f-a143fbe11650"/>
							<gml:surfaceMember xlink:href="#poly-7064cdab-6f57-4717-9027-92385f819f0b"/>
							<gml:surfaceMember xlink:href="#poly-9d55eb61-76f2-42be-83ae-395aa6f06966"/>
							<gml:surfaceMember xlink:href="#poly-26e9127c-a0c2-4fed-b4ed-06656540bc95"/>
							<gml:surfaceMember xlink:href="#poly-38cf6062-a8fb-45a4-ae3a-3ee1eb09d0a5"/>
							<gml:surfaceMember xlink:href="#poly-41e5d809-c9a8-47e5-9401-785af6709943"/>
							<gml:surfaceMember xlink:href="#poly-d9412d41-0be9-470f-9e13-73894e4d9b0c"/>
							<gml:surfaceMember xlink:href="#poly-c64ee64e-c7d6-4bfb-85dd-6ea7010e966e"/>
							<gml:surfaceMember xlink:href="#poly-b2aab428-d935-4c5d-aeb9-12f0f5a1d8a8"/>
							<gml:surfaceMember xlink:href="#poly-f6a6b658-19c9-4eb8-af7c-2ec0dc1cada5"/>
							<gml:surfaceMember xlink:href="#poly-53108798-edee-45c3-bd9d-51b87fd5194c"/>
							<gml:surfaceMember xlink:href="#poly-4a842bed-c65a-4428-98b4-31bf93b2a546"/>
							<gml:surfaceMember xlink:href="#poly-3b1f0f43-d65b-4b0b-bfa1-1870c57b8107"/>
							<gml:surfaceMember xlink:href="#poly-c54d7c5f-c3c2-448f-b78d-ea03851a8f2c"/>
							<gml:surfaceMember xlink:href="#poly-65ed0ec7-af57-4c94-8501-68999b3b0136"/>
							<gml:surfaceMember xlink:href="#poly-a915b36b-f45b-4567-920f-f4496d9fc3d4"/>
							<gml:surfaceMember xlink:href="#poly-7502364f-cffc-4c0e-b6b5-25ec1816d0a8"/>
							<gml:surfaceMember xlink:href="#poly-7396d45d-349d-4e27-bb2d-ca3fc29e4e11"/>
							<gml:surfaceMember xlink:href="#poly-5f18377a-9339-4e43-930b-7495c877511a"/>
							<gml:surfaceMember xlink:href="#poly-5eba745a-d6f1-48d2-ab29-3680f453c1b5"/>
							<gml:surfaceMember xlink:href="#poly-6d930b64-7e4b-4d70-bbaf-645575802273"/>
							<gml:surfaceMember xlink:href="#poly-f09c3ef2-dc7e-4274-a7c0-b7cde1871cdc"/>
							<gml:surfaceMember xlink:href="#poly-69f11b29-8836-478f-9f45-ac32c38e232a"/>
							<gml:surfaceMember xlink:href="#poly-f18aae08-0710-46ec-9271-66bbe0a87b00"/>
							<gml:surfaceMember xlink:href="#poly-ef2dc4a6-09a9-4266-9780-a23eadd08bcb"/>
							<gml:surfaceMember xlink:href="#poly-9db4bbeb-456f-48c1-90b2-60ad137153e2"/>
							<gml:surfaceMember xlink:href="#poly-379c1281-5a2b-4d6b-8cae-e14557a68adb"/>
							<gml:surfaceMember xlink:href="#poly-b73eca81-8d2e-4d60-b33c-5b20af417ac6"/>
							<gml:surfaceMember xlink:href="#poly-006abce6-f72b-4347-9831-d6847cf8d89d"/>
							<gml:surfaceMember xlink:href="#poly-8a2e084b-ee13-4742-ba89-8c657a53aad8"/>
							<gml:surfaceMember xlink:href="#poly-69dcf9ea-b7d4-4cff-979b-3c2df220a929"/>
							<gml:surfaceMember xlink:href="#poly-9ef6669c-593e-4632-95db-eb7750cf5f2f"/>
							<gml:surfaceMember xlink:href="#poly-d2721564-b298-427c-87cd-376144f8ddbd"/>
							<gml:surfaceMember xlink:href="#poly-2231e335-f188-4a40-b012-44a8252e7a50"/>
							<gml:surfaceMember xlink:href="#poly-e0dd4505-88f8-4867-8e7d-87a78dc0090c"/>
							<gml:surfaceMember xlink:href="#poly-9d3ff43d-982c-47f4-bd33-e103461615e3"/>
							<gml:surfaceMember xlink:href="#poly-0089466b-7169-4200-8e99-02067c7ba79f"/>
							<gml:surfaceMember xlink:href="#poly-f33ffb9f-eae1-4465-b6b1-4d98e64e9553"/>
							<gml:surfaceMember xlink:href="#poly-e8f3d084-e46b-4e09-91e6-03eec50b1c93"/>
							<gml:surfaceMember xlink:href="#poly-c6e8e7be-e6a0-4ad3-89b8-c5d361b87d8c"/>
							<gml:surfaceMember xlink:href="#poly-41e94953-927e-43a5-97ae-76e46e7aff49"/>
							<gml:surfaceMember xlink:href="#poly-2aaf2545-5f63-4312-92d4-8db963df4c36"/>
							<gml:surfaceMember xlink:href="#poly-c7e50d1c-e544-4c41-92ed-5a782ceacef9"/>
							<gml:surfaceMember xlink:href="#poly-09e4c5c4-7ad1-46b0-83c9-496f911ebfe2"/>
							<gml:surfaceMember xlink:href="#poly-57a9bd8c-4f1f-4a49-99d5-3dc3eb42421a"/>
							<gml:surfaceMember xlink:href="#poly-1841e91d-85d3-42b1-b965-a1eae3342a6f"/>
							<gml:surfaceMember xlink:href="#poly-5c11af96-23ff-4bca-85fd-7c2ad61fd1c7"/>
							<gml:surfaceMember xlink:href="#poly-35c938e1-ee79-47cc-acd0-6ca6e7856156"/>
							<gml:surfaceMember xlink:href="#poly-d9499b1a-049f-4d96-88cf-7c9eaefcfb97"/>
							<gml:surfaceMember xlink:href="#poly-fd03ba93-ecf9-4de7-a7e7-f4a539fceb7a"/>
							<gml:surfaceMember xlink:href="#poly-f4efaca1-3ada-4644-9c7b-a7feef39b905"/>
							<gml:surfaceMember xlink:href="#poly-ce196018-885f-4bf9-80fd-6f25e89fe1ac"/>
							<gml:surfaceMember xlink:href="#poly-0b70e0a6-3d2a-4db7-acf6-d4fddbb9aaa0"/>
							<gml:surfaceMember xlink:href="#poly-258ae92d-9a2b-455f-980b-3c3decd0c1ce"/>
							<gml:surfaceMember xlink:href="#poly-631003f8-12a7-4dc8-b311-970e15fb8687"/>
							<gml:surfaceMember xlink:href="#poly-36b33bcc-d58f-45db-bcbf-bb6c4ea9fd87"/>
							<gml:surfaceMember xlink:href="#poly-f6459bc4-e327-4f2b-ad1a-dfc2b1d16b49"/>
							<gml:surfaceMember xlink:href="#poly-8c631d28-f58e-4c35-9018-673b6098a06f"/>
							<gml:surfaceMember xlink:href="#poly-7992ff53-531c-4c01-9e1d-b96bcfe7f74a"/>
							<gml:surfaceMember xlink:href="#poly-13b03893-50c3-4c7b-935f-a90456897292"/>
							<gml:surfaceMember xlink:href="#poly-c5fbf5ba-dff9-46b1-80b9-89f3476d4e7e"/>
							<gml:surfaceMember xlink:href="#poly-10d19114-a03b-4ed2-8a7f-c59cad84fe3c"/>
							<gml:surfaceMember xlink:href="#poly-c13058bc-11fb-463b-8112-ae78d0e9ef4f"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_05a27ad4-34b0-4569-91f5-9f90a3f04da9_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cbb1f522-3efa-47fc-b2af-fa2be3d20fc9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67006356304376 139.7380223594259 39.872 35.67008677673578 139.7380151849274 39.872 35.67009233256383 139.73804221946793 39.872 35.670069127883934 139.73804939394836 39.872 35.67006356304376 139.7380223594259 39.872</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d0f5fd7a-de49-419b-995e-ff1c90811f34">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67007555688982 139.73804080339738 46.397 35.670073202778426 139.73803887310729 46.397 35.670071632109035 139.73803599191152 46.397 35.67007107958808 139.73803260137973 46.397 35.67007162673242 139.73802919849464 46.397 35.670073192838245 139.7380263135705 46.397 35.67007554389852 139.738024388734 46.397 35.67007831959171 139.73802371161526 46.397 35.67008108733786 139.73802438214446 46.397 35.67008344144074 139.73802630138812 46.397 35.67008501211037 139.7380291825841 46.397 35.670085573653886 139.73803258415197 46.397 35.67008501748698 139.7380359760021 46.397 35.670083451380926 139.73803886092654 46.397 35.67008110032917 139.73804079680897 46.397 35.6700783336496 139.73804147391644 46.397 35.67007555688982 139.73804080339738 46.397</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5f3d390d-3d5b-4148-b1e3-686e739d6e0c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5f3d390d-3d5b-4148-b1e3-686e739d6e0c_0">
											<gml:posList>35.67006356304376 139.7380223594259 39.872 35.67006356304376 139.7380223594259 46.397 35.67008677673578 139.7380151849274 46.397 35.67008677673578 139.7380151849274 39.872 35.67006356304376 139.7380223594259 39.872</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2c2d52af-286a-4580-8e4b-6a6f1495debc">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2c2d52af-286a-4580-8e4b-6a6f1495debc_0">
											<gml:posList>35.67007831959171 139.73802371161526 46.397 35.67007554389852 139.738024388734 46.397 35.67007554389852 139.738024388734 46.932 35.67007831959171 139.73802371161526 46.932 35.67007831959171 139.73802371161526 46.397</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-87d40d49-a870-4445-80cb-d3f671df4532">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-87d40d49-a870-4445-80cb-d3f671df4532_0">
											<gml:posList>35.67008108733786 139.73802438214446 46.397 35.67007831959171 139.73802371161526 46.397 35.67007831959171 139.73802371161526 46.932 35.67008108733786 139.73802438214446 46.932 35.67008108733786 139.73802438214446 46.397</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c98abc0c-1cbb-43f2-b70a-2be567450f85">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c98abc0c-1cbb-43f2-b70a-2be567450f85_0">
											<gml:posList>35.67008344144074 139.73802630138812 46.397 35.67008108733786 139.73802438214446 46.397 35.67008108733786 139.73802438214446 46.932 35.67008344144074 139.73802630138812 46.932 35.67008344144074 139.73802630138812 46.397</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-940afe96-24d1-46ce-8f90-4f2320545c1f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-940afe96-24d1-46ce-8f90-4f2320545c1f_0">
											<gml:posList>35.67007554389852 139.738024388734 46.397 35.670073192838245 139.7380263135705 46.397 35.670073192838245 139.7380263135705 46.932 35.67007554389852 139.738024388734 46.932 35.67007554389852 139.738024388734 46.397</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c14e3ba0-4219-4818-b612-9da4de0c747d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c14e3ba0-4219-4818-b612-9da4de0c747d_0">
											<gml:posList>35.67008501211037 139.7380291825841 46.397 35.67008344144074 139.73802630138812 46.397 35.67008344144074 139.73802630138812 46.932 35.67008501211037 139.7380291825841 46.932 35.67008501211037 139.7380291825841 46.397</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b1b1a653-7441-4054-bca9-a16f9ada9071">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b1b1a653-7441-4054-bca9-a16f9ada9071_0">
											<gml:posList>35.670073192838245 139.7380263135705 46.397 35.67007162673242 139.73802919849464 46.397 35.67007162673242 139.73802919849464 46.932 35.670073192838245 139.7380263135705 46.932 35.670073192838245 139.7380263135705 46.397</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4bca7f4d-9c09-4b22-b1de-09a2d1db6ff1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4bca7f4d-9c09-4b22-b1de-09a2d1db6ff1_0">
											<gml:posList>35.67009233256383 139.73804221946793 39.872 35.67008677673578 139.7380151849274 39.872 35.67008677673578 139.7380151849274 46.397 35.67009233256383 139.73804221946793 46.397 35.67009233256383 139.73804221946793 39.872</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7404eead-2f2b-403a-a343-94ff84fbca3f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7404eead-2f2b-403a-a343-94ff84fbca3f_0">
											<gml:posList>35.670085573653886 139.73803258415197 46.397 35.67008501211037 139.7380291825841 46.397 35.67008501211037 139.7380291825841 46.932 35.670085573653886 139.73803258415197 46.932 35.670085573653886 139.73803258415197 46.397</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b3e0cf8b-5e8b-461d-839b-3f5cddebf2f7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b3e0cf8b-5e8b-461d-839b-3f5cddebf2f7_0">
											<gml:posList>35.67007162673242 139.73802919849464 46.397 35.67007107958808 139.73803260137973 46.397 35.67007107958808 139.73803260137973 46.932 35.67007162673242 139.73802919849464 46.932 35.67007162673242 139.73802919849464 46.397</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-079ee86e-37ec-4cb9-9d8e-3c472866e6bb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-079ee86e-37ec-4cb9-9d8e-3c472866e6bb_0">
											<gml:posList>35.67006356304376 139.7380223594259 46.397 35.670069127883934 139.73804939394836 46.397 35.67009233256383 139.73804221946793 46.397 35.67008677673578 139.7380151849274 46.397 35.67006356304376 139.7380223594259 46.397</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-935017f2-6c6f-40ae-80c8-a8db99c2937c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-935017f2-6c6f-40ae-80c8-a8db99c2937c_0">
											<gml:posList>35.67007555688982 139.73804080339738 46.932 35.6700783336496 139.73804147391644 46.932 35.67008110032917 139.73804079680897 46.932 35.670083451380926 139.73803886092654 46.932 35.67008501748698 139.7380359760021 46.932 35.670085573653886 139.73803258415197 46.932 35.67008501211037 139.7380291825841 46.932 35.67008344144074 139.73802630138812 46.932 35.67008108733786 139.73802438214446 46.932 35.67007831959171 139.73802371161526 46.932 35.67007554389852 139.738024388734 46.932 35.670073192838245 139.7380263135705 46.932 35.67007162673242 139.73802919849464 46.932 35.67007107958808 139.73803260137973 46.932 35.670071632109035 139.73803599191152 46.932 35.670073202778426 139.73803887310729 46.932 35.67007555688982 139.73804080339738 46.932</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-806bbee5-25a6-4ddb-814a-a0a2d5be81f6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-806bbee5-25a6-4ddb-814a-a0a2d5be81f6_0">
											<gml:posList>35.67008501748698 139.7380359760021 46.397 35.670085573653886 139.73803258415197 46.397 35.670085573653886 139.73803258415197 46.932 35.67008501748698 139.7380359760021 46.932 35.67008501748698 139.7380359760021 46.397</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9ef2de7f-9d2a-464b-9d99-1e54220df69f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9ef2de7f-9d2a-464b-9d99-1e54220df69f_0">
											<gml:posList>35.67007107958808 139.73803260137973 46.397 35.670071632109035 139.73803599191152 46.397 35.670071632109035 139.73803599191152 46.932 35.67007107958808 139.73803260137973 46.932 35.67007107958808 139.73803260137973 46.397</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-928f2a24-b39e-4f17-91b6-d96dee98e242">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-928f2a24-b39e-4f17-91b6-d96dee98e242_0">
											<gml:posList>35.670069127883934 139.73804939394836 39.872 35.670069127883934 139.73804939394836 46.397 35.67006356304376 139.7380223594259 46.397 35.67006356304376 139.7380223594259 39.872 35.670069127883934 139.73804939394836 39.872</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b8ac968e-f954-4eb4-84e0-b32fe1bc5fc7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b8ac968e-f954-4eb4-84e0-b32fe1bc5fc7_0">
											<gml:posList>35.670071632109035 139.73803599191152 46.397 35.670073202778426 139.73803887310729 46.397 35.670073202778426 139.73803887310729 46.932 35.670071632109035 139.73803599191152 46.932 35.670071632109035 139.73803599191152 46.397</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b5cca862-0dd7-4d2a-a85a-95a4686b4724">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b5cca862-0dd7-4d2a-a85a-95a4686b4724_0">
											<gml:posList>35.670083451380926 139.73803886092654 46.397 35.67008501748698 139.7380359760021 46.397 35.67008501748698 139.7380359760021 46.932 35.670083451380926 139.73803886092654 46.932 35.670083451380926 139.73803886092654 46.397</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9297c935-76fa-4e86-875b-d86c561d008b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9297c935-76fa-4e86-875b-d86c561d008b_0">
											<gml:posList>35.67008110032917 139.73804079680897 46.397 35.670083451380926 139.73803886092654 46.397 35.670083451380926 139.73803886092654 46.932 35.67008110032917 139.73804079680897 46.932 35.67008110032917 139.73804079680897 46.397</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9a1dfd28-4fd3-4661-ab01-c80a2aa24b71">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9a1dfd28-4fd3-4661-ab01-c80a2aa24b71_0">
											<gml:posList>35.670073202778426 139.73803887310729 46.397 35.67007555688982 139.73804080339738 46.397 35.67007555688982 139.73804080339738 46.932 35.670073202778426 139.73803887310729 46.932 35.670073202778426 139.73803887310729 46.397</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-763b70ae-2947-4d30-9d75-e96647f7c655">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-763b70ae-2947-4d30-9d75-e96647f7c655_0">
											<gml:posList>35.67007555688982 139.73804080339738 46.397 35.6700783336496 139.73804147391644 46.397 35.6700783336496 139.73804147391644 46.932 35.67007555688982 139.73804080339738 46.932 35.67007555688982 139.73804080339738 46.397</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-666c6eb5-ee53-4b0c-a4c6-1f5eeb3fc750">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-666c6eb5-ee53-4b0c-a4c6-1f5eeb3fc750_0">
											<gml:posList>35.6700783336496 139.73804147391644 46.397 35.67008110032917 139.73804079680897 46.397 35.67008110032917 139.73804079680897 46.932 35.6700783336496 139.73804147391644 46.932 35.6700783336496 139.73804147391644 46.397</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8f0ffc16-39c7-4b4d-bc83-54622a3d875f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8f0ffc16-39c7-4b4d-bc83-54622a3d875f_0">
											<gml:posList>35.670069127883934 139.73804939394836 39.872 35.67009233256383 139.73804221946793 39.872 35.67009233256383 139.73804221946793 46.397 35.670069127883934 139.73804939394836 46.397 35.670069127883934 139.73804939394836 39.872</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_05a27ad4-34b0-4569-91f5-9f90a3f04da9_BuildingInstallation_1060">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1678cb01-6abb-4f73-a673-7d8ce4a169d1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67000137440607 139.73809843125582 18.454 35.669996110123215 139.7380753067527 18.454 35.67003443515588 139.7380622045977 18.454 35.67003583755277 139.738068863797 18.454 35.670076208061424 139.7380549528278 18.454 35.6700799708183 139.73807144035968 18.454 35.67000137440607 139.73809843125582 18.454</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-40106bca-e90a-4b85-b3e2-15ce2eab8df6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-40106bca-e90a-4b85-b3e2-15ce2eab8df6_0">
											<gml:posList>35.669996110123215 139.7380753067527 38.187 35.669996110123215 139.7380753067527 18.454 35.67000137440607 139.73809843125582 18.454 35.67000137440607 139.73809843125582 38.187 35.669996110123215 139.7380753067527 38.187</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8950e4b1-1789-45af-8fe0-d3eef9c9389f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8950e4b1-1789-45af-8fe0-d3eef9c9389f_0">
											<gml:posList>35.67003443515588 139.7380622045977 38.187 35.67003443515588 139.7380622045977 18.454 35.669996110123215 139.7380753067527 18.454 35.669996110123215 139.7380753067527 38.187 35.67003443515588 139.7380622045977 38.187</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4081bdef-93dc-426c-b7a5-31bf7b3362ea">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4081bdef-93dc-426c-b7a5-31bf7b3362ea_0">
											<gml:posList>35.67003583755277 139.738068863797 38.187 35.67003583755277 139.738068863797 18.454 35.67003443515588 139.7380622045977 18.454 35.67003443515588 139.7380622045977 38.187 35.67003583755277 139.738068863797 38.187</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9603365f-2f6b-44e2-80b6-2ddef12f069f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9603365f-2f6b-44e2-80b6-2ddef12f069f_0">
											<gml:posList>35.67003583755277 139.738068863797 38.187 35.67003443515588 139.7380622045977 38.187 35.669996110123215 139.7380753067527 38.187 35.67000137440607 139.73809843125582 38.187 35.6700799708183 139.73807144035968 38.187 35.670076208061424 139.7380549528278 38.187 35.67003583755277 139.738068863797 38.187</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2f78090b-3002-4304-b546-73b0a9c034ac">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2f78090b-3002-4304-b546-73b0a9c034ac_0">
											<gml:posList>35.6700799708183 139.73807144035968 18.454 35.6700799708183 139.73807144035968 38.187 35.67000137440607 139.73809843125582 38.187 35.67000137440607 139.73809843125582 18.454 35.6700799708183 139.73807144035968 18.454</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1ee383b4-fd5d-4fa5-b966-081a4f7f02f6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1ee383b4-fd5d-4fa5-b966-081a4f7f02f6_0">
											<gml:posList>35.670076208061424 139.7380549528278 38.187 35.670076208061424 139.7380549528278 18.454 35.67003583755277 139.738068863797 18.454 35.67003583755277 139.738068863797 38.187 35.670076208061424 139.7380549528278 38.187</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1e8eb523-e3c9-4295-aab9-47ec5ee317d6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1e8eb523-e3c9-4295-aab9-47ec5ee317d6_0">
											<gml:posList>35.6700799708183 139.73807144035968 38.187 35.6700799708183 139.73807144035968 18.454 35.670076208061424 139.7380549528278 18.454 35.670076208061424 139.7380549528278 38.187 35.6700799708183 139.73807144035968 38.187</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-1212d25f-53f0-4407-8ab3-2d987458b780">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1212d25f-53f0-4407-8ab3-2d987458b780">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1212d25f-53f0-4407-8ab3-2d987458b780">
											<gml:posList>35.67003443515588 139.7380622045977 18.454 35.669996110123215 139.7380753067527 18.454 35.66997885191777 139.7379994840207 18.454 35.669990367790845 139.7379720757385 18.454 35.670120236546985 139.73794795097268 18.454 35.67014339222318 139.73804965917185 18.454 35.6700799708183 139.73807144035968 18.454 35.670076208061424 139.7380549528278 18.454 35.67003583754403 139.7380688527508 18.454 35.67003443515588 139.7380622045977 18.454</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e590db6d-e8bb-470e-9d9f-a143fbe11650">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e590db6d-e8bb-470e-9d9f-a143fbe11650">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e590db6d-e8bb-470e-9d9f-a143fbe11650">
											<gml:posList>35.669990367790845 139.7379720757385 35.036 35.66999229935185 139.7379753873029 35.036 35.67011809450107 139.73795201853108 35.036 35.670120236546985 139.73794795097268 35.036 35.669990367790845 139.7379720757385 35.036</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-7064cdab-6f57-4717-9027-92385f819f0b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7064cdab-6f57-4717-9027-92385f819f0b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7064cdab-6f57-4717-9027-92385f819f0b">
											<gml:posList>35.67011180716048 139.73798013864615 40.84 35.67010712243673 139.73796042671202 35.036 35.67003595354521 139.73797626326592 35.036 35.67011180716048 139.73798013864615 40.84</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-9d55eb61-76f2-42be-83ae-395aa6f06966">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9d55eb61-76f2-42be-83ae-395aa6f06966">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9d55eb61-76f2-42be-83ae-395aa6f06966">
											<gml:posList>35.67011180716048 139.73798013864615 40.84 35.67003595354521 139.73797626326592 35.036 35.67003872350896 139.73799111712694 38.005 35.67011180716048 139.73798013864615 40.84</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-26e9127c-a0c2-4fed-b4ed-06656540bc95">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-26e9127c-a0c2-4fed-b4ed-06656540bc95">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-26e9127c-a0c2-4fed-b4ed-06656540bc95">
											<gml:posList>35.66997885191777 139.7379994840207 35.036 35.66998200704429 139.73799988897872 35.036 35.66999229935185 139.7379753873029 35.036 35.669990367790845 139.7379720757385 35.036 35.66997885191777 139.7379994840207 35.036</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-38cf6062-a8fb-45a4-ae3a-3ee1eb09d0a5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-38cf6062-a8fb-45a4-ae3a-3ee1eb09d0a5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-38cf6062-a8fb-45a4-ae3a-3ee1eb09d0a5">
											<gml:posList>35.67003872350896 139.73799111712694 38.005 35.67003595354521 139.73797626326592 35.036 35.66999241873898 139.73798955944292 35.036 35.669995188701094 139.73800441329632 38.005 35.67003872350896 139.73799111712694 38.005</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-41e5d809-c9a8-47e5-9401-785af6709943">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-41e5d809-c9a8-47e5-9401-785af6709943">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-41e5d809-c9a8-47e5-9401-785af6709943">
											<gml:posList>35.67011180716048 139.73798013864615 40.84 35.67003872350896 139.73799111712694 38.005 35.67004136674531 139.73800529732065 40.84 35.67011180716048 139.73798013864615 40.84</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d9412d41-0be9-470f-9e13-73894e4d9b0c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d9412d41-0be9-470f-9e13-73894e4d9b0c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d9412d41-0be9-470f-9e13-73894e4d9b0c">
											<gml:posList>35.67004136674531 139.73800529732065 40.84 35.67004462249186 139.7380075579234 40.84 35.67010994455636 139.73798422796338 40.84 35.67011180716048 139.73798013864615 40.84 35.67004136674531 139.73800529732065 40.84</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c64ee64e-c7d6-4bfb-85dd-6ea7010e966e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c64ee64e-c7d6-4bfb-85dd-6ea7010e966e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c64ee64e-c7d6-4bfb-85dd-6ea7010e966e">
											<gml:posList>35.670120236546985 139.73794795097268 35.036 35.67011809450107 139.73795201853108 35.036 35.6701397486951 139.7380471560085 35.036 35.67014339222318 139.73804965917185 35.036 35.670120236546985 139.73794795097268 35.036</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b2aab428-d935-4c5d-aeb9-12f0f5a1d8a8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b2aab428-d935-4c5d-aeb9-12f0f5a1d8a8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b2aab428-d935-4c5d-aeb9-12f0f5a1d8a8">
											<gml:posList>35.67003872350896 139.73799111712694 38.005 35.669995188701094 139.73800441329632 38.005 35.66999914804273 139.73800733583363 38.005 35.67003951077269 139.73799499341126 38.005 35.67003872350896 139.73799111712694 38.005</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f6a6b658-19c9-4eb8-af7c-2ec0dc1cada5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f6a6b658-19c9-4eb8-af7c-2ec0dc1cada5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f6a6b658-19c9-4eb8-af7c-2ec0dc1cada5">
											<gml:posList>35.67010712243673 139.73796042671202 34.511 35.670128033958974 139.7380510913403 34.511 35.6701397486951 139.7380471560085 34.511 35.67011809450107 139.73795201853108 34.511 35.66999229935185 139.7379753873029 34.511 35.66998200704429 139.73799988897872 34.511 35.66999222830255 139.73804504476084 34.511 35.67000277170938 139.73804168522975 34.511 35.66999241873898 139.73798955944292 34.511 35.67003595354521 139.73797626326592 34.511 35.67010712243673 139.73796042671202 34.511</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-53108798-edee-45c3-bd9d-51b87fd5194c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-53108798-edee-45c3-bd9d-51b87fd5194c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-53108798-edee-45c3-bd9d-51b87fd5194c">
											<gml:posList>35.67011180716048 139.73798013864615 40.84 35.67010994455636 139.73798422796338 40.84 35.670125538154295 139.73805235357582 40.84 35.67012885702219 139.7380546472465 40.84 35.67011180716048 139.73798013864615 40.84</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-4a842bed-c65a-4428-98b4-31bf93b2a546">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4a842bed-c65a-4428-98b4-31bf93b2a546">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4a842bed-c65a-4428-98b4-31bf93b2a546">
											<gml:posList>35.67004625223791 139.73802813508092 40.84 35.67004953510388 139.73803049506844 40.84 35.67004462249186 139.7380075579234 40.84 35.67004136674531 139.73800529732065 40.84 35.67004625223791 139.73802813508092 40.84</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-3b1f0f43-d65b-4b0b-bfa1-1870c57b8107">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3b1f0f43-d65b-4b0b-bfa1-1870c57b8107">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3b1f0f43-d65b-4b0b-bfa1-1870c57b8107">
											<gml:posList>35.66998942573411 139.73804593178798 35.036 35.66999222830255 139.73804504476084 35.036 35.66998200704429 139.73799988897872 35.036 35.66997885191777 139.7379994840207 35.036 35.66998942573411 139.73804593178798 35.036</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c54d7c5f-c3c2-448f-b78d-ea03851a8f2c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c54d7c5f-c3c2-448f-b78d-ea03851a8f2c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c54d7c5f-c3c2-448f-b78d-ea03851a8f2c">
											<gml:posList>35.67000277170938 139.73804168522975 38.005 35.670006722001425 139.73804456359508 38.004 35.66999914804273 139.73800733583363 38.005 35.669995188701094 139.73800441329632 38.005 35.67000277170938 139.73804168522975 38.005</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-65ed0ec7-af57-4c94-8501-68999b3b0136">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-65ed0ec7-af57-4c94-8501-68999b3b0136">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-65ed0ec7-af57-4c94-8501-68999b3b0136">
											<gml:posList>35.670125538154295 139.73805235357582 39.872 35.67010994455636 139.73798422796338 39.872 35.67004462249186 139.7380075579234 39.872 35.67004953510388 139.73803049506844 39.872 35.670031692409275 139.73803617193698 39.872 35.670037745219666 139.73806476338572 39.872 35.67007806167172 139.73805088561707 39.872 35.67008182442917 139.73806737314908 39.872 35.670125538154295 139.73805235357582 39.872</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a915b36b-f45b-4567-920f-f4496d9fc3d4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a915b36b-f45b-4567-920f-f4496d9fc3d4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a915b36b-f45b-4567-920f-f4496d9fc3d4">
											<gml:posList>35.67004625223791 139.73802813508092 40.84 35.67002841854839 139.73803380089285 40.84 35.670031692409275 139.73803617193698 40.84 35.67004953510388 139.73803049506844 40.84 35.67004625223791 139.73802813508092 40.84</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-7502364f-cffc-4c0e-b6b5-25ec1816d0a8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7502364f-cffc-4c0e-b6b5-25ec1816d0a8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7502364f-cffc-4c0e-b6b5-25ec1816d0a8">
											<gml:posList>35.67003951077269 139.73799499341126 37.587 35.66999914804273 139.73800733583363 37.587 35.670006722001425 139.73804456359508 37.586 35.66999345712333 139.73804877691805 37.586 35.66999836867886 139.73807038850742 37.586 35.67003362992804 139.73805840565777 37.587 35.67002841854839 139.73803380089285 37.587 35.67004625223791 139.73802813508092 37.587 35.67003951077269 139.73799499341126 37.587</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-7396d45d-349d-4e27-bb2d-ca3fc29e4e11">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7396d45d-349d-4e27-bb2d-ca3fc29e4e11">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7396d45d-349d-4e27-bb2d-ca3fc29e4e11">
											<gml:posList>35.67000277170938 139.73804168522975 38.005 35.66998942573411 139.73804593178798 38.004 35.66999345712333 139.73804877691805 38.004 35.670006722001425 139.73804456359508 38.004 35.67000277170938 139.73804168522975 38.005</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-5f18377a-9339-4e43-930b-7495c877511a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5f18377a-9339-4e43-930b-7495c877511a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5f18377a-9339-4e43-930b-7495c877511a">
											<gml:posList>35.67012885702219 139.7380546472465 35.036 35.67014339222318 139.73804965917185 35.036 35.6701397486951 139.7380471560085 35.036 35.670128033958974 139.7380510913403 35.036 35.67012885702219 139.7380546472465 35.036</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-5eba745a-d6f1-48d2-ab29-3680f453c1b5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5eba745a-d6f1-48d2-ab29-3680f453c1b5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5eba745a-d6f1-48d2-ab29-3680f453c1b5">
											<gml:posList>35.67003583754403 139.7380688527508 40.84 35.670037745219666 139.73806476338572 40.84 35.670031692409275 139.73803617193698 40.84 35.67002841854839 139.73803380089285 40.84 35.67003583754403 139.7380688527508 40.84</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-6d930b64-7e4b-4d70-bbaf-645575802273">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6d930b64-7e4b-4d70-bbaf-645575802273">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6d930b64-7e4b-4d70-bbaf-645575802273">
											<gml:posList>35.670076208061424 139.7380549528278 40.84 35.67007806167172 139.73805088561707 40.84 35.670037745219666 139.73806476338572 40.84 35.67003583754403 139.7380688527508 40.84 35.670076208061424 139.7380549528278 40.84</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f09c3ef2-dc7e-4274-a7c0-b7cde1871cdc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f09c3ef2-dc7e-4274-a7c0-b7cde1871cdc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f09c3ef2-dc7e-4274-a7c0-b7cde1871cdc">
											<gml:posList>35.669996110123215 139.7380753067527 38.004 35.66999836867886 139.73807038850742 38.004 35.66999345712333 139.73804877691805 38.004 35.66998942573411 139.73804593178798 38.004 35.669996110123215 139.7380753067527 38.004</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-69f11b29-8836-478f-9f45-ac32c38e232a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-69f11b29-8836-478f-9f45-ac32c38e232a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-69f11b29-8836-478f-9f45-ac32c38e232a">
											<gml:posList>35.670076208061424 139.7380549528278 40.84 35.6700799708183 139.73807144035968 40.84 35.67008182442917 139.73806737314908 40.84 35.67007806167172 139.73805088561707 40.84 35.670076208061424 139.7380549528278 40.84</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f18aae08-0710-46ec-9271-66bbe0a87b00">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f18aae08-0710-46ec-9271-66bbe0a87b00">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f18aae08-0710-46ec-9271-66bbe0a87b00">
											<gml:posList>35.67012885702219 139.7380546472465 40.84 35.670125538154295 139.73805235357582 40.84 35.67008182442917 139.73806737314908 40.84 35.6700799708183 139.73807144035968 40.84 35.67012885702219 139.7380546472465 40.84</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ef2dc4a6-09a9-4266-9780-a23eadd08bcb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ef2dc4a6-09a9-4266-9780-a23eadd08bcb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ef2dc4a6-09a9-4266-9780-a23eadd08bcb">
											<gml:posList>35.67003442614216 139.73806220460838 38.005 35.67003362992804 139.73805840565777 38.005 35.66999836867886 139.73807038850742 38.004 35.669996110123215 139.7380753067527 38.004 35.67003442614216 139.73806220460838 38.005</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9db4bbeb-456f-48c1-90b2-60ad137153e2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9db4bbeb-456f-48c1-90b2-60ad137153e2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9db4bbeb-456f-48c1-90b2-60ad137153e2">
											<gml:posList>35.67010712243673 139.73796042671202 35.036 35.67010712243673 139.73796042671202 34.511 35.67003595354521 139.73797626326592 34.511 35.67003595354521 139.73797626326592 35.036 35.67010712243673 139.73796042671202 35.036</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-379c1281-5a2b-4d6b-8cae-e14557a68adb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-379c1281-5a2b-4d6b-8cae-e14557a68adb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-379c1281-5a2b-4d6b-8cae-e14557a68adb">
											<gml:posList>35.669990367790845 139.7379720757385 18.454 35.66997885191777 139.7379994840207 18.454 35.66997885191777 139.7379994840207 35.036 35.669990367790845 139.7379720757385 35.036 35.669990367790845 139.7379720757385 18.454</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b73eca81-8d2e-4d60-b33c-5b20af417ac6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b73eca81-8d2e-4d60-b33c-5b20af417ac6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b73eca81-8d2e-4d60-b33c-5b20af417ac6">
											<gml:posList>35.66999222830255 139.73804504476084 35.036 35.66999222830255 139.73804504476084 34.511 35.66998200704429 139.73799988897872 34.511 35.66998200704429 139.73799988897872 35.036 35.66999222830255 139.73804504476084 35.036</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-006abce6-f72b-4347-9831-d6847cf8d89d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-006abce6-f72b-4347-9831-d6847cf8d89d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-006abce6-f72b-4347-9831-d6847cf8d89d">
											<gml:posList>35.66998200704429 139.73799988897872 35.036 35.66998200704429 139.73799988897872 34.511 35.66999229935185 139.7379753873029 34.511 35.66999229935185 139.7379753873029 35.036 35.66998200704429 139.73799988897872 35.036</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8a2e084b-ee13-4742-ba89-8c657a53aad8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8a2e084b-ee13-4742-ba89-8c657a53aad8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8a2e084b-ee13-4742-ba89-8c657a53aad8">
											<gml:posList>35.66997885191777 139.7379994840207 18.454 35.669996110123215 139.7380753067527 18.454 35.669996110123215 139.7380753067527 35.036 35.66998942573411 139.73804593178798 35.036 35.66997885191777 139.7379994840207 35.036 35.66997885191777 139.7379994840207 18.454</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-69dcf9ea-b7d4-4cff-979b-3c2df220a929">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-69dcf9ea-b7d4-4cff-979b-3c2df220a929">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-69dcf9ea-b7d4-4cff-979b-3c2df220a929">
											<gml:posList>35.66998942573411 139.73804593178798 38.004 35.66998942573411 139.73804593178798 35.036 35.669996110123215 139.7380753067527 35.036 35.669996110123215 139.7380753067527 38.004 35.66998942573411 139.73804593178798 38.004</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9ef6669c-593e-4632-95db-eb7750cf5f2f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9ef6669c-593e-4632-95db-eb7750cf5f2f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9ef6669c-593e-4632-95db-eb7750cf5f2f">
											<gml:posList>35.66999836867886 139.73807038850742 38.004 35.66999836867886 139.73807038850742 37.586 35.66999345712333 139.73804877691805 37.586 35.66999345712333 139.73804877691805 38.004 35.66999836867886 139.73807038850742 38.004</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d2721564-b298-427c-87cd-376144f8ddbd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d2721564-b298-427c-87cd-376144f8ddbd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d2721564-b298-427c-87cd-376144f8ddbd">
											<gml:posList>35.66999222830255 139.73804504476084 35.036 35.66998942573411 139.73804593178798 35.036 35.66998942573411 139.73804593178798 38.004 35.67000277170938 139.73804168522975 38.005 35.67000277170938 139.73804168522975 34.511 35.66999222830255 139.73804504476084 34.511 35.66999222830255 139.73804504476084 35.036</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2231e335-f188-4a40-b012-44a8252e7a50">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2231e335-f188-4a40-b012-44a8252e7a50">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2231e335-f188-4a40-b012-44a8252e7a50">
											<gml:posList>35.66999241873898 139.73798955944292 35.036 35.66999241873898 139.73798955944292 34.511 35.67000277170938 139.73804168522975 34.511 35.67000277170938 139.73804168522975 38.005 35.669995188701094 139.73800441329632 38.005 35.66999241873898 139.73798955944292 35.036</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e0dd4505-88f8-4867-8e7d-87a78dc0090c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e0dd4505-88f8-4867-8e7d-87a78dc0090c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e0dd4505-88f8-4867-8e7d-87a78dc0090c">
											<gml:posList>35.66999345712333 139.73804877691805 38.004 35.66999345712333 139.73804877691805 37.586 35.670006722001425 139.73804456359508 37.586 35.670006722001425 139.73804456359508 38.004 35.66999345712333 139.73804877691805 38.004</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9d3ff43d-982c-47f4-bd33-e103461615e3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9d3ff43d-982c-47f4-bd33-e103461615e3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9d3ff43d-982c-47f4-bd33-e103461615e3">
											<gml:posList>35.670006722001425 139.73804456359508 38.004 35.670006722001425 139.73804456359508 37.586 35.66999914804273 139.73800733583363 37.587 35.66999914804273 139.73800733583363 38.005 35.670006722001425 139.73804456359508 38.004</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0089466b-7169-4200-8e99-02067c7ba79f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0089466b-7169-4200-8e99-02067c7ba79f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0089466b-7169-4200-8e99-02067c7ba79f">
											<gml:posList>35.67003595354521 139.73797626326592 35.036 35.67003595354521 139.73797626326592 34.511 35.66999241873898 139.73798955944292 34.511 35.66999241873898 139.73798955944292 35.036 35.67003595354521 139.73797626326592 35.036</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f33ffb9f-eae1-4465-b6b1-4d98e64e9553">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f33ffb9f-eae1-4465-b6b1-4d98e64e9553">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f33ffb9f-eae1-4465-b6b1-4d98e64e9553">
											<gml:posList>35.669996110123215 139.7380753067527 18.454 35.67003443515588 139.7380622045977 18.454 35.67003443515588 139.7380622045977 35.036 35.669996110123215 139.7380753067527 35.036 35.669996110123215 139.7380753067527 18.454</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e8f3d084-e46b-4e09-91e6-03eec50b1c93">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e8f3d084-e46b-4e09-91e6-03eec50b1c93">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e8f3d084-e46b-4e09-91e6-03eec50b1c93">
											<gml:posList>35.669996110123215 139.7380753067527 38.004 35.669996110123215 139.7380753067527 35.036 35.67003443515588 139.7380622045977 35.036 35.67003442614216 139.73806220460838 38.005 35.669996110123215 139.7380753067527 38.004</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c6e8e7be-e6a0-4ad3-89b8-c5d361b87d8c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c6e8e7be-e6a0-4ad3-89b8-c5d361b87d8c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c6e8e7be-e6a0-4ad3-89b8-c5d361b87d8c">
											<gml:posList>35.67003362992804 139.73805840565777 38.005 35.67003362992804 139.73805840565777 37.587 35.66999836867886 139.73807038850742 37.586 35.66999836867886 139.73807038850742 38.004 35.67003362992804 139.73805840565777 38.005</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-41e94953-927e-43a5-97ae-76e46e7aff49">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-41e94953-927e-43a5-97ae-76e46e7aff49">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-41e94953-927e-43a5-97ae-76e46e7aff49">
											<gml:posList>35.66999914804273 139.73800733583363 38.005 35.66999914804273 139.73800733583363 37.587 35.67003951077269 139.73799499341126 37.587 35.67003951077269 139.73799499341126 38.005 35.66999914804273 139.73800733583363 38.005</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2aaf2545-5f63-4312-92d4-8db963df4c36">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2aaf2545-5f63-4312-92d4-8db963df4c36">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2aaf2545-5f63-4312-92d4-8db963df4c36">
											<gml:posList>35.67002841854839 139.73803380089285 37.587 35.67003362992804 139.73805840565777 37.587 35.67003362992804 139.73805840565777 38.005 35.67003442614216 139.73806220460838 38.005 35.67003583754403 139.7380688527508 37.393 35.67003583754403 139.7380688527508 40.84 35.67002841854839 139.73803380089285 40.84 35.67002841854839 139.73803380089285 37.587</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c7e50d1c-e544-4c41-92ed-5a782ceacef9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c7e50d1c-e544-4c41-92ed-5a782ceacef9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c7e50d1c-e544-4c41-92ed-5a782ceacef9">
											<gml:posList>35.670037745219666 139.73806476338572 40.84 35.670037745219666 139.73806476338572 39.872 35.670031692409275 139.73803617193698 39.872 35.670031692409275 139.73803617193698 40.84 35.670037745219666 139.73806476338572 40.84</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-09e4c5c4-7ad1-46b0-83c9-496f911ebfe2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-09e4c5c4-7ad1-46b0-83c9-496f911ebfe2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-09e4c5c4-7ad1-46b0-83c9-496f911ebfe2">
											<gml:posList>35.67003443515588 139.7380622045977 35.036 35.67003583754403 139.7380688527508 35.036 35.67003583754403 139.7380688527508 37.393 35.67003442614216 139.73806220460838 38.005 35.67003443515588 139.7380622045977 35.036</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-57a9bd8c-4f1f-4a49-99d5-3dc3eb42421a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-57a9bd8c-4f1f-4a49-99d5-3dc3eb42421a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-57a9bd8c-4f1f-4a49-99d5-3dc3eb42421a">
											<gml:posList>35.67003443515588 139.7380622045977 18.454 35.67003583754403 139.7380688527508 18.454 35.67003583754403 139.7380688527508 35.036 35.67003443515588 139.7380622045977 35.036 35.67003443515588 139.7380622045977 18.454</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1841e91d-85d3-42b1-b965-a1eae3342a6f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1841e91d-85d3-42b1-b965-a1eae3342a6f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1841e91d-85d3-42b1-b965-a1eae3342a6f">
											<gml:posList>35.67002841854839 139.73803380089285 40.84 35.67004625223791 139.73802813508092 40.84 35.67004625223791 139.73802813508092 37.587 35.67002841854839 139.73803380089285 37.587 35.67002841854839 139.73803380089285 40.84</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5c11af96-23ff-4bca-85fd-7c2ad61fd1c7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5c11af96-23ff-4bca-85fd-7c2ad61fd1c7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5c11af96-23ff-4bca-85fd-7c2ad61fd1c7">
											<gml:posList>35.670031692409275 139.73803617193698 40.84 35.670031692409275 139.73803617193698 39.872 35.67004953510388 139.73803049506844 39.872 35.67004953510388 139.73803049506844 40.84 35.670031692409275 139.73803617193698 40.84</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-35c938e1-ee79-47cc-acd0-6ca6e7856156">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-35c938e1-ee79-47cc-acd0-6ca6e7856156">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-35c938e1-ee79-47cc-acd0-6ca6e7856156">
											<gml:posList>35.67004136674531 139.73800529732065 40.84 35.67003872350896 139.73799111712694 38.005 35.67003951077269 139.73799499341126 38.005 35.67003951077269 139.73799499341126 37.587 35.67004625223791 139.73802813508092 37.587 35.67004625223791 139.73802813508092 40.84 35.67004136674531 139.73800529732065 40.84</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d9499b1a-049f-4d96-88cf-7c9eaefcfb97">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d9499b1a-049f-4d96-88cf-7c9eaefcfb97">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d9499b1a-049f-4d96-88cf-7c9eaefcfb97">
											<gml:posList>35.67004953510388 139.73803049506844 40.84 35.67004953510388 139.73803049506844 39.872 35.67004462249186 139.7380075579234 39.872 35.67004462249186 139.7380075579234 40.84 35.67004953510388 139.73803049506844 40.84</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-fd03ba93-ecf9-4de7-a7e7-f4a539fceb7a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fd03ba93-ecf9-4de7-a7e7-f4a539fceb7a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fd03ba93-ecf9-4de7-a7e7-f4a539fceb7a">
											<gml:posList>35.66999229935185 139.7379753873029 35.036 35.66999229935185 139.7379753873029 34.511 35.67011809450107 139.73795201853108 34.511 35.67011809450107 139.73795201853108 35.036 35.66999229935185 139.7379753873029 35.036</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f4efaca1-3ada-4644-9c7b-a7feef39b905">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f4efaca1-3ada-4644-9c7b-a7feef39b905">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f4efaca1-3ada-4644-9c7b-a7feef39b905">
											<gml:posList>35.670120236546985 139.73794795097268 18.454 35.669990367790845 139.7379720757385 18.454 35.669990367790845 139.7379720757385 35.036 35.670120236546985 139.73794795097268 35.036 35.670120236546985 139.73794795097268 18.454</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ce196018-885f-4bf9-80fd-6f25e89fe1ac">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ce196018-885f-4bf9-80fd-6f25e89fe1ac">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ce196018-885f-4bf9-80fd-6f25e89fe1ac">
											<gml:posList>35.670076208061424 139.7380549528278 18.454 35.670076208061424 139.7380549528278 40.84 35.67003583754403 139.7380688527508 40.84 35.67003583754403 139.7380688527508 37.393 35.67003583754403 139.7380688527508 35.036 35.67003583754403 139.7380688527508 18.454 35.670076208061424 139.7380549528278 18.454</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0b70e0a6-3d2a-4db7-acf6-d4fddbb9aaa0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0b70e0a6-3d2a-4db7-acf6-d4fddbb9aaa0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0b70e0a6-3d2a-4db7-acf6-d4fddbb9aaa0">
											<gml:posList>35.67007806167172 139.73805088561707 40.84 35.67007806167172 139.73805088561707 39.872 35.670037745219666 139.73806476338572 39.872 35.670037745219666 139.73806476338572 40.84 35.67007806167172 139.73805088561707 40.84</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-258ae92d-9a2b-455f-980b-3c3decd0c1ce">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-258ae92d-9a2b-455f-980b-3c3decd0c1ce">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-258ae92d-9a2b-455f-980b-3c3decd0c1ce">
											<gml:posList>35.67004462249186 139.7380075579234 40.84 35.67004462249186 139.7380075579234 39.872 35.67010994455636 139.73798422796338 39.872 35.67010994455636 139.73798422796338 40.84 35.67004462249186 139.7380075579234 40.84</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-631003f8-12a7-4dc8-b311-970e15fb8687">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-631003f8-12a7-4dc8-b311-970e15fb8687">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-631003f8-12a7-4dc8-b311-970e15fb8687">
											<gml:posList>35.670076208061424 139.7380549528278 18.454 35.6700799708183 139.73807144035968 18.454 35.6700799708183 139.73807144035968 40.84 35.670076208061424 139.7380549528278 40.84 35.670076208061424 139.7380549528278 18.454</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-36b33bcc-d58f-45db-bcbf-bb6c4ea9fd87">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-36b33bcc-d58f-45db-bcbf-bb6c4ea9fd87">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-36b33bcc-d58f-45db-bcbf-bb6c4ea9fd87">
											<gml:posList>35.67008182442917 139.73806737314908 40.84 35.67008182442917 139.73806737314908 39.872 35.67007806167172 139.73805088561707 39.872 35.67007806167172 139.73805088561707 40.84 35.67008182442917 139.73806737314908 40.84</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f6459bc4-e327-4f2b-ad1a-dfc2b1d16b49">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f6459bc4-e327-4f2b-ad1a-dfc2b1d16b49">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f6459bc4-e327-4f2b-ad1a-dfc2b1d16b49">
											<gml:posList>35.670125538154295 139.73805235357582 40.84 35.670125538154295 139.73805235357582 39.872 35.67008182442917 139.73806737314908 39.872 35.67008182442917 139.73806737314908 40.84 35.670125538154295 139.73805235357582 40.84</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8c631d28-f58e-4c35-9018-673b6098a06f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8c631d28-f58e-4c35-9018-673b6098a06f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8c631d28-f58e-4c35-9018-673b6098a06f">
											<gml:posList>35.67012885702219 139.7380546472465 35.036 35.67012885702219 139.7380546472465 40.84 35.6700799708183 139.73807144035968 40.84 35.6700799708183 139.73807144035968 18.454 35.67014339222318 139.73804965917185 18.454 35.67014339222318 139.73804965917185 35.036 35.67012885702219 139.7380546472465 35.036</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7992ff53-531c-4c01-9e1d-b96bcfe7f74a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7992ff53-531c-4c01-9e1d-b96bcfe7f74a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7992ff53-531c-4c01-9e1d-b96bcfe7f74a">
											<gml:posList>35.67010994455636 139.73798422796338 40.84 35.67010994455636 139.73798422796338 39.872 35.670125538154295 139.73805235357582 39.872 35.670125538154295 139.73805235357582 40.84 35.67010994455636 139.73798422796338 40.84</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-13b03893-50c3-4c7b-935f-a90456897292">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-13b03893-50c3-4c7b-935f-a90456897292">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-13b03893-50c3-4c7b-935f-a90456897292">
											<gml:posList>35.67011180716048 139.73798013864615 40.84 35.67012885702219 139.7380546472465 40.84 35.67012885702219 139.7380546472465 35.036 35.670128033958974 139.7380510913403 35.036 35.670128033958974 139.7380510913403 34.511 35.67010712243673 139.73796042671202 34.511 35.67010712243673 139.73796042671202 35.036 35.67011180716048 139.73798013864615 40.84</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c5fbf5ba-dff9-46b1-80b9-89f3476d4e7e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c5fbf5ba-dff9-46b1-80b9-89f3476d4e7e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c5fbf5ba-dff9-46b1-80b9-89f3476d4e7e">
											<gml:posList>35.67011809450107 139.73795201853108 35.036 35.67011809450107 139.73795201853108 34.511 35.6701397486951 139.7380471560085 34.511 35.6701397486951 139.7380471560085 35.036 35.67011809450107 139.73795201853108 35.036</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-10d19114-a03b-4ed2-8a7f-c59cad84fe3c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-10d19114-a03b-4ed2-8a7f-c59cad84fe3c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-10d19114-a03b-4ed2-8a7f-c59cad84fe3c">
											<gml:posList>35.67014339222318 139.73804965917185 18.454 35.670120236546985 139.73794795097268 18.454 35.670120236546985 139.73794795097268 35.036 35.67014339222318 139.73804965917185 35.036 35.67014339222318 139.73804965917185 18.454</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c13058bc-11fb-463b-8112-ae78d0e9ef4f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c13058bc-11fb-463b-8112-ae78d0e9ef4f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c13058bc-11fb-463b-8112-ae78d0e9ef4f">
											<gml:posList>35.6701397486951 139.7380471560085 35.036 35.6701397486951 139.7380471560085 34.511 35.670128033958974 139.7380510913403 34.511 35.670128033958974 139.7380510913403 35.036 35.6701397486951 139.7380471560085 35.036</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-3320</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">170.76685</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">211</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1320</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>4</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>