<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_05db4b41-921e-49eb-81e4-ef3aeea7b4a3">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="再開発等促進区を定める地区計画">
				<gen:value>赤坂一丁目地区</gen:value>
			</gen:stringAttribute>
			<bldg:measuredHeight uom="m">12.2</bldg:measuredHeight>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.670003792045144 139.74409039953866 0 35.66999097986713 139.74408545405268 0 35.669982998632946 139.74411643649574 0 35.66999582883716 139.74412138196612 0 35.670003792045144 139.74409039953866 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670003792045144 139.74409039953866 9.09 35.66999582883716 139.74412138196612 9.09 35.669982998632946 139.74411643649574 9.09 35.66999097986713 139.74408545405268 9.09 35.670003792045144 139.74409039953866 9.09</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670003792045144 139.74409039953866 9.09 35.66999097986713 139.74408545405268 9.09 35.66999097986713 139.74408545405268 21.29 35.670003792045144 139.74409039953866 21.29 35.670003792045144 139.74409039953866 9.09</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66999097986713 139.74408545405268 9.09 35.669982998632946 139.74411643649574 9.09 35.669982998632946 139.74411643649574 21.29 35.66999097986713 139.74408545405268 21.29 35.66999097986713 139.74408545405268 9.09</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669982998632946 139.74411643649574 9.09 35.66999582883716 139.74412138196612 9.09 35.66999582883716 139.74412138196612 21.29 35.669982998632946 139.74411643649574 21.29 35.669982998632946 139.74411643649574 9.09</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66999582883716 139.74412138196612 9.09 35.670003792045144 139.74409039953866 9.09 35.670003792045144 139.74409039953866 21.29 35.66999582883716 139.74412138196612 21.29 35.66999582883716 139.74412138196612 9.09</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670003792045144 139.74409039953866 21.29 35.66999097986713 139.74408545405268 21.29 35.669982998632946 139.74411643649574 21.29 35.66999582883716 139.74412138196612 21.29 35.670003792045144 139.74409039953866 21.29</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-1e7d2dc7-1de1-43af-a8cc-8ed0d7fcc877"/>
							<gml:surfaceMember xlink:href="#poly-07ba9c46-d84e-46df-803b-6668b198a14d"/>
							<gml:surfaceMember xlink:href="#poly-829b45a5-4138-4054-b4f2-90bb23702a95"/>
							<gml:surfaceMember xlink:href="#poly-e37e1273-bc6f-4b4a-bd0c-f93186e26097"/>
							<gml:surfaceMember xlink:href="#poly-6cd6a062-da23-439a-a655-9ef1c2fc978b"/>
							<gml:surfaceMember xlink:href="#poly-a0f25255-1ec8-4a82-a2db-6881e1b125e7"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-1e7d2dc7-1de1-43af-a8cc-8ed0d7fcc877">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1e7d2dc7-1de1-43af-a8cc-8ed0d7fcc877">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1e7d2dc7-1de1-43af-a8cc-8ed0d7fcc877">
											<gml:posList>35.67000379204514 139.74409039953866 9.09 35.66999582883714 139.74412138196612 9.09 35.669982998632925 139.74411643649574 9.09 35.66999097986713 139.74408545405268 9.09 35.67000379204514 139.74409039953866 9.09</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-07ba9c46-d84e-46df-803b-6668b198a14d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-07ba9c46-d84e-46df-803b-6668b198a14d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-07ba9c46-d84e-46df-803b-6668b198a14d">
											<gml:posList>35.66999582883714 139.74412138196612 13.314 35.67000379204514 139.74409039953866 13.314 35.66999097986713 139.74408545405268 13.314 35.669982998632925 139.74411643649574 13.314 35.66999582883714 139.74412138196612 13.314</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-829b45a5-4138-4054-b4f2-90bb23702a95">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-829b45a5-4138-4054-b4f2-90bb23702a95">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-829b45a5-4138-4054-b4f2-90bb23702a95">
											<gml:posList>35.66999097986713 139.74408545405268 9.09 35.669982998632925 139.74411643649574 9.09 35.669982998632925 139.74411643649574 13.314 35.66999097986713 139.74408545405268 13.314 35.66999097986713 139.74408545405268 9.09</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e37e1273-bc6f-4b4a-bd0c-f93186e26097">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e37e1273-bc6f-4b4a-bd0c-f93186e26097">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e37e1273-bc6f-4b4a-bd0c-f93186e26097">
											<gml:posList>35.67000379204514 139.74409039953866 9.09 35.66999097986713 139.74408545405268 9.09 35.66999097986713 139.74408545405268 13.314 35.67000379204514 139.74409039953866 13.314 35.67000379204514 139.74409039953866 9.09</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6cd6a062-da23-439a-a655-9ef1c2fc978b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6cd6a062-da23-439a-a655-9ef1c2fc978b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6cd6a062-da23-439a-a655-9ef1c2fc978b">
											<gml:posList>35.66999582883714 139.74412138196612 9.09 35.67000379204514 139.74409039953866 9.09 35.67000379204514 139.74409039953866 13.314 35.66999582883714 139.74412138196612 13.314 35.66999582883714 139.74412138196612 9.09</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a0f25255-1ec8-4a82-a2db-6881e1b125e7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a0f25255-1ec8-4a82-a2db-6881e1b125e7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a0f25255-1ec8-4a82-a2db-6881e1b125e7">
											<gml:posList>35.669982998632925 139.74411643649574 9.09 35.66999582883714 139.74412138196612 9.09 35.66999582883714 139.74412138196612 13.314 35.669982998632925 139.74411643649574 13.314 35.669982998632925 139.74411643649574 9.09</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-5980</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>6</uro:specifiedFloorAreaRate>
					<uro:surveyYear>0001</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>