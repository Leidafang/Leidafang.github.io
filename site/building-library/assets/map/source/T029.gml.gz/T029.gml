<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_07633ee6-e7f9-439f-93f6-b9b2a901e669">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">412</bldg:usage>
			<bldg:measuredHeight uom="m">34.4</bldg:measuredHeight>
			<bldg:storeysAboveGround>12</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.66851767017201 139.7387288215215 0 35.668593625592486 139.73880494939547 0 35.66862018485775 139.73876515242398 0 35.66863973297869 139.7387847139613 0 35.66864275780866 139.73877989432987 0 35.66866353702197 139.73874872004225 0 35.668670455997535 139.7387556487834 0 35.66867992728673 139.7387414434696 0 35.66866125412377 139.73872268726026 0 35.66875236540908 139.73858571938058 0 35.668669914229085 139.73850230887032 0 35.66851767017201 139.7387288215215 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66851767017201 139.7387288215215 14.329 35.668669914229085 139.73850230887032 14.329 35.66875236540908 139.73858571938058 14.329 35.66866125412377 139.73872268726026 14.329 35.66867992728673 139.7387414434696 14.329 35.668670455997535 139.7387556487834 14.329 35.66866353702197 139.73874872004225 14.329 35.66864275780866 139.73877989432987 14.329 35.66863973297869 139.7387847139613 14.329 35.66862018485775 139.73876515242398 14.329 35.668593625592486 139.73880494939547 14.329 35.66851767017201 139.7387288215215 14.329</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66851767017201 139.7387288215215 14.329 35.668593625592486 139.73880494939547 14.329 35.668593625592486 139.73880494939547 48.77 35.66851767017201 139.7387288215215 48.77 35.66851767017201 139.7387288215215 14.329</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668593625592486 139.73880494939547 14.329 35.66862018485775 139.73876515242398 14.329 35.66862018485775 139.73876515242398 48.77 35.668593625592486 139.73880494939547 48.77 35.668593625592486 139.73880494939547 14.329</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66862018485775 139.73876515242398 14.329 35.66863973297869 139.7387847139613 14.329 35.66863973297869 139.7387847139613 48.77 35.66862018485775 139.73876515242398 48.77 35.66862018485775 139.73876515242398 14.329</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66863973297869 139.7387847139613 14.329 35.66864275780866 139.73877989432987 14.329 35.66864275780866 139.73877989432987 48.77 35.66863973297869 139.7387847139613 48.77 35.66863973297869 139.7387847139613 14.329</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66864275780866 139.73877989432987 14.329 35.66866353702197 139.73874872004225 14.329 35.66866353702197 139.73874872004225 48.77 35.66864275780866 139.73877989432987 48.77 35.66864275780866 139.73877989432987 14.329</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66866353702197 139.73874872004225 14.329 35.668670455997535 139.7387556487834 14.329 35.668670455997535 139.7387556487834 48.77 35.66866353702197 139.73874872004225 48.77 35.66866353702197 139.73874872004225 14.329</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668670455997535 139.7387556487834 14.329 35.66867992728673 139.7387414434696 14.329 35.66867992728673 139.7387414434696 48.77 35.668670455997535 139.7387556487834 48.77 35.668670455997535 139.7387556487834 14.329</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66867992728673 139.7387414434696 14.329 35.66866125412377 139.73872268726026 14.329 35.66866125412377 139.73872268726026 48.77 35.66867992728673 139.7387414434696 48.77 35.66867992728673 139.7387414434696 14.329</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66866125412377 139.73872268726026 14.329 35.66875236540908 139.73858571938058 14.329 35.66875236540908 139.73858571938058 48.77 35.66866125412377 139.73872268726026 48.77 35.66866125412377 139.73872268726026 14.329</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66875236540908 139.73858571938058 14.329 35.668669914229085 139.73850230887032 14.329 35.668669914229085 139.73850230887032 48.77 35.66875236540908 139.73858571938058 48.77 35.66875236540908 139.73858571938058 14.329</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668669914229085 139.73850230887032 14.329 35.66851767017201 139.7387288215215 14.329 35.66851767017201 139.7387288215215 48.77 35.668669914229085 139.73850230887032 48.77 35.668669914229085 139.73850230887032 14.329</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66851767017201 139.7387288215215 48.77 35.668593625592486 139.73880494939547 48.77 35.66862018485775 139.73876515242398 48.77 35.66863973297869 139.7387847139613 48.77 35.66864275780866 139.73877989432987 48.77 35.66866353702197 139.73874872004225 48.77 35.668670455997535 139.7387556487834 48.77 35.66867992728673 139.7387414434696 48.77 35.66866125412377 139.73872268726026 48.77 35.66875236540908 139.73858571938058 48.77 35.668669914229085 139.73850230887032 48.77 35.66851767017201 139.7387288215215 48.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-cb018d17-8cbe-455b-9522-73aef8887bd7"/>
							<gml:surfaceMember xlink:href="#poly-cf2ea2b8-9746-4e2a-8641-dd2a1d3ae985"/>
							<gml:surfaceMember xlink:href="#poly-be18a1c9-d969-4408-9351-709bb4304053"/>
							<gml:surfaceMember xlink:href="#poly-ddfbff07-07d3-426a-8a41-97c10ddca2f4"/>
							<gml:surfaceMember xlink:href="#poly-32d0ffc7-87c4-484b-9e5e-3c782eefbac1"/>
							<gml:surfaceMember xlink:href="#poly-a9bac3e5-d655-41dc-b840-6b3fbb0a2153"/>
							<gml:surfaceMember xlink:href="#poly-982381d9-2f3f-4e94-be5f-a0de6c77f6cc"/>
							<gml:surfaceMember xlink:href="#poly-3dbf619f-f7c9-4d9c-ad3d-dee60bea2cf2"/>
							<gml:surfaceMember xlink:href="#poly-f55305b1-48fa-4f01-b915-0e488a82f178"/>
							<gml:surfaceMember xlink:href="#poly-e3c7e26c-c826-44e6-9078-4175e150e96f"/>
							<gml:surfaceMember xlink:href="#poly-33205698-6271-4176-807c-a320d08c6ea3"/>
							<gml:surfaceMember xlink:href="#poly-96ad3bcf-6870-4532-9ae6-a21b9011e4b4"/>
							<gml:surfaceMember xlink:href="#poly-3ffed716-49a1-41e4-b7d0-e4330c063948"/>
							<gml:surfaceMember xlink:href="#poly-6cec2bb2-7d94-4480-878b-90995ac2f4d3"/>
							<gml:surfaceMember xlink:href="#poly-1476b115-4f2f-4380-8ff5-2771cd5f9d64"/>
							<gml:surfaceMember xlink:href="#poly-b8bbe20e-921d-4da7-8394-07f1f52a4b21"/>
							<gml:surfaceMember xlink:href="#poly-a718b735-c571-41cd-bd13-f8010dd64688"/>
							<gml:surfaceMember xlink:href="#poly-03658085-587e-489f-812d-35ab31ef8165"/>
							<gml:surfaceMember xlink:href="#poly-b1ac1ab8-691b-4c4e-a6f1-e798b78f0d38"/>
							<gml:surfaceMember xlink:href="#poly-f0a42a2c-a5fc-4d7e-b269-50beec1e59ca"/>
							<gml:surfaceMember xlink:href="#poly-68779e93-5351-4750-a6a7-f511d1e197bb"/>
							<gml:surfaceMember xlink:href="#poly-dd2993a4-a796-4de2-9f31-544ff1938012"/>
							<gml:surfaceMember xlink:href="#poly-3907fa82-3afe-478a-991d-3d492164e304"/>
							<gml:surfaceMember xlink:href="#poly-e93af965-26f6-436a-933a-2e042b59749f"/>
							<gml:surfaceMember xlink:href="#poly-8836bb6f-9443-45c5-8014-1362e3b0ab29"/>
							<gml:surfaceMember xlink:href="#poly-485855e3-7104-4c08-b19a-d7ba81d54257"/>
							<gml:surfaceMember xlink:href="#poly-fd25fa1b-bfd5-4d63-8bf8-a88489790f56"/>
							<gml:surfaceMember xlink:href="#poly-1913d549-d6c4-46d6-8f18-201e6433406f"/>
							<gml:surfaceMember xlink:href="#poly-da2d763e-ed63-4820-9a6a-5c1d1fb0baf1"/>
							<gml:surfaceMember xlink:href="#poly-4ead063a-cab4-4a6f-bc54-2fe813b090d2"/>
							<gml:surfaceMember xlink:href="#poly-379a0323-d847-464f-8254-0d3812feb9ef"/>
							<gml:surfaceMember xlink:href="#poly-c092af7d-6062-49f3-8b13-270ee8bf9155"/>
							<gml:surfaceMember xlink:href="#poly-a7dc24f5-6ee9-4fb3-9a59-3e0ff1265012"/>
							<gml:surfaceMember xlink:href="#poly-029fb051-1c2d-4ab9-8291-7551e8ba7a55"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_07633ee6-e7f9-439f-93f6-b9b2a901e669_BuildingInstallation_1060">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4212b2e6-aa5c-4dcd-824c-81af04e5ba50">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66865350778588 139.7387985162913 14.329 35.668639732987344 139.73878472500732 14.329 35.668663537021956 139.73874872004222 14.329 35.668677438120824 139.73876264372745 14.329 35.66865350778588 139.7387985162913 14.329</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2303f453-559d-41dd-866b-360ffbdb9595">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2303f453-559d-41dd-866b-360ffbdb9595_0">
											<gml:posList>35.668639732987344 139.73878472500732 50.897 35.668639732987344 139.73878472500732 14.329 35.66865350778588 139.7387985162913 14.329 35.66865350778588 139.7387985162913 50.897 35.66864580400295 139.7387908042058 50.897 35.668639732987344 139.73878472500732 50.897</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e1306cf0-7af2-4ecd-ac5b-1af7ef0da55d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e1306cf0-7af2-4ecd-ac5b-1af7ef0da55d_0">
											<gml:posList>35.668639732987344 139.73878472500732 14.329 35.668639732987344 139.73878472500732 50.897 35.668663537021956 139.73874872004222 52.442 35.668663537021956 139.73874872004222 14.329 35.668639732987344 139.73878472500732 14.329</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-50b641ef-f560-4699-88df-ee62d443432e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-50b641ef-f560-4699-88df-ee62d443432e_0">
											<gml:posList>35.66866972531321 139.7387549206077 52.442 35.668663537021956 139.73874872004222 52.442 35.668639732987344 139.73878472500732 50.897 35.66864580400295 139.7387908042058 50.897 35.66866972531321 139.7387549206077 52.442</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-00cf7099-1f93-4c96-a771-ecc3e3894265">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-00cf7099-1f93-4c96-a771-ecc3e3894265_0">
											<gml:posList>35.66864580400295 139.7387908042058 50.897 35.66866972531321 139.7387549206077 49.488 35.66866972531321 139.7387549206077 52.442 35.66864580400295 139.7387908042058 50.897</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-17079119-cec9-48bc-8b89-5535bdca0b22">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-17079119-cec9-48bc-8b89-5535bdca0b22_0">
											<gml:posList>35.66864580400295 139.7387908042058 50.897 35.66865350778588 139.7387985162913 50.897 35.668677438120824 139.73876264372745 49.488 35.66866972531321 139.7387549206077 49.488 35.66864580400295 139.7387908042058 50.897</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9356de4c-7461-498f-88f2-4baeded1e0c8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9356de4c-7461-498f-88f2-4baeded1e0c8_0">
											<gml:posList>35.66865350778588 139.7387985162913 50.897 35.66865350778588 139.7387985162913 14.329 35.668677438120824 139.73876264372745 14.329 35.668677438120824 139.73876264372745 49.488 35.66865350778588 139.7387985162913 50.897</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b1e6c7a5-0569-4c64-81ce-426ac04681fd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b1e6c7a5-0569-4c64-81ce-426ac04681fd_0">
											<gml:posList>35.668677438120824 139.73876264372745 14.329 35.668663537021956 139.73874872004222 14.329 35.668663537021956 139.73874872004222 52.442 35.66866972531321 139.7387549206077 52.442 35.66866972531321 139.7387549206077 49.488 35.668677438120824 139.73876264372745 49.488 35.668677438120824 139.73876264372745 14.329</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-cb018d17-8cbe-455b-9522-73aef8887bd7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cb018d17-8cbe-455b-9522-73aef8887bd7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cb018d17-8cbe-455b-9522-73aef8887bd7">
											<gml:posList>35.668642757808634 139.73877989432987 14.329 35.668639732978676 139.7387847139613 14.329 35.66862018485773 139.73876515242398 14.329 35.66859362559247 139.73880494939547 14.329 35.66851767017199 139.7387288215215 14.329 35.66866991422907 139.73850230887032 14.329 35.668752365409055 139.73858571938058 14.329 35.66866125412377 139.73872268726026 14.329 35.66867992728674 139.7387414434696 14.329 35.668670455997535 139.7387556487834 14.329 35.668663537021956 139.73874872004222 14.329 35.668642757808634 139.73877989432987 14.329</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-cf2ea2b8-9746-4e2a-8641-dd2a1d3ae985">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cf2ea2b8-9746-4e2a-8641-dd2a1d3ae985">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cf2ea2b8-9746-4e2a-8641-dd2a1d3ae985">
											<gml:posList>35.66851767017199 139.7387288215215 41.338 35.66868099192081 139.73851351853043 49.278 35.66866991422907 139.73850230887032 41.338 35.66851767017199 139.7387288215215 41.338</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-be18a1c9-d969-4408-9351-709bb4304053">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-be18a1c9-d969-4408-9351-709bb4304053">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-be18a1c9-d969-4408-9351-709bb4304053">
											<gml:posList>35.66868099192081 139.73851351853043 49.278 35.66868127412959 139.73851705292472 49.278 35.668749490300335 139.73858606520503 49.278 35.668752365409055 139.73858571938058 49.278 35.66868099192081 139.73851351853043 49.278</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ddfbff07-07d3-426a-8a41-97c10ddca2f4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ddfbff07-07d3-426a-8a41-97c10ddca2f4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ddfbff07-07d3-426a-8a41-97c10ddca2f4">
											<gml:posList>35.66859362559247 139.73880494939547 49.278 35.66859334339213 139.73880141500396 49.278 35.66853230843786 139.73874024791127 49.278 35.66852943334592 139.7387406158212 49.278 35.66859362559247 139.73880494939547 49.278</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-32d0ffc7-87c4-484b-9e5e-3c782eefbac1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-32d0ffc7-87c4-484b-9e5e-3c782eefbac1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-32d0ffc7-87c4-484b-9e5e-3c782eefbac1">
											<gml:posList>35.66851767017199 139.7387288215215 41.338 35.66852943334592 139.7387406158212 49.278 35.66868099192081 139.73851351853043 49.278 35.66851767017199 139.7387288215215 41.338</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a9bac3e5-d655-41dc-b840-6b3fbb0a2153">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a9bac3e5-d655-41dc-b840-6b3fbb0a2153">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a9bac3e5-d655-41dc-b840-6b3fbb0a2153">
											<gml:posList>35.66852943334592 139.7387406158212 49.278 35.66853230843786 139.73874024791127 49.278 35.66868127412959 139.73851705292472 49.278 35.66868099192081 139.73851351853043 49.278 35.66852943334592 139.7387406158212 49.278</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-982381d9-2f3f-4e94-be5f-a0de6c77f6cc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-982381d9-2f3f-4e94-be5f-a0de6c77f6cc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-982381d9-2f3f-4e94-be5f-a0de6c77f6cc">
											<gml:posList>35.66862018485773 139.73876515242398 49.278 35.66861989364249 139.73876161804208 49.278 35.66859334339213 139.73880141500396 49.278 35.66859362559247 139.73880494939547 49.278 35.66862018485773 139.73876515242398 49.278</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-3dbf619f-f7c9-4d9c-ad3d-dee60bea2cf2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3dbf619f-f7c9-4d9c-ad3d-dee60bea2cf2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3dbf619f-f7c9-4d9c-ad3d-dee60bea2cf2">
											<gml:posList>35.66862018485773 139.73876515242398 49.278 35.668639732978676 139.7387847139613 49.278 35.66863940566575 139.73878112439093 49.278 35.66861989364249 139.73876161804208 49.278 35.66862018485773 139.73876515242398 49.278</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f55305b1-48fa-4f01-b915-0e488a82f178">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f55305b1-48fa-4f01-b915-0e488a82f178">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f55305b1-48fa-4f01-b915-0e488a82f178">
											<gml:posList>35.66861989364249 139.73876161804208 48.75 35.66863940566575 139.73878112439093 48.75 35.66864121524737 139.7387783497061 48.75 35.668627738133644 139.7387648563191 48.75 35.66865643109534 139.73872182031542 48.75 35.668658054841615 139.7387234421647 48.75 35.668749490300335 139.73858606520503 48.75 35.66868127412959 139.73851705292472 48.75 35.66853230843786 139.73874024791127 48.75 35.66859334339213 139.73880141500396 48.75 35.66861989364249 139.73876161804208 48.75</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e3c7e26c-c826-44e6-9078-4175e150e96f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e3c7e26c-c826-44e6-9078-4175e150e96f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e3c7e26c-c826-44e6-9078-4175e150e96f">
											<gml:posList>35.66863940566575 139.73878112439093 49.278 35.668639732978676 139.7387847139613 49.278 35.668642757808634 139.73877989432987 49.278 35.66864121524737 139.7387783497061 49.278 35.66863940566575 139.73878112439093 49.278</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-33205698-6271-4176-807c-a320d08c6ea3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-33205698-6271-4176-807c-a320d08c6ea3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-33205698-6271-4176-807c-a320d08c6ea3">
											<gml:posList>35.668627738133644 139.7387648563191 53.597 35.668642757808634 139.73877989432987 53.597 35.66867145076696 139.73873684727747 53.597 35.66865643109534 139.73872182031542 53.597 35.668627738133644 139.7387648563191 53.597</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-96ad3bcf-6870-4532-9ae6-a21b9011e4b4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-96ad3bcf-6870-4532-9ae6-a21b9011e4b4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-96ad3bcf-6870-4532-9ae6-a21b9011e4b4">
											<gml:posList>35.66867145076696 139.73873684727747 49.278 35.668663537021956 139.73874872004222 49.278 35.668670455997535 139.7387556487834 49.278 35.66867992728674 139.7387414434696 49.278 35.66866125412377 139.73872268726026 49.278 35.668659669574126 139.7387250640247 49.278 35.66867145076696 139.73873684727747 49.278</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-3ffed716-49a1-41e4-b7d0-e4330c063948">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3ffed716-49a1-41e4-b7d0-e4330c063948">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3ffed716-49a1-41e4-b7d0-e4330c063948">
											<gml:posList>35.668658054841615 139.7387234421647 49.278 35.668659669574126 139.7387250640247 49.278 35.66866125412377 139.73872268726026 49.278 35.668752365409055 139.73858571938058 49.278 35.668749490300335 139.73858606520503 49.278 35.668658054841615 139.7387234421647 49.278</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6cec2bb2-7d94-4480-878b-90995ac2f4d3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6cec2bb2-7d94-4480-878b-90995ac2f4d3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6cec2bb2-7d94-4480-878b-90995ac2f4d3">
											<gml:posList>35.66866991422907 139.73850230887032 41.338 35.66868099192081 139.73851351853043 49.278 35.668752365409055 139.73858571938058 49.278 35.668752365409055 139.73858571938058 14.329 35.66866991422907 139.73850230887032 14.329 35.66866991422907 139.73850230887032 41.338</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1476b115-4f2f-4380-8ff5-2771cd5f9d64">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1476b115-4f2f-4380-8ff5-2771cd5f9d64">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1476b115-4f2f-4380-8ff5-2771cd5f9d64">
											<gml:posList>35.66868127412959 139.73851705292472 49.278 35.66868127412959 139.73851705292472 48.75 35.668749490300335 139.73858606520503 48.75 35.668749490300335 139.73858606520503 49.278 35.66868127412959 139.73851705292472 49.278</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b8bbe20e-921d-4da7-8394-07f1f52a4b21">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b8bbe20e-921d-4da7-8394-07f1f52a4b21">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b8bbe20e-921d-4da7-8394-07f1f52a4b21">
											<gml:posList>35.66866991422907 139.73850230887032 14.329 35.66851767017199 139.7387288215215 14.329 35.66851767017199 139.7387288215215 41.338 35.66866991422907 139.73850230887032 41.338 35.66866991422907 139.73850230887032 14.329</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a718b735-c571-41cd-bd13-f8010dd64688">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a718b735-c571-41cd-bd13-f8010dd64688">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a718b735-c571-41cd-bd13-f8010dd64688">
											<gml:posList>35.66853230843786 139.73874024791127 49.278 35.66853230843786 139.73874024791127 48.75 35.66868127412959 139.73851705292472 48.75 35.66868127412959 139.73851705292472 49.278 35.66853230843786 139.73874024791127 49.278</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-03658085-587e-489f-812d-35ab31ef8165">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-03658085-587e-489f-812d-35ab31ef8165">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-03658085-587e-489f-812d-35ab31ef8165">
											<gml:posList>35.66866125412377 139.73872268726026 14.329 35.668752365409055 139.73858571938058 14.329 35.668752365409055 139.73858571938058 49.278 35.66866125412377 139.73872268726026 49.278 35.66866125412377 139.73872268726026 14.329</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b1ac1ab8-691b-4c4e-a6f1-e798b78f0d38">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b1ac1ab8-691b-4c4e-a6f1-e798b78f0d38">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b1ac1ab8-691b-4c4e-a6f1-e798b78f0d38">
											<gml:posList>35.668749490300335 139.73858606520503 49.278 35.668749490300335 139.73858606520503 48.75 35.668658054841615 139.7387234421647 48.75 35.668658054841615 139.7387234421647 49.278 35.668749490300335 139.73858606520503 49.278</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f0a42a2c-a5fc-4d7e-b269-50beec1e59ca">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f0a42a2c-a5fc-4d7e-b269-50beec1e59ca">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f0a42a2c-a5fc-4d7e-b269-50beec1e59ca">
											<gml:posList>35.66865643109534 139.73872182031542 53.597 35.66867145076696 139.73873684727747 53.597 35.66867145076696 139.73873684727747 49.278 35.668659669574126 139.7387250640247 49.278 35.668658054841615 139.7387234421647 49.278 35.668658054841615 139.7387234421647 48.75 35.66865643109534 139.73872182031542 48.75 35.66865643109534 139.73872182031542 53.597</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-68779e93-5351-4750-a6a7-f511d1e197bb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-68779e93-5351-4750-a6a7-f511d1e197bb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-68779e93-5351-4750-a6a7-f511d1e197bb">
											<gml:posList>35.66867992728674 139.7387414434696 14.329 35.66866125412377 139.73872268726026 14.329 35.66866125412377 139.73872268726026 49.278 35.66867992728674 139.7387414434696 49.278 35.66867992728674 139.7387414434696 14.329</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-dd2993a4-a796-4de2-9f31-544ff1938012">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-dd2993a4-a796-4de2-9f31-544ff1938012">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-dd2993a4-a796-4de2-9f31-544ff1938012">
											<gml:posList>35.668627738133644 139.7387648563191 53.597 35.66865643109534 139.73872182031542 53.597 35.66865643109534 139.73872182031542 48.75 35.668627738133644 139.7387648563191 48.75 35.668627738133644 139.7387648563191 53.597</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3907fa82-3afe-478a-991d-3d492164e304">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3907fa82-3afe-478a-991d-3d492164e304">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3907fa82-3afe-478a-991d-3d492164e304">
											<gml:posList>35.668670455997535 139.7387556487834 14.329 35.66867992728674 139.7387414434696 14.329 35.66867992728674 139.7387414434696 49.278 35.668670455997535 139.7387556487834 49.278 35.668670455997535 139.7387556487834 14.329</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e93af965-26f6-436a-933a-2e042b59749f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e93af965-26f6-436a-933a-2e042b59749f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e93af965-26f6-436a-933a-2e042b59749f">
											<gml:posList>35.668663537021956 139.73874872004222 14.329 35.668670455997535 139.7387556487834 14.329 35.668670455997535 139.7387556487834 49.278 35.668663537021956 139.73874872004222 49.278 35.668663537021956 139.73874872004222 14.329</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8836bb6f-9443-45c5-8014-1362e3b0ab29">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8836bb6f-9443-45c5-8014-1362e3b0ab29">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8836bb6f-9443-45c5-8014-1362e3b0ab29">
											<gml:posList>35.66867145076696 139.73873684727747 53.597 35.668642757808634 139.73877989432987 53.597 35.668642757808634 139.73877989432987 49.278 35.668642757808634 139.73877989432987 14.329 35.668663537021956 139.73874872004222 14.329 35.668663537021956 139.73874872004222 49.278 35.66867145076696 139.73873684727747 49.278 35.66867145076696 139.73873684727747 53.597</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-485855e3-7104-4c08-b19a-d7ba81d54257">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-485855e3-7104-4c08-b19a-d7ba81d54257">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-485855e3-7104-4c08-b19a-d7ba81d54257">
											<gml:posList>35.66859362559247 139.73880494939547 49.278 35.66852943334592 139.7387406158212 49.278 35.66851767017199 139.7387288215215 41.338 35.66851767017199 139.7387288215215 14.329 35.66859362559247 139.73880494939547 14.329 35.66859362559247 139.73880494939547 49.278</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-fd25fa1b-bfd5-4d63-8bf8-a88489790f56">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fd25fa1b-bfd5-4d63-8bf8-a88489790f56">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fd25fa1b-bfd5-4d63-8bf8-a88489790f56">
											<gml:posList>35.66859334339213 139.73880141500396 49.278 35.66859334339213 139.73880141500396 48.75 35.66853230843786 139.73874024791127 48.75 35.66853230843786 139.73874024791127 49.278 35.66859334339213 139.73880141500396 49.278</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1913d549-d6c4-46d6-8f18-201e6433406f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1913d549-d6c4-46d6-8f18-201e6433406f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1913d549-d6c4-46d6-8f18-201e6433406f">
											<gml:posList>35.66863940566575 139.73878112439093 49.278 35.66863940566575 139.73878112439093 48.75 35.66861989364249 139.73876161804208 48.75 35.66861989364249 139.73876161804208 49.278 35.66863940566575 139.73878112439093 49.278</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-da2d763e-ed63-4820-9a6a-5c1d1fb0baf1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-da2d763e-ed63-4820-9a6a-5c1d1fb0baf1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-da2d763e-ed63-4820-9a6a-5c1d1fb0baf1">
											<gml:posList>35.668642757808634 139.73877989432987 53.597 35.668627738133644 139.7387648563191 53.597 35.668627738133644 139.7387648563191 48.75 35.66864121524737 139.7387783497061 48.75 35.66864121524737 139.7387783497061 49.278 35.668642757808634 139.73877989432987 49.278 35.668642757808634 139.73877989432987 53.597</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4ead063a-cab4-4a6f-bc54-2fe813b090d2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4ead063a-cab4-4a6f-bc54-2fe813b090d2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4ead063a-cab4-4a6f-bc54-2fe813b090d2">
											<gml:posList>35.66862018485773 139.73876515242398 14.329 35.668639732978676 139.7387847139613 14.329 35.668639732978676 139.7387847139613 49.278 35.66862018485773 139.73876515242398 49.278 35.66862018485773 139.73876515242398 14.329</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-379a0323-d847-464f-8254-0d3812feb9ef">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-379a0323-d847-464f-8254-0d3812feb9ef">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-379a0323-d847-464f-8254-0d3812feb9ef">
											<gml:posList>35.66864121524737 139.7387783497061 49.278 35.66864121524737 139.7387783497061 48.75 35.66863940566575 139.73878112439093 48.75 35.66863940566575 139.73878112439093 49.278 35.66864121524737 139.7387783497061 49.278</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c092af7d-6062-49f3-8b13-270ee8bf9155">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c092af7d-6062-49f3-8b13-270ee8bf9155">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c092af7d-6062-49f3-8b13-270ee8bf9155">
											<gml:posList>35.66861989364249 139.73876161804208 49.278 35.66861989364249 139.73876161804208 48.75 35.66859334339213 139.73880141500396 48.75 35.66859334339213 139.73880141500396 49.278 35.66861989364249 139.73876161804208 49.278</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a7dc24f5-6ee9-4fb3-9a59-3e0ff1265012">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a7dc24f5-6ee9-4fb3-9a59-3e0ff1265012">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a7dc24f5-6ee9-4fb3-9a59-3e0ff1265012">
											<gml:posList>35.668639732978676 139.7387847139613 14.329 35.668642757808634 139.73877989432987 14.329 35.668642757808634 139.73877989432987 49.278 35.668639732978676 139.7387847139613 49.278 35.668639732978676 139.7387847139613 14.329</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-029fb051-1c2d-4ab9-8291-7551e8ba7a55">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-029fb051-1c2d-4ab9-8291-7551e8ba7a55">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-029fb051-1c2d-4ab9-8291-7551e8ba7a55">
											<gml:posList>35.66859362559247 139.73880494939547 14.329 35.66862018485773 139.73876515242398 14.329 35.66862018485773 139.73876515242398 49.278 35.66859362559247 139.73880494939547 49.278 35.66859362559247 139.73880494939547 14.329</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-306</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">378.06941</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">211</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1320</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>4</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>