<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_07862cc5-f4db-46e7-9cff-6620c96f2095">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="地区計画">
				<gen:value>赤坂二丁目地区</gen:value>
			</gen:stringAttribute>
			<bldg:measuredHeight uom="m">9.4</bldg:measuredHeight>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.66917318404213 139.73997503049407 0 35.66918615786637 139.73994410841456 0 35.66919058577241 139.73994689791942 0 35.66921628150273 139.73988568364913 0 35.669211979847404 139.73988297132232 0 35.66921942042862 139.73986522261464 0 35.669215434416074 139.73986271979675 0 35.66923174612718 139.73982384059755 0 35.66922101452827 139.73981707080787 0 35.669227591395256 139.73980139976655 0 35.66919948182725 139.73978368147922 0 35.669194020613645 139.7397967111981 0 35.669153204476395 139.7397709882841 0 35.669093049948486 139.7399143261618 0 35.669088413200505 139.7399095707029 0 35.668997297512014 139.74004279304268 0 35.66902181634196 139.74006797165214 0 35.66903443929472 139.7400495100258 0 35.669117025709724 139.74013434729443 0 35.66920507169588 139.74000613231473 0 35.66918194200343 139.73998228862686 0 35.669178709715744 139.73998698697997 0 35.669173757216306 139.73998187840445 0 35.66916380826811 139.73999636036788 0 35.66917318404213 139.73997503049407 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66917318404213 139.73997503049407 10.436 35.66916380826811 139.73999636036788 10.436 35.669173757216306 139.73998187840445 10.436 35.669178709715744 139.73998698697997 10.436 35.66918194200343 139.73998228862686 10.436 35.66920507169588 139.74000613231473 10.436 35.669117025709724 139.74013434729443 10.436 35.66903443929472 139.7400495100258 10.436 35.66902181634196 139.74006797165214 10.436 35.668997297512014 139.74004279304268 10.436 35.669088413200505 139.7399095707029 10.436 35.669093049948486 139.7399143261618 10.436 35.669153204476395 139.7397709882841 10.436 35.669194020613645 139.7397967111981 10.436 35.66919948182725 139.73978368147922 10.436 35.669227591395256 139.73980139976655 10.436 35.66922101452827 139.73981707080787 10.436 35.66923174612718 139.73982384059755 10.436 35.669215434416074 139.73986271979675 10.436 35.66921942042862 139.73986522261464 10.436 35.669211979847404 139.73988297132232 10.436 35.66921628150273 139.73988568364913 10.436 35.66919058577241 139.73994689791942 10.436 35.66918615786637 139.73994410841456 10.436 35.66917318404213 139.73997503049407 10.436</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66917318404213 139.73997503049407 10.436 35.66918615786637 139.73994410841456 10.436 35.66918615786637 139.73994410841456 19.81 35.66917318404213 139.73997503049407 19.81 35.66917318404213 139.73997503049407 10.436</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66918615786637 139.73994410841456 10.436 35.66919058577241 139.73994689791942 10.436 35.66919058577241 139.73994689791942 19.81 35.66918615786637 139.73994410841456 19.81 35.66918615786637 139.73994410841456 10.436</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66919058577241 139.73994689791942 10.436 35.66921628150273 139.73988568364913 10.436 35.66921628150273 139.73988568364913 19.81 35.66919058577241 139.73994689791942 19.81 35.66919058577241 139.73994689791942 10.436</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66921628150273 139.73988568364913 10.436 35.669211979847404 139.73988297132232 10.436 35.669211979847404 139.73988297132232 19.81 35.66921628150273 139.73988568364913 19.81 35.66921628150273 139.73988568364913 10.436</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669211979847404 139.73988297132232 10.436 35.66921942042862 139.73986522261464 10.436 35.66921942042862 139.73986522261464 19.81 35.669211979847404 139.73988297132232 19.81 35.669211979847404 139.73988297132232 10.436</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66921942042862 139.73986522261464 10.436 35.669215434416074 139.73986271979675 10.436 35.669215434416074 139.73986271979675 19.81 35.66921942042862 139.73986522261464 19.81 35.66921942042862 139.73986522261464 10.436</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669215434416074 139.73986271979675 10.436 35.66923174612718 139.73982384059755 10.436 35.66923174612718 139.73982384059755 19.81 35.669215434416074 139.73986271979675 19.81 35.669215434416074 139.73986271979675 10.436</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66923174612718 139.73982384059755 10.436 35.66922101452827 139.73981707080787 10.436 35.66922101452827 139.73981707080787 19.81 35.66923174612718 139.73982384059755 19.81 35.66923174612718 139.73982384059755 10.436</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66922101452827 139.73981707080787 10.436 35.669227591395256 139.73980139976655 10.436 35.669227591395256 139.73980139976655 19.81 35.66922101452827 139.73981707080787 19.81 35.66922101452827 139.73981707080787 10.436</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669227591395256 139.73980139976655 10.436 35.66919948182725 139.73978368147922 10.436 35.66919948182725 139.73978368147922 19.81 35.669227591395256 139.73980139976655 19.81 35.669227591395256 139.73980139976655 10.436</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66919948182725 139.73978368147922 10.436 35.669194020613645 139.7397967111981 10.436 35.669194020613645 139.7397967111981 19.81 35.66919948182725 139.73978368147922 19.81 35.66919948182725 139.73978368147922 10.436</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669194020613645 139.7397967111981 10.436 35.669153204476395 139.7397709882841 10.436 35.669153204476395 139.7397709882841 19.81 35.669194020613645 139.7397967111981 19.81 35.669194020613645 139.7397967111981 10.436</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669153204476395 139.7397709882841 10.436 35.669093049948486 139.7399143261618 10.436 35.669093049948486 139.7399143261618 19.81 35.669153204476395 139.7397709882841 19.81 35.669153204476395 139.7397709882841 10.436</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669093049948486 139.7399143261618 10.436 35.669088413200505 139.7399095707029 10.436 35.669088413200505 139.7399095707029 19.81 35.669093049948486 139.7399143261618 19.81 35.669093049948486 139.7399143261618 10.436</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669088413200505 139.7399095707029 10.436 35.668997297512014 139.74004279304268 10.436 35.668997297512014 139.74004279304268 19.81 35.669088413200505 139.7399095707029 19.81 35.669088413200505 139.7399095707029 10.436</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668997297512014 139.74004279304268 10.436 35.66902181634196 139.74006797165214 10.436 35.66902181634196 139.74006797165214 19.81 35.668997297512014 139.74004279304268 19.81 35.668997297512014 139.74004279304268 10.436</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66902181634196 139.74006797165214 10.436 35.66903443929472 139.7400495100258 10.436 35.66903443929472 139.7400495100258 19.81 35.66902181634196 139.74006797165214 19.81 35.66902181634196 139.74006797165214 10.436</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66903443929472 139.7400495100258 10.436 35.669117025709724 139.74013434729443 10.436 35.669117025709724 139.74013434729443 19.81 35.66903443929472 139.7400495100258 19.81 35.66903443929472 139.7400495100258 10.436</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669117025709724 139.74013434729443 10.436 35.66920507169588 139.74000613231473 10.436 35.66920507169588 139.74000613231473 19.81 35.669117025709724 139.74013434729443 19.81 35.669117025709724 139.74013434729443 10.436</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66920507169588 139.74000613231473 10.436 35.66918194200343 139.73998228862686 10.436 35.66918194200343 139.73998228862686 19.81 35.66920507169588 139.74000613231473 19.81 35.66920507169588 139.74000613231473 10.436</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66918194200343 139.73998228862686 10.436 35.669178709715744 139.73998698697997 10.436 35.669178709715744 139.73998698697997 19.81 35.66918194200343 139.73998228862686 19.81 35.66918194200343 139.73998228862686 10.436</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669178709715744 139.73998698697997 10.436 35.669173757216306 139.73998187840445 10.436 35.669173757216306 139.73998187840445 19.81 35.669178709715744 139.73998698697997 19.81 35.669178709715744 139.73998698697997 10.436</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669173757216306 139.73998187840445 10.436 35.66916380826811 139.73999636036788 10.436 35.66916380826811 139.73999636036788 19.81 35.669173757216306 139.73998187840445 19.81 35.669173757216306 139.73998187840445 10.436</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66916380826811 139.73999636036788 10.436 35.66917318404213 139.73997503049407 10.436 35.66917318404213 139.73997503049407 19.81 35.66916380826811 139.73999636036788 19.81 35.66916380826811 139.73999636036788 10.436</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66917318404213 139.73997503049407 19.81 35.66918615786637 139.73994410841456 19.81 35.66919058577241 139.73994689791942 19.81 35.66921628150273 139.73988568364913 19.81 35.669211979847404 139.73988297132232 19.81 35.66921942042862 139.73986522261464 19.81 35.669215434416074 139.73986271979675 19.81 35.66923174612718 139.73982384059755 19.81 35.66922101452827 139.73981707080787 19.81 35.669227591395256 139.73980139976655 19.81 35.66919948182725 139.73978368147922 19.81 35.669194020613645 139.7397967111981 19.81 35.669153204476395 139.7397709882841 19.81 35.669093049948486 139.7399143261618 19.81 35.669088413200505 139.7399095707029 19.81 35.668997297512014 139.74004279304268 19.81 35.66902181634196 139.74006797165214 19.81 35.66903443929472 139.7400495100258 19.81 35.669117025709724 139.74013434729443 19.81 35.66920507169588 139.74000613231473 19.81 35.66918194200343 139.73998228862686 19.81 35.669178709715744 139.73998698697997 19.81 35.669173757216306 139.73998187840445 19.81 35.66916380826811 139.73999636036788 19.81 35.66917318404213 139.73997503049407 19.81</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-933ea67e-723d-4423-b458-0c4ff2b3a53f"/>
							<gml:surfaceMember xlink:href="#poly-d9b1636c-b345-435a-93e2-86266fa3f0c8"/>
							<gml:surfaceMember xlink:href="#poly-d5183990-4ffb-4df4-bafc-b7716ab1b14a"/>
							<gml:surfaceMember xlink:href="#poly-d053aaad-86cb-4d7e-b263-9328096725f6"/>
							<gml:surfaceMember xlink:href="#poly-bf6d2719-aa2a-4df6-85ee-129701ba367f"/>
							<gml:surfaceMember xlink:href="#poly-ccc4d54a-ab1d-473d-9279-0ada880101ff"/>
							<gml:surfaceMember xlink:href="#poly-9b67beae-f8e6-4a2f-9cfe-2a02e42f64cb"/>
							<gml:surfaceMember xlink:href="#poly-e2af91a5-ab84-4358-8cba-42f866458d62"/>
							<gml:surfaceMember xlink:href="#poly-26b85ae3-08eb-436c-a5fc-772119e3168d"/>
							<gml:surfaceMember xlink:href="#poly-65d2ac97-4bcb-4f5e-b4ee-51de1ec1d22d"/>
							<gml:surfaceMember xlink:href="#poly-16798da6-5071-42d9-af5c-708f93310f06"/>
							<gml:surfaceMember xlink:href="#poly-65da53ea-201e-4831-8bd4-c7a0ed310a27"/>
							<gml:surfaceMember xlink:href="#poly-93a74dc5-87b3-4d08-8d6e-b07b8f52929b"/>
							<gml:surfaceMember xlink:href="#poly-516fbfbb-225c-4ddd-828c-342b09cdb1ad"/>
							<gml:surfaceMember xlink:href="#poly-2a58f822-20d2-456b-95b3-f64344605349"/>
							<gml:surfaceMember xlink:href="#poly-5b4264a6-bd5b-44b6-b12b-00e881e0cd72"/>
							<gml:surfaceMember xlink:href="#poly-bd22759b-f669-4570-ae76-6be7f25293f7"/>
							<gml:surfaceMember xlink:href="#poly-f6fcb6a9-f7ec-407f-81e6-a7c40a7307c0"/>
							<gml:surfaceMember xlink:href="#poly-d8b07651-6278-4867-9454-19379eb2eee0"/>
							<gml:surfaceMember xlink:href="#poly-5e44326e-6e85-45fd-9f8f-fad94f182c92"/>
							<gml:surfaceMember xlink:href="#poly-84e7b2b3-b774-4dbb-999d-f192d19cc8ae"/>
							<gml:surfaceMember xlink:href="#poly-790801e6-b304-465a-be14-d105234e33bf"/>
							<gml:surfaceMember xlink:href="#poly-1ffe4397-f7c5-481e-bb33-1122a244dd5b"/>
							<gml:surfaceMember xlink:href="#poly-50b30e55-64f9-404c-9d13-cf86cff33d83"/>
							<gml:surfaceMember xlink:href="#poly-bb8cd0ee-142d-4050-bb7a-e3d8ca86e218"/>
							<gml:surfaceMember xlink:href="#poly-c24ad8bd-8dba-417c-b680-6b26d02caeed"/>
							<gml:surfaceMember xlink:href="#poly-82223eff-00a2-43b7-a2eb-be795c893297"/>
							<gml:surfaceMember xlink:href="#poly-75331712-71e3-49ae-ad7e-4038d6893597"/>
							<gml:surfaceMember xlink:href="#poly-1f26d0fb-aecb-4b0e-806c-b7920494d3f7"/>
							<gml:surfaceMember xlink:href="#poly-eaf83161-2140-42ac-a2c8-0d564648c9fe"/>
							<gml:surfaceMember xlink:href="#poly-fde10742-61f6-476f-be0d-9c3590be0acc"/>
							<gml:surfaceMember xlink:href="#poly-69ec38b7-b068-4a75-b363-148cfb243cd1"/>
							<gml:surfaceMember xlink:href="#poly-28b0a64b-39e1-481d-b99e-b378ac09a21e"/>
							<gml:surfaceMember xlink:href="#poly-fd3cb831-0e4b-4b52-9a1a-8e4c94c4c6b9"/>
							<gml:surfaceMember xlink:href="#poly-8901f060-5216-4512-a248-265947d53a82"/>
							<gml:surfaceMember xlink:href="#poly-f0afd43d-5e2e-4b5d-9f48-b6ab6ec1982d"/>
							<gml:surfaceMember xlink:href="#poly-8ae59a6d-2bbe-49c2-828d-ca838c22b0c7"/>
							<gml:surfaceMember xlink:href="#poly-8cc04280-f117-4f20-b4be-5a35211a3c82"/>
							<gml:surfaceMember xlink:href="#poly-88eb4373-aec2-4e3d-a147-a2f2d115f037"/>
							<gml:surfaceMember xlink:href="#poly-f652d61f-f732-4a47-aa57-1e528304f9f8"/>
							<gml:surfaceMember xlink:href="#poly-8d474af8-4a25-4ac5-84d7-ca7aa46c6f3f"/>
							<gml:surfaceMember xlink:href="#poly-e44549e6-1a37-4d2d-b291-166242899cbe"/>
							<gml:surfaceMember xlink:href="#poly-1b248d79-c103-4a97-ac0c-e3a334d9d0ee"/>
							<gml:surfaceMember xlink:href="#poly-62f9cd8f-61f9-4221-88f5-48259952619c"/>
							<gml:surfaceMember xlink:href="#poly-3c0f89e0-aa67-4f21-ba66-05c0bda6e251"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-933ea67e-723d-4423-b458-0c4ff2b3a53f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-933ea67e-723d-4423-b458-0c4ff2b3a53f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-933ea67e-723d-4423-b458-0c4ff2b3a53f">
											<gml:posList>35.6692119798474 139.73988297132232 10.436 35.66921628150271 139.73988568364913 10.436 35.66919058577241 139.73994689791942 10.436 35.669186157866356 139.73994410841456 10.436 35.669173184042116 139.73997503049407 10.436 35.66916380826809 139.73999636036788 10.436 35.669173757216285 139.73998187840445 10.436 35.669178709715744 139.73998698697994 10.436 35.669181942003426 139.73998228862686 10.436 35.66920507169588 139.74000613231473 10.436 35.6691170257097 139.7401343472944 10.436 35.669034439294705 139.7400495100258 10.436 35.66902181634194 139.74006797165214 10.436 35.668997297512 139.74004279304268 10.436 35.66908841320049 139.7399095707029 10.436 35.669093049948486 139.73991432616177 10.436 35.669153204476395 139.7397709882841 10.436 35.66919402061365 139.7397967111981 10.436 35.66919948182725 139.7397836814792 10.436 35.66922759139522 139.73980139976652 10.436 35.66922101452823 139.73981707080785 10.436 35.669231746127174 139.73982384059755 10.436 35.66921543441609 139.73986271979675 10.436 35.66921942042858 139.73986522261464 10.436 35.6692119798474 139.73988297132232 10.436</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d9b1636c-b345-435a-93e2-86266fa3f0c8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d9b1636c-b345-435a-93e2-86266fa3f0c8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d9b1636c-b345-435a-93e2-86266fa3f0c8">
											<gml:posList>35.66922759139522 139.73980139976652 22.434 35.66919948182725 139.7397836814792 22.434 35.66919402061365 139.7397967111981 22.434 35.669153204476395 139.7397709882841 22.434 35.669093049948486 139.73991432616177 22.434 35.6690884533784 139.73992650429892 22.434 35.66909980595023 139.73993202516138 22.434 35.66910256776559 139.7399250629117 22.434 35.66915874084738 139.73995928453886 22.434 35.66921517715205 139.7398216065166 22.434 35.66921826118393 139.73982332611132 22.434 35.66922101452823 139.73981707080785 22.434 35.66922759139522 139.73980139976652 22.434</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d5183990-4ffb-4df4-bafc-b7716ab1b14a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d5183990-4ffb-4df4-bafc-b7716ab1b14a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d5183990-4ffb-4df4-bafc-b7716ab1b14a">
											<gml:posList>35.66921543441609 139.73986271979675 14.605 35.669231746127174 139.73982384059755 14.605 35.66922101452823 139.73981707080785 14.605 35.66921826118393 139.73982332611132 14.605 35.66921517715205 139.7398216065166 14.605 35.66915874084738 139.73995928453886 14.605 35.66914635323661 139.7399906256743 14.605 35.66914351164429 139.7399877017687 14.605 35.66913558848879 139.73999922101635 14.605 35.669179042369265 139.74004403966777 14.605 35.66920507169588 139.74000613231473 14.605 35.66918291625636 139.73998328164106 14.605 35.669179683977205 139.73998799104027 14.605 35.669173757216285 139.73998187840445 14.605 35.66916380826809 139.73999636036788 14.605 35.669173184042116 139.73997503049407 14.605 35.669186157866356 139.73994410841456 14.605 35.66919058577241 139.73994689791942 14.605 35.66921628150271 139.73988568364913 14.605 35.6692119798474 139.73988297132232 14.605 35.66921942042858 139.73986522261464 14.605 35.66921543441609 139.73986271979675 14.605</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d053aaad-86cb-4d7e-b263-9328096725f6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d053aaad-86cb-4d7e-b263-9328096725f6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d053aaad-86cb-4d7e-b263-9328096725f6">
											<gml:posList>35.66912380513704 139.73993799523015 14.605 35.66910256776559 139.7399250629117 14.605 35.66909980595023 139.73993202516138 14.605 35.6690884533784 139.73992650429892 14.605 35.669093049948486 139.73991432616177 14.605 35.66908841320049 139.7399095707029 14.605 35.668997297512 139.74004279304268 14.605 35.66902181634194 139.74006797165214 14.605 35.669034439294705 139.7400495100258 14.605 35.66909342544706 139.73995684209433 14.605 35.66910966132856 139.73997123832663 14.605 35.66911776674307 139.73996228155957 14.605 35.66912380513704 139.73993799523015 14.605</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-bf6d2719-aa2a-4df6-85ee-129701ba367f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bf6d2719-aa2a-4df6-85ee-129701ba367f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bf6d2719-aa2a-4df6-85ee-129701ba367f">
											<gml:posList>35.66915874084738 139.73995928453886 19.697 35.66912380513704 139.73993799523015 19.697 35.66911776674307 139.73996228155957 19.697 35.66910966132856 139.73997123832663 19.697 35.66909342544706 139.73995684209433 19.697 35.669034439294705 139.7400495100258 19.697 35.6691170257097 139.7401343472944 19.697 35.669179042369265 139.74004403966777 19.697 35.66913558848879 139.73999922101635 19.697 35.66914351164429 139.7399877017687 19.697 35.66914635323661 139.7399906256743 19.697 35.66915874084738 139.73995928453886 19.697</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ccc4d54a-ab1d-473d-9279-0ada880101ff">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ccc4d54a-ab1d-473d-9279-0ada880101ff">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ccc4d54a-ab1d-473d-9279-0ada880101ff">
											<gml:posList>35.66916380826809 139.73999636036788 10.436 35.66916380826809 139.73999636036788 14.605 35.669173757216285 139.73998187840445 14.605 35.669173757216285 139.73998187840445 10.436 35.66916380826809 139.73999636036788 10.436</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9b67beae-f8e6-4a2f-9cfe-2a02e42f64cb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9b67beae-f8e6-4a2f-9cfe-2a02e42f64cb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9b67beae-f8e6-4a2f-9cfe-2a02e42f64cb">
											<gml:posList>35.66919402061365 139.7397967111981 10.436 35.669153204476395 139.7397709882841 10.436 35.669153204476395 139.7397709882841 22.434 35.66919402061365 139.7397967111981 22.434 35.66919402061365 139.7397967111981 10.436</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e2af91a5-ab84-4358-8cba-42f866458d62">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e2af91a5-ab84-4358-8cba-42f866458d62">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e2af91a5-ab84-4358-8cba-42f866458d62">
											<gml:posList>35.66919948182725 139.7397836814792 10.436 35.66919402061365 139.7397967111981 10.436 35.66919402061365 139.7397967111981 22.434 35.66919948182725 139.7397836814792 22.434 35.66919948182725 139.7397836814792 10.436</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-26b85ae3-08eb-436c-a5fc-772119e3168d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-26b85ae3-08eb-436c-a5fc-772119e3168d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-26b85ae3-08eb-436c-a5fc-772119e3168d">
											<gml:posList>35.66922759139522 139.73980139976652 10.436 35.66919948182725 139.7397836814792 10.436 35.66919948182725 139.7397836814792 22.434 35.66922759139522 139.73980139976652 22.434 35.66922759139522 139.73980139976652 10.436</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-65d2ac97-4bcb-4f5e-b4ee-51de1ec1d22d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-65d2ac97-4bcb-4f5e-b4ee-51de1ec1d22d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-65d2ac97-4bcb-4f5e-b4ee-51de1ec1d22d">
											<gml:posList>35.66922759139522 139.73980139976652 10.436 35.66922759139522 139.73980139976652 22.434 35.66922101452823 139.73981707080785 22.434 35.66922101452823 139.73981707080785 14.605 35.66922101452823 139.73981707080785 10.436 35.66922759139522 139.73980139976652 10.436</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-16798da6-5071-42d9-af5c-708f93310f06">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-16798da6-5071-42d9-af5c-708f93310f06">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-16798da6-5071-42d9-af5c-708f93310f06">
											<gml:posList>35.66922101452823 139.73981707080785 14.605 35.66922101452823 139.73981707080785 22.434 35.66921826118393 139.73982332611132 22.434 35.66921826118393 139.73982332611132 14.605 35.66922101452823 139.73981707080785 14.605</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-65da53ea-201e-4831-8bd4-c7a0ed310a27">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-65da53ea-201e-4831-8bd4-c7a0ed310a27">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-65da53ea-201e-4831-8bd4-c7a0ed310a27">
											<gml:posList>35.669231746127174 139.73982384059755 10.436 35.66922101452823 139.73981707080785 10.436 35.66922101452823 139.73981707080785 14.605 35.669231746127174 139.73982384059755 14.605 35.669231746127174 139.73982384059755 10.436</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-93a74dc5-87b3-4d08-8d6e-b07b8f52929b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-93a74dc5-87b3-4d08-8d6e-b07b8f52929b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-93a74dc5-87b3-4d08-8d6e-b07b8f52929b">
											<gml:posList>35.66921826118393 139.73982332611132 14.605 35.66921826118393 139.73982332611132 22.434 35.66921517715205 139.7398216065166 22.434 35.66921517715205 139.7398216065166 14.605 35.66921826118393 139.73982332611132 14.605</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-516fbfbb-225c-4ddd-828c-342b09cdb1ad">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-516fbfbb-225c-4ddd-828c-342b09cdb1ad">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-516fbfbb-225c-4ddd-828c-342b09cdb1ad">
											<gml:posList>35.669153204476395 139.7397709882841 10.436 35.669093049948486 139.73991432616177 10.436 35.669093049948486 139.73991432616177 14.605 35.669093049948486 139.73991432616177 22.434 35.669153204476395 139.7397709882841 22.434 35.669153204476395 139.7397709882841 10.436</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2a58f822-20d2-456b-95b3-f64344605349">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2a58f822-20d2-456b-95b3-f64344605349">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2a58f822-20d2-456b-95b3-f64344605349">
											<gml:posList>35.66921543441609 139.73986271979675 10.436 35.669231746127174 139.73982384059755 10.436 35.669231746127174 139.73982384059755 14.605 35.66921543441609 139.73986271979675 14.605 35.66921543441609 139.73986271979675 10.436</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5b4264a6-bd5b-44b6-b12b-00e881e0cd72">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5b4264a6-bd5b-44b6-b12b-00e881e0cd72">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5b4264a6-bd5b-44b6-b12b-00e881e0cd72">
											<gml:posList>35.66921942042858 139.73986522261464 10.436 35.66921543441609 139.73986271979675 10.436 35.66921543441609 139.73986271979675 14.605 35.66921942042858 139.73986522261464 14.605 35.66921942042858 139.73986522261464 10.436</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-bd22759b-f669-4570-ae76-6be7f25293f7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bd22759b-f669-4570-ae76-6be7f25293f7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bd22759b-f669-4570-ae76-6be7f25293f7">
											<gml:posList>35.6692119798474 139.73988297132232 10.436 35.66921942042858 139.73986522261464 10.436 35.66921942042858 139.73986522261464 14.605 35.6692119798474 139.73988297132232 14.605 35.6692119798474 139.73988297132232 10.436</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f6fcb6a9-f7ec-407f-81e6-a7c40a7307c0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f6fcb6a9-f7ec-407f-81e6-a7c40a7307c0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f6fcb6a9-f7ec-407f-81e6-a7c40a7307c0">
											<gml:posList>35.66921628150271 139.73988568364913 10.436 35.6692119798474 139.73988297132232 10.436 35.6692119798474 139.73988297132232 14.605 35.66921628150271 139.73988568364913 14.605 35.66921628150271 139.73988568364913 10.436</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d8b07651-6278-4867-9454-19379eb2eee0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d8b07651-6278-4867-9454-19379eb2eee0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d8b07651-6278-4867-9454-19379eb2eee0">
											<gml:posList>35.66921517715205 139.7398216065166 14.605 35.66921517715205 139.7398216065166 22.434 35.66915874084738 139.73995928453886 22.434 35.66915874084738 139.73995928453886 19.697 35.66915874084738 139.73995928453886 14.605 35.66921517715205 139.7398216065166 14.605</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5e44326e-6e85-45fd-9f8f-fad94f182c92">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5e44326e-6e85-45fd-9f8f-fad94f182c92">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5e44326e-6e85-45fd-9f8f-fad94f182c92">
											<gml:posList>35.669093049948486 139.73991432616177 10.436 35.66908841320049 139.7399095707029 10.436 35.66908841320049 139.7399095707029 14.605 35.669093049948486 139.73991432616177 14.605 35.669093049948486 139.73991432616177 10.436</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-84e7b2b3-b774-4dbb-999d-f192d19cc8ae">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-84e7b2b3-b774-4dbb-999d-f192d19cc8ae">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-84e7b2b3-b774-4dbb-999d-f192d19cc8ae">
											<gml:posList>35.66919058577241 139.73994689791942 10.436 35.66921628150271 139.73988568364913 10.436 35.66921628150271 139.73988568364913 14.605 35.66919058577241 139.73994689791942 14.605 35.66919058577241 139.73994689791942 10.436</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-790801e6-b304-465a-be14-d105234e33bf">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-790801e6-b304-465a-be14-d105234e33bf">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-790801e6-b304-465a-be14-d105234e33bf">
											<gml:posList>35.6690884533784 139.73992650429892 14.605 35.6690884533784 139.73992650429892 22.434 35.669093049948486 139.73991432616177 22.434 35.669093049948486 139.73991432616177 14.605 35.6690884533784 139.73992650429892 14.605</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1ffe4397-f7c5-481e-bb33-1122a244dd5b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1ffe4397-f7c5-481e-bb33-1122a244dd5b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1ffe4397-f7c5-481e-bb33-1122a244dd5b">
											<gml:posList>35.66910256776559 139.7399250629117 14.605 35.66910256776559 139.7399250629117 22.434 35.66909980595023 139.73993202516138 22.434 35.66909980595023 139.73993202516138 14.605 35.66910256776559 139.7399250629117 14.605</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-50b30e55-64f9-404c-9d13-cf86cff33d83">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-50b30e55-64f9-404c-9d13-cf86cff33d83">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-50b30e55-64f9-404c-9d13-cf86cff33d83">
											<gml:posList>35.66909980595023 139.73993202516138 14.605 35.66909980595023 139.73993202516138 22.434 35.6690884533784 139.73992650429892 22.434 35.6690884533784 139.73992650429892 14.605 35.66909980595023 139.73993202516138 14.605</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-bb8cd0ee-142d-4050-bb7a-e3d8ca86e218">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bb8cd0ee-142d-4050-bb7a-e3d8ca86e218">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bb8cd0ee-142d-4050-bb7a-e3d8ca86e218">
											<gml:posList>35.66912380513704 139.73993799523015 19.697 35.66915874084738 139.73995928453886 19.697 35.66915874084738 139.73995928453886 22.434 35.66910256776559 139.7399250629117 22.434 35.66910256776559 139.7399250629117 14.605 35.66912380513704 139.73993799523015 14.605 35.66912380513704 139.73993799523015 19.697</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c24ad8bd-8dba-417c-b680-6b26d02caeed">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c24ad8bd-8dba-417c-b680-6b26d02caeed">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c24ad8bd-8dba-417c-b680-6b26d02caeed">
											<gml:posList>35.669186157866356 139.73994410841456 10.436 35.66919058577241 139.73994689791942 10.436 35.66919058577241 139.73994689791942 14.605 35.669186157866356 139.73994410841456 14.605 35.669186157866356 139.73994410841456 10.436</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-82223eff-00a2-43b7-a2eb-be795c893297">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-82223eff-00a2-43b7-a2eb-be795c893297">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-82223eff-00a2-43b7-a2eb-be795c893297">
											<gml:posList>35.66911776674307 139.73996228155957 14.605 35.66911776674307 139.73996228155957 19.697 35.66912380513704 139.73993799523015 19.697 35.66912380513704 139.73993799523015 14.605 35.66911776674307 139.73996228155957 14.605</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-75331712-71e3-49ae-ad7e-4038d6893597">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-75331712-71e3-49ae-ad7e-4038d6893597">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-75331712-71e3-49ae-ad7e-4038d6893597">
											<gml:posList>35.669173184042116 139.73997503049407 10.436 35.669186157866356 139.73994410841456 10.436 35.669186157866356 139.73994410841456 14.605 35.669173184042116 139.73997503049407 14.605 35.669173184042116 139.73997503049407 10.436</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1f26d0fb-aecb-4b0e-806c-b7920494d3f7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1f26d0fb-aecb-4b0e-806c-b7920494d3f7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1f26d0fb-aecb-4b0e-806c-b7920494d3f7">
											<gml:posList>35.66909342544706 139.73995684209433 14.605 35.66909342544706 139.73995684209433 19.697 35.66910966132856 139.73997123832663 19.697 35.66910966132856 139.73997123832663 14.605 35.66909342544706 139.73995684209433 14.605</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-eaf83161-2140-42ac-a2c8-0d564648c9fe">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-eaf83161-2140-42ac-a2c8-0d564648c9fe">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-eaf83161-2140-42ac-a2c8-0d564648c9fe">
											<gml:posList>35.66910966132856 139.73997123832663 14.605 35.66910966132856 139.73997123832663 19.697 35.66911776674307 139.73996228155957 19.697 35.66911776674307 139.73996228155957 14.605 35.66910966132856 139.73997123832663 14.605</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-fde10742-61f6-476f-be0d-9c3590be0acc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fde10742-61f6-476f-be0d-9c3590be0acc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fde10742-61f6-476f-be0d-9c3590be0acc">
											<gml:posList>35.66915874084738 139.73995928453886 14.605 35.66915874084738 139.73995928453886 19.697 35.66914635323661 139.7399906256743 19.697 35.66914635323661 139.7399906256743 14.605 35.66915874084738 139.73995928453886 14.605</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-69ec38b7-b068-4a75-b363-148cfb243cd1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-69ec38b7-b068-4a75-b363-148cfb243cd1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-69ec38b7-b068-4a75-b363-148cfb243cd1">
											<gml:posList>35.66908841320049 139.7399095707029 10.436 35.668997297512 139.74004279304268 10.436 35.668997297512 139.74004279304268 14.605 35.66908841320049 139.7399095707029 14.605 35.66908841320049 139.7399095707029 10.436</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-28b0a64b-39e1-481d-b99e-b378ac09a21e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-28b0a64b-39e1-481d-b99e-b378ac09a21e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-28b0a64b-39e1-481d-b99e-b378ac09a21e">
											<gml:posList>35.669179711044066 139.73998802414704 13.261 35.669178709715744 139.73998698697994 10.436 35.669173757216285 139.73998187840445 10.436 35.669173757216285 139.73998187840445 14.605 35.669179683977205 139.73998799104027 14.605 35.669179711044066 139.73998802414704 13.261</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-fd3cb831-0e4b-4b52-9a1a-8e4c94c4c6b9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fd3cb831-0e4b-4b52-9a1a-8e4c94c4c6b9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fd3cb831-0e4b-4b52-9a1a-8e4c94c4c6b9">
											<gml:posList>35.669179711044066 139.73998802414704 13.261 35.66918294332323 139.73998331474783 13.261 35.669181942003426 139.73998228862686 10.436 35.669178709715744 139.73998698697994 10.436 35.669179711044066 139.73998802414704 13.261</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8901f060-5216-4512-a248-265947d53a82">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8901f060-5216-4512-a248-265947d53a82">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8901f060-5216-4512-a248-265947d53a82">
											<gml:posList>35.669179683977205 139.73998799104027 14.605 35.66918291625636 139.73998328164106 14.605 35.66918294332323 139.73998331474783 13.261 35.669179711044066 139.73998802414704 13.261 35.669179683977205 139.73998799104027 14.605</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f0afd43d-5e2e-4b5d-9f48-b6ab6ec1982d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f0afd43d-5e2e-4b5d-9f48-b6ab6ec1982d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f0afd43d-5e2e-4b5d-9f48-b6ab6ec1982d">
											<gml:posList>35.66916380826809 139.73999636036788 10.436 35.669173184042116 139.73997503049407 10.436 35.669173184042116 139.73997503049407 14.605 35.66916380826809 139.73999636036788 14.605 35.66916380826809 139.73999636036788 10.436</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8ae59a6d-2bbe-49c2-828d-ca838c22b0c7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8ae59a6d-2bbe-49c2-828d-ca838c22b0c7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8ae59a6d-2bbe-49c2-828d-ca838c22b0c7">
											<gml:posList>35.66914635323661 139.7399906256743 14.605 35.66914635323661 139.7399906256743 19.697 35.66914351164429 139.7399877017687 19.697 35.66914351164429 139.7399877017687 14.605 35.66914635323661 139.7399906256743 14.605</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8cc04280-f117-4f20-b4be-5a35211a3c82">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8cc04280-f117-4f20-b4be-5a35211a3c82">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8cc04280-f117-4f20-b4be-5a35211a3c82">
											<gml:posList>35.66914351164429 139.7399877017687 14.605 35.66914351164429 139.7399877017687 19.697 35.66913558848879 139.73999922101635 19.697 35.66913558848879 139.73999922101635 14.605 35.66914351164429 139.7399877017687 14.605</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-88eb4373-aec2-4e3d-a147-a2f2d115f037">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-88eb4373-aec2-4e3d-a147-a2f2d115f037">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-88eb4373-aec2-4e3d-a147-a2f2d115f037">
											<gml:posList>35.66920507169588 139.74000613231473 14.605 35.66920507169588 139.74000613231473 10.436 35.669181942003426 139.73998228862686 10.436 35.66918294332323 139.73998331474783 13.261 35.66918291625636 139.73998328164106 14.605 35.66920507169588 139.74000613231473 14.605</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f652d61f-f732-4a47-aa57-1e528304f9f8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f652d61f-f732-4a47-aa57-1e528304f9f8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f652d61f-f732-4a47-aa57-1e528304f9f8">
											<gml:posList>35.669034439294705 139.7400495100258 14.605 35.669034439294705 139.7400495100258 19.697 35.66909342544706 139.73995684209433 19.697 35.66909342544706 139.73995684209433 14.605 35.669034439294705 139.7400495100258 14.605</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8d474af8-4a25-4ac5-84d7-ca7aa46c6f3f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8d474af8-4a25-4ac5-84d7-ca7aa46c6f3f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8d474af8-4a25-4ac5-84d7-ca7aa46c6f3f">
											<gml:posList>35.66913558848879 139.73999922101635 14.605 35.66913558848879 139.73999922101635 19.697 35.669179042369265 139.74004403966777 19.697 35.669179042369265 139.74004403966777 14.605 35.66913558848879 139.73999922101635 14.605</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e44549e6-1a37-4d2d-b291-166242899cbe">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e44549e6-1a37-4d2d-b291-166242899cbe">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e44549e6-1a37-4d2d-b291-166242899cbe">
											<gml:posList>35.668997297512 139.74004279304268 10.436 35.66902181634194 139.74006797165214 10.436 35.66902181634194 139.74006797165214 14.605 35.668997297512 139.74004279304268 14.605 35.668997297512 139.74004279304268 10.436</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1b248d79-c103-4a97-ac0c-e3a334d9d0ee">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1b248d79-c103-4a97-ac0c-e3a334d9d0ee">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1b248d79-c103-4a97-ac0c-e3a334d9d0ee">
											<gml:posList>35.66902181634194 139.74006797165214 10.436 35.669034439294705 139.7400495100258 10.436 35.669034439294705 139.7400495100258 14.605 35.66902181634194 139.74006797165214 14.605 35.66902181634194 139.74006797165214 10.436</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-62f9cd8f-61f9-4221-88f5-48259952619c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-62f9cd8f-61f9-4221-88f5-48259952619c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-62f9cd8f-61f9-4221-88f5-48259952619c">
											<gml:posList>35.669179042369265 139.74004403966777 14.605 35.669179042369265 139.74004403966777 19.697 35.6691170257097 139.7401343472944 19.697 35.6691170257097 139.7401343472944 10.436 35.66920507169588 139.74000613231473 10.436 35.66920507169588 139.74000613231473 14.605 35.669179042369265 139.74004403966777 14.605</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3c0f89e0-aa67-4f21-ba66-05c0bda6e251">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3c0f89e0-aa67-4f21-ba66-05c0bda6e251">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3c0f89e0-aa67-4f21-ba66-05c0bda6e251">
											<gml:posList>35.6691170257097 139.7401343472944 10.436 35.6691170257097 139.7401343472944 19.697 35.669034439294705 139.7400495100258 19.697 35.669034439294705 139.7400495100258 14.605 35.669034439294705 139.7400495100258 10.436 35.6691170257097 139.7401343472944 10.436</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-11432</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">211</uro:landUseType>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>7</uro:specifiedFloorAreaRate>
					<uro:surveyYear>0001</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">2</uro:rank>
					<uro:depth uom="m">0.74</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>