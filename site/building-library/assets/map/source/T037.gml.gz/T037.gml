<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_09577394-5aa5-4fe2-a8db-65729c5f432f">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">401</bldg:usage>
			<bldg:measuredHeight uom="m">19.7</bldg:measuredHeight>
			<bldg:storeysAboveGround>6</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.67121512810801 139.7381679072582 0 35.67122688879863 139.73822213100414 0 35.67117795677039 139.73823798535972 0 35.67116664816949 139.73818552852683 0 35.67112699792183 139.73819838936168 0 35.67116318508511 139.73836591981137 0 35.671300969759066 139.73832123966912 0 35.67126442067546 139.73815205242443 0 35.67121512810801 139.7381679072582 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67121512810801 139.7381679072582 15.2 35.67126442067546 139.73815205242443 15.2 35.671300969759066 139.73832123966912 15.2 35.67116318508511 139.73836591981137 15.2 35.67112699792183 139.73819838936168 15.2 35.67116664816949 139.73818552852683 15.2 35.67117795677039 139.73823798535972 15.2 35.67122688879863 139.73822213100414 15.2 35.67121512810801 139.7381679072582 15.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67121512810801 139.7381679072582 15.2 35.67122688879863 139.73822213100414 15.2 35.67122688879863 139.73822213100414 34.89 35.67121512810801 139.7381679072582 34.89 35.67121512810801 139.7381679072582 15.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67122688879863 139.73822213100414 15.2 35.67117795677039 139.73823798535972 15.2 35.67117795677039 139.73823798535972 34.89 35.67122688879863 139.73822213100414 34.89 35.67122688879863 139.73822213100414 15.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67117795677039 139.73823798535972 15.2 35.67116664816949 139.73818552852683 15.2 35.67116664816949 139.73818552852683 34.89 35.67117795677039 139.73823798535972 34.89 35.67117795677039 139.73823798535972 15.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67116664816949 139.73818552852683 15.2 35.67112699792183 139.73819838936168 15.2 35.67112699792183 139.73819838936168 34.89 35.67116664816949 139.73818552852683 34.89 35.67116664816949 139.73818552852683 15.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67112699792183 139.73819838936168 15.2 35.67116318508511 139.73836591981137 15.2 35.67116318508511 139.73836591981137 34.89 35.67112699792183 139.73819838936168 34.89 35.67112699792183 139.73819838936168 15.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67116318508511 139.73836591981137 15.2 35.671300969759066 139.73832123966912 15.2 35.671300969759066 139.73832123966912 34.89 35.67116318508511 139.73836591981137 34.89 35.67116318508511 139.73836591981137 15.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671300969759066 139.73832123966912 15.2 35.67126442067546 139.73815205242443 15.2 35.67126442067546 139.73815205242443 34.89 35.671300969759066 139.73832123966912 34.89 35.671300969759066 139.73832123966912 15.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67126442067546 139.73815205242443 15.2 35.67121512810801 139.7381679072582 15.2 35.67121512810801 139.7381679072582 34.89 35.67126442067546 139.73815205242443 34.89 35.67126442067546 139.73815205242443 15.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67121512810801 139.7381679072582 34.89 35.67122688879863 139.73822213100414 34.89 35.67117795677039 139.73823798535972 34.89 35.67116664816949 139.73818552852683 34.89 35.67112699792183 139.73819838936168 34.89 35.67116318508511 139.73836591981137 34.89 35.671300969759066 139.73832123966912 34.89 35.67126442067546 139.73815205242443 34.89 35.67121512810801 139.7381679072582 34.89</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-b6079967-87fc-4c57-9f6d-0746debd31ab"/>
							<gml:surfaceMember xlink:href="#poly-82ac3aab-ced5-4105-a712-728ea32d48f6"/>
							<gml:surfaceMember xlink:href="#poly-bade0fc6-a235-4d17-911d-1721f8d3a99b"/>
							<gml:surfaceMember xlink:href="#poly-d6389e83-2f51-4c26-89b4-959131fd7100"/>
							<gml:surfaceMember xlink:href="#poly-25af8fc2-07cd-468d-83bf-65a781259211"/>
							<gml:surfaceMember xlink:href="#poly-475595b4-7240-4918-bc83-60dd4130c10c"/>
							<gml:surfaceMember xlink:href="#poly-7fb81e3a-eb22-4e0b-a87e-5b55b5a3c4c5"/>
							<gml:surfaceMember xlink:href="#poly-ed77dbae-4a07-4e92-a67e-fd18dd5c8890"/>
							<gml:surfaceMember xlink:href="#poly-9d8ac6ce-5408-4e6e-9afd-214aa326c182"/>
							<gml:surfaceMember xlink:href="#poly-ab37563b-c598-4b18-8349-e02743b92a5c"/>
							<gml:surfaceMember xlink:href="#poly-8105ee44-a3cd-4703-b11c-37d98bc88f3e"/>
							<gml:surfaceMember xlink:href="#poly-307bb8a7-4339-4487-ad81-2d29a1c147ce"/>
							<gml:surfaceMember xlink:href="#poly-1453c345-8da8-43cf-a978-9273e5695058"/>
							<gml:surfaceMember xlink:href="#poly-e39dd5d1-a897-42c3-83e5-ae52c6d6cf64"/>
							<gml:surfaceMember xlink:href="#poly-10b4f207-7280-4630-bc3a-b5dfacf3dc67"/>
							<gml:surfaceMember xlink:href="#poly-e1ac4779-46a8-4131-a6d2-9647e83353f4"/>
							<gml:surfaceMember xlink:href="#poly-e21b6705-4076-4251-b43f-88da54ad24df"/>
							<gml:surfaceMember xlink:href="#poly-068a728d-f3ee-42c8-af0c-042d7d66e52e"/>
							<gml:surfaceMember xlink:href="#poly-e1d501d8-ad83-47be-b1b4-90f0deee8ec8"/>
							<gml:surfaceMember xlink:href="#poly-25ec85e3-370b-4137-9e6a-988d6d6df8e2"/>
							<gml:surfaceMember xlink:href="#poly-ca47519f-a936-41ce-b4b3-f3ec086a2ecd"/>
							<gml:surfaceMember xlink:href="#poly-d5348eec-d193-4b9c-9e76-7ffaac263c99"/>
							<gml:surfaceMember xlink:href="#poly-3fcc749f-14c8-4ada-ac80-383c9050420d"/>
							<gml:surfaceMember xlink:href="#poly-92321980-12ba-4d44-aa30-9d2562173f0b"/>
							<gml:surfaceMember xlink:href="#poly-e81da36a-a651-459a-b4d8-1502a36281d3"/>
							<gml:surfaceMember xlink:href="#poly-02315777-450a-4765-a7a2-dfda5de03e00"/>
							<gml:surfaceMember xlink:href="#poly-cfdd1f71-ad7b-40c2-9244-211da3c2a42b"/>
							<gml:surfaceMember xlink:href="#poly-f17ed923-9734-44c1-8e03-eedf5d3d928b"/>
							<gml:surfaceMember xlink:href="#poly-6e9be928-4d51-4d86-af16-24195a6bb844"/>
							<gml:surfaceMember xlink:href="#poly-52717ec1-f473-4fb7-8b96-2f8b05f487c4"/>
							<gml:surfaceMember xlink:href="#poly-4f4e46d7-6cb8-4f22-a52d-4dbf426234da"/>
							<gml:surfaceMember xlink:href="#poly-c3306a56-4757-409f-b6af-ed409e28c023"/>
							<gml:surfaceMember xlink:href="#poly-92e485d2-c0b8-43b8-9c5a-89a683672412"/>
							<gml:surfaceMember xlink:href="#poly-c7b4fd9c-a9fb-455e-a647-617f4ae60f86"/>
							<gml:surfaceMember xlink:href="#poly-06e21cb2-9a91-4bef-a2b3-3f60c7e93c7a"/>
							<gml:surfaceMember xlink:href="#poly-164abf35-759d-41fb-8304-8ede3fe61388"/>
							<gml:surfaceMember xlink:href="#poly-c55f683c-482c-4e62-92ec-ea1adc58a890"/>
							<gml:surfaceMember xlink:href="#poly-ca6bb374-e088-4f7c-b8de-085b97a8186d"/>
							<gml:surfaceMember xlink:href="#poly-7795e9cc-bc30-4d7e-bc8e-90818109e0f1"/>
							<gml:surfaceMember xlink:href="#poly-c67c383f-7898-411e-8e07-3008dd750f10"/>
							<gml:surfaceMember xlink:href="#poly-532bd4f1-bef1-4260-b093-c1068c835d38"/>
							<gml:surfaceMember xlink:href="#poly-d99c5386-73b3-413c-9e2f-f88cc0bf5bd0"/>
							<gml:surfaceMember xlink:href="#poly-5ca15b96-cfff-4a27-b317-aa39fede4403"/>
							<gml:surfaceMember xlink:href="#poly-a50e5d22-cec9-4c3b-835f-f5507d4438bd"/>
							<gml:surfaceMember xlink:href="#poly-434ab18a-e73a-4e4f-b6c1-e5ad149d1fb8"/>
							<gml:surfaceMember xlink:href="#poly-d27264bc-a36b-46fe-8635-66ba216a8b8c"/>
							<gml:surfaceMember xlink:href="#poly-314de9d9-5c6c-4016-9b91-44927be000a6"/>
							<gml:surfaceMember xlink:href="#poly-a7ca98f2-1f6c-408f-866b-a001b87e5acb"/>
							<gml:surfaceMember xlink:href="#poly-e0e5d7ce-8722-4406-ad8b-4ad5bb567456"/>
							<gml:surfaceMember xlink:href="#poly-bb512e6d-1179-42dc-971d-e328c5aed0fa"/>
							<gml:surfaceMember xlink:href="#poly-4a5e9f31-4330-4681-91f2-6e4c02e425c2"/>
							<gml:surfaceMember xlink:href="#poly-10faa212-c0cb-4c02-830b-746caa14f68f"/>
							<gml:surfaceMember xlink:href="#poly-afb1800c-08a5-4e5e-b30f-a8ac07dffadc"/>
							<gml:surfaceMember xlink:href="#poly-a9511f14-ce5b-44e9-9d75-28fcab2c040f"/>
							<gml:surfaceMember xlink:href="#poly-36119acf-92d6-4372-ade6-1b7075cbaed9"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_09577394-5aa5-4fe2-a8db-65729c5f432f_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-00b97fe5-4454-4132-8120-bcbadf589c23">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6711415167933 139.73822977694695 41.696 35.67115766526314 139.7382245439068 41.696 35.67116275861379 139.73824812185836 41.696 35.671146610142934 139.7382533548941 41.696 35.6711415167933 139.73822977694695 41.696</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-abe1c781-7e12-4ddd-8603-91d0510508d0">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67119881589637 139.7382739496988 37.317 35.67120943155673 139.73827076680317 37.317 35.67121145867042 139.73828094915623 37.317 35.67120084300106 139.73828412100423 37.317 35.67119881589637 139.7382739496988 37.317</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-df629cf6-85a3-426e-8c53-a845c16083af">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67120576775518 139.73829966845895 37.317 35.671203614372516 139.73828938683846 37.317 35.67121078751562 139.7382871248748 37.317 35.67121294090719 139.73829741754253 37.317 35.67120576775518 139.73829966845895 37.317</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-65132a83-2acb-4a31-ada3-b4de661e5fbb">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67117100566645 139.73828172617598 37.317 35.67117666907587 139.73830809819077 37.317 35.671161962414224 139.73831284346647 37.317 35.67115629900585 139.73828647145615 37.317 35.67117100566645 139.73828172617598 37.317</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7cbb573c-4853-48d5-b71d-b92586d0f869">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67119882242201 139.7383050562746 37.317 35.671191153637224 139.73830746242663 37.317 35.671188954994825 139.73829693784128 37.317 35.67119661476567 139.73829453169904 37.317 35.67119882242201 139.7383050562746 37.317</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c813f219-4c33-4818-92f8-a6594fe1708b">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671191153637224 139.73830746242663 37.317 35.67119882242201 139.7383050562746 37.317 35.67119882242201 139.7383050562746 39.383 35.671191153637224 139.73830746242663 39.383 35.671191153637224 139.73830746242663 37.317</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b329d3b4-0723-4cd2-9b87-b76bc199bcc7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67120878974922 139.7383141245797 37.317 35.67120666348741 139.7383039423436 37.317 35.67121383663951 139.73830169142752 37.317 35.67121596289279 139.73831186261808 37.317 35.67120878974922 139.7383141245797 37.317</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e3b5c130-9b09-4280-bb7c-71f3be6305f8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67119973626867 139.7383094406012 37.317 35.6711920674838 139.73831184675282 37.317 35.6711920674838 139.73831184675282 39.383 35.67119973626867 139.7383094406012 39.383 35.67119973626867 139.7383094406012 37.317</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-93f751d4-9df3-4289-8539-2d6db01bec51">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67120197108689 139.73832011979465 37.317 35.67119430230182 139.7383225259453 37.317 35.6711920674838 139.73831184675282 37.317 35.67119973626867 139.7383094406012 37.317 35.67120197108689 139.73832011979465 37.317</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6fedcf0c-2ed6-4ff8-bbf5-519fd07707e0">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67121681301555 139.73831545168224 37.317 35.67121913833651 139.73832659471861 37.317 35.671211875072885 139.73832887887855 37.317 35.671209540738424 139.7383177358538 37.317 35.67121681301555 139.73831545168224 37.317</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5dee91fd-922b-47a2-9172-48b2cef5857a">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67120564448911 139.7383376460353 37.317 35.67119797570369 139.73834005218436 37.317 35.671195677547146 139.73832906376757 37.317 35.67120333731864 139.7383266576282 37.317 35.67120564448911 139.7383376460353 37.317</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-252e7246-40f5-4e76-8236-e159b2c6e1c6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-252e7246-40f5-4e76-8236-e159b2c6e1c6_0">
											<gml:posList>35.67120878974922 139.7383141245797 37.317 35.67121596289279 139.73831186261808 37.317 35.67121596289279 139.73831186261808 39.383 35.67120878974922 139.7383141245797 39.383 35.67120878974922 139.7383141245797 37.317</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7d0be740-9cda-4d8f-979c-dbefb3fcd7db">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7d0be740-9cda-4d8f-979c-dbefb3fcd7db_0">
											<gml:posList>35.67115766526314 139.7382245439068 41.696 35.6711415167933 139.73822977694695 41.696 35.6711415167933 139.73822977694695 42.706 35.67115766526314 139.7382245439068 42.706 35.67115766526314 139.7382245439068 41.696</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-67c43c6a-fdfb-40ef-bde6-a4bb1044c588">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-67c43c6a-fdfb-40ef-bde6-a4bb1044c588_0">
											<gml:posList>35.6711415167933 139.73822977694695 42.706 35.671146610142934 139.7382533548941 42.706 35.67116275861379 139.73824812185836 42.706 35.67115766526314 139.7382245439068 42.706 35.6711415167933 139.73822977694695 42.706</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-939d34fd-4274-4fe0-a457-f77b750cb59d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-939d34fd-4274-4fe0-a457-f77b750cb59d_0">
											<gml:posList>35.671146610142934 139.7382533548941 41.696 35.671146610142934 139.7382533548941 42.706 35.6711415167933 139.73822977694695 42.706 35.6711415167933 139.73822977694695 41.696 35.671146610142934 139.7382533548941 41.696</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8d48a9e4-5480-4ff5-b5be-d38c7fe488c2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8d48a9e4-5480-4ff5-b5be-d38c7fe488c2_0">
											<gml:posList>35.671146610142934 139.7382533548941 41.696 35.67116275861379 139.73824812185836 41.696 35.67116275861379 139.73824812185836 42.706 35.671146610142934 139.7382533548941 42.706 35.671146610142934 139.7382533548941 41.696</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ec8e9b9b-6c5e-404e-9935-b78e5dc5f6c5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ec8e9b9b-6c5e-404e-9935-b78e5dc5f6c5_0">
											<gml:posList>35.67115629900585 139.73828647145615 37.317 35.671161962414224 139.73831284346647 37.317 35.671161962414224 139.73831284346647 39.686 35.67115629900585 139.73828647145615 39.686 35.67115629900585 139.73828647145615 37.317</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3eefcc03-0eb9-4d64-bb36-dbb89ce1cce0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3eefcc03-0eb9-4d64-bb36-dbb89ce1cce0_0">
											<gml:posList>35.67116275861379 139.73824812185836 41.696 35.67115766526314 139.7382245439068 41.696 35.67115766526314 139.7382245439068 42.706 35.67116275861379 139.73824812185836 42.706 35.67116275861379 139.73824812185836 41.696</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-47258387-9110-4de0-8dfe-b2ab419ef081">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-47258387-9110-4de0-8dfe-b2ab419ef081_0">
											<gml:posList>35.67117100566645 139.73828172617598 37.317 35.67115629900585 139.73828647145615 37.317 35.67115629900585 139.73828647145615 39.686 35.67117100566645 139.73828172617598 39.686 35.67117100566645 139.73828172617598 37.317</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c0d3c90b-5d08-4e52-a519-32538bc7fae1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c0d3c90b-5d08-4e52-a519-32538bc7fae1_0">
											<gml:posList>35.671161962414224 139.73831284346647 39.686 35.67117666907587 139.73830809819077 39.686 35.67117100566645 139.73828172617598 39.686 35.67115629900585 139.73828647145615 39.686 35.671161962414224 139.73831284346647 39.686</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cdec4664-481e-4c5e-8d1b-a9922dcd1e7e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cdec4664-481e-4c5e-8d1b-a9922dcd1e7e_0">
											<gml:posList>35.67117666907587 139.73830809819077 37.317 35.67117666907587 139.73830809819077 39.686 35.671161962414224 139.73831284346647 39.686 35.671161962414224 139.73831284346647 37.317 35.67117666907587 139.73830809819077 37.317</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-97c7dcce-e369-4119-bc1b-2ff1d4f74dd0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-97c7dcce-e369-4119-bc1b-2ff1d4f74dd0_0">
											<gml:posList>35.67117666907587 139.73830809819077 37.317 35.67117100566645 139.73828172617598 37.317 35.67117100566645 139.73828172617598 39.686 35.67117666907587 139.73830809819077 39.686 35.67117666907587 139.73830809819077 37.317</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-64c9605e-e256-4c36-9503-891ff36912a5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-64c9605e-e256-4c36-9503-891ff36912a5_0">
											<gml:posList>35.671188954994825 139.73829693784128 37.317 35.671191153637224 139.73830746242663 37.317 35.671191153637224 139.73830746242663 39.383 35.671188954994825 139.73829693784128 39.383 35.671188954994825 139.73829693784128 37.317</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-160a476b-ac56-43df-b46c-19b2dfae5587">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-160a476b-ac56-43df-b46c-19b2dfae5587_0">
											<gml:posList>35.67119661476567 139.73829453169904 37.317 35.671188954994825 139.73829693784128 37.317 35.671188954994825 139.73829693784128 39.383 35.67119661476567 139.73829453169904 39.383 35.67119661476567 139.73829453169904 37.317</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-dcb9c2d1-4b06-4efb-805b-8d6170007950">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-dcb9c2d1-4b06-4efb-805b-8d6170007950_0">
											<gml:posList>35.6711920674838 139.73831184675282 37.317 35.67119430230182 139.7383225259453 37.317 35.67119430230182 139.7383225259453 39.383 35.6711920674838 139.73831184675282 39.383 35.6711920674838 139.73831184675282 37.317</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1f6581e2-6aa1-4845-9f8b-9d2b53437a84">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1f6581e2-6aa1-4845-9f8b-9d2b53437a84_0">
											<gml:posList>35.671188954994825 139.73829693784128 39.383 35.671191153637224 139.73830746242663 39.383 35.67119882242201 139.7383050562746 39.383 35.67119661476567 139.73829453169904 39.383 35.671188954994825 139.73829693784128 39.383</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b8a573d0-087d-4e58-ac80-42d658c916d4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b8a573d0-087d-4e58-ac80-42d658c916d4_0">
											<gml:posList>35.671195677547146 139.73832906376757 37.317 35.67119797570369 139.73834005218436 37.317 35.67119797570369 139.73834005218436 39.383 35.671195677547146 139.73832906376757 39.383 35.671195677547146 139.73832906376757 37.317</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-48613667-8c96-4293-a8c3-760d40dd70cc">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-48613667-8c96-4293-a8c3-760d40dd70cc_0">
											<gml:posList>35.6711920674838 139.73831184675282 39.383 35.67119430230182 139.7383225259453 39.383 35.67120197108689 139.73832011979465 39.383 35.67119973626867 139.7383094406012 39.383 35.6711920674838 139.73831184675282 39.383</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9da7258b-82a4-4ad9-92dc-6ed8a3b05e5a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9da7258b-82a4-4ad9-92dc-6ed8a3b05e5a_0">
											<gml:posList>35.67119661476567 139.73829453169904 37.317 35.67119661476567 139.73829453169904 39.383 35.67119882242201 139.7383050562746 39.383 35.67119882242201 139.7383050562746 37.317 35.67119661476567 139.73829453169904 37.317</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ed4fc25b-46f7-4721-a1fd-2739c447054a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ed4fc25b-46f7-4721-a1fd-2739c447054a_0">
											<gml:posList>35.67119430230182 139.7383225259453 37.317 35.67120197108689 139.73832011979465 37.317 35.67120197108689 139.73832011979465 39.383 35.67119430230182 139.7383225259453 39.383 35.67119430230182 139.7383225259453 37.317</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fe7daffd-36d6-400f-ac71-87384f03dd46">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fe7daffd-36d6-400f-ac71-87384f03dd46_0">
											<gml:posList>35.67120333731864 139.7383266576282 37.317 35.671195677547146 139.73832906376757 37.317 35.671195677547146 139.73832906376757 39.383 35.67120333731864 139.7383266576282 39.383 35.67120333731864 139.7383266576282 37.317</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ac8d1bda-a979-4469-8557-953f983ce61a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ac8d1bda-a979-4469-8557-953f983ce61a_0">
											<gml:posList>35.67119881589637 139.7382739496988 37.317 35.67120084300106 139.73828412100423 37.317 35.67120084300106 139.73828412100423 38.995 35.67119881589637 139.7382739496988 38.995 35.67119881589637 139.7382739496988 37.317</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d63f1c1b-4702-422a-914b-96782179d1ba">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d63f1c1b-4702-422a-914b-96782179d1ba_0">
											<gml:posList>35.671195677547146 139.73832906376757 39.383 35.67119797570369 139.73834005218436 39.383 35.67120564448911 139.7383376460353 39.383 35.67120333731864 139.7383266576282 39.383 35.671195677547146 139.73832906376757 39.383</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a694b779-35d4-48c3-a6dc-f7acb5014878">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a694b779-35d4-48c3-a6dc-f7acb5014878_0">
											<gml:posList>35.67120197108689 139.73832011979465 37.317 35.67119973626867 139.7383094406012 37.317 35.67119973626867 139.7383094406012 39.383 35.67120197108689 139.73832011979465 39.383 35.67120197108689 139.73832011979465 37.317</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cdef4031-eacb-4cbe-b492-8065ea5eb210">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cdef4031-eacb-4cbe-b492-8065ea5eb210_0">
											<gml:posList>35.67119797570369 139.73834005218436 37.317 35.67120564448911 139.7383376460353 37.317 35.67120564448911 139.7383376460353 39.383 35.67119797570369 139.73834005218436 39.383 35.67119797570369 139.73834005218436 37.317</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b3f97fd0-23af-43b2-bfe7-705bbb026f92">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b3f97fd0-23af-43b2-bfe7-705bbb026f92_0">
											<gml:posList>35.67119881589637 139.7382739496988 37.317 35.67119881589637 139.7382739496988 38.995 35.67120943155673 139.73827076680317 38.995 35.67120943155673 139.73827076680317 37.317 35.67119881589637 139.7382739496988 37.317</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e286d3e8-98df-413f-a1eb-c517141f77d4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e286d3e8-98df-413f-a1eb-c517141f77d4_0">
											<gml:posList>35.67120564448911 139.7383376460353 37.317 35.67120333731864 139.7383266576282 37.317 35.67120333731864 139.7383266576282 39.383 35.67120564448911 139.7383376460353 39.383 35.67120564448911 139.7383376460353 37.317</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d27671b4-3415-4390-8440-d86043eefeb4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d27671b4-3415-4390-8440-d86043eefeb4_0">
											<gml:posList>35.671203614372516 139.73828938683846 37.317 35.67120576775518 139.73829966845895 37.317 35.67120576775518 139.73829966845895 39.383 35.671203614372516 139.73828938683846 39.383 35.671203614372516 139.73828938683846 37.317</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-97880503-e35d-49ca-afff-a3c6dcd455bd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-97880503-e35d-49ca-afff-a3c6dcd455bd_0">
											<gml:posList>35.67121145867042 139.73828094915623 38.995 35.67120943155673 139.73827076680317 38.995 35.67119881589637 139.7382739496988 38.995 35.67120084300106 139.73828412100423 38.995 35.67121145867042 139.73828094915623 38.995</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6fe8da80-7a6a-477f-827f-5d7c44afd3c6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6fe8da80-7a6a-477f-827f-5d7c44afd3c6_0">
											<gml:posList>35.67120084300106 139.73828412100423 37.317 35.67121145867042 139.73828094915623 37.317 35.67121145867042 139.73828094915623 38.995 35.67120084300106 139.73828412100423 38.995 35.67120084300106 139.73828412100423 37.317</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c830a938-96f4-4084-b02b-2836c5a4cfb9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c830a938-96f4-4084-b02b-2836c5a4cfb9_0">
											<gml:posList>35.67121078751562 139.7382871248748 37.317 35.671203614372516 139.73828938683846 37.317 35.671203614372516 139.73828938683846 39.383 35.67121078751562 139.7382871248748 39.383 35.67121078751562 139.7382871248748 37.317</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fd95d882-77e7-43b5-b70f-6800d27622b8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fd95d882-77e7-43b5-b70f-6800d27622b8_0">
											<gml:posList>35.67120666348741 139.7383039423436 37.317 35.67120878974922 139.7383141245797 37.317 35.67120878974922 139.7383141245797 39.383 35.67120666348741 139.7383039423436 39.383 35.67120666348741 139.7383039423436 37.317</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c6da52d1-9778-4479-80a3-c529b0ca1331">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c6da52d1-9778-4479-80a3-c529b0ca1331_0">
											<gml:posList>35.67121078751562 139.7382871248748 39.383 35.671203614372516 139.73828938683846 39.383 35.67120576775518 139.73829966845895 39.383 35.67121294090719 139.73829741754253 39.383 35.67121078751562 139.7382871248748 39.383</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2ca81fd2-1a13-4bd2-b1df-288298736e70">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2ca81fd2-1a13-4bd2-b1df-288298736e70_0">
											<gml:posList>35.67120576775518 139.73829966845895 37.317 35.67121294090719 139.73829741754253 37.317 35.67121294090719 139.73829741754253 39.383 35.67120576775518 139.73829966845895 39.383 35.67120576775518 139.73829966845895 37.317</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6b1ff567-e368-45e1-aa6a-757940e8e016">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6b1ff567-e368-45e1-aa6a-757940e8e016_0">
											<gml:posList>35.67121383663951 139.73830169142752 37.317 35.67120666348741 139.7383039423436 37.317 35.67120666348741 139.7383039423436 39.383 35.67121383663951 139.73830169142752 39.383 35.67121383663951 139.73830169142752 37.317</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b50c32fa-1934-4144-bf13-8a6311e67e16">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b50c32fa-1934-4144-bf13-8a6311e67e16_0">
											<gml:posList>35.67121145867042 139.73828094915623 37.317 35.67120943155673 139.73827076680317 37.317 35.67120943155673 139.73827076680317 38.995 35.67121145867042 139.73828094915623 38.995 35.67121145867042 139.73828094915623 37.317</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8d6a141c-4335-4cab-8fca-5eb90c91fb18">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8d6a141c-4335-4cab-8fca-5eb90c91fb18_0">
											<gml:posList>35.671209540738424 139.7383177358538 37.317 35.671211875072885 139.73832887887855 37.317 35.671211875072885 139.73832887887855 39.383 35.671209540738424 139.7383177358538 39.383 35.671209540738424 139.7383177358538 37.317</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f4751395-9681-4ee4-9b7c-932b636dfee9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f4751395-9681-4ee4-9b7c-932b636dfee9_0">
											<gml:posList>35.67121383663951 139.73830169142752 39.383 35.67120666348741 139.7383039423436 39.383 35.67120878974922 139.7383141245797 39.383 35.67121596289279 139.73831186261808 39.383 35.67121383663951 139.73830169142752 39.383</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7cf9c377-bb6d-4df0-baf5-63cd750d5dca">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7cf9c377-bb6d-4df0-baf5-63cd750d5dca_0">
											<gml:posList>35.67121294090719 139.73829741754253 37.317 35.67121078751562 139.7382871248748 37.317 35.67121078751562 139.7382871248748 39.383 35.67121294090719 139.73829741754253 39.383 35.67121294090719 139.73829741754253 37.317</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-340cf2a7-be36-47c8-a8af-777924bdffe7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-340cf2a7-be36-47c8-a8af-777924bdffe7_0">
											<gml:posList>35.67121681301555 139.73831545168224 37.317 35.671209540738424 139.7383177358538 37.317 35.671209540738424 139.7383177358538 39.383 35.67121681301555 139.73831545168224 39.383 35.67121681301555 139.73831545168224 37.317</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-acf14199-f393-499e-a298-b9342d627529">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-acf14199-f393-499e-a298-b9342d627529_0">
											<gml:posList>35.671211875072885 139.73832887887855 39.383 35.67121913833651 139.73832659471861 39.383 35.67121681301555 139.73831545168224 39.383 35.671209540738424 139.7383177358538 39.383 35.671211875072885 139.73832887887855 39.383</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2cfb01f6-d7b4-406c-8260-ddcf842d4da9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2cfb01f6-d7b4-406c-8260-ddcf842d4da9_0">
											<gml:posList>35.67121596289279 139.73831186261808 37.317 35.67121383663951 139.73830169142752 37.317 35.67121383663951 139.73830169142752 39.383 35.67121596289279 139.73831186261808 39.383 35.67121596289279 139.73831186261808 37.317</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c9c919fc-bda7-4ec9-b8af-7e2549e5d385">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c9c919fc-bda7-4ec9-b8af-7e2549e5d385_0">
											<gml:posList>35.671211875072885 139.73832887887855 37.317 35.67121913833651 139.73832659471861 37.317 35.67121913833651 139.73832659471861 39.383 35.671211875072885 139.73832887887855 39.383 35.671211875072885 139.73832887887855 37.317</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-201e6acb-b3fa-4dba-8422-2f41bd27d6a2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-201e6acb-b3fa-4dba-8422-2f41bd27d6a2_0">
											<gml:posList>35.67121913833651 139.73832659471861 37.317 35.67121681301555 139.73831545168224 37.317 35.67121681301555 139.73831545168224 39.383 35.67121913833651 139.73832659471861 39.383 35.67121913833651 139.73832659471861 37.317</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-b6079967-87fc-4c57-9f6d-0746debd31ab">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b6079967-87fc-4c57-9f6d-0746debd31ab">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b6079967-87fc-4c57-9f6d-0746debd31ab">
											<gml:posList>35.6711631850851 139.73836591981137 15.2 35.671126997921824 139.73819838936168 15.2 35.67116664816949 139.73818552852683 15.2 35.671177956770386 139.7382379853597 15.2 35.67122688879862 139.7382221310041 15.2 35.671215128107995 139.7381679072582 15.2 35.67126442067546 139.73815205242443 15.2 35.67130096975906 139.73832123966912 15.2 35.6711631850851 139.73836591981137 15.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-82ac3aab-ced5-4105-a712-728ea32d48f6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-82ac3aab-ced5-4105-a712-728ea32d48f6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-82ac3aab-ced5-4105-a712-728ea32d48f6">
											<gml:posList>35.67113247122376 139.7382237011308 37.886 35.67113651734617 139.73822238181378 37.886 35.67113212059537 139.73820202858292 37.886 35.671126997921824 139.73819838936168 37.886 35.67113247122376 139.7382237011308 37.886</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-bade0fc6-a235-4d17-911d-1721f8d3a99b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bade0fc6-a235-4d17-911d-1721f8d3a99b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bade0fc6-a235-4d17-911d-1721f8d3a99b">
											<gml:posList>35.671142115117846 139.738268350141 41.991 35.67114401383845 139.73826432701296 41.991 35.671135745045454 139.73822602802983 41.991 35.67113247122376 139.7382237011308 41.991 35.671142115117846 139.738268350141 41.991</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d6389e83-2f51-4c26-89b4-959131fd7100">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d6389e83-2f51-4c26-89b4-959131fd7100">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d6389e83-2f51-4c26-89b4-959131fd7100">
											<gml:posList>35.671126997921824 139.73819838936168 37.886 35.67113212059537 139.73820202858292 37.886 35.671163669576856 139.73819179535184 37.886 35.67116664816949 139.73818552852683 37.886 35.671126997921824 139.73819838936168 37.886</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-25af8fc2-07cd-468d-83bf-65a781259211">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-25af8fc2-07cd-468d-83bf-65a781259211">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-25af8fc2-07cd-468d-83bf-65a781259211">
											<gml:posList>35.67113247122376 139.7382237011308 41.991 35.671135745045454 139.73822602802983 41.991 35.67116056249841 139.73821797892808 41.991 35.67116247023976 139.7382139668336 41.991 35.67113247122376 139.7382237011308 41.991</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-475595b4-7240-4918-bc83-60dd4130c10c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-475595b4-7240-4918-bc83-60dd4130c10c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-475595b4-7240-4918-bc83-60dd4130c10c">
											<gml:posList>35.671168831293954 139.73825627792223 41.696 35.67116056249841 139.73821797892808 41.696 35.671135745045454 139.73822602802983 41.696 35.67114401383845 139.73826432701296 41.696 35.671168831293954 139.73825627792223 41.696</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-7fb81e3a-eb22-4e0b-a87e-5b55b5a3c4c5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7fb81e3a-eb22-4e0b-a87e-5b55b5a3c4c5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7fb81e3a-eb22-4e0b-a87e-5b55b5a3c4c5">
											<gml:posList>35.671142115117846 139.738268350141 37.886 35.6711631850851 139.73836591981137 37.886 35.671166163686806 139.7383596529928 37.886 35.671146161249474 139.73826704187238 37.886 35.671142115117846 139.738268350141 37.886</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ed77dbae-4a07-4e92-a67e-fd18dd5c8890">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ed77dbae-4a07-4e92-a67e-fd18dd5c8890">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ed77dbae-4a07-4e92-a67e-fd18dd5c8890">
											<gml:posList>35.67117211413745 139.73825861585928 41.991 35.671168831293954 139.73825627792223 41.991 35.67114401383845 139.73826432701296 41.991 35.671142115117846 139.738268350141 41.991 35.67117211413745 139.73825861585928 41.991</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-9d8ac6ce-5408-4e6e-9afd-214aa326c182">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9d8ac6ce-5408-4e6e-9afd-214aa326c182">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9d8ac6ce-5408-4e6e-9afd-214aa326c182">
											<gml:posList>35.67116247023976 139.7382139668336 41.991 35.67116056249841 139.73821797892808 41.991 35.671168831293954 139.73825627792223 41.991 35.67117211413745 139.73825861585928 41.991 35.67116247023976 139.7382139668336 41.991</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ab37563b-c598-4b18-8349-e02743b92a5c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ab37563b-c598-4b18-8349-e02743b92a5c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ab37563b-c598-4b18-8349-e02743b92a5c">
											<gml:posList>35.671177956770386 139.7382379853597 37.886 35.67116664816949 139.73818552852683 37.886 35.671163669576856 139.73819179535184 37.886 35.671174969161285 139.73824425219436 37.886 35.671177956770386 139.7382379853597 37.886</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-8105ee44-a3cd-4703-b11c-37d98bc88f3e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8105ee44-a3cd-4703-b11c-37d98bc88f3e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8105ee44-a3cd-4703-b11c-37d98bc88f3e">
											<gml:posList>35.671166163686806 139.7383596529928 37.317 35.671253664600215 139.73833125956295 37.317 35.67123097516395 139.73822611389838 37.317 35.671174969161285 139.73824425219436 37.317 35.671163669576856 139.73819179535184 37.317 35.67113212059537 139.73820202858292 37.317 35.67113651734617 139.73822238181378 37.317 35.67116247023976 139.7382139668336 37.317 35.67117211413745 139.73825861585928 37.317 35.671146161249474 139.73826704187238 37.317 35.671166163686806 139.7383596529928 37.317</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-307bb8a7-4339-4487-ad81-2d29a1c147ce">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-307bb8a7-4339-4487-ad81-2d29a1c147ce">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-307bb8a7-4339-4487-ad81-2d29a1c147ce">
											<gml:posList>35.671177956770386 139.7382379853597 37.886 35.671174969161285 139.73824425219436 37.886 35.67123097516395 139.73822611389838 37.886 35.671233962763324 139.7382198360123 37.886 35.671177956770386 139.7382379853597 37.886</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-1453c345-8da8-43cf-a978-9273e5695058">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1453c345-8da8-43cf-a978-9273e5695058">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1453c345-8da8-43cf-a978-9273e5695058">
											<gml:posList>35.67125878728709 139.73833492089116 37.886 35.671253664600215 139.73833125956295 37.886 35.671166163686806 139.7383596529928 37.886 35.6711631850851 139.73836591981137 37.886 35.67125878728709 139.73833492089116 37.886</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e39dd5d1-a897-42c3-83e5-ae52c6d6cf64">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e39dd5d1-a897-42c3-83e5-ae52c6d6cf64">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e39dd5d1-a897-42c3-83e5-ae52c6d6cf64">
											<gml:posList>35.67122688879862 139.7382221310041 30.281 35.67123042127849 139.7382209890368 30.281 35.671220295885895 139.73817159061343 30.281 35.671215128107995 139.7381679072582 30.281 35.67122688879862 139.7382221310041 30.281</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-10b4f207-7280-4630-bc3a-b5dfacf3dc67">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-10b4f207-7280-4630-bc3a-b5dfacf3dc67">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-10b4f207-7280-4630-bc3a-b5dfacf3dc67">
											<gml:posList>35.671215128107995 139.7381679072582 30.281 35.671220295885895 139.73817159061343 30.281 35.67126140606467 139.7381583634866 30.281 35.67126442067546 139.73815205242443 30.281 35.671215128107995 139.7381679072582 30.281</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e1ac4779-46a8-4131-a6d2-9647e83353f4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e1ac4779-46a8-4131-a6d2-9647e83353f4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e1ac4779-46a8-4131-a6d2-9647e83353f4">
											<gml:posList>35.671233962763324 139.7382198360123 37.886 35.67123097516395 139.73822611389838 37.886 35.671253664600215 139.73833125956295 37.886 35.67125878728709 139.73833492089116 37.886 35.671233962763324 139.7382198360123 37.886</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e21b6705-4076-4251-b43f-88da54ad24df">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e21b6705-4076-4251-b43f-88da54ad24df">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e21b6705-4076-4251-b43f-88da54ad24df">
											<gml:posList>35.67123523836598 139.7382257443107 34.305 35.67123588070459 139.73822873711697 34.305 35.67125425499603 139.73822278341524 34.305 35.671256036728636 139.73821900343967 34.305 35.67123523836598 139.7382257443107 34.305</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-068a728d-f3ee-42c8-af0c-042d7d66e52e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-068a728d-f3ee-42c8-af0c-042d7d66e52e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-068a728d-f3ee-42c8-af0c-042d7d66e52e">
											<gml:posList>35.67127652826132 139.73832597439284 33.974 35.67125425499603 139.73822278341524 33.974 35.67123588070459 139.73822873711697 33.974 35.67125810875678 139.73833175138404 33.974 35.67127652826132 139.73832597439284 33.974</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e1d501d8-ad83-47be-b1b4-90f0deee8ec8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e1d501d8-ad83-47be-b1b4-90f0deee8ec8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e1d501d8-ad83-47be-b1b4-90f0deee8ec8">
											<gml:posList>35.671256036728636 139.73821900343967 29.669 35.67127852708478 139.73832315519653 29.669 35.67129579297205 139.7383175563112 29.669 35.67126140606467 139.7381583634866 29.669 35.671220295885895 139.73817159061343 29.669 35.67123042127849 139.7382209890368 29.669 35.671233962763324 139.7382198360123 29.669 35.67123523836598 139.7382257443107 29.669 35.671256036728636 139.73821900343967 29.669</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-25ec85e3-370b-4137-9e6a-988d6d6df8e2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-25ec85e3-370b-4137-9e6a-988d6d6df8e2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-25ec85e3-370b-4137-9e6a-988d6d6df8e2">
											<gml:posList>35.671256036728636 139.73821900343967 34.305 35.67125425499603 139.73822278341524 34.305 35.67127652826132 139.73832597439284 34.305 35.67127960367455 139.73832816897868 34.305 35.671256036728636 139.73821900343967 34.305</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ca47519f-a936-41ce-b4b3-f3ec086a2ecd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ca47519f-a936-41ce-b4b3-f3ec086a2ecd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ca47519f-a936-41ce-b4b3-f3ec086a2ecd">
											<gml:posList>35.67125878728709 139.73833492089116 34.305 35.67127960367455 139.73832816897868 34.305 35.67127652826132 139.73832597439284 34.305 35.67125810875678 139.73833175138404 34.305 35.67125878728709 139.73833492089116 34.305</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d5348eec-d193-4b9c-9e76-7ffaac263c99">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d5348eec-d193-4b9c-9e76-7ffaac263c99">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d5348eec-d193-4b9c-9e76-7ffaac263c99">
											<gml:posList>35.67126442067546 139.73815205242443 30.281 35.67126140606467 139.7381583634866 30.281 35.67129579297205 139.7383175563112 30.281 35.67130096975906 139.73832123966912 30.281 35.67126442067546 139.73815205242443 30.281</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-3fcc749f-14c8-4ada-ac80-383c9050420d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3fcc749f-14c8-4ada-ac80-383c9050420d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3fcc749f-14c8-4ada-ac80-383c9050420d">
											<gml:posList>35.67127960367455 139.73832816897868 30.281 35.67130096975906 139.73832123966912 30.281 35.67129579297205 139.7383175563112 30.281 35.67127852708478 139.73832315519653 30.281 35.67127960367455 139.73832816897868 30.281</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-92321980-12ba-4d44-aa30-9d2562173f0b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-92321980-12ba-4d44-aa30-9d2562173f0b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-92321980-12ba-4d44-aa30-9d2562173f0b">
											<gml:posList>35.671163669576856 139.73819179535184 37.886 35.671163669576856 139.73819179535184 37.317 35.671174969161285 139.73824425219436 37.317 35.671174969161285 139.73824425219436 37.886 35.671163669576856 139.73819179535184 37.886</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e81da36a-a651-459a-b4d8-1502a36281d3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e81da36a-a651-459a-b4d8-1502a36281d3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e81da36a-a651-459a-b4d8-1502a36281d3">
											<gml:posList>35.67116056249841 139.73821797892808 41.991 35.67116056249841 139.73821797892808 41.696 35.671168831293954 139.73825627792223 41.696 35.671168831293954 139.73825627792223 41.991 35.67116056249841 139.73821797892808 41.991</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-02315777-450a-4765-a7a2-dfda5de03e00">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-02315777-450a-4765-a7a2-dfda5de03e00">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-02315777-450a-4765-a7a2-dfda5de03e00">
											<gml:posList>35.67113651734617 139.73822238181378 37.886 35.67113651734617 139.73822238181378 37.317 35.67113212059537 139.73820202858292 37.317 35.67113212059537 139.73820202858292 37.886 35.67113651734617 139.73822238181378 37.886</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-cfdd1f71-ad7b-40c2-9244-211da3c2a42b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cfdd1f71-ad7b-40c2-9244-211da3c2a42b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cfdd1f71-ad7b-40c2-9244-211da3c2a42b">
											<gml:posList>35.67114401383845 139.73826432701296 41.991 35.67114401383845 139.73826432701296 41.696 35.671135745045454 139.73822602802983 41.696 35.671135745045454 139.73822602802983 41.991 35.67114401383845 139.73826432701296 41.991</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f17ed923-9734-44c1-8e03-eedf5d3d928b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f17ed923-9734-44c1-8e03-eedf5d3d928b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f17ed923-9734-44c1-8e03-eedf5d3d928b">
											<gml:posList>35.671142115117846 139.738268350141 37.886 35.671142115117846 139.738268350141 41.991 35.67113247122376 139.7382237011308 41.991 35.67113247122376 139.7382237011308 37.886 35.671126997921824 139.73819838936168 37.886 35.671126997921824 139.73819838936168 15.2 35.6711631850851 139.73836591981137 15.2 35.6711631850851 139.73836591981137 37.886 35.671142115117846 139.738268350141 37.886</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6e9be928-4d51-4d86-af16-24195a6bb844">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6e9be928-4d51-4d86-af16-24195a6bb844">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6e9be928-4d51-4d86-af16-24195a6bb844">
											<gml:posList>35.67116664816949 139.73818552852683 15.2 35.671126997921824 139.73819838936168 15.2 35.671126997921824 139.73819838936168 37.886 35.67116664816949 139.73818552852683 37.886 35.67116664816949 139.73818552852683 15.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-52717ec1-f473-4fb7-8b96-2f8b05f487c4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-52717ec1-f473-4fb7-8b96-2f8b05f487c4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-52717ec1-f473-4fb7-8b96-2f8b05f487c4">
											<gml:posList>35.67113651734617 139.73822238181378 37.886 35.67113247122376 139.7382237011308 37.886 35.67113247122376 139.7382237011308 41.991 35.67116247023976 139.7382139668336 41.991 35.67116247023976 139.7382139668336 37.317 35.67113651734617 139.73822238181378 37.317 35.67113651734617 139.73822238181378 37.886</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4f4e46d7-6cb8-4f22-a52d-4dbf426234da">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4f4e46d7-6cb8-4f22-a52d-4dbf426234da">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4f4e46d7-6cb8-4f22-a52d-4dbf426234da">
											<gml:posList>35.67113212059537 139.73820202858292 37.886 35.67113212059537 139.73820202858292 37.317 35.671163669576856 139.73819179535184 37.317 35.671163669576856 139.73819179535184 37.886 35.67113212059537 139.73820202858292 37.886</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c3306a56-4757-409f-b6af-ed409e28c023">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c3306a56-4757-409f-b6af-ed409e28c023">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c3306a56-4757-409f-b6af-ed409e28c023">
											<gml:posList>35.671135745045454 139.73822602802983 41.991 35.671135745045454 139.73822602802983 41.696 35.67116056249841 139.73821797892808 41.696 35.67116056249841 139.73821797892808 41.991 35.671135745045454 139.73822602802983 41.991</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-92e485d2-c0b8-43b8-9c5a-89a683672412">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-92e485d2-c0b8-43b8-9c5a-89a683672412">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-92e485d2-c0b8-43b8-9c5a-89a683672412">
											<gml:posList>35.671166163686806 139.7383596529928 37.886 35.671166163686806 139.7383596529928 37.317 35.671146161249474 139.73826704187238 37.317 35.671146161249474 139.73826704187238 37.886 35.671166163686806 139.7383596529928 37.886</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c7b4fd9c-a9fb-455e-a647-617f4ae60f86">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c7b4fd9c-a9fb-455e-a647-617f4ae60f86">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c7b4fd9c-a9fb-455e-a647-617f4ae60f86">
											<gml:posList>35.671168831293954 139.73825627792223 41.991 35.671168831293954 139.73825627792223 41.696 35.67114401383845 139.73826432701296 41.696 35.67114401383845 139.73826432701296 41.991 35.671168831293954 139.73825627792223 41.991</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-06e21cb2-9a91-4bef-a2b3-3f60c7e93c7a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-06e21cb2-9a91-4bef-a2b3-3f60c7e93c7a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-06e21cb2-9a91-4bef-a2b3-3f60c7e93c7a">
											<gml:posList>35.671142115117846 139.738268350141 41.991 35.671142115117846 139.738268350141 37.886 35.671146161249474 139.73826704187238 37.886 35.671146161249474 139.73826704187238 37.317 35.67117211413745 139.73825861585928 37.317 35.67117211413745 139.73825861585928 41.991 35.671142115117846 139.738268350141 41.991</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-164abf35-759d-41fb-8304-8ede3fe61388">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-164abf35-759d-41fb-8304-8ede3fe61388">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-164abf35-759d-41fb-8304-8ede3fe61388">
											<gml:posList>35.67116247023976 139.7382139668336 41.991 35.67117211413745 139.73825861585928 41.991 35.67117211413745 139.73825861585928 37.317 35.67116247023976 139.7382139668336 37.317 35.67116247023976 139.7382139668336 41.991</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c55f683c-482c-4e62-92ec-ea1adc58a890">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c55f683c-482c-4e62-92ec-ea1adc58a890">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c55f683c-482c-4e62-92ec-ea1adc58a890">
											<gml:posList>35.671177956770386 139.7382379853597 15.2 35.67116664816949 139.73818552852683 15.2 35.67116664816949 139.73818552852683 37.886 35.671177956770386 139.7382379853597 37.886 35.671177956770386 139.7382379853597 15.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ca6bb374-e088-4f7c-b8de-085b97a8186d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ca6bb374-e088-4f7c-b8de-085b97a8186d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ca6bb374-e088-4f7c-b8de-085b97a8186d">
											<gml:posList>35.671174969161285 139.73824425219436 37.886 35.671174969161285 139.73824425219436 37.317 35.67123097516395 139.73822611389838 37.317 35.67123097516395 139.73822611389838 37.886 35.671174969161285 139.73824425219436 37.886</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7795e9cc-bc30-4d7e-bc8e-90818109e0f1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7795e9cc-bc30-4d7e-bc8e-90818109e0f1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7795e9cc-bc30-4d7e-bc8e-90818109e0f1">
											<gml:posList>35.67122688879862 139.7382221310041 30.281 35.67122688879862 139.7382221310041 15.2 35.671177956770386 139.7382379853597 15.2 35.671177956770386 139.7382379853597 37.886 35.671233962763324 139.7382198360123 37.886 35.671233962763324 139.7382198360123 29.669 35.67123042127849 139.7382209890368 29.669 35.67123042127849 139.7382209890368 30.281 35.67122688879862 139.7382221310041 30.281</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c67c383f-7898-411e-8e07-3008dd750f10">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c67c383f-7898-411e-8e07-3008dd750f10">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c67c383f-7898-411e-8e07-3008dd750f10">
											<gml:posList>35.671253664600215 139.73833125956295 37.886 35.671253664600215 139.73833125956295 37.317 35.671166163686806 139.7383596529928 37.317 35.671166163686806 139.7383596529928 37.886 35.671253664600215 139.73833125956295 37.886</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-532bd4f1-bef1-4260-b093-c1068c835d38">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-532bd4f1-bef1-4260-b093-c1068c835d38">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-532bd4f1-bef1-4260-b093-c1068c835d38">
											<gml:posList>35.671215128107995 139.7381679072582 15.2 35.67122688879862 139.7382221310041 15.2 35.67122688879862 139.7382221310041 30.281 35.671215128107995 139.7381679072582 30.281 35.671215128107995 139.7381679072582 15.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d99c5386-73b3-413c-9e2f-f88cc0bf5bd0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d99c5386-73b3-413c-9e2f-f88cc0bf5bd0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d99c5386-73b3-413c-9e2f-f88cc0bf5bd0">
											<gml:posList>35.67123042127849 139.7382209890368 30.281 35.67123042127849 139.7382209890368 29.669 35.671220295885895 139.73817159061343 29.669 35.671220295885895 139.73817159061343 30.281 35.67123042127849 139.7382209890368 30.281</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5ca15b96-cfff-4a27-b317-aa39fede4403">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5ca15b96-cfff-4a27-b317-aa39fede4403">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5ca15b96-cfff-4a27-b317-aa39fede4403">
											<gml:posList>35.67127960367455 139.73832816897868 30.281 35.67127960367455 139.73832816897868 34.305 35.67125878728709 139.73833492089116 34.305 35.67125878728709 139.73833492089116 37.886 35.6711631850851 139.73836591981137 37.886 35.6711631850851 139.73836591981137 15.2 35.67130096975906 139.73832123966912 15.2 35.67130096975906 139.73832123966912 30.281 35.67127960367455 139.73832816897868 30.281</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a50e5d22-cec9-4c3b-835f-f5507d4438bd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a50e5d22-cec9-4c3b-835f-f5507d4438bd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a50e5d22-cec9-4c3b-835f-f5507d4438bd">
											<gml:posList>35.67126442067546 139.73815205242443 15.2 35.671215128107995 139.7381679072582 15.2 35.671215128107995 139.7381679072582 30.281 35.67126442067546 139.73815205242443 30.281 35.67126442067546 139.73815205242443 15.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-434ab18a-e73a-4e4f-b6c1-e5ad149d1fb8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-434ab18a-e73a-4e4f-b6c1-e5ad149d1fb8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-434ab18a-e73a-4e4f-b6c1-e5ad149d1fb8">
											<gml:posList>35.671220295885895 139.73817159061343 30.281 35.671220295885895 139.73817159061343 29.669 35.67126140606467 139.7381583634866 29.669 35.67126140606467 139.7381583634866 30.281 35.671220295885895 139.73817159061343 30.281</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d27264bc-a36b-46fe-8635-66ba216a8b8c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d27264bc-a36b-46fe-8635-66ba216a8b8c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d27264bc-a36b-46fe-8635-66ba216a8b8c">
											<gml:posList>35.67123097516395 139.73822611389838 37.886 35.67123097516395 139.73822611389838 37.317 35.671253664600215 139.73833125956295 37.317 35.671253664600215 139.73833125956295 37.886 35.67123097516395 139.73822611389838 37.886</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-314de9d9-5c6c-4016-9b91-44927be000a6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-314de9d9-5c6c-4016-9b91-44927be000a6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-314de9d9-5c6c-4016-9b91-44927be000a6">
											<gml:posList>35.67123588070459 139.73822873711697 34.305 35.67123588070459 139.73822873711697 33.974 35.67125425499603 139.73822278341524 33.974 35.67125425499603 139.73822278341524 34.305 35.67123588070459 139.73822873711697 34.305</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a7ca98f2-1f6c-408f-866b-a001b87e5acb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a7ca98f2-1f6c-408f-866b-a001b87e5acb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a7ca98f2-1f6c-408f-866b-a001b87e5acb">
											<gml:posList>35.67123523836598 139.7382257443107 34.305 35.671256036728636 139.73821900343967 34.305 35.671256036728636 139.73821900343967 29.669 35.67123523836598 139.7382257443107 29.669 35.67123523836598 139.7382257443107 34.305</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e0e5d7ce-8722-4406-ad8b-4ad5bb567456">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e0e5d7ce-8722-4406-ad8b-4ad5bb567456">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e0e5d7ce-8722-4406-ad8b-4ad5bb567456">
											<gml:posList>35.67125810875678 139.73833175138404 34.305 35.67125810875678 139.73833175138404 33.974 35.67123588070459 139.73822873711697 33.974 35.67123588070459 139.73822873711697 34.305 35.67123523836598 139.7382257443107 34.305 35.67123523836598 139.7382257443107 29.669 35.671233962763324 139.7382198360123 29.669 35.671233962763324 139.7382198360123 37.886 35.67125878728709 139.73833492089116 37.886 35.67125878728709 139.73833492089116 34.305 35.67125810875678 139.73833175138404 34.305</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-bb512e6d-1179-42dc-971d-e328c5aed0fa">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bb512e6d-1179-42dc-971d-e328c5aed0fa">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bb512e6d-1179-42dc-971d-e328c5aed0fa">
											<gml:posList>35.67125425499603 139.73822278341524 34.305 35.67125425499603 139.73822278341524 33.974 35.67127652826132 139.73832597439284 33.974 35.67127652826132 139.73832597439284 34.305 35.67125425499603 139.73822278341524 34.305</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4a5e9f31-4330-4681-91f2-6e4c02e425c2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4a5e9f31-4330-4681-91f2-6e4c02e425c2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4a5e9f31-4330-4681-91f2-6e4c02e425c2">
											<gml:posList>35.67127652826132 139.73832597439284 34.305 35.67127652826132 139.73832597439284 33.974 35.67125810875678 139.73833175138404 33.974 35.67125810875678 139.73833175138404 34.305 35.67127652826132 139.73832597439284 34.305</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-10faa212-c0cb-4c02-830b-746caa14f68f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-10faa212-c0cb-4c02-830b-746caa14f68f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-10faa212-c0cb-4c02-830b-746caa14f68f">
											<gml:posList>35.671256036728636 139.73821900343967 29.669 35.671256036728636 139.73821900343967 34.305 35.67127960367455 139.73832816897868 34.305 35.67127960367455 139.73832816897868 30.281 35.67127852708478 139.73832315519653 30.281 35.67127852708478 139.73832315519653 29.669 35.671256036728636 139.73821900343967 29.669</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-afb1800c-08a5-4e5e-b30f-a8ac07dffadc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-afb1800c-08a5-4e5e-b30f-a8ac07dffadc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-afb1800c-08a5-4e5e-b30f-a8ac07dffadc">
											<gml:posList>35.67126140606467 139.7381583634866 30.281 35.67126140606467 139.7381583634866 29.669 35.67129579297205 139.7383175563112 29.669 35.67129579297205 139.7383175563112 30.281 35.67126140606467 139.7381583634866 30.281</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a9511f14-ce5b-44e9-9d75-28fcab2c040f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a9511f14-ce5b-44e9-9d75-28fcab2c040f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a9511f14-ce5b-44e9-9d75-28fcab2c040f">
											<gml:posList>35.67130096975906 139.73832123966912 15.2 35.67126442067546 139.73815205242443 15.2 35.67126442067546 139.73815205242443 30.281 35.67130096975906 139.73832123966912 30.281 35.67130096975906 139.73832123966912 15.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-36119acf-92d6-4372-ade6-1b7075cbaed9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-36119acf-92d6-4372-ade6-1b7075cbaed9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-36119acf-92d6-4372-ade6-1b7075cbaed9">
											<gml:posList>35.67129579297205 139.7383175563112 30.281 35.67129579297205 139.7383175563112 29.669 35.67127852708478 139.73832315519653 29.669 35.67127852708478 139.73832315519653 30.281 35.67129579297205 139.7383175563112 30.281</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-11658</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">221.4128</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1210</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>4</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.02</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>