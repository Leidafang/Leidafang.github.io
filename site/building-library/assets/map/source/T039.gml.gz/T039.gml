<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_0969e0d8-ae76-4eeb-ae49-d73bb27a0f28">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">413</bldg:usage>
			<bldg:measuredHeight uom="m">18.8</bldg:measuredHeight>
			<bldg:storeysAboveGround>7</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>1</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.672190795364344 139.73853769090388 0 35.67220123049122 139.73851127740613 0 35.672163106283556 139.73837891908917 0 35.67204354398664 139.73843074721523 0 35.672170959197175 139.7388741909308 0 35.6722745818672 139.73882933043478 0 35.672190795364344 139.73853769090388 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672190795364344 139.73853769090388 9.735 35.6722745818672 139.73882933043478 9.735 35.672170959197175 139.7388741909308 9.735 35.67204354398664 139.73843074721523 9.735 35.672163106283556 139.73837891908917 9.735 35.67220123049122 139.73851127740613 9.735 35.672190795364344 139.73853769090388 9.735</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672190795364344 139.73853769090388 9.735 35.67220123049122 139.73851127740613 9.735 35.67220123049122 139.73851127740613 27.04 35.672190795364344 139.73853769090388 27.04 35.672190795364344 139.73853769090388 9.735</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67220123049122 139.73851127740613 9.735 35.672163106283556 139.73837891908917 9.735 35.672163106283556 139.73837891908917 27.04 35.67220123049122 139.73851127740613 27.04 35.67220123049122 139.73851127740613 9.735</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672163106283556 139.73837891908917 9.735 35.67204354398664 139.73843074721523 9.735 35.67204354398664 139.73843074721523 27.04 35.672163106283556 139.73837891908917 27.04 35.672163106283556 139.73837891908917 9.735</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67204354398664 139.73843074721523 9.735 35.672170959197175 139.7388741909308 9.735 35.672170959197175 139.7388741909308 27.04 35.67204354398664 139.73843074721523 27.04 35.67204354398664 139.73843074721523 9.735</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672170959197175 139.7388741909308 9.735 35.6722745818672 139.73882933043478 9.735 35.6722745818672 139.73882933043478 27.04 35.672170959197175 139.7388741909308 27.04 35.672170959197175 139.7388741909308 9.735</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6722745818672 139.73882933043478 9.735 35.672190795364344 139.73853769090388 9.735 35.672190795364344 139.73853769090388 27.04 35.6722745818672 139.73882933043478 27.04 35.6722745818672 139.73882933043478 9.735</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672190795364344 139.73853769090388 27.04 35.67220123049122 139.73851127740613 27.04 35.672163106283556 139.73837891908917 27.04 35.67204354398664 139.73843074721523 27.04 35.672170959197175 139.7388741909308 27.04 35.6722745818672 139.73882933043478 27.04 35.672190795364344 139.73853769090388 27.04</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-f86b9140-0419-4285-a175-5e2e4a306c2b"/>
							<gml:surfaceMember xlink:href="#poly-a605c90a-218a-4530-ac0d-1c545ef36528"/>
							<gml:surfaceMember xlink:href="#poly-cc58f9c2-774a-46e9-8c5f-f60af38e4eff"/>
							<gml:surfaceMember xlink:href="#poly-74b196fe-06cd-481a-b873-1667795babf9"/>
							<gml:surfaceMember xlink:href="#poly-823c58ff-5626-4257-9efc-232e4066075b"/>
							<gml:surfaceMember xlink:href="#poly-f7d23c02-7f0e-4c3b-915a-71e0f5b5bedf"/>
							<gml:surfaceMember xlink:href="#poly-aea66972-ec3c-4a55-8d56-d486de6c293e"/>
							<gml:surfaceMember xlink:href="#poly-372fbddc-cb3c-427b-98fc-83feb2b32f60"/>
							<gml:surfaceMember xlink:href="#poly-b8eb41d6-9629-4657-bb2a-064e485f31a6"/>
							<gml:surfaceMember xlink:href="#poly-2f7c476c-d443-4dfc-91f5-830eee9a7386"/>
							<gml:surfaceMember xlink:href="#poly-cc4be829-4b0e-4702-b00e-86506341e5f6"/>
							<gml:surfaceMember xlink:href="#poly-2229368d-858d-4ed8-9154-72eab4018a7e"/>
							<gml:surfaceMember xlink:href="#poly-7b9657b6-b14a-4154-b94d-f2a27fbdbd49"/>
							<gml:surfaceMember xlink:href="#poly-2c758f7f-3c94-4381-80d9-e0d51ec61eca"/>
							<gml:surfaceMember xlink:href="#poly-476c98c9-516b-4fce-86cc-e51cb2765e77"/>
							<gml:surfaceMember xlink:href="#poly-5c9e2f9b-be32-43f4-8272-b6fa3ab527f6"/>
							<gml:surfaceMember xlink:href="#poly-1c48d4dc-2ffc-43fd-be6c-e1ab94a2e2a8"/>
							<gml:surfaceMember xlink:href="#poly-9c3943fc-a5af-4adc-ba60-18b96f74351b"/>
							<gml:surfaceMember xlink:href="#poly-62910454-a9ab-4f41-9b9c-9a25c607e293"/>
							<gml:surfaceMember xlink:href="#poly-08847b15-ed87-413d-a76e-bcc664ecd03d"/>
							<gml:surfaceMember xlink:href="#poly-6a15a8d3-a40b-434c-91b8-374d1c2e2f69"/>
							<gml:surfaceMember xlink:href="#poly-c026b5d3-be9f-42b4-8054-95c0d6a43301"/>
							<gml:surfaceMember xlink:href="#poly-3b43a73c-05c4-4066-ad81-d86cd392d347"/>
							<gml:surfaceMember xlink:href="#poly-a4b96bd1-52eb-40a0-8f05-7507023cbe9a"/>
							<gml:surfaceMember xlink:href="#poly-4204ec6b-05d1-4889-bf5d-51b63db1311b"/>
							<gml:surfaceMember xlink:href="#poly-5bf35363-3666-4e4a-89de-11309ef6a787"/>
							<gml:surfaceMember xlink:href="#poly-d59921b1-9121-4a4e-b3fd-f7bd06ad7a5c"/>
							<gml:surfaceMember xlink:href="#poly-598bb418-e929-43c3-9e81-74b80e0a26dc"/>
							<gml:surfaceMember xlink:href="#poly-2db8c4b9-06ed-4ee1-98fd-0000e085d20f"/>
							<gml:surfaceMember xlink:href="#poly-1713211b-a2a2-444f-89e5-a7cadf83a12b"/>
							<gml:surfaceMember xlink:href="#poly-64925935-3879-40de-9e3e-3013423b2039"/>
							<gml:surfaceMember xlink:href="#poly-437cc0b7-e98c-492e-b68f-eaece0166d54"/>
							<gml:surfaceMember xlink:href="#poly-ab60a91e-1742-4d0b-afe4-7c261ab746c2"/>
							<gml:surfaceMember xlink:href="#poly-a029a89b-57e5-4e29-9ed0-9b1e24b5eb72"/>
							<gml:surfaceMember xlink:href="#poly-ba323c16-9c37-4307-8d0b-3aec746a1b55"/>
							<gml:surfaceMember xlink:href="#poly-54ed9ef5-a9d4-4337-a201-e84b80c08b03"/>
							<gml:surfaceMember xlink:href="#poly-4aaa0428-bae0-415e-bdb5-3f10bf355f01"/>
							<gml:surfaceMember xlink:href="#poly-f75a29b5-519a-40b9-8491-cd3817d0cc23"/>
							<gml:surfaceMember xlink:href="#poly-28c9dab2-f57a-43a3-ab4c-07b4ff68f0d8"/>
							<gml:surfaceMember xlink:href="#poly-07f02880-29f1-401d-b8f6-7be65b8ed6a9"/>
							<gml:surfaceMember xlink:href="#poly-590ffd0c-14cd-4c48-94bc-65c22f7e9242"/>
							<gml:surfaceMember xlink:href="#poly-dbccf851-d8e4-4c5e-9d06-0aecfff1002f"/>
							<gml:surfaceMember xlink:href="#poly-4e14e57f-449f-41e3-b425-3da5b137682e"/>
							<gml:surfaceMember xlink:href="#poly-8e1dc489-ed52-40cc-88a9-a310c9c0acba"/>
							<gml:surfaceMember xlink:href="#poly-a6227a0f-298b-4d28-a1a6-7593c9844fb9"/>
							<gml:surfaceMember xlink:href="#poly-f3471570-59b2-4a17-b402-6f4ebb61017b"/>
							<gml:surfaceMember xlink:href="#poly-8e717676-3437-4f83-81a6-cb26290c46d0"/>
							<gml:surfaceMember xlink:href="#poly-55a050a4-1da7-44f3-8d35-8ca412869841"/>
							<gml:surfaceMember xlink:href="#poly-8f178cda-3e91-4d15-9401-527865672bd4"/>
							<gml:surfaceMember xlink:href="#poly-f68a1580-3b5f-41fc-8b45-deb86494fb08"/>
							<gml:surfaceMember xlink:href="#poly-612c24c8-d2de-4a58-a914-02a4b45ba3b6"/>
							<gml:surfaceMember xlink:href="#poly-ce7b7eed-35a6-46a3-94f0-57a1d0ed6f7c"/>
							<gml:surfaceMember xlink:href="#poly-62911140-6650-4e19-b9b7-f085cc333210"/>
							<gml:surfaceMember xlink:href="#poly-d909fd4c-e3ae-48fd-a991-f1bb26506083"/>
							<gml:surfaceMember xlink:href="#poly-eb9ea735-c863-425d-b598-ef5f4937010b"/>
							<gml:surfaceMember xlink:href="#poly-e721cc7b-1022-47c5-b883-5a991b2db052"/>
							<gml:surfaceMember xlink:href="#poly-537cc499-9439-448a-8abe-470578e915f7"/>
							<gml:surfaceMember xlink:href="#poly-b9ec06e3-f696-419d-b5cd-7bfa6ac23623"/>
							<gml:surfaceMember xlink:href="#poly-c413b076-d220-4645-a401-1d9f167fd70c"/>
							<gml:surfaceMember xlink:href="#poly-0c527561-67a9-49e6-8f90-b11d0982eb3f"/>
							<gml:surfaceMember xlink:href="#poly-ed99de09-22cb-4b85-b3fb-518753c61e19"/>
							<gml:surfaceMember xlink:href="#poly-13bc0145-270c-497c-b86d-7c32a1dd22dd"/>
							<gml:surfaceMember xlink:href="#poly-bb21fabf-a831-4fcc-b5bc-6f2815216667"/>
							<gml:surfaceMember xlink:href="#poly-51636d27-6613-43af-8fe6-3897e828034b"/>
							<gml:surfaceMember xlink:href="#poly-fe115526-890d-42f8-bbc0-82bdd04b7af3"/>
							<gml:surfaceMember xlink:href="#poly-16636d49-61eb-4d76-8ee9-054824d52275"/>
							<gml:surfaceMember xlink:href="#poly-9ea92823-9fe8-4679-83fb-d35814c867b5"/>
							<gml:surfaceMember xlink:href="#poly-c9e73730-6c6c-4ca4-83f2-80570d917bba"/>
							<gml:surfaceMember xlink:href="#poly-78906229-2f7f-42fd-bf3b-a01980023adb"/>
							<gml:surfaceMember xlink:href="#poly-5db17e61-a57e-415b-8545-a01fc3eae5e7"/>
							<gml:surfaceMember xlink:href="#poly-1ec5a710-17e6-44c3-9b62-2a47cf64749b"/>
							<gml:surfaceMember xlink:href="#poly-46990757-a9a7-4558-8889-554d799c9c84"/>
							<gml:surfaceMember xlink:href="#poly-5f8039e8-ced7-4079-aec5-fc5efb736a31"/>
							<gml:surfaceMember xlink:href="#poly-69471c75-4fce-4627-9db2-fe68b852869c"/>
							<gml:surfaceMember xlink:href="#poly-80d1b9f5-679b-4b55-bf61-3a353d6b2d52"/>
							<gml:surfaceMember xlink:href="#poly-7bff1361-a563-4050-ac21-baeb587f76d2"/>
							<gml:surfaceMember xlink:href="#poly-cce7351a-4b3a-4742-9913-b78beeee688a"/>
							<gml:surfaceMember xlink:href="#poly-b8a72155-ed9f-40e4-bbd7-a08030fbfce5"/>
							<gml:surfaceMember xlink:href="#poly-5a71e336-fe10-4fb0-bdd3-d20e91e52a40"/>
							<gml:surfaceMember xlink:href="#poly-8a251f14-122c-44e0-8902-dab284cbcde1"/>
							<gml:surfaceMember xlink:href="#poly-82ba17ad-64ce-488e-9b83-18ef07002d53"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_0969e0d8-ae76-4eeb-ae49-d73bb27a0f28_BuildingInstallation_1033">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3c1989c8-f986-4624-8bed-1e9ec11cf0d5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67211722212417 139.73853363545982 29.484 35.67210951405919 139.73854339863152 29.484 35.67210623901791 139.7385395141367 29.484 35.67211394708257 139.73852975096503 29.484 35.67211722212417 139.73853363545982 29.484</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-25b1b341-8e4d-4dc5-9056-6153396c4859">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-25b1b341-8e4d-4dc5-9056-6153396c4859_0">
											<gml:posList>35.67210951405919 139.73854339863152 29.484 35.67210951405919 139.73854339863152 32.212 35.67210623901791 139.7385395141367 32.212 35.67210623901791 139.7385395141367 29.484 35.67210951405919 139.73854339863152 29.484</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-796374ad-115a-4766-aaa2-e64a77c4362a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-796374ad-115a-4766-aaa2-e64a77c4362a_0">
											<gml:posList>35.67210623901791 139.7385395141367 29.484 35.67210623901791 139.7385395141367 32.212 35.67211394708257 139.73852975096503 32.212 35.67211394708257 139.73852975096503 29.484 35.67210623901791 139.7385395141367 29.484</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c8f35b45-52df-4e35-805f-980cec7bda16">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c8f35b45-52df-4e35-805f-980cec7bda16_0">
											<gml:posList>35.67210623901791 139.7385395141367 32.212 35.67210951405919 139.73854339863152 32.212 35.67211722212417 139.73853363545982 32.212 35.67211394708257 139.73852975096503 32.212 35.67210623901791 139.7385395141367 32.212</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b270dcc7-9191-4ebc-b9c4-fa4f302679a2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b270dcc7-9191-4ebc-b9c4-fa4f302679a2_0">
											<gml:posList>35.67211722212417 139.73853363545982 29.484 35.67211722212417 139.73853363545982 32.212 35.67210951405919 139.73854339863152 32.212 35.67210951405919 139.73854339863152 29.484 35.67211722212417 139.73853363545982 29.484</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0ed0919f-b4f8-4c07-9593-6316d4863cbb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0ed0919f-b4f8-4c07-9593-6316d4863cbb_0">
											<gml:posList>35.67211394708257 139.73852975096503 32.212 35.67211722212417 139.73853363545982 32.212 35.67211722212417 139.73853363545982 29.484 35.67211394708257 139.73852975096503 29.484 35.67211394708257 139.73852975096503 32.212</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_0969e0d8-ae76-4eeb-ae49-d73bb27a0f28_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2928cd9a-1fcc-40e4-84e8-56045b0302a7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672108579035644 139.73855790378806 29.484 35.67212193286411 139.7385521659153 29.484 35.6721264250811 139.7385679129133 29.484 35.672113080256935 139.73857363972664 29.484 35.672108579035644 139.73855790378806 29.484</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7ba52616-e0a1-4ab1-adc7-b4a2e65b40ae">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7ba52616-e0a1-4ab1-adc7-b4a2e65b40ae_0">
											<gml:posList>35.672113080256935 139.73857363972664 29.484 35.672113080256935 139.73857363972664 30.793 35.672108579035644 139.73855790378806 30.793 35.672108579035644 139.73855790378806 29.484 35.672113080256935 139.73857363972664 29.484</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8cc9d34a-cb52-41c0-8693-7fb9e8289926">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8cc9d34a-cb52-41c0-8693-7fb9e8289926_0">
											<gml:posList>35.672108579035644 139.73855790378806 29.484 35.672108579035644 139.73855790378806 30.793 35.67212193286411 139.7385521659153 30.793 35.67212193286411 139.7385521659153 29.484 35.672108579035644 139.73855790378806 29.484</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5e9599a1-b941-41df-b044-3b377062a595">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5e9599a1-b941-41df-b044-3b377062a595_0">
											<gml:posList>35.672108579035644 139.73855790378806 30.793 35.672113080256935 139.73857363972664 30.793 35.6721264250811 139.7385679129133 30.793 35.67212193286411 139.7385521659153 30.793 35.672108579035644 139.73855790378806 30.793</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-63c2949b-c762-42ad-b205-c008639b963c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-63c2949b-c762-42ad-b205-c008639b963c_0">
											<gml:posList>35.6721264250811 139.7385679129133 29.484 35.6721264250811 139.7385679129133 30.793 35.672113080256935 139.73857363972664 30.793 35.672113080256935 139.73857363972664 29.484 35.6721264250811 139.7385679129133 29.484</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-76fbb8f1-ca22-46ad-b4b0-7b19bdd14ae7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-76fbb8f1-ca22-46ad-b4b0-7b19bdd14ae7_0">
											<gml:posList>35.67212193286411 139.7385521659153 30.793 35.6721264250811 139.7385679129133 30.793 35.6721264250811 139.7385679129133 29.484 35.67212193286411 139.7385521659153 29.484 35.67212193286411 139.7385521659153 30.793</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_0969e0d8-ae76-4eeb-ae49-d73bb27a0f28_BuildingInstallation_1061">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-92e8a00b-059e-4f07-9abb-1c8ed7bf8b06">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67218256946539 139.7388404743568 24.921 35.67218858849949 139.7388607265591 24.921 35.6722634584085 139.7388286697091 24.921 35.67225767344828 139.73880806372574 24.921 35.67225967380892 139.73880718869233 24.921 35.67226618147078 139.73882983743025 24.921 35.67218713990802 139.73886406431157 24.921 35.672180100538434 139.73884153773145 24.921 35.67218256946539 139.7388404743568 24.921</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e7cd3ac7-de64-4538-957c-5e9a275d367d">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67218713990802 139.73886406431157 25.001 35.67226618147078 139.73882983743025 25.001 35.67226636223068 139.73883045582224 25.001 35.672187374854055 139.7388648151973 25.001 35.67218713990802 139.73886406431157 25.001</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d7e96189-ec7b-4d40-9d0a-a3b0de099613">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d7e96189-ec7b-4d40-9d0a-a3b0de099613_0">
											<gml:posList>35.67225767344828 139.73880806372574 24.921 35.67225767344828 139.73880806372574 25.809 35.67225967380892 139.73880718869233 25.809 35.67225967380892 139.73880718869233 24.921 35.67225767344828 139.73880806372574 24.921</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-270e181d-30a6-4e31-aecb-5145054e6e50">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-270e181d-30a6-4e31-aecb-5145054e6e50_0">
											<gml:posList>35.6722634584085 139.7388286697091 24.921 35.6722634584085 139.7388286697091 25.809 35.67225767344828 139.73880806372574 25.809 35.67225767344828 139.73880806372574 24.921 35.6722634584085 139.7388286697091 24.921</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-46d41368-4d5f-429d-82b0-f1609a3aa161">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-46d41368-4d5f-429d-82b0-f1609a3aa161_0">
											<gml:posList>35.67226618147078 139.73882983743025 25.001 35.67226618147078 139.73882983743025 24.921 35.67225967380892 139.73880718869233 24.921 35.67225967380892 139.73880718869233 25.809 35.67226636223068 139.73883045582224 25.809 35.67226636223068 139.73883045582224 25.001 35.67226618147078 139.73882983743025 25.001</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-05ae174a-e375-46c4-b81c-f137ada007a0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-05ae174a-e375-46c4-b81c-f137ada007a0_0">
											<gml:posList>35.672187374854055 139.7388648151973 25.809 35.67226636223068 139.73883045582224 25.809 35.67225967380892 139.73880718869233 25.809 35.67225767344828 139.73880806372574 25.809 35.6722634584085 139.7388286697091 25.809 35.67218858849949 139.7388607265591 25.809 35.672182560451674 139.73884047436744 25.809 35.672180100538434 139.73884153773145 25.809 35.672187374854055 139.7388648151973 25.809</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-40f4ae19-c894-4ea1-af89-1c2c9effc027">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-40f4ae19-c894-4ea1-af89-1c2c9effc027_0">
											<gml:posList>35.67218256946539 139.7388404743568 24.921 35.672180100538434 139.73884153773145 24.921 35.672180100538434 139.73884153773145 25.809 35.672182560451674 139.73884047436744 25.809 35.67218256946539 139.7388404743568 24.921</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-85d0df13-a0ba-4d3d-9bf6-329bb944e1ea">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-85d0df13-a0ba-4d3d-9bf6-329bb944e1ea_0">
											<gml:posList>35.67218858849949 139.7388607265591 24.921 35.67218858849949 139.7388607265591 25.809 35.6722634584085 139.7388286697091 25.809 35.6722634584085 139.7388286697091 24.921 35.67218858849949 139.7388607265591 24.921</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4f531d1f-7f07-4d01-9645-102a1ed3b327">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4f531d1f-7f07-4d01-9645-102a1ed3b327_0">
											<gml:posList>35.67218713990802 139.73886406431157 24.921 35.67226618147078 139.73882983743025 24.921 35.67226618147078 139.73882983743025 25.001 35.67218713990802 139.73886406431157 25.001 35.67218713990802 139.73886406431157 24.921</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5cbe7e29-5f3e-485e-b18c-e51ac917ce21">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5cbe7e29-5f3e-485e-b18c-e51ac917ce21_0">
											<gml:posList>35.67226636223068 139.73883045582224 25.001 35.67226636223068 139.73883045582224 25.809 35.672187374854055 139.7388648151973 25.809 35.672187374854055 139.7388648151973 25.001 35.67226636223068 139.73883045582224 25.001</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ecfc8470-a319-4938-ae8c-eaad2e190582">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ecfc8470-a319-4938-ae8c-eaad2e190582_0">
											<gml:posList>35.67218858849949 139.7388607265591 25.809 35.67218858849949 139.7388607265591 24.921 35.67218256946539 139.7388404743568 24.921 35.672182560451674 139.73884047436744 25.809 35.67218858849949 139.7388607265591 25.809</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-691fb9b5-2560-4bf3-85d2-e68554b4ed05">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-691fb9b5-2560-4bf3-85d2-e68554b4ed05_0">
											<gml:posList>35.67218713990802 139.73886406431157 24.921 35.67218713990802 139.73886406431157 25.001 35.672187374854055 139.7388648151973 25.001 35.672187374854055 139.7388648151973 25.809 35.672180100538434 139.73884153773145 25.809 35.672180100538434 139.73884153773145 24.921 35.67218713990802 139.73886406431157 24.921</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-f86b9140-0419-4285-a175-5e2e4a306c2b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f86b9140-0419-4285-a175-5e2e4a306c2b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f86b9140-0419-4285-a175-5e2e4a306c2b">
											<gml:posList>35.672043543986646 139.73843074721523 9.735 35.67216310628354 139.73837891908917 9.735 35.6722012304912 139.7385112774061 9.735 35.67219079536432 139.73853769090388 9.735 35.67227458186716 139.73882933043478 9.735 35.672170959197175 139.7388741909308 9.735 35.672043543986646 139.73843074721523 9.735</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a605c90a-218a-4530-ac0d-1c545ef36528">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a605c90a-218a-4530-ac0d-1c545ef36528">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a605c90a-218a-4530-ac0d-1c545ef36528">
											<gml:posList>35.67206150351809 139.73849326014093 28.07 35.67206328466724 139.73848872897256 28.07 35.672060500810375 139.7384790444935 28.07 35.67205681253695 139.73847693897753 28.07 35.67206150351809 139.73849326014093 28.07</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-cc58f9c2-774a-46e9-8c5f-f60af38e4eff">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cc58f9c2-774a-46e9-8c5f-f60af38e4eff">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cc58f9c2-774a-46e9-8c5f-f60af38e4eff">
											<gml:posList>35.672066688816926 139.73849631388518 29.783 35.67206150351809 139.73849326014093 29.783 35.67208813092487 139.73858594187092 29.783 35.672091969474295 139.73858429140677 29.783 35.672066688816926 139.73849631388518 29.783</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-74b196fe-06cd-481a-b873-1667795babf9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-74b196fe-06cd-481a-b873-1667795babf9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-74b196fe-06cd-481a-b873-1667795babf9">
											<gml:posList>35.67206150351809 139.73849326014093 29.783 35.672066688816926 139.73849631388518 29.783 35.672126907091254 139.7384703275634 29.783 35.67212927273007 139.73846401721264 29.783 35.67206150351809 139.73849326014093 29.783</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-823c58ff-5626-4257-9efc-232e4066075b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-823c58ff-5626-4257-9efc-232e4066075b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-823c58ff-5626-4257-9efc-232e4066075b">
											<gml:posList>35.6720499342277 139.73845299832686 23.828 35.67205681253695 139.73847693897753 28.07 35.67214208720169 139.73843726951424 28.07 35.6720499342277 139.73845299832686 23.828</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f7d23c02-7f0e-4c3b-915a-71e0f5b5bedf">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f7d23c02-7f0e-4c3b-915a-71e0f5b5bedf">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f7d23c02-7f0e-4c3b-915a-71e0f5b5bedf">
											<gml:posList>35.67214208720169 139.73843726951424 28.07 35.672136453962196 139.73841482969155 23.828 35.6720499342277 139.73845299832686 23.828 35.67214208720169 139.73843726951424 28.07</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-aea66972-ec3c-4a55-8d56-d486de6c293e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-aea66972-ec3c-4a55-8d56-d486de6c293e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-aea66972-ec3c-4a55-8d56-d486de6c293e">
											<gml:posList>35.67212927273007 139.73846401721264 28.07 35.67213097278073 139.73845951927524 28.07 35.67206328466724 139.73848872897256 28.07 35.67206150351809 139.73849326014093 28.07 35.67212927273007 139.73846401721264 28.07</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-372fbddc-cb3c-427b-98fc-83feb2b32f60">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-372fbddc-cb3c-427b-98fc-83feb2b32f60">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-372fbddc-cb3c-427b-98fc-83feb2b32f60">
											<gml:posList>35.67208813092487 139.73858594187092 38.279 35.67209080923388 139.738587507308 38.279 35.672106226501484 139.7385808722365 38.279 35.67210749485421 139.73857758992781 38.279 35.67208813092487 139.73858594187092 38.279</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b8eb41d6-9629-4657-bb2a-064e485f31a6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b8eb41d6-9629-4657-bb2a-064e485f31a6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b8eb41d6-9629-4657-bb2a-064e485f31a6">
											<gml:posList>35.67205681253695 139.73847693897753 28.07 35.672060500810375 139.7384790444935 28.07 35.672140414271375 139.73844186683914 28.07 35.67214208720169 139.73843726951424 28.07 35.67205681253695 139.73847693897753 28.07</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-2f7c476c-d443-4dfc-91f5-830eee9a7386">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2f7c476c-d443-4dfc-91f5-830eee9a7386">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2f7c476c-d443-4dfc-91f5-830eee9a7386">
											<gml:posList>35.67210986843793 139.73866158469 38.279 35.67211114580657 139.73865830237176 38.279 35.67209080923388 139.738587507308 38.279 35.67208813092487 139.73858594187092 38.279 35.67210986843793 139.73866158469 38.279</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-cc4be829-4b0e-4702-b00e-86506341e5f6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cc4be829-4b0e-4702-b00e-86506341e5f6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cc4be829-4b0e-4702-b00e-86506341e5f6">
											<gml:posList>35.672043543986646 139.73843074721523 17.244 35.6720499342277 139.73845299832686 17.244 35.6721693518617 139.73840059598282 17.244 35.67216310628354 139.73837891908917 17.244 35.672043543986646 139.73843074721523 17.244</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-2229368d-858d-4ed8-9154-72eab4018a7e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2229368d-858d-4ed8-9154-72eab4018a7e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2229368d-858d-4ed8-9154-72eab4018a7e">
											<gml:posList>35.67212655406432 139.73865166732284 38.041 35.672106226501484 139.7385808722365 38.041 35.67209080923388 139.738587507308 38.041 35.67211114580657 139.73865830237176 38.041 35.67212655406432 139.73865166732284 38.041</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-7b9657b6-b14a-4154-b94d-f2a27fbdbd49">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7b9657b6-b14a-4154-b94d-f2a27fbdbd49">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7b9657b6-b14a-4154-b94d-f2a27fbdbd49">
											<gml:posList>35.67213097278073 139.73845951927524 28.07 35.67215866034532 139.73854777017272 28.07 35.67216630336113 139.73852407742913 28.07 35.672140414271375 139.73844186683914 28.07 35.672060500810375 139.7384790444935 28.07 35.67206328466724 139.73848872897256 28.07 35.67213097278073 139.73845951927524 28.07</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-2c758f7f-3c94-4381-80d9-e0d51ec61eca">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2c758f7f-3c94-4381-80d9-e0d51ec61eca">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2c758f7f-3c94-4381-80d9-e0d51ec61eca">
											<gml:posList>35.67210749485421 139.73857758992781 38.279 35.672106226501484 139.7385808722365 38.279 35.67212655406432 139.73865166732284 38.279 35.67212922335874 139.73865323277352 38.279 35.67210749485421 139.73857758992781 38.279</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-476c98c9-516b-4fce-86cc-e51cb2765e77">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-476c98c9-516b-4fce-86cc-e51cb2765e77">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-476c98c9-516b-4fce-86cc-e51cb2765e77">
											<gml:posList>35.67212922335874 139.73865323277352 38.279 35.67212655406432 139.73865166732284 38.279 35.67211114580657 139.73865830237176 38.279 35.67210986843793 139.73866158469 38.279 35.67212922335874 139.73865323277352 38.279</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-5c9e2f9b-be32-43f4-8272-b6fa3ab527f6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5c9e2f9b-be32-43f4-8272-b6fa3ab527f6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5c9e2f9b-be32-43f4-8272-b6fa3ab527f6">
											<gml:posList>35.67212308824141 139.738577129638 29.783 35.672117867098414 139.73857434104474 29.783 35.67215492533039 139.738692505881 29.783 35.672157290937434 139.73868614030212 29.783 35.67212308824141 139.738577129638 29.783</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-1c48d4dc-2ffc-43fd-be6c-e1ab94a2e2a8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1c48d4dc-2ffc-43fd-be6c-e1ab94a2e2a8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1c48d4dc-2ffc-43fd-be6c-e1ab94a2e2a8">
											<gml:posList>35.67212308824141 139.738577129638 29.783 35.67215921035053 139.73855943463104 29.783 35.67215398019343 139.73855664604835 29.783 35.672117867098414 139.73857434104474 29.783 35.67212308824141 139.738577129638 29.783</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-9c3943fc-a5af-4adc-ba60-18b96f74351b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9c3943fc-a5af-4adc-ba60-18b96f74351b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9c3943fc-a5af-4adc-ba60-18b96f74351b">
											<gml:posList>35.67212927273007 139.73846401721264 29.783 35.672126907091254 139.7384703275634 29.783 35.67215398019343 139.73855664604835 29.783 35.67215921035053 139.73855943463104 29.783 35.67212927273007 139.73846401721264 29.783</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-62910454-a9ab-4f41-9b9c-9a25c607e293">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-62910454-a9ab-4f41-9b9c-9a25c607e293">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-62910454-a9ab-4f41-9b9c-9a25c607e293">
											<gml:posList>35.67212927273007 139.73846401721264 28.07 35.67215738500569 139.7385536263277 28.07 35.67215866034532 139.73854777017272 28.07 35.67213097278073 139.73845951927524 28.07 35.67212927273007 139.73846401721264 28.07</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-08847b15-ed87-413d-a76e-bcc664ecd03d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-08847b15-ed87-413d-a76e-bcc664ecd03d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-08847b15-ed87-413d-a76e-bcc664ecd03d">
											<gml:posList>35.67212308824141 139.738577129638 25.113 35.672157290937434 139.73868614030212 25.113 35.67217846571067 139.73867661530824 25.113 35.67214490206734 139.7385664439813 25.113 35.67212308824141 139.738577129638 25.113</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-6a15a8d3-a40b-434c-91b8-374d1c2e2f69">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6a15a8d3-a40b-434c-91b8-374d1c2e2f69">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6a15a8d3-a40b-434c-91b8-374d1c2e2f69">
											<gml:posList>35.672166093807654 139.7388423054023 29.484 35.67223781878241 139.73881134585702 29.484 35.672195932301804 139.7386740539888 29.484 35.67215492533039 139.738692505881 29.484 35.672117867098414 139.73857434104474 29.484 35.67215398019343 139.73855664604835 29.484 35.672126907091254 139.7384703275634 29.484 35.672066688816926 139.73849631388518 29.484 35.672091969474295 139.73858429140677 29.484 35.67210749485421 139.73857758992781 29.484 35.67212922335874 139.73865323277352 29.484 35.672113697974666 139.73865993423965 29.484 35.672166093807654 139.7388423054023 29.484</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c026b5d3-be9f-42b4-8054-95c0d6a43301">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c026b5d3-be9f-42b4-8054-95c0d6a43301">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c026b5d3-be9f-42b4-8054-95c0d6a43301">
											<gml:posList>35.672167057996354 139.73840647543986 21.794 35.6721693518617 139.73840059598282 21.794 35.672136453962196 139.73841482969155 21.794 35.672137511902406 139.73841905924905 21.794 35.672167057996354 139.73840647543986 21.794</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-3b43a73c-05c4-4066-ad81-d86cd392d347">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3b43a73c-05c4-4066-ad81-d86cd392d347">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3b43a73c-05c4-4066-ad81-d86cd392d347">
											<gml:posList>35.672169422116774 139.73852408478749 28.07 35.67214208720169 139.73843726951424 28.07 35.672140414271375 139.73844186683914 28.07 35.67216630336113 139.73852407742913 28.07 35.672169422116774 139.73852408478749 28.07</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a4b96bd1-52eb-40a0-8f05-7507023cbe9a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a4b96bd1-52eb-40a0-8f05-7507023cbe9a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a4b96bd1-52eb-40a0-8f05-7507023cbe9a">
											<gml:posList>35.67215738500569 139.7385536263277 28.07 35.67216027746189 139.73855241883925 28.07 35.67215866034532 139.73854777017272 28.07 35.67215738500569 139.7385536263277 28.07</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-4204ec6b-05d1-4889-bf5d-51b63db1311b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4204ec6b-05d1-4889-bf5d-51b63db1311b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4204ec6b-05d1-4889-bf5d-51b63db1311b">
											<gml:posList>35.67216027746189 139.73855241883925 21.644 35.67215738500569 139.7385536263277 21.987 35.67215921035053 139.73855943463104 21.987 35.67216027746189 139.73855241883925 21.644</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-5bf35363-3666-4e4a-89de-11309ef6a787">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5bf35363-3666-4e4a-89de-11309ef6a787">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5bf35363-3666-4e4a-89de-11309ef6a787">
											<gml:posList>35.672169422116774 139.73852408478749 28.07 35.67216630336113 139.73852407742913 28.07 35.67215866034532 139.73854777017272 28.07 35.67216027746189 139.73855241883925 28.07 35.672169422116774 139.73852408478749 28.07</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d59921b1-9121-4a4e-b3fd-f7bd06ad7a5c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d59921b1-9121-4a4e-b3fd-f7bd06ad7a5c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d59921b1-9121-4a4e-b3fd-f7bd06ad7a5c">
											<gml:posList>35.672137511902406 139.73841905924905 21.794 35.67214208720169 139.73843726951424 21.794 35.672169422116774 139.73852408478749 21.794 35.67216199488241 139.73854708134706 21.794 35.67218805234107 139.73853407089248 21.794 35.67219716507755 139.73851099500516 21.794 35.672167057996354 139.73840647543986 21.794 35.672137511902406 139.73841905924905 21.794</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-598bb418-e929-43c3-9e81-74b80e0a26dc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-598bb418-e929-43c3-9e81-74b80e0a26dc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-598bb418-e929-43c3-9e81-74b80e0a26dc">
											<gml:posList>35.67216199488241 139.73854708134706 21.794 35.67216027746189 139.73855241883925 21.794 35.67219079536432 139.73853769090388 21.794 35.67218805234107 139.73853407089248 21.794 35.67216199488241 139.73854708134706 21.794</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-2db8c4b9-06ed-4ee1-98fd-0000e085d20f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2db8c4b9-06ed-4ee1-98fd-0000e085d20f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2db8c4b9-06ed-4ee1-98fd-0000e085d20f">
											<gml:posList>35.6722012304912 139.7385112774061 21.794 35.6721693518617 139.73840059598282 21.794 35.672167057996354 139.73840647543986 21.794 35.67219716507755 139.73851099500516 21.794 35.6722012304912 139.7385112774061 21.794</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-1713211b-a2a2-444f-89e5-a7cadf83a12b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1713211b-a2a2-444f-89e5-a7cadf83a12b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1713211b-a2a2-444f-89e5-a7cadf83a12b">
											<gml:posList>35.67214490206734 139.7385664439813 25.113 35.67217846571067 139.73867661530824 25.113 35.67222485235869 139.73865623495627 16.711 35.67214490206734 139.7385664439813 25.113</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-64925935-3879-40de-9e3e-3013423b2039">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-64925935-3879-40de-9e3e-3013423b2039">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-64925935-3879-40de-9e3e-3013423b2039">
											<gml:posList>35.67215921035053 139.73855943463104 21.987 35.67214490206734 139.7385664439813 25.113 35.67222485235869 139.73865623495627 16.711 35.67215921035053 139.73855943463104 21.987</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-437cc0b7-e98c-492e-b68f-eaece0166d54">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-437cc0b7-e98c-492e-b68f-eaece0166d54">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-437cc0b7-e98c-492e-b68f-eaece0166d54">
											<gml:posList>35.67216027746189 139.73855241883925 21.644 35.67215921035053 139.73855943463104 21.987 35.67222485235869 139.73865623495627 16.711 35.67216027746189 139.73855241883925 21.644</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ab60a91e-1742-4d0b-afe4-7c261ab746c2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ab60a91e-1742-4d0b-afe4-7c261ab746c2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ab60a91e-1742-4d0b-afe4-7c261ab746c2">
											<gml:posList>35.67216027746189 139.73855241883925 21.644 35.67222485235869 139.73865623495627 16.711 35.67219079536432 139.73853769090388 16.711 35.67216027746189 139.73855241883925 21.644</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a029a89b-57e5-4e29-9ed0-9b1e24b5eb72">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a029a89b-57e5-4e29-9ed0-9b1e24b5eb72">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a029a89b-57e5-4e29-9ed0-9b1e24b5eb72">
											<gml:posList>35.6722012304912 139.7385112774061 21.794 35.67219716507755 139.73851099500516 21.794 35.67218805234107 139.73853407089248 21.794 35.67219079536432 139.73853769090388 21.794 35.6722012304912 139.7385112774061 21.794</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ba323c16-9c37-4307-8d0b-3aec746a1b55">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ba323c16-9c37-4307-8d0b-3aec746a1b55">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ba323c16-9c37-4307-8d0b-3aec746a1b55">
											<gml:posList>35.672166093807654 139.7388423054023 29.783 35.672113697974666 139.73865993423965 29.783 35.67210986843793 139.73866158469 29.783 35.672163620010394 139.73884864901177 29.783 35.672166093807654 139.7388423054023 29.783</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-54ed9ef5-a9d4-4337-a201-e84b80c08b03">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-54ed9ef5-a9d4-4337-a201-e84b80c08b03">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-54ed9ef5-a9d4-4337-a201-e84b80c08b03">
											<gml:posList>35.672172425487084 139.73887043339107 25.001 35.672165881691214 139.73884767425386 25.001 35.672163620010394 139.73884864901177 25.001 35.672170959197175 139.7388741909308 25.001 35.672172425487084 139.73887043339107 25.001</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-4aaa0428-bae0-415e-bdb5-3f10bf355f01">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4aaa0428-bae0-415e-bdb5-3f10bf355f01">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4aaa0428-bae0-415e-bdb5-3f10bf355f01">
											<gml:posList>35.672157290937434 139.73868614030212 29.783 35.67215492533039 139.738692505881 29.783 35.672195932301804 139.7386740539888 29.783 35.672198324940325 139.7386676773277 29.783 35.672157290937434 139.73868614030212 29.783</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f75a29b5-519a-40b9-8491-cd3817d0cc23">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f75a29b5-519a-40b9-8491-cd3817d0cc23">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f75a29b5-519a-40b9-8491-cd3817d0cc23">
											<gml:posList>35.67224307614815 139.73881435535748 29.783 35.67223781878241 139.73881134585702 29.783 35.672166093807654 139.7388423054023 29.783 35.672163620010394 139.73884864901177 29.783 35.67224307614815 139.73881435535748 29.783</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-28c9dab2-f57a-43a3-ab4c-07b4ff68f0d8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-28c9dab2-f57a-43a3-ab4c-07b4ff68f0d8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-28c9dab2-f57a-43a3-ab4c-07b4ff68f0d8">
											<gml:posList>35.672265017140774 139.73880488471636 24.921 35.672165881691214 139.73884767425386 24.921 35.672172425487084 139.73887043339107 24.921 35.672271515789355 139.7388275334662 24.921 35.672265017140774 139.73880488471636 24.921</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-07f02880-29f1-401d-b8f6-7be65b8ed6a9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-07f02880-29f1-401d-b8f6-7be65b8ed6a9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-07f02880-29f1-401d-b8f6-7be65b8ed6a9">
											<gml:posList>35.672198324940325 139.7386676773277 29.783 35.672195932301804 139.7386740539888 29.783 35.67223781878241 139.73881134585702 29.783 35.67224307614815 139.73881435535748 29.783 35.672198324940325 139.7386676773277 29.783</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-590ffd0c-14cd-4c48-94bc-65c22f7e9242">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-590ffd0c-14cd-4c48-94bc-65c22f7e9242">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-590ffd0c-14cd-4c48-94bc-65c22f7e9242">
											<gml:posList>35.67227458186716 139.73882933043478 25.001 35.672271515789355 139.7388275334662 25.001 35.672172425487084 139.73887043339107 25.001 35.672170959197175 139.7388741909308 25.001 35.67227458186716 139.73882933043478 25.001</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-dbccf851-d8e4-4c5e-9d06-0aecfff1002f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-dbccf851-d8e4-4c5e-9d06-0aecfff1002f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-dbccf851-d8e4-4c5e-9d06-0aecfff1002f">
											<gml:posList>35.672198324940325 139.7386676773277 29.783 35.67224307614815 139.73881435535748 29.783 35.6722672788212 139.738803909956 25.307 35.672198324940325 139.7386676773277 29.783</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-4e14e57f-449f-41e3-b425-3da5b137682e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4e14e57f-449f-41e3-b425-3da5b137682e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4e14e57f-449f-41e3-b425-3da5b137682e">
											<gml:posList>35.6722672788212 139.738803909956 25.307 35.67222485235869 139.73865623495627 25.307 35.672198324940325 139.7386676773277 29.783 35.6722672788212 139.738803909956 25.307</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-8e1dc489-ed52-40cc-88a9-a310c9c0acba">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8e1dc489-ed52-40cc-88a9-a310c9c0acba">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8e1dc489-ed52-40cc-88a9-a310c9c0acba">
											<gml:posList>35.672271515789355 139.7388275334662 25.001 35.67227458186716 139.73882933043478 25.001 35.6722672788212 139.738803909956 25.001 35.672265017140774 139.73880488471636 25.001 35.672271515789355 139.7388275334662 25.001</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a6227a0f-298b-4d28-a1a6-7593c9844fb9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a6227a0f-298b-4d28-a1a6-7593c9844fb9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a6227a0f-298b-4d28-a1a6-7593c9844fb9">
											<gml:posList>35.672126907091254 139.7384703275634 29.783 35.672126907091254 139.7384703275634 29.484 35.67215398019343 139.73855664604835 29.484 35.67215398019343 139.73855664604835 29.783 35.672126907091254 139.7384703275634 29.783</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f3471570-59b2-4a17-b402-6f4ebb61017b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f3471570-59b2-4a17-b402-6f4ebb61017b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f3471570-59b2-4a17-b402-6f4ebb61017b">
											<gml:posList>35.672106226501484 139.7385808722365 38.279 35.672106226501484 139.7385808722365 38.041 35.67212655406432 139.73865166732284 38.041 35.67212655406432 139.73865166732284 38.279 35.672106226501484 139.7385808722365 38.279</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8e717676-3437-4f83-81a6-cb26290c46d0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8e717676-3437-4f83-81a6-cb26290c46d0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8e717676-3437-4f83-81a6-cb26290c46d0">
											<gml:posList>35.67211114580657 139.73865830237176 38.279 35.67211114580657 139.73865830237176 38.041 35.67209080923388 139.738587507308 38.041 35.67209080923388 139.738587507308 38.279 35.67211114580657 139.73865830237176 38.279</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-55a050a4-1da7-44f3-8d35-8ca412869841">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-55a050a4-1da7-44f3-8d35-8ca412869841">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-55a050a4-1da7-44f3-8d35-8ca412869841">
											<gml:posList>35.672117867098414 139.73857434104474 29.783 35.672117867098414 139.73857434104474 29.484 35.67215492533039 139.738692505881 29.484 35.67215492533039 139.738692505881 29.783 35.672117867098414 139.73857434104474 29.783</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8f178cda-3e91-4d15-9401-527865672bd4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8f178cda-3e91-4d15-9401-527865672bd4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8f178cda-3e91-4d15-9401-527865672bd4">
											<gml:posList>35.672091969474295 139.73858429140677 29.783 35.672091969474295 139.73858429140677 29.484 35.672066688816926 139.73849631388518 29.484 35.672066688816926 139.73849631388518 29.783 35.672091969474295 139.73858429140677 29.783</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f68a1580-3b5f-41fc-8b45-deb86494fb08">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f68a1580-3b5f-41fc-8b45-deb86494fb08">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f68a1580-3b5f-41fc-8b45-deb86494fb08">
											<gml:posList>35.67206150351809 139.73849326014093 29.783 35.67212927273007 139.73846401721264 29.783 35.67212927273007 139.73846401721264 28.07 35.67206150351809 139.73849326014093 28.07 35.67206150351809 139.73849326014093 29.783</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-612c24c8-d2de-4a58-a914-02a4b45ba3b6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-612c24c8-d2de-4a58-a914-02a4b45ba3b6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-612c24c8-d2de-4a58-a914-02a4b45ba3b6">
											<gml:posList>35.672066688816926 139.73849631388518 29.783 35.672066688816926 139.73849631388518 29.484 35.672126907091254 139.7384703275634 29.484 35.672126907091254 139.7384703275634 29.783 35.672066688816926 139.73849631388518 29.783</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ce7b7eed-35a6-46a3-94f0-57a1d0ed6f7c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ce7b7eed-35a6-46a3-94f0-57a1d0ed6f7c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ce7b7eed-35a6-46a3-94f0-57a1d0ed6f7c">
											<gml:posList>35.672091969474295 139.73858429140677 29.783 35.67208813092487 139.73858594187092 29.783 35.67208813092487 139.73858594187092 38.279 35.67210749485421 139.73857758992781 38.279 35.67210749485421 139.73857758992781 29.484 35.672091969474295 139.73858429140677 29.484 35.672091969474295 139.73858429140677 29.783</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-62911140-6650-4e19-b9b7-f085cc333210">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-62911140-6650-4e19-b9b7-f085cc333210">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-62911140-6650-4e19-b9b7-f085cc333210">
											<gml:posList>35.67209080923388 139.738587507308 38.279 35.67209080923388 139.738587507308 38.041 35.672106226501484 139.7385808722365 38.041 35.672106226501484 139.7385808722365 38.279 35.67209080923388 139.738587507308 38.279</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d909fd4c-e3ae-48fd-a991-f1bb26506083">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d909fd4c-e3ae-48fd-a991-f1bb26506083">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d909fd4c-e3ae-48fd-a991-f1bb26506083">
											<gml:posList>35.67216310628354 139.73837891908917 9.735 35.672043543986646 139.73843074721523 9.735 35.672043543986646 139.73843074721523 17.244 35.67216310628354 139.73837891908917 17.244 35.67216310628354 139.73837891908917 9.735</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-eb9ea735-c863-425d-b598-ef5f4937010b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-eb9ea735-c863-425d-b598-ef5f4937010b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-eb9ea735-c863-425d-b598-ef5f4937010b">
											<gml:posList>35.67210986843793 139.73866158469 29.783 35.67210986843793 139.73866158469 38.279 35.67208813092487 139.73858594187092 38.279 35.67208813092487 139.73858594187092 29.783 35.67206150351809 139.73849326014093 29.783 35.67206150351809 139.73849326014093 28.07 35.67205681253695 139.73847693897753 28.07 35.6720499342277 139.73845299832686 23.828 35.6720499342277 139.73845299832686 17.244 35.672043543986646 139.73843074721523 17.244 35.672043543986646 139.73843074721523 9.735 35.672170959197175 139.7388741909308 9.735 35.672170959197175 139.7388741909308 25.001 35.672163620010394 139.73884864901177 25.001 35.672163620010394 139.73884864901177 29.783 35.67210986843793 139.73866158469 29.783</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e721cc7b-1022-47c5-b883-5a991b2db052">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e721cc7b-1022-47c5-b883-5a991b2db052">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e721cc7b-1022-47c5-b883-5a991b2db052">
											<gml:posList>35.6720499342277 139.73845299832686 23.828 35.672136453962196 139.73841482969155 23.828 35.672136453962196 139.73841482969155 21.794 35.6721693518617 139.73840059598282 21.794 35.6721693518617 139.73840059598282 17.244 35.6720499342277 139.73845299832686 17.244 35.6720499342277 139.73845299832686 23.828</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-537cc499-9439-448a-8abe-470578e915f7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-537cc499-9439-448a-8abe-470578e915f7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-537cc499-9439-448a-8abe-470578e915f7">
											<gml:posList>35.67210749485421 139.73857758992781 38.279 35.67212922335874 139.73865323277352 38.279 35.67212922335874 139.73865323277352 29.484 35.67210749485421 139.73857758992781 29.484 35.67210749485421 139.73857758992781 38.279</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b9ec06e3-f696-419d-b5cd-7bfa6ac23623">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b9ec06e3-f696-419d-b5cd-7bfa6ac23623">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b9ec06e3-f696-419d-b5cd-7bfa6ac23623">
											<gml:posList>35.67212655406432 139.73865166732284 38.279 35.67212655406432 139.73865166732284 38.041 35.67211114580657 139.73865830237176 38.041 35.67211114580657 139.73865830237176 38.279 35.67212655406432 139.73865166732284 38.279</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c413b076-d220-4645-a401-1d9f167fd70c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c413b076-d220-4645-a401-1d9f167fd70c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c413b076-d220-4645-a401-1d9f167fd70c">
											<gml:posList>35.67210986843793 139.73866158469 38.279 35.67210986843793 139.73866158469 29.783 35.672113697974666 139.73865993423965 29.783 35.672113697974666 139.73865993423965 29.484 35.67212922335874 139.73865323277352 29.484 35.67212922335874 139.73865323277352 38.279 35.67210986843793 139.73866158469 38.279</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0c527561-67a9-49e6-8f90-b11d0982eb3f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0c527561-67a9-49e6-8f90-b11d0982eb3f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0c527561-67a9-49e6-8f90-b11d0982eb3f">
											<gml:posList>35.67215398019343 139.73855664604835 29.783 35.67215398019343 139.73855664604835 29.484 35.672117867098414 139.73857434104474 29.484 35.672117867098414 139.73857434104474 29.783 35.67215398019343 139.73855664604835 29.783</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ed99de09-22cb-4b85-b3fb-518753c61e19">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ed99de09-22cb-4b85-b3fb-518753c61e19">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ed99de09-22cb-4b85-b3fb-518753c61e19">
											<gml:posList>35.672136453962196 139.73841482969155 23.828 35.67214208720169 139.73843726951424 28.07 35.67214208720169 139.73843726951424 21.794 35.672137511902406 139.73841905924905 21.794 35.672136453962196 139.73841482969155 21.794 35.672136453962196 139.73841482969155 23.828</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-13bc0145-270c-497c-b86d-7c32a1dd22dd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-13bc0145-270c-497c-b86d-7c32a1dd22dd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-13bc0145-270c-497c-b86d-7c32a1dd22dd">
											<gml:posList>35.67212308824141 139.738577129638 25.113 35.67212308824141 139.738577129638 29.783 35.672157290937434 139.73868614030212 29.783 35.672157290937434 139.73868614030212 25.113 35.67212308824141 139.738577129638 25.113</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-bb21fabf-a831-4fcc-b5bc-6f2815216667">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bb21fabf-a831-4fcc-b5bc-6f2815216667">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bb21fabf-a831-4fcc-b5bc-6f2815216667">
											<gml:posList>35.67214490206734 139.7385664439813 25.113 35.67215921035053 139.73855943463104 21.987 35.67215921035053 139.73855943463104 29.783 35.67212308824141 139.738577129638 29.783 35.67212308824141 139.738577129638 25.113 35.67214490206734 139.7385664439813 25.113</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-51636d27-6613-43af-8fe6-3897e828034b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-51636d27-6613-43af-8fe6-3897e828034b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-51636d27-6613-43af-8fe6-3897e828034b">
											<gml:posList>35.67215921035053 139.73855943463104 29.783 35.67215921035053 139.73855943463104 21.987 35.67215738500569 139.7385536263277 21.987 35.67215738500569 139.7385536263277 28.07 35.67212927273007 139.73846401721264 28.07 35.67212927273007 139.73846401721264 29.783 35.67215921035053 139.73855943463104 29.783</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-fe115526-890d-42f8-bbc0-82bdd04b7af3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fe115526-890d-42f8-bbc0-82bdd04b7af3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fe115526-890d-42f8-bbc0-82bdd04b7af3">
											<gml:posList>35.67214208720169 139.73843726951424 21.794 35.67214208720169 139.73843726951424 28.07 35.672169422116774 139.73852408478749 28.07 35.672169422116774 139.73852408478749 21.794 35.67214208720169 139.73843726951424 21.794</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-16636d49-61eb-4d76-8ee9-054824d52275">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-16636d49-61eb-4d76-8ee9-054824d52275">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-16636d49-61eb-4d76-8ee9-054824d52275">
											<gml:posList>35.67215738500569 139.7385536263277 21.987 35.67216027746189 139.73855241883925 21.644 35.67216027746189 139.73855241883925 21.794 35.67216027746189 139.73855241883925 28.07 35.67215738500569 139.7385536263277 28.07 35.67215738500569 139.7385536263277 21.987</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9ea92823-9fe8-4679-83fb-d35814c867b5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9ea92823-9fe8-4679-83fb-d35814c867b5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9ea92823-9fe8-4679-83fb-d35814c867b5">
											<gml:posList>35.672169422116774 139.73852408478749 28.07 35.67216027746189 139.73855241883925 28.07 35.67216027746189 139.73855241883925 21.794 35.67216199488241 139.73854708134706 21.794 35.672169422116774 139.73852408478749 21.794 35.672169422116774 139.73852408478749 28.07</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c9e73730-6c6c-4ca4-83f2-80570d917bba">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c9e73730-6c6c-4ca4-83f2-80570d917bba">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c9e73730-6c6c-4ca4-83f2-80570d917bba">
											<gml:posList>35.67215492533039 139.738692505881 29.783 35.67215492533039 139.738692505881 29.484 35.672195932301804 139.7386740539888 29.484 35.672195932301804 139.7386740539888 29.783 35.67215492533039 139.738692505881 29.783</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-78906229-2f7f-42fd-bf3b-a01980023adb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-78906229-2f7f-42fd-bf3b-a01980023adb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-78906229-2f7f-42fd-bf3b-a01980023adb">
											<gml:posList>35.67216027746189 139.73855241883925 21.644 35.67219079536432 139.73853769090388 16.711 35.67219079536432 139.73853769090388 21.794 35.67216027746189 139.73855241883925 21.794 35.67216027746189 139.73855241883925 21.644</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5db17e61-a57e-415b-8545-a01fc3eae5e7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5db17e61-a57e-415b-8545-a01fc3eae5e7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5db17e61-a57e-415b-8545-a01fc3eae5e7">
											<gml:posList>35.6721693518617 139.73840059598282 17.244 35.6721693518617 139.73840059598282 21.794 35.6722012304912 139.7385112774061 21.794 35.6722012304912 139.7385112774061 9.735 35.67216310628354 139.73837891908917 9.735 35.67216310628354 139.73837891908917 17.244 35.6721693518617 139.73840059598282 17.244</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1ec5a710-17e6-44c3-9b62-2a47cf64749b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1ec5a710-17e6-44c3-9b62-2a47cf64749b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1ec5a710-17e6-44c3-9b62-2a47cf64749b">
											<gml:posList>35.672157290937434 139.73868614030212 29.783 35.672198324940325 139.7386676773277 29.783 35.67222485235869 139.73865623495627 25.307 35.67222485235869 139.73865623495627 16.711 35.67217846571067 139.73867661530824 25.113 35.672157290937434 139.73868614030212 25.113 35.672157290937434 139.73868614030212 29.783</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-46990757-a9a7-4558-8889-554d799c9c84">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-46990757-a9a7-4558-8889-554d799c9c84">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-46990757-a9a7-4558-8889-554d799c9c84">
											<gml:posList>35.6722012304912 139.7385112774061 21.794 35.67219079536432 139.73853769090388 21.794 35.67219079536432 139.73853769090388 16.711 35.67219079536432 139.73853769090388 9.735 35.6722012304912 139.7385112774061 9.735 35.6722012304912 139.7385112774061 21.794</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5f8039e8-ced7-4079-aec5-fc5efb736a31">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5f8039e8-ced7-4079-aec5-fc5efb736a31">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5f8039e8-ced7-4079-aec5-fc5efb736a31">
											<gml:posList>35.67227458186716 139.73882933043478 9.735 35.67219079536432 139.73853769090388 9.735 35.67219079536432 139.73853769090388 16.711 35.67222485235869 139.73865623495627 16.711 35.67222485235869 139.73865623495627 25.307 35.6722672788212 139.738803909956 25.307 35.6722672788212 139.738803909956 25.001 35.67227458186716 139.73882933043478 25.001 35.67227458186716 139.73882933043478 9.735</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-69471c75-4fce-4627-9db2-fe68b852869c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-69471c75-4fce-4627-9db2-fe68b852869c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-69471c75-4fce-4627-9db2-fe68b852869c">
											<gml:posList>35.672195932301804 139.7386740539888 29.783 35.672195932301804 139.7386740539888 29.484 35.67223781878241 139.73881134585702 29.484 35.67223781878241 139.73881134585702 29.783 35.672195932301804 139.7386740539888 29.783</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-80d1b9f5-679b-4b55-bf61-3a353d6b2d52">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-80d1b9f5-679b-4b55-bf61-3a353d6b2d52">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-80d1b9f5-679b-4b55-bf61-3a353d6b2d52">
											<gml:posList>35.672166093807654 139.7388423054023 29.783 35.672166093807654 139.7388423054023 29.484 35.672113697974666 139.73865993423965 29.484 35.672113697974666 139.73865993423965 29.783 35.672166093807654 139.7388423054023 29.783</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7bff1361-a563-4050-ac21-baeb587f76d2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7bff1361-a563-4050-ac21-baeb587f76d2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7bff1361-a563-4050-ac21-baeb587f76d2">
											<gml:posList>35.672265017140774 139.73880488471636 25.001 35.672265017140774 139.73880488471636 24.921 35.672271515789355 139.7388275334662 24.921 35.672271515789355 139.7388275334662 25.001 35.672265017140774 139.73880488471636 25.001</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-cce7351a-4b3a-4742-9913-b78beeee688a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cce7351a-4b3a-4742-9913-b78beeee688a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cce7351a-4b3a-4742-9913-b78beeee688a">
											<gml:posList>35.672165881691214 139.73884767425386 25.001 35.672165881691214 139.73884767425386 24.921 35.672265017140774 139.73880488471636 24.921 35.672265017140774 139.73880488471636 25.001 35.6722672788212 139.738803909956 25.001 35.6722672788212 139.738803909956 25.307 35.67224307614815 139.73881435535748 29.783 35.672163620010394 139.73884864901177 29.783 35.672163620010394 139.73884864901177 25.001 35.672165881691214 139.73884767425386 25.001</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b8a72155-ed9f-40e4-bbd7-a08030fbfce5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b8a72155-ed9f-40e4-bbd7-a08030fbfce5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b8a72155-ed9f-40e4-bbd7-a08030fbfce5">
											<gml:posList>35.67223781878241 139.73881134585702 29.783 35.67223781878241 139.73881134585702 29.484 35.672166093807654 139.7388423054023 29.484 35.672166093807654 139.7388423054023 29.783 35.67223781878241 139.73881134585702 29.783</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5a71e336-fe10-4fb0-bdd3-d20e91e52a40">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5a71e336-fe10-4fb0-bdd3-d20e91e52a40">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5a71e336-fe10-4fb0-bdd3-d20e91e52a40">
											<gml:posList>35.672271515789355 139.7388275334662 25.001 35.672271515789355 139.7388275334662 24.921 35.672172425487084 139.73887043339107 24.921 35.672172425487084 139.73887043339107 25.001 35.672271515789355 139.7388275334662 25.001</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8a251f14-122c-44e0-8902-dab284cbcde1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8a251f14-122c-44e0-8902-dab284cbcde1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8a251f14-122c-44e0-8902-dab284cbcde1">
											<gml:posList>35.672170959197175 139.7388741909308 9.735 35.67227458186716 139.73882933043478 9.735 35.67227458186716 139.73882933043478 25.001 35.672170959197175 139.7388741909308 25.001 35.672170959197175 139.7388741909308 9.735</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-82ba17ad-64ce-488e-9b83-18ef07002d53">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-82ba17ad-64ce-488e-9b83-18ef07002d53">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-82ba17ad-64ce-488e-9b83-18ef07002d53">
											<gml:posList>35.672172425487084 139.73887043339107 25.001 35.672172425487084 139.73887043339107 24.921 35.672165881691214 139.73884767425386 24.921 35.672165881691214 139.73884767425386 25.001 35.672172425487084 139.73887043339107 25.001</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-1010</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">518.42435</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">211</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1230</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>5</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.01</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>