<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_0971d734-5765-4af1-8fff-82fbcd727a9b">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="地区計画">
				<gen:value>赤坂二丁目地区</gen:value>
			</gen:stringAttribute>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.669195119579406 139.73995839162498 0 35.66917965906487 139.7399791100097 0 35.669205251764915 139.7400058669988 0 35.66921027678402 139.7400115057061 0 35.66922496292866 139.73999182655456 0 35.669195119579406 139.73995839162498 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669195119579406 139.73995839162498 10.33 35.66922496292866 139.73999182655456 10.33 35.66921027678402 139.7400115057061 10.33 35.669205251764915 139.7400058669988 10.33 35.66917965906487 139.7399791100097 10.33 35.669195119579406 139.73995839162498 10.33</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669195119579406 139.73995839162498 10.33 35.66917965906487 139.7399791100097 10.33 35.66917965906487 139.7399791100097 13.33 35.669195119579406 139.73995839162498 13.33 35.669195119579406 139.73995839162498 10.33</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66917965906487 139.7399791100097 10.33 35.669205251764915 139.7400058669988 10.33 35.669205251764915 139.7400058669988 13.33 35.66917965906487 139.7399791100097 13.33 35.66917965906487 139.7399791100097 10.33</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669205251764915 139.7400058669988 10.33 35.66921027678402 139.7400115057061 10.33 35.66921027678402 139.7400115057061 13.33 35.669205251764915 139.7400058669988 13.33 35.669205251764915 139.7400058669988 10.33</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66921027678402 139.7400115057061 10.33 35.66922496292866 139.73999182655456 10.33 35.66922496292866 139.73999182655456 13.33 35.66921027678402 139.7400115057061 13.33 35.66921027678402 139.7400115057061 10.33</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66922496292866 139.73999182655456 10.33 35.669195119579406 139.73995839162498 10.33 35.669195119579406 139.73995839162498 13.33 35.66922496292866 139.73999182655456 13.33 35.66922496292866 139.73999182655456 10.33</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669195119579406 139.73995839162498 13.33 35.66917965906487 139.7399791100097 13.33 35.669205251764915 139.7400058669988 13.33 35.66921027678402 139.7400115057061 13.33 35.66922496292866 139.73999182655456 13.33 35.669195119579406 139.73995839162498 13.33</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-38a1a25a-8929-4f41-a40d-9558b089e8f3"/>
							<gml:surfaceMember xlink:href="#poly-628c33db-0b07-46bd-b490-be43c571f91a"/>
							<gml:surfaceMember xlink:href="#poly-151a113b-2725-49ac-81b8-871156a81e4f"/>
							<gml:surfaceMember xlink:href="#poly-0d247f5e-685d-4b0e-8f25-a480970d0ee0"/>
							<gml:surfaceMember xlink:href="#poly-23772367-038a-4bc9-8b59-5c091583a1a1"/>
							<gml:surfaceMember xlink:href="#poly-22020ec1-5ecb-4595-91f0-b432a8fd543d"/>
							<gml:surfaceMember xlink:href="#poly-b4682cdf-66c4-4f3e-bb66-a0cc229d0334"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-38a1a25a-8929-4f41-a40d-9558b089e8f3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-38a1a25a-8929-4f41-a40d-9558b089e8f3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-38a1a25a-8929-4f41-a40d-9558b089e8f3">
											<gml:posList>35.66922496292866 139.73999182655456 10.33 35.66921027678403 139.74001150570606 10.33 35.6692052517649 139.74000586699879 10.33 35.66917965906486 139.7399791100097 10.33 35.66919511957939 139.73995839162498 10.33 35.66922496292866 139.73999182655456 10.33</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-628c33db-0b07-46bd-b490-be43c571f91a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-628c33db-0b07-46bd-b490-be43c571f91a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-628c33db-0b07-46bd-b490-be43c571f91a">
											<gml:posList>35.66922496292866 139.73999182655456 13.261 35.66919511957939 139.73995839162498 13.261 35.66917965906486 139.7399791100097 13.261 35.6692052517649 139.74000586699879 13.261 35.66921027678403 139.74001150570606 13.261 35.66922496292866 139.73999182655456 13.261</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-151a113b-2725-49ac-81b8-871156a81e4f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-151a113b-2725-49ac-81b8-871156a81e4f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-151a113b-2725-49ac-81b8-871156a81e4f">
											<gml:posList>35.66919511957939 139.73995839162498 10.33 35.66917965906486 139.7399791100097 10.33 35.66917965906486 139.7399791100097 13.261 35.66919511957939 139.73995839162498 13.261 35.66919511957939 139.73995839162498 10.33</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0d247f5e-685d-4b0e-8f25-a480970d0ee0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0d247f5e-685d-4b0e-8f25-a480970d0ee0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0d247f5e-685d-4b0e-8f25-a480970d0ee0">
											<gml:posList>35.66922496292866 139.73999182655456 10.33 35.66919511957939 139.73995839162498 10.33 35.66919511957939 139.73995839162498 13.261 35.66922496292866 139.73999182655456 13.261 35.66922496292866 139.73999182655456 10.33</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-23772367-038a-4bc9-8b59-5c091583a1a1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-23772367-038a-4bc9-8b59-5c091583a1a1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-23772367-038a-4bc9-8b59-5c091583a1a1">
											<gml:posList>35.66917965906486 139.7399791100097 10.33 35.6692052517649 139.74000586699879 10.33 35.6692052517649 139.74000586699879 13.261 35.66917965906486 139.7399791100097 13.261 35.66917965906486 139.7399791100097 10.33</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-22020ec1-5ecb-4595-91f0-b432a8fd543d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-22020ec1-5ecb-4595-91f0-b432a8fd543d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-22020ec1-5ecb-4595-91f0-b432a8fd543d">
											<gml:posList>35.66921027678403 139.74001150570606 10.33 35.66922496292866 139.73999182655456 10.33 35.66922496292866 139.73999182655456 13.261 35.66921027678403 139.74001150570606 13.261 35.66921027678403 139.74001150570606 10.33</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b4682cdf-66c4-4f3e-bb66-a0cc229d0334">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b4682cdf-66c4-4f3e-bb66-a0cc229d0334">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b4682cdf-66c4-4f3e-bb66-a0cc229d0334">
											<gml:posList>35.6692052517649 139.74000586699879 10.33 35.66921027678403 139.74001150570606 10.33 35.66921027678403 139.74001150570606 13.261 35.6692052517649 139.74000586699879 13.261 35.6692052517649 139.74000586699879 10.33</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-9794</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">211</uro:landUseType>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>7</uro:specifiedFloorAreaRate>
					<uro:surveyYear>0001</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">2</uro:rank>
					<uro:depth uom="m">0.62</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">0</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>