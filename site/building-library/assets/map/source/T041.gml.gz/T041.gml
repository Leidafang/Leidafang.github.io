<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_09bd3171-4df3-46d4-bd3b-df9754778b9a">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>3</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001003</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">402</bldg:usage>
			<bldg:measuredHeight uom="m">15.2</bldg:measuredHeight>
			<bldg:storeysAboveGround>5</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>1</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.674306536640536 139.73778930916868 0 35.67428150129664 139.73770449960773 0 35.67418418824722 139.737748802824 0 35.674209314310694 139.73783438546292 0 35.674306536640536 139.73778930916868 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.674306536640536 139.73778930916868 9.055 35.674209314310694 139.73783438546292 9.055 35.67418418824722 139.737748802824 9.055 35.67428150129664 139.73770449960773 9.055 35.674306536640536 139.73778930916868 9.055</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.674306536640536 139.73778930916868 9.055 35.67428150129664 139.73770449960773 9.055 35.67428150129664 139.73770449960773 23.73 35.674306536640536 139.73778930916868 23.73 35.674306536640536 139.73778930916868 9.055</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67428150129664 139.73770449960773 9.055 35.67418418824722 139.737748802824 9.055 35.67418418824722 139.737748802824 23.73 35.67428150129664 139.73770449960773 23.73 35.67428150129664 139.73770449960773 9.055</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67418418824722 139.737748802824 9.055 35.674209314310694 139.73783438546292 9.055 35.674209314310694 139.73783438546292 23.73 35.67418418824722 139.737748802824 23.73 35.67418418824722 139.737748802824 9.055</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.674209314310694 139.73783438546292 9.055 35.674306536640536 139.73778930916868 9.055 35.674306536640536 139.73778930916868 23.73 35.674209314310694 139.73783438546292 23.73 35.674209314310694 139.73783438546292 9.055</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.674306536640536 139.73778930916868 23.73 35.67428150129664 139.73770449960773 23.73 35.67418418824722 139.737748802824 23.73 35.674209314310694 139.73783438546292 23.73 35.674306536640536 139.73778930916868 23.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-f0c6d87d-30b2-4b81-b877-30ba8e368cc6"/>
							<gml:surfaceMember xlink:href="#poly-a6c4152f-ccb3-4f6c-ad36-0bd11dfb73fb"/>
							<gml:surfaceMember xlink:href="#poly-a0173c02-9a74-42c7-bec0-f65cb59fec12"/>
							<gml:surfaceMember xlink:href="#poly-4f80470e-190b-450f-8637-d10ccaab28e3"/>
							<gml:surfaceMember xlink:href="#poly-15447dac-33c5-4f10-bb18-1c0da3134abd"/>
							<gml:surfaceMember xlink:href="#poly-145f7333-a594-4bf1-b977-9724a7588477"/>
							<gml:surfaceMember xlink:href="#poly-c3c88a70-070a-4003-9444-d2be1595111e"/>
							<gml:surfaceMember xlink:href="#poly-1162d669-047b-46da-a310-cde400f8f93d"/>
							<gml:surfaceMember xlink:href="#poly-5818e8fe-f624-4b4c-aeba-28c8a7542b8f"/>
							<gml:surfaceMember xlink:href="#poly-b793a8dc-341f-4634-852c-2ecc06c5908f"/>
							<gml:surfaceMember xlink:href="#poly-8c6ddb15-23cf-4bfd-b1b3-c350c2794064"/>
							<gml:surfaceMember xlink:href="#poly-d009a940-8b71-4a83-85fc-125136647af2"/>
							<gml:surfaceMember xlink:href="#poly-e38bf080-88d6-40ee-8d9f-2c2861e8fa2c"/>
							<gml:surfaceMember xlink:href="#poly-edc27b34-0476-4da2-a4c8-e792d2511f5a"/>
							<gml:surfaceMember xlink:href="#poly-62f5148b-fe5e-431e-8bb1-81faf3bb30ca"/>
							<gml:surfaceMember xlink:href="#poly-338e8d07-3dce-406a-98bf-429b40d4a600"/>
							<gml:surfaceMember xlink:href="#poly-b05f6a08-992f-43f7-94f5-4b8ccc447897"/>
							<gml:surfaceMember xlink:href="#poly-5355ad0f-df73-4dc0-a355-f194ca0e7109"/>
							<gml:surfaceMember xlink:href="#poly-3341249a-b650-4a93-906e-b41c0e6e96be"/>
							<gml:surfaceMember xlink:href="#poly-f4d903ce-1604-4a2d-b1c2-0d2af76faa61"/>
							<gml:surfaceMember xlink:href="#poly-5b329a5f-4000-4eb2-880a-0d896bf5c856"/>
							<gml:surfaceMember xlink:href="#poly-ca5a44b9-cded-4cd9-a7a4-bcd8497dd1e7"/>
							<gml:surfaceMember xlink:href="#poly-d9e059b2-209a-44ae-ab61-6699ee3ae46e"/>
							<gml:surfaceMember xlink:href="#poly-abb95e32-ac9a-499a-ae34-e7bfb489a516"/>
							<gml:surfaceMember xlink:href="#poly-64d3576f-484d-44e1-8535-1801545aaaff"/>
							<gml:surfaceMember xlink:href="#poly-04d907a9-7a4f-4300-aa36-1a10d5a1de99"/>
							<gml:surfaceMember xlink:href="#poly-97193f73-f2e5-4a9d-81b4-81776a793aea"/>
							<gml:surfaceMember xlink:href="#poly-0ce80bdd-3c40-40fd-a3db-75f4026fc95d"/>
							<gml:surfaceMember xlink:href="#poly-471fd95e-4f51-4eab-94e3-a57154801994"/>
							<gml:surfaceMember xlink:href="#poly-3cf1e070-8cf7-430a-92fd-fb00779735c7"/>
							<gml:surfaceMember xlink:href="#poly-56d49080-51a2-449a-ab75-232ab73fb00d"/>
							<gml:surfaceMember xlink:href="#poly-846f83bd-a4bc-4e89-a392-80b753b74a6f"/>
							<gml:surfaceMember xlink:href="#poly-61a41c25-1633-493e-8ccf-89bc82f801d8"/>
							<gml:surfaceMember xlink:href="#poly-11e5f1b9-43b8-443b-8265-13b217f6b049"/>
							<gml:surfaceMember xlink:href="#poly-8658f6ad-bcf5-470f-907f-5960dc1875f9"/>
							<gml:surfaceMember xlink:href="#poly-304eeeb8-d388-4a20-8737-999299bc8ac2"/>
							<gml:surfaceMember xlink:href="#poly-f89db8b3-88d8-4880-8655-08521d4112b9"/>
							<gml:surfaceMember xlink:href="#poly-16f28eac-9688-4c69-85c5-fe1e8ef9b213"/>
							<gml:surfaceMember xlink:href="#poly-0a2176ce-840e-49fb-a472-dc279f215f70"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_09bd3171-4df3-46d4-bd3b-df9754778b9a_BuildingInstallation_1041">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2b9d5808-6209-4917-85a8-fb2ce5944239">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67424853198456 139.7377421974508 25.661 35.674255346758834 139.7377654096839 25.661 35.674234063787196 139.7377747916871 25.661 35.6742272490147 139.73775157945937 25.661 35.67424853198456 139.7377421974508 25.661</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d253744f-8e60-49af-b7b1-bbceb8e0ea65">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d253744f-8e60-49af-b7b1-bbceb8e0ea65_0">
											<gml:posList>35.6742272490147 139.73775157945937 28.273 35.6742272490147 139.73775157945937 25.661 35.674234063787196 139.7377747916871 25.661 35.674234063787196 139.7377747916871 28.273 35.6742272490147 139.73775157945937 28.273</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ea8df3fe-1297-4b25-86c4-816adb9fd7a0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ea8df3fe-1297-4b25-86c4-816adb9fd7a0_0">
											<gml:posList>35.67424853198456 139.7377421974508 28.273 35.67424853198456 139.7377421974508 25.661 35.6742272490147 139.73775157945937 25.661 35.6742272490147 139.73775157945937 28.273 35.67424853198456 139.7377421974508 28.273</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-aa728f1a-c5be-4db2-ad0c-831a53f59196">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-aa728f1a-c5be-4db2-ad0c-831a53f59196_0">
											<gml:posList>35.67424853198456 139.7377421974508 28.273 35.6742272490147 139.73775157945937 28.273 35.674234063787196 139.7377747916871 28.273 35.674255346758834 139.7377654096839 28.273 35.67424853198456 139.7377421974508 28.273</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-812bb5d5-455d-4ca8-a3f9-67ee7cdc761f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-812bb5d5-455d-4ca8-a3f9-67ee7cdc761f_0">
											<gml:posList>35.674234063787196 139.7377747916871 28.273 35.674234063787196 139.7377747916871 25.661 35.674255346758834 139.7377654096839 25.661 35.674255346758834 139.7377654096839 28.273 35.674234063787196 139.7377747916871 28.273</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-72636b42-d07b-4369-9c31-198fa98fe5f8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-72636b42-d07b-4369-9c31-198fa98fe5f8_0">
											<gml:posList>35.674255346758834 139.7377654096839 28.273 35.674255346758834 139.7377654096839 25.661 35.67424853198456 139.7377421974508 25.661 35.67424853198456 139.7377421974508 28.273 35.674255346758834 139.7377654096839 28.273</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_09bd3171-4df3-46d4-bd3b-df9754778b9a_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-53dadaf1-a3e8-4ca0-95c5-182b922c048a">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67419815218438 139.73778498648957 30.496 35.674190144376524 139.7377577104771 30.496 35.67420121836679 139.73775282564202 30.496 35.67420922617575 139.73778010165776 30.496 35.67419815218438 139.73778498648957 30.496</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3fbca71a-e862-4c2f-95f0-0c0d4f23a1fb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3fbca71a-e862-4c2f-95f0-0c0d4f23a1fb_0">
											<gml:posList>35.67420121836679 139.73775282564202 33.353 35.67420121836679 139.73775282564202 30.496 35.674190144376524 139.7377577104771 30.496 35.674190144376524 139.7377577104771 33.353 35.67420121836679 139.73775282564202 33.353</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c48846cc-cca7-4613-bb82-0f4059550727">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c48846cc-cca7-4613-bb82-0f4059550727_0">
											<gml:posList>35.67420922617575 139.73778010165776 33.353 35.67420922617575 139.73778010165776 30.496 35.67420121836679 139.73775282564202 30.496 35.67420121836679 139.73775282564202 33.353 35.67420922617575 139.73778010165776 33.353</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4a229166-3ff2-4d87-82ac-b165b1b29999">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4a229166-3ff2-4d87-82ac-b165b1b29999_0">
											<gml:posList>35.67420121836679 139.73775282564202 33.353 35.674190144376524 139.7377577104771 33.353 35.67419815218438 139.73778498648957 33.353 35.67420922617575 139.73778010165776 33.353 35.67420121836679 139.73775282564202 33.353</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fe0caeed-f756-4b12-a0de-aa9bec8e3d98">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fe0caeed-f756-4b12-a0de-aa9bec8e3d98_0">
											<gml:posList>35.674190144376524 139.7377577104771 33.353 35.674190144376524 139.7377577104771 30.496 35.67419815218438 139.73778498648957 30.496 35.67419815218438 139.73778498648957 33.353 35.674190144376524 139.7377577104771 33.353</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e073b2ae-0872-4cf8-8c72-0419ffe73da9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e073b2ae-0872-4cf8-8c72-0419ffe73da9_0">
											<gml:posList>35.67419815218438 139.73778498648957 33.353 35.67419815218438 139.73778498648957 30.496 35.67420922617575 139.73778010165776 30.496 35.67420922617575 139.73778010165776 33.353 35.67419815218438 139.73778498648957 33.353</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_09bd3171-4df3-46d4-bd3b-df9754778b9a_BuildingInstallation_1060">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0c6a3a27-0a56-4de6-9bbf-104e6e864a87">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.674213317508844 139.73774490171672 25.661 35.67422353966785 139.7377797200529 25.661 35.67421653844739 139.73778279940498 25.661 35.67420816008581 139.7377542755414 25.661 35.67420631629805 139.73774799211822 25.661 35.674213317508844 139.73774490171672 25.661</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f54e09f2-62c9-45ef-ab63-19a6b086a260">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f54e09f2-62c9-45ef-ab63-19a6b086a260_0">
											<gml:posList>35.67420631629805 139.73774799211822 26.27 35.67420631629805 139.73774799211822 25.661 35.67420816008581 139.7377542755414 25.661 35.67420816008581 139.7377542755414 26.27 35.67420631629805 139.73774799211822 26.27</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b83b31fc-f98e-42c6-8f33-b61cb468fa11">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b83b31fc-f98e-42c6-8f33-b61cb468fa11_0">
											<gml:posList>35.674213317508844 139.73774490171672 26.27 35.674213317508844 139.73774490171672 25.661 35.67420631629805 139.73774799211822 25.661 35.67420631629805 139.73774799211822 26.27 35.674213317508844 139.73774490171672 26.27</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d7a04f7f-e600-4a68-a99a-61f08d3119ca">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d7a04f7f-e600-4a68-a99a-61f08d3119ca_0">
											<gml:posList>35.67421653844739 139.73778279940498 25.661 35.67421653844739 139.73778279940498 26.27 35.67420816008581 139.7377542755414 26.27 35.67420816008581 139.7377542755414 25.661 35.67421653844739 139.73778279940498 25.661</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4d782de0-cb5b-41d0-8e79-062a96a02252">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4d782de0-cb5b-41d0-8e79-062a96a02252_0">
											<gml:posList>35.674213317508844 139.73774490171672 26.27 35.67420631629805 139.73774799211822 26.27 35.67420816008581 139.7377542755414 26.27 35.67421653844739 139.73778279940498 26.27 35.67422353966785 139.7377797200529 26.27 35.674213317508844 139.73774490171672 26.27</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-372e5472-969d-4129-a46c-58720bd8f54e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-372e5472-969d-4129-a46c-58720bd8f54e_0">
											<gml:posList>35.67422353966785 139.7377797200529 26.27 35.67422353966785 139.7377797200529 25.661 35.674213317508844 139.73774490171672 25.661 35.674213317508844 139.73774490171672 26.27 35.67422353966785 139.7377797200529 26.27</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2d2fb411-9768-49ad-a913-06d273afe64f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2d2fb411-9768-49ad-a913-06d273afe64f_0">
											<gml:posList>35.67421653844739 139.73778279940498 25.661 35.67422353966785 139.7377797200529 25.661 35.67422353966785 139.7377797200529 26.27 35.67421653844739 139.73778279940498 26.27 35.67421653844739 139.73778279940498 25.661</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-f0c6d87d-30b2-4b81-b877-30ba8e368cc6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f0c6d87d-30b2-4b81-b877-30ba8e368cc6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f0c6d87d-30b2-4b81-b877-30ba8e368cc6">
											<gml:posList>35.67430653664054 139.73778930916865 9.055 35.67420931431069 139.7378343854629 9.055 35.674184188247224 139.73774880282397 9.055 35.67428150129662 139.7377044996077 9.055 35.67430653664054 139.73778930916865 9.055</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a6c4152f-ccb3-4f6c-ad36-0bd11dfb73fb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a6c4152f-ccb3-4f6c-ad36-0bd11dfb73fb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a6c4152f-ccb3-4f6c-ad36-0bd11dfb73fb">
											<gml:posList>35.67420785293419 139.73774205816164 25.797 35.674204680377926 139.73774240439502 25.797 35.67420495153486 139.73774334304852 25.797 35.67420785293419 139.73774205816164 25.797</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a0173c02-9a74-42c7-bec0-f65cb59fec12">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a0173c02-9a74-42c7-bec0-f65cb59fec12">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a0173c02-9a74-42c7-bec0-f65cb59fec12">
											<gml:posList>35.674279297585954 139.73771035703857 23.728 35.67428150129662 139.7377044996077 23.728 35.67425318139836 139.73771739185693 23.728 35.67425434749237 139.73772157720063 23.728 35.674279297585954 139.73771035703857 23.728</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-4f80470e-190b-450f-8637-d10ccaab28e3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4f80470e-190b-450f-8637-d10ccaab28e3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4f80470e-190b-450f-8637-d10ccaab28e3">
											<gml:posList>35.67425318139836 139.73771739185693 25.797 35.674184188247224 139.73774880282397 25.797 35.674184875148754 139.73775114392305 25.797 35.674204680377926 139.73774240439502 25.797 35.67420785293419 139.73774205816164 25.797 35.67425128339027 139.7377222878498 25.797 35.67425318139836 139.73771739185693 25.797</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-15447dac-33c5-4f10-bb18-1c0da3134abd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-15447dac-33c5-4f10-bb18-1c0da3134abd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-15447dac-33c5-4f10-bb18-1c0da3134abd">
											<gml:posList>35.67428150129662 139.7377044996077 23.728 35.674279297585954 139.73771035703857 23.728 35.67430182035446 139.73778665251095 23.728 35.67430653664054 139.73778930916865 23.728 35.67428150129662 139.7377044996077 23.728</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-145f7333-a594-4bf1-b977-9724a7588477">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-145f7333-a594-4bf1-b977-9724a7588477">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-145f7333-a594-4bf1-b977-9724a7588477">
											<gml:posList>35.674184875148754 139.73775114392305 30.947 35.67418759854504 139.73775272036602 30.947 35.67420339407376 139.73774575310497 30.947 35.674204680377926 139.73774240439502 30.947 35.674184875148754 139.73775114392305 30.947</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c3c88a70-070a-4003-9444-d2be1595111e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c3c88a70-070a-4003-9444-d2be1595111e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c3c88a70-070a-4003-9444-d2be1595111e">
											<gml:posList>35.67425318139836 139.73771739185693 25.797 35.67425128339027 139.7377222878498 25.797 35.67426609002055 139.73777538317887 25.797 35.674269994783145 139.7377776762578 25.797 35.67425318139836 139.73771739185693 25.797</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-1162d669-047b-46da-a310-cde400f8f93d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1162d669-047b-46da-a310-cde400f8f93d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1162d669-047b-46da-a310-cde400f8f93d">
											<gml:posList>35.67426609002055 139.73777538317887 25.661 35.67425128339027 139.7377222878498 25.661 35.67420785293419 139.73774205816164 25.661 35.67420495153486 139.73774334304852 25.661 35.67421689996909 139.7377840251675 25.661 35.67419999614554 139.73779149084845 25.661 35.67420346679104 139.73780330677312 25.661 35.67426609002055 139.73777538317887 25.661</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-5818e8fe-f624-4b4c-aeba-28c8a7542b8f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5818e8fe-f624-4b4c-aeba-28c8a7542b8f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5818e8fe-f624-4b4c-aeba-28c8a7542b8f">
											<gml:posList>35.674204680377926 139.73774240439502 30.947 35.67420339407376 139.73774575310497 30.947 35.67421417657321 139.7377824487229 30.947 35.67421689996909 139.7377840251675 30.947 35.674204680377926 139.73774240439502 30.947</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b793a8dc-341f-4634-852c-2ecc06c5908f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b793a8dc-341f-4634-852c-2ecc06c5908f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b793a8dc-341f-4634-852c-2ecc06c5908f">
											<gml:posList>35.67421417657321 139.7377824487229 30.496 35.67420339407376 139.73774575310497 30.496 35.67418759854504 139.73775272036602 30.496 35.674198381042395 139.7377894159777 30.496 35.67421417657321 139.7377824487229 30.496</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-8c6ddb15-23cf-4bfd-b1b3-c350c2794064">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8c6ddb15-23cf-4bfd-b1b3-c350c2794064">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8c6ddb15-23cf-4bfd-b1b3-c350c2794064">
											<gml:posList>35.674269994783145 139.7377776762578 23.325 35.67420509188047 139.73780660782566 23.325 35.67421153603733 139.7378285059255 23.325 35.67430182035446 139.73778665251095 23.325 35.674279297585954 139.73771035703857 23.325 35.67425434749237 139.73772157720063 23.325 35.674269994783145 139.7377776762578 23.325</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d009a940-8b71-4a83-85fc-125136647af2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d009a940-8b71-4a83-85fc-125136647af2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d009a940-8b71-4a83-85fc-125136647af2">
											<gml:posList>35.67419709473692 139.73779276468662 30.947 35.674198381042395 139.7377894159777 30.947 35.67418759854504 139.73775272036602 30.947 35.674184875148754 139.73775114392305 30.947 35.67419709473692 139.73779276468662 30.947</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e38bf080-88d6-40ee-8d9f-2c2861e8fa2c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e38bf080-88d6-40ee-8d9f-2c2861e8fa2c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e38bf080-88d6-40ee-8d9f-2c2861e8fa2c">
											<gml:posList>35.67421689996909 139.7377840251675 30.947 35.67421417657321 139.7377824487229 30.947 35.674198381042395 139.7377894159777 30.947 35.67419709473692 139.73779276468662 30.947 35.67421689996909 139.7377840251675 30.947</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-edc27b34-0476-4da2-a4c8-e792d2511f5a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-edc27b34-0476-4da2-a4c8-e792d2511f5a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-edc27b34-0476-4da2-a4c8-e792d2511f5a">
											<gml:posList>35.674269994783145 139.7377776762578 25.797 35.67426609002055 139.73777538317887 25.797 35.67420346679104 139.73780330677312 25.797 35.67420161381295 139.73780815852012 25.797 35.674269994783145 139.7377776762578 25.797</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-62f5148b-fe5e-431e-8bb1-81faf3bb30ca">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-62f5148b-fe5e-431e-8bb1-81faf3bb30ca">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-62f5148b-fe5e-431e-8bb1-81faf3bb30ca">
											<gml:posList>35.67420346679104 139.73780330677312 25.797 35.67419999614554 139.73779149084845 25.797 35.67419709473692 139.73779276468662 25.797 35.67420161381295 139.73780815852012 25.797 35.67420346679104 139.73780330677312 25.797</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-338e8d07-3dce-406a-98bf-429b40d4a600">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-338e8d07-3dce-406a-98bf-429b40d4a600">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-338e8d07-3dce-406a-98bf-429b40d4a600">
											<gml:posList>35.67430653664054 139.73778930916865 23.728 35.67430182035446 139.73778665251095 23.728 35.67421153603733 139.7378285059255 23.728 35.67420931431069 139.7378343854629 23.728 35.67430653664054 139.73778930916865 23.728</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b05f6a08-992f-43f7-94f5-4b8ccc447897">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b05f6a08-992f-43f7-94f5-4b8ccc447897">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b05f6a08-992f-43f7-94f5-4b8ccc447897">
											<gml:posList>35.67421153603733 139.7378285059255 23.728 35.67420509188047 139.73780660782566 23.728 35.67420161381295 139.73780815852012 23.728 35.67420931431069 139.7378343854629 23.728 35.67421153603733 139.7378285059255 23.728</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5355ad0f-df73-4dc0-a355-f194ca0e7109">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5355ad0f-df73-4dc0-a355-f194ca0e7109">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5355ad0f-df73-4dc0-a355-f194ca0e7109">
											<gml:posList>35.67420339407376 139.73774575310497 30.947 35.67420339407376 139.73774575310497 30.496 35.67421417657321 139.7377824487229 30.496 35.67421417657321 139.7377824487229 30.947 35.67420339407376 139.73774575310497 30.947</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3341249a-b650-4a93-906e-b41c0e6e96be">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3341249a-b650-4a93-906e-b41c0e6e96be">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3341249a-b650-4a93-906e-b41c0e6e96be">
											<gml:posList>35.67425434749237 139.73772157720063 23.728 35.67425434749237 139.73772157720063 23.325 35.674279297585954 139.73771035703857 23.325 35.674279297585954 139.73771035703857 23.728 35.67425434749237 139.73772157720063 23.728</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f4d903ce-1604-4a2d-b1c2-0d2af76faa61">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f4d903ce-1604-4a2d-b1c2-0d2af76faa61">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f4d903ce-1604-4a2d-b1c2-0d2af76faa61">
											<gml:posList>35.674184188247224 139.73774880282397 9.055 35.674184188247224 139.73774880282397 25.797 35.67425318139836 139.73771739185693 25.797 35.67425318139836 139.73771739185693 23.728 35.67428150129662 139.7377044996077 23.728 35.67428150129662 139.7377044996077 9.055 35.674184188247224 139.73774880282397 9.055</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5b329a5f-4000-4eb2-880a-0d896bf5c856">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5b329a5f-4000-4eb2-880a-0d896bf5c856">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5b329a5f-4000-4eb2-880a-0d896bf5c856">
											<gml:posList>35.67420785293419 139.73774205816164 25.797 35.67420785293419 139.73774205816164 25.661 35.67425128339027 139.7377222878498 25.661 35.67425128339027 139.7377222878498 25.797 35.67420785293419 139.73774205816164 25.797</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ca5a44b9-cded-4cd9-a7a4-bcd8497dd1e7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ca5a44b9-cded-4cd9-a7a4-bcd8497dd1e7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ca5a44b9-cded-4cd9-a7a4-bcd8497dd1e7">
											<gml:posList>35.67420495153486 139.73774334304852 25.797 35.67420495153486 139.73774334304852 25.661 35.67420785293419 139.73774205816164 25.661 35.67420785293419 139.73774205816164 25.797 35.67420495153486 139.73774334304852 25.797</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d9e059b2-209a-44ae-ab61-6699ee3ae46e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d9e059b2-209a-44ae-ab61-6699ee3ae46e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d9e059b2-209a-44ae-ab61-6699ee3ae46e">
											<gml:posList>35.674184875148754 139.73775114392305 30.947 35.674204680377926 139.73774240439502 30.947 35.674204680377926 139.73774240439502 25.797 35.674184875148754 139.73775114392305 25.797 35.674184875148754 139.73775114392305 30.947</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-abb95e32-ac9a-499a-ae34-e7bfb489a516">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-abb95e32-ac9a-499a-ae34-e7bfb489a516">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-abb95e32-ac9a-499a-ae34-e7bfb489a516">
											<gml:posList>35.67430653664054 139.73778930916865 9.055 35.67428150129662 139.7377044996077 9.055 35.67428150129662 139.7377044996077 23.728 35.67430653664054 139.73778930916865 23.728 35.67430653664054 139.73778930916865 9.055</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-64d3576f-484d-44e1-8535-1801545aaaff">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-64d3576f-484d-44e1-8535-1801545aaaff">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-64d3576f-484d-44e1-8535-1801545aaaff">
											<gml:posList>35.67425434749237 139.73772157720063 23.728 35.67425318139836 139.73771739185693 23.728 35.67425318139836 139.73771739185693 25.797 35.674269994783145 139.7377776762578 25.797 35.674269994783145 139.7377776762578 23.325 35.67425434749237 139.73772157720063 23.325 35.67425434749237 139.73772157720063 23.728</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-04d907a9-7a4f-4300-aa36-1a10d5a1de99">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-04d907a9-7a4f-4300-aa36-1a10d5a1de99">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-04d907a9-7a4f-4300-aa36-1a10d5a1de99">
											<gml:posList>35.674279297585954 139.73771035703857 23.728 35.674279297585954 139.73771035703857 23.325 35.67430182035446 139.73778665251095 23.325 35.67430182035446 139.73778665251095 23.728 35.674279297585954 139.73771035703857 23.728</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-97193f73-f2e5-4a9d-81b4-81776a793aea">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-97193f73-f2e5-4a9d-81b4-81776a793aea">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-97193f73-f2e5-4a9d-81b4-81776a793aea">
											<gml:posList>35.67425128339027 139.7377222878498 25.797 35.67425128339027 139.7377222878498 25.661 35.67426609002055 139.73777538317887 25.661 35.67426609002055 139.73777538317887 25.797 35.67425128339027 139.7377222878498 25.797</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0ce80bdd-3c40-40fd-a3db-75f4026fc95d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0ce80bdd-3c40-40fd-a3db-75f4026fc95d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0ce80bdd-3c40-40fd-a3db-75f4026fc95d">
											<gml:posList>35.67418759854504 139.73775272036602 30.947 35.67418759854504 139.73775272036602 30.496 35.67420339407376 139.73774575310497 30.496 35.67420339407376 139.73774575310497 30.947 35.67418759854504 139.73775272036602 30.947</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-471fd95e-4f51-4eab-94e3-a57154801994">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-471fd95e-4f51-4eab-94e3-a57154801994">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-471fd95e-4f51-4eab-94e3-a57154801994">
											<gml:posList>35.67420495153486 139.73774334304852 25.797 35.674204680377926 139.73774240439502 25.797 35.674204680377926 139.73774240439502 30.947 35.67421689996909 139.7377840251675 30.947 35.67421689996909 139.7377840251675 25.661 35.67420495153486 139.73774334304852 25.661 35.67420495153486 139.73774334304852 25.797</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3cf1e070-8cf7-430a-92fd-fb00779735c7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3cf1e070-8cf7-430a-92fd-fb00779735c7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3cf1e070-8cf7-430a-92fd-fb00779735c7">
											<gml:posList>35.674198381042395 139.7377894159777 30.947 35.674198381042395 139.7377894159777 30.496 35.67418759854504 139.73775272036602 30.496 35.67418759854504 139.73775272036602 30.947 35.674198381042395 139.7377894159777 30.947</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-56d49080-51a2-449a-ab75-232ab73fb00d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-56d49080-51a2-449a-ab75-232ab73fb00d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-56d49080-51a2-449a-ab75-232ab73fb00d">
											<gml:posList>35.67421417657321 139.7377824487229 30.947 35.67421417657321 139.7377824487229 30.496 35.674198381042395 139.7377894159777 30.496 35.674198381042395 139.7377894159777 30.947 35.67421417657321 139.7377824487229 30.947</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-846f83bd-a4bc-4e89-a392-80b753b74a6f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-846f83bd-a4bc-4e89-a392-80b753b74a6f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-846f83bd-a4bc-4e89-a392-80b753b74a6f">
											<gml:posList>35.67421689996909 139.7377840251675 25.661 35.67421689996909 139.7377840251675 30.947 35.67419709473692 139.73779276468662 30.947 35.67419709473692 139.73779276468662 25.797 35.67419999614554 139.73779149084845 25.797 35.67419999614554 139.73779149084845 25.661 35.67421689996909 139.7377840251675 25.661</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-61a41c25-1633-493e-8ccf-89bc82f801d8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-61a41c25-1633-493e-8ccf-89bc82f801d8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-61a41c25-1633-493e-8ccf-89bc82f801d8">
											<gml:posList>35.67426609002055 139.73777538317887 25.797 35.67426609002055 139.73777538317887 25.661 35.67420346679104 139.73780330677312 25.661 35.67420346679104 139.73780330677312 25.797 35.67426609002055 139.73777538317887 25.797</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-11e5f1b9-43b8-443b-8265-13b217f6b049">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-11e5f1b9-43b8-443b-8265-13b217f6b049">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-11e5f1b9-43b8-443b-8265-13b217f6b049">
											<gml:posList>35.67419709473692 139.73779276468662 25.797 35.67419709473692 139.73779276468662 30.947 35.674184875148754 139.73775114392305 30.947 35.674184875148754 139.73775114392305 25.797 35.674184188247224 139.73774880282397 25.797 35.674184188247224 139.73774880282397 9.055 35.67420931431069 139.7378343854629 9.055 35.67420931431069 139.7378343854629 23.728 35.67420161381295 139.73780815852012 23.728 35.67420161381295 139.73780815852012 25.797 35.67419709473692 139.73779276468662 25.797</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8658f6ad-bcf5-470f-907f-5960dc1875f9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8658f6ad-bcf5-470f-907f-5960dc1875f9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8658f6ad-bcf5-470f-907f-5960dc1875f9">
											<gml:posList>35.674269994783145 139.7377776762578 23.325 35.674269994783145 139.7377776762578 25.797 35.67420161381295 139.73780815852012 25.797 35.67420161381295 139.73780815852012 23.728 35.67420509188047 139.73780660782566 23.728 35.67420509188047 139.73780660782566 23.325 35.674269994783145 139.7377776762578 23.325</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-304eeeb8-d388-4a20-8737-999299bc8ac2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-304eeeb8-d388-4a20-8737-999299bc8ac2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-304eeeb8-d388-4a20-8737-999299bc8ac2">
											<gml:posList>35.67420346679104 139.73780330677312 25.797 35.67420346679104 139.73780330677312 25.661 35.67419999614554 139.73779149084845 25.661 35.67419999614554 139.73779149084845 25.797 35.67420346679104 139.73780330677312 25.797</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f89db8b3-88d8-4880-8655-08521d4112b9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f89db8b3-88d8-4880-8655-08521d4112b9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f89db8b3-88d8-4880-8655-08521d4112b9">
											<gml:posList>35.67430182035446 139.73778665251095 23.728 35.67430182035446 139.73778665251095 23.325 35.67421153603733 139.7378285059255 23.325 35.67421153603733 139.7378285059255 23.728 35.67430182035446 139.73778665251095 23.728</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-16f28eac-9688-4c69-85c5-fe1e8ef9b213">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-16f28eac-9688-4c69-85c5-fe1e8ef9b213">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-16f28eac-9688-4c69-85c5-fe1e8ef9b213">
											<gml:posList>35.67420931431069 139.7378343854629 9.055 35.67430653664054 139.73778930916865 9.055 35.67430653664054 139.73778930916865 23.728 35.67420931431069 139.7378343854629 23.728 35.67420931431069 139.7378343854629 9.055</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0a2176ce-840e-49fb-a472-dc279f215f70">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0a2176ce-840e-49fb-a472-dc279f215f70">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0a2176ce-840e-49fb-a472-dc279f215f70">
											<gml:posList>35.67421153603733 139.7378285059255 23.728 35.67421153603733 139.7378285059255 23.325 35.67420509188047 139.73780660782566 23.325 35.67420509188047 139.73780660782566 23.728 35.67421153603733 139.7378285059255 23.728</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂三丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-10661</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">94.48055</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1221</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>5</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.02</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>