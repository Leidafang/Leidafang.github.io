<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_0a0beb6d-c69d-4d79-86d4-cd38b9efe69a">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">401</bldg:usage>
			<bldg:measuredHeight uom="m">25.2</bldg:measuredHeight>
			<bldg:storeysAboveGround>7</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.671147676951925 139.7403232546541 0 35.671139034700104 139.7403374040257 0 35.67111490345578 139.74031213584982 0 35.67105570373547 139.7403970294754 0 35.67095882163968 139.74030037584603 0 35.67089940000203 139.7403896991507 0 35.670996462471926 139.74048657353464 0 35.670982957559794 139.74050691444407 0 35.671060625459205 139.7405843699205 0 35.671199546189584 139.740375432776 0 35.671147676951925 139.7403232546541 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671147676951925 139.7403232546541 9.63 35.671199546189584 139.740375432776 9.63 35.671060625459205 139.7405843699205 9.63 35.670982957559794 139.74050691444407 9.63 35.670996462471926 139.74048657353464 9.63 35.67089940000203 139.7403896991507 9.63 35.67095882163968 139.74030037584603 9.63 35.67105570373547 139.7403970294754 9.63 35.67111490345578 139.74031213584982 9.63 35.671139034700104 139.7403374040257 9.63 35.671147676951925 139.7403232546541 9.63</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671147676951925 139.7403232546541 9.63 35.671139034700104 139.7403374040257 9.63 35.671139034700104 139.7403374040257 34.85 35.671147676951925 139.7403232546541 34.85 35.671147676951925 139.7403232546541 9.63</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671139034700104 139.7403374040257 9.63 35.67111490345578 139.74031213584982 9.63 35.67111490345578 139.74031213584982 34.85 35.671139034700104 139.7403374040257 34.85 35.671139034700104 139.7403374040257 9.63</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67111490345578 139.74031213584982 9.63 35.67105570373547 139.7403970294754 9.63 35.67105570373547 139.7403970294754 34.85 35.67111490345578 139.74031213584982 34.85 35.67111490345578 139.74031213584982 9.63</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67105570373547 139.7403970294754 9.63 35.67095882163968 139.74030037584603 9.63 35.67095882163968 139.74030037584603 34.85 35.67105570373547 139.7403970294754 34.85 35.67105570373547 139.7403970294754 9.63</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67095882163968 139.74030037584603 9.63 35.67089940000203 139.7403896991507 9.63 35.67089940000203 139.7403896991507 34.85 35.67095882163968 139.74030037584603 34.85 35.67095882163968 139.74030037584603 9.63</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67089940000203 139.7403896991507 9.63 35.670996462471926 139.74048657353464 9.63 35.670996462471926 139.74048657353464 34.85 35.67089940000203 139.7403896991507 34.85 35.67089940000203 139.7403896991507 9.63</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670996462471926 139.74048657353464 9.63 35.670982957559794 139.74050691444407 9.63 35.670982957559794 139.74050691444407 34.85 35.670996462471926 139.74048657353464 34.85 35.670996462471926 139.74048657353464 9.63</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670982957559794 139.74050691444407 9.63 35.671060625459205 139.7405843699205 9.63 35.671060625459205 139.7405843699205 34.85 35.670982957559794 139.74050691444407 34.85 35.670982957559794 139.74050691444407 9.63</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671060625459205 139.7405843699205 9.63 35.671199546189584 139.740375432776 9.63 35.671199546189584 139.740375432776 34.85 35.671060625459205 139.7405843699205 34.85 35.671060625459205 139.7405843699205 9.63</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671199546189584 139.740375432776 9.63 35.671147676951925 139.7403232546541 9.63 35.671147676951925 139.7403232546541 34.85 35.671199546189584 139.740375432776 34.85 35.671199546189584 139.740375432776 9.63</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671147676951925 139.7403232546541 34.85 35.671139034700104 139.7403374040257 34.85 35.67111490345578 139.74031213584982 34.85 35.67105570373547 139.7403970294754 34.85 35.67095882163968 139.74030037584603 34.85 35.67089940000203 139.7403896991507 34.85 35.670996462471926 139.74048657353464 34.85 35.670982957559794 139.74050691444407 34.85 35.671060625459205 139.7405843699205 34.85 35.671199546189584 139.740375432776 34.85 35.671147676951925 139.7403232546541 34.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-c066444d-3ee3-4535-973c-78e98a06352b"/>
							<gml:surfaceMember xlink:href="#poly-16088f2b-1ef7-404b-849d-f348137e74a6"/>
							<gml:surfaceMember xlink:href="#poly-14de22e3-c648-4a8f-b73a-dfa2be69a613"/>
							<gml:surfaceMember xlink:href="#poly-4b20e078-ad6d-4514-8be5-4f20b521b56a"/>
							<gml:surfaceMember xlink:href="#poly-83fef035-7118-4328-9023-2d423c3bffad"/>
							<gml:surfaceMember xlink:href="#poly-4199bff8-4a06-426d-8e7d-cd9f505c231f"/>
							<gml:surfaceMember xlink:href="#poly-7e561c3b-3a19-489e-9e1b-c270aced7405"/>
							<gml:surfaceMember xlink:href="#poly-f0051e64-f3b3-4b64-bf85-d112d9fe727d"/>
							<gml:surfaceMember xlink:href="#poly-0d8ebe80-bafd-4067-8ff1-7abf95a8d8da"/>
							<gml:surfaceMember xlink:href="#poly-8fa0fc64-2847-4a94-9575-da5463177bfd"/>
							<gml:surfaceMember xlink:href="#poly-1cadfca0-efcd-479f-b223-4b737c445fe6"/>
							<gml:surfaceMember xlink:href="#poly-827415e0-15a6-4077-bcc4-d53dea9414dc"/>
							<gml:surfaceMember xlink:href="#poly-84caa601-b266-4fd1-b74b-f699d676aa19"/>
							<gml:surfaceMember xlink:href="#poly-1e079520-c20c-4885-a6f1-fa862f197c05"/>
							<gml:surfaceMember xlink:href="#poly-2fcff183-e990-4e9c-8dc1-463d8ac72751"/>
							<gml:surfaceMember xlink:href="#poly-f434e003-e22d-4d2e-a975-fe4767d05444"/>
							<gml:surfaceMember xlink:href="#poly-871a119c-b556-48da-b31c-bb5c81cc594a"/>
							<gml:surfaceMember xlink:href="#poly-cc94ddfa-e750-471a-920a-dee6672d2729"/>
							<gml:surfaceMember xlink:href="#poly-7872274b-0a87-4c5a-94e2-0feb96f419e2"/>
							<gml:surfaceMember xlink:href="#poly-13e4ba1b-6c5e-421c-9b92-9e4349ed5699"/>
							<gml:surfaceMember xlink:href="#poly-844b1f2a-0a16-46f0-bc1e-eea7ac843dd7"/>
							<gml:surfaceMember xlink:href="#poly-a6a56d76-2307-4ffe-9a14-47c089ff1a4e"/>
							<gml:surfaceMember xlink:href="#poly-cbf63bf1-361c-4468-98ab-4ec98060830b"/>
							<gml:surfaceMember xlink:href="#poly-bb828c70-cb09-46ec-9f2d-f779dea2826e"/>
							<gml:surfaceMember xlink:href="#poly-9080ad0b-d2e6-4afa-8086-4ad04a73c7c4"/>
							<gml:surfaceMember xlink:href="#poly-bad48473-c0e0-4e7a-8e6f-90a831ffbb14"/>
							<gml:surfaceMember xlink:href="#poly-f87716e8-64ee-4184-a6e6-d560b6f6b589"/>
							<gml:surfaceMember xlink:href="#poly-bcf0c3e6-d4a6-40a8-a6c5-b88450499542"/>
							<gml:surfaceMember xlink:href="#poly-cccbb4dd-c404-4665-8ddd-8c001b4eb73c"/>
							<gml:surfaceMember xlink:href="#poly-e772ac52-11c8-4087-9a7a-d8c4d6ff4345"/>
							<gml:surfaceMember xlink:href="#poly-85903320-310c-4cd4-aa1d-9e5f862262b3"/>
							<gml:surfaceMember xlink:href="#poly-998356af-a2de-4049-a05d-0d1a68c169b2"/>
							<gml:surfaceMember xlink:href="#poly-33555018-15a4-4d0e-886d-23bf13638e43"/>
							<gml:surfaceMember xlink:href="#poly-a9a0608b-d3fa-4f1b-a271-bc90b7522ca8"/>
							<gml:surfaceMember xlink:href="#poly-e20d15d3-3026-4c73-a08a-7ef933fb5738"/>
							<gml:surfaceMember xlink:href="#poly-7bf9cbed-4d2d-451a-ac61-e2714a71ee71"/>
							<gml:surfaceMember xlink:href="#poly-dffac438-c41b-4173-b67f-c187cc3ff501"/>
							<gml:surfaceMember xlink:href="#poly-7f5a79bd-dabc-45e8-8178-7e24d9a36e5d"/>
							<gml:surfaceMember xlink:href="#poly-b469357d-77aa-4c31-8bb3-092b8d4070a9"/>
							<gml:surfaceMember xlink:href="#poly-1a95a5e4-bfef-407e-a263-bc31f1610e35"/>
							<gml:surfaceMember xlink:href="#poly-29111569-a8c8-471e-b774-7733f7fb4e28"/>
							<gml:surfaceMember xlink:href="#poly-73732fe2-39cf-4c5e-b1ec-3ad7c085cbfe"/>
							<gml:surfaceMember xlink:href="#poly-aa7d5421-911f-4997-a183-55383a9060eb"/>
							<gml:surfaceMember xlink:href="#poly-f474af9c-9422-4493-87a7-045e6ac6c7b5"/>
							<gml:surfaceMember xlink:href="#poly-d33b3286-46fa-4f92-a8ff-51d58948f0eb"/>
							<gml:surfaceMember xlink:href="#poly-ccca72d4-fed4-4fc4-b0a7-900148877dd4"/>
							<gml:surfaceMember xlink:href="#poly-f5c83225-0f7d-4c71-bc57-d0e302e80429"/>
							<gml:surfaceMember xlink:href="#poly-13c39578-be92-44ad-ace3-ca14076f276b"/>
							<gml:surfaceMember xlink:href="#poly-9969d3cd-c8d8-4562-a703-b848a8e1b8f2"/>
							<gml:surfaceMember xlink:href="#poly-d2a7a448-2560-425b-8cb5-02b437e4b407"/>
							<gml:surfaceMember xlink:href="#poly-28f84f9d-f1e2-4bf3-97ed-97ee02fae919"/>
							<gml:surfaceMember xlink:href="#poly-87b38415-62e4-4846-b69c-66eaa32acc2d"/>
							<gml:surfaceMember xlink:href="#poly-9c83c83d-441e-4e35-9c6f-fb5dea3ce925"/>
							<gml:surfaceMember xlink:href="#poly-ce8e1482-1a6c-4eab-9912-2c863fb06748"/>
							<gml:surfaceMember xlink:href="#poly-1a7d4fcc-b9c4-47fc-8186-3eafc3b09878"/>
							<gml:surfaceMember xlink:href="#poly-a4962d0d-6b31-4128-96f7-7c0d95330977"/>
							<gml:surfaceMember xlink:href="#poly-be219c9f-dd72-4b7b-be3e-1f53e5431fcf"/>
							<gml:surfaceMember xlink:href="#poly-e5aec15a-9186-467f-b8df-694945363ba8"/>
							<gml:surfaceMember xlink:href="#poly-7e203c5c-5c2e-43d0-a800-28ea7e74a9f1"/>
							<gml:surfaceMember xlink:href="#poly-34b7efd5-c44f-4fa9-b14b-4630722c2cf9"/>
							<gml:surfaceMember xlink:href="#poly-acb43fcb-ce2c-4951-8e51-60aa0169de66"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_0a0beb6d-c69d-4d79-86d4-cd38b9efe69a_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-faaa344b-6e9e-4002-894b-63e8744a22c4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67095001783689 139.74040881691485 34.813 35.67094520091719 139.74041584796822 34.813 35.670930884751634 139.74040110665555 34.813 35.67093570167049 139.74039407560255 34.813 35.67095001783689 139.74040881691485 34.813</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-447aee79-30f0-4bdc-96a5-15def0f5461a">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67096075250863 139.74039625583168 34.813 35.67095607964724 139.74040307683933 34.813 35.670941023766616 139.74038757418722 34.813 35.67094569662713 139.74038075317998 34.813 35.67096075250863 139.74039625583168 34.813</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b0b320ea-db6e-4763-9269-fa824c03f130">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67097130473017 139.74038087813975 34.813 35.67096605562244 139.74038851724637 34.813 35.67095228972554 139.74037433866002 34.813 35.670957529810146 139.7403666885179 34.813 35.67097130473017 139.74038087813975 34.813</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e9d19208-978a-4ff0-911f-0a802d31a67c">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67096204962383 139.74036011070493 34.813 35.670975815522375 139.74037428929057 34.813 35.670975815522375 139.74037428929057 36.345 35.67096204962383 139.74036011070493 36.345 35.67096204962383 139.74036011070493 34.813</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-099eb18b-9c3d-4b23-88bf-2532cd9bbf97">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67098086653201 139.740366915524 34.813 35.670975815522375 139.74037428929057 34.813 35.67096204962383 139.74036011070493 34.813 35.6709671006326 139.74035273693872 34.813 35.67098086653201 139.740366915524 34.813</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-59543236-56a2-4ddd-b8cc-4499c5ad4047">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67097008744929 139.74042704220884 34.813 35.670964259820494 139.74042087405778 34.813 35.67097602788315 139.74040418044453 34.813 35.67098184649055 139.74041033755938 34.813 35.67097008744929 139.74042704220884 34.813</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d69a1e74-9e68-4987-be17-c773daff8979">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67097008744929 139.74042704220884 34.813 35.67098184649055 139.74041033755938 34.813 35.67098184649055 139.74041033755938 36.345 35.67097008744929 139.74042704220884 36.345 35.67097008744929 139.74042704220884 34.813</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-75000098-b7b2-4b2d-9a81-7990fbcef7f4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670977979700055 139.74035208363435 34.813 35.67097093436195 139.74034481226633 34.813 35.67097596736792 139.74033747165825 34.813 35.670983021711656 139.74034473196926 34.813 35.670977979700055 139.74035208363435 34.813</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bde45ef1-a16a-4f88-9d7e-aeb616dc3161">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670981220225364 139.74043978783365 34.813 35.670975464766656 139.74043369692157 34.813 35.67098761999491 139.74041645054203 34.813 35.67099337544596 139.74042253040747 34.813 35.670981220225364 139.74043978783365 34.813</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-290b1a76-0f98-4246-b443-86c8d1876dd9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670985700928156 139.74034750149394 34.813 35.670992403454655 139.74035439768537 34.813 35.67098736143394 139.74036173830436 34.813 35.670980667921576 139.7403548421023 34.813 35.670985700928156 139.74034750149394 34.813</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cc65aef5-8ac3-4ec7-930b-c73a32e63aa9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67098269880133 139.7404518929119 34.813 35.67099911286072 139.7404285992483 34.813 35.6710049224446 139.74043474533082 34.813 35.67098850838405 139.7404580389948 34.813 35.67098269880133 139.7404518929119 34.813</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c1d58fcc-2b00-47e7-8890-3568b337878d">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6710163075103 139.74044736916014 34.813 35.6710031151459 139.74046389873007 34.813 35.670997846259 139.74045758632408 34.813 35.671011047636256 139.74044105674378 34.813 35.6710163075103 139.74044736916014 34.813</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4616b651-7546-43c0-950e-1f15a9bad5e8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671009478310985 139.7405333618304 35.389 35.671011828159564 139.7405298132333 35.389 35.6710188732992 139.74053684160188 35.389 35.67101940104091 139.740543258919 35.389 35.671009478310985 139.7405333618304 35.389</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bfeb4e33-0ac1-4d87-9d56-3e7d9d576fdd">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67105563864763 139.74046454485733 34.813 35.67103189532645 139.74043967388846 34.813 35.671036496250515 139.74043307388683 34.813 35.67106024858677 139.7404579448447 34.813 35.67105563864763 139.74046454485733 34.813</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-850ae9df-349a-4952-ba51-dd3bbd197e06">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67105431178036 139.74041541221914 41.17 35.671062862618726 139.74042295801507 41.17 35.67105715541938 139.7404326854192 41.17 35.671048604590126 139.74042515066907 41.17 35.67105431178036 139.74041541221914 41.17</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3e6bda84-36b9-4fa7-8eae-6ce18f07a29b">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67107188420344 139.74042145630264 41.17 35.67106046412025 139.74041018016393 41.17 35.67106979139805 139.7403959968809 41.17 35.671081211482544 139.7404072730189 41.17 35.67107188420344 139.74042145630264 41.17</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-44f60046-b17d-4f5a-8616-455e22ad8035">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671082108193545 139.74036620162744 35.389 35.67107334753023 139.74037876044503 35.389 35.67107162451941 139.74037696188685 35.389 35.67108038517401 139.74036439202297 35.389 35.671082108193545 139.74036620162744 35.389</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-13489f9f-5cf8-4dbb-b9eb-47f32eef0ca9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671153815633616 139.74033535434984 34.813 35.6710188732992 139.74053684160188 34.813 35.671011828159564 139.7405298132333 34.813 35.67101263845802 139.74052859719725 34.813 35.67101869132216 139.74053463254302 34.813 35.67115202206514 139.74033556631122 34.813 35.67114755680061 139.74033107561996 34.813 35.671148312989125 139.74032982650354 34.813 35.671153815633616 139.74033535434984 34.813</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-663819eb-9234-4d6e-99a6-e15ea2c64efe">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671153815633616 139.74033535434984 35.389 35.671159070146956 139.74033471861205 35.389 35.67101940104091 139.740543258919 35.389 35.6710188732992 139.74053684160188 35.389 35.671153815633616 139.74033535434984 35.389</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-906d55ba-67c7-4a5e-be02-29e70acadb14">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67107334753023 139.74037876044503 34.813 35.671082108193545 139.74036620162744 34.813 35.67110531928528 139.7403905098427 34.813 35.67109655861947 139.7404030686613 34.813 35.67107334753023 139.74037876044503 34.813</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-93dbce93-ba5d-468b-bb80-bf08a279d0da">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671092176827614 139.74036658762125 34.813 35.67109753406436 139.74035890419032 34.813 35.67111277058092 139.74037487060494 34.813 35.67110741334316 139.74038255403624 34.813 35.671092176827614 139.74036658762125 34.813</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2b6a184f-d594-4b09-92ae-4a6239b4e86a">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67112012181218 139.74036972552358 34.813 35.671101583312975 139.74034992985128 34.813 35.67110639141969 139.74034316390308 34.813 35.671124938933715 139.74036295956452 34.813 35.67112012181218 139.74036972552358 34.813</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-af073d04-86d8-4848-bf7e-0ffe79c8cb2e">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67112099883196 139.74033818714457 34.813 35.67111570451347 139.7403456385326 34.813 35.671109010812614 139.74033849930115 34.813 35.67111430513068 139.7403310479133 34.813 35.67112099883196 139.74033818714457 34.813</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0bc49ebe-5077-4217-a200-65090ef6c699">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671118399599145 139.74034561331413 34.813 35.671123189703756 139.7403388805242 34.813 35.6711303795687 139.7403465494069 34.813 35.671125589472204 139.74035329324332 34.813 35.671118399599145 139.74034561331413 34.813</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c0b11252-fe4b-40ea-85af-a6ffffca47b0">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671153815633616 139.74033535434984 35.389 35.671148312989125 139.74032982650354 35.389 35.67114755680061 139.74033107561996 35.389 35.67114524749621 139.74032875856213 35.389 35.67114842567102 139.74032400493832 35.389 35.671159070146956 139.74033471861205 35.389 35.671153815633616 139.74033535434984 35.389</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e89eb564-a6e1-461c-af2d-1c2548006936">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e89eb564-a6e1-461c-af2d-1c2548006936_0">
											<gml:posList>35.67095228972554 139.74037433866002 34.813 35.67096605562244 139.74038851724637 34.813 35.67096605562244 139.74038851724637 36.345 35.67095228972554 139.74037433866002 36.345 35.67095228972554 139.74037433866002 34.813</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-75ad4d1f-8ea4-41fd-b291-dcafaa6e3e39">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-75ad4d1f-8ea4-41fd-b291-dcafaa6e3e39_0">
											<gml:posList>35.670980667921576 139.7403548421023 34.813 35.670980667921576 139.7403548421023 36.352 35.670985700928156 139.74034750149394 36.352 35.670985700928156 139.74034750149394 34.813 35.670980667921576 139.7403548421023 34.813</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-17ab4d5a-d0fe-489d-af41-acf65c71860e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-17ab4d5a-d0fe-489d-af41-acf65c71860e_0">
											<gml:posList>35.670981220225364 139.74043978783365 34.813 35.67099337544596 139.74042253040747 34.813 35.67099337544596 139.74042253040747 36.345 35.670981220225364 139.74043978783365 36.345 35.670981220225364 139.74043978783365 34.813</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ada3e5ea-7ed1-44d5-80f3-2d81cb3ac45b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ada3e5ea-7ed1-44d5-80f3-2d81cb3ac45b_0">
											<gml:posList>35.6710031151459 139.74046389873007 34.813 35.6710163075103 139.74044736916014 34.813 35.6710163075103 139.74044736916014 36.345 35.6710031151459 139.74046389873007 36.345 35.6710031151459 139.74046389873007 34.813</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3130c080-6ca3-4d40-bb35-ea4ae701b0c8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3130c080-6ca3-4d40-bb35-ea4ae701b0c8_0">
											<gml:posList>35.67109655861947 139.7404030686613 34.813 35.67110531928528 139.7403905098427 34.813 35.67110531928528 139.7403905098427 36.022 35.67109655861947 139.7404030686613 36.022 35.67109655861947 139.7404030686613 34.813</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e7b02d56-893a-4b6a-88a6-0eae1000d614">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e7b02d56-893a-4b6a-88a6-0eae1000d614_0">
											<gml:posList>35.67111277058092 139.74037487060494 34.813 35.67109753406436 139.74035890419032 34.813 35.67109753406436 139.74035890419032 36.114 35.67111277058092 139.74037487060494 36.114 35.67111277058092 139.74037487060494 34.813</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-64fdb795-14c1-495f-a742-6ec0a5c79140">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-64fdb795-14c1-495f-a742-6ec0a5c79140_0">
											<gml:posList>35.67110741334316 139.74038255403624 34.813 35.67111277058092 139.74037487060494 34.813 35.67111277058092 139.74037487060494 36.114 35.67110741334316 139.74038255403624 36.114 35.67110741334316 139.74038255403624 34.813</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-189f97ea-9f76-4894-b4e7-5a4b3225193c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-189f97ea-9f76-4894-b4e7-5a4b3225193c_0">
											<gml:posList>35.67111570451347 139.7403456385326 34.813 35.67112099883196 139.74033818714457 34.813 35.67112099883196 139.74033818714457 36.114 35.67111570451347 139.7403456385326 36.114 35.67111570451347 139.7403456385326 34.813</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a2f2e2c3-4707-44a6-889a-69c189975625">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a2f2e2c3-4707-44a6-889a-69c189975625_0">
											<gml:posList>35.671125589472204 139.74035329324332 34.813 35.671125589472204 139.74035329324332 36.114 35.671118399599145 139.74034561331413 36.114 35.671118399599145 139.74034561331413 34.813 35.671125589472204 139.74035329324332 34.813</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a99eb508-641e-4912-bd7b-0d81fdad95fc">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a99eb508-641e-4912-bd7b-0d81fdad95fc_0">
											<gml:posList>35.67112012181218 139.74036972552358 34.813 35.671124938933715 139.74036295956452 34.813 35.671124938933715 139.74036295956452 36.114 35.67112012181218 139.74036972552358 36.114 35.67112012181218 139.74036972552358 34.813</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5f0382c1-1032-41a5-8738-e8fa1293cc40">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5f0382c1-1032-41a5-8738-e8fa1293cc40_0">
											<gml:posList>35.671125589472204 139.74035329324332 34.813 35.6711303795687 139.7403465494069 34.813 35.6711303795687 139.7403465494069 36.114 35.671125589472204 139.74035329324332 36.114 35.671125589472204 139.74035329324332 34.813</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0202ef59-31b8-4a52-b4db-0510f9a3ce0d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0202ef59-31b8-4a52-b4db-0510f9a3ce0d_0">
											<gml:posList>35.67114524749621 139.74032875856213 35.389 35.67114524749621 139.74032875856213 36.904 35.67114842567102 139.74032400493832 36.904 35.67114842567102 139.74032400493832 35.389 35.67114524749621 139.74032875856213 35.389</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4e1c6d8f-b5a7-4c7b-99b6-04024e764729">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4e1c6d8f-b5a7-4c7b-99b6-04024e764729_0">
											<gml:posList>35.67114842567102 139.74032400493832 35.389 35.67114842567102 139.74032400493832 36.904 35.671159070146956 139.74033471861205 36.904 35.671159070146956 139.74033471861205 35.389 35.67114842567102 139.74032400493832 35.389</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3363dab9-bd59-48c6-b73d-34fdc16c0487">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3363dab9-bd59-48c6-b73d-34fdc16c0487_0">
											<gml:posList>35.671148312989125 139.74032982650354 34.813 35.67114755680061 139.74033107561996 34.813 35.67114755680061 139.74033107561996 35.389 35.671148312989125 139.74032982650354 35.389 35.671148312989125 139.74032982650354 34.813</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7f2890df-0498-4c76-a5cb-357d2ab12381">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7f2890df-0498-4c76-a5cb-357d2ab12381_0">
											<gml:posList>35.67115202206514 139.74033556631122 34.813 35.67115202206514 139.74033556631122 36.904 35.67114524749621 139.74032875856213 36.904 35.67114524749621 139.74032875856213 35.389 35.67114755680061 139.74033107561996 35.389 35.67114755680061 139.74033107561996 34.813 35.67115202206514 139.74033556631122 34.813</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ed9b89cc-b3e4-4b52-b968-e6e9e38ba9c1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ed9b89cc-b3e4-4b52-b968-e6e9e38ba9c1_0">
											<gml:posList>35.671148312989125 139.74032982650354 35.389 35.671153815633616 139.74033535434984 35.389 35.671153815633616 139.74033535434984 34.813 35.671148312989125 139.74032982650354 34.813 35.671148312989125 139.74032982650354 35.389</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fb132334-751e-448f-be32-550005d6b628">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fb132334-751e-448f-be32-550005d6b628_0">
											<gml:posList>35.67112099883196 139.74033818714457 34.813 35.67111430513068 139.7403310479133 34.813 35.67111430513068 139.7403310479133 36.114 35.67112099883196 139.74033818714457 36.114 35.67112099883196 139.74033818714457 34.813</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f2c42f23-2f21-4fed-adf1-c9fbf3a48014">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f2c42f23-2f21-4fed-adf1-c9fbf3a48014_0">
											<gml:posList>35.67111430513068 139.7403310479133 34.813 35.671109010812614 139.74033849930115 34.813 35.671109010812614 139.74033849930115 36.114 35.67111430513068 139.7403310479133 36.114 35.67111430513068 139.7403310479133 34.813</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fb19eab6-56e8-4774-8a16-5bd3a020812e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fb19eab6-56e8-4774-8a16-5bd3a020812e_0">
											<gml:posList>35.671109010812614 139.74033849930115 36.114 35.67111570451347 139.7403456385326 36.114 35.67112099883196 139.74033818714457 36.114 35.67111430513068 139.7403310479133 36.114 35.671109010812614 139.74033849930115 36.114</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-70a5b59a-c3f7-4025-9183-885851d3b930">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-70a5b59a-c3f7-4025-9183-885851d3b930_0">
											<gml:posList>35.67097596736792 139.74033747165825 34.813 35.67097596736792 139.74033747165825 36.352 35.670983021711656 139.74034473196926 36.352 35.670983021711656 139.74034473196926 34.813 35.67097596736792 139.74033747165825 34.813</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-41a35369-e655-4945-9724-761fdc6dc199">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-41a35369-e655-4945-9724-761fdc6dc199_0">
											<gml:posList>35.67097093436195 139.74034481226633 34.813 35.67097093436195 139.74034481226633 36.352 35.67097596736792 139.74033747165825 36.352 35.67097596736792 139.74033747165825 34.813 35.67097093436195 139.74034481226633 34.813</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bd03e180-3822-45b7-a406-dc4e04d3112b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bd03e180-3822-45b7-a406-dc4e04d3112b_0">
											<gml:posList>35.671109010812614 139.74033849930115 34.813 35.67111570451347 139.7403456385326 34.813 35.67111570451347 139.7403456385326 36.114 35.671109010812614 139.74033849930115 36.114 35.671109010812614 139.74033849930115 34.813</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-dcea3a31-d521-4471-89e6-55d5a78ceaa8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-dcea3a31-d521-4471-89e6-55d5a78ceaa8_0">
											<gml:posList>35.671123189703756 139.7403388805242 34.813 35.671118399599145 139.74034561331413 34.813 35.671118399599145 139.74034561331413 36.114 35.671123189703756 139.7403388805242 36.114 35.671123189703756 139.7403388805242 34.813</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d9465e39-97c5-4006-81fd-0ba172768eba">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d9465e39-97c5-4006-81fd-0ba172768eba_0">
											<gml:posList>35.6711303795687 139.7403465494069 34.813 35.671123189703756 139.7403388805242 34.813 35.671123189703756 139.7403388805242 36.114 35.6711303795687 139.7403465494069 36.114 35.6711303795687 139.7403465494069 34.813</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-36b9138a-ce65-4504-a739-00f436d36b97">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-36b9138a-ce65-4504-a739-00f436d36b97_0">
											<gml:posList>35.67097596736792 139.74033747165825 36.352 35.67097093436195 139.74034481226633 36.352 35.670977979700055 139.74035208363435 36.352 35.670983021711656 139.74034473196926 36.352 35.67097596736792 139.74033747165825 36.352</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-94c4800b-c18b-4214-b6a5-12a106e2c20b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-94c4800b-c18b-4214-b6a5-12a106e2c20b_0">
											<gml:posList>35.6711303795687 139.7403465494069 36.114 35.671123189703756 139.7403388805242 36.114 35.671118399599145 139.74034561331413 36.114 35.671125589472204 139.74035329324332 36.114 35.6711303795687 139.7403465494069 36.114</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bcf7f60b-6e8a-4b48-9833-ee037b514b48">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bcf7f60b-6e8a-4b48-9833-ee037b514b48_0">
											<gml:posList>35.67110639141969 139.74034316390308 34.813 35.671101583312975 139.74034992985128 34.813 35.671101583312975 139.74034992985128 36.114 35.67110639141969 139.74034316390308 36.114 35.67110639141969 139.74034316390308 34.813</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1c26b364-de6e-4914-a700-a32b0b55f264">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1c26b364-de6e-4914-a700-a32b0b55f264_0">
											<gml:posList>35.670977979700055 139.74035208363435 34.813 35.670983021711656 139.74034473196926 34.813 35.670983021711656 139.74034473196926 36.352 35.670977979700055 139.74035208363435 36.352 35.670977979700055 139.74035208363435 34.813</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9372e444-a8c5-4988-b3dc-6fbdc5255850">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9372e444-a8c5-4988-b3dc-6fbdc5255850_0">
											<gml:posList>35.67097093436195 139.74034481226633 34.813 35.670977979700055 139.74035208363435 34.813 35.670977979700055 139.74035208363435 36.352 35.67097093436195 139.74034481226633 36.352 35.67097093436195 139.74034481226633 34.813</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-89231bde-830e-496f-889a-4ca4882d01d7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-89231bde-830e-496f-889a-4ca4882d01d7_0">
											<gml:posList>35.670992403454655 139.74035439768537 34.813 35.670985700928156 139.74034750149394 34.813 35.670985700928156 139.74034750149394 36.352 35.670992403454655 139.74035439768537 36.352 35.670992403454655 139.74035439768537 34.813</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-75bc027f-717e-472d-b108-622d78c21c38">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-75bc027f-717e-472d-b108-622d78c21c38_0">
											<gml:posList>35.671124938933715 139.74036295956452 34.813 35.67110639141969 139.74034316390308 34.813 35.67110639141969 139.74034316390308 36.114 35.671124938933715 139.74036295956452 36.114 35.671124938933715 139.74036295956452 34.813</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-487a53de-b9f3-471f-991b-cefb63152bc4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-487a53de-b9f3-471f-991b-cefb63152bc4_0">
											<gml:posList>35.67098736143394 139.74036173830436 36.352 35.670992403454655 139.74035439768537 36.352 35.670985700928156 139.74034750149394 36.352 35.670980667921576 139.7403548421023 36.352 35.67098736143394 139.74036173830436 36.352</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-38712427-5bdf-4a22-a773-8e13f1f54958">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-38712427-5bdf-4a22-a773-8e13f1f54958_0">
											<gml:posList>35.6709671006326 139.74035273693872 34.813 35.67096204962383 139.74036011070493 34.813 35.67096204962383 139.74036011070493 36.345 35.6709671006326 139.74035273693872 36.345 35.6709671006326 139.74035273693872 34.813</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5f02b06e-a87e-429a-99b3-418b20167b7d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5f02b06e-a87e-429a-99b3-418b20167b7d_0">
											<gml:posList>35.67112012181218 139.74036972552358 36.114 35.671124938933715 139.74036295956452 36.114 35.67110639141969 139.74034316390308 36.114 35.671101583312975 139.74034992985128 36.114 35.67112012181218 139.74036972552358 36.114</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-57ec47ea-3541-4556-903c-31710d3dc482">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-57ec47ea-3541-4556-903c-31710d3dc482_0">
											<gml:posList>35.67098736143394 139.74036173830436 34.813 35.670992403454655 139.74035439768537 34.813 35.670992403454655 139.74035439768537 36.352 35.67098736143394 139.74036173830436 36.352 35.67098736143394 139.74036173830436 34.813</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9ea4acef-6fa2-49c2-9c20-bd91b0243a65">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9ea4acef-6fa2-49c2-9c20-bd91b0243a65_0">
											<gml:posList>35.670980667921576 139.7403548421023 34.813 35.67098736143394 139.74036173830436 34.813 35.67098736143394 139.74036173830436 36.352 35.670980667921576 139.7403548421023 36.352 35.670980667921576 139.7403548421023 34.813</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9f5d810e-302d-4f3c-95f6-e68820227e90">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9f5d810e-302d-4f3c-95f6-e68820227e90_0">
											<gml:posList>35.6709671006326 139.74035273693872 34.813 35.6709671006326 139.74035273693872 36.345 35.67098086653201 139.740366915524 36.345 35.67098086653201 139.740366915524 34.813 35.6709671006326 139.74035273693872 34.813</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7b96b3dc-608c-4b7e-9db0-bb1e914e2b2d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7b96b3dc-608c-4b7e-9db0-bb1e914e2b2d_0">
											<gml:posList>35.67112012181218 139.74036972552358 34.813 35.67112012181218 139.74036972552358 36.114 35.671101583312975 139.74034992985128 36.114 35.671101583312975 139.74034992985128 34.813 35.67112012181218 139.74036972552358 34.813</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cf57d773-cade-4dc4-a10b-6e87734acc5c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cf57d773-cade-4dc4-a10b-6e87734acc5c_0">
											<gml:posList>35.67109753406436 139.74035890419032 34.813 35.671092176827614 139.74036658762125 34.813 35.671092176827614 139.74036658762125 36.114 35.67109753406436 139.74035890419032 36.114 35.67109753406436 139.74035890419032 34.813</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ad14ec19-56d4-427d-9625-af4a51cfd39d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ad14ec19-56d4-427d-9625-af4a51cfd39d_0">
											<gml:posList>35.67096204962383 139.74036011070493 36.345 35.670975815522375 139.74037428929057 36.345 35.67098086653201 139.740366915524 36.345 35.6709671006326 139.74035273693872 36.345 35.67096204962383 139.74036011070493 36.345</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8d110374-08e0-40a7-a371-af93382ee51e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8d110374-08e0-40a7-a371-af93382ee51e_0">
											<gml:posList>35.670957529810146 139.7403666885179 34.813 35.67095228972554 139.74037433866002 34.813 35.67095228972554 139.74037433866002 36.345 35.670957529810146 139.7403666885179 36.345 35.670957529810146 139.7403666885179 34.813</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-515886de-e9ce-4bf9-89fe-2617a3cffb6f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-515886de-e9ce-4bf9-89fe-2617a3cffb6f_0">
											<gml:posList>35.670975815522375 139.74037428929057 34.813 35.67098086653201 139.740366915524 34.813 35.67098086653201 139.740366915524 36.345 35.670975815522375 139.74037428929057 36.345 35.670975815522375 139.74037428929057 34.813</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9bc58d10-04a6-419a-8061-5132f718e00f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9bc58d10-04a6-419a-8061-5132f718e00f_0">
											<gml:posList>35.67108038517401 139.74036439202297 35.389 35.67107162451941 139.74037696188685 35.389 35.67107162451941 139.74037696188685 36.022 35.67108038517401 139.74036439202297 36.022 35.67108038517401 139.74036439202297 35.389</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-15de6497-0cd0-4fa4-82fd-a2d0668b7151">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-15de6497-0cd0-4fa4-82fd-a2d0668b7151_0">
											<gml:posList>35.67111277058092 139.74037487060494 36.114 35.67109753406436 139.74035890419032 36.114 35.671092176827614 139.74036658762125 36.114 35.67110741334316 139.74038255403624 36.114 35.67111277058092 139.74037487060494 36.114</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c62864ba-5e4f-4c46-a5b7-01eddf4f217a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c62864ba-5e4f-4c46-a5b7-01eddf4f217a_0">
											<gml:posList>35.67107334753023 139.74037876044503 35.389 35.671082108193545 139.74036620162744 35.389 35.671082108193545 139.74036620162744 34.813 35.67107334753023 139.74037876044503 34.813 35.67107334753023 139.74037876044503 35.389</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-96b23e59-50bc-46ee-a4eb-45e2600bc25d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-96b23e59-50bc-46ee-a4eb-45e2600bc25d_0">
											<gml:posList>35.67097130473017 139.74038087813975 34.813 35.670957529810146 139.7403666885179 34.813 35.670957529810146 139.7403666885179 36.345 35.67097130473017 139.74038087813975 36.345 35.67097130473017 139.74038087813975 34.813</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d0ebe172-9d55-4284-9faf-e2e5571a0993">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d0ebe172-9d55-4284-9faf-e2e5571a0993_0">
											<gml:posList>35.67110741334316 139.74038255403624 34.813 35.67110741334316 139.74038255403624 36.114 35.671092176827614 139.74036658762125 36.114 35.671092176827614 139.74036658762125 34.813 35.67110741334316 139.74038255403624 34.813</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-33b1f49e-89e2-44c3-8d26-c4d6fe354898">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-33b1f49e-89e2-44c3-8d26-c4d6fe354898_0">
											<gml:posList>35.67095228972554 139.74037433866002 36.345 35.67096605562244 139.74038851724637 36.345 35.67097130473017 139.74038087813975 36.345 35.670957529810146 139.7403666885179 36.345 35.67095228972554 139.74037433866002 36.345</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-42fabf6c-c548-43b7-85b1-348bb9edbab4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-42fabf6c-c548-43b7-85b1-348bb9edbab4_0">
											<gml:posList>35.67108038517401 139.74036439202297 36.022 35.67110531928528 139.7403905098427 36.022 35.67110531928528 139.7403905098427 34.813 35.671082108193545 139.74036620162744 34.813 35.671082108193545 139.74036620162744 35.389 35.67108038517401 139.74036439202297 35.389 35.67108038517401 139.74036439202297 36.022</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-33d300fb-13a3-4c2a-9339-07935b2e3acf">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-33d300fb-13a3-4c2a-9339-07935b2e3acf_0">
											<gml:posList>35.67110531928528 139.7403905098427 36.022 35.67108038517401 139.74036439202297 36.022 35.67107162451941 139.74037696188685 36.022 35.67109655861947 139.7404030686613 36.022 35.67110531928528 139.7403905098427 36.022</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-de6975bb-696e-44dd-b5bb-442d67db8856">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-de6975bb-696e-44dd-b5bb-442d67db8856_0">
											<gml:posList>35.67094569662713 139.74038075317998 34.813 35.670941023766616 139.74038757418722 34.813 35.670941023766616 139.74038757418722 36.345 35.67094569662713 139.74038075317998 36.345 35.67094569662713 139.74038075317998 34.813</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-97eb9de3-3a86-404b-b708-f5a351a1a823">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-97eb9de3-3a86-404b-b708-f5a351a1a823_0">
											<gml:posList>35.67096605562244 139.74038851724637 34.813 35.67097130473017 139.74038087813975 34.813 35.67097130473017 139.74038087813975 36.345 35.67096605562244 139.74038851724637 36.345 35.67096605562244 139.74038851724637 34.813</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-db391541-d0eb-4e45-85da-dddfb243e235">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-db391541-d0eb-4e45-85da-dddfb243e235_0">
											<gml:posList>35.67096075250863 139.74039625583168 34.813 35.67094569662713 139.74038075317998 34.813 35.67094569662713 139.74038075317998 36.345 35.67096075250863 139.74039625583168 36.345 35.67096075250863 139.74039625583168 34.813</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8c8449e9-caa2-49a9-ae95-640447aad831">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8c8449e9-caa2-49a9-ae95-640447aad831_0">
											<gml:posList>35.67107334753023 139.74037876044503 35.389 35.67107334753023 139.74037876044503 34.813 35.67109655861947 139.7404030686613 34.813 35.67109655861947 139.7404030686613 36.022 35.67107162451941 139.74037696188685 36.022 35.67107162451941 139.74037696188685 35.389 35.67107334753023 139.74037876044503 35.389</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8238f894-5377-4e78-9c46-a7a84dff04f4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8238f894-5377-4e78-9c46-a7a84dff04f4_0">
											<gml:posList>35.670941023766616 139.74038757418722 36.345 35.67095607964724 139.74040307683933 36.345 35.67096075250863 139.74039625583168 36.345 35.67094569662713 139.74038075317998 36.345 35.670941023766616 139.74038757418722 36.345</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e15b8185-f76d-4f2e-9419-e216b458ef1f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e15b8185-f76d-4f2e-9419-e216b458ef1f_0">
											<gml:posList>35.670941023766616 139.74038757418722 34.813 35.67095607964724 139.74040307683933 34.813 35.67095607964724 139.74040307683933 36.345 35.670941023766616 139.74038757418722 36.345 35.670941023766616 139.74038757418722 34.813</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d3c56876-826a-4afb-8af5-c98025517515">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d3c56876-826a-4afb-8af5-c98025517515_0">
											<gml:posList>35.67093570167049 139.74039407560255 34.813 35.670930884751634 139.74040110665555 34.813 35.670930884751634 139.74040110665555 36.345 35.67093570167049 139.74039407560255 36.345 35.67093570167049 139.74039407560255 34.813</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6b7276d5-7eda-428f-9518-553cae2d6fa0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6b7276d5-7eda-428f-9518-553cae2d6fa0_0">
											<gml:posList>35.67095607964724 139.74040307683933 34.813 35.67096075250863 139.74039625583168 34.813 35.67096075250863 139.74039625583168 36.345 35.67095607964724 139.74040307683933 36.345 35.67095607964724 139.74040307683933 34.813</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f7234fee-1e58-4ccc-9ff9-9c8d6ef10bac">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f7234fee-1e58-4ccc-9ff9-9c8d6ef10bac_0">
											<gml:posList>35.67095001783689 139.74040881691485 34.813 35.67093570167049 139.74039407560255 34.813 35.67093570167049 139.74039407560255 36.345 35.67095001783689 139.74040881691485 36.345 35.67095001783689 139.74040881691485 34.813</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a11f4aa0-1112-428c-9378-fd46ee66150a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a11f4aa0-1112-428c-9378-fd46ee66150a_0">
											<gml:posList>35.671081211482544 139.7404072730189 41.17 35.67106979139805 139.7403959968809 41.17 35.67106979139805 139.7403959968809 42.242 35.671081211482544 139.7404072730189 42.242 35.671081211482544 139.7404072730189 41.17</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a54b5d80-3305-4858-8c09-6fff296b0543">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a54b5d80-3305-4858-8c09-6fff296b0543_0">
											<gml:posList>35.67106979139805 139.7403959968809 41.17 35.67106046412025 139.74041018016393 41.17 35.67106046412025 139.74041018016393 42.242 35.67106979139805 139.7403959968809 42.242 35.67106979139805 139.7403959968809 41.17</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3046ba67-07be-4d1b-bda5-a15362a2c631">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3046ba67-07be-4d1b-bda5-a15362a2c631_0">
											<gml:posList>35.670930884751634 139.74040110665555 36.345 35.67094520091719 139.74041584796822 36.345 35.67095001783689 139.74040881691485 36.345 35.67093570167049 139.74039407560255 36.345 35.670930884751634 139.74040110665555 36.345</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bb4e28a5-ada0-445a-8aab-268c2b3c187d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bb4e28a5-ada0-445a-8aab-268c2b3c187d_0">
											<gml:posList>35.67098184649055 139.74041033755938 34.813 35.67097602788315 139.74040418044453 34.813 35.67097602788315 139.74040418044453 36.345 35.67098184649055 139.74041033755938 36.345 35.67098184649055 139.74041033755938 34.813</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a24de7fa-11c4-4368-9262-dc96b8cc28e7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a24de7fa-11c4-4368-9262-dc96b8cc28e7_0">
											<gml:posList>35.670930884751634 139.74040110665555 34.813 35.67094520091719 139.74041584796822 34.813 35.67094520091719 139.74041584796822 36.345 35.670930884751634 139.74040110665555 36.345 35.670930884751634 139.74040110665555 34.813</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b3820e7c-e38d-4d63-b02d-dbe9f7e2f402">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b3820e7c-e38d-4d63-b02d-dbe9f7e2f402_0">
											<gml:posList>35.67106979139805 139.7403959968809 42.242 35.67106046412025 139.74041018016393 42.242 35.67107188420344 139.74042145630264 42.242 35.671081211482544 139.7404072730189 42.242 35.67106979139805 139.7403959968809 42.242</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-09046716-b023-4e22-95d3-656345cd4f46">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-09046716-b023-4e22-95d3-656345cd4f46_0">
											<gml:posList>35.67094520091719 139.74041584796822 34.813 35.67095001783689 139.74040881691485 34.813 35.67095001783689 139.74040881691485 36.345 35.67094520091719 139.74041584796822 36.345 35.67094520091719 139.74041584796822 34.813</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f3b44af6-9cbc-40b1-8308-bc849e3e8d33">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f3b44af6-9cbc-40b1-8308-bc849e3e8d33_0">
											<gml:posList>35.67097602788315 139.74040418044453 34.813 35.670964259820494 139.74042087405778 34.813 35.670964259820494 139.74042087405778 36.345 35.67097602788315 139.74040418044453 36.345 35.67097602788315 139.74040418044453 34.813</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-45bff32a-3612-46f3-8204-2e0210fa2cb9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-45bff32a-3612-46f3-8204-2e0210fa2cb9_0">
											<gml:posList>35.67107188420344 139.74042145630264 41.17 35.671081211482544 139.7404072730189 41.17 35.671081211482544 139.7404072730189 42.242 35.67107188420344 139.74042145630264 42.242 35.67107188420344 139.74042145630264 41.17</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-38d5eb16-a528-43ed-9006-562fa58b654b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-38d5eb16-a528-43ed-9006-562fa58b654b_0">
											<gml:posList>35.67097602788315 139.74040418044453 36.345 35.670964259820494 139.74042087405778 36.345 35.67097008744929 139.74042704220884 36.345 35.67098184649055 139.74041033755938 36.345 35.67097602788315 139.74040418044453 36.345</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-abe789b3-ccb3-42a6-b8aa-1f96b5e79782">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-abe789b3-ccb3-42a6-b8aa-1f96b5e79782_0">
											<gml:posList>35.67107188420344 139.74042145630264 41.17 35.67107188420344 139.74042145630264 42.242 35.67106046412025 139.74041018016393 42.242 35.67106046412025 139.74041018016393 41.17 35.67107188420344 139.74042145630264 41.17</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d37d14f4-5014-4fc1-81e1-ea096ccda4ed">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d37d14f4-5014-4fc1-81e1-ea096ccda4ed_0">
											<gml:posList>35.671062862618726 139.74042295801507 41.17 35.67105431178036 139.74041541221914 41.17 35.67105431178036 139.74041541221914 41.658 35.671062862618726 139.74042295801507 41.658 35.671062862618726 139.74042295801507 41.17</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-da2e30b5-4ae6-46b5-b520-47e7654bca14">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-da2e30b5-4ae6-46b5-b520-47e7654bca14_0">
											<gml:posList>35.67098761999491 139.74041645054203 34.813 35.67098761999491 139.74041645054203 36.345 35.67099337544596 139.74042253040747 36.345 35.67099337544596 139.74042253040747 34.813 35.67098761999491 139.74041645054203 34.813</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-96255506-db1c-4e21-b8a7-a4fb7d0b73f7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-96255506-db1c-4e21-b8a7-a4fb7d0b73f7_0">
											<gml:posList>35.671048604590126 139.74042515066907 41.17 35.671048604590126 139.74042515066907 41.658 35.67105431178036 139.74041541221914 41.658 35.67105431178036 139.74041541221914 41.17 35.671048604590126 139.74042515066907 41.17</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-de572f99-f156-4b32-8297-c4f5e7541fcb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-de572f99-f156-4b32-8297-c4f5e7541fcb_0">
											<gml:posList>35.670964259820494 139.74042087405778 34.813 35.67097008744929 139.74042704220884 34.813 35.67097008744929 139.74042704220884 36.345 35.670964259820494 139.74042087405778 36.345 35.670964259820494 139.74042087405778 34.813</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c64867de-fbf6-46da-b4e0-2bc432e94080">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c64867de-fbf6-46da-b4e0-2bc432e94080_0">
											<gml:posList>35.67105715541938 139.7404326854192 41.658 35.671062862618726 139.74042295801507 41.658 35.67105431178036 139.74041541221914 41.658 35.671048604590126 139.74042515066907 41.658 35.67105715541938 139.7404326854192 41.658</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5dd5afe7-c61c-4192-a48f-20eec184d1ab">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5dd5afe7-c61c-4192-a48f-20eec184d1ab_0">
											<gml:posList>35.67098761999491 139.74041645054203 34.813 35.670975464766656 139.74043369692157 34.813 35.670975464766656 139.74043369692157 36.345 35.67098761999491 139.74041645054203 36.345 35.67098761999491 139.74041645054203 34.813</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3b4c81d5-8849-4223-8ab4-e39adb005cb7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3b4c81d5-8849-4223-8ab4-e39adb005cb7_0">
											<gml:posList>35.67105715541938 139.7404326854192 41.17 35.671062862618726 139.74042295801507 41.17 35.671062862618726 139.74042295801507 41.658 35.67105715541938 139.7404326854192 41.658 35.67105715541938 139.7404326854192 41.17</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-13102c5b-8a0a-46a2-9bac-a86932e47330">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-13102c5b-8a0a-46a2-9bac-a86932e47330_0">
											<gml:posList>35.670981220225364 139.74043978783365 36.345 35.67099337544596 139.74042253040747 36.345 35.67098761999491 139.74041645054203 36.345 35.670975464766656 139.74043369692157 36.345 35.670981220225364 139.74043978783365 36.345</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0fe7723a-7384-493e-ac6f-dd9a573d0fc9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0fe7723a-7384-493e-ac6f-dd9a573d0fc9_0">
											<gml:posList>35.671048604590126 139.74042515066907 41.17 35.67105715541938 139.7404326854192 41.17 35.67105715541938 139.7404326854192 41.658 35.671048604590126 139.74042515066907 41.658 35.671048604590126 139.74042515066907 41.17</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c25a6aa0-00f9-4f96-a482-2a2579ffc208">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c25a6aa0-00f9-4f96-a482-2a2579ffc208_0">
											<gml:posList>35.6710049224446 139.74043474533082 34.813 35.67099911286072 139.7404285992483 34.813 35.67099911286072 139.7404285992483 36.345 35.6710049224446 139.74043474533082 36.345 35.6710049224446 139.74043474533082 34.813</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b8bce65b-4ded-40f6-8c0b-c7346db1bcd9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b8bce65b-4ded-40f6-8c0b-c7346db1bcd9_0">
											<gml:posList>35.671009478310985 139.7405333618304 36.904 35.67101940104091 139.740543258919 36.904 35.671159070146956 139.74033471861205 36.904 35.67114842567102 139.74032400493832 36.904 35.67114524749621 139.74032875856213 36.904 35.67115202206514 139.74033556631122 36.904 35.67101869132216 139.74053463254302 36.904 35.67101263845802 139.74052859719725 36.904 35.671009478310985 139.7405333618304 36.904</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-68cbc486-9b2d-4d4e-99a0-f6080df40ff2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-68cbc486-9b2d-4d4e-99a0-f6080df40ff2_0">
											<gml:posList>35.67101869132216 139.74053463254302 34.813 35.67101869132216 139.74053463254302 36.904 35.67115202206514 139.74033556631122 36.904 35.67115202206514 139.74033556631122 34.813 35.67101869132216 139.74053463254302 34.813</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7ffdd7d7-c70c-47cc-8d4a-27ddd419cbf1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7ffdd7d7-c70c-47cc-8d4a-27ddd419cbf1_0">
											<gml:posList>35.6710188732992 139.74053684160188 34.813 35.671153815633616 139.74033535434984 34.813 35.671153815633616 139.74033535434984 35.389 35.6710188732992 139.74053684160188 35.389 35.6710188732992 139.74053684160188 34.813</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7c33cd35-6dcf-4050-9eff-4ef1d56a04b5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7c33cd35-6dcf-4050-9eff-4ef1d56a04b5_0">
											<gml:posList>35.671036496250515 139.74043307388683 34.813 35.67103189532645 139.74043967388846 34.813 35.67103189532645 139.74043967388846 37.71 35.671036496250515 139.74043307388683 37.71 35.671036496250515 139.74043307388683 34.813</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-180e79fc-39b1-40fa-8e02-91066c24d9d6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-180e79fc-39b1-40fa-8e02-91066c24d9d6_0">
											<gml:posList>35.670975464766656 139.74043369692157 34.813 35.670981220225364 139.74043978783365 34.813 35.670981220225364 139.74043978783365 36.345 35.670975464766656 139.74043369692157 36.345 35.670975464766656 139.74043369692157 34.813</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d387ac95-c1d2-49df-a8ed-6c644ef9dad9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d387ac95-c1d2-49df-a8ed-6c644ef9dad9_0">
											<gml:posList>35.67101940104091 139.740543258919 35.389 35.671159070146956 139.74033471861205 35.389 35.671159070146956 139.74033471861205 36.904 35.67101940104091 139.740543258919 36.904 35.67101940104091 139.740543258919 35.389</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e0c23f60-f4ef-4642-b6fb-3ba0844aa7d6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e0c23f60-f4ef-4642-b6fb-3ba0844aa7d6_0">
											<gml:posList>35.67098269880133 139.7404518929119 34.813 35.67098269880133 139.7404518929119 36.345 35.67099911286072 139.7404285992483 36.345 35.67099911286072 139.7404285992483 34.813 35.67098269880133 139.7404518929119 34.813</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0276306d-d793-4517-a0b7-2d36982966b5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0276306d-d793-4517-a0b7-2d36982966b5_0">
											<gml:posList>35.67098269880133 139.7404518929119 36.345 35.67098850838405 139.7404580389948 36.345 35.6710049224446 139.74043474533082 36.345 35.67099911286072 139.7404285992483 36.345 35.67098269880133 139.7404518929119 36.345</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c3c61ce6-70e1-42e5-9408-140e37771beb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c3c61ce6-70e1-42e5-9408-140e37771beb_0">
											<gml:posList>35.6710163075103 139.74044736916014 34.813 35.671011047636256 139.74044105674378 34.813 35.671011047636256 139.74044105674378 36.345 35.6710163075103 139.74044736916014 36.345 35.6710163075103 139.74044736916014 34.813</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ad543e05-ed6a-4307-bdad-c3c7b383d74a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ad543e05-ed6a-4307-bdad-c3c7b383d74a_0">
											<gml:posList>35.67106024858677 139.7404579448447 34.813 35.671036496250515 139.74043307388683 34.813 35.671036496250515 139.74043307388683 37.71 35.67106024858677 139.7404579448447 37.71 35.67106024858677 139.7404579448447 34.813</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2a4bf21e-8fb0-4549-a3c6-0cb2edb9a641">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2a4bf21e-8fb0-4549-a3c6-0cb2edb9a641_0">
											<gml:posList>35.67098850838405 139.7404580389948 34.813 35.6710049224446 139.74043474533082 34.813 35.6710049224446 139.74043474533082 36.345 35.67098850838405 139.7404580389948 36.345 35.67098850838405 139.7404580389948 34.813</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4a5e5b3c-b171-4620-9204-1ed44b4de5f3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4a5e5b3c-b171-4620-9204-1ed44b4de5f3_0">
											<gml:posList>35.671036496250515 139.74043307388683 37.71 35.67103189532645 139.74043967388846 37.71 35.67105563864763 139.74046454485733 37.71 35.67106024858677 139.7404579448447 37.71 35.671036496250515 139.74043307388683 37.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7ae54436-8e95-40fa-8d0a-d6010703a586">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7ae54436-8e95-40fa-8d0a-d6010703a586_0">
											<gml:posList>35.670997846259 139.74045758632408 34.813 35.670997846259 139.74045758632408 36.345 35.671011047636256 139.74044105674378 36.345 35.671011047636256 139.74044105674378 34.813 35.670997846259 139.74045758632408 34.813</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-17fddcaa-fe4c-4861-9786-e5ef37f6e5af">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-17fddcaa-fe4c-4861-9786-e5ef37f6e5af_0">
											<gml:posList>35.67103189532645 139.74043967388846 34.813 35.67105563864763 139.74046454485733 34.813 35.67105563864763 139.74046454485733 37.71 35.67103189532645 139.74043967388846 37.71 35.67103189532645 139.74043967388846 34.813</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-04113e02-3807-41db-b201-ad13016ba521">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-04113e02-3807-41db-b201-ad13016ba521_0">
											<gml:posList>35.670997846259 139.74045758632408 36.345 35.6710031151459 139.74046389873007 36.345 35.6710163075103 139.74044736916014 36.345 35.671011047636256 139.74044105674378 36.345 35.670997846259 139.74045758632408 36.345</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d1cc8ead-40a9-4f56-b69e-21629f91a535">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d1cc8ead-40a9-4f56-b69e-21629f91a535_0">
											<gml:posList>35.67098269880133 139.7404518929119 34.813 35.67098850838405 139.7404580389948 34.813 35.67098850838405 139.7404580389948 36.345 35.67098269880133 139.7404518929119 36.345 35.67098269880133 139.7404518929119 34.813</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bbae248a-43cc-4d61-8340-6fe75be27b69">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bbae248a-43cc-4d61-8340-6fe75be27b69_0">
											<gml:posList>35.670997846259 139.74045758632408 34.813 35.6710031151459 139.74046389873007 34.813 35.6710031151459 139.74046389873007 36.345 35.670997846259 139.74045758632408 36.345 35.670997846259 139.74045758632408 34.813</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-36fa77fa-b360-4e6d-a381-925f0e7bb2b3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-36fa77fa-b360-4e6d-a381-925f0e7bb2b3_0">
											<gml:posList>35.67105563864763 139.74046454485733 34.813 35.67106024858677 139.7404579448447 34.813 35.67106024858677 139.7404579448447 37.71 35.67105563864763 139.74046454485733 37.71 35.67105563864763 139.74046454485733 34.813</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-30c9d60d-975f-443f-b00c-38cf8706b68d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-30c9d60d-975f-443f-b00c-38cf8706b68d_0">
											<gml:posList>35.671011828159564 139.7405298132333 35.389 35.671009478310985 139.7405333618304 35.389 35.671009478310985 139.7405333618304 36.904 35.67101263845802 139.74052859719725 36.904 35.67101263845802 139.74052859719725 34.813 35.671011828159564 139.7405298132333 34.813 35.671011828159564 139.7405298132333 35.389</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-28454f85-922c-4cf9-824c-f4e5bda7b739">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-28454f85-922c-4cf9-824c-f4e5bda7b739_0">
											<gml:posList>35.67101263845802 139.74052859719725 34.813 35.67101263845802 139.74052859719725 36.904 35.67101869132216 139.74053463254302 36.904 35.67101869132216 139.74053463254302 34.813 35.67101263845802 139.74052859719725 34.813</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cd83fc32-1f36-47e4-b842-ad1fbacfe148">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cd83fc32-1f36-47e4-b842-ad1fbacfe148_0">
											<gml:posList>35.6710188732992 139.74053684160188 35.389 35.671011828159564 139.7405298132333 35.389 35.671011828159564 139.7405298132333 34.813 35.6710188732992 139.74053684160188 34.813 35.6710188732992 139.74053684160188 35.389</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e0697f4b-f4e5-4112-8e58-c56bf183d6e8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e0697f4b-f4e5-4112-8e58-c56bf183d6e8_0">
											<gml:posList>35.671009478310985 139.7405333618304 35.389 35.67101940104091 139.740543258919 35.389 35.67101940104091 139.740543258919 36.904 35.671009478310985 139.7405333618304 36.904 35.671009478310985 139.7405333618304 35.389</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_0a0beb6d-c69d-4d79-86d4-cd38b9efe69a_BuildingInstallation_1060">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-eff91928-7c14-4cde-8a2a-cc10c59de3ee">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671139034700104 139.7403374040257 9.63 35.67111491246949 139.74031213583936 9.63 35.67112386220055 139.74029930062952 9.63 35.67114767695193 139.74032325465407 9.63 35.671139034700104 139.7403374040257 9.63</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-68e318a2-cad9-4b09-8f58-72dc8e407f76">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6710121723277 139.74040338739906 34.813 35.67100475322173 139.74041402258277 34.813 35.670980017570535 139.7403881033925 34.813 35.67098743668277 139.74037747925604 34.813 35.6710121723277 139.74040338739906 34.813</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cc5b1129-b4e3-4b61-841f-6142b75bab88">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cc5b1129-b4e3-4b61-841f-6142b75bab88_0">
											<gml:posList>35.67112386220055 139.74029930062952 9.63 35.67111491246949 139.74031213583936 9.63 35.67111491246949 139.74031213583936 31.793 35.67112386220055 139.74029930062952 31.793 35.67112386220055 139.74029930062952 9.63</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3cc2f9d8-02c3-4e0e-94f3-07b2ce4f2d9e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3cc2f9d8-02c3-4e0e-94f3-07b2ce4f2d9e_0">
											<gml:posList>35.67114767695193 139.74032325465407 9.63 35.67112386220055 139.74029930062952 9.63 35.67112386220055 139.74029930062952 31.793 35.67114767695193 139.74032325465407 31.793 35.67114767695193 139.74032325465407 9.63</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-862b3947-4825-4f88-9950-5ace9a9088bf">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-862b3947-4825-4f88-9950-5ace9a9088bf_0">
											<gml:posList>35.671139034700104 139.7403374040257 31.793 35.67114767695193 139.74032325465407 31.793 35.67112386220055 139.74029930062952 31.793 35.67111491246949 139.74031213583936 31.793 35.671139034700104 139.7403374040257 31.793</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2e934a6b-aa40-4a75-951b-f78e1f176a0c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2e934a6b-aa40-4a75-951b-f78e1f176a0c_0">
											<gml:posList>35.67111491246949 139.74031213583936 31.793 35.67111491246949 139.74031213583936 9.63 35.671139034700104 139.7403374040257 9.63 35.671139034700104 139.7403374040257 31.793 35.67111491246949 139.74031213583936 31.793</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b27daed7-3538-41eb-b886-34389d6ed1a7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b27daed7-3538-41eb-b886-34389d6ed1a7_0">
											<gml:posList>35.67114767695193 139.74032325465407 9.63 35.67114767695193 139.74032325465407 31.793 35.671139034700104 139.7403374040257 31.793 35.671139034700104 139.7403374040257 9.63 35.67114767695193 139.74032325465407 9.63</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d4c5c6a7-9046-47ed-b622-fbf1e6663998">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d4c5c6a7-9046-47ed-b622-fbf1e6663998_0">
											<gml:posList>35.670980017570535 139.7403881033925 34.813 35.670980017570535 139.7403881033925 35.729 35.67098743668277 139.74037747925604 35.729 35.67098743668277 139.74037747925604 34.813 35.670980017570535 139.7403881033925 34.813</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1eed065b-cea9-4a60-a6b9-f7cd14ab19ca">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1eed065b-cea9-4a60-a6b9-f7cd14ab19ca_0">
											<gml:posList>35.67098743668277 139.74037747925604 34.813 35.67098743668277 139.74037747925604 35.729 35.6710121723277 139.74040338739906 35.729 35.6710121723277 139.74040338739906 34.813 35.67098743668277 139.74037747925604 34.813</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cc251a1b-af37-44f2-a33d-e95ac6e722a3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cc251a1b-af37-44f2-a33d-e95ac6e722a3_0">
											<gml:posList>35.670980017570535 139.7403881033925 35.729 35.67100475322173 139.74041402258277 35.729 35.6710121723277 139.74040338739906 35.729 35.67098743668277 139.74037747925604 35.729 35.670980017570535 139.7403881033925 35.729</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2832bf85-5826-491e-a449-7b60be853b05">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2832bf85-5826-491e-a449-7b60be853b05_0">
											<gml:posList>35.670980017570535 139.7403881033925 34.813 35.67100475322173 139.74041402258277 34.813 35.67100475322173 139.74041402258277 35.729 35.670980017570535 139.7403881033925 35.729 35.670980017570535 139.7403881033925 34.813</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-04fcc005-d2e5-45ce-a272-c3a094486d14">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-04fcc005-d2e5-45ce-a272-c3a094486d14_0">
											<gml:posList>35.67100475322173 139.74041402258277 34.813 35.6710121723277 139.74040338739906 34.813 35.6710121723277 139.74040338739906 35.729 35.67100475322173 139.74041402258277 35.729 35.67100475322173 139.74041402258277 34.813</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_0a0beb6d-c69d-4d79-86d4-cd38b9efe69a_BuildingInstallation_1041">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b6120ae2-c7a8-4a96-a4cf-783912734997">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67103279781665 139.7404528069522 34.813 35.6710498557998 139.74046968810924 34.813 35.671016057789096 139.7405209602135 34.813 35.67099900882676 139.7405040790422 34.813 35.67103279781665 139.7404528069522 34.813</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c8e0bd27-6a93-4084-966c-c2d2d015e4aa">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c8e0bd27-6a93-4084-966c-c2d2d015e4aa_0">
											<gml:posList>35.67103279781665 139.7404528069522 34.813 35.67103279781665 139.7404528069522 37.744 35.6710498557998 139.74046968810924 37.744 35.6710498557998 139.74046968810924 34.813 35.67103279781665 139.7404528069522 34.813</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-40b4faf1-5e7d-4224-9660-ada7bd910311">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-40b4faf1-5e7d-4224-9660-ada7bd910311_0">
											<gml:posList>35.67099900882676 139.7405040790422 34.813 35.67099900882676 139.7405040790422 37.744 35.67103279781665 139.7404528069522 37.744 35.67103279781665 139.7404528069522 34.813 35.67099900882676 139.7405040790422 34.813</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a3e2321d-5f1b-4ac8-b87f-2bb9e03d0253">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a3e2321d-5f1b-4ac8-b87f-2bb9e03d0253_0">
											<gml:posList>35.67103279781665 139.7404528069522 37.744 35.67099900882676 139.7405040790422 37.744 35.671016057789096 139.7405209602135 37.744 35.6710498557998 139.74046968810924 37.744 35.67103279781665 139.7404528069522 37.744</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0f37f62e-b42a-42eb-87a9-144469d878c0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0f37f62e-b42a-42eb-87a9-144469d878c0_0">
											<gml:posList>35.6710498557998 139.74046968810924 34.813 35.6710498557998 139.74046968810924 37.744 35.671016057789096 139.7405209602135 37.744 35.671016057789096 139.7405209602135 34.813 35.6710498557998 139.74046968810924 34.813</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cf96a7eb-980c-41fe-8661-a66bd89b7db9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cf96a7eb-980c-41fe-8661-a66bd89b7db9_0">
											<gml:posList>35.671016057789096 139.7405209602135 37.744 35.67099900882676 139.7405040790422 37.744 35.67099900882676 139.7405040790422 34.813 35.671016057789096 139.7405209602135 34.813 35.671016057789096 139.7405209602135 37.744</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-c066444d-3ee3-4535-973c-78e98a06352b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c066444d-3ee3-4535-973c-78e98a06352b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c066444d-3ee3-4535-973c-78e98a06352b">
											<gml:posList>35.6709964624719 139.74048657353464 9.63 35.67089940000202 139.7403896991507 9.63 35.67095882163967 139.74030037584603 9.63 35.67105570373547 139.74039702947536 9.63 35.67111490345576 139.74031213584982 9.63 35.671139034700104 139.7403374040257 9.63 35.67114767695193 139.74032325465407 9.63 35.67119954618957 139.74037543277598 9.63 35.671060625459205 139.7405843699205 9.63 35.67098295755977 139.74050691444407 9.63 35.6709964624719 139.74048657353464 9.63</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-16088f2b-1ef7-404b-849d-f348137e74a6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-16088f2b-1ef7-404b-849d-f348137e74a6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-16088f2b-1ef7-404b-849d-f348137e74a6">
											<gml:posList>35.671139034700104 139.7403374040257 35.389 35.67111490345576 139.74031213584982 35.389 35.67111530504294 139.74031858645853 35.389 35.671139625727626 139.74034405325133 35.389 35.671139034700104 139.7403374040257 35.389</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-14de22e3-c648-4a8f-b73a-dfa2be69a613">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-14de22e3-c648-4a8f-b73a-dfa2be69a613">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-14de22e3-c648-4a8f-b73a-dfa2be69a613">
											<gml:posList>35.671159070146956 139.74033471861205 35.389 35.67114767695193 139.74032325465407 35.389 35.671148312989125 139.74032982650354 35.389 35.671153815633616 139.74033535434984 35.389 35.671159070146956 139.74033471861205 35.389</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-4b20e078-ad6d-4514-8be5-4f20b521b56a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4b20e078-ad6d-4514-8be5-4f20b521b56a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4b20e078-ad6d-4514-8be5-4f20b521b56a">
											<gml:posList>35.671139034700104 139.7403374040257 35.389 35.671139625727626 139.74034405325133 35.389 35.671148312989125 139.74032982650354 35.389 35.67114767695193 139.74032325465407 35.389 35.671139034700104 139.7403374040257 35.389</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-83fef035-7118-4328-9023-2d423c3bffad">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-83fef035-7118-4328-9023-2d423c3bffad">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-83fef035-7118-4328-9023-2d423c3bffad">
											<gml:posList>35.67095882163967 139.74030037584603 31.654 35.67089940000202 139.7403896991507 31.654 35.67097100858233 139.74031253477236 35.389 35.67095882163967 139.74030037584603 31.654</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-4199bff8-4a06-426d-8e7d-cd9f505c231f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4199bff8-4a06-426d-8e7d-cd9f505c231f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4199bff8-4a06-426d-8e7d-cd9f505c231f">
											<gml:posList>35.67107051492771 139.74037579225975 35.389 35.67107334753023 139.74037876044503 35.389 35.67111530504294 139.74031858645853 35.389 35.67111490345576 139.74031213584982 35.389 35.67107051492771 139.74037579225975 35.389</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-7e561c3b-3a19-489e-9e1b-c270aced7405">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7e561c3b-3a19-489e-9e1b-c270aced7405">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7e561c3b-3a19-489e-9e1b-c270aced7405">
											<gml:posList>35.67089940000202 139.7403896991507 31.654 35.670908186145304 139.74039847079953 35.389 35.67097100858233 139.74031253477236 35.389 35.67089940000202 139.7403896991507 31.654</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f0051e64-f3b3-4b64-bf85-d112d9fe727d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f0051e64-f3b3-4b64-bf85-d112d9fe727d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f0051e64-f3b3-4b64-bf85-d112d9fe727d">
											<gml:posList>35.670908186145304 139.74039847079953 35.389 35.67091357595882 139.74039795642068 35.389 35.67097141005855 139.7403188417672 35.389 35.67097100858233 139.74031253477236 35.389 35.670908186145304 139.74039847079953 35.389</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-0d8ebe80-bafd-4067-8ff1-7abf95a8d8da">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0d8ebe80-bafd-4067-8ff1-7abf95a8d8da">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0d8ebe80-bafd-4067-8ff1-7abf95a8d8da">
											<gml:posList>35.671008284642916 139.740353097892 35.389 35.67105338976668 139.7404003460633 35.389 35.67105570373547 139.74039702947536 35.389 35.67097100858233 139.74031253477236 35.389 35.67097141005855 139.7403188417672 35.389 35.67100718618861 139.74035467879332 35.389 35.671008284642916 139.740353097892 35.389</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-8fa0fc64-2847-4a94-9575-da5463177bfd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8fa0fc64-2847-4a94-9575-da5463177bfd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8fa0fc64-2847-4a94-9575-da5463177bfd">
											<gml:posList>35.67098965585762 139.74037980746158 38.137 35.670993324178035 139.74037946077195 38.137 35.67100857655355 139.7403575934163 38.137 35.671008284642916 139.740353097892 38.137 35.67098965585762 139.74037980746158 38.137</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-1cadfca0-efcd-479f-b223-4b737c445fe6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1cadfca0-efcd-479f-b223-4b737c445fe6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1cadfca0-efcd-479f-b223-4b737c445fe6">
											<gml:posList>35.67103971389773 139.74038602375256 38.137 35.671008284642916 139.740353097892 38.137 35.67100857655355 139.7403575934163 38.137 35.67103803019911 139.74038844485514 38.137 35.67103971389773 139.74038602375256 38.137</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-827415e0-15a6-4077-bcc4-d53dea9414dc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-827415e0-15a6-4077-bcc4-d53dea9414dc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-827415e0-15a6-4077-bcc4-d53dea9414dc">
											<gml:posList>35.67103803019911 139.74038844485514 37.701 35.67100857655355 139.7403575934163 37.701 35.670993324178035 139.74037946077195 37.701 35.67102277781805 139.740410312213 37.701 35.67103803019911 139.74038844485514 37.701</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-84caa601-b266-4fd1-b74b-f699d676aa19">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-84caa601-b266-4fd1-b74b-f699d676aa19">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-84caa601-b266-4fd1-b74b-f699d676aa19">
											<gml:posList>35.67107051492771 139.74037579225975 41.499 35.67107076140223 139.74037981284704 41.499 35.671092691519775 139.74040279698465 41.499 35.67109598128093 139.74040247282716 41.499 35.67107051492771 139.74037579225975 41.499</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-1e079520-c20c-4885-a6f1-fa862f197c05">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1e079520-c20c-4885-a6f1-fa862f197c05">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1e079520-c20c-4885-a6f1-fa862f197c05">
											<gml:posList>35.671021085105224 139.74041273332497 38.137 35.67102277781805 139.740410312213 38.137 35.670993324178035 139.74037946077195 38.137 35.67098965585762 139.74037980746158 38.137 35.671021085105224 139.74041273332497 38.137</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-2fcff183-e990-4e9c-8dc1-463d8ac72751">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2fcff183-e990-4e9c-8dc1-463d8ac72751">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2fcff183-e990-4e9c-8dc1-463d8ac72751">
											<gml:posList>35.671033068257884 139.74042947674897 41.499 35.67103634901395 139.7404291636496 41.499 35.67107076140223 139.74037981284704 41.499 35.67107051492771 139.74037579225975 41.499 35.671033068257884 139.74042947674897 41.499</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f434e003-e22d-4d2e-a975-fe4767d05444">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f434e003-e22d-4d2e-a975-fe4767d05444">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f434e003-e22d-4d2e-a975-fe4767d05444">
											<gml:posList>35.67105338976668 139.7404003460633 39.958 35.67103971389773 139.74038602375256 39.958 35.67102005867468 139.74041420367882 39.958 35.67103373454886 139.7404285370372 39.958 35.67105338976668 139.7404003460633 39.958</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-871a119c-b556-48da-b31c-bb5c81cc594a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-871a119c-b556-48da-b31c-bb5c81cc594a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-871a119c-b556-48da-b31c-bb5c81cc594a">
											<gml:posList>35.671092691519775 139.74040279698465 41.17 35.67107076140223 139.74037981284704 41.17 35.67103634901395 139.7404291636496 41.17 35.67105828811889 139.74045212568774 41.17 35.671092691519775 139.74040279698465 41.17</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-cc94ddfa-e750-471a-920a-dee6672d2729">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cc94ddfa-e750-471a-920a-dee6672d2729">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cc94ddfa-e750-471a-920a-dee6672d2729">
											<gml:posList>35.671139625727626 139.74034405325133 34.813 35.67111530504294 139.74031858645853 34.813 35.67107334753023 139.74037876044503 34.813 35.67109598128093 139.74040247282716 34.813 35.671058543613086 139.74045615731058 34.813 35.671033068257884 139.74042947674897 34.813 35.67103373454886 139.7404285370372 34.813 35.67102005867468 139.74041420367882 34.813 35.671021085105224 139.74041273332497 34.813 35.67098965585762 139.74037980746158 34.813 35.67100718618861 139.74035467879332 34.813 35.67097141005855 139.7403188417672 34.813 35.67091357595882 139.74039795642068 34.813 35.67100170795545 139.74048591572577 34.813 35.670988203043436 139.74050625663668 34.813 35.6710188732992 139.74053684160188 34.813 35.671153815633616 139.74033535434984 34.813 35.671148312989125 139.74032982650354 34.813 35.671139625727626 139.74034405325133 34.813</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-7872274b-0a87-4c5a-94e2-0feb96f419e2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7872274b-0a87-4c5a-94e2-0feb96f419e2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7872274b-0a87-4c5a-94e2-0feb96f419e2">
											<gml:posList>35.67109598128093 139.74040247282716 41.499 35.671092691519775 139.74040279698465 41.499 35.67105828811889 139.74045212568774 41.499 35.671058543613086 139.74045615731058 41.499 35.67109598128093 139.74040247282716 41.499</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-13e4ba1b-6c5e-421c-9b92-9e4349ed5699">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-13e4ba1b-6c5e-421c-9b92-9e4349ed5699">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-13e4ba1b-6c5e-421c-9b92-9e4349ed5699">
											<gml:posList>35.67101940104091 139.740543258919 35.389 35.67119954618957 139.74037543277598 28.185 35.671159070146956 139.74033471861205 35.389 35.67101940104091 139.740543258919 35.389</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-844b1f2a-0a16-46f0-bc1e-eea7ac843dd7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-844b1f2a-0a16-46f0-bc1e-eea7ac843dd7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-844b1f2a-0a16-46f0-bc1e-eea7ac843dd7">
											<gml:posList>35.671159070146956 139.74033471861205 35.389 35.671153815633616 139.74033535434984 35.389 35.6710188732992 139.74053684160188 35.389 35.67101940104091 139.740543258919 35.389 35.671159070146956 139.74033471861205 35.389</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a6a56d76-2307-4ffe-9a14-47c089ff1a4e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a6a56d76-2307-4ffe-9a14-47c089ff1a4e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a6a56d76-2307-4ffe-9a14-47c089ff1a4e">
											<gml:posList>35.6709964624719 139.74048657353464 35.389 35.67100170795545 139.74048591572577 35.389 35.67091357595882 139.74039795642068 35.389 35.670908186145304 139.74039847079953 35.389 35.6709964624719 139.74048657353464 35.389</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-cbf63bf1-361c-4468-98ab-4ec98060830b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cbf63bf1-361c-4468-98ab-4ec98060830b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cbf63bf1-361c-4468-98ab-4ec98060830b">
											<gml:posList>35.671058543613086 139.74045615731058 41.499 35.67105828811889 139.74045212568774 41.499 35.67103634901395 139.7404291636496 41.499 35.671033068257884 139.74042947674897 41.499 35.671058543613086 139.74045615731058 41.499</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-bb828c70-cb09-46ec-9f2d-f779dea2826e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bb828c70-cb09-46ec-9f2d-f779dea2826e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bb828c70-cb09-46ec-9f2d-f779dea2826e">
											<gml:posList>35.67101940104091 139.740543258919 35.389 35.671060625459205 139.7405843699205 28.185 35.67119954618957 139.74037543277598 28.185 35.67101940104091 139.740543258919 35.389</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-9080ad0b-d2e6-4afa-8086-4ad04a73c7c4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9080ad0b-d2e6-4afa-8086-4ad04a73c7c4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9080ad0b-d2e6-4afa-8086-4ad04a73c7c4">
											<gml:posList>35.6709964624719 139.74048657353464 35.389 35.67098295755977 139.74050691444407 35.389 35.670988203043436 139.74050625663668 35.389 35.67100170795545 139.74048591572577 35.389 35.6709964624719 139.74048657353464 35.389</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-bad48473-c0e0-4e7a-8e6f-90a831ffbb14">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bad48473-c0e0-4e7a-8e6f-90a831ffbb14">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bad48473-c0e0-4e7a-8e6f-90a831ffbb14">
											<gml:posList>35.67101940104091 139.740543258919 35.389 35.6710188732992 139.74053684160188 35.389 35.670988203043436 139.74050625663668 35.389 35.67098295755977 139.74050691444407 35.389 35.67101940104091 139.740543258919 35.389</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f87716e8-64ee-4184-a6e6-d560b6f6b589">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f87716e8-64ee-4184-a6e6-d560b6f6b589">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f87716e8-64ee-4184-a6e6-d560b6f6b589">
											<gml:posList>35.67100857655355 139.7403575934163 38.137 35.67100857655355 139.7403575934163 37.701 35.67103803019911 139.74038844485514 37.701 35.67103803019911 139.74038844485514 38.137 35.67100857655355 139.7403575934163 38.137</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-bcf0c3e6-d4a6-40a8-a6c5-b88450499542">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bcf0c3e6-d4a6-40a8-a6c5-b88450499542">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bcf0c3e6-d4a6-40a8-a6c5-b88450499542">
											<gml:posList>35.67102277781805 139.740410312213 38.137 35.67102277781805 139.740410312213 37.701 35.670993324178035 139.74037946077195 37.701 35.670993324178035 139.74037946077195 38.137 35.67102277781805 139.740410312213 38.137</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-cccbb4dd-c404-4665-8ddd-8c001b4eb73c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cccbb4dd-c404-4665-8ddd-8c001b4eb73c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cccbb4dd-c404-4665-8ddd-8c001b4eb73c">
											<gml:posList>35.67103634901395 139.7404291636496 41.499 35.67103634901395 139.7404291636496 41.17 35.67107076140223 139.74037981284704 41.17 35.67107076140223 139.74037981284704 41.499 35.67103634901395 139.7404291636496 41.499</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e772ac52-11c8-4087-9a7a-d8c4d6ff4345">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e772ac52-11c8-4087-9a7a-d8c4d6ff4345">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e772ac52-11c8-4087-9a7a-d8c4d6ff4345">
											<gml:posList>35.671092691519775 139.74040279698465 41.499 35.671092691519775 139.74040279698465 41.17 35.67105828811889 139.74045212568774 41.17 35.67105828811889 139.74045212568774 41.499 35.671092691519775 139.74040279698465 41.499</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-85903320-310c-4cd4-aa1d-9e5f862262b3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-85903320-310c-4cd4-aa1d-9e5f862262b3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-85903320-310c-4cd4-aa1d-9e5f862262b3">
											<gml:posList>35.67095882163967 139.74030037584603 9.63 35.67089940000202 139.7403896991507 9.63 35.67089940000202 139.7403896991507 31.654 35.67095882163967 139.74030037584603 31.654 35.67095882163967 139.74030037584603 9.63</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-998356af-a2de-4049-a05d-0d1a68c169b2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-998356af-a2de-4049-a05d-0d1a68c169b2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-998356af-a2de-4049-a05d-0d1a68c169b2">
											<gml:posList>35.67091357595882 139.74039795642068 35.389 35.67091357595882 139.74039795642068 34.813 35.67097141005855 139.7403188417672 34.813 35.67097141005855 139.7403188417672 35.389 35.67091357595882 139.74039795642068 35.389</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-33555018-15a4-4d0e-886d-23bf13638e43">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-33555018-15a4-4d0e-886d-23bf13638e43">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-33555018-15a4-4d0e-886d-23bf13638e43">
											<gml:posList>35.67089940000202 139.7403896991507 9.63 35.6709964624719 139.74048657353464 9.63 35.6709964624719 139.74048657353464 35.389 35.670908186145304 139.74039847079953 35.389 35.67089940000202 139.7403896991507 31.654 35.67089940000202 139.7403896991507 9.63</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a9a0608b-d3fa-4f1b-a271-bc90b7522ca8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a9a0608b-d3fa-4f1b-a271-bc90b7522ca8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a9a0608b-d3fa-4f1b-a271-bc90b7522ca8">
											<gml:posList>35.67100170795545 139.74048591572577 35.389 35.67100170795545 139.74048591572577 34.813 35.67091357595882 139.74039795642068 34.813 35.67091357595882 139.74039795642068 35.389 35.67100170795545 139.74048591572577 35.389</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e20d15d3-3026-4c73-a08a-7ef933fb5738">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e20d15d3-3026-4c73-a08a-7ef933fb5738">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e20d15d3-3026-4c73-a08a-7ef933fb5738">
											<gml:posList>35.67097141005855 139.7403188417672 35.389 35.67097141005855 139.7403188417672 34.813 35.67100718618861 139.74035467879332 34.813 35.67100718618861 139.74035467879332 35.389 35.67097141005855 139.7403188417672 35.389</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7bf9cbed-4d2d-451a-ac61-e2714a71ee71">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7bf9cbed-4d2d-451a-ac61-e2714a71ee71">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7bf9cbed-4d2d-451a-ac61-e2714a71ee71">
											<gml:posList>35.6709964624719 139.74048657353464 9.63 35.67098295755977 139.74050691444407 9.63 35.67098295755977 139.74050691444407 35.389 35.6709964624719 139.74048657353464 35.389 35.6709964624719 139.74048657353464 9.63</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-dffac438-c41b-4173-b67f-c187cc3ff501">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-dffac438-c41b-4173-b67f-c187cc3ff501">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-dffac438-c41b-4173-b67f-c187cc3ff501">
											<gml:posList>35.670988203043436 139.74050625663668 35.389 35.670988203043436 139.74050625663668 34.813 35.67100170795545 139.74048591572577 34.813 35.67100170795545 139.74048591572577 35.389 35.670988203043436 139.74050625663668 35.389</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7f5a79bd-dabc-45e8-8178-7e24d9a36e5d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7f5a79bd-dabc-45e8-8178-7e24d9a36e5d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7f5a79bd-dabc-45e8-8178-7e24d9a36e5d">
											<gml:posList>35.67098965585762 139.74037980746158 34.813 35.67098965585762 139.74037980746158 38.137 35.671008284642916 139.740353097892 38.137 35.671008284642916 139.740353097892 35.389 35.67100718618861 139.74035467879332 35.389 35.67100718618861 139.74035467879332 34.813 35.67098965585762 139.74037980746158 34.813</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b469357d-77aa-4c31-8bb3-092b8d4070a9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b469357d-77aa-4c31-8bb3-092b8d4070a9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b469357d-77aa-4c31-8bb3-092b8d4070a9">
											<gml:posList>35.670993324178035 139.74037946077195 38.137 35.670993324178035 139.74037946077195 37.701 35.67100857655355 139.7403575934163 37.701 35.67100857655355 139.7403575934163 38.137 35.670993324178035 139.74037946077195 38.137</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1a95a5e4-bfef-407e-a263-bc31f1610e35">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1a95a5e4-bfef-407e-a263-bc31f1610e35">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1a95a5e4-bfef-407e-a263-bc31f1610e35">
											<gml:posList>35.6710188732992 139.74053684160188 35.389 35.6710188732992 139.74053684160188 34.813 35.670988203043436 139.74050625663668 34.813 35.670988203043436 139.74050625663668 35.389 35.6710188732992 139.74053684160188 35.389</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-29111569-a8c8-471e-b774-7733f7fb4e28">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-29111569-a8c8-471e-b774-7733f7fb4e28">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-29111569-a8c8-471e-b774-7733f7fb4e28">
											<gml:posList>35.67098965585762 139.74037980746158 34.813 35.671021085105224 139.74041273332497 34.813 35.671021085105224 139.74041273332497 38.137 35.67098965585762 139.74037980746158 38.137 35.67098965585762 139.74037980746158 34.813</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-73732fe2-39cf-4c5e-b1ec-3ad7c085cbfe">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-73732fe2-39cf-4c5e-b1ec-3ad7c085cbfe">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-73732fe2-39cf-4c5e-b1ec-3ad7c085cbfe">
											<gml:posList>35.67105570373547 139.74039702947536 35.389 35.67105570373547 139.74039702947536 9.63 35.67095882163967 139.74030037584603 9.63 35.67095882163967 139.74030037584603 31.654 35.67097100858233 139.74031253477236 35.389 35.67105570373547 139.74039702947536 35.389</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-aa7d5421-911f-4997-a183-55383a9060eb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-aa7d5421-911f-4997-a183-55383a9060eb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-aa7d5421-911f-4997-a183-55383a9060eb">
											<gml:posList>35.67098295755977 139.74050691444407 9.63 35.671060625459205 139.7405843699205 9.63 35.671060625459205 139.7405843699205 28.185 35.67101940104091 139.740543258919 35.389 35.67098295755977 139.74050691444407 35.389 35.67098295755977 139.74050691444407 9.63</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f474af9c-9422-4493-87a7-045e6ac6c7b5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f474af9c-9422-4493-87a7-045e6ac6c7b5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f474af9c-9422-4493-87a7-045e6ac6c7b5">
											<gml:posList>35.67102005867468 139.74041420367882 34.813 35.67103373454886 139.7404285370372 34.813 35.67103373454886 139.7404285370372 39.958 35.67102005867468 139.74041420367882 39.958 35.67102005867468 139.74041420367882 34.813</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d33b3286-46fa-4f92-a8ff-51d58948f0eb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d33b3286-46fa-4f92-a8ff-51d58948f0eb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d33b3286-46fa-4f92-a8ff-51d58948f0eb">
											<gml:posList>35.67103803019911 139.74038844485514 38.137 35.67103803019911 139.74038844485514 37.701 35.67102277781805 139.740410312213 37.701 35.67102277781805 139.740410312213 38.137 35.671021085105224 139.74041273332497 38.137 35.671021085105224 139.74041273332497 34.813 35.67102005867468 139.74041420367882 34.813 35.67102005867468 139.74041420367882 39.958 35.67103971389773 139.74038602375256 39.958 35.67103971389773 139.74038602375256 38.137 35.67103803019911 139.74038844485514 38.137</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ccca72d4-fed4-4fc4-b0a7-900148877dd4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ccca72d4-fed4-4fc4-b0a7-900148877dd4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ccca72d4-fed4-4fc4-b0a7-900148877dd4">
											<gml:posList>35.67105338976668 139.7404003460633 35.389 35.671008284642916 139.740353097892 35.389 35.671008284642916 139.740353097892 38.137 35.67103971389773 139.74038602375256 38.137 35.67103971389773 139.74038602375256 39.958 35.67105338976668 139.7404003460633 39.958 35.67105338976668 139.7404003460633 35.389</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f5c83225-0f7d-4c71-bc57-d0e302e80429">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f5c83225-0f7d-4c71-bc57-d0e302e80429">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f5c83225-0f7d-4c71-bc57-d0e302e80429">
											<gml:posList>35.671033068257884 139.74042947674897 34.813 35.671058543613086 139.74045615731058 34.813 35.671058543613086 139.74045615731058 41.499 35.671033068257884 139.74042947674897 41.499 35.671033068257884 139.74042947674897 34.813</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-13c39578-be92-44ad-ace3-ca14076f276b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-13c39578-be92-44ad-ace3-ca14076f276b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-13c39578-be92-44ad-ace3-ca14076f276b">
											<gml:posList>35.67105828811889 139.74045212568774 41.499 35.67105828811889 139.74045212568774 41.17 35.67103634901395 139.7404291636496 41.17 35.67103634901395 139.7404291636496 41.499 35.67105828811889 139.74045212568774 41.499</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9969d3cd-c8d8-4562-a703-b848a8e1b8f2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9969d3cd-c8d8-4562-a703-b848a8e1b8f2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9969d3cd-c8d8-4562-a703-b848a8e1b8f2">
											<gml:posList>35.67103373454886 139.7404285370372 39.958 35.67103373454886 139.7404285370372 34.813 35.671033068257884 139.74042947674897 34.813 35.671033068257884 139.74042947674897 41.499 35.67107051492771 139.74037579225975 41.499 35.67107051492771 139.74037579225975 35.389 35.67111490345576 139.74031213584982 35.389 35.67111490345576 139.74031213584982 9.63 35.67105570373547 139.74039702947536 9.63 35.67105570373547 139.74039702947536 35.389 35.67105338976668 139.7404003460633 35.389 35.67105338976668 139.7404003460633 39.958 35.67103373454886 139.7404285370372 39.958</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d2a7a448-2560-425b-8cb5-02b437e4b407">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d2a7a448-2560-425b-8cb5-02b437e4b407">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d2a7a448-2560-425b-8cb5-02b437e4b407">
											<gml:posList>35.671058543613086 139.74045615731058 34.813 35.67109598128093 139.74040247282716 34.813 35.67109598128093 139.74040247282716 41.499 35.671058543613086 139.74045615731058 41.499 35.671058543613086 139.74045615731058 34.813</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-28f84f9d-f1e2-4bf3-97ed-97ee02fae919">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-28f84f9d-f1e2-4bf3-97ed-97ee02fae919">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-28f84f9d-f1e2-4bf3-97ed-97ee02fae919">
											<gml:posList>35.67107076140223 139.74037981284704 41.499 35.67107076140223 139.74037981284704 41.17 35.671092691519775 139.74040279698465 41.17 35.671092691519775 139.74040279698465 41.499 35.67107076140223 139.74037981284704 41.499</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-87b38415-62e4-4846-b69c-66eaa32acc2d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-87b38415-62e4-4846-b69c-66eaa32acc2d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-87b38415-62e4-4846-b69c-66eaa32acc2d">
											<gml:posList>35.67107334753023 139.74037876044503 35.389 35.67107051492771 139.74037579225975 35.389 35.67107051492771 139.74037579225975 41.499 35.67109598128093 139.74040247282716 41.499 35.67109598128093 139.74040247282716 34.813 35.67107334753023 139.74037876044503 34.813 35.67107334753023 139.74037876044503 35.389</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9c83c83d-441e-4e35-9c6f-fb5dea3ce925">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9c83c83d-441e-4e35-9c6f-fb5dea3ce925">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9c83c83d-441e-4e35-9c6f-fb5dea3ce925">
											<gml:posList>35.671153815633616 139.74033535434984 35.389 35.671153815633616 139.74033535434984 34.813 35.6710188732992 139.74053684160188 34.813 35.6710188732992 139.74053684160188 35.389 35.671153815633616 139.74033535434984 35.389</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ce8e1482-1a6c-4eab-9912-2c863fb06748">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ce8e1482-1a6c-4eab-9912-2c863fb06748">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ce8e1482-1a6c-4eab-9912-2c863fb06748">
											<gml:posList>35.67107334753023 139.74037876044503 35.389 35.67107334753023 139.74037876044503 34.813 35.67111530504294 139.74031858645853 34.813 35.67111530504294 139.74031858645853 35.389 35.67107334753023 139.74037876044503 35.389</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1a7d4fcc-b9c4-47fc-8186-3eafc3b09878">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1a7d4fcc-b9c4-47fc-8186-3eafc3b09878">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1a7d4fcc-b9c4-47fc-8186-3eafc3b09878">
											<gml:posList>35.671139034700104 139.7403374040257 9.63 35.67111490345576 139.74031213584982 9.63 35.67111490345576 139.74031213584982 35.389 35.671139034700104 139.7403374040257 35.389 35.671139034700104 139.7403374040257 9.63</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a4962d0d-6b31-4128-96f7-7c0d95330977">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a4962d0d-6b31-4128-96f7-7c0d95330977">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a4962d0d-6b31-4128-96f7-7c0d95330977">
											<gml:posList>35.67111530504294 139.74031858645853 35.389 35.67111530504294 139.74031858645853 34.813 35.671139625727626 139.74034405325133 34.813 35.671139625727626 139.74034405325133 35.389 35.67111530504294 139.74031858645853 35.389</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-be219c9f-dd72-4b7b-be3e-1f53e5431fcf">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-be219c9f-dd72-4b7b-be3e-1f53e5431fcf">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-be219c9f-dd72-4b7b-be3e-1f53e5431fcf">
											<gml:posList>35.671060625459205 139.7405843699205 9.63 35.67119954618957 139.74037543277598 9.63 35.67119954618957 139.74037543277598 28.185 35.671060625459205 139.7405843699205 28.185 35.671060625459205 139.7405843699205 9.63</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e5aec15a-9186-467f-b8df-694945363ba8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e5aec15a-9186-467f-b8df-694945363ba8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e5aec15a-9186-467f-b8df-694945363ba8">
											<gml:posList>35.67114767695193 139.74032325465407 9.63 35.671139034700104 139.7403374040257 9.63 35.671139034700104 139.7403374040257 35.389 35.67114767695193 139.74032325465407 35.389 35.67114767695193 139.74032325465407 9.63</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7e203c5c-5c2e-43d0-a800-28ea7e74a9f1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7e203c5c-5c2e-43d0-a800-28ea7e74a9f1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7e203c5c-5c2e-43d0-a800-28ea7e74a9f1">
											<gml:posList>35.671139625727626 139.74034405325133 35.389 35.671139625727626 139.74034405325133 34.813 35.671148312989125 139.74032982650354 34.813 35.671148312989125 139.74032982650354 35.389 35.671139625727626 139.74034405325133 35.389</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-34b7efd5-c44f-4fa9-b14b-4630722c2cf9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-34b7efd5-c44f-4fa9-b14b-4630722c2cf9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-34b7efd5-c44f-4fa9-b14b-4630722c2cf9">
											<gml:posList>35.671148312989125 139.74032982650354 35.389 35.671148312989125 139.74032982650354 34.813 35.671153815633616 139.74033535434984 34.813 35.671153815633616 139.74033535434984 35.389 35.671148312989125 139.74032982650354 35.389</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-acb43fcb-ce2c-4951-8e51-60aa0169de66">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-acb43fcb-ce2c-4951-8e51-60aa0169de66">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-acb43fcb-ce2c-4951-8e51-60aa0169de66">
											<gml:posList>35.67119954618957 139.74037543277598 28.185 35.67119954618957 139.74037543277598 9.63 35.67114767695193 139.74032325465407 9.63 35.67114767695193 139.74032325465407 35.389 35.671159070146956 139.74033471861205 35.389 35.67119954618957 139.74037543277598 28.185</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-7697</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">414.9481</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1210</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>6</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.05</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>