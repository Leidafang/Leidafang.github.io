<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_0a7c3ff7-6119-4874-91f5-f617789a47ab">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3001</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">402</bldg:usage>
			<bldg:measuredHeight uom="m">7.2</bldg:measuredHeight>
			<bldg:storeysAboveGround>2</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.67255479976066 139.73972830048442 0 35.67258375904206 139.73976074356767 0 35.67260717041391 139.73972945446042 0 35.67261971030276 139.73974335849502 0 35.67266284109832 139.73968553456353 0 35.67252742711911 139.73953402353766 0 35.67246223574108 139.7396213675258 0 35.67251672613292 139.73968239127427 0 35.67250628104318 139.73969632213144 0 35.67254570534979 139.73974046231623 0 35.67255479976066 139.73972830048442 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67255479976066 139.73972830048442 7.72 35.67254570534979 139.73974046231623 7.72 35.67250628104318 139.73969632213144 7.72 35.67251672613292 139.73968239127427 7.72 35.67246223574108 139.7396213675258 7.72 35.67252742711911 139.73953402353766 7.72 35.67266284109832 139.73968553456353 7.72 35.67261971030276 139.73974335849502 7.72 35.67260717041391 139.73972945446042 7.72 35.67258375904206 139.73976074356767 7.72 35.67255479976066 139.73972830048442 7.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67255479976066 139.73972830048442 7.72 35.67258375904206 139.73976074356767 7.72 35.67258375904206 139.73976074356767 14.88 35.67255479976066 139.73972830048442 14.88 35.67255479976066 139.73972830048442 7.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67258375904206 139.73976074356767 7.72 35.67260717041391 139.73972945446042 7.72 35.67260717041391 139.73972945446042 14.88 35.67258375904206 139.73976074356767 14.88 35.67258375904206 139.73976074356767 7.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67260717041391 139.73972945446042 7.72 35.67261971030276 139.73974335849502 7.72 35.67261971030276 139.73974335849502 14.88 35.67260717041391 139.73972945446042 14.88 35.67260717041391 139.73972945446042 7.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67261971030276 139.73974335849502 7.72 35.67266284109832 139.73968553456353 7.72 35.67266284109832 139.73968553456353 14.88 35.67261971030276 139.73974335849502 14.88 35.67261971030276 139.73974335849502 7.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67266284109832 139.73968553456353 7.72 35.67252742711911 139.73953402353766 7.72 35.67252742711911 139.73953402353766 14.88 35.67266284109832 139.73968553456353 14.88 35.67266284109832 139.73968553456353 7.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67252742711911 139.73953402353766 7.72 35.67246223574108 139.7396213675258 7.72 35.67246223574108 139.7396213675258 14.88 35.67252742711911 139.73953402353766 14.88 35.67252742711911 139.73953402353766 7.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67246223574108 139.7396213675258 7.72 35.67251672613292 139.73968239127427 7.72 35.67251672613292 139.73968239127427 14.88 35.67246223574108 139.7396213675258 14.88 35.67246223574108 139.7396213675258 7.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67251672613292 139.73968239127427 7.72 35.67250628104318 139.73969632213144 7.72 35.67250628104318 139.73969632213144 14.88 35.67251672613292 139.73968239127427 14.88 35.67251672613292 139.73968239127427 7.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67250628104318 139.73969632213144 7.72 35.67254570534979 139.73974046231623 7.72 35.67254570534979 139.73974046231623 14.88 35.67250628104318 139.73969632213144 14.88 35.67250628104318 139.73969632213144 7.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67254570534979 139.73974046231623 7.72 35.67255479976066 139.73972830048442 7.72 35.67255479976066 139.73972830048442 14.88 35.67254570534979 139.73974046231623 14.88 35.67254570534979 139.73974046231623 7.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67255479976066 139.73972830048442 14.88 35.67258375904206 139.73976074356767 14.88 35.67260717041391 139.73972945446042 14.88 35.67261971030276 139.73974335849502 14.88 35.67266284109832 139.73968553456353 14.88 35.67252742711911 139.73953402353766 14.88 35.67246223574108 139.7396213675258 14.88 35.67251672613292 139.73968239127427 14.88 35.67250628104318 139.73969632213144 14.88 35.67254570534979 139.73974046231623 14.88 35.67255479976066 139.73972830048442 14.88</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-ce83471d-0272-4d33-8939-11bf5ed299cf"/>
							<gml:surfaceMember xlink:href="#poly-e84df9db-f25a-45d8-8eef-8fd541bb11ad"/>
							<gml:surfaceMember xlink:href="#poly-1b99629c-d5aa-43ac-b435-e1b5557692d7"/>
							<gml:surfaceMember xlink:href="#poly-de15f28c-0a29-4fe2-b4d4-d2fc77bf7353"/>
							<gml:surfaceMember xlink:href="#poly-97396e30-bedd-4c75-8352-7473a3813460"/>
							<gml:surfaceMember xlink:href="#poly-79847e46-032b-4e31-af05-425f11706e63"/>
							<gml:surfaceMember xlink:href="#poly-e47cd309-794a-4dfd-9e2b-1d3a007aa331"/>
							<gml:surfaceMember xlink:href="#poly-1160d724-53db-49f8-8cd1-234fce9e1efd"/>
							<gml:surfaceMember xlink:href="#poly-98b5b14e-158a-404c-bebb-46cae620d80d"/>
							<gml:surfaceMember xlink:href="#poly-4f5af75f-10d0-4d95-b5b4-02a09efa6b57"/>
							<gml:surfaceMember xlink:href="#poly-ea70572a-d237-4880-a81f-8eec68fc0c5a"/>
							<gml:surfaceMember xlink:href="#poly-d3ced81e-3d04-42c2-9f1f-8d83c082feab"/>
							<gml:surfaceMember xlink:href="#poly-84999a39-627a-42cc-8f66-3413676f2576"/>
							<gml:surfaceMember xlink:href="#poly-c7be0f8c-b031-4c0c-aa87-c1edee4256d9"/>
							<gml:surfaceMember xlink:href="#poly-fdb3dec8-6d9e-484f-a423-09ecab7457c6"/>
							<gml:surfaceMember xlink:href="#poly-f4b39910-b460-4683-936a-06cceeeb892e"/>
							<gml:surfaceMember xlink:href="#poly-ea185518-2221-4dec-98e5-44d4d9eebfbe"/>
							<gml:surfaceMember xlink:href="#poly-90dbe036-2f30-4bee-aa6a-1ab067dc89dc"/>
							<gml:surfaceMember xlink:href="#poly-8d9c0ef2-cd2e-4373-b64e-adc8ff4d72ba"/>
							<gml:surfaceMember xlink:href="#poly-0c617e8d-98b9-404d-a385-8b58b53e6183"/>
							<gml:surfaceMember xlink:href="#poly-9cd1212b-fb41-4ce1-932b-7bda852f9744"/>
							<gml:surfaceMember xlink:href="#poly-e8b2bb20-9694-4b0f-9b3c-ddc82077c5f2"/>
							<gml:surfaceMember xlink:href="#poly-7e0da9c1-613a-4e18-9343-e69ae0db765f"/>
							<gml:surfaceMember xlink:href="#poly-01b8a7f9-7a21-45d4-aeaf-9a0e7ed4f08d"/>
							<gml:surfaceMember xlink:href="#poly-ef1f5790-cdb9-409a-89a0-17010919ff3c"/>
							<gml:surfaceMember xlink:href="#poly-81eb2b2d-99eb-441a-948a-8dcc55762eae"/>
							<gml:surfaceMember xlink:href="#poly-0f78c0bc-b33d-43eb-93be-909f64393570"/>
							<gml:surfaceMember xlink:href="#poly-a56170da-e6c5-49ca-bf54-d284b354d488"/>
							<gml:surfaceMember xlink:href="#poly-44e12d63-007c-4b81-9d12-4f9df0cc1a9a"/>
							<gml:surfaceMember xlink:href="#poly-e5336678-1554-4999-a534-4a3910478cc5"/>
							<gml:surfaceMember xlink:href="#poly-a3ab73af-24a0-461f-9a52-abf4b72bfa19"/>
							<gml:surfaceMember xlink:href="#poly-37785610-2cb1-4d67-b4dd-f7cc6744da9a"/>
							<gml:surfaceMember xlink:href="#poly-d4149ae1-d5c1-482a-93de-441183689e03"/>
							<gml:surfaceMember xlink:href="#poly-0d4875cf-4b36-4c4e-b01d-dc0f8bea8cd7"/>
							<gml:surfaceMember xlink:href="#poly-1a8f2d04-4184-49cb-be16-aaeb51af2f14"/>
							<gml:surfaceMember xlink:href="#poly-4c7428f0-418d-48d5-a65e-f83588eb0160"/>
							<gml:surfaceMember xlink:href="#poly-1a67c9a1-b18e-40a5-b0b0-be6a021e1307"/>
							<gml:surfaceMember xlink:href="#poly-2cd2e715-aef4-4810-a945-03cae13dbe9c"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-ce83471d-0272-4d33-8939-11bf5ed299cf">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ce83471d-0272-4d33-8939-11bf5ed299cf">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ce83471d-0272-4d33-8939-11bf5ed299cf">
											<gml:posList>35.67266284109832 139.73968553456353 7.72 35.67261971030274 139.739743358495 7.72 35.672607170413876 139.73972945446042 7.72 35.67258375904205 139.73976074356767 7.72 35.67255479976066 139.7397283004844 7.72 35.67254570534977 139.7397404623162 7.72 35.672506281043184 139.73969632213144 7.72 35.67251672613293 139.73968239127424 7.72 35.67246223574107 139.73962136752579 7.72 35.672527427119086 139.73953402353766 7.72 35.67266284109832 139.73968553456353 7.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e84df9db-f25a-45d8-8eef-8fd541bb11ad">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e84df9db-f25a-45d8-8eef-8fd541bb11ad">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e84df9db-f25a-45d8-8eef-8fd541bb11ad">
											<gml:posList>35.67258375904205 139.73976074356767 13.377 35.672607170413876 139.73972945446042 13.377 35.67264282721391 139.73968115035993 13.377 35.67258375904205 139.73976074356767 13.377</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-1b99629c-d5aa-43ac-b435-e1b5557692d7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1b99629c-d5aa-43ac-b435-e1b5557692d7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1b99629c-d5aa-43ac-b435-e1b5557692d7">
											<gml:posList>35.67248954588946 139.7395847715226 14.452 35.67246223574107 139.73962136752579 13.377 35.67251672613293 139.73968239127424 13.377 35.67248954588946 139.7395847715226 14.452</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-de15f28c-0a29-4fe2-b4d4-d2fc77bf7353">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-de15f28c-0a29-4fe2-b4d4-d2fc77bf7353">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-de15f28c-0a29-4fe2-b4d4-d2fc77bf7353">
											<gml:posList>35.6725156740637 139.73959298169848 14.139 35.6725088601806 139.73955888895762 13.377 35.67248954588946 139.7395847715226 14.452 35.6725156740637 139.73959298169848 14.139</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-97396e30-bedd-4c75-8352-7473a3813460">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-97396e30-bedd-4c75-8352-7473a3813460">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-97396e30-bedd-4c75-8352-7473a3813460">
											<gml:posList>35.67248954588946 139.7395847715226 14.452 35.67250711996507 139.73960446906833 14.747 35.6725156740637 139.73959298169848 14.139 35.67248954588946 139.7395847715226 14.452</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-79847e46-032b-4e31-af05-425f11706e63">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-79847e46-032b-4e31-af05-425f11706e63">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-79847e46-032b-4e31-af05-425f11706e63">
											<gml:posList>35.6725156740637 139.73959298169848 14.139 35.67250711996507 139.73960446906833 14.747 35.67252470306833 139.73962418870522 15.042 35.6725156740637 139.73959298169848 14.139</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e47cd309-794a-4dfd-9e2b-1d3a007aa331">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e47cd309-794a-4dfd-9e2b-1d3a007aa331">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e47cd309-794a-4dfd-9e2b-1d3a007aa331">
											<gml:posList>35.6725156740637 139.73959298169848 14.139 35.67252641621574 139.7395785644304 14.139 35.6725088601806 139.73955888895762 13.377 35.6725156740637 139.73959298169848 14.139</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-1160d724-53db-49f8-8cd1-234fce9e1efd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1160d724-53db-49f8-8cd1-234fce9e1efd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1160d724-53db-49f8-8cd1-234fce9e1efd">
											<gml:posList>35.672527427119086 139.73953402353766 13.377 35.6725088601806 139.73955888895762 13.377 35.67252641621574 139.7395785644304 14.139 35.6725449741101 139.73955365483386 14.139 35.672527427119086 139.73953402353766 13.377</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-98b5b14e-158a-404c-bebb-46cae620d80d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-98b5b14e-158a-404c-bebb-46cae620d80d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-98b5b14e-158a-404c-bebb-46cae620d80d">
											<gml:posList>35.67252470306833 139.73962418870522 15.042 35.672543972256236 139.73959825095832 13.377 35.6725156740637 139.73959298169848 14.139 35.67252470306833 139.73962418870522 15.042</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-4f5af75f-10d0-4d95-b5b4-02a09efa6b57">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4f5af75f-10d0-4d95-b5b4-02a09efa6b57">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4f5af75f-10d0-4d95-b5b4-02a09efa6b57">
											<gml:posList>35.672543972256236 139.73959825095832 13.377 35.67252641621574 139.7395785644304 14.139 35.6725156740637 139.73959298169848 14.139 35.672543972256236 139.73959825095832 13.377</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ea70572a-d237-4880-a81f-8eec68fc0c5a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ea70572a-d237-4880-a81f-8eec68fc0c5a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ea70572a-d237-4880-a81f-8eec68fc0c5a">
											<gml:posList>35.672506281043184 139.73969632213144 12.228 35.67254570534977 139.7397404623162 12.228 35.67255479976066 139.7397283004844 12.228 35.67251672613293 139.73968239127424 12.228 35.672506281043184 139.73969632213144 12.228</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d3ced81e-3d04-42c2-9f1f-8d83c082feab">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d3ced81e-3d04-42c2-9f1f-8d83c082feab">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d3ced81e-3d04-42c2-9f1f-8d83c082feab">
											<gml:posList>35.67251672613293 139.73968239127424 13.377 35.67258046555251 139.7396867023031 15.978 35.67252470306833 139.73962418870522 15.042 35.67250711996507 139.73960446906833 14.747 35.67248954588946 139.7395847715226 14.452 35.67251672613293 139.73968239127424 13.377</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-84999a39-627a-42cc-8f66-3413676f2576">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-84999a39-627a-42cc-8f66-3413676f2576">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-84999a39-627a-42cc-8f66-3413676f2576">
											<gml:posList>35.6725449741101 139.73955365483386 14.139 35.67252641621574 139.7395785644304 14.139 35.672543972256236 139.73959825095832 13.377 35.67256252109789 139.7395732861387 13.377 35.6725449741101 139.73955365483386 14.139</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c7be0f8c-b031-4c0c-aa87-c1edee4256d9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c7be0f8c-b031-4c0c-aa87-c1edee4256d9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c7be0f8c-b031-4c0c-aa87-c1edee4256d9">
											<gml:posList>35.67255258028179 139.7397255966689 15.623 35.67258046555251 139.7396867023031 15.978 35.67251672613293 139.73968239127424 13.377 35.67255258028179 139.7397255966689 15.623</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-fdb3dec8-6d9e-484f-a423-09ecab7457c6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fdb3dec8-6d9e-484f-a423-09ecab7457c6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fdb3dec8-6d9e-484f-a423-09ecab7457c6">
											<gml:posList>35.672579084318855 139.73963761299353 13.377 35.672543972256236 139.73959825095832 13.377 35.67252470306833 139.73962418870522 15.042 35.672579084318855 139.73963761299353 13.377</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f4b39910-b460-4683-936a-06cceeeb892e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f4b39910-b460-4683-936a-06cceeeb892e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f4b39910-b460-4683-936a-06cceeeb892e">
											<gml:posList>35.67252470306833 139.73962418870522 15.042 35.67258046555251 139.7396867023031 15.978 35.672579084318855 139.73963761299353 13.377 35.67252470306833 139.73962418870522 15.042</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ea185518-2221-4dec-98e5-44d4d9eebfbe">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ea185518-2221-4dec-98e5-44d4d9eebfbe">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ea185518-2221-4dec-98e5-44d4d9eebfbe">
											<gml:posList>35.67258046555251 139.7396867023031 15.978 35.67255258028179 139.7397255966689 15.623 35.67258375904205 139.73976074356767 13.377 35.67258046555251 139.7396867023031 15.978</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-90dbe036-2f30-4bee-aa6a-1ab067dc89dc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-90dbe036-2f30-4bee-aa6a-1ab067dc89dc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-90dbe036-2f30-4bee-aa6a-1ab067dc89dc">
											<gml:posList>35.67259010551453 139.73962269829843 13.377 35.67259760605002 139.7396125487846 13.377 35.67256252109789 139.7395732861387 13.377 35.672543972256236 139.73959825095832 13.377 35.672579084318855 139.73963761299353 13.377 35.67259010551453 139.73962269829843 13.377</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-8d9c0ef2-cd2e-4373-b64e-adc8ff4d72ba">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8d9c0ef2-cd2e-4373-b64e-adc8ff4d72ba">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8d9c0ef2-cd2e-4373-b64e-adc8ff4d72ba">
											<gml:posList>35.67261160376609 139.73964652270718 15.623 35.67259010551453 139.73962269829843 13.377 35.672579084318855 139.73963761299353 13.377 35.67261160376609 139.73964652270718 15.623</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-0c617e8d-98b9-404d-a385-8b58b53e6183">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0c617e8d-98b9-404d-a385-8b58b53e6183">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0c617e8d-98b9-404d-a385-8b58b53e6183">
											<gml:posList>35.672579084318855 139.73963761299353 13.377 35.67258046555251 139.7396867023031 15.978 35.67261160376609 139.73964652270718 15.623 35.672579084318855 139.73963761299353 13.377</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-9cd1212b-fb41-4ce1-932b-7bda852f9744">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9cd1212b-fb41-4ce1-932b-7bda852f9744">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9cd1212b-fb41-4ce1-932b-7bda852f9744">
											<gml:posList>35.67258046555251 139.7396867023031 15.978 35.67264282721391 139.73968115035993 13.377 35.67261160376609 139.73964652270718 15.623 35.67258046555251 139.7396867023031 15.978</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e8b2bb20-9694-4b0f-9b3c-ddc82077c5f2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e8b2bb20-9694-4b0f-9b3c-ddc82077c5f2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e8b2bb20-9694-4b0f-9b3c-ddc82077c5f2">
											<gml:posList>35.67258046555251 139.7396867023031 15.978 35.67258375904205 139.73976074356767 13.377 35.67264282721391 139.73968115035993 13.377 35.67258046555251 139.7396867023031 15.978</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-7e0da9c1-613a-4e18-9343-e69ae0db765f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7e0da9c1-613a-4e18-9343-e69ae0db765f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7e0da9c1-613a-4e18-9343-e69ae0db765f">
											<gml:posList>35.67264282721391 139.73968115035993 13.377 35.672607170413876 139.73972945446042 13.377 35.67261971030274 139.739743358495 13.377 35.67266284109832 139.73968553456353 13.377 35.67259760605002 139.7396125487846 13.377 35.67259010551453 139.73962269829843 13.377 35.67264282721391 139.73968115035993 13.377</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-01b8a7f9-7a21-45d4-aeaf-9a0e7ed4f08d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-01b8a7f9-7a21-45d4-aeaf-9a0e7ed4f08d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-01b8a7f9-7a21-45d4-aeaf-9a0e7ed4f08d">
											<gml:posList>35.672527427119086 139.73953402353766 7.72 35.67246223574107 139.73962136752579 7.72 35.67246223574107 139.73962136752579 13.377 35.67248954588946 139.7395847715226 14.452 35.6725088601806 139.73955888895762 13.377 35.672527427119086 139.73953402353766 13.377 35.672527427119086 139.73953402353766 7.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ef1f5790-cdb9-409a-89a0-17010919ff3c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ef1f5790-cdb9-409a-89a0-17010919ff3c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ef1f5790-cdb9-409a-89a0-17010919ff3c">
											<gml:posList>35.67259760605002 139.7396125487846 13.377 35.67266284109832 139.73968553456353 13.377 35.67266284109832 139.73968553456353 7.72 35.672527427119086 139.73953402353766 7.72 35.672527427119086 139.73953402353766 13.377 35.6725449741101 139.73955365483386 14.139 35.67256252109789 139.7395732861387 13.377 35.67259760605002 139.7396125487846 13.377</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-81eb2b2d-99eb-441a-948a-8dcc55762eae">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-81eb2b2d-99eb-441a-948a-8dcc55762eae">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-81eb2b2d-99eb-441a-948a-8dcc55762eae">
											<gml:posList>35.67246223574107 139.73962136752579 13.377 35.67246223574107 139.73962136752579 7.72 35.67251672613293 139.73968239127424 7.72 35.67251672613293 139.73968239127424 12.228 35.67251672613293 139.73968239127424 13.377 35.67246223574107 139.73962136752579 13.377</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0f78c0bc-b33d-43eb-93be-909f64393570">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0f78c0bc-b33d-43eb-93be-909f64393570">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0f78c0bc-b33d-43eb-93be-909f64393570">
											<gml:posList>35.67261160376609 139.73964652270718 15.623 35.67264282721391 139.73968115035993 13.377 35.67259010551453 139.73962269829843 13.377 35.67261160376609 139.73964652270718 15.623</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a56170da-e6c5-49ca-bf54-d284b354d488">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a56170da-e6c5-49ca-bf54-d284b354d488">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a56170da-e6c5-49ca-bf54-d284b354d488">
											<gml:posList>35.67251672613293 139.73968239127424 12.228 35.67251672613293 139.73968239127424 7.72 35.672506281043184 139.73969632213144 7.72 35.672506281043184 139.73969632213144 12.228 35.67251672613293 139.73968239127424 12.228</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-44e12d63-007c-4b81-9d12-4f9df0cc1a9a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-44e12d63-007c-4b81-9d12-4f9df0cc1a9a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-44e12d63-007c-4b81-9d12-4f9df0cc1a9a">
											<gml:posList>35.67255258028179 139.7397255966689 15.623 35.67251672613293 139.73968239127424 13.377 35.67251672613293 139.73968239127424 12.228 35.67255258028179 139.7397255966689 15.623</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e5336678-1554-4999-a534-4a3910478cc5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e5336678-1554-4999-a534-4a3910478cc5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e5336678-1554-4999-a534-4a3910478cc5">
											<gml:posList>35.67255258028179 139.7397255966689 15.623 35.67251672613293 139.73968239127424 12.228 35.67255479976066 139.7397283004844 12.228 35.67255258028179 139.7397255966689 15.623</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a3ab73af-24a0-461f-9a52-abf4b72bfa19">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a3ab73af-24a0-461f-9a52-abf4b72bfa19">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a3ab73af-24a0-461f-9a52-abf4b72bfa19">
											<gml:posList>35.67261971030274 139.739743358495 13.377 35.67261971030274 139.739743358495 7.72 35.67266284109832 139.73968553456353 7.72 35.67266284109832 139.73968553456353 13.377 35.67261971030274 139.739743358495 13.377</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-37785610-2cb1-4d67-b4dd-f7cc6744da9a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-37785610-2cb1-4d67-b4dd-f7cc6744da9a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-37785610-2cb1-4d67-b4dd-f7cc6744da9a">
											<gml:posList>35.672506281043184 139.73969632213144 12.228 35.672506281043184 139.73969632213144 7.72 35.67254570534977 139.7397404623162 7.72 35.67254570534977 139.7397404623162 12.228 35.672506281043184 139.73969632213144 12.228</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d4149ae1-d5c1-482a-93de-441183689e03">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d4149ae1-d5c1-482a-93de-441183689e03">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d4149ae1-d5c1-482a-93de-441183689e03">
											<gml:posList>35.67254570534977 139.7397404623162 12.228 35.67254570534977 139.7397404623162 7.72 35.67255479976066 139.7397283004844 7.72 35.67255479976066 139.7397283004844 12.228 35.67254570534977 139.7397404623162 12.228</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0d4875cf-4b36-4c4e-b01d-dc0f8bea8cd7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0d4875cf-4b36-4c4e-b01d-dc0f8bea8cd7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0d4875cf-4b36-4c4e-b01d-dc0f8bea8cd7">
											<gml:posList>35.672607170413876 139.73972945446042 13.377 35.672607170413876 139.73972945446042 7.72 35.67261971030274 139.739743358495 7.72 35.67261971030274 139.739743358495 13.377 35.672607170413876 139.73972945446042 13.377</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1a8f2d04-4184-49cb-be16-aaeb51af2f14">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1a8f2d04-4184-49cb-be16-aaeb51af2f14">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1a8f2d04-4184-49cb-be16-aaeb51af2f14">
											<gml:posList>35.67255258028179 139.7397255966689 15.623 35.67258375904205 139.73976074356767 7.72 35.67258375904205 139.73976074356767 13.377 35.67255258028179 139.7397255966689 15.623</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4c7428f0-418d-48d5-a65e-f83588eb0160">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4c7428f0-418d-48d5-a65e-f83588eb0160">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4c7428f0-418d-48d5-a65e-f83588eb0160">
											<gml:posList>35.67255258028179 139.7397255966689 15.623 35.67255479976066 139.7397283004844 12.228 35.67258375904205 139.73976074356767 7.72 35.67255258028179 139.7397255966689 15.623</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1a67c9a1-b18e-40a5-b0b0-be6a021e1307">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1a67c9a1-b18e-40a5-b0b0-be6a021e1307">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1a67c9a1-b18e-40a5-b0b0-be6a021e1307">
											<gml:posList>35.67255479976066 139.7397283004844 12.228 35.67255479976066 139.7397283004844 7.72 35.67258375904205 139.73976074356767 7.72 35.67255479976066 139.7397283004844 12.228</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2cd2e715-aef4-4810-a945-03cae13dbe9c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2cd2e715-aef4-4810-a945-03cae13dbe9c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2cd2e715-aef4-4810-a945-03cae13dbe9c">
											<gml:posList>35.67258375904205 139.73976074356767 13.377 35.67258375904205 139.73976074356767 7.72 35.672607170413876 139.73972945446042 7.72 35.672607170413876 139.73972945446042 13.377 35.67258375904205 139.73976074356767 13.377</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-10330</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">222.3749</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1003</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1242</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>7</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.18</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">21</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>