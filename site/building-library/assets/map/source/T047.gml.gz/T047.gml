<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_0b140369-5113-4307-b960-a59e5262c056">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">401</bldg:usage>
			<bldg:measuredHeight uom="m">12.6</bldg:measuredHeight>
			<bldg:storeysAboveGround>3</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.67159335629405 139.7404926206171 0 35.67152934296869 139.74058901950687 0 35.67162640526957 139.7406858948919 0 35.67173462480213 139.74052294521994 0 35.6715874976861 139.7403761980736 0 35.67154329163533 139.74044274877446 0 35.67159335629405 139.7404926206171 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67159335629405 139.7404926206171 7.98 35.67154329163533 139.74044274877446 7.98 35.6715874976861 139.7403761980736 7.98 35.67173462480213 139.74052294521994 7.98 35.67162640526957 139.7406858948919 7.98 35.67152934296869 139.74058901950687 7.98 35.67159335629405 139.7404926206171 7.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67159335629405 139.7404926206171 7.98 35.67152934296869 139.74058901950687 7.98 35.67152934296869 139.74058901950687 20.47 35.67159335629405 139.7404926206171 20.47 35.67159335629405 139.7404926206171 7.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67152934296869 139.74058901950687 7.98 35.67162640526957 139.7406858948919 7.98 35.67162640526957 139.7406858948919 20.47 35.67152934296869 139.74058901950687 20.47 35.67152934296869 139.74058901950687 7.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67162640526957 139.7406858948919 7.98 35.67173462480213 139.74052294521994 7.98 35.67173462480213 139.74052294521994 20.47 35.67162640526957 139.7406858948919 20.47 35.67162640526957 139.7406858948919 7.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67173462480213 139.74052294521994 7.98 35.6715874976861 139.7403761980736 7.98 35.6715874976861 139.7403761980736 20.47 35.67173462480213 139.74052294521994 20.47 35.67173462480213 139.74052294521994 7.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6715874976861 139.7403761980736 7.98 35.67154329163533 139.74044274877446 7.98 35.67154329163533 139.74044274877446 20.47 35.6715874976861 139.7403761980736 20.47 35.6715874976861 139.7403761980736 7.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67154329163533 139.74044274877446 7.98 35.67159335629405 139.7404926206171 7.98 35.67159335629405 139.7404926206171 20.47 35.67154329163533 139.74044274877446 20.47 35.67154329163533 139.74044274877446 7.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67159335629405 139.7404926206171 20.47 35.67152934296869 139.74058901950687 20.47 35.67162640526957 139.7406858948919 20.47 35.67173462480213 139.74052294521994 20.47 35.6715874976861 139.7403761980736 20.47 35.67154329163533 139.74044274877446 20.47 35.67159335629405 139.7404926206171 20.47</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-443715db-a627-4809-bee8-4fcd1ba5c35b"/>
							<gml:surfaceMember xlink:href="#poly-bd4bddc3-04bb-45a1-8a78-a1501342089d"/>
							<gml:surfaceMember xlink:href="#poly-7f3495f1-514f-4ea1-a3ed-1c4efa8b1b2b"/>
							<gml:surfaceMember xlink:href="#poly-ef2c12e2-4512-497d-86e5-4523e27b3e98"/>
							<gml:surfaceMember xlink:href="#poly-2e7c3d41-da22-46eb-9799-04fad5318f1b"/>
							<gml:surfaceMember xlink:href="#poly-57b2d9fa-5292-4a7e-96e4-dc92061afa0c"/>
							<gml:surfaceMember xlink:href="#poly-dca86ec5-bc50-44c5-a644-29d16b62bfa5"/>
							<gml:surfaceMember xlink:href="#poly-5e161655-3eda-4042-bdb2-747143390ede"/>
							<gml:surfaceMember xlink:href="#poly-93563c2b-69b6-47fd-96d3-8451025420ea"/>
							<gml:surfaceMember xlink:href="#poly-67c9075d-9846-4e60-9b19-15ac36fa0654"/>
							<gml:surfaceMember xlink:href="#poly-8416ea9f-8fad-4f49-a2d2-de3f35663c84"/>
							<gml:surfaceMember xlink:href="#poly-da176d1f-4ea2-4d9e-91ff-2bf28a2c66fb"/>
							<gml:surfaceMember xlink:href="#poly-2c69678a-9c37-4154-af42-c60a79acc096"/>
							<gml:surfaceMember xlink:href="#poly-e5c8ec3e-a6c0-46d7-a02b-c8e7728e4ab6"/>
							<gml:surfaceMember xlink:href="#poly-6b9c9ee7-f7b5-4319-ac9d-b074048220f3"/>
							<gml:surfaceMember xlink:href="#poly-810b8ed1-7060-4e9b-8864-c8c9b5c9f41d"/>
							<gml:surfaceMember xlink:href="#poly-dc550bc7-314c-491a-b060-06273e3365a5"/>
							<gml:surfaceMember xlink:href="#poly-3b0075f7-c376-41e7-b3db-3ff0d6fba3be"/>
							<gml:surfaceMember xlink:href="#poly-f5a4c9c7-0ce4-42e0-9509-d679b4b104a1"/>
							<gml:surfaceMember xlink:href="#poly-22be9bef-b612-4f9d-a6ff-1fc646e7f256"/>
							<gml:surfaceMember xlink:href="#poly-1eabae2f-682c-479b-a3bd-148af9e387d0"/>
							<gml:surfaceMember xlink:href="#poly-aee982f9-dbf9-4735-b888-8cc40a94a80e"/>
							<gml:surfaceMember xlink:href="#poly-b6f1bc4d-6640-4553-a487-c2dec8648407"/>
							<gml:surfaceMember xlink:href="#poly-6012d619-bf12-4c52-9961-b69e31ce78af"/>
							<gml:surfaceMember xlink:href="#poly-057a0898-d89d-424d-8c3e-681b2820d649"/>
							<gml:surfaceMember xlink:href="#poly-3f4c90a3-7761-4ebd-a085-17a3bdde6d51"/>
							<gml:surfaceMember xlink:href="#poly-1a675944-0633-478d-a127-cc6ab6fbe996"/>
							<gml:surfaceMember xlink:href="#poly-ed924cef-dfe7-4d79-844a-1a5991ed4d0b"/>
							<gml:surfaceMember xlink:href="#poly-00ecdc89-f257-43f9-bb30-3c8f832e59c8"/>
							<gml:surfaceMember xlink:href="#poly-74bd23b6-f307-4621-ba82-e06ab0739fe9"/>
							<gml:surfaceMember xlink:href="#poly-9f5fc636-fbba-4ed0-a564-e32a81fccbba"/>
							<gml:surfaceMember xlink:href="#poly-e64184ff-db6e-427d-a9a3-9d3bd5ae6af9"/>
							<gml:surfaceMember xlink:href="#poly-7787c978-5a86-4934-9630-9ecb30c514e6"/>
							<gml:surfaceMember xlink:href="#poly-6d0f78fa-fccb-4837-af7c-02fd5a00d41d"/>
							<gml:surfaceMember xlink:href="#poly-9eec9208-8e40-44f7-8104-60afce6b5a02"/>
							<gml:surfaceMember xlink:href="#poly-7fe860b3-2e76-43c5-86c2-0d228f59f51a"/>
							<gml:surfaceMember xlink:href="#poly-2b9ff37e-ad00-4349-a470-d36e83ccc6e8"/>
							<gml:surfaceMember xlink:href="#poly-cb81c6d1-2297-47fd-9f87-df3ab1b591ef"/>
							<gml:surfaceMember xlink:href="#poly-9295b713-709d-4423-8d8d-7fa4ce9bff10"/>
							<gml:surfaceMember xlink:href="#poly-f7ada190-b357-401b-9d82-e8803b1957f6"/>
							<gml:surfaceMember xlink:href="#poly-01e3c345-3cd0-4d64-9f16-bde213ee61b9"/>
							<gml:surfaceMember xlink:href="#poly-a1bef5c6-2778-4283-93cb-8d119aa24ac1"/>
							<gml:surfaceMember xlink:href="#poly-c9420384-23b5-4e23-bfb1-cbcf2935319a"/>
							<gml:surfaceMember xlink:href="#poly-0b7e8322-e0f8-47eb-a6e8-c9ffc05a7df9"/>
							<gml:surfaceMember xlink:href="#poly-ccaeb732-ceaa-4a18-8196-5d3843829922"/>
							<gml:surfaceMember xlink:href="#poly-548e6602-52cf-4e62-82d6-ee44a2037dc3"/>
							<gml:surfaceMember xlink:href="#poly-f4d4574f-990a-4e13-84b8-a9ef953e7142"/>
							<gml:surfaceMember xlink:href="#poly-f62a5214-a9d3-4a89-8731-4a1c8c208e10"/>
							<gml:surfaceMember xlink:href="#poly-73bbcfe6-48f1-4e82-ad44-fdd96859fd15"/>
							<gml:surfaceMember xlink:href="#poly-71412075-59be-4304-9377-ce5b65b85584"/>
							<gml:surfaceMember xlink:href="#poly-654b39c0-5318-4049-852f-64d3712f84a2"/>
							<gml:surfaceMember xlink:href="#poly-d6fa2cfd-15a6-4451-b632-006992bd729e"/>
							<gml:surfaceMember xlink:href="#poly-73da273f-ff5d-47ac-aa4b-365d5f78fda2"/>
							<gml:surfaceMember xlink:href="#poly-ce5902e4-508d-4093-96ba-aaff63416caf"/>
							<gml:surfaceMember xlink:href="#poly-ea76901c-c215-44a5-93dd-b164c8b7437d"/>
							<gml:surfaceMember xlink:href="#poly-4e3af14c-423d-4e15-9cb0-bb21e37b6c5e"/>
							<gml:surfaceMember xlink:href="#poly-9454d28b-2e6c-470b-9e33-a4741a7f6c20"/>
							<gml:surfaceMember xlink:href="#poly-978580fe-07c3-47a9-b092-34d36d1eb517"/>
							<gml:surfaceMember xlink:href="#poly-d4c130e4-2c57-4d1e-aafc-d7e239ceb8ef"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_0b140369-5113-4307-b960-a59e5262c056_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-533b8e53-618a-4bc3-8f9b-003ec9203e8d">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67157527897281 139.74055656720677 19.489 35.671569694789696 139.74055048708948 19.489 35.671581805390375 139.74053379297249 19.489 35.671587389574306 139.74053987308955 19.489 35.67157527897281 139.74055656720677 19.489</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c9617219-45a1-4441-a3e3-dfeaae36c3c9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671584131019706 139.74062751919956 19.489 35.67159251174849 139.74063657862501 19.489 35.671588919109 139.74064156471692 19.489 35.67158025025617 139.74063291434223 19.489 35.671584131019706 139.74062751919956 19.489</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2d02f3a4-5891-4d4c-8f42-451c988515ac">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67160044304796 139.74062385501674 19.489 35.67159506759726 139.74063131757077 19.489 35.67158689436228 139.7406224898806 19.489 35.671592269803924 139.7406150162803 19.489 35.67160044304796 139.74062385501674 19.489</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-460d1582-b0c4-4a1c-9bc5-2c62737e7b24">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67159163328039 139.74060779265358 19.489 35.6715974139047 139.7405997552154 19.489 35.67161162234776 139.74061510436405 19.489 35.67160584173096 139.74062315284894 19.489 35.67159163328039 139.74060779265358 19.489</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-acbc148e-c404-42a2-8a70-07d2568dfcee">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67162405608156 139.74059663139894 19.489 35.67161865362545 139.74060413817398 19.489 35.671603308499236 139.74058755314093 19.489 35.67160871095434 139.7405800463662 19.489 35.67162405608156 139.74059663139894 19.489</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-14d79a1b-f65e-4c61-a7ab-e7d5827746e5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67164066049328 139.74057468502298 19.489 35.671632124616124 139.74058654772017 19.489 35.671620036163915 139.74057349377733 19.489 35.67162857203129 139.7405616200341 19.489 35.67164066049328 139.74057468502298 19.489</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d6730735-b4d5-4e08-91c7-e035141b0422">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d6730735-b4d5-4e08-91c7-e035141b0422_0">
											<gml:posList>35.671592269803924 139.7406150162803 19.489 35.671592269803924 139.7406150162803 20.79 35.67160044304796 139.74062385501674 20.79 35.67160044304796 139.74062385501674 19.489 35.671592269803924 139.7406150162803 19.489</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-70227745-7b52-4abc-ab91-13b3762c4fa6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-70227745-7b52-4abc-ab91-13b3762c4fa6_0">
											<gml:posList>35.671587389574306 139.74053987308955 19.489 35.671581805390375 139.74053379297249 19.489 35.671581805390375 139.74053379297249 20.624 35.671587389574306 139.74053987308955 20.624 35.671587389574306 139.74053987308955 19.489</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-78e9b0fd-1b7a-4021-9585-35f801ef4609">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-78e9b0fd-1b7a-4021-9585-35f801ef4609_0">
											<gml:posList>35.671569694789696 139.74055048708948 19.489 35.671569694789696 139.74055048708948 20.624 35.671581805390375 139.74053379297249 20.624 35.671581805390375 139.74053379297249 19.489 35.671569694789696 139.74055048708948 19.489</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5291bb98-9696-4f72-9336-c9f78c2277f4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5291bb98-9696-4f72-9336-c9f78c2277f4_0">
											<gml:posList>35.671581805390375 139.74053379297249 20.624 35.671569694789696 139.74055048708948 20.624 35.67157527897281 139.74055656720677 20.624 35.671587389574306 139.74053987308955 20.624 35.671581805390375 139.74053379297249 20.624</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6d0f50f4-d20e-4bcb-bd2b-b9ec75ebb3cd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6d0f50f4-d20e-4bcb-bd2b-b9ec75ebb3cd_0">
											<gml:posList>35.67157527897281 139.74055656720677 19.489 35.671587389574306 139.74053987308955 19.489 35.671587389574306 139.74053987308955 20.624 35.67157527897281 139.74055656720677 20.624 35.67157527897281 139.74055656720677 19.489</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4180d7fe-0453-4d16-b31a-c87d914d9a2e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4180d7fe-0453-4d16-b31a-c87d914d9a2e_0">
											<gml:posList>35.671569694789696 139.74055048708948 19.489 35.67157527897281 139.74055656720677 19.489 35.67157527897281 139.74055656720677 20.624 35.671569694789696 139.74055048708948 20.624 35.671569694789696 139.74055048708948 19.489</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-55640bb4-89f6-466f-b7c9-1f67fb742bd8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-55640bb4-89f6-466f-b7c9-1f67fb742bd8_0">
											<gml:posList>35.67162857203129 139.7405616200341 19.489 35.671620036163915 139.74057349377733 19.489 35.671620036163915 139.74057349377733 21.22 35.67162857203129 139.7405616200341 21.22 35.67162857203129 139.7405616200341 19.489</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3f770b68-cc2a-458a-b071-f4f456676349">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3f770b68-cc2a-458a-b071-f4f456676349_0">
											<gml:posList>35.67164066049328 139.74057468502298 19.489 35.67162857203129 139.7405616200341 19.489 35.67162857203129 139.7405616200341 21.22 35.67164066049328 139.74057468502298 21.22 35.67164066049328 139.74057468502298 19.489</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-df9e1933-a0b4-4532-962c-657682fc1e9b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-df9e1933-a0b4-4532-962c-657682fc1e9b_0">
											<gml:posList>35.671620036163915 139.74057349377733 21.22 35.671632124616124 139.74058654772017 21.22 35.67164066049328 139.74057468502298 21.22 35.67162857203129 139.7405616200341 21.22 35.671620036163915 139.74057349377733 21.22</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-68c87db4-5b8b-47b9-a4aa-77fe32e92642">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-68c87db4-5b8b-47b9-a4aa-77fe32e92642_0">
											<gml:posList>35.671620036163915 139.74057349377733 19.489 35.671632124616124 139.74058654772017 19.489 35.671632124616124 139.74058654772017 21.22 35.671620036163915 139.74057349377733 21.22 35.671620036163915 139.74057349377733 19.489</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8c6d5bd9-0a2c-482e-8a58-aaf22daf8ff9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8c6d5bd9-0a2c-482e-8a58-aaf22daf8ff9_0">
											<gml:posList>35.671632124616124 139.74058654772017 19.489 35.67164066049328 139.74057468502298 19.489 35.67164066049328 139.74057468502298 21.22 35.671632124616124 139.74058654772017 21.22 35.671632124616124 139.74058654772017 19.489</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-42099541-1e76-47f3-aa1b-5eb241e90aa1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-42099541-1e76-47f3-aa1b-5eb241e90aa1_0">
											<gml:posList>35.67160871095434 139.7405800463662 19.489 35.671603308499236 139.74058755314093 19.489 35.671603308499236 139.74058755314093 20.79 35.67160871095434 139.7405800463662 20.79 35.67160871095434 139.7405800463662 19.489</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9229ac7d-e352-44cb-82b1-0b77c9e66980">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9229ac7d-e352-44cb-82b1-0b77c9e66980_0">
											<gml:posList>35.67162405608156 139.74059663139894 19.489 35.67160871095434 139.7405800463662 19.489 35.67160871095434 139.7405800463662 20.79 35.67162405608156 139.74059663139894 20.79 35.67162405608156 139.74059663139894 19.489</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e69355cf-8aef-4bda-a2b3-284f02d6faa7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e69355cf-8aef-4bda-a2b3-284f02d6faa7_0">
											<gml:posList>35.671603308499236 139.74058755314093 20.79 35.67161865362545 139.74060413817398 20.79 35.67162405608156 139.74059663139894 20.79 35.67160871095434 139.7405800463662 20.79 35.671603308499236 139.74058755314093 20.79</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-518cabe3-d0f2-4b1f-b8b4-2006c2627bad">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-518cabe3-d0f2-4b1f-b8b4-2006c2627bad_0">
											<gml:posList>35.671603308499236 139.74058755314093 19.489 35.67161865362545 139.74060413817398 19.489 35.67161865362545 139.74060413817398 20.79 35.671603308499236 139.74058755314093 20.79 35.671603308499236 139.74058755314093 19.489</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c8253c05-4b63-47fc-8e28-700d07b27295">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c8253c05-4b63-47fc-8e28-700d07b27295_0">
											<gml:posList>35.67161865362545 139.74060413817398 19.489 35.67162405608156 139.74059663139894 19.489 35.67162405608156 139.74059663139894 20.79 35.67161865362545 139.74060413817398 20.79 35.67161865362545 139.74060413817398 19.489</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5070172f-ff7a-49cb-923d-2555745cb390">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5070172f-ff7a-49cb-923d-2555745cb390_0">
											<gml:posList>35.6715974139047 139.7405997552154 19.489 35.67159163328039 139.74060779265358 19.489 35.67159163328039 139.74060779265358 20.79 35.6715974139047 139.7405997552154 20.79 35.6715974139047 139.7405997552154 19.489</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-39a3e48a-03dc-4e04-826e-92ec5c985edf">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-39a3e48a-03dc-4e04-826e-92ec5c985edf_0">
											<gml:posList>35.67161162234776 139.74061510436405 19.489 35.6715974139047 139.7405997552154 19.489 35.6715974139047 139.7405997552154 20.79 35.67161162234776 139.74061510436405 20.79 35.67161162234776 139.74061510436405 19.489</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-253260d8-26c2-4899-9174-ca2048f55438">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-253260d8-26c2-4899-9174-ca2048f55438_0">
											<gml:posList>35.67161162234776 139.74061510436405 20.79 35.6715974139047 139.7405997552154 20.79 35.67159163328039 139.74060779265358 20.79 35.67160584173096 139.74062315284894 20.79 35.67161162234776 139.74061510436405 20.79</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-48bcbae6-c117-484b-bf0a-245d65fb23fb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-48bcbae6-c117-484b-bf0a-245d65fb23fb_0">
											<gml:posList>35.67160584173096 139.74062315284894 19.489 35.67160584173096 139.74062315284894 20.79 35.67159163328039 139.74060779265358 20.79 35.67159163328039 139.74060779265358 19.489 35.67160584173096 139.74062315284894 19.489</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7be525f5-c578-4eb1-ae95-bbe05d1834aa">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7be525f5-c578-4eb1-ae95-bbe05d1834aa_0">
											<gml:posList>35.671592269803924 139.7406150162803 19.489 35.67158689436228 139.7406224898806 19.489 35.67158689436228 139.7406224898806 20.79 35.671592269803924 139.7406150162803 20.79 35.671592269803924 139.7406150162803 19.489</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c024e27d-90ee-4466-8d1a-8d8927c85aa6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c024e27d-90ee-4466-8d1a-8d8927c85aa6_0">
											<gml:posList>35.67161162234776 139.74061510436405 19.489 35.67161162234776 139.74061510436405 20.79 35.67160584173096 139.74062315284894 20.79 35.67160584173096 139.74062315284894 19.489 35.67161162234776 139.74061510436405 19.489</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b0742bdc-d0a3-4826-a986-2f6d26ee3354">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b0742bdc-d0a3-4826-a986-2f6d26ee3354_0">
											<gml:posList>35.67158689436228 139.7406224898806 20.79 35.67159506759726 139.74063131757077 20.79 35.67160044304796 139.74062385501674 20.79 35.671592269803924 139.7406150162803 20.79 35.67158689436228 139.7406224898806 20.79</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-de158db3-187c-4fc5-9f48-df3f14377251">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-de158db3-187c-4fc5-9f48-df3f14377251_0">
											<gml:posList>35.67159506759726 139.74063131757077 19.489 35.67159506759726 139.74063131757077 20.79 35.67158689436228 139.7406224898806 20.79 35.67158689436228 139.7406224898806 19.489 35.67159506759726 139.74063131757077 19.489</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-949b2d22-eef9-4b17-9ced-03a10c7cd29e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-949b2d22-eef9-4b17-9ced-03a10c7cd29e_0">
											<gml:posList>35.67159506759726 139.74063131757077 19.489 35.67160044304796 139.74062385501674 19.489 35.67160044304796 139.74062385501674 20.79 35.67159506759726 139.74063131757077 20.79 35.67159506759726 139.74063131757077 19.489</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cd92d7da-0275-4e92-9279-c6b8250a49a0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cd92d7da-0275-4e92-9279-c6b8250a49a0_0">
											<gml:posList>35.671584131019706 139.74062751919956 19.489 35.67158025025617 139.74063291434223 19.489 35.67158025025617 139.74063291434223 20.79 35.671584131019706 139.74062751919956 20.79 35.671584131019706 139.74062751919956 19.489</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-325f7621-8a70-4fb0-97fd-15fc7a7c2354">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-325f7621-8a70-4fb0-97fd-15fc7a7c2354_0">
											<gml:posList>35.67159251174849 139.74063657862501 19.489 35.671584131019706 139.74062751919956 19.489 35.671584131019706 139.74062751919956 20.79 35.67159251174849 139.74063657862501 20.79 35.67159251174849 139.74063657862501 19.489</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-17b8c6aa-8a5f-413e-88c7-a3f60198f514">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-17b8c6aa-8a5f-413e-88c7-a3f60198f514_0">
											<gml:posList>35.671588919109 139.74064156471692 20.79 35.67159251174849 139.74063657862501 20.79 35.671584131019706 139.74062751919956 20.79 35.67158025025617 139.74063291434223 20.79 35.671588919109 139.74064156471692 20.79</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ff2999de-1c06-468a-86e9-6bf28bde4ab8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ff2999de-1c06-468a-86e9-6bf28bde4ab8_0">
											<gml:posList>35.671588919109 139.74064156471692 20.79 35.67158025025617 139.74063291434223 20.79 35.67158025025617 139.74063291434223 19.489 35.671588919109 139.74064156471692 19.489 35.671588919109 139.74064156471692 20.79</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6fb3fc55-2f5c-4b5e-8321-d93c1be13024">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6fb3fc55-2f5c-4b5e-8321-d93c1be13024_0">
											<gml:posList>35.671588919109 139.74064156471692 19.489 35.67159251174849 139.74063657862501 19.489 35.67159251174849 139.74063657862501 20.79 35.671588919109 139.74064156471692 20.79 35.671588919109 139.74064156471692 19.489</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_0b140369-5113-4307-b960-a59e5262c056_BuildingInstallation_1060">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a6ea4d9a-e347-4fb2-98e5-a5f4dd0d075a">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67159866027116 139.74049768478528 19.489 35.67163230618654 139.74052973571054 19.489 35.671626292316894 139.74053920946324 19.489 35.67159265542624 139.7405071695724 19.489 35.67159866027116 139.74049768478528 19.489</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-694da724-4b86-4fcd-8a02-97514c63614e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-694da724-4b86-4fcd-8a02-97514c63614e_0">
											<gml:posList>35.67159265542624 139.7405071695724 19.489 35.67159265542624 139.7405071695724 20.176 35.67159866027116 139.74049768478528 20.176 35.67159866027116 139.74049768478528 19.489 35.67159265542624 139.7405071695724 19.489</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-953068d9-2092-41a1-8a25-c968054c555e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-953068d9-2092-41a1-8a25-c968054c555e_0">
											<gml:posList>35.67163230618654 139.74052973571054 19.489 35.67159866027116 139.74049768478528 19.489 35.67159866027116 139.74049768478528 20.176 35.67163230618654 139.74052973571054 20.176 35.67163230618654 139.74052973571054 19.489</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fc171875-5802-4106-af0d-5d40c11f6789">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fc171875-5802-4106-af0d-5d40c11f6789_0">
											<gml:posList>35.67159866027116 139.74049768478528 20.176 35.67159265542624 139.7405071695724 20.176 35.671626292316894 139.74053920946324 20.176 35.67163230618654 139.74052973571054 20.176 35.67159866027116 139.74049768478528 20.176</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0168578a-842f-4b33-98a7-aca143e706ee">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0168578a-842f-4b33-98a7-aca143e706ee_0">
											<gml:posList>35.671626292316894 139.74053920946324 19.489 35.671626292316894 139.74053920946324 20.176 35.67159265542624 139.7405071695724 20.176 35.67159265542624 139.7405071695724 19.489 35.671626292316894 139.74053920946324 19.489</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ebaa1e02-0c17-431e-adcb-5dd28b9e42c7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ebaa1e02-0c17-431e-adcb-5dd28b9e42c7_0">
											<gml:posList>35.67163230618654 139.74052973571054 20.176 35.671626292316894 139.74053920946324 20.176 35.671626292316894 139.74053920946324 19.489 35.67163230618654 139.74052973571054 19.489 35.67163230618654 139.74052973571054 20.176</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_0b140369-5113-4307-b960-a59e5262c056_BuildingInstallation_1041">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9fdae503-de5a-4ef3-8d78-640519133f31">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67156446688232 139.74056225757965 19.489 35.6715830595724 139.74058224114165 19.489 35.6715687881816 139.74060219644574 19.489 35.671550186481056 139.7405822128931 19.489 35.67156446688232 139.74056225757965 19.489</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e7b6eaba-ce14-47a0-9d47-de9b9a4995ea">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e7b6eaba-ce14-47a0-9d47-de9b9a4995ea_0">
											<gml:posList>35.671550186481056 139.7405822128931 19.489 35.671550186481056 139.7405822128931 21.692 35.67156446688232 139.74056225757965 21.692 35.67156446688232 139.74056225757965 19.489 35.671550186481056 139.7405822128931 19.489</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-922d8679-bcc2-4aea-b916-fa5c384ebc89">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-922d8679-bcc2-4aea-b916-fa5c384ebc89_0">
											<gml:posList>35.67156446688232 139.74056225757965 21.692 35.6715830595724 139.74058224114165 21.692 35.6715830595724 139.74058224114165 19.489 35.67156446688232 139.74056225757965 19.489 35.67156446688232 139.74056225757965 21.692</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-16404162-beb2-4d9e-b985-be5aa0437938">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-16404162-beb2-4d9e-b985-be5aa0437938_0">
											<gml:posList>35.6715687881816 139.74060219644574 21.692 35.6715830595724 139.74058224114165 21.692 35.67156446688232 139.74056225757965 21.692 35.671550186481056 139.7405822128931 21.692 35.6715687881816 139.74060219644574 21.692</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9ccee180-0779-429e-9d82-8f1d34768d26">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9ccee180-0779-429e-9d82-8f1d34768d26_0">
											<gml:posList>35.6715687881816 139.74060219644574 21.692 35.671550186481056 139.7405822128931 21.692 35.671550186481056 139.7405822128931 19.489 35.6715687881816 139.74060219644574 19.489 35.6715687881816 139.74060219644574 21.692</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-087a5198-89d0-439b-af6a-a48fc62d8f56">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-087a5198-89d0-439b-af6a-a48fc62d8f56_0">
											<gml:posList>35.6715830595724 139.74058224114165 19.489 35.6715830595724 139.74058224114165 21.692 35.6715687881816 139.74060219644574 21.692 35.6715687881816 139.74060219644574 19.489 35.6715830595724 139.74058224114165 19.489</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-443715db-a627-4809-bee8-4fcd1ba5c35b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-443715db-a627-4809-bee8-4fcd1ba5c35b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-443715db-a627-4809-bee8-4fcd1ba5c35b">
											<gml:posList>35.671587497686104 139.74037619807356 7.98 35.67173462480211 139.74052294521994 7.98 35.671626405269535 139.74068589489187 7.98 35.67152934296867 139.74058901950687 7.98 35.67159335629404 139.7404926206171 7.98 35.67154329163533 139.74044274877443 7.98 35.671587497686104 139.74037619807356 7.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-bd4bddc3-04bb-45a1-8a78-a1501342089d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bd4bddc3-04bb-45a1-8a78-a1501342089d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bd4bddc3-04bb-45a1-8a78-a1501342089d">
											<gml:posList>35.671588325532554 139.7403860394792 28.51 35.671636126083015 139.74043372674416 28.51 35.67164415654121 139.74043272326003 28.51 35.671587497686104 139.74037619807356 28.51 35.671588325532554 139.7403860394792 28.51</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-7f3495f1-514f-4ea1-a3ed-1c4efa8b1b2b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7f3495f1-514f-4ea1-a3ed-1c4efa8b1b2b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7f3495f1-514f-4ea1-a3ed-1c4efa8b1b2b">
											<gml:posList>35.671587497686104 139.74037619807356 28.51 35.67154329163533 139.74044274877443 28.51 35.67155132209373 139.74044174529237 28.51 35.671588325532554 139.7403860394792 28.51 35.671587497686104 139.74037619807356 28.51</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ef2c12e2-4512-497d-86e5-4523e27b3e98">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ef2c12e2-4512-497d-86e5-4523e27b3e98">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ef2c12e2-4512-497d-86e5-4523e27b3e98">
											<gml:posList>35.67163493764397 139.74043550659684 27.129 35.67160472530888 139.740402645341 27.129 35.67158952631886 139.74042361802856 27.129 35.67162044232348 139.7404572627675 27.129 35.67163493764397 139.74043550659684 27.129</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-2e7c3d41-da22-46eb-9799-04fad5318f1b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2e7c3d41-da22-46eb-9799-04fad5318f1b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2e7c3d41-da22-46eb-9799-04fad5318f1b">
											<gml:posList>35.67159911347243 139.7404892558364 22.937 35.67162044232348 139.7404572627675 22.937 35.67158952631886 139.74042361802856 22.937 35.67160472530888 139.740402645341 22.937 35.67163493764397 139.74043550659684 22.937 35.671636126083015 139.74043372674416 22.937 35.671588325532554 139.7403860394792 22.937 35.67155132209373 139.74044174529237 22.937 35.671596957600364 139.7404871926511 22.937 35.67159911347243 139.7404892558364 22.937</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-57b2d9fa-5292-4a7e-96e4-dc92061afa0c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-57b2d9fa-5292-4a7e-96e4-dc92061afa0c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-57b2d9fa-5292-4a7e-96e4-dc92061afa0c">
											<gml:posList>35.67170734631978 139.74049574731774 22.937 35.67164415654121 139.74043272326003 22.937 35.6716413114951 139.7404369904799 22.937 35.671700865957064 139.74049640656176 22.937 35.67170734631978 139.74049574731774 22.937</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-dca86ec5-bc50-44c5-a644-29d16b62bfa5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-dca86ec5-bc50-44c5-a644-29d16b62bfa5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-dca86ec5-bc50-44c5-a644-29d16b62bfa5">
											<gml:posList>35.67160001331721 139.74049896460414 28.51 35.67164415654121 139.74043272326003 28.51 35.671636126083015 139.74043372674416 28.51 35.67159911347243 139.7404892558364 28.51 35.671596957600364 139.7404871926511 28.51 35.67160001331721 139.74049896460414 28.51</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-5e161655-3eda-4042-bdb2-747143390ede">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5e161655-3eda-4042-bdb2-747143390ede">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5e161655-3eda-4042-bdb2-747143390ede">
											<gml:posList>35.67154329163533 139.74044274877443 28.51 35.67160001331721 139.74049896460414 28.51 35.671596957600364 139.7404871926511 28.51 35.67155132209373 139.74044174529237 28.51 35.67154329163533 139.74044274877443 28.51</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-93563c2b-69b6-47fd-96d3-8451025420ea">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-93563c2b-69b6-47fd-96d3-8451025420ea">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-93563c2b-69b6-47fd-96d3-8451025420ea">
											<gml:posList>35.6716413114951 139.7404369904799 22.491 35.671602939395356 139.7404945757841 22.491 35.671661752235835 139.7405507892722 22.491 35.671700865957064 139.74049640656176 22.491 35.6716413114951 139.7404369904799 22.491</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-67c9075d-9846-4e60-9b19-15ac36fa0654">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-67c9075d-9846-4e60-9b19-15ac36fa0654">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-67c9075d-9846-4e60-9b19-15ac36fa0654">
											<gml:posList>35.6717171931824 139.7405124602312 19.489 35.67172349330483 139.74051184538277 19.489 35.67170734631978 139.74049574731774 19.489 35.67170457305759 139.74049959469085 19.489 35.6717171931824 139.7405124602312 19.489</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-8416ea9f-8fad-4f49-a2d2-de3f35663c84">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8416ea9f-8fad-4f49-a2d2-de3f35663c84">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8416ea9f-8fad-4f49-a2d2-de3f35663c84">
											<gml:posList>35.67173462480211 139.74052294521994 16.05 35.67172349330483 139.74051184538277 16.05 35.671720512888356 139.74051590287837 16.05 35.67172804541607 139.7405237702733 16.05 35.67173462480211 139.74052294521994 16.05</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-da176d1f-4ea2-4d9e-91ff-2bf28a2c66fb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-da176d1f-4ea2-4d9e-91ff-2bf28a2c66fb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-da176d1f-4ea2-4d9e-91ff-2bf28a2c66fb">
											<gml:posList>35.671661752235835 139.7405507892722 22.937 35.671602939395356 139.7404945757841 22.937 35.67160001331721 139.74049896460414 22.937 35.67165859148401 139.74055476964685 22.937 35.671661752235835 139.7405507892722 22.937</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-2c69678a-9c37-4154-af42-c60a79acc096">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2c69678a-9c37-4154-af42-c60a79acc096">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2c69678a-9c37-4154-af42-c60a79acc096">
											<gml:posList>35.67166233492728 139.74055833331371 22.937 35.67170734631978 139.74049574731774 22.937 35.671700865957064 139.74049640656176 22.937 35.671661752235835 139.7405507892722 22.937 35.67166233492728 139.74055833331371 22.937</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e5c8ec3e-a6c0-46d7-a02b-c8e7728e4ab6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e5c8ec3e-a6c0-46d7-a02b-c8e7728e4ab6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e5c8ec3e-a6c0-46d7-a02b-c8e7728e4ab6">
											<gml:posList>35.67159335629404 139.7404926206171 22.937 35.67152934296867 139.74058901950687 22.937 35.67153548973932 139.7405882501935 22.937 35.671596729912594 139.74049584226717 22.937 35.67159335629404 139.7404926206171 22.937</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-6b9c9ee7-f7b5-4319-ac9d-b074048220f3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6b9c9ee7-f7b5-4319-ac9d-b074048220f3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6b9c9ee7-f7b5-4319-ac9d-b074048220f3">
											<gml:posList>35.671596729912594 139.74049584226717 19.489 35.67153548973932 139.7405882501935 19.489 35.67159260856096 139.74064524995788 19.489 35.67165859148401 139.74055476964685 19.489 35.671596729912594 139.74049584226717 19.489</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-810b8ed1-7060-4e9b-8864-c8c9b5c9f41d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-810b8ed1-7060-4e9b-8864-c8c9b5c9f41d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-810b8ed1-7060-4e9b-8864-c8c9b5c9f41d">
											<gml:posList>35.6717171931824 139.7405124602312 19.28 35.67170457305759 139.74049959469085 19.28 35.67166233492728 139.74055833331371 19.28 35.67159698358275 139.7406496192851 19.28 35.6716083315754 139.7406609508487 19.28 35.6717171931824 139.7405124602312 19.28</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-dc550bc7-314c-491a-b060-06273e3365a5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-dc550bc7-314c-491a-b060-06273e3365a5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-dc550bc7-314c-491a-b060-06273e3365a5">
											<gml:posList>35.6717171931824 139.7405124602312 19.489 35.6716083315754 139.7406609508487 19.489 35.67160877890961 139.74066830725317 19.489 35.67172349330483 139.74051184538277 19.489 35.6717171931824 139.7405124602312 19.489</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-3b0075f7-c376-41e7-b3db-3ff0d6fba3be">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3b0075f7-c376-41e7-b3db-3ff0d6fba3be">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3b0075f7-c376-41e7-b3db-3ff0d6fba3be">
											<gml:posList>35.67172804541607 139.7405237702733 15.721 35.671720512888356 139.74051590287837 15.721 35.67161206546625 139.7406638186043 15.721 35.67162574105459 139.7406778207183 15.721 35.67172804541607 139.7405237702733 15.721</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f5a4c9c7-0ce4-42e0-9509-d679b4b104a1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f5a4c9c7-0ce4-42e0-9509-d679b4b104a1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f5a4c9c7-0ce4-42e0-9509-d679b4b104a1">
											<gml:posList>35.67165859148401 139.74055476964685 22.937 35.67159260856096 139.74064524995788 22.937 35.67159421956737 139.74065377593683 22.937 35.67159698358275 139.7406496192851 22.937 35.67166233492728 139.74055833331371 22.937 35.671661752235835 139.7405507892722 22.937 35.67165859148401 139.74055476964685 22.937</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-22be9bef-b612-4f9d-a6ff-1fc646e7f256">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-22be9bef-b612-4f9d-a6ff-1fc646e7f256">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-22be9bef-b612-4f9d-a6ff-1fc646e7f256">
											<gml:posList>35.671626405269535 139.74068589489187 16.05 35.67173462480211 139.74052294521994 16.05 35.67172804541607 139.7405237702733 16.05 35.67162574105459 139.7406778207183 16.05 35.671626405269535 139.74068589489187 16.05</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-1eabae2f-682c-479b-a3bd-148af9e387d0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1eabae2f-682c-479b-a3bd-148af9e387d0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1eabae2f-682c-479b-a3bd-148af9e387d0">
											<gml:posList>35.67152934296867 139.74058901950687 22.937 35.67159421956737 139.74065377593683 22.937 35.67159260856096 139.74064524995788 22.937 35.67153548973932 139.7405882501935 22.937 35.67152934296867 139.74058901950687 22.937</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-aee982f9-dbf9-4735-b888-8cc40a94a80e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-aee982f9-dbf9-4735-b888-8cc40a94a80e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-aee982f9-dbf9-4735-b888-8cc40a94a80e">
											<gml:posList>35.6716083315754 139.7406609508487 19.489 35.67159698358275 139.7406496192851 19.489 35.67159421956737 139.74065377593683 19.489 35.67160877890961 139.74066830725317 19.489 35.6716083315754 139.7406609508487 19.489</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b6f1bc4d-6640-4553-a487-c2dec8648407">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b6f1bc4d-6640-4553-a487-c2dec8648407">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b6f1bc4d-6640-4553-a487-c2dec8648407">
											<gml:posList>35.671626405269535 139.74068589489187 16.05 35.67162574105459 139.7406778207183 16.05 35.67161206546625 139.7406638186043 16.05 35.67160877890961 139.74066830725317 16.05 35.671626405269535 139.74068589489187 16.05</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6012d619-bf12-4c52-9961-b69e31ce78af">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6012d619-bf12-4c52-9961-b69e31ce78af">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6012d619-bf12-4c52-9961-b69e31ce78af">
											<gml:posList>35.67160472530888 139.740402645341 22.937 35.67158952631886 139.74042361802856 22.937 35.67158952631886 139.74042361802856 27.129 35.67160472530888 139.740402645341 27.129 35.67160472530888 139.740402645341 22.937</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-057a0898-d89d-424d-8c3e-681b2820d649">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-057a0898-d89d-424d-8c3e-681b2820d649">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-057a0898-d89d-424d-8c3e-681b2820d649">
											<gml:posList>35.67160472530888 139.740402645341 22.937 35.67160472530888 139.740402645341 27.129 35.67163493764397 139.74043550659684 27.129 35.67163493764397 139.74043550659684 22.937 35.67160472530888 139.740402645341 22.937</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3f4c90a3-7761-4ebd-a085-17a3bdde6d51">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3f4c90a3-7761-4ebd-a085-17a3bdde6d51">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3f4c90a3-7761-4ebd-a085-17a3bdde6d51">
											<gml:posList>35.67162044232348 139.7404572627675 22.937 35.67162044232348 139.7404572627675 27.129 35.67158952631886 139.74042361802856 27.129 35.67158952631886 139.74042361802856 22.937 35.67162044232348 139.7404572627675 22.937</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1a675944-0633-478d-a127-cc6ab6fbe996">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1a675944-0633-478d-a127-cc6ab6fbe996">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1a675944-0633-478d-a127-cc6ab6fbe996">
											<gml:posList>35.67155132209373 139.74044174529237 28.51 35.671596957600364 139.7404871926511 28.51 35.671596957600364 139.7404871926511 22.937 35.67155132209373 139.74044174529237 22.937 35.67155132209373 139.74044174529237 28.51</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ed924cef-dfe7-4d79-844a-1a5991ed4d0b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ed924cef-dfe7-4d79-844a-1a5991ed4d0b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ed924cef-dfe7-4d79-844a-1a5991ed4d0b">
											<gml:posList>35.671596957600364 139.7404871926511 28.51 35.67159911347243 139.7404892558364 28.51 35.67159911347243 139.7404892558364 22.937 35.671596957600364 139.7404871926511 22.937 35.671596957600364 139.7404871926511 28.51</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-00ecdc89-f257-43f9-bb30-3c8f832e59c8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-00ecdc89-f257-43f9-bb30-3c8f832e59c8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-00ecdc89-f257-43f9-bb30-3c8f832e59c8">
											<gml:posList>35.671661752235835 139.7405507892722 22.937 35.671661752235835 139.7405507892722 22.491 35.671602939395356 139.7404945757841 22.491 35.671602939395356 139.7404945757841 22.937 35.671661752235835 139.7405507892722 22.937</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-74bd23b6-f307-4621-ba82-e06ab0739fe9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-74bd23b6-f307-4621-ba82-e06ab0739fe9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-74bd23b6-f307-4621-ba82-e06ab0739fe9">
											<gml:posList>35.67153548973932 139.7405882501935 19.489 35.671596729912594 139.74049584226717 19.489 35.671596729912594 139.74049584226717 22.937 35.67153548973932 139.7405882501935 22.937 35.67153548973932 139.7405882501935 19.489</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9f5fc636-fbba-4ed0-a564-e32a81fccbba">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9f5fc636-fbba-4ed0-a564-e32a81fccbba">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9f5fc636-fbba-4ed0-a564-e32a81fccbba">
											<gml:posList>35.67159335629404 139.7404926206171 22.937 35.67159335629404 139.7404926206171 7.98 35.67152934296867 139.74058901950687 7.98 35.67152934296867 139.74058901950687 22.937 35.67159335629404 139.7404926206171 22.937</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e64184ff-db6e-427d-a9a3-9d3bd5ae6af9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e64184ff-db6e-427d-a9a3-9d3bd5ae6af9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e64184ff-db6e-427d-a9a3-9d3bd5ae6af9">
											<gml:posList>35.67153548973932 139.7405882501935 22.937 35.67159260856096 139.74064524995788 22.937 35.67159260856096 139.74064524995788 19.489 35.67153548973932 139.7405882501935 19.489 35.67153548973932 139.7405882501935 22.937</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7787c978-5a86-4934-9630-9ecb30c514e6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7787c978-5a86-4934-9630-9ecb30c514e6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7787c978-5a86-4934-9630-9ecb30c514e6">
											<gml:posList>35.67154329163533 139.74044274877443 7.98 35.67154329163533 139.74044274877443 28.51 35.671587497686104 139.74037619807356 28.51 35.671587497686104 139.74037619807356 7.98 35.67154329163533 139.74044274877443 7.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6d0f78fa-fccb-4837-af7c-02fd5a00d41d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6d0f78fa-fccb-4837-af7c-02fd5a00d41d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6d0f78fa-fccb-4837-af7c-02fd5a00d41d">
											<gml:posList>35.67154329163533 139.74044274877443 28.51 35.67159335629404 139.7404926206171 7.98 35.67159335629404 139.7404926206171 22.937 35.67154329163533 139.74044274877443 28.51</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9eec9208-8e40-44f7-8104-60afce6b5a02">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9eec9208-8e40-44f7-8104-60afce6b5a02">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9eec9208-8e40-44f7-8104-60afce6b5a02">
											<gml:posList>35.67154329163533 139.74044274877443 28.51 35.67154329163533 139.74044274877443 7.98 35.67159335629404 139.7404926206171 7.98 35.67154329163533 139.74044274877443 28.51</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7fe860b3-2e76-43c5-86c2-0d228f59f51a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7fe860b3-2e76-43c5-86c2-0d228f59f51a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7fe860b3-2e76-43c5-86c2-0d228f59f51a">
											<gml:posList>35.671588325532554 139.7403860394792 28.51 35.67155132209373 139.74044174529237 28.51 35.67155132209373 139.74044174529237 22.937 35.671588325532554 139.7403860394792 22.937 35.671588325532554 139.7403860394792 28.51</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2b9ff37e-ad00-4349-a470-d36e83ccc6e8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2b9ff37e-ad00-4349-a470-d36e83ccc6e8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2b9ff37e-ad00-4349-a470-d36e83ccc6e8">
											<gml:posList>35.67154329163533 139.74044274877443 28.51 35.67159335629404 139.7404926206171 22.937 35.671596729912594 139.74049584226717 22.937 35.67154329163533 139.74044274877443 28.51</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-cb81c6d1-2297-47fd-9f87-df3ab1b591ef">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cb81c6d1-2297-47fd-9f87-df3ab1b591ef">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cb81c6d1-2297-47fd-9f87-df3ab1b591ef">
											<gml:posList>35.67154329163533 139.74044274877443 28.51 35.67160001331721 139.74049896460414 22.937 35.67160001331721 139.74049896460414 28.51 35.67154329163533 139.74044274877443 28.51</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9295b713-709d-4423-8d8d-7fa4ce9bff10">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9295b713-709d-4423-8d8d-7fa4ce9bff10">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9295b713-709d-4423-8d8d-7fa4ce9bff10">
											<gml:posList>35.67154329163533 139.74044274877443 28.51 35.671596729912594 139.74049584226717 22.937 35.67160001331721 139.74049896460414 22.937 35.67154329163533 139.74044274877443 28.51</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f7ada190-b357-401b-9d82-e8803b1957f6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f7ada190-b357-401b-9d82-e8803b1957f6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f7ada190-b357-401b-9d82-e8803b1957f6">
											<gml:posList>35.67160877890961 139.74066830725317 16.05 35.67160877890961 139.74066830725317 19.489 35.67159421956737 139.74065377593683 19.489 35.67159421956737 139.74065377593683 22.937 35.67152934296867 139.74058901950687 22.937 35.67152934296867 139.74058901950687 7.98 35.671626405269535 139.74068589489187 7.98 35.671626405269535 139.74068589489187 16.05 35.67160877890961 139.74066830725317 16.05</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-01e3c345-3cd0-4d64-9f16-bde213ee61b9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-01e3c345-3cd0-4d64-9f16-bde213ee61b9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-01e3c345-3cd0-4d64-9f16-bde213ee61b9">
											<gml:posList>35.67159698358275 139.7406496192851 22.937 35.67159421956737 139.74065377593683 22.937 35.67159421956737 139.74065377593683 19.489 35.67159698358275 139.7406496192851 19.489 35.67159698358275 139.7406496192851 22.937</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a1bef5c6-2778-4283-93cb-8d119aa24ac1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a1bef5c6-2778-4283-93cb-8d119aa24ac1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a1bef5c6-2778-4283-93cb-8d119aa24ac1">
											<gml:posList>35.671636126083015 139.74043372674416 28.51 35.671588325532554 139.7403860394792 28.51 35.671588325532554 139.7403860394792 22.937 35.671636126083015 139.74043372674416 22.937 35.671636126083015 139.74043372674416 28.51</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c9420384-23b5-4e23-bfb1-cbcf2935319a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c9420384-23b5-4e23-bfb1-cbcf2935319a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c9420384-23b5-4e23-bfb1-cbcf2935319a">
											<gml:posList>35.67173462480211 139.74052294521994 7.98 35.671587497686104 139.74037619807356 7.98 35.671587497686104 139.74037619807356 28.51 35.67164415654121 139.74043272326003 28.51 35.67164415654121 139.74043272326003 22.937 35.67170734631978 139.74049574731774 22.937 35.67170734631978 139.74049574731774 19.489 35.67172349330483 139.74051184538277 19.489 35.67172349330483 139.74051184538277 16.05 35.67173462480211 139.74052294521994 16.05 35.67173462480211 139.74052294521994 7.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0b7e8322-e0f8-47eb-a6e8-c9ffc05a7df9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0b7e8322-e0f8-47eb-a6e8-c9ffc05a7df9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0b7e8322-e0f8-47eb-a6e8-c9ffc05a7df9">
											<gml:posList>35.67162044232348 139.7404572627675 27.129 35.67162044232348 139.7404572627675 22.937 35.67159911347243 139.7404892558364 22.937 35.67159911347243 139.7404892558364 28.51 35.671636126083015 139.74043372674416 28.51 35.671636126083015 139.74043372674416 22.937 35.67163493764397 139.74043550659684 22.937 35.67163493764397 139.74043550659684 27.129 35.67162044232348 139.7404572627675 27.129</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ccaeb732-ceaa-4a18-8196-5d3843829922">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ccaeb732-ceaa-4a18-8196-5d3843829922">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ccaeb732-ceaa-4a18-8196-5d3843829922">
											<gml:posList>35.67164415654121 139.74043272326003 28.51 35.67160001331721 139.74049896460414 28.51 35.67160001331721 139.74049896460414 22.937 35.671602939395356 139.7404945757841 22.937 35.671602939395356 139.7404945757841 22.491 35.6716413114951 139.7404369904799 22.491 35.6716413114951 139.7404369904799 22.937 35.67164415654121 139.74043272326003 22.937 35.67164415654121 139.74043272326003 28.51</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-548e6602-52cf-4e62-82d6-ee44a2037dc3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-548e6602-52cf-4e62-82d6-ee44a2037dc3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-548e6602-52cf-4e62-82d6-ee44a2037dc3">
											<gml:posList>35.6716413114951 139.7404369904799 22.491 35.671700865957064 139.74049640656176 22.491 35.671700865957064 139.74049640656176 22.937 35.6716413114951 139.7404369904799 22.937 35.6716413114951 139.7404369904799 22.491</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f4d4574f-990a-4e13-84b8-a9ef953e7142">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f4d4574f-990a-4e13-84b8-a9ef953e7142">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f4d4574f-990a-4e13-84b8-a9ef953e7142">
											<gml:posList>35.67170457305759 139.74049959469085 19.28 35.6717171931824 139.7405124602312 19.28 35.6717171931824 139.7405124602312 19.489 35.67170457305759 139.74049959469085 19.489 35.67170457305759 139.74049959469085 19.28</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f62a5214-a9d3-4a89-8731-4a1c8c208e10">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f62a5214-a9d3-4a89-8731-4a1c8c208e10">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f62a5214-a9d3-4a89-8731-4a1c8c208e10">
											<gml:posList>35.671720512888356 139.74051590287837 15.721 35.67172804541607 139.7405237702733 15.721 35.67172804541607 139.7405237702733 16.05 35.671720512888356 139.74051590287837 16.05 35.671720512888356 139.74051590287837 15.721</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-73bbcfe6-48f1-4e82-ad44-fdd96859fd15">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-73bbcfe6-48f1-4e82-ad44-fdd96859fd15">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-73bbcfe6-48f1-4e82-ad44-fdd96859fd15">
											<gml:posList>35.671700865957064 139.74049640656176 22.491 35.671661752235835 139.7405507892722 22.491 35.671661752235835 139.7405507892722 22.937 35.671700865957064 139.74049640656176 22.937 35.671700865957064 139.74049640656176 22.491</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-71412075-59be-4304-9377-ce5b65b85584">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-71412075-59be-4304-9377-ce5b65b85584">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-71412075-59be-4304-9377-ce5b65b85584">
											<gml:posList>35.67165859148401 139.74055476964685 19.489 35.67165859148401 139.74055476964685 22.937 35.67160001331721 139.74049896460414 22.937 35.671596729912594 139.74049584226717 22.937 35.671596729912594 139.74049584226717 19.489 35.67165859148401 139.74055476964685 19.489</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-654b39c0-5318-4049-852f-64d3712f84a2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-654b39c0-5318-4049-852f-64d3712f84a2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-654b39c0-5318-4049-852f-64d3712f84a2">
											<gml:posList>35.67166233492728 139.74055833331371 19.28 35.67170457305759 139.74049959469085 19.28 35.67170457305759 139.74049959469085 19.489 35.67170734631978 139.74049574731774 19.489 35.67170734631978 139.74049574731774 22.937 35.67166233492728 139.74055833331371 22.937 35.67166233492728 139.74055833331371 19.28</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d6fa2cfd-15a6-4451-b632-006992bd729e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d6fa2cfd-15a6-4451-b632-006992bd729e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d6fa2cfd-15a6-4451-b632-006992bd729e">
											<gml:posList>35.6717171931824 139.7405124602312 19.28 35.6716083315754 139.7406609508487 19.28 35.6716083315754 139.7406609508487 19.489 35.6717171931824 139.7405124602312 19.489 35.6717171931824 139.7405124602312 19.28</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-73da273f-ff5d-47ac-aa4b-365d5f78fda2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-73da273f-ff5d-47ac-aa4b-365d5f78fda2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-73da273f-ff5d-47ac-aa4b-365d5f78fda2">
											<gml:posList>35.67161206546625 139.7406638186043 16.05 35.67161206546625 139.7406638186043 15.721 35.671720512888356 139.74051590287837 15.721 35.671720512888356 139.74051590287837 16.05 35.67172349330483 139.74051184538277 16.05 35.67172349330483 139.74051184538277 19.489 35.67160877890961 139.74066830725317 19.489 35.67160877890961 139.74066830725317 16.05 35.67161206546625 139.7406638186043 16.05</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ce5902e4-508d-4093-96ba-aaff63416caf">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ce5902e4-508d-4093-96ba-aaff63416caf">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ce5902e4-508d-4093-96ba-aaff63416caf">
											<gml:posList>35.67165859148401 139.74055476964685 19.489 35.67159260856096 139.74064524995788 19.489 35.67159260856096 139.74064524995788 22.937 35.67165859148401 139.74055476964685 22.937 35.67165859148401 139.74055476964685 19.489</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ea76901c-c215-44a5-93dd-b164c8b7437d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ea76901c-c215-44a5-93dd-b164c8b7437d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ea76901c-c215-44a5-93dd-b164c8b7437d">
											<gml:posList>35.67162574105459 139.7406778207183 16.05 35.67172804541607 139.7405237702733 16.05 35.67172804541607 139.7405237702733 15.721 35.67162574105459 139.7406778207183 15.721 35.67162574105459 139.7406778207183 16.05</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4e3af14c-423d-4e15-9cb0-bb21e37b6c5e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4e3af14c-423d-4e15-9cb0-bb21e37b6c5e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4e3af14c-423d-4e15-9cb0-bb21e37b6c5e">
											<gml:posList>35.67166233492728 139.74055833331371 19.28 35.67166233492728 139.74055833331371 22.937 35.67159698358275 139.7406496192851 22.937 35.67159698358275 139.7406496192851 19.489 35.67159698358275 139.7406496192851 19.28 35.67166233492728 139.74055833331371 19.28</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9454d28b-2e6c-470b-9e33-a4741a7f6c20">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9454d28b-2e6c-470b-9e33-a4741a7f6c20">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9454d28b-2e6c-470b-9e33-a4741a7f6c20">
											<gml:posList>35.671626405269535 139.74068589489187 7.98 35.67173462480211 139.74052294521994 7.98 35.67173462480211 139.74052294521994 16.05 35.671626405269535 139.74068589489187 16.05 35.671626405269535 139.74068589489187 7.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-978580fe-07c3-47a9-b092-34d36d1eb517">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-978580fe-07c3-47a9-b092-34d36d1eb517">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-978580fe-07c3-47a9-b092-34d36d1eb517">
											<gml:posList>35.67159698358275 139.7406496192851 19.489 35.6716083315754 139.7406609508487 19.489 35.6716083315754 139.7406609508487 19.28 35.67159698358275 139.7406496192851 19.28 35.67159698358275 139.7406496192851 19.489</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d4c130e4-2c57-4d1e-aafc-d7e239ceb8ef">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d4c130e4-2c57-4d1e-aafc-d7e239ceb8ef">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d4c130e4-2c57-4d1e-aafc-d7e239ceb8ef">
											<gml:posList>35.67161206546625 139.7406638186043 16.05 35.67162574105459 139.7406778207183 16.05 35.67162574105459 139.7406778207183 15.721 35.67161206546625 139.7406638186043 15.721 35.67161206546625 139.7406638186043 16.05</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-10513</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">319.7018</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1210</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>6</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.01</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>