<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_0b8ccbb8-e395-427a-822f-3e4105c505a5">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">402</bldg:usage>
			<bldg:measuredHeight uom="m">23</bldg:measuredHeight>
			<bldg:storeysAboveGround>7</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.67282641058898 139.7383816241963 0 35.67285803741558 139.73836722615738 0 35.67285288609074 139.73835011002953 0 35.67286018423983 139.7383463455386 0 35.67278101804014 139.7380856293459 0 35.672742093105406 139.73810379199 0 35.67282641058898 139.7383816241963 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67282641058898 139.7383816241963 8.853 35.672742093105406 139.73810379199 8.853 35.67278101804014 139.7380856293459 8.853 35.67286018423983 139.7383463455386 8.853 35.67285288609074 139.73835011002953 8.853 35.67285803741558 139.73836722615738 8.853 35.67282641058898 139.7383816241963 8.853</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67282641058898 139.7383816241963 8.853 35.67285803741558 139.73836722615738 8.853 35.67285803741558 139.73836722615738 31.880000000000003 35.67282641058898 139.7383816241963 31.880000000000003 35.67282641058898 139.7383816241963 8.853</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67285803741558 139.73836722615738 8.853 35.67285288609074 139.73835011002953 8.853 35.67285288609074 139.73835011002953 31.880000000000003 35.67285803741558 139.73836722615738 31.880000000000003 35.67285803741558 139.73836722615738 8.853</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67285288609074 139.73835011002953 8.853 35.67286018423983 139.7383463455386 8.853 35.67286018423983 139.7383463455386 31.880000000000003 35.67285288609074 139.73835011002953 31.880000000000003 35.67285288609074 139.73835011002953 8.853</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67286018423983 139.7383463455386 8.853 35.67278101804014 139.7380856293459 8.853 35.67278101804014 139.7380856293459 31.880000000000003 35.67286018423983 139.7383463455386 31.880000000000003 35.67286018423983 139.7383463455386 8.853</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67278101804014 139.7380856293459 8.853 35.672742093105406 139.73810379199 8.853 35.672742093105406 139.73810379199 31.880000000000003 35.67278101804014 139.7380856293459 31.880000000000003 35.67278101804014 139.7380856293459 8.853</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672742093105406 139.73810379199 8.853 35.67282641058898 139.7383816241963 8.853 35.67282641058898 139.7383816241963 31.880000000000003 35.672742093105406 139.73810379199 31.880000000000003 35.672742093105406 139.73810379199 8.853</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67282641058898 139.7383816241963 31.880000000000003 35.67285803741558 139.73836722615738 31.880000000000003 35.67285288609074 139.73835011002953 31.880000000000003 35.67286018423983 139.7383463455386 31.880000000000003 35.67278101804014 139.7380856293459 31.880000000000003 35.672742093105406 139.73810379199 31.880000000000003 35.67282641058898 139.7383816241963 31.880000000000003</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-954a60c4-da46-4214-a8b7-746a01e18aaf"/>
							<gml:surfaceMember xlink:href="#poly-89619410-05e3-48c7-8ec3-22fe28f704df"/>
							<gml:surfaceMember xlink:href="#poly-ff2d6c9b-425c-4f66-a334-4f3d960ddaf8"/>
							<gml:surfaceMember xlink:href="#poly-69c3c686-7ac6-4bfa-8f1a-165f7104132d"/>
							<gml:surfaceMember xlink:href="#poly-0508bc24-e0cf-4b62-828b-bc019ba1bfb7"/>
							<gml:surfaceMember xlink:href="#poly-f0024983-a02f-4e6c-8e0c-86ccceb1475f"/>
							<gml:surfaceMember xlink:href="#poly-9a4fd112-fff4-4587-bb76-a2e816e5aa88"/>
							<gml:surfaceMember xlink:href="#poly-221c3f69-5ad5-424b-b692-39f1744ee27b"/>
							<gml:surfaceMember xlink:href="#poly-fe1041ff-5457-4d48-9480-107a091406a6"/>
							<gml:surfaceMember xlink:href="#poly-ff9f4cba-a34e-4404-8629-dd8b33923111"/>
							<gml:surfaceMember xlink:href="#poly-2df162bb-847c-46be-b659-ceb54c3d2854"/>
							<gml:surfaceMember xlink:href="#poly-85f85ffb-8ba9-4d0a-be5e-33a54ca3f10f"/>
							<gml:surfaceMember xlink:href="#poly-9a85372b-38e5-410e-9c19-7dc954b66983"/>
							<gml:surfaceMember xlink:href="#poly-05853f79-9aae-48e5-82d7-b34931153929"/>
							<gml:surfaceMember xlink:href="#poly-84301621-b87e-4e25-962e-f4c0586895cd"/>
							<gml:surfaceMember xlink:href="#poly-75bc93b9-6761-4adb-b4e7-5e6606daaab9"/>
							<gml:surfaceMember xlink:href="#poly-4b176393-032a-436e-8e5a-ebd7c868e7de"/>
							<gml:surfaceMember xlink:href="#poly-c63c0eaf-5611-4c8d-98d4-1343ecdf1be9"/>
							<gml:surfaceMember xlink:href="#poly-c9a27403-cc79-4596-a0f7-02f314e2678f"/>
							<gml:surfaceMember xlink:href="#poly-a4e4a9cc-f094-4e19-a927-9b96e09d7121"/>
							<gml:surfaceMember xlink:href="#poly-4d782b64-20b1-4863-9db4-a9a0f934b556"/>
							<gml:surfaceMember xlink:href="#poly-61c5d642-2ef2-4606-84cc-319a4dcc1d97"/>
							<gml:surfaceMember xlink:href="#poly-69522473-b4aa-4eae-bb2f-0239159e2add"/>
							<gml:surfaceMember xlink:href="#poly-7d5e6d22-6235-456b-8b29-cec82873bd54"/>
							<gml:surfaceMember xlink:href="#poly-2121ddd3-f62f-4af5-a061-c2abb27c10dc"/>
							<gml:surfaceMember xlink:href="#poly-e33748c7-25b1-4763-be42-4c95666c3b33"/>
							<gml:surfaceMember xlink:href="#poly-2d60fc24-3df3-4223-8779-7ae7b8d48e9e"/>
							<gml:surfaceMember xlink:href="#poly-a18a38d5-7028-41f0-898d-97d1bddaad5b"/>
							<gml:surfaceMember xlink:href="#poly-eaa69bd3-c204-4487-ad72-41509026edf1"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_0b8ccbb8-e395-427a-822f-3e4105c505a5_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-99127756-ff00-486f-b36d-36340e2b9f14">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672786664969294 139.73823936908738 37.703 35.67280424402497 139.73823085340584 37.703 35.672808752915344 139.73824483304492 37.703 35.67279094860296 139.73825345945696 37.703 35.672786664969294 139.73823936908738 37.703</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e4ca84a9-9d49-4c18-a7c6-f80364f9cbe5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672848172110676 139.73833893645607 31.905 35.672826988457615 139.73834859418875 31.905 35.672820734702235 139.73832798865095 31.905 35.67284192736737 139.73831833090287 31.905 35.672848172110676 139.73833893645607 31.905</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a1b7ad4e-a7d9-425c-88ad-8b7a547ed374">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a1b7ad4e-a7d9-425c-88ad-8b7a547ed374_0">
											<gml:posList>35.672786664969294 139.73823936908738 38.871 35.672786664969294 139.73823936908738 37.703 35.67279094860296 139.73825345945696 37.703 35.67279094860296 139.73825345945696 38.871 35.672786664969294 139.73823936908738 38.871</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0431a310-11fa-43be-b869-99b7ad1dc7aa">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0431a310-11fa-43be-b869-99b7ad1dc7aa_0">
											<gml:posList>35.672786664969294 139.73823936908738 38.871 35.67280424402497 139.73823085340584 38.871 35.67280424402497 139.73823085340584 37.703 35.672786664969294 139.73823936908738 37.703 35.672786664969294 139.73823936908738 38.871</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3de39ea2-f565-4cc0-9dc8-e3c39bce762f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3de39ea2-f565-4cc0-9dc8-e3c39bce762f_0">
											<gml:posList>35.672786664969294 139.73823936908738 38.871 35.67279094860296 139.73825345945696 38.871 35.672808752915344 139.73824483304492 38.871 35.67280424402497 139.73823085340584 38.871 35.672786664969294 139.73823936908738 38.871</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d209b3cb-d233-41b2-9aeb-48d250cfcd8b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d209b3cb-d233-41b2-9aeb-48d250cfcd8b_0">
											<gml:posList>35.67279094860296 139.73825345945696 38.871 35.67279094860296 139.73825345945696 37.703 35.672808752915344 139.73824483304492 37.703 35.672808752915344 139.73824483304492 38.871 35.67279094860296 139.73825345945696 38.871</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-246cb4f9-750f-47f9-b286-cef7311e5101">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-246cb4f9-750f-47f9-b286-cef7311e5101_0">
											<gml:posList>35.672808752915344 139.73824483304492 37.703 35.67280424402497 139.73823085340584 37.703 35.67280424402497 139.73823085340584 38.871 35.672808752915344 139.73824483304492 38.871 35.672808752915344 139.73824483304492 37.703</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fb789285-f138-4111-84b1-847a08a55782">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fb789285-f138-4111-84b1-847a08a55782_0">
											<gml:posList>35.672820734702235 139.73832798865095 31.905 35.672826988457615 139.73834859418875 31.905 35.672826988457615 139.73834859418875 34.532 35.672820734702235 139.73832798865095 34.532 35.672820734702235 139.73832798865095 31.905</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-06694745-9ada-4e2c-913a-a063f0b47a7f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-06694745-9ada-4e2c-913a-a063f0b47a7f_0">
											<gml:posList>35.67284192736737 139.73831833090287 31.905 35.672820734702235 139.73832798865095 31.905 35.672820734702235 139.73832798865095 34.532 35.67284192736737 139.73831833090287 34.532 35.67284192736737 139.73831833090287 31.905</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d6c38dd6-8bf1-4f6d-9845-00813ab5fe9f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d6c38dd6-8bf1-4f6d-9845-00813ab5fe9f_0">
											<gml:posList>35.672848172110676 139.73833893645607 34.532 35.67284192736737 139.73831833090287 34.532 35.672820734702235 139.73832798865095 34.532 35.672826988457615 139.73834859418875 34.532 35.672848172110676 139.73833893645607 34.532</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a4baaca8-c08c-4c2f-9477-db878fe819e6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a4baaca8-c08c-4c2f-9477-db878fe819e6_0">
											<gml:posList>35.672848172110676 139.73833893645607 31.905 35.672848172110676 139.73833893645607 34.532 35.672826988457615 139.73834859418875 34.532 35.672826988457615 139.73834859418875 31.905 35.672848172110676 139.73833893645607 31.905</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ac688c43-5ee0-41d1-bc4f-ef8317994d63">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ac688c43-5ee0-41d1-bc4f-ef8317994d63_0">
											<gml:posList>35.672848172110676 139.73833893645607 31.905 35.67284192736737 139.73831833090287 31.905 35.67284192736737 139.73831833090287 34.532 35.672848172110676 139.73833893645607 34.532 35.672848172110676 139.73833893645607 31.905</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-954a60c4-da46-4214-a8b7-746a01e18aaf">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-954a60c4-da46-4214-a8b7-746a01e18aaf">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-954a60c4-da46-4214-a8b7-746a01e18aaf">
											<gml:posList>35.672742093105384 139.73810379199 8.853 35.672781018040126 139.7380856293459 8.853 35.67286018423985 139.7383463455386 8.853 35.6728528860907 139.73835011002953 8.853 35.67285803741558 139.73836722615738 8.853 35.67282641058898 139.73838162419628 8.853 35.672742093105384 139.73810379199 8.853</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-89619410-05e3-48c7-8ec3-22fe28f704df">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-89619410-05e3-48c7-8ec3-22fe28f704df">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-89619410-05e3-48c7-8ec3-22fe28f704df">
											<gml:posList>35.6728204114251 139.73821535794698 39.488 35.672781018040126 139.7380856293459 19.769 35.672742093105384 139.73810379199 19.769 35.67278136000844 139.73823317824284 39.488 35.6728204114251 139.73821535794698 39.488</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ff2d6c9b-425c-4f66-a334-4f3d960ddaf8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ff2d6c9b-425c-4f66-a334-4f3d960ddaf8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ff2d6c9b-425c-4f66-a334-4f3d960ddaf8">
											<gml:posList>35.672795385785854 139.7382793694994 39.488 35.6727972746727 139.73827430792056 39.488 35.6727854901324 139.7382355041742 39.488 35.67278136000844 139.73823317824284 39.488 35.672795385785854 139.7382793694994 39.488</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-69c3c686-7ac6-4bfa-8f1a-165f7104132d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-69c3c686-7ac6-4bfa-8f1a-165f7104132d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-69c3c686-7ac6-4bfa-8f1a-165f7104132d">
											<gml:posList>35.67278136000844 139.73823317824284 39.488 35.6727854901324 139.7382355041742 39.488 35.67281851353576 139.7382204305859 39.488 35.6728204114251 139.73821535794698 39.488 35.67278136000844 139.73823317824284 39.488</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-0508bc24-e0cf-4b62-828b-bc019ba1bfb7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0508bc24-e0cf-4b62-828b-bc019ba1bfb7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0508bc24-e0cf-4b62-828b-bc019ba1bfb7">
											<gml:posList>35.672830307112044 139.7382592564285 37.703 35.67281851353576 139.7382204305859 37.703 35.6727854901324 139.7382355041742 37.703 35.6727972746727 139.73827430792056 37.703 35.672830307112044 139.7382592564285 37.703</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f0024983-a02f-4e6c-8e0c-86ccceb1475f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f0024983-a02f-4e6c-8e0c-86ccceb1475f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f0024983-a02f-4e6c-8e0c-86ccceb1475f">
											<gml:posList>35.67282783176855 139.73837783353045 32.234 35.67279763840449 139.73827833949548 32.234 35.672795385785854 139.7382793694994 32.234 35.67282641058898 139.73838162419628 32.234 35.67282783176855 139.73837783353045 32.234</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-9a4fd112-fff4-4587-bb76-a2e816e5aa88">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9a4fd112-fff4-4587-bb76-a2e816e5aa88">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9a4fd112-fff4-4587-bb76-a2e816e5aa88">
											<gml:posList>35.672834446240465 139.73826157130534 39.488 35.672830307112044 139.7382592564285 39.488 35.6727972746727 139.73827430792056 39.488 35.672795385785854 139.7382793694994 39.488 35.672834446240465 139.73826157130534 39.488</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-221c3f69-5ad5-424b-b692-39f1744ee27b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-221c3f69-5ad5-424b-b692-39f1744ee27b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-221c3f69-5ad5-424b-b692-39f1744ee27b">
											<gml:posList>35.6728204114251 139.73821535794698 39.488 35.67281851353576 139.7382204305859 39.488 35.672830307112044 139.7382592564285 39.488 35.672834446240465 139.73826157130534 39.488 35.6728204114251 139.73821535794698 39.488</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-fe1041ff-5457-4d48-9480-107a091406a6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fe1041ff-5457-4d48-9480-107a091406a6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fe1041ff-5457-4d48-9480-107a091406a6">
											<gml:posList>35.672832193621986 139.7382626013102 31.905 35.67279763840449 139.73827833949548 31.905 35.67282783176855 139.73837783353045 31.905 35.67285494433359 139.73836548445848 31.905 35.672849829150486 139.73834847875457 31.905 35.67285711829457 139.73834472532093 31.905 35.672832193621986 139.7382626013102 31.905</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ff9f4cba-a34e-4404-8629-dd8b33923111">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ff9f4cba-a34e-4404-8629-dd8b33923111">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ff9f4cba-a34e-4404-8629-dd8b33923111">
											<gml:posList>35.67285803741558 139.73836722615738 32.234 35.67285494433359 139.73836548445848 32.234 35.67282783176855 139.73837783353045 32.234 35.67282641058898 139.73838162419628 32.234 35.67285803741558 139.73836722615738 32.234</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-2df162bb-847c-46be-b659-ceb54c3d2854">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2df162bb-847c-46be-b659-ceb54c3d2854">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2df162bb-847c-46be-b659-ceb54c3d2854">
											<gml:posList>35.67285711829457 139.73834472532093 32.234 35.67286018423985 139.7383463455386 32.234 35.672834446240465 139.73826157130534 32.234 35.672832193621986 139.7382626013102 32.234 35.67285711829457 139.73834472532093 32.234</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-85f85ffb-8ba9-4d0a-be5e-33a54ca3f10f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-85f85ffb-8ba9-4d0a-be5e-33a54ca3f10f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-85f85ffb-8ba9-4d0a-be5e-33a54ca3f10f">
											<gml:posList>35.6728528860907 139.73835011002953 32.234 35.672849829150486 139.73834847875457 32.234 35.67285494433359 139.73836548445848 32.234 35.67285803741558 139.73836722615738 32.234 35.6728528860907 139.73835011002953 32.234</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-9a85372b-38e5-410e-9c19-7dc954b66983">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9a85372b-38e5-410e-9c19-7dc954b66983">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9a85372b-38e5-410e-9c19-7dc954b66983">
											<gml:posList>35.6728528860907 139.73835011002953 32.234 35.67286018423985 139.7383463455386 32.234 35.67285711829457 139.73834472532093 32.234 35.672849829150486 139.73834847875457 32.234 35.6728528860907 139.73835011002953 32.234</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-05853f79-9aae-48e5-82d7-b34931153929">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-05853f79-9aae-48e5-82d7-b34931153929">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-05853f79-9aae-48e5-82d7-b34931153929">
											<gml:posList>35.67281851353576 139.7382204305859 39.488 35.67281851353576 139.7382204305859 37.703 35.672830307112044 139.7382592564285 37.703 35.672830307112044 139.7382592564285 39.488 35.67281851353576 139.7382204305859 39.488</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-84301621-b87e-4e25-962e-f4c0586895cd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-84301621-b87e-4e25-962e-f4c0586895cd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-84301621-b87e-4e25-962e-f4c0586895cd">
											<gml:posList>35.6727972746727 139.73827430792056 39.488 35.6727972746727 139.73827430792056 37.703 35.6727854901324 139.7382355041742 37.703 35.6727854901324 139.7382355041742 39.488 35.6727972746727 139.73827430792056 39.488</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-75bc93b9-6761-4adb-b4e7-5e6606daaab9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-75bc93b9-6761-4adb-b4e7-5e6606daaab9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-75bc93b9-6761-4adb-b4e7-5e6606daaab9">
											<gml:posList>35.672781018040126 139.7380856293459 8.853 35.672742093105384 139.73810379199 8.853 35.672742093105384 139.73810379199 19.769 35.672781018040126 139.7380856293459 19.769 35.672781018040126 139.7380856293459 8.853</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4b176393-032a-436e-8e5a-ebd7c868e7de">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4b176393-032a-436e-8e5a-ebd7c868e7de">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4b176393-032a-436e-8e5a-ebd7c868e7de">
											<gml:posList>35.67282641058898 139.73838162419628 8.853 35.67282641058898 139.73838162419628 32.234 35.672795385785854 139.7382793694994 32.234 35.672795385785854 139.7382793694994 39.488 35.67278136000844 139.73823317824284 39.488 35.672742093105384 139.73810379199 19.769 35.672742093105384 139.73810379199 8.853 35.67282641058898 139.73838162419628 8.853</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c63c0eaf-5611-4c8d-98d4-1343ecdf1be9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c63c0eaf-5611-4c8d-98d4-1343ecdf1be9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c63c0eaf-5611-4c8d-98d4-1343ecdf1be9">
											<gml:posList>35.6727854901324 139.7382355041742 39.488 35.6727854901324 139.7382355041742 37.703 35.67281851353576 139.7382204305859 37.703 35.67281851353576 139.7382204305859 39.488 35.6727854901324 139.7382355041742 39.488</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c9a27403-cc79-4596-a0f7-02f314e2678f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c9a27403-cc79-4596-a0f7-02f314e2678f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c9a27403-cc79-4596-a0f7-02f314e2678f">
											<gml:posList>35.67282783176855 139.73837783353045 32.234 35.67282783176855 139.73837783353045 31.905 35.67279763840449 139.73827833949548 31.905 35.67279763840449 139.73827833949548 32.234 35.67282783176855 139.73837783353045 32.234</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a4e4a9cc-f094-4e19-a927-9b96e09d7121">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a4e4a9cc-f094-4e19-a927-9b96e09d7121">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a4e4a9cc-f094-4e19-a927-9b96e09d7121">
											<gml:posList>35.672830307112044 139.7382592564285 39.488 35.672830307112044 139.7382592564285 37.703 35.6727972746727 139.73827430792056 37.703 35.6727972746727 139.73827430792056 39.488 35.672830307112044 139.7382592564285 39.488</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4d782b64-20b1-4863-9db4-a9a0f934b556">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4d782b64-20b1-4863-9db4-a9a0f934b556">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4d782b64-20b1-4863-9db4-a9a0f934b556">
											<gml:posList>35.67279763840449 139.73827833949548 32.234 35.67279763840449 139.73827833949548 31.905 35.672832193621986 139.7382626013102 31.905 35.672832193621986 139.7382626013102 32.234 35.672834446240465 139.73826157130534 32.234 35.672834446240465 139.73826157130534 39.488 35.672795385785854 139.7382793694994 39.488 35.672795385785854 139.7382793694994 32.234 35.67279763840449 139.73827833949548 32.234</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-61c5d642-2ef2-4606-84cc-319a4dcc1d97">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-61c5d642-2ef2-4606-84cc-319a4dcc1d97">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-61c5d642-2ef2-4606-84cc-319a4dcc1d97">
											<gml:posList>35.672834446240465 139.73826157130534 32.234 35.67286018423985 139.7383463455386 32.234 35.67286018423985 139.7383463455386 8.853 35.672781018040126 139.7380856293459 8.853 35.672781018040126 139.7380856293459 19.769 35.6728204114251 139.73821535794698 39.488 35.672834446240465 139.73826157130534 39.488 35.672834446240465 139.73826157130534 32.234</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-69522473-b4aa-4eae-bb2f-0239159e2add">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-69522473-b4aa-4eae-bb2f-0239159e2add">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-69522473-b4aa-4eae-bb2f-0239159e2add">
											<gml:posList>35.67285494433359 139.73836548445848 32.234 35.67285494433359 139.73836548445848 31.905 35.67282783176855 139.73837783353045 31.905 35.67282783176855 139.73837783353045 32.234 35.67285494433359 139.73836548445848 32.234</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7d5e6d22-6235-456b-8b29-cec82873bd54">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7d5e6d22-6235-456b-8b29-cec82873bd54">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7d5e6d22-6235-456b-8b29-cec82873bd54">
											<gml:posList>35.67282641058898 139.73838162419628 8.853 35.67285803741558 139.73836722615738 8.853 35.67285803741558 139.73836722615738 32.234 35.67282641058898 139.73838162419628 32.234 35.67282641058898 139.73838162419628 8.853</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2121ddd3-f62f-4af5-a061-c2abb27c10dc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2121ddd3-f62f-4af5-a061-c2abb27c10dc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2121ddd3-f62f-4af5-a061-c2abb27c10dc">
											<gml:posList>35.672832193621986 139.7382626013102 32.234 35.672832193621986 139.7382626013102 31.905 35.67285711829457 139.73834472532093 31.905 35.67285711829457 139.73834472532093 32.234 35.672832193621986 139.7382626013102 32.234</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e33748c7-25b1-4763-be42-4c95666c3b33">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e33748c7-25b1-4763-be42-4c95666c3b33">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e33748c7-25b1-4763-be42-4c95666c3b33">
											<gml:posList>35.672849829150486 139.73834847875457 32.234 35.672849829150486 139.73834847875457 31.905 35.67285494433359 139.73836548445848 31.905 35.67285494433359 139.73836548445848 32.234 35.672849829150486 139.73834847875457 32.234</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2d60fc24-3df3-4223-8779-7ae7b8d48e9e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2d60fc24-3df3-4223-8779-7ae7b8d48e9e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2d60fc24-3df3-4223-8779-7ae7b8d48e9e">
											<gml:posList>35.67285711829457 139.73834472532093 32.234 35.67285711829457 139.73834472532093 31.905 35.672849829150486 139.73834847875457 31.905 35.672849829150486 139.73834847875457 32.234 35.67285711829457 139.73834472532093 32.234</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a18a38d5-7028-41f0-898d-97d1bddaad5b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a18a38d5-7028-41f0-898d-97d1bddaad5b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a18a38d5-7028-41f0-898d-97d1bddaad5b">
											<gml:posList>35.67285803741558 139.73836722615738 8.853 35.6728528860907 139.73835011002953 8.853 35.6728528860907 139.73835011002953 32.234 35.67285803741558 139.73836722615738 32.234 35.67285803741558 139.73836722615738 8.853</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-eaa69bd3-c204-4487-ad72-41509026edf1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-eaa69bd3-c204-4487-ad72-41509026edf1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-eaa69bd3-c204-4487-ad72-41509026edf1">
											<gml:posList>35.6728528860907 139.73835011002953 8.853 35.67286018423985 139.7383463455386 8.853 35.67286018423985 139.7383463455386 32.234 35.6728528860907 139.73835011002953 32.234 35.6728528860907 139.73835011002953 8.853</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-5935</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">122.67345</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1242</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>5</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.01</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>