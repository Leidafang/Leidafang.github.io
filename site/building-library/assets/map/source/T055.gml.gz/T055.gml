<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_0d21a3dd-5ba3-496f-ae32-a42f3f9af8fa">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>46</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13101046002</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="再開発等促進区を定める地区計画">
				<gen:value>永田町二丁目地区</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3001</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">402</bldg:usage>
			<bldg:measuredHeight uom="m">21.1</bldg:measuredHeight>
			<bldg:storeysAboveGround>2</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.67400855739941 139.7405744418454 0 35.674048579325195 139.74057572114884 0 35.67415431295044 139.74057913377783 0 35.67415743865352 139.74042447524275 0 35.67409906464816 139.7403529598137 0 35.67391517961301 139.7403464345747 0 35.67385178563249 139.74042759116136 0 35.67384855983056 139.74056932453976 0 35.67400855739941 139.7405744418454 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67400855739941 139.7405744418454 9.5 35.67384855983056 139.74056932453976 9.5 35.67385178563249 139.74042759116136 9.5 35.67391517961301 139.7403464345747 9.5 35.67409906464816 139.7403529598137 9.5 35.67415743865352 139.74042447524275 9.5 35.67415431295044 139.74057913377783 9.5 35.674048579325195 139.74057572114884 9.5 35.67400855739941 139.7405744418454 9.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67400855739941 139.7405744418454 9.5 35.674048579325195 139.74057572114884 9.5 35.674048579325195 139.74057572114884 28.01 35.67400855739941 139.7405744418454 28.01 35.67400855739941 139.7405744418454 9.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.674048579325195 139.74057572114884 9.5 35.67415431295044 139.74057913377783 9.5 35.67415431295044 139.74057913377783 28.01 35.674048579325195 139.74057572114884 28.01 35.674048579325195 139.74057572114884 9.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67415431295044 139.74057913377783 9.5 35.67415743865352 139.74042447524275 9.5 35.67415743865352 139.74042447524275 28.01 35.67415431295044 139.74057913377783 28.01 35.67415431295044 139.74057913377783 9.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67415743865352 139.74042447524275 9.5 35.67409906464816 139.7403529598137 9.5 35.67409906464816 139.7403529598137 28.01 35.67415743865352 139.74042447524275 28.01 35.67415743865352 139.74042447524275 9.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67409906464816 139.7403529598137 9.5 35.67391517961301 139.7403464345747 9.5 35.67391517961301 139.7403464345747 28.01 35.67409906464816 139.7403529598137 28.01 35.67409906464816 139.7403529598137 9.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67391517961301 139.7403464345747 9.5 35.67385178563249 139.74042759116136 9.5 35.67385178563249 139.74042759116136 28.01 35.67391517961301 139.7403464345747 28.01 35.67391517961301 139.7403464345747 9.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67385178563249 139.74042759116136 9.5 35.67384855983056 139.74056932453976 9.5 35.67384855983056 139.74056932453976 28.01 35.67385178563249 139.74042759116136 28.01 35.67385178563249 139.74042759116136 9.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67384855983056 139.74056932453976 9.5 35.67400855739941 139.7405744418454 9.5 35.67400855739941 139.7405744418454 28.01 35.67384855983056 139.74056932453976 28.01 35.67384855983056 139.74056932453976 9.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67400855739941 139.7405744418454 28.01 35.674048579325195 139.74057572114884 28.01 35.67415431295044 139.74057913377783 28.01 35.67415743865352 139.74042447524275 28.01 35.67409906464816 139.7403529598137 28.01 35.67391517961301 139.7403464345747 28.01 35.67385178563249 139.74042759116136 28.01 35.67384855983056 139.74056932453976 28.01 35.67400855739941 139.7405744418454 28.01</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-38d0837d-b316-4888-8467-9faf4d9cef47"/>
							<gml:surfaceMember xlink:href="#poly-151ff8ee-c01c-4da2-be0f-c1f8b542b7e0"/>
							<gml:surfaceMember xlink:href="#poly-c855d020-f7b4-4f7f-82fb-dbcec347f095"/>
							<gml:surfaceMember xlink:href="#poly-8c1e4c10-b0b9-4e81-afee-795a12053598"/>
							<gml:surfaceMember xlink:href="#poly-842b7277-fcb2-418b-82cd-c691ec75c4b2"/>
							<gml:surfaceMember xlink:href="#poly-aa1810d9-c286-473d-b74a-d577fdd1728e"/>
							<gml:surfaceMember xlink:href="#poly-a61e7df0-395e-457a-9da2-0eec606ddd5c"/>
							<gml:surfaceMember xlink:href="#poly-fb886233-f248-47c3-8557-6668467b3760"/>
							<gml:surfaceMember xlink:href="#poly-cee809d5-b03c-43e9-9756-ba1c6a49470e"/>
							<gml:surfaceMember xlink:href="#poly-b11b40c7-5cf6-4f59-8e0f-54acc7b8216c"/>
							<gml:surfaceMember xlink:href="#poly-ee3b63bd-f269-442e-ae0e-d3c0fa798a70"/>
							<gml:surfaceMember xlink:href="#poly-ab3965f1-8c8f-4750-9d32-195128d621fe"/>
							<gml:surfaceMember xlink:href="#poly-7388b992-a7f1-4b80-848d-eab1ecf3834b"/>
							<gml:surfaceMember xlink:href="#poly-3fb2ecd0-1544-4f80-9936-65ce995659bb"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-38d0837d-b316-4888-8467-9faf4d9cef47">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-38d0837d-b316-4888-8467-9faf4d9cef47">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-38d0837d-b316-4888-8467-9faf4d9cef47">
											<gml:posList>35.6741574386535 139.74042447524275 9.5 35.674154312950435 139.74057913377783 9.5 35.674048579325195 139.74057572114882 9.5 35.67400855739939 139.74057444184538 9.5 35.67384855983056 139.74056932453976 9.5 35.67385178563248 139.74042759116136 9.5 35.673915179613005 139.7403464345747 9.5 35.67409906464816 139.7403529598137 9.5 35.6741574386535 139.74042447524275 9.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-151ff8ee-c01c-4da2-be0f-c1f8b542b7e0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-151ff8ee-c01c-4da2-be0f-c1f8b542b7e0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-151ff8ee-c01c-4da2-be0f-c1f8b542b7e0">
											<gml:posList>35.67397246447143 139.74052509356855 25 35.673974798948834 139.74041980424664 25 35.67385178563248 139.74042759116136 25 35.67384855983056 139.74056932453976 25 35.67397246447143 139.74052509356855 25</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c855d020-f7b4-4f7f-82fb-dbcec347f095">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c855d020-f7b4-4f7f-82fb-dbcec347f095">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c855d020-f7b4-4f7f-82fb-dbcec347f095">
											<gml:posList>35.674128108464444 139.74053028211378 25 35.67397246447143 139.74052509356855 25 35.67384855983056 139.74056932453976 25 35.67400855739939 139.74057444184538 25 35.674048579325195 139.74057572114882 25 35.674154312950435 139.74057913377783 25 35.6741574386535 139.74042447524275 25 35.67409906464816 139.7403529598137 25 35.673915179613005 139.7403464345747 25 35.67385178563248 139.74042759116136 25 35.673974798948834 139.74041980424664 25 35.67413045195973 139.74042499257712 25 35.674128108464444 139.74053028211378 25</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-8c1e4c10-b0b9-4e81-afee-795a12053598">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8c1e4c10-b0b9-4e81-afee-795a12053598">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8c1e4c10-b0b9-4e81-afee-795a12053598">
											<gml:posList>35.67397246447143 139.74052509356855 27.84 35.674128108464444 139.74053028211378 27.84 35.67413045195973 139.74042499257712 30.59 35.673974798948834 139.74041980424664 30.59 35.67397246447143 139.74052509356855 27.84</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-842b7277-fcb2-418b-82cd-c691ec75c4b2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-842b7277-fcb2-418b-82cd-c691ec75c4b2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-842b7277-fcb2-418b-82cd-c691ec75c4b2">
											<gml:posList>35.67385178563248 139.74042759116136 9.5 35.67384855983056 139.74056932453976 9.5 35.67384855983056 139.74056932453976 25 35.67385178563248 139.74042759116136 25 35.67385178563248 139.74042759116136 9.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-aa1810d9-c286-473d-b74a-d577fdd1728e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-aa1810d9-c286-473d-b74a-d577fdd1728e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-aa1810d9-c286-473d-b74a-d577fdd1728e">
											<gml:posList>35.673915179613005 139.7403464345747 9.5 35.67385178563248 139.74042759116136 9.5 35.67385178563248 139.74042759116136 25 35.673915179613005 139.7403464345747 25 35.673915179613005 139.7403464345747 9.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a61e7df0-395e-457a-9da2-0eec606ddd5c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a61e7df0-395e-457a-9da2-0eec606ddd5c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a61e7df0-395e-457a-9da2-0eec606ddd5c">
											<gml:posList>35.67397246447143 139.74052509356855 27.84 35.673974798948834 139.74041980424664 30.59 35.673974798948834 139.74041980424664 25 35.67397246447143 139.74052509356855 25 35.67397246447143 139.74052509356855 27.84</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-fb886233-f248-47c3-8557-6668467b3760">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fb886233-f248-47c3-8557-6668467b3760">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fb886233-f248-47c3-8557-6668467b3760">
											<gml:posList>35.674048579325195 139.74057572114882 9.5 35.674154312950435 139.74057913377783 9.5 35.674154312950435 139.74057913377783 25 35.674048579325195 139.74057572114882 25 35.67400855739939 139.74057444184538 25 35.67384855983056 139.74056932453976 25 35.67384855983056 139.74056932453976 9.5 35.67400855739939 139.74057444184538 9.5 35.674048579325195 139.74057572114882 9.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-cee809d5-b03c-43e9-9756-ba1c6a49470e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cee809d5-b03c-43e9-9756-ba1c6a49470e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cee809d5-b03c-43e9-9756-ba1c6a49470e">
											<gml:posList>35.67409906464816 139.7403529598137 9.5 35.673915179613005 139.7403464345747 9.5 35.673915179613005 139.7403464345747 25 35.67409906464816 139.7403529598137 25 35.67409906464816 139.7403529598137 9.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b11b40c7-5cf6-4f59-8e0f-54acc7b8216c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b11b40c7-5cf6-4f59-8e0f-54acc7b8216c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b11b40c7-5cf6-4f59-8e0f-54acc7b8216c">
											<gml:posList>35.674128108464444 139.74053028211378 27.84 35.67397246447143 139.74052509356855 27.84 35.67397246447143 139.74052509356855 25 35.674128108464444 139.74053028211378 25 35.674128108464444 139.74053028211378 27.84</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ee3b63bd-f269-442e-ae0e-d3c0fa798a70">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ee3b63bd-f269-442e-ae0e-d3c0fa798a70">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ee3b63bd-f269-442e-ae0e-d3c0fa798a70">
											<gml:posList>35.673974798948834 139.74041980424664 30.59 35.67413045195973 139.74042499257712 30.59 35.67413045195973 139.74042499257712 25 35.673974798948834 139.74041980424664 25 35.673974798948834 139.74041980424664 30.59</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ab3965f1-8c8f-4750-9d32-195128d621fe">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ab3965f1-8c8f-4750-9d32-195128d621fe">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ab3965f1-8c8f-4750-9d32-195128d621fe">
											<gml:posList>35.6741574386535 139.74042447524275 9.5 35.67409906464816 139.7403529598137 9.5 35.67409906464816 139.7403529598137 25 35.6741574386535 139.74042447524275 25 35.6741574386535 139.74042447524275 9.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7388b992-a7f1-4b80-848d-eab1ecf3834b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7388b992-a7f1-4b80-848d-eab1ecf3834b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7388b992-a7f1-4b80-848d-eab1ecf3834b">
											<gml:posList>35.67413045195973 139.74042499257712 30.59 35.674128108464444 139.74053028211378 27.84 35.674128108464444 139.74053028211378 25 35.67413045195973 139.74042499257712 25 35.67413045195973 139.74042499257712 30.59</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3fb2ecd0-1544-4f80-9936-65ce995659bb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3fb2ecd0-1544-4f80-9936-65ce995659bb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3fb2ecd0-1544-4f80-9936-65ce995659bb">
											<gml:posList>35.674154312950435 139.74057913377783 9.5 35.6741574386535 139.74042447524275 9.5 35.6741574386535 139.74042447524275 25 35.674154312950435 139.74057913377783 25 35.674154312950435 139.74057913377783 9.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都千代田区永田町二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13101-bldg-4558</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13101</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">642.78435</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1221</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>6</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.0</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>