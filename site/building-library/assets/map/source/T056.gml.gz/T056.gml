<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_0d266534-11b7-4d9f-973e-251fa46d362d">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="再開発等促進区を定める地区計画">
				<gen:value>霞が関三丁目南地区</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3001</bldg:class>
			<bldg:measuredHeight uom="m">9.3</bldg:measuredHeight>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.67155693890554 139.74766455222507 0 35.67158661448352 139.74769324122417 0 35.67163433447325 139.74761906868565 0 35.671604658877804 139.747590379697 0 35.67155693890554 139.74766455222507 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67155693890554 139.74766455222507 7.4 35.671604658877804 139.747590379697 7.4 35.67163433447325 139.74761906868565 7.4 35.67158661448352 139.74769324122417 7.4 35.67155693890554 139.74766455222507 7.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67155693890554 139.74766455222507 7.4 35.67158661448352 139.74769324122417 7.4 35.67158661448352 139.74769324122417 16.68 35.67155693890554 139.74766455222507 16.68 35.67155693890554 139.74766455222507 7.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67158661448352 139.74769324122417 7.4 35.67163433447325 139.74761906868565 7.4 35.67163433447325 139.74761906868565 16.68 35.67158661448352 139.74769324122417 16.68 35.67158661448352 139.74769324122417 7.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67163433447325 139.74761906868565 7.4 35.671604658877804 139.747590379697 7.4 35.671604658877804 139.747590379697 16.68 35.67163433447325 139.74761906868565 16.68 35.67163433447325 139.74761906868565 7.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671604658877804 139.747590379697 7.4 35.67155693890554 139.74766455222507 7.4 35.67155693890554 139.74766455222507 16.68 35.671604658877804 139.747590379697 16.68 35.671604658877804 139.747590379697 7.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67155693890554 139.74766455222507 16.68 35.67158661448352 139.74769324122417 16.68 35.67163433447325 139.74761906868565 16.68 35.671604658877804 139.747590379697 16.68 35.67155693890554 139.74766455222507 16.68</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-391c98cf-5658-460c-ac95-ee551125077c"/>
							<gml:surfaceMember xlink:href="#poly-3aa3cb92-8e85-47c9-bba1-f1cd8103df84"/>
							<gml:surfaceMember xlink:href="#poly-07c0e681-9002-4af9-abb7-16336c07efa7"/>
							<gml:surfaceMember xlink:href="#poly-b4737d9d-95d2-475e-a8a3-d2a7aa409cfe"/>
							<gml:surfaceMember xlink:href="#poly-478b4583-99a8-48e5-9403-16a086dd4670"/>
							<gml:surfaceMember xlink:href="#poly-330248fb-6df1-40d4-9766-b7dc1f2bfcf6"/>
							<gml:surfaceMember xlink:href="#poly-d27af94e-b383-4977-a2a3-f302f3d12957"/>
							<gml:surfaceMember xlink:href="#poly-62665453-64c3-43bb-999b-6ec5b78d4fb3"/>
							<gml:surfaceMember xlink:href="#poly-548c071c-ddb7-4df1-8172-a7b0b08a6286"/>
							<gml:surfaceMember xlink:href="#poly-7d0bffd2-469d-467e-857f-e876deee0321"/>
							<gml:surfaceMember xlink:href="#poly-9b286f10-04d6-4052-ae0d-27b8366e28f8"/>
							<gml:surfaceMember xlink:href="#poly-30639479-9ff4-4c2c-ab8b-451376584faf"/>
							<gml:surfaceMember xlink:href="#poly-bb56615a-f031-4fc7-9101-fc3d00ce909a"/>
							<gml:surfaceMember xlink:href="#poly-9b55c7e0-66ec-47a2-9619-41919c331ff8"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-391c98cf-5658-460c-ac95-ee551125077c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-391c98cf-5658-460c-ac95-ee551125077c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-391c98cf-5658-460c-ac95-ee551125077c">
											<gml:posList>35.67155693890551 139.74766455222505 7.4 35.671604658877804 139.747590379697 7.4 35.67163433447325 139.74761906868565 7.4 35.67158661448353 139.74769324122414 7.4 35.67155693890551 139.74766455222505 7.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-3aa3cb92-8e85-47c9-bba1-f1cd8103df84">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3aa3cb92-8e85-47c9-bba1-f1cd8103df84">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3aa3cb92-8e85-47c9-bba1-f1cd8103df84">
											<gml:posList>35.67158661448353 139.74769324122414 18.1 35.67158604235276 139.74768724362582 18.1 35.671561832853946 139.74766384002461 18.1 35.67155693890551 139.74766455222505 18.1 35.67158661448353 139.74769324122414 18.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-07c0e681-9002-4af9-abb7-16336c07efa7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-07c0e681-9002-4af9-abb7-16336c07efa7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-07c0e681-9002-4af9-abb7-16336c07efa7">
											<gml:posList>35.67155693890551 139.74766455222505 18.1 35.671561832853946 139.74766384002461 18.1 35.671605240027134 139.74759637728638 18.1 35.671604658877804 139.747590379697 18.1 35.67155693890551 139.74766455222505 18.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b4737d9d-95d2-475e-a8a3-d2a7aa409cfe">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b4737d9d-95d2-475e-a8a3-d2a7aa409cfe">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b4737d9d-95d2-475e-a8a3-d2a7aa409cfe">
											<gml:posList>35.67162944052514 139.74761978088947 17.572 35.671605240027134 139.74759637728638 17.572 35.671561832853946 139.74766384002461 17.572 35.67158604235276 139.74768724362582 17.572 35.67162944052514 139.74761978088947 17.572</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-478b4583-99a8-48e5-9403-16a086dd4670">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-478b4583-99a8-48e5-9403-16a086dd4670">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-478b4583-99a8-48e5-9403-16a086dd4670">
											<gml:posList>35.67163433447325 139.74761906868565 18.1 35.67162944052514 139.74761978088947 18.1 35.67158604235276 139.74768724362582 18.1 35.67158661448353 139.74769324122414 18.1 35.67163433447325 139.74761906868565 18.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-330248fb-6df1-40d4-9766-b7dc1f2bfcf6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-330248fb-6df1-40d4-9766-b7dc1f2bfcf6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-330248fb-6df1-40d4-9766-b7dc1f2bfcf6">
											<gml:posList>35.671604658877804 139.747590379697 18.1 35.671605240027134 139.74759637728638 18.1 35.67162944052514 139.74761978088947 18.1 35.67163433447325 139.74761906868565 18.1 35.671604658877804 139.747590379697 18.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d27af94e-b383-4977-a2a3-f302f3d12957">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d27af94e-b383-4977-a2a3-f302f3d12957">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d27af94e-b383-4977-a2a3-f302f3d12957">
											<gml:posList>35.67155693890551 139.74766455222505 7.4 35.67158661448353 139.74769324122414 7.4 35.67158661448353 139.74769324122414 18.1 35.67155693890551 139.74766455222505 18.1 35.67155693890551 139.74766455222505 7.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-62665453-64c3-43bb-999b-6ec5b78d4fb3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-62665453-64c3-43bb-999b-6ec5b78d4fb3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-62665453-64c3-43bb-999b-6ec5b78d4fb3">
											<gml:posList>35.671561832853946 139.74766384002461 18.1 35.671561832853946 139.74766384002461 17.572 35.671605240027134 139.74759637728638 17.572 35.671605240027134 139.74759637728638 18.1 35.671561832853946 139.74766384002461 18.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-548c071c-ddb7-4df1-8172-a7b0b08a6286">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-548c071c-ddb7-4df1-8172-a7b0b08a6286">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-548c071c-ddb7-4df1-8172-a7b0b08a6286">
											<gml:posList>35.67162944052514 139.74761978088947 18.1 35.67162944052514 139.74761978088947 17.572 35.67158604235276 139.74768724362582 17.572 35.67158604235276 139.74768724362582 18.1 35.67162944052514 139.74761978088947 18.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7d0bffd2-469d-467e-857f-e876deee0321">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7d0bffd2-469d-467e-857f-e876deee0321">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7d0bffd2-469d-467e-857f-e876deee0321">
											<gml:posList>35.67163433447325 139.74761906868565 7.4 35.671604658877804 139.747590379697 7.4 35.671604658877804 139.747590379697 18.1 35.67163433447325 139.74761906868565 18.1 35.67163433447325 139.74761906868565 7.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9b286f10-04d6-4052-ae0d-27b8366e28f8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9b286f10-04d6-4052-ae0d-27b8366e28f8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9b286f10-04d6-4052-ae0d-27b8366e28f8">
											<gml:posList>35.671605240027134 139.74759637728638 18.1 35.671605240027134 139.74759637728638 17.572 35.67162944052514 139.74761978088947 17.572 35.67162944052514 139.74761978088947 18.1 35.671605240027134 139.74759637728638 18.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-30639479-9ff4-4c2c-ab8b-451376584faf">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-30639479-9ff4-4c2c-ab8b-451376584faf">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-30639479-9ff4-4c2c-ab8b-451376584faf">
											<gml:posList>35.671604658877804 139.747590379697 7.4 35.67155693890551 139.74766455222505 7.4 35.67155693890551 139.74766455222505 18.1 35.671604658877804 139.747590379697 18.1 35.671604658877804 139.747590379697 7.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-bb56615a-f031-4fc7-9101-fc3d00ce909a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bb56615a-f031-4fc7-9101-fc3d00ce909a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bb56615a-f031-4fc7-9101-fc3d00ce909a">
											<gml:posList>35.67158661448353 139.74769324122414 7.4 35.67163433447325 139.74761906868565 7.4 35.67163433447325 139.74761906868565 18.1 35.67158661448353 139.74769324122414 18.1 35.67158661448353 139.74769324122414 7.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9b55c7e0-66ec-47a2-9619-41919c331ff8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9b55c7e0-66ec-47a2-9619-41919c331ff8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9b55c7e0-66ec-47a2-9619-41919c331ff8">
											<gml:posList>35.67158604235276 139.74768724362582 18.1 35.67158604235276 139.74768724362582 17.572 35.671561832853946 139.74766384002461 17.572 35.671561832853946 139.74766384002461 18.1 35.67158604235276 139.74768724362582 18.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13101-bldg-2696</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13101</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>7</uro:specifiedFloorAreaRate>
					<uro:surveyYear>0001</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.02</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>