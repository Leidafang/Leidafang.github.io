<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_0dc4527b-8a70-4f84-a3aa-f66431ad65b3">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">401</bldg:usage>
			<bldg:measuredHeight uom="m">19</bldg:measuredHeight>
			<bldg:storeysAboveGround>5</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.66868251506137 139.73905282787283 0 35.66855513879494 139.73892219291122 0 35.66850922143435 139.73898940666575 0 35.66863659754242 139.73911993119955 0 35.66868251506137 139.73905282787283 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66868251506137 139.73905282787283 12.56 35.66863659754242 139.73911993119955 12.56 35.66850922143435 139.73898940666575 12.56 35.66855513879494 139.73892219291122 12.56 35.66868251506137 139.73905282787283 12.56</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66868251506137 139.73905282787283 12.56 35.66855513879494 139.73892219291122 12.56 35.66855513879494 139.73892219291122 31.54 35.66868251506137 139.73905282787283 31.54 35.66868251506137 139.73905282787283 12.56</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66855513879494 139.73892219291122 12.56 35.66850922143435 139.73898940666575 12.56 35.66850922143435 139.73898940666575 31.54 35.66855513879494 139.73892219291122 31.54 35.66855513879494 139.73892219291122 12.56</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66850922143435 139.73898940666575 12.56 35.66863659754242 139.73911993119955 12.56 35.66863659754242 139.73911993119955 31.54 35.66850922143435 139.73898940666575 31.54 35.66850922143435 139.73898940666575 12.56</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66863659754242 139.73911993119955 12.56 35.66868251506137 139.73905282787283 12.56 35.66868251506137 139.73905282787283 31.54 35.66863659754242 139.73911993119955 31.54 35.66863659754242 139.73911993119955 12.56</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66868251506137 139.73905282787283 31.54 35.66855513879494 139.73892219291122 31.54 35.66850922143435 139.73898940666575 31.54 35.66863659754242 139.73911993119955 31.54 35.66868251506137 139.73905282787283 31.54</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-3c4b7016-566b-4101-a1a5-9f85c9c23e02"/>
							<gml:surfaceMember xlink:href="#poly-6dcb2a7e-b22f-4f1c-9d04-df690c9ef956"/>
							<gml:surfaceMember xlink:href="#poly-0a3aed02-1da5-439e-b47b-7f570c1d4c24"/>
							<gml:surfaceMember xlink:href="#poly-d79b7b94-f539-440b-902c-b64462ef6ff6"/>
							<gml:surfaceMember xlink:href="#poly-189b18d5-2e39-4238-93aa-8cd234d266f8"/>
							<gml:surfaceMember xlink:href="#poly-b9d5a281-25ad-4653-8b83-032ff9dd972c"/>
							<gml:surfaceMember xlink:href="#poly-7d5e2bd8-eca3-454b-acaa-8f1b7a004016"/>
							<gml:surfaceMember xlink:href="#poly-79aeec71-7dd1-4867-8092-fafd07d8f958"/>
							<gml:surfaceMember xlink:href="#poly-64516ff2-ef5b-4efa-b0be-4b4635e47972"/>
							<gml:surfaceMember xlink:href="#poly-a6ab9835-75b5-437c-b66b-9510bc2d0b6a"/>
							<gml:surfaceMember xlink:href="#poly-94cf9ea4-4b5a-47f8-ae87-1347895c0093"/>
							<gml:surfaceMember xlink:href="#poly-5889e9b0-8319-4281-9a5c-b0412944f22c"/>
							<gml:surfaceMember xlink:href="#poly-af1e45d2-ef73-4500-8627-81e9c406a572"/>
							<gml:surfaceMember xlink:href="#poly-7419dd62-bca8-46ef-9f21-676f31e7f954"/>
							<gml:surfaceMember xlink:href="#poly-e497f64a-b2bc-49db-8f71-8f4bfdb33984"/>
							<gml:surfaceMember xlink:href="#poly-e5a68402-0912-4932-abea-6b506e42aef4"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_0dc4527b-8a70-4f84-a3aa-f66431ad65b3_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a93bc28e-e3c3-4fb3-9b48-ab7bbde00578">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66855394057718 139.73894596533063 31.515 35.668547310164186 139.73893917984142 31.515 35.66855550325839 139.73892718527765 31.515 35.668562124666984 139.73893398182315 31.515 35.66855394057718 139.73894596533063 31.515</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fe3ae69c-1f02-4bea-ba6a-3f21c85e4734">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66851415962291 139.7389876997711 31.515 35.66852168646804 139.73897667804957 31.515 35.66852882206298 139.73898399315343 31.515 35.66852130423092 139.73899501486468 31.515 35.66851415962291 139.7389876997711 31.515</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2ed72a67-c915-450c-bb10-2f0e76a7983a">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66864127303147 139.73908200472016 35.32 35.66863183746294 139.73909583438032 35.32 35.668619929784384 139.73908363148067 35.32 35.668629365351535 139.7390698018211 35.32 35.66864127303147 139.73908200472016 35.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4b53e09d-de07-4082-8dba-cee4539b4329">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4b53e09d-de07-4082-8dba-cee4539b4329_0">
											<gml:posList>35.66851415962291 139.7389876997711 32.926 35.66851415962291 139.7389876997711 31.515 35.66852130423092 139.73899501486468 31.515 35.66852130423092 139.73899501486468 32.926 35.66851415962291 139.7389876997711 32.926</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5c8f150e-6926-4e42-933d-ac210b6f99b8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5c8f150e-6926-4e42-933d-ac210b6f99b8_0">
											<gml:posList>35.66852168646804 139.73897667804957 31.515 35.66851415962291 139.7389876997711 31.515 35.66851415962291 139.7389876997711 32.926 35.66852168646804 139.73897667804957 32.926 35.66852168646804 139.73897667804957 31.515</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b3c6cd6d-503a-4494-831c-468cd87fc0d8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b3c6cd6d-503a-4494-831c-468cd87fc0d8_0">
											<gml:posList>35.66851415962291 139.7389876997711 32.926 35.66852130423092 139.73899501486468 32.926 35.66852882206298 139.73898399315343 32.926 35.66852168646804 139.73897667804957 32.926 35.66851415962291 139.7389876997711 32.926</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-01151d39-970a-4152-a734-ac99eff5f1a0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-01151d39-970a-4152-a734-ac99eff5f1a0_0">
											<gml:posList>35.66852882206298 139.73898399315343 31.515 35.66852882206298 139.73898399315343 32.926 35.66852130423092 139.73899501486468 32.926 35.66852130423092 139.73899501486468 31.515 35.66852882206298 139.73898399315343 31.515</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-819a64b4-4474-4422-beb4-029f0757200d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-819a64b4-4474-4422-beb4-029f0757200d_0">
											<gml:posList>35.66852168646804 139.73897667804957 31.515 35.66852168646804 139.73897667804957 32.926 35.66852882206298 139.73898399315343 32.926 35.66852882206298 139.73898399315343 31.515 35.66852168646804 139.73897667804957 31.515</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-49f3c42a-65d9-4092-91eb-3d17f27bd3e2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-49f3c42a-65d9-4092-91eb-3d17f27bd3e2_0">
											<gml:posList>35.668547310164186 139.73893917984142 31.515 35.66855394057718 139.73894596533063 31.515 35.66855394057718 139.73894596533063 32.926 35.668547310164186 139.73893917984142 32.926 35.668547310164186 139.73893917984142 31.515</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2bea5703-7a5f-4c02-a2e3-1e5741aeca32">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2bea5703-7a5f-4c02-a2e3-1e5741aeca32_0">
											<gml:posList>35.66855550325839 139.73892718527765 31.515 35.668547310164186 139.73893917984142 31.515 35.668547310164186 139.73893917984142 32.926 35.66855550325839 139.73892718527765 32.926 35.66855550325839 139.73892718527765 31.515</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ef9b04a5-848f-4383-8361-125314814145">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ef9b04a5-848f-4383-8361-125314814145_0">
											<gml:posList>35.66855550325839 139.73892718527765 32.926 35.668547310164186 139.73893917984142 32.926 35.66855394057718 139.73894596533063 32.926 35.668562124666984 139.73893398182315 32.926 35.66855550325839 139.73892718527765 32.926</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9110fcb9-4683-4948-88d4-736a07ce5685">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9110fcb9-4683-4948-88d4-736a07ce5685_0">
											<gml:posList>35.668562124666984 139.73893398182315 32.926 35.66855394057718 139.73894596533063 32.926 35.66855394057718 139.73894596533063 31.515 35.668562124666984 139.73893398182315 31.515 35.668562124666984 139.73893398182315 32.926</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-da75302b-eedd-4e8a-8876-1b681f9f7c96">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-da75302b-eedd-4e8a-8876-1b681f9f7c96_0">
											<gml:posList>35.668562124666984 139.73893398182315 31.515 35.66855550325839 139.73892718527765 31.515 35.66855550325839 139.73892718527765 32.926 35.668562124666984 139.73893398182315 32.926 35.668562124666984 139.73893398182315 31.515</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e7e89a3b-807e-4efb-bdc4-2902e36e4036">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e7e89a3b-807e-4efb-bdc4-2902e36e4036_0">
											<gml:posList>35.668629365351535 139.7390698018211 35.32 35.668619929784384 139.73908363148067 35.32 35.668619929784384 139.73908363148067 36.004 35.668629365351535 139.7390698018211 36.004 35.668629365351535 139.7390698018211 35.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6657efd3-49ad-47bb-8f3f-faae06f9519d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6657efd3-49ad-47bb-8f3f-faae06f9519d_0">
											<gml:posList>35.668619929784384 139.73908363148067 35.32 35.66863183746294 139.73909583438032 35.32 35.66863183746294 139.73909583438032 36.004 35.668619929784384 139.73908363148067 36.004 35.668619929784384 139.73908363148067 35.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9e082ed8-f922-4a84-b428-58685b9b4fd4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9e082ed8-f922-4a84-b428-58685b9b4fd4_0">
											<gml:posList>35.668619929784384 139.73908363148067 36.004 35.66863183746294 139.73909583438032 36.004 35.66864127303147 139.73908200472016 36.004 35.668629365351535 139.7390698018211 36.004 35.668619929784384 139.73908363148067 36.004</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1760354e-6617-4418-b559-048d6dbfac48">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1760354e-6617-4418-b559-048d6dbfac48_0">
											<gml:posList>35.66864127303147 139.73908200472016 35.32 35.668629365351535 139.7390698018211 35.32 35.668629365351535 139.7390698018211 36.004 35.66864127303147 139.73908200472016 36.004 35.66864127303147 139.73908200472016 35.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ad31611f-12b9-4148-a4b9-7d710007f983">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ad31611f-12b9-4148-a4b9-7d710007f983_0">
											<gml:posList>35.66864127303147 139.73908200472016 36.004 35.66863183746294 139.73909583438032 36.004 35.66863183746294 139.73909583438032 35.32 35.66864127303147 139.73908200472016 35.32 35.66864127303147 139.73908200472016 36.004</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_0dc4527b-8a70-4f84-a3aa-f66431ad65b3_BuildingInstallation_1041">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-af784113-b6b4-43e8-8028-332ef1aaff62">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66860905506822 139.73899775044825 31.515 35.66862005166838 139.7390090596779 31.515 35.66860630342176 139.73902913541397 31.515 35.66859531584582 139.73901783721888 31.515 35.66860905506822 139.73899775044825 31.515</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a74681da-5145-4a7c-b755-b8d5c5f760cf">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66866086910291 139.7390822799284 32.967 35.66862492954853 139.7390454395213 32.967 35.6686457996775 139.73901517097613 32.967 35.66868164904322 139.73905193416306 32.967 35.66866086910291 139.7390822799284 32.967</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-373b798f-2029-4dea-be03-e2d57b183f3b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-373b798f-2029-4dea-be03-e2d57b183f3b_0">
											<gml:posList>35.66862005166838 139.7390090596779 31.515 35.66860905506822 139.73899775044825 31.515 35.66860905506822 139.73899775044825 34.157 35.66862005166838 139.7390090596779 34.157 35.66862005166838 139.7390090596779 31.515</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9e6f037b-b4ea-4cab-8705-f9bbc34a0303">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9e6f037b-b4ea-4cab-8705-f9bbc34a0303_0">
											<gml:posList>35.66859531584582 139.73901783721888 31.515 35.66859531584582 139.73901783721888 34.157 35.66860905506822 139.73899775044825 34.157 35.66860905506822 139.73899775044825 31.515 35.66859531584582 139.73901783721888 31.515</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5a0757cf-357f-434f-be3a-56ce6c647c6a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5a0757cf-357f-434f-be3a-56ce6c647c6a_0">
											<gml:posList>35.66860905506822 139.73899775044825 34.157 35.66859531584582 139.73901783721888 34.157 35.66860630342176 139.73902913541397 34.157 35.66862005166838 139.7390090596779 34.157 35.66860905506822 139.73899775044825 34.157</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b3a31066-a5b7-433e-851a-5a413bf9afc6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b3a31066-a5b7-433e-851a-5a413bf9afc6_0">
											<gml:posList>35.66862005166838 139.7390090596779 31.515 35.66862005166838 139.7390090596779 34.157 35.66860630342176 139.73902913541397 34.157 35.66860630342176 139.73902913541397 31.515 35.66862005166838 139.7390090596779 31.515</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c691064f-ed5c-43ab-9cdd-765a47417938">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c691064f-ed5c-43ab-9cdd-765a47417938_0">
											<gml:posList>35.66859531584582 139.73901783721888 31.515 35.66860630342176 139.73902913541397 31.515 35.66860630342176 139.73902913541397 34.157 35.66859531584582 139.73901783721888 34.157 35.66859531584582 139.73901783721888 31.515</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-345bdc6b-991a-44e9-a6b2-bbd98a38499d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-345bdc6b-991a-44e9-a6b2-bbd98a38499d_0">
											<gml:posList>35.66862492954853 139.7390454395213 34.951 35.6686457996775 139.73901517097613 34.951 35.6686457996775 139.73901517097613 32.967 35.66862492954853 139.7390454395213 32.967 35.66862492954853 139.7390454395213 34.951</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-134dd4b3-77f2-4feb-bd8f-b21c492a5293">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-134dd4b3-77f2-4feb-bd8f-b21c492a5293_0">
											<gml:posList>35.6686457996775 139.73901517097613 34.951 35.66868164905187 139.73905194520907 34.951 35.66868164904322 139.73905193416306 32.967 35.6686457996775 139.73901517097613 32.967 35.6686457996775 139.73901517097613 34.951</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7805aeef-541e-45ec-a1bc-0d5909e84dc8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7805aeef-541e-45ec-a1bc-0d5909e84dc8_0">
											<gml:posList>35.66868164905187 139.73905194520907 34.951 35.6686457996775 139.73901517097613 34.951 35.66862492954853 139.7390454395213 34.951 35.668660878116626 139.73908227991782 34.951 35.66868164905187 139.73905194520907 34.951</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-31edaff2-b1a6-4bca-ba88-956819e707c0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-31edaff2-b1a6-4bca-ba88-956819e707c0_0">
											<gml:posList>35.66862492954853 139.7390454395213 34.951 35.66862492954853 139.7390454395213 32.967 35.66866086910291 139.7390822799284 32.967 35.668660878116626 139.73908227991782 34.951 35.66862492954853 139.7390454395213 34.951</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c61c6d46-37da-4223-83d6-2e5f844445d9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c61c6d46-37da-4223-83d6-2e5f844445d9_0">
											<gml:posList>35.66868164905187 139.73905194520907 34.951 35.668660878116626 139.73908227991782 34.951 35.66866086910291 139.7390822799284 32.967 35.66868164904322 139.73905193416306 32.967 35.66868164905187 139.73905194520907 34.951</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-3c4b7016-566b-4101-a1a5-9f85c9c23e02">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3c4b7016-566b-4101-a1a5-9f85c9c23e02">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3c4b7016-566b-4101-a1a5-9f85c9c23e02">
											<gml:posList>35.66868251506135 139.73905282787283 12.56 35.668636597542424 139.73911993119955 12.56 35.66850922143433 139.73898940666572 12.56 35.66855513879492 139.73892219291122 12.56 35.66868251506135 139.73905282787283 12.56</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-6dcb2a7e-b22f-4f1c-9d04-df690c9ef956">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6dcb2a7e-b22f-4f1c-9d04-df690c9ef956">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6dcb2a7e-b22f-4f1c-9d04-df690c9ef956">
											<gml:posList>35.66855550325839 139.73892718527765 32.967 35.66855513879492 139.73892219291122 32.967 35.66850922143433 139.73898940666572 32.967 35.66851329529191 139.73898896003232 32.967 35.66855550325839 139.73892718527765 32.967</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-0a3aed02-1da5-439e-b47b-7f570c1d4c24">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0a3aed02-1da5-439e-b47b-7f570c1d4c24">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0a3aed02-1da5-439e-b47b-7f570c1d4c24">
											<gml:posList>35.66859972885084 139.73908215296765 32.967 35.66860158356857 139.73907945556005 32.967 35.66851329529191 139.73898896003232 32.967 35.66850922143433 139.73898940666572 32.967 35.66859972885084 139.73908215296765 32.967</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d79b7b94-f539-440b-902c-b64462ef6ff6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d79b7b94-f539-440b-902c-b64462ef6ff6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d79b7b94-f539-440b-902c-b64462ef6ff6">
											<gml:posList>35.66864382770494 139.73901776911046 31.515 35.66855550325839 139.73892718527765 31.515 35.66851329529191 139.73898896003232 31.515 35.66860158356857 139.73907945556005 31.515 35.66864382770494 139.73901776911046 31.515</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-189b18d5-2e39-4238-93aa-8cd234d266f8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-189b18d5-2e39-4238-93aa-8cd234d266f8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-189b18d5-2e39-4238-93aa-8cd234d266f8">
											<gml:posList>35.668645682403906 139.73901504960784 32.967 35.66855513879492 139.73892219291122 32.967 35.66855550325839 139.73892718527765 32.967 35.66864382770494 139.73901776911046 32.967 35.668645682403906 139.73901504960784 32.967</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b9d5a281-25ad-4653-8b83-032ff9dd972c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b9d5a281-25ad-4653-8b83-032ff9dd972c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b9d5a281-25ad-4653-8b83-032ff9dd972c">
											<gml:posList>35.66862492954853 139.7390454395213 35.32 35.66859972885084 139.73908215296765 35.32 35.668636642645616 139.73911997533065 35.32 35.66866175314827 139.73908317361708 35.32 35.66862492954853 139.7390454395213 35.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-7d5e2bd8-eca3-454b-acaa-8f1b7a004016">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7d5e2bd8-eca3-454b-acaa-8f1b7a004016">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7d5e2bd8-eca3-454b-acaa-8f1b7a004016">
											<gml:posList>35.66866174413454 139.73908317362768 32.967 35.66868251506135 139.73905282787283 32.967 35.668645682403906 139.73901504960784 32.967 35.66864382770494 139.73901776911046 32.967 35.66862492954853 139.7390454395213 32.967 35.66866174413454 139.73908317362768 32.967</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-79aeec71-7dd1-4867-8092-fafd07d8f958">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-79aeec71-7dd1-4867-8092-fafd07d8f958">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-79aeec71-7dd1-4867-8092-fafd07d8f958">
											<gml:posList>35.66864382770494 139.73901776911046 31.515 35.66864382770494 139.73901776911046 32.967 35.66855550325839 139.73892718527765 32.967 35.66855550325839 139.73892718527765 31.515 35.66864382770494 139.73901776911046 31.515</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-64516ff2-ef5b-4efa-b0be-4b4635e47972">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-64516ff2-ef5b-4efa-b0be-4b4635e47972">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-64516ff2-ef5b-4efa-b0be-4b4635e47972">
											<gml:posList>35.66851329529191 139.73898896003232 31.515 35.66851329529191 139.73898896003232 32.967 35.66860158356857 139.73907945556005 32.967 35.66860158356857 139.73907945556005 31.515 35.66851329529191 139.73898896003232 31.515</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a6ab9835-75b5-437c-b66b-9510bc2d0b6a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a6ab9835-75b5-437c-b66b-9510bc2d0b6a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a6ab9835-75b5-437c-b66b-9510bc2d0b6a">
											<gml:posList>35.66850922143433 139.73898940666572 32.967 35.66855513879492 139.73892219291122 32.967 35.66855513879492 139.73892219291122 12.56 35.66850922143433 139.73898940666572 12.56 35.66850922143433 139.73898940666572 32.967</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-94cf9ea4-4b5a-47f8-ae87-1347895c0093">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-94cf9ea4-4b5a-47f8-ae87-1347895c0093">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-94cf9ea4-4b5a-47f8-ae87-1347895c0093">
											<gml:posList>35.66855550325839 139.73892718527765 31.515 35.66855550325839 139.73892718527765 32.967 35.66851329529191 139.73898896003232 32.967 35.66851329529191 139.73898896003232 31.515 35.66855550325839 139.73892718527765 31.515</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5889e9b0-8319-4281-9a5c-b0412944f22c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5889e9b0-8319-4281-9a5c-b0412944f22c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5889e9b0-8319-4281-9a5c-b0412944f22c">
											<gml:posList>35.66868251506135 139.73905282787283 12.56 35.66855513879492 139.73892219291122 12.56 35.66855513879492 139.73892219291122 32.967 35.668645682403906 139.73901504960784 32.967 35.66868251506135 139.73905282787283 32.967 35.66868251506135 139.73905282787283 12.56</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-af1e45d2-ef73-4500-8627-81e9c406a572">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-af1e45d2-ef73-4500-8627-81e9c406a572">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-af1e45d2-ef73-4500-8627-81e9c406a572">
											<gml:posList>35.66859972885084 139.73908215296765 32.967 35.66859972885084 139.73908215296765 35.32 35.66862492954853 139.7390454395213 35.32 35.66862492954853 139.7390454395213 32.967 35.66864382770494 139.73901776911046 32.967 35.66864382770494 139.73901776911046 31.515 35.66860158356857 139.73907945556005 31.515 35.66860158356857 139.73907945556005 32.967 35.66859972885084 139.73908215296765 32.967</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7419dd62-bca8-46ef-9f21-676f31e7f954">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7419dd62-bca8-46ef-9f21-676f31e7f954">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7419dd62-bca8-46ef-9f21-676f31e7f954">
											<gml:posList>35.66850922143433 139.73898940666572 12.56 35.668636597542424 139.73911993119955 12.56 35.668636642645616 139.73911997533065 35.32 35.66859972885084 139.73908215296765 35.32 35.66859972885084 139.73908215296765 32.967 35.66850922143433 139.73898940666572 32.967 35.66850922143433 139.73898940666572 12.56</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e497f64a-b2bc-49db-8f71-8f4bfdb33984">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e497f64a-b2bc-49db-8f71-8f4bfdb33984">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e497f64a-b2bc-49db-8f71-8f4bfdb33984">
											<gml:posList>35.66862492954853 139.7390454395213 32.967 35.66862492954853 139.7390454395213 35.32 35.66866175314827 139.73908317361708 35.32 35.66866174413454 139.73908317362768 32.967 35.66862492954853 139.7390454395213 32.967</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e5a68402-0912-4932-abea-6b506e42aef4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e5a68402-0912-4932-abea-6b506e42aef4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e5a68402-0912-4932-abea-6b506e42aef4">
											<gml:posList>35.668636597542424 139.73911993119955 12.56 35.66868251506135 139.73905282787283 12.56 35.66868251506135 139.73905282787283 32.967 35.66866174413454 139.73908317362768 32.967 35.66866175314827 139.73908317361708 35.32 35.668636642645616 139.73911997533065 35.32 35.668636597542424 139.73911993119955 12.56</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-3395</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">146.1375</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1210</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>4</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>