<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_0e17534c-b696-41e7-aa0f-85218ed09bf1">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>3</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001003</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">402</bldg:usage>
			<bldg:measuredHeight uom="m">18.6</bldg:measuredHeight>
			<bldg:storeysAboveGround>6</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>1</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.67392941425493 139.73825979776677 0 35.674036006564215 139.73820907717973 0 35.67398495145404 139.73804774465717 0 35.67387835912469 139.73809835495877 0 35.67392941425493 139.73825979776677 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67392941425493 139.73825979776677 8.497 35.67387835912469 139.73809835495877 8.497 35.67398495145404 139.73804774465717 8.497 35.674036006564215 139.73820907717973 8.497 35.67392941425493 139.73825979776677 8.497</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67392941425493 139.73825979776677 8.497 35.674036006564215 139.73820907717973 8.497 35.674036006564215 139.73820907717973 27.05 35.67392941425493 139.73825979776677 27.05 35.67392941425493 139.73825979776677 8.497</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.674036006564215 139.73820907717973 8.497 35.67398495145404 139.73804774465717 8.497 35.67398495145404 139.73804774465717 27.05 35.674036006564215 139.73820907717973 27.05 35.674036006564215 139.73820907717973 8.497</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67398495145404 139.73804774465717 8.497 35.67387835912469 139.73809835495877 8.497 35.67387835912469 139.73809835495877 27.05 35.67398495145404 139.73804774465717 27.05 35.67398495145404 139.73804774465717 8.497</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67387835912469 139.73809835495877 8.497 35.67392941425493 139.73825979776677 8.497 35.67392941425493 139.73825979776677 27.05 35.67387835912469 139.73809835495877 27.05 35.67387835912469 139.73809835495877 8.497</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67392941425493 139.73825979776677 27.05 35.674036006564215 139.73820907717973 27.05 35.67398495145404 139.73804774465717 27.05 35.67387835912469 139.73809835495877 27.05 35.67392941425493 139.73825979776677 27.05</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-9db5fbcd-b9a6-4f7f-a4f5-d9d62c0b6a3a"/>
							<gml:surfaceMember xlink:href="#poly-406f6c89-fa6a-4df7-b87b-01836aeed281"/>
							<gml:surfaceMember xlink:href="#poly-7f377e16-70a1-42e8-9442-892549ff9351"/>
							<gml:surfaceMember xlink:href="#poly-b1866353-d8a0-47a1-8f7b-4ea170d122b7"/>
							<gml:surfaceMember xlink:href="#poly-9dab4b0f-2ff5-4b0c-821c-74314844a3ac"/>
							<gml:surfaceMember xlink:href="#poly-ec90c1e1-3d4e-4500-b9d9-d871e8172cc8"/>
							<gml:surfaceMember xlink:href="#poly-e84912cc-58ad-40fc-8625-99394f221328"/>
							<gml:surfaceMember xlink:href="#poly-fc81c553-a068-428b-b663-cc5945a056a7"/>
							<gml:surfaceMember xlink:href="#poly-868c6944-49c1-48d7-a8df-20a407a891a9"/>
							<gml:surfaceMember xlink:href="#poly-592b27aa-26bc-4e6f-a6e0-5ee8432929e7"/>
							<gml:surfaceMember xlink:href="#poly-3e88765b-da1e-4ef5-a8d6-e8f32ec1e373"/>
							<gml:surfaceMember xlink:href="#poly-52a504ca-890f-4f03-b3e5-800460c877f9"/>
							<gml:surfaceMember xlink:href="#poly-d791c2e5-a900-4688-922f-2d426abdd97f"/>
							<gml:surfaceMember xlink:href="#poly-7de41a67-52e0-40ce-bb17-80eb6577b0ff"/>
							<gml:surfaceMember xlink:href="#poly-bb69be5e-3a0f-4e8e-8958-17862eab4013"/>
							<gml:surfaceMember xlink:href="#poly-bca290f1-230d-4a37-9572-df80eeb5e4f9"/>
							<gml:surfaceMember xlink:href="#poly-91bcef26-a195-46d6-85c2-e9ee671244b9"/>
							<gml:surfaceMember xlink:href="#poly-143d20e6-caf8-43f2-b4ad-7f68f36228c3"/>
							<gml:surfaceMember xlink:href="#poly-16be684f-758d-4524-b16b-c0564633c2eb"/>
							<gml:surfaceMember xlink:href="#poly-7b617835-dc81-4221-91ef-52162d0f8baa"/>
							<gml:surfaceMember xlink:href="#poly-73345f83-0282-4228-aaed-60bbccc8d575"/>
							<gml:surfaceMember xlink:href="#poly-dae4e5ce-3b6b-43ef-abce-0e110fed2959"/>
							<gml:surfaceMember xlink:href="#poly-6de4c745-52b7-4c4f-930e-55ca741e4c0a"/>
							<gml:surfaceMember xlink:href="#poly-4b757017-9e8a-4a4e-9d44-a19520b45c03"/>
							<gml:surfaceMember xlink:href="#poly-aff25956-b51b-460d-b16f-0cf8e98355ce"/>
							<gml:surfaceMember xlink:href="#poly-caa1ce30-2c55-41b9-8fb1-21aa15d44e58"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_0e17534c-b696-41e7-aa0f-85218ed09bf1_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1d7d2ee8-8fa1-4fb1-8e6b-9b4ea5873af8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1d7d2ee8-8fa1-4fb1-8e6b-9b4ea5873af8_0">
											<gml:posList>35.67391253036869 139.73818983665467 30.496 35.67391676840668 139.73820325342191 30.496 35.67391676840668 139.73820325342191 30.785 35.67391253036869 139.73818983665467 30.785 35.67391253036869 139.73818983665467 30.496</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8d3a93e9-3afd-4abf-82e0-7d213f1cf377">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8d3a93e9-3afd-4abf-82e0-7d213f1cf377_0">
											<gml:posList>35.67391676840668 139.73820325342191 30.785 35.67391676840668 139.73820325342191 30.496 35.67392025541465 139.73820160331874 30.496 35.67392025541465 139.73820160331874 30.785 35.67391676840668 139.73820325342191 30.785</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fc81c77e-6c99-4392-bedc-71214dc8f4e3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fc81c77e-6c99-4392-bedc-71214dc8f4e3_0">
											<gml:posList>35.67390832256903 139.7381918742497 30.785 35.67391434908414 139.7382100500417 30.785 35.67391434908414 139.7382100500417 32.895 35.67390832256903 139.7381918742497 32.895 35.67390832256903 139.7381918742497 30.785</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d5083896-c02d-4a66-9a59-20db6ca7c4f8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d5083896-c02d-4a66-9a59-20db6ca7c4f8_0">
											<gml:posList>35.67391253036869 139.73818983665467 30.785 35.67390832256903 139.7381918742497 30.785 35.67390832256903 139.7381918742497 32.895 35.67391583714579 139.73818824199864 32.895 35.67391583714579 139.73818824199864 30.496 35.67391253036869 139.73818983665467 30.496 35.67391253036869 139.73818983665467 30.785</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2f4ba8c4-0259-4d8e-9652-5d5930e5b510">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2f4ba8c4-0259-4d8e-9652-5d5930e5b510_0">
											<gml:posList>35.67391434908414 139.7382100500417 32.895 35.67392185464774 139.73820641780276 32.895 35.67391583714579 139.73818824199864 32.895 35.67390832256903 139.7381918742497 32.895 35.67391434908414 139.7382100500417 32.895</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-981cfa2b-7f80-40c6-917e-4bd21677dd68">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-981cfa2b-7f80-40c6-917e-4bd21677dd68_0">
											<gml:posList>35.67392185464774 139.73820641780276 32.895 35.67391434908414 139.7382100500417 32.895 35.67391434908414 139.7382100500417 30.785 35.67392185464774 139.73820641780276 30.785 35.67392185464774 139.73820641780276 32.895</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-db30db37-524e-44f9-8d50-04066480abea">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-db30db37-524e-44f9-8d50-04066480abea_0">
											<gml:posList>35.67392025541465 139.73820160331874 30.785 35.67392025541465 139.73820160331874 30.496 35.67391583714579 139.73818824199864 30.496 35.67391583714579 139.73818824199864 32.895 35.67392185464774 139.73820641780276 32.895 35.67392185464774 139.73820641780276 30.785 35.67392025541465 139.73820160331874 30.785</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cd9d1479-ac71-475e-b0fd-f9bfb2c3d631">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cd9d1479-ac71-475e-b0fd-f9bfb2c3d631_0">
											<gml:posList>35.67397576558854 139.73813779767227 34.808 35.67397576558854 139.73813779767227 33.287 35.673982768719156 139.73815992705448 33.287 35.673982768719156 139.73815992705448 34.808 35.67397576558854 139.73813779767227 34.808</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1f839791-7dbb-4053-bd1c-b581f4273d4a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1f839791-7dbb-4053-bd1c-b581f4273d4a_0">
											<gml:posList>35.67397576558854 139.73813779767227 34.808 35.67399429985146 139.73812898244472 34.808 35.67399429985146 139.73812898244472 33.287 35.67397576558854 139.73813779767227 33.287 35.67397576558854 139.73813779767227 34.808</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fefced15-06e9-46b1-90c4-2b953fc29d3f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fefced15-06e9-46b1-90c4-2b953fc29d3f_0">
											<gml:posList>35.67399429985146 139.73812898244472 34.808 35.67397576558854 139.73813779767227 34.808 35.673982768719156 139.73815992705448 34.808 35.674001302983676 139.73815111183129 34.808 35.67399429985146 139.73812898244472 34.808</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-dc9e410c-0868-4ca1-b486-55bab6877574">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-dc9e410c-0868-4ca1-b486-55bab6877574_0">
											<gml:posList>35.674001302983676 139.73815111183129 34.808 35.673982768719156 139.73815992705448 34.808 35.673982768719156 139.73815992705448 33.287 35.674001302983676 139.73815111183129 33.287 35.674001302983676 139.73815111183129 34.808</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e7954c87-e3f1-4fff-a223-7c56d21c91da">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e7954c87-e3f1-4fff-a223-7c56d21c91da_0">
											<gml:posList>35.67399429985146 139.73812898244472 34.808 35.674001302983676 139.73815111183129 34.808 35.674001302983676 139.73815111183129 33.287 35.67399429985146 139.73812898244472 33.287 35.67399429985146 139.73812898244472 34.808</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1e538dc1-b630-491a-bbbd-59a65f4389fb">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67392025541465 139.73820160331874 30.785 35.67392185464774 139.73820641780276 30.785 35.67391434908414 139.7382100500417 30.785 35.67390832256903 139.7381918742497 30.785 35.67391253036869 139.73818983665467 30.785 35.67391676840668 139.73820325342191 30.785 35.67392025541465 139.73820160331874 30.785</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d7a488c3-34b1-4d65-8bed-7a6a5a1f4b19">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67391583714579 139.73818824199864 30.496 35.67392025541465 139.73820160331874 30.496 35.67391676840668 139.73820325342191 30.496 35.67391253036869 139.73818983665467 30.496 35.67391583714579 139.73818824199864 30.496</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8fc0fae6-147a-4f9b-9304-1b1849345c06">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.673982768719156 139.73815992705448 33.287 35.67397576558854 139.73813779767227 33.287 35.67399429985146 139.73812898244472 33.287 35.674001302983676 139.73815111183129 33.287 35.673982768719156 139.73815992705448 33.287</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-9db5fbcd-b9a6-4f7f-a4f5-d9d62c0b6a3a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9db5fbcd-b9a6-4f7f-a4f5-d9d62c0b6a3a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9db5fbcd-b9a6-4f7f-a4f5-d9d62c0b6a3a">
											<gml:posList>35.6739294142549 139.73825979776674 8.497 35.67387835912469 139.73809835495877 8.497 35.67398495145402 139.73804774465714 8.497 35.67403600656419 139.73820907717973 8.497 35.6739294142549 139.73825979776674 8.497</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-406f6c89-fa6a-4df7-b87b-01836aeed281">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-406f6c89-fa6a-4df7-b87b-01836aeed281">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-406f6c89-fa6a-4df7-b87b-01836aeed281">
											<gml:posList>35.67398495145402 139.73804774465714 22.413 35.67387835912469 139.73809835495877 22.413 35.67389739863768 139.73815854814123 30.785 35.67395887617194 139.7381293117286 30.785 35.674003981925935 139.73810787163774 30.785 35.67398495145402 139.73804774465714 22.413</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-7f377e16-70a1-42e8-9442-892549ff9351">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7f377e16-70a1-42e8-9442-892549ff9351">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7f377e16-70a1-42e8-9442-892549ff9351">
											<gml:posList>35.67395887617194 139.7381293117286 33.614 35.673962852915466 139.73813145007603 33.614 35.6740022280951 139.73811273429465 33.614 35.674003981925935 139.73810787163774 33.614 35.67395887617194 139.7381293117286 33.614</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b1866353-d8a0-47a1-8f7b-4ea170d122b7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b1866353-d8a0-47a1-8f7b-4ea170d122b7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b1866353-d8a0-47a1-8f7b-4ea170d122b7">
											<gml:posList>35.674003981925935 139.73810787163774 33.614 35.6740022280951 139.73811273429465 33.614 35.674016640965384 139.73815824087433 33.614 35.674020608712105 139.73816040132888 33.614 35.674003981925935 139.73810787163774 33.614</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-9dab4b0f-2ff5-4b0c-821c-74314844a3ac">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9dab4b0f-2ff5-4b0c-821c-74314844a3ac">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9dab4b0f-2ff5-4b0c-821c-74314844a3ac">
											<gml:posList>35.674016640965384 139.73815824087433 33.287 35.6740022280951 139.73811273429465 33.287 35.673962852915466 139.73813145007603 33.287 35.67397725676501 139.7381769566474 33.287 35.674016640965384 139.73815824087433 33.287</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ec90c1e1-3d4e-4500-b9d9-d871e8172cc8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ec90c1e1-3d4e-4500-b9d9-d871e8172cc8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ec90c1e1-3d4e-4500-b9d9-d871e8172cc8">
											<gml:posList>35.67395887617194 139.7381293117286 30.785 35.67389739863768 139.73815854814123 30.785 35.67390371996869 139.73816197617413 30.785 35.6739606472799 139.7381348992821 30.785 35.67395887617194 139.7381293117286 30.785</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e84912cc-58ad-40fc-8625-99394f221328">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e84912cc-58ad-40fc-8625-99394f221328">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e84912cc-58ad-40fc-8625-99394f221328">
											<gml:posList>35.67397550294012 139.73818183034797 33.614 35.67397725676501 139.7381769566474 33.614 35.673962852915466 139.73813145007603 33.614 35.67395887617194 139.7381293117286 33.614 35.67397550294012 139.73818183034797 33.614</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-fc81c553-a068-428b-b663-cc5945a056a7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fc81c553-a068-428b-b663-cc5945a056a7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fc81c553-a068-428b-b663-cc5945a056a7">
											<gml:posList>35.6739737318256 139.73817623174568 30.496 35.6739606472799 139.7381348992821 30.496 35.67390371996869 139.73816197617413 30.496 35.67391676840668 139.73820325342191 30.496 35.6739737318256 139.73817623174568 30.496</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-868c6944-49c1-48d7-a8df-20a407a891a9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-868c6944-49c1-48d7-a8df-20a407a891a9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-868c6944-49c1-48d7-a8df-20a407a891a9">
											<gml:posList>35.674020608712105 139.73816040132888 33.614 35.674016640965384 139.73815824087433 33.614 35.67397725676501 139.7381769566474 33.614 35.67397550294012 139.73818183034797 33.614 35.674020608712105 139.73816040132888 33.614</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-592b27aa-26bc-4e6f-a6e0-5ee8432929e7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-592b27aa-26bc-4e6f-a6e0-5ee8432929e7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-592b27aa-26bc-4e6f-a6e0-5ee8432929e7">
											<gml:posList>35.673913980272275 139.73821100049946 30.785 35.67391676840668 139.73820325342191 30.785 35.67390371996869 139.73816197617413 30.785 35.67389739863768 139.73815854814123 30.785 35.673913980272275 139.73821100049946 30.785</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-3e88765b-da1e-4ef5-a8d6-e8f32ec1e373">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3e88765b-da1e-4ef5-a8d6-e8f32ec1e373">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3e88765b-da1e-4ef5-a8d6-e8f32ec1e373">
											<gml:posList>35.673913980272275 139.73821100049946 30.785 35.67397550294012 139.73818183034797 30.785 35.6739737318256 139.73817623174568 30.785 35.67391676840668 139.73820325342191 30.785 35.673913980272275 139.73821100049946 30.785</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-52a504ca-890f-4f03-b3e5-800460c877f9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-52a504ca-890f-4f03-b3e5-800460c877f9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-52a504ca-890f-4f03-b3e5-800460c877f9">
											<gml:posList>35.67403600656419 139.73820907717973 22.413 35.674020608712105 139.73816040132888 30.785 35.67397550294012 139.73818183034797 30.785 35.673913980272275 139.73821100049946 30.785 35.6739294142549 139.73825979776674 22.413 35.67403600656419 139.73820907717973 22.413</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d791c2e5-a900-4688-922f-2d426abdd97f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d791c2e5-a900-4688-922f-2d426abdd97f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d791c2e5-a900-4688-922f-2d426abdd97f">
											<gml:posList>35.67398495145402 139.73804774465714 8.497 35.67387835912469 139.73809835495877 8.497 35.67387835912469 139.73809835495877 22.413 35.67398495145402 139.73804774465714 22.413 35.67398495145402 139.73804774465714 8.497</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7de41a67-52e0-40ce-bb17-80eb6577b0ff">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7de41a67-52e0-40ce-bb17-80eb6577b0ff">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7de41a67-52e0-40ce-bb17-80eb6577b0ff">
											<gml:posList>35.67395887617194 139.7381293117286 33.614 35.674003981925935 139.73810787163774 33.614 35.674003981925935 139.73810787163774 30.785 35.67395887617194 139.7381293117286 30.785 35.67395887617194 139.7381293117286 33.614</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-bb69be5e-3a0f-4e8e-8958-17862eab4013">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bb69be5e-3a0f-4e8e-8958-17862eab4013">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bb69be5e-3a0f-4e8e-8958-17862eab4013">
											<gml:posList>35.673962852915466 139.73813145007603 33.614 35.673962852915466 139.73813145007603 33.287 35.6740022280951 139.73811273429465 33.287 35.6740022280951 139.73811273429465 33.614 35.673962852915466 139.73813145007603 33.614</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-bca290f1-230d-4a37-9572-df80eeb5e4f9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bca290f1-230d-4a37-9572-df80eeb5e4f9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bca290f1-230d-4a37-9572-df80eeb5e4f9">
											<gml:posList>35.674020608712105 139.73816040132888 30.785 35.67403600656419 139.73820907717973 22.413 35.67403600656419 139.73820907717973 8.497 35.67398495145402 139.73804774465714 8.497 35.67398495145402 139.73804774465714 22.413 35.674003981925935 139.73810787163774 30.785 35.674003981925935 139.73810787163774 33.614 35.674020608712105 139.73816040132888 33.614 35.674020608712105 139.73816040132888 30.785</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-91bcef26-a195-46d6-85c2-e9ee671244b9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-91bcef26-a195-46d6-85c2-e9ee671244b9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-91bcef26-a195-46d6-85c2-e9ee671244b9">
											<gml:posList>35.6740022280951 139.73811273429465 33.614 35.6740022280951 139.73811273429465 33.287 35.674016640965384 139.73815824087433 33.287 35.674016640965384 139.73815824087433 33.614 35.6740022280951 139.73811273429465 33.614</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-143d20e6-caf8-43f2-b4ad-7f68f36228c3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-143d20e6-caf8-43f2-b4ad-7f68f36228c3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-143d20e6-caf8-43f2-b4ad-7f68f36228c3">
											<gml:posList>35.6739606472799 139.7381348992821 30.496 35.6739606472799 139.7381348992821 30.785 35.67390371996869 139.73816197617413 30.785 35.67390371996869 139.73816197617413 30.496 35.6739606472799 139.7381348992821 30.496</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-16be684f-758d-4524-b16b-c0564633c2eb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-16be684f-758d-4524-b16b-c0564633c2eb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-16be684f-758d-4524-b16b-c0564633c2eb">
											<gml:posList>35.67397725676501 139.7381769566474 33.614 35.67397725676501 139.7381769566474 33.287 35.673962852915466 139.73813145007603 33.287 35.673962852915466 139.73813145007603 33.614 35.67397725676501 139.7381769566474 33.614</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7b617835-dc81-4221-91ef-52162d0f8baa">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7b617835-dc81-4221-91ef-52162d0f8baa">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7b617835-dc81-4221-91ef-52162d0f8baa">
											<gml:posList>35.6739606472799 139.7381348992821 30.785 35.6739606472799 139.7381348992821 30.496 35.6739737318256 139.73817623174568 30.496 35.6739737318256 139.73817623174568 30.785 35.67397550294012 139.73818183034797 30.785 35.67397550294012 139.73818183034797 33.614 35.67395887617194 139.7381293117286 33.614 35.67395887617194 139.7381293117286 30.785 35.6739606472799 139.7381348992821 30.785</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-73345f83-0282-4228-aaed-60bbccc8d575">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-73345f83-0282-4228-aaed-60bbccc8d575">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-73345f83-0282-4228-aaed-60bbccc8d575">
											<gml:posList>35.674016640965384 139.73815824087433 33.614 35.674016640965384 139.73815824087433 33.287 35.67397725676501 139.7381769566474 33.287 35.67397725676501 139.7381769566474 33.614 35.674016640965384 139.73815824087433 33.614</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-dae4e5ce-3b6b-43ef-abce-0e110fed2959">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-dae4e5ce-3b6b-43ef-abce-0e110fed2959">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-dae4e5ce-3b6b-43ef-abce-0e110fed2959">
											<gml:posList>35.674020608712105 139.73816040132888 33.614 35.67397550294012 139.73818183034797 33.614 35.67397550294012 139.73818183034797 30.785 35.674020608712105 139.73816040132888 30.785 35.674020608712105 139.73816040132888 33.614</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6de4c745-52b7-4c4f-930e-55ca741e4c0a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6de4c745-52b7-4c4f-930e-55ca741e4c0a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6de4c745-52b7-4c4f-930e-55ca741e4c0a">
											<gml:posList>35.67387835912469 139.73809835495877 22.413 35.67387835912469 139.73809835495877 8.497 35.6739294142549 139.73825979776674 8.497 35.6739294142549 139.73825979776674 22.413 35.673913980272275 139.73821100049946 30.785 35.67389739863768 139.73815854814123 30.785 35.67387835912469 139.73809835495877 22.413</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4b757017-9e8a-4a4e-9d44-a19520b45c03">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4b757017-9e8a-4a4e-9d44-a19520b45c03">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4b757017-9e8a-4a4e-9d44-a19520b45c03">
											<gml:posList>35.67391676840668 139.73820325342191 30.785 35.67391676840668 139.73820325342191 30.496 35.67390371996869 139.73816197617413 30.496 35.67390371996869 139.73816197617413 30.785 35.67391676840668 139.73820325342191 30.785</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-aff25956-b51b-460d-b16f-0cf8e98355ce">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-aff25956-b51b-460d-b16f-0cf8e98355ce">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-aff25956-b51b-460d-b16f-0cf8e98355ce">
											<gml:posList>35.67391676840668 139.73820325342191 30.785 35.6739737318256 139.73817623174568 30.785 35.6739737318256 139.73817623174568 30.496 35.67391676840668 139.73820325342191 30.496 35.67391676840668 139.73820325342191 30.785</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-caa1ce30-2c55-41b9-8fb1-21aa15d44e58">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-caa1ce30-2c55-41b9-8fb1-21aa15d44e58">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-caa1ce30-2c55-41b9-8fb1-21aa15d44e58">
											<gml:posList>35.6739294142549 139.73825979776674 8.497 35.67403600656419 139.73820907717973 8.497 35.67403600656419 139.73820907717973 22.413 35.6739294142549 139.73825979776674 22.413 35.6739294142549 139.73825979776674 8.497</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂三丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-9953</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">198.7442</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1002</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1242</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>5</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.03</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">12</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>