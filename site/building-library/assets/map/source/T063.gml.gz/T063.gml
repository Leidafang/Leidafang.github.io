<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_0f1f74e5-ef09-4fb2-8055-7f52df30bbae">
			<core:creationDate>2024-03-15</core:creationDate>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.672855682712516 139.746320527383 0 35.672910682454905 139.74630525650878 0 35.67290715329791 139.74628616075424 0 35.67285215355794 139.74630143164092 0 35.672855682712516 139.746320527383 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672855682712516 139.746320527383 11.277 35.67285215355794 139.74630143164092 11.277 35.67290715329791 139.74628616075424 11.277 35.672910682454905 139.74630525650878 11.277 35.672855682712516 139.746320527383 11.277</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672855682712516 139.746320527383 11.277 35.672910682454905 139.74630525650878 11.277 35.672910682454905 139.74630525650878 14.277 35.672855682712516 139.746320527383 14.277 35.672855682712516 139.746320527383 11.277</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672910682454905 139.74630525650878 11.277 35.67290715329791 139.74628616075424 11.277 35.67290715329791 139.74628616075424 14.277 35.672910682454905 139.74630525650878 14.277 35.672910682454905 139.74630525650878 11.277</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67290715329791 139.74628616075424 11.277 35.67285215355794 139.74630143164092 11.277 35.67285215355794 139.74630143164092 14.277 35.67290715329791 139.74628616075424 14.277 35.67290715329791 139.74628616075424 11.277</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67285215355794 139.74630143164092 11.277 35.672855682712516 139.746320527383 11.277 35.672855682712516 139.746320527383 14.277 35.67285215355794 139.74630143164092 14.277 35.67285215355794 139.74630143164092 11.277</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672855682712516 139.746320527383 14.277 35.672910682454905 139.74630525650878 14.277 35.67290715329791 139.74628616075424 14.277 35.67285215355794 139.74630143164092 14.277 35.672855682712516 139.746320527383 14.277</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-888c6a86-5431-402c-b86d-25bed43cb05a"/>
							<gml:surfaceMember xlink:href="#poly-2c826c6e-2caa-456c-88b8-99e3ad92e82a"/>
							<gml:surfaceMember xlink:href="#poly-a73ddfd9-3a56-428f-800b-7ebf36c6d54a"/>
							<gml:surfaceMember xlink:href="#poly-d7ac895b-a177-4721-984e-6165d8d586a5"/>
							<gml:surfaceMember xlink:href="#poly-6c7c68fc-6260-49d0-b0d4-106312c2e5ff"/>
							<gml:surfaceMember xlink:href="#poly-11c9d825-3132-450c-b41d-8daadb474451"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-888c6a86-5431-402c-b86d-25bed43cb05a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-888c6a86-5431-402c-b86d-25bed43cb05a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-888c6a86-5431-402c-b86d-25bed43cb05a">
											<gml:posList>35.67291067344118 139.74630525651853 11.277 35.67285567369879 139.74632052739278 11.277 35.672852144544215 139.7463014316507 11.277 35.672907144284196 139.74628616076404 11.277 35.67291067344118 139.74630525651853 11.277</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-2c826c6e-2caa-456c-88b8-99e3ad92e82a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2c826c6e-2caa-456c-88b8-99e3ad92e82a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2c826c6e-2caa-456c-88b8-99e3ad92e82a">
											<gml:posList>35.67285567369879 139.74632052739278 13.643 35.67291067344118 139.74630525651853 13.643 35.672907144284196 139.74628616076404 13.643 35.672852144544215 139.7463014316507 13.643 35.67285567369879 139.74632052739278 13.643</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a73ddfd9-3a56-428f-800b-7ebf36c6d54a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a73ddfd9-3a56-428f-800b-7ebf36c6d54a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a73ddfd9-3a56-428f-800b-7ebf36c6d54a">
											<gml:posList>35.672907144284196 139.74628616076404 11.277 35.672852144544215 139.7463014316507 11.277 35.672852144544215 139.7463014316507 13.643 35.672907144284196 139.74628616076404 13.643 35.672907144284196 139.74628616076404 11.277</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d7ac895b-a177-4721-984e-6165d8d586a5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d7ac895b-a177-4721-984e-6165d8d586a5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d7ac895b-a177-4721-984e-6165d8d586a5">
											<gml:posList>35.67291067344118 139.74630525651853 11.277 35.672907144284196 139.74628616076404 11.277 35.672907144284196 139.74628616076404 13.643 35.67291067344118 139.74630525651853 13.643 35.67291067344118 139.74630525651853 11.277</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6c7c68fc-6260-49d0-b0d4-106312c2e5ff">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6c7c68fc-6260-49d0-b0d4-106312c2e5ff">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6c7c68fc-6260-49d0-b0d4-106312c2e5ff">
											<gml:posList>35.672852144544215 139.7463014316507 11.277 35.67285567369879 139.74632052739278 11.277 35.67285567369879 139.74632052739278 13.643 35.672852144544215 139.7463014316507 13.643 35.672852144544215 139.7463014316507 11.277</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-11c9d825-3132-450c-b41d-8daadb474451">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-11c9d825-3132-450c-b41d-8daadb474451">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-11c9d825-3132-450c-b41d-8daadb474451">
											<gml:posList>35.67285567369879 139.74632052739278 11.277 35.67291067344118 139.74630525651853 11.277 35.67291067344118 139.74630525651853 13.643 35.67285567369879 139.74632052739278 13.643 35.67285567369879 139.74632052739278 11.277</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13101-bldg-4521</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13101</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">224</uro:landUseType>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>5</uro:specifiedFloorAreaRate>
					<uro:surveyYear>0001</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.26</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">0</uro:lod1HeightType>
					<uro:lodType>2.0</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>