<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_0f6acf67-39a9-4eb7-8660-4d831d4fe16e">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">413</bldg:usage>
			<bldg:measuredHeight uom="m">17.9</bldg:measuredHeight>
			<bldg:storeysAboveGround>4</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>1</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.671296347347116 139.737606323083 0 35.67129372449797 139.7375951693658 0 35.671287957385545 139.73759727506538 0 35.6712856059134 139.73758733612777 0 35.67127659473998 139.73759055034 0 35.67127018199798 139.7375742093529 0 35.67123665947795 139.73758496437728 0 35.671246065625915 139.73762505149784 0 35.671235252234055 139.73762893063818 0 35.67126193212305 139.73774146140926 0 35.671379798344674 139.73769945503375 0 35.67137148369766 139.73767173849834 0 35.671357155918855 139.7376768369349 0 35.67135218152199 139.73765563379513 0 35.67133460968209 139.73766184074356 0 35.67132538952798 139.73762893350548 0 35.671296347347116 139.737606323083 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671296347347116 139.737606323083 10.91 35.67132538952798 139.73762893350548 10.91 35.67133460968209 139.73766184074356 10.91 35.67135218152199 139.73765563379513 10.91 35.671357155918855 139.7376768369349 10.91 35.67137148369766 139.73767173849834 10.91 35.671379798344674 139.73769945503375 10.91 35.67126193212305 139.73774146140926 10.91 35.671235252234055 139.73762893063818 10.91 35.671246065625915 139.73762505149784 10.91 35.67123665947795 139.73758496437728 10.91 35.67127018199798 139.7375742093529 10.91 35.67127659473998 139.73759055034 10.91 35.6712856059134 139.73758733612777 10.91 35.671287957385545 139.73759727506538 10.91 35.67129372449797 139.7375951693658 10.91 35.671296347347116 139.737606323083 10.91</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671296347347116 139.737606323083 10.91 35.67129372449797 139.7375951693658 10.91 35.67129372449797 139.7375951693658 28.83 35.671296347347116 139.737606323083 28.83 35.671296347347116 139.737606323083 10.91</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67129372449797 139.7375951693658 10.91 35.671287957385545 139.73759727506538 10.91 35.671287957385545 139.73759727506538 28.83 35.67129372449797 139.7375951693658 28.83 35.67129372449797 139.7375951693658 10.91</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671287957385545 139.73759727506538 10.91 35.6712856059134 139.73758733612777 10.91 35.6712856059134 139.73758733612777 28.83 35.671287957385545 139.73759727506538 28.83 35.671287957385545 139.73759727506538 10.91</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6712856059134 139.73758733612777 10.91 35.67127659473998 139.73759055034 10.91 35.67127659473998 139.73759055034 28.83 35.6712856059134 139.73758733612777 28.83 35.6712856059134 139.73758733612777 10.91</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67127659473998 139.73759055034 10.91 35.67127018199798 139.7375742093529 10.91 35.67127018199798 139.7375742093529 28.83 35.67127659473998 139.73759055034 28.83 35.67127659473998 139.73759055034 10.91</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67127018199798 139.7375742093529 10.91 35.67123665947795 139.73758496437728 10.91 35.67123665947795 139.73758496437728 28.83 35.67127018199798 139.7375742093529 28.83 35.67127018199798 139.7375742093529 10.91</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67123665947795 139.73758496437728 10.91 35.671246065625915 139.73762505149784 10.91 35.671246065625915 139.73762505149784 28.83 35.67123665947795 139.73758496437728 28.83 35.67123665947795 139.73758496437728 10.91</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671246065625915 139.73762505149784 10.91 35.671235252234055 139.73762893063818 10.91 35.671235252234055 139.73762893063818 28.83 35.671246065625915 139.73762505149784 28.83 35.671246065625915 139.73762505149784 10.91</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671235252234055 139.73762893063818 10.91 35.67126193212305 139.73774146140926 10.91 35.67126193212305 139.73774146140926 28.83 35.671235252234055 139.73762893063818 28.83 35.671235252234055 139.73762893063818 10.91</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67126193212305 139.73774146140926 10.91 35.671379798344674 139.73769945503375 10.91 35.671379798344674 139.73769945503375 28.83 35.67126193212305 139.73774146140926 28.83 35.67126193212305 139.73774146140926 10.91</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671379798344674 139.73769945503375 10.91 35.67137148369766 139.73767173849834 10.91 35.67137148369766 139.73767173849834 28.83 35.671379798344674 139.73769945503375 28.83 35.671379798344674 139.73769945503375 10.91</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67137148369766 139.73767173849834 10.91 35.671357155918855 139.7376768369349 10.91 35.671357155918855 139.7376768369349 28.83 35.67137148369766 139.73767173849834 28.83 35.67137148369766 139.73767173849834 10.91</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671357155918855 139.7376768369349 10.91 35.67135218152199 139.73765563379513 10.91 35.67135218152199 139.73765563379513 28.83 35.671357155918855 139.7376768369349 28.83 35.671357155918855 139.7376768369349 10.91</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67135218152199 139.73765563379513 10.91 35.67133460968209 139.73766184074356 10.91 35.67133460968209 139.73766184074356 28.83 35.67135218152199 139.73765563379513 28.83 35.67135218152199 139.73765563379513 10.91</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67133460968209 139.73766184074356 10.91 35.67132538952798 139.73762893350548 10.91 35.67132538952798 139.73762893350548 28.83 35.67133460968209 139.73766184074356 28.83 35.67133460968209 139.73766184074356 10.91</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67132538952798 139.73762893350548 10.91 35.671296347347116 139.737606323083 10.91 35.671296347347116 139.737606323083 28.83 35.67132538952798 139.73762893350548 28.83 35.67132538952798 139.73762893350548 10.91</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671296347347116 139.737606323083 28.83 35.67129372449797 139.7375951693658 28.83 35.671287957385545 139.73759727506538 28.83 35.6712856059134 139.73758733612777 28.83 35.67127659473998 139.73759055034 28.83 35.67127018199798 139.7375742093529 28.83 35.67123665947795 139.73758496437728 28.83 35.671246065625915 139.73762505149784 28.83 35.671235252234055 139.73762893063818 28.83 35.67126193212305 139.73774146140926 28.83 35.671379798344674 139.73769945503375 28.83 35.67137148369766 139.73767173849834 28.83 35.671357155918855 139.7376768369349 28.83 35.67135218152199 139.73765563379513 28.83 35.67133460968209 139.73766184074356 28.83 35.67132538952798 139.73762893350548 28.83 35.671296347347116 139.737606323083 28.83</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-84f9d5da-6edc-4e9c-9b8b-f672dc993d7d"/>
							<gml:surfaceMember xlink:href="#poly-597af9f2-8218-4f3f-a52b-0f03ffcf42be"/>
							<gml:surfaceMember xlink:href="#poly-8668f72c-562f-433e-a3ef-a67810ba4d04"/>
							<gml:surfaceMember xlink:href="#poly-d76fe2d0-cbb8-4d2b-8fe6-accaa8ad89ed"/>
							<gml:surfaceMember xlink:href="#poly-4ebca86a-c3af-4db1-a1a8-90aa3c9970c2"/>
							<gml:surfaceMember xlink:href="#poly-96b8bfe8-ff18-431d-aba8-dd69bbe52b4a"/>
							<gml:surfaceMember xlink:href="#poly-d2327fc0-90ae-4dfc-b343-f8138969c95d"/>
							<gml:surfaceMember xlink:href="#poly-e936f0ae-66de-4a20-b8bb-d6e0d22ba838"/>
							<gml:surfaceMember xlink:href="#poly-cc4db973-d8fc-4655-bba1-96ffcbba86be"/>
							<gml:surfaceMember xlink:href="#poly-4b20f7d9-d037-4253-9a66-f38bdea94874"/>
							<gml:surfaceMember xlink:href="#poly-7a9b17f2-fced-4662-a38f-2248ba5dacde"/>
							<gml:surfaceMember xlink:href="#poly-d159be20-f2da-49fa-84bc-35eec9423c51"/>
							<gml:surfaceMember xlink:href="#poly-276fd450-2fa9-49fd-bcd0-c1852c91c159"/>
							<gml:surfaceMember xlink:href="#poly-1df80ab9-e138-4349-add0-efe055cacaac"/>
							<gml:surfaceMember xlink:href="#poly-61716d97-706b-47d3-b4ad-63bb6d708c01"/>
							<gml:surfaceMember xlink:href="#poly-b610e40e-c679-46f1-bf73-e2e5b28a51c4"/>
							<gml:surfaceMember xlink:href="#poly-73801371-23a9-400d-b8bd-8cfa59057d0e"/>
							<gml:surfaceMember xlink:href="#poly-a9020e37-89ab-4ccb-95bb-b94a3a1b7d51"/>
							<gml:surfaceMember xlink:href="#poly-865be586-31e8-42ef-9fa6-c384707be917"/>
							<gml:surfaceMember xlink:href="#poly-f8d6964d-3718-4291-814f-a264fae4fa9f"/>
							<gml:surfaceMember xlink:href="#poly-9cbbeb1b-3423-49ae-9aea-1f70296396f7"/>
							<gml:surfaceMember xlink:href="#poly-482540ee-6ed9-4354-9186-4940a401b1ee"/>
							<gml:surfaceMember xlink:href="#poly-67588e7a-abea-49ca-beda-241d81e569f6"/>
							<gml:surfaceMember xlink:href="#poly-6163df5c-ffcc-4231-9002-17e59f4d1521"/>
							<gml:surfaceMember xlink:href="#poly-deed4163-f66d-4960-9c7e-e6b39408ada3"/>
							<gml:surfaceMember xlink:href="#poly-8f406bf7-3222-4dfb-a8b3-bd244592a437"/>
							<gml:surfaceMember xlink:href="#poly-a502984f-c2b1-4028-b116-9dc38efc0f9e"/>
							<gml:surfaceMember xlink:href="#poly-193d5e44-1fd3-4c1c-b8ab-817ca6a51779"/>
							<gml:surfaceMember xlink:href="#poly-75f2c9ad-bdc1-45dd-b9e1-7c129521cfe7"/>
							<gml:surfaceMember xlink:href="#poly-77a4c7c7-cec5-4650-8248-0ad73daa0548"/>
							<gml:surfaceMember xlink:href="#poly-4117a122-523d-4d90-b1f8-b24d3de37a57"/>
							<gml:surfaceMember xlink:href="#poly-988c21c3-f5bd-446e-8d5e-11cd26873395"/>
							<gml:surfaceMember xlink:href="#poly-d5515d05-48a3-4f44-9b14-c6ef7e154125"/>
							<gml:surfaceMember xlink:href="#poly-6b1c581b-07ad-486f-851c-950cdef38976"/>
							<gml:surfaceMember xlink:href="#poly-20b9d0cb-7739-4349-a2c1-8d567c90dd4c"/>
							<gml:surfaceMember xlink:href="#poly-1b1266af-f209-46ea-80c1-9fb94f9d362c"/>
							<gml:surfaceMember xlink:href="#poly-1300129c-a446-49aa-9fb1-004d47e1e888"/>
							<gml:surfaceMember xlink:href="#poly-699d2e1c-ce21-471b-9656-75702c1a1ee7"/>
							<gml:surfaceMember xlink:href="#poly-19804583-2766-4776-9a2a-ce119c1ab7d3"/>
							<gml:surfaceMember xlink:href="#poly-26af69cc-3967-4b1f-8c45-2c6e7b43cbe2"/>
							<gml:surfaceMember xlink:href="#poly-fe0745dc-ef46-41ca-a4b9-53aa6c00d580"/>
							<gml:surfaceMember xlink:href="#poly-8440e5ca-562c-4367-9f09-1e57e0d717c8"/>
							<gml:surfaceMember xlink:href="#poly-b3507377-72a4-4784-b7a7-e9e261e86784"/>
							<gml:surfaceMember xlink:href="#poly-c606cea4-2a18-4892-9b69-a1d07a0e9083"/>
							<gml:surfaceMember xlink:href="#poly-8a014d50-7777-4c44-9072-a613d758d514"/>
							<gml:surfaceMember xlink:href="#poly-f489d601-ff26-4797-b6be-32143d5a2292"/>
							<gml:surfaceMember xlink:href="#poly-6426823c-9639-4e95-97cd-5a14f525707b"/>
							<gml:surfaceMember xlink:href="#poly-b8ec4dd7-5218-44d0-8734-6de5f952c272"/>
							<gml:surfaceMember xlink:href="#poly-d7ce855b-ba0c-4c03-9cc4-9a45663da4d9"/>
							<gml:surfaceMember xlink:href="#poly-4080a6bf-6264-4df0-8aa6-5fe50fae87de"/>
							<gml:surfaceMember xlink:href="#poly-53ae34f2-8f5d-4bf7-a588-129c8177af64"/>
							<gml:surfaceMember xlink:href="#poly-3ae4d467-ad28-4d1a-8108-5d84b36ee93a"/>
							<gml:surfaceMember xlink:href="#poly-fdfbb90f-9d03-4804-93e6-624e1c309a38"/>
							<gml:surfaceMember xlink:href="#poly-ac5877cf-f189-4c2f-8c67-d991e4d947d0"/>
							<gml:surfaceMember xlink:href="#poly-6d475963-0ea5-49ab-93de-1eed0d5cb1ab"/>
							<gml:surfaceMember xlink:href="#poly-4017af4f-408d-42f1-85b9-a966babe0a4b"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_0f6acf67-39a9-4eb7-8660-4d831d4fe16e_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2f45ee37-0d45-4685-8741-e283b0022bad">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67134514574675 139.73767194666613 31.789 35.67134571440974 139.7376729512093 31.789 35.67134609388111 139.73767407748858 31.789 35.67134627510328 139.7376752702827 31.789 35.67134624902742 139.73767648541698 31.789 35.671346024623375 139.73767766764865 31.789 35.671345592842314 139.73767877280304 31.789 35.67134498969526 139.73767974560516 31.789 35.67134423316576 139.73768053080158 31.789 35.67134335929994 139.7376811173029 31.789 35.67134241313131 139.73768146086988 31.789 35.67134142170103 139.73768156147023 31.789 35.67134043908264 139.73768140799305 31.789 35.671339501331026 139.73768100039536 31.789 35.67133865354112 139.73768037176248 31.789 35.67133792276285 139.73767953310863 31.789 35.67133736311364 139.73767852855474 31.789 35.671336983642306 139.7376774022756 31.789 35.67133679340643 139.73767620949235 31.789 35.671336819482285 139.73767499435823 31.789 35.67133705289126 139.73767380106955 31.789 35.67133747566732 139.73767270697238 31.789 35.67133807881433 139.73767173417033 31.789 35.671338835335 139.7376709379275 31.789 35.67133970920954 139.73767036247244 31.789 35.67134066438309 139.73767000784824 31.789 35.671341646808415 139.7376699183049 31.789 35.67134263844054 139.73767007177116 31.789 35.671343576192186 139.73767047936875 31.789 35.67134442398214 139.73767110800154 31.789 35.67134514574675 139.73767194666613 31.789</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4ff92500-9d1a-42ed-8f23-448482bc2b89">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4ff92500-9d1a-42ed-8f23-448482bc2b89_0">
											<gml:posList>35.67134066438309 139.73767000784824 31.789 35.67134066438309 139.73767000784824 34.303 35.671341646808415 139.7376699183049 34.303 35.671341646808415 139.7376699183049 31.789 35.67134066438309 139.73767000784824 31.789</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f8c366b7-9643-4f54-a731-87d1d3e373b8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f8c366b7-9643-4f54-a731-87d1d3e373b8_0">
											<gml:posList>35.671341646808415 139.7376699183049 31.789 35.671341646808415 139.7376699183049 34.303 35.67134263844054 139.73767007177116 34.303 35.67134263844054 139.73767007177116 31.789 35.671341646808415 139.7376699183049 31.789</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d1eeaf74-0a75-4cd9-b3f9-cf065e435391">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d1eeaf74-0a75-4cd9-b3f9-cf065e435391_0">
											<gml:posList>35.67133970920954 139.73767036247244 31.789 35.67133970920954 139.73767036247244 34.303 35.67134066438309 139.73767000784824 34.303 35.67134066438309 139.73767000784824 31.789 35.67133970920954 139.73767036247244 31.789</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4c72b018-c658-49ba-b2b5-67aa000b622e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4c72b018-c658-49ba-b2b5-67aa000b622e_0">
											<gml:posList>35.67134263844054 139.73767007177116 31.789 35.67134263844054 139.73767007177116 34.303 35.671343576192186 139.73767047936875 34.303 35.671343576192186 139.73767047936875 31.789 35.67134263844054 139.73767007177116 31.789</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4b4f6098-6439-4d1d-8a84-aec9115389a5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4b4f6098-6439-4d1d-8a84-aec9115389a5_0">
											<gml:posList>35.671338835335 139.7376709379275 31.789 35.671338835335 139.7376709379275 34.303 35.67133970920954 139.73767036247244 34.303 35.67133970920954 139.73767036247244 31.789 35.671338835335 139.7376709379275 31.789</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4a250820-a2d7-40aa-a1d9-c99e00a26b38">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4a250820-a2d7-40aa-a1d9-c99e00a26b38_0">
											<gml:posList>35.671343576192186 139.73767047936875 31.789 35.671343576192186 139.73767047936875 34.303 35.67134442398214 139.73767110800154 34.303 35.67134442398214 139.73767110800154 31.789 35.671343576192186 139.73767047936875 31.789</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-917b64aa-cd3b-4dcd-b9c5-7577574eec2d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-917b64aa-cd3b-4dcd-b9c5-7577574eec2d_0">
											<gml:posList>35.67133807881433 139.73767173417033 31.789 35.67133807881433 139.73767173417033 34.303 35.671338835335 139.7376709379275 34.303 35.671338835335 139.7376709379275 31.789 35.67133807881433 139.73767173417033 31.789</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d834cfcf-b64b-4d9d-a5aa-d63def85afe3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d834cfcf-b64b-4d9d-a5aa-d63def85afe3_0">
											<gml:posList>35.67134442398214 139.73767110800154 31.789 35.67134442398214 139.73767110800154 34.303 35.67134514574675 139.73767194666613 34.303 35.67134514574675 139.73767194666613 31.789 35.67134442398214 139.73767110800154 31.789</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1688fda2-ca70-4cff-a8a9-76e366b9e6d5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1688fda2-ca70-4cff-a8a9-76e366b9e6d5_0">
											<gml:posList>35.67133747566732 139.73767270697238 31.789 35.67133747566732 139.73767270697238 34.303 35.67133807881433 139.73767173417033 34.303 35.67133807881433 139.73767173417033 31.789 35.67133747566732 139.73767270697238 31.789</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-739d977c-cb56-4143-bf9f-2b8ded36c1ea">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-739d977c-cb56-4143-bf9f-2b8ded36c1ea_0">
											<gml:posList>35.67134514574675 139.73767194666613 31.789 35.67134514574675 139.73767194666613 34.303 35.67134571440974 139.7376729512093 34.303 35.67134571440974 139.7376729512093 31.789 35.67134514574675 139.73767194666613 31.789</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-eed33b33-4bb9-4144-ad0e-8b4b8402be02">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-eed33b33-4bb9-4144-ad0e-8b4b8402be02_0">
											<gml:posList>35.67133705289126 139.73767380106955 31.789 35.67133705289126 139.73767380106955 34.303 35.67133747566732 139.73767270697238 34.303 35.67133747566732 139.73767270697238 31.789 35.67133705289126 139.73767380106955 31.789</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8c9385f6-5ef6-4fa5-894a-8ac085df537d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8c9385f6-5ef6-4fa5-894a-8ac085df537d_0">
											<gml:posList>35.67134571440974 139.7376729512093 31.789 35.67134571440974 139.7376729512093 34.303 35.67134609388111 139.73767407748858 34.303 35.67134609388111 139.73767407748858 31.789 35.67134571440974 139.7376729512093 31.789</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9e2a2d1c-d3d3-422c-a453-de45ea921525">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9e2a2d1c-d3d3-422c-a453-de45ea921525_0">
											<gml:posList>35.671336819482285 139.73767499435823 31.789 35.671336819482285 139.73767499435823 34.303 35.67133705289126 139.73767380106955 34.303 35.67133705289126 139.73767380106955 31.789 35.671336819482285 139.73767499435823 31.789</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e57c2833-ab0e-44c6-b403-1833e00e1722">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e57c2833-ab0e-44c6-b403-1833e00e1722_0">
											<gml:posList>35.67134609388111 139.73767407748858 31.789 35.67134609388111 139.73767407748858 34.303 35.67134627510328 139.7376752702827 34.303 35.67134627510328 139.7376752702827 31.789 35.67134609388111 139.73767407748858 31.789</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e06cb214-3c31-4190-b01b-5c8c1b496aca">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e06cb214-3c31-4190-b01b-5c8c1b496aca_0">
											<gml:posList>35.67133679340643 139.73767620949235 31.789 35.67133679340643 139.73767620949235 34.303 35.671336819482285 139.73767499435823 34.303 35.671336819482285 139.73767499435823 31.789 35.67133679340643 139.73767620949235 31.789</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-10440348-f6bf-4a46-a530-017af1afd831">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-10440348-f6bf-4a46-a530-017af1afd831_0">
											<gml:posList>35.671343576192186 139.73767047936875 34.303 35.67134263844054 139.73767007177116 34.303 35.671341646808415 139.7376699183049 34.303 35.67134066438309 139.73767000784824 34.303 35.67133970920954 139.73767036247244 34.303 35.671338835335 139.7376709379275 34.303 35.67133807881433 139.73767173417033 34.303 35.67133747566732 139.73767270697238 34.303 35.67133705289126 139.73767380106955 34.303 35.671336819482285 139.73767499435823 34.303 35.67133679340643 139.73767620949235 34.303 35.671336983642306 139.7376774022756 34.303 35.67133736311364 139.73767852855474 34.303 35.67133792276285 139.73767953310863 34.303 35.67133865354112 139.73768037176248 34.303 35.671339501331026 139.73768100039536 34.303 35.67134043908264 139.73768140799305 34.303 35.67134142170103 139.73768156147023 34.303 35.67134241313131 139.73768146086988 34.303 35.67134335929994 139.7376811173029 34.303 35.67134423316576 139.73768053080158 34.303 35.67134498969526 139.73767974560516 34.303 35.671345592842314 139.73767877280304 34.303 35.671346024623375 139.73767766764865 34.303 35.67134624902742 139.73767648541698 34.303 35.67134627510328 139.7376752702827 34.303 35.67134609388111 139.73767407748858 34.303 35.67134571440974 139.7376729512093 34.303 35.67134514574675 139.73767194666613 34.303 35.67134442398214 139.73767110800154 34.303 35.671343576192186 139.73767047936875 34.303</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1f9a6cae-c13d-43f1-b61a-a3cea106cc12">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1f9a6cae-c13d-43f1-b61a-a3cea106cc12_0">
											<gml:posList>35.67134627510328 139.7376752702827 31.789 35.67134627510328 139.7376752702827 34.303 35.67134624902742 139.73767648541698 34.303 35.67134624902742 139.73767648541698 31.789 35.67134627510328 139.7376752702827 31.789</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0ad471f5-3bbf-48c2-a0fe-52e02452abef">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0ad471f5-3bbf-48c2-a0fe-52e02452abef_0">
											<gml:posList>35.671336983642306 139.7376774022756 31.789 35.671336983642306 139.7376774022756 34.303 35.67133679340643 139.73767620949235 34.303 35.67133679340643 139.73767620949235 31.789 35.671336983642306 139.7376774022756 31.789</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-dccab78f-4eb5-4983-abcc-11086ba5689b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-dccab78f-4eb5-4983-abcc-11086ba5689b_0">
											<gml:posList>35.67134624902742 139.73767648541698 31.789 35.67134624902742 139.73767648541698 34.303 35.671346024623375 139.73767766764865 34.303 35.671346024623375 139.73767766764865 31.789 35.67134624902742 139.73767648541698 31.789</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e03ef332-bcdc-4eca-a4ee-0883fc4b3ac0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e03ef332-bcdc-4eca-a4ee-0883fc4b3ac0_0">
											<gml:posList>35.67133736311364 139.73767852855474 31.789 35.67133736311364 139.73767852855474 34.303 35.671336983642306 139.7376774022756 34.303 35.671336983642306 139.7376774022756 31.789 35.67133736311364 139.73767852855474 31.789</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d8b33a64-1fc6-41b6-ace1-da44c8290570">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d8b33a64-1fc6-41b6-ace1-da44c8290570_0">
											<gml:posList>35.671346024623375 139.73767766764865 31.789 35.671346024623375 139.73767766764865 34.303 35.671345592842314 139.73767877280304 34.303 35.671345592842314 139.73767877280304 31.789 35.671346024623375 139.73767766764865 31.789</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fe648603-7115-41af-8cdf-9edcafefd509">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fe648603-7115-41af-8cdf-9edcafefd509_0">
											<gml:posList>35.67133792276285 139.73767953310863 31.789 35.67133792276285 139.73767953310863 34.303 35.67133736311364 139.73767852855474 34.303 35.67133736311364 139.73767852855474 31.789 35.67133792276285 139.73767953310863 31.789</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-480c3824-e954-4b81-a0e2-d051ef158fd1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-480c3824-e954-4b81-a0e2-d051ef158fd1_0">
											<gml:posList>35.671345592842314 139.73767877280304 31.789 35.671345592842314 139.73767877280304 34.303 35.67134498969526 139.73767974560516 34.303 35.67134498969526 139.73767974560516 31.789 35.671345592842314 139.73767877280304 31.789</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3ee045dd-904f-459b-9cfd-ca6b8fd0f102">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3ee045dd-904f-459b-9cfd-ca6b8fd0f102_0">
											<gml:posList>35.67133865354112 139.73768037176248 31.789 35.67133865354112 139.73768037176248 34.303 35.67133792276285 139.73767953310863 34.303 35.67133792276285 139.73767953310863 31.789 35.67133865354112 139.73768037176248 31.789</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-039ad3e7-928f-4343-9e72-78aae780d0c1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-039ad3e7-928f-4343-9e72-78aae780d0c1_0">
											<gml:posList>35.67134498969526 139.73767974560516 31.789 35.67134498969526 139.73767974560516 34.303 35.67134423316576 139.73768053080158 34.303 35.67134423316576 139.73768053080158 31.789 35.67134498969526 139.73767974560516 31.789</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-03c35d77-03be-40d9-b625-50a66b5f817a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-03c35d77-03be-40d9-b625-50a66b5f817a_0">
											<gml:posList>35.671339501331026 139.73768100039536 31.789 35.671339501331026 139.73768100039536 34.303 35.67133865354112 139.73768037176248 34.303 35.67133865354112 139.73768037176248 31.789 35.671339501331026 139.73768100039536 31.789</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-81e43d83-9af2-4d5e-a123-82f0c1bc92c6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-81e43d83-9af2-4d5e-a123-82f0c1bc92c6_0">
											<gml:posList>35.67134423316576 139.73768053080158 31.789 35.67134423316576 139.73768053080158 34.303 35.67134335929994 139.7376811173029 34.303 35.67134335929994 139.7376811173029 31.789 35.67134423316576 139.73768053080158 31.789</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a1a05c8c-5a5c-4b0c-bf56-7d65d6f1c479">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a1a05c8c-5a5c-4b0c-bf56-7d65d6f1c479_0">
											<gml:posList>35.67134043908264 139.73768140799305 31.789 35.67134043908264 139.73768140799305 34.303 35.671339501331026 139.73768100039536 34.303 35.671339501331026 139.73768100039536 31.789 35.67134043908264 139.73768140799305 31.789</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-341adf9c-a014-497c-9547-57b77e08abb9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-341adf9c-a014-497c-9547-57b77e08abb9_0">
											<gml:posList>35.67134335929994 139.7376811173029 31.789 35.67134335929994 139.7376811173029 34.303 35.67134241313131 139.73768146086988 34.303 35.67134241313131 139.73768146086988 31.789 35.67134335929994 139.7376811173029 31.789</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-af61bbbe-6db1-41ce-91ff-374cd5b006ec">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-af61bbbe-6db1-41ce-91ff-374cd5b006ec_0">
											<gml:posList>35.67134142170103 139.73768156147023 31.789 35.67134142170103 139.73768156147023 34.303 35.67134043908264 139.73768140799305 34.303 35.67134043908264 139.73768140799305 31.789 35.67134142170103 139.73768156147023 31.789</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7241ab1c-0527-42a1-865a-782022dcd12f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7241ab1c-0527-42a1-865a-782022dcd12f_0">
											<gml:posList>35.67134241313131 139.73768146086988 31.789 35.67134241313131 139.73768146086988 34.303 35.67134142170103 139.73768156147023 34.303 35.67134142170103 139.73768156147023 31.789 35.67134241313131 139.73768146086988 31.789</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-84f9d5da-6edc-4e9c-9b8b-f672dc993d7d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-84f9d5da-6edc-4e9c-9b8b-f672dc993d7d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-84f9d5da-6edc-4e9c-9b8b-f672dc993d7d">
											<gml:posList>35.67128795738553 139.73759727506538 10.91 35.67129372449798 139.73759516936576 10.91 35.67129634734711 139.737606323083 10.91 35.67132538952796 139.73762893350548 10.91 35.67133460968209 139.73766184074356 10.91 35.671352181521975 139.73765563379513 10.91 35.671357155918834 139.73767683693487 10.91 35.67137148369765 139.73767173849834 10.91 35.671379798344674 139.73769945503375 10.91 35.67126193212304 139.73774146140926 10.91 35.67123525223404 139.73762893063815 10.91 35.67124606562589 139.73762505149782 10.91 35.671236659477955 139.73758496437728 10.91 35.67127018199799 139.7375742093529 10.91 35.671276594739965 139.73759055034 10.91 35.67128560591337 139.73758733612775 10.91 35.67128795738553 139.73759727506538 10.91</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-597af9f2-8218-4f3f-a52b-0f03ffcf42be">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-597af9f2-8218-4f3f-a52b-0f03ffcf42be">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-597af9f2-8218-4f3f-a52b-0f03ffcf42be">
											<gml:posList>35.671236659477955 139.73758496437728 26.689 35.67124606562589 139.73762505149782 26.689 35.67125370653034 139.73762160695253 26.689 35.67127506467546 139.737616080357 26.689 35.67129634734711 139.737606323083 26.689 35.67129372449798 139.73759516936576 26.689 35.67128795738553 139.73759727506538 26.689 35.67128560591337 139.73758733612775 26.689 35.671276594739965 139.73759055034 26.689 35.67127018199799 139.7375742093529 26.689 35.671236659477955 139.73758496437728 26.689</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-8668f72c-562f-433e-a3ef-a67810ba4d04">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8668f72c-562f-433e-a3ef-a67810ba4d04">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8668f72c-562f-433e-a3ef-a67810ba4d04">
											<gml:posList>35.67129634734711 139.737606323083 30.551 35.67127506467546 139.737616080357 30.551 35.67127731021585 139.73761749161312 30.551 35.671296133037615 139.7376088640075 30.551 35.67129634734711 139.737606323083 30.551</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d76fe2d0-cbb8-4d2b-8fe6-accaa8ad89ed">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d76fe2d0-cbb8-4d2b-8fe6-accaa8ad89ed">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d76fe2d0-cbb8-4d2b-8fe6-accaa8ad89ed">
											<gml:posList>35.67132538952796 139.73762893350548 30.551 35.67129634734711 139.737606323083 30.551 35.671296133037615 139.7376088640075 30.551 35.67132384036205 139.73763043766363 30.551 35.67132538952796 139.73762893350548 30.551</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-4ebca86a-c3af-4db1-a1a8-90aa3c9970c2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4ebca86a-c3af-4db1-a1a8-90aa3c9970c2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4ebca86a-c3af-4db1-a1a8-90aa3c9970c2">
											<gml:posList>35.67133066852633 139.73764778339185 30.551 35.67132538952796 139.73762893350548 30.551 35.67132384036205 139.73763043766363 30.551 35.67132878518541 139.73764844842293 30.551 35.67133066852633 139.73764778339185 30.551</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-96b8bfe8-ff18-431d-aba8-dd69bbe52b4a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-96b8bfe8-ff18-431d-aba8-dd69bbe52b4a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-96b8bfe8-ff18-431d-aba8-dd69bbe52b4a">
											<gml:posList>35.67129316393666 139.7376610617213 32.305 35.671297159173946 139.73766377436465 32.305 35.671328617251504 139.7376526352051 32.305 35.67133066852633 139.73764778339185 32.305 35.67129316393666 139.7376610617213 32.305</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d2327fc0-90ae-4dfc-b343-f8138969c95d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d2327fc0-90ae-4dfc-b343-f8138969c95d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d2327fc0-90ae-4dfc-b343-f8138969c95d">
											<gml:posList>35.67133460968209 139.73766184074356 32.305 35.67133066852633 139.73764778339185 32.305 35.671328617251504 139.7376526352051 32.305 35.671332558406704 139.73766669255667 32.305 35.67133460968209 139.73766184074356 32.305</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e936f0ae-66de-4a20-b8bb-d6e0d22ba838">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e936f0ae-66de-4a20-b8bb-d6e0d22ba838">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e936f0ae-66de-4a20-b8bb-d6e0d22ba838">
											<gml:posList>35.67133460968209 139.73766184074356 32.305 35.671332558406704 139.73766669255667 32.305 35.67134996804376 139.737660541035 32.305 35.671352181521975 139.73765563379513 32.305 35.67133460968209 139.73766184074356 32.305</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-cc4db973-d8fc-4655-bba1-96ffcbba86be">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cc4db973-d8fc-4655-bba1-96ffcbba86be">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cc4db973-d8fc-4655-bba1-96ffcbba86be">
											<gml:posList>35.67129316393666 139.7376610617213 30.246 35.67132878518541 139.73764844842293 30.246 35.67132384036205 139.73763043766363 30.246 35.671296133037615 139.7376088640075 30.246 35.67127731021585 139.73761749161312 30.246 35.671300759396956 139.7377252321603 30.246 35.67130779712171 139.737722716238 30.246 35.67129316393666 139.7376610617213 30.246</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-4b20f7d9-d037-4253-9a66-f38bdea94874">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4b20f7d9-d037-4253-9a66-f38bdea94874">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4b20f7d9-d037-4253-9a66-f38bdea94874">
											<gml:posList>35.671357155918834 139.73767683693487 32.305 35.671352181521975 139.73765563379513 32.305 35.67134996804376 139.737660541035 32.305 35.67135494243099 139.7376817331281 32.305 35.671357155918834 139.73767683693487 32.305</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-7a9b17f2-fced-4662-a38f-2248ba5dacde">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7a9b17f2-fced-4662-a38f-2248ba5dacde">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7a9b17f2-fced-4662-a38f-2248ba5dacde">
											<gml:posList>35.67129944566538 139.73772809474085 30.551 35.671300759396956 139.7377252321603 30.551 35.67127731021585 139.73761749161312 30.551 35.67127506467546 139.737616080357 30.551 35.67129944566538 139.73772809474085 30.551</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d159be20-f2da-49fa-84bc-35eec9423c51">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d159be20-f2da-49fa-84bc-35eec9423c51">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d159be20-f2da-49fa-84bc-35eec9423c51">
											<gml:posList>35.67127506467546 139.737616080357 29.12 35.67125370653034 139.73762160695253 27.967 35.671280576249224 139.7377348113501 27.967 35.67127506467546 139.737616080357 29.12</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-276fd450-2fa9-49fd-bcd0-c1852c91c159">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-276fd450-2fa9-49fd-bcd0-c1852c91c159">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-276fd450-2fa9-49fd-bcd0-c1852c91c159">
											<gml:posList>35.671280576249224 139.7377348113501 27.967 35.67129944566538 139.73772809474085 29.12 35.67127506467546 139.737616080357 29.12 35.671280576249224 139.7377348113501 27.967</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-1df80ab9-e138-4349-add0-efe055cacaac">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1df80ab9-e138-4349-add0-efe055cacaac">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1df80ab9-e138-4349-add0-efe055cacaac">
											<gml:posList>35.671357155918834 139.73767683693487 32.305 35.67135494243099 139.7376817331281 32.305 35.67136948648665 139.73767656815616 32.305 35.67137148369765 139.73767173849834 32.305 35.671357155918834 139.73767683693487 32.305</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-61716d97-706b-47d3-b4ad-63bb6d708c01">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-61716d97-706b-47d3-b4ad-63bb6d708c01">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-61716d97-706b-47d3-b4ad-63bb6d708c01">
											<gml:posList>35.67124606562589 139.73762505149782 26.022 35.67123525223404 139.73762893063815 25.353 35.67126193212304 139.73774146140926 25.353 35.671280576249224 139.7377348113501 26.502 35.67125370653034 139.73762160695253 26.502 35.67124606562589 139.73762505149782 26.022</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b610e40e-c679-46f1-bf73-e2e5b28a51c4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b610e40e-c679-46f1-bf73-e2e5b28a51c4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b610e40e-c679-46f1-bf73-e2e5b28a51c4">
											<gml:posList>35.67137148369765 139.73767173849834 32.305 35.67136948648665 139.73767656815616 32.305 35.67137556883924 139.73769685312928 32.305 35.671379798344674 139.73769945503375 32.305 35.67137148369765 139.73767173849834 32.305</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-73801371-23a9-400d-b8bd-8cfa59057d0e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-73801371-23a9-400d-b8bd-8cfa59057d0e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-73801371-23a9-400d-b8bd-8cfa59057d0e">
											<gml:posList>35.67135494243099 139.7376817331281 31.789 35.67134996804376 139.737660541035 31.789 35.671332558406704 139.73766669255667 31.789 35.671328617251504 139.7376526352051 31.789 35.671297159173946 139.73766377436465 31.789 35.67131051713391 139.73772002872218 31.789 35.67137556883924 139.73769685312928 31.789 35.67136948648665 139.73767656815616 31.789 35.67135494243099 139.7376817331281 31.789</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a9020e37-89ab-4ccb-95bb-b94a3a1b7d51">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a9020e37-89ab-4ccb-95bb-b94a3a1b7d51">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a9020e37-89ab-4ccb-95bb-b94a3a1b7d51">
											<gml:posList>35.67130832167172 139.73772492488987 32.305 35.67131051713391 139.73772002872218 32.305 35.671297159173946 139.73766377436465 32.305 35.67129316393666 139.7376610617213 32.305 35.67130832167172 139.73772492488987 32.305</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-865be586-31e8-42ef-9fa6-c384707be917">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-865be586-31e8-42ef-9fa6-c384707be917">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-865be586-31e8-42ef-9fa6-c384707be917">
											<gml:posList>35.671379798344674 139.73769945503375 32.305 35.67137556883924 139.73769685312928 32.305 35.67131051713391 139.73772002872218 32.305 35.67130832167172 139.73772492488987 32.305 35.671379798344674 139.73769945503375 32.305</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f8d6964d-3718-4291-814f-a264fae4fa9f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f8d6964d-3718-4291-814f-a264fae4fa9f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f8d6964d-3718-4291-814f-a264fae4fa9f">
											<gml:posList>35.67130832167172 139.73772492488987 30.551 35.67130779712171 139.737722716238 30.551 35.671300759396956 139.7377252321603 30.551 35.67129944566538 139.73772809474085 30.551 35.67130832167172 139.73772492488987 30.551</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9cbbeb1b-3423-49ae-9aea-1f70296396f7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9cbbeb1b-3423-49ae-9aea-1f70296396f7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9cbbeb1b-3423-49ae-9aea-1f70296396f7">
											<gml:posList>35.67132538952796 139.73762893350548 30.551 35.67132538952796 139.73762893350548 10.91 35.67129634734711 139.737606323083 10.91 35.67129634734711 139.737606323083 26.689 35.67129634734711 139.737606323083 30.551 35.67132538952796 139.73762893350548 30.551</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-482540ee-6ed9-4354-9186-4940a401b1ee">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-482540ee-6ed9-4354-9186-4940a401b1ee">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-482540ee-6ed9-4354-9186-4940a401b1ee">
											<gml:posList>35.671296133037615 139.7376088640075 30.551 35.671296133037615 139.7376088640075 30.246 35.67132384036205 139.73763043766363 30.246 35.67132384036205 139.73763043766363 30.551 35.671296133037615 139.7376088640075 30.551</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-67588e7a-abea-49ca-beda-241d81e569f6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-67588e7a-abea-49ca-beda-241d81e569f6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-67588e7a-abea-49ca-beda-241d81e569f6">
											<gml:posList>35.67123525223404 139.73762893063815 25.353 35.67124606562589 139.73762505149782 26.022 35.67124606562589 139.73762505149782 10.91 35.67123525223404 139.73762893063815 10.91 35.67123525223404 139.73762893063815 25.353</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6163df5c-ffcc-4231-9002-17e59f4d1521">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6163df5c-ffcc-4231-9002-17e59f4d1521">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6163df5c-ffcc-4231-9002-17e59f4d1521">
											<gml:posList>35.671236659477955 139.73758496437728 26.689 35.671236659477955 139.73758496437728 10.91 35.67124606562589 139.73762505149782 10.91 35.67124606562589 139.73762505149782 26.022 35.67124606562589 139.73762505149782 26.689 35.671236659477955 139.73758496437728 26.689</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-deed4163-f66d-4960-9c7e-e6b39408ada3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-deed4163-f66d-4960-9c7e-e6b39408ada3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-deed4163-f66d-4960-9c7e-e6b39408ada3">
											<gml:posList>35.67123525223404 139.73762893063815 10.91 35.67126193212304 139.73774146140926 10.91 35.67126193212304 139.73774146140926 25.353 35.67123525223404 139.73762893063815 25.353 35.67123525223404 139.73762893063815 10.91</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8f406bf7-3222-4dfb-a8b3-bd244592a437">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8f406bf7-3222-4dfb-a8b3-bd244592a437">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8f406bf7-3222-4dfb-a8b3-bd244592a437">
											<gml:posList>35.67124606562589 139.73762505149782 26.689 35.67124606562589 139.73762505149782 26.022 35.67125370653034 139.73762160695253 26.502 35.67125370653034 139.73762160695253 26.689 35.67124606562589 139.73762505149782 26.689</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a502984f-c2b1-4028-b116-9dc38efc0f9e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a502984f-c2b1-4028-b116-9dc38efc0f9e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a502984f-c2b1-4028-b116-9dc38efc0f9e">
											<gml:posList>35.67127018199799 139.7375742093529 10.91 35.671236659477955 139.73758496437728 10.91 35.671236659477955 139.73758496437728 26.689 35.67127018199799 139.7375742093529 26.689 35.67127018199799 139.7375742093529 10.91</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-193d5e44-1fd3-4c1c-b8ab-817ca6a51779">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-193d5e44-1fd3-4c1c-b8ab-817ca6a51779">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-193d5e44-1fd3-4c1c-b8ab-817ca6a51779">
											<gml:posList>35.67127506467546 139.737616080357 26.689 35.67125370653034 139.73762160695253 26.689 35.67125370653034 139.73762160695253 27.967 35.67127506467546 139.737616080357 29.12 35.67127506467546 139.737616080357 26.689</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-75f2c9ad-bdc1-45dd-b9e1-7c129521cfe7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-75f2c9ad-bdc1-45dd-b9e1-7c129521cfe7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-75f2c9ad-bdc1-45dd-b9e1-7c129521cfe7">
											<gml:posList>35.671280576249224 139.7377348113501 26.502 35.671280576249224 139.7377348113501 27.967 35.67125370653034 139.73762160695253 27.967 35.67125370653034 139.73762160695253 26.689 35.67125370653034 139.73762160695253 26.502 35.671280576249224 139.7377348113501 26.502</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-77a4c7c7-cec5-4650-8248-0ad73daa0548">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-77a4c7c7-cec5-4650-8248-0ad73daa0548">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-77a4c7c7-cec5-4650-8248-0ad73daa0548">
											<gml:posList>35.671276594739965 139.73759055034 10.91 35.67127018199799 139.7375742093529 10.91 35.67127018199799 139.7375742093529 26.689 35.671276594739965 139.73759055034 26.689 35.671276594739965 139.73759055034 10.91</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4117a122-523d-4d90-b1f8-b24d3de37a57">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4117a122-523d-4d90-b1f8-b24d3de37a57">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4117a122-523d-4d90-b1f8-b24d3de37a57">
											<gml:posList>35.67128560591337 139.73758733612775 10.91 35.671276594739965 139.73759055034 10.91 35.671276594739965 139.73759055034 26.689 35.67128560591337 139.73758733612775 26.689 35.67128560591337 139.73758733612775 10.91</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-988c21c3-f5bd-446e-8d5e-11cd26873395">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-988c21c3-f5bd-446e-8d5e-11cd26873395">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-988c21c3-f5bd-446e-8d5e-11cd26873395">
											<gml:posList>35.67129634734711 139.737606323083 26.689 35.67127506467546 139.737616080357 26.689 35.67127506467546 139.737616080357 29.12 35.67127506467546 139.737616080357 30.551 35.67129634734711 139.737606323083 30.551 35.67129634734711 139.737606323083 26.689</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d5515d05-48a3-4f44-9b14-c6ef7e154125">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d5515d05-48a3-4f44-9b14-c6ef7e154125">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d5515d05-48a3-4f44-9b14-c6ef7e154125">
											<gml:posList>35.67127731021585 139.73761749161312 30.551 35.67127731021585 139.73761749161312 30.246 35.671296133037615 139.7376088640075 30.246 35.671296133037615 139.7376088640075 30.551 35.67127731021585 139.73761749161312 30.551</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6b1c581b-07ad-486f-851c-950cdef38976">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6b1c581b-07ad-486f-851c-950cdef38976">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6b1c581b-07ad-486f-851c-950cdef38976">
											<gml:posList>35.67128795738553 139.73759727506538 10.91 35.67128560591337 139.73758733612775 10.91 35.67128560591337 139.73758733612775 26.689 35.67128795738553 139.73759727506538 26.689 35.67128795738553 139.73759727506538 10.91</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-20b9d0cb-7739-4349-a2c1-8d567c90dd4c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-20b9d0cb-7739-4349-a2c1-8d567c90dd4c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-20b9d0cb-7739-4349-a2c1-8d567c90dd4c">
											<gml:posList>35.67129944566538 139.73772809474085 29.12 35.67129944566538 139.73772809474085 30.551 35.67127506467546 139.737616080357 30.551 35.67127506467546 139.737616080357 29.12 35.67129944566538 139.73772809474085 29.12</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1b1266af-f209-46ea-80c1-9fb94f9d362c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1b1266af-f209-46ea-80c1-9fb94f9d362c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1b1266af-f209-46ea-80c1-9fb94f9d362c">
											<gml:posList>35.671300759396956 139.7377252321603 30.551 35.671300759396956 139.7377252321603 30.246 35.67127731021585 139.73761749161312 30.246 35.67127731021585 139.73761749161312 30.551 35.671300759396956 139.7377252321603 30.551</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1300129c-a446-49aa-9fb1-004d47e1e888">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1300129c-a446-49aa-9fb1-004d47e1e888">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1300129c-a446-49aa-9fb1-004d47e1e888">
											<gml:posList>35.67129372449798 139.73759516936576 10.91 35.67128795738553 139.73759727506538 10.91 35.67128795738553 139.73759727506538 26.689 35.67129372449798 139.73759516936576 26.689 35.67129372449798 139.73759516936576 10.91</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-699d2e1c-ce21-471b-9656-75702c1a1ee7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-699d2e1c-ce21-471b-9656-75702c1a1ee7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-699d2e1c-ce21-471b-9656-75702c1a1ee7">
											<gml:posList>35.67129634734711 139.737606323083 10.91 35.67129372449798 139.73759516936576 10.91 35.67129372449798 139.73759516936576 26.689 35.67129634734711 139.737606323083 26.689 35.67129634734711 139.737606323083 10.91</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-19804583-2766-4776-9a2a-ce119c1ab7d3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-19804583-2766-4776-9a2a-ce119c1ab7d3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-19804583-2766-4776-9a2a-ce119c1ab7d3">
											<gml:posList>35.67130832167172 139.73772492488987 32.305 35.67129316393666 139.7376610617213 32.305 35.67129316393666 139.7376610617213 30.246 35.67130779712171 139.737722716238 30.246 35.67130779712171 139.737722716238 30.551 35.67130832167172 139.73772492488987 30.551 35.67130832167172 139.73772492488987 32.305</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-26af69cc-3967-4b1f-8c45-2c6e7b43cbe2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-26af69cc-3967-4b1f-8c45-2c6e7b43cbe2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-26af69cc-3967-4b1f-8c45-2c6e7b43cbe2">
											<gml:posList>35.67131051713391 139.73772002872218 32.305 35.67131051713391 139.73772002872218 31.789 35.671297159173946 139.73766377436465 31.789 35.671297159173946 139.73766377436465 32.305 35.67131051713391 139.73772002872218 32.305</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-fe0745dc-ef46-41ca-a4b9-53aa6c00d580">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fe0745dc-ef46-41ca-a4b9-53aa6c00d580">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fe0745dc-ef46-41ca-a4b9-53aa6c00d580">
											<gml:posList>35.67130779712171 139.737722716238 30.551 35.67130779712171 139.737722716238 30.246 35.671300759396956 139.7377252321603 30.246 35.671300759396956 139.7377252321603 30.551 35.67130779712171 139.737722716238 30.551</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8440e5ca-562c-4367-9f09-1e57e0d717c8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8440e5ca-562c-4367-9f09-1e57e0d717c8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8440e5ca-562c-4367-9f09-1e57e0d717c8">
											<gml:posList>35.67129316393666 139.7376610617213 30.246 35.67129316393666 139.7376610617213 32.305 35.67133066852633 139.73764778339185 32.305 35.67133066852633 139.73764778339185 30.551 35.67132878518541 139.73764844842293 30.551 35.67132878518541 139.73764844842293 30.246 35.67129316393666 139.7376610617213 30.246</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b3507377-72a4-4784-b7a7-e9e261e86784">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b3507377-72a4-4784-b7a7-e9e261e86784">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b3507377-72a4-4784-b7a7-e9e261e86784">
											<gml:posList>35.671297159173946 139.73766377436465 32.305 35.671297159173946 139.73766377436465 31.789 35.671328617251504 139.7376526352051 31.789 35.671328617251504 139.7376526352051 32.305 35.671297159173946 139.73766377436465 32.305</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c606cea4-2a18-4892-9b69-a1d07a0e9083">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c606cea4-2a18-4892-9b69-a1d07a0e9083">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c606cea4-2a18-4892-9b69-a1d07a0e9083">
											<gml:posList>35.671280576249224 139.7377348113501 26.502 35.67126193212304 139.73774146140926 25.353 35.67126193212304 139.73774146140926 10.91 35.671379798344674 139.73769945503375 10.91 35.671379798344674 139.73769945503375 32.305 35.67130832167172 139.73772492488987 32.305 35.67130832167172 139.73772492488987 30.551 35.67129944566538 139.73772809474085 30.551 35.67129944566538 139.73772809474085 29.12 35.671280576249224 139.7377348113501 27.967 35.671280576249224 139.7377348113501 26.502</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8a014d50-7777-4c44-9072-a613d758d514">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8a014d50-7777-4c44-9072-a613d758d514">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8a014d50-7777-4c44-9072-a613d758d514">
											<gml:posList>35.67132384036205 139.73763043766363 30.551 35.67132384036205 139.73763043766363 30.246 35.67132878518541 139.73764844842293 30.246 35.67132878518541 139.73764844842293 30.551 35.67132384036205 139.73763043766363 30.551</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f489d601-ff26-4797-b6be-32143d5a2292">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f489d601-ff26-4797-b6be-32143d5a2292">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f489d601-ff26-4797-b6be-32143d5a2292">
											<gml:posList>35.67133066852633 139.73764778339185 30.551 35.67133066852633 139.73764778339185 32.305 35.67133460968209 139.73766184074356 32.305 35.67133460968209 139.73766184074356 10.91 35.67132538952796 139.73762893350548 10.91 35.67132538952796 139.73762893350548 30.551 35.67133066852633 139.73764778339185 30.551</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6426823c-9639-4e95-97cd-5a14f525707b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6426823c-9639-4e95-97cd-5a14f525707b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6426823c-9639-4e95-97cd-5a14f525707b">
											<gml:posList>35.671328617251504 139.7376526352051 32.305 35.671328617251504 139.7376526352051 31.789 35.671332558406704 139.73766669255667 31.789 35.671332558406704 139.73766669255667 32.305 35.671328617251504 139.7376526352051 32.305</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b8ec4dd7-5218-44d0-8734-6de5f952c272">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b8ec4dd7-5218-44d0-8734-6de5f952c272">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b8ec4dd7-5218-44d0-8734-6de5f952c272">
											<gml:posList>35.671332558406704 139.73766669255667 32.305 35.671332558406704 139.73766669255667 31.789 35.67134996804376 139.737660541035 31.789 35.67134996804376 139.737660541035 32.305 35.671332558406704 139.73766669255667 32.305</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d7ce855b-ba0c-4c03-9cc4-9a45663da4d9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d7ce855b-ba0c-4c03-9cc4-9a45663da4d9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d7ce855b-ba0c-4c03-9cc4-9a45663da4d9">
											<gml:posList>35.67137556883924 139.73769685312928 32.305 35.67137556883924 139.73769685312928 31.789 35.67131051713391 139.73772002872218 31.789 35.67131051713391 139.73772002872218 32.305 35.67137556883924 139.73769685312928 32.305</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4080a6bf-6264-4df0-8aa6-5fe50fae87de">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4080a6bf-6264-4df0-8aa6-5fe50fae87de">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4080a6bf-6264-4df0-8aa6-5fe50fae87de">
											<gml:posList>35.671352181521975 139.73765563379513 10.91 35.67133460968209 139.73766184074356 10.91 35.67133460968209 139.73766184074356 32.305 35.671352181521975 139.73765563379513 32.305 35.671352181521975 139.73765563379513 10.91</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-53ae34f2-8f5d-4bf7-a588-129c8177af64">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-53ae34f2-8f5d-4bf7-a588-129c8177af64">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-53ae34f2-8f5d-4bf7-a588-129c8177af64">
											<gml:posList>35.67134996804376 139.737660541035 32.305 35.67134996804376 139.737660541035 31.789 35.67135494243099 139.7376817331281 31.789 35.67135494243099 139.7376817331281 32.305 35.67134996804376 139.737660541035 32.305</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3ae4d467-ad28-4d1a-8108-5d84b36ee93a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3ae4d467-ad28-4d1a-8108-5d84b36ee93a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3ae4d467-ad28-4d1a-8108-5d84b36ee93a">
											<gml:posList>35.671357155918834 139.73767683693487 10.91 35.671352181521975 139.73765563379513 10.91 35.671352181521975 139.73765563379513 32.305 35.671357155918834 139.73767683693487 32.305 35.671357155918834 139.73767683693487 10.91</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-fdfbb90f-9d03-4804-93e6-624e1c309a38">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fdfbb90f-9d03-4804-93e6-624e1c309a38">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fdfbb90f-9d03-4804-93e6-624e1c309a38">
											<gml:posList>35.67135494243099 139.7376817331281 32.305 35.67135494243099 139.7376817331281 31.789 35.67136948648665 139.73767656815616 31.789 35.67136948648665 139.73767656815616 32.305 35.67135494243099 139.7376817331281 32.305</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ac5877cf-f189-4c2f-8c67-d991e4d947d0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ac5877cf-f189-4c2f-8c67-d991e4d947d0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ac5877cf-f189-4c2f-8c67-d991e4d947d0">
											<gml:posList>35.67137148369765 139.73767173849834 10.91 35.671357155918834 139.73767683693487 10.91 35.671357155918834 139.73767683693487 32.305 35.67137148369765 139.73767173849834 32.305 35.67137148369765 139.73767173849834 10.91</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6d475963-0ea5-49ab-93de-1eed0d5cb1ab">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6d475963-0ea5-49ab-93de-1eed0d5cb1ab">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6d475963-0ea5-49ab-93de-1eed0d5cb1ab">
											<gml:posList>35.67136948648665 139.73767656815616 32.305 35.67136948648665 139.73767656815616 31.789 35.67137556883924 139.73769685312928 31.789 35.67137556883924 139.73769685312928 32.305 35.67136948648665 139.73767656815616 32.305</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4017af4f-408d-42f1-85b9-a966babe0a4b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4017af4f-408d-42f1-85b9-a966babe0a4b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4017af4f-408d-42f1-85b9-a966babe0a4b">
											<gml:posList>35.671379798344674 139.73769945503375 10.91 35.67137148369765 139.73767173849834 10.91 35.67137148369765 139.73767173849834 32.305 35.671379798344674 139.73769945503375 32.305 35.671379798344674 139.73769945503375 10.91</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-8629</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">131.4961</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">211</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1230</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>5</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.01</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>