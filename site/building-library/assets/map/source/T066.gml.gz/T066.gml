<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_1078f3a5-d8fc-4534-9d5c-df815090c88f">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">401</bldg:usage>
			<bldg:measuredHeight uom="m">19.5</bldg:measuredHeight>
			<bldg:storeysAboveGround>7</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.67081928092419 139.74158193297438 0 35.67088895826157 139.74146529236708 0 35.67078394839715 139.74146541269013 0 35.670781985012916 139.74155026168464 0 35.67081928092419 139.74158193297438 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67081928092419 139.74158193297438 8.598 35.670781985012916 139.74155026168464 8.598 35.67078394839715 139.74146541269013 8.598 35.67088895826157 139.74146529236708 8.598 35.67081928092419 139.74158193297438 8.598</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67081928092419 139.74158193297438 8.598 35.67088895826157 139.74146529236708 8.598 35.67088895826157 139.74146529236708 28.1 35.67081928092419 139.74158193297438 28.1 35.67081928092419 139.74158193297438 8.598</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67088895826157 139.74146529236708 8.598 35.67078394839715 139.74146541269013 8.598 35.67078394839715 139.74146541269013 28.1 35.67088895826157 139.74146529236708 28.1 35.67088895826157 139.74146529236708 8.598</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67078394839715 139.74146541269013 8.598 35.670781985012916 139.74155026168464 8.598 35.670781985012916 139.74155026168464 28.1 35.67078394839715 139.74146541269013 28.1 35.67078394839715 139.74146541269013 8.598</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670781985012916 139.74155026168464 8.598 35.67081928092419 139.74158193297438 8.598 35.67081928092419 139.74158193297438 28.1 35.670781985012916 139.74155026168464 28.1 35.670781985012916 139.74155026168464 8.598</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67081928092419 139.74158193297438 28.1 35.67088895826157 139.74146529236708 28.1 35.67078394839715 139.74146541269013 28.1 35.670781985012916 139.74155026168464 28.1 35.67081928092419 139.74158193297438 28.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-cf72d385-0f36-4f19-ad34-e13f3ba078ad"/>
							<gml:surfaceMember xlink:href="#poly-24081eb4-a0aa-4603-9df6-afa8b57c7f44"/>
							<gml:surfaceMember xlink:href="#poly-0952f6d5-8e56-4966-b69c-be7297f1952c"/>
							<gml:surfaceMember xlink:href="#poly-a703bf2c-7076-4e80-b13e-088f3cf32e18"/>
							<gml:surfaceMember xlink:href="#poly-3a3d6b9b-6827-4f42-a7f0-8436b87c828b"/>
							<gml:surfaceMember xlink:href="#poly-5b98d57f-bf9d-48c8-90e3-c399854831ed"/>
							<gml:surfaceMember xlink:href="#poly-e190ae62-4a5b-46c8-8f1c-2848e3291fae"/>
							<gml:surfaceMember xlink:href="#poly-679b66cc-8f51-45e2-8099-e0f455a9078e"/>
							<gml:surfaceMember xlink:href="#poly-4dc18189-886f-47a2-ba53-3444c60367d8"/>
							<gml:surfaceMember xlink:href="#poly-acf86684-6187-430c-996a-7900a7a1337a"/>
							<gml:surfaceMember xlink:href="#poly-ec2433df-d585-4c8d-a217-40bd858c8f97"/>
							<gml:surfaceMember xlink:href="#poly-ff12e127-8e8d-4a39-930e-c7fd8762e944"/>
							<gml:surfaceMember xlink:href="#poly-dbf59053-44d9-422b-a2ad-cb16b5d34112"/>
							<gml:surfaceMember xlink:href="#poly-52e4876b-1e63-4941-ac54-88ee5ae3760b"/>
							<gml:surfaceMember xlink:href="#poly-ec42b455-a814-4621-9330-01352fcbf7d4"/>
							<gml:surfaceMember xlink:href="#poly-dc0b340e-907d-488c-85a0-e07a7ab6fa72"/>
							<gml:surfaceMember xlink:href="#poly-9d04dae2-c595-4b91-910a-78f0c965533d"/>
							<gml:surfaceMember xlink:href="#poly-72b15200-2892-406a-bd81-110528ad61ea"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_1078f3a5-d8fc-4534-9d5c-df815090c88f_BuildingInstallation_1060">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fc94d5a9-d268-4a51-b09c-a4ded90ac732">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fc94d5a9-d268-4a51-b09c-a4ded90ac732_0">
											<gml:posList>35.670790915489086 139.7415829485571 29.893 35.67079143751493 139.74155828153562 29.893 35.67079143751493 139.74155828153562 33.094 35.670790915489086 139.7415829485571 29.893</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-419e2396-9e9c-4429-83db-de0c9164f24a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-419e2396-9e9c-4429-83db-de0c9164f24a_0">
											<gml:posList>35.67079143751493 139.74155828153562 29.893 35.67078198501288 139.74155026168464 33.094 35.67079143751493 139.74155828153562 33.094 35.67079143751493 139.74155828153562 29.893</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-63f83218-a0af-4e70-8984-5d8864cabad4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-63f83218-a0af-4e70-8984-5d8864cabad4_0">
											<gml:posList>35.67079143751493 139.74155828153562 29.893 35.67078198501288 139.74155026168464 28.893 35.67078198501288 139.74155026168464 33.094 35.67079143751493 139.74155828153562 29.893</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a7b6548c-610e-463f-adb8-30e3b0a14271">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a7b6548c-610e-463f-adb8-30e3b0a14271_0">
											<gml:posList>35.67079143751493 139.74155828153562 29.893 35.67081928092419 139.74158193297438 27.529 35.67078198501288 139.74155026168464 28.893 35.67079143751493 139.74155828153562 29.893</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b27f0972-c776-46e3-9942-c47577e68d5a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b27f0972-c776-46e3-9942-c47577e68d5a_0">
											<gml:posList>35.67078198501288 139.74155026168464 28.893 35.67081928092419 139.74158193297438 27.529 35.67078198501288 139.74155026168464 8.598 35.67078198501288 139.74155026168464 28.893</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2329ddff-858e-44c2-b420-24ba74e3110f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2329ddff-858e-44c2-b420-24ba74e3110f_0">
											<gml:posList>35.67081928092419 139.74158193297438 27.529 35.67081928092419 139.74158193297438 8.598 35.67078198501288 139.74155026168464 8.598 35.67081928092419 139.74158193297438 27.529</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e0d93e4a-12b2-46af-8dec-ba559b6c583c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e0d93e4a-12b2-46af-8dec-ba559b6c583c_0">
											<gml:posList>35.67078198501288 139.74155026168464 33.094 35.67078198501288 139.74155026168464 28.893 35.67078124350406 139.74158261718958 29.893 35.67078198501288 139.74155026168464 33.094</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0d6d9197-d188-40ec-a2e8-643dc19589c6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0d6d9197-d188-40ec-a2e8-643dc19589c6_0">
											<gml:posList>35.67078124350406 139.74158261718958 29.893 35.67078198501288 139.74155026168464 28.893 35.67078124350406 139.74158261718958 8.598 35.67078124350406 139.74158261718958 29.893</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a46c6ca0-ac74-46ff-8eca-35dfa272178e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a46c6ca0-ac74-46ff-8eca-35dfa272178e_0">
											<gml:posList>35.67078198501288 139.74155026168464 28.893 35.67078198501288 139.74155026168464 8.598 35.67078124350406 139.74158261718958 8.598 35.67078198501288 139.74155026168464 28.893</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-87d8fa72-49ff-44dc-822c-b270bcb6e4d5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-87d8fa72-49ff-44dc-822c-b270bcb6e4d5_0">
											<gml:posList>35.67079143751493 139.74155828153562 33.094 35.67078124350406 139.74158261718958 29.893 35.670790915489086 139.7415829485571 29.893 35.67079143751493 139.74155828153562 33.094</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0ed856c1-7a43-45d5-ad64-506263ef7fb5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0ed856c1-7a43-45d5-ad64-506263ef7fb5_0">
											<gml:posList>35.67079143751493 139.74155828153562 33.094 35.67078198501288 139.74155026168464 33.094 35.67078124350406 139.74158261718958 29.893 35.67079143751493 139.74155828153562 33.094</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e541cfeb-5a9d-43fb-b3b2-0be9ac8e7bb1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e541cfeb-5a9d-43fb-b3b2-0be9ac8e7bb1_0">
											<gml:posList>35.67079143751493 139.74155828153562 29.893 35.670790915489086 139.7415829485571 29.893 35.67081811063851 139.7415839005586 27.529 35.67079143751493 139.74155828153562 29.893</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7a32104e-28a8-4b90-89a8-bdeb6c9a72ad">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7a32104e-28a8-4b90-89a8-bdeb6c9a72ad_0">
											<gml:posList>35.67081928092419 139.74158193297438 27.529 35.67079143751493 139.74155828153562 29.893 35.67081811063851 139.7415839005586 27.529 35.67081928092419 139.74158193297438 27.529</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-24846797-c4ab-4e90-9b61-8a3e49c8bdfd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-24846797-c4ab-4e90-9b61-8a3e49c8bdfd_0">
											<gml:posList>35.67081811063851 139.7415839005586 27.529 35.67081928092419 139.74158193297438 8.598 35.67081928092419 139.74158193297438 27.529 35.67081811063851 139.7415839005586 27.529</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3a17dd33-0d9d-4c33-949d-ca528e419392">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3a17dd33-0d9d-4c33-949d-ca528e419392_0">
											<gml:posList>35.67081811063851 139.7415839005586 27.529 35.67081811063851 139.7415839005586 8.598 35.67081928092419 139.74158193297438 8.598 35.67081811063851 139.7415839005586 27.529</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-aeaa4d06-7666-4f81-bf84-b0358cf7bba2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-aeaa4d06-7666-4f81-bf84-b0358cf7bba2_0">
											<gml:posList>35.670790915489086 139.7415829485571 29.893 35.67078124350406 139.74158261718958 29.893 35.67081811063851 139.7415839005586 27.529 35.670790915489086 139.7415829485571 29.893</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fc006866-3f10-42dc-9ba8-796a173e42d8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fc006866-3f10-42dc-9ba8-796a173e42d8_0">
											<gml:posList>35.67078124350406 139.74158261718958 29.893 35.67078124350406 139.74158261718958 8.598 35.67081811063851 139.7415839005586 27.529 35.67078124350406 139.74158261718958 29.893</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6ae52f42-1ae8-44e9-ba23-deff2020e7a8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6ae52f42-1ae8-44e9-ba23-deff2020e7a8_0">
											<gml:posList>35.67078124350406 139.74158261718958 8.598 35.67081811063851 139.7415839005586 8.598 35.67081811063851 139.7415839005586 27.529 35.67078124350406 139.74158261718958 8.598</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cca42ff9-4d14-40ce-b873-2535a816396d">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67081811063851 139.7415839005586 8.598 35.67078124350406 139.74158261718958 8.598 35.67078198501288 139.74155026168464 8.598 35.67081928092419 139.74158193297438 8.598 35.67081811063851 139.7415839005586 8.598</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-cf72d385-0f36-4f19-ad34-e13f3ba078ad">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cf72d385-0f36-4f19-ad34-e13f3ba078ad">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cf72d385-0f36-4f19-ad34-e13f3ba078ad">
											<gml:posList>35.67081928092419 139.74158193297438 8.598 35.67078198501288 139.74155026168464 8.598 35.67078394839715 139.74146541269016 8.598 35.670888958261564 139.74146529236708 8.598 35.67081928092419 139.74158193297438 8.598</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-24081eb4-a0aa-4603-9df6-afa8b57c7f44">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-24081eb4-a0aa-4603-9df6-afa8b57c7f44">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-24081eb4-a0aa-4603-9df6-afa8b57c7f44">
											<gml:posList>35.67078394839715 139.74146541269016 33.273 35.67078833327993 139.74147093082374 33.273 35.670858541162836 139.7414708503826 33.273 35.670863043810215 139.7414653220606 33.273 35.67078394839715 139.74146541269016 33.273</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-0952f6d5-8e56-4966-b69c-be7297f1952c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0952f6d5-8e56-4966-b69c-be7297f1952c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0952f6d5-8e56-4966-b69c-be7297f1952c">
											<gml:posList>35.670863076839105 139.74150862362097 33.273 35.670863043810215 139.7414653220606 33.273 35.670858541162836 139.7414708503826 33.273 35.67085856861332 139.74150683927945 33.273 35.670863076839105 139.74150862362097 33.273</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a703bf2c-7076-4e80-b13e-088f3cf32e18">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a703bf2c-7076-4e80-b13e-088f3cf32e18">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a703bf2c-7076-4e80-b13e-088f3cf32e18">
											<gml:posList>35.670863043810215 139.7414653220606 10.901 35.670863076839105 139.74150862362097 10.901 35.670888958261564 139.74146529236708 10.901 35.670863043810215 139.7414653220606 10.901</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-3a3d6b9b-6827-4f42-a7f0-8436b87c828b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3a3d6b9b-6827-4f42-a7f0-8436b87c828b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3a3d6b9b-6827-4f42-a7f0-8436b87c828b">
											<gml:posList>35.67078198501288 139.74155026168464 33.273 35.67078655281458 139.7415474285988 33.273 35.67078833327993 139.74147093082374 33.273 35.67078394839715 139.74146541269016 33.273 35.67078198501288 139.74155026168464 33.273</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-5b98d57f-bf9d-48c8-90e3-c399854831ed">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5b98d57f-bf9d-48c8-90e3-c399854831ed">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5b98d57f-bf9d-48c8-90e3-c399854831ed">
											<gml:posList>35.67085856861332 139.74150683927945 32.797 35.670858541162836 139.7414708503826 32.797 35.67078833327993 139.74147093082374 32.797 35.67078655281458 139.7415474285988 32.797 35.670818247577124 139.74157434533515 32.797 35.67085856861332 139.74150683927945 32.797</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e190ae62-4a5b-46c8-8f1c-2848e3291fae">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e190ae62-4a5b-46c8-8f1c-2848e3291fae">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e190ae62-4a5b-46c8-8f1c-2848e3291fae">
											<gml:posList>35.670863076839105 139.74150862362097 33.273 35.67085856861332 139.74150683927945 33.273 35.670818247577124 139.74157434533515 33.273 35.67081928092419 139.74158193297438 33.273 35.670863076839105 139.74150862362097 33.273</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-679b66cc-8f51-45e2-8099-e0f455a9078e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-679b66cc-8f51-45e2-8099-e0f455a9078e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-679b66cc-8f51-45e2-8099-e0f455a9078e">
											<gml:posList>35.67078198501288 139.74155026168464 33.273 35.67081928092419 139.74158193297438 33.273 35.670818247577124 139.74157434533515 33.273 35.67078655281458 139.7415474285988 33.273 35.67078198501288 139.74155026168464 33.273</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4dc18189-886f-47a2-ba53-3444c60367d8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4dc18189-886f-47a2-ba53-3444c60367d8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4dc18189-886f-47a2-ba53-3444c60367d8">
											<gml:posList>35.67078394839715 139.74146541269016 8.598 35.67078198501288 139.74155026168464 8.598 35.67078198501288 139.74155026168464 33.273 35.67078394839715 139.74146541269016 33.273 35.67078394839715 139.74146541269016 8.598</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-acf86684-6187-430c-996a-7900a7a1337a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-acf86684-6187-430c-996a-7900a7a1337a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-acf86684-6187-430c-996a-7900a7a1337a">
											<gml:posList>35.67078655281458 139.7415474285988 33.273 35.67078655281458 139.7415474285988 32.797 35.67078833327993 139.74147093082374 32.797 35.67078833327993 139.74147093082374 33.273 35.67078655281458 139.7415474285988 33.273</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ec2433df-d585-4c8d-a217-40bd858c8f97">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ec2433df-d585-4c8d-a217-40bd858c8f97">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ec2433df-d585-4c8d-a217-40bd858c8f97">
											<gml:posList>35.67078198501288 139.74155026168464 8.598 35.67081928092419 139.74158193297438 8.598 35.67081928092419 139.74158193297438 33.273 35.67078198501288 139.74155026168464 33.273 35.67078198501288 139.74155026168464 8.598</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ff12e127-8e8d-4a39-930e-c7fd8762e944">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ff12e127-8e8d-4a39-930e-c7fd8762e944">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ff12e127-8e8d-4a39-930e-c7fd8762e944">
											<gml:posList>35.670818247577124 139.74157434533515 33.273 35.670818247577124 139.74157434533515 32.797 35.67078655281458 139.7415474285988 32.797 35.67078655281458 139.7415474285988 33.273 35.670818247577124 139.74157434533515 33.273</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-dbf59053-44d9-422b-a2ad-cb16b5d34112">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-dbf59053-44d9-422b-a2ad-cb16b5d34112">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-dbf59053-44d9-422b-a2ad-cb16b5d34112">
											<gml:posList>35.67078833327993 139.74147093082374 33.273 35.67078833327993 139.74147093082374 32.797 35.670858541162836 139.7414708503826 32.797 35.670858541162836 139.7414708503826 33.273 35.67078833327993 139.74147093082374 33.273</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-52e4876b-1e63-4941-ac54-88ee5ae3760b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-52e4876b-1e63-4941-ac54-88ee5ae3760b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-52e4876b-1e63-4941-ac54-88ee5ae3760b">
											<gml:posList>35.67078394839715 139.74146541269016 8.598 35.67078394839715 139.74146541269016 33.273 35.670863043810215 139.7414653220606 33.273 35.670863043810215 139.7414653220606 10.901 35.670888958261564 139.74146529236708 10.901 35.670888958261564 139.74146529236708 8.598 35.67078394839715 139.74146541269016 8.598</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ec42b455-a814-4621-9330-01352fcbf7d4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ec42b455-a814-4621-9330-01352fcbf7d4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ec42b455-a814-4621-9330-01352fcbf7d4">
											<gml:posList>35.67085856861332 139.74150683927945 33.273 35.67085856861332 139.74150683927945 32.797 35.670818247577124 139.74157434533515 32.797 35.670818247577124 139.74157434533515 33.273 35.67085856861332 139.74150683927945 33.273</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-dc0b340e-907d-488c-85a0-e07a7ab6fa72">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-dc0b340e-907d-488c-85a0-e07a7ab6fa72">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-dc0b340e-907d-488c-85a0-e07a7ab6fa72">
											<gml:posList>35.670863076839105 139.74150862362097 10.901 35.670863076839105 139.74150862362097 33.273 35.67081928092419 139.74158193297438 33.273 35.67081928092419 139.74158193297438 8.598 35.670888958261564 139.74146529236708 8.598 35.670888958261564 139.74146529236708 10.901 35.670863076839105 139.74150862362097 10.901</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9d04dae2-c595-4b91-910a-78f0c965533d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9d04dae2-c595-4b91-910a-78f0c965533d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9d04dae2-c595-4b91-910a-78f0c965533d">
											<gml:posList>35.670858541162836 139.7414708503826 33.273 35.670858541162836 139.7414708503826 32.797 35.67085856861332 139.74150683927945 32.797 35.67085856861332 139.74150683927945 33.273 35.670858541162836 139.7414708503826 33.273</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-72b15200-2892-406a-bd81-110528ad61ea">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-72b15200-2892-406a-bd81-110528ad61ea">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-72b15200-2892-406a-bd81-110528ad61ea">
											<gml:posList>35.670863043810215 139.7414653220606 10.901 35.670863043810215 139.7414653220606 33.273 35.670863076839105 139.74150862362097 33.273 35.670863076839105 139.74150862362097 10.901 35.670863043810215 139.7414653220606 10.901</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-6848</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">84.2183</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1210</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>7</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.02</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>