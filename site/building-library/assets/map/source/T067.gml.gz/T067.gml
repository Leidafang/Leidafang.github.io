<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_108c4a1c-8623-4eae-9ab1-4393e94d747e">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="再開発等促進区を定める地区計画">
				<gen:value>永田町二丁目地区</gen:value>
			</gen:stringAttribute>
			<bldg:measuredHeight uom="m">4.4</bldg:measuredHeight>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.67461284309789 139.73985902296073 0 35.6746178626107 139.7397995298568 0 35.674617889402974 139.73979920946715 0 35.67460275387177 139.73979729392957 0 35.674585635125545 139.73979512662953 0 35.67457656642595 139.73979397729315 0 35.674577620423584 139.7397815925582 0 35.67456735277941 139.7397802899669 0 35.674568013665876 139.73977240175444 0 35.6745282592199 139.7397673555629 0 35.67452758932006 139.73977524378196 0 35.674523163147576 139.73977468555927 0 35.674517366530154 139.73984329313507 0 35.67452231554933 139.73984391703274 0 35.674521860018196 139.7398492863234 0 35.67456330920246 139.73985454046888 0 35.67458042795626 139.73985671882787 0 35.67459755571515 139.73985888613043 0 35.674597582516164 139.73985857678764 0 35.67461271804645 139.73986049233662 0 35.67461284309789 139.73985902296073 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67461284309789 139.73985902296073 27.879 35.67461271804645 139.73986049233662 27.879 35.674597582516164 139.73985857678764 27.879 35.67459755571515 139.73985888613043 27.879 35.67458042795626 139.73985671882787 27.879 35.67456330920246 139.73985454046888 27.879 35.674521860018196 139.7398492863234 27.879 35.67452231554933 139.73984391703274 27.879 35.674517366530154 139.73984329313507 27.879 35.674523163147576 139.73977468555927 27.879 35.67452758932006 139.73977524378196 27.879 35.6745282592199 139.7397673555629 27.879 35.674568013665876 139.73977240175444 27.879 35.67456735277941 139.7397802899669 27.879 35.674577620423584 139.7397815925582 27.879 35.67457656642595 139.73979397729315 27.879 35.674585635125545 139.73979512662953 27.879 35.67460275387177 139.73979729392957 27.879 35.674617889402974 139.73979920946715 27.879 35.6746178626107 139.7397995298568 27.879 35.67461284309789 139.73985902296073 27.879</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67461284309789 139.73985902296073 27.879 35.6746178626107 139.7397995298568 27.879 35.6746178626107 139.7397995298568 31.63 35.67461284309789 139.73985902296073 31.63 35.67461284309789 139.73985902296073 27.879</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6746178626107 139.7397995298568 27.879 35.674617889402974 139.73979920946715 27.879 35.674617889402974 139.73979920946715 31.63 35.6746178626107 139.7397995298568 31.63 35.6746178626107 139.7397995298568 27.879</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.674617889402974 139.73979920946715 27.879 35.67460275387177 139.73979729392957 27.879 35.67460275387177 139.73979729392957 31.63 35.674617889402974 139.73979920946715 31.63 35.674617889402974 139.73979920946715 27.879</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67460275387177 139.73979729392957 27.879 35.674585635125545 139.73979512662953 27.879 35.674585635125545 139.73979512662953 31.63 35.67460275387177 139.73979729392957 31.63 35.67460275387177 139.73979729392957 27.879</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.674585635125545 139.73979512662953 27.879 35.67457656642595 139.73979397729315 27.879 35.67457656642595 139.73979397729315 31.63 35.674585635125545 139.73979512662953 31.63 35.674585635125545 139.73979512662953 27.879</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67457656642595 139.73979397729315 27.879 35.674577620423584 139.7397815925582 27.879 35.674577620423584 139.7397815925582 31.63 35.67457656642595 139.73979397729315 31.63 35.67457656642595 139.73979397729315 27.879</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.674577620423584 139.7397815925582 27.879 35.67456735277941 139.7397802899669 27.879 35.67456735277941 139.7397802899669 31.63 35.674577620423584 139.7397815925582 31.63 35.674577620423584 139.7397815925582 27.879</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67456735277941 139.7397802899669 27.879 35.674568013665876 139.73977240175444 27.879 35.674568013665876 139.73977240175444 31.63 35.67456735277941 139.7397802899669 31.63 35.67456735277941 139.7397802899669 27.879</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.674568013665876 139.73977240175444 27.879 35.6745282592199 139.7397673555629 27.879 35.6745282592199 139.7397673555629 31.63 35.674568013665876 139.73977240175444 31.63 35.674568013665876 139.73977240175444 27.879</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6745282592199 139.7397673555629 27.879 35.67452758932006 139.73977524378196 27.879 35.67452758932006 139.73977524378196 31.63 35.6745282592199 139.7397673555629 31.63 35.6745282592199 139.7397673555629 27.879</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67452758932006 139.73977524378196 27.879 35.674523163147576 139.73977468555927 27.879 35.674523163147576 139.73977468555927 31.63 35.67452758932006 139.73977524378196 31.63 35.67452758932006 139.73977524378196 27.879</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.674523163147576 139.73977468555927 27.879 35.674517366530154 139.73984329313507 27.879 35.674517366530154 139.73984329313507 31.63 35.674523163147576 139.73977468555927 31.63 35.674523163147576 139.73977468555927 27.879</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.674517366530154 139.73984329313507 27.879 35.67452231554933 139.73984391703274 27.879 35.67452231554933 139.73984391703274 31.63 35.674517366530154 139.73984329313507 31.63 35.674517366530154 139.73984329313507 27.879</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67452231554933 139.73984391703274 27.879 35.674521860018196 139.7398492863234 27.879 35.674521860018196 139.7398492863234 31.63 35.67452231554933 139.73984391703274 31.63 35.67452231554933 139.73984391703274 27.879</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.674521860018196 139.7398492863234 27.879 35.67456330920246 139.73985454046888 27.879 35.67456330920246 139.73985454046888 31.63 35.674521860018196 139.7398492863234 31.63 35.674521860018196 139.7398492863234 27.879</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67456330920246 139.73985454046888 27.879 35.67458042795626 139.73985671882787 27.879 35.67458042795626 139.73985671882787 31.63 35.67456330920246 139.73985454046888 31.63 35.67456330920246 139.73985454046888 27.879</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67458042795626 139.73985671882787 27.879 35.67459755571515 139.73985888613043 27.879 35.67459755571515 139.73985888613043 31.63 35.67458042795626 139.73985671882787 31.63 35.67458042795626 139.73985671882787 27.879</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67459755571515 139.73985888613043 27.879 35.674597582516164 139.73985857678764 27.879 35.674597582516164 139.73985857678764 31.63 35.67459755571515 139.73985888613043 31.63 35.67459755571515 139.73985888613043 27.879</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.674597582516164 139.73985857678764 27.879 35.67461271804645 139.73986049233662 27.879 35.67461271804645 139.73986049233662 31.63 35.674597582516164 139.73985857678764 31.63 35.674597582516164 139.73985857678764 27.879</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67461271804645 139.73986049233662 27.879 35.67461284309789 139.73985902296073 27.879 35.67461284309789 139.73985902296073 31.63 35.67461271804645 139.73986049233662 31.63 35.67461271804645 139.73986049233662 27.879</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67461284309789 139.73985902296073 31.63 35.6746178626107 139.7397995298568 31.63 35.674617889402974 139.73979920946715 31.63 35.67460275387177 139.73979729392957 31.63 35.674585635125545 139.73979512662953 31.63 35.67457656642595 139.73979397729315 31.63 35.674577620423584 139.7397815925582 31.63 35.67456735277941 139.7397802899669 31.63 35.674568013665876 139.73977240175444 31.63 35.6745282592199 139.7397673555629 31.63 35.67452758932006 139.73977524378196 31.63 35.674523163147576 139.73977468555927 31.63 35.674517366530154 139.73984329313507 31.63 35.67452231554933 139.73984391703274 31.63 35.674521860018196 139.7398492863234 31.63 35.67456330920246 139.73985454046888 31.63 35.67458042795626 139.73985671882787 31.63 35.67459755571515 139.73985888613043 31.63 35.674597582516164 139.73985857678764 31.63 35.67461271804645 139.73986049233662 31.63 35.67461284309789 139.73985902296073 31.63</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-8ebe99a8-38fe-47dd-9269-df80827b8f66"/>
							<gml:surfaceMember xlink:href="#poly-d6f51ee8-a5a9-4a1f-9d0e-becff3fe592b"/>
							<gml:surfaceMember xlink:href="#poly-7b840db8-227f-499e-8bd9-9d6396a02977"/>
							<gml:surfaceMember xlink:href="#poly-5ec961fe-923a-410c-b6b6-c08d72e5117f"/>
							<gml:surfaceMember xlink:href="#poly-7d9f6a0e-644b-47fb-a324-1103b791cebd"/>
							<gml:surfaceMember xlink:href="#poly-6331b661-fe1a-4325-970d-85e03fb6d670"/>
							<gml:surfaceMember xlink:href="#poly-fab0d564-9830-4ef0-b7ad-0ce59c8bd3b2"/>
							<gml:surfaceMember xlink:href="#poly-259a5160-0431-4d0e-8829-76e1231c7a5c"/>
							<gml:surfaceMember xlink:href="#poly-50582aff-c4e2-45d0-b95e-5a2d73fdf0ca"/>
							<gml:surfaceMember xlink:href="#poly-293273e8-8b68-4d16-afda-037da81b378b"/>
							<gml:surfaceMember xlink:href="#poly-0d427738-771e-473b-933a-96b347dcbbd2"/>
							<gml:surfaceMember xlink:href="#poly-838a6173-6b52-47b7-990f-561f84a05e27"/>
							<gml:surfaceMember xlink:href="#poly-63a440fe-5041-473f-836c-074994794046"/>
							<gml:surfaceMember xlink:href="#poly-906d28d2-e762-4da4-81c4-32bc0179c560"/>
							<gml:surfaceMember xlink:href="#poly-555cfdf1-18a9-4f15-b24b-e4832afe305d"/>
							<gml:surfaceMember xlink:href="#poly-c083de37-da30-492c-a24d-11e04dce5382"/>
							<gml:surfaceMember xlink:href="#poly-8cc92fd9-174a-4565-b8d0-09d584af9806"/>
							<gml:surfaceMember xlink:href="#poly-45ff3b52-08fb-4325-a195-e812e6212297"/>
							<gml:surfaceMember xlink:href="#poly-15ee940e-81bb-427b-a6b2-abeaf27def92"/>
							<gml:surfaceMember xlink:href="#poly-258e771a-4127-4fe0-8912-f132f350e0b3"/>
							<gml:surfaceMember xlink:href="#poly-6aaaf5e0-bb8b-48db-bb0e-8aa7a698d6c2"/>
							<gml:surfaceMember xlink:href="#poly-984dd6d9-3c11-47b6-9658-6cb183c6b2d5"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-8ebe99a8-38fe-47dd-9269-df80827b8f66">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8ebe99a8-38fe-47dd-9269-df80827b8f66">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8ebe99a8-38fe-47dd-9269-df80827b8f66">
											<gml:posList>35.67452758932004 139.73977524378193 27.879 35.67452825921988 139.73976735556286 27.879 35.67456801366585 139.73977240175444 27.879 35.67456735277941 139.7397802899669 27.879 35.67457762042358 139.7397815925582 27.879 35.67457656642592 139.73979397729312 27.879 35.674617889402974 139.73979920946712 27.879 35.67461270904129 139.73986050339397 27.879 35.674521860001036 139.73984926422975 27.879 35.67452231554932 139.73984391703274 27.879 35.67451736653014 139.73984329313507 27.879 35.67452316314758 139.73977468555924 27.879 35.67452758932004 139.73977524378193 27.879</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d6f51ee8-a5a9-4a1f-9d0e-becff3fe592b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d6f51ee8-a5a9-4a1f-9d0e-becff3fe592b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d6f51ee8-a5a9-4a1f-9d0e-becff3fe592b">
											<gml:posList>35.67454235503056 139.73984645652774 32.246 35.674547475560935 139.73977777239196 32.246 35.67452316314758 139.73977468555924 31.496 35.67451736653014 139.73984329313507 31.496 35.67454235503056 139.73984645652774 32.246</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-7b840db8-227f-499e-8bd9-9d6396a02977">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7b840db8-227f-499e-8bd9-9d6396a02977">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7b840db8-227f-499e-8bd9-9d6396a02977">
											<gml:posList>35.67456376473379 139.73984917117548 30.746 35.67452231554932 139.73984391703274 30.746 35.674521851064526 139.73984936366165 30.746 35.674563309168136 139.7398544962816 30.746 35.67456376473379 139.73984917117548 30.746</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-5ec961fe-923a-410c-b6b6-c08d72e5117f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5ec961fe-923a-410c-b6b6-c08d72e5117f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5ec961fe-923a-410c-b6b6-c08d72e5117f">
											<gml:posList>35.67452758932004 139.73977524378193 30.746 35.67456735277941 139.7397802899669 30.746 35.67456801366585 139.73977240175444 30.746 35.67452825921988 139.73976735556286 30.746 35.67452758932004 139.73977524378193 30.746</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-7d9f6a0e-644b-47fb-a324-1103b791cebd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7d9f6a0e-644b-47fb-a324-1103b791cebd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7d9f6a0e-644b-47fb-a324-1103b791cebd">
											<gml:posList>35.67457182380233 139.73985020018011 31.496 35.67457762042358 139.7397815925582 31.496 35.674547475560935 139.73977777239196 32.246 35.67454235503056 139.73984645652774 32.246 35.67457182380233 139.73985020018011 31.496</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-6331b661-fe1a-4325-970d-85e03fb6d670">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6331b661-fe1a-4325-970d-85e03fb6d670">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6331b661-fe1a-4325-970d-85e03fb6d670">
											<gml:posList>35.67457182380233 139.73985020018011 30.496 35.67456376473379 139.73984917117548 30.496 35.67456330915956 139.73985448523476 30.496 35.67457182380233 139.73985020018011 30.496</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-fab0d564-9830-4ef0-b7ad-0ce59c8bd3b2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fab0d564-9830-4ef0-b7ad-0ce59c8bd3b2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fab0d564-9830-4ef0-b7ad-0ce59c8bd3b2">
											<gml:posList>35.67457182380233 139.73985020018011 30.496 35.67456330915956 139.73985448523476 30.496 35.674580436918525 139.7398566525364 31.632 35.67457182380233 139.73985020018011 30.496</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-259a5160-0431-4d0e-8829-76e1231c7a5c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-259a5160-0431-4d0e-8829-76e1231c7a5c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-259a5160-0431-4d0e-8829-76e1231c7a5c">
											<gml:posList>35.67458563511694 139.7397951155827 31.632 35.67457656642592 139.73979397729312 30.496 35.67457182380233 139.73985020018011 30.496 35.674580436918525 139.7398566525364 31.632 35.67458563511694 139.7397951155827 31.632</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-50582aff-c4e2-45d0-b95e-5a2d73fdf0ca">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-50582aff-c4e2-45d0-b95e-5a2d73fdf0ca">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-50582aff-c4e2-45d0-b95e-5a2d73fdf0ca">
											<gml:posList>35.67460275387175 139.73979729392957 30.496 35.67458563511694 139.7397951155827 31.632 35.674580436918525 139.7398566525364 31.632 35.67459756460879 139.73985873146427 30.496 35.67460275387175 139.73979729392957 30.496</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-293273e8-8b68-4d16-afda-037da81b378b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-293273e8-8b68-4d16-afda-037da81b378b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-293273e8-8b68-4d16-afda-037da81b378b">
											<gml:posList>35.67460275387175 139.73979729392957 30.496 35.67459756460879 139.73985873146427 30.496 35.67461270911847 139.73986060281547 30.496 35.674617889402974 139.73979920946712 30.496 35.67460275387175 139.73979729392957 30.496</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0d427738-771e-473b-933a-96b347dcbbd2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0d427738-771e-473b-933a-96b347dcbbd2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0d427738-771e-473b-933a-96b347dcbbd2">
											<gml:posList>35.67456376473379 139.73984917117548 30.496 35.67456376473379 139.73984917117548 30.746 35.674563309168136 139.7398544962816 30.746 35.67456330915956 139.73985448523476 30.496 35.67456376473379 139.73984917117548 30.496</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-838a6173-6b52-47b7-990f-561f84a05e27">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-838a6173-6b52-47b7-990f-561f84a05e27">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-838a6173-6b52-47b7-990f-561f84a05e27">
											<gml:posList>35.67452316314758 139.73977468555924 31.496 35.67452316314758 139.73977468555924 27.879 35.67451736653014 139.73984329313507 27.879 35.67451736653014 139.73984329313507 31.496 35.67452316314758 139.73977468555924 31.496</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-63a440fe-5041-473f-836c-074994794046">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-63a440fe-5041-473f-836c-074994794046">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-63a440fe-5041-473f-836c-074994794046">
											<gml:posList>35.67452231554932 139.73984391703274 30.746 35.67452231554932 139.73984391703274 27.879 35.674521860001036 139.73984926422975 27.879 35.674521851064526 139.73984936366165 30.746 35.67452231554932 139.73984391703274 30.746</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-906d28d2-e762-4da4-81c4-32bc0179c560">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-906d28d2-e762-4da4-81c4-32bc0179c560">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-906d28d2-e762-4da4-81c4-32bc0179c560">
											<gml:posList>35.67452758932004 139.73977524378193 27.879 35.67452758932004 139.73977524378193 30.746 35.67452825921988 139.73976735556286 30.746 35.67452825921988 139.73976735556286 27.879 35.67452758932004 139.73977524378193 27.879</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-555cfdf1-18a9-4f15-b24b-e4832afe305d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-555cfdf1-18a9-4f15-b24b-e4832afe305d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-555cfdf1-18a9-4f15-b24b-e4832afe305d">
											<gml:posList>35.67451736653014 139.73984329313507 31.496 35.67451736653014 139.73984329313507 27.879 35.67452231554932 139.73984391703274 27.879 35.67452231554932 139.73984391703274 30.746 35.67456376473379 139.73984917117548 30.746 35.67456376473379 139.73984917117548 30.496 35.67457182380233 139.73985020018011 30.496 35.67457182380233 139.73985020018011 31.496 35.67454235503056 139.73984645652774 32.246 35.67451736653014 139.73984329313507 31.496</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c083de37-da30-492c-a24d-11e04dce5382">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c083de37-da30-492c-a24d-11e04dce5382">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c083de37-da30-492c-a24d-11e04dce5382">
											<gml:posList>35.67456801366585 139.73977240175444 30.746 35.67456801366585 139.73977240175444 27.879 35.67452825921988 139.73976735556286 27.879 35.67452825921988 139.73976735556286 30.746 35.67456801366585 139.73977240175444 30.746</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8cc92fd9-174a-4565-b8d0-09d584af9806">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8cc92fd9-174a-4565-b8d0-09d584af9806">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8cc92fd9-174a-4565-b8d0-09d584af9806">
											<gml:posList>35.67452758932004 139.73977524378193 30.746 35.67452758932004 139.73977524378193 27.879 35.67452316314758 139.73977468555924 27.879 35.67452316314758 139.73977468555924 31.496 35.674547475560935 139.73977777239196 32.246 35.67457762042358 139.7397815925582 31.496 35.67457762042358 139.7397815925582 27.879 35.67456735277941 139.7397802899669 27.879 35.67456735277941 139.7397802899669 30.746 35.67452758932004 139.73977524378193 30.746</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-45ff3b52-08fb-4325-a195-e812e6212297">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-45ff3b52-08fb-4325-a195-e812e6212297">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-45ff3b52-08fb-4325-a195-e812e6212297">
											<gml:posList>35.67459756460879 139.73985873146427 30.496 35.674580436918525 139.7398566525364 31.632 35.67456330915956 139.73985448523476 30.496 35.674563309168136 139.7398544962816 30.746 35.674521851064526 139.73984936366165 30.746 35.674521860001036 139.73984926422975 27.879 35.67461270904129 139.73986050339397 27.879 35.67461270911847 139.73986060281547 30.496 35.67459756460879 139.73985873146427 30.496</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-15ee940e-81bb-427b-a6b2-abeaf27def92">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-15ee940e-81bb-427b-a6b2-abeaf27def92">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-15ee940e-81bb-427b-a6b2-abeaf27def92">
											<gml:posList>35.67456735277941 139.7397802899669 30.746 35.67456735277941 139.7397802899669 27.879 35.67456801366585 139.73977240175444 27.879 35.67456801366585 139.73977240175444 30.746 35.67456735277941 139.7397802899669 30.746</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-258e771a-4127-4fe0-8912-f132f350e0b3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-258e771a-4127-4fe0-8912-f132f350e0b3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-258e771a-4127-4fe0-8912-f132f350e0b3">
											<gml:posList>35.67457656642592 139.73979397729312 30.496 35.67457656642592 139.73979397729312 27.879 35.67457762042358 139.7397815925582 27.879 35.67457762042358 139.7397815925582 31.496 35.67457182380233 139.73985020018011 31.496 35.67457182380233 139.73985020018011 30.496 35.67457656642592 139.73979397729312 30.496</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6aaaf5e0-bb8b-48db-bb0e-8aa7a698d6c2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6aaaf5e0-bb8b-48db-bb0e-8aa7a698d6c2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6aaaf5e0-bb8b-48db-bb0e-8aa7a698d6c2">
											<gml:posList>35.67457656642592 139.73979397729312 27.879 35.67457656642592 139.73979397729312 30.496 35.67458563511694 139.7397951155827 31.632 35.67460275387175 139.73979729392957 30.496 35.674617889402974 139.73979920946712 30.496 35.674617889402974 139.73979920946712 27.879 35.67457656642592 139.73979397729312 27.879</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-984dd6d9-3c11-47b6-9658-6cb183c6b2d5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-984dd6d9-3c11-47b6-9658-6cb183c6b2d5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-984dd6d9-3c11-47b6-9658-6cb183c6b2d5">
											<gml:posList>35.67461270911847 139.73986060281547 30.496 35.67461270904129 139.73986050339397 27.879 35.674617889402974 139.73979920946712 27.879 35.674617889402974 139.73979920946712 30.496 35.67461270911847 139.73986060281547 30.496</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13101-bldg-4597</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13101</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">214</uro:landUseType>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>5</uro:specifiedFloorAreaRate>
					<uro:surveyYear>0001</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.0</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>