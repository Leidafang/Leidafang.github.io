<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_11cca6f4-9a60-464f-a5c9-eac084376b4e">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="再開発等促進区を定める地区計画">
				<gen:value>永田町二丁目地区</gen:value>
			</gen:stringAttribute>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.67462581104789 139.73976257993527 0 35.67462264036083 139.73980014290558 0 35.6746178626107 139.7397995298568 0 35.67461284309789 139.73985902296073 0 35.67463228761322 139.73986148582816 0 35.67464048679426 139.739764385535 0 35.67462581104789 139.73976257993527 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67462581104789 139.73976257993527 28.49 35.67464048679426 139.739764385535 28.49 35.67463228761322 139.73986148582816 28.49 35.67461284309789 139.73985902296073 28.49 35.6746178626107 139.7397995298568 28.49 35.67462264036083 139.73980014290558 28.49 35.67462581104789 139.73976257993527 28.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67462581104789 139.73976257993527 28.49 35.67462264036083 139.73980014290558 28.49 35.67462264036083 139.73980014290558 31.49 35.67462581104789 139.73976257993527 31.49 35.67462581104789 139.73976257993527 28.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67462264036083 139.73980014290558 28.49 35.6746178626107 139.7397995298568 28.49 35.6746178626107 139.7397995298568 31.49 35.67462264036083 139.73980014290558 31.49 35.67462264036083 139.73980014290558 28.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6746178626107 139.7397995298568 28.49 35.67461284309789 139.73985902296073 28.49 35.67461284309789 139.73985902296073 31.49 35.6746178626107 139.7397995298568 31.49 35.6746178626107 139.7397995298568 28.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67461284309789 139.73985902296073 28.49 35.67463228761322 139.73986148582816 28.49 35.67463228761322 139.73986148582816 31.49 35.67461284309789 139.73985902296073 31.49 35.67461284309789 139.73985902296073 28.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67463228761322 139.73986148582816 28.49 35.67464048679426 139.739764385535 28.49 35.67464048679426 139.739764385535 31.49 35.67463228761322 139.73986148582816 31.49 35.67463228761322 139.73986148582816 28.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67464048679426 139.739764385535 28.49 35.67462581104789 139.73976257993527 28.49 35.67462581104789 139.73976257993527 31.49 35.67464048679426 139.739764385535 31.49 35.67464048679426 139.739764385535 28.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67462581104789 139.73976257993527 31.49 35.67462264036083 139.73980014290558 31.49 35.6746178626107 139.7397995298568 31.49 35.67461284309789 139.73985902296073 31.49 35.67463228761322 139.73986148582816 31.49 35.67464048679426 139.739764385535 31.49 35.67462581104789 139.73976257993527 31.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-57703ab4-afe6-467e-8fcd-f726ff332e20"/>
							<gml:surfaceMember xlink:href="#poly-a7addf85-03a9-40c8-912d-ab102921556f"/>
							<gml:surfaceMember xlink:href="#poly-73a987ca-916b-4447-9e61-ce103c7e9387"/>
							<gml:surfaceMember xlink:href="#poly-11873097-b9a9-4f1f-a116-9674e059e884"/>
							<gml:surfaceMember xlink:href="#poly-e3ae6fe5-d594-49d3-8281-318a43d81f08"/>
							<gml:surfaceMember xlink:href="#poly-bb638732-5959-4344-8901-2b20f97a6419"/>
							<gml:surfaceMember xlink:href="#poly-d7845d5d-df51-4f6b-a953-0e5d7c8989da"/>
							<gml:surfaceMember xlink:href="#poly-3367afce-4bda-4c68-b4b7-f11fdaa9d765"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-57703ab4-afe6-467e-8fcd-f726ff332e20">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-57703ab4-afe6-467e-8fcd-f726ff332e20">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-57703ab4-afe6-467e-8fcd-f726ff332e20">
											<gml:posList>35.67461303238592 139.73985902274003 28.49 35.67461806091244 139.73979952962543 28.49 35.67462264036081 139.73980014290555 28.49 35.67462573910128 139.7397627899093 28.49 35.674640414890526 139.73976465074324 28.49 35.67463228761322 139.73986148582816 28.49 35.67461303238592 139.73985902274003 28.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a7addf85-03a9-40c8-912d-ab102921556f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a7addf85-03a9-40c8-912d-ab102921556f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a7addf85-03a9-40c8-912d-ab102921556f">
											<gml:posList>35.674640414890526 139.73976465074324 30.496 35.67462573910128 139.7397627899093 30.496 35.67462264036081 139.73980014290555 30.496 35.67461806091244 139.73979952962543 30.496 35.67461303238592 139.73985902274003 30.496 35.67463228761322 139.73986148582816 30.496 35.674640414890526 139.73976465074324 30.496</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-73a987ca-916b-4447-9e61-ce103c7e9387">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-73a987ca-916b-4447-9e61-ce103c7e9387">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-73a987ca-916b-4447-9e61-ce103c7e9387">
											<gml:posList>35.674640414890526 139.73976465074324 28.49 35.67462573910128 139.7397627899093 28.49 35.67462573910128 139.7397627899093 30.496 35.674640414890526 139.73976465074324 30.496 35.674640414890526 139.73976465074324 28.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-11873097-b9a9-4f1f-a116-9674e059e884">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-11873097-b9a9-4f1f-a116-9674e059e884">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-11873097-b9a9-4f1f-a116-9674e059e884">
											<gml:posList>35.67461806091244 139.73979952962543 28.49 35.67461303238592 139.73985902274003 28.49 35.67461303238592 139.73985902274003 30.496 35.67461806091244 139.73979952962543 30.496 35.67461806091244 139.73979952962543 28.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e3ae6fe5-d594-49d3-8281-318a43d81f08">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e3ae6fe5-d594-49d3-8281-318a43d81f08">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e3ae6fe5-d594-49d3-8281-318a43d81f08">
											<gml:posList>35.67462264036081 139.73980014290555 28.49 35.67461806091244 139.73979952962543 28.49 35.67461806091244 139.73979952962543 30.496 35.67462264036081 139.73980014290555 30.496 35.67462264036081 139.73980014290555 28.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-bb638732-5959-4344-8901-2b20f97a6419">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bb638732-5959-4344-8901-2b20f97a6419">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bb638732-5959-4344-8901-2b20f97a6419">
											<gml:posList>35.67461303238592 139.73985902274003 28.49 35.67463228761322 139.73986148582816 28.49 35.67463228761322 139.73986148582816 30.496 35.67461303238592 139.73985902274003 30.496 35.67461303238592 139.73985902274003 28.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d7845d5d-df51-4f6b-a953-0e5d7c8989da">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d7845d5d-df51-4f6b-a953-0e5d7c8989da">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d7845d5d-df51-4f6b-a953-0e5d7c8989da">
											<gml:posList>35.67462573910128 139.7397627899093 28.49 35.67462264036081 139.73980014290555 28.49 35.67462264036081 139.73980014290555 30.496 35.67462573910128 139.7397627899093 30.496 35.67462573910128 139.7397627899093 28.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3367afce-4bda-4c68-b4b7-f11fdaa9d765">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3367afce-4bda-4c68-b4b7-f11fdaa9d765">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3367afce-4bda-4c68-b4b7-f11fdaa9d765">
											<gml:posList>35.67463228761322 139.73986148582816 28.49 35.674640414890526 139.73976465074324 28.49 35.674640414890526 139.73976465074324 30.496 35.67463228761322 139.73986148582816 30.496 35.67463228761322 139.73986148582816 28.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13101-bldg-4596</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13101</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">214</uro:landUseType>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>5</uro:specifiedFloorAreaRate>
					<uro:surveyYear>0001</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">0</uro:lod1HeightType>
					<uro:lodType>2.0</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>