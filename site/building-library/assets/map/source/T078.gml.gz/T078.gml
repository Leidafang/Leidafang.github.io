<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_1530fb56-2a23-46df-a7ff-7605ac5ab791">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001001</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">401</bldg:usage>
			<bldg:measuredHeight uom="m">16.2</bldg:measuredHeight>
			<bldg:storeysAboveGround>5</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.670159267262726 139.74467251742243 0 35.670172027129404 139.74461870816677 0 35.6700867342639 139.7445875417395 0 35.67007370416193 139.7446415721661 0 35.670159267262726 139.74467251742243 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670159267262726 139.74467251742243 8.444 35.67007370416193 139.7446415721661 8.444 35.6700867342639 139.7445875417395 8.444 35.670172027129404 139.74461870816677 8.444 35.670159267262726 139.74467251742243 8.444</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670159267262726 139.74467251742243 8.444 35.670172027129404 139.74461870816677 8.444 35.670172027129404 139.74461870816677 24.68 35.670159267262726 139.74467251742243 24.68 35.670159267262726 139.74467251742243 8.444</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670172027129404 139.74461870816677 8.444 35.6700867342639 139.7445875417395 8.444 35.6700867342639 139.7445875417395 24.68 35.670172027129404 139.74461870816677 24.68 35.670172027129404 139.74461870816677 8.444</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6700867342639 139.7445875417395 8.444 35.67007370416193 139.7446415721661 8.444 35.67007370416193 139.7446415721661 24.68 35.6700867342639 139.7445875417395 24.68 35.6700867342639 139.7445875417395 8.444</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67007370416193 139.7446415721661 8.444 35.670159267262726 139.74467251742243 8.444 35.670159267262726 139.74467251742243 24.68 35.67007370416193 139.7446415721661 24.68 35.67007370416193 139.7446415721661 8.444</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670159267262726 139.74467251742243 24.68 35.670172027129404 139.74461870816677 24.68 35.6700867342639 139.7445875417395 24.68 35.67007370416193 139.7446415721661 24.68 35.670159267262726 139.74467251742243 24.68</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-a69cb5ad-b84a-4b74-934c-d2a1e1f111cc"/>
							<gml:surfaceMember xlink:href="#poly-ab9f95ae-4a55-4d1b-9156-cbe70681c70a"/>
							<gml:surfaceMember xlink:href="#poly-8b2291ae-a6c9-4910-b020-c17d42947744"/>
							<gml:surfaceMember xlink:href="#poly-51a078d3-c17c-438c-9516-2ced9c6536a5"/>
							<gml:surfaceMember xlink:href="#poly-0db411a9-82fd-47e5-ab84-909f562fd10c"/>
							<gml:surfaceMember xlink:href="#poly-1f02cfa0-be8f-493b-9890-21729f2d83bc"/>
							<gml:surfaceMember xlink:href="#poly-6bbd95d1-dc18-41af-b882-b98cff29dac0"/>
							<gml:surfaceMember xlink:href="#poly-e59c219c-7d90-4110-bd61-f2368beddb4e"/>
							<gml:surfaceMember xlink:href="#poly-f3023f48-c667-462f-b597-ec3a4d202a8d"/>
							<gml:surfaceMember xlink:href="#poly-d7e9ed6c-66e4-400e-af30-a592af599aaa"/>
							<gml:surfaceMember xlink:href="#poly-bc165272-bcd8-42bf-bac3-d2c8b44a35fa"/>
							<gml:surfaceMember xlink:href="#poly-d210ccb9-020f-43e1-bbb5-f0deb5dfe055"/>
							<gml:surfaceMember xlink:href="#poly-331f26a6-3691-40ed-ad28-9024edd54d05"/>
							<gml:surfaceMember xlink:href="#poly-9b189830-59cb-48e8-971e-21c03d0ef296"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_1530fb56-2a23-46df-a7ff-7605ac5ab791_BuildingInstallation_1060">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ec79f29f-b7b7-4e35-86bd-ef6ddf6bbc97">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67013065783291 139.74463600814474 24.01 35.670105944599584 139.7446270549052 24.01 35.67010874832028 139.74461543117727 24.01 35.67013346154632 139.7446243733673 24.01 35.67013065783291 139.74463600814474 24.01</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0193d005-5d51-4b37-9de5-12cf1a1e5e06">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0193d005-5d51-4b37-9de5-12cf1a1e5e06_0">
											<gml:posList>35.67010874832028 139.74461543117727 24.01 35.67010874832028 139.74461543117727 25.831 35.67013346154632 139.7446243733673 25.831 35.67013346154632 139.7446243733673 24.01 35.67010874832028 139.74461543117727 24.01</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-92ec035e-0f9e-4dd3-acdf-1266e71db6df">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-92ec035e-0f9e-4dd3-acdf-1266e71db6df_0">
											<gml:posList>35.670105944599584 139.7446270549052 24.01 35.670105944599584 139.7446270549052 25.831 35.67010874832028 139.74461543117727 25.831 35.67010874832028 139.74461543117727 24.01 35.670105944599584 139.7446270549052 24.01</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-08a56960-28f0-4b29-8ee0-fce3de33b05a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-08a56960-28f0-4b29-8ee0-fce3de33b05a_0">
											<gml:posList>35.67013065783291 139.74463600814474 25.831 35.67013346154632 139.7446243733673 25.831 35.67010874832028 139.74461543117727 25.831 35.670105944599584 139.7446270549052 25.831 35.67013065783291 139.74463600814474 25.831</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b559581d-eff7-4eea-aab7-825d902d56c3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b559581d-eff7-4eea-aab7-825d902d56c3_0">
											<gml:posList>35.67013346154632 139.7446243733673 25.831 35.67013065783291 139.74463600814474 25.831 35.67013065783291 139.74463600814474 24.01 35.67013346154632 139.7446243733673 24.01 35.67013346154632 139.7446243733673 25.831</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f373878a-2955-43f1-b281-6a4ec0c439d8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f373878a-2955-43f1-b281-6a4ec0c439d8_0">
											<gml:posList>35.67013065783291 139.74463600814474 24.01 35.67013065783291 139.74463600814474 25.831 35.670105944599584 139.7446270549052 25.831 35.670105944599584 139.7446270549052 24.01 35.67013065783291 139.74463600814474 24.01</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_1530fb56-2a23-46df-a7ff-7605ac5ab791_BuildingInstallation_1041">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7c310d64-f420-4be6-9a99-6780ba9f9aed">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67008002486114 139.744619914586 24.8 35.67007921340623 139.74461961723594 24.8 35.67008562061627 139.7445930439893 24.8 35.67008644108496 139.74459334132916 24.8 35.67008002486114 139.744619914586 24.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-57bebb58-e652-4269-9854-6ae64bc30650">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67010545035833 139.74462911004932 24.01 35.67008002486114 139.744619914586 24.01 35.67008644108496 139.74459334132916 24.01 35.67011185757042 139.74460253679476 24.01 35.67010545035833 139.74462911004932 24.01</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b2d3abe3-5a92-4adc-b6cf-19934c91f57d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b2d3abe3-5a92-4adc-b6cf-19934c91f57d_0">
											<gml:posList>35.67007921340623 139.74461961723594 24.8 35.67007921340623 139.74461961723594 28.875 35.67008562061627 139.7445930439893 28.875 35.67008562061627 139.7445930439893 24.8 35.67007921340623 139.74461961723594 24.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f39da7f2-f49a-498d-b6a4-7799f62676fb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f39da7f2-f49a-498d-b6a4-7799f62676fb_0">
											<gml:posList>35.67008644108496 139.74459334132916 24.01 35.67008002486114 139.744619914586 24.01 35.67008002486114 139.744619914586 24.8 35.67008644108496 139.74459334132916 24.8 35.67008644108496 139.74459334132916 24.01</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3dc5d075-4162-4964-aeb9-0eb918a7cb21">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3dc5d075-4162-4964-aeb9-0eb918a7cb21_0">
											<gml:posList>35.67010545035833 139.74462911004932 24.01 35.67010545035833 139.74462911004932 28.875 35.67007921340623 139.74461961723594 28.875 35.67007921340623 139.74461961723594 24.8 35.67008002486114 139.744619914586 24.8 35.67008002486114 139.744619914586 24.01 35.67010545035833 139.74462911004932 24.01</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1b9732f6-1cca-47d1-a46c-ad6a48cbfe61">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1b9732f6-1cca-47d1-a46c-ad6a48cbfe61_0">
											<gml:posList>35.67008562061627 139.7445930439893 28.875 35.67007921340623 139.74461961723594 28.875 35.67010545035833 139.74462911004932 28.875 35.67011185757042 139.74460253679476 28.875 35.67008562061627 139.7445930439893 28.875</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fde3983b-e01f-482c-a007-f46e7506452e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fde3983b-e01f-482c-a007-f46e7506452e_0">
											<gml:posList>35.67008644108496 139.74459334132916 24.8 35.67008562061627 139.7445930439893 24.8 35.67008562061627 139.7445930439893 28.875 35.67011185757042 139.74460253679476 28.875 35.67011185757042 139.74460253679476 24.01 35.67008644108496 139.74459334132916 24.01 35.67008644108496 139.74459334132916 24.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1942e647-bfe3-4e9b-a115-c0588f0b349d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1942e647-bfe3-4e9b-a115-c0588f0b349d_0">
											<gml:posList>35.67010545035833 139.74462911004932 28.875 35.67010545035833 139.74462911004932 24.01 35.67011185757042 139.74460253679476 24.01 35.67011185757042 139.74460253679476 28.875 35.67010545035833 139.74462911004932 28.875</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_1530fb56-2a23-46df-a7ff-7605ac5ab791_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-80431413-c7d7-4d66-84a2-0ef4e06901fc">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6700800428479 139.74461985933502 24.8 35.67007604394677 139.74463643308653 24.8 35.670075349702856 139.7446361797915 24.8 35.67007934860396 139.74461960604015 24.8 35.6700800428479 139.74461985933502 24.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-88d4937e-945b-4284-ae3f-c2d432c6e362">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67007604394677 139.74463643308653 24.01 35.6700800428479 139.74461985933502 24.01 35.67010545035833 139.74462911004932 24.01 35.67010145145594 139.74464568380563 24.01 35.67007604394677 139.74463643308653 24.01</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2beb3ee9-a452-4e0e-b611-39b64bf1c192">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670113976806846 139.74465284999604 24.01 35.67011720288953 139.74463948049726 24.01 35.67013247622255 139.7446450088071 24.01 35.670129250131126 139.744658367262 24.01 35.670113976806846 139.74465284999604 24.01</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2d970625-bea3-45dd-8010-83329e8bf9a0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2d970625-bea3-45dd-8010-83329e8bf9a0_0">
											<gml:posList>35.67007934860396 139.74461960604015 24.8 35.670075349702856 139.7446361797915 24.8 35.670075349702856 139.7446361797915 26.841 35.67007934860396 139.74461960604015 26.841 35.67007934860396 139.74461960604015 24.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7efa4070-5735-458f-823e-4e7ff4049ef0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7efa4070-5735-458f-823e-4e7ff4049ef0_0">
											<gml:posList>35.6700800428479 139.74461985933502 24.8 35.6700800428479 139.74461985933502 24.01 35.67007604394677 139.74463643308653 24.01 35.67007604394677 139.74463643308653 24.8 35.6700800428479 139.74461985933502 24.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f9e14593-5bad-4290-8b43-f346eaafa05f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f9e14593-5bad-4290-8b43-f346eaafa05f_0">
											<gml:posList>35.67007604394677 139.74463643308653 24.8 35.67007604394677 139.74463643308653 24.01 35.67010145145594 139.74464568380563 24.01 35.67010145145594 139.74464568380563 26.841 35.670075349702856 139.7446361797915 26.841 35.670075349702856 139.7446361797915 24.8 35.67007604394677 139.74463643308653 24.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8c7d26f8-a15b-4118-8847-196cbccbef78">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8c7d26f8-a15b-4118-8847-196cbccbef78_0">
											<gml:posList>35.67010545035833 139.74462911004932 26.841 35.67007934860396 139.74461960604015 26.841 35.670075349702856 139.7446361797915 26.841 35.67010145145594 139.74464568380563 26.841 35.67010545035833 139.74462911004932 26.841</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a06a5d07-399f-4ebf-b39c-3be7027a5674">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a06a5d07-399f-4ebf-b39c-3be7027a5674_0">
											<gml:posList>35.67007934860396 139.74461960604015 26.841 35.67010545035833 139.74462911004932 26.841 35.67010545035833 139.74462911004932 24.01 35.6700800428479 139.74461985933502 24.01 35.6700800428479 139.74461985933502 24.8 35.67007934860396 139.74461960604015 24.8 35.67007934860396 139.74461960604015 26.841</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9af52d15-67a8-4be0-a134-cc02665a8efa">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9af52d15-67a8-4be0-a134-cc02665a8efa_0">
											<gml:posList>35.67010545035833 139.74462911004932 24.01 35.67010545035833 139.74462911004932 26.841 35.67010145145594 139.74464568380563 26.841 35.67010145145594 139.74464568380563 24.01 35.67010545035833 139.74462911004932 24.01</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5510ffc7-6335-4709-b0ff-fd76eecbb309">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5510ffc7-6335-4709-b0ff-fd76eecbb309_0">
											<gml:posList>35.67011720288953 139.74463948049726 24.01 35.670113976806846 139.74465284999604 24.01 35.670113976806846 139.74465284999604 26.55 35.67011720288953 139.74463948049726 26.55 35.67011720288953 139.74463948049726 24.01</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3a29a7ff-4ffb-47e5-9413-2b6185ad1fc0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3a29a7ff-4ffb-47e5-9413-2b6185ad1fc0_0">
											<gml:posList>35.670113976806846 139.74465284999604 24.01 35.670129250131126 139.744658367262 24.01 35.670129250131126 139.744658367262 26.55 35.670113976806846 139.74465284999604 26.55 35.670113976806846 139.74465284999604 24.01</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-86b45114-d5ad-4c9a-94ea-0f8cd87cd003">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-86b45114-d5ad-4c9a-94ea-0f8cd87cd003_0">
											<gml:posList>35.670113976806846 139.74465284999604 26.55 35.670129250131126 139.744658367262 26.55 35.67013247622255 139.7446450088071 26.55 35.67011720288953 139.74463948049726 26.55 35.670113976806846 139.74465284999604 26.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-39b6b4ae-4153-40c4-8a71-426b8bceab06">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-39b6b4ae-4153-40c4-8a71-426b8bceab06_0">
											<gml:posList>35.67013247622255 139.7446450088071 24.01 35.67011720288953 139.74463948049726 24.01 35.67011720288953 139.74463948049726 26.55 35.67013247622255 139.7446450088071 26.55 35.67013247622255 139.7446450088071 24.01</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e9e6bc80-bb8f-4630-8df7-df99a7c293e1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e9e6bc80-bb8f-4630-8df7-df99a7c293e1_0">
											<gml:posList>35.67013247622255 139.7446450088071 24.01 35.67013247622255 139.7446450088071 26.55 35.670129250131126 139.744658367262 26.55 35.670129250131126 139.744658367262 24.01 35.67013247622255 139.7446450088071 24.01</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-a69cb5ad-b84a-4b74-934c-d2a1e1f111cc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a69cb5ad-b84a-4b74-934c-d2a1e1f111cc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a69cb5ad-b84a-4b74-934c-d2a1e1f111cc">
											<gml:posList>35.670159267262726 139.74467251742243 8.444 35.670073704161915 139.7446415721661 8.444 35.670086734263904 139.7445875417395 8.444 35.670172027129375 139.74461870816677 8.444 35.670159267262726 139.74467251742243 8.444</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ab9f95ae-4a55-4d1b-9156-cbe70681c70a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ab9f95ae-4a55-4d1b-9156-cbe70681c70a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ab9f95ae-4a55-4d1b-9156-cbe70681c70a">
											<gml:posList>35.670073704161915 139.7446415721661 24.8 35.67007501050916 139.74464069806984 24.8 35.670087447544844 139.74458916474424 24.8 35.670086734263904 139.7445875417395 24.8 35.670073704161915 139.7446415721661 24.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-8b2291ae-a6c9-4910-b020-c17d42947744">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8b2291ae-a6c9-4910-b020-c17d42947744">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8b2291ae-a6c9-4910-b020-c17d42947744">
											<gml:posList>35.670159267262726 139.74467251742243 24.8 35.670158535963594 139.7446709054816 24.8 35.67007501050916 139.74464069806984 24.8 35.670073704161915 139.7446415721661 24.8 35.670159267262726 139.74467251742243 24.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-51a078d3-c17c-438c-9516-2ced9c6536a5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-51a078d3-c17c-438c-9516-2ced9c6536a5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-51a078d3-c17c-438c-9516-2ced9c6536a5">
											<gml:posList>35.670170702754874 139.74461958228437 24.01 35.670087447544844 139.74458916474424 24.01 35.67007501050916 139.74464069806984 24.01 35.670158535963594 139.7446709054816 24.01 35.670170702754874 139.74461958228437 24.01</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-0db411a9-82fd-47e5-ab84-909f562fd10c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0db411a9-82fd-47e5-ab84-909f562fd10c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0db411a9-82fd-47e5-ab84-909f562fd10c">
											<gml:posList>35.670086734263904 139.7445875417395 24.8 35.670087447544844 139.74458916474424 24.8 35.670170702754874 139.74461958228437 24.8 35.670172027129375 139.74461870816677 24.8 35.670086734263904 139.7445875417395 24.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-1f02cfa0-be8f-493b-9890-21729f2d83bc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1f02cfa0-be8f-493b-9890-21729f2d83bc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1f02cfa0-be8f-493b-9890-21729f2d83bc">
											<gml:posList>35.670172027129375 139.74461870816677 24.8 35.670170702754874 139.74461958228437 24.8 35.670158535963594 139.7446709054816 24.8 35.670159267262726 139.74467251742243 24.8 35.670172027129375 139.74461870816677 24.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6bbd95d1-dc18-41af-b882-b98cff29dac0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6bbd95d1-dc18-41af-b882-b98cff29dac0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6bbd95d1-dc18-41af-b882-b98cff29dac0">
											<gml:posList>35.670172027129375 139.74461870816677 8.444 35.670086734263904 139.7445875417395 8.444 35.670086734263904 139.7445875417395 24.8 35.670172027129375 139.74461870816677 24.8 35.670172027129375 139.74461870816677 8.444</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e59c219c-7d90-4110-bd61-f2368beddb4e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e59c219c-7d90-4110-bd61-f2368beddb4e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e59c219c-7d90-4110-bd61-f2368beddb4e">
											<gml:posList>35.670087447544844 139.74458916474424 24.8 35.670087447544844 139.74458916474424 24.01 35.670170702754874 139.74461958228437 24.01 35.670170702754874 139.74461958228437 24.8 35.670087447544844 139.74458916474424 24.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f3023f48-c667-462f-b597-ec3a4d202a8d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f3023f48-c667-462f-b597-ec3a4d202a8d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f3023f48-c667-462f-b597-ec3a4d202a8d">
											<gml:posList>35.670086734263904 139.7445875417395 8.444 35.670073704161915 139.7446415721661 8.444 35.670073704161915 139.7446415721661 24.8 35.670086734263904 139.7445875417395 24.8 35.670086734263904 139.7445875417395 8.444</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d7e9ed6c-66e4-400e-af30-a592af599aaa">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d7e9ed6c-66e4-400e-af30-a592af599aaa">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d7e9ed6c-66e4-400e-af30-a592af599aaa">
											<gml:posList>35.67007501050916 139.74464069806984 24.8 35.67007501050916 139.74464069806984 24.01 35.670087447544844 139.74458916474424 24.01 35.670087447544844 139.74458916474424 24.8 35.67007501050916 139.74464069806984 24.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-bc165272-bcd8-42bf-bac3-d2c8b44a35fa">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bc165272-bcd8-42bf-bac3-d2c8b44a35fa">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bc165272-bcd8-42bf-bac3-d2c8b44a35fa">
											<gml:posList>35.670170702754874 139.74461958228437 24.8 35.670170702754874 139.74461958228437 24.01 35.670158535963594 139.7446709054816 24.01 35.670158535963594 139.7446709054816 24.8 35.670170702754874 139.74461958228437 24.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d210ccb9-020f-43e1-bbb5-f0deb5dfe055">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d210ccb9-020f-43e1-bbb5-f0deb5dfe055">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d210ccb9-020f-43e1-bbb5-f0deb5dfe055">
											<gml:posList>35.670159267262726 139.74467251742243 8.444 35.670172027129375 139.74461870816677 8.444 35.670172027129375 139.74461870816677 24.8 35.670159267262726 139.74467251742243 24.8 35.670159267262726 139.74467251742243 8.444</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-331f26a6-3691-40ed-ad28-9024edd54d05">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-331f26a6-3691-40ed-ad28-9024edd54d05">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-331f26a6-3691-40ed-ad28-9024edd54d05">
											<gml:posList>35.670158535963594 139.7446709054816 24.8 35.670158535963594 139.7446709054816 24.01 35.67007501050916 139.74464069806984 24.01 35.67007501050916 139.74464069806984 24.8 35.670158535963594 139.7446709054816 24.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9b189830-59cb-48e8-971e-21c03d0ef296">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9b189830-59cb-48e8-971e-21c03d0ef296">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9b189830-59cb-48e8-971e-21c03d0ef296">
											<gml:posList>35.670073704161915 139.7446415721661 8.444 35.670159267262726 139.74467251742243 8.444 35.670159267262726 139.74467251742243 24.8 35.670073704161915 139.7446415721661 24.8 35.670073704161915 139.7446415721661 8.444</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂一丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-8647</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">50.2847</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1210</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>7</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>