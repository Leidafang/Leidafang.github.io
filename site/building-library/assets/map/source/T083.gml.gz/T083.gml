<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_15aea018-0a70-4ae1-bbd2-60c60fd237c3">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>8</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>3</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13101008003</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">401</bldg:usage>
			<bldg:measuredHeight uom="m">29.3</bldg:measuredHeight>
			<bldg:storeysAboveGround>8</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>2</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.67157840021656 139.74641882392646 0 35.67156794405943 139.746418503869 0 35.671551721272685 139.74642117259685 0 35.671533790502785 139.74643025009814 0 35.67151306834782 139.7464433073305 0 35.67149388482016 139.74646508955547 0 35.67147614738786 139.746492282945 0 35.67143590589946 139.74656147703098 0 35.67163595638811 139.74673645694594 0 35.67167655947858 139.74666858795655 0 35.67168871051001 139.74664427265296 0 35.671698873585285 139.74661311069832 0 35.67170407926438 139.74658217502872 0 35.671704779029845 139.74655256980554 0 35.6717005234706 139.74652606295112 0 35.67168788155906 139.74649459428446 0 35.67166884125124 139.74646501045493 0 35.67164115087171 139.74643974412416 0 35.67161094366116 139.74642420139742 0 35.67157840021656 139.74641882392646 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67157840021656 139.74641882392646 12.3 35.67161094366116 139.74642420139742 12.3 35.67164115087171 139.74643974412416 12.3 35.67166884125124 139.74646501045493 12.3 35.67168788155906 139.74649459428446 12.3 35.6717005234706 139.74652606295112 12.3 35.671704779029845 139.74655256980554 12.3 35.67170407926438 139.74658217502872 12.3 35.671698873585285 139.74661311069832 12.3 35.67168871051001 139.74664427265296 12.3 35.67167655947858 139.74666858795655 12.3 35.67163595638811 139.74673645694594 12.3 35.67143590589946 139.74656147703098 12.3 35.67147614738786 139.746492282945 12.3 35.67149388482016 139.74646508955547 12.3 35.67151306834782 139.7464433073305 12.3 35.671533790502785 139.74643025009814 12.3 35.671551721272685 139.74642117259685 12.3 35.67156794405943 139.746418503869 12.3 35.67157840021656 139.74641882392646 12.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67157840021656 139.74641882392646 12.3 35.67156794405943 139.746418503869 12.3 35.67156794405943 139.746418503869 41.64 35.67157840021656 139.74641882392646 41.64 35.67157840021656 139.74641882392646 12.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67156794405943 139.746418503869 12.3 35.671551721272685 139.74642117259685 12.3 35.671551721272685 139.74642117259685 41.64 35.67156794405943 139.746418503869 41.64 35.67156794405943 139.746418503869 12.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671551721272685 139.74642117259685 12.3 35.671533790502785 139.74643025009814 12.3 35.671533790502785 139.74643025009814 41.64 35.671551721272685 139.74642117259685 41.64 35.671551721272685 139.74642117259685 12.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671533790502785 139.74643025009814 12.3 35.67151306834782 139.7464433073305 12.3 35.67151306834782 139.7464433073305 41.64 35.671533790502785 139.74643025009814 41.64 35.671533790502785 139.74643025009814 12.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67151306834782 139.7464433073305 12.3 35.67149388482016 139.74646508955547 12.3 35.67149388482016 139.74646508955547 41.64 35.67151306834782 139.7464433073305 41.64 35.67151306834782 139.7464433073305 12.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67149388482016 139.74646508955547 12.3 35.67147614738786 139.746492282945 12.3 35.67147614738786 139.746492282945 41.64 35.67149388482016 139.74646508955547 41.64 35.67149388482016 139.74646508955547 12.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67147614738786 139.746492282945 12.3 35.67143590589946 139.74656147703098 12.3 35.67143590589946 139.74656147703098 41.64 35.67147614738786 139.746492282945 41.64 35.67147614738786 139.746492282945 12.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67143590589946 139.74656147703098 12.3 35.67163595638811 139.74673645694594 12.3 35.67163595638811 139.74673645694594 41.64 35.67143590589946 139.74656147703098 41.64 35.67143590589946 139.74656147703098 12.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67163595638811 139.74673645694594 12.3 35.67167655947858 139.74666858795655 12.3 35.67167655947858 139.74666858795655 41.64 35.67163595638811 139.74673645694594 41.64 35.67163595638811 139.74673645694594 12.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67167655947858 139.74666858795655 12.3 35.67168871051001 139.74664427265296 12.3 35.67168871051001 139.74664427265296 41.64 35.67167655947858 139.74666858795655 41.64 35.67167655947858 139.74666858795655 12.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67168871051001 139.74664427265296 12.3 35.671698873585285 139.74661311069832 12.3 35.671698873585285 139.74661311069832 41.64 35.67168871051001 139.74664427265296 41.64 35.67168871051001 139.74664427265296 12.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671698873585285 139.74661311069832 12.3 35.67170407926438 139.74658217502872 12.3 35.67170407926438 139.74658217502872 41.64 35.671698873585285 139.74661311069832 41.64 35.671698873585285 139.74661311069832 12.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67170407926438 139.74658217502872 12.3 35.671704779029845 139.74655256980554 12.3 35.671704779029845 139.74655256980554 41.64 35.67170407926438 139.74658217502872 41.64 35.67170407926438 139.74658217502872 12.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671704779029845 139.74655256980554 12.3 35.6717005234706 139.74652606295112 12.3 35.6717005234706 139.74652606295112 41.64 35.671704779029845 139.74655256980554 41.64 35.671704779029845 139.74655256980554 12.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6717005234706 139.74652606295112 12.3 35.67168788155906 139.74649459428446 12.3 35.67168788155906 139.74649459428446 41.64 35.6717005234706 139.74652606295112 41.64 35.6717005234706 139.74652606295112 12.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67168788155906 139.74649459428446 12.3 35.67166884125124 139.74646501045493 12.3 35.67166884125124 139.74646501045493 41.64 35.67168788155906 139.74649459428446 41.64 35.67168788155906 139.74649459428446 12.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67166884125124 139.74646501045493 12.3 35.67164115087171 139.74643974412416 12.3 35.67164115087171 139.74643974412416 41.64 35.67166884125124 139.74646501045493 41.64 35.67166884125124 139.74646501045493 12.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67164115087171 139.74643974412416 12.3 35.67161094366116 139.74642420139742 12.3 35.67161094366116 139.74642420139742 41.64 35.67164115087171 139.74643974412416 41.64 35.67164115087171 139.74643974412416 12.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67161094366116 139.74642420139742 12.3 35.67157840021656 139.74641882392646 12.3 35.67157840021656 139.74641882392646 41.64 35.67161094366116 139.74642420139742 41.64 35.67161094366116 139.74642420139742 12.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67157840021656 139.74641882392646 41.64 35.67156794405943 139.746418503869 41.64 35.671551721272685 139.74642117259685 41.64 35.671533790502785 139.74643025009814 41.64 35.67151306834782 139.7464433073305 41.64 35.67149388482016 139.74646508955547 41.64 35.67147614738786 139.746492282945 41.64 35.67143590589946 139.74656147703098 41.64 35.67163595638811 139.74673645694594 41.64 35.67167655947858 139.74666858795655 41.64 35.67168871051001 139.74664427265296 41.64 35.671698873585285 139.74661311069832 41.64 35.67170407926438 139.74658217502872 41.64 35.671704779029845 139.74655256980554 41.64 35.6717005234706 139.74652606295112 41.64 35.67168788155906 139.74649459428446 41.64 35.67166884125124 139.74646501045493 41.64 35.67164115087171 139.74643974412416 41.64 35.67161094366116 139.74642420139742 41.64 35.67157840021656 139.74641882392646 41.64</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-5f406581-600a-45b4-98ec-2c081e675a41"/>
							<gml:surfaceMember xlink:href="#poly-5f40aa7f-8d05-4016-bd60-3586a9dd6e2e"/>
							<gml:surfaceMember xlink:href="#poly-1d702249-0124-4b59-b724-0c3808ede66e"/>
							<gml:surfaceMember xlink:href="#poly-c45b38a6-a792-4fcd-a9ce-9df15f83b00a"/>
							<gml:surfaceMember xlink:href="#poly-4cccf6a1-17fc-4151-bc5c-3d291bd21bfb"/>
							<gml:surfaceMember xlink:href="#poly-2a648c43-7361-443d-a6e3-a6ace30a3e08"/>
							<gml:surfaceMember xlink:href="#poly-200a7218-c2db-46b7-8212-e7e42222f0e8"/>
							<gml:surfaceMember xlink:href="#poly-994866ce-6157-4774-a1ca-11b046dd5fce"/>
							<gml:surfaceMember xlink:href="#poly-8d21fad1-2ef1-4612-8f33-6daf4a361e22"/>
							<gml:surfaceMember xlink:href="#poly-b6b55970-49af-4fec-a65b-95dfbcae3006"/>
							<gml:surfaceMember xlink:href="#poly-df36848a-0bc6-440a-9478-1874ffd6457e"/>
							<gml:surfaceMember xlink:href="#poly-4fbf7135-1911-4dfe-bde1-ed6f5d857a4d"/>
							<gml:surfaceMember xlink:href="#poly-16d9bcae-158b-4332-a18e-b1c3f3757a93"/>
							<gml:surfaceMember xlink:href="#poly-fff41a96-4cf3-40e3-9818-3335e2b54691"/>
							<gml:surfaceMember xlink:href="#poly-0858612b-6de1-4a92-8366-c762689fd0e9"/>
							<gml:surfaceMember xlink:href="#poly-61a84eeb-1085-4222-9ec2-ef3d9ab567b3"/>
							<gml:surfaceMember xlink:href="#poly-aaf646ff-f37b-43f5-b946-0bd3469b38b1"/>
							<gml:surfaceMember xlink:href="#poly-ad5c8475-99ec-4959-8b9a-76ad290672ff"/>
							<gml:surfaceMember xlink:href="#poly-4c8df497-460a-4b84-a370-6aa6bb5271de"/>
							<gml:surfaceMember xlink:href="#poly-a683a72d-8bff-4eb9-80b7-5c3162188f72"/>
							<gml:surfaceMember xlink:href="#poly-20e2f31e-068c-48ac-b8ce-6126f28520ef"/>
							<gml:surfaceMember xlink:href="#poly-0b18840f-6274-4b0d-a103-ad829ceda78b"/>
							<gml:surfaceMember xlink:href="#poly-452a4a17-facd-4cdb-9d0a-dc356cd38eaf"/>
							<gml:surfaceMember xlink:href="#poly-a5ccee09-2228-41e7-958d-80178fd1d240"/>
							<gml:surfaceMember xlink:href="#poly-487bf42b-8cf6-4975-aa20-480efc67c13f"/>
							<gml:surfaceMember xlink:href="#poly-714f71ee-77f5-4671-aeea-f16a889a80ed"/>
							<gml:surfaceMember xlink:href="#poly-74b56230-fd8d-483e-b960-577d5711e8ff"/>
							<gml:surfaceMember xlink:href="#poly-7d3d6021-b43d-4f18-af59-2e4b7087a69e"/>
							<gml:surfaceMember xlink:href="#poly-8c0d685b-ec63-4543-8365-ad9202e9ef12"/>
							<gml:surfaceMember xlink:href="#poly-a565d8dc-1919-4c6a-a4a2-8edb3df7d8c9"/>
							<gml:surfaceMember xlink:href="#poly-e1dd19bc-4105-467a-a40f-800ab7738849"/>
							<gml:surfaceMember xlink:href="#poly-3ecdb279-d973-435f-a5f2-8a0d38440fc5"/>
							<gml:surfaceMember xlink:href="#poly-87fd1000-3f43-41e1-b52f-5770067206e5"/>
							<gml:surfaceMember xlink:href="#poly-03960dde-3131-4302-8cff-c9d914e1987d"/>
							<gml:surfaceMember xlink:href="#poly-d0e8e0f4-3dbe-4516-bc60-56ba8bf6fd71"/>
							<gml:surfaceMember xlink:href="#poly-b365696a-782d-41bd-8f76-6dcd993b7f04"/>
							<gml:surfaceMember xlink:href="#poly-858a394b-1ba0-44af-a827-e02ce0aae9d1"/>
							<gml:surfaceMember xlink:href="#poly-6b87a848-a9cf-4a0d-8391-3175c0145984"/>
							<gml:surfaceMember xlink:href="#poly-0b263af6-16c7-4edc-9171-e84b097a3ca7"/>
							<gml:surfaceMember xlink:href="#poly-1dd6dc5b-cc05-484e-ae06-f9607905e84c"/>
							<gml:surfaceMember xlink:href="#poly-84ba8d3b-37fc-4353-8dff-d41a713516e9"/>
							<gml:surfaceMember xlink:href="#poly-671cb933-367c-4da0-9feb-ab089f872604"/>
							<gml:surfaceMember xlink:href="#poly-9c3b9069-42f1-4c17-a0f4-c78aa4964021"/>
							<gml:surfaceMember xlink:href="#poly-cdea355d-1fc9-4ea5-8fb4-247fccfcb0db"/>
							<gml:surfaceMember xlink:href="#poly-f19eae39-cd6f-4749-9e17-5607c476bbd0"/>
							<gml:surfaceMember xlink:href="#poly-5eaaf81e-57e8-48b4-a59d-3637d34f62b3"/>
							<gml:surfaceMember xlink:href="#poly-9410b4b2-d8e4-42c5-af33-67a379a5cc63"/>
							<gml:surfaceMember xlink:href="#poly-87417cc4-8549-40b4-8e5f-1471a62059e5"/>
							<gml:surfaceMember xlink:href="#poly-39ad8c72-f461-4883-b2cb-d8370a7dbeb5"/>
							<gml:surfaceMember xlink:href="#poly-d02ea6e6-5c83-4a20-a9c4-5fa7c87495aa"/>
							<gml:surfaceMember xlink:href="#poly-85220563-1949-48d7-8c12-43e38c5808e1"/>
							<gml:surfaceMember xlink:href="#poly-9d3d8f11-7b15-4b07-ab9d-30d559083273"/>
							<gml:surfaceMember xlink:href="#poly-ec11d93e-82e9-440a-9e3b-c6b7f6b9d53c"/>
							<gml:surfaceMember xlink:href="#poly-c3ca04e8-e61c-476c-8e9a-97e22d034fd5"/>
							<gml:surfaceMember xlink:href="#poly-b52c4f16-539f-4f56-b06c-06b42b223047"/>
							<gml:surfaceMember xlink:href="#poly-3eb72d30-b8c1-4198-8c5b-5c79d856a6cb"/>
							<gml:surfaceMember xlink:href="#poly-15a9670d-66be-487a-bb31-682eea52cd7e"/>
							<gml:surfaceMember xlink:href="#poly-2cb0adfd-ab0a-44da-8c92-d3fd720a0db8"/>
							<gml:surfaceMember xlink:href="#poly-2040fe2c-4280-478c-8420-a47b7e11e02b"/>
							<gml:surfaceMember xlink:href="#poly-0406326e-0fa3-4d48-837f-e8b7e87830b9"/>
							<gml:surfaceMember xlink:href="#poly-bd4510f3-474f-48b4-9ae0-ef000abd4f9c"/>
							<gml:surfaceMember xlink:href="#poly-7c174ba4-6289-4772-a8bf-dfaab21b4774"/>
							<gml:surfaceMember xlink:href="#poly-95839309-d9ca-4b67-91cc-15e7b8635b51"/>
							<gml:surfaceMember xlink:href="#poly-c868c190-eb4d-47c9-a3da-ecf927986e37"/>
							<gml:surfaceMember xlink:href="#poly-f60c6160-f1c5-4020-8ed8-7eb699748c15"/>
							<gml:surfaceMember xlink:href="#poly-30106bd7-34b3-4bea-94c7-49a977414055"/>
							<gml:surfaceMember xlink:href="#poly-e55b1a74-61ca-4a70-a699-d9be4164796e"/>
							<gml:surfaceMember xlink:href="#poly-6a60f21a-2943-4a99-8125-eb7c5a87f27f"/>
							<gml:surfaceMember xlink:href="#poly-388a1cc8-215a-4f47-8e53-24270f9903b4"/>
							<gml:surfaceMember xlink:href="#poly-eec67339-8ee6-4873-b92f-94777d0e22a4"/>
							<gml:surfaceMember xlink:href="#poly-245bc0d3-b227-4837-92f3-a89b96116fe2"/>
							<gml:surfaceMember xlink:href="#poly-f8aa96bd-d2ec-4912-8300-68885e55da8e"/>
							<gml:surfaceMember xlink:href="#poly-4265ccde-9a78-4539-a728-3d312999460c"/>
							<gml:surfaceMember xlink:href="#poly-161c8e20-862b-45fb-ae1f-f0df3f7a2c61"/>
							<gml:surfaceMember xlink:href="#poly-bede1466-f889-4139-8a21-5d4da09a9068"/>
							<gml:surfaceMember xlink:href="#poly-13c5d6b1-c386-40ca-9081-de9132813876"/>
							<gml:surfaceMember xlink:href="#poly-0a9c035a-7e12-4527-8e18-43647a4f7072"/>
							<gml:surfaceMember xlink:href="#poly-624344e8-7a9f-4805-8aee-72a04b43b548"/>
							<gml:surfaceMember xlink:href="#poly-6478968b-5589-4e22-986c-a23f5dedcc84"/>
							<gml:surfaceMember xlink:href="#poly-103befb1-d400-4616-8c30-91a94b77a617"/>
							<gml:surfaceMember xlink:href="#poly-a8572d3d-fb57-4732-a317-3c43fa4fc7ed"/>
							<gml:surfaceMember xlink:href="#poly-37e1bde5-00ee-4e70-ab48-4d3e09136b2f"/>
							<gml:surfaceMember xlink:href="#poly-9948f54c-53a2-4b39-adaa-2142f7540356"/>
							<gml:surfaceMember xlink:href="#poly-94bf00d0-39a5-48f6-885e-288b15a71c83"/>
							<gml:surfaceMember xlink:href="#poly-50d4ea3c-3216-4de4-b91e-8e0afa83af68"/>
							<gml:surfaceMember xlink:href="#poly-d1bf3cce-3db9-4558-a3fc-ccc3861e5671"/>
							<gml:surfaceMember xlink:href="#poly-3f8d702c-4223-478e-b97e-bfde4dbf9375"/>
							<gml:surfaceMember xlink:href="#poly-19261393-1a84-4d97-838c-0c09fe4297db"/>
							<gml:surfaceMember xlink:href="#poly-afc97a67-813c-4413-bfde-e1ad9442a032"/>
							<gml:surfaceMember xlink:href="#poly-07d08da6-e7c4-41ca-9783-6e73deddf312"/>
							<gml:surfaceMember xlink:href="#poly-9c6b8542-2d40-41ab-b2a6-161804006d0c"/>
							<gml:surfaceMember xlink:href="#poly-713e93a2-03fc-4d0c-9a1e-a0d150330775"/>
							<gml:surfaceMember xlink:href="#poly-f26eedc4-1871-44cf-8a95-c0885578b886"/>
							<gml:surfaceMember xlink:href="#poly-7d3941e9-6654-48cb-bbac-f2acf13a6c70"/>
							<gml:surfaceMember xlink:href="#poly-7686aad8-7fc5-4da1-8093-b18f4ff287f0"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_15aea018-0a70-4ae1-bbd2-60c60fd237c3_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0db7008f-8be3-4887-b0f0-e2c604455e6b">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67159315086025 139.74642461835634 42.2 35.67159356577053 139.74642500453152 42.2 35.6715929707931 139.74642490575863 42.2 35.67159315086025 139.74642461835634 42.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-76bd6e3e-417c-492c-a497-d882dd295bb2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6715929707931 139.74642490575863 41.743 35.67159356577053 139.74642500453152 41.743 35.67161459123437 139.74644504205702 41.743 35.67159271275378 139.7464795306203 41.743 35.671584567760824 139.74647177380643 41.743 35.67157795919454 139.74648218669864 41.743 35.671569444384126 139.74647407680104 41.743 35.67157604392801 139.74646365287262 41.743 35.6715721022217 139.7464599013593 41.743 35.6715929707931 139.74642490575863 41.743</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7cc7390a-26af-4f23-ba04-8d3c5f349d29">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671611440010466 139.74645000531908 44.994 35.67159669230112 139.7464732629847 44.994 35.67158177334013 139.74645905135168 44.994 35.671596521046744 139.7464357936878 44.994 35.671611440010466 139.74645000531908 44.994</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-996cb205-c535-4bbd-96ed-06f1843a6773">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6715764813271 139.74650771658744 41.743 35.67158912082008 139.74648583097465 41.743 35.6716258927794 139.7465177042829 41.743 35.6716132623024 139.74653960093738 41.743 35.6715764813271 139.74650771658744 41.743</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-952b3bba-9df6-4da2-8336-46cb030e1aab">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-952b3bba-9df6-4da2-8336-46cb030e1aab_0">
											<gml:posList>35.6715929707931 139.74642490575863 42.2 35.67159356577053 139.74642500453152 42.2 35.67159356577053 139.74642500453152 41.743 35.6715929707931 139.74642490575863 41.743 35.6715929707931 139.74642490575863 42.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f8aca360-dc7b-4328-b9d4-df8d3780d378">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f8aca360-dc7b-4328-b9d4-df8d3780d378_0">
											<gml:posList>35.67157604392801 139.74646365287262 41.743 35.671569444384126 139.74647407680104 41.743 35.671569444384126 139.74647407680104 43.461 35.67157604392801 139.74646365287262 43.461 35.67157604392801 139.74646365287262 41.743</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9511a241-5431-483a-813f-5ff0953fd824">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9511a241-5431-483a-813f-5ff0953fd824_0">
											<gml:posList>35.671569444384126 139.74647407680104 41.743 35.67157795919454 139.74648218669864 41.743 35.67157795919454 139.74648218669864 43.461 35.671569444384126 139.74647407680104 43.461 35.671569444384126 139.74647407680104 41.743</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3c46f470-0f8e-4005-bbd9-145079b0b75f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3c46f470-0f8e-4005-bbd9-145079b0b75f_0">
											<gml:posList>35.67157604392801 139.74646365287262 43.461 35.671569444384126 139.74647407680104 43.461 35.67157795919454 139.74648218669864 43.461 35.671584567760824 139.74647177380643 43.461 35.67157604392801 139.74646365287262 43.461</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-60b75ff9-0a78-4745-9052-84b99389d6b7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-60b75ff9-0a78-4745-9052-84b99389d6b7_0">
											<gml:posList>35.67157795919454 139.74648218669864 41.743 35.671584567760824 139.74647177380643 41.743 35.671584567760824 139.74647177380643 43.461 35.67157795919454 139.74648218669864 43.461 35.67157795919454 139.74648218669864 41.743</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fec48603-c661-4580-b632-aa58834d63b5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fec48603-c661-4580-b632-aa58834d63b5_0">
											<gml:posList>35.67157604392801 139.74646365287262 43.461 35.671584567760824 139.74647177380643 43.461 35.671584567760824 139.74647177380643 41.743 35.67159271275378 139.7464795306203 41.743 35.67159271275378 139.7464795306203 44.994 35.6715721022217 139.7464599013593 44.994 35.6715721022217 139.7464599013593 41.743 35.67157604392801 139.74646365287262 41.743 35.67157604392801 139.74646365287262 43.461</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9bc5f4c6-7683-4f03-891a-4689642d872d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9bc5f4c6-7683-4f03-891a-4689642d872d_0">
											<gml:posList>35.6715929707931 139.74642490575863 42.2 35.6715929707931 139.74642490575863 41.743 35.6715721022217 139.7464599013593 41.743 35.6715721022217 139.7464599013593 44.994 35.67159315086025 139.74642461835634 44.994 35.67159315086025 139.74642461835634 42.2 35.6715929707931 139.74642490575863 42.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-80b19177-6da9-4c6f-a981-3d5f1b41623d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-80b19177-6da9-4c6f-a981-3d5f1b41623d_0">
											<gml:posList>35.67158912082008 139.74648583097465 41.743 35.6715764813271 139.74650771658744 41.743 35.6715764813271 139.74650771658744 45.264 35.67158912082008 139.74648583097465 45.264 35.67158912082008 139.74648583097465 41.743</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2459bcef-26cd-479d-92c5-6e79bb031c15">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2459bcef-26cd-479d-92c5-6e79bb031c15_0">
											<gml:posList>35.671596521046744 139.7464357936878 44.994 35.67158177334013 139.74645905135168 44.994 35.67158177334013 139.74645905135168 46.096 35.671596521046744 139.7464357936878 46.096 35.671596521046744 139.7464357936878 44.994</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-77f7b378-ffc3-4282-98d5-f1713d7da5d8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-77f7b378-ffc3-4282-98d5-f1713d7da5d8_0">
											<gml:posList>35.67159669230112 139.7464732629847 44.994 35.67159669230112 139.7464732629847 46.096 35.67158177334013 139.74645905135168 46.096 35.67158177334013 139.74645905135168 44.994 35.67159669230112 139.7464732629847 44.994</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c9fcf07e-083a-424f-9be1-054e59370cd2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c9fcf07e-083a-424f-9be1-054e59370cd2_0">
											<gml:posList>35.6715721022217 139.7464599013593 44.994 35.67159271275378 139.7464795306203 44.994 35.67161459123437 139.74644504205702 44.994 35.67159315086025 139.74642461835634 44.994 35.6715721022217 139.7464599013593 44.994</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0732b743-824a-4f98-b949-8dd919b3bfcf">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0732b743-824a-4f98-b949-8dd919b3bfcf_0">
											<gml:posList>35.6715764813271 139.74650771658744 41.743 35.6716132623024 139.74653960093738 41.743 35.6716132623024 139.74653960093738 45.264 35.6715764813271 139.74650771658744 45.264 35.6715764813271 139.74650771658744 41.743</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-48aad724-4dd8-4aa2-8b2e-8e7ee0ca82f1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-48aad724-4dd8-4aa2-8b2e-8e7ee0ca82f1_0">
											<gml:posList>35.671611440010466 139.74645000531908 46.096 35.671596521046744 139.7464357936878 46.096 35.67158177334013 139.74645905135168 46.096 35.67159669230112 139.7464732629847 46.096 35.671611440010466 139.74645000531908 46.096</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-657bd43f-0978-4d19-a002-8168d99c5d01">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-657bd43f-0978-4d19-a002-8168d99c5d01_0">
											<gml:posList>35.6715764813271 139.74650771658744 45.264 35.6716132623024 139.74653960093738 45.264 35.6716258927794 139.7465177042829 45.264 35.67158912082008 139.74648583097465 45.264 35.6715764813271 139.74650771658744 45.264</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f177c99a-e5b7-4b0f-a045-07ac3d7fe5a9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f177c99a-e5b7-4b0f-a045-07ac3d7fe5a9_0">
											<gml:posList>35.67159271275378 139.7464795306203 41.743 35.67161459123437 139.74644504205702 41.743 35.67161459123437 139.74644504205702 44.994 35.67159271275378 139.7464795306203 44.994 35.67159271275378 139.7464795306203 41.743</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-769b16c8-89c9-4c8b-9185-0ce2d053fa34">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-769b16c8-89c9-4c8b-9185-0ce2d053fa34_0">
											<gml:posList>35.67159356577053 139.74642500453152 42.2 35.67159315086025 139.74642461835634 42.2 35.67159315086025 139.74642461835634 44.994 35.67161459123437 139.74644504205702 44.994 35.67161459123437 139.74644504205702 41.743 35.67159356577053 139.74642500453152 41.743 35.67159356577053 139.74642500453152 42.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-94357c15-06fd-411f-a054-ba5b4dcafd49">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-94357c15-06fd-411f-a054-ba5b4dcafd49_0">
											<gml:posList>35.671611440010466 139.74645000531908 44.994 35.671596521046744 139.7464357936878 44.994 35.671596521046744 139.7464357936878 46.096 35.671611440010466 139.74645000531908 46.096 35.671611440010466 139.74645000531908 44.994</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6331757e-3b54-43e2-8a5a-147146707f60">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6331757e-3b54-43e2-8a5a-147146707f60_0">
											<gml:posList>35.67159669230112 139.7464732629847 44.994 35.671611440010466 139.74645000531908 44.994 35.671611440010466 139.74645000531908 46.096 35.67159669230112 139.7464732629847 46.096 35.67159669230112 139.7464732629847 44.994</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c87b8966-8788-4dc1-8bec-f33ad82865f4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c87b8966-8788-4dc1-8bec-f33ad82865f4_0">
											<gml:posList>35.67158912082008 139.74648583097465 41.743 35.67158912082008 139.74648583097465 45.264 35.6716258927794 139.7465177042829 45.264 35.6716258927794 139.7465177042829 41.743 35.67158912082008 139.74648583097465 41.743</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0a4feff6-c460-47e3-9506-1e5de974a4ad">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0a4feff6-c460-47e3-9506-1e5de974a4ad_0">
											<gml:posList>35.6716258927794 139.7465177042829 45.264 35.6716132623024 139.74653960093738 45.264 35.6716132623024 139.74653960093738 41.743 35.6716258927794 139.7465177042829 41.743 35.6716258927794 139.7465177042829 45.264</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_15aea018-0a70-4ae1-bbd2-60c60fd237c3_BuildingInstallation_1051">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a2e9132e-dcc4-42ac-ac82-44001f6ca644">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671582966622985 139.74668904768933 31.98 35.67148800127282 139.74660599292383 31.98 35.67148925285949 139.7466041578654 32.202 35.67158420919719 139.74668721263976 32.202 35.671582966622985 139.74668904768933 31.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-df7d9d65-46ed-4ac5-a67b-85e2902aaefb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-df7d9d65-46ed-4ac5-a67b-85e2902aaefb_0">
											<gml:posList>35.67148800127282 139.74660599292383 35.184 35.67148925285949 139.7466041578654 35.184 35.67148925285949 139.7466041578654 32.202 35.67148800127282 139.74660599292383 31.98 35.67148800127282 139.74660599292383 35.184</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c2048997-c7a9-4e4e-a0f7-fa4800d94eec">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c2048997-c7a9-4e4e-a0f7-fa4800d94eec_0">
											<gml:posList>35.67148925285949 139.7466041578654 35.184 35.67158420919719 139.74668721263976 35.184 35.67158420919719 139.74668721263976 32.202 35.67148925285949 139.7466041578654 32.202 35.67148925285949 139.7466041578654 35.184</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-039d6171-c27f-491f-b778-3b04d5ef259b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-039d6171-c27f-491f-b778-3b04d5ef259b_0">
											<gml:posList>35.67148925285949 139.7466041578654 35.184 35.67148800127282 139.74660599292383 35.184 35.671582966622985 139.74668904768933 35.184 35.67158420919719 139.74668721263976 35.184 35.67148925285949 139.7466041578654 35.184</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-79efd81b-934e-4b10-b2ff-c7694a107d32">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-79efd81b-934e-4b10-b2ff-c7694a107d32_0">
											<gml:posList>35.671582966622985 139.74668904768933 35.184 35.67148800127282 139.74660599292383 35.184 35.67148800127282 139.74660599292383 31.98 35.671582966622985 139.74668904768933 31.98 35.671582966622985 139.74668904768933 35.184</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-309171da-0358-4687-9929-16642a65d1e8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-309171da-0358-4687-9929-16642a65d1e8_0">
											<gml:posList>35.67158420919719 139.74668721263976 32.202 35.67158420919719 139.74668721263976 35.184 35.671582966622985 139.74668904768933 35.184 35.671582966622985 139.74668904768933 31.98 35.67158420919719 139.74668721263976 32.202</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-5f406581-600a-45b4-98ec-2c081e675a41">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5f406581-600a-45b4-98ec-2c081e675a41">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5f406581-600a-45b4-98ec-2c081e675a41">
											<gml:posList>35.67157840021657 139.74641882392646 12.3 35.67161094366112 139.74642420139742 12.3 35.67164115087171 139.74643974412416 12.3 35.671668841251226 139.74646501045493 12.3 35.67168788155903 139.74649459428446 12.3 35.671700523470584 139.74652606295112 12.3 35.6717047790298 139.74655256980554 12.3 35.671704079264394 139.7465821750287 12.3 35.671698873585264 139.74661311069832 12.3 35.67168871051 139.74664427265296 12.3 35.67167655947857 139.74666858795652 12.3 35.67163595638811 139.7467364569459 12.3 35.67143590589945 139.74656147703098 12.3 35.671476147387864 139.74649228294498 12.3 35.67149388482014 139.74646508955547 12.3 35.6715130683478 139.7464433073305 12.3 35.67153379050274 139.74643025009811 12.3 35.671551721272685 139.74642117259685 12.3 35.671567944059404 139.74641850386897 12.3 35.67157840021657 139.74641882392646 12.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-5f40aa7f-8d05-4016-bd60-3586a9dd6e2e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5f40aa7f-8d05-4016-bd60-3586a9dd6e2e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5f40aa7f-8d05-4016-bd60-3586a9dd6e2e">
											<gml:posList>35.67157840021657 139.74641882392646 42.2 35.671567944059404 139.74641850386897 42.2 35.671568099931854 139.74642216006623 42.2 35.67157817750469 139.74642246948815 42.2 35.67157840021657 139.74641882392646 42.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-1d702249-0124-4b59-b724-0c3808ede66e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1d702249-0124-4b59-b724-0c3808ede66e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1d702249-0124-4b59-b724-0c3808ede66e">
											<gml:posList>35.671567944059404 139.74641850386897 42.2 35.671551721272685 139.74642117259685 42.2 35.67155249901216 139.7464247176551 42.2 35.671568099931854 139.74642216006623 42.2 35.671567944059404 139.74641850386897 42.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c45b38a6-a792-4fcd-a9ce-9df15f83b00a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c45b38a6-a792-4fcd-a9ce-9df15f83b00a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c45b38a6-a792-4fcd-a9ce-9df15f83b00a">
											<gml:posList>35.67157840021657 139.74641882392646 42.2 35.67157817750469 139.74642246948815 42.2 35.67161016202654 139.74642774814856 42.2 35.67161094366112 139.74642420139742 42.2 35.67157840021657 139.74641882392646 42.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-4cccf6a1-17fc-4151-bc5c-3d291bd21bfb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4cccf6a1-17fc-4151-bc5c-3d291bd21bfb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4cccf6a1-17fc-4151-bc5c-3d291bd21bfb">
											<gml:posList>35.67153379050274 139.74643025009811 42.2 35.671535090854505 139.74643354052156 42.2 35.67155249901216 139.7464247176551 42.2 35.671551721272685 139.74642117259685 42.2 35.67153379050274 139.74643025009811 42.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-2a648c43-7361-443d-a6e3-a6ace30a3e08">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2a648c43-7361-443d-a6e3-a6ace30a3e08">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2a648c43-7361-443d-a6e3-a6ace30a3e08">
											<gml:posList>35.67161094366112 139.74642420139742 42.2 35.67161016202654 139.74642774814856 42.2 35.6716396208267 139.74644291610886 42.2 35.67164115087171 139.74643974412416 42.2 35.67161094366112 139.74642420139742 42.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-200a7218-c2db-46b7-8212-e7e42222f0e8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-200a7218-c2db-46b7-8212-e7e42222f0e8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-200a7218-c2db-46b7-8212-e7e42222f0e8">
											<gml:posList>35.67153379050274 139.74643025009811 42.2 35.6715130683478 139.7464433073305 42.2 35.67151479214488 139.74644632113396 42.2 35.671535090854505 139.74643354052156 42.2 35.67153379050274 139.74643025009811 42.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-994866ce-6157-4774-a1ca-11b046dd5fce">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-994866ce-6157-4774-a1ca-11b046dd5fce">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-994866ce-6157-4774-a1ca-11b046dd5fce">
											<gml:posList>35.67164115087171 139.74643974412416 42.2 35.6716396208267 139.74644291610886 42.2 35.67166674296652 139.74646766387335 42.2 35.671668841251226 139.74646501045493 42.2 35.67164115087171 139.74643974412416 42.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-8d21fad1-2ef1-4612-8f33-6daf4a361e22">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8d21fad1-2ef1-4612-8f33-6daf4a361e22">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8d21fad1-2ef1-4612-8f33-6daf4a361e22">
											<gml:posList>35.67149388482014 139.74646508955547 42.2 35.671496058936235 139.74646759473575 42.2 35.67151479214488 139.74644632113396 42.2 35.6715130683478 139.7464433073305 42.2 35.67149388482014 139.74646508955547 42.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b6b55970-49af-4fec-a65b-95dfbcae3006">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b6b55970-49af-4fec-a65b-95dfbcae3006">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b6b55970-49af-4fec-a65b-95dfbcae3006">
											<gml:posList>35.671603794204 139.74648448950845 46.199 35.67160666011356 139.74648385675746 46.199 35.671622314927305 139.74645604697835 46.199 35.671621780583166 139.74645253479227 46.199 35.671603794204 139.74648448950845 46.199</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-df36848a-0bc6-440a-9478-1874ffd6457e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-df36848a-0bc6-440a-9478-1874ffd6457e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-df36848a-0bc6-440a-9478-1874ffd6457e">
											<gml:posList>35.671668841251226 139.74646501045493 42.2 35.67166674296652 139.74646766387335 42.2 35.67167139025294 139.74647489425502 42.2 35.67167510380292 139.7464747466281 42.2 35.671668841251226 139.74646501045493 42.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-4fbf7135-1911-4dfe-bde1-ed6f5d857a4d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4fbf7135-1911-4dfe-bde1-ed6f5d857a4d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4fbf7135-1911-4dfe-bde1-ed6f5d857a4d">
											<gml:posList>35.67166638067666 139.74649024318362 46.199 35.671621780583166 139.74645253479227 46.199 35.671622314927305 139.74645604697835 46.199 35.67166690600598 139.74649375538164 46.199 35.67166638067666 139.74649024318362 46.199</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-16d9bcae-158b-4332-a18e-b1c3f3757a93">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-16d9bcae-158b-4332-a18e-b1c3f3757a93">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-16d9bcae-158b-4332-a18e-b1c3f3757a93">
											<gml:posList>35.67167329435552 139.74647795205553 42.2 35.67167510380292 139.7464747466281 42.2 35.67167139025294 139.74647489425502 42.2 35.67167329435552 139.74647795205553 42.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-fff41a96-4cf3-40e3-9818-3335e2b54691">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fff41a96-4cf3-40e3-9818-3335e2b54691">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fff41a96-4cf3-40e3-9818-3335e2b54691">
											<gml:posList>35.671476147387864 139.74649228294498 42.2 35.67147857360881 139.74649440122798 42.2 35.671496058936235 139.74646759473575 42.2 35.67149388482014 139.74646508955547 42.2 35.671476147387864 139.74649228294498 42.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-0858612b-6de1-4a92-8366-c762689fd0e9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0858612b-6de1-4a92-8366-c762689fd0e9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0858612b-6de1-4a92-8366-c762689fd0e9">
											<gml:posList>35.67166638067666 139.74649024318362 46.199 35.67166690600598 139.74649375538164 46.199 35.67167521502735 139.74647898834002 46.199 35.67167510380292 139.7464747466281 46.199 35.67166638067666 139.74649024318362 46.199</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-61a84eeb-1085-4222-9ec2-ef3d9ab567b3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-61a84eeb-1085-4222-9ec2-ef3d9ab567b3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-61a84eeb-1085-4222-9ec2-ef3d9ab567b3">
											<gml:posList>35.67168788155903 139.74649459428446 46.199 35.67167510380292 139.7464747466281 46.199 35.67167521502735 139.74647898834002 46.199 35.67168615192814 139.74649598800931 46.199 35.67168788155903 139.74649459428446 46.199</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-aaf646ff-f37b-43f5-b946-0bd3469b38b1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-aaf646ff-f37b-43f5-b946-0bd3469b38b1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-aaf646ff-f37b-43f5-b946-0bd3469b38b1">
											<gml:posList>35.671476147387864 139.74649228294498 42.2 35.67147252834852 139.74649849494767 42.2 35.67147668306918 139.74649765092053 42.2 35.67147857360881 139.74649440122798 42.2 35.671476147387864 139.74649228294498 42.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ad5c8475-99ec-4959-8b9a-76ad290672ff">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ad5c8475-99ec-4959-8b9a-76ad290672ff">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ad5c8475-99ec-4959-8b9a-76ad290672ff">
											<gml:posList>35.67168788155903 139.74649459428446 46.199 35.67168615192814 139.74649598800931 46.199 35.6716904682302 139.74650672047449 46.199 35.67169283899845 139.74650693883578 46.199 35.67168788155903 139.74649459428446 46.199</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-4c8df497-460a-4b84-a370-6aa6bb5271de">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4c8df497-460a-4b84-a370-6aa6bb5271de">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4c8df497-460a-4b84-a370-6aa6bb5271de">
											<gml:posList>35.671646897093865 139.7465209291903 46.199 35.671649762995635 139.74652028539384 46.199 35.67160666011356 139.74648385675746 46.199 35.671603794204 139.74648448950845 46.199 35.671646897093865 139.7465209291903 46.199</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a683a72d-8bff-4eb9-80b7-5c3162188f72">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a683a72d-8bff-4eb9-80b7-5c3162188f72">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a683a72d-8bff-4eb9-80b7-5c3162188f72">
											<gml:posList>35.67168615192814 139.74649598800931 45.772 35.67167521502735 139.74647898834002 45.772 35.67166690600598 139.74649375538164 45.772 35.671622314927305 139.74645604697835 45.772 35.67160666011356 139.74648385675746 45.772 35.671649762995635 139.74652028539384 45.772 35.67164005862583 139.74653752833828 45.772 35.671662453368526 139.74655647082562 45.772 35.6716904682302 139.74650672047449 45.772 35.67168615192814 139.74649598800931 45.772</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-20e2f31e-068c-48ac-b8ce-6126f28520ef">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-20e2f31e-068c-48ac-b8ce-6126f28520ef">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-20e2f31e-068c-48ac-b8ce-6126f28520ef">
											<gml:posList>35.67169240251132 139.74651413054147 42.2 35.67169283899845 139.74650693883578 42.2 35.6716906154606 139.74651089586956 42.2 35.67169240251132 139.74651413054147 42.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-0b18840f-6274-4b0d-a103-ad829ceda78b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0b18840f-6274-4b0d-a103-ad829ceda78b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0b18840f-6274-4b0d-a103-ad829ceda78b">
											<gml:posList>35.671700523470584 139.74652606295112 42.2 35.67169283899845 139.74650693883578 42.2 35.67169240251132 139.74651413054147 42.2 35.67169766695682 139.74652722592035 42.2 35.671700523470584 139.74652606295112 42.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-452a4a17-facd-4cdb-9d0a-dc356cd38eaf">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-452a4a17-facd-4cdb-9d0a-dc356cd38eaf">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-452a4a17-facd-4cdb-9d0a-dc356cd38eaf">
											<gml:posList>35.671646897093865 139.7465209291903 46.199 35.67163719272396 139.74653817213402 46.199 35.67164005862583 139.74653752833828 46.199 35.671649762995635 139.74652028539384 46.199 35.671646897093865 139.7465209291903 46.199</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a5ccee09-2228-41e7-958d-80178fd1d240">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a5ccee09-2228-41e7-958d-80178fd1d240">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a5ccee09-2228-41e7-958d-80178fd1d240">
											<gml:posList>35.67169283899845 139.74650693883578 46.199 35.6716904682302 139.74650672047449 46.199 35.671662453368526 139.74655647082562 46.199 35.67166297868795 139.74655997197752 46.199 35.67169283899845 139.74650693883578 46.199</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-487bf42b-8cf6-4975-aa20-480efc67c13f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-487bf42b-8cf6-4975-aa20-480efc67c13f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-487bf42b-8cf6-4975-aa20-480efc67c13f">
											<gml:posList>35.671700523470584 139.74652606295112 42.2 35.67169766695682 139.74652722592035 42.2 35.67170178668103 139.746552860252 42.2 35.6717047790298 139.74655256980554 42.2 35.671700523470584 139.74652606295112 42.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-714f71ee-77f5-4671-aeea-f16a889a80ed">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-714f71ee-77f5-4671-aeea-f16a889a80ed">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-714f71ee-77f5-4671-aeea-f16a889a80ed">
											<gml:posList>35.67163719272396 139.74653817213402 41.743 35.671646897093865 139.7465209291903 41.743 35.671603794204 139.74648448950845 41.743 35.671621780583166 139.74645253479227 41.743 35.67166638067666 139.74649024318362 41.743 35.67167329435552 139.74647795205553 41.743 35.67167139025294 139.74647489425502 41.743 35.67166674296652 139.74646766387335 41.743 35.6716396208267 139.74644291610886 41.743 35.67161016202654 139.74642774814856 41.743 35.67157817750469 139.74642246948815 41.743 35.671568099931854 139.74642216006623 41.743 35.67155249901216 139.7464247176551 41.743 35.671535090854505 139.74643354052156 41.743 35.67151479214488 139.74644632113396 41.743 35.671496058936235 139.74646759473575 41.743 35.67147857360881 139.74649440122798 41.743 35.67147668306918 139.74649765092053 41.743 35.67167246770183 139.74666922202655 41.743 35.671674052224716 139.74666659126143 41.743 35.671686032233595 139.74664260753647 41.743 35.671696015431785 139.74661199809927 41.743 35.67170110443363 139.74658175848282 41.743 35.67170178668103 139.746552860252 41.743 35.67169766695682 139.74652722592035 41.743 35.67169240251132 139.74651413054147 41.743 35.6716906154606 139.74651089586956 41.743 35.67166297868795 139.74655997197752 41.743 35.67163719272396 139.74653817213402 41.743</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-74b56230-fd8d-483e-b960-577d5711e8ff">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-74b56230-fd8d-483e-b960-577d5711e8ff">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-74b56230-fd8d-483e-b960-577d5711e8ff">
											<gml:posList>35.67166297868795 139.74655997197752 46.199 35.671662453368526 139.74655647082562 46.199 35.67164005862583 139.74653752833828 46.199 35.67163719272396 139.74653817213402 46.199 35.67166297868795 139.74655997197752 46.199</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-7d3d6021-b43d-4f18-af59-2e4b7087a69e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7d3d6021-b43d-4f18-af59-2e4b7087a69e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7d3d6021-b43d-4f18-af59-2e4b7087a69e">
											<gml:posList>35.6717047790298 139.74655256980554 42.2 35.67170178668103 139.746552860252 42.2 35.67170110443363 139.74658175848282 42.2 35.671704079264394 139.7465821750287 42.2 35.6717047790298 139.74655256980554 42.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-8c0d685b-ec63-4543-8365-ad9202e9ef12">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8c0d685b-ec63-4543-8365-ad9202e9ef12">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8c0d685b-ec63-4543-8365-ad9202e9ef12">
											<gml:posList>35.67167313837441 139.74667430266314 42.2 35.67167246770183 139.74666922202655 42.2 35.67147668306918 139.74649765092053 42.2 35.67147252834852 139.74649849494767 42.2 35.67167313837441 139.74667430266314 42.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a565d8dc-1919-4c6a-a4a2-8edb3df7d8c9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a565d8dc-1919-4c6a-a4a2-8edb3df7d8c9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a565d8dc-1919-4c6a-a4a2-8edb3df7d8c9">
											<gml:posList>35.67167313837441 139.74667430266314 41.046 35.67147252834852 139.74649849494767 41.046 35.67146005080527 139.74651997163411 38.6 35.67166065135734 139.74669518287874 38.6 35.67167313837441 139.74667430266314 41.046</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e1dd19bc-4105-467a-a40f-800ab7738849">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e1dd19bc-4105-467a-a40f-800ab7738849">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e1dd19bc-4105-467a-a40f-800ab7738849">
											<gml:posList>35.671704079264394 139.7465821750287 42.2 35.67170110443363 139.74658175848282 42.2 35.671696015431785 139.74661199809927 42.2 35.671698873585264 139.74661311069832 42.2 35.671704079264394 139.7465821750287 42.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-3ecdb279-d973-435f-a5f2-8a0d38440fc5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3ecdb279-d973-435f-a5f2-8a0d38440fc5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3ecdb279-d973-435f-a5f2-8a0d38440fc5">
											<gml:posList>35.67146005080527 139.74651997163411 37.998 35.67144797835019 139.74654071881247 35.2 35.671648299367654 139.74671581992038 35.2 35.67166065135734 139.74669518287874 37.998 35.67146005080527 139.74651997163411 37.998</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-87fd1000-3f43-41e1-b52f-5770067206e5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-87fd1000-3f43-41e1-b52f-5770067206e5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-87fd1000-3f43-41e1-b52f-5770067206e5">
											<gml:posList>35.671698873585264 139.74661311069832 42.2 35.671696015431785 139.74661199809927 42.2 35.671686032233595 139.74664260753647 42.2 35.67168871051 139.74664427265296 42.2 35.671698873585264 139.74661311069832 42.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-03960dde-3131-4302-8cff-c9d914e1987d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-03960dde-3131-4302-8cff-c9d914e1987d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-03960dde-3131-4302-8cff-c9d914e1987d">
											<gml:posList>35.67144797835019 139.74654071881247 34.273 35.67143590589945 139.74656147703098 31.9 35.67163595638811 139.7467364569459 31.9 35.671648299367654 139.74671581992038 34.273 35.67144797835019 139.74654071881247 34.273</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d0e8e0f4-3dbe-4516-bc60-56ba8bf6fd71">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d0e8e0f4-3dbe-4516-bc60-56ba8bf6fd71">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d0e8e0f4-3dbe-4516-bc60-56ba8bf6fd71">
											<gml:posList>35.67167655947857 139.74666858795652 42.2 35.67168871051 139.74664427265296 42.2 35.671686032233595 139.74664260753647 42.2 35.671674052224716 139.74666659126143 42.2 35.67167655947857 139.74666858795652 42.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b365696a-782d-41bd-8f76-6dcd993b7f04">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b365696a-782d-41bd-8f76-6dcd993b7f04">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b365696a-782d-41bd-8f76-6dcd993b7f04">
											<gml:posList>35.67167655947857 139.74666858795652 42.2 35.671674052224716 139.74666659126143 42.2 35.67167246770183 139.74666922202655 42.2 35.67167313837441 139.74667430266314 42.2 35.67167655947857 139.74666858795652 42.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-858a394b-1ba0-44af-a827-e02ce0aae9d1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-858a394b-1ba0-44af-a827-e02ce0aae9d1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-858a394b-1ba0-44af-a827-e02ce0aae9d1">
											<gml:posList>35.671649762995635 139.74652028539384 46.199 35.671649762995635 139.74652028539384 45.772 35.67160666011356 139.74648385675746 45.772 35.67160666011356 139.74648385675746 46.199 35.671649762995635 139.74652028539384 46.199</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6b87a848-a9cf-4a0d-8391-3175c0145984">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6b87a848-a9cf-4a0d-8391-3175c0145984">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6b87a848-a9cf-4a0d-8391-3175c0145984">
											<gml:posList>35.67157840021657 139.74641882392646 12.3 35.671567944059404 139.74641850386897 12.3 35.671567944059404 139.74641850386897 42.2 35.67157840021657 139.74641882392646 42.2 35.67157840021657 139.74641882392646 12.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0b263af6-16c7-4edc-9171-e84b097a3ca7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0b263af6-16c7-4edc-9171-e84b097a3ca7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0b263af6-16c7-4edc-9171-e84b097a3ca7">
											<gml:posList>35.671567944059404 139.74641850386897 12.3 35.671551721272685 139.74642117259685 12.3 35.671551721272685 139.74642117259685 42.2 35.671567944059404 139.74641850386897 42.2 35.671567944059404 139.74641850386897 12.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1dd6dc5b-cc05-484e-ae06-f9607905e84c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1dd6dc5b-cc05-484e-ae06-f9607905e84c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1dd6dc5b-cc05-484e-ae06-f9607905e84c">
											<gml:posList>35.67161094366112 139.74642420139742 12.3 35.67157840021657 139.74641882392646 12.3 35.67157840021657 139.74641882392646 42.2 35.67161094366112 139.74642420139742 42.2 35.67161094366112 139.74642420139742 12.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-84ba8d3b-37fc-4353-8dff-d41a713516e9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-84ba8d3b-37fc-4353-8dff-d41a713516e9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-84ba8d3b-37fc-4353-8dff-d41a713516e9">
											<gml:posList>35.671568099931854 139.74642216006623 42.2 35.671568099931854 139.74642216006623 41.743 35.67157817750469 139.74642246948815 41.743 35.67157817750469 139.74642246948815 42.2 35.671568099931854 139.74642216006623 42.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-671cb933-367c-4da0-9feb-ab089f872604">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-671cb933-367c-4da0-9feb-ab089f872604">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-671cb933-367c-4da0-9feb-ab089f872604">
											<gml:posList>35.67155249901216 139.7464247176551 42.2 35.67155249901216 139.7464247176551 41.743 35.671568099931854 139.74642216006623 41.743 35.671568099931854 139.74642216006623 42.2 35.67155249901216 139.7464247176551 42.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9c3b9069-42f1-4c17-a0f4-c78aa4964021">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9c3b9069-42f1-4c17-a0f4-c78aa4964021">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9c3b9069-42f1-4c17-a0f4-c78aa4964021">
											<gml:posList>35.67157817750469 139.74642246948815 42.2 35.67157817750469 139.74642246948815 41.743 35.67161016202654 139.74642774814856 41.743 35.67161016202654 139.74642774814856 42.2 35.67157817750469 139.74642246948815 42.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-cdea355d-1fc9-4ea5-8fb4-247fccfcb0db">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cdea355d-1fc9-4ea5-8fb4-247fccfcb0db">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cdea355d-1fc9-4ea5-8fb4-247fccfcb0db">
											<gml:posList>35.671551721272685 139.74642117259685 12.3 35.67153379050274 139.74643025009811 12.3 35.67153379050274 139.74643025009811 42.2 35.671551721272685 139.74642117259685 42.2 35.671551721272685 139.74642117259685 12.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f19eae39-cd6f-4749-9e17-5607c476bbd0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f19eae39-cd6f-4749-9e17-5607c476bbd0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f19eae39-cd6f-4749-9e17-5607c476bbd0">
											<gml:posList>35.671535090854505 139.74643354052156 42.2 35.671535090854505 139.74643354052156 41.743 35.67155249901216 139.7464247176551 41.743 35.67155249901216 139.7464247176551 42.2 35.671535090854505 139.74643354052156 42.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5eaaf81e-57e8-48b4-a59d-3637d34f62b3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5eaaf81e-57e8-48b4-a59d-3637d34f62b3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5eaaf81e-57e8-48b4-a59d-3637d34f62b3">
											<gml:posList>35.67164115087171 139.74643974412416 12.3 35.67161094366112 139.74642420139742 12.3 35.67161094366112 139.74642420139742 42.2 35.67164115087171 139.74643974412416 42.2 35.67164115087171 139.74643974412416 12.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9410b4b2-d8e4-42c5-af33-67a379a5cc63">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9410b4b2-d8e4-42c5-af33-67a379a5cc63">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9410b4b2-d8e4-42c5-af33-67a379a5cc63">
											<gml:posList>35.67161016202654 139.74642774814856 42.2 35.67161016202654 139.74642774814856 41.743 35.6716396208267 139.74644291610886 41.743 35.6716396208267 139.74644291610886 42.2 35.67161016202654 139.74642774814856 42.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-87417cc4-8549-40b4-8e5f-1471a62059e5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-87417cc4-8549-40b4-8e5f-1471a62059e5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-87417cc4-8549-40b4-8e5f-1471a62059e5">
											<gml:posList>35.67153379050274 139.74643025009811 12.3 35.6715130683478 139.7464433073305 12.3 35.6715130683478 139.7464433073305 42.2 35.67153379050274 139.74643025009811 42.2 35.67153379050274 139.74643025009811 12.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-39ad8c72-f461-4883-b2cb-d8370a7dbeb5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-39ad8c72-f461-4883-b2cb-d8370a7dbeb5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-39ad8c72-f461-4883-b2cb-d8370a7dbeb5">
											<gml:posList>35.67151479214488 139.74644632113396 42.2 35.67151479214488 139.74644632113396 41.743 35.671535090854505 139.74643354052156 41.743 35.671535090854505 139.74643354052156 42.2 35.67151479214488 139.74644632113396 42.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d02ea6e6-5c83-4a20-a9c4-5fa7c87495aa">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d02ea6e6-5c83-4a20-a9c4-5fa7c87495aa">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d02ea6e6-5c83-4a20-a9c4-5fa7c87495aa">
											<gml:posList>35.671668841251226 139.74646501045493 12.3 35.67164115087171 139.74643974412416 12.3 35.67164115087171 139.74643974412416 42.2 35.671668841251226 139.74646501045493 42.2 35.671668841251226 139.74646501045493 12.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-85220563-1949-48d7-8c12-43e38c5808e1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-85220563-1949-48d7-8c12-43e38c5808e1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-85220563-1949-48d7-8c12-43e38c5808e1">
											<gml:posList>35.6715130683478 139.7464433073305 12.3 35.67149388482014 139.74646508955547 12.3 35.67149388482014 139.74646508955547 42.2 35.6715130683478 139.7464433073305 42.2 35.6715130683478 139.7464433073305 12.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9d3d8f11-7b15-4b07-ab9d-30d559083273">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9d3d8f11-7b15-4b07-ab9d-30d559083273">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9d3d8f11-7b15-4b07-ab9d-30d559083273">
											<gml:posList>35.6716396208267 139.74644291610886 42.2 35.6716396208267 139.74644291610886 41.743 35.67166674296652 139.74646766387335 41.743 35.67166674296652 139.74646766387335 42.2 35.6716396208267 139.74644291610886 42.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ec11d93e-82e9-440a-9e3b-c6b7f6b9d53c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ec11d93e-82e9-440a-9e3b-c6b7f6b9d53c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ec11d93e-82e9-440a-9e3b-c6b7f6b9d53c">
											<gml:posList>35.671496058936235 139.74646759473575 42.2 35.671496058936235 139.74646759473575 41.743 35.67151479214488 139.74644632113396 41.743 35.67151479214488 139.74644632113396 42.2 35.671496058936235 139.74646759473575 42.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c3ca04e8-e61c-476c-8e9a-97e22d034fd5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c3ca04e8-e61c-476c-8e9a-97e22d034fd5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c3ca04e8-e61c-476c-8e9a-97e22d034fd5">
											<gml:posList>35.671603794204 139.74648448950845 46.199 35.671621780583166 139.74645253479227 46.199 35.671621780583166 139.74645253479227 41.743 35.671603794204 139.74648448950845 41.743 35.671603794204 139.74648448950845 46.199</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b52c4f16-539f-4f56-b06c-06b42b223047">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b52c4f16-539f-4f56-b06c-06b42b223047">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b52c4f16-539f-4f56-b06c-06b42b223047">
											<gml:posList>35.67160666011356 139.74648385675746 46.199 35.67160666011356 139.74648385675746 45.772 35.671622314927305 139.74645604697835 45.772 35.671622314927305 139.74645604697835 46.199 35.67160666011356 139.74648385675746 46.199</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3eb72d30-b8c1-4198-8c5b-5c79d856a6cb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3eb72d30-b8c1-4198-8c5b-5c79d856a6cb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3eb72d30-b8c1-4198-8c5b-5c79d856a6cb">
											<gml:posList>35.67166674296652 139.74646766387335 42.2 35.67166674296652 139.74646766387335 41.743 35.67167139025294 139.74647489425502 41.743 35.67167139025294 139.74647489425502 42.2 35.67166674296652 139.74646766387335 42.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-15a9670d-66be-487a-bb31-682eea52cd7e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-15a9670d-66be-487a-bb31-682eea52cd7e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-15a9670d-66be-487a-bb31-682eea52cd7e">
											<gml:posList>35.671621780583166 139.74645253479227 46.199 35.67166638067666 139.74649024318362 46.199 35.67166638067666 139.74649024318362 41.743 35.671621780583166 139.74645253479227 41.743 35.671621780583166 139.74645253479227 46.199</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2cb0adfd-ab0a-44da-8c92-d3fd720a0db8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2cb0adfd-ab0a-44da-8c92-d3fd720a0db8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2cb0adfd-ab0a-44da-8c92-d3fd720a0db8">
											<gml:posList>35.671622314927305 139.74645604697835 46.199 35.671622314927305 139.74645604697835 45.772 35.67166690600598 139.74649375538164 45.772 35.67166690600598 139.74649375538164 46.199 35.671622314927305 139.74645604697835 46.199</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2040fe2c-4280-478c-8420-a47b7e11e02b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2040fe2c-4280-478c-8420-a47b7e11e02b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2040fe2c-4280-478c-8420-a47b7e11e02b">
											<gml:posList>35.67167139025294 139.74647489425502 42.2 35.67167139025294 139.74647489425502 41.743 35.67167329435552 139.74647795205553 41.743 35.67167329435552 139.74647795205553 42.2 35.67167139025294 139.74647489425502 42.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0406326e-0fa3-4d48-837f-e8b7e87830b9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0406326e-0fa3-4d48-837f-e8b7e87830b9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0406326e-0fa3-4d48-837f-e8b7e87830b9">
											<gml:posList>35.67149388482014 139.74646508955547 12.3 35.671476147387864 139.74649228294498 12.3 35.671476147387864 139.74649228294498 42.2 35.67149388482014 139.74646508955547 42.2 35.67149388482014 139.74646508955547 12.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-bd4510f3-474f-48b4-9ae0-ef000abd4f9c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bd4510f3-474f-48b4-9ae0-ef000abd4f9c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bd4510f3-474f-48b4-9ae0-ef000abd4f9c">
											<gml:posList>35.671668841251226 139.74646501045493 12.3 35.671668841251226 139.74646501045493 42.2 35.67167510380292 139.7464747466281 42.2 35.67167510380292 139.7464747466281 46.199 35.67168788155903 139.74649459428446 46.199 35.67168788155903 139.74649459428446 12.3 35.671668841251226 139.74646501045493 12.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7c174ba4-6289-4772-a8bf-dfaab21b4774">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7c174ba4-6289-4772-a8bf-dfaab21b4774">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7c174ba4-6289-4772-a8bf-dfaab21b4774">
											<gml:posList>35.67147857360881 139.74649440122798 42.2 35.67147857360881 139.74649440122798 41.743 35.671496058936235 139.74646759473575 41.743 35.671496058936235 139.74646759473575 42.2 35.67147857360881 139.74649440122798 42.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-95839309-d9ca-4b67-91cc-15e7b8635b51">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-95839309-d9ca-4b67-91cc-15e7b8635b51">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-95839309-d9ca-4b67-91cc-15e7b8635b51">
											<gml:posList>35.67166638067666 139.74649024318362 41.743 35.67166638067666 139.74649024318362 46.199 35.67167510380292 139.7464747466281 46.199 35.67167510380292 139.7464747466281 42.2 35.67167329435552 139.74647795205553 42.2 35.67167329435552 139.74647795205553 41.743 35.67166638067666 139.74649024318362 41.743</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c868c190-eb4d-47c9-a3da-ecf927986e37">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c868c190-eb4d-47c9-a3da-ecf927986e37">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c868c190-eb4d-47c9-a3da-ecf927986e37">
											<gml:posList>35.67166690600598 139.74649375538164 46.199 35.67166690600598 139.74649375538164 45.772 35.67167521502735 139.74647898834002 45.772 35.67167521502735 139.74647898834002 46.199 35.67166690600598 139.74649375538164 46.199</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f60c6160-f1c5-4020-8ed8-7eb699748c15">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f60c6160-f1c5-4020-8ed8-7eb699748c15">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f60c6160-f1c5-4020-8ed8-7eb699748c15">
											<gml:posList>35.67167521502735 139.74647898834002 46.199 35.67167521502735 139.74647898834002 45.772 35.67168615192814 139.74649598800931 45.772 35.67168615192814 139.74649598800931 46.199 35.67167521502735 139.74647898834002 46.199</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-30106bd7-34b3-4bea-94c7-49a977414055">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-30106bd7-34b3-4bea-94c7-49a977414055">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-30106bd7-34b3-4bea-94c7-49a977414055">
											<gml:posList>35.67147668306918 139.74649765092053 42.2 35.67147668306918 139.74649765092053 41.743 35.67147857360881 139.74649440122798 41.743 35.67147857360881 139.74649440122798 42.2 35.67147668306918 139.74649765092053 42.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e55b1a74-61ca-4a70-a699-d9be4164796e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e55b1a74-61ca-4a70-a699-d9be4164796e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e55b1a74-61ca-4a70-a699-d9be4164796e">
											<gml:posList>35.67168615192814 139.74649598800931 46.199 35.67168615192814 139.74649598800931 45.772 35.6716904682302 139.74650672047449 45.772 35.6716904682302 139.74650672047449 46.199 35.67168615192814 139.74649598800931 46.199</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6a60f21a-2943-4a99-8125-eb7c5a87f27f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6a60f21a-2943-4a99-8125-eb7c5a87f27f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6a60f21a-2943-4a99-8125-eb7c5a87f27f">
											<gml:posList>35.671603794204 139.74648448950845 41.743 35.671646897093865 139.7465209291903 41.743 35.671646897093865 139.7465209291903 46.199 35.671603794204 139.74648448950845 46.199 35.671603794204 139.74648448950845 41.743</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-388a1cc8-215a-4f47-8e53-24270f9903b4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-388a1cc8-215a-4f47-8e53-24270f9903b4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-388a1cc8-215a-4f47-8e53-24270f9903b4">
											<gml:posList>35.671700523470584 139.74652606295112 12.3 35.67168788155903 139.74649459428446 12.3 35.67168788155903 139.74649459428446 46.199 35.67169283899845 139.74650693883578 46.199 35.67169283899845 139.74650693883578 42.2 35.671700523470584 139.74652606295112 42.2 35.671700523470584 139.74652606295112 12.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-eec67339-8ee6-4873-b92f-94777d0e22a4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-eec67339-8ee6-4873-b92f-94777d0e22a4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-eec67339-8ee6-4873-b92f-94777d0e22a4">
											<gml:posList>35.6716906154606 139.74651089586956 42.2 35.6716906154606 139.74651089586956 41.743 35.67169240251132 139.74651413054147 41.743 35.67169240251132 139.74651413054147 42.2 35.6716906154606 139.74651089586956 42.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-245bc0d3-b227-4837-92f3-a89b96116fe2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-245bc0d3-b227-4837-92f3-a89b96116fe2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-245bc0d3-b227-4837-92f3-a89b96116fe2">
											<gml:posList>35.67169240251132 139.74651413054147 42.2 35.67169240251132 139.74651413054147 41.743 35.67169766695682 139.74652722592035 41.743 35.67169766695682 139.74652722592035 42.2 35.67169240251132 139.74651413054147 42.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f8aa96bd-d2ec-4912-8300-68885e55da8e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f8aa96bd-d2ec-4912-8300-68885e55da8e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f8aa96bd-d2ec-4912-8300-68885e55da8e">
											<gml:posList>35.671476147387864 139.74649228294498 42.2 35.671476147387864 139.74649228294498 12.3 35.67143590589945 139.74656147703098 12.3 35.67143590589945 139.74656147703098 31.9 35.67144797835019 139.74654071881247 34.273 35.67144797835019 139.74654071881247 35.2 35.67146005080527 139.74651997163411 37.998 35.67146005080527 139.74651997163411 38.6 35.67147252834852 139.74649849494767 41.046 35.67147252834852 139.74649849494767 42.2 35.671476147387864 139.74649228294498 42.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4265ccde-9a78-4539-a728-3d312999460c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4265ccde-9a78-4539-a728-3d312999460c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4265ccde-9a78-4539-a728-3d312999460c">
											<gml:posList>35.67164005862583 139.74653752833828 46.199 35.67164005862583 139.74653752833828 45.772 35.671649762995635 139.74652028539384 45.772 35.671649762995635 139.74652028539384 46.199 35.67164005862583 139.74653752833828 46.199</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-161c8e20-862b-45fb-ae1f-f0df3f7a2c61">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-161c8e20-862b-45fb-ae1f-f0df3f7a2c61">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-161c8e20-862b-45fb-ae1f-f0df3f7a2c61">
											<gml:posList>35.67163719272396 139.74653817213402 46.199 35.671646897093865 139.7465209291903 46.199 35.671646897093865 139.7465209291903 41.743 35.67163719272396 139.74653817213402 41.743 35.67163719272396 139.74653817213402 46.199</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-bede1466-f889-4139-8a21-5d4da09a9068">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bede1466-f889-4139-8a21-5d4da09a9068">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bede1466-f889-4139-8a21-5d4da09a9068">
											<gml:posList>35.6716904682302 139.74650672047449 46.199 35.6716904682302 139.74650672047449 45.772 35.671662453368526 139.74655647082562 45.772 35.671662453368526 139.74655647082562 46.199 35.6716904682302 139.74650672047449 46.199</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-13c5d6b1-c386-40ca-9081-de9132813876">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-13c5d6b1-c386-40ca-9081-de9132813876">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-13c5d6b1-c386-40ca-9081-de9132813876">
											<gml:posList>35.67169283899845 139.74650693883578 46.199 35.67166297868795 139.74655997197752 46.199 35.67166297868795 139.74655997197752 41.743 35.6716906154606 139.74651089586956 41.743 35.6716906154606 139.74651089586956 42.2 35.67169283899845 139.74650693883578 42.2 35.67169283899845 139.74650693883578 46.199</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0a9c035a-7e12-4527-8e18-43647a4f7072">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0a9c035a-7e12-4527-8e18-43647a4f7072">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0a9c035a-7e12-4527-8e18-43647a4f7072">
											<gml:posList>35.6717047790298 139.74655256980554 12.3 35.671700523470584 139.74652606295112 12.3 35.671700523470584 139.74652606295112 42.2 35.6717047790298 139.74655256980554 42.2 35.6717047790298 139.74655256980554 12.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-624344e8-7a9f-4805-8aee-72a04b43b548">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-624344e8-7a9f-4805-8aee-72a04b43b548">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-624344e8-7a9f-4805-8aee-72a04b43b548">
											<gml:posList>35.67169766695682 139.74652722592035 42.2 35.67169766695682 139.74652722592035 41.743 35.67170178668103 139.746552860252 41.743 35.67170178668103 139.746552860252 42.2 35.67169766695682 139.74652722592035 42.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6478968b-5589-4e22-986c-a23f5dedcc84">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6478968b-5589-4e22-986c-a23f5dedcc84">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6478968b-5589-4e22-986c-a23f5dedcc84">
											<gml:posList>35.671662453368526 139.74655647082562 46.199 35.671662453368526 139.74655647082562 45.772 35.67164005862583 139.74653752833828 45.772 35.67164005862583 139.74653752833828 46.199 35.671662453368526 139.74655647082562 46.199</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-103befb1-d400-4616-8c30-91a94b77a617">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-103befb1-d400-4616-8c30-91a94b77a617">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-103befb1-d400-4616-8c30-91a94b77a617">
											<gml:posList>35.67163719272396 139.74653817213402 41.743 35.67166297868795 139.74655997197752 41.743 35.67166297868795 139.74655997197752 46.199 35.67163719272396 139.74653817213402 46.199 35.67163719272396 139.74653817213402 41.743</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a8572d3d-fb57-4732-a317-3c43fa4fc7ed">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a8572d3d-fb57-4732-a317-3c43fa4fc7ed">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a8572d3d-fb57-4732-a317-3c43fa4fc7ed">
											<gml:posList>35.67170178668103 139.746552860252 42.2 35.67170178668103 139.746552860252 41.743 35.67170110443363 139.74658175848282 41.743 35.67170110443363 139.74658175848282 42.2 35.67170178668103 139.746552860252 42.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-37e1bde5-00ee-4e70-ab48-4d3e09136b2f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-37e1bde5-00ee-4e70-ab48-4d3e09136b2f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-37e1bde5-00ee-4e70-ab48-4d3e09136b2f">
											<gml:posList>35.671704079264394 139.7465821750287 12.3 35.6717047790298 139.74655256980554 12.3 35.6717047790298 139.74655256980554 42.2 35.671704079264394 139.7465821750287 42.2 35.671704079264394 139.7465821750287 12.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9948f54c-53a2-4b39-adaa-2142f7540356">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9948f54c-53a2-4b39-adaa-2142f7540356">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9948f54c-53a2-4b39-adaa-2142f7540356">
											<gml:posList>35.67167246770183 139.74666922202655 42.2 35.67167246770183 139.74666922202655 41.743 35.67147668306918 139.74649765092053 41.743 35.67147668306918 139.74649765092053 42.2 35.67167246770183 139.74666922202655 42.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-94bf00d0-39a5-48f6-885e-288b15a71c83">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-94bf00d0-39a5-48f6-885e-288b15a71c83">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-94bf00d0-39a5-48f6-885e-288b15a71c83">
											<gml:posList>35.67167313837441 139.74667430266314 41.046 35.67167313837441 139.74667430266314 42.2 35.67147252834852 139.74649849494767 42.2 35.67147252834852 139.74649849494767 41.046 35.67167313837441 139.74667430266314 41.046</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-50d4ea3c-3216-4de4-b91e-8e0afa83af68">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-50d4ea3c-3216-4de4-b91e-8e0afa83af68">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-50d4ea3c-3216-4de4-b91e-8e0afa83af68">
											<gml:posList>35.67170110443363 139.74658175848282 42.2 35.67170110443363 139.74658175848282 41.743 35.671696015431785 139.74661199809927 41.743 35.671696015431785 139.74661199809927 42.2 35.67170110443363 139.74658175848282 42.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d1bf3cce-3db9-4558-a3fc-ccc3861e5671">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d1bf3cce-3db9-4558-a3fc-ccc3861e5671">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d1bf3cce-3db9-4558-a3fc-ccc3861e5671">
											<gml:posList>35.671698873585264 139.74661311069832 12.3 35.671704079264394 139.7465821750287 12.3 35.671704079264394 139.7465821750287 42.2 35.671698873585264 139.74661311069832 42.2 35.671698873585264 139.74661311069832 12.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3f8d702c-4223-478e-b97e-bfde4dbf9375">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3f8d702c-4223-478e-b97e-bfde4dbf9375">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3f8d702c-4223-478e-b97e-bfde4dbf9375">
											<gml:posList>35.67166065135734 139.74669518287874 37.998 35.67166065135734 139.74669518287874 38.6 35.67146005080527 139.74651997163411 38.6 35.67146005080527 139.74651997163411 37.998 35.67166065135734 139.74669518287874 37.998</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-19261393-1a84-4d97-838c-0c09fe4297db">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-19261393-1a84-4d97-838c-0c09fe4297db">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-19261393-1a84-4d97-838c-0c09fe4297db">
											<gml:posList>35.671696015431785 139.74661199809927 42.2 35.671696015431785 139.74661199809927 41.743 35.671686032233595 139.74664260753647 41.743 35.671686032233595 139.74664260753647 42.2 35.671696015431785 139.74661199809927 42.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-afc97a67-813c-4413-bfde-e1ad9442a032">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-afc97a67-813c-4413-bfde-e1ad9442a032">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-afc97a67-813c-4413-bfde-e1ad9442a032">
											<gml:posList>35.671648299367654 139.74671581992038 34.273 35.671648299367654 139.74671581992038 35.2 35.67144797835019 139.74654071881247 35.2 35.67144797835019 139.74654071881247 34.273 35.671648299367654 139.74671581992038 34.273</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-07d08da6-e7c4-41ca-9783-6e73deddf312">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-07d08da6-e7c4-41ca-9783-6e73deddf312">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-07d08da6-e7c4-41ca-9783-6e73deddf312">
											<gml:posList>35.67168871051 139.74664427265296 12.3 35.671698873585264 139.74661311069832 12.3 35.671698873585264 139.74661311069832 42.2 35.67168871051 139.74664427265296 42.2 35.67168871051 139.74664427265296 12.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9c6b8542-2d40-41ab-b2a6-161804006d0c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9c6b8542-2d40-41ab-b2a6-161804006d0c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9c6b8542-2d40-41ab-b2a6-161804006d0c">
											<gml:posList>35.67163595638811 139.7467364569459 31.9 35.67143590589945 139.74656147703098 31.9 35.67143590589945 139.74656147703098 12.3 35.67163595638811 139.7467364569459 12.3 35.67163595638811 139.7467364569459 31.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-713e93a2-03fc-4d0c-9a1e-a0d150330775">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-713e93a2-03fc-4d0c-9a1e-a0d150330775">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-713e93a2-03fc-4d0c-9a1e-a0d150330775">
											<gml:posList>35.671686032233595 139.74664260753647 42.2 35.671686032233595 139.74664260753647 41.743 35.671674052224716 139.74666659126143 41.743 35.671674052224716 139.74666659126143 42.2 35.671686032233595 139.74664260753647 42.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f26eedc4-1871-44cf-8a95-c0885578b886">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f26eedc4-1871-44cf-8a95-c0885578b886">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f26eedc4-1871-44cf-8a95-c0885578b886">
											<gml:posList>35.67167655947857 139.74666858795652 12.3 35.67168871051 139.74664427265296 12.3 35.67168871051 139.74664427265296 42.2 35.67167655947857 139.74666858795652 42.2 35.67167655947857 139.74666858795652 12.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7d3941e9-6654-48cb-bbac-f2acf13a6c70">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7d3941e9-6654-48cb-bbac-f2acf13a6c70">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7d3941e9-6654-48cb-bbac-f2acf13a6c70">
											<gml:posList>35.671674052224716 139.74666659126143 42.2 35.671674052224716 139.74666659126143 41.743 35.67167246770183 139.74666922202655 41.743 35.67167246770183 139.74666922202655 42.2 35.671674052224716 139.74666659126143 42.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7686aad8-7fc5-4da1-8093-b18f4ff287f0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7686aad8-7fc5-4da1-8093-b18f4ff287f0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7686aad8-7fc5-4da1-8093-b18f4ff287f0">
											<gml:posList>35.67167313837441 139.74667430266314 41.046 35.67166065135734 139.74669518287874 38.6 35.67166065135734 139.74669518287874 37.998 35.671648299367654 139.74671581992038 35.2 35.671648299367654 139.74671581992038 34.273 35.67163595638811 139.7467364569459 31.9 35.67163595638811 139.7467364569459 12.3 35.67167655947857 139.74666858795652 12.3 35.67167655947857 139.74666858795652 42.2 35.67167313837441 139.74667430266314 42.2 35.67167313837441 139.74667430266314 41.046</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都千代田区霞が関三丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13101-bldg-3989</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13101</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">529.9885</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1210</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>7</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>