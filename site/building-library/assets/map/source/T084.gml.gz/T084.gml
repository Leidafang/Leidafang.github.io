<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_15bd0047-93ef-42da-a183-f4c30c171e47">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">412</bldg:usage>
			<bldg:measuredHeight uom="m">30.3</bldg:measuredHeight>
			<bldg:storeysAboveGround>11</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.67149606472529 139.73791317490245 0 35.671513096542405 139.73790796281665 0 35.67150621914717 139.7378739480462 0 35.6714791845538 139.73788226504286 0 35.67147203568856 139.73784692504316 0 35.67134326071366 139.73788629310292 0 35.67136298772699 139.73798358835444 0 35.671501765600304 139.73794122600833 0 35.67149606472529 139.73791317490245 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67149606472529 139.73791317490245 11.47 35.671501765600304 139.73794122600833 11.47 35.67136298772699 139.73798358835444 11.47 35.67134326071366 139.73788629310292 11.47 35.67147203568856 139.73784692504316 11.47 35.6714791845538 139.73788226504286 11.47 35.67150621914717 139.7378739480462 11.47 35.671513096542405 139.73790796281665 11.47 35.67149606472529 139.73791317490245 11.47</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67149606472529 139.73791317490245 11.47 35.671513096542405 139.73790796281665 11.47 35.671513096542405 139.73790796281665 41.81 35.67149606472529 139.73791317490245 41.81 35.67149606472529 139.73791317490245 11.47</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671513096542405 139.73790796281665 11.47 35.67150621914717 139.7378739480462 11.47 35.67150621914717 139.7378739480462 41.81 35.671513096542405 139.73790796281665 41.81 35.671513096542405 139.73790796281665 11.47</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67150621914717 139.7378739480462 11.47 35.6714791845538 139.73788226504286 11.47 35.6714791845538 139.73788226504286 41.81 35.67150621914717 139.7378739480462 41.81 35.67150621914717 139.7378739480462 11.47</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6714791845538 139.73788226504286 11.47 35.67147203568856 139.73784692504316 11.47 35.67147203568856 139.73784692504316 41.81 35.6714791845538 139.73788226504286 41.81 35.6714791845538 139.73788226504286 11.47</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67147203568856 139.73784692504316 11.47 35.67134326071366 139.73788629310292 11.47 35.67134326071366 139.73788629310292 41.81 35.67147203568856 139.73784692504316 41.81 35.67147203568856 139.73784692504316 11.47</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67134326071366 139.73788629310292 11.47 35.67136298772699 139.73798358835444 11.47 35.67136298772699 139.73798358835444 41.81 35.67134326071366 139.73788629310292 41.81 35.67134326071366 139.73788629310292 11.47</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67136298772699 139.73798358835444 11.47 35.671501765600304 139.73794122600833 11.47 35.671501765600304 139.73794122600833 41.81 35.67136298772699 139.73798358835444 41.81 35.67136298772699 139.73798358835444 11.47</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671501765600304 139.73794122600833 11.47 35.67149606472529 139.73791317490245 11.47 35.67149606472529 139.73791317490245 41.81 35.671501765600304 139.73794122600833 41.81 35.671501765600304 139.73794122600833 11.47</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67149606472529 139.73791317490245 41.81 35.671513096542405 139.73790796281665 41.81 35.67150621914717 139.7378739480462 41.81 35.6714791845538 139.73788226504286 41.81 35.67147203568856 139.73784692504316 41.81 35.67134326071366 139.73788629310292 41.81 35.67136298772699 139.73798358835444 41.81 35.671501765600304 139.73794122600833 41.81 35.67149606472529 139.73791317490245 41.81</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-b1a496eb-6f34-47cd-836d-9b3243e49daf"/>
							<gml:surfaceMember xlink:href="#poly-0728cf50-d03f-471b-a375-c3baa8ed20dc"/>
							<gml:surfaceMember xlink:href="#poly-7be23847-d044-4e5b-9559-260c4bc736dc"/>
							<gml:surfaceMember xlink:href="#poly-647c5d89-59eb-428b-ad10-2ce5949896bf"/>
							<gml:surfaceMember xlink:href="#poly-23deac2d-c4b9-4425-b6f5-39a0be87222f"/>
							<gml:surfaceMember xlink:href="#poly-d600d3c8-a17c-4f7b-aed0-455c9b6f088f"/>
							<gml:surfaceMember xlink:href="#poly-ad07e070-2c2c-423a-bf79-aa44e37ff761"/>
							<gml:surfaceMember xlink:href="#poly-a5a3e0d4-1212-42e1-9830-334438005779"/>
							<gml:surfaceMember xlink:href="#poly-dbd24fc8-a9d3-4812-bb35-f2e45c10c8ed"/>
							<gml:surfaceMember xlink:href="#poly-41b2d645-cc47-4d08-a01f-224f9eae640a"/>
							<gml:surfaceMember xlink:href="#poly-d4bcc408-a464-44c3-a066-ace5901d217f"/>
							<gml:surfaceMember xlink:href="#poly-25b5d876-84db-4c66-9ab8-2c979d1023ae"/>
							<gml:surfaceMember xlink:href="#poly-1bd6045c-9292-44cc-8f53-c7b792147fd4"/>
							<gml:surfaceMember xlink:href="#poly-6b7c5839-5a8f-4c4c-a5c8-8bc0790954e4"/>
							<gml:surfaceMember xlink:href="#poly-0e0a85bf-dc9a-47d5-915a-6dbe1ac48e7a"/>
							<gml:surfaceMember xlink:href="#poly-0ed7bc39-dc6a-4491-9dbe-184104cd7e56"/>
							<gml:surfaceMember xlink:href="#poly-d7e65169-6026-4a6d-91ca-67f09f71210e"/>
							<gml:surfaceMember xlink:href="#poly-b7e10b93-b820-4adb-9a4e-129e6f1e0b8b"/>
							<gml:surfaceMember xlink:href="#poly-4941bb28-f7e7-48ba-bd9a-a6a98d6a9927"/>
							<gml:surfaceMember xlink:href="#poly-e7c251b4-1066-456d-8a7a-46b9cafe062b"/>
							<gml:surfaceMember xlink:href="#poly-4fa2f1d6-43ab-492d-aa60-1eec79ddd218"/>
							<gml:surfaceMember xlink:href="#poly-4e7f0e4d-e584-4638-8d39-b97260616eb2"/>
							<gml:surfaceMember xlink:href="#poly-c264af9b-75ef-403e-8e34-2b6281d48402"/>
							<gml:surfaceMember xlink:href="#poly-f3e3fd66-4190-40e6-a925-4b05667bcb73"/>
							<gml:surfaceMember xlink:href="#poly-0cc9418b-520f-46d4-835a-b758bbd60497"/>
							<gml:surfaceMember xlink:href="#poly-0c7fee79-f3d8-46fd-b670-8b143f68a57c"/>
							<gml:surfaceMember xlink:href="#poly-402e80cb-2cc5-4758-91d6-b12cb4e00c41"/>
							<gml:surfaceMember xlink:href="#poly-8c26e89b-582a-4f8b-8213-09149de6e231"/>
							<gml:surfaceMember xlink:href="#poly-c29954a5-6da5-4757-acc7-2d089f768bd8"/>
							<gml:surfaceMember xlink:href="#poly-1f2adab8-d530-4ff8-8a49-0635d91df50a"/>
							<gml:surfaceMember xlink:href="#poly-6a43f705-b5fc-4b0d-985c-098c0f6263b1"/>
							<gml:surfaceMember xlink:href="#poly-8ff6ba66-da5f-42fe-bd3e-aa45ecd6c4fc"/>
							<gml:surfaceMember xlink:href="#poly-c0128f40-3a00-4fe7-8bf3-4d755b5b3e42"/>
							<gml:surfaceMember xlink:href="#poly-29ff95d3-28c0-4b4a-8d5f-d2cc5250f4ae"/>
							<gml:surfaceMember xlink:href="#poly-4c388748-f527-492b-8b2b-4a5e12f7581c"/>
							<gml:surfaceMember xlink:href="#poly-5d3f5f21-b305-4b77-a616-f07edf5e49d7"/>
							<gml:surfaceMember xlink:href="#poly-b320eea6-99f8-4cca-b383-e3dae21cd302"/>
							<gml:surfaceMember xlink:href="#poly-109e69a2-8bbd-4d39-8a62-dbe6ca3d1b96"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_15bd0047-93ef-42da-a183-f4c30c171e47_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a8ee6cbd-e228-4d65-a575-46429b569853">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67143048257333 139.7379039960691 42.407 35.67143509601877 139.73792474677194 42.407 35.67141065725051 139.73793290600563 42.407 35.67140604380647 139.73791215530863 42.407 35.67143048257333 139.7379039960691 42.407</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-120693a4-cd1a-4f7d-8337-9540c2e7ca0a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-120693a4-cd1a-4f7d-8337-9540c2e7ca0a_0">
											<gml:posList>35.67143509601877 139.73792474677194 42.407 35.67143509601877 139.73792474677194 43.357 35.67141065725051 139.73793290600563 43.357 35.67141065725051 139.73793290600563 42.407 35.67143509601877 139.73792474677194 42.407</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0d806fa1-95cc-4f57-a626-60d1572d7d31">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0d806fa1-95cc-4f57-a626-60d1572d7d31_0">
											<gml:posList>35.67140604380647 139.73791215530863 42.407 35.67140604380647 139.73791215530863 43.357 35.67143048257333 139.7379039960691 43.357 35.67143048257333 139.7379039960691 42.407 35.67140604380647 139.73791215530863 42.407</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ab7f594a-1879-4220-a3ce-fd2a44868d7c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ab7f594a-1879-4220-a3ce-fd2a44868d7c_0">
											<gml:posList>35.67143048257333 139.7379039960691 42.407 35.67143048257333 139.7379039960691 43.357 35.67143509601877 139.73792474677194 43.357 35.67143509601877 139.73792474677194 42.407 35.67143048257333 139.7379039960691 42.407</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-93fd22fa-b50e-434d-a520-ec64559542fa">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-93fd22fa-b50e-434d-a520-ec64559542fa_0">
											<gml:posList>35.67143048257333 139.7379039960691 43.357 35.67140604380647 139.73791215530863 43.357 35.67141065725051 139.73793290600563 43.357 35.67143509601877 139.73792474677194 43.357 35.67143048257333 139.7379039960691 43.357</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b3f55082-030d-416d-b652-a364d9a8824d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b3f55082-030d-416d-b652-a364d9a8824d_0">
											<gml:posList>35.67141065725051 139.73793290600563 42.407 35.67141065725051 139.73793290600563 43.357 35.67140604380647 139.73791215530863 43.357 35.67140604380647 139.73791215530863 42.407 35.67141065725051 139.73793290600563 42.407</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-b1a496eb-6f34-47cd-836d-9b3243e49daf">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b1a496eb-6f34-47cd-836d-9b3243e49daf">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b1a496eb-6f34-47cd-836d-9b3243e49daf">
											<gml:posList>35.6714791845538 139.73788226504286 11.47 35.67150621914717 139.7378739480462 11.47 35.67151309654237 139.73790796281665 11.47 35.671496064725275 139.73791317490242 11.47 35.67150176560029 139.7379412260083 11.47 35.67136298772695 139.73798358835444 11.47 35.67134326071366 139.7378862931029 11.47 35.67147203568855 139.73784692504316 11.47 35.6714791845538 139.73788226504286 11.47</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-0728cf50-d03f-471b-a375-c3baa8ed20dc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0728cf50-d03f-471b-a375-c3baa8ed20dc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0728cf50-d03f-471b-a375-c3baa8ed20dc">
											<gml:posList>35.6714791845538 139.73788226504286 42.759 35.67147203568855 139.73784692504316 42.759 35.671470271837464 139.7378505061805 42.759 35.67147681440068 139.73788284227797 42.759 35.6714791845538 139.73788226504286 42.759</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-7be23847-d044-4e5b-9559-260c4bc736dc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7be23847-d044-4e5b-9559-260c4bc736dc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7be23847-d044-4e5b-9559-260c4bc736dc">
											<gml:posList>35.67134326071366 139.7378862931029 42.759 35.67134617386161 139.73788845472774 42.759 35.671470271837464 139.7378505061805 42.759 35.67147203568855 139.73784692504316 42.759 35.67134326071366 139.7378862931029 42.759</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-647c5d89-59eb-428b-ad10-2ce5949896bf">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-647c5d89-59eb-428b-ad10-2ce5949896bf">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-647c5d89-59eb-428b-ad10-2ce5949896bf">
											<gml:posList>35.67150610436827 139.73787697490036 39.655 35.67150621914717 139.7378739480462 39.374 35.6714791845538 139.73788226504286 42.759 35.67150610436827 139.73787697490036 39.655</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-23deac2d-c4b9-4425-b6f5-39a0be87222f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-23deac2d-c4b9-4425-b6f5-39a0be87222f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-23deac2d-c4b9-4425-b6f5-39a0be87222f">
											<gml:posList>35.6714791845538 139.73788226504286 42.759 35.67148074580131 139.73788462711605 42.542 35.67150610436827 139.73787697490036 39.655 35.6714791845538 139.73788226504286 42.759</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d600d3c8-a17c-4f7b-aed0-455c9b6f088f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d600d3c8-a17c-4f7b-aed0-455c9b6f088f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d600d3c8-a17c-4f7b-aed0-455c9b6f088f">
											<gml:posList>35.67150621914717 139.7378739480462 39.374 35.67150610436827 139.73787697490036 39.655 35.67151075125924 139.73790580051076 39.527 35.67150621914717 139.7378739480462 39.374</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ad07e070-2c2c-423a-bf79-aa44e37ff761">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ad07e070-2c2c-423a-bf79-aa44e37ff761">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ad07e070-2c2c-423a-bf79-aa44e37ff761">
											<gml:posList>35.67151075125924 139.73790580051076 39.527 35.67151309654237 139.73790796281665 39.374 35.67150621914717 139.7378739480462 39.374 35.67151075125924 139.73790580051076 39.527</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a5a3e0d4-1212-42e1-9830-334438005779">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a5a3e0d4-1212-42e1-9830-334438005779">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a5a3e0d4-1212-42e1-9830-334438005779">
											<gml:posList>35.67151075125924 139.73790580051076 38.596 35.67150610436827 139.73787697490036 38.724 35.67148074580131 139.73788462711605 41.611 35.67148435701423 139.7379145917307 41.611 35.67151075125924 139.73790580051076 38.596</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-dbd24fc8-a9d3-4812-bb35-f2e45c10c8ed">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-dbd24fc8-a9d3-4812-bb35-f2e45c10c8ed">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-dbd24fc8-a9d3-4812-bb35-f2e45c10c8ed">
											<gml:posList>35.6714791845538 139.73788226504286 42.759 35.67148346721192 139.73791781834177 42.759 35.67148435701423 139.7379145917307 42.542 35.67148074580131 139.73788462711605 42.542 35.6714791845538 139.73788226504286 42.759</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-41b2d645-cc47-4d08-a01f-224f9eae640a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-41b2d645-cc47-4d08-a01f-224f9eae640a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-41b2d645-cc47-4d08-a01f-224f9eae640a">
											<gml:posList>35.67148346721192 139.73791781834177 42.759 35.6714791845538 139.73788226504286 42.759 35.67147681440068 139.73788284227797 42.759 35.671481097058624 139.73791839557586 42.759 35.67148346721192 139.73791781834177 42.759</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d4bcc408-a464-44c3-a066-ace5901d217f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d4bcc408-a464-44c3-a066-ace5901d217f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d4bcc408-a464-44c3-a066-ace5901d217f">
											<gml:posList>35.67151309654237 139.73790796281665 39.374 35.67151075125924 139.73790580051076 39.527 35.67148435701423 139.7379145917307 42.542 35.67148346721192 139.73791781834177 42.759 35.67151309654237 139.73790796281665 39.374</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-25b5d876-84db-4c66-9ab8-2c979d1023ae">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-25b5d876-84db-4c66-9ab8-2c979d1023ae">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-25b5d876-84db-4c66-9ab8-2c979d1023ae">
											<gml:posList>35.67136474257706 139.73798001828192 42.407 35.671486092105724 139.73794296789697 42.407 35.671481097058624 139.73791839557586 42.407 35.67147681440068 139.73788284227797 42.407 35.671470271837464 139.7378505061805 42.407 35.67134617386161 139.73788845472774 42.407 35.67136474257706 139.73798001828192 42.407</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-1bd6045c-9292-44cc-8f53-c7b792147fd4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1bd6045c-9292-44cc-8f53-c7b792147fd4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1bd6045c-9292-44cc-8f53-c7b792147fd4">
											<gml:posList>35.67148346721192 139.73791781834177 18.619 35.67148901425755 139.73794511847058 18.619 35.67150176560029 139.7379412260083 18.619 35.671496064725275 139.73791317490242 18.619 35.67148346721192 139.73791781834177 18.619</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-6b7c5839-5a8f-4c4c-a5c8-8bc0790954e4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6b7c5839-5a8f-4c4c-a5c8-8bc0790954e4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6b7c5839-5a8f-4c4c-a5c8-8bc0790954e4">
											<gml:posList>35.67148346721192 139.73791781834177 42.759 35.671481097058624 139.73791839557586 42.759 35.671486092105724 139.73794296789697 42.759 35.67148901425755 139.73794511847058 42.759 35.67148346721192 139.73791781834177 42.759</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-0e0a85bf-dc9a-47d5-915a-6dbe1ac48e7a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0e0a85bf-dc9a-47d5-915a-6dbe1ac48e7a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0e0a85bf-dc9a-47d5-915a-6dbe1ac48e7a">
											<gml:posList>35.67136298772695 139.73798358835444 42.759 35.67136474257706 139.73798001828192 42.759 35.67134617386161 139.73788845472774 42.759 35.67134326071366 139.7378862931029 42.759 35.67136298772695 139.73798358835444 42.759</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-0ed7bc39-dc6a-4491-9dbe-184104cd7e56">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0ed7bc39-dc6a-4491-9dbe-184104cd7e56">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0ed7bc39-dc6a-4491-9dbe-184104cd7e56">
											<gml:posList>35.67148901425755 139.73794511847058 42.759 35.671486092105724 139.73794296789697 42.759 35.67136474257706 139.73798001828192 42.759 35.67136298772695 139.73798358835444 42.759 35.67148901425755 139.73794511847058 42.759</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d7e65169-6026-4a6d-91ca-67f09f71210e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d7e65169-6026-4a6d-91ca-67f09f71210e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d7e65169-6026-4a6d-91ca-67f09f71210e">
											<gml:posList>35.67147203568855 139.73784692504316 11.47 35.67134326071366 139.7378862931029 11.47 35.67134326071366 139.7378862931029 42.759 35.67147203568855 139.73784692504316 42.759 35.67147203568855 139.73784692504316 11.47</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b7e10b93-b820-4adb-9a4e-129e6f1e0b8b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b7e10b93-b820-4adb-9a4e-129e6f1e0b8b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b7e10b93-b820-4adb-9a4e-129e6f1e0b8b">
											<gml:posList>35.67134617386161 139.73788845472774 42.759 35.67134617386161 139.73788845472774 42.407 35.671470271837464 139.7378505061805 42.407 35.671470271837464 139.7378505061805 42.759 35.67134617386161 139.73788845472774 42.759</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4941bb28-f7e7-48ba-bd9a-a6a98d6a9927">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4941bb28-f7e7-48ba-bd9a-a6a98d6a9927">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4941bb28-f7e7-48ba-bd9a-a6a98d6a9927">
											<gml:posList>35.671470271837464 139.7378505061805 42.759 35.671470271837464 139.7378505061805 42.407 35.67147681440068 139.73788284227797 42.407 35.67147681440068 139.73788284227797 42.759 35.671470271837464 139.7378505061805 42.759</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e7c251b4-1066-456d-8a7a-46b9cafe062b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e7c251b4-1066-456d-8a7a-46b9cafe062b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e7c251b4-1066-456d-8a7a-46b9cafe062b">
											<gml:posList>35.6714791845538 139.73788226504286 11.47 35.67147203568855 139.73784692504316 11.47 35.67147203568855 139.73784692504316 42.759 35.6714791845538 139.73788226504286 42.759 35.6714791845538 139.73788226504286 11.47</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4fa2f1d6-43ab-492d-aa60-1eec79ddd218">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4fa2f1d6-43ab-492d-aa60-1eec79ddd218">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4fa2f1d6-43ab-492d-aa60-1eec79ddd218">
											<gml:posList>35.67150621914717 139.7378739480462 39.374 35.67150621914717 139.7378739480462 11.47 35.6714791845538 139.73788226504286 11.47 35.6714791845538 139.73788226504286 42.759 35.67150621914717 139.7378739480462 39.374</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4e7f0e4d-e584-4638-8d39-b97260616eb2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4e7f0e4d-e584-4638-8d39-b97260616eb2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4e7f0e4d-e584-4638-8d39-b97260616eb2">
											<gml:posList>35.67150610436827 139.73787697490036 39.655 35.67148074580131 139.73788462711605 42.542 35.67148074580131 139.73788462711605 41.611 35.67150610436827 139.73787697490036 38.724 35.67150610436827 139.73787697490036 39.655</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c264af9b-75ef-403e-8e34-2b6281d48402">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c264af9b-75ef-403e-8e34-2b6281d48402">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c264af9b-75ef-403e-8e34-2b6281d48402">
											<gml:posList>35.67151075125924 139.73790580051076 39.527 35.67150610436827 139.73787697490036 39.655 35.67150610436827 139.73787697490036 38.724 35.67151075125924 139.73790580051076 38.596 35.67151075125924 139.73790580051076 39.527</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f3e3fd66-4190-40e6-a925-4b05667bcb73">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f3e3fd66-4190-40e6-a925-4b05667bcb73">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f3e3fd66-4190-40e6-a925-4b05667bcb73">
											<gml:posList>35.67151309654237 139.73790796281665 11.47 35.67150621914717 139.7378739480462 11.47 35.67150621914717 139.7378739480462 39.374 35.67151309654237 139.73790796281665 39.374 35.67151309654237 139.73790796281665 11.47</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0cc9418b-520f-46d4-835a-b758bbd60497">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0cc9418b-520f-46d4-835a-b758bbd60497">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0cc9418b-520f-46d4-835a-b758bbd60497">
											<gml:posList>35.67134326071366 139.7378862931029 11.47 35.67136298772695 139.73798358835444 11.47 35.67136298772695 139.73798358835444 42.759 35.67134326071366 139.7378862931029 42.759 35.67134326071366 139.7378862931029 11.47</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0c7fee79-f3d8-46fd-b670-8b143f68a57c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0c7fee79-f3d8-46fd-b670-8b143f68a57c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0c7fee79-f3d8-46fd-b670-8b143f68a57c">
											<gml:posList>35.67136474257706 139.73798001828192 42.759 35.67136474257706 139.73798001828192 42.407 35.67134617386161 139.73788845472774 42.407 35.67134617386161 139.73788845472774 42.759 35.67136474257706 139.73798001828192 42.759</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-402e80cb-2cc5-4758-91d6-b12cb4e00c41">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-402e80cb-2cc5-4758-91d6-b12cb4e00c41">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-402e80cb-2cc5-4758-91d6-b12cb4e00c41">
											<gml:posList>35.671486092105724 139.73794296789697 42.759 35.671486092105724 139.73794296789697 42.407 35.67136474257706 139.73798001828192 42.407 35.67136474257706 139.73798001828192 42.759 35.671486092105724 139.73794296789697 42.759</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8c26e89b-582a-4f8b-8213-09149de6e231">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8c26e89b-582a-4f8b-8213-09149de6e231">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8c26e89b-582a-4f8b-8213-09149de6e231">
											<gml:posList>35.67148901425755 139.73794511847058 18.619 35.67148901425755 139.73794511847058 42.759 35.67136298772695 139.73798358835444 42.759 35.67136298772695 139.73798358835444 11.47 35.67150176560029 139.7379412260083 11.47 35.67150176560029 139.7379412260083 18.619 35.67148901425755 139.73794511847058 18.619</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c29954a5-6da5-4757-acc7-2d089f768bd8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c29954a5-6da5-4757-acc7-2d089f768bd8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c29954a5-6da5-4757-acc7-2d089f768bd8">
											<gml:posList>35.67147681440068 139.73788284227797 42.759 35.67147681440068 139.73788284227797 42.407 35.671481097058624 139.73791839557586 42.407 35.671481097058624 139.73791839557586 42.759 35.67147681440068 139.73788284227797 42.759</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1f2adab8-d530-4ff8-8a49-0635d91df50a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1f2adab8-d530-4ff8-8a49-0635d91df50a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1f2adab8-d530-4ff8-8a49-0635d91df50a">
											<gml:posList>35.67148435701423 139.7379145917307 42.542 35.67148435701423 139.7379145917307 41.611 35.67148074580131 139.73788462711605 41.611 35.67148074580131 139.73788462711605 42.542 35.67148435701423 139.7379145917307 42.542</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6a43f705-b5fc-4b0d-985c-098c0f6263b1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6a43f705-b5fc-4b0d-985c-098c0f6263b1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6a43f705-b5fc-4b0d-985c-098c0f6263b1">
											<gml:posList>35.671481097058624 139.73791839557586 42.759 35.671481097058624 139.73791839557586 42.407 35.671486092105724 139.73794296789697 42.407 35.671486092105724 139.73794296789697 42.759 35.671481097058624 139.73791839557586 42.759</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8ff6ba66-da5f-42fe-bd3e-aa45ecd6c4fc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8ff6ba66-da5f-42fe-bd3e-aa45ecd6c4fc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8ff6ba66-da5f-42fe-bd3e-aa45ecd6c4fc">
											<gml:posList>35.67148346721192 139.73791781834177 18.619 35.67148346721192 139.73791781834177 42.759 35.67148901425755 139.73794511847058 42.759 35.67148901425755 139.73794511847058 18.619 35.67148346721192 139.73791781834177 18.619</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c0128f40-3a00-4fe7-8bf3-4d755b5b3e42">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c0128f40-3a00-4fe7-8bf3-4d755b5b3e42">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c0128f40-3a00-4fe7-8bf3-4d755b5b3e42">
											<gml:posList>35.671496064725275 139.73791317490242 18.619 35.67148346721192 139.73791781834177 42.759 35.67148346721192 139.73791781834177 18.619 35.671496064725275 139.73791317490242 18.619</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-29ff95d3-28c0-4b4a-8d5f-d2cc5250f4ae">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-29ff95d3-28c0-4b4a-8d5f-d2cc5250f4ae">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-29ff95d3-28c0-4b4a-8d5f-d2cc5250f4ae">
											<gml:posList>35.67151075125924 139.73790580051076 39.527 35.67151075125924 139.73790580051076 38.596 35.67148435701423 139.7379145917307 41.611 35.67148435701423 139.7379145917307 42.542 35.67151075125924 139.73790580051076 39.527</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4c388748-f527-492b-8b2b-4a5e12f7581c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4c388748-f527-492b-8b2b-4a5e12f7581c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4c388748-f527-492b-8b2b-4a5e12f7581c">
											<gml:posList>35.67151309654237 139.73790796281665 11.47 35.67151309654237 139.73790796281665 39.374 35.67148346721192 139.73791781834177 42.759 35.67151309654237 139.73790796281665 11.47</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5d3f5f21-b305-4b77-a616-f07edf5e49d7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5d3f5f21-b305-4b77-a616-f07edf5e49d7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5d3f5f21-b305-4b77-a616-f07edf5e49d7">
											<gml:posList>35.671496064725275 139.73791317490242 18.619 35.67151309654237 139.73790796281665 11.47 35.67148346721192 139.73791781834177 42.759 35.671496064725275 139.73791317490242 18.619</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b320eea6-99f8-4cca-b383-e3dae21cd302">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b320eea6-99f8-4cca-b383-e3dae21cd302">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b320eea6-99f8-4cca-b383-e3dae21cd302">
											<gml:posList>35.67150176560029 139.7379412260083 11.47 35.671496064725275 139.73791317490242 11.47 35.671496064725275 139.73791317490242 18.619 35.67150176560029 139.7379412260083 18.619 35.67150176560029 139.7379412260083 11.47</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-109e69a2-8bbd-4d39-8a62-dbe6ca3d1b96">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-109e69a2-8bbd-4d39-8a62-dbe6ca3d1b96">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-109e69a2-8bbd-4d39-8a62-dbe6ca3d1b96">
											<gml:posList>35.671496064725275 139.73791317490242 18.619 35.671496064725275 139.73791317490242 11.47 35.67151309654237 139.73790796281665 11.47 35.671496064725275 139.73791317490242 18.619</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-2768</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">146.4515</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">211</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1320</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>4</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.01</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>