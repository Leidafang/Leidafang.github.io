<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_15bedadf-45d0-48fa-9bca-d24f6f9f760d">
			<core:creationDate>2024-03-15</core:creationDate>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.67128213040909 139.73789868259527 0 35.6713276474085 139.73788436752577 0 35.671315731212424 139.7378274707208 0 35.671270223233485 139.7378417858097 0 35.67128213040909 139.73789868259527 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67128213040909 139.73789868259527 14.723 35.671270223233485 139.7378417858097 14.723 35.671315731212424 139.7378274707208 14.723 35.6713276474085 139.73788436752577 14.723 35.67128213040909 139.73789868259527 14.723</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67128213040909 139.73789868259527 14.723 35.6713276474085 139.73788436752577 14.723 35.6713276474085 139.73788436752577 17.723 35.67128213040909 139.73789868259527 17.723 35.67128213040909 139.73789868259527 14.723</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6713276474085 139.73788436752577 14.723 35.671315731212424 139.7378274707208 14.723 35.671315731212424 139.7378274707208 17.723 35.6713276474085 139.73788436752577 17.723 35.6713276474085 139.73788436752577 14.723</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671315731212424 139.7378274707208 14.723 35.671270223233485 139.7378417858097 14.723 35.671270223233485 139.7378417858097 17.723 35.671315731212424 139.7378274707208 17.723 35.671315731212424 139.7378274707208 14.723</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671270223233485 139.7378417858097 14.723 35.67128213040909 139.73789868259527 14.723 35.67128213040909 139.73789868259527 17.723 35.671270223233485 139.7378417858097 17.723 35.671270223233485 139.7378417858097 14.723</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67128213040909 139.73789868259527 17.723 35.6713276474085 139.73788436752577 17.723 35.671315731212424 139.7378274707208 17.723 35.671270223233485 139.7378417858097 17.723 35.67128213040909 139.73789868259527 17.723</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-19bf4a86-a669-412e-bfa2-4b8612f53390"/>
							<gml:surfaceMember xlink:href="#poly-cea0fa95-7382-4151-ac48-eb7bd39aab36"/>
							<gml:surfaceMember xlink:href="#poly-daf0ed0c-494e-409c-8d7b-1c79c8c455f9"/>
							<gml:surfaceMember xlink:href="#poly-a6c19699-deeb-4294-ab44-ddbccb526d3c"/>
							<gml:surfaceMember xlink:href="#poly-25ad7984-c14b-49ee-bf35-5d5d73068868"/>
							<gml:surfaceMember xlink:href="#poly-d23b2d7f-49bb-419a-bd22-0bd22385b848"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-19bf4a86-a669-412e-bfa2-4b8612f53390">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-19bf4a86-a669-412e-bfa2-4b8612f53390">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-19bf4a86-a669-412e-bfa2-4b8612f53390">
											<gml:posList>35.67128213040909 139.73789868259527 14.723 35.67127022323345 139.7378417858097 14.723 35.67131573121241 139.7378274707208 14.723 35.67132764740849 139.73788436752577 14.723 35.67128213040909 139.73789868259527 14.723</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-cea0fa95-7382-4151-ac48-eb7bd39aab36">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cea0fa95-7382-4151-ac48-eb7bd39aab36">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cea0fa95-7382-4151-ac48-eb7bd39aab36">
											<gml:posList>35.67127022323345 139.7378417858097 17.362 35.67128213040909 139.73789868259527 17.362 35.67132764740849 139.73788436752577 17.362 35.67131573121241 139.7378274707208 17.362 35.67127022323345 139.7378417858097 17.362</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-daf0ed0c-494e-409c-8d7b-1c79c8c455f9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-daf0ed0c-494e-409c-8d7b-1c79c8c455f9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-daf0ed0c-494e-409c-8d7b-1c79c8c455f9">
											<gml:posList>35.67127022323345 139.7378417858097 14.723 35.67128213040909 139.73789868259527 14.723 35.67128213040909 139.73789868259527 17.362 35.67127022323345 139.7378417858097 17.362 35.67127022323345 139.7378417858097 14.723</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a6c19699-deeb-4294-ab44-ddbccb526d3c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a6c19699-deeb-4294-ab44-ddbccb526d3c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a6c19699-deeb-4294-ab44-ddbccb526d3c">
											<gml:posList>35.67131573121241 139.7378274707208 14.723 35.67127022323345 139.7378417858097 14.723 35.67127022323345 139.7378417858097 17.362 35.67131573121241 139.7378274707208 17.362 35.67131573121241 139.7378274707208 14.723</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-25ad7984-c14b-49ee-bf35-5d5d73068868">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-25ad7984-c14b-49ee-bf35-5d5d73068868">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-25ad7984-c14b-49ee-bf35-5d5d73068868">
											<gml:posList>35.67128213040909 139.73789868259527 14.723 35.67132764740849 139.73788436752577 14.723 35.67132764740849 139.73788436752577 17.362 35.67128213040909 139.73789868259527 17.362 35.67128213040909 139.73789868259527 14.723</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d23b2d7f-49bb-419a-bd22-0bd22385b848">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d23b2d7f-49bb-419a-bd22-0bd22385b848">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d23b2d7f-49bb-419a-bd22-0bd22385b848">
											<gml:posList>35.67132764740849 139.73788436752577 14.723 35.67131573121241 139.7378274707208 14.723 35.67131573121241 139.7378274707208 17.362 35.67132764740849 139.73788436752577 17.362 35.67132764740849 139.73788436752577 14.723</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-6352</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">211</uro:landUseType>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>4</uro:specifiedFloorAreaRate>
					<uro:surveyYear>0001</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.01</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">0</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>