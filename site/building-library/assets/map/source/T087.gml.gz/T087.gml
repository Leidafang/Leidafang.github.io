<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_161579f9-4437-4e85-bf72-df142f7358bd">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">401</bldg:usage>
			<bldg:measuredHeight uom="m">16.6</bldg:measuredHeight>
			<bldg:storeysAboveGround>5</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.67200469704254 139.7383535451434 0 35.67196791258963 139.73822865305564 0 35.67185816394892 139.73827749814532 0 35.67188981514689 139.73840825079054 0 35.67200469704254 139.7383535451434 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67200469704254 139.7383535451434 9.884 35.67188981514689 139.73840825079054 9.884 35.67185816394892 139.73827749814532 9.884 35.67196791258963 139.73822865305564 9.884 35.67200469704254 139.7383535451434 9.884</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67200469704254 139.7383535451434 9.884 35.67196791258963 139.73822865305564 9.884 35.67196791258963 139.73822865305564 26.46 35.67200469704254 139.7383535451434 26.46 35.67200469704254 139.7383535451434 9.884</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67196791258963 139.73822865305564 9.884 35.67185816394892 139.73827749814532 9.884 35.67185816394892 139.73827749814532 26.46 35.67196791258963 139.73822865305564 26.46 35.67196791258963 139.73822865305564 9.884</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67185816394892 139.73827749814532 9.884 35.67188981514689 139.73840825079054 9.884 35.67188981514689 139.73840825079054 26.46 35.67185816394892 139.73827749814532 26.46 35.67185816394892 139.73827749814532 9.884</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67188981514689 139.73840825079054 9.884 35.67200469704254 139.7383535451434 9.884 35.67200469704254 139.7383535451434 26.46 35.67188981514689 139.73840825079054 26.46 35.67188981514689 139.73840825079054 9.884</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67200469704254 139.7383535451434 26.46 35.67196791258963 139.73822865305564 26.46 35.67185816394892 139.73827749814532 26.46 35.67188981514689 139.73840825079054 26.46 35.67200469704254 139.7383535451434 26.46</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-8da7c9dc-52e1-4de1-afe3-2f3bfa47c347"/>
							<gml:surfaceMember xlink:href="#poly-9566c76d-3b6e-4853-abfc-e2aa54cf6554"/>
							<gml:surfaceMember xlink:href="#poly-7b8f7887-c74c-4c18-89ff-0897131ea802"/>
							<gml:surfaceMember xlink:href="#poly-77b6b0e4-717c-4c95-8ccc-6ab005753520"/>
							<gml:surfaceMember xlink:href="#poly-494207e4-eade-4840-806d-2bf686534898"/>
							<gml:surfaceMember xlink:href="#poly-57c81410-7c44-48fa-adbf-04eecfd0b0aa"/>
							<gml:surfaceMember xlink:href="#poly-1f948c9d-3af4-4d27-9fcd-56173aca53b9"/>
							<gml:surfaceMember xlink:href="#poly-ad359650-87db-4d9a-b824-ab20a46e9fd8"/>
							<gml:surfaceMember xlink:href="#poly-0a2e3381-9161-4dc8-b6f7-751396d496cb"/>
							<gml:surfaceMember xlink:href="#poly-9674517b-9a9e-4380-911e-f445384859ad"/>
							<gml:surfaceMember xlink:href="#poly-e47a81af-106d-4802-aa70-05cbe301fb0a"/>
							<gml:surfaceMember xlink:href="#poly-09942ddc-954e-42d2-8527-ddf8ad85be41"/>
							<gml:surfaceMember xlink:href="#poly-ce45805c-a586-4a51-b0c3-ee170e1be96d"/>
							<gml:surfaceMember xlink:href="#poly-026aa18c-b5a9-418b-991c-8f1e650f9751"/>
							<gml:surfaceMember xlink:href="#poly-2d177e9c-0043-4f37-be47-d4c20ef39b59"/>
							<gml:surfaceMember xlink:href="#poly-41795c52-abab-47b7-85aa-0aa4722ace2b"/>
							<gml:surfaceMember xlink:href="#poly-f0c99205-2e51-4b7e-bbe4-ac892b3dacc4"/>
							<gml:surfaceMember xlink:href="#poly-d9f83734-6007-4a34-8d2e-74f25ebc0b01"/>
							<gml:surfaceMember xlink:href="#poly-9211040a-eeeb-4396-a0f1-1295d1cf0596"/>
							<gml:surfaceMember xlink:href="#poly-66031690-a7da-489e-aa59-0ef8b990eaf0"/>
							<gml:surfaceMember xlink:href="#poly-c6587e13-d69e-4188-89f4-79b47955f050"/>
							<gml:surfaceMember xlink:href="#poly-9e26eb53-2a2f-4c64-9162-93f023756a9e"/>
							<gml:surfaceMember xlink:href="#poly-572d6460-eb22-4937-b6e3-2728e7fffbf4"/>
							<gml:surfaceMember xlink:href="#poly-c8a471f9-50df-49db-b6c5-0fe1d482b0aa"/>
							<gml:surfaceMember xlink:href="#poly-de42651f-2613-4f4f-8b5b-08128c9eb81e"/>
							<gml:surfaceMember xlink:href="#poly-2115c619-ce74-467e-8d03-16f0f72f8250"/>
							<gml:surfaceMember xlink:href="#poly-ece85d69-13a8-4219-9ea3-26bb18eb1d80"/>
							<gml:surfaceMember xlink:href="#poly-f6c27a70-c298-4329-8167-aa1dbd7b7a27"/>
							<gml:surfaceMember xlink:href="#poly-bc7c8a84-ab6c-48dc-b9ba-abf6f867e716"/>
							<gml:surfaceMember xlink:href="#poly-e60caf26-815c-443c-a8bb-4b95a812923f"/>
							<gml:surfaceMember xlink:href="#poly-f697b0fa-e807-4a75-b513-635eb2f59af5"/>
							<gml:surfaceMember xlink:href="#poly-774bf8f9-6111-4d63-bce1-df82b825f26b"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_161579f9-4437-4e85-bf72-df142f7358bd_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-06dd90b9-302f-4177-9a07-00da124e6fd3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-06dd90b9-302f-4177-9a07-00da124e6fd3_0">
											<gml:posList>35.67189178366459 139.7383555678563 25.739 35.67189400691215 139.7383630105418 27.555 35.67189178366459 139.7383555678563 27.555 35.67189178366459 139.7383555678563 25.739</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-19df02b8-2572-47e4-a289-62c6e0f44c00">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-19df02b8-2572-47e4-a289-62c6e0f44c00_0">
											<gml:posList>35.67189178366459 139.7383555678563 25.739 35.67189400691215 139.7383630105418 25.739 35.67189400691215 139.7383630105418 27.555 35.67189178366459 139.7383555678563 25.739</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1eb333b6-a18a-47f2-b55f-fc90eb9689c6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1eb333b6-a18a-47f2-b55f-fc90eb9689c6_0">
											<gml:posList>35.67189178366459 139.7383555678563 25.739 35.67190001028927 139.7383518796365 27.555 35.67190001028927 139.7383518796365 25.739 35.67189178366459 139.7383555678563 25.739</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-57d8ecc5-e6bc-44e0-a299-5895998fb426">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-57d8ecc5-e6bc-44e0-a299-5895998fb426_0">
											<gml:posList>35.67189178366459 139.7383555678563 25.739 35.67189178366459 139.7383555678563 27.555 35.67190001028927 139.7383518796365 27.555 35.67189178366459 139.7383555678563 25.739</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1d04c732-b288-4a88-8376-61e5130bd8a1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1d04c732-b288-4a88-8376-61e5130bd8a1_0">
											<gml:posList>35.67189178366459 139.7383555678563 27.555 35.67189400691215 139.7383630105418 27.555 35.67190223352835 139.73835931127618 27.555 35.67189178366459 139.7383555678563 27.555</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ec7f01d0-a7db-4305-96f9-ccabfc8eb5e5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ec7f01d0-a7db-4305-96f9-ccabfc8eb5e5_0">
											<gml:posList>35.67190001028927 139.7383518796365 27.555 35.67189178366459 139.7383555678563 27.555 35.67190223352835 139.73835931127618 27.555 35.67190001028927 139.7383518796365 27.555</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2743e2a7-0602-4892-871c-c338607009b2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2743e2a7-0602-4892-871c-c338607009b2_0">
											<gml:posList>35.67190223352835 139.73835931127618 25.739 35.67189400691215 139.7383630105418 27.555 35.67189400691215 139.7383630105418 25.739 35.67190223352835 139.73835931127618 25.739</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6fce4bfb-8021-4de5-b544-c15ddca5167b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6fce4bfb-8021-4de5-b544-c15ddca5167b_0">
											<gml:posList>35.67190223352835 139.73835931127618 25.739 35.67190223352835 139.73835931127618 27.555 35.67189400691215 139.7383630105418 27.555 35.67190223352835 139.73835931127618 25.739</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-312a51e0-a737-46d3-9d02-3ed4b533eeae">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-312a51e0-a737-46d3-9d02-3ed4b533eeae_0">
											<gml:posList>35.67190223352835 139.73835931127618 25.739 35.67190001028927 139.7383518796365 27.555 35.67190223352835 139.73835931127618 27.555 35.67190223352835 139.73835931127618 25.739</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f8bfda37-7475-4ea7-8a10-2d1a4359788d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f8bfda37-7475-4ea7-8a10-2d1a4359788d_0">
											<gml:posList>35.67190223352835 139.73835931127618 25.739 35.67190001028927 139.7383518796365 25.739 35.67190001028927 139.7383518796365 27.555 35.67190223352835 139.73835931127618 25.739</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-32ae94f2-e7b1-4a52-b19b-b0ca64d81dc6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-32ae94f2-e7b1-4a52-b19b-b0ca64d81dc6_0">
											<gml:posList>35.67193219331172 139.73829984576037 25.739 35.67193075162221 139.7383004881647 30.299 35.67193219331172 139.73829984576037 30.299 35.67193219331172 139.73829984576037 25.739</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-72484b19-e866-40a7-8964-02cb6b15ac52">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-72484b19-e866-40a7-8964-02cb6b15ac52_0">
											<gml:posList>35.67193219331172 139.73829984576037 25.739 35.67193075162221 139.7383004881647 25.739 35.67193075162221 139.7383004881647 30.299 35.67193219331172 139.73829984576037 25.739</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-550183dc-84e9-4c70-a3ad-4e4ee6e98a78">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-550183dc-84e9-4c70-a3ad-4e4ee6e98a78_0">
											<gml:posList>35.67193075162221 139.7383004881647 25.739 35.67194867358085 139.73836099055927 30.299 35.67193075162221 139.7383004881647 30.299 35.67193075162221 139.7383004881647 25.739</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2ed126fb-90ab-497b-a406-89a700ce23b9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2ed126fb-90ab-497b-a406-89a700ce23b9_0">
											<gml:posList>35.67193075162221 139.7383004881647 25.739 35.67194867358085 139.73836099055927 25.739 35.67194867358085 139.73836099055927 30.299 35.67193075162221 139.7383004881647 25.739</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a0383130-8110-4c7b-b290-d0d6d99043ff">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a0383130-8110-4c7b-b290-d0d6d99043ff_0">
											<gml:posList>35.67193219331172 139.73829984576037 25.739 35.67194959104602 139.73835853715488 30.299 35.67194959104602 139.73835853715488 25.739 35.67193219331172 139.73829984576037 25.739</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-dc205b6b-8686-4ef1-a6d6-3e96e644d56e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-dc205b6b-8686-4ef1-a6d6-3e96e644d56e_0">
											<gml:posList>35.67193219331172 139.73829984576037 25.739 35.67193219331172 139.73829984576037 30.299 35.67194959104602 139.73835853715488 30.299 35.67193219331172 139.73829984576037 25.739</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6d3a7f3d-d2d2-4c94-bbdb-150bd8285651">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6d3a7f3d-d2d2-4c94-bbdb-150bd8285651_0">
											<gml:posList>35.67199404016263 139.7383387554832 25.739 35.67194959104602 139.73835853715488 25.739 35.67199404016263 139.7383387554832 26.169 35.67199404016263 139.7383387554832 25.739</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bbb4f231-684c-479e-9bed-e3c6f0b11373">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bbb4f231-684c-479e-9bed-e3c6f0b11373_0">
											<gml:posList>35.671995454819886 139.73833812415754 26.169 35.67199404016263 139.7383387554832 26.169 35.671995454819886 139.73833812415754 30.299 35.671995454819886 139.73833812415754 26.169</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0ecee6d5-5ce0-408b-8ea4-d73a44cf5b74">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0ecee6d5-5ce0-408b-8ea4-d73a44cf5b74_0">
											<gml:posList>35.671995454819886 139.73833812415754 30.299 35.67199404016263 139.7383387554832 26.169 35.67194959104602 139.73835853715488 30.299 35.671995454819886 139.73833812415754 30.299</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-09175c88-cdac-4ba8-bbd2-0c2e8e50dcd1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-09175c88-cdac-4ba8-bbd2-0c2e8e50dcd1_0">
											<gml:posList>35.67199404016263 139.7383387554832 26.169 35.67194959104602 139.73835853715488 25.739 35.67194959104602 139.73835853715488 30.299 35.67199404016263 139.7383387554832 26.169</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a9cc467d-01a2-4650-828a-a4aea5c5cedc">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a9cc467d-01a2-4650-828a-a4aea5c5cedc_0">
											<gml:posList>35.671994573392595 139.7383405554279 25.739 35.671994573392595 139.7383405554279 26.169 35.67194867358085 139.73836099055927 25.739 35.671994573392595 139.7383405554279 25.739</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b28e95cd-ad96-4026-8b7c-0772cfc53327">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b28e95cd-ad96-4026-8b7c-0772cfc53327_0">
											<gml:posList>35.67194867358085 139.73836099055927 25.739 35.671994573392595 139.7383405554279 26.169 35.67194867358085 139.73836099055927 30.299 35.67194867358085 139.73836099055927 25.739</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3470c62b-e296-4495-937c-acf03e72253b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3470c62b-e296-4495-937c-acf03e72253b_0">
											<gml:posList>35.67194867358085 139.73836099055927 30.299 35.671994573392595 139.7383405554279 26.169 35.6719981415794 139.7383389715532 30.299 35.67194867358085 139.73836099055927 30.299</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-46ef94ba-8881-417c-97a2-82381ffb8db1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-46ef94ba-8881-417c-97a2-82381ffb8db1_0">
											<gml:posList>35.671994573392595 139.7383405554279 26.169 35.6719981415794 139.7383389715532 26.169 35.6719981415794 139.7383389715532 30.299 35.671994573392595 139.7383405554279 26.169</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-26f577c9-ca6a-486f-9e53-197cd4f38e09">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-26f577c9-ca6a-486f-9e53-197cd4f38e09_0">
											<gml:posList>35.67197978698613 139.7382785138251 26.169 35.67197802091621 139.738279300219 30.299 35.67197978698613 139.7382785138251 30.299 35.67197978698613 139.7382785138251 26.169</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b058b42c-4113-4424-a101-d23ee6bcf39c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b058b42c-4113-4424-a101-d23ee6bcf39c_0">
											<gml:posList>35.67197978698613 139.7382785138251 26.169 35.67197802091621 139.738279300219 26.169 35.67197802091621 139.738279300219 30.299 35.67197978698613 139.7382785138251 26.169</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cf878a8d-d5be-4ebf-b3d2-84529e1aa5d4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cf878a8d-d5be-4ebf-b3d2-84529e1aa5d4_0">
											<gml:posList>35.67198013827703 139.7382782041072 26.169 35.67197978698613 139.7382785138251 30.299 35.67198013827703 139.7382782041072 30.299 35.67198013827703 139.7382782041072 26.169</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-627a09b4-c32e-4198-9fa2-6f74ee23d6b0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-627a09b4-c32e-4198-9fa2-6f74ee23d6b0_0">
											<gml:posList>35.67198013827703 139.7382782041072 26.169 35.67197978698613 139.7382785138251 26.169 35.67197978698613 139.7382785138251 30.299 35.67198013827703 139.7382782041072 26.169</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-dbf53529-f4a0-44fa-b44f-77b29e4561c9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-dbf53529-f4a0-44fa-b44f-77b29e4561c9_0">
											<gml:posList>35.671995454819886 139.73833812415754 30.299 35.67197802091621 139.738279300219 26.169 35.671995454819886 139.73833812415754 26.169 35.671995454819886 139.73833812415754 30.299</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-38b6dbff-da9e-473d-adce-f9842bfba06f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-38b6dbff-da9e-473d-adce-f9842bfba06f_0">
											<gml:posList>35.671995454819886 139.73833812415754 30.299 35.67197802091621 139.738279300219 30.299 35.67197802091621 139.738279300219 26.169 35.671995454819886 139.73833812415754 30.299</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7760a135-39b0-440d-b707-c609d6a7b90a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7760a135-39b0-440d-b707-c609d6a7b90a_0">
											<gml:posList>35.6719981415794 139.7383389715532 26.169 35.67198013827703 139.7382782041072 30.299 35.6719981415794 139.7383389715532 30.299 35.6719981415794 139.7383389715532 26.169</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-38b074f6-1b60-4cf2-b4f7-effe16e4e4c6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-38b074f6-1b60-4cf2-b4f7-effe16e4e4c6_0">
											<gml:posList>35.6719981415794 139.7383389715532 26.169 35.67198013827703 139.7382782041072 26.169 35.67198013827703 139.7382782041072 30.299 35.6719981415794 139.7383389715532 26.169</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c233e988-68ae-482f-9d92-9c2acc6d2052">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c233e988-68ae-482f-9d92-9c2acc6d2052_0">
											<gml:posList>35.671994573392595 139.7383405554279 25.739 35.67199404016263 139.7383387554832 26.169 35.671994573392595 139.7383405554279 26.169 35.671994573392595 139.7383405554279 25.739</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0ab33639-0365-4217-8f2b-3cdc909a3a9c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0ab33639-0365-4217-8f2b-3cdc909a3a9c_0">
											<gml:posList>35.671994573392595 139.7383405554279 25.739 35.67199404016263 139.7383387554832 25.739 35.67199404016263 139.7383387554832 26.169 35.671994573392595 139.7383405554279 25.739</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b91104ae-8b02-453c-9ec4-7060351a6548">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b91104ae-8b02-453c-9ec4-7060351a6548_0">
											<gml:posList>35.67193219331172 139.73829984576037 30.299 35.67193075162221 139.7383004881647 30.299 35.67194959104602 139.73835853715488 30.299 35.67193219331172 139.73829984576037 30.299</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c624f90f-b4e6-43c6-922e-1d41a8be9ddd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c624f90f-b4e6-43c6-922e-1d41a8be9ddd_0">
											<gml:posList>35.67198013827703 139.7382782041072 30.299 35.671995454819886 139.73833812415754 30.299 35.6719981415794 139.7383389715532 30.299 35.67198013827703 139.7382782041072 30.299</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0f83b420-1dd8-4770-b93c-073e47717392">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0f83b420-1dd8-4770-b93c-073e47717392_0">
											<gml:posList>35.67193075162221 139.7383004881647 30.299 35.67194867358085 139.73836099055927 30.299 35.67194959104602 139.73835853715488 30.299 35.67193075162221 139.7383004881647 30.299</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5160d3bf-760c-4608-b3a5-35a457c05c5a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5160d3bf-760c-4608-b3a5-35a457c05c5a_0">
											<gml:posList>35.671995454819886 139.73833812415754 30.299 35.67194867358085 139.73836099055927 30.299 35.6719981415794 139.7383389715532 30.299 35.671995454819886 139.73833812415754 30.299</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2890a7a7-a1be-491d-bee9-f7d67d255c81">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2890a7a7-a1be-491d-bee9-f7d67d255c81_0">
											<gml:posList>35.67197978698613 139.7382785138251 30.299 35.67197802091621 139.738279300219 30.299 35.671995454819886 139.73833812415754 30.299 35.67197978698613 139.7382785138251 30.299</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4cd62a5f-a9f1-4ed8-bb2c-a9b183aa02fd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4cd62a5f-a9f1-4ed8-bb2c-a9b183aa02fd_0">
											<gml:posList>35.67197978698613 139.7382785138251 30.299 35.671995454819886 139.73833812415754 30.299 35.67198013827703 139.7382782041072 30.299 35.67197978698613 139.7382785138251 30.299</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ebf7b29e-ba3d-411c-8cba-0e08f876cfab">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ebf7b29e-ba3d-411c-8cba-0e08f876cfab_0">
											<gml:posList>35.67194959104602 139.73835853715488 30.299 35.67194867358085 139.73836099055927 30.299 35.671995454819886 139.73833812415754 30.299 35.67194959104602 139.73835853715488 30.299</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b53bf09c-7a1b-40e1-9028-f312c907e22a">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67197802091621 139.738279300219 26.169 35.67197978698613 139.7382785138251 26.169 35.671995454819886 139.73833812415754 26.169 35.67197802091621 139.738279300219 26.169</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b195c571-90fc-4911-9432-95ae1e613d8d">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671994573392595 139.7383405554279 26.169 35.67199404016263 139.7383387554832 26.169 35.671995454819886 139.73833812415754 26.169 35.671994573392595 139.7383405554279 26.169</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-082ecc0e-bdc8-4f69-9dba-e8cffabf6d1a">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671994573392595 139.7383405554279 26.169 35.671995454819886 139.73833812415754 26.169 35.6719981415794 139.7383389715532 26.169 35.671994573392595 139.7383405554279 26.169</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-daa56953-eab4-49a2-9abb-21f11c6514aa">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671995454819886 139.73833812415754 26.169 35.67197978698613 139.7382785138251 26.169 35.67198013827703 139.7382782041072 26.169 35.671995454819886 139.73833812415754 26.169</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-248c8177-d684-4249-99ae-4f26a211ca87">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671995454819886 139.73833812415754 26.169 35.67198013827703 139.7382782041072 26.169 35.6719981415794 139.7383389715532 26.169 35.671995454819886 139.73833812415754 26.169</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9066a3ef-606c-4782-976b-42ecc212621c">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67199404016263 139.7383387554832 25.739 35.671994573392595 139.7383405554279 25.739 35.67194959104602 139.73835853715488 25.739 35.67199404016263 139.7383387554832 25.739</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f1aa6aab-eed6-4496-aaa9-5d4db93d0f00">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67193219331172 139.73829984576037 25.739 35.67194959104602 139.73835853715488 25.739 35.67193075162221 139.7383004881647 25.739 35.67193219331172 139.73829984576037 25.739</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5df3b58b-ff10-4b8c-b295-12c0f0590aed">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67193075162221 139.7383004881647 25.739 35.67194959104602 139.73835853715488 25.739 35.67194867358085 139.73836099055927 25.739 35.67193075162221 139.7383004881647 25.739</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-139fb5bb-85aa-4d3e-9da4-9484afd7c26e">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67194959104602 139.73835853715488 25.739 35.671994573392595 139.7383405554279 25.739 35.67194867358085 139.73836099055927 25.739 35.67194959104602 139.73835853715488 25.739</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-afc027cb-3613-4c7b-8bef-5c1f222631aa">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67190223352835 139.73835931127618 25.739 35.67189400691215 139.7383630105418 25.739 35.67189178366459 139.7383555678563 25.739 35.67190223352835 139.73835931127618 25.739</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ed8987fb-7ee9-4d3e-99cd-449316f14e0a">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67190001028927 139.7383518796365 25.739 35.67190223352835 139.73835931127618 25.739 35.67189178366459 139.7383555678563 25.739 35.67190001028927 139.7383518796365 25.739</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_161579f9-4437-4e85-bf72-df142f7358bd_BuildingInstallation_1041">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d1e870da-29ad-412a-bb60-fa6ffee7d45c">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67195549211358 139.73835482959478 25.739 35.671937347363446 139.73829756407739 25.739 35.671974948432435 139.73828081722942 25.739 35.67199205698743 139.73833855899633 25.739 35.67195549211358 139.73835482959478 25.739</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-01db9445-ec6d-40a1-b053-47464c4f90bc">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67187372902636 139.7383096911828 25.739 35.6718958143831 139.7383004522522 25.739 35.67190301874197 139.73832632558947 25.739 35.67188093338326 139.7383355645138 25.739 35.67187372902636 139.7383096911828 25.739</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7e3c7652-8a22-4aba-992c-56fedc525303">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7e3c7652-8a22-4aba-992c-56fedc525303_0">
											<gml:posList>35.671974948432435 139.73828081722942 25.739 35.671937347363446 139.73829756407739 25.739 35.671937347363446 139.73829756407739 29.217 35.671974948432435 139.73828081722942 29.217 35.671974948432435 139.73828081722942 25.739</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-93af1764-2e35-4125-b7ab-8b1f9413d744">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-93af1764-2e35-4125-b7ab-8b1f9413d744_0">
											<gml:posList>35.6718958143831 139.7383004522522 25.739 35.67187372902636 139.7383096911828 25.739 35.67187372902636 139.7383096911828 28.41 35.6718958143831 139.7383004522522 28.41 35.6718958143831 139.7383004522522 25.739</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-df93aafe-e8e5-4b4c-a044-2e235764a221">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-df93aafe-e8e5-4b4c-a044-2e235764a221_0">
											<gml:posList>35.671974948432435 139.73828081722942 25.739 35.671974948432435 139.73828081722942 29.217 35.67199205698743 139.73833855899633 29.217 35.67199205698743 139.73833855899633 25.739 35.671974948432435 139.73828081722942 25.739</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4a37ce96-c7d9-4b58-9bb0-c451ee7b17ee">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4a37ce96-c7d9-4b58-9bb0-c451ee7b17ee_0">
											<gml:posList>35.67190301874197 139.73832632558947 25.739 35.6718958143831 139.7383004522522 25.739 35.6718958143831 139.7383004522522 28.41 35.67190301874197 139.73832632558947 28.41 35.67190301874197 139.73832632558947 25.739</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cbeabf71-11f6-4b1d-ab69-58c82574ba61">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cbeabf71-11f6-4b1d-ab69-58c82574ba61_0">
											<gml:posList>35.67195549211358 139.73835482959478 29.217 35.67199205698743 139.73833855899633 29.217 35.671974948432435 139.73828081722942 29.217 35.671937347363446 139.73829756407739 29.217 35.67195549211358 139.73835482959478 29.217</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2bc1e6bc-11bb-4709-b7b5-aaf50ecdba30">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2bc1e6bc-11bb-4709-b7b5-aaf50ecdba30_0">
											<gml:posList>35.67187372902636 139.7383096911828 28.41 35.67188093338326 139.7383355645138 28.41 35.67190301874197 139.73832632558947 28.41 35.6718958143831 139.7383004522522 28.41 35.67187372902636 139.7383096911828 28.41</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7f35d23f-0ae7-4913-8fef-1cac5188ee84">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7f35d23f-0ae7-4913-8fef-1cac5188ee84_0">
											<gml:posList>35.67187372902636 139.7383096911828 25.739 35.67188093338326 139.7383355645138 25.739 35.67188093338326 139.7383355645138 28.41 35.67187372902636 139.7383096911828 28.41 35.67187372902636 139.7383096911828 25.739</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3bc6aea9-9d40-41e2-bca1-b5cad4151971">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3bc6aea9-9d40-41e2-bca1-b5cad4151971_0">
											<gml:posList>35.671937347363446 139.73829756407739 25.739 35.67195549211358 139.73835482959478 25.739 35.67195549211358 139.73835482959478 29.217 35.671937347363446 139.73829756407739 29.217 35.671937347363446 139.73829756407739 25.739</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a8cca649-72d9-4950-b937-32fdf21ce1e0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a8cca649-72d9-4950-b937-32fdf21ce1e0_0">
											<gml:posList>35.67188093338326 139.7383355645138 25.739 35.67190301874197 139.73832632558947 25.739 35.67190301874197 139.73832632558947 28.41 35.67188093338326 139.7383355645138 28.41 35.67188093338326 139.7383355645138 25.739</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c31f10d7-1221-4e2c-8cae-1e53ba25ccd7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c31f10d7-1221-4e2c-8cae-1e53ba25ccd7_0">
											<gml:posList>35.67199205698743 139.73833855899633 25.739 35.67199205698743 139.73833855899633 29.217 35.67195549211358 139.73835482959478 29.217 35.67195549211358 139.73835482959478 25.739 35.67199205698743 139.73833855899633 25.739</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-8da7c9dc-52e1-4de1-afe3-2f3bfa47c347">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8da7c9dc-52e1-4de1-afe3-2f3bfa47c347">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8da7c9dc-52e1-4de1-afe3-2f3bfa47c347">
											<gml:posList>35.67200469704252 139.7383535451434 9.884 35.67188981514687 139.73840825079054 9.884 35.67185816394892 139.73827749814532 9.884 35.671967912589615 139.73822865305564 9.884 35.67200469704252 139.7383535451434 9.884</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-9566c76d-3b6e-4853-abfc-e2aa54cf6554">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9566c76d-3b6e-4853-abfc-e2aa54cf6554">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9566c76d-3b6e-4853-abfc-e2aa54cf6554">
											<gml:posList>35.67185816394892 139.73827749814532 26.169 35.67188981514687 139.73840825079054 26.169 35.671893656445995 139.7383986579084 26.169 35.67186541452884 139.7382819854596 26.169 35.67185816394892 139.73827749814532 26.169</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-7b8f7887-c74c-4c18-89ff-0897131ea802">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7b8f7887-c74c-4c18-89ff-0897131ea802">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7b8f7887-c74c-4c18-89ff-0897131ea802">
											<gml:posList>35.67186541452884 139.7382819854596 26.169 35.671917342395616 139.73825886991006 26.169 35.67191532695437 139.7382520566277 26.169 35.67185816394892 139.73827749814532 26.169 35.67186541452884 139.7382819854596 26.169</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-77b6b0e4-717c-4c95-8ccc-6ab005753520">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-77b6b0e4-717c-4c95-8ccc-6ab005753520">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-77b6b0e4-717c-4c95-8ccc-6ab005753520">
											<gml:posList>35.67192980551294 139.73830090905213 30.545 35.67193253103783 139.73829376979984 30.545 35.671921161474025 139.7382553967891 30.545 35.67191532695437 139.7382520566277 30.545 35.67192980551294 139.73830090905213 30.545</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-494207e4-eade-4840-806d-2bf686534898">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-494207e4-eade-4840-806d-2bf686534898">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-494207e4-eade-4840-806d-2bf686534898">
											<gml:posList>35.67192980551294 139.73830090905213 25.739 35.671917342395616 139.73825886991006 25.739 35.67186541452884 139.7382819854596 25.739 35.671893656445995 139.7383986579084 25.739 35.671997167275386 139.73834935640068 25.739 35.671978729872265 139.7382867557521 25.739 35.67197648017182 139.73828006425282 25.739 35.671974948432435 139.73828081722942 25.739 35.67192980551294 139.73830090905213 25.739</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-57c81410-7c44-48fa-adbf-04eecfd0b0aa">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-57c81410-7c44-48fa-adbf-04eecfd0b0aa">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-57c81410-7c44-48fa-adbf-04eecfd0b0aa">
											<gml:posList>35.67191532695437 139.7382520566277 30.545 35.671921161474025 139.7382553967891 30.545 35.671962637093216 139.73823694417158 30.545 35.671965353591865 139.73822979387842 30.545 35.67191532695437 139.7382520566277 30.545</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-1f948c9d-3af4-4d27-9fcd-56173aca53b9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1f948c9d-3af4-4d27-9fcd-56173aca53b9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1f948c9d-3af4-4d27-9fcd-56173aca53b9">
											<gml:posList>35.67200469704252 139.7383535451434 26.169 35.671997167275386 139.73834935640068 26.169 35.671893656445995 139.7383986579084 26.169 35.67188981514687 139.73840825079054 26.169 35.67200469704252 139.7383535451434 26.169</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ad359650-87db-4d9a-b824-ab20a46e9fd8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ad359650-87db-4d9a-b824-ab20a46e9fd8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ad359650-87db-4d9a-b824-ab20a46e9fd8">
											<gml:posList>35.67197324977201 139.7382756494913 30.084 35.67197399762297 139.73827528407082 30.084 35.671962637093216 139.73823694417158 30.084 35.671921161474025 139.7382553967891 30.084 35.67193253103783 139.73829376979984 30.084 35.67197324977201 139.7382756494913 30.084</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-0a2e3381-9161-4dc8-b6f7-751396d496cb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0a2e3381-9161-4dc8-b6f7-751396d496cb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0a2e3381-9161-4dc8-b6f7-751396d496cb">
											<gml:posList>35.671974948432435 139.73828081722942 30.545 35.67197324977201 139.7382756494913 30.545 35.67193253103783 139.73829376979984 30.545 35.67192980551294 139.73830090905213 30.545 35.671974948432435 139.73828081722942 30.545</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-9674517b-9a9e-4380-911e-f445384859ad">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9674517b-9a9e-4380-911e-f445384859ad">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9674517b-9a9e-4380-911e-f445384859ad">
											<gml:posList>35.671965353591865 139.73822979387842 30.545 35.671962637093216 139.73823694417158 30.545 35.67197399762297 139.73827528407082 30.545 35.67197978698613 139.7382785138251 30.545 35.671965353591865 139.73822979387842 30.545</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e47a81af-106d-4802-aa70-05cbe301fb0a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e47a81af-106d-4802-aa70-05cbe301fb0a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e47a81af-106d-4802-aa70-05cbe301fb0a">
											<gml:posList>35.671974948432435 139.73828081722942 30.545 35.67197802091621 139.738279300219 30.545 35.67197399762297 139.73827528407082 30.545 35.67197324977201 139.7382756494913 30.545 35.671974948432435 139.73828081722942 30.545</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-09942ddc-954e-42d2-8527-ddf8ad85be41">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-09942ddc-954e-42d2-8527-ddf8ad85be41">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-09942ddc-954e-42d2-8527-ddf8ad85be41">
											<gml:posList>35.67197802091621 139.738279300219 30.545 35.67197978698613 139.7382785138251 30.545 35.67197399762297 139.73827528407082 30.545 35.67197802091621 139.738279300219 30.545</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ce45805c-a586-4a51-b0c3-ee170e1be96d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ce45805c-a586-4a51-b0c3-ee170e1be96d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ce45805c-a586-4a51-b0c3-ee170e1be96d">
											<gml:posList>35.67197978698613 139.7382785138251 26.169 35.67197802091621 139.738279300219 26.169 35.67197648017182 139.73828006425282 26.169 35.671978729872265 139.7382867557521 26.169 35.671997167275386 139.73834935640068 26.169 35.67200469704252 139.7383535451434 26.169 35.671967912589615 139.73822865305564 26.169 35.671965353591865 139.73822979387842 26.169 35.67197978698613 139.7382785138251 26.169</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-026aa18c-b5a9-418b-991c-8f1e650f9751">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-026aa18c-b5a9-418b-991c-8f1e650f9751">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-026aa18c-b5a9-418b-991c-8f1e650f9751">
											<gml:posList>35.67197324977201 139.7382756494913 30.545 35.67197324977201 139.7382756494913 30.084 35.67193253103783 139.73829376979984 30.084 35.67193253103783 139.73829376979984 30.545 35.67197324977201 139.7382756494913 30.545</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2d177e9c-0043-4f37-be47-d4c20ef39b59">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2d177e9c-0043-4f37-be47-d4c20ef39b59">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2d177e9c-0043-4f37-be47-d4c20ef39b59">
											<gml:posList>35.67185816394892 139.73827749814532 9.884 35.67188981514687 139.73840825079054 9.884 35.67188981514687 139.73840825079054 26.169 35.67185816394892 139.73827749814532 26.169 35.67185816394892 139.73827749814532 9.884</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-41795c52-abab-47b7-85aa-0aa4722ace2b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-41795c52-abab-47b7-85aa-0aa4722ace2b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-41795c52-abab-47b7-85aa-0aa4722ace2b">
											<gml:posList>35.671893656445995 139.7383986579084 26.169 35.671893656445995 139.7383986579084 25.739 35.67186541452884 139.7382819854596 25.739 35.67186541452884 139.7382819854596 26.169 35.671893656445995 139.7383986579084 26.169</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f0c99205-2e51-4b7e-bbe4-ac892b3dacc4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f0c99205-2e51-4b7e-bbe4-ac892b3dacc4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f0c99205-2e51-4b7e-bbe4-ac892b3dacc4">
											<gml:posList>35.67186541452884 139.7382819854596 26.169 35.67186541452884 139.7382819854596 25.739 35.671917342395616 139.73825886991006 25.739 35.671917342395616 139.73825886991006 26.169 35.67186541452884 139.7382819854596 26.169</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d9f83734-6007-4a34-8d2e-74f25ebc0b01">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d9f83734-6007-4a34-8d2e-74f25ebc0b01">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d9f83734-6007-4a34-8d2e-74f25ebc0b01">
											<gml:posList>35.67191532695437 139.7382520566277 26.169 35.67191532695437 139.7382520566277 30.545 35.671965353591865 139.73822979387842 30.545 35.671965353591865 139.73822979387842 26.169 35.671967912589615 139.73822865305564 26.169 35.671967912589615 139.73822865305564 9.884 35.67185816394892 139.73827749814532 9.884 35.67185816394892 139.73827749814532 26.169 35.67191532695437 139.7382520566277 26.169</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9211040a-eeeb-4396-a0f1-1295d1cf0596">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9211040a-eeeb-4396-a0f1-1295d1cf0596">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9211040a-eeeb-4396-a0f1-1295d1cf0596">
											<gml:posList>35.67191532695437 139.7382520566277 30.545 35.67191532695437 139.7382520566277 26.169 35.671917342395616 139.73825886991006 26.169 35.671917342395616 139.73825886991006 25.739 35.67192980551294 139.73830090905213 25.739 35.67192980551294 139.73830090905213 30.545 35.67191532695437 139.7382520566277 30.545</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-66031690-a7da-489e-aa59-0ef8b990eaf0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-66031690-a7da-489e-aa59-0ef8b990eaf0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-66031690-a7da-489e-aa59-0ef8b990eaf0">
											<gml:posList>35.67193253103783 139.73829376979984 30.545 35.67193253103783 139.73829376979984 30.084 35.671921161474025 139.7382553967891 30.084 35.671921161474025 139.7382553967891 30.545 35.67193253103783 139.73829376979984 30.545</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c6587e13-d69e-4188-89f4-79b47955f050">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c6587e13-d69e-4188-89f4-79b47955f050">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c6587e13-d69e-4188-89f4-79b47955f050">
											<gml:posList>35.671921161474025 139.7382553967891 30.545 35.671921161474025 139.7382553967891 30.084 35.671962637093216 139.73823694417158 30.084 35.671962637093216 139.73823694417158 30.545 35.671921161474025 139.7382553967891 30.545</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9e26eb53-2a2f-4c64-9162-93f023756a9e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9e26eb53-2a2f-4c64-9162-93f023756a9e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9e26eb53-2a2f-4c64-9162-93f023756a9e">
											<gml:posList>35.671997167275386 139.73834935640068 26.169 35.671997167275386 139.73834935640068 25.739 35.671893656445995 139.7383986579084 25.739 35.671893656445995 139.7383986579084 26.169 35.671997167275386 139.73834935640068 26.169</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-572d6460-eb22-4937-b6e3-2728e7fffbf4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-572d6460-eb22-4937-b6e3-2728e7fffbf4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-572d6460-eb22-4937-b6e3-2728e7fffbf4">
											<gml:posList>35.67188981514687 139.73840825079054 9.884 35.67200469704252 139.7383535451434 9.884 35.67200469704252 139.7383535451434 26.169 35.67188981514687 139.73840825079054 26.169 35.67188981514687 139.73840825079054 9.884</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c8a471f9-50df-49db-b6c5-0fe1d482b0aa">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c8a471f9-50df-49db-b6c5-0fe1d482b0aa">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c8a471f9-50df-49db-b6c5-0fe1d482b0aa">
											<gml:posList>35.67192980551294 139.73830090905213 25.739 35.671974948432435 139.73828081722942 25.739 35.671974948432435 139.73828081722942 30.545 35.67192980551294 139.73830090905213 30.545 35.67192980551294 139.73830090905213 25.739</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-de42651f-2613-4f4f-8b5b-08128c9eb81e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-de42651f-2613-4f4f-8b5b-08128c9eb81e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-de42651f-2613-4f4f-8b5b-08128c9eb81e">
											<gml:posList>35.671962637093216 139.73823694417158 30.545 35.671962637093216 139.73823694417158 30.084 35.67197399762297 139.73827528407082 30.084 35.67197399762297 139.73827528407082 30.545 35.671962637093216 139.73823694417158 30.545</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2115c619-ce74-467e-8d03-16f0f72f8250">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2115c619-ce74-467e-8d03-16f0f72f8250">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2115c619-ce74-467e-8d03-16f0f72f8250">
											<gml:posList>35.671965353591865 139.73822979387842 26.169 35.671965353591865 139.73822979387842 30.545 35.67197978698613 139.7382785138251 30.545 35.67197978698613 139.7382785138251 26.169 35.671965353591865 139.73822979387842 26.169</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ece85d69-13a8-4219-9ea3-26bb18eb1d80">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ece85d69-13a8-4219-9ea3-26bb18eb1d80">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ece85d69-13a8-4219-9ea3-26bb18eb1d80">
											<gml:posList>35.67197399762297 139.73827528407082 30.545 35.67197399762297 139.73827528407082 30.084 35.67197324977201 139.7382756494913 30.084 35.67197324977201 139.7382756494913 30.545 35.67197399762297 139.73827528407082 30.545</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f6c27a70-c298-4329-8167-aa1dbd7b7a27">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f6c27a70-c298-4329-8167-aa1dbd7b7a27">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f6c27a70-c298-4329-8167-aa1dbd7b7a27">
											<gml:posList>35.67197802091621 139.738279300219 30.545 35.671974948432435 139.73828081722942 30.545 35.671974948432435 139.73828081722942 25.739 35.67197648017182 139.73828006425282 25.739 35.67197648017182 139.73828006425282 26.169 35.67197802091621 139.738279300219 26.169 35.67197802091621 139.738279300219 30.545</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-bc7c8a84-ab6c-48dc-b9ba-abf6f867e716">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bc7c8a84-ab6c-48dc-b9ba-abf6f867e716">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bc7c8a84-ab6c-48dc-b9ba-abf6f867e716">
											<gml:posList>35.67197648017182 139.73828006425282 26.169 35.67197648017182 139.73828006425282 25.739 35.671978729872265 139.7382867557521 25.739 35.671978729872265 139.7382867557521 26.169 35.67197648017182 139.73828006425282 26.169</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e60caf26-815c-443c-a8bb-4b95a812923f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e60caf26-815c-443c-a8bb-4b95a812923f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e60caf26-815c-443c-a8bb-4b95a812923f">
											<gml:posList>35.67197978698613 139.7382785138251 26.169 35.67197978698613 139.7382785138251 30.545 35.67197802091621 139.738279300219 30.545 35.67197802091621 139.738279300219 26.169 35.67197978698613 139.7382785138251 26.169</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f697b0fa-e807-4a75-b513-635eb2f59af5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f697b0fa-e807-4a75-b513-635eb2f59af5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f697b0fa-e807-4a75-b513-635eb2f59af5">
											<gml:posList>35.67200469704252 139.7383535451434 9.884 35.671967912589615 139.73822865305564 9.884 35.671967912589615 139.73822865305564 26.169 35.67200469704252 139.7383535451434 26.169 35.67200469704252 139.7383535451434 9.884</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-774bf8f9-6111-4d63-bce1-df82b825f26b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-774bf8f9-6111-4d63-bce1-df82b825f26b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-774bf8f9-6111-4d63-bce1-df82b825f26b">
											<gml:posList>35.671978729872265 139.7382867557521 26.169 35.671978729872265 139.7382867557521 25.739 35.671997167275386 139.73834935640068 25.739 35.671997167275386 139.73834935640068 26.169 35.671978729872265 139.7382867557521 26.169</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-4517</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">161.97725</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1210</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>5</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.01</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>