<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_1862c5f4-2943-4f0e-ba7b-0f8f890463b9">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">401</bldg:usage>
			<bldg:measuredHeight uom="m">37.2</bldg:measuredHeight>
			<bldg:storeysAboveGround>9</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.67066461626921 139.7419281905077 0 35.6706535604472 139.74194536905782 0 35.67061338141087 139.74190337266882 0 35.670490119540545 139.74208279426958 0 35.67055642270286 139.74215175808348 0 35.67069111936178 139.7419555330304 0 35.67066461626921 139.7419281905077 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67066461626921 139.7419281905077 7.685 35.67069111936178 139.7419555330304 7.685 35.67055642270286 139.74215175808348 7.685 35.670490119540545 139.74208279426958 7.685 35.67061338141087 139.74190337266882 7.685 35.6706535604472 139.74194536905782 7.685 35.67066461626921 139.7419281905077 7.685</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67066461626921 139.7419281905077 7.685 35.6706535604472 139.74194536905782 7.685 35.6706535604472 139.74194536905782 44.87 35.67066461626921 139.7419281905077 44.87 35.67066461626921 139.7419281905077 7.685</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6706535604472 139.74194536905782 7.685 35.67061338141087 139.74190337266882 7.685 35.67061338141087 139.74190337266882 44.87 35.6706535604472 139.74194536905782 44.87 35.6706535604472 139.74194536905782 7.685</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67061338141087 139.74190337266882 7.685 35.670490119540545 139.74208279426958 7.685 35.670490119540545 139.74208279426958 44.87 35.67061338141087 139.74190337266882 44.87 35.67061338141087 139.74190337266882 7.685</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670490119540545 139.74208279426958 7.685 35.67055642270286 139.74215175808348 7.685 35.67055642270286 139.74215175808348 44.87 35.670490119540545 139.74208279426958 44.87 35.670490119540545 139.74208279426958 7.685</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67055642270286 139.74215175808348 7.685 35.67069111936178 139.7419555330304 7.685 35.67069111936178 139.7419555330304 44.87 35.67055642270286 139.74215175808348 44.87 35.67055642270286 139.74215175808348 7.685</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67069111936178 139.7419555330304 7.685 35.67066461626921 139.7419281905077 7.685 35.67066461626921 139.7419281905077 44.87 35.67069111936178 139.7419555330304 44.87 35.67069111936178 139.7419555330304 7.685</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67066461626921 139.7419281905077 44.87 35.6706535604472 139.74194536905782 44.87 35.67061338141087 139.74190337266882 44.87 35.670490119540545 139.74208279426958 44.87 35.67055642270286 139.74215175808348 44.87 35.67069111936178 139.7419555330304 44.87 35.67066461626921 139.7419281905077 44.87</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-7a75f24b-db53-44b5-8cce-cdb212fd465f"/>
							<gml:surfaceMember xlink:href="#poly-13134ffb-e264-4dd0-8157-c4bd26cd856b"/>
							<gml:surfaceMember xlink:href="#poly-a2963e44-74ae-4a25-81fd-f922e967efc5"/>
							<gml:surfaceMember xlink:href="#poly-aa7790cd-c870-4c21-b313-9aef86656871"/>
							<gml:surfaceMember xlink:href="#poly-c47c1c43-fdae-476f-8ea0-48429c3822c9"/>
							<gml:surfaceMember xlink:href="#poly-094e149f-a172-40b5-b3f9-c86a5618078c"/>
							<gml:surfaceMember xlink:href="#poly-dd55ff14-ac6b-4635-8ee3-8b232a3386ab"/>
							<gml:surfaceMember xlink:href="#poly-20e770be-ccbb-4546-8bb4-189f3f387978"/>
							<gml:surfaceMember xlink:href="#poly-a08278d5-6a15-4005-b71d-1898eacfc1b8"/>
							<gml:surfaceMember xlink:href="#poly-dcb3647d-e5a7-4169-890c-6ba9ffdf2982"/>
							<gml:surfaceMember xlink:href="#poly-ed3a7f51-6468-45aa-a7af-e0cc35dca0a3"/>
							<gml:surfaceMember xlink:href="#poly-accb606d-a51f-4633-8269-0b74b4fd94a2"/>
							<gml:surfaceMember xlink:href="#poly-577b7f39-4a07-4d8d-974a-b70ea268c87b"/>
							<gml:surfaceMember xlink:href="#poly-c77b6977-7487-4430-a247-e1b06497c6b2"/>
							<gml:surfaceMember xlink:href="#poly-7ac8c336-bc32-4061-90a8-c65593210c43"/>
							<gml:surfaceMember xlink:href="#poly-f1421120-ab6b-4a8b-a4d7-162b57d6f58f"/>
							<gml:surfaceMember xlink:href="#poly-d1b27f72-a18d-4fd9-9391-ce2cdfaee82f"/>
							<gml:surfaceMember xlink:href="#poly-c7c42e7e-35ec-4a2a-a61c-66c7ae56e2b0"/>
							<gml:surfaceMember xlink:href="#poly-44c58d86-2acb-490b-932e-7c501cc2e531"/>
							<gml:surfaceMember xlink:href="#poly-5274d02d-3d5d-4709-afa1-d333b6ea064c"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_1862c5f4-2943-4f0e-ba7b-0f8f890463b9_BuildingInstallation_1041">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-000040d3-edb5-483f-96b4-2e527459db3d">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67058961784698 139.74206527207863 45.63 35.670573434224366 139.74204813561846 45.63 35.67060427307185 139.74200437928928 45.63 35.67062046571432 139.7420215157369 45.63 35.67058961784698 139.74206527207863 45.63</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a845e4cb-f558-4f00-8961-677ef2e45694">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a845e4cb-f558-4f00-8961-677ef2e45694_0">
											<gml:posList>35.67060427307185 139.74200437928928 45.63 35.67060427307185 139.74200437928928 47.899 35.67062046571432 139.7420215157369 47.899 35.67062046571432 139.7420215157369 45.63 35.67060427307185 139.74200437928928 45.63</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-85e26cdc-151c-413d-a12d-0c4e678aa605">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-85e26cdc-151c-413d-a12d-0c4e678aa605_0">
											<gml:posList>35.670573434224366 139.74204813561846 45.63 35.670573434224366 139.74204813561846 47.899 35.67060427307185 139.74200437928928 47.899 35.67060427307185 139.74200437928928 45.63 35.670573434224366 139.74204813561846 45.63</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-af5d0fc6-d6ae-40dd-92b2-9f7d6684db4e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-af5d0fc6-d6ae-40dd-92b2-9f7d6684db4e_0">
											<gml:posList>35.67058961784698 139.74206527207863 47.899 35.67062046571432 139.7420215157369 47.899 35.67060427307185 139.74200437928928 47.899 35.670573434224366 139.74204813561846 47.899 35.67058961784698 139.74206527207863 47.899</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-475c4cb4-9e53-4da9-87ac-566d16417524">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-475c4cb4-9e53-4da9-87ac-566d16417524_0">
											<gml:posList>35.67062046571432 139.7420215157369 45.63 35.67062046571432 139.7420215157369 47.899 35.67058961784698 139.74206527207863 47.899 35.67058961784698 139.74206527207863 45.63 35.67062046571432 139.7420215157369 45.63</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e769e7ca-f857-4019-97f7-1295ce862d31">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e769e7ca-f857-4019-97f7-1295ce862d31_0">
											<gml:posList>35.67058961784698 139.74206527207863 45.63 35.67058961784698 139.74206527207863 47.899 35.670573434224366 139.74204813561846 47.899 35.670573434224366 139.74204813561846 45.63 35.67058961784698 139.74206527207863 45.63</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_1862c5f4-2943-4f0e-ba7b-0f8f890463b9_BuildingInstallation_1060">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8e2abde3-9267-4c50-a7c8-1968d442fa29">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670631131063224 139.74189363168907 7.685 35.67066461626921 139.7419281905077 7.685 35.6706535604472 139.7419453690578 7.685 35.67061987640742 139.7419101035007 7.685 35.670631131063224 139.74189363168907 7.685</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a384014c-cbfc-4ccc-abd2-2a6d5caee4cd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a384014c-cbfc-4ccc-abd2-2a6d5caee4cd_0">
											<gml:posList>35.670631131063224 139.74189363168907 45.743 35.670631131063224 139.74189363168907 7.685 35.67061987640742 139.7419101035007 7.685 35.67061987640742 139.7419101035007 45.743 35.670631131063224 139.74189363168907 45.743</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6c2e1f55-007d-46e6-91a2-07358832c2ad">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6c2e1f55-007d-46e6-91a2-07358832c2ad_0">
											<gml:posList>35.67063950236566 139.74190227139104 45.743 35.670631131063224 139.74189363168907 45.743 35.67061987640742 139.7419101035007 45.743 35.670628301925206 139.74191891988207 45.743 35.670633902145724 139.74191059563714 45.743 35.67063950236566 139.74190227139104 45.743</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-223391a4-fdc9-4501-8378-f4b3167eb485">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-223391a4-fdc9-4501-8378-f4b3167eb485_0">
											<gml:posList>35.67066461626921 139.7419281905077 45.743 35.67066461626921 139.7419281905077 7.685 35.670631131063224 139.74189363168907 7.685 35.670631131063224 139.74189363168907 45.743 35.67063950236566 139.74190227139104 45.743 35.67066461626921 139.7419281905077 47.683 35.67066461626921 139.7419281905077 45.743</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-742304c7-3c84-40a9-b5a7-bbb2b634d2c4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-742304c7-3c84-40a9-b5a7-bbb2b634d2c4_0">
											<gml:posList>35.67065908835851 139.74193677978337 47.683 35.67066461626921 139.7419281905077 47.683 35.67063950236566 139.74190227139104 45.743 35.670633902145724 139.74191059563714 45.743 35.67065908835851 139.74193677978337 47.683</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d3e3fe46-df62-443f-bbef-df555a6b1aa3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d3e3fe46-df62-443f-bbef-df555a6b1aa3_0">
											<gml:posList>35.670633902145724 139.74191059563714 45.743 35.67065908835851 139.74193677978337 45.743 35.67065908835851 139.74193677978337 47.683 35.670633902145724 139.74191059563714 45.743</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c83822b5-428d-49c7-99ea-78fd7948e0b5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c83822b5-428d-49c7-99ea-78fd7948e0b5_0">
											<gml:posList>35.67061987640742 139.7419101035007 45.743 35.67061987640742 139.7419101035007 7.685 35.6706535604472 139.7419453690578 7.685 35.6706535604472 139.7419453690578 45.743 35.670628301925206 139.74191891988207 45.743 35.67061987640742 139.7419101035007 45.743</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2e834144-bcc6-40e4-8e39-b1d108457c3f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2e834144-bcc6-40e4-8e39-b1d108457c3f_0">
											<gml:posList>35.670628301925206 139.74191891988207 45.743 35.6706535604472 139.7419453690578 45.743 35.67065908835851 139.74193677978337 45.743 35.670633902145724 139.74191059563714 45.743 35.670628301925206 139.74191891988207 45.743</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c3549987-c6ab-443d-8e7d-11b20c58bea7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c3549987-c6ab-443d-8e7d-11b20c58bea7_0">
											<gml:posList>35.67065908835851 139.74193677978337 45.743 35.67066461626921 139.7419281905077 45.743 35.67066461626921 139.7419281905077 47.683 35.67065908835851 139.74193677978337 47.683 35.67065908835851 139.74193677978337 45.743</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-19b4c3ab-aa18-48bb-9da3-34510869c659">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-19b4c3ab-aa18-48bb-9da3-34510869c659_0">
											<gml:posList>35.6706535604472 139.7419453690578 45.743 35.6706535604472 139.7419453690578 7.685 35.67066461626921 139.7419281905077 7.685 35.67066461626921 139.7419281905077 45.743 35.67065908835851 139.74193677978337 45.743 35.6706535604472 139.7419453690578 45.743</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_1862c5f4-2943-4f0e-ba7b-0f8f890463b9_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5f0674ea-ab47-45e0-95b1-24b86dd8d88b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5f0674ea-ab47-45e0-95b1-24b86dd8d88b_0">
											<gml:posList>35.670617070504015 139.74196601198517 45.63 35.67061273066709 139.74197231331695 47.123 35.670617070504015 139.74196601198517 47.123 35.670617070504015 139.74196601198517 45.63</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e2575e5c-918d-4702-98d8-6ab762d86279">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e2575e5c-918d-4702-98d8-6ab762d86279_0">
											<gml:posList>35.670617070504015 139.74196601198517 45.63 35.67061273066709 139.74197231331695 45.63 35.67061273066709 139.74197231331695 47.123 35.670617070504015 139.74196601198517 45.63</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9712b30b-f668-45f5-99f8-6179214bf755">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9712b30b-f668-45f5-99f8-6179214bf755_0">
											<gml:posList>35.670610875885174 139.74197501072555 45.63 35.67060591479647 139.74198222960635 47.123 35.670610875885174 139.74197501072555 47.123 35.670610875885174 139.74197501072555 45.63</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9db2bbfc-2780-4c61-b870-1bbd4884f99f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9db2bbfc-2780-4c61-b870-1bbd4884f99f_0">
											<gml:posList>35.670610875885174 139.74197501072555 45.63 35.67060591479647 139.74198222960635 45.63 35.67060591479647 139.74198222960635 47.123 35.670610875885174 139.74197501072555 45.63</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f38f6c10-3992-403c-b38d-c800e7e5dcf4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f38f6c10-3992-403c-b38d-c800e7e5dcf4_0">
											<gml:posList>35.670617070504015 139.74196601198517 45.63 35.67064406977027 139.7419939173 47.123 35.67064406977027 139.7419939173 45.63 35.670617070504015 139.74196601198517 45.63</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f5e20089-be43-401f-be77-db7e46ddacca">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f5e20089-be43-401f-be77-db7e46ddacca_0">
											<gml:posList>35.670617070504015 139.74196601198517 45.63 35.670617070504015 139.74196601198517 47.123 35.67064406977027 139.7419939173 47.123 35.670617070504015 139.74196601198517 45.63</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-adc29983-ee6f-4789-99bc-d8ad1a8ef738">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-adc29983-ee6f-4789-99bc-d8ad1a8ef738_0">
											<gml:posList>35.67060119076229 139.74199300512157 45.63 35.67060470232663 139.74198800819775 46.262 35.67060119076229 139.74199300512157 46.262 35.67060119076229 139.74199300512157 45.63</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-eae4765e-d56b-4bad-9920-50533af4b42e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-eae4765e-d56b-4bad-9920-50533af4b42e_0">
											<gml:posList>35.67060119076229 139.74199300512157 45.63 35.67060470232663 139.74198800819775 45.63 35.67060470232663 139.74198800819775 46.262 35.67060119076229 139.74199300512157 45.63</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-696a36b0-985c-4384-8e08-8a3c819573c9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-696a36b0-985c-4384-8e08-8a3c819573c9_0">
											<gml:posList>35.67055973384718 139.74201312344934 45.63 35.67058444089915 139.74197802334484 47.784 35.67058444089915 139.74197802334484 45.63 35.67055973384718 139.74201312344934 45.63</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-45c13286-a37b-4c00-8366-f75bf415213d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-45c13286-a37b-4c00-8366-f75bf415213d_0">
											<gml:posList>35.67055973384718 139.74201312344934 45.63 35.67055973384718 139.74201312344934 47.784 35.67058444089915 139.74197802334484 47.784 35.67055973384718 139.74201312344934 45.63</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5b30cbc0-78b9-46c9-8204-df88b0fd5519">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5b30cbc0-78b9-46c9-8204-df88b0fd5519_0">
											<gml:posList>35.67063972993189 139.74200021863237 45.63 35.67064406977027 139.7419939173 47.123 35.67063972993189 139.74200021863237 47.123 35.67063972993189 139.74200021863237 45.63</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3ce2c802-59c9-415c-b28d-2e4e282f2d80">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3ce2c802-59c9-415c-b28d-2e4e282f2d80_0">
											<gml:posList>35.67063972993189 139.74200021863237 45.63 35.67064406977027 139.7419939173 45.63 35.67064406977027 139.7419939173 47.123 35.67063972993189 139.74200021863237 45.63</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f8085faf-e81e-4053-b47c-822394fa2e57">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f8085faf-e81e-4053-b47c-822394fa2e57_0">
											<gml:posList>35.67057082565197 139.74201960603204 45.63 35.670598035830665 139.7419809572138 46.262 35.670598035830665 139.7419809572138 45.63 35.67057082565197 139.74201960603204 45.63</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1ce8bdf8-2b10-41be-8a6d-41ad7f1b5c6f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1ce8bdf8-2b10-41be-8a6d-41ad7f1b5c6f_0">
											<gml:posList>35.67057082565197 139.74201960603204 45.63 35.67057082565197 139.74201960603204 46.262 35.670598035830665 139.7419809572138 46.262 35.67057082565197 139.74201960603204 45.63</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-432755a4-67bf-4273-83a4-4a47cae729cb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-432755a4-67bf-4273-83a4-4a47cae729cb_0">
											<gml:posList>35.6705904939761 139.7419844343415 45.63 35.6705657869223 139.74201953444668 47.784 35.6705657869223 139.74201953444668 45.63 35.6705904939761 139.7419844343415 45.63</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-647380f7-16ef-4c72-a8f6-bb3c4f310380">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-647380f7-16ef-4c72-a8f6-bb3c4f310380_0">
											<gml:posList>35.6705904939761 139.7419844343415 45.63 35.6705904939761 139.7419844343415 47.784 35.6705657869223 139.74201953444668 47.784 35.6705904939761 139.7419844343415 45.63</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b70ac860-4f6c-4424-b442-baf3bb5d079e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b70ac860-4f6c-4424-b442-baf3bb5d079e_0">
											<gml:posList>35.670506155547955 139.7420835603045 45.63 35.67061223445765 139.74192420728264 49.643 35.670506155547955 139.7420835603045 49.643 35.670506155547955 139.7420835603045 45.63</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7007d682-4702-4159-a098-6139c160a439">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7007d682-4702-4159-a098-6139c160a439_0">
											<gml:posList>35.670506155547955 139.7420835603045 45.63 35.67061223445765 139.74192420728264 45.63 35.67061223445765 139.74192420728264 49.643 35.670506155547955 139.7420835603045 45.63</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fd317b5b-4432-439a-a951-59f25cd5a355">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fd317b5b-4432-439a-a951-59f25cd5a355_0">
											<gml:posList>35.67063291405901 139.74201013492277 45.63 35.670637875149374 139.74200291604126 47.123 35.67063291405901 139.74201013492277 47.123 35.67063291405901 139.74201013492277 45.63</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-028263a7-588d-4d87-9706-cfd9eb30b9c0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-028263a7-588d-4d87-9706-cfd9eb30b9c0_0">
											<gml:posList>35.67063291405901 139.74201013492277 45.63 35.670637875149374 139.74200291604126 45.63 35.670637875149374 139.74200291604126 47.123 35.67063291405901 139.74201013492277 45.63</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-97e13066-a0cf-4385-9031-9a9d99dc246d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-97e13066-a0cf-4385-9031-9a9d99dc246d_0">
											<gml:posList>35.67059926027544 139.74199096375725 45.63 35.67057557067314 139.742024615642 46.262 35.67057557067314 139.742024615642 45.63 35.67059926027544 139.74199096375725 45.63</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0fa57f90-c0ae-47b8-a318-1ec6208144b7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0fa57f90-c0ae-47b8-a318-1ec6208144b7_0">
											<gml:posList>35.67059926027544 139.74199096375725 45.63 35.67059926027544 139.74199096375725 46.262 35.67057557067314 139.742024615642 46.262 35.67059926027544 139.74199096375725 45.63</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-669894c6-99b7-4c6f-90d6-aaff8f763632">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-669894c6-99b7-4c6f-90d6-aaff8f763632_0">
											<gml:posList>35.670658092122935 139.74198994675072 45.63 35.67055594196819 139.74213588512032 45.63 35.670658092122935 139.74198994675072 47.468 35.670658092122935 139.74198994675072 45.63</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d42117f9-4ca5-4039-8315-93c340f537db">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d42117f9-4ca5-4039-8315-93c340f537db_0">
											<gml:posList>35.67066552939625 139.74197931173805 47.468 35.670658092122935 139.74198994675072 47.468 35.67066552939625 139.74197931173805 49.643 35.67066552939625 139.74197931173805 47.468</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b88a02a2-3127-4609-bed1-df31d22cc10d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b88a02a2-3127-4609-bed1-df31d22cc10d_0">
											<gml:posList>35.67066552939625 139.74197931173805 49.643 35.670658092122935 139.74198994675072 47.468 35.67055594196819 139.74213588512032 49.643 35.67066552939625 139.74197931173805 49.643</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-948e76a6-47cc-4a26-9da6-98ae973c941f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-948e76a6-47cc-4a26-9da6-98ae973c941f_0">
											<gml:posList>35.670658092122935 139.74198994675072 47.468 35.67055594196819 139.74213588512032 45.63 35.67055594196819 139.74213588512032 49.643 35.670658092122935 139.74198994675072 47.468</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ffb9d0ad-4ab4-460e-a8e0-e850d8c24c3f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ffb9d0ad-4ab4-460e-a8e0-e850d8c24c3f_0">
											<gml:posList>35.67061251118953 139.74190878634406 49.087 35.67061251118953 139.74190878634406 49.643 35.67061369291816 139.74191001113493 49.087 35.67061251118953 139.74190878634406 49.087</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c30066ec-ab6d-4032-aa97-896d24b14f47">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c30066ec-ab6d-4032-aa97-896d24b14f47_0">
											<gml:posList>35.67067424092251 139.7419730496062 45.63 35.67061369291816 139.74191001113493 45.63 35.67061369291816 139.74191001113493 49.087 35.67067424092251 139.7419730496062 45.63</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6bf6b25f-cc79-4e0c-bf95-8697c8bb3885">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6bf6b25f-cc79-4e0c-bf95-8697c8bb3885_0">
											<gml:posList>35.67067424092251 139.7419730496062 49.087 35.67061251118953 139.74190878634406 49.643 35.670676559284665 139.74197546610424 49.643 35.67067424092251 139.7419730496062 49.087</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fe34039e-df10-4340-9ebf-32cbb6b04c7f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fe34039e-df10-4340-9ebf-32cbb6b04c7f_0">
											<gml:posList>35.67067424092251 139.7419730496062 49.087 35.670676559284665 139.74197546610424 49.643 35.670676559284665 139.74197546610424 49.087 35.67067424092251 139.7419730496062 49.087</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a4bb7547-e82f-4327-93d1-19ba85175fd3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a4bb7547-e82f-4327-93d1-19ba85175fd3_0">
											<gml:posList>35.67067424092251 139.7419730496062 45.63 35.67061369291816 139.74191001113493 49.087 35.67067424092251 139.7419730496062 49.087 35.67067424092251 139.7419730496062 45.63</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-037fe7d9-dc22-46a5-ad9d-c1950e78e4f4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-037fe7d9-dc22-46a5-ad9d-c1950e78e4f4_0">
											<gml:posList>35.67061369291816 139.74191001113493 49.087 35.67061251118953 139.74190878634406 49.643 35.67067424092251 139.7419730496062 49.087 35.67061369291816 139.74191001113493 49.087</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-556c7f59-4964-4d8f-bb41-5a7c55c7956f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-556c7f59-4964-4d8f-bb41-5a7c55c7956f_0">
											<gml:posList>35.670657067878324 139.74197056166506 45.63 35.670657067878324 139.74197056166506 47.468 35.67061223445765 139.74192420728264 45.63 35.670657067878324 139.74197056166506 45.63</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3c5b69cf-1bdf-4454-ad52-44d419544e7d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3c5b69cf-1bdf-4454-ad52-44d419544e7d_0">
											<gml:posList>35.67061223445765 139.74192420728264 45.63 35.670657067878324 139.74197056166506 47.468 35.67061223445765 139.74192420728264 49.643 35.67061223445765 139.74192420728264 45.63</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6454ecfb-97a7-4684-8a27-0c600af9a373">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6454ecfb-97a7-4684-8a27-0c600af9a373_0">
											<gml:posList>35.67061223445765 139.74192420728264 49.643 35.670657067878324 139.74197056166506 47.468 35.67066552939625 139.74197931173805 49.643 35.67061223445765 139.74192420728264 49.643</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f6e1f115-5f3d-4965-a06f-56a0c6fbba4c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f6e1f115-5f3d-4965-a06f-56a0c6fbba4c_0">
											<gml:posList>35.670657067878324 139.74197056166506 47.468 35.67066552939625 139.74197931173805 47.468 35.67066552939625 139.74197931173805 49.643 35.670657067878324 139.74197056166506 47.468</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1ad49c6b-d95e-4e54-863b-45942ab12ecc">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1ad49c6b-d95e-4e54-863b-45942ab12ecc_0">
											<gml:posList>35.670657067878324 139.74197056166506 45.63 35.670649756797886 139.74198119653363 47.468 35.670657067878324 139.74197056166506 47.468 35.670657067878324 139.74197056166506 45.63</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e8599f52-877b-4671-8f18-500b11b641b5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e8599f52-877b-4671-8f18-500b11b641b5_0">
											<gml:posList>35.670657067878324 139.74197056166506 45.63 35.670649756797886 139.74198119653363 45.63 35.670649756797886 139.74198119653363 47.468 35.670657067878324 139.74197056166506 45.63</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4ea43d1b-e6a7-411c-acf2-959a041708e1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4ea43d1b-e6a7-411c-acf2-959a041708e1_0">
											<gml:posList>35.670649756797886 139.74198119653363 47.468 35.67066552939625 139.74197931173805 47.468 35.670657067878324 139.74197056166506 47.468 35.670649756797886 139.74198119653363 47.468</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1a1eab10-691d-465e-aac6-f22b7aaf2f03">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1a1eab10-691d-465e-aac6-f22b7aaf2f03_0">
											<gml:posList>35.670649756797886 139.74198119653363 47.468 35.670658092122935 139.74198994675072 47.468 35.67066552939625 139.74197931173805 47.468 35.670649756797886 139.74198119653363 47.468</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-525c7e5a-c2a8-48a6-85d3-f6a19c108bb2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-525c7e5a-c2a8-48a6-85d3-f6a19c108bb2_0">
											<gml:posList>35.6705904939761 139.7419844343415 45.63 35.67058444089915 139.74197802334484 47.784 35.6705904939761 139.7419844343415 47.784 35.6705904939761 139.7419844343415 45.63</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3f3cac15-d172-4b7b-a4de-820071070fef">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3f3cac15-d172-4b7b-a4de-820071070fef_0">
											<gml:posList>35.6705904939761 139.7419844343415 45.63 35.67058444089915 139.74197802334484 45.63 35.67058444089915 139.74197802334484 47.784 35.6705904939761 139.7419844343415 45.63</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cbc740fd-5929-4aa0-b8e6-afdee9d66411">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cbc740fd-5929-4aa0-b8e6-afdee9d66411_0">
											<gml:posList>35.67063972993189 139.74200021863237 47.123 35.67064406977027 139.7419939173 47.123 35.670617070504015 139.74196601198517 47.123 35.67063972993189 139.74200021863237 47.123</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2431c130-452b-4e2e-9170-5d4c55c65535">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2431c130-452b-4e2e-9170-5d4c55c65535_0">
											<gml:posList>35.67061273066709 139.74197231331695 47.123 35.67063972993189 139.74200021863237 47.123 35.670617070504015 139.74196601198517 47.123 35.67061273066709 139.74197231331695 47.123</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-68b9a559-1f84-4296-90d4-b43c4905a19e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-68b9a559-1f84-4296-90d4-b43c4905a19e_0">
											<gml:posList>35.67060470232663 139.74198800819775 45.63 35.670598035830665 139.7419809572138 46.262 35.67060470232663 139.74198800819775 46.262 35.67060470232663 139.74198800819775 45.63</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f9cf7a40-8e17-4a59-8a11-1fb54de7e45f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f9cf7a40-8e17-4a59-8a11-1fb54de7e45f_0">
											<gml:posList>35.67060470232663 139.74198800819775 45.63 35.670598035830665 139.7419809572138 45.63 35.670598035830665 139.7419809572138 46.262 35.67060470232663 139.74198800819775 45.63</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b5f7f675-f76d-4128-97fc-f767be596dee">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b5f7f675-f76d-4128-97fc-f767be596dee_0">
											<gml:posList>35.670649756797886 139.74198119653363 45.63 35.670658092122935 139.74198994675072 47.468 35.670649756797886 139.74198119653363 47.468 35.670649756797886 139.74198119653363 45.63</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-111d8ae4-6bb0-4925-853d-4eb8c32e6561">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-111d8ae4-6bb0-4925-853d-4eb8c32e6561_0">
											<gml:posList>35.670649756797886 139.74198119653363 45.63 35.670658092122935 139.74198994675072 45.63 35.670658092122935 139.74198994675072 47.468 35.670649756797886 139.74198119653363 45.63</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8360bd14-225c-4808-96f6-96c66a8cbf18">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8360bd14-225c-4808-96f6-96c66a8cbf18_0">
											<gml:posList>35.67059926027544 139.74199096375725 45.63 35.67060119076229 139.74199300512157 46.262 35.67059926027544 139.74199096375725 46.262 35.67059926027544 139.74199096375725 45.63</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6571be26-36c8-4597-9234-7c7bf06d8fed">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6571be26-36c8-4597-9234-7c7bf06d8fed_0">
											<gml:posList>35.67059926027544 139.74199096375725 45.63 35.67060119076229 139.74199300512157 45.63 35.67060119076229 139.74199300512157 46.262 35.67059926027544 139.74199096375725 45.63</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-87b531c2-31bc-4d0d-872a-afd2390606f9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-87b531c2-31bc-4d0d-872a-afd2390606f9_0">
											<gml:posList>35.670637875149374 139.74200291604126 47.123 35.670610875885174 139.74197501072555 47.123 35.67060591479647 139.74198222960635 47.123 35.670637875149374 139.74200291604126 47.123</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-761ce5a4-77be-4214-84e2-71dd13abac4a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-761ce5a4-77be-4214-84e2-71dd13abac4a_0">
											<gml:posList>35.67063291405901 139.74201013492277 47.123 35.670637875149374 139.74200291604126 47.123 35.67060591479647 139.74198222960635 47.123 35.67063291405901 139.74201013492277 47.123</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-73a13819-348a-406c-b62f-c4c0f228249d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-73a13819-348a-406c-b62f-c4c0f228249d_0">
											<gml:posList>35.670495356111736 139.74208225808857 49.087 35.67061369291816 139.74191001113493 45.63 35.670495356111736 139.74208225808857 45.63 35.670495356111736 139.74208225808857 49.087</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8567abde-9d81-4a44-b35b-bf7a0daf824e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8567abde-9d81-4a44-b35b-bf7a0daf824e_0">
											<gml:posList>35.670495356111736 139.74208225808857 49.087 35.67061369291816 139.74191001113493 49.087 35.67061369291816 139.74191001113493 45.63 35.670495356111736 139.74208225808857 49.087</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2fa6c4e1-c944-43e6-902b-3f61868cba27">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2fa6c4e1-c944-43e6-902b-3f61868cba27_0">
											<gml:posList>35.67060591479647 139.74198222960635 45.63 35.67063291405901 139.74201013492277 47.123 35.67060591479647 139.74198222960635 47.123 35.67060591479647 139.74198222960635 45.63</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-344691ec-66ba-4ae6-bfcf-b6d797b533b7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-344691ec-66ba-4ae6-bfcf-b6d797b533b7_0">
											<gml:posList>35.67060591479647 139.74198222960635 45.63 35.67063291405901 139.74201013492277 45.63 35.67063291405901 139.74201013492277 47.123 35.67060591479647 139.74198222960635 45.63</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d5044ce5-d1d2-4fe8-83ae-d374a90311f7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d5044ce5-d1d2-4fe8-83ae-d374a90311f7_0">
											<gml:posList>35.67049371742228 139.74208464594903 49.087 35.67061251118953 139.74190878634406 49.643 35.67061251118953 139.74190878634406 49.087 35.67049371742228 139.74208464594903 49.087</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f0e14aff-e436-4b42-bf78-50f91e410a90">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f0e14aff-e436-4b42-bf78-50f91e410a90_0">
											<gml:posList>35.67049371742228 139.74208464594903 49.087 35.67049371742228 139.74208464594903 49.643 35.67061251118953 139.74190878634406 49.643 35.67049371742228 139.74208464594903 49.087</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c022ce4b-b663-4a9f-942a-021afd54b053">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c022ce4b-b663-4a9f-942a-021afd54b053_0">
											<gml:posList>35.6705904939761 139.7419844343415 47.784 35.67058444089915 139.74197802334484 47.784 35.67055973384718 139.74201312344934 47.784 35.6705904939761 139.7419844343415 47.784</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-44146bc4-f0bb-4cbc-9abc-f81757b2ef79">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-44146bc4-f0bb-4cbc-9abc-f81757b2ef79_0">
											<gml:posList>35.6705657869223 139.74201953444668 47.784 35.6705904939761 139.7419844343415 47.784 35.67055973384718 139.74201312344934 47.784 35.6705657869223 139.74201953444668 47.784</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e719a5a8-02d8-43b8-8902-83c665d1ced3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e719a5a8-02d8-43b8-8902-83c665d1ced3_0">
											<gml:posList>35.67060119076229 139.74199300512157 46.262 35.67060470232663 139.74198800819775 46.262 35.67059926027544 139.74199096375725 46.262 35.67060119076229 139.74199300512157 46.262</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c57dabb1-4cd0-40e2-a484-7975b6a9c113">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c57dabb1-4cd0-40e2-a484-7975b6a9c113_0">
											<gml:posList>35.67057557067314 139.742024615642 46.262 35.67059926027544 139.74199096375725 46.262 35.67057082565197 139.74201960603204 46.262 35.67057557067314 139.742024615642 46.262</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2f82c11c-2fd2-438e-8991-8f3dde403900">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2f82c11c-2fd2-438e-8991-8f3dde403900_0">
											<gml:posList>35.67057082565197 139.74201960603204 46.262 35.67059926027544 139.74199096375725 46.262 35.670598035830665 139.7419809572138 46.262 35.67057082565197 139.74201960603204 46.262</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-26267f23-d7f5-4358-98c2-e252101e7287">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-26267f23-d7f5-4358-98c2-e252101e7287_0">
											<gml:posList>35.67059926027544 139.74199096375725 46.262 35.67060470232663 139.74198800819775 46.262 35.670598035830665 139.7419809572138 46.262 35.67059926027544 139.74199096375725 46.262</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e3153b90-de83-42d1-b588-d800965a9a70">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e3153b90-de83-42d1-b588-d800965a9a70_0">
											<gml:posList>35.67055973384718 139.74201312344934 45.63 35.6705657869223 139.74201953444668 47.784 35.67055973384718 139.74201312344934 47.784 35.67055973384718 139.74201312344934 45.63</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4f06bbc5-5038-42df-a286-d7db106e5b22">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4f06bbc5-5038-42df-a286-d7db106e5b22_0">
											<gml:posList>35.67055973384718 139.74201312344934 45.63 35.6705657869223 139.74201953444668 45.63 35.6705657869223 139.74201953444668 47.784 35.67055973384718 139.74201312344934 45.63</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-55a385ff-faa0-40e5-9689-0e8dabcd6b4e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-55a385ff-faa0-40e5-9689-0e8dabcd6b4e_0">
											<gml:posList>35.67057082565197 139.74201960603204 45.63 35.67057557067314 139.742024615642 46.262 35.67057082565197 139.74201960603204 46.262 35.67057082565197 139.74201960603204 45.63</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-637e6e29-4836-4ea6-a543-16a5b818b086">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-637e6e29-4836-4ea6-a543-16a5b818b086_0">
											<gml:posList>35.67057082565197 139.74201960603204 45.63 35.67057557067314 139.742024615642 45.63 35.67057557067314 139.742024615642 46.262 35.67057082565197 139.74201960603204 45.63</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a4355a82-791f-4e07-bb90-cca03663a2f6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a4355a82-791f-4e07-bb90-cca03663a2f6_0">
											<gml:posList>35.67066552939625 139.74197931173805 49.643 35.67055503257364 139.74214909750998 49.643 35.670676559284665 139.74197546610424 49.643 35.67066552939625 139.74197931173805 49.643</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6f1b4865-8fdd-4c61-8fcc-d4432c2be76c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6f1b4865-8fdd-4c61-8fcc-d4432c2be76c_0">
											<gml:posList>35.67061223445765 139.74192420728264 49.643 35.670676559284665 139.74197546610424 49.643 35.67061251118953 139.74190878634406 49.643 35.67061223445765 139.74192420728264 49.643</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d4739794-404e-4d2d-9350-7cc78305f9f7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d4739794-404e-4d2d-9350-7cc78305f9f7_0">
											<gml:posList>35.670506155547955 139.7420835603045 49.643 35.67049371742228 139.74208464594903 49.643 35.67055503257364 139.74214909750998 49.643 35.670506155547955 139.7420835603045 49.643</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7dc3cb90-daa7-474b-b581-3b39ee52775a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7dc3cb90-daa7-474b-b581-3b39ee52775a_0">
											<gml:posList>35.67061223445765 139.74192420728264 49.643 35.67061251118953 139.74190878634406 49.643 35.67049371742228 139.74208464594903 49.643 35.67061223445765 139.74192420728264 49.643</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-85f270d0-95d6-418f-b758-0261924ed02a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-85f270d0-95d6-418f-b758-0261924ed02a_0">
											<gml:posList>35.670676559284665 139.74197546610424 49.643 35.67061223445765 139.74192420728264 49.643 35.67066552939625 139.74197931173805 49.643 35.670676559284665 139.74197546610424 49.643</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ca8aed1a-f358-4870-af60-4c9398182c82">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ca8aed1a-f358-4870-af60-4c9398182c82_0">
											<gml:posList>35.67055594196819 139.74213588512032 49.643 35.67055503257364 139.74214909750998 49.643 35.67066552939625 139.74197931173805 49.643 35.67055594196819 139.74213588512032 49.643</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a1670f8a-068b-4f2b-a351-62a26092612c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a1670f8a-068b-4f2b-a351-62a26092612c_0">
											<gml:posList>35.670506155547955 139.7420835603045 49.643 35.67055503257364 139.74214909750998 49.643 35.67055594196819 139.74213588512032 49.643 35.670506155547955 139.7420835603045 49.643</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4a9f2837-9241-4a79-a644-e0b2b066daf1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4a9f2837-9241-4a79-a644-e0b2b066daf1_0">
											<gml:posList>35.67061223445765 139.74192420728264 49.643 35.67049371742228 139.74208464594903 49.643 35.670506155547955 139.7420835603045 49.643 35.67061223445765 139.74192420728264 49.643</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fb12d4c4-095f-413b-8c56-b62d3cce4362">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fb12d4c4-095f-413b-8c56-b62d3cce4362_0">
											<gml:posList>35.670555994189485 139.74214532963356 45.63 35.67067424092251 139.7419730496062 49.087 35.670555994189485 139.74214532963356 49.087 35.670555994189485 139.74214532963356 45.63</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-43010528-7873-4fe2-b68c-e565af2dabe9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-43010528-7873-4fe2-b68c-e565af2dabe9_0">
											<gml:posList>35.670555994189485 139.74214532963356 45.63 35.67067424092251 139.7419730496062 45.63 35.67067424092251 139.7419730496062 49.087 35.670555994189485 139.74214532963356 45.63</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6798a35b-30c0-49bc-ac90-9755ccf41e0b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6798a35b-30c0-49bc-ac90-9755ccf41e0b_0">
											<gml:posList>35.67055503257364 139.74214909750998 49.087 35.670676559284665 139.74197546610424 49.643 35.67055503257364 139.74214909750998 49.643 35.67055503257364 139.74214909750998 49.087</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-aaff01a2-22fd-4293-b66a-3e71032bc070">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-aaff01a2-22fd-4293-b66a-3e71032bc070_0">
											<gml:posList>35.67055503257364 139.74214909750998 49.087 35.670676559284665 139.74197546610424 49.087 35.670676559284665 139.74197546610424 49.643 35.67055503257364 139.74214909750998 49.087</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-008c1f6a-1c39-4020-a004-0320242c5aff">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-008c1f6a-1c39-4020-a004-0320242c5aff_0">
											<gml:posList>35.67055594196819 139.74213588512032 45.63 35.670506155547955 139.7420835603045 49.643 35.67055594196819 139.74213588512032 49.643 35.67055594196819 139.74213588512032 45.63</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-94d03a5f-02ef-411b-a3f6-d511d5c0ecad">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-94d03a5f-02ef-411b-a3f6-d511d5c0ecad_0">
											<gml:posList>35.67055594196819 139.74213588512032 45.63 35.670506155547955 139.7420835603045 45.63 35.670506155547955 139.7420835603045 49.643 35.67055594196819 139.74213588512032 45.63</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cae6b762-cdab-4b1a-a9be-383f487cbefd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cae6b762-cdab-4b1a-a9be-383f487cbefd_0">
											<gml:posList>35.670495356111736 139.74208225808857 49.087 35.670555994189485 139.74214532963356 45.63 35.670555994189485 139.74214532963356 49.087 35.670495356111736 139.74208225808857 49.087</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-490d7f50-47ba-4286-bc97-1094a67c0282">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-490d7f50-47ba-4286-bc97-1094a67c0282_0">
											<gml:posList>35.670495356111736 139.74208225808857 49.087 35.670495356111736 139.74208225808857 45.63 35.670555994189485 139.74214532963356 45.63 35.670495356111736 139.74208225808857 49.087</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-885f99a1-a64f-4d3b-bb3d-c526732ca49e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-885f99a1-a64f-4d3b-bb3d-c526732ca49e_0">
											<gml:posList>35.67049371742228 139.74208464594903 49.087 35.67055503257364 139.74214909750998 49.643 35.67049371742228 139.74208464594903 49.643 35.67049371742228 139.74208464594903 49.087</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6b27b34b-ce20-4302-aebd-c0a7f57b5f7b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6b27b34b-ce20-4302-aebd-c0a7f57b5f7b_0">
											<gml:posList>35.67049371742228 139.74208464594903 49.087 35.67055503257364 139.74214909750998 49.087 35.67055503257364 139.74214909750998 49.643 35.67049371742228 139.74208464594903 49.087</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d8e2acac-0773-4e6a-875a-52e54d3dba2c">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67063972993189 139.74200021863237 45.63 35.67061273066709 139.74197231331695 45.63 35.670617070504015 139.74196601198517 45.63 35.67063972993189 139.74200021863237 45.63</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6c40d7fb-8b1c-4c48-9fd9-d55294b028ce">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67064406977027 139.7419939173 45.63 35.67063972993189 139.74200021863237 45.63 35.670617070504015 139.74196601198517 45.63 35.67064406977027 139.7419939173 45.63</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-de2702ce-af83-4834-8816-436a85c659ce">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67061273066709 139.74197231331695 45.63 35.67063972993189 139.74200021863237 47.123 35.67061273066709 139.74197231331695 47.123 35.67061273066709 139.74197231331695 45.63</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-65d72b5d-2218-470d-8650-2489cdfcd83d">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67061273066709 139.74197231331695 45.63 35.67063972993189 139.74200021863237 45.63 35.67063972993189 139.74200021863237 47.123 35.67061273066709 139.74197231331695 45.63</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-04d68011-e8b2-47ac-879a-4b6c75fc785f">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670610875885174 139.74197501072555 45.63 35.670637875149374 139.74200291604126 47.123 35.670637875149374 139.74200291604126 45.63 35.670610875885174 139.74197501072555 45.63</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-587df612-13f8-4aeb-ae35-bbe98f6c373b">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670610875885174 139.74197501072555 45.63 35.670610875885174 139.74197501072555 47.123 35.670637875149374 139.74200291604126 47.123 35.670610875885174 139.74197501072555 45.63</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e202d508-90d7-4573-a87a-196b1138c40a">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67060591479647 139.74198222960635 45.63 35.670610875885174 139.74197501072555 45.63 35.670637875149374 139.74200291604126 45.63 35.67060591479647 139.74198222960635 45.63</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-128c15d1-711c-4444-a0d2-faf3b1e316bb">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67063291405901 139.74201013492277 45.63 35.67060591479647 139.74198222960635 45.63 35.670637875149374 139.74200291604126 45.63 35.67063291405901 139.74201013492277 45.63</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fb638ec8-59b6-4ef5-93c0-83363e66c9da">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6705904939761 139.7419844343415 45.63 35.6705657869223 139.74201953444668 45.63 35.67055973384718 139.74201312344934 45.63 35.6705904939761 139.7419844343415 45.63</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-506a3e58-12df-4cb2-b4be-17feccc5a018">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67058444089915 139.74197802334484 45.63 35.6705904939761 139.7419844343415 45.63 35.67055973384718 139.74201312344934 45.63 35.67058444089915 139.74197802334484 45.63</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-95e0d354-d202-4032-a624-3f4760e602bc">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67060119076229 139.74199300512157 45.63 35.67059926027544 139.74199096375725 45.63 35.67060470232663 139.74198800819775 45.63 35.67060119076229 139.74199300512157 45.63</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9026c6a6-e264-4af8-92b0-1d0027f3ef64">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67060470232663 139.74198800819775 45.63 35.67059926027544 139.74199096375725 45.63 35.670598035830665 139.7419809572138 45.63 35.67060470232663 139.74198800819775 45.63</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bf97dc55-162e-486a-b878-ae7ed8b2b96c">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670598035830665 139.7419809572138 45.63 35.67059926027544 139.74199096375725 45.63 35.67057082565197 139.74201960603204 45.63 35.670598035830665 139.7419809572138 45.63</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-172dbed7-67cf-40ae-9a29-37ab62f70999">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67059926027544 139.74199096375725 45.63 35.67057557067314 139.742024615642 45.63 35.67057082565197 139.74201960603204 45.63 35.67059926027544 139.74199096375725 45.63</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ae565c87-cdc1-438c-8b30-fbb1cd10a685">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67061369291816 139.74191001113493 45.63 35.67067424092251 139.7419730496062 45.63 35.670657067878324 139.74197056166506 45.63 35.67061369291816 139.74191001113493 45.63</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c49f0ba4-190e-42fe-afb0-0f438a35eea2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670555994189485 139.74214532963356 45.63 35.670658092122935 139.74198994675072 45.63 35.67067424092251 139.7419730496062 45.63 35.670555994189485 139.74214532963356 45.63</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9302d972-5db2-4de0-9e7b-5c1fe6bfabc4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670495356111736 139.74208225808857 45.63 35.67061369291816 139.74191001113493 45.63 35.67061223445765 139.74192420728264 45.63 35.670495356111736 139.74208225808857 45.63</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5ef190fb-b2f5-4e60-8f7e-328cd0a97018">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670506155547955 139.7420835603045 45.63 35.670555994189485 139.74214532963356 45.63 35.670495356111736 139.74208225808857 45.63 35.670506155547955 139.7420835603045 45.63</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d2f1e483-a7eb-41ee-8c27-521b72a9b819">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67061223445765 139.74192420728264 45.63 35.67061369291816 139.74191001113493 45.63 35.670657067878324 139.74197056166506 45.63 35.67061223445765 139.74192420728264 45.63</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-25f40295-4b1b-43e2-96f3-7e9f02b331c2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67067424092251 139.7419730496062 45.63 35.670658092122935 139.74198994675072 45.63 35.670657067878324 139.74197056166506 45.63 35.67067424092251 139.7419730496062 45.63</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2083b010-8d5f-4906-ab78-7c443c95106b">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670555994189485 139.74214532963356 45.63 35.67055594196819 139.74213588512032 45.63 35.670658092122935 139.74198994675072 45.63 35.670555994189485 139.74214532963356 45.63</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f57aa3dd-6bc2-4d7a-973f-9446b36a0659">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670506155547955 139.7420835603045 45.63 35.670495356111736 139.74208225808857 45.63 35.67061223445765 139.74192420728264 45.63 35.670506155547955 139.7420835603045 45.63</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-80de2098-fa6e-4a66-89dc-c549e613ed35">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67055594196819 139.74213588512032 45.63 35.670555994189485 139.74214532963356 45.63 35.670506155547955 139.7420835603045 45.63 35.67055594196819 139.74213588512032 45.63</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a6b80a9e-f0e9-4cdf-9539-71510cce8852">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670657067878324 139.74197056166506 45.63 35.670658092122935 139.74198994675072 45.63 35.670649756797886 139.74198119653363 45.63 35.670657067878324 139.74197056166506 45.63</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ba9ef2f5-431c-4ffd-801a-41b8aa6510a7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67061251118953 139.74190878634406 49.087 35.67061369291816 139.74191001113493 49.087 35.670495356111736 139.74208225808857 49.087 35.67061251118953 139.74190878634406 49.087</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-67f8e0fc-8a2b-46cc-8f4b-cd121edb5655">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67067424092251 139.7419730496062 49.087 35.670676559284665 139.74197546610424 49.087 35.670555994189485 139.74214532963356 49.087 35.67067424092251 139.7419730496062 49.087</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fadb9a4b-9737-4f2f-97bf-a92d215d5d51">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670495356111736 139.74208225808857 49.087 35.670555994189485 139.74214532963356 49.087 35.67049371742228 139.74208464594903 49.087 35.670495356111736 139.74208225808857 49.087</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8ea56b80-5a80-4553-a7a8-447462df5b07">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67061251118953 139.74190878634406 49.087 35.670495356111736 139.74208225808857 49.087 35.67049371742228 139.74208464594903 49.087 35.67061251118953 139.74190878634406 49.087</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-56438d9d-0d32-42b7-8fff-eaa3643b1a53">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670555994189485 139.74214532963356 49.087 35.670676559284665 139.74197546610424 49.087 35.67055503257364 139.74214909750998 49.087 35.670555994189485 139.74214532963356 49.087</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e81e39b2-4ce4-49ed-adc1-bd532a8134f7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67049371742228 139.74208464594903 49.087 35.670555994189485 139.74214532963356 49.087 35.67055503257364 139.74214909750998 49.087 35.67049371742228 139.74208464594903 49.087</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-7a75f24b-db53-44b5-8cce-cdb212fd465f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7a75f24b-db53-44b5-8cce-cdb212fd465f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7a75f24b-db53-44b5-8cce-cdb212fd465f">
											<gml:posList>35.670490119540524 139.74208279426958 7.685 35.67061338141089 139.7419033726688 7.685 35.6706535604472 139.7419453690578 7.685 35.67066461626921 139.7419281905077 7.685 35.670691119361756 139.74195553303036 7.685 35.67055642270288 139.74215175808345 7.685 35.670490119540524 139.74208279426958 7.685</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-13134ffb-e264-4dd0-8157-c4bd26cd856b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-13134ffb-e264-4dd0-8157-c4bd26cd856b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-13134ffb-e264-4dd0-8157-c4bd26cd856b">
											<gml:posList>35.670490119540524 139.74208279426958 49.087 35.670495356111736 139.74208225808857 49.087 35.6706138189677 139.74190982320425 49.087 35.67061338141089 139.7419033726688 49.087 35.670490119540524 139.74208279426958 49.087</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a2963e44-74ae-4a25-81fd-f922e967efc5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a2963e44-74ae-4a25-81fd-f922e967efc5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a2963e44-74ae-4a25-81fd-f922e967efc5">
											<gml:posList>35.670555994189485 139.74214532963356 45.63 35.67068588280806 139.74195609131357 45.63 35.67066516204805 139.74193471824813 45.63 35.67065408821443 139.74195191891056 45.63 35.6706138189677 139.74190982320425 45.63 35.670495356111736 139.74208225808857 45.63 35.670555994189485 139.74214532963356 45.63</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-aa7790cd-c870-4c21-b313-9aef86656871">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-aa7790cd-c870-4c21-b313-9aef86656871">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-aa7790cd-c870-4c21-b313-9aef86656871">
											<gml:posList>35.67055642270288 139.74215175808345 49.087 35.670555994189485 139.74214532963356 49.087 35.670495356111736 139.74208225808857 49.087 35.670490119540524 139.74208279426958 49.087 35.67055642270288 139.74215175808345 49.087</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c47c1c43-fdae-476f-8ea0-48429c3822c9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c47c1c43-fdae-476f-8ea0-48429c3822c9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c47c1c43-fdae-476f-8ea0-48429c3822c9">
											<gml:posList>35.6706535604472 139.7419453690578 49.087 35.67061338141089 139.7419033726688 49.087 35.6706138189677 139.74190982320425 49.087 35.67065408821443 139.74195191891056 49.087 35.6706535604472 139.7419453690578 49.087</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-094e149f-a172-40b5-b3f9-c86a5618078c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-094e149f-a172-40b5-b3f9-c86a5618078c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-094e149f-a172-40b5-b3f9-c86a5618078c">
											<gml:posList>35.6706535604472 139.7419453690578 49.087 35.67065408821443 139.74195191891056 49.087 35.67066516204805 139.74193471824813 49.087 35.67066461626921 139.7419281905077 49.087 35.6706535604472 139.7419453690578 49.087</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-dd55ff14-ac6b-4635-8ee3-8b232a3386ab">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-dd55ff14-ac6b-4635-8ee3-8b232a3386ab">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-dd55ff14-ac6b-4635-8ee3-8b232a3386ab">
											<gml:posList>35.67066461626921 139.7419281905077 49.087 35.67066516204805 139.74193471824813 49.087 35.67068588280806 139.74195609131357 49.087 35.670691119361756 139.74195553303036 49.087 35.67066461626921 139.7419281905077 49.087</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-20e770be-ccbb-4546-8bb4-189f3f387978">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-20e770be-ccbb-4546-8bb4-189f3f387978">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-20e770be-ccbb-4546-8bb4-189f3f387978">
											<gml:posList>35.670691119361756 139.74195553303036 49.087 35.67068588280806 139.74195609131357 49.087 35.670555994189485 139.74214532963356 49.087 35.67055642270288 139.74215175808345 49.087 35.670691119361756 139.74195553303036 49.087</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a08278d5-6a15-4005-b71d-1898eacfc1b8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a08278d5-6a15-4005-b71d-1898eacfc1b8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a08278d5-6a15-4005-b71d-1898eacfc1b8">
											<gml:posList>35.670495356111736 139.74208225808857 49.087 35.670495356111736 139.74208225808857 45.63 35.6706138189677 139.74190982320425 45.63 35.6706138189677 139.74190982320425 49.087 35.670495356111736 139.74208225808857 49.087</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-dcb3647d-e5a7-4169-890c-6ba9ffdf2982">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-dcb3647d-e5a7-4169-890c-6ba9ffdf2982">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-dcb3647d-e5a7-4169-890c-6ba9ffdf2982">
											<gml:posList>35.670490119540524 139.74208279426958 7.685 35.67055642270288 139.74215175808345 7.685 35.67055642270288 139.74215175808345 49.087 35.670490119540524 139.74208279426958 49.087 35.670490119540524 139.74208279426958 7.685</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ed3a7f51-6468-45aa-a7af-e0cc35dca0a3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ed3a7f51-6468-45aa-a7af-e0cc35dca0a3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ed3a7f51-6468-45aa-a7af-e0cc35dca0a3">
											<gml:posList>35.670555994189485 139.74214532963356 49.087 35.670555994189485 139.74214532963356 45.63 35.670495356111736 139.74208225808857 45.63 35.670495356111736 139.74208225808857 49.087 35.670555994189485 139.74214532963356 49.087</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-accb606d-a51f-4633-8269-0b74b4fd94a2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-accb606d-a51f-4633-8269-0b74b4fd94a2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-accb606d-a51f-4633-8269-0b74b4fd94a2">
											<gml:posList>35.67061338141089 139.7419033726688 7.685 35.670490119540524 139.74208279426958 7.685 35.670490119540524 139.74208279426958 49.087 35.67061338141089 139.7419033726688 49.087 35.67061338141089 139.7419033726688 7.685</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-577b7f39-4a07-4d8d-974a-b70ea268c87b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-577b7f39-4a07-4d8d-974a-b70ea268c87b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-577b7f39-4a07-4d8d-974a-b70ea268c87b">
											<gml:posList>35.67068588280806 139.74195609131357 49.087 35.67068588280806 139.74195609131357 45.63 35.670555994189485 139.74214532963356 45.63 35.670555994189485 139.74214532963356 49.087 35.67068588280806 139.74195609131357 49.087</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c77b6977-7487-4430-a247-e1b06497c6b2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c77b6977-7487-4430-a247-e1b06497c6b2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c77b6977-7487-4430-a247-e1b06497c6b2">
											<gml:posList>35.67055642270288 139.74215175808345 7.685 35.670691119361756 139.74195553303036 7.685 35.670691119361756 139.74195553303036 49.087 35.67055642270288 139.74215175808345 49.087 35.67055642270288 139.74215175808345 7.685</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7ac8c336-bc32-4061-90a8-c65593210c43">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7ac8c336-bc32-4061-90a8-c65593210c43">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7ac8c336-bc32-4061-90a8-c65593210c43">
											<gml:posList>35.6706535604472 139.7419453690578 7.685 35.67061338141089 139.7419033726688 7.685 35.67061338141089 139.7419033726688 49.087 35.6706535604472 139.7419453690578 49.087 35.6706535604472 139.7419453690578 7.685</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f1421120-ab6b-4a8b-a4d7-162b57d6f58f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f1421120-ab6b-4a8b-a4d7-162b57d6f58f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f1421120-ab6b-4a8b-a4d7-162b57d6f58f">
											<gml:posList>35.6706138189677 139.74190982320425 49.087 35.6706138189677 139.74190982320425 45.63 35.67065408821443 139.74195191891056 45.63 35.67065408821443 139.74195191891056 49.087 35.6706138189677 139.74190982320425 49.087</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d1b27f72-a18d-4fd9-9391-ce2cdfaee82f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d1b27f72-a18d-4fd9-9391-ce2cdfaee82f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d1b27f72-a18d-4fd9-9391-ce2cdfaee82f">
											<gml:posList>35.67066461626921 139.7419281905077 7.685 35.6706535604472 139.7419453690578 7.685 35.6706535604472 139.7419453690578 49.087 35.67066461626921 139.7419281905077 49.087 35.67066461626921 139.7419281905077 7.685</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c7c42e7e-35ec-4a2a-a61c-66c7ae56e2b0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c7c42e7e-35ec-4a2a-a61c-66c7ae56e2b0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c7c42e7e-35ec-4a2a-a61c-66c7ae56e2b0">
											<gml:posList>35.67065408821443 139.74195191891056 49.087 35.67065408821443 139.74195191891056 45.63 35.67066516204805 139.74193471824813 45.63 35.67066516204805 139.74193471824813 49.087 35.67065408821443 139.74195191891056 49.087</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-44c58d86-2acb-490b-932e-7c501cc2e531">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-44c58d86-2acb-490b-932e-7c501cc2e531">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-44c58d86-2acb-490b-932e-7c501cc2e531">
											<gml:posList>35.67066516204805 139.74193471824813 49.087 35.67066516204805 139.74193471824813 45.63 35.67068588280806 139.74195609131357 45.63 35.67068588280806 139.74195609131357 49.087 35.67066516204805 139.74193471824813 49.087</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5274d02d-3d5d-4709-afa1-d333b6ea064c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5274d02d-3d5d-4709-afa1-d333b6ea064c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5274d02d-3d5d-4709-afa1-d333b6ea064c">
											<gml:posList>35.670691119361756 139.74195553303036 7.685 35.67066461626921 139.7419281905077 7.685 35.67066461626921 139.7419281905077 49.087 35.670691119361756 139.74195553303036 49.087 35.670691119361756 139.74195553303036 7.685</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-6094</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">223.6149</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1210</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>7</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.03</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>