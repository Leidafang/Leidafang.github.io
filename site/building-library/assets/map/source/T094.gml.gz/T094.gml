<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_186a92b6-6171-45f3-8fab-2226b28f802d">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001001</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">401</bldg:usage>
			<bldg:measuredHeight uom="m">17</bldg:measuredHeight>
			<bldg:storeysAboveGround>4</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.66905715619574 139.74189752545448 0 35.6690438264087 139.7420302040218 0 35.669186079403225 139.74205169238328 0 35.669199409213334 139.74191901358404 0 35.66905715619574 139.74189752545448 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66905715619574 139.74189752545448 9.99 35.669199409213334 139.74191901358404 9.99 35.669186079403225 139.74205169238328 9.99 35.6690438264087 139.7420302040218 9.99 35.66905715619574 139.74189752545448 9.99</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66905715619574 139.74189752545448 9.99 35.6690438264087 139.7420302040218 9.99 35.6690438264087 139.7420302040218 26.97 35.66905715619574 139.74189752545448 26.97 35.66905715619574 139.74189752545448 9.99</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6690438264087 139.7420302040218 9.99 35.669186079403225 139.74205169238328 9.99 35.669186079403225 139.74205169238328 26.97 35.6690438264087 139.7420302040218 26.97 35.6690438264087 139.7420302040218 9.99</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669186079403225 139.74205169238328 9.99 35.669199409213334 139.74191901358404 9.99 35.669199409213334 139.74191901358404 26.97 35.669186079403225 139.74205169238328 26.97 35.669186079403225 139.74205169238328 9.99</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669199409213334 139.74191901358404 9.99 35.66905715619574 139.74189752545448 9.99 35.66905715619574 139.74189752545448 26.97 35.669199409213334 139.74191901358404 26.97 35.669199409213334 139.74191901358404 9.99</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66905715619574 139.74189752545448 26.97 35.6690438264087 139.7420302040218 26.97 35.669186079403225 139.74205169238328 26.97 35.669199409213334 139.74191901358404 26.97 35.66905715619574 139.74189752545448 26.97</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-bcbb468a-c09b-43a2-99d0-d13642eb4be0"/>
							<gml:surfaceMember xlink:href="#poly-c38970f0-901a-444b-9415-575043a2155f"/>
							<gml:surfaceMember xlink:href="#poly-8c9c2cd2-a72c-400b-ae06-247a61b81cfc"/>
							<gml:surfaceMember xlink:href="#poly-873de489-5332-4dfb-b59b-0184cbb53fb5"/>
							<gml:surfaceMember xlink:href="#poly-db5d445e-ecd6-418c-83b1-b90d6eefbb16"/>
							<gml:surfaceMember xlink:href="#poly-657cccef-91fd-4221-bfe5-894cc4f52656"/>
							<gml:surfaceMember xlink:href="#poly-e6178998-4f15-4e62-bc70-469c9bad6043"/>
							<gml:surfaceMember xlink:href="#poly-908c6df4-90fa-48be-9b62-051065ee2d23"/>
							<gml:surfaceMember xlink:href="#poly-d7b146d6-2c21-41c5-9547-e84ec1a045b7"/>
							<gml:surfaceMember xlink:href="#poly-e71d7f44-c91f-4cf3-a099-b545accdb52b"/>
							<gml:surfaceMember xlink:href="#poly-7ead591a-d8cb-4569-8de9-9f333986186e"/>
							<gml:surfaceMember xlink:href="#poly-2f5f6f1f-1863-4826-a479-6bf6a3b113d1"/>
							<gml:surfaceMember xlink:href="#poly-032d5885-c64a-41cf-b524-effd7cd704ae"/>
							<gml:surfaceMember xlink:href="#poly-05618d14-b866-4a59-93c0-be7480c60936"/>
							<gml:surfaceMember xlink:href="#poly-32b39ba0-6fce-499f-8911-0e44e4b10b3e"/>
							<gml:surfaceMember xlink:href="#poly-e3c6baa1-ff92-4031-babb-7c27391b0a0e"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_186a92b6-6171-45f3-8fab-2226b28f802d_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4fb5b4d4-bd35-4d44-8e34-72cb069486c3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66917268190338 139.74198818155338 26.222 35.6691746824345 139.7419518597188 26.222 35.66918688778918 139.74195286204926 26.222 35.66918488726616 139.7419891949354 26.222 35.66917268190338 139.74198818155338 26.222</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-29faaec4-44c2-4f19-be5b-8cc8a8c63915">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-29faaec4-44c2-4f19-be5b-8cc8a8c63915_0">
											<gml:posList>35.6691746824345 139.7419518597188 26.222 35.6691746824345 139.7419518597188 28.514 35.66918688778918 139.74195286204926 28.514 35.66918688778918 139.74195286204926 26.222 35.6691746824345 139.7419518597188 26.222</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-453a6748-23ef-4113-85a3-c065211b4882">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-453a6748-23ef-4113-85a3-c065211b4882_0">
											<gml:posList>35.66917268190338 139.74198818155338 28.514 35.6691746824345 139.7419518597188 28.514 35.6691746824345 139.7419518597188 26.222 35.66917268190338 139.74198818155338 26.222 35.66917268190338 139.74198818155338 28.514</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c3d25061-ccee-47c4-827f-c41c1d25e645">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c3d25061-ccee-47c4-827f-c41c1d25e645_0">
											<gml:posList>35.66918688778918 139.74195286204926 28.514 35.6691746824345 139.7419518597188 28.514 35.66917268190338 139.74198818155338 28.514 35.66918488726616 139.7419891949354 28.514 35.66918688778918 139.74195286204926 28.514</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fcdfc320-3f9d-4c14-accc-8808d483a2ea">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fcdfc320-3f9d-4c14-accc-8808d483a2ea_0">
											<gml:posList>35.66918688778918 139.74195286204926 26.222 35.66918688778918 139.74195286204926 28.514 35.66918488726616 139.7419891949354 28.514 35.66918488726616 139.7419891949354 26.222 35.66918688778918 139.74195286204926 26.222</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3327aaff-21db-4a6f-937a-61c5a527430d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3327aaff-21db-4a6f-937a-61c5a527430d_0">
											<gml:posList>35.66918488726616 139.7419891949354 28.514 35.66917268190338 139.74198818155338 28.514 35.66917268190338 139.74198818155338 26.222 35.66918488726616 139.7419891949354 26.222 35.66918488726616 139.7419891949354 28.514</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-bcbb468a-c09b-43a2-99d0-d13642eb4be0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bcbb468a-c09b-43a2-99d0-d13642eb4be0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bcbb468a-c09b-43a2-99d0-d13642eb4be0">
											<gml:posList>35.669057156195755 139.74189752545445 9.99 35.66919940921333 139.74191901358404 9.99 35.669186079403225 139.74205169238328 9.99 35.66904382640867 139.7420302040218 9.99 35.669057156195755 139.74189752545445 9.99</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c38970f0-901a-444b-9415-575043a2155f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c38970f0-901a-444b-9415-575043a2155f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c38970f0-901a-444b-9415-575043a2155f">
											<gml:posList>35.669098633133764 139.74190378546913 23.9 35.669057156195755 139.74189752545445 23.9 35.66904382640867 139.7420302040218 23.9 35.66908528531252 139.74203646412462 23.9 35.669098633133764 139.74190378546913 23.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-8c9c2cd2-a72c-400b-ae06-247a61b81cfc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8c9c2cd2-a72c-400b-ae06-247a61b81cfc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8c9c2cd2-a72c-400b-ae06-247a61b81cfc">
											<gml:posList>35.66908528531252 139.74203646412462 27.5 35.669090095157614 139.74203186347796 27.5 35.669102396344066 139.7419096908327 27.5 35.669098633133764 139.74190378546913 27.5 35.66908528531252 139.74203646412462 27.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-873de489-5332-4dfb-b59b-0184cbb53fb5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-873de489-5332-4dfb-b59b-0184cbb53fb5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-873de489-5332-4dfb-b59b-0184cbb53fb5">
											<gml:posList>35.669186079403225 139.74205169238328 27.5 35.669182325222025 139.74204579804274 27.5 35.669090095157614 139.74203186347796 27.5 35.66908528531252 139.74203646412462 27.5 35.669186079403225 139.74205169238328 27.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-db5d445e-ecd6-418c-83b1-b90d6eefbb16">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-db5d445e-ecd6-418c-83b1-b90d6eefbb16">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-db5d445e-ecd6-418c-83b1-b90d6eefbb16">
											<gml:posList>35.669194590367326 139.74192362530013 26.222 35.669102396344066 139.7419096908327 26.222 35.669090095157614 139.74203186347796 26.222 35.669182325222025 139.74204579804274 26.222 35.669194590367326 139.74192362530013 26.222</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-657cccef-91fd-4221-bfe5-894cc4f52656">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-657cccef-91fd-4221-bfe5-894cc4f52656">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-657cccef-91fd-4221-bfe5-894cc4f52656">
											<gml:posList>35.669098633133764 139.74190378546913 27.5 35.669102396344066 139.7419096908327 27.5 35.669194590367326 139.74192362530013 27.5 35.66919940921333 139.74191901358404 27.5 35.669098633133764 139.74190378546913 27.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e6178998-4f15-4e62-bc70-469c9bad6043">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e6178998-4f15-4e62-bc70-469c9bad6043">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e6178998-4f15-4e62-bc70-469c9bad6043">
											<gml:posList>35.66919940921333 139.74191901358404 27.5 35.669194590367326 139.74192362530013 27.5 35.669182325222025 139.74204579804274 27.5 35.669186079403225 139.74205169238328 27.5 35.66919940921333 139.74191901358404 27.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-908c6df4-90fa-48be-9b62-051065ee2d23">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-908c6df4-90fa-48be-9b62-051065ee2d23">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-908c6df4-90fa-48be-9b62-051065ee2d23">
											<gml:posList>35.669057156195755 139.74189752545445 9.99 35.669057156195755 139.74189752545445 23.9 35.669098633133764 139.74190378546913 23.9 35.669098633133764 139.74190378546913 27.5 35.66919940921333 139.74191901358404 27.5 35.66919940921333 139.74191901358404 9.99 35.669057156195755 139.74189752545445 9.99</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d7b146d6-2c21-41c5-9547-e84ec1a045b7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d7b146d6-2c21-41c5-9547-e84ec1a045b7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d7b146d6-2c21-41c5-9547-e84ec1a045b7">
											<gml:posList>35.669102396344066 139.7419096908327 27.5 35.669102396344066 139.7419096908327 26.222 35.669194590367326 139.74192362530013 26.222 35.669194590367326 139.74192362530013 27.5 35.669102396344066 139.7419096908327 27.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e71d7f44-c91f-4cf3-a099-b545accdb52b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e71d7f44-c91f-4cf3-a099-b545accdb52b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e71d7f44-c91f-4cf3-a099-b545accdb52b">
											<gml:posList>35.669057156195755 139.74189752545445 9.99 35.66904382640867 139.7420302040218 9.99 35.66904382640867 139.7420302040218 23.9 35.669057156195755 139.74189752545445 23.9 35.669057156195755 139.74189752545445 9.99</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7ead591a-d8cb-4569-8de9-9f333986186e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7ead591a-d8cb-4569-8de9-9f333986186e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7ead591a-d8cb-4569-8de9-9f333986186e">
											<gml:posList>35.66908528531252 139.74203646412462 23.9 35.66908528531252 139.74203646412462 27.5 35.669098633133764 139.74190378546913 27.5 35.669098633133764 139.74190378546913 23.9 35.66908528531252 139.74203646412462 23.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2f5f6f1f-1863-4826-a479-6bf6a3b113d1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2f5f6f1f-1863-4826-a479-6bf6a3b113d1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2f5f6f1f-1863-4826-a479-6bf6a3b113d1">
											<gml:posList>35.669090095157614 139.74203186347796 27.5 35.669090095157614 139.74203186347796 26.222 35.669102396344066 139.7419096908327 26.222 35.669102396344066 139.7419096908327 27.5 35.669090095157614 139.74203186347796 27.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-032d5885-c64a-41cf-b524-effd7cd704ae">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-032d5885-c64a-41cf-b524-effd7cd704ae">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-032d5885-c64a-41cf-b524-effd7cd704ae">
											<gml:posList>35.669194590367326 139.74192362530013 27.5 35.669194590367326 139.74192362530013 26.222 35.669182325222025 139.74204579804274 26.222 35.669182325222025 139.74204579804274 27.5 35.669194590367326 139.74192362530013 27.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-05618d14-b866-4a59-93c0-be7480c60936">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-05618d14-b866-4a59-93c0-be7480c60936">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-05618d14-b866-4a59-93c0-be7480c60936">
											<gml:posList>35.669186079403225 139.74205169238328 9.99 35.66919940921333 139.74191901358404 9.99 35.66919940921333 139.74191901358404 27.5 35.669186079403225 139.74205169238328 27.5 35.669186079403225 139.74205169238328 9.99</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-32b39ba0-6fce-499f-8911-0e44e4b10b3e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-32b39ba0-6fce-499f-8911-0e44e4b10b3e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-32b39ba0-6fce-499f-8911-0e44e4b10b3e">
											<gml:posList>35.669182325222025 139.74204579804274 27.5 35.669182325222025 139.74204579804274 26.222 35.669090095157614 139.74203186347796 26.222 35.669090095157614 139.74203186347796 27.5 35.669182325222025 139.74204579804274 27.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e3c6baa1-ff92-4031-babb-7c27391b0a0e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e3c6baa1-ff92-4031-babb-7c27391b0a0e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e3c6baa1-ff92-4031-babb-7c27391b0a0e">
											<gml:posList>35.66908528531252 139.74203646412462 23.9 35.66904382640867 139.7420302040218 23.9 35.66904382640867 139.7420302040218 9.99 35.669186079403225 139.74205169238328 9.99 35.669186079403225 139.74205169238328 27.5 35.66908528531252 139.74203646412462 27.5 35.66908528531252 139.74203646412462 23.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂一丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-6050</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">165.6648</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">6</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1210</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.6</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>4</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.01</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>