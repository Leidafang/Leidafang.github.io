<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_19825a00-6048-4cfb-be71-9a71872164f6">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001001</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">401</bldg:usage>
			<bldg:measuredHeight uom="m">45.9</bldg:measuredHeight>
			<bldg:storeysAboveGround>5</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.66737612530251 139.74146391570622 0 35.667380832697766 139.74145501840664 0 35.667353946466214 139.7414336755076 0 35.66737859949935 139.7413870558748 0 35.667365530679696 139.74137668776666 0 35.6673861783543 139.74133762806468 0 35.66737624820645 139.7413297416776 0 35.667379758487854 139.74132309909643 0 35.66734656780472 139.74129674866558 0 35.667351923238805 139.74128662452713 0 35.66730568175281 139.74124991706591 0 35.66730105538635 139.74125867068022 0 35.66727040810597 139.74123433876764 0 35.66717351527595 139.74141761180456 0 35.66724703978872 139.74147598204704 0 35.66724073926201 139.74148789666611 0 35.66727588707046 139.74151580236273 0 35.66728266462832 139.74150297039017 0 35.66733394777614 139.7415436929012 0 35.66734888903103 139.74151543158 0 35.66735814272456 139.74152277751566 0 35.66738537899912 139.74147126163837 0 35.66737612530251 139.74146391570622 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66737612530251 139.74146391570622 24.1 35.66738537899912 139.74147126163837 24.1 35.66735814272456 139.74152277751566 24.1 35.66734888903103 139.74151543158 24.1 35.66733394777614 139.7415436929012 24.1 35.66728266462832 139.74150297039017 24.1 35.66727588707046 139.74151580236273 24.1 35.66724073926201 139.74148789666611 24.1 35.66724703978872 139.74147598204704 24.1 35.66717351527595 139.74141761180456 24.1 35.66727040810597 139.74123433876764 24.1 35.66730105538635 139.74125867068022 24.1 35.66730568175281 139.74124991706591 24.1 35.667351923238805 139.74128662452713 24.1 35.66734656780472 139.74129674866558 24.1 35.667379758487854 139.74132309909643 24.1 35.66737624820645 139.7413297416776 24.1 35.6673861783543 139.74133762806468 24.1 35.667365530679696 139.74137668776666 24.1 35.66737859949935 139.7413870558748 24.1 35.667353946466214 139.7414336755076 24.1 35.667380832697766 139.74145501840664 24.1 35.66737612530251 139.74146391570622 24.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66737612530251 139.74146391570622 24.1 35.667380832697766 139.74145501840664 24.1 35.667380832697766 139.74145501840664 69.99 35.66737612530251 139.74146391570622 69.99 35.66737612530251 139.74146391570622 24.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667380832697766 139.74145501840664 24.1 35.667353946466214 139.7414336755076 24.1 35.667353946466214 139.7414336755076 69.99 35.667380832697766 139.74145501840664 69.99 35.667380832697766 139.74145501840664 24.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667353946466214 139.7414336755076 24.1 35.66737859949935 139.7413870558748 24.1 35.66737859949935 139.7413870558748 69.99 35.667353946466214 139.7414336755076 69.99 35.667353946466214 139.7414336755076 24.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66737859949935 139.7413870558748 24.1 35.667365530679696 139.74137668776666 24.1 35.667365530679696 139.74137668776666 69.99 35.66737859949935 139.7413870558748 69.99 35.66737859949935 139.7413870558748 24.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667365530679696 139.74137668776666 24.1 35.6673861783543 139.74133762806468 24.1 35.6673861783543 139.74133762806468 69.99 35.667365530679696 139.74137668776666 69.99 35.667365530679696 139.74137668776666 24.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6673861783543 139.74133762806468 24.1 35.66737624820645 139.7413297416776 24.1 35.66737624820645 139.7413297416776 69.99 35.6673861783543 139.74133762806468 69.99 35.6673861783543 139.74133762806468 24.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66737624820645 139.7413297416776 24.1 35.667379758487854 139.74132309909643 24.1 35.667379758487854 139.74132309909643 69.99 35.66737624820645 139.7413297416776 69.99 35.66737624820645 139.7413297416776 24.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667379758487854 139.74132309909643 24.1 35.66734656780472 139.74129674866558 24.1 35.66734656780472 139.74129674866558 69.99 35.667379758487854 139.74132309909643 69.99 35.667379758487854 139.74132309909643 24.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66734656780472 139.74129674866558 24.1 35.667351923238805 139.74128662452713 24.1 35.667351923238805 139.74128662452713 69.99 35.66734656780472 139.74129674866558 69.99 35.66734656780472 139.74129674866558 24.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667351923238805 139.74128662452713 24.1 35.66730568175281 139.74124991706591 24.1 35.66730568175281 139.74124991706591 69.99 35.667351923238805 139.74128662452713 69.99 35.667351923238805 139.74128662452713 24.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66730568175281 139.74124991706591 24.1 35.66730105538635 139.74125867068022 24.1 35.66730105538635 139.74125867068022 69.99 35.66730568175281 139.74124991706591 69.99 35.66730568175281 139.74124991706591 24.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66730105538635 139.74125867068022 24.1 35.66727040810597 139.74123433876764 24.1 35.66727040810597 139.74123433876764 69.99 35.66730105538635 139.74125867068022 69.99 35.66730105538635 139.74125867068022 24.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66727040810597 139.74123433876764 24.1 35.66717351527595 139.74141761180456 24.1 35.66717351527595 139.74141761180456 69.99 35.66727040810597 139.74123433876764 69.99 35.66727040810597 139.74123433876764 24.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66717351527595 139.74141761180456 24.1 35.66724703978872 139.74147598204704 24.1 35.66724703978872 139.74147598204704 69.99 35.66717351527595 139.74141761180456 69.99 35.66717351527595 139.74141761180456 24.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66724703978872 139.74147598204704 24.1 35.66724073926201 139.74148789666611 24.1 35.66724073926201 139.74148789666611 69.99 35.66724703978872 139.74147598204704 69.99 35.66724703978872 139.74147598204704 24.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66724073926201 139.74148789666611 24.1 35.66727588707046 139.74151580236273 24.1 35.66727588707046 139.74151580236273 69.99 35.66724073926201 139.74148789666611 69.99 35.66724073926201 139.74148789666611 24.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66727588707046 139.74151580236273 24.1 35.66728266462832 139.74150297039017 24.1 35.66728266462832 139.74150297039017 69.99 35.66727588707046 139.74151580236273 69.99 35.66727588707046 139.74151580236273 24.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66728266462832 139.74150297039017 24.1 35.66733394777614 139.7415436929012 24.1 35.66733394777614 139.7415436929012 69.99 35.66728266462832 139.74150297039017 69.99 35.66728266462832 139.74150297039017 24.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66733394777614 139.7415436929012 24.1 35.66734888903103 139.74151543158 24.1 35.66734888903103 139.74151543158 69.99 35.66733394777614 139.7415436929012 69.99 35.66733394777614 139.7415436929012 24.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66734888903103 139.74151543158 24.1 35.66735814272456 139.74152277751566 24.1 35.66735814272456 139.74152277751566 69.99 35.66734888903103 139.74151543158 69.99 35.66734888903103 139.74151543158 24.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66735814272456 139.74152277751566 24.1 35.66738537899912 139.74147126163837 24.1 35.66738537899912 139.74147126163837 69.99 35.66735814272456 139.74152277751566 69.99 35.66735814272456 139.74152277751566 24.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66738537899912 139.74147126163837 24.1 35.66737612530251 139.74146391570622 24.1 35.66737612530251 139.74146391570622 69.99 35.66738537899912 139.74147126163837 69.99 35.66738537899912 139.74147126163837 24.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66737612530251 139.74146391570622 69.99 35.667380832697766 139.74145501840664 69.99 35.667353946466214 139.7414336755076 69.99 35.66737859949935 139.7413870558748 69.99 35.667365530679696 139.74137668776666 69.99 35.6673861783543 139.74133762806468 69.99 35.66737624820645 139.7413297416776 69.99 35.667379758487854 139.74132309909643 69.99 35.66734656780472 139.74129674866558 69.99 35.667351923238805 139.74128662452713 69.99 35.66730568175281 139.74124991706591 69.99 35.66730105538635 139.74125867068022 69.99 35.66727040810597 139.74123433876764 69.99 35.66717351527595 139.74141761180456 69.99 35.66724703978872 139.74147598204704 69.99 35.66724073926201 139.74148789666611 69.99 35.66727588707046 139.74151580236273 69.99 35.66728266462832 139.74150297039017 69.99 35.66733394777614 139.7415436929012 69.99 35.66734888903103 139.74151543158 69.99 35.66735814272456 139.74152277751566 69.99 35.66738537899912 139.74147126163837 69.99 35.66737612530251 139.74146391570622 69.99</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-e5887db8-1e07-43b4-a553-18a96871aa7d"/>
							<gml:surfaceMember xlink:href="#poly-5bab476b-a9ca-47e5-be56-a8602d593a39"/>
							<gml:surfaceMember xlink:href="#poly-7a6c2fac-36c5-4022-bd7f-563921334862"/>
							<gml:surfaceMember xlink:href="#poly-9072ff39-6f9e-4c19-99c8-7365918564ad"/>
							<gml:surfaceMember xlink:href="#poly-99f6bc9a-c94d-4e35-a0c1-363c76d82b21"/>
							<gml:surfaceMember xlink:href="#poly-ea42c51e-16df-4a94-9215-c415ec43c1d6"/>
							<gml:surfaceMember xlink:href="#poly-f74290c5-681e-4cac-b828-a1410f730304"/>
							<gml:surfaceMember xlink:href="#poly-e8bae464-56ab-4201-b8ef-960620ef4e21"/>
							<gml:surfaceMember xlink:href="#poly-c9faa16a-d583-41bc-8fae-54a7d4de08c6"/>
							<gml:surfaceMember xlink:href="#poly-3bcb8e64-16e7-4e99-8448-5cbd58eff6fc"/>
							<gml:surfaceMember xlink:href="#poly-f5aa40f7-477a-407a-b9d6-e83fb58b950b"/>
							<gml:surfaceMember xlink:href="#poly-77373ff6-4b3a-4efb-b397-bf2a155ce848"/>
							<gml:surfaceMember xlink:href="#poly-581edb5d-cef4-429d-a9e0-aa2f341821bd"/>
							<gml:surfaceMember xlink:href="#poly-7fe9ba25-be80-4260-881b-e7833f6cb4e6"/>
							<gml:surfaceMember xlink:href="#poly-ead3e5dc-35e5-4427-a977-ded7f7a5c8dc"/>
							<gml:surfaceMember xlink:href="#poly-98ee6aa6-45a9-4cc8-9e73-6eaab16138b7"/>
							<gml:surfaceMember xlink:href="#poly-0da65ed5-da1f-477f-9426-6303ba810618"/>
							<gml:surfaceMember xlink:href="#poly-fe8310eb-1cc4-471f-a21b-7398ff67be0e"/>
							<gml:surfaceMember xlink:href="#poly-760a0413-1359-4d52-854f-d302877ae370"/>
							<gml:surfaceMember xlink:href="#poly-2da96cd9-e7f4-4c38-ad58-b290b596c07f"/>
							<gml:surfaceMember xlink:href="#poly-4935edd0-1a41-4e42-bce2-ee90aa457c9c"/>
							<gml:surfaceMember xlink:href="#poly-c95b1041-3a07-47ea-beb7-c45e62dfa95f"/>
							<gml:surfaceMember xlink:href="#poly-b4308692-6226-4faf-9dfd-be2b7f19f729"/>
							<gml:surfaceMember xlink:href="#poly-3d27317b-7038-43c4-a15c-c13ad622dfa4"/>
							<gml:surfaceMember xlink:href="#poly-39bd3d30-c051-41ce-baa6-f018f6f094c6"/>
							<gml:surfaceMember xlink:href="#poly-710d980e-ac81-4d88-bd4d-4de1f2a75d4a"/>
							<gml:surfaceMember xlink:href="#poly-90a006e8-a8b7-42e4-8268-f6af8b481a36"/>
							<gml:surfaceMember xlink:href="#poly-34989037-dd36-4dc2-b208-d7f882656fa4"/>
							<gml:surfaceMember xlink:href="#poly-3c3c085f-3262-4c9b-97ba-8c91d28c336b"/>
							<gml:surfaceMember xlink:href="#poly-9308ca2b-bc8e-4a22-82ca-40b92d454ef0"/>
							<gml:surfaceMember xlink:href="#poly-1ffdae80-e035-4f03-96c1-bbd5d7700a48"/>
							<gml:surfaceMember xlink:href="#poly-d276594d-4b53-4a09-962d-5327bbca0247"/>
							<gml:surfaceMember xlink:href="#poly-e91cbc3d-df21-48d1-b379-2ef0c51e37c1"/>
							<gml:surfaceMember xlink:href="#poly-1ac969dc-61c7-47c0-960b-a40940027d85"/>
							<gml:surfaceMember xlink:href="#poly-033eee68-dd16-40c1-bad0-78276bb6bd06"/>
							<gml:surfaceMember xlink:href="#poly-fc0c0190-d867-4e87-b1d0-5c163ff5c601"/>
							<gml:surfaceMember xlink:href="#poly-236d5d40-3cf9-4017-88bb-9c84f3fd9a51"/>
							<gml:surfaceMember xlink:href="#poly-5838fa0a-1ccb-40d5-ae05-090729f150c6"/>
							<gml:surfaceMember xlink:href="#poly-9d85e409-9dd6-4cc3-9d33-bf4fd33714bb"/>
							<gml:surfaceMember xlink:href="#poly-9c3f574e-1aef-4ffc-9966-b33d8119f0eb"/>
							<gml:surfaceMember xlink:href="#poly-86718fcd-b4c2-46fc-9740-888f13cd4f5b"/>
							<gml:surfaceMember xlink:href="#poly-7c03c96f-e539-46d2-9fe8-c44fa7b06730"/>
							<gml:surfaceMember xlink:href="#poly-edf34bf0-024c-44af-b764-39f37df882c4"/>
							<gml:surfaceMember xlink:href="#poly-1c056be9-f53b-49d7-9ae7-85ad87d630a0"/>
							<gml:surfaceMember xlink:href="#poly-6fa31885-cef7-465f-8886-43adc08fa47a"/>
							<gml:surfaceMember xlink:href="#poly-5d1f2833-affa-4a6e-80f9-361f71d784a2"/>
							<gml:surfaceMember xlink:href="#poly-0eb7f737-b881-4e08-a927-1b05ea205e45"/>
							<gml:surfaceMember xlink:href="#poly-f5650d15-0bcb-44ed-8d55-a0c2aa75ab51"/>
							<gml:surfaceMember xlink:href="#poly-ebdfa20f-2d86-437d-9d77-16d9b41db17d"/>
							<gml:surfaceMember xlink:href="#poly-e29a050f-3edf-47ef-b223-3530b8198b7d"/>
							<gml:surfaceMember xlink:href="#poly-c0996a33-93de-4ad5-96f6-2ab2518d818f"/>
							<gml:surfaceMember xlink:href="#poly-5169a71d-7edd-4fe9-ab0b-d495b6eb8282"/>
							<gml:surfaceMember xlink:href="#poly-41b2fc2c-8b51-46ea-b8d1-7927b502f033"/>
							<gml:surfaceMember xlink:href="#poly-5200940b-bec2-4282-9fde-9dd723eea595"/>
							<gml:surfaceMember xlink:href="#poly-9c11e8b6-e762-40a9-8ad5-38d35852440d"/>
							<gml:surfaceMember xlink:href="#poly-65669179-288b-4f47-840c-8f390525b760"/>
							<gml:surfaceMember xlink:href="#poly-1314d6a7-d51c-4029-beda-7dc0f1c7e34f"/>
							<gml:surfaceMember xlink:href="#poly-04b4c585-128a-4616-b8e3-74ddc9ab7b20"/>
							<gml:surfaceMember xlink:href="#poly-035beeda-f304-4335-b748-dd8665f54771"/>
							<gml:surfaceMember xlink:href="#poly-6d3ed814-ec27-4a36-9987-07eafb9ba23d"/>
							<gml:surfaceMember xlink:href="#poly-2553b45a-3bf6-40be-97e9-4c4ae7721d47"/>
							<gml:surfaceMember xlink:href="#poly-b50b8eff-bb63-44e4-a8e9-656c6ce25c1d"/>
							<gml:surfaceMember xlink:href="#poly-c8c6167a-56ed-41e6-bbcc-00a6cb59cfe5"/>
							<gml:surfaceMember xlink:href="#poly-657d3ae4-dfa5-4db3-b9cb-2cc6f6222c30"/>
							<gml:surfaceMember xlink:href="#poly-fb2a8178-f3cf-417d-90cf-6719cec57436"/>
							<gml:surfaceMember xlink:href="#poly-be3a42f6-c598-4aca-aa09-994cb9cdb174"/>
							<gml:surfaceMember xlink:href="#poly-faee9cee-f3b8-4972-8e33-b2863e973172"/>
							<gml:surfaceMember xlink:href="#poly-a120c718-dfa6-4c7e-9652-3aebce5667bc"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_19825a00-6048-4cfb-be71-9a71872164f6_BuildingInstallation_1041">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c64f63f8-d5dc-440a-ad35-97e697ec6995">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66736077238474 139.74137794140373 69.141 35.66737385021803 139.74138830950113 69.141 35.66735601072942 139.7414220197775 69.141 35.667338315054195 139.74140796765985 69.141 35.66735661354733 139.74137335110228 69.141 35.66736124942063 139.7413770350975 69.141 35.66736077238474 139.74137794140373 69.141</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a19b54dc-b082-4f9a-8b2d-aec6e9428bae">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66736124942063 139.7413770350975 70.5 35.66737559897393 139.74138842900024 70.5 35.667357300476525 139.74142304556258 70.5 35.66735601072942 139.7414220197775 70.5 35.66737385021803 139.74138830950113 70.5 35.66736077238474 139.74137794140373 70.5 35.66736124942063 139.7413770350975 70.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c4166d32-6e63-4044-acce-7f2462232401">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c4166d32-6e63-4044-acce-7f2462232401_0">
											<gml:posList>35.667338315054195 139.74140796765985 69.141 35.667338315054195 139.74140796765985 71.534 35.66735661354733 139.74137335110228 71.534 35.66735661354733 139.74137335110228 69.141 35.667338315054195 139.74140796765985 69.141</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2d8706e8-f2a7-4057-b3e2-f5efd2b4a126">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2d8706e8-f2a7-4057-b3e2-f5efd2b4a126_0">
											<gml:posList>35.667357300476525 139.74142304556258 71.534 35.667338315054195 139.74140796765985 71.534 35.667338315054195 139.74140796765985 69.141 35.66735601072942 139.7414220197775 69.141 35.66735601072942 139.7414220197775 70.5 35.667357300476525 139.74142304556258 70.5 35.667357300476525 139.74142304556258 71.534</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1b3a233f-5a6e-4a4f-9b01-a8414bc47fb6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1b3a233f-5a6e-4a4f-9b01-a8414bc47fb6_0">
											<gml:posList>35.66737559897393 139.74138842900024 71.534 35.66735661354733 139.74137335110228 71.534 35.667338315054195 139.74140796765985 71.534 35.667357300476525 139.74142304556258 71.534 35.66737559897393 139.74138842900024 71.534</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4e0d179b-6ec8-44da-aea1-44a308c7cff3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4e0d179b-6ec8-44da-aea1-44a308c7cff3_0">
											<gml:posList>35.66736124942063 139.7413770350975 69.141 35.66736124942063 139.7413770350975 70.5 35.66736077238474 139.74137794140373 70.5 35.66736077238474 139.74137794140373 69.141 35.66736124942063 139.7413770350975 69.141</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cac2d443-1532-4be3-b404-3bc979f9dd4b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cac2d443-1532-4be3-b404-3bc979f9dd4b_0">
											<gml:posList>35.66735601072942 139.7414220197775 70.5 35.66735601072942 139.7414220197775 69.141 35.66737385021803 139.74138830950113 69.141 35.66737385021803 139.74138830950113 70.5 35.66735601072942 139.7414220197775 70.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-18621be4-fc4f-4802-8c19-15ff577a1dc8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-18621be4-fc4f-4802-8c19-15ff577a1dc8_0">
											<gml:posList>35.66735661354733 139.74137335110228 69.141 35.66735661354733 139.74137335110228 71.534 35.66737559897393 139.74138842900024 71.534 35.66737559897393 139.74138842900024 70.5 35.66736124942063 139.7413770350975 70.5 35.66736124942063 139.7413770350975 69.141 35.66735661354733 139.74137335110228 69.141</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9d353034-895c-4eed-91e4-95b51ec5e4ce">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9d353034-895c-4eed-91e4-95b51ec5e4ce_0">
											<gml:posList>35.66737559897393 139.74138842900024 70.5 35.66737559897393 139.74138842900024 71.534 35.667357300476525 139.74142304556258 71.534 35.667357300476525 139.74142304556258 70.5 35.66737559897393 139.74138842900024 70.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3b9df7e0-c43e-407a-8707-1b39b1b6743f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3b9df7e0-c43e-407a-8707-1b39b1b6743f_0">
											<gml:posList>35.66736077238474 139.74137794140373 70.5 35.66737385021803 139.74138830950113 70.5 35.66737385021803 139.74138830950113 69.141 35.66736077238474 139.74137794140373 69.141 35.66736077238474 139.74137794140373 70.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_19825a00-6048-4cfb-be71-9a71872164f6_BuildingInstallation_1060">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ba217a16-f90c-4ec9-b34d-ac135fe4ba4b">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66740012833847 139.74140415225457 24.1 35.66737547529884 139.74145077189465 24.1 35.667353946466214 139.7414336755076 24.1 35.66737859949933 139.7413870558748 24.1 35.66740012833847 139.74140415225457 24.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3a3f0d81-d816-4d6b-acac-f129f63310e2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3a3f0d81-d816-4d6b-acac-f129f63310e2_0">
											<gml:posList>35.66740012833847 139.74140415225457 70.5 35.66740012833847 139.74140415225457 24.1 35.66737859949933 139.7413870558748 24.1 35.66737859949933 139.7413870558748 70.5 35.66740012833847 139.74140415225457 70.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-64d3602d-94f9-4e00-bee7-555ed703cf23">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-64d3602d-94f9-4e00-bee7-555ed703cf23_0">
											<gml:posList>35.66737859949933 139.7413870558748 70.5 35.66737859949933 139.7413870558748 24.1 35.667353946466214 139.7414336755076 24.1 35.667353946466214 139.7414336755076 70.5 35.66737859949933 139.7413870558748 70.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0214927d-3987-400e-aad6-179f638dbb47">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0214927d-3987-400e-aad6-179f638dbb47_0">
											<gml:posList>35.66737859949933 139.7413870558748 70.5 35.667353946466214 139.7414336755076 70.5 35.66737547529884 139.74145077189465 70.5 35.66740012833847 139.74140415225457 70.5 35.66737859949933 139.7413870558748 70.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fcdcadfe-6e88-41da-9c95-70481339c117">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fcdcadfe-6e88-41da-9c95-70481339c117_0">
											<gml:posList>35.66737547529884 139.74145077189465 70.5 35.66737547529884 139.74145077189465 24.1 35.66740012833847 139.74140415225457 24.1 35.66740012833847 139.74140415225457 70.5 35.66737547529884 139.74145077189465 70.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9ff18258-6a28-4e74-a9be-817616e0fae1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9ff18258-6a28-4e74-a9be-817616e0fae1_0">
											<gml:posList>35.667353946466214 139.7414336755076 70.5 35.667353946466214 139.7414336755076 24.1 35.66737547529884 139.74145077189465 24.1 35.66737547529884 139.74145077189465 70.5 35.667353946466214 139.7414336755076 70.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_19825a00-6048-4cfb-be71-9a71872164f6_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b466476c-de49-4298-8ff6-14007f2dfd4a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b466476c-de49-4298-8ff6-14007f2dfd4a_0">
											<gml:posList>35.667249331002914 139.74143098976398 71.862 35.66725906274117 139.74143874382858 72.8 35.667249331002914 139.74143098976398 72.8 35.667249331002914 139.74143098976398 71.862</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-beb21f05-87de-4022-8d87-2671dd802cce">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-beb21f05-87de-4022-8d87-2671dd802cce_0">
											<gml:posList>35.667249331002914 139.74143098976398 71.862 35.66725906274117 139.74143874382858 71.862 35.66725906274117 139.74143874382858 72.8 35.667249331002914 139.74143098976398 71.862</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5f62fad1-3eb3-4b87-8407-74f5e4bd3174">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5f62fad1-3eb3-4b87-8407-74f5e4bd3174_0">
											<gml:posList>35.667249331002914 139.74143098976398 71.862 35.66726890772347 139.74139410738925 72.8 35.66726890772347 139.74139410738925 71.862 35.667249331002914 139.74143098976398 71.862</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-98c00d51-56f0-429d-a2a2-6ff655430697">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-98c00d51-56f0-429d-a2a2-6ff655430697_0">
											<gml:posList>35.667249331002914 139.74143098976398 71.862 35.667249331002914 139.74143098976398 72.8 35.66726890772347 139.74139410738925 72.8 35.667249331002914 139.74143098976398 71.862</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-836c31c1-b5af-484c-9e84-dacc6349d62e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-836c31c1-b5af-484c-9e84-dacc6349d62e_0">
											<gml:posList>35.66725906274117 139.74143874382858 71.862 35.66727863946406 139.74140186145127 72.8 35.66725906274117 139.74143874382858 72.8 35.66725906274117 139.74143874382858 71.862</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e3b74c3f-afc0-4851-ae74-47d0e75a9cba">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e3b74c3f-afc0-4851-ae74-47d0e75a9cba_0">
											<gml:posList>35.66725906274117 139.74143874382858 71.862 35.66727863946406 139.74140186145127 71.862 35.66727863946406 139.74140186145127 72.8 35.66725906274117 139.74143874382858 71.862</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bcebbfb4-4164-4354-b526-663089f96749">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bcebbfb4-4164-4354-b526-663089f96749_0">
											<gml:posList>35.667304850055984 139.74130568844626 73.862 35.6672396573932 139.74142853763152 71.862 35.667304850055984 139.74130568844626 71.862 35.667304850055984 139.74130568844626 73.862</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-134c8ecc-a089-4974-b992-7a3a990a1994">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-134c8ecc-a089-4974-b992-7a3a990a1994_0">
											<gml:posList>35.667304850055984 139.74130568844626 73.862 35.6672396573932 139.74142853763152 73.862 35.6672396573932 139.74142853763152 71.862 35.667304850055984 139.74130568844626 73.862</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4f39d413-99ca-4015-aeca-a96a93ae3d61">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4f39d413-99ca-4015-aeca-a96a93ae3d61_0">
											<gml:posList>35.66729440005788 139.7413370485175 71.862 35.667272519079766 139.74137817515967 73.474 35.66729440005788 139.7413370485175 73.474 35.66729440005788 139.7413370485175 71.862</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e5f76b80-56b7-4f99-8b90-034820a6fdd2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e5f76b80-56b7-4f99-8b90-034820a6fdd2_0">
											<gml:posList>35.66729440005788 139.7413370485175 71.862 35.667272519079766 139.74137817515967 71.862 35.667272519079766 139.74137817515967 73.474 35.66729440005788 139.7413370485175 71.862</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-dc784069-5f4d-4be5-acf1-db9148cd82d1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-dc784069-5f4d-4be5-acf1-db9148cd82d1_0">
											<gml:posList>35.66728949328091 139.74139173102398 71.862 35.66731136524985 139.74135060438707 73.474 35.66728949328091 139.74139173102398 73.474 35.66728949328091 139.74139173102398 71.862</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-efdc83c0-42b6-479a-85ca-6cb95926d170">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-efdc83c0-42b6-479a-85ca-6cb95926d170_0">
											<gml:posList>35.66728949328091 139.74139173102398 71.862 35.66731136524985 139.74135060438707 71.862 35.66731136524985 139.74135060438707 73.474 35.66728949328091 139.74139173102398 71.862</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3a7e3040-e0fb-43e6-809f-5c1411d7c894">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3a7e3040-e0fb-43e6-809f-5c1411d7c894_0">
											<gml:posList>35.66726821223616 139.74145128140702 73.862 35.66733339591649 139.74132844325254 71.862 35.66726821223616 139.74145128140702 71.862 35.66726821223616 139.74145128140702 73.862</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-00db17aa-6955-4c36-bb3f-e3b262f5dc0e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-00db17aa-6955-4c36-bb3f-e3b262f5dc0e_0">
											<gml:posList>35.66726821223616 139.74145128140702 73.862 35.66733339591649 139.74132844325254 73.862 35.66733339591649 139.74132844325254 71.862 35.66726821223616 139.74145128140702 73.862</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c37eb6a7-0dfa-4376-8377-037076edca56">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c37eb6a7-0dfa-4376-8377-037076edca56_0">
											<gml:posList>35.667300351653246 139.74139937333766 69.141 35.66730779530357 139.74138534763728 71.475 35.66730779530357 139.74138534763728 69.141 35.667300351653246 139.74139937333766 69.141</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9143f80a-1993-4192-8c12-66288aa94cc5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9143f80a-1993-4192-8c12-66288aa94cc5_0">
											<gml:posList>35.667300351653246 139.74139937333766 69.141 35.667300351653246 139.74139937333766 71.475 35.66730779530357 139.74138534763728 71.475 35.667300351653246 139.74139937333766 69.141</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4681fdcf-d33d-468e-8899-5cc0dc31662c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4681fdcf-d33d-468e-8899-5cc0dc31662c_0">
											<gml:posList>35.667312898748825 139.7413757319071 69.141 35.667319991367194 139.74136236935524 71.475 35.667319991367194 139.74136236935524 69.141 35.667312898748825 139.7413757319071 69.141</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-32377c2c-d407-43ae-93b4-25611377f1f5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-32377c2c-d407-43ae-93b4-25611377f1f5_0">
											<gml:posList>35.667312898748825 139.7413757319071 69.141 35.667312898748825 139.7413757319071 71.475 35.667319991367194 139.74136236935524 71.475 35.667312898748825 139.7413757319071 69.141</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-329e8ff5-8e6d-41b9-ba73-e970494302e1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-329e8ff5-8e6d-41b9-ba73-e970494302e1_0">
											<gml:posList>35.66730371835086 139.74129916165617 69.141 35.66733873098821 139.7413270564011 73.862 35.66733873098821 139.7413270564011 69.141 35.66730371835086 139.74129916165617 69.141</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8a07c861-f456-48a6-8345-4d406e8da764">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8a07c861-f456-48a6-8345-4d406e8da764_0">
											<gml:posList>35.66730371835086 139.74129916165617 69.141 35.66730371835086 139.74129916165617 73.862 35.66733873098821 139.7413270564011 73.862 35.66730371835086 139.74129916165617 69.141</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1a10098b-9d8e-4fd4-a07f-29f1e6a12534">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1a10098b-9d8e-4fd4-a07f-29f1e6a12534_0">
											<gml:posList>35.66733339591649 139.74132844325254 73.862 35.667304850055984 139.74130568844626 71.862 35.66733339591649 139.74132844325254 71.862 35.66733339591649 139.74132844325254 73.862</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fa3a1d37-3d20-4885-81a1-0c76530b9489">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fa3a1d37-3d20-4885-81a1-0c76530b9489_0">
											<gml:posList>35.66733339591649 139.74132844325254 73.862 35.667304850055984 139.74130568844626 73.862 35.667304850055984 139.74130568844626 71.862 35.66733339591649 139.74132844325254 73.862</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d92fa878-1a2b-4a60-b0bb-e97873f1dc3b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d92fa878-1a2b-4a60-b0bb-e97873f1dc3b_0">
											<gml:posList>35.66729440005788 139.7413370485175 71.862 35.66731136524985 139.74135060438707 73.474 35.66731136524985 139.74135060438707 71.862 35.66729440005788 139.7413370485175 71.862</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9fb5495a-d5e2-40b8-87c2-1e14b66db029">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9fb5495a-d5e2-40b8-87c2-1e14b66db029_0">
											<gml:posList>35.66729440005788 139.7413370485175 71.862 35.66729440005788 139.7413370485175 73.474 35.66731136524985 139.74135060438707 73.474 35.66729440005788 139.7413370485175 71.862</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-eb8d7876-354d-442a-bfb0-b53a5b4c69ec">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-eb8d7876-354d-442a-bfb0-b53a5b4c69ec_0">
											<gml:posList>35.667272519079766 139.74137817515967 73.474 35.66731136524985 139.74135060438707 73.474 35.66729440005788 139.7413370485175 73.474 35.667272519079766 139.74137817515967 73.474</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a6dbd548-b5ed-40c5-bd23-d7d9a6078b5e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a6dbd548-b5ed-40c5-bd23-d7d9a6078b5e_0">
											<gml:posList>35.667272519079766 139.74137817515967 73.474 35.66728949328091 139.74139173102398 73.474 35.66731136524985 139.74135060438707 73.474 35.667272519079766 139.74137817515967 73.474</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fefde807-e7b0-43eb-a24c-012d4091db88">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fefde807-e7b0-43eb-a24c-012d4091db88_0">
											<gml:posList>35.667234331333944 139.74142992446417 69.141 35.66730371835086 139.74129916165617 73.862 35.66730371835086 139.74129916165617 69.141 35.667234331333944 139.74142992446417 69.141</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8e92281d-37da-4743-9c84-2bbf039267f9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8e92281d-37da-4743-9c84-2bbf039267f9_0">
											<gml:posList>35.667234331333944 139.74142992446417 69.141 35.667234331333944 139.74142992446417 73.862 35.66730371835086 139.74129916165617 73.862 35.667234331333944 139.74142992446417 69.141</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9de0e072-f5ce-4b82-861b-e14be036e6bc">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9de0e072-f5ce-4b82-861b-e14be036e6bc_0">
											<gml:posList>35.667319991367194 139.74136236935524 69.141 35.66733312336017 139.74137283679528 71.475 35.66733312336017 139.74137283679528 69.141 35.667319991367194 139.74136236935524 69.141</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2ade8d7e-1d29-4cf0-bae7-f20640158267">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2ade8d7e-1d29-4cf0-bae7-f20640158267_0">
											<gml:posList>35.667319991367194 139.74136236935524 69.141 35.667319991367194 139.74136236935524 71.475 35.66733312336017 139.74137283679528 71.475 35.667319991367194 139.74136236935524 69.141</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3e0c6379-ec15-47e3-ab4c-b7f267956c04">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3e0c6379-ec15-47e3-ab4c-b7f267956c04_0">
											<gml:posList>35.66733312336017 139.74137283679528 71.475 35.667319991367194 139.74136236935524 71.475 35.667312898748825 139.7413757319071 71.475 35.66733312336017 139.74137283679528 71.475</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b933a7c0-e168-4ff8-8637-e7ed530b6569">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b933a7c0-e168-4ff8-8637-e7ed530b6569_0">
											<gml:posList>35.66732603074067 139.7413861993484 71.475 35.66733312336017 139.74137283679528 71.475 35.667312898748825 139.7413757319071 71.475 35.66732603074067 139.7413861993484 71.475</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3c008b8b-34b8-420a-803b-d604e54662d5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3c008b8b-34b8-420a-803b-d604e54662d5_0">
											<gml:posList>35.667304850055984 139.74130568844626 71.862 35.66726821223616 139.74145128140702 71.862 35.66733339591649 139.74132844325254 71.862 35.667304850055984 139.74130568844626 71.862</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-06ac165d-2e1b-4b03-a7d0-882f923b4cc7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-06ac165d-2e1b-4b03-a7d0-882f923b4cc7_0">
											<gml:posList>35.667304850055984 139.74130568844626 71.862 35.6672396573932 139.74142853763152 71.862 35.66726821223616 139.74145128140702 71.862 35.667304850055984 139.74130568844626 71.862</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3114d126-5ff3-43d3-bfab-4ec4158398b1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3114d126-5ff3-43d3-bfab-4ec4158398b1_0">
											<gml:posList>35.6672396573932 139.74142853763152 73.862 35.66730371835086 139.74129916165617 73.862 35.667234331333944 139.74142992446417 73.862 35.6672396573932 139.74142853763152 73.862</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c635ff7c-31c2-485a-8f26-e38d35296075">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c635ff7c-31c2-485a-8f26-e38d35296075_0">
											<gml:posList>35.667234331333944 139.74142992446417 73.862 35.66726934394146 139.7414578192422 73.862 35.66726821223616 139.74145128140702 73.862 35.667234331333944 139.74142992446417 73.862</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-880e114f-9245-492a-bf96-5fc52877230f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-880e114f-9245-492a-bf96-5fc52877230f_0">
											<gml:posList>35.66733873098821 139.7413270564011 73.862 35.66730371835086 139.74129916165617 73.862 35.667304850055984 139.74130568844626 73.862 35.66733873098821 139.7413270564011 73.862</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-93383d66-e1ea-46e1-b4a9-0a04a6d09403">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-93383d66-e1ea-46e1-b4a9-0a04a6d09403_0">
											<gml:posList>35.66726934394146 139.7414578192422 73.862 35.66733873098821 139.7413270564011 73.862 35.66733339591649 139.74132844325254 73.862 35.66726934394146 139.7414578192422 73.862</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ee417b17-f593-4e5d-9c3d-7137b9f911f9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ee417b17-f593-4e5d-9c3d-7137b9f911f9_0">
											<gml:posList>35.6672396573932 139.74142853763152 73.862 35.667234331333944 139.74142992446417 73.862 35.66726821223616 139.74145128140702 73.862 35.6672396573932 139.74142853763152 73.862</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-52cadd0e-f281-4d4a-8649-ea9f2925fa15">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-52cadd0e-f281-4d4a-8649-ea9f2925fa15_0">
											<gml:posList>35.667304850055984 139.74130568844626 73.862 35.66730371835086 139.74129916165617 73.862 35.6672396573932 139.74142853763152 73.862 35.667304850055984 139.74130568844626 73.862</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4f54cc63-8c18-4c72-a9b2-94ac96210cde">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4f54cc63-8c18-4c72-a9b2-94ac96210cde_0">
											<gml:posList>35.66726934394146 139.7414578192422 73.862 35.66733339591649 139.74132844325254 73.862 35.66726821223616 139.74145128140702 73.862 35.66726934394146 139.7414578192422 73.862</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-37047da1-0893-4d6c-9078-81b12006aedc">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-37047da1-0893-4d6c-9078-81b12006aedc_0">
											<gml:posList>35.667304850055984 139.74130568844626 73.862 35.66733339591649 139.74132844325254 73.862 35.66733873098821 139.7413270564011 73.862 35.667304850055984 139.74130568844626 73.862</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7a22a906-a1fc-4b58-b688-b6c1fe323418">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7a22a906-a1fc-4b58-b688-b6c1fe323418_0">
											<gml:posList>35.66733312336017 139.74137283679528 69.141 35.66732603074067 139.7413861993484 71.475 35.66732603074067 139.7413861993484 69.141 35.66733312336017 139.74137283679528 69.141</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f3ef97bd-b2ed-47b4-929c-7c8223559401">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f3ef97bd-b2ed-47b4-929c-7c8223559401_0">
											<gml:posList>35.66733312336017 139.74137283679528 69.141 35.66733312336017 139.74137283679528 71.475 35.66732603074067 139.7413861993484 71.475 35.66733312336017 139.74137283679528 69.141</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d2901917-c24f-4594-8656-2390b91723d8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d2901917-c24f-4594-8656-2390b91723d8_0">
											<gml:posList>35.66732603074067 139.7413861993484 69.141 35.667312898748825 139.7413757319071 71.475 35.667312898748825 139.7413757319071 69.141 35.66732603074067 139.7413861993484 69.141</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-db467089-7fd9-46ab-b597-6f94085bf2b9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-db467089-7fd9-46ab-b597-6f94085bf2b9_0">
											<gml:posList>35.66732603074067 139.7413861993484 69.141 35.66732603074067 139.7413861993484 71.475 35.667312898748825 139.7413757319071 71.475 35.66732603074067 139.7413861993484 69.141</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c0e5b9be-3d03-417f-aa5b-2e63e662629d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c0e5b9be-3d03-417f-aa5b-2e63e662629d_0">
											<gml:posList>35.66728949328091 139.74139173102398 71.862 35.667272519079766 139.74137817515967 73.474 35.667272519079766 139.74137817515967 71.862 35.66728949328091 139.74139173102398 71.862</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a0d7d7f5-aa6d-4760-8831-0bdbb5aa75c1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a0d7d7f5-aa6d-4760-8831-0bdbb5aa75c1_0">
											<gml:posList>35.66728949328091 139.74139173102398 71.862 35.66728949328091 139.74139173102398 73.474 35.667272519079766 139.74137817515967 73.474 35.66728949328091 139.74139173102398 71.862</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b9b4dac1-0276-4b31-891e-af45bfeac3e5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b9b4dac1-0276-4b31-891e-af45bfeac3e5_0">
											<gml:posList>35.66730779530357 139.74138534763728 69.141 35.66732070181646 139.7413956386046 71.475 35.66732070181646 139.7413956386046 69.141 35.66730779530357 139.74138534763728 69.141</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-43da456b-51c9-44f4-afe7-d3f8e33368f8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-43da456b-51c9-44f4-afe7-d3f8e33368f8_0">
											<gml:posList>35.66730779530357 139.74138534763728 69.141 35.66730779530357 139.74138534763728 71.475 35.66732070181646 139.7413956386046 71.475 35.66730779530357 139.74138534763728 69.141</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-64e31ce7-2fcf-4f61-a118-05848c50350f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-64e31ce7-2fcf-4f61-a118-05848c50350f_0">
											<gml:posList>35.66733873098821 139.7413270564011 69.141 35.66726934394146 139.7414578192422 73.862 35.66726934394146 139.7414578192422 69.141 35.66733873098821 139.7413270564011 69.141</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-68827b33-6fb1-4526-b2bf-0c465c5b77b9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-68827b33-6fb1-4526-b2bf-0c465c5b77b9_0">
											<gml:posList>35.66733873098821 139.7413270564011 69.141 35.66733873098821 139.7413270564011 73.862 35.66726934394146 139.7414578192422 73.862 35.66733873098821 139.7413270564011 69.141</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d750a01c-bea8-4750-9096-e265348d6757">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d750a01c-bea8-4750-9096-e265348d6757_0">
											<gml:posList>35.66730779530357 139.74138534763728 71.475 35.667300351653246 139.74139937333766 71.475 35.66731326717025 139.74140965325014 71.475 35.66730779530357 139.74138534763728 71.475</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-028de9e6-b877-4ec5-8321-67a282193865">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-028de9e6-b877-4ec5-8321-67a282193865_0">
											<gml:posList>35.66732070181646 139.7413956386046 71.475 35.66730779530357 139.74138534763728 71.475 35.66731326717025 139.74140965325014 71.475 35.66732070181646 139.7413956386046 71.475</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5eac1e32-ea1c-482b-9714-a18cdf941c4c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5eac1e32-ea1c-482b-9714-a18cdf941c4c_0">
											<gml:posList>35.66726890772347 139.74139410738925 71.862 35.66727863946406 139.74140186145127 72.8 35.66727863946406 139.74140186145127 71.862 35.66726890772347 139.74139410738925 71.862</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fb644ad6-5cec-486b-976c-baf294005fae">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fb644ad6-5cec-486b-976c-baf294005fae_0">
											<gml:posList>35.66726890772347 139.74139410738925 71.862 35.66726890772347 139.74139410738925 72.8 35.66727863946406 139.74140186145127 72.8 35.66726890772347 139.74139410738925 71.862</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-61492e9d-7b4a-40db-8fd0-1dc77fd2abe2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-61492e9d-7b4a-40db-8fd0-1dc77fd2abe2_0">
											<gml:posList>35.66732070181646 139.7413956386046 69.141 35.66731326717025 139.74140965325014 71.475 35.66731326717025 139.74140965325014 69.141 35.66732070181646 139.7413956386046 69.141</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2f161a75-c37f-4d08-b952-f9737d6a0c8c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2f161a75-c37f-4d08-b952-f9737d6a0c8c_0">
											<gml:posList>35.66732070181646 139.7413956386046 69.141 35.66732070181646 139.7413956386046 71.475 35.66731326717025 139.74140965325014 71.475 35.66732070181646 139.7413956386046 69.141</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c92378d0-3e21-4d16-bda7-e1121ca7d923">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c92378d0-3e21-4d16-bda7-e1121ca7d923_0">
											<gml:posList>35.66731326717025 139.74140965325014 69.141 35.667300351653246 139.74139937333766 71.475 35.667300351653246 139.74139937333766 69.141 35.66731326717025 139.74140965325014 69.141</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cb4de3ea-946f-4d15-880e-0ee15e9f9d90">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cb4de3ea-946f-4d15-880e-0ee15e9f9d90_0">
											<gml:posList>35.66731326717025 139.74140965325014 69.141 35.66731326717025 139.74140965325014 71.475 35.667300351653246 139.74139937333766 71.475 35.66731326717025 139.74140965325014 69.141</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ef54e104-1ac6-4686-b1f3-3eeb1336512b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ef54e104-1ac6-4686-b1f3-3eeb1336512b_0">
											<gml:posList>35.66726890772347 139.74139410738925 72.8 35.667249331002914 139.74143098976398 72.8 35.66725906274117 139.74143874382858 72.8 35.66726890772347 139.74139410738925 72.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b7523157-8163-4eba-bdf7-6c444324cd26">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b7523157-8163-4eba-bdf7-6c444324cd26_0">
											<gml:posList>35.66727863946406 139.74140186145127 72.8 35.66726890772347 139.74139410738925 72.8 35.66725906274117 139.74143874382858 72.8 35.66727863946406 139.74140186145127 72.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-88f03579-f70d-46f2-ad33-b93e79806c7d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-88f03579-f70d-46f2-ad33-b93e79806c7d_0">
											<gml:posList>35.6672396573932 139.74142853763152 73.862 35.66726821223616 139.74145128140702 71.862 35.6672396573932 139.74142853763152 71.862 35.6672396573932 139.74142853763152 73.862</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-35d7666d-0301-4014-8e15-14f02855cea0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-35d7666d-0301-4014-8e15-14f02855cea0_0">
											<gml:posList>35.6672396573932 139.74142853763152 73.862 35.66726821223616 139.74145128140702 73.862 35.66726821223616 139.74145128140702 71.862 35.6672396573932 139.74142853763152 73.862</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-db1ea289-bbd7-4919-8e5b-e0506d2581d6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-db1ea289-bbd7-4919-8e5b-e0506d2581d6_0">
											<gml:posList>35.66726934394146 139.7414578192422 69.141 35.667234331333944 139.74142992446417 73.862 35.667234331333944 139.74142992446417 69.141 35.66726934394146 139.7414578192422 69.141</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-757a66fc-3601-4471-a1bc-6e40fc1a7600">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-757a66fc-3601-4471-a1bc-6e40fc1a7600_0">
											<gml:posList>35.66726934394146 139.7414578192422 69.141 35.66726934394146 139.7414578192422 73.862 35.667234331333944 139.74142992446417 73.862 35.66726934394146 139.7414578192422 69.141</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cd56880b-6793-4322-9e24-f66292c412a5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66726890772347 139.74139410738925 71.862 35.66727863946406 139.74140186145127 71.862 35.66725906274117 139.74143874382858 71.862 35.66726890772347 139.74139410738925 71.862</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-aa485085-3f20-459c-840e-4100a1b05f69">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667249331002914 139.74143098976398 71.862 35.66726890772347 139.74139410738925 71.862 35.66725906274117 139.74143874382858 71.862 35.667249331002914 139.74143098976398 71.862</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-53d3acfc-de9a-4edb-a41a-58b417c77b87">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66726934394146 139.7414578192422 69.141 35.66730371835086 139.74129916165617 69.141 35.66733873098821 139.7413270564011 69.141 35.66726934394146 139.7414578192422 69.141</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e7f53b8a-2d41-4f3c-859f-4e84ceff360f">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66726934394146 139.7414578192422 69.141 35.667234331333944 139.74142992446417 69.141 35.66730371835086 139.74129916165617 69.141 35.66726934394146 139.7414578192422 69.141</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3e29b0f0-d742-4316-9d77-dea53504af31">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667272519079766 139.74137817515967 71.862 35.66731136524985 139.74135060438707 71.862 35.66728949328091 139.74139173102398 71.862 35.667272519079766 139.74137817515967 71.862</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5902d57a-5682-46f7-952b-d359843c8f2d">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667272519079766 139.74137817515967 71.862 35.66729440005788 139.7413370485175 71.862 35.66731136524985 139.74135060438707 71.862 35.667272519079766 139.74137817515967 71.862</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b427623b-c4bc-461e-aaf3-b7b0e272f92f">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66730779530357 139.74138534763728 69.141 35.66732070181646 139.7413956386046 69.141 35.66731326717025 139.74140965325014 69.141 35.66730779530357 139.74138534763728 69.141</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-94297ef3-acc8-4b10-b7b4-db29ad708d0c">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667300351653246 139.74139937333766 69.141 35.66730779530357 139.74138534763728 69.141 35.66731326717025 139.74140965325014 69.141 35.667300351653246 139.74139937333766 69.141</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-036932a4-37fa-4f9c-b6ac-8ff153856f9d">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66733312336017 139.74137283679528 69.141 35.66732603074067 139.7413861993484 69.141 35.667312898748825 139.7413757319071 69.141 35.66733312336017 139.74137283679528 69.141</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ab216d35-b88b-4da4-8f72-94ad4e29e685">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667319991367194 139.74136236935524 69.141 35.66733312336017 139.74137283679528 69.141 35.667312898748825 139.7413757319071 69.141 35.667319991367194 139.74136236935524 69.141</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-e5887db8-1e07-43b4-a553-18a96871aa7d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e5887db8-1e07-43b4-a553-18a96871aa7d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e5887db8-1e07-43b4-a553-18a96871aa7d">
											<gml:posList>35.66728266462829 139.74150297039017 24.1 35.667275887070446 139.7415158023627 24.1 35.667240739262006 139.74148789666611 24.1 35.66724703978873 139.74147598204704 24.1 35.66717351527593 139.74141761180456 24.1 35.667270408105956 139.74123433876764 24.1 35.66730105538636 139.74125867068022 24.1 35.66730568175279 139.74124991706591 24.1 35.6673519232388 139.74128662452713 24.1 35.66734656780469 139.74129674866558 24.1 35.66737975848784 139.74132309909643 24.1 35.667376248206445 139.7413297416776 24.1 35.66738617835427 139.74133762806468 24.1 35.66736553067968 139.7413766877667 24.1 35.66737859949933 139.7413870558748 24.1 35.667353946466214 139.7414336755076 24.1 35.66738083269778 139.74145501840664 24.1 35.66737612530251 139.7414639157062 24.1 35.66738537899912 139.74147126163834 24.1 35.66735814272454 139.74152277751566 24.1 35.66734888903102 139.74151543158 24.1 35.66733394777612 139.74154369290116 24.1 35.66728266462829 139.74150297039017 24.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-5bab476b-a9ca-47e5-be56-a8602d593a39">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5bab476b-a9ca-47e5-be56-a8602d593a39">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5bab476b-a9ca-47e5-be56-a8602d593a39">
											<gml:posList>35.66730105538636 139.74125867068022 70.5 35.667270408105956 139.74123433876764 70.5 35.667271422095496 139.74124015875609 70.5 35.66730206938316 139.74126450171704 70.5 35.66730105538636 139.74125867068022 70.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-7a6c2fac-36c5-4022-bd7f-563921334862">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7a6c2fac-36c5-4022-bd7f-563921334862">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7a6c2fac-36c5-4022-bd7f-563921334862">
											<gml:posList>35.66730105538636 139.74125867068022 70.5 35.66730206938316 139.74126450171704 70.5 35.66730669574157 139.7412557370571 70.5 35.66730568175279 139.74124991706591 70.5 35.66730105538636 139.74125867068022 70.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-9072ff39-6f9e-4c19-99c8-7365918564ad">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9072ff39-6f9e-4c19-99c8-7365918564ad">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9072ff39-6f9e-4c19-99c8-7365918564ad">
											<gml:posList>35.66730568175279 139.74124991706591 70.5 35.66730669574157 139.7412557370571 70.5 35.667347173958525 139.74128787815897 70.5 35.6673519232388 139.74128662452713 70.5 35.66730568175279 139.74124991706591 70.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-99f6bc9a-c94d-4e35-a0c1-363c76d82b21">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-99f6bc9a-c94d-4e35-a0c1-363c76d82b21">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-99f6bc9a-c94d-4e35-a0c1-363c76d82b21">
											<gml:posList>35.66734656780469 139.74129674866558 70.5 35.6673519232388 139.74128662452713 70.5 35.667347173958525 139.74128787815897 70.5 35.66734180951058 139.74129800230708 70.5 35.66734656780469 139.74129674866558 70.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ea42c51e-16df-4a94-9215-c415ec43c1d6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ea42c51e-16df-4a94-9215-c415ec43c1d6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ea42c51e-16df-4a94-9215-c415ec43c1d6">
											<gml:posList>35.66734656780469 139.74129674866558 70.5 35.66734180951058 139.74129800230708 70.5 35.66737500920721 139.74132435272654 70.5 35.66737975848784 139.74132309909643 70.5 35.66734656780469 139.74129674866558 70.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f74290c5-681e-4cac-b828-a1410f730304">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f74290c5-681e-4cac-b828-a1410f730304">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f74290c5-681e-4cac-b828-a1410f730304">
											<gml:posList>35.66724703978873 139.74147598204704 70.5 35.66725178907948 139.74147473947374 70.5 35.66717825555241 139.7414163692393 70.5 35.66717351527593 139.74141761180456 70.5 35.66724703978873 139.74147598204704 70.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e8bae464-56ab-4201-b8ef-960620ef4e21">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e8bae464-56ab-4201-b8ef-960620ef4e21">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e8bae464-56ab-4201-b8ef-960620ef4e21">
											<gml:posList>35.66717351527593 139.74141761180456 70.5 35.66717825555241 139.7414163692393 70.5 35.667271422095496 139.74124015875609 70.5 35.667270408105956 139.74123433876764 70.5 35.66717351527593 139.74141761180456 70.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c9faa16a-d583-41bc-8fae-54a7d4de08c6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c9faa16a-d583-41bc-8fae-54a7d4de08c6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c9faa16a-d583-41bc-8fae-54a7d4de08c6">
											<gml:posList>35.66724703978873 139.74147598204704 70.5 35.667240739262006 139.74148789666611 70.5 35.66724547953916 139.74148665410394 70.5 35.66725178907948 139.74147473947374 70.5 35.66724703978873 139.74147598204704 70.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-3bcb8e64-16e7-4e99-8448-5cbd58eff6fc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3bcb8e64-16e7-4e99-8448-5cbd58eff6fc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3bcb8e64-16e7-4e99-8448-5cbd58eff6fc">
											<gml:posList>35.667275887070446 139.7415158023627 70.5 35.66727487310265 139.74150999341626 70.5 35.66724547953916 139.74148665410394 70.5 35.667240739262006 139.74148789666611 70.5 35.667275887070446 139.7415158023627 70.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f5aa40f7-477a-407a-b9d6-e83fb58b950b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f5aa40f7-477a-407a-b9d6-e83fb58b950b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f5aa40f7-477a-407a-b9d6-e83fb58b950b">
											<gml:posList>35.66728266462829 139.74150297039017 70.5 35.667281650651454 139.74149715039758 70.5 35.66727487310265 139.74150999341626 70.5 35.667275887070446 139.7415158023627 70.5 35.66728266462829 139.74150297039017 70.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-77373ff6-4b3a-4efb-b397-bf2a155ce848">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-77373ff6-4b3a-4efb-b397-bf2a155ce848">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-77373ff6-4b3a-4efb-b397-bf2a155ce848">
											<gml:posList>35.66725178907948 139.74147473947374 69.141 35.66724547953916 139.74148665410394 69.141 35.66727487310265 139.74150999341626 69.141 35.667281650651454 139.74149715039758 69.141 35.66733292479594 139.74153788396046 69.141 35.667347866041055 139.74150961159276 69.141 35.667357119743365 139.74151696857345 69.141 35.66738062970851 139.74147250421396 69.141 35.66737136699824 139.7414651582924 69.141 35.66737608340734 139.74145626098314 69.141 35.66734918816225 139.74143491809525 69.141 35.66737385021803 139.74138830950113 69.141 35.66736077238474 139.74137794140373 69.141 35.6673814290735 139.74133888169405 69.141 35.667371489912014 139.74133099531758 69.141 35.66737500920721 139.74132435272654 69.141 35.66734180951058 139.74129800230708 69.141 35.667347173958525 139.74128787815897 69.141 35.66730669574157 139.7412557370571 69.141 35.66730206938316 139.74126450171704 69.141 35.667271422095496 139.74124015875609 69.141 35.66717825555241 139.7414163692393 69.141 35.66725178907948 139.74147473947374 69.141</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-581edb5d-cef4-429d-a9e0-aa2f341821bd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-581edb5d-cef4-429d-a9e0-aa2f341821bd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-581edb5d-cef4-429d-a9e0-aa2f341821bd">
											<gml:posList>35.66728266462829 139.74150297039017 70.5 35.66733394777612 139.74154369290116 70.5 35.66733292479594 139.74153788396046 70.5 35.667281650651454 139.74149715039758 70.5 35.66728266462829 139.74150297039017 70.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-7fe9ba25-be80-4260-881b-e7833f6cb4e6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7fe9ba25-be80-4260-881b-e7833f6cb4e6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7fe9ba25-be80-4260-881b-e7833f6cb4e6">
											<gml:posList>35.66734888903102 139.74151543158 70.5 35.667347866041055 139.74150961159276 70.5 35.66733292479594 139.74153788396046 70.5 35.66733394777612 139.74154369290116 70.5 35.66734888903102 139.74151543158 70.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ead3e5dc-35e5-4427-a977-ded7f7a5c8dc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ead3e5dc-35e5-4427-a977-ded7f7a5c8dc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ead3e5dc-35e5-4427-a977-ded7f7a5c8dc">
											<gml:posList>35.66734888903102 139.74151543158 70.5 35.66735814272454 139.74152277751566 70.5 35.667357119743365 139.74151696857345 70.5 35.667347866041055 139.74150961159276 70.5 35.66734888903102 139.74151543158 70.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-98ee6aa6-45a9-4cc8-9e73-6eaab16138b7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-98ee6aa6-45a9-4cc8-9e73-6eaab16138b7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-98ee6aa6-45a9-4cc8-9e73-6eaab16138b7">
											<gml:posList>35.667353946466214 139.7414336755076 70.5 35.66737859949933 139.7413870558748 70.5 35.66737385021803 139.74138830950113 70.5 35.66734918816225 139.74143491809525 70.5 35.667353946466214 139.7414336755076 70.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-0da65ed5-da1f-477f-9426-6303ba810618">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0da65ed5-da1f-477f-9426-6303ba810618">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0da65ed5-da1f-477f-9426-6303ba810618">
											<gml:posList>35.667353946466214 139.7414336755076 70.5 35.66734918816225 139.74143491809525 70.5 35.66737608340734 139.74145626098314 70.5 35.66738083269778 139.74145501840664 70.5 35.667353946466214 139.7414336755076 70.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-fe8310eb-1cc4-471f-a21b-7398ff67be0e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fe8310eb-1cc4-471f-a21b-7398ff67be0e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fe8310eb-1cc4-471f-a21b-7398ff67be0e">
											<gml:posList>35.66736553067968 139.7413766877667 70.5 35.66736077238474 139.74137794140373 70.5 35.66737385021803 139.74138830950113 70.5 35.66737859949933 139.7413870558748 70.5 35.66736553067968 139.7413766877667 70.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-760a0413-1359-4d52-854f-d302877ae370">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-760a0413-1359-4d52-854f-d302877ae370">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-760a0413-1359-4d52-854f-d302877ae370">
											<gml:posList>35.66738537899912 139.74147126163834 70.5 35.66738062970851 139.74147250421396 70.5 35.667357119743365 139.74151696857345 70.5 35.66735814272454 139.74152277751566 70.5 35.66738537899912 139.74147126163834 70.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-2da96cd9-e7f4-4c38-ad58-b290b596c07f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2da96cd9-e7f4-4c38-ad58-b290b596c07f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2da96cd9-e7f4-4c38-ad58-b290b596c07f">
											<gml:posList>35.66736553067968 139.7413766877667 70.5 35.66738617835427 139.74133762806468 70.5 35.6673814290735 139.74133888169405 70.5 35.66736077238474 139.74137794140373 70.5 35.66736553067968 139.7413766877667 70.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-4935edd0-1a41-4e42-bce2-ee90aa457c9c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4935edd0-1a41-4e42-bce2-ee90aa457c9c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4935edd0-1a41-4e42-bce2-ee90aa457c9c">
											<gml:posList>35.667376248206445 139.7413297416776 70.5 35.66737975848784 139.74132309909643 70.5 35.66737500920721 139.74132435272654 70.5 35.667371489912014 139.74133099531758 70.5 35.667376248206445 139.7413297416776 70.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c95b1041-3a07-47ea-beb7-c45e62dfa95f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c95b1041-3a07-47ea-beb7-c45e62dfa95f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c95b1041-3a07-47ea-beb7-c45e62dfa95f">
											<gml:posList>35.66737612530251 139.7414639157062 70.5 35.66738083269778 139.74145501840664 70.5 35.66737608340734 139.74145626098314 70.5 35.66737136699824 139.7414651582924 70.5 35.66737612530251 139.7414639157062 70.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b4308692-6226-4faf-9dfd-be2b7f19f729">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b4308692-6226-4faf-9dfd-be2b7f19f729">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b4308692-6226-4faf-9dfd-be2b7f19f729">
											<gml:posList>35.66737612530251 139.7414639157062 70.5 35.66737136699824 139.7414651582924 70.5 35.66738062970851 139.74147250421396 70.5 35.66738537899912 139.74147126163834 70.5 35.66737612530251 139.7414639157062 70.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-3d27317b-7038-43c4-a15c-c13ad622dfa4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3d27317b-7038-43c4-a15c-c13ad622dfa4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3d27317b-7038-43c4-a15c-c13ad622dfa4">
											<gml:posList>35.667376248206445 139.7413297416776 70.5 35.667371489912014 139.74133099531758 70.5 35.6673814290735 139.74133888169405 70.5 35.66738617835427 139.74133762806468 70.5 35.667376248206445 139.7413297416776 70.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-39bd3d30-c051-41ce-baa6-f018f6f094c6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-39bd3d30-c051-41ce-baa6-f018f6f094c6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-39bd3d30-c051-41ce-baa6-f018f6f094c6">
											<gml:posList>35.66730105538636 139.74125867068022 24.1 35.667270408105956 139.74123433876764 24.1 35.667270408105956 139.74123433876764 70.5 35.66730105538636 139.74125867068022 70.5 35.66730105538636 139.74125867068022 24.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-710d980e-ac81-4d88-bd4d-4de1f2a75d4a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-710d980e-ac81-4d88-bd4d-4de1f2a75d4a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-710d980e-ac81-4d88-bd4d-4de1f2a75d4a">
											<gml:posList>35.667271422095496 139.74124015875609 70.5 35.667271422095496 139.74124015875609 69.141 35.66730206938316 139.74126450171704 69.141 35.66730206938316 139.74126450171704 70.5 35.667271422095496 139.74124015875609 70.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-90a006e8-a8b7-42e4-8268-f6af8b481a36">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-90a006e8-a8b7-42e4-8268-f6af8b481a36">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-90a006e8-a8b7-42e4-8268-f6af8b481a36">
											<gml:posList>35.66730568175279 139.74124991706591 24.1 35.66730105538636 139.74125867068022 24.1 35.66730105538636 139.74125867068022 70.5 35.66730568175279 139.74124991706591 70.5 35.66730568175279 139.74124991706591 24.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-34989037-dd36-4dc2-b208-d7f882656fa4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-34989037-dd36-4dc2-b208-d7f882656fa4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-34989037-dd36-4dc2-b208-d7f882656fa4">
											<gml:posList>35.66730206938316 139.74126450171704 70.5 35.66730206938316 139.74126450171704 69.141 35.66730669574157 139.7412557370571 69.141 35.66730669574157 139.7412557370571 70.5 35.66730206938316 139.74126450171704 70.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3c3c085f-3262-4c9b-97ba-8c91d28c336b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3c3c085f-3262-4c9b-97ba-8c91d28c336b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3c3c085f-3262-4c9b-97ba-8c91d28c336b">
											<gml:posList>35.6673519232388 139.74128662452713 24.1 35.66730568175279 139.74124991706591 24.1 35.66730568175279 139.74124991706591 70.5 35.6673519232388 139.74128662452713 70.5 35.6673519232388 139.74128662452713 24.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9308ca2b-bc8e-4a22-82ca-40b92d454ef0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9308ca2b-bc8e-4a22-82ca-40b92d454ef0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9308ca2b-bc8e-4a22-82ca-40b92d454ef0">
											<gml:posList>35.66730669574157 139.7412557370571 70.5 35.66730669574157 139.7412557370571 69.141 35.667347173958525 139.74128787815897 69.141 35.667347173958525 139.74128787815897 70.5 35.66730669574157 139.7412557370571 70.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1ffdae80-e035-4f03-96c1-bbd5d7700a48">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1ffdae80-e035-4f03-96c1-bbd5d7700a48">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1ffdae80-e035-4f03-96c1-bbd5d7700a48">
											<gml:posList>35.66734656780469 139.74129674866558 24.1 35.6673519232388 139.74128662452713 24.1 35.6673519232388 139.74128662452713 70.5 35.66734656780469 139.74129674866558 70.5 35.66734656780469 139.74129674866558 24.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d276594d-4b53-4a09-962d-5327bbca0247">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d276594d-4b53-4a09-962d-5327bbca0247">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d276594d-4b53-4a09-962d-5327bbca0247">
											<gml:posList>35.667347173958525 139.74128787815897 70.5 35.667347173958525 139.74128787815897 69.141 35.66734180951058 139.74129800230708 69.141 35.66734180951058 139.74129800230708 70.5 35.667347173958525 139.74128787815897 70.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e91cbc3d-df21-48d1-b379-2ef0c51e37c1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e91cbc3d-df21-48d1-b379-2ef0c51e37c1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e91cbc3d-df21-48d1-b379-2ef0c51e37c1">
											<gml:posList>35.66737975848784 139.74132309909643 24.1 35.66734656780469 139.74129674866558 24.1 35.66734656780469 139.74129674866558 70.5 35.66737975848784 139.74132309909643 70.5 35.66737975848784 139.74132309909643 24.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1ac969dc-61c7-47c0-960b-a40940027d85">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1ac969dc-61c7-47c0-960b-a40940027d85">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1ac969dc-61c7-47c0-960b-a40940027d85">
											<gml:posList>35.66734180951058 139.74129800230708 70.5 35.66734180951058 139.74129800230708 69.141 35.66737500920721 139.74132435272654 69.141 35.66737500920721 139.74132435272654 70.5 35.66734180951058 139.74129800230708 70.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-033eee68-dd16-40c1-bad0-78276bb6bd06">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-033eee68-dd16-40c1-bad0-78276bb6bd06">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-033eee68-dd16-40c1-bad0-78276bb6bd06">
											<gml:posList>35.667270408105956 139.74123433876764 24.1 35.66717351527593 139.74141761180456 24.1 35.66717351527593 139.74141761180456 70.5 35.667270408105956 139.74123433876764 70.5 35.667270408105956 139.74123433876764 24.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-fc0c0190-d867-4e87-b1d0-5c163ff5c601">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fc0c0190-d867-4e87-b1d0-5c163ff5c601">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fc0c0190-d867-4e87-b1d0-5c163ff5c601">
											<gml:posList>35.667376248206445 139.7413297416776 24.1 35.66737975848784 139.74132309909643 24.1 35.66737975848784 139.74132309909643 70.5 35.667376248206445 139.7413297416776 70.5 35.667376248206445 139.7413297416776 24.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-236d5d40-3cf9-4017-88bb-9c84f3fd9a51">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-236d5d40-3cf9-4017-88bb-9c84f3fd9a51">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-236d5d40-3cf9-4017-88bb-9c84f3fd9a51">
											<gml:posList>35.66737500920721 139.74132435272654 70.5 35.66737500920721 139.74132435272654 69.141 35.667371489912014 139.74133099531758 69.141 35.667371489912014 139.74133099531758 70.5 35.66737500920721 139.74132435272654 70.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5838fa0a-1ccb-40d5-ae05-090729f150c6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5838fa0a-1ccb-40d5-ae05-090729f150c6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5838fa0a-1ccb-40d5-ae05-090729f150c6">
											<gml:posList>35.66717825555241 139.7414163692393 70.5 35.66717825555241 139.7414163692393 69.141 35.667271422095496 139.74124015875609 69.141 35.667271422095496 139.74124015875609 70.5 35.66717825555241 139.7414163692393 70.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9d85e409-9dd6-4cc3-9d33-bf4fd33714bb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9d85e409-9dd6-4cc3-9d33-bf4fd33714bb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9d85e409-9dd6-4cc3-9d33-bf4fd33714bb">
											<gml:posList>35.66738617835427 139.74133762806468 24.1 35.667376248206445 139.7413297416776 24.1 35.667376248206445 139.7413297416776 70.5 35.66738617835427 139.74133762806468 70.5 35.66738617835427 139.74133762806468 24.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9c3f574e-1aef-4ffc-9966-b33d8119f0eb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9c3f574e-1aef-4ffc-9966-b33d8119f0eb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9c3f574e-1aef-4ffc-9966-b33d8119f0eb">
											<gml:posList>35.667371489912014 139.74133099531758 70.5 35.667371489912014 139.74133099531758 69.141 35.6673814290735 139.74133888169405 69.141 35.6673814290735 139.74133888169405 70.5 35.667371489912014 139.74133099531758 70.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-86718fcd-b4c2-46fc-9740-888f13cd4f5b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-86718fcd-b4c2-46fc-9740-888f13cd4f5b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-86718fcd-b4c2-46fc-9740-888f13cd4f5b">
											<gml:posList>35.66736553067968 139.7413766877667 24.1 35.66738617835427 139.74133762806468 24.1 35.66738617835427 139.74133762806468 70.5 35.66736553067968 139.7413766877667 70.5 35.66736553067968 139.7413766877667 24.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7c03c96f-e539-46d2-9fe8-c44fa7b06730">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7c03c96f-e539-46d2-9fe8-c44fa7b06730">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7c03c96f-e539-46d2-9fe8-c44fa7b06730">
											<gml:posList>35.6673814290735 139.74133888169405 70.5 35.6673814290735 139.74133888169405 69.141 35.66736077238474 139.74137794140373 69.141 35.66736077238474 139.74137794140373 70.5 35.6673814290735 139.74133888169405 70.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-edf34bf0-024c-44af-b764-39f37df882c4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-edf34bf0-024c-44af-b764-39f37df882c4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-edf34bf0-024c-44af-b764-39f37df882c4">
											<gml:posList>35.66737859949933 139.7413870558748 24.1 35.66736553067968 139.7413766877667 24.1 35.66736553067968 139.7413766877667 70.5 35.66737859949933 139.7413870558748 70.5 35.66737859949933 139.7413870558748 24.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1c056be9-f53b-49d7-9ae7-85ad87d630a0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1c056be9-f53b-49d7-9ae7-85ad87d630a0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1c056be9-f53b-49d7-9ae7-85ad87d630a0">
											<gml:posList>35.66736077238474 139.74137794140373 70.5 35.66736077238474 139.74137794140373 69.141 35.66737385021803 139.74138830950113 69.141 35.66737385021803 139.74138830950113 70.5 35.66736077238474 139.74137794140373 70.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6fa31885-cef7-465f-8886-43adc08fa47a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6fa31885-cef7-465f-8886-43adc08fa47a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6fa31885-cef7-465f-8886-43adc08fa47a">
											<gml:posList>35.667353946466214 139.7414336755076 24.1 35.66737859949933 139.7413870558748 24.1 35.66737859949933 139.7413870558748 70.5 35.667353946466214 139.7414336755076 70.5 35.667353946466214 139.7414336755076 24.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5d1f2833-affa-4a6e-80f9-361f71d784a2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5d1f2833-affa-4a6e-80f9-361f71d784a2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5d1f2833-affa-4a6e-80f9-361f71d784a2">
											<gml:posList>35.66737385021803 139.74138830950113 70.5 35.66737385021803 139.74138830950113 69.141 35.66734918816225 139.74143491809525 69.141 35.66734918816225 139.74143491809525 70.5 35.66737385021803 139.74138830950113 70.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0eb7f737-b881-4e08-a927-1b05ea205e45">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0eb7f737-b881-4e08-a927-1b05ea205e45">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0eb7f737-b881-4e08-a927-1b05ea205e45">
											<gml:posList>35.66738083269778 139.74145501840664 24.1 35.667353946466214 139.7414336755076 24.1 35.667353946466214 139.7414336755076 70.5 35.66738083269778 139.74145501840664 70.5 35.66738083269778 139.74145501840664 24.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f5650d15-0bcb-44ed-8d55-a0c2aa75ab51">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f5650d15-0bcb-44ed-8d55-a0c2aa75ab51">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f5650d15-0bcb-44ed-8d55-a0c2aa75ab51">
											<gml:posList>35.66725178907948 139.74147473947374 70.5 35.66725178907948 139.74147473947374 69.141 35.66717825555241 139.7414163692393 69.141 35.66717825555241 139.7414163692393 70.5 35.66725178907948 139.74147473947374 70.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ebdfa20f-2d86-437d-9d77-16d9b41db17d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ebdfa20f-2d86-437d-9d77-16d9b41db17d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ebdfa20f-2d86-437d-9d77-16d9b41db17d">
											<gml:posList>35.66734918816225 139.74143491809525 70.5 35.66734918816225 139.74143491809525 69.141 35.66737608340734 139.74145626098314 69.141 35.66737608340734 139.74145626098314 70.5 35.66734918816225 139.74143491809525 70.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e29a050f-3edf-47ef-b223-3530b8198b7d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e29a050f-3edf-47ef-b223-3530b8198b7d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e29a050f-3edf-47ef-b223-3530b8198b7d">
											<gml:posList>35.66717351527593 139.74141761180456 24.1 35.66724703978873 139.74147598204704 24.1 35.66724703978873 139.74147598204704 70.5 35.66717351527593 139.74141761180456 70.5 35.66717351527593 139.74141761180456 24.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c0996a33-93de-4ad5-96f6-2ab2518d818f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c0996a33-93de-4ad5-96f6-2ab2518d818f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c0996a33-93de-4ad5-96f6-2ab2518d818f">
											<gml:posList>35.66737612530251 139.7414639157062 24.1 35.66738083269778 139.74145501840664 24.1 35.66738083269778 139.74145501840664 70.5 35.66737612530251 139.7414639157062 70.5 35.66737612530251 139.7414639157062 24.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5169a71d-7edd-4fe9-ab0b-d495b6eb8282">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5169a71d-7edd-4fe9-ab0b-d495b6eb8282">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5169a71d-7edd-4fe9-ab0b-d495b6eb8282">
											<gml:posList>35.66737608340734 139.74145626098314 70.5 35.66737608340734 139.74145626098314 69.141 35.66737136699824 139.7414651582924 69.141 35.66737136699824 139.7414651582924 70.5 35.66737608340734 139.74145626098314 70.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-41b2fc2c-8b51-46ea-b8d1-7927b502f033">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-41b2fc2c-8b51-46ea-b8d1-7927b502f033">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-41b2fc2c-8b51-46ea-b8d1-7927b502f033">
											<gml:posList>35.66738537899912 139.74147126163834 24.1 35.66737612530251 139.7414639157062 24.1 35.66737612530251 139.7414639157062 70.5 35.66738537899912 139.74147126163834 70.5 35.66738537899912 139.74147126163834 24.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5200940b-bec2-4282-9fde-9dd723eea595">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5200940b-bec2-4282-9fde-9dd723eea595">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5200940b-bec2-4282-9fde-9dd723eea595">
											<gml:posList>35.66737136699824 139.7414651582924 70.5 35.66737136699824 139.7414651582924 69.141 35.66738062970851 139.74147250421396 69.141 35.66738062970851 139.74147250421396 70.5 35.66737136699824 139.7414651582924 70.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9c11e8b6-e762-40a9-8ad5-38d35852440d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9c11e8b6-e762-40a9-8ad5-38d35852440d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9c11e8b6-e762-40a9-8ad5-38d35852440d">
											<gml:posList>35.66724547953916 139.74148665410394 70.5 35.66724547953916 139.74148665410394 69.141 35.66725178907948 139.74147473947374 69.141 35.66725178907948 139.74147473947374 70.5 35.66724547953916 139.74148665410394 70.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-65669179-288b-4f47-840c-8f390525b760">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-65669179-288b-4f47-840c-8f390525b760">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-65669179-288b-4f47-840c-8f390525b760">
											<gml:posList>35.66724703978873 139.74147598204704 24.1 35.667240739262006 139.74148789666611 24.1 35.667240739262006 139.74148789666611 70.5 35.66724703978873 139.74147598204704 70.5 35.66724703978873 139.74147598204704 24.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1314d6a7-d51c-4029-beda-7dc0f1c7e34f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1314d6a7-d51c-4029-beda-7dc0f1c7e34f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1314d6a7-d51c-4029-beda-7dc0f1c7e34f">
											<gml:posList>35.66738062970851 139.74147250421396 70.5 35.66738062970851 139.74147250421396 69.141 35.667357119743365 139.74151696857345 69.141 35.667357119743365 139.74151696857345 70.5 35.66738062970851 139.74147250421396 70.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-04b4c585-128a-4616-b8e3-74ddc9ab7b20">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-04b4c585-128a-4616-b8e3-74ddc9ab7b20">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-04b4c585-128a-4616-b8e3-74ddc9ab7b20">
											<gml:posList>35.66735814272454 139.74152277751566 24.1 35.66738537899912 139.74147126163834 24.1 35.66738537899912 139.74147126163834 70.5 35.66735814272454 139.74152277751566 70.5 35.66735814272454 139.74152277751566 24.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-035beeda-f304-4335-b748-dd8665f54771">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-035beeda-f304-4335-b748-dd8665f54771">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-035beeda-f304-4335-b748-dd8665f54771">
											<gml:posList>35.66727487310265 139.74150999341626 70.5 35.66727487310265 139.74150999341626 69.141 35.66724547953916 139.74148665410394 69.141 35.66724547953916 139.74148665410394 70.5 35.66727487310265 139.74150999341626 70.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6d3ed814-ec27-4a36-9987-07eafb9ba23d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6d3ed814-ec27-4a36-9987-07eafb9ba23d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6d3ed814-ec27-4a36-9987-07eafb9ba23d">
											<gml:posList>35.667240739262006 139.74148789666611 24.1 35.667275887070446 139.7415158023627 24.1 35.667275887070446 139.7415158023627 70.5 35.667240739262006 139.74148789666611 70.5 35.667240739262006 139.74148789666611 24.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2553b45a-3bf6-40be-97e9-4c4ae7721d47">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2553b45a-3bf6-40be-97e9-4c4ae7721d47">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2553b45a-3bf6-40be-97e9-4c4ae7721d47">
											<gml:posList>35.667281650651454 139.74149715039758 70.5 35.667281650651454 139.74149715039758 69.141 35.66727487310265 139.74150999341626 69.141 35.66727487310265 139.74150999341626 70.5 35.667281650651454 139.74149715039758 70.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b50b8eff-bb63-44e4-a8e9-656c6ce25c1d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b50b8eff-bb63-44e4-a8e9-656c6ce25c1d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b50b8eff-bb63-44e4-a8e9-656c6ce25c1d">
											<gml:posList>35.667275887070446 139.7415158023627 24.1 35.66728266462829 139.74150297039017 24.1 35.66728266462829 139.74150297039017 70.5 35.667275887070446 139.7415158023627 70.5 35.667275887070446 139.7415158023627 24.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c8c6167a-56ed-41e6-bbcc-00a6cb59cfe5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c8c6167a-56ed-41e6-bbcc-00a6cb59cfe5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c8c6167a-56ed-41e6-bbcc-00a6cb59cfe5">
											<gml:posList>35.667357119743365 139.74151696857345 70.5 35.667357119743365 139.74151696857345 69.141 35.667347866041055 139.74150961159276 69.141 35.667347866041055 139.74150961159276 70.5 35.667357119743365 139.74151696857345 70.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-657d3ae4-dfa5-4db3-b9cb-2cc6f6222c30">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-657d3ae4-dfa5-4db3-b9cb-2cc6f6222c30">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-657d3ae4-dfa5-4db3-b9cb-2cc6f6222c30">
											<gml:posList>35.66733292479594 139.74153788396046 70.5 35.66733292479594 139.74153788396046 69.141 35.667281650651454 139.74149715039758 69.141 35.667281650651454 139.74149715039758 70.5 35.66733292479594 139.74153788396046 70.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-fb2a8178-f3cf-417d-90cf-6719cec57436">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fb2a8178-f3cf-417d-90cf-6719cec57436">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fb2a8178-f3cf-417d-90cf-6719cec57436">
											<gml:posList>35.66734888903102 139.74151543158 24.1 35.66735814272454 139.74152277751566 24.1 35.66735814272454 139.74152277751566 70.5 35.66734888903102 139.74151543158 70.5 35.66734888903102 139.74151543158 24.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-be3a42f6-c598-4aca-aa09-994cb9cdb174">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-be3a42f6-c598-4aca-aa09-994cb9cdb174">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-be3a42f6-c598-4aca-aa09-994cb9cdb174">
											<gml:posList>35.66728266462829 139.74150297039017 24.1 35.66733394777612 139.74154369290116 24.1 35.66733394777612 139.74154369290116 70.5 35.66728266462829 139.74150297039017 70.5 35.66728266462829 139.74150297039017 24.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-faee9cee-f3b8-4972-8e33-b2863e973172">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-faee9cee-f3b8-4972-8e33-b2863e973172">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-faee9cee-f3b8-4972-8e33-b2863e973172">
											<gml:posList>35.667347866041055 139.74150961159276 70.5 35.667347866041055 139.74150961159276 69.141 35.66733292479594 139.74153788396046 69.141 35.66733292479594 139.74153788396046 70.5 35.667347866041055 139.74150961159276 70.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a120c718-dfa6-4c7e-9652-3aebce5667bc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a120c718-dfa6-4c7e-9652-3aebce5667bc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a120c718-dfa6-4c7e-9652-3aebce5667bc">
											<gml:posList>35.66733394777612 139.74154369290116 24.1 35.66734888903102 139.74151543158 24.1 35.66734888903102 139.74151543158 70.5 35.66733394777612 139.74154369290116 70.5 35.66733394777612 139.74154369290116 24.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂一丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-4733</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">581.6461</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">6</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1210</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.6</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>4</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.08</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>