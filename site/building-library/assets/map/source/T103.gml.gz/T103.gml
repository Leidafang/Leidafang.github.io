<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_19c974a0-b35a-4931-a46b-7842be2263db">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>18</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103018001</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">401</bldg:usage>
			<bldg:measuredHeight uom="m">31.6</bldg:measuredHeight>
			<bldg:storeysAboveGround>9</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.67049710931123 139.74998319344027 0 35.67049818866426 139.74997987843523 0 35.670528575621056 139.74999531163758 0 35.67053617669677 139.74997287978468 0 35.67054557684145 139.74994514384062 0 35.67050578523502 139.74992491530637 0 35.67039183857063 139.74986698573835 0 35.670373577679854 139.74992035818136 0 35.67049710931123 139.74998319344027 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67049710931123 139.74998319344027 6.44 35.670373577679854 139.74992035818136 6.44 35.67039183857063 139.74986698573835 6.44 35.67050578523502 139.74992491530637 6.44 35.67054557684145 139.74994514384062 6.44 35.67053617669677 139.74997287978468 6.44 35.670528575621056 139.74999531163758 6.44 35.67049818866426 139.74997987843523 6.44 35.67049710931123 139.74998319344027 6.44</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67049710931123 139.74998319344027 6.44 35.67049818866426 139.74997987843523 6.44 35.67049818866426 139.74997987843523 34.49 35.67049710931123 139.74998319344027 34.49 35.67049710931123 139.74998319344027 6.44</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67049818866426 139.74997987843523 6.44 35.670528575621056 139.74999531163758 6.44 35.670528575621056 139.74999531163758 34.49 35.67049818866426 139.74997987843523 34.49 35.67049818866426 139.74997987843523 6.44</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670528575621056 139.74999531163758 6.44 35.67053617669677 139.74997287978468 6.44 35.67053617669677 139.74997287978468 34.49 35.670528575621056 139.74999531163758 34.49 35.670528575621056 139.74999531163758 6.44</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67053617669677 139.74997287978468 6.44 35.67054557684145 139.74994514384062 6.44 35.67054557684145 139.74994514384062 34.49 35.67053617669677 139.74997287978468 34.49 35.67053617669677 139.74997287978468 6.44</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67054557684145 139.74994514384062 6.44 35.67050578523502 139.74992491530637 6.44 35.67050578523502 139.74992491530637 34.49 35.67054557684145 139.74994514384062 34.49 35.67054557684145 139.74994514384062 6.44</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67050578523502 139.74992491530637 6.44 35.67039183857063 139.74986698573835 6.44 35.67039183857063 139.74986698573835 34.49 35.67050578523502 139.74992491530637 34.49 35.67050578523502 139.74992491530637 6.44</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67039183857063 139.74986698573835 6.44 35.670373577679854 139.74992035818136 6.44 35.670373577679854 139.74992035818136 34.49 35.67039183857063 139.74986698573835 34.49 35.67039183857063 139.74986698573835 6.44</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670373577679854 139.74992035818136 6.44 35.67049710931123 139.74998319344027 6.44 35.67049710931123 139.74998319344027 34.49 35.670373577679854 139.74992035818136 34.49 35.670373577679854 139.74992035818136 6.44</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67049710931123 139.74998319344027 34.49 35.67049818866426 139.74997987843523 34.49 35.670528575621056 139.74999531163758 34.49 35.67053617669677 139.74997287978468 34.49 35.67054557684145 139.74994514384062 34.49 35.67050578523502 139.74992491530637 34.49 35.67039183857063 139.74986698573835 34.49 35.670373577679854 139.74992035818136 34.49 35.67049710931123 139.74998319344027 34.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-3dfa214e-9804-4d99-9282-cda2742b5162"/>
							<gml:surfaceMember xlink:href="#poly-c9bdd46c-3818-480e-bf59-96c86016c97b"/>
							<gml:surfaceMember xlink:href="#poly-78afe585-7e39-4863-8194-e8ebd4db84d4"/>
							<gml:surfaceMember xlink:href="#poly-27794469-185b-447b-a2f0-31cff97b3f79"/>
							<gml:surfaceMember xlink:href="#poly-0c7d4e4e-ec1d-40a8-b928-e0d031c260d7"/>
							<gml:surfaceMember xlink:href="#poly-998c3696-8182-4baf-bb68-8d59fc8647ea"/>
							<gml:surfaceMember xlink:href="#poly-2653be67-a53e-49e9-897c-2aa8434ad2ed"/>
							<gml:surfaceMember xlink:href="#poly-2479c383-1870-46dc-96ca-0244a56f5c83"/>
							<gml:surfaceMember xlink:href="#poly-381c802a-a3cb-487d-bc48-7ff9920d7b53"/>
							<gml:surfaceMember xlink:href="#poly-2e25557b-5234-4708-aa76-5c8a1bbd0a3e"/>
							<gml:surfaceMember xlink:href="#poly-350902f8-6ca0-411d-9732-05b73b663291"/>
							<gml:surfaceMember xlink:href="#poly-0c2a58b6-75ee-4530-a0f1-5e777df4e4a9"/>
							<gml:surfaceMember xlink:href="#poly-1cad5576-552d-4fd9-b39a-d1066d47a685"/>
							<gml:surfaceMember xlink:href="#poly-1d2db5b2-e2a2-4b66-ba1f-792a284e2868"/>
							<gml:surfaceMember xlink:href="#poly-d3d780d2-4edf-4745-890d-f79f41d4c85f"/>
							<gml:surfaceMember xlink:href="#poly-0c2a0ac3-55a6-477b-a9e4-24ccec2aeac3"/>
							<gml:surfaceMember xlink:href="#poly-34893f3f-e3a3-4f00-8245-09f527c6c717"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-3dfa214e-9804-4d99-9282-cda2742b5162">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3dfa214e-9804-4d99-9282-cda2742b5162">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3dfa214e-9804-4d99-9282-cda2742b5162">
											<gml:posList>35.67054557684145 139.74994514384062 6.44 35.670528575621034 139.74999531163758 6.44 35.67049818866424 139.74997987843523 6.44 35.67049710931118 139.74998319344027 6.44 35.67037357767984 139.74992035818136 6.44 35.670391838570595 139.74986698573832 6.44 35.67054557684145 139.74994514384062 6.44</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c9bdd46c-3818-480e-bf59-96c86016c97b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c9bdd46c-3818-480e-bf59-96c86016c97b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c9bdd46c-3818-480e-bf59-96c86016c97b">
											<gml:posList>35.67044601416125 139.74993645456013 34.5 35.67037357767984 139.74992035818136 34.5 35.67049710931118 139.74998319344027 34.5 35.670463002016646 139.7499450971672 34.5 35.67044601416125 139.74993645456013 34.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-78afe585-7e39-4863-8194-e8ebd4db84d4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-78afe585-7e39-4863-8194-e8ebd4db84d4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-78afe585-7e39-4863-8194-e8ebd4db84d4">
											<gml:posList>35.67046924476522 139.74992664339916 34.5 35.670463002016646 139.7499450971672 34.5 35.67049710931118 139.74998319344027 34.5 35.67049818866424 139.74997987843523 34.5 35.670528575621034 139.74999531163758 34.5 35.67053617669675 139.74997287978468 34.5 35.67049635812256 139.74995275068355 34.5 35.67050578523501 139.74992491530637 34.5 35.670391838570595 139.74986698573832 34.5 35.67037357767984 139.74992035818136 34.5 35.67044601416125 139.74993645456013 34.5 35.670452256916185 139.7499180118416 34.5 35.67046924476522 139.74992664339916 34.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-27794469-185b-447b-a2f0-31cff97b3f79">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-27794469-185b-447b-a2f0-31cff97b3f79">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-27794469-185b-447b-a2f0-31cff97b3f79">
											<gml:posList>35.67044601416125 139.74993645456013 36.5 35.670463002016646 139.7499450971672 36.5 35.67046924476522 139.74992664339916 36.5 35.670452256916185 139.7499180118416 36.5 35.67044601416125 139.74993645456013 36.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-0c7d4e4e-ec1d-40a8-b928-e0d031c260d7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0c7d4e4e-ec1d-40a8-b928-e0d031c260d7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0c7d4e4e-ec1d-40a8-b928-e0d031c260d7">
											<gml:posList>35.67054557684145 139.74994514384062 38 35.67050578523501 139.74992491530637 38 35.67049635812256 139.74995275068355 38 35.67053617669675 139.74997287978468 38 35.67054557684145 139.74994514384062 38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-998c3696-8182-4baf-bb68-8d59fc8647ea">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-998c3696-8182-4baf-bb68-8d59fc8647ea">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-998c3696-8182-4baf-bb68-8d59fc8647ea">
											<gml:posList>35.670391838570595 139.74986698573832 6.44 35.67037357767984 139.74992035818136 6.44 35.67037357767984 139.74992035818136 34.5 35.670391838570595 139.74986698573832 34.5 35.670391838570595 139.74986698573832 6.44</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2653be67-a53e-49e9-897c-2aa8434ad2ed">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2653be67-a53e-49e9-897c-2aa8434ad2ed">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2653be67-a53e-49e9-897c-2aa8434ad2ed">
											<gml:posList>35.67037357767984 139.74992035818136 6.44 35.67049710931118 139.74998319344027 6.44 35.67049710931118 139.74998319344027 34.5 35.67037357767984 139.74992035818136 34.5 35.67037357767984 139.74992035818136 6.44</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2479c383-1870-46dc-96ca-0244a56f5c83">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2479c383-1870-46dc-96ca-0244a56f5c83">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2479c383-1870-46dc-96ca-0244a56f5c83">
											<gml:posList>35.67044601416125 139.74993645456013 36.5 35.670452256916185 139.7499180118416 36.5 35.670452256916185 139.7499180118416 34.5 35.67044601416125 139.74993645456013 34.5 35.67044601416125 139.74993645456013 36.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-381c802a-a3cb-487d-bc48-7ff9920d7b53">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-381c802a-a3cb-487d-bc48-7ff9920d7b53">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-381c802a-a3cb-487d-bc48-7ff9920d7b53">
											<gml:posList>35.670463002016646 139.7499450971672 36.5 35.67044601416125 139.74993645456013 36.5 35.67044601416125 139.74993645456013 34.5 35.670463002016646 139.7499450971672 34.5 35.670463002016646 139.7499450971672 36.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2e25557b-5234-4708-aa76-5c8a1bbd0a3e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2e25557b-5234-4708-aa76-5c8a1bbd0a3e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2e25557b-5234-4708-aa76-5c8a1bbd0a3e">
											<gml:posList>35.670452256916185 139.7499180118416 36.5 35.67046924476522 139.74992664339916 36.5 35.67046924476522 139.74992664339916 34.5 35.670452256916185 139.7499180118416 34.5 35.670452256916185 139.7499180118416 36.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-350902f8-6ca0-411d-9732-05b73b663291">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-350902f8-6ca0-411d-9732-05b73b663291">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-350902f8-6ca0-411d-9732-05b73b663291">
											<gml:posList>35.67046924476522 139.74992664339916 36.5 35.670463002016646 139.7499450971672 36.5 35.670463002016646 139.7499450971672 34.5 35.67046924476522 139.74992664339916 34.5 35.67046924476522 139.74992664339916 36.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0c2a58b6-75ee-4530-a0f1-5e777df4e4a9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0c2a58b6-75ee-4530-a0f1-5e777df4e4a9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0c2a58b6-75ee-4530-a0f1-5e777df4e4a9">
											<gml:posList>35.670391838570595 139.74986698573832 6.44 35.670391838570595 139.74986698573832 34.5 35.67050578523501 139.74992491530637 34.5 35.67050578523501 139.74992491530637 38 35.67054557684145 139.74994514384062 38 35.67054557684145 139.74994514384062 6.44 35.670391838570595 139.74986698573832 6.44</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1cad5576-552d-4fd9-b39a-d1066d47a685">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1cad5576-552d-4fd9-b39a-d1066d47a685">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1cad5576-552d-4fd9-b39a-d1066d47a685">
											<gml:posList>35.67049710931118 139.74998319344027 6.44 35.67049818866424 139.74997987843523 6.44 35.67049818866424 139.74997987843523 34.5 35.67049710931118 139.74998319344027 34.5 35.67049710931118 139.74998319344027 6.44</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1d2db5b2-e2a2-4b66-ba1f-792a284e2868">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1d2db5b2-e2a2-4b66-ba1f-792a284e2868">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1d2db5b2-e2a2-4b66-ba1f-792a284e2868">
											<gml:posList>35.67049635812256 139.74995275068355 38 35.67050578523501 139.74992491530637 38 35.67050578523501 139.74992491530637 34.5 35.67049635812256 139.74995275068355 34.5 35.67049635812256 139.74995275068355 38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d3d780d2-4edf-4745-890d-f79f41d4c85f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d3d780d2-4edf-4745-890d-f79f41d4c85f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d3d780d2-4edf-4745-890d-f79f41d4c85f">
											<gml:posList>35.67049818866424 139.74997987843523 6.44 35.670528575621034 139.74999531163758 6.44 35.670528575621034 139.74999531163758 34.5 35.67049818866424 139.74997987843523 34.5 35.67049818866424 139.74997987843523 6.44</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0c2a0ac3-55a6-477b-a9e4-24ccec2aeac3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0c2a0ac3-55a6-477b-a9e4-24ccec2aeac3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0c2a0ac3-55a6-477b-a9e4-24ccec2aeac3">
											<gml:posList>35.67053617669675 139.74997287978468 38 35.67049635812256 139.74995275068355 38 35.67049635812256 139.74995275068355 34.5 35.67053617669675 139.74997287978468 34.5 35.67053617669675 139.74997287978468 38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-34893f3f-e3a3-4f00-8245-09f527c6c717">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-34893f3f-e3a3-4f00-8245-09f527c6c717">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-34893f3f-e3a3-4f00-8245-09f527c6c717">
											<gml:posList>35.67054557684145 139.74994514384062 38 35.67053617669675 139.74997287978468 38 35.67053617669675 139.74997287978468 34.5 35.670528575621034 139.74999531163758 34.5 35.670528575621034 139.74999531163758 6.44 35.67054557684145 139.74994514384062 6.44 35.67054557684145 139.74994514384062 38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区虎ノ門一丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13101-bldg-4462</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13101</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">95.6414</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1210</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>8</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.0</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>