<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_1c4b1ca9-3dd3-4744-a59e-4d19324aa87e">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001001</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3001</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">401</bldg:usage>
			<bldg:measuredHeight uom="m">12.1</bldg:measuredHeight>
			<bldg:storeysAboveGround>4</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.67014088395023 139.74394735295763 0 35.670115539989446 139.74404812276887 0 35.67020876801788 139.74408325644492 0 35.670234021870286 139.7439824866279 0 35.67014088395023 139.74394735295763 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67014088395023 139.74394735295763 8.427 35.670234021870286 139.7439824866279 8.427 35.67020876801788 139.74408325644492 8.427 35.670115539989446 139.74404812276887 8.427 35.67014088395023 139.74394735295763 8.427</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67014088395023 139.74394735295763 8.427 35.670115539989446 139.74404812276887 8.427 35.670115539989446 139.74404812276887 20.55 35.67014088395023 139.74394735295763 20.55 35.67014088395023 139.74394735295763 8.427</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670115539989446 139.74404812276887 8.427 35.67020876801788 139.74408325644492 8.427 35.67020876801788 139.74408325644492 20.55 35.670115539989446 139.74404812276887 20.55 35.670115539989446 139.74404812276887 8.427</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67020876801788 139.74408325644492 8.427 35.670234021870286 139.7439824866279 8.427 35.670234021870286 139.7439824866279 20.55 35.67020876801788 139.74408325644492 20.55 35.67020876801788 139.74408325644492 8.427</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670234021870286 139.7439824866279 8.427 35.67014088395023 139.74394735295763 8.427 35.67014088395023 139.74394735295763 20.55 35.670234021870286 139.7439824866279 20.55 35.670234021870286 139.7439824866279 8.427</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67014088395023 139.74394735295763 20.55 35.670115539989446 139.74404812276887 20.55 35.67020876801788 139.74408325644492 20.55 35.670234021870286 139.7439824866279 20.55 35.67014088395023 139.74394735295763 20.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-56a7bc5a-2e85-4b1d-bcb4-cfc3c38403d4"/>
							<gml:surfaceMember xlink:href="#poly-5a5fea9d-b0e4-49ab-bcef-97bb04a90c1e"/>
							<gml:surfaceMember xlink:href="#poly-1d7978c8-b874-457c-a83d-60736d28d4b2"/>
							<gml:surfaceMember xlink:href="#poly-e1d6b293-ae90-4110-86c9-1eab1daa6d3e"/>
							<gml:surfaceMember xlink:href="#poly-3a7863ce-54cb-4ad8-8299-4a59b3493566"/>
							<gml:surfaceMember xlink:href="#poly-c7f41801-9fc4-4e5f-a7f0-3d1bbef6eb43"/>
							<gml:surfaceMember xlink:href="#poly-56981783-b557-433f-b93b-2b0baf9268b0"/>
							<gml:surfaceMember xlink:href="#poly-cc4ed462-1b07-454e-b598-336d1fff785f"/>
							<gml:surfaceMember xlink:href="#poly-9d69893e-7914-4931-94c6-1a0c55554dc1"/>
							<gml:surfaceMember xlink:href="#poly-bb786541-93ba-49a6-b1da-9ec6f955c859"/>
							<gml:surfaceMember xlink:href="#poly-e3c0ba72-3da2-4f09-95f0-53afdbc637a4"/>
							<gml:surfaceMember xlink:href="#poly-e04d1f05-4133-4a4f-b915-b7209adbe09b"/>
							<gml:surfaceMember xlink:href="#poly-948fe98b-b19d-4ad7-9f04-4dab7b430261"/>
							<gml:surfaceMember xlink:href="#poly-e6eb587f-771e-41f4-ae8a-b654616d9bb3"/>
							<gml:surfaceMember xlink:href="#poly-170ae2ef-43ab-4401-98e6-a1e381872f30"/>
							<gml:surfaceMember xlink:href="#poly-42aa8c99-a98e-41e5-809d-d2223e2c5f8e"/>
							<gml:surfaceMember xlink:href="#poly-6e488bfd-996a-4e4f-a47d-305dd2c3be59"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-56a7bc5a-2e85-4b1d-bcb4-cfc3c38403d4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-56a7bc5a-2e85-4b1d-bcb4-cfc3c38403d4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-56a7bc5a-2e85-4b1d-bcb4-cfc3c38403d4">
											<gml:posList>35.670140883950246 139.74394735295763 8.427 35.670234021870286 139.74398248662789 8.427 35.67020876801787 139.74408325644492 8.427 35.670115539989446 139.74404812276887 8.427 35.670140883950246 139.74394735295763 8.427</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-5a5fea9d-b0e4-49ab-bcef-97bb04a90c1e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5a5fea9d-b0e4-49ab-bcef-97bb04a90c1e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5a5fea9d-b0e4-49ab-bcef-97bb04a90c1e">
											<gml:posList>35.670115539989446 139.74404812276887 14.3 35.6701468985094 139.74405994045082 20.9 35.67017220642499 139.74395917064402 20.9 35.670140883950246 139.74394735295763 14.3 35.670115539989446 139.74404812276887 14.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-1d7978c8-b874-457c-a83d-60736d28d4b2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1d7978c8-b874-457c-a83d-60736d28d4b2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1d7978c8-b874-457c-a83d-60736d28d4b2">
											<gml:posList>35.67017220642499 139.74395917064402 20.9 35.6701468985094 139.74405994045082 20.9 35.67015027703432 139.74405774953587 20.9 35.6701739942168 139.74396331098794 20.9 35.67017220642499 139.74395917064402 20.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e1d6b293-ae90-4110-86c9-1eab1daa6d3e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e1d6b293-ae90-4110-86c9-1eab1daa6d3e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e1d6b293-ae90-4110-86c9-1eab1daa6d3e">
											<gml:posList>35.6701468985094 139.74405994045082 20.9 35.67020876801787 139.74408325644492 20.9 35.6702069802302 139.74407911609651 20.9 35.67015027703432 139.74405774953587 20.9 35.6701468985094 139.74405994045082 20.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-3a7863ce-54cb-4ad8-8299-4a59b3493566">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3a7863ce-54cb-4ad8-8299-4a59b3493566">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3a7863ce-54cb-4ad8-8299-4a59b3493566">
											<gml:posList>35.670230643346784 139.7439846775483 20.4 35.6701739942168 139.74396331098794 20.4 35.67015027703432 139.74405774953587 20.4 35.6702069802302 139.74407911609651 20.4 35.670230643346784 139.7439846775483 20.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c7f41801-9fc4-4e5f-a7f0-3d1bbef6eb43">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c7f41801-9fc4-4e5f-a7f0-3d1bbef6eb43">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c7f41801-9fc4-4e5f-a7f0-3d1bbef6eb43">
											<gml:posList>35.670234021870286 139.74398248662789 20.9 35.67017220642499 139.74395917064402 20.9 35.6701739942168 139.74396331098794 20.9 35.670230643346784 139.7439846775483 20.9 35.670234021870286 139.74398248662789 20.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-56981783-b557-433f-b93b-2b0baf9268b0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-56981783-b557-433f-b93b-2b0baf9268b0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-56981783-b557-433f-b93b-2b0baf9268b0">
											<gml:posList>35.67020876801787 139.74408325644492 20.9 35.670209567889465 139.74408008528474 20.9 35.6702069802302 139.74407911609651 20.9 35.67020876801787 139.74408325644492 20.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-cc4ed462-1b07-454e-b598-336d1fff785f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cc4ed462-1b07-454e-b598-336d1fff785f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cc4ed462-1b07-454e-b598-336d1fff785f">
											<gml:posList>35.670209567889465 139.74408008528474 20.9 35.670233231015 139.74398565778 20.9 35.670230643346784 139.7439846775483 20.9 35.6702069802302 139.74407911609651 20.9 35.670209567889465 139.74408008528474 20.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-9d69893e-7914-4931-94c6-1a0c55554dc1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9d69893e-7914-4931-94c6-1a0c55554dc1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9d69893e-7914-4931-94c6-1a0c55554dc1">
											<gml:posList>35.670233231015 139.74398565778 20.9 35.670234021870286 139.74398248662789 20.9 35.670230643346784 139.7439846775483 20.9 35.670233231015 139.74398565778 20.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-bb786541-93ba-49a6-b1da-9ec6f955c859">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bb786541-93ba-49a6-b1da-9ec6f955c859">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bb786541-93ba-49a6-b1da-9ec6f955c859">
											<gml:posList>35.67020876801787 139.74408325644492 8.427 35.670234021870286 139.74398248662789 8.427 35.670234021870286 139.74398248662789 20.9 35.670233231015 139.74398565778 20.9 35.670209567889465 139.74408008528474 20.9 35.67020876801787 139.74408325644492 20.9 35.67020876801787 139.74408325644492 8.427</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e3c0ba72-3da2-4f09-95f0-53afdbc637a4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e3c0ba72-3da2-4f09-95f0-53afdbc637a4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e3c0ba72-3da2-4f09-95f0-53afdbc637a4">
											<gml:posList>35.670140883950246 139.74394735295763 8.427 35.670140883950246 139.74394735295763 14.3 35.67017220642499 139.74395917064402 20.9 35.670234021870286 139.74398248662789 20.9 35.670234021870286 139.74398248662789 8.427 35.670140883950246 139.74394735295763 8.427</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e04d1f05-4133-4a4f-b915-b7209adbe09b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e04d1f05-4133-4a4f-b915-b7209adbe09b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e04d1f05-4133-4a4f-b915-b7209adbe09b">
											<gml:posList>35.670230643346784 139.7439846775483 20.9 35.6701739942168 139.74396331098794 20.9 35.6701739942168 139.74396331098794 20.4 35.670230643346784 139.7439846775483 20.4 35.670230643346784 139.7439846775483 20.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-948fe98b-b19d-4ad7-9f04-4dab7b430261">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-948fe98b-b19d-4ad7-9f04-4dab7b430261">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-948fe98b-b19d-4ad7-9f04-4dab7b430261">
											<gml:posList>35.670140883950246 139.74394735295763 8.427 35.670115539989446 139.74404812276887 8.427 35.670115539989446 139.74404812276887 14.3 35.670140883950246 139.74394735295763 14.3 35.670140883950246 139.74394735295763 8.427</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e6eb587f-771e-41f4-ae8a-b654616d9bb3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e6eb587f-771e-41f4-ae8a-b654616d9bb3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e6eb587f-771e-41f4-ae8a-b654616d9bb3">
											<gml:posList>35.6701739942168 139.74396331098794 20.9 35.67015027703432 139.74405774953587 20.9 35.67015027703432 139.74405774953587 20.4 35.6701739942168 139.74396331098794 20.4 35.6701739942168 139.74396331098794 20.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-170ae2ef-43ab-4401-98e6-a1e381872f30">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-170ae2ef-43ab-4401-98e6-a1e381872f30">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-170ae2ef-43ab-4401-98e6-a1e381872f30">
											<gml:posList>35.6702069802302 139.74407911609651 20.9 35.670230643346784 139.7439846775483 20.9 35.670230643346784 139.7439846775483 20.4 35.6702069802302 139.74407911609651 20.4 35.6702069802302 139.74407911609651 20.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-42aa8c99-a98e-41e5-809d-d2223e2c5f8e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-42aa8c99-a98e-41e5-809d-d2223e2c5f8e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-42aa8c99-a98e-41e5-809d-d2223e2c5f8e">
											<gml:posList>35.670115539989446 139.74404812276887 8.427 35.67020876801787 139.74408325644492 8.427 35.67020876801787 139.74408325644492 20.9 35.6701468985094 139.74405994045082 20.9 35.670115539989446 139.74404812276887 14.3 35.670115539989446 139.74404812276887 8.427</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6e488bfd-996a-4e4f-a47d-305dd2c3be59">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6e488bfd-996a-4e4f-a47d-305dd2c3be59">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6e488bfd-996a-4e4f-a47d-305dd2c3be59">
											<gml:posList>35.67015027703432 139.74405774953587 20.9 35.6702069802302 139.74407911609651 20.9 35.6702069802302 139.74407911609651 20.4 35.67015027703432 139.74405774953587 20.4 35.67015027703432 139.74405774953587 20.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂一丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-224</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">103.23505</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1210</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>6</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>