<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_1d4b3f41-6264-4299-a3a1-9a8c4d01b66f">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">401</bldg:usage>
			<bldg:measuredHeight uom="m">34.1</bldg:measuredHeight>
			<bldg:storeysAboveGround>9</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.67189307686429 139.7418061404394 0 35.67199680992983 139.7419051089617 0 35.67203021060303 139.74185210296704 0 35.672070903565285 139.74178751187836 0 35.672140081538366 139.74167773007483 0 35.67219253211976 139.74159447885026 0 35.6721725096246 139.74157870525718 0 35.67211426987916 139.74156419053267 0 35.67205006851029 139.74159233315066 0 35.672039480915025 139.7415969737445 0 35.671893063848245 139.74178901842882 0 35.67189307686429 139.7418061404394 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67189307686429 139.7418061404394 7.39 35.671893063848245 139.74178901842882 7.39 35.672039480915025 139.7415969737445 7.39 35.67205006851029 139.74159233315066 7.39 35.67211426987916 139.74156419053267 7.39 35.6721725096246 139.74157870525718 7.39 35.67219253211976 139.74159447885026 7.39 35.672140081538366 139.74167773007483 7.39 35.672070903565285 139.74178751187836 7.39 35.67203021060303 139.74185210296704 7.39 35.67199680992983 139.7419051089617 7.39 35.67189307686429 139.7418061404394 7.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67189307686429 139.7418061404394 7.39 35.67199680992983 139.7419051089617 7.39 35.67199680992983 139.7419051089617 35.85 35.67189307686429 139.7418061404394 35.85 35.67189307686429 139.7418061404394 7.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67199680992983 139.7419051089617 7.39 35.67203021060303 139.74185210296704 7.39 35.67203021060303 139.74185210296704 35.85 35.67199680992983 139.7419051089617 35.85 35.67199680992983 139.7419051089617 7.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67203021060303 139.74185210296704 7.39 35.672070903565285 139.74178751187836 7.39 35.672070903565285 139.74178751187836 35.85 35.67203021060303 139.74185210296704 35.85 35.67203021060303 139.74185210296704 7.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672070903565285 139.74178751187836 7.39 35.672140081538366 139.74167773007483 7.39 35.672140081538366 139.74167773007483 35.85 35.672070903565285 139.74178751187836 35.85 35.672070903565285 139.74178751187836 7.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672140081538366 139.74167773007483 7.39 35.67219253211976 139.74159447885026 7.39 35.67219253211976 139.74159447885026 35.85 35.672140081538366 139.74167773007483 35.85 35.672140081538366 139.74167773007483 7.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67219253211976 139.74159447885026 7.39 35.6721725096246 139.74157870525718 7.39 35.6721725096246 139.74157870525718 35.85 35.67219253211976 139.74159447885026 35.85 35.67219253211976 139.74159447885026 7.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6721725096246 139.74157870525718 7.39 35.67211426987916 139.74156419053267 7.39 35.67211426987916 139.74156419053267 35.85 35.6721725096246 139.74157870525718 35.85 35.6721725096246 139.74157870525718 7.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67211426987916 139.74156419053267 7.39 35.67205006851029 139.74159233315066 7.39 35.67205006851029 139.74159233315066 35.85 35.67211426987916 139.74156419053267 35.85 35.67211426987916 139.74156419053267 7.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67205006851029 139.74159233315066 7.39 35.672039480915025 139.7415969737445 7.39 35.672039480915025 139.7415969737445 35.85 35.67205006851029 139.74159233315066 35.85 35.67205006851029 139.74159233315066 7.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672039480915025 139.7415969737445 7.39 35.671893063848245 139.74178901842882 7.39 35.671893063848245 139.74178901842882 35.85 35.672039480915025 139.7415969737445 35.85 35.672039480915025 139.7415969737445 7.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671893063848245 139.74178901842882 7.39 35.67189307686429 139.7418061404394 7.39 35.67189307686429 139.7418061404394 35.85 35.671893063848245 139.74178901842882 35.85 35.671893063848245 139.74178901842882 7.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67189307686429 139.7418061404394 35.85 35.67199680992983 139.7419051089617 35.85 35.67203021060303 139.74185210296704 35.85 35.672070903565285 139.74178751187836 35.85 35.672140081538366 139.74167773007483 35.85 35.67219253211976 139.74159447885026 35.85 35.6721725096246 139.74157870525718 35.85 35.67211426987916 139.74156419053267 35.85 35.67205006851029 139.74159233315066 35.85 35.672039480915025 139.7415969737445 35.85 35.671893063848245 139.74178901842882 35.85 35.67189307686429 139.7418061404394 35.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-c1bdf32c-fc04-4496-968f-3f0574844162"/>
							<gml:surfaceMember xlink:href="#poly-70747b10-114e-4410-8a4d-50d2b51ed2f1"/>
							<gml:surfaceMember xlink:href="#poly-c53cb013-0b69-4c87-b317-b3721cafb925"/>
							<gml:surfaceMember xlink:href="#poly-e4c58acc-cb45-4e61-a59e-fde59a2bace4"/>
							<gml:surfaceMember xlink:href="#poly-08e08087-4aad-42ce-ab8a-ceb8abdaa9e1"/>
							<gml:surfaceMember xlink:href="#poly-1fd3ea19-44d1-42aa-ae84-8cd748cc1229"/>
							<gml:surfaceMember xlink:href="#poly-f38d9215-3507-4912-bc22-3bf7a1a7c7a7"/>
							<gml:surfaceMember xlink:href="#poly-925c50bf-a6f9-41f1-a1db-32d9487b0548"/>
							<gml:surfaceMember xlink:href="#poly-1fa2c43a-bb03-487c-98a0-211eea243a91"/>
							<gml:surfaceMember xlink:href="#poly-bac0ca88-2f2d-46e6-ac6d-7a2b5fcdf317"/>
							<gml:surfaceMember xlink:href="#poly-d528a2d9-be63-4d0c-a40c-5ed4b0bd2255"/>
							<gml:surfaceMember xlink:href="#poly-af9694c4-4d40-410b-bd99-459945da100a"/>
							<gml:surfaceMember xlink:href="#poly-cca9b1b5-8fc1-4764-a289-3d3c188205c8"/>
							<gml:surfaceMember xlink:href="#poly-b2ef9202-5cbe-4f79-a3f9-6a790401c6ea"/>
							<gml:surfaceMember xlink:href="#poly-30f54117-2b46-43ff-b036-7ba232b6e83e"/>
							<gml:surfaceMember xlink:href="#poly-3db89fcc-1c38-4ab7-8e44-85eaa5b2120b"/>
							<gml:surfaceMember xlink:href="#poly-110b8846-96cd-4b70-9ab4-16da82843e4e"/>
							<gml:surfaceMember xlink:href="#poly-35798dde-4906-47a1-a27b-1dc80b8741cd"/>
							<gml:surfaceMember xlink:href="#poly-db49b196-a8ee-45fb-98fe-e01037d00793"/>
							<gml:surfaceMember xlink:href="#poly-a2a09447-eb92-415d-adc0-bfcd4e60428c"/>
							<gml:surfaceMember xlink:href="#poly-669cb2b3-5e70-413a-9104-2a6639267985"/>
							<gml:surfaceMember xlink:href="#poly-1b13dda0-231c-41ad-a0aa-e93372a81a60"/>
							<gml:surfaceMember xlink:href="#poly-5cf5932e-6029-4fce-bf0d-ad9494164f52"/>
							<gml:surfaceMember xlink:href="#poly-1565c402-f09c-484f-bdb3-545459addd0d"/>
							<gml:surfaceMember xlink:href="#poly-06ce190f-c17f-4dcc-b867-810ae266cda1"/>
							<gml:surfaceMember xlink:href="#poly-b6c0c992-5a76-4542-9d87-e9ff785ea6f9"/>
							<gml:surfaceMember xlink:href="#poly-4ab9581c-6ac5-4674-a931-5d7238233f41"/>
							<gml:surfaceMember xlink:href="#poly-7342ca74-0154-4aeb-895d-ea0ce43cedb5"/>
							<gml:surfaceMember xlink:href="#poly-24772180-2577-461c-aa9f-aecdf9cce484"/>
							<gml:surfaceMember xlink:href="#poly-002782a6-3e6e-444c-acfc-e968719fef69"/>
							<gml:surfaceMember xlink:href="#poly-dbdb9919-7e84-448a-baf9-afc1f8b16a9f"/>
							<gml:surfaceMember xlink:href="#poly-cb33f5e5-ba51-4c33-9a72-b88e3ecc4df2"/>
							<gml:surfaceMember xlink:href="#poly-fc10f492-e9c2-4805-8abe-861f2ad8c161"/>
							<gml:surfaceMember xlink:href="#poly-22dad21c-c6cb-422b-b22e-bc1c65e72f27"/>
							<gml:surfaceMember xlink:href="#poly-de1c0c28-0ef1-4e66-a4f7-0023cf6a03ee"/>
							<gml:surfaceMember xlink:href="#poly-2f918f3e-4bca-471f-9f1e-d68a0b745583"/>
							<gml:surfaceMember xlink:href="#poly-2ca9d4f4-b41c-4c0c-bd7e-ff710f64ac5e"/>
							<gml:surfaceMember xlink:href="#poly-fb38ea1a-770a-4460-80d9-70eed64a8548"/>
							<gml:surfaceMember xlink:href="#poly-039f90d3-d8e9-4acc-8f34-7b7e48fb53d4"/>
							<gml:surfaceMember xlink:href="#poly-e5ab5b93-9d66-42d3-ac72-875893281289"/>
							<gml:surfaceMember xlink:href="#poly-edede2ae-ca35-4e6e-9d1f-d3a4fef5dd25"/>
							<gml:surfaceMember xlink:href="#poly-09f3bd01-485e-482e-abf8-e7d4ac28dad1"/>
							<gml:surfaceMember xlink:href="#poly-b1816959-43ec-4ad5-b5bf-290461d8767f"/>
							<gml:surfaceMember xlink:href="#poly-cd9d2080-0a4a-4856-ab7e-10815c0f74e8"/>
							<gml:surfaceMember xlink:href="#poly-d2c8e7d5-4083-4eb3-89cb-ff3cc4aeca13"/>
							<gml:surfaceMember xlink:href="#poly-92fb08f9-af2c-49fe-ae81-ca680bb4d789"/>
							<gml:surfaceMember xlink:href="#poly-0ae266fe-c88f-4895-bf86-ad204eb74886"/>
							<gml:surfaceMember xlink:href="#poly-04e41ea5-b467-4824-aa09-aa639f850f2c"/>
							<gml:surfaceMember xlink:href="#poly-1e7a48dd-5737-4328-b89f-a194e8673b03"/>
							<gml:surfaceMember xlink:href="#poly-ab98429e-4d8a-464e-b6b5-c3a9e8ff9ef3"/>
							<gml:surfaceMember xlink:href="#poly-eb17dccc-85d4-41fb-80e7-b2edfb5a8c21"/>
							<gml:surfaceMember xlink:href="#poly-85a4b30b-742e-440b-b064-086db3fa754e"/>
							<gml:surfaceMember xlink:href="#poly-509b9010-42a1-4a5f-bdf4-62081ec7e9d0"/>
							<gml:surfaceMember xlink:href="#poly-45086ed0-e66a-4938-921d-4081c100a94c"/>
							<gml:surfaceMember xlink:href="#poly-a54214de-fe6b-4f92-a30c-5f33980d01f6"/>
							<gml:surfaceMember xlink:href="#poly-759a30b3-57df-48c2-b958-30b8abe8684e"/>
							<gml:surfaceMember xlink:href="#poly-31603d85-de14-4b4d-a75a-edeaeabc8bf2"/>
							<gml:surfaceMember xlink:href="#poly-a7cf3a5b-d8e6-4ff5-ad87-f1bda59a7606"/>
							<gml:surfaceMember xlink:href="#poly-ae66fc68-160a-49b4-ada0-b55bf0868845"/>
							<gml:surfaceMember xlink:href="#poly-2a006df5-24b5-4344-832c-4bbc0f817a92"/>
							<gml:surfaceMember xlink:href="#poly-1f6192bd-e77e-4484-a6fe-ce2b6bc693fc"/>
							<gml:surfaceMember xlink:href="#poly-8cab4a67-7b8f-448e-a74b-8d57ca096493"/>
							<gml:surfaceMember xlink:href="#poly-cd42d445-8e75-4f21-8137-042d393f21db"/>
							<gml:surfaceMember xlink:href="#poly-a740c32f-6fa1-49f9-a608-6d1602d8509d"/>
							<gml:surfaceMember xlink:href="#poly-9949b593-728f-4a0c-ab37-53fa306d5a1c"/>
							<gml:surfaceMember xlink:href="#poly-bfa31e5e-bfc9-4531-b540-9e14a245fb9a"/>
							<gml:surfaceMember xlink:href="#poly-0db12260-685d-49dd-8566-9ffac1005c6d"/>
							<gml:surfaceMember xlink:href="#poly-9945afe1-19fd-4bdb-94e5-13fe0afd4b87"/>
							<gml:surfaceMember xlink:href="#poly-989953b3-ed45-4337-a3ed-2fa05a086aef"/>
							<gml:surfaceMember xlink:href="#poly-8e155986-2a27-462f-b746-14d98e8787f8"/>
							<gml:surfaceMember xlink:href="#poly-d1facffd-f4d1-4a22-be8c-d0cfa48e4245"/>
							<gml:surfaceMember xlink:href="#poly-fc8b11cd-6f61-4506-8e8d-ec56f65aab31"/>
							<gml:surfaceMember xlink:href="#poly-0b1c97fe-db74-4516-81b7-f9edd9345e5e"/>
							<gml:surfaceMember xlink:href="#poly-086a1198-e22a-42d4-a592-e0852303effa"/>
							<gml:surfaceMember xlink:href="#poly-ebac2da8-931b-404f-8d93-bc00767f2856"/>
							<gml:surfaceMember xlink:href="#poly-d0e587ca-a265-4edb-ab08-4037dc2b051b"/>
							<gml:surfaceMember xlink:href="#poly-d32637fd-6689-47af-9abf-09d9a0c6df35"/>
							<gml:surfaceMember xlink:href="#poly-6f95f13d-6bc7-4a39-b0dc-102606c93a67"/>
							<gml:surfaceMember xlink:href="#poly-ea8738f7-66f4-4309-a52b-a8a772fb25df"/>
							<gml:surfaceMember xlink:href="#poly-7968df01-da76-4dad-b6db-db12d2ad6edc"/>
							<gml:surfaceMember xlink:href="#poly-a053c44a-847b-4c8b-8f5a-e26a26671c8d"/>
							<gml:surfaceMember xlink:href="#poly-3e4bf1e5-312c-42dc-b575-2f1515a036ce"/>
							<gml:surfaceMember xlink:href="#poly-26729009-b221-4399-82a5-ad2e554d287f"/>
							<gml:surfaceMember xlink:href="#poly-6cb2d7ca-785f-4b0b-86a4-1bc493d876ef"/>
							<gml:surfaceMember xlink:href="#poly-a5956c5c-b471-44e0-ad85-f5e63acf8430"/>
							<gml:surfaceMember xlink:href="#poly-2ce2bc79-b314-4c35-8cb5-088bf0b2ffb2"/>
							<gml:surfaceMember xlink:href="#poly-eaf37423-24db-4d5b-b9ea-7144308bf364"/>
							<gml:surfaceMember xlink:href="#poly-ebc2d0fb-20a4-4293-8e14-118928cfb246"/>
							<gml:surfaceMember xlink:href="#poly-fc9172c1-d77d-4549-bbd5-83c413f4781f"/>
							<gml:surfaceMember xlink:href="#poly-01a16802-fdde-4567-93a0-7aef49b52b26"/>
							<gml:surfaceMember xlink:href="#poly-1917b6ab-a5a2-4134-8818-6ce53a0817a5"/>
							<gml:surfaceMember xlink:href="#poly-f37cdb8b-d31f-49f6-9461-f2ac60501158"/>
							<gml:surfaceMember xlink:href="#poly-0d7c1170-b3bb-498f-9c90-5c26f090c456"/>
							<gml:surfaceMember xlink:href="#poly-0d998890-baa5-4d52-a6ab-99902b61e8ae"/>
							<gml:surfaceMember xlink:href="#poly-f39c22dd-8315-46bf-b376-e6a9fb7c375c"/>
							<gml:surfaceMember xlink:href="#poly-c324dd64-26b4-4a67-a592-db19fe395994"/>
							<gml:surfaceMember xlink:href="#poly-2a78c54f-65e1-47a0-aae8-0e4cda2b670b"/>
							<gml:surfaceMember xlink:href="#poly-f2faf60c-c38f-4f3a-af3b-872a3fb307a0"/>
							<gml:surfaceMember xlink:href="#poly-8f4885d8-6ba6-4674-a1f2-bca85c439968"/>
							<gml:surfaceMember xlink:href="#poly-40e911c4-b4ba-4338-ab8f-fd9a4f5274fb"/>
							<gml:surfaceMember xlink:href="#poly-59596e55-ca01-4867-b120-85d1030b4158"/>
							<gml:surfaceMember xlink:href="#poly-62d324a4-e37e-405f-a293-c7537ba823ee"/>
							<gml:surfaceMember xlink:href="#poly-fc2f1434-0640-4240-a292-79b6c376855f"/>
							<gml:surfaceMember xlink:href="#poly-62f7eca7-c349-4ebd-a717-ff2ada2034cb"/>
							<gml:surfaceMember xlink:href="#poly-2753e24f-45b2-4659-8056-f651b5036f5a"/>
							<gml:surfaceMember xlink:href="#poly-e2fd0ffb-5404-4dc4-adca-912c80d0c424"/>
							<gml:surfaceMember xlink:href="#poly-9bf5c279-f2d2-4781-b0db-754af20802f7"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-c1bdf32c-fc04-4496-968f-3f0574844162">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c1bdf32c-fc04-4496-968f-3f0574844162">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c1bdf32c-fc04-4496-968f-3f0574844162">
											<gml:posList>35.67189307686427 139.74180614043937 7.39 35.67189306384822 139.74178901842882 7.39 35.672039480915025 139.7415969737445 7.39 35.67211426987915 139.74156419053267 7.39 35.672172509624595 139.74157870525715 7.39 35.67219253211972 139.74159447885023 7.39 35.67199680992982 139.7419051089617 7.39 35.67189307686427 139.74180614043937 7.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-70747b10-114e-4410-8a4d-50d2b51ed2f1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-70747b10-114e-4410-8a4d-50d2b51ed2f1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-70747b10-114e-4410-8a4d-50d2b51ed2f1">
											<gml:posList>35.672092780525155 139.74158702614363 33.733 35.67209224816856 139.7415863087306 33.733 35.672091688812884 139.741585646581 33.733 35.67209108441386 139.74158501762244 33.733 35.67209046202945 139.74158444391696 33.733 35.672089803623855 139.74158391443865 33.733 35.67208911821074 139.74158342917727 33.733 35.6720884148207 139.7415830102154 33.733 35.672087684431574 139.74158264651695 33.733 35.672086945062404 139.74158232701475 33.733 35.67208617870257 139.7415820738224 33.733 35.67208541239324 139.741581886909 33.733 35.67208463710386 139.74158174419185 33.733 35.67208385285126 139.74158166776388 33.733 35.672083068649165 139.74158165761486 33.733 35.67208228448916 139.74158170269826 33.733 35.672081500371235 139.74158180301404 33.733 35.672080725317535 139.74158196959846 33.733 35.672079959328066 139.74158220245144 33.733 35.672079211399705 139.7415824794697 33.733 35.67207847253555 139.7415828227566 33.733 35.67207776075466 139.74158322124495 33.733 35.67207705802957 139.74158367495536 33.733 35.67207639139303 139.74158417281046 33.733 35.67207575183973 139.74158472586703 33.733 35.672075139369674 139.74158533412503 33.733 35.67207455396603 139.74158597549155 33.733 35.67207400465934 139.74158667204924 33.733 35.67207350044651 139.74158740169477 33.733 35.67207302330849 139.74158817549528 33.733 35.672072591264325 139.74158898238366 33.733 35.67207220430559 139.74158981131342 33.733 35.67207186244912 139.74159068437754 33.733 35.67207155665593 139.74159156844686 33.733 35.67207130497032 139.74159248559374 33.733 35.67207109836172 139.74159341373553 33.733 35.67207093683013 139.74159435287223 33.733 35.672070829397676 139.74159531404 33.733 35.67207076703383 139.74159627515624 33.733 35.67207074973857 139.74159723622085 33.733 35.67207078652563 139.74159819722362 33.733 35.67207087739501 139.7415991581645 33.733 35.672071013324555 139.7416001080073 33.733 35.67207119430587 139.74160103570563 33.733 35.6720714293695 139.74160196334202 33.733 35.67207170947649 139.74160285778743 33.733 35.67207202562993 139.74160374114513 33.733 35.67207239584043 139.7416045913015 33.733 35.67207286525236 139.74160550762332 33.733 35.67206952518438 139.7416107916681 33.733 35.6720910215781 139.7416090217286 33.733 35.672091390854526 139.74160864572525 33.733 35.672091976258294 139.74160800435877 33.733 35.6720925255651 139.74160730780108 33.733 35.672093029778054 139.7416065781555 33.733 35.672093506916184 139.74160580435492 33.733 35.672093938960465 139.74160499746642 33.733 35.672094325910884 139.74160415749 33.733 35.672094667775866 139.7416032954722 33.733 35.67209497356913 139.74160241140268 33.733 35.67209522525482 139.74160149425552 33.733 35.6720954318635 139.74160056611348 33.733 35.67209559339512 139.7415996269765 33.733 35.672095700827605 139.74159866580843 33.733 35.672095763191486 139.74159770469194 33.733 35.672095780486735 139.741596743627 33.733 35.67209574369967 139.74159578262393 33.733 35.67209565283027 139.74159482168278 33.733 35.672095516900676 139.74159387183968 33.733 35.6720953359193 139.7415929441411 33.733 35.6720951008556 139.74159201650443 33.733 35.67209482074855 139.74159112205882 33.733 35.67209450459501 139.74159023870092 33.733 35.672094134384395 139.7415893885444 33.733 35.67209371913043 139.74158857157892 33.733 35.67209326783841 139.74158777674765 33.733 35.672092780525155 139.74158702614363 33.733</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c53cb013-0b69-4c87-b317-b3721cafb925">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c53cb013-0b69-4c87-b317-b3721cafb925">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c53cb013-0b69-4c87-b317-b3721cafb925">
											<gml:posList>35.6720910215781 139.7416090217286 33.733 35.67206952518438 139.7416107916681 33.733 35.67209892216821 139.74163868357886 33.483 35.6720910215781 139.7416090217286 33.733</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e4c58acc-cb45-4e61-a59e-fde59a2bace4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e4c58acc-cb45-4e61-a59e-fde59a2bace4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e4c58acc-cb45-4e61-a59e-fde59a2bace4">
											<gml:posList>35.67209892216821 139.74163868357886 33.483 35.672107672954915 139.74162482126246 33.733 35.6720910215781 139.7416090217286 33.733 35.67209892216821 139.74163868357886 33.483</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-08e08087-4aad-42ce-ab8a-ceb8abdaa9e1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-08e08087-4aad-42ce-ab8a-ceb8abdaa9e1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-08e08087-4aad-42ce-ab8a-ceb8abdaa9e1">
											<gml:posList>35.67209892216821 139.74163868357886 12.5 35.67214008153836 139.74167773007483 12.5 35.67219253211972 139.74159447885023 12.5 35.672172509624595 139.74157870525715 12.5 35.67211426987915 139.74156419053267 12.5 35.672050068510245 139.74159233315063 12.5 35.67206952518438 139.7416107916681 12.5 35.67207286525236 139.74160550762332 12.5 35.67207239584043 139.7416045913015 12.5 35.67207202562993 139.74160374114513 12.5 35.67207170947649 139.74160285778743 12.5 35.6720714293695 139.74160196334202 12.5 35.67207119430587 139.74160103570563 12.5 35.672071013324555 139.7416001080073 12.5 35.67207087739501 139.7415991581645 12.5 35.67207078652563 139.74159819722362 12.5 35.67207074973857 139.74159723622085 12.5 35.67207076703383 139.74159627515624 12.5 35.672070829397676 139.74159531404 12.5 35.67207093683013 139.74159435287223 12.5 35.67207109836172 139.74159341373553 12.5 35.67207130497032 139.74159248559374 12.5 35.67207155665593 139.74159156844686 12.5 35.67207186244912 139.74159068437754 12.5 35.67207220430559 139.74158981131342 12.5 35.672072591264325 139.74158898238366 12.5 35.67207302330849 139.74158817549528 12.5 35.67207350044651 139.74158740169477 12.5 35.67207400465934 139.74158667204924 12.5 35.67207455396603 139.74158597549155 12.5 35.672075139369674 139.74158533412503 12.5 35.67207575183973 139.74158472586703 12.5 35.67207639139303 139.74158417281046 12.5 35.67207705802957 139.74158367495536 12.5 35.67207776075466 139.74158322124495 12.5 35.67207847253555 139.7415828227566 12.5 35.672079211399705 139.7415824794697 12.5 35.672079959328066 139.74158220245144 12.5 35.672080725317535 139.74158196959846 12.5 35.672081500371235 139.74158180301404 12.5 35.67208228448916 139.74158170269826 12.5 35.672083068649165 139.74158165761486 12.5 35.67208385285126 139.74158166776388 12.5 35.67208463710386 139.74158174419185 12.5 35.67208541239324 139.741581886909 12.5 35.67208617870257 139.7415820738224 12.5 35.672086945062404 139.74158232701475 12.5 35.672087684431574 139.74158264651695 12.5 35.6720884148207 139.7415830102154 12.5 35.67208911821074 139.74158342917727 12.5 35.672089803623855 139.74158391443865 12.5 35.67209046202945 139.74158444391696 12.5 35.67209108441386 139.74158501762244 12.5 35.672091688812884 139.741585646581 12.5 35.67209224816856 139.7415863087306 12.5 35.672092780525155 139.74158702614363 12.5 35.67209326783841 139.74158777674765 12.5 35.67209371913043 139.74158857157892 12.5 35.672094134384395 139.7415893885444 12.5 35.67209450459501 139.74159023870092 12.5 35.67209482074855 139.74159112205882 12.5 35.6720951008556 139.74159201650443 12.5 35.6720953359193 139.7415929441411 12.5 35.672095516900676 139.74159387183968 12.5 35.67209565283027 139.74159482168278 12.5 35.67209574369967 139.74159578262393 12.5 35.672095780486735 139.741596743627 12.5 35.672095763191486 139.74159770469194 12.5 35.672095700827605 139.74159866580843 12.5 35.67209559339512 139.7415996269765 12.5 35.6720954318635 139.74160056611348 12.5 35.67209522525482 139.74160149425552 12.5 35.67209497356913 139.74160241140268 12.5 35.672094667775866 139.7416032954722 12.5 35.672094325910884 139.74160415749 12.5 35.672093938960465 139.74160499746642 12.5 35.672093506916184 139.74160580435492 12.5 35.672093029778054 139.7416065781555 12.5 35.6720925255651 139.74160730780108 12.5 35.672091976258294 139.74160800435877 12.5 35.672091390854526 139.74160864572525 12.5 35.6720910215781 139.7416090217286 12.5 35.672107672954915 139.74162482126246 12.5 35.67209892216821 139.74163868357886 12.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-1fd3ea19-44d1-42aa-ae84-8cd748cc1229">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1fd3ea19-44d1-42aa-ae84-8cd748cc1229">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1fd3ea19-44d1-42aa-ae84-8cd748cc1229">
											<gml:posList>35.67208133670918 139.74167462688996 38.476 35.672066670047734 139.74166104542633 38.476 35.67204357833356 139.74169848628765 38.476 35.67205823598551 139.741712078811 38.476 35.67208133670918 139.74167462688996 38.476</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f38d9215-3507-4912-bc22-3bf7a1a7c7a7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f38d9215-3507-4912-bc22-3bf7a1a7c7a7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f38d9215-3507-4912-bc22-3bf7a1a7c7a7">
											<gml:posList>35.67205823598551 139.741712078811 35.9 35.67207090356526 139.74178751187836 35.9 35.67214008153836 139.74167773007483 35.9 35.67208133670918 139.74167462688996 35.9 35.67205823598551 139.741712078811 35.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-925c50bf-a6f9-41f1-a1db-32d9487b0548">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-925c50bf-a6f9-41f1-a1db-32d9487b0548">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-925c50bf-a6f9-41f1-a1db-32d9487b0548">
											<gml:posList>35.67200850168384 139.74172846235055 35.9 35.67207090356526 139.74178751187836 35.9 35.67205823598551 139.741712078811 35.9 35.67204357833356 139.74169848628765 35.9 35.672066670047734 139.74166104542633 35.9 35.67208133670918 139.74167462688996 35.9 35.67214008153836 139.74167773007483 35.9 35.672050068510245 139.74159233315063 35.9 35.672039480915025 139.7415969737445 35.9 35.67189306384822 139.74178901842882 35.9 35.67189307686427 139.74180614043937 35.9 35.671951702496315 139.7418303094796 35.9 35.67196435041112 139.74180876545896 35.9 35.67201309326227 139.74185174691837 35.9 35.6720004453315 139.7418732798989 35.9 35.67199680992982 139.7419051089617 35.9 35.672030210603026 139.74185210296704 35.9 35.67196779973909 139.7417930534291 35.9 35.67200850168384 139.74172846235055 35.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-1fa2c43a-bb03-487c-98a0-211eea243a91">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1fa2c43a-bb03-487c-98a0-211eea243a91">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1fa2c43a-bb03-487c-98a0-211eea243a91">
											<gml:posList>35.67200850168384 139.74172846235055 41.476 35.67196779973909 139.7417930534291 41.476 35.672030210603026 139.74185210296704 41.476 35.67207090356526 139.74178751187836 41.476 35.67200850168384 139.74172846235055 41.476</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-bac0ca88-2f2d-46e6-ac6d-7a2b5fcdf317">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bac0ca88-2f2d-46e6-ac6d-7a2b5fcdf317">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bac0ca88-2f2d-46e6-ac6d-7a2b5fcdf317">
											<gml:posList>35.67196435041112 139.74180876545896 38.476 35.671951702496315 139.7418303094796 38.476 35.6720004453315 139.7418732798989 38.476 35.67201309326227 139.74185174691837 38.476 35.67196435041112 139.74180876545896 38.476</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d528a2d9-be63-4d0c-a40c-5ed4b0bd2255">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d528a2d9-be63-4d0c-a40c-5ed4b0bd2255">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d528a2d9-be63-4d0c-a40c-5ed4b0bd2255">
											<gml:posList>35.671951702496315 139.7418303094796 35.9 35.67189307686427 139.74180614043937 35.9 35.67199680992982 139.7419051089617 35.9 35.6720004453315 139.7418732798989 35.9 35.671951702496315 139.7418303094796 35.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-af9694c4-4d40-410b-bd99-459945da100a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-af9694c4-4d40-410b-bd99-459945da100a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-af9694c4-4d40-410b-bd99-459945da100a">
											<gml:posList>35.67207076703383 139.74159627515624 33.733 35.672070829397676 139.74159531404 33.733 35.672070829397676 139.74159531404 12.5 35.67207076703383 139.74159627515624 12.5 35.67207076703383 139.74159627515624 33.733</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-cca9b1b5-8fc1-4764-a289-3d3c188205c8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cca9b1b5-8fc1-4764-a289-3d3c188205c8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cca9b1b5-8fc1-4764-a289-3d3c188205c8">
											<gml:posList>35.67207074973857 139.74159723622085 33.733 35.67207076703383 139.74159627515624 33.733 35.67207076703383 139.74159627515624 12.5 35.67207074973857 139.74159723622085 12.5 35.67207074973857 139.74159723622085 33.733</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b2ef9202-5cbe-4f79-a3f9-6a790401c6ea">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b2ef9202-5cbe-4f79-a3f9-6a790401c6ea">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b2ef9202-5cbe-4f79-a3f9-6a790401c6ea">
											<gml:posList>35.67207239584043 139.7416045913015 33.733 35.67207202562993 139.74160374114513 33.733 35.67207202562993 139.74160374114513 12.5 35.67207239584043 139.7416045913015 12.5 35.67207239584043 139.7416045913015 33.733</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-30f54117-2b46-43ff-b036-7ba232b6e83e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-30f54117-2b46-43ff-b036-7ba232b6e83e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-30f54117-2b46-43ff-b036-7ba232b6e83e">
											<gml:posList>35.672091390854526 139.74160864572525 33.733 35.6720910215781 139.7416090217286 33.733 35.6720910215781 139.7416090217286 12.5 35.672091390854526 139.74160864572525 12.5 35.672091390854526 139.74160864572525 33.733</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3db89fcc-1c38-4ab7-8e44-85eaa5b2120b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3db89fcc-1c38-4ab7-8e44-85eaa5b2120b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3db89fcc-1c38-4ab7-8e44-85eaa5b2120b">
											<gml:posList>35.67204357833356 139.74169848628765 35.9 35.67204357833356 139.74169848628765 38.476 35.672066670047734 139.74166104542633 38.476 35.672066670047734 139.74166104542633 35.9 35.67204357833356 139.74169848628765 35.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-110b8846-96cd-4b70-9ab4-16da82843e4e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-110b8846-96cd-4b70-9ab4-16da82843e4e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-110b8846-96cd-4b70-9ab4-16da82843e4e">
											<gml:posList>35.67207078652563 139.74159819722362 33.733 35.67207074973857 139.74159723622085 33.733 35.67207074973857 139.74159723622085 12.5 35.67207078652563 139.74159819722362 12.5 35.67207078652563 139.74159819722362 33.733</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-35798dde-4906-47a1-a27b-1dc80b8741cd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-35798dde-4906-47a1-a27b-1dc80b8741cd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-35798dde-4906-47a1-a27b-1dc80b8741cd">
											<gml:posList>35.67207087739501 139.7415991581645 33.733 35.67207078652563 139.74159819722362 33.733 35.67207078652563 139.74159819722362 12.5 35.67207087739501 139.7415991581645 12.5 35.67207087739501 139.7415991581645 33.733</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-db49b196-a8ee-45fb-98fe-e01037d00793">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-db49b196-a8ee-45fb-98fe-e01037d00793">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-db49b196-a8ee-45fb-98fe-e01037d00793">
											<gml:posList>35.672070829397676 139.74159531404 33.733 35.67207093683013 139.74159435287223 33.733 35.67207093683013 139.74159435287223 12.5 35.672070829397676 139.74159531404 12.5 35.672070829397676 139.74159531404 33.733</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a2a09447-eb92-415d-adc0-bfcd4e60428c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a2a09447-eb92-415d-adc0-bfcd4e60428c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a2a09447-eb92-415d-adc0-bfcd4e60428c">
											<gml:posList>35.672071013324555 139.7416001080073 33.733 35.67207087739501 139.7415991581645 33.733 35.67207087739501 139.7415991581645 12.5 35.672071013324555 139.7416001080073 12.5 35.672071013324555 139.7416001080073 33.733</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-669cb2b3-5e70-413a-9104-2a6639267985">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-669cb2b3-5e70-413a-9104-2a6639267985">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-669cb2b3-5e70-413a-9104-2a6639267985">
											<gml:posList>35.67207093683013 139.74159435287223 33.733 35.67207109836172 139.74159341373553 33.733 35.67207109836172 139.74159341373553 12.5 35.67207093683013 139.74159435287223 12.5 35.67207093683013 139.74159435287223 33.733</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1b13dda0-231c-41ad-a0aa-e93372a81a60">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1b13dda0-231c-41ad-a0aa-e93372a81a60">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1b13dda0-231c-41ad-a0aa-e93372a81a60">
											<gml:posList>35.67207119430587 139.74160103570563 33.733 35.672071013324555 139.7416001080073 33.733 35.672071013324555 139.7416001080073 12.5 35.67207119430587 139.74160103570563 12.5 35.67207119430587 139.74160103570563 33.733</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5cf5932e-6029-4fce-bf0d-ad9494164f52">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5cf5932e-6029-4fce-bf0d-ad9494164f52">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5cf5932e-6029-4fce-bf0d-ad9494164f52">
											<gml:posList>35.67206952518438 139.7416107916681 33.733 35.67207286525236 139.74160550762332 33.733 35.67207286525236 139.74160550762332 12.5 35.67206952518438 139.7416107916681 12.5 35.67206952518438 139.7416107916681 33.733</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1565c402-f09c-484f-bdb3-545459addd0d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1565c402-f09c-484f-bdb3-545459addd0d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1565c402-f09c-484f-bdb3-545459addd0d">
											<gml:posList>35.67207109836172 139.74159341373553 33.733 35.67207130497032 139.74159248559374 33.733 35.67207130497032 139.74159248559374 12.5 35.67207109836172 139.74159341373553 12.5 35.67207109836172 139.74159341373553 33.733</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-06ce190f-c17f-4dcc-b867-810ae266cda1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-06ce190f-c17f-4dcc-b867-810ae266cda1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-06ce190f-c17f-4dcc-b867-810ae266cda1">
											<gml:posList>35.6720714293695 139.74160196334202 33.733 35.67207119430587 139.74160103570563 33.733 35.67207119430587 139.74160103570563 12.5 35.6720714293695 139.74160196334202 12.5 35.6720714293695 139.74160196334202 33.733</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b6c0c992-5a76-4542-9d87-e9ff785ea6f9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b6c0c992-5a76-4542-9d87-e9ff785ea6f9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b6c0c992-5a76-4542-9d87-e9ff785ea6f9">
											<gml:posList>35.67207130497032 139.74159248559374 33.733 35.67207155665593 139.74159156844686 33.733 35.67207155665593 139.74159156844686 12.5 35.67207130497032 139.74159248559374 12.5 35.67207130497032 139.74159248559374 33.733</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4ab9581c-6ac5-4674-a931-5d7238233f41">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4ab9581c-6ac5-4674-a931-5d7238233f41">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4ab9581c-6ac5-4674-a931-5d7238233f41">
											<gml:posList>35.67207170947649 139.74160285778743 33.733 35.6720714293695 139.74160196334202 33.733 35.6720714293695 139.74160196334202 12.5 35.67207170947649 139.74160285778743 12.5 35.67207170947649 139.74160285778743 33.733</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7342ca74-0154-4aeb-895d-ea0ce43cedb5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7342ca74-0154-4aeb-895d-ea0ce43cedb5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7342ca74-0154-4aeb-895d-ea0ce43cedb5">
											<gml:posList>35.67207155665593 139.74159156844686 33.733 35.67207186244912 139.74159068437754 33.733 35.67207186244912 139.74159068437754 12.5 35.67207155665593 139.74159156844686 12.5 35.67207155665593 139.74159156844686 33.733</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-24772180-2577-461c-aa9f-aecdf9cce484">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-24772180-2577-461c-aa9f-aecdf9cce484">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-24772180-2577-461c-aa9f-aecdf9cce484">
											<gml:posList>35.67207202562993 139.74160374114513 33.733 35.67207170947649 139.74160285778743 33.733 35.67207170947649 139.74160285778743 12.5 35.67207202562993 139.74160374114513 12.5 35.67207202562993 139.74160374114513 33.733</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-002782a6-3e6e-444c-acfc-e968719fef69">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-002782a6-3e6e-444c-acfc-e968719fef69">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-002782a6-3e6e-444c-acfc-e968719fef69">
											<gml:posList>35.67207186244912 139.74159068437754 33.733 35.67207220430559 139.74158981131342 33.733 35.67207220430559 139.74158981131342 12.5 35.67207186244912 139.74159068437754 12.5 35.67207186244912 139.74159068437754 33.733</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-dbdb9919-7e84-448a-baf9-afc1f8b16a9f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-dbdb9919-7e84-448a-baf9-afc1f8b16a9f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-dbdb9919-7e84-448a-baf9-afc1f8b16a9f">
											<gml:posList>35.67207220430559 139.74158981131342 33.733 35.672072591264325 139.74158898238366 33.733 35.672072591264325 139.74158898238366 12.5 35.67207220430559 139.74158981131342 12.5 35.67207220430559 139.74158981131342 33.733</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-cb33f5e5-ba51-4c33-9a72-b88e3ecc4df2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cb33f5e5-ba51-4c33-9a72-b88e3ecc4df2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cb33f5e5-ba51-4c33-9a72-b88e3ecc4df2">
											<gml:posList>35.67207286525236 139.74160550762332 33.733 35.67207239584043 139.7416045913015 33.733 35.67207239584043 139.7416045913015 12.5 35.67207286525236 139.74160550762332 12.5 35.67207286525236 139.74160550762332 33.733</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-fc10f492-e9c2-4805-8abe-861f2ad8c161">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fc10f492-e9c2-4805-8abe-861f2ad8c161">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fc10f492-e9c2-4805-8abe-861f2ad8c161">
											<gml:posList>35.672072591264325 139.74158898238366 33.733 35.67207302330849 139.74158817549528 33.733 35.67207302330849 139.74158817549528 12.5 35.672072591264325 139.74158898238366 12.5 35.672072591264325 139.74158898238366 33.733</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-22dad21c-c6cb-422b-b22e-bc1c65e72f27">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-22dad21c-c6cb-422b-b22e-bc1c65e72f27">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-22dad21c-c6cb-422b-b22e-bc1c65e72f27">
											<gml:posList>35.67207302330849 139.74158817549528 33.733 35.67207350044651 139.74158740169477 33.733 35.67207350044651 139.74158740169477 12.5 35.67207302330849 139.74158817549528 12.5 35.67207302330849 139.74158817549528 33.733</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-de1c0c28-0ef1-4e66-a4f7-0023cf6a03ee">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-de1c0c28-0ef1-4e66-a4f7-0023cf6a03ee">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-de1c0c28-0ef1-4e66-a4f7-0023cf6a03ee">
											<gml:posList>35.67207350044651 139.74158740169477 33.733 35.67207400465934 139.74158667204924 33.733 35.67207400465934 139.74158667204924 12.5 35.67207350044651 139.74158740169477 12.5 35.67207350044651 139.74158740169477 33.733</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2f918f3e-4bca-471f-9f1e-d68a0b745583">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2f918f3e-4bca-471f-9f1e-d68a0b745583">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2f918f3e-4bca-471f-9f1e-d68a0b745583">
											<gml:posList>35.672066670047734 139.74166104542633 35.9 35.672066670047734 139.74166104542633 38.476 35.67208133670918 139.74167462688996 38.476 35.67208133670918 139.74167462688996 35.9 35.672066670047734 139.74166104542633 35.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2ca9d4f4-b41c-4c0c-bd7e-ff710f64ac5e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2ca9d4f4-b41c-4c0c-bd7e-ff710f64ac5e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2ca9d4f4-b41c-4c0c-bd7e-ff710f64ac5e">
											<gml:posList>35.67207400465934 139.74158667204924 33.733 35.67207455396603 139.74158597549155 33.733 35.67207455396603 139.74158597549155 12.5 35.67207400465934 139.74158667204924 12.5 35.67207400465934 139.74158667204924 33.733</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-fb38ea1a-770a-4460-80d9-70eed64a8548">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fb38ea1a-770a-4460-80d9-70eed64a8548">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fb38ea1a-770a-4460-80d9-70eed64a8548">
											<gml:posList>35.67207455396603 139.74158597549155 33.733 35.672075139369674 139.74158533412503 33.733 35.672075139369674 139.74158533412503 12.5 35.67207455396603 139.74158597549155 12.5 35.67207455396603 139.74158597549155 33.733</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-039f90d3-d8e9-4acc-8f34-7b7e48fb53d4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-039f90d3-d8e9-4acc-8f34-7b7e48fb53d4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-039f90d3-d8e9-4acc-8f34-7b7e48fb53d4">
											<gml:posList>35.672075139369674 139.74158533412503 33.733 35.67207575183973 139.74158472586703 33.733 35.67207575183973 139.74158472586703 12.5 35.672075139369674 139.74158533412503 12.5 35.672075139369674 139.74158533412503 33.733</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e5ab5b93-9d66-42d3-ac72-875893281289">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e5ab5b93-9d66-42d3-ac72-875893281289">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e5ab5b93-9d66-42d3-ac72-875893281289">
											<gml:posList>35.67207575183973 139.74158472586703 33.733 35.67207639139303 139.74158417281046 33.733 35.67207639139303 139.74158417281046 12.5 35.67207575183973 139.74158472586703 12.5 35.67207575183973 139.74158472586703 33.733</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-edede2ae-ca35-4e6e-9d1f-d3a4fef5dd25">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-edede2ae-ca35-4e6e-9d1f-d3a4fef5dd25">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-edede2ae-ca35-4e6e-9d1f-d3a4fef5dd25">
											<gml:posList>35.67207639139303 139.74158417281046 33.733 35.67207705802957 139.74158367495536 33.733 35.67207705802957 139.74158367495536 12.5 35.67207639139303 139.74158417281046 12.5 35.67207639139303 139.74158417281046 33.733</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-09f3bd01-485e-482e-abf8-e7d4ac28dad1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-09f3bd01-485e-482e-abf8-e7d4ac28dad1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-09f3bd01-485e-482e-abf8-e7d4ac28dad1">
											<gml:posList>35.672039480915025 139.7415969737445 35.9 35.672050068510245 139.74159233315063 35.9 35.672050068510245 139.74159233315063 12.5 35.67211426987915 139.74156419053267 12.5 35.67211426987915 139.74156419053267 7.39 35.672039480915025 139.7415969737445 7.39 35.672039480915025 139.7415969737445 35.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b1816959-43ec-4ad5-b5bf-290461d8767f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b1816959-43ec-4ad5-b5bf-290461d8767f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b1816959-43ec-4ad5-b5bf-290461d8767f">
											<gml:posList>35.67207705802957 139.74158367495536 33.733 35.67207776075466 139.74158322124495 33.733 35.67207776075466 139.74158322124495 12.5 35.67207705802957 139.74158367495536 12.5 35.67207705802957 139.74158367495536 33.733</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-cd9d2080-0a4a-4856-ab7e-10815c0f74e8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cd9d2080-0a4a-4856-ab7e-10815c0f74e8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cd9d2080-0a4a-4856-ab7e-10815c0f74e8">
											<gml:posList>35.67207776075466 139.74158322124495 33.733 35.67207847253555 139.7415828227566 33.733 35.67207847253555 139.7415828227566 12.5 35.67207776075466 139.74158322124495 12.5 35.67207776075466 139.74158322124495 33.733</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d2c8e7d5-4083-4eb3-89cb-ff3cc4aeca13">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d2c8e7d5-4083-4eb3-89cb-ff3cc4aeca13">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d2c8e7d5-4083-4eb3-89cb-ff3cc4aeca13">
											<gml:posList>35.67207847253555 139.7415828227566 33.733 35.672079211399705 139.7415824794697 33.733 35.672079211399705 139.7415824794697 12.5 35.67207847253555 139.7415828227566 12.5 35.67207847253555 139.7415828227566 33.733</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-92fb08f9-af2c-49fe-ae81-ca680bb4d789">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-92fb08f9-af2c-49fe-ae81-ca680bb4d789">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-92fb08f9-af2c-49fe-ae81-ca680bb4d789">
											<gml:posList>35.672079211399705 139.7415824794697 33.733 35.672079959328066 139.74158220245144 33.733 35.672079959328066 139.74158220245144 12.5 35.672079211399705 139.7415824794697 12.5 35.672079211399705 139.7415824794697 33.733</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0ae266fe-c88f-4895-bf86-ad204eb74886">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0ae266fe-c88f-4895-bf86-ad204eb74886">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0ae266fe-c88f-4895-bf86-ad204eb74886">
											<gml:posList>35.672079959328066 139.74158220245144 33.733 35.672080725317535 139.74158196959846 33.733 35.672080725317535 139.74158196959846 12.5 35.672079959328066 139.74158220245144 12.5 35.672079959328066 139.74158220245144 33.733</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-04e41ea5-b467-4824-aa09-aa639f850f2c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-04e41ea5-b467-4824-aa09-aa639f850f2c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-04e41ea5-b467-4824-aa09-aa639f850f2c">
											<gml:posList>35.672080725317535 139.74158196959846 33.733 35.672081500371235 139.74158180301404 33.733 35.672081500371235 139.74158180301404 12.5 35.672080725317535 139.74158196959846 12.5 35.672080725317535 139.74158196959846 33.733</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1e7a48dd-5737-4328-b89f-a194e8673b03">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1e7a48dd-5737-4328-b89f-a194e8673b03">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1e7a48dd-5737-4328-b89f-a194e8673b03">
											<gml:posList>35.672081500371235 139.74158180301404 33.733 35.67208228448916 139.74158170269826 33.733 35.67208228448916 139.74158170269826 12.5 35.672081500371235 139.74158180301404 12.5 35.672081500371235 139.74158180301404 33.733</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ab98429e-4d8a-464e-b6b5-c3a9e8ff9ef3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ab98429e-4d8a-464e-b6b5-c3a9e8ff9ef3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ab98429e-4d8a-464e-b6b5-c3a9e8ff9ef3">
											<gml:posList>35.67208228448916 139.74158170269826 33.733 35.672083068649165 139.74158165761486 33.733 35.672083068649165 139.74158165761486 12.5 35.67208228448916 139.74158170269826 12.5 35.67208228448916 139.74158170269826 33.733</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-eb17dccc-85d4-41fb-80e7-b2edfb5a8c21">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-eb17dccc-85d4-41fb-80e7-b2edfb5a8c21">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-eb17dccc-85d4-41fb-80e7-b2edfb5a8c21">
											<gml:posList>35.672083068649165 139.74158165761486 33.733 35.67208385285126 139.74158166776388 33.733 35.67208385285126 139.74158166776388 12.5 35.672083068649165 139.74158165761486 12.5 35.672083068649165 139.74158165761486 33.733</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-85a4b30b-742e-440b-b064-086db3fa754e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-85a4b30b-742e-440b-b064-086db3fa754e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-85a4b30b-742e-440b-b064-086db3fa754e">
											<gml:posList>35.67208385285126 139.74158166776388 33.733 35.67208463710386 139.74158174419185 33.733 35.67208463710386 139.74158174419185 12.5 35.67208385285126 139.74158166776388 12.5 35.67208385285126 139.74158166776388 33.733</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-509b9010-42a1-4a5f-bdf4-62081ec7e9d0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-509b9010-42a1-4a5f-bdf4-62081ec7e9d0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-509b9010-42a1-4a5f-bdf4-62081ec7e9d0">
											<gml:posList>35.67208463710386 139.74158174419185 33.733 35.67208541239324 139.741581886909 33.733 35.67208541239324 139.741581886909 12.5 35.67208463710386 139.74158174419185 12.5 35.67208463710386 139.74158174419185 33.733</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-45086ed0-e66a-4938-921d-4081c100a94c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-45086ed0-e66a-4938-921d-4081c100a94c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-45086ed0-e66a-4938-921d-4081c100a94c">
											<gml:posList>35.67208541239324 139.741581886909 33.733 35.67208617870257 139.7415820738224 33.733 35.67208617870257 139.7415820738224 12.5 35.67208541239324 139.741581886909 12.5 35.67208541239324 139.741581886909 33.733</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a54214de-fe6b-4f92-a30c-5f33980d01f6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a54214de-fe6b-4f92-a30c-5f33980d01f6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a54214de-fe6b-4f92-a30c-5f33980d01f6">
											<gml:posList>35.67208617870257 139.7415820738224 33.733 35.672086945062404 139.74158232701475 33.733 35.672086945062404 139.74158232701475 12.5 35.67208617870257 139.7415820738224 12.5 35.67208617870257 139.7415820738224 33.733</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-759a30b3-57df-48c2-b958-30b8abe8684e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-759a30b3-57df-48c2-b958-30b8abe8684e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-759a30b3-57df-48c2-b958-30b8abe8684e">
											<gml:posList>35.672086945062404 139.74158232701475 33.733 35.672087684431574 139.74158264651695 33.733 35.672087684431574 139.74158264651695 12.5 35.672086945062404 139.74158232701475 12.5 35.672086945062404 139.74158232701475 33.733</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-31603d85-de14-4b4d-a75a-edeaeabc8bf2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-31603d85-de14-4b4d-a75a-edeaeabc8bf2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-31603d85-de14-4b4d-a75a-edeaeabc8bf2">
											<gml:posList>35.672087684431574 139.74158264651695 33.733 35.6720884148207 139.7415830102154 33.733 35.6720884148207 139.7415830102154 12.5 35.672087684431574 139.74158264651695 12.5 35.672087684431574 139.74158264651695 33.733</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a7cf3a5b-d8e6-4ff5-ad87-f1bda59a7606">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a7cf3a5b-d8e6-4ff5-ad87-f1bda59a7606">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a7cf3a5b-d8e6-4ff5-ad87-f1bda59a7606">
											<gml:posList>35.6720884148207 139.7415830102154 33.733 35.67208911821074 139.74158342917727 33.733 35.67208911821074 139.74158342917727 12.5 35.6720884148207 139.7415830102154 12.5 35.6720884148207 139.7415830102154 33.733</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ae66fc68-160a-49b4-ada0-b55bf0868845">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ae66fc68-160a-49b4-ada0-b55bf0868845">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ae66fc68-160a-49b4-ada0-b55bf0868845">
											<gml:posList>35.67208911821074 139.74158342917727 33.733 35.672089803623855 139.74158391443865 33.733 35.672089803623855 139.74158391443865 12.5 35.67208911821074 139.74158342917727 12.5 35.67208911821074 139.74158342917727 33.733</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2a006df5-24b5-4344-832c-4bbc0f817a92">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2a006df5-24b5-4344-832c-4bbc0f817a92">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2a006df5-24b5-4344-832c-4bbc0f817a92">
											<gml:posList>35.672089803623855 139.74158391443865 33.733 35.67209046202945 139.74158444391696 33.733 35.67209046202945 139.74158444391696 12.5 35.672089803623855 139.74158391443865 12.5 35.672089803623855 139.74158391443865 33.733</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1f6192bd-e77e-4484-a6fe-ce2b6bc693fc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1f6192bd-e77e-4484-a6fe-ce2b6bc693fc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1f6192bd-e77e-4484-a6fe-ce2b6bc693fc">
											<gml:posList>35.67209046202945 139.74158444391696 33.733 35.67209108441386 139.74158501762244 33.733 35.67209108441386 139.74158501762244 12.5 35.67209046202945 139.74158444391696 12.5 35.67209046202945 139.74158444391696 33.733</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8cab4a67-7b8f-448e-a74b-8d57ca096493">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8cab4a67-7b8f-448e-a74b-8d57ca096493">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8cab4a67-7b8f-448e-a74b-8d57ca096493">
											<gml:posList>35.67209108441386 139.74158501762244 33.733 35.672091688812884 139.741585646581 33.733 35.672091688812884 139.741585646581 12.5 35.67209108441386 139.74158501762244 12.5 35.67209108441386 139.74158501762244 33.733</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-cd42d445-8e75-4f21-8137-042d393f21db">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cd42d445-8e75-4f21-8137-042d393f21db">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cd42d445-8e75-4f21-8137-042d393f21db">
											<gml:posList>35.672091976258294 139.74160800435877 33.733 35.672091390854526 139.74160864572525 33.733 35.672091390854526 139.74160864572525 12.5 35.672091976258294 139.74160800435877 12.5 35.672091976258294 139.74160800435877 33.733</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a740c32f-6fa1-49f9-a608-6d1602d8509d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a740c32f-6fa1-49f9-a608-6d1602d8509d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a740c32f-6fa1-49f9-a608-6d1602d8509d">
											<gml:posList>35.672091688812884 139.741585646581 33.733 35.67209224816856 139.7415863087306 33.733 35.67209224816856 139.7415863087306 12.5 35.672091688812884 139.741585646581 12.5 35.672091688812884 139.741585646581 33.733</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9949b593-728f-4a0c-ab37-53fa306d5a1c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9949b593-728f-4a0c-ab37-53fa306d5a1c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9949b593-728f-4a0c-ab37-53fa306d5a1c">
											<gml:posList>35.6720925255651 139.74160730780108 33.733 35.672091976258294 139.74160800435877 33.733 35.672091976258294 139.74160800435877 12.5 35.6720925255651 139.74160730780108 12.5 35.6720925255651 139.74160730780108 33.733</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-bfa31e5e-bfc9-4531-b540-9e14a245fb9a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bfa31e5e-bfc9-4531-b540-9e14a245fb9a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bfa31e5e-bfc9-4531-b540-9e14a245fb9a">
											<gml:posList>35.67209224816856 139.7415863087306 33.733 35.672092780525155 139.74158702614363 33.733 35.672092780525155 139.74158702614363 12.5 35.67209224816856 139.7415863087306 12.5 35.67209224816856 139.7415863087306 33.733</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0db12260-685d-49dd-8566-9ffac1005c6d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0db12260-685d-49dd-8566-9ffac1005c6d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0db12260-685d-49dd-8566-9ffac1005c6d">
											<gml:posList>35.672093029778054 139.7416065781555 33.733 35.6720925255651 139.74160730780108 33.733 35.6720925255651 139.74160730780108 12.5 35.672093029778054 139.7416065781555 12.5 35.672093029778054 139.7416065781555 33.733</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9945afe1-19fd-4bdb-94e5-13fe0afd4b87">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9945afe1-19fd-4bdb-94e5-13fe0afd4b87">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9945afe1-19fd-4bdb-94e5-13fe0afd4b87">
											<gml:posList>35.672092780525155 139.74158702614363 33.733 35.67209326783841 139.74158777674765 33.733 35.67209326783841 139.74158777674765 12.5 35.672092780525155 139.74158702614363 12.5 35.672092780525155 139.74158702614363 33.733</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-989953b3-ed45-4337-a3ed-2fa05a086aef">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-989953b3-ed45-4337-a3ed-2fa05a086aef">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-989953b3-ed45-4337-a3ed-2fa05a086aef">
											<gml:posList>35.672093506916184 139.74160580435492 33.733 35.672093029778054 139.7416065781555 33.733 35.672093029778054 139.7416065781555 12.5 35.672093506916184 139.74160580435492 12.5 35.672093506916184 139.74160580435492 33.733</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8e155986-2a27-462f-b746-14d98e8787f8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8e155986-2a27-462f-b746-14d98e8787f8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8e155986-2a27-462f-b746-14d98e8787f8">
											<gml:posList>35.67209326783841 139.74158777674765 33.733 35.67209371913043 139.74158857157892 33.733 35.67209371913043 139.74158857157892 12.5 35.67209326783841 139.74158777674765 12.5 35.67209326783841 139.74158777674765 33.733</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d1facffd-f4d1-4a22-be8c-d0cfa48e4245">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d1facffd-f4d1-4a22-be8c-d0cfa48e4245">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d1facffd-f4d1-4a22-be8c-d0cfa48e4245">
											<gml:posList>35.672093938960465 139.74160499746642 33.733 35.672093506916184 139.74160580435492 33.733 35.672093506916184 139.74160580435492 12.5 35.672093938960465 139.74160499746642 12.5 35.672093938960465 139.74160499746642 33.733</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-fc8b11cd-6f61-4506-8e8d-ec56f65aab31">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fc8b11cd-6f61-4506-8e8d-ec56f65aab31">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fc8b11cd-6f61-4506-8e8d-ec56f65aab31">
											<gml:posList>35.67209371913043 139.74158857157892 33.733 35.672094134384395 139.7415893885444 33.733 35.672094134384395 139.7415893885444 12.5 35.67209371913043 139.74158857157892 12.5 35.67209371913043 139.74158857157892 33.733</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0b1c97fe-db74-4516-81b7-f9edd9345e5e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0b1c97fe-db74-4516-81b7-f9edd9345e5e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0b1c97fe-db74-4516-81b7-f9edd9345e5e">
											<gml:posList>35.672094325910884 139.74160415749 33.733 35.672093938960465 139.74160499746642 33.733 35.672093938960465 139.74160499746642 12.5 35.672094325910884 139.74160415749 12.5 35.672094325910884 139.74160415749 33.733</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-086a1198-e22a-42d4-a592-e0852303effa">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-086a1198-e22a-42d4-a592-e0852303effa">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-086a1198-e22a-42d4-a592-e0852303effa">
											<gml:posList>35.672094134384395 139.7415893885444 33.733 35.67209450459501 139.74159023870092 33.733 35.67209450459501 139.74159023870092 12.5 35.672094134384395 139.7415893885444 12.5 35.672094134384395 139.7415893885444 33.733</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ebac2da8-931b-404f-8d93-bc00767f2856">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ebac2da8-931b-404f-8d93-bc00767f2856">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ebac2da8-931b-404f-8d93-bc00767f2856">
											<gml:posList>35.672094667775866 139.7416032954722 33.733 35.672094325910884 139.74160415749 33.733 35.672094325910884 139.74160415749 12.5 35.672094667775866 139.7416032954722 12.5 35.672094667775866 139.7416032954722 33.733</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d0e587ca-a265-4edb-ab08-4037dc2b051b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d0e587ca-a265-4edb-ab08-4037dc2b051b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d0e587ca-a265-4edb-ab08-4037dc2b051b">
											<gml:posList>35.67209450459501 139.74159023870092 33.733 35.67209482074855 139.74159112205882 33.733 35.67209482074855 139.74159112205882 12.5 35.67209450459501 139.74159023870092 12.5 35.67209450459501 139.74159023870092 33.733</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d32637fd-6689-47af-9abf-09d9a0c6df35">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d32637fd-6689-47af-9abf-09d9a0c6df35">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d32637fd-6689-47af-9abf-09d9a0c6df35">
											<gml:posList>35.67209497356913 139.74160241140268 33.733 35.672094667775866 139.7416032954722 33.733 35.672094667775866 139.7416032954722 12.5 35.67209497356913 139.74160241140268 12.5 35.67209497356913 139.74160241140268 33.733</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6f95f13d-6bc7-4a39-b0dc-102606c93a67">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6f95f13d-6bc7-4a39-b0dc-102606c93a67">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6f95f13d-6bc7-4a39-b0dc-102606c93a67">
											<gml:posList>35.67209482074855 139.74159112205882 33.733 35.6720951008556 139.74159201650443 33.733 35.6720951008556 139.74159201650443 12.5 35.67209482074855 139.74159112205882 12.5 35.67209482074855 139.74159112205882 33.733</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ea8738f7-66f4-4309-a52b-a8a772fb25df">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ea8738f7-66f4-4309-a52b-a8a772fb25df">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ea8738f7-66f4-4309-a52b-a8a772fb25df">
											<gml:posList>35.67214008153836 139.74167773007483 12.5 35.67209892216821 139.74163868357886 12.5 35.67209892216821 139.74163868357886 33.483 35.67206952518438 139.7416107916681 33.733 35.67206952518438 139.7416107916681 12.5 35.672050068510245 139.74159233315063 12.5 35.672050068510245 139.74159233315063 35.9 35.67214008153836 139.74167773007483 35.9 35.67214008153836 139.74167773007483 12.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7968df01-da76-4dad-b6db-db12d2ad6edc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7968df01-da76-4dad-b6db-db12d2ad6edc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7968df01-da76-4dad-b6db-db12d2ad6edc">
											<gml:posList>35.67209522525482 139.74160149425552 33.733 35.67209497356913 139.74160241140268 33.733 35.67209497356913 139.74160241140268 12.5 35.67209522525482 139.74160149425552 12.5 35.67209522525482 139.74160149425552 33.733</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a053c44a-847b-4c8b-8f5a-e26a26671c8d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a053c44a-847b-4c8b-8f5a-e26a26671c8d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a053c44a-847b-4c8b-8f5a-e26a26671c8d">
											<gml:posList>35.6720951008556 139.74159201650443 33.733 35.6720953359193 139.7415929441411 33.733 35.6720953359193 139.7415929441411 12.5 35.6720951008556 139.74159201650443 12.5 35.6720951008556 139.74159201650443 33.733</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3e4bf1e5-312c-42dc-b575-2f1515a036ce">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3e4bf1e5-312c-42dc-b575-2f1515a036ce">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3e4bf1e5-312c-42dc-b575-2f1515a036ce">
											<gml:posList>35.6720954318635 139.74160056611348 33.733 35.67209522525482 139.74160149425552 33.733 35.67209522525482 139.74160149425552 12.5 35.6720954318635 139.74160056611348 12.5 35.6720954318635 139.74160056611348 33.733</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-26729009-b221-4399-82a5-ad2e554d287f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-26729009-b221-4399-82a5-ad2e554d287f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-26729009-b221-4399-82a5-ad2e554d287f">
											<gml:posList>35.6720953359193 139.7415929441411 33.733 35.672095516900676 139.74159387183968 33.733 35.672095516900676 139.74159387183968 12.5 35.6720953359193 139.7415929441411 12.5 35.6720953359193 139.7415929441411 33.733</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6cb2d7ca-785f-4b0b-86a4-1bc493d876ef">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6cb2d7ca-785f-4b0b-86a4-1bc493d876ef">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6cb2d7ca-785f-4b0b-86a4-1bc493d876ef">
											<gml:posList>35.67209559339512 139.7415996269765 33.733 35.6720954318635 139.74160056611348 33.733 35.6720954318635 139.74160056611348 12.5 35.67209559339512 139.7415996269765 12.5 35.67209559339512 139.7415996269765 33.733</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a5956c5c-b471-44e0-ad85-f5e63acf8430">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a5956c5c-b471-44e0-ad85-f5e63acf8430">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a5956c5c-b471-44e0-ad85-f5e63acf8430">
											<gml:posList>35.672095516900676 139.74159387183968 33.733 35.67209565283027 139.74159482168278 33.733 35.67209565283027 139.74159482168278 12.5 35.672095516900676 139.74159387183968 12.5 35.672095516900676 139.74159387183968 33.733</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2ce2bc79-b314-4c35-8cb5-088bf0b2ffb2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2ce2bc79-b314-4c35-8cb5-088bf0b2ffb2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2ce2bc79-b314-4c35-8cb5-088bf0b2ffb2">
											<gml:posList>35.672095700827605 139.74159866580843 33.733 35.67209559339512 139.7415996269765 33.733 35.67209559339512 139.7415996269765 12.5 35.672095700827605 139.74159866580843 12.5 35.672095700827605 139.74159866580843 33.733</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-eaf37423-24db-4d5b-b9ea-7144308bf364">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-eaf37423-24db-4d5b-b9ea-7144308bf364">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-eaf37423-24db-4d5b-b9ea-7144308bf364">
											<gml:posList>35.67209565283027 139.74159482168278 33.733 35.67209574369967 139.74159578262393 33.733 35.67209574369967 139.74159578262393 12.5 35.67209565283027 139.74159482168278 12.5 35.67209565283027 139.74159482168278 33.733</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ebc2d0fb-20a4-4293-8e14-118928cfb246">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ebc2d0fb-20a4-4293-8e14-118928cfb246">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ebc2d0fb-20a4-4293-8e14-118928cfb246">
											<gml:posList>35.672095763191486 139.74159770469194 33.733 35.672095700827605 139.74159866580843 33.733 35.672095700827605 139.74159866580843 12.5 35.672095763191486 139.74159770469194 12.5 35.672095763191486 139.74159770469194 33.733</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-fc9172c1-d77d-4549-bbd5-83c413f4781f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fc9172c1-d77d-4549-bbd5-83c413f4781f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fc9172c1-d77d-4549-bbd5-83c413f4781f">
											<gml:posList>35.67209574369967 139.74159578262393 33.733 35.672095780486735 139.741596743627 33.733 35.672095780486735 139.741596743627 12.5 35.67209574369967 139.74159578262393 12.5 35.67209574369967 139.74159578262393 33.733</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-01a16802-fdde-4567-93a0-7aef49b52b26">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-01a16802-fdde-4567-93a0-7aef49b52b26">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-01a16802-fdde-4567-93a0-7aef49b52b26">
											<gml:posList>35.672095780486735 139.741596743627 33.733 35.672095763191486 139.74159770469194 33.733 35.672095763191486 139.74159770469194 12.5 35.672095780486735 139.741596743627 12.5 35.672095780486735 139.741596743627 33.733</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1917b6ab-a5a2-4134-8818-6ce53a0817a5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1917b6ab-a5a2-4134-8818-6ce53a0817a5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1917b6ab-a5a2-4134-8818-6ce53a0817a5">
											<gml:posList>35.6720910215781 139.7416090217286 33.733 35.672107672954915 139.74162482126246 33.733 35.672107672954915 139.74162482126246 12.5 35.6720910215781 139.7416090217286 12.5 35.6720910215781 139.7416090217286 33.733</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f37cdb8b-d31f-49f6-9461-f2ac60501158">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f37cdb8b-d31f-49f6-9461-f2ac60501158">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f37cdb8b-d31f-49f6-9461-f2ac60501158">
											<gml:posList>35.672107672954915 139.74162482126246 33.733 35.67209892216821 139.74163868357886 33.483 35.67209892216821 139.74163868357886 12.5 35.672107672954915 139.74162482126246 12.5 35.672107672954915 139.74162482126246 33.733</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0d7c1170-b3bb-498f-9c90-5c26f090c456">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0d7c1170-b3bb-498f-9c90-5c26f090c456">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0d7c1170-b3bb-498f-9c90-5c26f090c456">
											<gml:posList>35.672172509624595 139.74157870525715 7.39 35.67211426987915 139.74156419053267 7.39 35.67211426987915 139.74156419053267 12.5 35.672172509624595 139.74157870525715 12.5 35.672172509624595 139.74157870525715 7.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0d998890-baa5-4d52-a6ab-99902b61e8ae">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0d998890-baa5-4d52-a6ab-99902b61e8ae">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0d998890-baa5-4d52-a6ab-99902b61e8ae">
											<gml:posList>35.67219253211972 139.74159447885023 7.39 35.672172509624595 139.74157870525715 7.39 35.672172509624595 139.74157870525715 12.5 35.67219253211972 139.74159447885023 12.5 35.67219253211972 139.74159447885023 7.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f39c22dd-8315-46bf-b376-e6a9fb7c375c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f39c22dd-8315-46bf-b376-e6a9fb7c375c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f39c22dd-8315-46bf-b376-e6a9fb7c375c">
											<gml:posList>35.672039480915025 139.7415969737445 7.39 35.67189306384822 139.74178901842882 7.39 35.67189306384822 139.74178901842882 35.9 35.672039480915025 139.7415969737445 35.9 35.672039480915025 139.7415969737445 7.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c324dd64-26b4-4a67-a592-db19fe395994">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c324dd64-26b4-4a67-a592-db19fe395994">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c324dd64-26b4-4a67-a592-db19fe395994">
											<gml:posList>35.67208133670918 139.74167462688996 35.9 35.67208133670918 139.74167462688996 38.476 35.67205823598551 139.741712078811 38.476 35.67205823598551 139.741712078811 35.9 35.67208133670918 139.74167462688996 35.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2a78c54f-65e1-47a0-aae8-0e4cda2b670b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2a78c54f-65e1-47a0-aae8-0e4cda2b670b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2a78c54f-65e1-47a0-aae8-0e4cda2b670b">
											<gml:posList>35.67205823598551 139.741712078811 35.9 35.67205823598551 139.741712078811 38.476 35.67204357833356 139.74169848628765 38.476 35.67204357833356 139.74169848628765 35.9 35.67205823598551 139.741712078811 35.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f2faf60c-c38f-4f3a-af3b-872a3fb307a0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f2faf60c-c38f-4f3a-af3b-872a3fb307a0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f2faf60c-c38f-4f3a-af3b-872a3fb307a0">
											<gml:posList>35.67214008153836 139.74167773007483 12.5 35.67214008153836 139.74167773007483 35.9 35.67207090356526 139.74178751187836 35.9 35.67207090356526 139.74178751187836 41.476 35.672030210603026 139.74185210296704 41.476 35.672030210603026 139.74185210296704 35.9 35.67199680992982 139.7419051089617 35.9 35.67199680992982 139.7419051089617 7.39 35.67219253211972 139.74159447885023 7.39 35.67219253211972 139.74159447885023 12.5 35.67214008153836 139.74167773007483 12.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8f4885d8-6ba6-4674-a1f2-bca85c439968">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8f4885d8-6ba6-4674-a1f2-bca85c439968">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8f4885d8-6ba6-4674-a1f2-bca85c439968">
											<gml:posList>35.67200850168384 139.74172846235055 35.9 35.67200850168384 139.74172846235055 41.476 35.67207090356526 139.74178751187836 41.476 35.67207090356526 139.74178751187836 35.9 35.67200850168384 139.74172846235055 35.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-40e911c4-b4ba-4338-ab8f-fd9a4f5274fb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-40e911c4-b4ba-4338-ab8f-fd9a4f5274fb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-40e911c4-b4ba-4338-ab8f-fd9a4f5274fb">
											<gml:posList>35.67196779973909 139.7417930534291 35.9 35.67196779973909 139.7417930534291 41.476 35.67200850168384 139.74172846235055 41.476 35.67200850168384 139.74172846235055 35.9 35.67196779973909 139.7417930534291 35.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-59596e55-ca01-4867-b120-85d1030b4158">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-59596e55-ca01-4867-b120-85d1030b4158">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-59596e55-ca01-4867-b120-85d1030b4158">
											<gml:posList>35.67189306384822 139.74178901842882 7.39 35.67189307686427 139.74180614043937 7.39 35.67189307686427 139.74180614043937 35.9 35.67189306384822 139.74178901842882 35.9 35.67189306384822 139.74178901842882 7.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-62d324a4-e37e-405f-a293-c7537ba823ee">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-62d324a4-e37e-405f-a293-c7537ba823ee">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-62d324a4-e37e-405f-a293-c7537ba823ee">
											<gml:posList>35.671951702496315 139.7418303094796 35.9 35.671951702496315 139.7418303094796 38.476 35.67196435041112 139.74180876545896 38.476 35.67196435041112 139.74180876545896 35.9 35.671951702496315 139.7418303094796 35.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-fc2f1434-0640-4240-a292-79b6c376855f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fc2f1434-0640-4240-a292-79b6c376855f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fc2f1434-0640-4240-a292-79b6c376855f">
											<gml:posList>35.672030210603026 139.74185210296704 35.9 35.672030210603026 139.74185210296704 41.476 35.67196779973909 139.7417930534291 41.476 35.67196779973909 139.7417930534291 35.9 35.672030210603026 139.74185210296704 35.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-62f7eca7-c349-4ebd-a717-ff2ada2034cb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-62f7eca7-c349-4ebd-a717-ff2ada2034cb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-62f7eca7-c349-4ebd-a717-ff2ada2034cb">
											<gml:posList>35.67196435041112 139.74180876545896 35.9 35.67196435041112 139.74180876545896 38.476 35.67201309326227 139.74185174691837 38.476 35.67201309326227 139.74185174691837 35.9 35.67196435041112 139.74180876545896 35.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2753e24f-45b2-4659-8056-f651b5036f5a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2753e24f-45b2-4659-8056-f651b5036f5a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2753e24f-45b2-4659-8056-f651b5036f5a">
											<gml:posList>35.6720004453315 139.7418732798989 35.9 35.6720004453315 139.7418732798989 38.476 35.671951702496315 139.7418303094796 38.476 35.671951702496315 139.7418303094796 35.9 35.6720004453315 139.7418732798989 35.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e2fd0ffb-5404-4dc4-adca-912c80d0c424">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e2fd0ffb-5404-4dc4-adca-912c80d0c424">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e2fd0ffb-5404-4dc4-adca-912c80d0c424">
											<gml:posList>35.67189307686427 139.74180614043937 7.39 35.67199680992982 139.7419051089617 7.39 35.67199680992982 139.7419051089617 35.9 35.67189307686427 139.74180614043937 35.9 35.67189307686427 139.74180614043937 7.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9bf5c279-f2d2-4781-b0db-754af20802f7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9bf5c279-f2d2-4781-b0db-754af20802f7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9bf5c279-f2d2-4781-b0db-754af20802f7">
											<gml:posList>35.67201309326227 139.74185174691837 35.9 35.67201309326227 139.74185174691837 38.476 35.6720004453315 139.7418732798989 38.476 35.6720004453315 139.7418732798989 35.9 35.67201309326227 139.74185174691837 35.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13101-bldg-4492</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13101</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">458.0165</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1210</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>7</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.31</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.0</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>