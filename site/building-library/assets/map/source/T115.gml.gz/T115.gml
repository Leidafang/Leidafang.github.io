<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_1e970fae-0d7b-4da8-a3f3-8469a301e34e">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001001</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">401</bldg:usage>
			<bldg:measuredHeight uom="m">19.3</bldg:measuredHeight>
			<bldg:storeysAboveGround>5</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.67052790182932 139.74342045577993 0 35.67052195153471 139.74341880551086 0 35.67051773174459 139.74344112372606 0 35.670617264273446 139.74346918017852 0 35.67063854224442 139.74335593180248 0 35.67054495990298 139.74332941528323 0 35.67052790182932 139.74342045577993 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67052790182932 139.74342045577993 7.29 35.67054495990298 139.74332941528323 7.29 35.67063854224442 139.74335593180248 7.29 35.670617264273446 139.74346918017852 7.29 35.67051773174459 139.74344112372606 7.29 35.67052195153471 139.74341880551086 7.29 35.67052790182932 139.74342045577993 7.29</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67052790182932 139.74342045577993 7.29 35.67052195153471 139.74341880551086 7.29 35.67052195153471 139.74341880551086 26.61 35.67052790182932 139.74342045577993 26.61 35.67052790182932 139.74342045577993 7.29</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67052195153471 139.74341880551086 7.29 35.67051773174459 139.74344112372606 7.29 35.67051773174459 139.74344112372606 26.61 35.67052195153471 139.74341880551086 26.61 35.67052195153471 139.74341880551086 7.29</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67051773174459 139.74344112372606 7.29 35.670617264273446 139.74346918017852 7.29 35.670617264273446 139.74346918017852 26.61 35.67051773174459 139.74344112372606 26.61 35.67051773174459 139.74344112372606 7.29</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670617264273446 139.74346918017852 7.29 35.67063854224442 139.74335593180248 7.29 35.67063854224442 139.74335593180248 26.61 35.670617264273446 139.74346918017852 26.61 35.670617264273446 139.74346918017852 7.29</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67063854224442 139.74335593180248 7.29 35.67054495990298 139.74332941528323 7.29 35.67054495990298 139.74332941528323 26.61 35.67063854224442 139.74335593180248 26.61 35.67063854224442 139.74335593180248 7.29</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67054495990298 139.74332941528323 7.29 35.67052790182932 139.74342045577993 7.29 35.67052790182932 139.74342045577993 26.61 35.67054495990298 139.74332941528323 26.61 35.67054495990298 139.74332941528323 7.29</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67052790182932 139.74342045577993 26.61 35.67052195153471 139.74341880551086 26.61 35.67051773174459 139.74344112372606 26.61 35.670617264273446 139.74346918017852 26.61 35.67063854224442 139.74335593180248 26.61 35.67054495990298 139.74332941528323 26.61 35.67052790182932 139.74342045577993 26.61</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-e17e9533-5e69-45f9-91dc-bb7616806b95"/>
							<gml:surfaceMember xlink:href="#poly-3ed94a23-93a5-47d9-a133-9c0b548da5f1"/>
							<gml:surfaceMember xlink:href="#poly-d08f29a2-d063-48e8-ada7-c048ba13b119"/>
							<gml:surfaceMember xlink:href="#poly-1150f597-f504-49e3-bbd0-5fc4a4cbf95d"/>
							<gml:surfaceMember xlink:href="#poly-6143bd58-c7e9-4a04-b51b-d05d665bb708"/>
							<gml:surfaceMember xlink:href="#poly-77c8feac-613a-4cae-96e7-c09f70751d80"/>
							<gml:surfaceMember xlink:href="#poly-7e15f6f7-f58f-4a63-ad1d-6470d81caf58"/>
							<gml:surfaceMember xlink:href="#poly-0fdc669f-94d0-4e24-84d4-3d8c5af0d648"/>
							<gml:surfaceMember xlink:href="#poly-6a17074e-d6a1-4892-80e4-1594e00bfc4f"/>
							<gml:surfaceMember xlink:href="#poly-21d34eb2-8cb8-41a9-b0ef-7b31c15beebe"/>
							<gml:surfaceMember xlink:href="#poly-9547a8fa-6212-477c-9886-6ac551fde2cc"/>
							<gml:surfaceMember xlink:href="#poly-7027473d-a2a0-467c-9127-12820b6b5833"/>
							<gml:surfaceMember xlink:href="#poly-a57bcc8f-c545-4562-a9a3-2e8b9581753a"/>
							<gml:surfaceMember xlink:href="#poly-7dbd1ebb-e78a-4138-bd2f-228415e15ee6"/>
							<gml:surfaceMember xlink:href="#poly-7ed0cba4-e2ef-4f35-a249-9bda33be0a0a"/>
							<gml:surfaceMember xlink:href="#poly-c9eb5d7f-a04c-4f41-8471-a7aaffba518e"/>
							<gml:surfaceMember xlink:href="#poly-8f71b717-10ae-47f9-a5d7-4f2a8f1a4aef"/>
							<gml:surfaceMember xlink:href="#poly-702575a4-fac5-4e6f-a4cf-5cc7222e27ce"/>
							<gml:surfaceMember xlink:href="#poly-d0860111-27e9-49f4-bf1e-aa9c6d386d4a"/>
							<gml:surfaceMember xlink:href="#poly-b7e92d73-c77c-4f77-9d1c-cdbcc58ea0a1"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_1e970fae-0d7b-4da8-a3f3-8469a301e34e_BuildingInstallation_1041">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-50d3dc57-acb9-483a-83d8-9dff0fe80e3d">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67056164657008 139.74345310389413 27.3 35.67056201464856 139.7434511151502 27.3 35.67059070236755 139.74345919096584 27.3 35.67059034331916 139.74346120179285 27.3 35.67056164657008 139.74345310389413 27.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-31c17054-4050-4c2b-b6c1-34f4015588e6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67056201464856 139.7434511151502 25.85 35.670566907393315 139.74342467590412 25.85 35.670595604136025 139.74343276274692 25.85 35.67059070236755 139.74345919096584 25.85 35.67056201464856 139.7434511151502 25.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-dd763d4c-9298-452b-9060-2953f017d425">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-dd763d4c-9298-452b-9060-2953f017d425_0">
											<gml:posList>35.67056201464856 139.7434511151502 27.3 35.67056164657008 139.74345310389413 27.3 35.67056164657008 139.74345310389413 31.275 35.670566907393315 139.74342467590412 31.275 35.670566907393315 139.74342467590412 25.85 35.67056201464856 139.7434511151502 25.85 35.67056201464856 139.7434511151502 27.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c179b29f-4c34-4aac-a788-786a2b9e5c43">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c179b29f-4c34-4aac-a788-786a2b9e5c43_0">
											<gml:posList>35.67059034331916 139.74346120179285 27.3 35.67059034331916 139.74346120179285 31.275 35.67056164657008 139.74345310389413 31.275 35.67056164657008 139.74345310389413 27.3 35.67059034331916 139.74346120179285 27.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-10e65288-64d5-4e6d-a8c9-b4b716474cb4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-10e65288-64d5-4e6d-a8c9-b4b716474cb4_0">
											<gml:posList>35.67056201464856 139.7434511151502 25.85 35.67059070236755 139.74345919096584 25.85 35.67059070236755 139.74345919096584 27.3 35.67056201464856 139.7434511151502 27.3 35.67056201464856 139.7434511151502 25.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-06ec8ac7-b13c-43ca-bd86-6e79a112857e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-06ec8ac7-b13c-43ca-bd86-6e79a112857e_0">
											<gml:posList>35.670595604136025 139.74343276274692 31.275 35.670566907393315 139.74342467590412 31.275 35.67056164657008 139.74345310389413 31.275 35.67059034331916 139.74346120179285 31.275 35.670595604136025 139.74343276274692 31.275</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7f2ea593-fd52-4a1b-8601-2605d372cffa">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7f2ea593-fd52-4a1b-8601-2605d372cffa_0">
											<gml:posList>35.670566907393315 139.74342467590412 25.85 35.670566907393315 139.74342467590412 31.275 35.670595604136025 139.74343276274692 31.275 35.670595604136025 139.74343276274692 25.85 35.670566907393315 139.74342467590412 25.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-78ebd832-32e3-4180-83e3-d99debc7ab85">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-78ebd832-32e3-4180-83e3-d99debc7ab85_0">
											<gml:posList>35.670595604136025 139.74343276274692 25.85 35.670595604136025 139.74343276274692 31.275 35.67059034331916 139.74346120179285 31.275 35.67059034331916 139.74346120179285 27.3 35.67059070236755 139.74345919096584 27.3 35.67059070236755 139.74345919096584 25.85 35.670595604136025 139.74343276274692 25.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_1e970fae-0d7b-4da8-a3f3-8469a301e34e_BuildingInstallation_1060">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-17665954-0863-4b46-be9f-cc1ed7db0f85">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670620709616855 139.74335129027932 27.3 35.670620341523524 139.74335325693258 27.3 35.670614021566415 139.74335147452595 27.3 35.670614389651455 139.7433494968266 27.3 35.670620709616855 139.74335129027932 27.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7c8a448d-9a01-4a5b-9387-e1c1fc90ac22">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670620341523524 139.74335325693258 25.85 35.67061435337823 139.7433853973163 25.85 35.67060803341332 139.74338360386102 25.85 35.670614021566415 139.74335147452595 25.85 35.670620341523524 139.74335325693258 25.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-09e69d15-8442-45cc-8560-e3eec0cf587a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-09e69d15-8442-45cc-8560-e3eec0cf587a_0">
											<gml:posList>35.67061435337823 139.7433853973163 25.85 35.67061435337823 139.7433853973163 28.414 35.67060803341332 139.74338360386102 28.414 35.67060803341332 139.74338360386102 25.85 35.67061435337823 139.7433853973163 25.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7827e197-3531-4515-89e6-585043fb32ac">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7827e197-3531-4515-89e6-585043fb32ac_0">
											<gml:posList>35.670614021566415 139.74335147452595 27.3 35.670614021566415 139.74335147452595 25.85 35.67060803341332 139.74338360386102 25.85 35.67060803341332 139.74338360386102 28.414 35.670614389651455 139.7433494968266 28.414 35.670614389651455 139.7433494968266 27.3 35.670614021566415 139.74335147452595 27.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1e0e8987-c545-41b2-bd09-8936aa420548">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1e0e8987-c545-41b2-bd09-8936aa420548_0">
											<gml:posList>35.67060803341332 139.74338360386102 28.414 35.67061435337823 139.7433853973163 28.414 35.670620709616855 139.74335129027932 28.414 35.670614389651455 139.7433494968266 28.414 35.67060803341332 139.74338360386102 28.414</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4a8e9273-c31b-424a-af92-43a32418d1b7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4a8e9273-c31b-424a-af92-43a32418d1b7_0">
											<gml:posList>35.670620341523524 139.74335325693258 25.85 35.670614021566415 139.74335147452595 25.85 35.670614021566415 139.74335147452595 27.3 35.670620341523524 139.74335325693258 27.3 35.670620341523524 139.74335325693258 25.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6118807a-dc87-4aa5-a50b-889b573f49af">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6118807a-dc87-4aa5-a50b-889b573f49af_0">
											<gml:posList>35.670620709616855 139.74335129027932 28.414 35.67061435337823 139.7433853973163 28.414 35.67061435337823 139.7433853973163 25.85 35.670620341523524 139.74335325693258 25.85 35.670620341523524 139.74335325693258 27.3 35.670620709616855 139.74335129027932 27.3 35.670620709616855 139.74335129027932 28.414</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6eccc11d-17b2-4b4c-91f8-28d95f88498d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6eccc11d-17b2-4b4c-91f8-28d95f88498d_0">
											<gml:posList>35.670614389651455 139.7433494968266 27.3 35.670614389651455 139.7433494968266 28.414 35.670620709616855 139.74335129027932 28.414 35.670620709616855 139.74335129027932 27.3 35.670614389651455 139.7433494968266 27.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_1e970fae-0d7b-4da8-a3f3-8469a301e34e_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-83b5352e-c179-49f0-9356-990c3334a0ba">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67059965965125 139.74334740351696 27.3 35.67060240928256 139.7433479969306 27.3 35.670602382373474 139.74334817370146 27.3 35.67059965965125 139.74334740351696 27.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0482291b-5734-4d3e-8528-2b9540575d45">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67058339626137 139.74334389800424 25.85 35.67059965965125 139.74334740351696 25.85 35.670602382373474 139.74334817370146 25.85 35.67060074138897 139.74335958636087 25.85 35.67058173738187 139.74335548742172 25.85 35.67058339626137 139.74334389800424 25.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-55c049d4-4aae-4f32-b988-728ccb5300fc">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67056938694471 139.7433774392055 25.85 35.67055057196223 139.74337298657056 25.85 35.670552267550356 139.74336226977314 25.85 35.67057107351951 139.74336672241574 25.85 35.67056938694471 139.7433774392055 25.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d05d66b6-c098-43fd-b1b2-0b824b3049dd">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670570185516105 139.74338461839537 25.85 35.67056823042564 139.7433978761315 25.85 35.67055766458474 139.74339553512482 25.85 35.67055961967495 139.74338227739034 25.85 35.670570185516105 139.74338461839537 25.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-903e0b3b-dffb-4e8c-96b0-ec2e7c868c64">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670564708077855 139.7434247225555 25.85 35.67056410438109 139.74342502148218 25.85 35.67056349161288 139.74342524309503 25.85 35.67056285175401 139.74342539846052 25.85 35.670562211845635 139.74342548754836 25.85 35.67056157188779 139.74342551035858 25.85 35.67056092285849 139.74342545585495 25.85 35.67056028279341 139.74342533506356 25.85 35.67055965169258 139.74342514798442 25.85 35.670559047591674 139.7434249056436 25.85 35.670558452446755 139.7434245859687 25.85 35.670557884301765 139.7434242110322 25.85 35.67055734314845 139.74342376978765 25.85 35.67055683800879 139.7434232732713 25.85 35.67055636889103 139.74342273252947 25.85 35.67055594480064 139.74342213650573 25.85 35.67055556574587 139.74342149624633 25.85 35.670555222721255 139.74342082280768 25.85 35.670554933754225 139.74342011616957 25.85 35.67055469884478 139.743419376332 25.85 35.67055451800117 139.74341861434124 25.85 35.670554391231654 139.7434178412435 25.85 35.67055431853622 139.7434170570389 25.85 35.67055429991487 139.74341626172736 25.85 35.67055434439782 139.74341547739132 25.85 35.67055443394939 139.74341469300475 25.85 35.67055458660526 139.7434139195937 25.85 35.67055479335997 139.7434131682145 25.85 35.67055505422175 139.7434124499135 25.85 35.670555360168656 139.74341175365447 25.85 35.67055572022263 139.74341109047364 25.85 35.67055612537822 139.74341047142732 25.85 35.67055656662169 139.74340989652566 25.85 35.67055705297503 139.74340937680483 25.85 35.67055756640253 139.74340890123878 25.85 35.67055812494814 139.74340849189983 25.85 35.67055870156245 139.743408137772 25.85 35.67055930526741 139.7434078498915 25.85 35.67055991803559 139.74340762827856 25.85 35.670560557894454 139.7434074729129 25.85 35.67056119779455 139.74340737277865 25.85 35.67056184677436 139.74340736100444 25.85 35.67056248678171 139.74340740447178 25.85 35.6705631268468 139.743407525263 25.85 35.670563757947654 139.74340771234202 25.85 35.670564362056844 139.743407965729 25.85 35.67056495719356 139.7434082743575 25.85 35.670565525346845 139.74340866034024 25.85 35.670566066491965 139.74340909053845 25.85 35.67056657163168 139.74340958705474 25.85 35.670567040757746 139.74341013884285 25.85 35.67056746483994 139.74341072382038 25.85 35.670567852908505 139.7434113640697 25.85 35.670568186919446 139.7434120375185 25.85 35.670568475894775 139.74341275520297 25.85 35.670568710796005 139.7434134839944 25.85 35.67056889163965 139.74341424598526 25.85 35.670569018409196 139.7434150190831 25.85 35.67056909111289 139.74341581433413 25.85 35.670569109725996 139.74341659859957 25.85 35.67056906525128 139.743417393982 25.85 35.67056897569144 139.74341816732246 25.85 35.67056882303554 139.74341894073368 25.85 35.67056861628081 139.74341969211295 25.85 35.67056835542722 139.74342042146034 25.85 35.67056804948028 139.74342111771944 25.85 35.67056768941799 139.74342176985405 25.85 35.67056728426235 139.7434223889004 25.85 35.67056684301882 139.74342296380203 25.85 35.67056635667367 139.74342349456913 25.85 35.67056583422415 139.743423959099 25.85 35.67056528470045 139.74342437947405 25.85 35.670564708077855 139.7434247225555 25.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-aebb72d1-3ac4-4c77-81d6-9a95379eff66">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67060670048113 139.74345750504284 25.85 35.67059175257032 139.74345329107035 25.85 35.67059361101456 139.7434433804656 25.85 35.670608558925714 139.7434475944364 25.85 35.67060670048113 139.74345750504284 25.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-13470ca6-c4ac-49a3-9c10-b8e36a65fb09">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-13470ca6-c4ac-49a3-9c10-b8e36a65fb09_0">
											<gml:posList>35.67058339626137 139.74334389800424 25.85 35.67058339626137 139.74334389800424 29.624 35.67060240928256 139.7433479969306 29.624 35.67060240928256 139.7433479969306 27.3 35.67059965965125 139.74334740351696 27.3 35.67059965965125 139.74334740351696 25.85 35.67058339626137 139.74334389800424 25.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-743bfcfd-71e0-4592-9906-13bdbfb2a9de">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-743bfcfd-71e0-4592-9906-13bdbfb2a9de_0">
											<gml:posList>35.67059965965125 139.74334740351696 27.3 35.670602382373474 139.74334817370146 27.3 35.670602382373474 139.74334817370146 25.85 35.67059965965125 139.74334740351696 25.85 35.67059965965125 139.74334740351696 27.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cc6677df-bf36-44b5-8af6-6d0fe503c736">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cc6677df-bf36-44b5-8af6-6d0fe503c736_0">
											<gml:posList>35.67058339626137 139.74334389800424 25.85 35.67058173738187 139.74335548742172 25.85 35.67058173738187 139.74335548742172 29.624 35.67058339626137 139.74334389800424 29.624 35.67058339626137 139.74334389800424 25.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-542468aa-3f52-4a81-8344-367aa642a3d9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-542468aa-3f52-4a81-8344-367aa642a3d9_0">
											<gml:posList>35.67060074138897 139.74335958636087 29.624 35.67060240928256 139.7433479969306 29.624 35.67058339626137 139.74334389800424 29.624 35.67058173738187 139.74335548742172 29.624 35.67060074138897 139.74335958636087 29.624</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5dd2ed54-f521-4b66-93b1-0188dc19781b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5dd2ed54-f521-4b66-93b1-0188dc19781b_0">
											<gml:posList>35.670602382373474 139.74334817370146 27.3 35.67060240928256 139.7433479969306 27.3 35.67060240928256 139.7433479969306 29.624 35.67060074138897 139.74335958636087 29.624 35.67060074138897 139.74335958636087 25.85 35.670602382373474 139.74334817370146 25.85 35.670602382373474 139.74334817370146 27.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-dda133e1-8de3-471f-8928-a1499d0a22c3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-dda133e1-8de3-471f-8928-a1499d0a22c3_0">
											<gml:posList>35.67058173738187 139.74335548742172 25.85 35.67060074138897 139.74335958636087 25.85 35.67060074138897 139.74335958636087 29.624 35.67058173738187 139.74335548742172 29.624 35.67058173738187 139.74335548742172 25.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-74a1d042-e3d5-4652-a3d5-1324b1200c3e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-74a1d042-e3d5-4652-a3d5-1324b1200c3e_0">
											<gml:posList>35.670552267550356 139.74336226977314 25.85 35.670552267550356 139.74336226977314 28.295 35.67057107351951 139.74336672241574 28.295 35.67057107351951 139.74336672241574 25.85 35.670552267550356 139.74336226977314 25.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-52c71662-8fe1-4844-ab6b-88d870db371e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-52c71662-8fe1-4844-ab6b-88d870db371e_0">
											<gml:posList>35.670552267550356 139.74336226977314 25.85 35.67055057196223 139.74337298657056 25.85 35.67055057196223 139.74337298657056 28.295 35.670552267550356 139.74336226977314 28.295 35.670552267550356 139.74336226977314 25.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5c717ffe-af26-4d33-8900-e37002c5e33f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5c717ffe-af26-4d33-8900-e37002c5e33f_0">
											<gml:posList>35.67056938694471 139.7433774392055 28.295 35.67057107351951 139.74336672241574 28.295 35.670552267550356 139.74336226977314 28.295 35.67055057196223 139.74337298657056 28.295 35.67056938694471 139.7433774392055 28.295</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e24407e7-58ec-43e3-aeaa-4d34c828a6c1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e24407e7-58ec-43e3-aeaa-4d34c828a6c1_0">
											<gml:posList>35.67056938694471 139.7433774392055 25.85 35.67057107351951 139.74336672241574 25.85 35.67057107351951 139.74336672241574 28.295 35.67056938694471 139.7433774392055 28.295 35.67056938694471 139.7433774392055 25.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-006d028a-e575-4b40-9fed-4c008be53e3e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-006d028a-e575-4b40-9fed-4c008be53e3e_0">
											<gml:posList>35.67055057196223 139.74337298657056 25.85 35.67056938694471 139.7433774392055 25.85 35.67056938694471 139.7433774392055 28.295 35.67055057196223 139.74337298657056 28.295 35.67055057196223 139.74337298657056 25.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f56f6aa5-ea9e-4e7b-a61a-5a28eadff46a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f56f6aa5-ea9e-4e7b-a61a-5a28eadff46a_0">
											<gml:posList>35.670570185516105 139.74338461839537 25.85 35.67055961967495 139.74338227739034 25.85 35.67055961967495 139.74338227739034 28.328 35.670570185516105 139.74338461839537 28.328 35.670570185516105 139.74338461839537 25.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6b93ae9f-6dec-4a8d-b465-40c35b4b54c7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6b93ae9f-6dec-4a8d-b465-40c35b4b54c7_0">
											<gml:posList>35.67055961967495 139.74338227739034 25.85 35.67055766458474 139.74339553512482 25.85 35.67055766458474 139.74339553512482 28.328 35.67055961967495 139.74338227739034 28.328 35.67055961967495 139.74338227739034 25.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ac457298-3595-4ed1-b182-87a7261a1b76">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ac457298-3595-4ed1-b182-87a7261a1b76_0">
											<gml:posList>35.67055766458474 139.74339553512482 28.328 35.67056823042564 139.7433978761315 28.328 35.670570185516105 139.74338461839537 28.328 35.67055961967495 139.74338227739034 28.328 35.67055766458474 139.74339553512482 28.328</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-898e350f-dcd5-4fa4-b9a6-59f75f81bfd4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-898e350f-dcd5-4fa4-b9a6-59f75f81bfd4_0">
											<gml:posList>35.67056823042564 139.7433978761315 25.85 35.670570185516105 139.74338461839537 25.85 35.670570185516105 139.74338461839537 28.328 35.67056823042564 139.7433978761315 28.328 35.67056823042564 139.7433978761315 25.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-60715d87-e189-4a0b-b5d1-e5671f6cf3d7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-60715d87-e189-4a0b-b5d1-e5671f6cf3d7_0">
											<gml:posList>35.67055766458474 139.74339553512482 25.85 35.67056823042564 139.7433978761315 25.85 35.67056823042564 139.7433978761315 28.328 35.67055766458474 139.74339553512482 28.328 35.67055766458474 139.74339553512482 25.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b53a7b4f-6c95-4299-96a7-4ea54264201d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b53a7b4f-6c95-4299-96a7-4ea54264201d_0">
											<gml:posList>35.67056184677436 139.74340736100444 25.85 35.67056119779455 139.74340737277865 25.85 35.67056119779455 139.74340737277865 28.816 35.67056184677436 139.74340736100444 28.816 35.67056184677436 139.74340736100444 25.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0405fcea-9412-4800-9a29-99194b4f19d5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0405fcea-9412-4800-9a29-99194b4f19d5_0">
											<gml:posList>35.67056248678171 139.74340740447178 25.85 35.67056184677436 139.74340736100444 25.85 35.67056184677436 139.74340736100444 28.816 35.67056248678171 139.74340740447178 28.816 35.67056248678171 139.74340740447178 25.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-24e5a893-e029-4bb2-b368-74cc1a68aa1f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-24e5a893-e029-4bb2-b368-74cc1a68aa1f_0">
											<gml:posList>35.67056119779455 139.74340737277865 25.85 35.670560557894454 139.7434074729129 25.85 35.670560557894454 139.7434074729129 28.816 35.67056119779455 139.74340737277865 28.816 35.67056119779455 139.74340737277865 25.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-44613306-a77f-421c-b34f-159f7be25c3c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-44613306-a77f-421c-b34f-159f7be25c3c_0">
											<gml:posList>35.6705631268468 139.743407525263 25.85 35.67056248678171 139.74340740447178 25.85 35.67056248678171 139.74340740447178 28.816 35.6705631268468 139.743407525263 28.816 35.6705631268468 139.743407525263 25.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5035fe95-e113-4e80-9e86-a95bd9a94c99">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5035fe95-e113-4e80-9e86-a95bd9a94c99_0">
											<gml:posList>35.67055991803559 139.74340762827856 25.85 35.67055991803559 139.74340762827856 28.816 35.670560557894454 139.7434074729129 28.816 35.670560557894454 139.7434074729129 25.85 35.67055991803559 139.74340762827856 25.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f8f14383-0a9c-4288-9c6a-8e6b99a5edce">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f8f14383-0a9c-4288-9c6a-8e6b99a5edce_0">
											<gml:posList>35.6705631268468 139.743407525263 25.85 35.6705631268468 139.743407525263 28.816 35.670563757947654 139.74340771234202 28.816 35.670563757947654 139.74340771234202 25.85 35.6705631268468 139.743407525263 25.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cee3f200-73bf-4fff-a98f-5e5d53602c61">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cee3f200-73bf-4fff-a98f-5e5d53602c61_0">
											<gml:posList>35.67055930526741 139.7434078498915 25.85 35.67055930526741 139.7434078498915 28.816 35.67055991803559 139.74340762827856 28.816 35.67055991803559 139.74340762827856 25.85 35.67055930526741 139.7434078498915 25.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ce75bb20-a4d0-4264-9d11-a9a3836d1b0d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ce75bb20-a4d0-4264-9d11-a9a3836d1b0d_0">
											<gml:posList>35.670563757947654 139.74340771234202 25.85 35.670563757947654 139.74340771234202 28.816 35.670564362056844 139.743407965729 28.816 35.670564362056844 139.743407965729 25.85 35.670563757947654 139.74340771234202 25.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-948e8c94-127f-4db1-92ef-45b7b34e3603">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-948e8c94-127f-4db1-92ef-45b7b34e3603_0">
											<gml:posList>35.67055870156245 139.743408137772 25.85 35.67055870156245 139.743408137772 28.816 35.67055930526741 139.7434078498915 28.816 35.67055930526741 139.7434078498915 25.85 35.67055870156245 139.743408137772 25.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-22478524-ffc6-4d70-9216-edd454ebf158">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-22478524-ffc6-4d70-9216-edd454ebf158_0">
											<gml:posList>35.67056495719356 139.7434082743575 25.85 35.670564362056844 139.743407965729 25.85 35.670564362056844 139.743407965729 28.816 35.67056495719356 139.7434082743575 28.816 35.67056495719356 139.7434082743575 25.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ff630180-8268-4602-9086-19960fd0be4f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ff630180-8268-4602-9086-19960fd0be4f_0">
											<gml:posList>35.67055870156245 139.743408137772 25.85 35.67055812494814 139.74340849189983 25.85 35.67055812494814 139.74340849189983 28.816 35.67055870156245 139.743408137772 28.816 35.67055870156245 139.743408137772 25.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e7a9ebdd-3073-4659-bc97-98840b16ae32">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e7a9ebdd-3073-4659-bc97-98840b16ae32_0">
											<gml:posList>35.670565525346845 139.74340866034024 25.85 35.67056495719356 139.7434082743575 25.85 35.67056495719356 139.7434082743575 28.816 35.670565525346845 139.74340866034024 28.816 35.670565525346845 139.74340866034024 25.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-983c3210-b267-43fb-8e40-8a0e1d99c0f6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-983c3210-b267-43fb-8e40-8a0e1d99c0f6_0">
											<gml:posList>35.67055812494814 139.74340849189983 25.85 35.67055756640253 139.74340890123878 25.85 35.67055756640253 139.74340890123878 28.816 35.67055812494814 139.74340849189983 28.816 35.67055812494814 139.74340849189983 25.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5e12cc89-0223-47d0-b825-ddf9ea8d7011">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5e12cc89-0223-47d0-b825-ddf9ea8d7011_0">
											<gml:posList>35.670566066491965 139.74340909053845 25.85 35.670565525346845 139.74340866034024 25.85 35.670565525346845 139.74340866034024 28.816 35.670566066491965 139.74340909053845 28.816 35.670566066491965 139.74340909053845 25.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b847caec-8317-4d32-98f2-18ae6cd7a08d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b847caec-8317-4d32-98f2-18ae6cd7a08d_0">
											<gml:posList>35.67055756640253 139.74340890123878 25.85 35.67055705297503 139.74340937680483 25.85 35.67055705297503 139.74340937680483 28.816 35.67055756640253 139.74340890123878 28.816 35.67055756640253 139.74340890123878 25.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a1e7ae24-caa5-43f6-bb1a-c50c4e808362">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a1e7ae24-caa5-43f6-bb1a-c50c4e808362_0">
											<gml:posList>35.67056657163168 139.74340958705474 25.85 35.670566066491965 139.74340909053845 25.85 35.670566066491965 139.74340909053845 28.816 35.67056657163168 139.74340958705474 28.816 35.67056657163168 139.74340958705474 25.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-57f733e8-86d6-4080-8830-5c6ae443a09f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-57f733e8-86d6-4080-8830-5c6ae443a09f_0">
											<gml:posList>35.67055705297503 139.74340937680483 25.85 35.67055656662169 139.74340989652566 25.85 35.67055656662169 139.74340989652566 28.816 35.67055705297503 139.74340937680483 28.816 35.67055705297503 139.74340937680483 25.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a648536e-3baf-4a24-9b06-350ce2b8a267">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a648536e-3baf-4a24-9b06-350ce2b8a267_0">
											<gml:posList>35.670567040757746 139.74341013884285 25.85 35.67056657163168 139.74340958705474 25.85 35.67056657163168 139.74340958705474 28.816 35.670567040757746 139.74341013884285 28.816 35.670567040757746 139.74341013884285 25.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-01bf426e-bd43-40b5-bc26-3c62cedd6e31">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-01bf426e-bd43-40b5-bc26-3c62cedd6e31_0">
											<gml:posList>35.67055656662169 139.74340989652566 25.85 35.67055612537822 139.74341047142732 25.85 35.67055612537822 139.74341047142732 28.816 35.67055656662169 139.74340989652566 28.816 35.67055656662169 139.74340989652566 25.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b4477e3d-f025-4b09-a6c4-bb69e4c433c5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b4477e3d-f025-4b09-a6c4-bb69e4c433c5_0">
											<gml:posList>35.67056746483994 139.74341072382038 25.85 35.670567040757746 139.74341013884285 25.85 35.670567040757746 139.74341013884285 28.816 35.67056746483994 139.74341072382038 28.816 35.67056746483994 139.74341072382038 25.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2f8836f2-9a09-40a5-9b24-5990993427c9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2f8836f2-9a09-40a5-9b24-5990993427c9_0">
											<gml:posList>35.67055572022263 139.74341109047364 25.85 35.67055572022263 139.74341109047364 28.816 35.67055612537822 139.74341047142732 28.816 35.67055612537822 139.74341047142732 25.85 35.67055572022263 139.74341109047364 25.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0bebd4ce-b92c-4f5c-ab23-3981c3b31673">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0bebd4ce-b92c-4f5c-ab23-3981c3b31673_0">
											<gml:posList>35.670567852908505 139.7434113640697 25.85 35.67056746483994 139.74341072382038 25.85 35.67056746483994 139.74341072382038 28.816 35.670567852908505 139.7434113640697 28.816 35.670567852908505 139.7434113640697 25.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1fab1710-9530-42e8-9b21-60af42821b60">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1fab1710-9530-42e8-9b21-60af42821b60_0">
											<gml:posList>35.67055572022263 139.74341109047364 25.85 35.670555360168656 139.74341175365447 25.85 35.670555360168656 139.74341175365447 28.816 35.67055572022263 139.74341109047364 28.816 35.67055572022263 139.74341109047364 25.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-dd51be4a-1882-4fbe-bef4-6142694e5de9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-dd51be4a-1882-4fbe-bef4-6142694e5de9_0">
											<gml:posList>35.670568186919446 139.7434120375185 25.85 35.670567852908505 139.7434113640697 25.85 35.670567852908505 139.7434113640697 28.816 35.670568186919446 139.7434120375185 28.816 35.670568186919446 139.7434120375185 25.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9619dc17-090b-4d7a-97f8-6433a9ad286e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9619dc17-090b-4d7a-97f8-6433a9ad286e_0">
											<gml:posList>35.670555360168656 139.74341175365447 25.85 35.67055505422175 139.7434124499135 25.85 35.67055505422175 139.7434124499135 28.816 35.670555360168656 139.74341175365447 28.816 35.670555360168656 139.74341175365447 25.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7c552f7e-1b77-4e4c-8bb5-3d945f1d8d18">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7c552f7e-1b77-4e4c-8bb5-3d945f1d8d18_0">
											<gml:posList>35.670568475894775 139.74341275520297 25.85 35.670568186919446 139.7434120375185 25.85 35.670568186919446 139.7434120375185 28.816 35.670568475894775 139.74341275520297 28.816 35.670568475894775 139.74341275520297 25.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-341c8a13-f560-44b4-805c-07ff96ed5948">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-341c8a13-f560-44b4-805c-07ff96ed5948_0">
											<gml:posList>35.67055505422175 139.7434124499135 25.85 35.67055479335997 139.7434131682145 25.85 35.67055479335997 139.7434131682145 28.816 35.67055505422175 139.7434124499135 28.816 35.67055505422175 139.7434124499135 25.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-81a8c3a6-2da5-46a1-82cc-5750a8d79316">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-81a8c3a6-2da5-46a1-82cc-5750a8d79316_0">
											<gml:posList>35.670568710796005 139.7434134839944 25.85 35.670568475894775 139.74341275520297 25.85 35.670568475894775 139.74341275520297 28.816 35.670568710796005 139.7434134839944 28.816 35.670568710796005 139.7434134839944 25.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a9b90f94-3f2c-4e2b-8425-81b675750cc6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a9b90f94-3f2c-4e2b-8425-81b675750cc6_0">
											<gml:posList>35.67055458660526 139.7434139195937 25.85 35.67055458660526 139.7434139195937 28.816 35.67055479335997 139.7434131682145 28.816 35.67055479335997 139.7434131682145 25.85 35.67055458660526 139.7434139195937 25.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b99531a5-f7c1-46b8-9bdc-caabc8aaf74c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b99531a5-f7c1-46b8-9bdc-caabc8aaf74c_0">
											<gml:posList>35.67056889163965 139.74341424598526 25.85 35.670568710796005 139.7434134839944 25.85 35.670568710796005 139.7434134839944 28.816 35.67056889163965 139.74341424598526 28.816 35.67056889163965 139.74341424598526 25.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e79f6301-5b5d-43a6-be7b-9a53fe78c8f3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e79f6301-5b5d-43a6-be7b-9a53fe78c8f3_0">
											<gml:posList>35.67055443394939 139.74341469300475 25.85 35.67055443394939 139.74341469300475 28.816 35.67055458660526 139.7434139195937 28.816 35.67055458660526 139.7434139195937 25.85 35.67055443394939 139.74341469300475 25.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c366a84d-16c0-44d5-ae57-71745b6de74d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c366a84d-16c0-44d5-ae57-71745b6de74d_0">
											<gml:posList>35.670569018409196 139.7434150190831 25.85 35.67056889163965 139.74341424598526 25.85 35.67056889163965 139.74341424598526 28.816 35.670569018409196 139.7434150190831 28.816 35.670569018409196 139.7434150190831 25.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-46e41df2-1e62-4cb9-b6fd-ffbf0ad014bf">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-46e41df2-1e62-4cb9-b6fd-ffbf0ad014bf_0">
											<gml:posList>35.67055443394939 139.74341469300475 25.85 35.67055434439782 139.74341547739132 25.85 35.67055434439782 139.74341547739132 28.816 35.67055443394939 139.74341469300475 28.816 35.67055443394939 139.74341469300475 25.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c30926b3-1ff1-4f45-9e48-37935b28c9cd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c30926b3-1ff1-4f45-9e48-37935b28c9cd_0">
											<gml:posList>35.67056909111289 139.74341581433413 25.85 35.670569018409196 139.7434150190831 25.85 35.670569018409196 139.7434150190831 28.816 35.67056909111289 139.74341581433413 28.816 35.67056909111289 139.74341581433413 25.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a001afbd-a362-4ecf-943b-2d4f5c9c9dd1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a001afbd-a362-4ecf-943b-2d4f5c9c9dd1_0">
											<gml:posList>35.67055434439782 139.74341547739132 25.85 35.67055429991487 139.74341626172736 25.85 35.67055429991487 139.74341626172736 28.816 35.67055434439782 139.74341547739132 28.816 35.67055434439782 139.74341547739132 25.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-24a948e8-ebe2-44e3-826f-9a409cc49e47">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-24a948e8-ebe2-44e3-826f-9a409cc49e47_0">
											<gml:posList>35.67056909111289 139.74341581433413 25.85 35.67056909111289 139.74341581433413 28.816 35.670569109725996 139.74341659859957 28.816 35.670569109725996 139.74341659859957 25.85 35.67056909111289 139.74341581433413 25.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6d9b7cbb-876a-44ba-8c90-a3efccb210f4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6d9b7cbb-876a-44ba-8c90-a3efccb210f4_0">
											<gml:posList>35.67056583422415 139.743423959099 28.816 35.67056635667367 139.74342349456913 28.816 35.67056684301882 139.74342296380203 28.816 35.67056728426235 139.7434223889004 28.816 35.67056768941799 139.74342176985405 28.816 35.67056804948028 139.74342111771944 28.816 35.67056835542722 139.74342042146034 28.816 35.67056861628081 139.74341969211295 28.816 35.67056882303554 139.74341894073368 28.816 35.67056897569144 139.74341816732246 28.816 35.67056906525128 139.743417393982 28.816 35.670569109725996 139.74341659859957 28.816 35.67056909111289 139.74341581433413 28.816 35.670569018409196 139.7434150190831 28.816 35.67056889163965 139.74341424598526 28.816 35.670568710796005 139.7434134839944 28.816 35.670568475894775 139.74341275520297 28.816 35.670568186919446 139.7434120375185 28.816 35.670567852908505 139.7434113640697 28.816 35.67056746483994 139.74341072382038 28.816 35.670567040757746 139.74341013884285 28.816 35.67056657163168 139.74340958705474 28.816 35.670566066491965 139.74340909053845 28.816 35.670565525346845 139.74340866034024 28.816 35.67056495719356 139.7434082743575 28.816 35.670564362056844 139.743407965729 28.816 35.670563757947654 139.74340771234202 28.816 35.6705631268468 139.743407525263 28.816 35.67056248678171 139.74340740447178 28.816 35.67056184677436 139.74340736100444 28.816 35.67056119779455 139.74340737277865 28.816 35.670560557894454 139.7434074729129 28.816 35.67055991803559 139.74340762827856 28.816 35.67055930526741 139.7434078498915 28.816 35.67055870156245 139.743408137772 28.816 35.67055812494814 139.74340849189983 28.816 35.67055756640253 139.74340890123878 28.816 35.67055705297503 139.74340937680483 28.816 35.67055656662169 139.74340989652566 28.816 35.67055612537822 139.74341047142732 28.816 35.67055572022263 139.74341109047364 28.816 35.670555360168656 139.74341175365447 28.816 35.67055505422175 139.7434124499135 28.816 35.67055479335997 139.7434131682145 28.816 35.67055458660526 139.7434139195937 28.816 35.67055443394939 139.74341469300475 28.816 35.67055434439782 139.74341547739132 28.816 35.67055429991487 139.74341626172736 28.816 35.67055431853622 139.7434170570389 28.816 35.670554391231654 139.7434178412435 28.816 35.67055451800117 139.74341861434124 28.816 35.67055469884478 139.743419376332 28.816 35.670554933754225 139.74342011616957 28.816 35.670555222721255 139.74342082280768 28.816 35.67055556574587 139.74342149624633 28.816 35.67055594480064 139.74342213650573 28.816 35.67055636889103 139.74342273252947 28.816 35.67055683800879 139.7434232732713 28.816 35.67055734314845 139.74342376978765 28.816 35.670557884301765 139.7434242110322 28.816 35.670558452446755 139.7434245859687 28.816 35.670559047591674 139.7434249056436 28.816 35.67055965169258 139.74342514798442 28.816 35.67056028279341 139.74342533506356 28.816 35.67056092285849 139.74342545585495 28.816 35.67056157188779 139.74342551035858 28.816 35.670562211845635 139.74342548754836 28.816 35.67056285175401 139.74342539846052 28.816 35.67056349161288 139.74342524309503 28.816 35.67056410438109 139.74342502148218 28.816 35.670564708077855 139.7434247225555 28.816 35.67056528470045 139.74342437947405 28.816 35.67056583422415 139.743423959099 28.816</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5eb33ea7-260b-42bd-8f15-1586f2ec6a65">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5eb33ea7-260b-42bd-8f15-1586f2ec6a65_0">
											<gml:posList>35.67055431853622 139.7434170570389 25.85 35.67055431853622 139.7434170570389 28.816 35.67055429991487 139.74341626172736 28.816 35.67055429991487 139.74341626172736 25.85 35.67055431853622 139.7434170570389 25.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7f8b9ed1-f3bb-4114-8a03-4f7fb300853a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7f8b9ed1-f3bb-4114-8a03-4f7fb300853a_0">
											<gml:posList>35.67056906525128 139.743417393982 25.85 35.670569109725996 139.74341659859957 25.85 35.670569109725996 139.74341659859957 28.816 35.67056906525128 139.743417393982 28.816 35.67056906525128 139.743417393982 25.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-565a29a1-4452-4fa4-8cb0-4213b1cfa94d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-565a29a1-4452-4fa4-8cb0-4213b1cfa94d_0">
											<gml:posList>35.67055431853622 139.7434170570389 25.85 35.670554391231654 139.7434178412435 25.85 35.670554391231654 139.7434178412435 28.816 35.67055431853622 139.7434170570389 28.816 35.67055431853622 139.7434170570389 25.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c33ffa29-722b-45cd-b37f-ed80d542803d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c33ffa29-722b-45cd-b37f-ed80d542803d_0">
											<gml:posList>35.67056897569144 139.74341816732246 25.85 35.67056906525128 139.743417393982 25.85 35.67056906525128 139.743417393982 28.816 35.67056897569144 139.74341816732246 28.816 35.67056897569144 139.74341816732246 25.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b1f6b218-6ede-43ec-a56a-5b74a29ccf98">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b1f6b218-6ede-43ec-a56a-5b74a29ccf98_0">
											<gml:posList>35.67055451800117 139.74341861434124 25.85 35.67055451800117 139.74341861434124 28.816 35.670554391231654 139.7434178412435 28.816 35.670554391231654 139.7434178412435 25.85 35.67055451800117 139.74341861434124 25.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a80588ef-7f0a-4a91-8d01-875c06b7c82c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a80588ef-7f0a-4a91-8d01-875c06b7c82c_0">
											<gml:posList>35.67056882303554 139.74341894073368 25.85 35.67056897569144 139.74341816732246 25.85 35.67056897569144 139.74341816732246 28.816 35.67056882303554 139.74341894073368 28.816 35.67056882303554 139.74341894073368 25.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-74659ee8-8149-463f-88fd-76f50e9b8652">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-74659ee8-8149-463f-88fd-76f50e9b8652_0">
											<gml:posList>35.67055451800117 139.74341861434124 25.85 35.67055469884478 139.743419376332 25.85 35.67055469884478 139.743419376332 28.816 35.67055451800117 139.74341861434124 28.816 35.67055451800117 139.74341861434124 25.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e5bcb55f-1b40-46e9-94cc-4ff3ab18245c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e5bcb55f-1b40-46e9-94cc-4ff3ab18245c_0">
											<gml:posList>35.67056882303554 139.74341894073368 25.85 35.67056882303554 139.74341894073368 28.816 35.67056861628081 139.74341969211295 28.816 35.67056861628081 139.74341969211295 25.85 35.67056882303554 139.74341894073368 25.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4bb78f01-8dba-4604-ba1f-4d6247619332">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4bb78f01-8dba-4604-ba1f-4d6247619332_0">
											<gml:posList>35.670554933754225 139.74342011616957 25.85 35.670554933754225 139.74342011616957 28.816 35.67055469884478 139.743419376332 28.816 35.67055469884478 139.743419376332 25.85 35.670554933754225 139.74342011616957 25.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9331aa32-42b7-4f39-8539-9211c84210eb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9331aa32-42b7-4f39-8539-9211c84210eb_0">
											<gml:posList>35.67056835542722 139.74342042146034 25.85 35.67056861628081 139.74341969211295 25.85 35.67056861628081 139.74341969211295 28.816 35.67056835542722 139.74342042146034 28.816 35.67056835542722 139.74342042146034 25.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-59b32531-778a-40ae-957f-47b3827852d3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-59b32531-778a-40ae-957f-47b3827852d3_0">
											<gml:posList>35.670554933754225 139.74342011616957 25.85 35.670555222721255 139.74342082280768 25.85 35.670555222721255 139.74342082280768 28.816 35.670554933754225 139.74342011616957 28.816 35.670554933754225 139.74342011616957 25.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-778d35fd-654f-4465-8892-780da0f88afa">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-778d35fd-654f-4465-8892-780da0f88afa_0">
											<gml:posList>35.67056804948028 139.74342111771944 25.85 35.67056835542722 139.74342042146034 25.85 35.67056835542722 139.74342042146034 28.816 35.67056804948028 139.74342111771944 28.816 35.67056804948028 139.74342111771944 25.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c436a899-22a8-421c-a45d-5a4363865b3d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c436a899-22a8-421c-a45d-5a4363865b3d_0">
											<gml:posList>35.670555222721255 139.74342082280768 25.85 35.67055556574587 139.74342149624633 25.85 35.67055556574587 139.74342149624633 28.816 35.670555222721255 139.74342082280768 28.816 35.670555222721255 139.74342082280768 25.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-12fa50fa-aea3-4ae0-baac-471be1c06a13">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-12fa50fa-aea3-4ae0-baac-471be1c06a13_0">
											<gml:posList>35.67056768941799 139.74342176985405 25.85 35.67056804948028 139.74342111771944 25.85 35.67056804948028 139.74342111771944 28.816 35.67056768941799 139.74342176985405 28.816 35.67056768941799 139.74342176985405 25.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9adfc4b8-c35e-4c9f-9598-fefbeebf8520">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9adfc4b8-c35e-4c9f-9598-fefbeebf8520_0">
											<gml:posList>35.67055556574587 139.74342149624633 25.85 35.67055594480064 139.74342213650573 25.85 35.67055594480064 139.74342213650573 28.816 35.67055556574587 139.74342149624633 28.816 35.67055556574587 139.74342149624633 25.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-09d0abc0-9a6d-4399-9259-5e5f0aaa7fcb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-09d0abc0-9a6d-4399-9259-5e5f0aaa7fcb_0">
											<gml:posList>35.67056728426235 139.7434223889004 25.85 35.67056768941799 139.74342176985405 25.85 35.67056768941799 139.74342176985405 28.816 35.67056728426235 139.7434223889004 28.816 35.67056728426235 139.7434223889004 25.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-145129c7-052d-44f6-8bcc-960ca41cc96a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-145129c7-052d-44f6-8bcc-960ca41cc96a_0">
											<gml:posList>35.67055594480064 139.74342213650573 25.85 35.67055636889103 139.74342273252947 25.85 35.67055636889103 139.74342273252947 28.816 35.67055594480064 139.74342213650573 28.816 35.67055594480064 139.74342213650573 25.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b31af8ab-dccd-4a03-97fe-160b8cf7ad66">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b31af8ab-dccd-4a03-97fe-160b8cf7ad66_0">
											<gml:posList>35.67056684301882 139.74342296380203 25.85 35.67056728426235 139.7434223889004 25.85 35.67056728426235 139.7434223889004 28.816 35.67056684301882 139.74342296380203 28.816 35.67056684301882 139.74342296380203 25.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-dc1b8a7d-3de8-4cc4-901f-656b90d7f928">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-dc1b8a7d-3de8-4cc4-901f-656b90d7f928_0">
											<gml:posList>35.67055636889103 139.74342273252947 25.85 35.67055683800879 139.7434232732713 25.85 35.67055683800879 139.7434232732713 28.816 35.67055636889103 139.74342273252947 28.816 35.67055636889103 139.74342273252947 25.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-00e4f1c4-f64d-4665-aee7-6e9add7c4f65">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-00e4f1c4-f64d-4665-aee7-6e9add7c4f65_0">
											<gml:posList>35.67056635667367 139.74342349456913 25.85 35.67056684301882 139.74342296380203 25.85 35.67056684301882 139.74342296380203 28.816 35.67056635667367 139.74342349456913 28.816 35.67056635667367 139.74342349456913 25.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-495a5c99-0153-40e4-8927-82f4de109d13">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-495a5c99-0153-40e4-8927-82f4de109d13_0">
											<gml:posList>35.67055734314845 139.74342376978765 25.85 35.67055734314845 139.74342376978765 28.816 35.67055683800879 139.7434232732713 28.816 35.67055683800879 139.7434232732713 25.85 35.67055734314845 139.74342376978765 25.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7de462dc-dd68-4cb3-9ad5-e5c6da065e4f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7de462dc-dd68-4cb3-9ad5-e5c6da065e4f_0">
											<gml:posList>35.67056583422415 139.743423959099 25.85 35.67056635667367 139.74342349456913 25.85 35.67056635667367 139.74342349456913 28.816 35.67056583422415 139.743423959099 28.816 35.67056583422415 139.743423959099 25.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e62bc032-e06b-45b6-bad5-60995390fcf4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e62bc032-e06b-45b6-bad5-60995390fcf4_0">
											<gml:posList>35.67055734314845 139.74342376978765 25.85 35.670557884301765 139.7434242110322 25.85 35.670557884301765 139.7434242110322 28.816 35.67055734314845 139.74342376978765 28.816 35.67055734314845 139.74342376978765 25.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1aa94d0e-cca7-484f-8b04-60fc0ac0bebf">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1aa94d0e-cca7-484f-8b04-60fc0ac0bebf_0">
											<gml:posList>35.67056583422415 139.743423959099 25.85 35.67056583422415 139.743423959099 28.816 35.67056528470045 139.74342437947405 28.816 35.67056528470045 139.74342437947405 25.85 35.67056583422415 139.743423959099 25.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bec5a46e-d778-421b-b369-262dcf0bc673">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bec5a46e-d778-421b-b369-262dcf0bc673_0">
											<gml:posList>35.670557884301765 139.7434242110322 25.85 35.670558452446755 139.7434245859687 25.85 35.670558452446755 139.7434245859687 28.816 35.670557884301765 139.7434242110322 28.816 35.670557884301765 139.7434242110322 25.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3dff0b79-19c7-40b6-8cff-a8b0b4a83692">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3dff0b79-19c7-40b6-8cff-a8b0b4a83692_0">
											<gml:posList>35.670564708077855 139.7434247225555 25.85 35.67056528470045 139.74342437947405 25.85 35.67056528470045 139.74342437947405 28.816 35.670564708077855 139.7434247225555 28.816 35.670564708077855 139.7434247225555 25.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a27f35c9-9a63-4fda-baa0-07ea0b19ce81">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a27f35c9-9a63-4fda-baa0-07ea0b19ce81_0">
											<gml:posList>35.670558452446755 139.7434245859687 25.85 35.670559047591674 139.7434249056436 25.85 35.670559047591674 139.7434249056436 28.816 35.670558452446755 139.7434245859687 28.816 35.670558452446755 139.7434245859687 25.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-de006f02-05b8-4c4d-a73d-71128e08c7c0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-de006f02-05b8-4c4d-a73d-71128e08c7c0_0">
											<gml:posList>35.67056410438109 139.74342502148218 25.85 35.670564708077855 139.7434247225555 25.85 35.670564708077855 139.7434247225555 28.816 35.67056410438109 139.74342502148218 28.816 35.67056410438109 139.74342502148218 25.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-42f58e8e-5713-40a0-8bbe-feb47afd5ffd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-42f58e8e-5713-40a0-8bbe-feb47afd5ffd_0">
											<gml:posList>35.670559047591674 139.7434249056436 25.85 35.67055965169258 139.74342514798442 25.85 35.67055965169258 139.74342514798442 28.816 35.670559047591674 139.7434249056436 28.816 35.670559047591674 139.7434249056436 25.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fe85e1ad-eb7b-49f3-8fc0-b609ea0aff44">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fe85e1ad-eb7b-49f3-8fc0-b609ea0aff44_0">
											<gml:posList>35.67056349161288 139.74342524309503 25.85 35.67056410438109 139.74342502148218 25.85 35.67056410438109 139.74342502148218 28.816 35.67056349161288 139.74342524309503 28.816 35.67056349161288 139.74342524309503 25.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5e1992ef-3df5-40b8-be74-e5b81bb4d3a2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5e1992ef-3df5-40b8-be74-e5b81bb4d3a2_0">
											<gml:posList>35.67055965169258 139.74342514798442 25.85 35.67056028279341 139.74342533506356 25.85 35.67056028279341 139.74342533506356 28.816 35.67055965169258 139.74342514798442 28.816 35.67055965169258 139.74342514798442 25.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f927ab93-32b7-472f-ad96-9387cb6ca82d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f927ab93-32b7-472f-ad96-9387cb6ca82d_0">
											<gml:posList>35.67056285175401 139.74342539846052 25.85 35.67056349161288 139.74342524309503 25.85 35.67056349161288 139.74342524309503 28.816 35.67056285175401 139.74342539846052 28.816 35.67056285175401 139.74342539846052 25.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a2545c32-d2a0-46f6-995c-8fd76dd25773">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a2545c32-d2a0-46f6-995c-8fd76dd25773_0">
											<gml:posList>35.67056028279341 139.74342533506356 25.85 35.67056092285849 139.74342545585495 25.85 35.67056092285849 139.74342545585495 28.816 35.67056028279341 139.74342533506356 28.816 35.67056028279341 139.74342533506356 25.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-52a5e90e-13c2-4cb6-8431-5346b5731c5a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-52a5e90e-13c2-4cb6-8431-5346b5731c5a_0">
											<gml:posList>35.670562211845635 139.74342548754836 25.85 35.67056285175401 139.74342539846052 25.85 35.67056285175401 139.74342539846052 28.816 35.670562211845635 139.74342548754836 28.816 35.670562211845635 139.74342548754836 25.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0e52ec88-77d2-4c48-8e59-1de2e170adef">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0e52ec88-77d2-4c48-8e59-1de2e170adef_0">
											<gml:posList>35.67056092285849 139.74342545585495 25.85 35.67056157188779 139.74342551035858 25.85 35.67056157188779 139.74342551035858 28.816 35.67056092285849 139.74342545585495 28.816 35.67056092285849 139.74342545585495 25.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a6db54a4-c0a8-4b0c-a675-97b3c93734da">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a6db54a4-c0a8-4b0c-a675-97b3c93734da_0">
											<gml:posList>35.670562211845635 139.74342548754836 25.85 35.670562211845635 139.74342548754836 28.816 35.67056157188779 139.74342551035858 28.816 35.67056157188779 139.74342551035858 25.85 35.670562211845635 139.74342548754836 25.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-990fe4ce-620a-48b8-80ac-01dd1a7f2199">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-990fe4ce-620a-48b8-80ac-01dd1a7f2199_0">
											<gml:posList>35.67059361101456 139.7434433804656 30.311 35.670608558925714 139.7434475944364 30.311 35.670608558925714 139.7434475944364 25.85 35.67059361101456 139.7434433804656 25.85 35.67059361101456 139.7434433804656 30.311</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-93c3d604-0768-414d-aeee-67cf1e0c7593">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-93c3d604-0768-414d-aeee-67cf1e0c7593_0">
											<gml:posList>35.67059361101456 139.7434433804656 25.85 35.67059175257032 139.74345329107035 25.85 35.67059175257032 139.74345329107035 30.311 35.67059361101456 139.7434433804656 30.311 35.67059361101456 139.7434433804656 25.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-73162fda-6f5c-4b81-920c-dddc0aa370eb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-73162fda-6f5c-4b81-920c-dddc0aa370eb_0">
											<gml:posList>35.67059361101456 139.7434433804656 30.311 35.67059175257032 139.74345329107035 30.311 35.67060670048113 139.74345750504284 30.311 35.670608558925714 139.7434475944364 30.311 35.67059361101456 139.7434433804656 30.311</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3910cd76-dcf5-43df-88a6-b8031e33f949">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3910cd76-dcf5-43df-88a6-b8031e33f949_0">
											<gml:posList>35.670608558925714 139.7434475944364 25.85 35.670608558925714 139.7434475944364 30.311 35.67060670048113 139.74345750504284 30.311 35.67060670048113 139.74345750504284 25.85 35.670608558925714 139.7434475944364 25.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1301c2aa-4b21-45f6-97b0-9fe99ce22196">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1301c2aa-4b21-45f6-97b0-9fe99ce22196_0">
											<gml:posList>35.67059175257032 139.74345329107035 25.85 35.67060670048113 139.74345750504284 25.85 35.67060670048113 139.74345750504284 30.311 35.67059175257032 139.74345329107035 30.311 35.67059175257032 139.74345329107035 25.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-e17e9533-5e69-45f9-91dc-bb7616806b95">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e17e9533-5e69-45f9-91dc-bb7616806b95">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e17e9533-5e69-45f9-91dc-bb7616806b95">
											<gml:posList>35.670638542244426 139.74335593180248 7.29 35.67061726427344 139.74346918017852 7.29 35.670517731744596 139.7434411237261 7.29 35.67052195153471 139.74341880551086 7.29 35.670527901829296 139.7434204557799 7.29 35.670544959902976 139.74332941528323 7.29 35.670638542244426 139.74335593180248 7.29</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-3ed94a23-93a5-47d9-a133-9c0b548da5f1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3ed94a23-93a5-47d9-a133-9c0b548da5f1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3ed94a23-93a5-47d9-a133-9c0b548da5f1">
											<gml:posList>35.670517731744596 139.7434411237261 27.3 35.67052011902058 139.7434392984135 27.3 35.670523449965586 139.7434216869094 27.3 35.67052195153471 139.74341880551086 27.3 35.670517731744596 139.7434411237261 27.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d08f29a2-d063-48e8-ada7-c048ba13b119">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d08f29a2-d063-48e8-ada7-c048ba13b119">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d08f29a2-d063-48e8-ada7-c048ba13b119">
											<gml:posList>35.670527901829296 139.7434204557799 27.3 35.67052195153471 139.74341880551086 27.3 35.670523449965586 139.7434216869094 27.3 35.67052940026012 139.74342333717868 27.3 35.670527901829296 139.7434204557799 27.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-1150f597-f504-49e3-bbd0-5fc4a4cbf95d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1150f597-f504-49e3-bbd0-5fc4a4cbf95d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1150f597-f504-49e3-bbd0-5fc4a4cbf95d">
											<gml:posList>35.670527901829296 139.7434204557799 27.3 35.67052940026012 139.74342333717868 27.3 35.67054644934702 139.74333232982983 27.3 35.670544959902976 139.74332941528323 27.3 35.670527901829296 139.7434204557799 27.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-6143bd58-c7e9-4a04-b51b-d05d665bb708">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6143bd58-c7e9-4a04-b51b-d05d665bb708">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6143bd58-c7e9-4a04-b51b-d05d665bb708">
											<gml:posList>35.67061726427344 139.74346918017852 27.3 35.670615783846436 139.74346626561666 27.3 35.67052011902058 139.7434392984135 27.3 35.670517731744596 139.7434411237261 27.3 35.67061726427344 139.74346918017852 27.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-77c8feac-613a-4cae-96e7-c09f70751d80">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-77c8feac-613a-4cae-96e7-c09f70751d80">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-77c8feac-613a-4cae-96e7-c09f70751d80">
											<gml:posList>35.670615783846436 139.74346626561666 25.85 35.67063617298895 139.74335774605373 25.85 35.67054644934702 139.74333232982983 25.85 35.67052940026012 139.74342333717868 25.85 35.670523449965586 139.7434216869094 25.85 35.67052011902058 139.7434392984135 25.85 35.670615783846436 139.74346626561666 25.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-7e15f6f7-f58f-4a63-ad1d-6470d81caf58">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7e15f6f7-f58f-4a63-ad1d-6470d81caf58">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7e15f6f7-f58f-4a63-ad1d-6470d81caf58">
											<gml:posList>35.670544959902976 139.74332941528323 27.3 35.67054644934702 139.74333232982983 27.3 35.67063617298895 139.74335774605373 27.3 35.670638542244426 139.74335593180248 27.3 35.670544959902976 139.74332941528323 27.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-0fdc669f-94d0-4e24-84d4-3d8c5af0d648">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0fdc669f-94d0-4e24-84d4-3d8c5af0d648">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0fdc669f-94d0-4e24-84d4-3d8c5af0d648">
											<gml:posList>35.670638542244426 139.74335593180248 27.3 35.67063617298895 139.74335774605373 27.3 35.670615783846436 139.74346626561666 27.3 35.67061726427344 139.74346918017852 27.3 35.670638542244426 139.74335593180248 27.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6a17074e-d6a1-4892-80e4-1594e00bfc4f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6a17074e-d6a1-4892-80e4-1594e00bfc4f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6a17074e-d6a1-4892-80e4-1594e00bfc4f">
											<gml:posList>35.670638542244426 139.74335593180248 7.29 35.670544959902976 139.74332941528323 7.29 35.670544959902976 139.74332941528323 27.3 35.670638542244426 139.74335593180248 27.3 35.670638542244426 139.74335593180248 7.29</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-21d34eb2-8cb8-41a9-b0ef-7b31c15beebe">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-21d34eb2-8cb8-41a9-b0ef-7b31c15beebe">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-21d34eb2-8cb8-41a9-b0ef-7b31c15beebe">
											<gml:posList>35.67054644934702 139.74333232982983 27.3 35.67054644934702 139.74333232982983 25.85 35.67063617298895 139.74335774605373 25.85 35.67063617298895 139.74335774605373 27.3 35.67054644934702 139.74333232982983 27.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9547a8fa-6212-477c-9886-6ac551fde2cc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9547a8fa-6212-477c-9886-6ac551fde2cc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9547a8fa-6212-477c-9886-6ac551fde2cc">
											<gml:posList>35.670544959902976 139.74332941528323 7.29 35.670527901829296 139.7434204557799 7.29 35.670527901829296 139.7434204557799 27.3 35.670544959902976 139.74332941528323 27.3 35.670544959902976 139.74332941528323 7.29</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7027473d-a2a0-467c-9127-12820b6b5833">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7027473d-a2a0-467c-9127-12820b6b5833">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7027473d-a2a0-467c-9127-12820b6b5833">
											<gml:posList>35.67052940026012 139.74342333717868 27.3 35.67052940026012 139.74342333717868 25.85 35.67054644934702 139.74333232982983 25.85 35.67054644934702 139.74333232982983 27.3 35.67052940026012 139.74342333717868 27.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a57bcc8f-c545-4562-a9a3-2e8b9581753a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a57bcc8f-c545-4562-a9a3-2e8b9581753a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a57bcc8f-c545-4562-a9a3-2e8b9581753a">
											<gml:posList>35.67063617298895 139.74335774605373 27.3 35.67063617298895 139.74335774605373 25.85 35.670615783846436 139.74346626561666 25.85 35.670615783846436 139.74346626561666 27.3 35.67063617298895 139.74335774605373 27.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7dbd1ebb-e78a-4138-bd2f-228415e15ee6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7dbd1ebb-e78a-4138-bd2f-228415e15ee6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7dbd1ebb-e78a-4138-bd2f-228415e15ee6">
											<gml:posList>35.67061726427344 139.74346918017852 7.29 35.670638542244426 139.74335593180248 7.29 35.670638542244426 139.74335593180248 27.3 35.67061726427344 139.74346918017852 27.3 35.67061726427344 139.74346918017852 7.29</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7ed0cba4-e2ef-4f35-a249-9bda33be0a0a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7ed0cba4-e2ef-4f35-a249-9bda33be0a0a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7ed0cba4-e2ef-4f35-a249-9bda33be0a0a">
											<gml:posList>35.670527901829296 139.7434204557799 7.29 35.67052195153471 139.74341880551086 7.29 35.67052195153471 139.74341880551086 27.3 35.670527901829296 139.7434204557799 27.3 35.670527901829296 139.7434204557799 7.29</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c9eb5d7f-a04c-4f41-8471-a7aaffba518e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c9eb5d7f-a04c-4f41-8471-a7aaffba518e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c9eb5d7f-a04c-4f41-8471-a7aaffba518e">
											<gml:posList>35.670523449965586 139.7434216869094 27.3 35.670523449965586 139.7434216869094 25.85 35.67052940026012 139.74342333717868 25.85 35.67052940026012 139.74342333717868 27.3 35.670523449965586 139.7434216869094 27.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8f71b717-10ae-47f9-a5d7-4f2a8f1a4aef">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8f71b717-10ae-47f9-a5d7-4f2a8f1a4aef">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8f71b717-10ae-47f9-a5d7-4f2a8f1a4aef">
											<gml:posList>35.67052195153471 139.74341880551086 7.29 35.670517731744596 139.7434411237261 7.29 35.670517731744596 139.7434411237261 27.3 35.67052195153471 139.74341880551086 27.3 35.67052195153471 139.74341880551086 7.29</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-702575a4-fac5-4e6f-a4cf-5cc7222e27ce">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-702575a4-fac5-4e6f-a4cf-5cc7222e27ce">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-702575a4-fac5-4e6f-a4cf-5cc7222e27ce">
											<gml:posList>35.67052011902058 139.7434392984135 27.3 35.67052011902058 139.7434392984135 25.85 35.670523449965586 139.7434216869094 25.85 35.670523449965586 139.7434216869094 27.3 35.67052011902058 139.7434392984135 27.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d0860111-27e9-49f4-bf1e-aa9c6d386d4a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d0860111-27e9-49f4-bf1e-aa9c6d386d4a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d0860111-27e9-49f4-bf1e-aa9c6d386d4a">
											<gml:posList>35.670615783846436 139.74346626561666 27.3 35.670615783846436 139.74346626561666 25.85 35.67052011902058 139.7434392984135 25.85 35.67052011902058 139.7434392984135 27.3 35.670615783846436 139.74346626561666 27.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b7e92d73-c77c-4f77-9d1c-cdbcc58ea0a1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b7e92d73-c77c-4f77-9d1c-cdbcc58ea0a1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b7e92d73-c77c-4f77-9d1c-cdbcc58ea0a1">
											<gml:posList>35.670517731744596 139.7434411237261 7.29 35.67061726427344 139.74346918017852 7.29 35.67061726427344 139.74346918017852 27.3 35.670517731744596 139.7434411237261 27.3 35.670517731744596 139.7434411237261 7.29</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂一丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-9494</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">113.54655</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1210</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>7</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.46</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>