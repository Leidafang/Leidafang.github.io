<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_1ef1f7e4-b934-46c4-9e23-a198cc095e9b">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>18</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103018002</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="再開発等促進区を定める地区計画">
				<gen:value>虎ノ門一・二丁目地区</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">401</bldg:usage>
			<bldg:measuredHeight uom="m">34.5</bldg:measuredHeight>
			<bldg:storeysAboveGround>9</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.668680369034966 139.7469961709437 0 35.66869974121249 139.74697335108164 0 35.668715005492366 139.74699153849988 0 35.66881979570932 139.7468611154657 0 35.66880653402824 139.74684511300498 0 35.66883526210525 139.7468092928245 0 35.668750369158424 139.74670676676183 0 35.66859790305469 139.7468965915502 0 35.668680369034966 139.7469961709437 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668680369034966 139.7469961709437 5.95 35.66859790305469 139.7468965915502 5.95 35.668750369158424 139.74670676676183 5.95 35.66883526210525 139.7468092928245 5.95 35.66880653402824 139.74684511300498 5.95 35.66881979570932 139.7468611154657 5.95 35.668715005492366 139.74699153849988 5.95 35.66869974121249 139.74697335108164 5.95 35.668680369034966 139.7469961709437 5.95</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668680369034966 139.7469961709437 5.95 35.66869974121249 139.74697335108164 5.95 35.66869974121249 139.74697335108164 38.35 35.668680369034966 139.7469961709437 38.35 35.668680369034966 139.7469961709437 5.95</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66869974121249 139.74697335108164 5.95 35.668715005492366 139.74699153849988 5.95 35.668715005492366 139.74699153849988 38.35 35.66869974121249 139.74697335108164 38.35 35.66869974121249 139.74697335108164 5.95</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668715005492366 139.74699153849988 5.95 35.66881979570932 139.7468611154657 5.95 35.66881979570932 139.7468611154657 38.35 35.668715005492366 139.74699153849988 38.35 35.668715005492366 139.74699153849988 5.95</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66881979570932 139.7468611154657 5.95 35.66880653402824 139.74684511300498 5.95 35.66880653402824 139.74684511300498 38.35 35.66881979570932 139.7468611154657 38.35 35.66881979570932 139.7468611154657 5.95</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66880653402824 139.74684511300498 5.95 35.66883526210525 139.7468092928245 5.95 35.66883526210525 139.7468092928245 38.35 35.66880653402824 139.74684511300498 38.35 35.66880653402824 139.74684511300498 5.95</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66883526210525 139.7468092928245 5.95 35.668750369158424 139.74670676676183 5.95 35.668750369158424 139.74670676676183 38.35 35.66883526210525 139.7468092928245 38.35 35.66883526210525 139.7468092928245 5.95</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668750369158424 139.74670676676183 5.95 35.66859790305469 139.7468965915502 5.95 35.66859790305469 139.7468965915502 38.35 35.668750369158424 139.74670676676183 38.35 35.668750369158424 139.74670676676183 5.95</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66859790305469 139.7468965915502 5.95 35.668680369034966 139.7469961709437 5.95 35.668680369034966 139.7469961709437 38.35 35.66859790305469 139.7468965915502 38.35 35.66859790305469 139.7468965915502 5.95</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668680369034966 139.7469961709437 38.35 35.66869974121249 139.74697335108164 38.35 35.668715005492366 139.74699153849988 38.35 35.66881979570932 139.7468611154657 38.35 35.66880653402824 139.74684511300498 38.35 35.66883526210525 139.7468092928245 38.35 35.668750369158424 139.74670676676183 38.35 35.66859790305469 139.7468965915502 38.35 35.668680369034966 139.7469961709437 38.35</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-b879d2ab-8b22-4038-9a80-1e6bb76d4c7f"/>
							<gml:surfaceMember xlink:href="#poly-e2413038-a6e2-4847-9383-5202bc8a1a6f"/>
							<gml:surfaceMember xlink:href="#poly-6022ea46-b576-4776-9c80-58bbd840c688"/>
							<gml:surfaceMember xlink:href="#poly-6f70b60a-d7fd-45a3-adca-6c1ab7ca7233"/>
							<gml:surfaceMember xlink:href="#poly-1e267ef9-ac9c-4f12-8d81-383c7f32e170"/>
							<gml:surfaceMember xlink:href="#poly-083cbe62-71c0-4bd7-b5c0-f7bc28e41091"/>
							<gml:surfaceMember xlink:href="#poly-d72609d8-32b1-499c-b34b-421c15f57f4f"/>
							<gml:surfaceMember xlink:href="#poly-1c1d31f4-5e65-426e-a4a1-230194e73f6d"/>
							<gml:surfaceMember xlink:href="#poly-40951aac-cfdd-465b-a800-0fd79070c338"/>
							<gml:surfaceMember xlink:href="#poly-f47986f1-8a92-46d7-b5ae-b0ff470209ac"/>
							<gml:surfaceMember xlink:href="#poly-f139a9fc-e9d4-44cd-8fb2-61a28216d040"/>
							<gml:surfaceMember xlink:href="#poly-5442bf15-1ca5-48ea-a1b8-108699950d4d"/>
							<gml:surfaceMember xlink:href="#poly-feb59b81-fe0a-43c0-9cf3-500d7c13c18a"/>
							<gml:surfaceMember xlink:href="#poly-fba06175-76a8-4a7e-b51a-e361e7d1b25d"/>
							<gml:surfaceMember xlink:href="#poly-50e2c821-3d36-499f-84c7-1781bb4b6f18"/>
							<gml:surfaceMember xlink:href="#poly-37482c29-45a1-4579-9cde-45e59e0fabab"/>
							<gml:surfaceMember xlink:href="#poly-de66dbbf-bb5d-44ee-9626-7f62c0d0c669"/>
							<gml:surfaceMember xlink:href="#poly-77e5be66-8f75-48f5-98f1-f23976083873"/>
							<gml:surfaceMember xlink:href="#poly-2500c5c7-1633-4120-b228-6f5aa6545d23"/>
							<gml:surfaceMember xlink:href="#poly-3a1f2d08-35d7-4c4f-9aef-903b83900d72"/>
							<gml:surfaceMember xlink:href="#poly-6f82dda7-0814-4618-b0f8-44efe0fc8fc2"/>
							<gml:surfaceMember xlink:href="#poly-e795ae3f-6ca5-4b0b-8ac3-d2fb56ae72c5"/>
							<gml:surfaceMember xlink:href="#poly-ae536392-6879-406b-abff-102f86e6f72a"/>
							<gml:surfaceMember xlink:href="#poly-21348adf-9772-402b-bd01-b7185b3002e3"/>
							<gml:surfaceMember xlink:href="#poly-656dd08e-ae9b-4792-8bcd-f12c25f7eb0d"/>
							<gml:surfaceMember xlink:href="#poly-9d717d37-1421-444d-b973-ac7e9f403ae7"/>
							<gml:surfaceMember xlink:href="#poly-1308c4ed-5281-434f-82cf-6e3cc555d697"/>
							<gml:surfaceMember xlink:href="#poly-20ed1ab4-0a68-4d46-9f43-81440d7bb0d3"/>
							<gml:surfaceMember xlink:href="#poly-7c232b12-e8bc-48b3-92e3-e74e44f55ba9"/>
							<gml:surfaceMember xlink:href="#poly-56e847a4-1101-4442-811e-49d0562d59fe"/>
							<gml:surfaceMember xlink:href="#poly-00b282d6-ee6d-49ef-9fd1-a7761a87681b"/>
							<gml:surfaceMember xlink:href="#poly-9eb00c27-e380-4e6b-9a72-300f8656addd"/>
							<gml:surfaceMember xlink:href="#poly-9576a546-2a50-436d-8959-b78ce4f7f5cb"/>
							<gml:surfaceMember xlink:href="#poly-ea2b04eb-ba5e-4f3e-8d85-32f779c614ec"/>
							<gml:surfaceMember xlink:href="#poly-05affa6c-1771-4e77-9220-a7e86bd98647"/>
							<gml:surfaceMember xlink:href="#poly-1d950a81-ab1f-4d9b-bb8c-1496671d2067"/>
							<gml:surfaceMember xlink:href="#poly-fa0c7452-9a75-42f6-b9ee-4a58d0fa4ca6"/>
							<gml:surfaceMember xlink:href="#poly-847141ae-6887-471b-a12f-497f3d72cf71"/>
							<gml:surfaceMember xlink:href="#poly-9cf066cf-f883-466e-a965-868ae6383366"/>
							<gml:surfaceMember xlink:href="#poly-e58d8f49-fede-448b-b839-bc778abc4ce1"/>
							<gml:surfaceMember xlink:href="#poly-228b6947-3af2-4835-8b8e-1ce5d5934a8a"/>
							<gml:surfaceMember xlink:href="#poly-81e8d6aa-8568-4467-b9a9-6d4756fa3468"/>
							<gml:surfaceMember xlink:href="#poly-540fc6f8-5092-4d96-9dc9-ee1f3649b540"/>
							<gml:surfaceMember xlink:href="#poly-61325a52-783c-4edc-ab3d-77d4e918843f"/>
							<gml:surfaceMember xlink:href="#poly-09d5f34f-4475-4a6c-b654-2a7749d99123"/>
							<gml:surfaceMember xlink:href="#poly-9da7b723-10f2-4720-9ca9-6a7282981c66"/>
							<gml:surfaceMember xlink:href="#poly-6674728c-4e3f-41f4-ab36-9143a98f4434"/>
							<gml:surfaceMember xlink:href="#poly-b5d7be8a-07f1-42bc-8cf6-eed6f8912526"/>
							<gml:surfaceMember xlink:href="#poly-63548672-ac92-4a35-b22d-d5550f88f2fd"/>
							<gml:surfaceMember xlink:href="#poly-c5d03d71-929b-4eca-8a9a-67a4f7377cb0"/>
							<gml:surfaceMember xlink:href="#poly-7edbdf66-1f67-4c9e-a245-0e171a352887"/>
							<gml:surfaceMember xlink:href="#poly-030288d6-812f-4a0c-891e-c4c079284fef"/>
							<gml:surfaceMember xlink:href="#poly-9418cd5d-faf1-4f0f-90f4-0404afe5baed"/>
							<gml:surfaceMember xlink:href="#poly-52dbcb28-0058-4865-a453-2db1eafc162b"/>
							<gml:surfaceMember xlink:href="#poly-02db16f6-06b5-4cd3-9806-2527d0a9bcca"/>
							<gml:surfaceMember xlink:href="#poly-df57aae5-acc6-4811-a4fc-bcc34a0ac042"/>
							<gml:surfaceMember xlink:href="#poly-cf4d812b-b347-4ae8-aece-b23ff1bdeeb9"/>
							<gml:surfaceMember xlink:href="#poly-f094186c-f0a9-4282-b390-9b54c0f68176"/>
							<gml:surfaceMember xlink:href="#poly-6efed1b7-fbd3-4af2-8655-bf526c28ad91"/>
							<gml:surfaceMember xlink:href="#poly-345906d7-84df-4d6e-8ab5-717fbf7a75b6"/>
							<gml:surfaceMember xlink:href="#poly-9e59db8e-f0d5-4af8-b06f-e26e16cac47b"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_1ef1f7e4-b934-46c4-9e23-a198cc095e9b_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-27733062-9e05-481b-9f59-001f504fc666">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66862864683278 139.74690626785903 38.428 35.668623234545734 139.74691318850006 38.428 35.66861064075121 139.7468983893657 38.428 35.668616053037425 139.74689146872473 38.428 35.66862864683278 139.74690626785903 38.428</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9704178e-ce04-4aec-a392-ce198c634d18">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66862864683278 139.74690626785903 38.428 35.668616053037425 139.74689146872473 38.428 35.668616053037425 139.74689146872473 40.155 35.66862864683278 139.74690626785903 40.155 35.66862864683278 139.74690626785903 38.428</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-486d9e6e-d2cc-41b0-8c3d-10f4b2adb75c">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66864119145746 139.74689023760774 38.428 35.66863556304012 139.74689743463446 38.428 35.6686229692437 139.74688263550027 38.428 35.66862858864644 139.74687543848339 38.428 35.66864119145746 139.74689023760774 38.428</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d89d171a-0ccc-436b-9aaf-2010b32d486f">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66864119145746 139.74689023760774 38.428 35.66862858864644 139.74687543848339 38.428 35.66862858864644 139.74687543848339 40.155 35.66864119145746 139.74689023760774 40.155 35.66864119145746 139.74689023760774 38.428</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3379f006-70f0-4cfe-adc4-82a3a76890e0">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6686356579421 139.7468664062627 38.428 35.66864116929018 139.7468593640044 38.428 35.668654114918226 139.7468745714617 38.428 35.66864860356926 139.74688161372012 38.428 35.6686356579421 139.7468664062627 38.428</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5a125c27-538b-42f9-b8ba-b357c8e21965">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668660247634904 139.74686672217257 38.428 35.668646823873765 139.74685095188394 38.428 35.66865269544471 139.7468434563481 38.428 35.668666119206826 139.7468592266366 38.428 35.668660247634904 139.74686672217257 38.428</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cf7599c9-8279-4288-9e71-9163769ddde6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66866469239789 139.74683045328354 38.428 35.66867826943469 139.74684627863704 38.428 35.66867261404232 139.74685356406744 38.428 35.668659037014386 139.74683774975986 38.428 35.66866469239789 139.74683045328354 38.428</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fef7b805-d0bf-4eec-97b9-6c3ee1d3cae7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66867679522865 139.74691468826242 38.428 35.66866507634472 139.74690069453456 38.428 35.66867016450952 139.7468942934016 38.428 35.668681883402115 139.74690829817544 38.428 35.66867679522865 139.74691468826242 38.428</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d6e0444f-20a2-4277-b1dc-54220bd0879d">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66868091505191 139.74687777904944 38.428 35.668693987932265 139.7468944665478 38.428 35.6686885662358 139.7469008349041 38.428 35.66867550237797 139.7468841584421 38.428 35.66868091505191 139.74687777904944 38.428</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ff004dbc-d125-4044-9db5-7ae09eee4db0">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668686781534255 139.7469134182524 38.428 35.668699754688 139.7469293105512 38.428 35.66869447727273 139.74693576711837 38.428 35.66868151314148 139.74691988585587 38.428 35.668686781534255 139.7469134182524 38.428</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-14217a59-cb97-47a0-8943-a70b75ced4cc">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668703327652814 139.74690910351384 38.428 35.66869496041701 139.74691819236736 38.428 35.66868836484252 139.74690908650336 38.428 35.66869674108344 139.7468999865939 38.428 35.668703327652814 139.74690910351384 38.428</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-982c29a4-8df9-4309-a56c-be2ac745b031">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6687258336159 139.7468570303524 43.854 35.668733029157764 139.74684807530522 43.854 35.6687472020182 139.7468651813727 43.854 35.668740006483006 139.74687414746595 43.854 35.6687258336159 139.7468570303524 43.854</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bf8fe1ff-e52f-4be5-b44c-a54686905d11">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bf8fe1ff-e52f-4be5-b44c-a54686905d11_0">
											<gml:posList>35.66863556304012 139.74689743463446 38.428 35.66863556304012 139.74689743463446 40.155 35.6686229692437 139.74688263550027 40.155 35.6686229692437 139.74688263550027 38.428 35.66863556304012 139.74689743463446 38.428</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3694b47b-04ad-4b8b-9037-99054bb07b6f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3694b47b-04ad-4b8b-9037-99054bb07b6f_0">
											<gml:posList>35.668654114918226 139.7468745714617 38.428 35.66864116929018 139.7468593640044 38.428 35.66864116929018 139.7468593640044 40.155 35.668654114918226 139.7468745714617 40.155 35.668654114918226 139.7468745714617 38.428</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a669c888-e63c-47ff-bf27-ba7539ad9375">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a669c888-e63c-47ff-bf27-ba7539ad9375_0">
											<gml:posList>35.668681883402115 139.74690829817544 38.428 35.66867016450952 139.7468942934016 38.428 35.66867016450952 139.7468942934016 40.155 35.668681883402115 139.74690829817544 40.155 35.668681883402115 139.74690829817544 38.428</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3a04905d-4487-4151-a842-c7cce905c1b8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3a04905d-4487-4151-a842-c7cce905c1b8_0">
											<gml:posList>35.66861064075121 139.7468983893657 38.428 35.66861064075121 139.7468983893657 40.155 35.668616053037425 139.74689146872473 40.155 35.668616053037425 139.74689146872473 38.428 35.66861064075121 139.7468983893657 38.428</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c0499728-ca8f-4f6e-9c11-118d14910945">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c0499728-ca8f-4f6e-9c11-118d14910945_0">
											<gml:posList>35.66861064075121 139.7468983893657 38.428 35.668623234545734 139.74691318850006 38.428 35.668623234545734 139.74691318850006 40.155 35.66861064075121 139.7468983893657 40.155 35.66861064075121 139.7468983893657 38.428</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7210d3a9-fd4e-45f8-85d9-ca42ca116665">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7210d3a9-fd4e-45f8-85d9-ca42ca116665_0">
											<gml:posList>35.66861064075121 139.7468983893657 40.155 35.668623234545734 139.74691318850006 40.155 35.66862864683278 139.74690626785903 40.155 35.668616053037425 139.74689146872473 40.155 35.66861064075121 139.7468983893657 40.155</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-60a1f53b-f780-4cdf-bc80-1f024642221e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-60a1f53b-f780-4cdf-bc80-1f024642221e_0">
											<gml:posList>35.66862858864644 139.74687543848339 38.428 35.6686229692437 139.74688263550027 38.428 35.6686229692437 139.74688263550027 40.155 35.66862858864644 139.74687543848339 40.155 35.66862858864644 139.74687543848339 38.428</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bf1c1ba9-b3f7-4ed7-a237-ec94fa3effee">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bf1c1ba9-b3f7-4ed7-a237-ec94fa3effee_0">
											<gml:posList>35.668623234545734 139.74691318850006 38.428 35.66862864683278 139.74690626785903 38.428 35.66862864683278 139.74690626785903 40.155 35.668623234545734 139.74691318850006 40.155 35.668623234545734 139.74691318850006 38.428</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ca8c1636-946a-4b93-ae6d-870eccd62869">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ca8c1636-946a-4b93-ae6d-870eccd62869_0">
											<gml:posList>35.66864119145746 139.74689023760774 40.155 35.66862858864644 139.74687543848339 40.155 35.6686229692437 139.74688263550027 40.155 35.66863556304012 139.74689743463446 40.155 35.66864119145746 139.74689023760774 40.155</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8b92fa51-77a0-4afa-8ae1-55d5e8d0e4de">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8b92fa51-77a0-4afa-8ae1-55d5e8d0e4de_0">
											<gml:posList>35.66863556304012 139.74689743463446 38.428 35.66864119145746 139.74689023760774 38.428 35.66864119145746 139.74689023760774 40.155 35.66863556304012 139.74689743463446 40.155 35.66863556304012 139.74689743463446 38.428</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2dbca80e-e238-4997-ad83-c9dd92590ee9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2dbca80e-e238-4997-ad83-c9dd92590ee9_0">
											<gml:posList>35.66864116929018 139.7468593640044 38.428 35.6686356579421 139.7468664062627 38.428 35.6686356579421 139.7468664062627 40.155 35.66864116929018 139.7468593640044 40.155 35.66864116929018 139.7468593640044 38.428</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-778be91d-ddd1-4cf7-a648-6f570de58960">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-778be91d-ddd1-4cf7-a648-6f570de58960_0">
											<gml:posList>35.66864860356926 139.74688161372012 38.428 35.66864860356926 139.74688161372012 40.155 35.6686356579421 139.7468664062627 40.155 35.6686356579421 139.7468664062627 38.428 35.66864860356926 139.74688161372012 38.428</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0d204fff-9f9f-4eb8-b87e-e0d10eb66575">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0d204fff-9f9f-4eb8-b87e-e0d10eb66575_0">
											<gml:posList>35.668654114918226 139.7468745714617 40.155 35.66864116929018 139.7468593640044 40.155 35.6686356579421 139.7468664062627 40.155 35.66864860356926 139.74688161372012 40.155 35.668654114918226 139.7468745714617 40.155</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cf52bce4-bd3b-4717-b58d-c8aa395c02dc">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cf52bce4-bd3b-4717-b58d-c8aa395c02dc_0">
											<gml:posList>35.66865269544471 139.7468434563481 38.428 35.668646823873765 139.74685095188394 38.428 35.668646823873765 139.74685095188394 40.155 35.66865269544471 139.7468434563481 40.155 35.66865269544471 139.7468434563481 38.428</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-885640ba-db59-4568-8c0b-c12d7ed7ba20">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-885640ba-db59-4568-8c0b-c12d7ed7ba20_0">
											<gml:posList>35.66864860356926 139.74688161372012 38.428 35.668654114918226 139.7468745714617 38.428 35.668654114918226 139.7468745714617 40.155 35.66864860356926 139.74688161372012 40.155 35.66864860356926 139.74688161372012 38.428</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-97cf6181-67b5-4fdb-97d2-f8edc0bd13fd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-97cf6181-67b5-4fdb-97d2-f8edc0bd13fd_0">
											<gml:posList>35.668646823873765 139.74685095188394 38.428 35.668660247634904 139.74686672217257 38.428 35.668660247634904 139.74686672217257 40.155 35.668646823873765 139.74685095188394 40.155 35.668646823873765 139.74685095188394 38.428</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-16b9bace-8f31-4ac6-b9bd-5b47afa63915">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-16b9bace-8f31-4ac6-b9bd-5b47afa63915_0">
											<gml:posList>35.66865269544471 139.7468434563481 40.155 35.668646823873765 139.74685095188394 40.155 35.668660247634904 139.74686672217257 40.155 35.668666119206826 139.7468592266366 40.155 35.66865269544471 139.7468434563481 40.155</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6c4d1193-7b6a-4679-95fd-18027a57ce68">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6c4d1193-7b6a-4679-95fd-18027a57ce68_0">
											<gml:posList>35.668666119206826 139.7468592266366 38.428 35.66865269544471 139.7468434563481 38.428 35.66865269544471 139.7468434563481 40.155 35.668666119206826 139.7468592266366 40.155 35.668666119206826 139.7468592266366 38.428</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-94fe42b1-c9ea-4d9a-ab06-d3aad827529f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-94fe42b1-c9ea-4d9a-ab06-d3aad827529f_0">
											<gml:posList>35.66866469239789 139.74683045328354 38.428 35.668659037014386 139.74683774975986 38.428 35.668659037014386 139.74683774975986 40.155 35.66866469239789 139.74683045328354 40.155 35.66866469239789 139.74683045328354 38.428</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-31290445-d4b5-4e41-a8b9-9c93c6b9d4ae">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-31290445-d4b5-4e41-a8b9-9c93c6b9d4ae_0">
											<gml:posList>35.668660247634904 139.74686672217257 38.428 35.668666119206826 139.7468592266366 38.428 35.668666119206826 139.7468592266366 40.155 35.668660247634904 139.74686672217257 40.155 35.668660247634904 139.74686672217257 38.428</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2a9b9990-b0d1-40dd-90cb-5ed671f58d8c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2a9b9990-b0d1-40dd-90cb-5ed671f58d8c_0">
											<gml:posList>35.668659037014386 139.74683774975986 38.428 35.66867261404232 139.74685356406744 38.428 35.66867261404232 139.74685356406744 40.155 35.668659037014386 139.74683774975986 40.155 35.668659037014386 139.74683774975986 38.428</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-081b194b-2bb2-410e-acd8-960e484ac8cb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-081b194b-2bb2-410e-acd8-960e484ac8cb_0">
											<gml:posList>35.66867016450952 139.7468942934016 38.428 35.66866507634472 139.74690069453456 38.428 35.66866507634472 139.74690069453456 40.155 35.66867016450952 139.7468942934016 40.155 35.66867016450952 139.7468942934016 38.428</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-649812c5-6032-46ae-a3d9-02a34f170ea2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-649812c5-6032-46ae-a3d9-02a34f170ea2_0">
											<gml:posList>35.66867261404232 139.74685356406744 40.155 35.66867826943469 139.74684627863704 40.155 35.66866469239789 139.74683045328354 40.155 35.668659037014386 139.74683774975986 40.155 35.66867261404232 139.74685356406744 40.155</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7a00ed74-52f8-4378-bd48-df28d0edf62f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7a00ed74-52f8-4378-bd48-df28d0edf62f_0">
											<gml:posList>35.66867679522865 139.74691468826242 38.428 35.66867679522865 139.74691468826242 40.155 35.66866507634472 139.74690069453456 40.155 35.66866507634472 139.74690069453456 38.428 35.66867679522865 139.74691468826242 38.428</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-99fc95de-863b-4594-81ad-1df169584a8f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-99fc95de-863b-4594-81ad-1df169584a8f_0">
											<gml:posList>35.66867826943469 139.74684627863704 38.428 35.66866469239789 139.74683045328354 38.428 35.66866469239789 139.74683045328354 40.155 35.66867826943469 139.74684627863704 40.155 35.66867826943469 139.74684627863704 38.428</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1b7c014d-5070-4154-90a1-eb62c7467af4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1b7c014d-5070-4154-90a1-eb62c7467af4_0">
											<gml:posList>35.66867679522865 139.74691468826242 40.155 35.668681883402115 139.74690829817544 40.155 35.66867016450952 139.7468942934016 40.155 35.66866507634472 139.74690069453456 40.155 35.66867679522865 139.74691468826242 40.155</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4102d9ca-e58f-4a17-acfa-5d3b3bd2e7dd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4102d9ca-e58f-4a17-acfa-5d3b3bd2e7dd_0">
											<gml:posList>35.66867261404232 139.74685356406744 38.428 35.66867826943469 139.74684627863704 38.428 35.66867826943469 139.74684627863704 40.155 35.66867261404232 139.74685356406744 40.155 35.66867261404232 139.74685356406744 38.428</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-46aff316-4e74-480a-ae5b-f3cab84354ff">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-46aff316-4e74-480a-ae5b-f3cab84354ff_0">
											<gml:posList>35.66868091505191 139.74687777904944 38.428 35.66867550237797 139.7468841584421 38.428 35.66867550237797 139.7468841584421 40.155 35.66868091505191 139.74687777904944 40.155 35.66868091505191 139.74687777904944 38.428</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-350f0fa9-5fc8-4cc5-ba9f-2f5eaa0c3cdd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-350f0fa9-5fc8-4cc5-ba9f-2f5eaa0c3cdd_0">
											<gml:posList>35.66867679522865 139.74691468826242 38.428 35.668681883402115 139.74690829817544 38.428 35.668681883402115 139.74690829817544 40.155 35.66867679522865 139.74691468826242 40.155 35.66867679522865 139.74691468826242 38.428</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7f3fb8e2-39be-4957-b0bd-f99aee28d921">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7f3fb8e2-39be-4957-b0bd-f99aee28d921_0">
											<gml:posList>35.66867550237797 139.7468841584421 38.428 35.6686885662358 139.7469008349041 38.428 35.6686885662358 139.7469008349041 40.155 35.66867550237797 139.7468841584421 40.155 35.66867550237797 139.7468841584421 38.428</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3fa22a06-4134-4e8b-9174-63db10682384">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3fa22a06-4134-4e8b-9174-63db10682384_0">
											<gml:posList>35.668686781534255 139.7469134182524 38.428 35.66868151314148 139.74691988585587 38.428 35.66868151314148 139.74691988585587 40.155 35.668686781534255 139.7469134182524 40.155 35.668686781534255 139.7469134182524 38.428</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c31587c6-5d61-4289-8ed0-e3d2b0eb73f2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c31587c6-5d61-4289-8ed0-e3d2b0eb73f2_0">
											<gml:posList>35.6686885662358 139.7469008349041 40.155 35.668693987932265 139.7468944665478 40.155 35.66868091505191 139.74687777904944 40.155 35.66867550237797 139.7468841584421 40.155 35.6686885662358 139.7469008349041 40.155</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-10ce25e7-54a0-4bcb-b441-64294f311396">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-10ce25e7-54a0-4bcb-b441-64294f311396_0">
											<gml:posList>35.668693987932265 139.7468944665478 38.428 35.66868091505191 139.74687777904944 38.428 35.66868091505191 139.74687777904944 40.155 35.668693987932265 139.7468944665478 40.155 35.668693987932265 139.7468944665478 38.428</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8a384c63-196b-4d6b-b268-5edc1712a85b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8a384c63-196b-4d6b-b268-5edc1712a85b_0">
											<gml:posList>35.66868151314148 139.74691988585587 38.428 35.66869447727273 139.74693576711837 38.428 35.66869447727273 139.74693576711837 40.155 35.66868151314148 139.74691988585587 40.155 35.66868151314148 139.74691988585587 38.428</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-50e18d4c-fbb5-44c5-ade6-397475e5df2a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-50e18d4c-fbb5-44c5-ade6-397475e5df2a_0">
											<gml:posList>35.66869447727273 139.74693576711837 40.155 35.668699754688 139.7469293105512 40.155 35.668686781534255 139.7469134182524 40.155 35.66868151314148 139.74691988585587 40.155 35.66869447727273 139.74693576711837 40.155</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-dd26394f-b694-400b-ba87-bf2b10598d19">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-dd26394f-b694-400b-ba87-bf2b10598d19_0">
											<gml:posList>35.6686885662358 139.7469008349041 38.428 35.668693987932265 139.7468944665478 38.428 35.668693987932265 139.7468944665478 40.155 35.6686885662358 139.7469008349041 40.155 35.6686885662358 139.7469008349041 38.428</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7fedff79-6007-4e65-8738-a73c0d2bfe76">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7fedff79-6007-4e65-8738-a73c0d2bfe76_0">
											<gml:posList>35.66868836484252 139.74690908650336 38.428 35.66869496041701 139.74691819236736 38.428 35.66869496041701 139.74691819236736 40.864 35.66868836484252 139.74690908650336 40.864 35.66868836484252 139.74690908650336 38.428</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3956c308-ca2b-4b7b-ac1f-ad8c2f7207ae">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3956c308-ca2b-4b7b-ac1f-ad8c2f7207ae_0">
											<gml:posList>35.66868836484252 139.74690908650336 38.428 35.66868836484252 139.74690908650336 40.864 35.66869674108344 139.7468999865939 40.864 35.66869674108344 139.7468999865939 38.428 35.66868836484252 139.74690908650336 38.428</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3bc67ce9-6139-43a0-a709-9f3c64cf2abe">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3bc67ce9-6139-43a0-a709-9f3c64cf2abe_0">
											<gml:posList>35.668699754688 139.7469293105512 38.428 35.668686781534255 139.7469134182524 38.428 35.668686781534255 139.7469134182524 40.155 35.668699754688 139.7469293105512 40.155 35.668699754688 139.7469293105512 38.428</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-58fd5b8a-5604-4dc2-a501-ba8e668bfce6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-58fd5b8a-5604-4dc2-a501-ba8e668bfce6_0">
											<gml:posList>35.668703327652814 139.74690910351384 40.864 35.66869674108344 139.7468999865939 40.864 35.66868836484252 139.74690908650336 40.864 35.66869496041701 139.74691819236736 40.864 35.668703327652814 139.74690910351384 40.864</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7291e310-4c7d-44e3-9140-0c890b3413dd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7291e310-4c7d-44e3-9140-0c890b3413dd_0">
											<gml:posList>35.66869447727273 139.74693576711837 38.428 35.668699754688 139.7469293105512 38.428 35.668699754688 139.7469293105512 40.155 35.66869447727273 139.74693576711837 40.155 35.66869447727273 139.74693576711837 38.428</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ddae14ff-68e9-4f2d-b9e2-d5df5cb77a30">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ddae14ff-68e9-4f2d-b9e2-d5df5cb77a30_0">
											<gml:posList>35.66869496041701 139.74691819236736 38.428 35.668703327652814 139.74690910351384 38.428 35.668703327652814 139.74690910351384 40.864 35.66869496041701 139.74691819236736 40.864 35.66869496041701 139.74691819236736 38.428</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5910cd93-fe72-447f-a783-2b786e20d284">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5910cd93-fe72-447f-a783-2b786e20d284_0">
											<gml:posList>35.668703327652814 139.74690910351384 38.428 35.66869674108344 139.7468999865939 38.428 35.66869674108344 139.7468999865939 40.864 35.668703327652814 139.74690910351384 40.864 35.668703327652814 139.74690910351384 38.428</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bb72a678-15c9-476b-9344-6c196ab1a468">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bb72a678-15c9-476b-9344-6c196ab1a468_0">
											<gml:posList>35.6687258336159 139.7468570303524 43.854 35.6687258336159 139.7468570303524 44.452 35.668733029157764 139.74684807530522 44.452 35.668733029157764 139.74684807530522 43.854 35.6687258336159 139.7468570303524 43.854</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-38324e7b-fa40-41ce-afdb-21c39eda0834">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-38324e7b-fa40-41ce-afdb-21c39eda0834_0">
											<gml:posList>35.6687258336159 139.7468570303524 43.854 35.668740006483006 139.74687414746595 43.854 35.668740006483006 139.74687414746595 44.452 35.6687258336159 139.7468570303524 44.452 35.6687258336159 139.7468570303524 43.854</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a0ff37ed-b1e9-40e5-9a0e-0b8888d5840e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a0ff37ed-b1e9-40e5-9a0e-0b8888d5840e_0">
											<gml:posList>35.6687472020182 139.7468651813727 44.452 35.668733029157764 139.74684807530522 44.452 35.6687258336159 139.7468570303524 44.452 35.668740006483006 139.74687414746595 44.452 35.6687472020182 139.7468651813727 44.452</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9d9f86e5-1d9c-4a62-abf8-406ca73017ea">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9d9f86e5-1d9c-4a62-abf8-406ca73017ea_0">
											<gml:posList>35.6687472020182 139.7468651813727 43.854 35.668733029157764 139.74684807530522 43.854 35.668733029157764 139.74684807530522 44.452 35.6687472020182 139.7468651813727 44.452 35.6687472020182 139.7468651813727 43.854</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7eab52fb-02ac-4f05-b8a7-93b77ccd8b49">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7eab52fb-02ac-4f05-b8a7-93b77ccd8b49_0">
											<gml:posList>35.668740006483006 139.74687414746595 43.854 35.6687472020182 139.7468651813727 43.854 35.6687472020182 139.7468651813727 44.452 35.668740006483006 139.74687414746595 44.452 35.668740006483006 139.74687414746595 43.854</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_1ef1f7e4-b934-46c4-9e23-a198cc095e9b_BuildingInstallation_1041">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8c0ca9f4-52c2-4cbc-882d-ebad7644be54">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66865109531698 139.74689968232533 38.428 35.66868511697169 139.7469426920168 38.428 35.66866871694498 139.7469621838274 38.428 35.66863468627548 139.74691916310013 38.428 35.66865109531698 139.74689968232533 38.428</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-aa964889-595f-47dc-8e05-241edaebcdc9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66875563200314 139.74675526422112 35.24 35.66876195914687 139.746754572535 35.24 35.66877237360678 139.74675957619124 35.24 35.66878239502005 139.74676952889902 35.24 35.66878994781471 139.74678107490396 35.24 35.668793920134384 139.74678980803495 35.24 35.6687944607796 139.7468021016957 35.24 35.66875563200314 139.74675526422112 35.24</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0ba1edde-ed49-4f7b-8da1-651e9d1ace37">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0ba1edde-ed49-4f7b-8da1-651e9d1ace37_0">
											<gml:posList>35.66863468627548 139.74691916310013 38.428 35.66863468627548 139.74691916310013 41.409 35.66865109531698 139.74689968232533 41.409 35.66865109531698 139.74689968232533 38.428 35.66863468627548 139.74691916310013 38.428</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-131ace5e-49ec-4f76-807c-e23ebdff9ab4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-131ace5e-49ec-4f76-807c-e23ebdff9ab4_0">
											<gml:posList>35.66863468627548 139.74691916310013 38.428 35.66866871694498 139.7469621838274 38.428 35.66866871694498 139.7469621838274 41.409 35.66863468627548 139.74691916310013 41.409 35.66863468627548 139.74691916310013 38.428</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-533ee115-40e8-42c9-90d8-dfb5f887d6a3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-533ee115-40e8-42c9-90d8-dfb5f887d6a3_0">
											<gml:posList>35.66866871694498 139.7469621838274 41.409 35.66868511697169 139.7469426920168 41.409 35.66865109531698 139.74689968232533 41.409 35.66863468627548 139.74691916310013 41.409 35.66866871694498 139.7469621838274 41.409</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4555c4ca-0096-4448-a597-eaaeae06145c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4555c4ca-0096-4448-a597-eaaeae06145c_0">
											<gml:posList>35.66868511697169 139.7469426920168 38.428 35.66865109531698 139.74689968232533 38.428 35.66865109531698 139.74689968232533 41.409 35.66868511697169 139.7469426920168 41.409 35.66868511697169 139.7469426920168 38.428</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0a213369-fcd0-468e-9d70-58c7a0ae06af">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0a213369-fcd0-468e-9d70-58c7a0ae06af_0">
											<gml:posList>35.66866871694498 139.7469621838274 38.428 35.66868511697169 139.7469426920168 38.428 35.66868511697169 139.7469426920168 41.409 35.66866871694498 139.7469621838274 41.409 35.66866871694498 139.7469621838274 38.428</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-142c9e5d-32aa-4ae3-8100-6c412aea116c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-142c9e5d-32aa-4ae3-8100-6c412aea116c_0">
											<gml:posList>35.66876195914687 139.746754572535 35.24 35.66875563200314 139.74675526422112 35.24 35.66875563200314 139.74675526422112 37.491 35.66876195914687 139.746754572535 37.491 35.66876195914687 139.746754572535 35.24</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e9c7195a-4f2c-49e8-9c89-2e0c2f5e49e3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e9c7195a-4f2c-49e8-9c89-2e0c2f5e49e3_0">
											<gml:posList>35.66877237360678 139.74675957619124 35.24 35.66876195914687 139.746754572535 35.24 35.66876195914687 139.746754572535 37.491 35.66877237360678 139.74675957619124 37.491 35.66877237360678 139.74675957619124 35.24</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1c6d5491-c97b-409b-974e-714b8f6b2a22">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1c6d5491-c97b-409b-974e-714b8f6b2a22_0">
											<gml:posList>35.668793920134384 139.74678980803495 37.491 35.66878994781471 139.74678107490396 37.491 35.66878239502005 139.74676952889902 37.491 35.66877237360678 139.74675957619124 37.491 35.66876195914687 139.746754572535 37.491 35.66875563200314 139.74675526422112 37.491 35.6687944607796 139.7468021016957 37.491 35.668793920134384 139.74678980803495 37.491</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f9bb43f5-443b-4c56-afc8-72d3770fe693">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f9bb43f5-443b-4c56-afc8-72d3770fe693_0">
											<gml:posList>35.66875563200314 139.74675526422112 35.24 35.6687944607796 139.7468021016957 35.24 35.6687944607796 139.7468021016957 37.491 35.66875563200314 139.74675526422112 37.491 35.66875563200314 139.74675526422112 35.24</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-954b7a8e-600b-401b-814c-b79691420a77">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-954b7a8e-600b-401b-814c-b79691420a77_0">
											<gml:posList>35.66878239502005 139.74676952889902 35.24 35.66877237360678 139.74675957619124 35.24 35.66877237360678 139.74675957619124 37.491 35.66878239502005 139.74676952889902 37.491 35.66878239502005 139.74676952889902 35.24</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7f74a396-f76b-48fe-be23-2ca6c257ce83">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7f74a396-f76b-48fe-be23-2ca6c257ce83_0">
											<gml:posList>35.66878239502005 139.74676952889902 35.24 35.66878239502005 139.74676952889902 37.491 35.66878994781471 139.74678107490396 37.491 35.66878994781471 139.74678107490396 35.24 35.66878239502005 139.74676952889902 35.24</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-44c362c1-be69-4ea8-9d75-e22d8224121d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-44c362c1-be69-4ea8-9d75-e22d8224121d_0">
											<gml:posList>35.668793920134384 139.74678980803495 35.24 35.66878994781471 139.74678107490396 35.24 35.66878994781471 139.74678107490396 37.491 35.668793920134384 139.74678980803495 37.491 35.668793920134384 139.74678980803495 35.24</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-dddf47e8-f5b0-417c-b771-a6e15bb5dfbf">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-dddf47e8-f5b0-417c-b771-a6e15bb5dfbf_0">
											<gml:posList>35.6687944607796 139.7468021016957 35.24 35.668793920134384 139.74678980803495 35.24 35.668793920134384 139.74678980803495 37.491 35.6687944607796 139.7468021016957 37.491 35.6687944607796 139.7468021016957 35.24</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_1ef1f7e4-b934-46c4-9e23-a198cc095e9b_BuildingInstallation_1060">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9617dd17-77a8-474b-bb06-a601dec75080">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668725690169865 139.74690832828037 38.428 35.668698733786066 139.74687580468964 38.428 35.668706469669125 139.74686617525666 38.428 35.668733426055496 139.74689869884727 38.428 35.668725690169865 139.74690832828037 38.428</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0fe1f3f5-e031-4a88-8354-4f5d951249cd">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6686997412125 139.7469733510816 5.95 35.66871500549238 139.74699153849988 5.95 35.66869605750294 139.74701512008122 5.95 35.66868036903495 139.7469961709437 5.95 35.6686997412125 139.7469733510816 5.95</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-49dd0489-f4c6-4ff9-99ee-0a1fa19fa9ba">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-49dd0489-f4c6-4ff9-99ee-0a1fa19fa9ba_0">
											<gml:posList>35.668706469669125 139.74686617525666 38.428 35.668698733786066 139.74687580468964 38.428 35.668698733786066 139.74687580468964 43.103 35.668706469669125 139.74686617525666 43.103 35.668706469669125 139.74686617525666 38.428</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2677eac2-fa43-40ae-8314-17a4af1faa83">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2677eac2-fa43-40ae-8314-17a4af1faa83_0">
											<gml:posList>35.668706469669125 139.74686617525666 43.103 35.668733426055496 139.74689869884727 43.103 35.668733426055496 139.74689869884727 38.428 35.668706469669125 139.74686617525666 38.428 35.668706469669125 139.74686617525666 43.103</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e703742d-02a8-4a20-b074-f04d42754380">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e703742d-02a8-4a20-b074-f04d42754380_0">
											<gml:posList>35.668725690169865 139.74690832828037 43.103 35.668733426055496 139.74689869884727 43.103 35.668706469669125 139.74686617525666 43.103 35.668698733786066 139.74687580468964 43.103 35.668725690169865 139.74690832828037 43.103</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d13fb2d2-eee1-4148-acae-5a16db310f51">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d13fb2d2-eee1-4148-acae-5a16db310f51_0">
											<gml:posList>35.668698733786066 139.74687580468964 38.428 35.668725690169865 139.74690832828037 38.428 35.668725690169865 139.74690832828037 43.103 35.668698733786066 139.74687580468964 43.103 35.668698733786066 139.74687580468964 38.428</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c927325a-ca7b-44f4-92fd-262e2da1e3dd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c927325a-ca7b-44f4-92fd-262e2da1e3dd_0">
											<gml:posList>35.668725690169865 139.74690832828037 38.428 35.668733426055496 139.74689869884727 38.428 35.668733426055496 139.74689869884727 43.103 35.668725690169865 139.74690832828037 43.103 35.668725690169865 139.74690832828037 38.428</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6ab86ec1-4ba8-4443-be65-ce57e7545955">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6ab86ec1-4ba8-4443-be65-ce57e7545955_0">
											<gml:posList>35.66871500549238 139.74699153849988 5.95 35.6686997412125 139.7469733510816 5.95 35.6686997412125 139.7469733510816 40.3 35.66871500549238 139.74699153849988 40.3 35.66871500549238 139.74699153849988 5.95</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-03d47ed1-59e2-4abe-a3fc-0b862b670823">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-03d47ed1-59e2-4abe-a3fc-0b862b670823_0">
											<gml:posList>35.66868036903495 139.7469961709437 5.95 35.66868036903495 139.7469961709437 40.3 35.6686997412125 139.7469733510816 40.3 35.6686997412125 139.7469733510816 5.95 35.66868036903495 139.7469961709437 5.95</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-46a287d3-24b9-45ec-adaf-d797db3460f5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-46a287d3-24b9-45ec-adaf-d797db3460f5_0">
											<gml:posList>35.66869605750294 139.74701512008122 40.3 35.66871500549238 139.74699153849988 40.3 35.6686997412125 139.7469733510816 40.3 35.66868036903495 139.7469961709437 40.3 35.66869605750294 139.74701512008122 40.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d478efe0-a192-4c95-9ae9-6468f40288a2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d478efe0-a192-4c95-9ae9-6468f40288a2_0">
											<gml:posList>35.66869605750294 139.74701512008122 5.95 35.66871500549238 139.74699153849988 5.95 35.66871500549238 139.74699153849988 40.3 35.66869605750294 139.74701512008122 40.3 35.66869605750294 139.74701512008122 5.95</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-38ed246d-0ed4-4e82-af83-dc5ac72be063">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-38ed246d-0ed4-4e82-af83-dc5ac72be063_0">
											<gml:posList>35.66869605750294 139.74701512008122 5.95 35.66869605750294 139.74701512008122 40.3 35.66868036903495 139.7469961709437 40.3 35.66868036903495 139.7469961709437 5.95 35.66869605750294 139.74701512008122 5.95</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-b879d2ab-8b22-4038-9a80-1e6bb76d4c7f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b879d2ab-8b22-4038-9a80-1e6bb76d4c7f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b879d2ab-8b22-4038-9a80-1e6bb76d4c7f">
											<gml:posList>35.6686997412125 139.7469733510816 5.95 35.66868036903495 139.7469961709437 5.95 35.66859790305469 139.7468965915502 5.95 35.668750369158424 139.7467067667618 5.95 35.66883526210525 139.7468092928245 5.95 35.668806534028214 139.74684511300498 5.95 35.66881979570931 139.7468611154657 5.95 35.66871500549238 139.74699153849988 5.95 35.6686997412125 139.7469733510816 5.95</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e2413038-a6e2-4847-9383-5202bc8a1a6f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e2413038-a6e2-4847-9383-5202bc8a1a6f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e2413038-a6e2-4847-9383-5202bc8a1a6f">
											<gml:posList>35.66860377049141 139.7468958893262 40.3 35.66866642300841 139.74681786999523 40.3 35.668663734584506 139.74681462536503 40.3 35.66859790305469 139.7468965915502 40.3 35.66860059147641 139.7468998361805 40.3 35.66860377049141 139.7468958893262 40.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-6022ea46-b576-4776-9c80-58bbd840c688">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6022ea46-b576-4776-9c80-58bbd840c688">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6022ea46-b576-4776-9c80-58bbd840c688">
											<gml:posList>35.66860377049141 139.7468958893262 38.428 35.66868057085399 139.7469885047844 38.428 35.66874325051895 139.74691055169785 38.428 35.66870240094857 139.74686126416142 38.428 35.66866642300841 139.74681786999523 38.428 35.66860377049141 139.7468958893262 38.428</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-6f70b60a-d7fd-45a3-adca-6c1ab7ca7233">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6f70b60a-d7fd-45a3-adca-6c1ab7ca7233">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6f70b60a-d7fd-45a3-adca-6c1ab7ca7233">
											<gml:posList>35.66866642300841 139.74681786999523 40.3 35.66870240094857 139.74686126416142 40.3 35.668702369227155 139.74685474703858 40.3 35.668669061673256 139.74681458647893 40.3 35.668663734584506 139.74681462536503 40.3 35.66866642300841 139.74681786999523 40.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-1e267ef9-ac9c-4f12-8d81-383c7f32e170">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1e267ef9-ac9c-4f12-8d81-383c7f32e170">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1e267ef9-ac9c-4f12-8d81-383c7f32e170">
											<gml:posList>35.668663734584506 139.74681462536503 40.3 35.668669061673256 139.74681458647893 40.3 35.66873321808657 139.74673469861708 40.3 35.66873316833086 139.74672818151126 40.3 35.668663734584506 139.74681462536503 40.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-083cbe62-71c0-4bd7-b5c0-f7bc28e41091">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-083cbe62-71c0-4bd7-b5c0-f7bc28e41091">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-083cbe62-71c0-4bd7-b5c0-f7bc28e41091">
											<gml:posList>35.668702369227155 139.74685474703858 40.3 35.66870240094857 139.74686126416142 40.3 35.668705048628304 139.74685798063535 40.3 35.668702369227155 139.74685474703858 40.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d72609d8-32b1-499c-b34b-421c15f57f4f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d72609d8-32b1-499c-b34b-421c15f57f4f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d72609d8-32b1-499c-b34b-421c15f57f4f">
											<gml:posList>35.66872811217816 139.74682926921543 46.373 35.66870575106439 139.74685709619544 46.373 35.668709089046594 139.74686113544237 46.373 35.66873145917502 139.74683330845258 46.373 35.66872811217816 139.74682926921543 46.373</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-1c1d31f4-5e65-426e-a4a1-230194e73f6d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1c1d31f4-5e65-426e-a4a1-230194e73f6d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1c1d31f4-5e65-426e-a4a1-230194e73f6d">
											<gml:posList>35.66870240094857 139.74686126416142 46.373 35.66873217206121 139.74689718689254 46.373 35.66873551317244 139.74689302998223 46.373 35.668709089046594 139.74686113544237 46.373 35.66870575106439 139.74685709619544 46.373 35.66870240094857 139.74686126416142 46.373</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-40951aac-cfdd-465b-a800-0fd79070c338">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-40951aac-cfdd-465b-a800-0fd79070c338">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-40951aac-cfdd-465b-a800-0fd79070c338">
											<gml:posList>35.66873551317244 139.74689302998223 43.854 35.66875787429443 139.74686520300187 43.854 35.66873145917502 139.74683330845258 43.854 35.668709089046594 139.74686113544237 43.854 35.66873551317244 139.74689302998223 43.854</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f47986f1-8a92-46d7-b5ae-b0ff470209ac">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f47986f1-8a92-46d7-b5ae-b0ff470209ac">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f47986f1-8a92-46d7-b5ae-b0ff470209ac">
											<gml:posList>35.66873144428127 139.74682512335826 38.273 35.66877504544012 139.74687773278484 38.273 35.66877768410654 139.74687444926607 38.273 35.66881280624915 139.7468307021979 38.273 35.66873321808657 139.74673469861708 38.273 35.668669061673256 139.74681458647893 38.273 35.668702369227155 139.74685474703858 38.273 35.668705048628304 139.74685798063535 38.273 35.66873144428127 139.74682512335826 38.273</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f139a9fc-e9d4-44cd-8fb2-61a28216d040">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f139a9fc-e9d4-44cd-8fb2-61a28216d040">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f139a9fc-e9d4-44cd-8fb2-61a28216d040">
											<gml:posList>35.66875042044884 139.74671541575222 35.699 35.668750369158424 139.7467067667618 35.699 35.66873316833086 139.74672818151126 35.699 35.6687367318353 139.74673246352333 35.699 35.66875042044884 139.74671541575222 35.699</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-5442bf15-1ca5-48ea-a1b8-108699950d4d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5442bf15-1ca5-48ea-a1b8-108699950d4d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5442bf15-1ca5-48ea-a1b8-108699950d4d">
											<gml:posList>35.66876121540456 139.74686104608892 46.373 35.66873144428127 139.74682512335826 46.373 35.66872811217816 139.74682926921543 46.373 35.66873145917502 139.74683330845258 46.373 35.66875787429443 139.74686520300187 46.373 35.66876121540456 139.74686104608892 46.373</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-feb59b81-fe0a-43c0-9cf3-500d7c13c18a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-feb59b81-fe0a-43c0-9cf3-500d7c13c18a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-feb59b81-fe0a-43c0-9cf3-500d7c13c18a">
											<gml:posList>35.66873891428917 139.74689712439428 46.373 35.66876127541208 139.74686929741387 46.373 35.66876121540456 139.74686104608892 46.373 35.66875787429443 139.74686520300187 46.373 35.66873551317244 139.74689302998223 46.373 35.66873217206121 139.74689718689254 46.373 35.66873891428917 139.74689712439428 46.373</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-fba06175-76a8-4a7e-b51a-e361e7d1b25d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fba06175-76a8-4a7e-b51a-e361e7d1b25d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fba06175-76a8-4a7e-b51a-e361e7d1b25d">
											<gml:posList>35.668784253302825 139.74689703133484 45.951 35.66876127541208 139.74686929741387 45.951 35.66873891428917 139.74689712439428 45.951 35.66876189217359 139.7469248583155 45.951 35.668784253302825 139.74689703133484 45.951</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-50e2c821-3d36-499f-84c7-1781bb4b6f18">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-50e2c821-3d36-499f-84c7-1781bb4b6f18">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-50e2c821-3d36-499f-84c7-1781bb4b6f18">
											<gml:posList>35.66873316833086 139.74672818151126 40.3 35.66873321808657 139.74673469861708 40.3 35.66881280624915 139.7468307021979 40.3 35.66881813332983 139.74683065226674 40.3 35.66873316833086 139.74672818151126 40.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-37482c29-45a1-4579-9cde-45e59e0fabab">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-37482c29-45a1-4579-9cde-45e59e0fabab">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-37482c29-45a1-4579-9cde-45e59e0fabab">
											<gml:posList>35.66876121540456 139.74686104608892 46.373 35.66876127541208 139.74686929741387 46.373 35.668784253302825 139.74689703133484 46.373 35.66879098651701 139.74689696884624 46.373 35.66876121540456 139.74686104608892 46.373</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-de66dbbf-bb5d-44ee-9626-7f62c0d0c669">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-de66dbbf-bb5d-44ee-9626-7f62c0d0c669">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-de66dbbf-bb5d-44ee-9626-7f62c0d0c669">
											<gml:posList>35.66877504544012 139.74687773278484 40.3 35.668777724840616 139.74688096638533 40.3 35.66877768410654 139.74687444926607 40.3 35.66877504544012 139.74687773278484 40.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-77e5be66-8f75-48f5-98f1-f23976083873">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-77e5be66-8f75-48f5-98f1-f23976083873">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-77e5be66-8f75-48f5-98f1-f23976083873">
											<gml:posList>35.6687367318353 139.74673246352333 35.24 35.66881456982097 139.7468263591999 35.24 35.66882820439702 139.74680935567068 35.24 35.66875042044884 139.74671541575222 35.24 35.6687367318353 139.74673246352333 35.24</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-2500c5c7-1633-4120-b228-6f5aa6545d23">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2500c5c7-1633-4120-b228-6f5aa6545d23">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2500c5c7-1633-4120-b228-6f5aa6545d23">
											<gml:posList>35.668750369158424 139.7467067667618 35.699 35.66875042044884 139.74671541575222 35.699 35.66882820439702 139.74680935567068 35.699 35.66883526210525 139.7468092928245 35.699 35.668750369158424 139.7467067667618 35.699</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-3a1f2d08-35d7-4c4f-9aef-903b83900d72">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3a1f2d08-35d7-4c4f-9aef-903b83900d72">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3a1f2d08-35d7-4c4f-9aef-903b83900d72">
											<gml:posList>35.66881813332983 139.74683065226674 40.3 35.66881280624915 139.7468307021979 40.3 35.66877768410654 139.74687444926607 40.3 35.668777724840616 139.74688096638533 40.3 35.66881813332983 139.74683065226674 40.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-6f82dda7-0814-4618-b0f8-44efe0fc8fc2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6f82dda7-0814-4618-b0f8-44efe0fc8fc2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6f82dda7-0814-4618-b0f8-44efe0fc8fc2">
											<gml:posList>35.66881979570931 139.7468611154657 38.7 35.668806534028214 139.74684511300498 38.7 35.668777724840616 139.74688096638533 38.7 35.66879098651701 139.74689696884624 38.7 35.66881979570931 139.7468611154657 38.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e795ae3f-6ca5-4b0b-8ac3-d2fb56ae72c5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e795ae3f-6ca5-4b0b-8ac3-d2fb56ae72c5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e795ae3f-6ca5-4b0b-8ac3-d2fb56ae72c5">
											<gml:posList>35.66882820439702 139.74680935567068 35.699 35.66881456982097 139.7468263591999 35.699 35.66881813332983 139.74683065226674 35.699 35.66883526210525 139.7468092928245 35.699 35.66882820439702 139.74680935567068 35.699</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ae536392-6879-406b-abff-102f86e6f72a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ae536392-6879-406b-abff-102f86e6f72a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ae536392-6879-406b-abff-102f86e6f72a">
											<gml:posList>35.66860059147641 139.7468998361805 40.3 35.668677337801164 139.74699251797318 40.3 35.66868057085399 139.7469885047844 40.3 35.66860377049141 139.7468958893262 40.3 35.66860059147641 139.7468998361805 40.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-21348adf-9772-402b-bd01-b7185b3002e3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-21348adf-9772-402b-bd01-b7185b3002e3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-21348adf-9772-402b-bd01-b7185b3002e3">
											<gml:posList>35.66868057085399 139.7469885047844 40.3 35.668677337801164 139.74699251797318 40.3 35.66868036903495 139.7469961709437 40.3 35.6686997412125 139.7469733510816 40.3 35.668746777946154 139.74691481166545 40.3 35.66874325051895 139.74691055169785 40.3 35.66868057085399 139.7469885047844 40.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-656dd08e-ae9b-4792-8bcd-f12c25f7eb0d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-656dd08e-ae9b-4792-8bcd-f12c25f7eb0d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-656dd08e-ae9b-4792-8bcd-f12c25f7eb0d">
											<gml:posList>35.66871500549238 139.74699153849988 38.7 35.66876194316302 139.7469331096503 38.7 35.668746777946154 139.74691481166545 38.7 35.6686997412125 139.7469733510816 38.7 35.66871500549238 139.74699153849988 38.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-9d717d37-1421-444d-b973-ac7e9f403ae7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9d717d37-1421-444d-b973-ac7e9f403ae7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9d717d37-1421-444d-b973-ac7e9f403ae7">
											<gml:posList>35.66876194316302 139.7469331096503 46.373 35.66876189217359 139.7469248583155 46.373 35.66873891428917 139.74689712439428 46.373 35.66873217206121 139.74689718689254 46.373 35.66876194316302 139.7469331096503 46.373</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-1308c4ed-5281-434f-82cf-6e3cc555d697">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1308c4ed-5281-434f-82cf-6e3cc555d697">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1308c4ed-5281-434f-82cf-6e3cc555d697">
											<gml:posList>35.66879098651701 139.74689696884624 46.373 35.668784253302825 139.74689703133484 46.373 35.66876189217359 139.7469248583155 46.373 35.66876194316302 139.7469331096503 46.373 35.66879098651701 139.74689696884624 46.373</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-20ed1ab4-0a68-4d46-9f43-81440d7bb0d3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-20ed1ab4-0a68-4d46-9f43-81440d7bb0d3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-20ed1ab4-0a68-4d46-9f43-81440d7bb0d3">
											<gml:posList>35.668709089046594 139.74686113544237 46.373 35.668709089046594 139.74686113544237 43.854 35.66873145917502 139.74683330845258 43.854 35.66873145917502 139.74683330845258 46.373 35.668709089046594 139.74686113544237 46.373</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7c232b12-e8bc-48b3-92e3-e74e44f55ba9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7c232b12-e8bc-48b3-92e3-e74e44f55ba9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7c232b12-e8bc-48b3-92e3-e74e44f55ba9">
											<gml:posList>35.66873551317244 139.74689302998223 46.373 35.66873551317244 139.74689302998223 43.854 35.668709089046594 139.74686113544237 43.854 35.668709089046594 139.74686113544237 46.373 35.66873551317244 139.74689302998223 46.373</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-56e847a4-1101-4442-811e-49d0562d59fe">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-56e847a4-1101-4442-811e-49d0562d59fe">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-56e847a4-1101-4442-811e-49d0562d59fe">
											<gml:posList>35.66873145917502 139.74683330845258 46.373 35.66873145917502 139.74683330845258 43.854 35.66875787429443 139.74686520300187 43.854 35.66875787429443 139.74686520300187 46.373 35.66873145917502 139.74683330845258 46.373</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-00b282d6-ee6d-49ef-9fd1-a7761a87681b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-00b282d6-ee6d-49ef-9fd1-a7761a87681b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-00b282d6-ee6d-49ef-9fd1-a7761a87681b">
											<gml:posList>35.66873891428917 139.74689712439428 46.373 35.66873891428917 139.74689712439428 45.951 35.66876127541208 139.74686929741387 45.951 35.66876127541208 139.74686929741387 46.373 35.66873891428917 139.74689712439428 46.373</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9eb00c27-e380-4e6b-9a72-300f8656addd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9eb00c27-e380-4e6b-9a72-300f8656addd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9eb00c27-e380-4e6b-9a72-300f8656addd">
											<gml:posList>35.66876189217359 139.7469248583155 46.373 35.66876189217359 139.7469248583155 45.951 35.66873891428917 139.74689712439428 45.951 35.66873891428917 139.74689712439428 46.373 35.66876189217359 139.7469248583155 46.373</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9576a546-2a50-436d-8959-b78ce4f7f5cb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9576a546-2a50-436d-8959-b78ce4f7f5cb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9576a546-2a50-436d-8959-b78ce4f7f5cb">
											<gml:posList>35.66876127541208 139.74686929741387 46.373 35.66876127541208 139.74686929741387 45.951 35.668784253302825 139.74689703133484 45.951 35.668784253302825 139.74689703133484 46.373 35.66876127541208 139.74686929741387 46.373</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ea2b04eb-ba5e-4f3e-8d85-32f779c614ec">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ea2b04eb-ba5e-4f3e-8d85-32f779c614ec">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ea2b04eb-ba5e-4f3e-8d85-32f779c614ec">
											<gml:posList>35.6687367318353 139.74673246352333 35.699 35.6687367318353 139.74673246352333 35.24 35.66875042044884 139.74671541575222 35.24 35.66875042044884 139.74671541575222 35.699 35.6687367318353 139.74673246352333 35.699</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-05affa6c-1771-4e77-9220-a7e86bd98647">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-05affa6c-1771-4e77-9220-a7e86bd98647">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-05affa6c-1771-4e77-9220-a7e86bd98647">
											<gml:posList>35.66883526210525 139.7468092928245 5.95 35.668750369158424 139.7467067667618 5.95 35.668750369158424 139.7467067667618 35.699 35.66883526210525 139.7468092928245 35.699 35.66883526210525 139.7468092928245 5.95</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1d950a81-ab1f-4d9b-bb8c-1496671d2067">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1d950a81-ab1f-4d9b-bb8c-1496671d2067">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1d950a81-ab1f-4d9b-bb8c-1496671d2067">
											<gml:posList>35.66875042044884 139.74671541575222 35.699 35.66875042044884 139.74671541575222 35.24 35.66882820439702 139.74680935567068 35.24 35.66882820439702 139.74680935567068 35.699 35.66875042044884 139.74671541575222 35.699</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-fa0c7452-9a75-42f6-b9ee-4a58d0fa4ca6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fa0c7452-9a75-42f6-b9ee-4a58d0fa4ca6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fa0c7452-9a75-42f6-b9ee-4a58d0fa4ca6">
											<gml:posList>35.668669061673256 139.74681458647893 40.3 35.668669061673256 139.74681458647893 38.273 35.66873321808657 139.74673469861708 38.273 35.66873321808657 139.74673469861708 40.3 35.668669061673256 139.74681458647893 40.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-847141ae-6887-471b-a12f-497f3d72cf71">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-847141ae-6887-471b-a12f-497f3d72cf71">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-847141ae-6887-471b-a12f-497f3d72cf71">
											<gml:posList>35.66873316833086 139.74672818151126 40.3 35.66881813332983 139.74683065226674 40.3 35.66881813332983 139.74683065226674 35.699 35.66881456982097 139.7468263591999 35.699 35.66881456982097 139.7468263591999 35.24 35.6687367318353 139.74673246352333 35.24 35.6687367318353 139.74673246352333 35.699 35.66873316833086 139.74672818151126 35.699 35.66873316833086 139.74672818151126 40.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9cf066cf-f883-466e-a965-868ae6383366">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9cf066cf-f883-466e-a965-868ae6383366">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9cf066cf-f883-466e-a965-868ae6383366">
											<gml:posList>35.66873321808657 139.74673469861708 40.3 35.66873321808657 139.74673469861708 38.273 35.66881280624915 139.7468307021979 38.273 35.66881280624915 139.7468307021979 40.3 35.66873321808657 139.74673469861708 40.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e58d8f49-fede-448b-b839-bc778abc4ce1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e58d8f49-fede-448b-b839-bc778abc4ce1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e58d8f49-fede-448b-b839-bc778abc4ce1">
											<gml:posList>35.668663734584506 139.74681462536503 40.3 35.66873316833086 139.74672818151126 40.3 35.66873316833086 139.74672818151126 35.699 35.668750369158424 139.7467067667618 35.699 35.668750369158424 139.7467067667618 5.95 35.66859790305469 139.7468965915502 5.95 35.66859790305469 139.7468965915502 40.3 35.668663734584506 139.74681462536503 40.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-228b6947-3af2-4835-8b8e-1ce5d5934a8a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-228b6947-3af2-4835-8b8e-1ce5d5934a8a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-228b6947-3af2-4835-8b8e-1ce5d5934a8a">
											<gml:posList>35.66882820439702 139.74680935567068 35.699 35.66882820439702 139.74680935567068 35.24 35.66881456982097 139.7468263591999 35.24 35.66881456982097 139.7468263591999 35.699 35.66882820439702 139.74680935567068 35.699</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-81e8d6aa-8568-4467-b9a9-6d4756fa3468">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-81e8d6aa-8568-4467-b9a9-6d4756fa3468">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-81e8d6aa-8568-4467-b9a9-6d4756fa3468">
											<gml:posList>35.668702369227155 139.74685474703858 40.3 35.668702369227155 139.74685474703858 38.273 35.668669061673256 139.74681458647893 38.273 35.668669061673256 139.74681458647893 40.3 35.668702369227155 139.74685474703858 40.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-540fc6f8-5092-4d96-9dc9-ee1f3649b540">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-540fc6f8-5092-4d96-9dc9-ee1f3649b540">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-540fc6f8-5092-4d96-9dc9-ee1f3649b540">
											<gml:posList>35.66866642300841 139.74681786999523 40.3 35.66866642300841 139.74681786999523 38.428 35.66870240094857 139.74686126416142 38.428 35.66870240094857 139.74686126416142 40.3 35.66866642300841 139.74681786999523 40.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-61325a52-783c-4edc-ab3d-77d4e918843f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-61325a52-783c-4edc-ab3d-77d4e918843f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-61325a52-783c-4edc-ab3d-77d4e918843f">
											<gml:posList>35.668705048628304 139.74685798063535 40.3 35.66870240094857 139.74686126416142 40.3 35.66870240094857 139.74686126416142 46.373 35.66870575106439 139.74685709619544 46.373 35.66872811217816 139.74682926921543 46.373 35.66873144428127 139.74682512335826 46.373 35.66873144428127 139.74682512335826 38.273 35.668705048628304 139.74685798063535 38.273 35.668705048628304 139.74685798063535 40.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-09d5f34f-4475-4a6c-b654-2a7749d99123">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-09d5f34f-4475-4a6c-b654-2a7749d99123">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-09d5f34f-4475-4a6c-b654-2a7749d99123">
											<gml:posList>35.66883526210525 139.7468092928245 5.95 35.66883526210525 139.7468092928245 35.699 35.66881813332983 139.74683065226674 35.699 35.66881813332983 139.74683065226674 40.3 35.668777724840616 139.74688096638533 40.3 35.668777724840616 139.74688096638533 38.7 35.668806534028214 139.74684511300498 38.7 35.668806534028214 139.74684511300498 5.95 35.66883526210525 139.7468092928245 5.95</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9da7b723-10f2-4720-9ca9-6a7282981c66">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9da7b723-10f2-4720-9ca9-6a7282981c66">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9da7b723-10f2-4720-9ca9-6a7282981c66">
											<gml:posList>35.66881280624915 139.7468307021979 40.3 35.66881280624915 139.7468307021979 38.273 35.66877768410654 139.74687444926607 38.273 35.66877768410654 139.74687444926607 40.3 35.66881280624915 139.7468307021979 40.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6674728c-4e3f-41f4-ab36-9143a98f4434">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6674728c-4e3f-41f4-ab36-9143a98f4434">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6674728c-4e3f-41f4-ab36-9143a98f4434">
											<gml:posList>35.66881979570931 139.7468611154657 5.95 35.668806534028214 139.74684511300498 5.95 35.668806534028214 139.74684511300498 38.7 35.66881979570931 139.7468611154657 38.7 35.66881979570931 139.7468611154657 5.95</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b5d7be8a-07f1-42bc-8cf6-eed6f8912526">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b5d7be8a-07f1-42bc-8cf6-eed6f8912526">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b5d7be8a-07f1-42bc-8cf6-eed6f8912526">
											<gml:posList>35.668705048628304 139.74685798063535 40.3 35.668705048628304 139.74685798063535 38.273 35.668702369227155 139.74685474703858 38.273 35.668702369227155 139.74685474703858 40.3 35.668705048628304 139.74685798063535 40.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-63548672-ac92-4a35-b22d-d5550f88f2fd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-63548672-ac92-4a35-b22d-d5550f88f2fd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-63548672-ac92-4a35-b22d-d5550f88f2fd">
											<gml:posList>35.66860377049141 139.7468958893262 40.3 35.66860377049141 139.7468958893262 38.428 35.66866642300841 139.74681786999523 38.428 35.66866642300841 139.74681786999523 40.3 35.66860377049141 139.7468958893262 40.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c5d03d71-929b-4eca-8a9a-67a4f7377cb0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c5d03d71-929b-4eca-8a9a-67a4f7377cb0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c5d03d71-929b-4eca-8a9a-67a4f7377cb0">
											<gml:posList>35.66879098651701 139.74689696884624 38.7 35.668777724840616 139.74688096638533 38.7 35.668777724840616 139.74688096638533 40.3 35.66877504544012 139.74687773278484 40.3 35.66877504544012 139.74687773278484 38.273 35.66873144428127 139.74682512335826 38.273 35.66873144428127 139.74682512335826 46.373 35.66876121540456 139.74686104608892 46.373 35.66879098651701 139.74689696884624 46.373 35.66879098651701 139.74689696884624 38.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7edbdf66-1f67-4c9e-a245-0e171a352887">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7edbdf66-1f67-4c9e-a245-0e171a352887">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7edbdf66-1f67-4c9e-a245-0e171a352887">
											<gml:posList>35.66877768410654 139.74687444926607 40.3 35.66877768410654 139.74687444926607 38.273 35.66877504544012 139.74687773278484 38.273 35.66877504544012 139.74687773278484 40.3 35.66877768410654 139.74687444926607 40.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-030288d6-812f-4a0c-891e-c4c079284fef">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-030288d6-812f-4a0c-891e-c4c079284fef">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-030288d6-812f-4a0c-891e-c4c079284fef">
											<gml:posList>35.66875787429443 139.74686520300187 46.373 35.66875787429443 139.74686520300187 43.854 35.66873551317244 139.74689302998223 43.854 35.66873551317244 139.74689302998223 46.373 35.66875787429443 139.74686520300187 46.373</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9418cd5d-faf1-4f0f-90f4-0404afe5baed">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9418cd5d-faf1-4f0f-90f4-0404afe5baed">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9418cd5d-faf1-4f0f-90f4-0404afe5baed">
											<gml:posList>35.66870240094857 139.74686126416142 40.3 35.66870240094857 139.74686126416142 38.428 35.66874325051895 139.74691055169785 38.428 35.66874325051895 139.74691055169785 40.3 35.668746777946154 139.74691481166545 40.3 35.668746777946154 139.74691481166545 38.7 35.66876194316302 139.7469331096503 38.7 35.66876194316302 139.7469331096503 46.373 35.66873217206121 139.74689718689254 46.373 35.66870240094857 139.74686126416142 46.373 35.66870240094857 139.74686126416142 40.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-52dbcb28-0058-4865-a453-2db1eafc162b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-52dbcb28-0058-4865-a453-2db1eafc162b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-52dbcb28-0058-4865-a453-2db1eafc162b">
											<gml:posList>35.668784253302825 139.74689703133484 46.373 35.668784253302825 139.74689703133484 45.951 35.66876189217359 139.7469248583155 45.951 35.66876189217359 139.7469248583155 46.373 35.668784253302825 139.74689703133484 46.373</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-02db16f6-06b5-4cd3-9806-2527d0a9bcca">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-02db16f6-06b5-4cd3-9806-2527d0a9bcca">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-02db16f6-06b5-4cd3-9806-2527d0a9bcca">
											<gml:posList>35.66879098651701 139.74689696884624 38.7 35.66879098651701 139.74689696884624 46.373 35.66876194316302 139.7469331096503 46.373 35.66876194316302 139.7469331096503 38.7 35.66871500549238 139.74699153849988 38.7 35.66871500549238 139.74699153849988 5.95 35.66881979570931 139.7468611154657 5.95 35.66881979570931 139.7468611154657 38.7 35.66879098651701 139.74689696884624 38.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-df57aae5-acc6-4811-a4fc-bcc34a0ac042">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-df57aae5-acc6-4811-a4fc-bcc34a0ac042">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-df57aae5-acc6-4811-a4fc-bcc34a0ac042">
											<gml:posList>35.66868057085399 139.7469885047844 40.3 35.66868057085399 139.7469885047844 38.428 35.66860377049141 139.7468958893262 38.428 35.66860377049141 139.7468958893262 40.3 35.66868057085399 139.7469885047844 40.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-cf4d812b-b347-4ae8-aece-b23ff1bdeeb9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cf4d812b-b347-4ae8-aece-b23ff1bdeeb9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cf4d812b-b347-4ae8-aece-b23ff1bdeeb9">
											<gml:posList>35.668746777946154 139.74691481166545 40.3 35.6686997412125 139.7469733510816 40.3 35.6686997412125 139.7469733510816 38.7 35.668746777946154 139.74691481166545 38.7 35.668746777946154 139.74691481166545 40.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f094186c-f0a9-4282-b390-9b54c0f68176">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f094186c-f0a9-4282-b390-9b54c0f68176">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f094186c-f0a9-4282-b390-9b54c0f68176">
											<gml:posList>35.66859790305469 139.7468965915502 5.95 35.66868036903495 139.7469961709437 5.95 35.66868036903495 139.7469961709437 40.3 35.668677337801164 139.74699251797318 40.3 35.66860059147641 139.7468998361805 40.3 35.66859790305469 139.7468965915502 40.3 35.66859790305469 139.7468965915502 5.95</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6efed1b7-fbd3-4af2-8655-bf526c28ad91">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6efed1b7-fbd3-4af2-8655-bf526c28ad91">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6efed1b7-fbd3-4af2-8655-bf526c28ad91">
											<gml:posList>35.66874325051895 139.74691055169785 40.3 35.66874325051895 139.74691055169785 38.428 35.66868057085399 139.7469885047844 38.428 35.66868057085399 139.7469885047844 40.3 35.66874325051895 139.74691055169785 40.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-345906d7-84df-4d6e-8ab5-717fbf7a75b6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-345906d7-84df-4d6e-8ab5-717fbf7a75b6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-345906d7-84df-4d6e-8ab5-717fbf7a75b6">
											<gml:posList>35.6686997412125 139.7469733510816 5.95 35.66871500549238 139.74699153849988 5.95 35.66871500549238 139.74699153849988 38.7 35.6686997412125 139.7469733510816 38.7 35.6686997412125 139.7469733510816 5.95</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9e59db8e-f0d5-4af8-b06f-e26e16cac47b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9e59db8e-f0d5-4af8-b06f-e26e16cac47b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9e59db8e-f0d5-4af8-b06f-e26e16cac47b">
											<gml:posList>35.66868036903495 139.7469961709437 40.3 35.66868036903495 139.7469961709437 5.95 35.6686997412125 139.7469733510816 5.95 35.6686997412125 139.7469733510816 38.7 35.6686997412125 139.7469733510816 40.3 35.66868036903495 139.7469961709437 40.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区虎ノ門二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-4525</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">359.28405</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1210</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>6</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.09</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>