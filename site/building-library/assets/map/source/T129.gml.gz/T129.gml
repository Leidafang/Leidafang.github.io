<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_227c4f88-07c7-4d44-ad2c-784844943ae9">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">413</bldg:usage>
			<bldg:measuredHeight uom="m">25</bldg:measuredHeight>
			<bldg:storeysAboveGround>2</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.67045142551249 139.7414570671467 0 35.67044720075075 139.74159062137753 0 35.67049737358118 139.74159377843355 0 35.67049914405188 139.7415514249858 0 35.67052081410232 139.74155279201037 0 35.670523268422976 139.7414616242581 0 35.67045142551249 139.7414570671467 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67045142551249 139.7414570671467 8.57 35.670523268422976 139.7414616242581 8.57 35.67052081410232 139.74155279201037 8.57 35.67049914405188 139.7415514249858 8.57 35.67049737358118 139.74159377843355 8.57 35.67044720075075 139.74159062137753 8.57 35.67045142551249 139.7414570671467 8.57</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67045142551249 139.7414570671467 8.57 35.67044720075075 139.74159062137753 8.57 35.67044720075075 139.74159062137753 33.55 35.67045142551249 139.7414570671467 33.55 35.67045142551249 139.7414570671467 8.57</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67044720075075 139.74159062137753 8.57 35.67049737358118 139.74159377843355 8.57 35.67049737358118 139.74159377843355 33.55 35.67044720075075 139.74159062137753 33.55 35.67044720075075 139.74159062137753 8.57</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67049737358118 139.74159377843355 8.57 35.67049914405188 139.7415514249858 8.57 35.67049914405188 139.7415514249858 33.55 35.67049737358118 139.74159377843355 33.55 35.67049737358118 139.74159377843355 8.57</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67049914405188 139.7415514249858 8.57 35.67052081410232 139.74155279201037 8.57 35.67052081410232 139.74155279201037 33.55 35.67049914405188 139.7415514249858 33.55 35.67049914405188 139.7415514249858 8.57</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67052081410232 139.74155279201037 8.57 35.670523268422976 139.7414616242581 8.57 35.670523268422976 139.7414616242581 33.55 35.67052081410232 139.74155279201037 33.55 35.67052081410232 139.74155279201037 8.57</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670523268422976 139.7414616242581 8.57 35.67045142551249 139.7414570671467 8.57 35.67045142551249 139.7414570671467 33.55 35.670523268422976 139.7414616242581 33.55 35.670523268422976 139.7414616242581 8.57</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67045142551249 139.7414570671467 33.55 35.67044720075075 139.74159062137753 33.55 35.67049737358118 139.74159377843355 33.55 35.67049914405188 139.7415514249858 33.55 35.67052081410232 139.74155279201037 33.55 35.670523268422976 139.7414616242581 33.55 35.67045142551249 139.7414570671467 33.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-0ef7cf4a-9898-4b26-9a65-ba5cbd080462"/>
							<gml:surfaceMember xlink:href="#poly-c98db661-b3d2-4c39-a6fc-95779125025e"/>
							<gml:surfaceMember xlink:href="#poly-01187d9c-6312-4bed-a67f-d40b2ea93d15"/>
							<gml:surfaceMember xlink:href="#poly-ad3b98be-f3b9-48b7-99d4-19e2c95fe425"/>
							<gml:surfaceMember xlink:href="#poly-da720760-429a-4c11-b881-e2864b4a5fa5"/>
							<gml:surfaceMember xlink:href="#poly-5632405b-6565-41b0-be56-041afe4d3d91"/>
							<gml:surfaceMember xlink:href="#poly-ada83739-2a97-4e69-823f-f4732ab630a8"/>
							<gml:surfaceMember xlink:href="#poly-10c6cfe9-ddd5-4480-96d1-191df89a9549"/>
							<gml:surfaceMember xlink:href="#poly-ca2723b6-abe4-41ee-919e-6e5b2e65b7a0"/>
							<gml:surfaceMember xlink:href="#poly-872f319e-d40e-493c-a0f9-8cc378612bfd"/>
							<gml:surfaceMember xlink:href="#poly-a492c6e8-6982-44b8-be7a-bd4024d01477"/>
							<gml:surfaceMember xlink:href="#poly-e9f6d312-189c-4d71-b7d6-2a6f34019119"/>
							<gml:surfaceMember xlink:href="#poly-7d7b8234-a9e8-4d02-95b4-a2ee648eba48"/>
							<gml:surfaceMember xlink:href="#poly-99052dee-0b0e-41b8-b3d3-9b964898689a"/>
							<gml:surfaceMember xlink:href="#poly-399115d7-f882-4bd9-bbbb-7bef960a32dc"/>
							<gml:surfaceMember xlink:href="#poly-33a31f37-e382-4a2a-893c-d183809d6f71"/>
							<gml:surfaceMember xlink:href="#poly-4da401dd-d3a7-4d86-b88f-1aa04fd9e35b"/>
							<gml:surfaceMember xlink:href="#poly-b4ae3cae-3bc9-4935-9712-4ae2fba337e6"/>
							<gml:surfaceMember xlink:href="#poly-087784a0-e3b9-454a-b3af-523643540fa7"/>
							<gml:surfaceMember xlink:href="#poly-e3dd7b52-74af-4a65-aa90-06c4927fcecb"/>
							<gml:surfaceMember xlink:href="#poly-ecab22df-d509-4754-8cf7-307c7530ef1f"/>
							<gml:surfaceMember xlink:href="#poly-7e144d83-236a-4d7e-a492-e4683c57717b"/>
							<gml:surfaceMember xlink:href="#poly-550b8baa-9b70-4646-827d-538e947c75d2"/>
							<gml:surfaceMember xlink:href="#poly-46671c35-255d-4975-8ed9-576d5942a8e4"/>
							<gml:surfaceMember xlink:href="#poly-dbac7b21-446e-46dd-8f97-cee02b2aaf34"/>
							<gml:surfaceMember xlink:href="#poly-18788262-a5de-4431-a00f-b9e34217ade8"/>
							<gml:surfaceMember xlink:href="#poly-c778686f-d1b6-4df3-b88e-9869e3378be8"/>
							<gml:surfaceMember xlink:href="#poly-96260695-08f5-4191-ab3d-bc5c319b7ff3"/>
							<gml:surfaceMember xlink:href="#poly-c2aa1a88-d1dd-4d22-8ced-cd00aed54441"/>
							<gml:surfaceMember xlink:href="#poly-97144dcf-0592-499d-be65-944a664bdafd"/>
							<gml:surfaceMember xlink:href="#poly-70c8af0e-2905-493f-9913-af09f9c0f5f5"/>
							<gml:surfaceMember xlink:href="#poly-be559886-fc26-4b7b-aa99-732816f8541a"/>
							<gml:surfaceMember xlink:href="#poly-3b9d8121-0700-4c1e-8a13-4288364c375b"/>
							<gml:surfaceMember xlink:href="#poly-8f14597d-acd6-4ece-aa40-2b4261d7c5d5"/>
							<gml:surfaceMember xlink:href="#poly-a5f4718f-f7d8-4edf-a1df-83f3a402eec9"/>
							<gml:surfaceMember xlink:href="#poly-dfb6b00b-ba59-45fd-ab83-1431fcfc584c"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_227c4f88-07c7-4d44-ad2c-784844943ae9_BuildingInstallation_1060">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ca38c971-8e95-45cd-90dc-724137ae7845">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67049794803482 139.74154328524966 34.531 35.670481929866284 139.74154227628446 34.531 35.67047434895488 139.74154179892747 34.531 35.67047484468744 139.74152994570943 34.531 35.6704984437591 139.7415314209819 34.531 35.67049794803482 139.74154328524966 34.531</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c637d2a6-e18f-47b3-b7f1-00ab285dd028">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670519674617 139.7415951778864 8.57 35.67049737358117 139.74159377843355 8.57 35.67049914405186 139.74155142498577 8.57 35.670520814102304 139.74155279201037 8.57 35.670519674617 139.7415951778864 8.57</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e1280b5b-068a-455e-8082-1aebd71a0437">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e1280b5b-068a-455e-8082-1aebd71a0437_0">
											<gml:posList>35.67047484468744 139.74152994570943 34.531 35.67047484468744 139.74152994570943 35.091 35.6704984437591 139.7415314209819 35.091 35.6704984437591 139.7415314209819 34.531 35.67047484468744 139.74152994570943 34.531</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2c64e689-cf88-40b8-8159-dc0c2b8b2e74">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2c64e689-cf88-40b8-8159-dc0c2b8b2e74_0">
											<gml:posList>35.67047434895488 139.74154179892747 35.091 35.67047484468744 139.74152994570943 35.091 35.67047484468744 139.74152994570943 34.531 35.67047434895488 139.74154179892747 34.531 35.67047434895488 139.74154179892747 35.091</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d67e017e-c500-4987-8862-48283993415d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d67e017e-c500-4987-8862-48283993415d_0">
											<gml:posList>35.67047484468744 139.74152994570943 35.091 35.67047434895488 139.74154179892747 35.091 35.670481929866284 139.74154227628446 35.091 35.67049794803482 139.74154328524966 35.091 35.6704984437591 139.7415314209819 35.091 35.67047484468744 139.74152994570943 35.091</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c697fd79-bac1-450d-8293-182ff69be805">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c697fd79-bac1-450d-8293-182ff69be805_0">
											<gml:posList>35.6704984437591 139.7415314209819 34.531 35.6704984437591 139.7415314209819 35.091 35.67049794803482 139.74154328524966 35.091 35.67049794803482 139.74154328524966 34.531 35.6704984437591 139.7415314209819 34.531</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f56cf44e-d217-4a41-8038-c60fe14163ac">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f56cf44e-d217-4a41-8038-c60fe14163ac_0">
											<gml:posList>35.67047434895488 139.74154179892747 35.091 35.67047434895488 139.74154179892747 34.531 35.670481929866284 139.74154227628446 34.531 35.670481929866284 139.74154227628446 35.091 35.67047434895488 139.74154179892747 35.091</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ef8eef25-e3d2-48fc-b725-0d72e1466f59">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ef8eef25-e3d2-48fc-b725-0d72e1466f59_0">
											<gml:posList>35.67049794803482 139.74154328524966 34.531 35.67049794803482 139.74154328524966 35.091 35.670481929866284 139.74154227628446 35.091 35.670481929866284 139.74154227628446 34.531 35.67049794803482 139.74154328524966 34.531</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6e342d4a-9032-497b-bb82-17f6b1fadd82">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6e342d4a-9032-497b-bb82-17f6b1fadd82_0">
											<gml:posList>35.670520814102304 139.74155279201037 36.333 35.670520814102304 139.74155279201037 8.57 35.67049914405186 139.74155142498577 8.57 35.67049914405186 139.74155142498577 36.333 35.670520814102304 139.74155279201037 36.333</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a42c9b13-98e6-492d-bc55-d8bf60895418">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a42c9b13-98e6-492d-bc55-d8bf60895418_0">
											<gml:posList>35.67049914405186 139.74155142498577 36.333 35.67049914405186 139.74155142498577 8.57 35.67049737358117 139.74159377843355 8.57 35.67049737358117 139.74159377843355 36.333 35.67049914405186 139.74155142498577 36.333</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-62aa39a3-7bba-4aea-b355-9c899cdd0c73">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-62aa39a3-7bba-4aea-b355-9c899cdd0c73_0">
											<gml:posList>35.670519674617 139.7415951778864 36.333 35.670520814102304 139.74155279201037 36.333 35.67049914405186 139.74155142498577 36.333 35.67049737358117 139.74159377843355 36.333 35.670519674617 139.7415951778864 36.333</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8667f5d4-1ebf-4527-b532-87c27dcae91e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8667f5d4-1ebf-4527-b532-87c27dcae91e_0">
											<gml:posList>35.670519674617 139.7415951778864 36.333 35.670519674617 139.7415951778864 8.57 35.670520814102304 139.74155279201037 8.57 35.670520814102304 139.74155279201037 36.333 35.670519674617 139.7415951778864 36.333</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-beeb80dc-2f82-42a3-a138-83d810964764">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-beeb80dc-2f82-42a3-a138-83d810964764_0">
											<gml:posList>35.67049737358117 139.74159377843355 36.333 35.67049737358117 139.74159377843355 8.57 35.670519674617 139.7415951778864 8.57 35.670519674617 139.7415951778864 36.333 35.67049737358117 139.74159377843355 36.333</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_227c4f88-07c7-4d44-ad2c-784844943ae9_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6da60a7f-b03b-4e93-a2b6-fb17d288b091">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67047383775777 139.7415451907184 34.531 35.67047312082277 139.7415624789554 34.531 35.670456552783556 139.74156142643093 34.531 35.67045727874055 139.74154414923345 34.531 35.67047383775777 139.7415451907184 34.531</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-01590e4c-2924-4da8-a381-02a8ace1ef42">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-01590e4c-2924-4da8-a381-02a8ace1ef42_0">
											<gml:posList>35.67045727874055 139.74154414923345 37.114 35.67047383775777 139.7415451907184 37.114 35.67047383775777 139.7415451907184 34.531 35.67045727874055 139.74154414923345 34.531 35.67045727874055 139.74154414923345 37.114</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0385a148-c7ad-475c-a6df-5aa06da24667">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0385a148-c7ad-475c-a6df-5aa06da24667_0">
											<gml:posList>35.670456552783556 139.74156142643093 34.531 35.670456552783556 139.74156142643093 37.114 35.67045727874055 139.74154414923345 37.114 35.67045727874055 139.74154414923345 34.531 35.670456552783556 139.74156142643093 34.531</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8a1be46b-14dd-44e4-9cb3-21c5a6b7e6b3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8a1be46b-14dd-44e4-9cb3-21c5a6b7e6b3_0">
											<gml:posList>35.67047383775777 139.7415451907184 37.114 35.67045727874055 139.74154414923345 37.114 35.670456552783556 139.74156142643093 37.114 35.67047312082277 139.7415624789554 37.114 35.67047383775777 139.7415451907184 37.114</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b0d908f2-b507-40b7-af29-75a4a5816b09">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b0d908f2-b507-40b7-af29-75a4a5816b09_0">
											<gml:posList>35.67047383775777 139.7415451907184 34.531 35.67047383775777 139.7415451907184 37.114 35.67047312082277 139.7415624789554 37.114 35.67047312082277 139.7415624789554 34.531 35.67047383775777 139.7415451907184 34.531</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6422a0c4-ffd3-4db4-88eb-85f1777fa213">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6422a0c4-ffd3-4db4-88eb-85f1777fa213_0">
											<gml:posList>35.67047312082277 139.7415624789554 34.531 35.67047312082277 139.7415624789554 37.114 35.670456552783556 139.74156142643093 37.114 35.670456552783556 139.74156142643093 34.531 35.67047312082277 139.7415624789554 34.531</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-0ef7cf4a-9898-4b26-9a65-ba5cbd080462">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0ef7cf4a-9898-4b26-9a65-ba5cbd080462">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0ef7cf4a-9898-4b26-9a65-ba5cbd080462">
											<gml:posList>35.67045142551249 139.7414570671467 8.57 35.670523268422954 139.7414616242581 8.57 35.670520814102304 139.74155279201037 8.57 35.67049914405186 139.74155142498577 8.57 35.67049737358117 139.74159377843355 8.57 35.67044720075076 139.74159062137753 8.57 35.67045142551249 139.7414570671467 8.57</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c98db661-b3d2-4c39-a6fc-95779125025e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c98db661-b3d2-4c39-a6fc-95779125025e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c98db661-b3d2-4c39-a6fc-95779125025e">
											<gml:posList>35.670523268422954 139.7414616242581 29.945 35.67045142551249 139.7414570671467 29.945 35.67044970917406 139.7415112621098 36.333 35.670523268422954 139.7414616242581 29.945</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-01187d9c-6312-4bed-a67f-d40b2ea93d15">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-01187d9c-6312-4bed-a67f-d40b2ea93d15">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-01187d9c-6312-4bed-a67f-d40b2ea93d15">
											<gml:posList>35.670523268422954 139.7414616242581 29.945 35.67044970917406 139.7415112621098 36.333 35.670521839662534 139.74151469221988 36.333 35.670523268422954 139.7414616242581 29.945</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ad3b98be-f3b9-48b7-99d4-19e2c95fe425">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ad3b98be-f3b9-48b7-99d4-19e2c95fe425">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ad3b98be-f3b9-48b7-99d4-19e2c95fe425">
											<gml:posList>35.67044970917406 139.7415112621098 36.333 35.670451405472306 139.74151351360612 36.333 35.67052002047407 139.74151677100363 36.333 35.670521839662534 139.74151469221988 36.333 35.67044970917406 139.7415112621098 36.333</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-da720760-429a-4c11-b881-e2864b4a5fa5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-da720760-429a-4c11-b881-e2864b4a5fa5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-da720760-429a-4c11-b881-e2864b4a5fa5">
											<gml:posList>35.670521839662534 139.74151469221988 36.333 35.67052002047407 139.74151677100363 36.333 35.6705191178048 139.7415505405113 36.333 35.670520814102304 139.74155279201037 36.333 35.670521839662534 139.74151469221988 36.333</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-5632405b-6565-41b0-be56-041afe4d3d91">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5632405b-6565-41b0-be56-041afe4d3d91">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5632405b-6565-41b0-be56-041afe4d3d91">
											<gml:posList>35.670473988389126 139.74154177724773 39.474 35.67047594639633 139.74154443715784 39.474 35.6704973009582 139.74154579349505 39.474 35.67049948044349 139.7415433829118 39.474 35.670473988389126 139.74154177724773 39.474</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ada83739-2a97-4e69-823f-f4732ab630a8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ada83739-2a97-4e69-823f-f4732ab630a8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ada83739-2a97-4e69-823f-f4732ab630a8">
											<gml:posList>35.67044720075076 139.74159062137753 36.333 35.67044903799322 139.7415885757155 36.333 35.670451405472306 139.74151351360612 36.333 35.67044970917406 139.7415112621098 36.333 35.67044720075076 139.74159062137753 36.333</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-10c6cfe9-ddd5-4480-96d1-191df89a9549">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-10c6cfe9-ddd5-4480-96d1-191df89a9549">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-10c6cfe9-ddd5-4480-96d1-191df89a9549">
											<gml:posList>35.6705191178048 139.7415505405113 36.333 35.67049923255564 139.74154928190694 36.333 35.67049914405186 139.74155142498577 36.333 35.670520814102304 139.74155279201037 36.333 35.6705191178048 139.7415505405113 36.333</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ca2723b6-abe4-41ee-919e-6e5b2e65b7a0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ca2723b6-abe4-41ee-919e-6e5b2e65b7a0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ca2723b6-abe4-41ee-919e-6e5b2e65b7a0">
											<gml:posList>35.6705191178048 139.7415505405113 34.531 35.67052002047407 139.74151677100363 34.531 35.670451405472306 139.74151351360612 34.531 35.67044903799322 139.7415885757155 34.531 35.67049570431718 139.74159151585707 34.531 35.67049592559517 139.7415861802528 34.531 35.67047219130148 139.7415846830265 34.531 35.670473988389126 139.74154177724773 34.531 35.67049948044349 139.7415433829118 34.531 35.67049923255564 139.74154928190694 34.531 35.6705191178048 139.7415505405113 34.531</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-872f319e-d40e-493c-a0f9-8cc378612bfd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-872f319e-d40e-493c-a0f9-8cc378612bfd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-872f319e-d40e-493c-a0f9-8cc378612bfd">
											<gml:posList>35.67047219130148 139.7415846830265 39.474 35.67047436177381 139.74158227245536 39.474 35.67047594639633 139.74154443715784 39.474 35.670473988389126 139.74154177724773 39.474 35.67047219130148 139.7415846830265 39.474</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a492c6e8-6982-44b8-be7a-bd4024d01477">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a492c6e8-6982-44b8-be7a-bd4024d01477">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a492c6e8-6982-44b8-be7a-bd4024d01477">
											<gml:posList>35.6704973009582 139.74154579349505 38.958 35.67047594639633 139.74154443715784 38.958 35.67047436177381 139.74158227245536 38.958 35.670495716335296 139.74158362880263 38.958 35.6704973009582 139.74154579349505 38.958</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e9f6d312-189c-4d71-b7d6-2a6f34019119">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e9f6d312-189c-4d71-b7d6-2a6f34019119">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e9f6d312-189c-4d71-b7d6-2a6f34019119">
											<gml:posList>35.67049948044349 139.7415433829118 39.474 35.6704973009582 139.74154579349505 39.474 35.670495716335296 139.74158362880263 39.474 35.67049768335529 139.74158628870413 39.474 35.67049948044349 139.7415433829118 39.474</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-7d7b8234-a9e8-4d02-95b4-a2ee648eba48">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7d7b8234-a9e8-4d02-95b4-a2ee648eba48">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7d7b8234-a9e8-4d02-95b4-a2ee648eba48">
											<gml:posList>35.67049768335529 139.74158628870413 39.474 35.670495716335296 139.74158362880263 39.474 35.67047436177381 139.74158227245536 39.474 35.67047219130148 139.7415846830265 39.474 35.67049768335529 139.74158628870413 39.474</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-99052dee-0b0e-41b8-b3d3-9b964898689a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-99052dee-0b0e-41b8-b3d3-9b964898689a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-99052dee-0b0e-41b8-b3d3-9b964898689a">
											<gml:posList>35.67049570431718 139.74159151585707 36.333 35.67049737358117 139.74159377843355 36.333 35.67049768335529 139.74158628870413 36.333 35.67049592559517 139.7415861802528 36.333 35.67049570431718 139.74159151585707 36.333</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-399115d7-f882-4bd9-bbbb-7bef960a32dc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-399115d7-f882-4bd9-bbbb-7bef960a32dc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-399115d7-f882-4bd9-bbbb-7bef960a32dc">
											<gml:posList>35.67049737358117 139.74159377843355 36.333 35.67049570431718 139.74159151585707 36.333 35.67044903799322 139.7415885757155 36.333 35.67044720075076 139.74159062137753 36.333 35.67049737358117 139.74159377843355 36.333</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-33a31f37-e382-4a2a-893c-d183809d6f71">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-33a31f37-e382-4a2a-893c-d183809d6f71">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-33a31f37-e382-4a2a-893c-d183809d6f71">
											<gml:posList>35.67044720075076 139.74159062137753 36.333 35.67044970917406 139.7415112621098 36.333 35.67045142551249 139.7414570671467 29.945 35.67045142551249 139.7414570671467 8.57 35.67044720075076 139.74159062137753 8.57 35.67044720075076 139.74159062137753 36.333</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4da401dd-d3a7-4d86-b88f-1aa04fd9e35b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4da401dd-d3a7-4d86-b88f-1aa04fd9e35b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4da401dd-d3a7-4d86-b88f-1aa04fd9e35b">
											<gml:posList>35.67044903799322 139.7415885757155 36.333 35.67044903799322 139.7415885757155 34.531 35.670451405472306 139.74151351360612 34.531 35.670451405472306 139.74151351360612 36.333 35.67044903799322 139.7415885757155 36.333</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b4ae3cae-3bc9-4935-9712-4ae2fba337e6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b4ae3cae-3bc9-4935-9712-4ae2fba337e6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b4ae3cae-3bc9-4935-9712-4ae2fba337e6">
											<gml:posList>35.67044720075076 139.74159062137753 8.57 35.67049737358117 139.74159377843355 8.57 35.67049737358117 139.74159377843355 36.333 35.67044720075076 139.74159062137753 36.333 35.67044720075076 139.74159062137753 8.57</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-087784a0-e3b9-454a-b3af-523643540fa7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-087784a0-e3b9-454a-b3af-523643540fa7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-087784a0-e3b9-454a-b3af-523643540fa7">
											<gml:posList>35.67049570431718 139.74159151585707 36.333 35.67049570431718 139.74159151585707 34.531 35.67044903799322 139.7415885757155 34.531 35.67044903799322 139.7415885757155 36.333 35.67049570431718 139.74159151585707 36.333</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e3dd7b52-74af-4a65-aa90-06c4927fcecb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e3dd7b52-74af-4a65-aa90-06c4927fcecb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e3dd7b52-74af-4a65-aa90-06c4927fcecb">
											<gml:posList>35.67047219130148 139.7415846830265 39.474 35.670473988389126 139.74154177724773 39.474 35.670473988389126 139.74154177724773 34.531 35.67047219130148 139.7415846830265 34.531 35.67047219130148 139.7415846830265 39.474</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ecab22df-d509-4754-8cf7-307c7530ef1f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ecab22df-d509-4754-8cf7-307c7530ef1f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ecab22df-d509-4754-8cf7-307c7530ef1f">
											<gml:posList>35.67047436177381 139.74158227245536 39.474 35.67047436177381 139.74158227245536 38.958 35.67047594639633 139.74154443715784 38.958 35.67047594639633 139.74154443715784 39.474 35.67047436177381 139.74158227245536 39.474</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7e144d83-236a-4d7e-a492-e4683c57717b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7e144d83-236a-4d7e-a492-e4683c57717b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7e144d83-236a-4d7e-a492-e4683c57717b">
											<gml:posList>35.67049768335529 139.74158628870413 39.474 35.67047219130148 139.7415846830265 39.474 35.67047219130148 139.7415846830265 34.531 35.67049592559517 139.7415861802528 34.531 35.67049592559517 139.7415861802528 36.333 35.67049768335529 139.74158628870413 36.333 35.67049768335529 139.74158628870413 39.474</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-550b8baa-9b70-4646-827d-538e947c75d2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-550b8baa-9b70-4646-827d-538e947c75d2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-550b8baa-9b70-4646-827d-538e947c75d2">
											<gml:posList>35.670495716335296 139.74158362880263 39.474 35.670495716335296 139.74158362880263 38.958 35.67047436177381 139.74158227245536 38.958 35.67047436177381 139.74158227245536 39.474 35.670495716335296 139.74158362880263 39.474</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-46671c35-255d-4975-8ed9-576d5942a8e4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-46671c35-255d-4975-8ed9-576d5942a8e4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-46671c35-255d-4975-8ed9-576d5942a8e4">
											<gml:posList>35.670451405472306 139.74151351360612 36.333 35.670451405472306 139.74151351360612 34.531 35.67052002047407 139.74151677100363 34.531 35.67052002047407 139.74151677100363 36.333 35.670451405472306 139.74151351360612 36.333</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-dbac7b21-446e-46dd-8f97-cee02b2aaf34">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-dbac7b21-446e-46dd-8f97-cee02b2aaf34">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-dbac7b21-446e-46dd-8f97-cee02b2aaf34">
											<gml:posList>35.67047594639633 139.74154443715784 39.474 35.67047594639633 139.74154443715784 38.958 35.6704973009582 139.74154579349505 38.958 35.6704973009582 139.74154579349505 39.474 35.67047594639633 139.74154443715784 39.474</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-18788262-a5de-4431-a00f-b9e34217ade8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-18788262-a5de-4431-a00f-b9e34217ade8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-18788262-a5de-4431-a00f-b9e34217ade8">
											<gml:posList>35.670473988389126 139.74154177724773 39.474 35.67049948044349 139.7415433829118 39.474 35.67049948044349 139.7415433829118 34.531 35.670473988389126 139.74154177724773 34.531 35.670473988389126 139.74154177724773 39.474</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c778686f-d1b6-4df3-b88e-9869e3378be8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c778686f-d1b6-4df3-b88e-9869e3378be8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c778686f-d1b6-4df3-b88e-9869e3378be8">
											<gml:posList>35.670523268422954 139.7414616242581 8.57 35.67045142551249 139.7414570671467 8.57 35.67045142551249 139.7414570671467 29.945 35.670523268422954 139.7414616242581 29.945 35.670523268422954 139.7414616242581 8.57</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-96260695-08f5-4191-ab3d-bc5c319b7ff3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-96260695-08f5-4191-ab3d-bc5c319b7ff3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-96260695-08f5-4191-ab3d-bc5c319b7ff3">
											<gml:posList>35.67049592559517 139.7415861802528 36.333 35.67049592559517 139.7415861802528 34.531 35.67049570431718 139.74159151585707 34.531 35.67049570431718 139.74159151585707 36.333 35.67049592559517 139.7415861802528 36.333</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c2aa1a88-d1dd-4d22-8ced-cd00aed54441">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c2aa1a88-d1dd-4d22-8ced-cd00aed54441">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c2aa1a88-d1dd-4d22-8ced-cd00aed54441">
											<gml:posList>35.6704973009582 139.74154579349505 39.474 35.6704973009582 139.74154579349505 38.958 35.670495716335296 139.74158362880263 38.958 35.670495716335296 139.74158362880263 39.474 35.6704973009582 139.74154579349505 39.474</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-97144dcf-0592-499d-be65-944a664bdafd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-97144dcf-0592-499d-be65-944a664bdafd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-97144dcf-0592-499d-be65-944a664bdafd">
											<gml:posList>35.67049948044349 139.7415433829118 39.474 35.67049768335529 139.74158628870413 39.474 35.67049768335529 139.74158628870413 36.333 35.67049737358117 139.74159377843355 36.333 35.67049737358117 139.74159377843355 8.57 35.67049914405186 139.74155142498577 8.57 35.67049914405186 139.74155142498577 36.333 35.67049923255564 139.74154928190694 36.333 35.67049923255564 139.74154928190694 34.531 35.67049948044349 139.7415433829118 34.531 35.67049948044349 139.7415433829118 39.474</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-70c8af0e-2905-493f-9913-af09f9c0f5f5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-70c8af0e-2905-493f-9913-af09f9c0f5f5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-70c8af0e-2905-493f-9913-af09f9c0f5f5">
											<gml:posList>35.6705191178048 139.7415505405113 36.333 35.6705191178048 139.7415505405113 34.531 35.67049923255564 139.74154928190694 34.531 35.67049923255564 139.74154928190694 36.333 35.6705191178048 139.7415505405113 36.333</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-be559886-fc26-4b7b-aa99-732816f8541a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-be559886-fc26-4b7b-aa99-732816f8541a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-be559886-fc26-4b7b-aa99-732816f8541a">
											<gml:posList>35.67049914405186 139.74155142498577 8.57 35.670520814102304 139.74155279201037 8.57 35.670520814102304 139.74155279201037 36.333 35.67049914405186 139.74155142498577 36.333 35.67049914405186 139.74155142498577 8.57</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3b9d8121-0700-4c1e-8a13-4288364c375b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3b9d8121-0700-4c1e-8a13-4288364c375b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3b9d8121-0700-4c1e-8a13-4288364c375b">
											<gml:posList>35.67052002047407 139.74151677100363 36.333 35.67052002047407 139.74151677100363 34.531 35.6705191178048 139.7415505405113 34.531 35.6705191178048 139.7415505405113 36.333 35.67052002047407 139.74151677100363 36.333</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8f14597d-acd6-4ece-aa40-2b4261d7c5d5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8f14597d-acd6-4ece-aa40-2b4261d7c5d5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8f14597d-acd6-4ece-aa40-2b4261d7c5d5">
											<gml:posList>35.670523268422954 139.7414616242581 29.945 35.670520814102304 139.74155279201037 8.57 35.670523268422954 139.7414616242581 8.57 35.670523268422954 139.7414616242581 29.945</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a5f4718f-f7d8-4edf-a1df-83f3a402eec9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a5f4718f-f7d8-4edf-a1df-83f3a402eec9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a5f4718f-f7d8-4edf-a1df-83f3a402eec9">
											<gml:posList>35.670523268422954 139.7414616242581 29.945 35.670520814102304 139.74155279201037 36.333 35.670520814102304 139.74155279201037 8.57 35.670523268422954 139.7414616242581 29.945</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-dfb6b00b-ba59-45fd-ab83-1431fcfc584c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-dfb6b00b-ba59-45fd-ab83-1431fcfc584c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-dfb6b00b-ba59-45fd-ab83-1431fcfc584c">
											<gml:posList>35.670523268422954 139.7414616242581 29.945 35.670521839662534 139.74151469221988 36.333 35.670520814102304 139.74155279201037 36.333 35.670523268422954 139.7414616242581 29.945</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-3438</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">96.96735</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">211</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1230</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>7</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.01</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>