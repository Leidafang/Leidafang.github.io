<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_22bde008-2f26-4be8-bbd0-67f17dbba261">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001001</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">413</bldg:usage>
			<bldg:measuredHeight uom="m">12.9</bldg:measuredHeight>
			<bldg:storeysAboveGround>4</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>1</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.670358074993416 139.74389364694025 0 35.67034932913796 139.7438902323572 0 35.67035121627608 139.74388249787296 0 35.670272684665626 139.74385287108825 0 35.67024626241751 139.74395806079363 0 35.67033426095319 139.7439911014608 0 35.670358074993416 139.74389364694025 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670358074993416 139.74389364694025 7.735 35.67033426095319 139.7439911014608 7.735 35.67024626241751 139.74395806079363 7.735 35.670272684665626 139.74385287108825 7.735 35.67035121627608 139.74388249787296 7.735 35.67034932913796 139.7438902323572 7.735 35.670358074993416 139.74389364694025 7.735</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670358074993416 139.74389364694025 7.735 35.67034932913796 139.7438902323572 7.735 35.67034932913796 139.7438902323572 20.67 35.670358074993416 139.74389364694025 20.67 35.670358074993416 139.74389364694025 7.735</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67034932913796 139.7438902323572 7.735 35.67035121627608 139.74388249787296 7.735 35.67035121627608 139.74388249787296 20.67 35.67034932913796 139.7438902323572 20.67 35.67034932913796 139.7438902323572 7.735</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67035121627608 139.74388249787296 7.735 35.670272684665626 139.74385287108825 7.735 35.670272684665626 139.74385287108825 20.67 35.67035121627608 139.74388249787296 20.67 35.67035121627608 139.74388249787296 7.735</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670272684665626 139.74385287108825 7.735 35.67024626241751 139.74395806079363 7.735 35.67024626241751 139.74395806079363 20.67 35.670272684665626 139.74385287108825 20.67 35.670272684665626 139.74385287108825 7.735</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67024626241751 139.74395806079363 7.735 35.67033426095319 139.7439911014608 7.735 35.67033426095319 139.7439911014608 20.67 35.67024626241751 139.74395806079363 20.67 35.67024626241751 139.74395806079363 7.735</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67033426095319 139.7439911014608 7.735 35.670358074993416 139.74389364694025 7.735 35.670358074993416 139.74389364694025 20.67 35.67033426095319 139.7439911014608 20.67 35.67033426095319 139.7439911014608 7.735</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670358074993416 139.74389364694025 20.67 35.67034932913796 139.7438902323572 20.67 35.67035121627608 139.74388249787296 20.67 35.670272684665626 139.74385287108825 20.67 35.67024626241751 139.74395806079363 20.67 35.67033426095319 139.7439911014608 20.67 35.670358074993416 139.74389364694025 20.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-2dda1066-b64d-47c3-8b68-2445b620b52d"/>
							<gml:surfaceMember xlink:href="#poly-41dd56c0-cbde-44fb-b77a-3ea9248e78a0"/>
							<gml:surfaceMember xlink:href="#poly-3af7496b-7052-4187-8dac-6dde784a15e8"/>
							<gml:surfaceMember xlink:href="#poly-289d54bf-7ddc-4c6d-95c7-d6bcade6f648"/>
							<gml:surfaceMember xlink:href="#poly-5b2bed74-ffac-4a3e-a87c-d4e45ea2e0e1"/>
							<gml:surfaceMember xlink:href="#poly-77c19ae8-ec10-494e-8943-7f9080b0ef99"/>
							<gml:surfaceMember xlink:href="#poly-dc7f39eb-fd0b-459c-b514-b1f92f97c0f3"/>
							<gml:surfaceMember xlink:href="#poly-8c21a35c-e565-4f34-9f84-595c954e8b06"/>
							<gml:surfaceMember xlink:href="#poly-a0c01fcc-32f5-45ef-9ba2-1ab271a4b042"/>
							<gml:surfaceMember xlink:href="#poly-8f33dff5-be7b-4199-999c-b33d56a6803e"/>
							<gml:surfaceMember xlink:href="#poly-71d539c8-fa8b-418e-b2cf-acfc5f016b86"/>
							<gml:surfaceMember xlink:href="#poly-bba6f4e9-85ab-4621-b1c4-de4ffc7905e9"/>
							<gml:surfaceMember xlink:href="#poly-01844e09-ca2f-44f9-b7ae-18d3cf956e18"/>
							<gml:surfaceMember xlink:href="#poly-f54c868b-92af-4921-ba3c-0e7f4c9b9fbb"/>
							<gml:surfaceMember xlink:href="#poly-8d6616c9-3d7c-4db0-ae76-22fd91fa85f2"/>
							<gml:surfaceMember xlink:href="#poly-c15db528-49ae-43cd-b366-d18ce922e3cc"/>
							<gml:surfaceMember xlink:href="#poly-c4038845-39ec-4ac2-856b-f71b5a958150"/>
							<gml:surfaceMember xlink:href="#poly-ed5fbefe-e0e7-4e55-b97a-603726935e72"/>
							<gml:surfaceMember xlink:href="#poly-3ced360b-a0a6-4e47-b1b8-1a427ef5356a"/>
							<gml:surfaceMember xlink:href="#poly-19010d05-0dc1-43cf-8dfa-205060c573e7"/>
							<gml:surfaceMember xlink:href="#poly-23c46e70-e424-4af9-81df-a6adfd2551f4"/>
							<gml:surfaceMember xlink:href="#poly-d80b68e4-cb8e-4ba6-b089-4b8899e6786e"/>
							<gml:surfaceMember xlink:href="#poly-029d8957-bacf-44c0-9736-b111b1ba94dc"/>
							<gml:surfaceMember xlink:href="#poly-2cce4088-8eef-4524-bd63-28e4c4408670"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_22bde008-2f26-4be8-bbd0-67f17dbba261_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5ac78790-3b0a-4794-99b4-27e3cec12acf">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67032290418657 139.74388255155205 20.8 35.67031775455126 139.74390305913946 20.8 35.670306898967816 139.74389895099665 20.8 35.670312048610654 139.74387845445798 20.8 35.67032290418657 139.74388255155205 20.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f16b3e2b-160f-4587-9432-a6d78bdb2006">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f16b3e2b-160f-4587-9432-a6d78bdb2006_0">
											<gml:posList>35.670312048610654 139.74387845445798 22.481 35.67032290418657 139.74388255155205 22.481 35.67032290418657 139.74388255155205 20.8 35.670312048610654 139.74387845445798 20.8 35.670312048610654 139.74387845445798 22.481</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0dfafa10-df08-4390-ac67-62229c0db293">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0dfafa10-df08-4390-ac67-62229c0db293_0">
											<gml:posList>35.670306898967816 139.74389895099665 20.8 35.670306898967816 139.74389895099665 22.481 35.670312048610654 139.74387845445798 22.481 35.670312048610654 139.74387845445798 20.8 35.670306898967816 139.74389895099665 20.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8a7addba-a8be-473f-abe2-451e4eefe046">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8a7addba-a8be-473f-abe2-451e4eefe046_0">
											<gml:posList>35.670306898967816 139.74389895099665 22.481 35.67031775455126 139.74390305913946 22.481 35.67032290418657 139.74388255155205 22.481 35.670312048610654 139.74387845445798 22.481 35.670306898967816 139.74389895099665 22.481</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b9bd9f05-7912-4c86-b346-ac0f03b4c351">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b9bd9f05-7912-4c86-b346-ac0f03b4c351_0">
											<gml:posList>35.67032290418657 139.74388255155205 20.8 35.67032290418657 139.74388255155205 22.481 35.67031775455126 139.74390305913946 22.481 35.67031775455126 139.74390305913946 20.8 35.67032290418657 139.74388255155205 20.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ccf10c32-c427-4b9b-8267-4076df990ee1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ccf10c32-c427-4b9b-8267-4076df990ee1_0">
											<gml:posList>35.67031775455126 139.74390305913946 20.8 35.67031775455126 139.74390305913946 22.481 35.670306898967816 139.74389895099665 22.481 35.670306898967816 139.74389895099665 20.8 35.67031775455126 139.74390305913946 20.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_22bde008-2f26-4be8-bbd0-67f17dbba261_BuildingInstallation_1041">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2f032018-d057-4463-a26c-38a0af920aad">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67025382960247 139.74392791820915 20.8 35.67027268466558 139.74385287108825 20.8 35.67030928166278 139.74386668224258 20.8 35.67030175952084 139.74389676957213 20.8 35.67031770926114 139.74390276094118 20.8 35.67030534309656 139.74395222879338 20.8 35.67028533604321 139.74394470651043 20.8 35.67028646841024 139.74394017628677 20.8 35.67025382960247 139.74392791820915 20.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1a9118b5-65fa-4317-ac06-8dd9c1a57b40">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1a9118b5-65fa-4317-ac06-8dd9c1a57b40_0">
											<gml:posList>35.67027268466558 139.74385287108825 23.383 35.67027268466558 139.74385287108825 20.8 35.67025382960247 139.74392791820915 20.8 35.67025382960247 139.74392791820915 23.383 35.67027268466558 139.74385287108825 23.383</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d8e5907e-1fe7-4009-8a69-6bc84efdd93f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d8e5907e-1fe7-4009-8a69-6bc84efdd93f_0">
											<gml:posList>35.67025382960247 139.74392791820915 23.383 35.67025382960247 139.74392791820915 20.8 35.67028646841024 139.74394017628677 20.8 35.67028646841024 139.74394017628677 23.383 35.67025382960247 139.74392791820915 23.383</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ac2226d4-0e34-4fcd-9ab6-8d64f27c95fb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ac2226d4-0e34-4fcd-9ab6-8d64f27c95fb_0">
											<gml:posList>35.67025382960247 139.74392791820915 23.383 35.67028646841024 139.74394017628677 23.383 35.67028533604321 139.74394470651043 23.383 35.67030534309656 139.74395222879338 23.383 35.67031770926114 139.74390276094118 23.383 35.67030175952084 139.74389676957213 23.383 35.67030928166278 139.74386668224258 23.383 35.67027268466558 139.74385287108825 23.383 35.67025382960247 139.74392791820915 23.383</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cd162432-d13e-4469-9cfa-7fa68081b984">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cd162432-d13e-4469-9cfa-7fa68081b984_0">
											<gml:posList>35.67028646841024 139.74394017628677 23.383 35.67028646841024 139.74394017628677 20.8 35.67028533604321 139.74394470651043 20.8 35.67028533604321 139.74394470651043 23.383 35.67028646841024 139.74394017628677 23.383</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-79b6afed-2930-49b6-839c-707885af4194">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-79b6afed-2930-49b6-839c-707885af4194_0">
											<gml:posList>35.67030928166278 139.74386668224258 23.383 35.67030928166278 139.74386668224258 20.8 35.67027268466558 139.74385287108825 20.8 35.67027268466558 139.74385287108825 23.383 35.67030928166278 139.74386668224258 23.383</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7f9ae833-4033-40d8-80bf-d2470c74d04e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7f9ae833-4033-40d8-80bf-d2470c74d04e_0">
											<gml:posList>35.67028533604321 139.74394470651043 23.383 35.67028533604321 139.74394470651043 20.8 35.67030534309656 139.74395222879338 20.8 35.67030534309656 139.74395222879338 23.383 35.67028533604321 139.74394470651043 23.383</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-07edd800-104a-478f-b7a0-44958f05e763">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-07edd800-104a-478f-b7a0-44958f05e763_0">
											<gml:posList>35.67030175952084 139.74389676957213 23.383 35.67030175952084 139.74389676957213 20.8 35.67030928166278 139.74386668224258 20.8 35.67030928166278 139.74386668224258 23.383 35.67030175952084 139.74389676957213 23.383</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2d37a4ec-589e-482e-ae20-b25ba2404e01">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2d37a4ec-589e-482e-ae20-b25ba2404e01_0">
											<gml:posList>35.67031770926114 139.74390276094118 23.383 35.67031770926114 139.74390276094118 20.8 35.67030175952084 139.74389676957213 20.8 35.67030175952084 139.74389676957213 23.383 35.67031770926114 139.74390276094118 23.383</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2f990add-b4e4-40ca-aec2-7f9c8c6af04e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2f990add-b4e4-40ca-aec2-7f9c8c6af04e_0">
											<gml:posList>35.67030534309656 139.74395222879338 23.383 35.67030534309656 139.74395222879338 20.8 35.67031770926114 139.74390276094118 20.8 35.67031770926114 139.74390276094118 23.383 35.67030534309656 139.74395222879338 23.383</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-2dda1066-b64d-47c3-8b68-2445b620b52d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2dda1066-b64d-47c3-8b68-2445b620b52d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2dda1066-b64d-47c3-8b68-2445b620b52d">
											<gml:posList>35.67027268466558 139.74385287108825 7.735 35.670351216276046 139.74388249787293 7.735 35.670349329137956 139.7438902323572 7.735 35.6703580749934 139.74389364694025 7.735 35.67033426095318 139.74399110146078 7.735 35.67024626241749 139.7439580607936 7.735 35.67027268466558 139.74385287108825 7.735</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-41dd56c0-cbde-44fb-b77a-3ea9248e78a0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-41dd56c0-cbde-44fb-b77a-3ea9248e78a0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-41dd56c0-cbde-44fb-b77a-3ea9248e78a0">
											<gml:posList>35.67025353852588 139.74396079215092 25.113 35.670254772799325 139.74395997335318 25.113 35.670260605429036 139.74393669241695 25.113 35.67025994630366 139.74393517981653 25.113 35.67025353852588 139.74396079215092 25.113</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-3af7496b-7052-4187-8dac-6dde784a15e8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3af7496b-7052-4187-8dac-6dde784a15e8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3af7496b-7052-4187-8dac-6dde784a15e8">
											<gml:posList>35.67030383113609 139.7439796804083 25.113 35.67030316298935 139.7439781567705 25.113 35.670254772799325 139.74395997335318 25.113 35.67025353852588 139.74396079215092 25.113 35.67030383113609 139.7439796804083 25.113</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-289d54bf-7ddc-4c6d-95c7-d6bcade6f648">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-289d54bf-7ddc-4c6d-95c7-d6bcade6f648">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-289d54bf-7ddc-4c6d-95c7-d6bcade6f648">
											<gml:posList>35.670308986600574 139.74395486478537 24.696 35.670260605429036 139.74393669241695 24.696 35.670254772799325 139.74395997335318 24.696 35.67030316298935 139.7439781567705 24.696 35.670308986600574 139.74395486478537 24.696</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-5b2bed74-ffac-4a3e-a87c-d4e45ea2e0e1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5b2bed74-ffac-4a3e-a87c-d4e45ea2e0e1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5b2bed74-ffac-4a3e-a87c-d4e45ea2e0e1">
											<gml:posList>35.67025994630366 139.74393517981653 25.113 35.670260605429036 139.74393669241695 25.113 35.670308986600574 139.74395486478537 25.113 35.67031022989589 139.74395405702313 25.113 35.67025994630366 139.74393517981653 25.113</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-77c19ae8-ec10-494e-8943-7f9080b0ef99">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-77c19ae8-ec10-494e-8943-7f9080b0ef99">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-77c19ae8-ec10-494e-8943-7f9080b0ef99">
											<gml:posList>35.67027268466558 139.74385287108825 20.8 35.67024626241749 139.7439580607936 20.8 35.67025353852588 139.74396079215092 20.8 35.67025994630366 139.74393517981653 20.8 35.67031022989589 139.74395405702313 20.8 35.670330199377815 139.7438745680185 20.8 35.67027268466558 139.74385287108825 20.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-dc7f39eb-fd0b-459c-b514-b1f92f97c0f3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-dc7f39eb-fd0b-459c-b514-b1f92f97c0f3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-dc7f39eb-fd0b-459c-b514-b1f92f97c0f3">
											<gml:posList>35.67031022989589 139.74395405702313 25.113 35.670308986600574 139.74395486478537 25.113 35.67030316298935 139.7439781567705 25.113 35.67030383113609 139.7439796804083 25.113 35.67031022989589 139.74395405702313 25.113</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-8c21a35c-e565-4f34-9f84-595c954e8b06">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8c21a35c-e565-4f34-9f84-595c954e8b06">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8c21a35c-e565-4f34-9f84-595c954e8b06">
											<gml:posList>35.67031022989589 139.74395405702313 19.6 35.67033103033665 139.74396182144392 19.6 35.670349329137956 139.7438902323572 19.6 35.670351216276046 139.74388249787293 19.6 35.670330199377815 139.7438745680185 19.6 35.67031022989589 139.74395405702313 19.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a0c01fcc-32f5-45ef-9ba2-1ab271a4b042">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a0c01fcc-32f5-45ef-9ba2-1ab271a4b042">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a0c01fcc-32f5-45ef-9ba2-1ab271a4b042">
											<gml:posList>35.67033426095318 139.74399110146078 14.9 35.6703580749934 139.74389364694025 14.9 35.670349329137956 139.7438902323572 14.9 35.67033103033665 139.74396182144392 14.9 35.67031022989589 139.74395405702313 14.9 35.67030383113609 139.7439796804083 14.9 35.67033426095318 139.74399110146078 14.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8f33dff5-be7b-4199-999c-b33d56a6803e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8f33dff5-be7b-4199-999c-b33d56a6803e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8f33dff5-be7b-4199-999c-b33d56a6803e">
											<gml:posList>35.670260605429036 139.74393669241695 25.113 35.670260605429036 139.74393669241695 24.696 35.670308986600574 139.74395486478537 24.696 35.670308986600574 139.74395486478537 25.113 35.670260605429036 139.74393669241695 25.113</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-71d539c8-fa8b-418e-b2cf-acfc5f016b86">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-71d539c8-fa8b-418e-b2cf-acfc5f016b86">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-71d539c8-fa8b-418e-b2cf-acfc5f016b86">
											<gml:posList>35.67027268466558 139.74385287108825 7.735 35.67027268466558 139.74385287108825 20.8 35.670330199377815 139.7438745680185 20.8 35.670330199377815 139.7438745680185 19.6 35.670351216276046 139.74388249787293 19.6 35.670351216276046 139.74388249787293 7.735 35.67027268466558 139.74385287108825 7.735</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-bba6f4e9-85ab-4621-b1c4-de4ffc7905e9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bba6f4e9-85ab-4621-b1c4-de4ffc7905e9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bba6f4e9-85ab-4621-b1c4-de4ffc7905e9">
											<gml:posList>35.670351216276046 139.74388249787293 19.6 35.670349329137956 139.7438902323572 19.6 35.670349329137956 139.7438902323572 14.9 35.670349329137956 139.7438902323572 7.735 35.670351216276046 139.74388249787293 7.735 35.670351216276046 139.74388249787293 19.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-01844e09-ca2f-44f9-b7ae-18d3cf956e18">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-01844e09-ca2f-44f9-b7ae-18d3cf956e18">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-01844e09-ca2f-44f9-b7ae-18d3cf956e18">
											<gml:posList>35.6703580749934 139.74389364694025 7.735 35.670349329137956 139.7438902323572 7.735 35.670349329137956 139.7438902323572 14.9 35.6703580749934 139.74389364694025 14.9 35.6703580749934 139.74389364694025 7.735</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f54c868b-92af-4921-ba3c-0e7f4c9b9fbb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f54c868b-92af-4921-ba3c-0e7f4c9b9fbb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f54c868b-92af-4921-ba3c-0e7f4c9b9fbb">
											<gml:posList>35.67027268466558 139.74385287108825 7.735 35.67024626241749 139.7439580607936 7.735 35.67024626241749 139.7439580607936 20.8 35.67027268466558 139.74385287108825 20.8 35.67027268466558 139.74385287108825 7.735</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8d6616c9-3d7c-4db0-ae76-22fd91fa85f2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8d6616c9-3d7c-4db0-ae76-22fd91fa85f2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8d6616c9-3d7c-4db0-ae76-22fd91fa85f2">
											<gml:posList>35.670349329137956 139.7438902323572 14.9 35.670349329137956 139.7438902323572 19.6 35.67033103033665 139.74396182144392 19.6 35.67033103033665 139.74396182144392 14.9 35.670349329137956 139.7438902323572 14.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c15db528-49ae-43cd-b366-d18ce922e3cc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c15db528-49ae-43cd-b366-d18ce922e3cc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c15db528-49ae-43cd-b366-d18ce922e3cc">
											<gml:posList>35.67031022989589 139.74395405702313 19.6 35.670330199377815 139.7438745680185 19.6 35.670330199377815 139.7438745680185 20.8 35.67031022989589 139.74395405702313 20.8 35.67031022989589 139.74395405702313 25.113 35.67030383113609 139.7439796804083 25.113 35.67030383113609 139.7439796804083 14.9 35.67031022989589 139.74395405702313 14.9 35.67031022989589 139.74395405702313 19.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c4038845-39ec-4ac2-856b-f71b5a958150">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c4038845-39ec-4ac2-856b-f71b5a958150">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c4038845-39ec-4ac2-856b-f71b5a958150">
											<gml:posList>35.67033426095318 139.74399110146078 7.735 35.6703580749934 139.74389364694025 7.735 35.6703580749934 139.74389364694025 14.9 35.67033426095318 139.74399110146078 14.9 35.67033426095318 139.74399110146078 7.735</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ed5fbefe-e0e7-4e55-b97a-603726935e72">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ed5fbefe-e0e7-4e55-b97a-603726935e72">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ed5fbefe-e0e7-4e55-b97a-603726935e72">
											<gml:posList>35.67025994630366 139.74393517981653 20.8 35.67025994630366 139.74393517981653 25.113 35.67031022989589 139.74395405702313 25.113 35.67031022989589 139.74395405702313 20.8 35.67025994630366 139.74393517981653 20.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3ced360b-a0a6-4e47-b1b8-1a427ef5356a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3ced360b-a0a6-4e47-b1b8-1a427ef5356a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3ced360b-a0a6-4e47-b1b8-1a427ef5356a">
											<gml:posList>35.67025353852588 139.74396079215092 25.113 35.67025994630366 139.74393517981653 25.113 35.67025994630366 139.74393517981653 20.8 35.67025353852588 139.74396079215092 20.8 35.67025353852588 139.74396079215092 25.113</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-19010d05-0dc1-43cf-8dfa-205060c573e7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-19010d05-0dc1-43cf-8dfa-205060c573e7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-19010d05-0dc1-43cf-8dfa-205060c573e7">
											<gml:posList>35.670254772799325 139.74395997335318 25.113 35.670254772799325 139.74395997335318 24.696 35.670260605429036 139.74393669241695 24.696 35.670260605429036 139.74393669241695 25.113 35.670254772799325 139.74395997335318 25.113</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-23c46e70-e424-4af9-81df-a6adfd2551f4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-23c46e70-e424-4af9-81df-a6adfd2551f4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-23c46e70-e424-4af9-81df-a6adfd2551f4">
											<gml:posList>35.67033103033665 139.74396182144392 14.9 35.67033103033665 139.74396182144392 19.6 35.67031022989589 139.74395405702313 19.6 35.67031022989589 139.74395405702313 14.9 35.67033103033665 139.74396182144392 14.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d80b68e4-cb8e-4ba6-b089-4b8899e6786e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d80b68e4-cb8e-4ba6-b089-4b8899e6786e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d80b68e4-cb8e-4ba6-b089-4b8899e6786e">
											<gml:posList>35.670308986600574 139.74395486478537 25.113 35.670308986600574 139.74395486478537 24.696 35.67030316298935 139.7439781567705 24.696 35.67030316298935 139.7439781567705 25.113 35.670308986600574 139.74395486478537 25.113</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-029d8957-bacf-44c0-9736-b111b1ba94dc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-029d8957-bacf-44c0-9736-b111b1ba94dc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-029d8957-bacf-44c0-9736-b111b1ba94dc">
											<gml:posList>35.67030316298935 139.7439781567705 25.113 35.67030316298935 139.7439781567705 24.696 35.670254772799325 139.74395997335318 24.696 35.670254772799325 139.74395997335318 25.113 35.67030316298935 139.7439781567705 25.113</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2cce4088-8eef-4524-bd63-28e4c4408670">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2cce4088-8eef-4524-bd63-28e4c4408670">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2cce4088-8eef-4524-bd63-28e4c4408670">
											<gml:posList>35.67025353852588 139.74396079215092 20.8 35.67024626241749 139.7439580607936 20.8 35.67024626241749 139.7439580607936 7.735 35.67033426095318 139.74399110146078 7.735 35.67033426095318 139.74399110146078 14.9 35.67030383113609 139.7439796804083 14.9 35.67030383113609 139.7439796804083 25.113 35.67025353852588 139.74396079215092 25.113 35.67025353852588 139.74396079215092 20.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂一丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-11506</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">100.5371</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">211</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1230</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>7</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.22</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>