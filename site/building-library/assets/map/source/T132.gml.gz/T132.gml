<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_2319b05d-ddb9-47c0-a062-6251af387275">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="再開発等促進区を定める地区計画">
				<gen:value>虎ノ門一・二丁目地区</gen:value>
			</gen:stringAttribute>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.66803773939181 139.74753218215292 0 35.667889227203226 139.7475548305543 0 35.667894800726366 139.7476097228031 0 35.66804331292527 139.7475870745018 0 35.66803773939181 139.74753218215292 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66803773939181 139.74753218215292 5.719 35.66804331292527 139.7475870745018 5.719 35.667894800726366 139.7476097228031 5.719 35.667889227203226 139.7475548305543 5.719 35.66803773939181 139.74753218215292 5.719</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66803773939181 139.74753218215292 5.719 35.667889227203226 139.7475548305543 5.719 35.667889227203226 139.7475548305543 8.719000000000001 35.66803773939181 139.74753218215292 8.719000000000001 35.66803773939181 139.74753218215292 5.719</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667889227203226 139.7475548305543 5.719 35.667894800726366 139.7476097228031 5.719 35.667894800726366 139.7476097228031 8.719000000000001 35.667889227203226 139.7475548305543 8.719000000000001 35.667889227203226 139.7475548305543 5.719</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667894800726366 139.7476097228031 5.719 35.66804331292527 139.7475870745018 5.719 35.66804331292527 139.7475870745018 8.719000000000001 35.667894800726366 139.7476097228031 8.719000000000001 35.667894800726366 139.7476097228031 5.719</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66804331292527 139.7475870745018 5.719 35.66803773939181 139.74753218215292 5.719 35.66803773939181 139.74753218215292 8.719000000000001 35.66804331292527 139.7475870745018 8.719000000000001 35.66804331292527 139.7475870745018 5.719</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66803773939181 139.74753218215292 8.719000000000001 35.667889227203226 139.7475548305543 8.719000000000001 35.667894800726366 139.7476097228031 8.719000000000001 35.66804331292527 139.7475870745018 8.719000000000001 35.66803773939181 139.74753218215292 8.719000000000001</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-94c4b847-9970-44ae-a4d9-3f4eedf039fe"/>
							<gml:surfaceMember xlink:href="#poly-13f50eab-a100-4fb1-a746-c446767f8736"/>
							<gml:surfaceMember xlink:href="#poly-54933993-b41d-4324-96c6-c4d749c93e09"/>
							<gml:surfaceMember xlink:href="#poly-035eae18-2739-4ee2-99f2-87acae83ef72"/>
							<gml:surfaceMember xlink:href="#poly-a9dc212b-971f-42fa-90bc-5ef42e154c73"/>
							<gml:surfaceMember xlink:href="#poly-6d3410f9-0172-4b77-89bf-9f8bfc916cf3"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-94c4b847-9970-44ae-a4d9-3f4eedf039fe">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-94c4b847-9970-44ae-a4d9-3f4eedf039fe">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-94c4b847-9970-44ae-a4d9-3f4eedf039fe">
											<gml:posList>35.6680377393918 139.7475321821529 5.719 35.66804331292528 139.74758707450178 5.719 35.66789480072637 139.7476097228031 5.719 35.66788922720322 139.7475548305543 5.719 35.6680377393918 139.7475321821529 5.719</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-13f50eab-a100-4fb1-a746-c446767f8736">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-13f50eab-a100-4fb1-a746-c446767f8736">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-13f50eab-a100-4fb1-a746-c446767f8736">
											<gml:posList>35.66804331292528 139.74758707450178 15.658 35.6680377393918 139.7475321821529 15.658 35.66788922720322 139.7475548305543 15.658 35.66789480072637 139.7476097228031 15.658 35.66804331292528 139.74758707450178 15.658</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-54933993-b41d-4324-96c6-c4d749c93e09">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-54933993-b41d-4324-96c6-c4d749c93e09">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-54933993-b41d-4324-96c6-c4d749c93e09">
											<gml:posList>35.6680377393918 139.7475321821529 5.719 35.66788922720322 139.7475548305543 5.719 35.66788922720322 139.7475548305543 15.658 35.6680377393918 139.7475321821529 15.658 35.6680377393918 139.7475321821529 5.719</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-035eae18-2739-4ee2-99f2-87acae83ef72">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-035eae18-2739-4ee2-99f2-87acae83ef72">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-035eae18-2739-4ee2-99f2-87acae83ef72">
											<gml:posList>35.66804331292528 139.74758707450178 5.719 35.6680377393918 139.7475321821529 5.719 35.6680377393918 139.7475321821529 15.658 35.66804331292528 139.74758707450178 15.658 35.66804331292528 139.74758707450178 5.719</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a9dc212b-971f-42fa-90bc-5ef42e154c73">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a9dc212b-971f-42fa-90bc-5ef42e154c73">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a9dc212b-971f-42fa-90bc-5ef42e154c73">
											<gml:posList>35.66788922720322 139.7475548305543 5.719 35.66789480072637 139.7476097228031 5.719 35.66789480072637 139.7476097228031 15.658 35.66788922720322 139.7475548305543 15.658 35.66788922720322 139.7475548305543 5.719</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6d3410f9-0172-4b77-89bf-9f8bfc916cf3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6d3410f9-0172-4b77-89bf-9f8bfc916cf3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6d3410f9-0172-4b77-89bf-9f8bfc916cf3">
											<gml:posList>35.66789480072637 139.7476097228031 5.719 35.66804331292528 139.74758707450178 5.719 35.66804331292528 139.74758707450178 15.658 35.66789480072637 139.7476097228031 15.658 35.66789480072637 139.7476097228031 5.719</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-9763</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">224</uro:landUseType>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>7</uro:specifiedFloorAreaRate>
					<uro:surveyYear>0001</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.2</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">0</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>