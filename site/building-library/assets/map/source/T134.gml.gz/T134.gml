<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_23310f9a-11a7-461d-9ea0-ca78732abfed">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">402</bldg:usage>
			<bldg:measuredHeight uom="m">14.1</bldg:measuredHeight>
			<bldg:storeysAboveGround>5</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.67210885024693 139.73806775933144 0 35.672085532686026 139.7379892464653 0 35.672017025426285 139.73801970576946 0 35.67202770811687 139.73805567147485 0 35.67199369358756 139.73807121011143 0 35.67200621997986 139.7381133927934 0 35.67210885024693 139.73806775933144 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67210885024693 139.73806775933144 9.794 35.67200621997986 139.7381133927934 9.794 35.67199369358756 139.73807121011143 9.794 35.67202770811687 139.73805567147485 9.794 35.672017025426285 139.73801970576946 9.794 35.672085532686026 139.7379892464653 9.794 35.67210885024693 139.73806775933144 9.794</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67210885024693 139.73806775933144 9.794 35.672085532686026 139.7379892464653 9.794 35.672085532686026 139.7379892464653 23.94 35.67210885024693 139.73806775933144 23.94 35.67210885024693 139.73806775933144 9.794</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672085532686026 139.7379892464653 9.794 35.672017025426285 139.73801970576946 9.794 35.672017025426285 139.73801970576946 23.94 35.672085532686026 139.7379892464653 23.94 35.672085532686026 139.7379892464653 9.794</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672017025426285 139.73801970576946 9.794 35.67202770811687 139.73805567147485 9.794 35.67202770811687 139.73805567147485 23.94 35.672017025426285 139.73801970576946 23.94 35.672017025426285 139.73801970576946 9.794</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67202770811687 139.73805567147485 9.794 35.67199369358756 139.73807121011143 9.794 35.67199369358756 139.73807121011143 23.94 35.67202770811687 139.73805567147485 23.94 35.67202770811687 139.73805567147485 9.794</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67199369358756 139.73807121011143 9.794 35.67200621997986 139.7381133927934 9.794 35.67200621997986 139.7381133927934 23.94 35.67199369358756 139.73807121011143 23.94 35.67199369358756 139.73807121011143 9.794</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67200621997986 139.7381133927934 9.794 35.67210885024693 139.73806775933144 9.794 35.67210885024693 139.73806775933144 23.94 35.67200621997986 139.7381133927934 23.94 35.67200621997986 139.7381133927934 9.794</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67210885024693 139.73806775933144 23.94 35.672085532686026 139.7379892464653 23.94 35.672017025426285 139.73801970576946 23.94 35.67202770811687 139.73805567147485 23.94 35.67199369358756 139.73807121011143 23.94 35.67200621997986 139.7381133927934 23.94 35.67210885024693 139.73806775933144 23.94</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-fe16927f-4d73-4a1c-966d-c5001686b871"/>
							<gml:surfaceMember xlink:href="#poly-8a4dd49e-1799-4d12-971e-f0fb820d57bb"/>
							<gml:surfaceMember xlink:href="#poly-cd65250c-dab6-4b2a-a97a-abb651f8f55b"/>
							<gml:surfaceMember xlink:href="#poly-f46880e1-390a-43a2-a2b1-ea6cf7b4e723"/>
							<gml:surfaceMember xlink:href="#poly-ae56eb66-dd48-4f9e-a9ea-97b4b301d20a"/>
							<gml:surfaceMember xlink:href="#poly-f88eee4f-659d-46f5-bc40-ebdfbb934062"/>
							<gml:surfaceMember xlink:href="#poly-c6c920ba-6faf-47b1-ad08-7741776d0a58"/>
							<gml:surfaceMember xlink:href="#poly-cad42ac6-2b21-4459-ab83-447274282693"/>
							<gml:surfaceMember xlink:href="#poly-5643e6fc-dd1c-45ea-b083-251212c66abd"/>
							<gml:surfaceMember xlink:href="#poly-954af3c8-f1ff-42a2-9571-86a0b5ea9e73"/>
							<gml:surfaceMember xlink:href="#poly-df854771-c2aa-4c5c-a7c1-9a1f8456771f"/>
							<gml:surfaceMember xlink:href="#poly-15b0877c-c75e-4063-bcec-defcf6f95bce"/>
							<gml:surfaceMember xlink:href="#poly-b20484a8-0c51-43f8-97b2-f513c02e12a5"/>
							<gml:surfaceMember xlink:href="#poly-19c14eac-755e-4362-9e94-d2f7eee5055c"/>
							<gml:surfaceMember xlink:href="#poly-d967e7de-a68e-48a8-95ee-09e3515f82e4"/>
							<gml:surfaceMember xlink:href="#poly-34db7528-afac-4ce6-931f-bbf7012c10a8"/>
							<gml:surfaceMember xlink:href="#poly-e6287980-c266-4b32-ad39-1b025b3cfc53"/>
							<gml:surfaceMember xlink:href="#poly-a23c6a1f-b003-4203-b05b-095a655cd142"/>
							<gml:surfaceMember xlink:href="#poly-f335e227-dd87-4099-b2f7-b893ce3fb6ca"/>
							<gml:surfaceMember xlink:href="#poly-1e941542-cd8e-444b-9ce0-60ba9d5d9819"/>
							<gml:surfaceMember xlink:href="#poly-49492b90-e446-4cdd-b7da-e39b7d02f44a"/>
							<gml:surfaceMember xlink:href="#poly-3a2f3b0e-1baa-4a98-881f-4bb11bfed598"/>
							<gml:surfaceMember xlink:href="#poly-c99be1ea-da7e-46b9-9bdf-e28301d0dd36"/>
							<gml:surfaceMember xlink:href="#poly-1effd613-5b4d-47c1-beec-87f4221b0367"/>
							<gml:surfaceMember xlink:href="#poly-a5400fb5-5fdf-44a9-ba53-9bb116096f49"/>
							<gml:surfaceMember xlink:href="#poly-e3036ec0-8aaf-4a8a-8a12-06862b26bc6e"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_23310f9a-11a7-461d-9ea0-ca78732abfed_BuildingInstallation_1041">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4866e9c9-8fcf-48a0-b9fc-729d92d68ecd">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6720652907918 139.73803850474968 19.987 35.67203870990008 139.73805064329483 19.987 35.672029302191056 139.73801979059257 19.987 35.672056108308986 139.73800750816648 19.987 35.6720652907918 139.73803850474968 19.987</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2bdb5f92-9f02-455c-b814-bc17f4349a91">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2bdb5f92-9f02-455c-b814-bc17f4349a91_0">
											<gml:posList>35.672056108308986 139.73800750816648 19.987 35.672029302191056 139.73801979059257 19.987 35.672029302191056 139.73801979059257 22.554 35.672056108308986 139.73800750816648 22.554 35.672056108308986 139.73800750816648 19.987</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8c7f784b-1511-41d8-bb5d-9875a03989f0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8c7f784b-1511-41d8-bb5d-9875a03989f0_0">
											<gml:posList>35.672029302191056 139.73801979059257 22.554 35.6720652907918 139.73803850474968 23.931 35.672056108308986 139.73800750816648 22.554 35.672029302191056 139.73801979059257 22.554</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b097c0f0-7494-4973-ab14-5fd23af6e421">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b097c0f0-7494-4973-ab14-5fd23af6e421_0">
											<gml:posList>35.672056108308986 139.73800750816648 19.987 35.672056108308986 139.73800750816648 22.554 35.6720652907918 139.73803850474968 23.931 35.6720652907918 139.73803850474968 19.987 35.672056108308986 139.73800750816648 19.987</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-676c5c83-8080-4fe7-bec5-d125f4dfec1f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-676c5c83-8080-4fe7-bec5-d125f4dfec1f_0">
											<gml:posList>35.67203870990008 139.73805064329483 19.987 35.67203870990008 139.73805064329483 22.554 35.672029302191056 139.73801979059257 22.554 35.672029302191056 139.73801979059257 19.987 35.67203870990008 139.73805064329483 19.987</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7266430d-b2a0-4250-bc21-39ec1d0cbc12">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7266430d-b2a0-4250-bc21-39ec1d0cbc12_0">
											<gml:posList>35.672029302191056 139.73801979059257 22.554 35.67203870990008 139.73805064329483 22.554 35.6720652907918 139.73803850474968 23.931 35.672029302191056 139.73801979059257 22.554</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c6f822a8-ff95-4f81-84c7-d31f2f14fff7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c6f822a8-ff95-4f81-84c7-d31f2f14fff7_0">
											<gml:posList>35.6720652907918 139.73803850474968 19.987 35.6720652907918 139.73803850474968 23.931 35.67203870990008 139.73805064329483 22.554 35.67203870990008 139.73805064329483 19.987 35.6720652907918 139.73803850474968 19.987</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_23310f9a-11a7-461d-9ea0-ca78732abfed_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-014c9571-2e97-4e86-b377-c609e5c512ec">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67201807843894 139.73808603865922 23.783 35.67200340938967 139.73809273920855 23.783 35.67199744482429 139.7380731387885 23.783 35.672012113872505 139.7380664382361 23.783 35.67201807843894 139.73808603865922 23.783</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2fe2e38c-a3db-41b7-9007-0c07b803a11a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2fe2e38c-a3db-41b7-9007-0c07b803a11a_0">
											<gml:posList>35.67200340938967 139.73809273920855 25.238 35.67199744482429 139.7380731387885 25.238 35.67199744482429 139.7380731387885 23.783 35.67200340938967 139.73809273920855 23.783 35.67200340938967 139.73809273920855 25.238</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8418a75f-8e92-4894-9bcd-75d49141b36d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8418a75f-8e92-4894-9bcd-75d49141b36d_0">
											<gml:posList>35.67199744482429 139.7380731387885 23.783 35.67199744482429 139.7380731387885 25.238 35.672012113872505 139.7380664382361 25.238 35.672012113872505 139.7380664382361 23.783 35.67199744482429 139.7380731387885 23.783</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-945b5726-918b-4171-a9df-3b5cedeee201">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-945b5726-918b-4171-a9df-3b5cedeee201_0">
											<gml:posList>35.67199744482429 139.7380731387885 25.238 35.67200340938967 139.73809273920855 25.238 35.67201807843894 139.73808603865922 25.238 35.672012113872505 139.7380664382361 25.238 35.67199744482429 139.7380731387885 25.238</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-103107ee-1f57-4eda-8bd1-62f0e3792d9f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-103107ee-1f57-4eda-8bd1-62f0e3792d9f_0">
											<gml:posList>35.67201807843894 139.73808603865922 23.783 35.67201807843894 139.73808603865922 25.238 35.67200340938967 139.73809273920855 25.238 35.67200340938967 139.73809273920855 23.783 35.67201807843894 139.73808603865922 23.783</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fc6070f7-f914-44bc-9e5c-04274afcc09b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fc6070f7-f914-44bc-9e5c-04274afcc09b_0">
											<gml:posList>35.672012113872505 139.7380664382361 23.783 35.672012113872505 139.7380664382361 25.238 35.67201807843894 139.73808603865922 25.238 35.67201807843894 139.73808603865922 23.783 35.672012113872505 139.7380664382361 23.783</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-fe16927f-4d73-4a1c-966d-c5001686b871">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fe16927f-4d73-4a1c-966d-c5001686b871">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fe16927f-4d73-4a1c-966d-c5001686b871">
											<gml:posList>35.67210885024693 139.73806775933144 9.794 35.67200621997984 139.7381133927934 9.794 35.67199369358755 139.73807121011143 9.794 35.67202770811688 139.73805567147485 9.794 35.67201702542627 139.73801970576946 9.794 35.67208553268602 139.73798924646528 9.794 35.67210885024693 139.73806775933144 9.794</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-8a4dd49e-1799-4d12-971e-f0fb820d57bb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8a4dd49e-1799-4d12-971e-f0fb820d57bb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8a4dd49e-1799-4d12-971e-f0fb820d57bb">
											<gml:posList>35.67200621997984 139.7381133927934 23.98 35.672007785134866 139.7381093037356 23.98 35.67199703015823 139.7380730950953 23.98 35.67199369358755 139.73807121011143 23.98 35.67200621997984 139.7381133927934 23.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-cd65250c-dab6-4b2a-a97a-abb651f8f55b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cd65250c-dab6-4b2a-a97a-abb651f8f55b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cd65250c-dab6-4b2a-a97a-abb651f8f55b">
											<gml:posList>35.6720652907918 139.73803850474968 23.98 35.67199369358755 139.73807121011143 23.98 35.67199703015823 139.7380730950953 23.98 35.672068627371694 139.73804040078036 23.98 35.6720652907918 139.73803850474968 23.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f46880e1-390a-43a2-a2b1-ea6cf7b4e723">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f46880e1-390a-43a2-a2b1-ea6cf7b4e723">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f46880e1-390a-43a2-a2b1-ea6cf7b4e723">
											<gml:posList>35.672105504645025 139.73806585226293 23.783 35.672083967543834 139.73799334657585 23.783 35.67205808922842 139.73800485465347 23.783 35.672068627371694 139.73804040078036 23.783 35.67199703015823 139.7380730950953 23.783 35.672007785134866 139.7381093037356 23.783 35.672105504645025 139.73806585226293 23.783</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ae56eb66-dd48-4f9e-a9ea-97b4b301d20a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ae56eb66-dd48-4f9e-a9ea-97b4b301d20a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ae56eb66-dd48-4f9e-a9ea-97b4b301d20a">
											<gml:posList>35.67210885024693 139.73806775933144 23.98 35.672105504645025 139.73806585226293 23.98 35.672007785134866 139.7381093037356 23.98 35.67200621997984 139.7381133927934 23.98 35.67210885024693 139.73806775933144 23.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f88eee4f-659d-46f5-bc40-ebdfbb934062">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f88eee4f-659d-46f5-bc40-ebdfbb934062">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f88eee4f-659d-46f5-bc40-ebdfbb934062">
											<gml:posList>35.67205475263047 139.7380029365316 23.98 35.67205808922842 139.73800485465347 23.98 35.672083967543834 139.73799334657585 23.98 35.67208553268602 139.73798924646528 23.98 35.67205475263047 139.7380029365316 23.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c6c920ba-6faf-47b1-ad08-7741776d0a58">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c6c920ba-6faf-47b1-ad08-7741776d0a58">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c6c920ba-6faf-47b1-ad08-7741776d0a58">
											<gml:posList>35.67202139004269 139.73802219708628 20.188 35.67205590948245 139.73800684561348 20.188 35.67205475263047 139.7380029365316 20.188 35.67201702542627 139.73801970576946 20.188 35.67202139004269 139.73802219708628 20.188</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-cad42ac6-2b21-4459-ab83-447274282693">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cad42ac6-2b21-4459-ab83-447274282693">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cad42ac6-2b21-4459-ab83-447274282693">
											<gml:posList>35.6720652907918 139.73803850474968 23.98 35.672068627371694 139.73804040078036 23.98 35.67205808922842 139.73800485465347 23.98 35.67205475263047 139.7380029365316 23.98 35.6720652907918 139.73803850474968 23.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-5643e6fc-dd1c-45ea-b083-251212c66abd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5643e6fc-dd1c-45ea-b083-251212c66abd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5643e6fc-dd1c-45ea-b083-251212c66abd">
											<gml:posList>35.67208553268602 139.73798924646528 23.98 35.672083967543834 139.73799334657585 23.98 35.672105504645025 139.73806585226293 23.98 35.67210885024693 139.73806775933144 23.98 35.67208553268602 139.73798924646528 23.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-954af3c8-f1ff-42a2-9571-86a0b5ea9e73">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-954af3c8-f1ff-42a2-9571-86a0b5ea9e73">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-954af3c8-f1ff-42a2-9571-86a0b5ea9e73">
											<gml:posList>35.67203092485224 139.73805419846934 19.987 35.6720652907918 139.73803850474968 19.987 35.67205590948245 139.73800684561348 19.987 35.67202139004269 139.73802219708628 19.987 35.67203092485224 139.73805419846934 19.987</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-df854771-c2aa-4c5c-a7c1-9a1f8456771f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-df854771-c2aa-4c5c-a7c1-9a1f8456771f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-df854771-c2aa-4c5c-a7c1-9a1f8456771f">
											<gml:posList>35.67202139004269 139.73802219708628 20.188 35.67201702542627 139.73801970576946 20.188 35.67202770811688 139.73805567147485 20.188 35.67203092485224 139.73805419846934 20.188 35.67202139004269 139.73802219708628 20.188</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-15b0877c-c75e-4063-bcec-defcf6f95bce">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-15b0877c-c75e-4063-bcec-defcf6f95bce">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-15b0877c-c75e-4063-bcec-defcf6f95bce">
											<gml:posList>35.67199703015823 139.7380730950953 23.98 35.67199703015823 139.7380730950953 23.783 35.672068627371694 139.73804040078036 23.783 35.672068627371694 139.73804040078036 23.98 35.67199703015823 139.7380730950953 23.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b20484a8-0c51-43f8-97b2-f513c02e12a5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b20484a8-0c51-43f8-97b2-f513c02e12a5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b20484a8-0c51-43f8-97b2-f513c02e12a5">
											<gml:posList>35.67199369358755 139.73807121011143 9.794 35.67200621997984 139.7381133927934 9.794 35.67200621997984 139.7381133927934 23.98 35.67199369358755 139.73807121011143 23.98 35.67199369358755 139.73807121011143 9.794</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-19c14eac-755e-4362-9e94-d2f7eee5055c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-19c14eac-755e-4362-9e94-d2f7eee5055c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-19c14eac-755e-4362-9e94-d2f7eee5055c">
											<gml:posList>35.672007785134866 139.7381093037356 23.98 35.672007785134866 139.7381093037356 23.783 35.67199703015823 139.7380730950953 23.783 35.67199703015823 139.7380730950953 23.98 35.672007785134866 139.7381093037356 23.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d967e7de-a68e-48a8-95ee-09e3515f82e4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d967e7de-a68e-48a8-95ee-09e3515f82e4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d967e7de-a68e-48a8-95ee-09e3515f82e4">
											<gml:posList>35.67201702542627 139.73801970576946 9.794 35.67202770811688 139.73805567147485 9.794 35.67202770811688 139.73805567147485 20.188 35.67201702542627 139.73801970576946 20.188 35.67201702542627 139.73801970576946 9.794</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-34db7528-afac-4ce6-931f-bbf7012c10a8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-34db7528-afac-4ce6-931f-bbf7012c10a8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-34db7528-afac-4ce6-931f-bbf7012c10a8">
											<gml:posList>35.67203092485224 139.73805419846934 20.188 35.67203092485224 139.73805419846934 19.987 35.67202139004269 139.73802219708628 19.987 35.67202139004269 139.73802219708628 20.188 35.67203092485224 139.73805419846934 20.188</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e6287980-c266-4b32-ad39-1b025b3cfc53">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e6287980-c266-4b32-ad39-1b025b3cfc53">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e6287980-c266-4b32-ad39-1b025b3cfc53">
											<gml:posList>35.67202770811688 139.73805567147485 20.188 35.67202770811688 139.73805567147485 9.794 35.67199369358755 139.73807121011143 9.794 35.67199369358755 139.73807121011143 23.98 35.6720652907918 139.73803850474968 23.98 35.6720652907918 139.73803850474968 19.987 35.67203092485224 139.73805419846934 19.987 35.67203092485224 139.73805419846934 20.188 35.67202770811688 139.73805567147485 20.188</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a23c6a1f-b003-4203-b05b-095a655cd142">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a23c6a1f-b003-4203-b05b-095a655cd142">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a23c6a1f-b003-4203-b05b-095a655cd142">
											<gml:posList>35.67202139004269 139.73802219708628 20.188 35.67202139004269 139.73802219708628 19.987 35.67205590948245 139.73800684561348 19.987 35.67205590948245 139.73800684561348 20.188 35.67202139004269 139.73802219708628 20.188</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f335e227-dd87-4099-b2f7-b893ce3fb6ca">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f335e227-dd87-4099-b2f7-b893ce3fb6ca">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f335e227-dd87-4099-b2f7-b893ce3fb6ca">
											<gml:posList>35.67205475263047 139.7380029365316 20.188 35.67205475263047 139.7380029365316 23.98 35.67208553268602 139.73798924646528 23.98 35.67208553268602 139.73798924646528 9.794 35.67201702542627 139.73801970576946 9.794 35.67201702542627 139.73801970576946 20.188 35.67205475263047 139.7380029365316 20.188</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1e941542-cd8e-444b-9ce0-60ba9d5d9819">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1e941542-cd8e-444b-9ce0-60ba9d5d9819">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1e941542-cd8e-444b-9ce0-60ba9d5d9819">
											<gml:posList>35.672105504645025 139.73806585226293 23.98 35.672105504645025 139.73806585226293 23.783 35.672007785134866 139.7381093037356 23.783 35.672007785134866 139.7381093037356 23.98 35.672105504645025 139.73806585226293 23.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-49492b90-e446-4cdd-b7da-e39b7d02f44a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-49492b90-e446-4cdd-b7da-e39b7d02f44a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-49492b90-e446-4cdd-b7da-e39b7d02f44a">
											<gml:posList>35.67200621997984 139.7381133927934 9.794 35.67210885024693 139.73806775933144 9.794 35.67210885024693 139.73806775933144 23.98 35.67200621997984 139.7381133927934 23.98 35.67200621997984 139.7381133927934 9.794</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3a2f3b0e-1baa-4a98-881f-4bb11bfed598">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3a2f3b0e-1baa-4a98-881f-4bb11bfed598">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3a2f3b0e-1baa-4a98-881f-4bb11bfed598">
											<gml:posList>35.67205475263047 139.7380029365316 23.98 35.67205475263047 139.7380029365316 20.188 35.67205590948245 139.73800684561348 20.188 35.67205590948245 139.73800684561348 19.987 35.6720652907918 139.73803850474968 19.987 35.6720652907918 139.73803850474968 23.98 35.67205475263047 139.7380029365316 23.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c99be1ea-da7e-46b9-9bdf-e28301d0dd36">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c99be1ea-da7e-46b9-9bdf-e28301d0dd36">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c99be1ea-da7e-46b9-9bdf-e28301d0dd36">
											<gml:posList>35.672068627371694 139.73804040078036 23.98 35.672068627371694 139.73804040078036 23.783 35.67205808922842 139.73800485465347 23.783 35.67205808922842 139.73800485465347 23.98 35.672068627371694 139.73804040078036 23.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1effd613-5b4d-47c1-beec-87f4221b0367">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1effd613-5b4d-47c1-beec-87f4221b0367">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1effd613-5b4d-47c1-beec-87f4221b0367">
											<gml:posList>35.67205808922842 139.73800485465347 23.98 35.67205808922842 139.73800485465347 23.783 35.672083967543834 139.73799334657585 23.783 35.672083967543834 139.73799334657585 23.98 35.67205808922842 139.73800485465347 23.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a5400fb5-5fdf-44a9-ba53-9bb116096f49">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a5400fb5-5fdf-44a9-ba53-9bb116096f49">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a5400fb5-5fdf-44a9-ba53-9bb116096f49">
											<gml:posList>35.672083967543834 139.73799334657585 23.98 35.672083967543834 139.73799334657585 23.783 35.672105504645025 139.73806585226293 23.783 35.672105504645025 139.73806585226293 23.98 35.672083967543834 139.73799334657585 23.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e3036ec0-8aaf-4a8a-8a12-06862b26bc6e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e3036ec0-8aaf-4a8a-8a12-06862b26bc6e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e3036ec0-8aaf-4a8a-8a12-06862b26bc6e">
											<gml:posList>35.67210885024693 139.73806775933144 9.794 35.67208553268602 139.73798924646528 9.794 35.67208553268602 139.73798924646528 23.98 35.67210885024693 139.73806775933144 23.98 35.67210885024693 139.73806775933144 9.794</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-4571</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">91.60095</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1242</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>5</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.01</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>