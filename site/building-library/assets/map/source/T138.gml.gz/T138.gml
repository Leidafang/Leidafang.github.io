<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_243506f6-a370-46bc-8416-ac374661f8f1">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">401</bldg:usage>
			<bldg:measuredHeight uom="m">26</bldg:measuredHeight>
			<bldg:storeysAboveGround>8</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.670513442361745 139.74117709444528 0 35.6705137304098 139.74118836131765 0 35.6704594395406 139.74118683304934 0 35.67046098096194 139.741104514469 0 35.670433300800774 139.7411058276767 0 35.67043236898117 139.74113669201773 0 35.670405354151896 139.74113580624245 0 35.67040741311818 139.74130578377404 0 35.670548574685775 139.74131434831182 0 35.67055883986135 139.74130063913816 0 35.67051911740043 139.74110174125565 0 35.6704837127584 139.74110342787804 0 35.670482843781784 139.74113396077803 0 35.67047400114214 139.74113373897487 0 35.67047197095904 139.74117810313848 0 35.670513442361745 139.74117709444528 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670513442361745 139.74117709444528 8.85 35.67047197095904 139.74117810313848 8.85 35.67047400114214 139.74113373897487 8.85 35.670482843781784 139.74113396077803 8.85 35.6704837127584 139.74110342787804 8.85 35.67051911740043 139.74110174125565 8.85 35.67055883986135 139.74130063913816 8.85 35.670548574685775 139.74131434831182 8.85 35.67040741311818 139.74130578377404 8.85 35.670405354151896 139.74113580624245 8.85 35.67043236898117 139.74113669201773 8.85 35.670433300800774 139.7411058276767 8.85 35.67046098096194 139.741104514469 8.85 35.6704594395406 139.74118683304934 8.85 35.6705137304098 139.74118836131765 8.85 35.670513442361745 139.74117709444528 8.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670513442361745 139.74117709444528 8.85 35.6705137304098 139.74118836131765 8.85 35.6705137304098 139.74118836131765 34.85 35.670513442361745 139.74117709444528 34.85 35.670513442361745 139.74117709444528 8.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6705137304098 139.74118836131765 8.85 35.6704594395406 139.74118683304934 8.85 35.6704594395406 139.74118683304934 34.85 35.6705137304098 139.74118836131765 34.85 35.6705137304098 139.74118836131765 8.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6704594395406 139.74118683304934 8.85 35.67046098096194 139.741104514469 8.85 35.67046098096194 139.741104514469 34.85 35.6704594395406 139.74118683304934 34.85 35.6704594395406 139.74118683304934 8.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67046098096194 139.741104514469 8.85 35.670433300800774 139.7411058276767 8.85 35.670433300800774 139.7411058276767 34.85 35.67046098096194 139.741104514469 34.85 35.67046098096194 139.741104514469 8.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670433300800774 139.7411058276767 8.85 35.67043236898117 139.74113669201773 8.85 35.67043236898117 139.74113669201773 34.85 35.670433300800774 139.7411058276767 34.85 35.670433300800774 139.7411058276767 8.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67043236898117 139.74113669201773 8.85 35.670405354151896 139.74113580624245 8.85 35.670405354151896 139.74113580624245 34.85 35.67043236898117 139.74113669201773 34.85 35.67043236898117 139.74113669201773 8.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670405354151896 139.74113580624245 8.85 35.67040741311818 139.74130578377404 8.85 35.67040741311818 139.74130578377404 34.85 35.670405354151896 139.74113580624245 34.85 35.670405354151896 139.74113580624245 8.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67040741311818 139.74130578377404 8.85 35.670548574685775 139.74131434831182 8.85 35.670548574685775 139.74131434831182 34.85 35.67040741311818 139.74130578377404 34.85 35.67040741311818 139.74130578377404 8.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670548574685775 139.74131434831182 8.85 35.67055883986135 139.74130063913816 8.85 35.67055883986135 139.74130063913816 34.85 35.670548574685775 139.74131434831182 34.85 35.670548574685775 139.74131434831182 8.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67055883986135 139.74130063913816 8.85 35.67051911740043 139.74110174125565 8.85 35.67051911740043 139.74110174125565 34.85 35.67055883986135 139.74130063913816 34.85 35.67055883986135 139.74130063913816 8.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67051911740043 139.74110174125565 8.85 35.6704837127584 139.74110342787804 8.85 35.6704837127584 139.74110342787804 34.85 35.67051911740043 139.74110174125565 34.85 35.67051911740043 139.74110174125565 8.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6704837127584 139.74110342787804 8.85 35.670482843781784 139.74113396077803 8.85 35.670482843781784 139.74113396077803 34.85 35.6704837127584 139.74110342787804 34.85 35.6704837127584 139.74110342787804 8.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670482843781784 139.74113396077803 8.85 35.67047400114214 139.74113373897487 8.85 35.67047400114214 139.74113373897487 34.85 35.670482843781784 139.74113396077803 34.85 35.670482843781784 139.74113396077803 8.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67047400114214 139.74113373897487 8.85 35.67047197095904 139.74117810313848 8.85 35.67047197095904 139.74117810313848 34.85 35.67047400114214 139.74113373897487 34.85 35.67047400114214 139.74113373897487 8.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67047197095904 139.74117810313848 8.85 35.670513442361745 139.74117709444528 8.85 35.670513442361745 139.74117709444528 34.85 35.67047197095904 139.74117810313848 34.85 35.67047197095904 139.74117810313848 8.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670513442361745 139.74117709444528 34.85 35.6705137304098 139.74118836131765 34.85 35.6704594395406 139.74118683304934 34.85 35.67046098096194 139.741104514469 34.85 35.670433300800774 139.7411058276767 34.85 35.67043236898117 139.74113669201773 34.85 35.670405354151896 139.74113580624245 34.85 35.67040741311818 139.74130578377404 34.85 35.670548574685775 139.74131434831182 34.85 35.67055883986135 139.74130063913816 34.85 35.67051911740043 139.74110174125565 34.85 35.6704837127584 139.74110342787804 34.85 35.670482843781784 139.74113396077803 34.85 35.67047400114214 139.74113373897487 34.85 35.67047197095904 139.74117810313848 34.85 35.670513442361745 139.74117709444528 34.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-6e65c926-fc01-4bda-8fc9-f84fc4a79e22"/>
							<gml:surfaceMember xlink:href="#poly-8478e94e-5bee-4141-9d36-6803266c4f7b"/>
							<gml:surfaceMember xlink:href="#poly-9b0f952c-2060-40c1-a5e6-4ea2ad881707"/>
							<gml:surfaceMember xlink:href="#poly-577374bf-7a8b-4be2-befa-83bbe58f59fd"/>
							<gml:surfaceMember xlink:href="#poly-7c8befd2-fbc5-4795-8053-47000e9f804e"/>
							<gml:surfaceMember xlink:href="#poly-8b120309-4a48-4f45-b152-7b78f9af27d4"/>
							<gml:surfaceMember xlink:href="#poly-7dea0cef-bb73-486d-9967-34ecfac3e4f8"/>
							<gml:surfaceMember xlink:href="#poly-d86d1844-acf9-438f-9712-c6f095db5d2a"/>
							<gml:surfaceMember xlink:href="#poly-cfabd4d3-506c-43eb-9cf8-e21e0bc6e054"/>
							<gml:surfaceMember xlink:href="#poly-15f71a21-7423-4421-aece-9725bae2ac9d"/>
							<gml:surfaceMember xlink:href="#poly-f2e85290-ff6f-472b-9f61-4b707e5e97e2"/>
							<gml:surfaceMember xlink:href="#poly-20a97099-f61a-40d9-af36-6619b40c27e7"/>
							<gml:surfaceMember xlink:href="#poly-bfb2633a-d3fe-473e-af6b-4565d755266f"/>
							<gml:surfaceMember xlink:href="#poly-630ad6de-a072-4332-aa9e-c916e13f80ea"/>
							<gml:surfaceMember xlink:href="#poly-65f70f2f-6d99-4089-81c2-d52b10755764"/>
							<gml:surfaceMember xlink:href="#poly-b098ecda-e8ab-4861-af7e-41ead9cf7574"/>
							<gml:surfaceMember xlink:href="#poly-e4d7fc81-6ae1-4cb0-9cc1-364f6bc9d762"/>
							<gml:surfaceMember xlink:href="#poly-ab33d366-bc6b-42c2-9ae6-1bd77c20ede6"/>
							<gml:surfaceMember xlink:href="#poly-ecd23e93-2dee-4c8c-ada9-2c3b6a48344c"/>
							<gml:surfaceMember xlink:href="#poly-6102da76-38d3-4b6d-a215-c85fa279d16a"/>
							<gml:surfaceMember xlink:href="#poly-3d41905d-d24c-48a6-b55e-55396c3efde9"/>
							<gml:surfaceMember xlink:href="#poly-2f0cf8f8-c861-4ce8-a3be-67fe5acdbe6b"/>
							<gml:surfaceMember xlink:href="#poly-2a771488-a32c-4c2f-a9e2-cda1b6329e1d"/>
							<gml:surfaceMember xlink:href="#poly-ad2af69f-e577-4cc1-b0bc-6eb5467c321f"/>
							<gml:surfaceMember xlink:href="#poly-7595e3a1-1374-4ec4-86a5-300081f6a69f"/>
							<gml:surfaceMember xlink:href="#poly-46ae1a34-ebc4-4eae-8331-7d187eb611c6"/>
							<gml:surfaceMember xlink:href="#poly-df940631-ca18-4844-b922-26d479bb0e91"/>
							<gml:surfaceMember xlink:href="#poly-3f5d2170-7762-4190-a0bd-f5a80b1002c2"/>
							<gml:surfaceMember xlink:href="#poly-c41ae021-edf6-465e-b801-76c07aad0995"/>
							<gml:surfaceMember xlink:href="#poly-00ca71ed-9681-46ba-8c1e-c60d6a1f3e3a"/>
							<gml:surfaceMember xlink:href="#poly-c87a2019-74ff-49c8-9ac7-f69d59b168f7"/>
							<gml:surfaceMember xlink:href="#poly-1ababb61-5210-4c9b-9b52-f19139889b63"/>
							<gml:surfaceMember xlink:href="#poly-cea0e60f-e666-4c31-965b-d269f7bd408e"/>
							<gml:surfaceMember xlink:href="#poly-e880ad5f-ba6c-408c-9b26-e7511ab58b9f"/>
							<gml:surfaceMember xlink:href="#poly-50dccc54-c2cf-4369-ba10-1c5fa054636b"/>
							<gml:surfaceMember xlink:href="#poly-a6442a28-70de-4881-b710-f6723132f012"/>
							<gml:surfaceMember xlink:href="#poly-0464a397-370b-418a-ad2c-e7437b528c35"/>
							<gml:surfaceMember xlink:href="#poly-65bb7312-3739-4462-9b97-fcb0c3cb0144"/>
							<gml:surfaceMember xlink:href="#poly-d5e0d983-14dd-45c3-8344-d0a632df7290"/>
							<gml:surfaceMember xlink:href="#poly-79af6bfc-a269-44c8-a717-e19adc1b5eec"/>
							<gml:surfaceMember xlink:href="#poly-e070c05c-324a-405d-b1af-ff22892679c7"/>
							<gml:surfaceMember xlink:href="#poly-01fbb3dd-3271-42d6-9f0d-3484337bc5c4"/>
							<gml:surfaceMember xlink:href="#poly-729d0752-2563-40f9-b0bb-a22aa6705ec2"/>
							<gml:surfaceMember xlink:href="#poly-f191c9f5-1912-4eaf-82ba-432177bf8a43"/>
							<gml:surfaceMember xlink:href="#poly-4cc54b81-aba8-4716-ba64-4638a544a71c"/>
							<gml:surfaceMember xlink:href="#poly-cc35a278-1598-4aa6-8fbf-d2002c23581e"/>
							<gml:surfaceMember xlink:href="#poly-34a5757e-85d3-4a7c-9d87-e151fb0b8e32"/>
							<gml:surfaceMember xlink:href="#poly-23e28b84-555a-481d-b29e-60c57559828d"/>
							<gml:surfaceMember xlink:href="#poly-21c65d17-73bb-4105-841e-322b5b3f1881"/>
							<gml:surfaceMember xlink:href="#poly-cde30f7b-b6e0-4e11-aaec-4ab379599aab"/>
							<gml:surfaceMember xlink:href="#poly-2f5512bf-b581-4e29-8f73-416b8081c8db"/>
							<gml:surfaceMember xlink:href="#poly-ef71913b-99e5-440c-8cb1-f24cfe2c30e9"/>
							<gml:surfaceMember xlink:href="#poly-2a5d0a34-4afc-43c1-b3f2-f8398b00a43e"/>
							<gml:surfaceMember xlink:href="#poly-c74460dc-de93-4aee-898b-c3c0c85ee0ec"/>
							<gml:surfaceMember xlink:href="#poly-ffb73196-99d1-416b-acb8-aa4b71a1d405"/>
							<gml:surfaceMember xlink:href="#poly-18d0f4c6-2430-49c9-ad0f-e2452bc49413"/>
							<gml:surfaceMember xlink:href="#poly-f1d69aef-310b-4462-a3b8-d18f1c5beef8"/>
							<gml:surfaceMember xlink:href="#poly-fdde9a87-c8c3-4eb6-ba1e-237d208f51b0"/>
							<gml:surfaceMember xlink:href="#poly-cebce600-2118-402a-aef5-2a6f6f667c93"/>
							<gml:surfaceMember xlink:href="#poly-4a6e0865-71ed-4506-bb18-05d315b16e98"/>
							<gml:surfaceMember xlink:href="#poly-b9fe0ac7-e401-4a98-8682-3da342564d36"/>
							<gml:surfaceMember xlink:href="#poly-3ed9be4e-c343-48b6-918e-e23abd34f455"/>
							<gml:surfaceMember xlink:href="#poly-ba3ef0e6-4b6a-43d9-b1ef-f95590890502"/>
							<gml:surfaceMember xlink:href="#poly-88d5d088-7d57-487b-abd9-0506412e8f53"/>
							<gml:surfaceMember xlink:href="#poly-2c132443-1a4d-4188-a201-f23496971867"/>
							<gml:surfaceMember xlink:href="#poly-ffefb602-f295-45c3-92ef-c4d058a79cf0"/>
							<gml:surfaceMember xlink:href="#poly-733a51f7-3df5-4c94-ae1e-228d25c53a37"/>
							<gml:surfaceMember xlink:href="#poly-3e557d2a-6b66-402c-974b-e8172c04d1ff"/>
							<gml:surfaceMember xlink:href="#poly-b5920a2c-861e-4537-8a92-0f979607ff4a"/>
							<gml:surfaceMember xlink:href="#poly-c1644473-2a76-4190-b64f-f91a631e269b"/>
							<gml:surfaceMember xlink:href="#poly-20ed6779-be52-4338-b95e-7c5d001a93c7"/>
							<gml:surfaceMember xlink:href="#poly-2609b77c-ec35-4253-b08b-cf9d7cce29e2"/>
							<gml:surfaceMember xlink:href="#poly-ee40e491-d4e9-4b06-a185-3656417689ee"/>
							<gml:surfaceMember xlink:href="#poly-ba4834b0-ae9c-4387-a5a2-021da12e2c4a"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_243506f6-a370-46bc-8416-ac374661f8f1_BuildingInstallation_1060">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f2643d73-a6fd-499d-8ae8-9e5c1743289b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f2643d73-a6fd-499d-8ae8-9e5c1743289b_0">
											<gml:posList>35.6704837127584 139.74110342787804 8.89 35.67046098095347 139.74110450342272 36.802 35.6704837127584 139.74110342787804 36.802 35.6704837127584 139.74110342787804 8.89</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4a2de7ec-e546-4689-83c3-8e30f3d4e7a2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4a2de7ec-e546-4689-83c3-8e30f3d4e7a2_0">
											<gml:posList>35.6704837127584 139.74110342787804 8.89 35.67046098095347 139.74110450342272 8.89 35.67046098095347 139.74110450342272 36.802 35.6704837127584 139.74110342787804 8.89</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-adf3465c-b0d0-4249-8bc1-6f8bafbfbdb6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-adf3465c-b0d0-4249-8bc1-6f8bafbfbdb6_0">
											<gml:posList>35.670427694459796 139.74110608818975 36.802 35.670433300800774 139.7411058276767 36.802 35.67040500773171 139.7411071747273 34.908 35.670427694459796 139.74110608818975 36.802</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6a20eff3-d1a5-419b-9bfe-c3b532ade962">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6a20eff3-d1a5-419b-9bfe-c3b532ade962_0">
											<gml:posList>35.670433300800774 139.7411058276767 36.802 35.670433300800774 139.7411058276767 8.85 35.67040500773171 139.7411071747273 34.908 35.670433300800774 139.7411058276767 36.802</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d75221b7-6236-4a48-822d-c5e2a311522a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d75221b7-6236-4a48-822d-c5e2a311522a_0">
											<gml:posList>35.670433300800774 139.7411058276767 8.85 35.67040500773171 139.7411071747273 8.85 35.67040500773171 139.7411071747273 34.908 35.670433300800774 139.7411058276767 8.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-11f1f287-85ea-4a7b-87ac-aefd3b1005cd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-11f1f287-85ea-4a7b-87ac-aefd3b1005cd_0">
											<gml:posList>35.670482843781755 139.74113396077803 8.89 35.6704837127584 139.74110342787804 8.89 35.670482843781755 139.74113396077803 8.901 35.670482843781755 139.74113396077803 8.89</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-47e41733-eded-4961-ad3a-2575bc3d1329">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-47e41733-eded-4961-ad3a-2575bc3d1329_0">
											<gml:posList>35.670482843781755 139.74113396077803 8.901 35.6704837127584 139.74110342787804 36.802 35.670482843781755 139.74113396077803 36.802 35.670482843781755 139.74113396077803 8.901</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-317063b1-fcbc-426a-bf90-d2cf436da43c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-317063b1-fcbc-426a-bf90-d2cf436da43c_0">
											<gml:posList>35.670482843781755 139.74113396077803 8.901 35.6704837127584 139.74110342787804 8.89 35.6704837127584 139.74110342787804 36.802 35.670482843781755 139.74113396077803 8.901</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cd0b9862-b847-46e7-ac5c-3650e560844f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cd0b9862-b847-46e7-ac5c-3650e560844f_0">
											<gml:posList>35.670427694459796 139.74110608818975 36.802 35.670427402293036 139.74113653203497 36.802 35.67043236898117 139.74113669201773 36.802 35.670427694459796 139.74110608818975 36.802</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9d1a2042-1e66-4ebc-b1e1-fbeedda180ed">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9d1a2042-1e66-4ebc-b1e1-fbeedda180ed_0">
											<gml:posList>35.670433300800774 139.7411058276767 36.802 35.670427694459796 139.74110608818975 36.802 35.67043236898117 139.74113669201773 36.802 35.670433300800774 139.7411058276767 36.802</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-735a7644-10a1-4fe5-bd08-27b82defc88b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-735a7644-10a1-4fe5-bd08-27b82defc88b_0">
											<gml:posList>35.67043236898117 139.74113669201773 36.802 35.670433300800774 139.7411058276767 8.85 35.670433300800774 139.7411058276767 36.802 35.67043236898117 139.74113669201773 36.802</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b911af99-4579-4c1a-91f6-87a374df535e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b911af99-4579-4c1a-91f6-87a374df535e_0">
											<gml:posList>35.67043236898117 139.74113669201773 36.802 35.67043236898117 139.74113669201773 8.85 35.670433300800774 139.7411058276767 8.85 35.67043236898117 139.74113669201773 36.802</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-270a90d1-377a-4404-a984-4854ccd383a8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-270a90d1-377a-4404-a984-4854ccd383a8_0">
											<gml:posList>35.67040500773171 139.7411071747273 34.908 35.67040535416036 139.74113581728872 34.908 35.670427402293036 139.74113653203497 36.802 35.67040500773171 139.7411071747273 34.908</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e99d272f-d614-488e-bbce-475544815142">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e99d272f-d614-488e-bbce-475544815142_0">
											<gml:posList>35.670427694459796 139.74110608818975 36.802 35.67040500773171 139.7411071747273 34.908 35.670427402293036 139.74113653203497 36.802 35.670427694459796 139.74110608818975 36.802</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bc60c8f6-c8d7-4771-b056-056d7d9d8068">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bc60c8f6-c8d7-4771-b056-056d7d9d8068_0">
											<gml:posList>35.67040500773171 139.7411071747273 8.85 35.67040535416036 139.74113581728872 34.908 35.67040500773171 139.7411071747273 34.908 35.67040500773171 139.7411071747273 8.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6bda8619-bd66-40dd-8bf4-79fc82ccf84d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6bda8619-bd66-40dd-8bf4-79fc82ccf84d_0">
											<gml:posList>35.67040500773171 139.7411071747273 8.85 35.67040535416036 139.74113581728872 8.85 35.67040535416036 139.74113581728872 34.908 35.67040500773171 139.7411071747273 8.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c346379f-4222-4c21-9159-9f2eb8abbcbe">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c346379f-4222-4c21-9159-9f2eb8abbcbe_0">
											<gml:posList>35.670474001142146 139.74113373897484 30.905 35.670482843781755 139.74113396077803 36.802 35.670474001142146 139.74113373897484 36.802 35.670474001142146 139.74113373897484 30.905</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-75cb46b5-d912-4daf-a023-de73660a4ff2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-75cb46b5-d912-4daf-a023-de73660a4ff2_0">
											<gml:posList>35.670474001142146 139.74113373897484 30.905 35.670482843781755 139.74113396077803 8.901 35.670482843781755 139.74113396077803 36.802 35.670474001142146 139.74113373897484 30.905</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a030e29e-667c-4879-890b-15722a896caa">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a030e29e-667c-4879-890b-15722a896caa_0">
											<gml:posList>35.670482843781755 139.74113396077803 8.901 35.670474001142146 139.74113373897484 8.89 35.670482843781755 139.74113396077803 8.89 35.670482843781755 139.74113396077803 8.901</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8cbacd31-6a1d-46af-9c43-a538b965f653">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8cbacd31-6a1d-46af-9c43-a538b965f653_0">
											<gml:posList>35.670482843781755 139.74113396077803 8.901 35.670474001142146 139.74113373897484 30.905 35.670474001142146 139.74113373897484 8.89 35.670482843781755 139.74113396077803 8.901</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-15046b33-2544-4a50-b993-bf925e3a4143">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-15046b33-2544-4a50-b993-bf925e3a4143_0">
											<gml:posList>35.670427402293036 139.74113653203497 36.802 35.67040535416036 139.74113581728872 34.908 35.67043236898117 139.74113669201773 36.802 35.670427402293036 139.74113653203497 36.802</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e1130568-e8f9-4c3b-8eb8-5a2052325576">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e1130568-e8f9-4c3b-8eb8-5a2052325576_0">
											<gml:posList>35.67043236898117 139.74113669201773 36.802 35.67040535416036 139.74113581728872 34.908 35.67043236898117 139.74113669201773 8.85 35.67043236898117 139.74113669201773 36.802</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9ee8635d-b3f6-4f76-8bed-2735dc3974fe">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9ee8635d-b3f6-4f76-8bed-2735dc3974fe_0">
											<gml:posList>35.67040535416036 139.74113581728872 34.908 35.67040535416036 139.74113581728872 8.85 35.67043236898117 139.74113669201773 8.85 35.67040535416036 139.74113581728872 34.908</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e75b6edf-e4c7-4193-818c-5877763a6f30">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e75b6edf-e4c7-4193-818c-5877763a6f30_0">
											<gml:posList>35.67045943954058 139.74118683304934 8.89 35.67046098095347 139.74110450342272 36.802 35.67046098095347 139.74110450342272 8.89 35.67045943954058 139.74118683304934 8.89</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-45602a79-21c5-40b4-acf6-f02a58efcbe2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-45602a79-21c5-40b4-acf6-f02a58efcbe2_0">
											<gml:posList>35.67045943954058 139.74118683304934 8.89 35.67045943954058 139.74118683304934 36.802 35.67046098095347 139.74110450342272 36.802 35.67045943954058 139.74118683304934 8.89</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7e638372-c0c1-41b5-a3ba-96811fbf995f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7e638372-c0c1-41b5-a3ba-96811fbf995f_0">
											<gml:posList>35.670474001142146 139.74113373897484 36.802 35.6704837127584 139.74110342787804 36.802 35.67046098095347 139.74110450342272 36.802 35.670474001142146 139.74113373897484 36.802</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b4027bd0-ffda-4abc-b4d0-6f413144ff2e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b4027bd0-ffda-4abc-b4d0-6f413144ff2e_0">
											<gml:posList>35.67045943954058 139.74118683304934 36.802 35.670474001142146 139.74113373897484 36.802 35.67046098095347 139.74110450342272 36.802 35.67045943954058 139.74118683304934 36.802</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cbd30ac9-eefb-436e-9479-18397e4f81c8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cbd30ac9-eefb-436e-9479-18397e4f81c8_0">
											<gml:posList>35.670474001142146 139.74113373897484 36.802 35.670482843781755 139.74113396077803 36.802 35.6704837127584 139.74110342787804 36.802 35.670474001142146 139.74113373897484 36.802</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-eeb33326-9ae8-4ed4-9701-c966f09c4483">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-eeb33326-9ae8-4ed4-9701-c966f09c4483_0">
											<gml:posList>35.670513730325254 139.74118825085495 36.802 35.67051344236174 139.74117709444525 36.802 35.67047197095905 139.74117810313845 36.802 35.670513730325254 139.74118825085495 36.802</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c43c7668-ef25-4459-aece-251282175c25">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c43c7668-ef25-4459-aece-251282175c25_0">
											<gml:posList>35.670461972447406 139.74118689641594 36.802 35.670513730325254 139.74118825085495 36.802 35.67047197095905 139.74117810313845 36.802 35.670461972447406 139.74118689641594 36.802</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a0f881b6-f8ae-4968-8a6e-f994aa24e31c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a0f881b6-f8ae-4968-8a6e-f994aa24e31c_0">
											<gml:posList>35.67047197095905 139.74117810313845 36.802 35.67045943954058 139.74118683304934 36.802 35.670461972447406 139.74118689641594 36.802 35.67047197095905 139.74117810313845 36.802</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f3541e88-a7a9-4d18-bd73-ff66efb8e079">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f3541e88-a7a9-4d18-bd73-ff66efb8e079_0">
											<gml:posList>35.67045943954058 139.74118683304934 36.802 35.67047197095905 139.74117810313845 36.802 35.670474001142146 139.74113373897484 36.802 35.67045943954058 139.74118683304934 36.802</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1fd49662-ee5e-4d83-99b8-5b19dec90d86">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1fd49662-ee5e-4d83-99b8-5b19dec90d86_0">
											<gml:posList>35.67047327416162 139.74114960225793 30.911 35.670474001142146 139.74113373897484 36.802 35.67047197095905 139.74117810313845 36.802 35.67047327416162 139.74114960225793 30.911</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9d858c29-0926-4d00-9846-9f311b78c262">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9d858c29-0926-4d00-9846-9f311b78c262_0">
											<gml:posList>35.670472006489796 139.74117741822872 9.419 35.67047197095905 139.74117810313845 36.802 35.67047197095905 139.74117810313845 8.89 35.670472006489796 139.74117741822872 9.419</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-afb4081f-c846-4b86-a847-6b28d07c05b7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-afb4081f-c846-4b86-a847-6b28d07c05b7_0">
											<gml:posList>35.670474001142146 139.74113373897484 30.905 35.670474001142146 139.74113373897484 36.802 35.67047327416162 139.74114960225793 30.911 35.670474001142146 139.74113373897484 30.905</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d05a198f-8da5-4b20-82fd-cd9e49f5f7ba">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d05a198f-8da5-4b20-82fd-cd9e49f5f7ba_0">
											<gml:posList>35.670471979829045 139.74117791534164 8.982 35.67047197095905 139.74117810313845 8.89 35.670474001142146 139.74113373897484 8.89 35.670471979829045 139.74117791534164 8.982</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9cc6d259-cc1f-46a4-9f08-3ad630c977c9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9cc6d259-cc1f-46a4-9f08-3ad630c977c9_0">
											<gml:posList>35.67047327416162 139.74114960225793 23.018 35.670474001142146 139.74113373897484 8.89 35.670474001142146 139.74113373897484 30.905 35.67047327416162 139.74114960225793 23.018</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-17a46660-7172-48a3-ab49-a23358a2a0c9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-17a46660-7172-48a3-ab49-a23358a2a0c9_0">
											<gml:posList>35.67047197095905 139.74117810313845 36.802 35.670472006489796 139.74117741822872 9.419 35.67047327416162 139.74114960225793 30.911 35.67047197095905 139.74117810313845 36.802</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3c50beeb-cd41-4661-bea4-d8a32534ce3f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3c50beeb-cd41-4661-bea4-d8a32534ce3f_0">
											<gml:posList>35.670471979829045 139.74117791534164 8.982 35.670472006489796 139.74117741822872 9.419 35.67047197095905 139.74117810313845 8.89 35.670471979829045 139.74117791534164 8.982</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-55b28155-6da4-411e-a770-750d217debd1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-55b28155-6da4-411e-a770-750d217debd1_0">
											<gml:posList>35.67047327416162 139.74114960225793 23.018 35.670474001142146 139.74113373897484 30.905 35.67047327416162 139.74114960225793 30.911 35.67047327416162 139.74114960225793 23.018</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bc050c76-fa53-4f26-92b2-b46eafcea259">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bc050c76-fa53-4f26-92b2-b46eafcea259_0">
											<gml:posList>35.67047327416162 139.74114960225793 23.018 35.670471979829045 139.74117791534164 8.982 35.670474001142146 139.74113373897484 8.89 35.67047327416162 139.74114960225793 23.018</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a05ab08c-5d38-4578-8d59-2e70fdd3f236">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a05ab08c-5d38-4578-8d59-2e70fdd3f236_0">
											<gml:posList>35.670472006489796 139.74117741822872 9.419 35.67047327416162 139.74114960225793 23.018 35.67047327416162 139.74114960225793 30.911 35.670472006489796 139.74117741822872 9.419</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-55f4c081-b825-4828-b374-9af7fed6b8a6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-55f4c081-b825-4828-b374-9af7fed6b8a6_0">
											<gml:posList>35.670472006489796 139.74117741822872 9.419 35.670471979829045 139.74117791534164 8.982 35.67047327416162 139.74114960225793 23.018 35.670472006489796 139.74117741822872 9.419</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e3e215b1-0004-479c-a390-1721d4377b89">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e3e215b1-0004-479c-a390-1721d4377b89_0">
											<gml:posList>35.67051344236174 139.74117709444525 8.89 35.67047197095905 139.74117810313845 36.802 35.67051344236174 139.74117709444525 36.802 35.67051344236174 139.74117709444525 8.89</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4d36632e-a64d-4bb2-aabf-49bfdb87f5e3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4d36632e-a64d-4bb2-aabf-49bfdb87f5e3_0">
											<gml:posList>35.67051344236174 139.74117709444525 8.89 35.67047197095905 139.74117810313845 8.89 35.67047197095905 139.74117810313845 36.802 35.67051344236174 139.74117709444525 8.89</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-490c1fff-083e-40c3-923e-cda9fa5c94f0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-490c1fff-083e-40c3-923e-cda9fa5c94f0_0">
											<gml:posList>35.670513730325254 139.74118825085495 36.802 35.67051373040979 139.74118836131765 27.883 35.67051344236174 139.74117709444525 36.802 35.670513730325254 139.74118825085495 36.802</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b8aaf189-b52a-4e46-b5ee-a1a24a9a9861">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b8aaf189-b52a-4e46-b5ee-a1a24a9a9861_0">
											<gml:posList>35.67051344236174 139.74117709444525 36.802 35.67051373040979 139.74118836131765 27.883 35.67051344236174 139.74117709444525 8.89 35.67051344236174 139.74117709444525 36.802</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fa737123-5f61-4362-b8e1-f02056d92363">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fa737123-5f61-4362-b8e1-f02056d92363_0">
											<gml:posList>35.67051373040979 139.74118836131765 27.883 35.67051373040979 139.74118836131765 8.89 35.67051344236174 139.74117709444525 8.89 35.67051373040979 139.74118836131765 27.883</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-737ce55a-b618-44ea-b497-fbf862eff748">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-737ce55a-b618-44ea-b497-fbf862eff748_0">
											<gml:posList>35.67051373040979 139.74118836131765 27.883 35.670461972447406 139.74118689641594 36.508 35.67045943954058 139.74118683304934 8.89 35.67051373040979 139.74118836131765 27.883</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-be0cb8bd-09d4-4162-80d7-13f71b437aaa">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-be0cb8bd-09d4-4162-80d7-13f71b437aaa_0">
											<gml:posList>35.670461972447406 139.74118689641594 36.802 35.67045943954058 139.74118683304934 36.802 35.670461972447406 139.74118689641594 36.508 35.670461972447406 139.74118689641594 36.802</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-97824ab1-6791-4a20-8fc3-4e06d99a3369">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-97824ab1-6791-4a20-8fc3-4e06d99a3369_0">
											<gml:posList>35.67051373040979 139.74118836131765 27.883 35.67045943954058 139.74118683304934 8.89 35.67051373040979 139.74118836131765 8.89 35.67051373040979 139.74118836131765 27.883</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-56d6234d-3e4f-4762-9aad-0f6d174cfbb0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-56d6234d-3e4f-4762-9aad-0f6d174cfbb0_0">
											<gml:posList>35.670461972447406 139.74118689641594 36.508 35.67045943954058 139.74118683304934 36.802 35.67045943954058 139.74118683304934 8.89 35.670461972447406 139.74118689641594 36.508</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ba620332-fbd5-403e-baa2-95c4bca9b48b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ba620332-fbd5-403e-baa2-95c4bca9b48b_0">
											<gml:posList>35.670513730325254 139.74118825085495 36.802 35.670461972447406 139.74118689641594 36.508 35.67051373040979 139.74118836131765 27.883 35.670513730325254 139.74118825085495 36.802</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e4bf29da-056e-4377-9170-13810a77252d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e4bf29da-056e-4377-9170-13810a77252d_0">
											<gml:posList>35.670513730325254 139.74118825085495 36.802 35.670461972447406 139.74118689641594 36.802 35.670461972447406 139.74118689641594 36.508 35.670513730325254 139.74118825085495 36.802</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c920f841-5d9b-480e-ab46-3d26aa9cbaff">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67043236898117 139.74113669201773 8.85 35.67040535416036 139.74113581728872 8.85 35.67040500773171 139.7411071747273 8.85 35.67043236898117 139.74113669201773 8.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3a10ae0f-dfa0-4f05-a4a2-cf34545d5afb">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670433300800774 139.7411058276767 8.85 35.67043236898117 139.74113669201773 8.85 35.67040500773171 139.7411071747273 8.85 35.670433300800774 139.7411058276767 8.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b93885d6-6844-4b03-a77a-aaa6e556da89">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67051344236174 139.74117709444525 8.89 35.67051373040979 139.74118836131765 8.89 35.67047197095905 139.74117810313845 8.89 35.67051344236174 139.74117709444525 8.89</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d6be15b6-13ee-41be-a348-7e9c9c7b82e4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670474001142146 139.74113373897484 8.89 35.6704837127584 139.74110342787804 8.89 35.670482843781755 139.74113396077803 8.89 35.670474001142146 139.74113373897484 8.89</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f03b6234-c6c2-4cba-a10a-445724082619">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6704837127584 139.74110342787804 8.89 35.670474001142146 139.74113373897484 8.89 35.67046098095347 139.74110450342272 8.89 35.6704837127584 139.74110342787804 8.89</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6c3a67a9-fbd3-4fab-88b6-e2fa0e4257df">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67051373040979 139.74118836131765 8.89 35.67045943954058 139.74118683304934 8.89 35.67047197095905 139.74117810313845 8.89 35.67051373040979 139.74118836131765 8.89</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5b9fe762-426b-4b16-b943-47b9cffc4b43">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67045943954058 139.74118683304934 8.89 35.67046098095347 139.74110450342272 8.89 35.670474001142146 139.74113373897484 8.89 35.67045943954058 139.74118683304934 8.89</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-80b258fe-1c43-4998-81d1-6f01069d0042">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67045943954058 139.74118683304934 8.89 35.670474001142146 139.74113373897484 8.89 35.67047197095905 139.74117810313845 8.89 35.67045943954058 139.74118683304934 8.89</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_243506f6-a370-46bc-8416-ac374661f8f1_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-82b09cd5-ffd0-44a4-985d-1955b1480402">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670446119477994 139.74120152884885 36.362 35.67043080508689 139.74120144703022 36.362 35.670430861685844 139.74118117706615 36.362 35.67044617606849 139.74118124783467 36.362 35.670446119477994 139.74120152884885 36.362</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-530df1f4-15ae-4191-8a34-a39746b7fae0">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67045114200822 139.7411215591341 41.099 35.67045117043308 139.7411469102894 41.099 35.67044051622123 139.7411469335857 41.099 35.67044047878265 139.7411215824441 41.099 35.67045114200822 139.7411215591341 41.099</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5f787c6a-5663-4f6c-8ad0-f957016659ce">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670488104498155 139.7412120850272 40.101 35.6704696532556 139.74121190739424 40.101 35.670469725834735 139.74120073953 40.101 35.67048817707732 139.74120091716043 40.101 35.670488104498155 139.7412120850272 40.101</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b8bc2311-532f-407b-9f7d-899805a57838">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670507262263875 139.7412049933982 36.362 35.6705069625285 139.74123735933418 36.362 35.67046561610919 139.74123678823577 36.362 35.67046574137878 139.7412237976768 36.362 35.67049694724179 139.7412242257703 36.362 35.67049712170751 139.74120485040245 36.362 35.670507262263875 139.7412049933982 36.362</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cef82d20-6211-4ed5-b423-a9a03eaf9aa2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67051441909792 139.74122846956163 36.362 35.670514691678996 139.74121952176327 36.362 35.670527158113764 139.74122010393995 36.362 35.67052688553265 139.7412290517397 36.362 35.67051441909792 139.74122846956163 36.362</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-29bdb167-cf22-4bbf-bfac-5e99330e26d4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-29bdb167-cf22-4bbf-bfac-5e99330e26d4_0">
											<gml:posList>35.67045114200822 139.7411215591341 41.099 35.67044047878265 139.7411215824441 41.099 35.67044047878265 139.7411215824441 41.939 35.67045114200822 139.7411215591341 41.939 35.67045114200822 139.7411215591341 41.099</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7921b28c-e22a-4d7c-a39c-240971e54746">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7921b28c-e22a-4d7c-a39c-240971e54746_0">
											<gml:posList>35.67045117043308 139.7411469102894 41.099 35.67045114200822 139.7411215591341 41.099 35.67045114200822 139.7411215591341 41.939 35.67045117043308 139.7411469102894 41.939 35.67045117043308 139.7411469102894 41.099</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-49dd33c7-c295-4ee4-b436-c696cd9af608">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-49dd33c7-c295-4ee4-b436-c696cd9af608_0">
											<gml:posList>35.67045114200822 139.7411215591341 41.939 35.67044047878265 139.7411215824441 41.939 35.67044051622123 139.7411469335857 41.939 35.67045117043308 139.7411469102894 41.939 35.67045114200822 139.7411215591341 41.939</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-68510a87-0d1c-4140-83d4-f84078ca512e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-68510a87-0d1c-4140-83d4-f84078ca512e_0">
											<gml:posList>35.67044051622123 139.7411469335857 41.099 35.67044051622123 139.7411469335857 41.939 35.67044047878265 139.7411215824441 41.939 35.67044047878265 139.7411215824441 41.099 35.67044051622123 139.7411469335857 41.099</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-145e726b-939c-4f14-a9b7-63c55c8e174e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-145e726b-939c-4f14-a9b7-63c55c8e174e_0">
											<gml:posList>35.67044051622123 139.7411469335857 41.099 35.67045117043308 139.7411469102894 41.099 35.67045117043308 139.7411469102894 41.939 35.67044051622123 139.7411469335857 41.939 35.67044051622123 139.7411469335857 41.099</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ce10c532-a133-4eec-b97b-a21d9c6776b2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ce10c532-a133-4eec-b97b-a21d9c6776b2_0">
											<gml:posList>35.67044617606849 139.74118124783467 36.362 35.670430861685844 139.74118117706615 36.362 35.670430861685844 139.74118117706615 38.454 35.67044617606849 139.74118124783467 38.454 35.67044617606849 139.74118124783467 36.362</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6d1c24fb-6ee9-4b47-9b71-c604d6fe19b6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6d1c24fb-6ee9-4b47-9b71-c604d6fe19b6_0">
											<gml:posList>35.670430861685844 139.74118117706615 36.362 35.67043080508689 139.74120144703022 36.362 35.67043080508689 139.74120144703022 38.454 35.670430861685844 139.74118117706615 38.454 35.670430861685844 139.74118117706615 36.362</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e99b2755-7e8d-4e43-b327-361765679b7b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e99b2755-7e8d-4e43-b327-361765679b7b_0">
											<gml:posList>35.670430861685844 139.74118117706615 38.454 35.67043080508689 139.74120144703022 38.454 35.670446119477994 139.74120152884885 38.454 35.67044617606849 139.74118124783467 38.454 35.670430861685844 139.74118117706615 38.454</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1a14b7ad-6b83-4c37-88a7-622e4998cc1c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1a14b7ad-6b83-4c37-88a7-622e4998cc1c_0">
											<gml:posList>35.670446119477994 139.74120152884885 36.362 35.67044617606849 139.74118124783467 36.362 35.67044617606849 139.74118124783467 38.454 35.670446119477994 139.74120152884885 38.454 35.670446119477994 139.74120152884885 36.362</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2e9c1c09-2d6e-4d3e-9a76-5996e4821a56">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2e9c1c09-2d6e-4d3e-9a76-5996e4821a56_0">
											<gml:posList>35.67048817707732 139.74120091716043 40.101 35.670469725834735 139.74120073953 40.101 35.670469725834735 139.74120073953 43.61 35.67048817707732 139.74120091716043 43.61 35.67048817707732 139.74120091716043 40.101</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f6bc7588-1b04-447b-8e51-f74ca3c42c7b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f6bc7588-1b04-447b-8e51-f74ca3c42c7b_0">
											<gml:posList>35.67043080508689 139.74120144703022 36.362 35.670446119477994 139.74120152884885 36.362 35.670446119477994 139.74120152884885 38.454 35.67043080508689 139.74120144703022 38.454 35.67043080508689 139.74120144703022 36.362</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1000e83c-f46f-4d67-8617-c38d5ae966c2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1000e83c-f46f-4d67-8617-c38d5ae966c2_0">
											<gml:posList>35.670507262263875 139.7412049933982 36.362 35.67049712170751 139.74120485040245 36.362 35.67049712170751 139.74120485040245 39.09 35.670507262263875 139.7412049933982 39.09 35.670507262263875 139.7412049933982 36.362</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-92c5ad1b-6d54-475e-9497-a1aef8c542a2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-92c5ad1b-6d54-475e-9497-a1aef8c542a2_0">
											<gml:posList>35.670469725834735 139.74120073953 40.101 35.6704696532556 139.74121190739424 40.101 35.6704696532556 139.74121190739424 43.61 35.670469725834735 139.74120073953 43.61 35.670469725834735 139.74120073953 40.101</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b7ba4d7d-fe61-4a02-9671-f8c591a9be6e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b7ba4d7d-fe61-4a02-9671-f8c591a9be6e_0">
											<gml:posList>35.670469725834735 139.74120073953 43.61 35.6704696532556 139.74121190739424 43.61 35.670488104498155 139.7412120850272 43.61 35.67048817707732 139.74120091716043 43.61 35.670469725834735 139.74120073953 43.61</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8f038bf5-5269-4188-8eb4-45f151888f19">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8f038bf5-5269-4188-8eb4-45f151888f19_0">
											<gml:posList>35.670488104498155 139.7412120850272 40.101 35.67048817707732 139.74120091716043 40.101 35.67048817707732 139.74120091716043 43.61 35.670488104498155 139.7412120850272 43.61 35.670488104498155 139.7412120850272 40.101</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1b3fcc66-0933-4091-916d-74d63d195e9b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1b3fcc66-0933-4091-916d-74d63d195e9b_0">
											<gml:posList>35.670488104498155 139.7412120850272 40.101 35.670488104498155 139.7412120850272 43.61 35.6704696532556 139.74121190739424 43.61 35.6704696532556 139.74121190739424 40.101 35.670488104498155 139.7412120850272 40.101</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-65c2f504-b3fc-4c4d-8ad8-b9f3c0aca0ee">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-65c2f504-b3fc-4c4d-8ad8-b9f3c0aca0ee_0">
											<gml:posList>35.67049712170751 139.74120485040245 36.362 35.67049694724179 139.7412242257703 36.362 35.67049694724179 139.7412242257703 39.09 35.67049712170751 139.74120485040245 39.09 35.67049712170751 139.74120485040245 36.362</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-738ef189-98b4-4218-b036-65bbcc144659">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-738ef189-98b4-4218-b036-65bbcc144659_0">
											<gml:posList>35.670527158113764 139.74122010393995 36.362 35.670514691678996 139.74121952176327 36.362 35.670514691678996 139.74121952176327 37.747 35.670527158113764 139.74122010393995 37.747 35.670527158113764 139.74122010393995 36.362</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5d21a4e5-86a5-4ceb-9003-59d6e2566ac8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5d21a4e5-86a5-4ceb-9003-59d6e2566ac8_0">
											<gml:posList>35.67049694724179 139.7412242257703 39.09 35.67048170486766 139.74122402235557 39.09 35.67046574137878 139.7412237976768 39.09 35.67046561610919 139.74123678823577 39.09 35.6705069625285 139.74123735933418 39.09 35.670507262263875 139.7412049933982 39.09 35.67049712170751 139.74120485040245 39.09 35.67049694724179 139.7412242257703 39.09</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-27fba47c-99ef-4035-aa75-5bd03a532157">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-27fba47c-99ef-4035-aa75-5bd03a532157_0">
											<gml:posList>35.6705069625285 139.74123735933418 36.362 35.670507262263875 139.7412049933982 36.362 35.670507262263875 139.7412049933982 39.09 35.6705069625285 139.74123735933418 39.09 35.6705069625285 139.74123735933418 36.362</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6d998fcb-56f7-4947-9235-e9a689959651">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6d998fcb-56f7-4947-9235-e9a689959651_0">
											<gml:posList>35.67048170486766 139.74122402235557 39.09 35.67046574137878 139.7412237976768 36.725 35.67046574137878 139.7412237976768 39.09 35.67048170486766 139.74122402235557 39.09</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e48465df-ad82-43e8-ac2b-018988988ed0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e48465df-ad82-43e8-ac2b-018988988ed0_0">
											<gml:posList>35.67049694724179 139.7412242257703 36.362 35.67046574137878 139.7412237976768 36.362 35.67046574137878 139.7412237976768 36.725 35.67048170486766 139.74122402235557 39.09 35.67049694724179 139.7412242257703 39.09 35.67049694724179 139.7412242257703 36.362</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a6308417-90e3-4515-8c12-2a6568795dd8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a6308417-90e3-4515-8c12-2a6568795dd8_0">
											<gml:posList>35.670514691678996 139.74121952176327 36.362 35.67051441909792 139.74122846956163 36.362 35.67051441909792 139.74122846956163 37.747 35.670514691678996 139.74121952176327 37.747 35.670514691678996 139.74121952176327 36.362</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f0ea47a5-c26d-438d-8b89-88373de92f65">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f0ea47a5-c26d-438d-8b89-88373de92f65_0">
											<gml:posList>35.670527158113764 139.74122010393995 37.747 35.670514691678996 139.74121952176327 37.747 35.67051441909792 139.74122846956163 37.747 35.67052688553265 139.7412290517397 37.747 35.670527158113764 139.74122010393995 37.747</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-72d4bfbb-55c2-4498-988b-59a0092e9899">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-72d4bfbb-55c2-4498-988b-59a0092e9899_0">
											<gml:posList>35.67052688553265 139.7412290517397 36.362 35.670527158113764 139.74122010393995 36.362 35.670527158113764 139.74122010393995 37.747 35.67052688553265 139.7412290517397 37.747 35.67052688553265 139.7412290517397 36.362</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d304407a-d012-4a92-9971-601e2cbf4f95">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d304407a-d012-4a92-9971-601e2cbf4f95_0">
											<gml:posList>35.67051441909792 139.74122846956163 36.362 35.67052688553265 139.7412290517397 36.362 35.67052688553265 139.7412290517397 37.747 35.67051441909792 139.74122846956163 37.747 35.67051441909792 139.74122846956163 36.362</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-210f50ec-db08-485f-8cd1-c786d9063c63">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-210f50ec-db08-485f-8cd1-c786d9063c63_0">
											<gml:posList>35.67046561610919 139.74123678823577 36.362 35.67046561610919 139.74123678823577 39.09 35.67046574137878 139.7412237976768 39.09 35.67046574137878 139.7412237976768 36.725 35.67046574137878 139.7412237976768 36.362 35.67046561610919 139.74123678823577 36.362</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9991d041-e7c8-4a2c-8f5a-126d4d514637">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9991d041-e7c8-4a2c-8f5a-126d4d514637_0">
											<gml:posList>35.67046561610919 139.74123678823577 36.362 35.6705069625285 139.74123735933418 36.362 35.6705069625285 139.74123735933418 39.09 35.67046561610919 139.74123678823577 39.09 35.67046561610919 139.74123678823577 36.362</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-6e65c926-fc01-4bda-8fc9-f84fc4a79e22">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6e65c926-fc01-4bda-8fc9-f84fc4a79e22">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6e65c926-fc01-4bda-8fc9-f84fc4a79e22">
											<gml:posList>35.670482843781755 139.74113396077803 8.85 35.6704837127584 139.74110342787804 8.85 35.6705191174004 139.74110174125565 8.85 35.670558839861314 139.74130063913816 8.85 35.670548574685746 139.7413143483118 8.85 35.67040741311814 139.741305783774 8.85 35.6704053541519 139.74113580624245 8.85 35.67043236898117 139.74113669201773 8.85 35.670433300800774 139.7411058276767 8.85 35.67046098096193 139.741104514469 8.85 35.67045943954058 139.74118683304934 8.85 35.67051373040979 139.74118836131765 8.85 35.67051344236174 139.74117709444525 8.85 35.67047197095905 139.74117810313845 8.85 35.670474001142146 139.74113373897484 8.85 35.670482843781755 139.74113396077803 8.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-8478e94e-5bee-4141-9d36-6803266c4f7b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8478e94e-5bee-4141-9d36-6803266c4f7b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8478e94e-5bee-4141-9d36-6803266c4f7b">
											<gml:posList>35.67043520495523 139.74110877483966 41.764 35.6704363418349 139.74111027582433 41.764 35.67045615476741 139.7411112582453 41.764 35.67045737056245 139.7411098760631 41.764 35.67043520495523 139.74110877483966 41.764</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-9b0f952c-2060-40c1-a5e6-4ea2ad881707">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9b0f952c-2060-40c1-a5e6-4ea2ad881707">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9b0f952c-2060-40c1-a5e6-4ea2ad881707">
											<gml:posList>35.670433300800774 139.7411058276767 36.802 35.67043236898117 139.74113669201773 36.802 35.670434191783 139.74113934102576 36.802 35.67043520495523 139.74110877483966 36.802 35.67045737056245 139.7411098760631 36.802 35.67046098096193 139.741104514469 36.802 35.670433300800774 139.7411058276767 36.802</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-577374bf-7a8b-4be2-befa-83bbe58f59fd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-577374bf-7a8b-4be2-befa-83bbe58f59fd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-577374bf-7a8b-4be2-befa-83bbe58f59fd">
											<gml:posList>35.67043367212579 139.7411552151088 41.764 35.670434896926615 139.74115382187102 41.764 35.6704363418349 139.74111027582433 41.764 35.67043520495523 139.74110877483966 41.764 35.67043367212579 139.7411552151088 41.764</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-7c8befd2-fbc5-4795-8053-47000e9f804e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7c8befd2-fbc5-4795-8053-47000e9f804e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7c8befd2-fbc5-4795-8053-47000e9f804e">
											<gml:posList>35.67045615476741 139.7411112582453 41.099 35.6704363418349 139.74111027582433 41.099 35.670434896926615 139.74115382187102 41.099 35.670454709875706 139.74115482639525 41.099 35.67045615476741 139.7411112582453 41.099</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-8b120309-4a48-4f45-b152-7b78f9af27d4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8b120309-4a48-4f45-b152-7b78f9af27d4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8b120309-4a48-4f45-b152-7b78f9af27d4">
											<gml:posList>35.67045737056245 139.7411098760631 41.764 35.67045615476741 139.7411112582453 41.764 35.670454709875706 139.74115482639525 41.764 35.67045583773262 139.741156316345 41.764 35.67045737056245 139.7411098760631 41.764</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-7dea0cef-bb73-486d-9967-34ecfac3e4f8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7dea0cef-bb73-486d-9967-34ecfac3e4f8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7dea0cef-bb73-486d-9967-34ecfac3e4f8">
											<gml:posList>35.670482843781755 139.74113396077803 30.911 35.670474001142146 139.74113373897484 30.911 35.67047327416162 139.74114960225793 30.911 35.670488371665144 139.74114895526193 30.911 35.670494982587364 139.7411775464678 30.911 35.67051344236174 139.74117709444525 30.911 35.670500639928896 139.74110262412069 30.911 35.6704837127584 139.74110342787804 30.911 35.670482843781755 139.74113396077803 30.911</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d86d1844-acf9-438f-9712-c6f095db5d2a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d86d1844-acf9-438f-9712-c6f095db5d2a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d86d1844-acf9-438f-9712-c6f095db5d2a">
											<gml:posList>35.67053650847579 139.74118884326847 27.851 35.6705191174004 139.74110174125565 27.851 35.670500639928896 139.74110262412069 27.851 35.67051344236174 139.74117709444525 27.851 35.67051373040979 139.74118836131765 27.851 35.67053650847579 139.74118884326847 27.851</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-cfabd4d3-506c-43eb-9cf8-e21e0bc6e054">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cfabd4d3-506c-43eb-9cf8-e21e0bc6e054">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cfabd4d3-506c-43eb-9cf8-e21e0bc6e054">
											<gml:posList>35.67045737056245 139.7411098760631 36.802 35.67045583773262 139.741156316345 36.802 35.67045722590099 139.74119171804483 36.802 35.67045943954058 139.74118683304934 36.802 35.67046098096193 139.741104514469 36.802 35.67045737056245 139.7411098760631 36.802</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-15f71a21-7423-4421-aece-9725bae2ac9d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-15f71a21-7423-4421-aece-9725bae2ac9d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-15f71a21-7423-4421-aece-9725bae2ac9d">
											<gml:posList>35.67045583773262 139.741156316345 41.764 35.670454709875706 139.74115482639525 41.764 35.670434896926615 139.74115382187102 41.764 35.67043367212579 139.7411552151088 41.764 35.67045583773262 139.741156316345 41.764</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f2e85290-ff6f-472b-9f61-4b707e5e97e2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f2e85290-ff6f-472b-9f61-4b707e5e97e2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f2e85290-ff6f-472b-9f61-4b707e5e97e2">
											<gml:posList>35.67047197095905 139.74117810313845 33.776 35.670494982587364 139.7411775464678 33.776 35.670488371665144 139.74114895526193 33.776 35.67047327416162 139.74114960225793 33.776 35.67047197095905 139.74117810313845 33.776</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-20a97099-f61a-40d9-af36-6619b40c27e7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-20a97099-f61a-40d9-af36-6619b40c27e7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-20a97099-f61a-40d9-af36-6619b40c27e7">
											<gml:posList>35.67045722590099 139.74119171804483 36.362 35.67045583773262 139.741156316345 36.362 35.67043367212579 139.7411552151088 36.362 35.670434191783 139.74113934102576 36.362 35.670407636797414 139.74113864250728 36.362 35.67040836341731 139.74124009055478 36.362 35.67045722590099 139.74119171804483 36.362</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-bfb2633a-d3fe-473e-af6b-4565d755266f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bfb2633a-d3fe-473e-af6b-4565d755266f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bfb2633a-d3fe-473e-af6b-4565d755266f">
											<gml:posList>35.67045722590099 139.74119171804483 36.802 35.670463580651614 139.74119181015826 36.802 35.670497238281115 139.7411922796068 36.802 35.67053429388946 139.74119249108625 36.802 35.67053650847579 139.74118884326847 36.802 35.67045943954058 139.74118683304934 36.802 35.67045722590099 139.74119171804483 36.802</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-630ad6de-a072-4332-aa9e-c916e13f80ea">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-630ad6de-a072-4332-aa9e-c916e13f80ea">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-630ad6de-a072-4332-aa9e-c916e13f80ea">
											<gml:posList>35.670463580651614 139.74119181015826 41.346 35.670465727980066 139.7411945029807 41.346 35.67049503193076 139.7411949111559 41.346 35.670497238281115 139.7411922796068 41.346 35.670463580651614 139.74119181015826 41.346</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-65f70f2f-6d99-4089-81c2-d52b10755764">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-65f70f2f-6d99-4089-81c2-d52b10755764">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-65f70f2f-6d99-4089-81c2-d52b10755764">
											<gml:posList>35.67054120288153 139.74125725854225 36.802 35.67054797276216 139.74124621553128 36.802 35.67054481692015 139.7412448604632 36.802 35.670539604682034 139.7412536371973 36.802 35.67046137170206 139.74124996026583 36.802 35.670461491161284 139.74124115625085 36.802 35.67040836341731 139.74124009055478 36.802 35.670407636797414 139.74113864250728 36.802 35.670434191783 139.74113934102576 36.802 35.67043236898117 139.74113669201773 36.802 35.6704053541519 139.74113580624245 36.802 35.67040664372242 139.74124261107806 36.802 35.670458365621315 139.74124406500997 36.802 35.67045819234141 139.74125321152079 36.802 35.67054120288153 139.74125725854225 36.802</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b098ecda-e8ab-4861-af7e-41ead9cf7574">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b098ecda-e8ab-4861-af7e-41ead9cf7574">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b098ecda-e8ab-4861-af7e-41ead9cf7574">
											<gml:posList>35.670463289620834 139.74122376735463 41.346 35.67046548694965 139.74122112477147 41.346 35.670465727980066 139.7411945029807 41.346 35.670463580651614 139.74119181015826 41.346 35.670463289620834 139.74122376735463 41.346</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e4d7fc81-6ae1-4cb0-9cc1-364f6bc9d762">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e4d7fc81-6ae1-4cb0-9cc1-364f6bc9d762">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e4d7fc81-6ae1-4cb0-9cc1-364f6bc9d762">
											<gml:posList>35.67049503193076 139.7411949111559 40.101 35.670465727980066 139.7411945029807 40.101 35.67046548694965 139.74122112477147 40.101 35.67049479090029 139.7412215329564 40.101 35.67049503193076 139.7411949111559 40.101</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ab33d366-bc6b-42c2-9ae6-1bd77c20ede6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ab33d366-bc6b-42c2-9ae6-1bd77c20ede6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ab33d366-bc6b-42c2-9ae6-1bd77c20ede6">
											<gml:posList>35.670497238281115 139.7411922796068 41.346 35.67049503193076 139.7411949111559 41.346 35.67049479090029 139.7412215329564 41.346 35.67049694725024 139.74122423681658 41.346 35.670497238281115 139.7411922796068 41.346</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ecd23e93-2dee-4c8c-ada9-2c3b6a48344c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ecd23e93-2dee-4c8c-ada9-2c3b6a48344c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ecd23e93-2dee-4c8c-ada9-2c3b6a48344c">
											<gml:posList>35.67045722590099 139.74119171804483 36.362 35.67040836341731 139.74124009055478 36.362 35.670461491161284 139.74124115625085 36.362 35.670463289620834 139.74122376735463 36.362 35.670463580651614 139.74119181015826 36.362 35.67045722590099 139.74119171804483 36.362</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-6102da76-38d3-4b6d-a215-c85fa279d16a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6102da76-38d3-4b6d-a215-c85fa279d16a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6102da76-38d3-4b6d-a215-c85fa279d16a">
											<gml:posList>35.67053429388946 139.74119249108625 36.802 35.67054481692015 139.7412448604632 36.802 35.67054797276216 139.74124621553128 36.802 35.67053650847579 139.74118884326847 36.802 35.67053429388946 139.74119249108625 36.802</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-3d41905d-d24c-48a6-b55e-55396c3efde9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3d41905d-d24c-48a6-b55e-55396c3efde9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3d41905d-d24c-48a6-b55e-55396c3efde9">
											<gml:posList>35.67049694725024 139.74122423681658 41.346 35.67049479090029 139.7412215329564 41.346 35.67046548694965 139.74122112477147 41.346 35.670463289620834 139.74122376735463 41.346 35.67049694725024 139.74122423681658 41.346</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-2f0cf8f8-c861-4ce8-a3be-67fe5acdbe6b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2f0cf8f8-c861-4ce8-a3be-67fe5acdbe6b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2f0cf8f8-c861-4ce8-a3be-67fe5acdbe6b">
											<gml:posList>35.67053429388946 139.74119249108625 36.362 35.670497238281115 139.7411922796068 36.362 35.67049694725024 139.74122423681658 36.362 35.670463289620834 139.74122376735463 36.362 35.670461491161284 139.74124115625085 36.362 35.67046137170206 139.74124996026583 36.362 35.670539604682034 139.7412536371973 36.362 35.67054481692015 139.7412448604632 36.362 35.67053429388946 139.74119249108625 36.362</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-2a771488-a32c-4c2f-a9e2-cda1b6329e1d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2a771488-a32c-4c2f-a9e2-cda1b6329e1d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2a771488-a32c-4c2f-a9e2-cda1b6329e1d">
											<gml:posList>35.670558839861314 139.74130063913816 28.447 35.67054797276216 139.74124621553128 36.802 35.67054120288153 139.74125725854225 36.802 35.670558839861314 139.74130063913816 28.447</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ad2af69f-e577-4cc1-b0bc-6eb5467c321f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ad2af69f-e577-4cc1-b0bc-6eb5467c321f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ad2af69f-e577-4cc1-b0bc-6eb5467c321f">
											<gml:posList>35.670458365621315 139.74124406500997 36.802 35.67040664372242 139.74124261107806 36.802 35.67040741311814 139.741305783774 28.412 35.670458365621315 139.74124406500997 36.802</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-7595e3a1-1374-4ec4-86a5-300081f6a69f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7595e3a1-1374-4ec4-86a5-300081f6a69f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7595e3a1-1374-4ec4-86a5-300081f6a69f">
											<gml:posList>35.67040741311814 139.741305783774 28.412 35.670457153187655 139.74130879754549 28.447 35.670458365621315 139.74124406500997 36.802 35.67040741311814 139.741305783774 28.412</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-46ae1a34-ebc4-4eae-8331-7d187eb611c6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-46ae1a34-ebc4-4eae-8331-7d187eb611c6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-46ae1a34-ebc4-4eae-8331-7d187eb611c6">
											<gml:posList>35.670457153187655 139.74130879754549 28.447 35.67054120288153 139.74125725854225 36.802 35.67045819234141 139.74125321152079 36.802 35.670457153187655 139.74130879754549 28.447</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-df940631-ca18-4844-b922-26d479bb0e91">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-df940631-ca18-4844-b922-26d479bb0e91">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-df940631-ca18-4844-b922-26d479bb0e91">
											<gml:posList>35.670457153187655 139.74130879754549 28.447 35.670548574685746 139.7413143483118 28.447 35.67054120288153 139.74125725854225 36.802 35.670457153187655 139.74130879754549 28.447</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-3f5d2170-7762-4190-a0bd-f5a80b1002c2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3f5d2170-7762-4190-a0bd-f5a80b1002c2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3f5d2170-7762-4190-a0bd-f5a80b1002c2">
											<gml:posList>35.67054120288153 139.74125725854225 36.802 35.670548574685746 139.7413143483118 28.447 35.670558839861314 139.74130063913816 28.447 35.67054120288153 139.74125725854225 36.802</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c41ae021-edf6-465e-b801-76c07aad0995">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c41ae021-edf6-465e-b801-76c07aad0995">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c41ae021-edf6-465e-b801-76c07aad0995">
											<gml:posList>35.67040664372242 139.74124261107806 36.802 35.6704053541519 139.74113580624245 36.802 35.6704053541519 139.74113580624245 8.85 35.67040741311814 139.741305783774 8.85 35.67040741311814 139.741305783774 28.412 35.67040664372242 139.74124261107806 36.802</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-00ca71ed-9681-46ba-8c1e-c60d6a1f3e3a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-00ca71ed-9681-46ba-8c1e-c60d6a1f3e3a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-00ca71ed-9681-46ba-8c1e-c60d6a1f3e3a">
											<gml:posList>35.67040836341731 139.74124009055478 36.802 35.67040836341731 139.74124009055478 36.362 35.670407636797414 139.74113864250728 36.362 35.670407636797414 139.74113864250728 36.802 35.67040836341731 139.74124009055478 36.802</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c87a2019-74ff-49c8-9ac7-f69d59b168f7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c87a2019-74ff-49c8-9ac7-f69d59b168f7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c87a2019-74ff-49c8-9ac7-f69d59b168f7">
											<gml:posList>35.67043236898117 139.74113669201773 8.85 35.6704053541519 139.74113580624245 8.85 35.6704053541519 139.74113580624245 36.802 35.67043236898117 139.74113669201773 36.802 35.67043236898117 139.74113669201773 8.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1ababb61-5210-4c9b-9b52-f19139889b63">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1ababb61-5210-4c9b-9b52-f19139889b63">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1ababb61-5210-4c9b-9b52-f19139889b63">
											<gml:posList>35.670407636797414 139.74113864250728 36.802 35.670407636797414 139.74113864250728 36.362 35.670434191783 139.74113934102576 36.362 35.670434191783 139.74113934102576 36.802 35.670407636797414 139.74113864250728 36.802</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-cea0e60f-e666-4c31-965b-d269f7bd408e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cea0e60f-e666-4c31-965b-d269f7bd408e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cea0e60f-e666-4c31-965b-d269f7bd408e">
											<gml:posList>35.670457153187655 139.74130879754549 28.412 35.670457153187655 139.74130879754549 28.447 35.67040741311814 139.741305783774 28.412 35.670457153187655 139.74130879754549 28.412</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e880ad5f-ba6c-408c-9b26-e7511ab58b9f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e880ad5f-ba6c-408c-9b26-e7511ab58b9f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e880ad5f-ba6c-408c-9b26-e7511ab58b9f">
											<gml:posList>35.670433300800774 139.7411058276767 8.85 35.67043236898117 139.74113669201773 8.85 35.67043236898117 139.74113669201773 36.802 35.670433300800774 139.7411058276767 36.802 35.670433300800774 139.7411058276767 8.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-50dccc54-c2cf-4369-ba10-1c5fa054636b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-50dccc54-c2cf-4369-ba10-1c5fa054636b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-50dccc54-c2cf-4369-ba10-1c5fa054636b">
											<gml:posList>35.67043367212579 139.7411552151088 36.362 35.67043367212579 139.7411552151088 41.764 35.67043520495523 139.74110877483966 41.764 35.67043520495523 139.74110877483966 36.802 35.670434191783 139.74113934102576 36.802 35.670434191783 139.74113934102576 36.362 35.67043367212579 139.7411552151088 36.362</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a6442a28-70de-4881-b710-f6723132f012">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a6442a28-70de-4881-b710-f6723132f012">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a6442a28-70de-4881-b710-f6723132f012">
											<gml:posList>35.670461491161284 139.74124115625085 36.802 35.670461491161284 139.74124115625085 36.362 35.67040836341731 139.74124009055478 36.362 35.67040836341731 139.74124009055478 36.802 35.670461491161284 139.74124115625085 36.802</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0464a397-370b-418a-ad2c-e7437b528c35">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0464a397-370b-418a-ad2c-e7437b528c35">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0464a397-370b-418a-ad2c-e7437b528c35">
											<gml:posList>35.670434896926615 139.74115382187102 41.764 35.670434896926615 139.74115382187102 41.099 35.6704363418349 139.74111027582433 41.099 35.6704363418349 139.74111027582433 41.764 35.670434896926615 139.74115382187102 41.764</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-65bb7312-3739-4462-9b97-fcb0c3cb0144">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-65bb7312-3739-4462-9b97-fcb0c3cb0144">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-65bb7312-3739-4462-9b97-fcb0c3cb0144">
											<gml:posList>35.67043367212579 139.7411552151088 41.764 35.67043367212579 139.7411552151088 36.362 35.67045583773262 139.741156316345 36.362 35.67045583773262 139.741156316345 36.802 35.67045583773262 139.741156316345 41.764 35.67043367212579 139.7411552151088 41.764</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d5e0d983-14dd-45c3-8344-d0a632df7290">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d5e0d983-14dd-45c3-8344-d0a632df7290">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d5e0d983-14dd-45c3-8344-d0a632df7290">
											<gml:posList>35.670454709875706 139.74115482639525 41.764 35.670454709875706 139.74115482639525 41.099 35.670434896926615 139.74115382187102 41.099 35.670434896926615 139.74115382187102 41.764 35.670454709875706 139.74115482639525 41.764</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-79af6bfc-a269-44c8-a717-e19adc1b5eec">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-79af6bfc-a269-44c8-a717-e19adc1b5eec">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-79af6bfc-a269-44c8-a717-e19adc1b5eec">
											<gml:posList>35.6704363418349 139.74111027582433 41.764 35.6704363418349 139.74111027582433 41.099 35.67045615476741 139.7411112582453 41.099 35.67045615476741 139.7411112582453 41.764 35.6704363418349 139.74111027582433 41.764</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e070c05c-324a-405d-b1af-ff22892679c7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e070c05c-324a-405d-b1af-ff22892679c7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e070c05c-324a-405d-b1af-ff22892679c7">
											<gml:posList>35.67043520495523 139.74110877483966 36.802 35.67043520495523 139.74110877483966 41.764 35.67045737056245 139.7411098760631 41.764 35.67045737056245 139.7411098760631 36.802 35.67043520495523 139.74110877483966 36.802</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-01fbb3dd-3271-42d6-9f0d-3484337bc5c4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-01fbb3dd-3271-42d6-9f0d-3484337bc5c4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-01fbb3dd-3271-42d6-9f0d-3484337bc5c4">
											<gml:posList>35.67046098096193 139.741104514469 8.85 35.670433300800774 139.7411058276767 8.85 35.670433300800774 139.7411058276767 36.802 35.67046098096193 139.741104514469 36.802 35.67046098096193 139.741104514469 8.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-729d0752-2563-40f9-b0bb-a22aa6705ec2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-729d0752-2563-40f9-b0bb-a22aa6705ec2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-729d0752-2563-40f9-b0bb-a22aa6705ec2">
											<gml:posList>35.67045615476741 139.7411112582453 41.764 35.67045615476741 139.7411112582453 41.099 35.670454709875706 139.74115482639525 41.099 35.670454709875706 139.74115482639525 41.764 35.67045615476741 139.7411112582453 41.764</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f191c9f5-1912-4eaf-82ba-432177bf8a43">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f191c9f5-1912-4eaf-82ba-432177bf8a43">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f191c9f5-1912-4eaf-82ba-432177bf8a43">
											<gml:posList>35.67045583773262 139.741156316345 36.802 35.67045583773262 139.741156316345 36.362 35.67045722590099 139.74119171804483 36.362 35.67045722590099 139.74119171804483 36.802 35.67045583773262 139.741156316345 36.802</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4cc54b81-aba8-4716-ba64-4638a544a71c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4cc54b81-aba8-4716-ba64-4638a544a71c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4cc54b81-aba8-4716-ba64-4638a544a71c">
											<gml:posList>35.67045737056245 139.7411098760631 36.802 35.67045737056245 139.7411098760631 41.764 35.67045583773262 139.741156316345 41.764 35.67045583773262 139.741156316345 36.802 35.67045737056245 139.7411098760631 36.802</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-cc35a278-1598-4aa6-8fbf-d2002c23581e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cc35a278-1598-4aa6-8fbf-d2002c23581e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cc35a278-1598-4aa6-8fbf-d2002c23581e">
											<gml:posList>35.67045819234141 139.74125321152079 36.802 35.670458365621315 139.74124406500997 36.802 35.670457153187655 139.74130879754549 28.447 35.67045819234141 139.74125321152079 36.802</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-34a5757e-85d3-4a7c-9d87-e151fb0b8e32">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-34a5757e-85d3-4a7c-9d87-e151fb0b8e32">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-34a5757e-85d3-4a7c-9d87-e151fb0b8e32">
											<gml:posList>35.67046098096193 139.741104514469 8.85 35.67046098096193 139.741104514469 36.802 35.67045943954058 139.74118683304934 36.802 35.67045943954058 139.74118683304934 8.85 35.67046098096193 139.741104514469 8.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-23e28b84-555a-481d-b29e-60c57559828d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-23e28b84-555a-481d-b29e-60c57559828d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-23e28b84-555a-481d-b29e-60c57559828d">
											<gml:posList>35.67045722590099 139.74119171804483 36.802 35.67045722590099 139.74119171804483 36.362 35.670463580651614 139.74119181015826 36.362 35.670463580651614 139.74119181015826 36.802 35.67045722590099 139.74119171804483 36.802</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-21c65d17-73bb-4105-841e-322b5b3f1881">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-21c65d17-73bb-4105-841e-322b5b3f1881">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-21c65d17-73bb-4105-841e-322b5b3f1881">
											<gml:posList>35.67046137170206 139.74124996026583 36.802 35.67046137170206 139.74124996026583 36.362 35.670461491161284 139.74124115625085 36.362 35.670461491161284 139.74124115625085 36.802 35.67046137170206 139.74124996026583 36.802</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-cde30f7b-b6e0-4e11-aaec-4ab379599aab">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cde30f7b-b6e0-4e11-aaec-4ab379599aab">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cde30f7b-b6e0-4e11-aaec-4ab379599aab">
											<gml:posList>35.670463289620834 139.74122376735463 36.362 35.670463289620834 139.74122376735463 41.346 35.670463580651614 139.74119181015826 41.346 35.670463580651614 139.74119181015826 36.802 35.670463580651614 139.74119181015826 36.362 35.670463289620834 139.74122376735463 36.362</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2f5512bf-b581-4e29-8f73-416b8081c8db">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2f5512bf-b581-4e29-8f73-416b8081c8db">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2f5512bf-b581-4e29-8f73-416b8081c8db">
											<gml:posList>35.67046548694965 139.74122112477147 41.346 35.67046548694965 139.74122112477147 40.101 35.670465727980066 139.7411945029807 40.101 35.670465727980066 139.7411945029807 41.346 35.67046548694965 139.74122112477147 41.346</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ef71913b-99e5-440c-8cb1-f24cfe2c30e9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ef71913b-99e5-440c-8cb1-f24cfe2c30e9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ef71913b-99e5-440c-8cb1-f24cfe2c30e9">
											<gml:posList>35.67047197095905 139.74117810313845 8.85 35.67047197095905 139.74117810313845 33.776 35.67047327416162 139.74114960225793 33.776 35.67047327416162 139.74114960225793 30.911 35.670474001142146 139.74113373897484 30.911 35.670474001142146 139.74113373897484 8.85 35.67047197095905 139.74117810313845 8.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2a5d0a34-4afc-43c1-b3f2-f8398b00a43e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2a5d0a34-4afc-43c1-b3f2-f8398b00a43e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2a5d0a34-4afc-43c1-b3f2-f8398b00a43e">
											<gml:posList>35.670548574685746 139.7413143483118 8.85 35.670548574685746 139.7413143483118 28.447 35.670457153187655 139.74130879754549 28.447 35.670457153187655 139.74130879754549 28.412 35.67040741311814 139.741305783774 28.412 35.67040741311814 139.741305783774 8.85 35.670548574685746 139.7413143483118 8.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c74460dc-de93-4aee-898b-c3c0c85ee0ec">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c74460dc-de93-4aee-898b-c3c0c85ee0ec">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c74460dc-de93-4aee-898b-c3c0c85ee0ec">
											<gml:posList>35.670482843781755 139.74113396077803 8.85 35.670474001142146 139.74113373897484 8.85 35.670474001142146 139.74113373897484 30.911 35.670482843781755 139.74113396077803 30.911 35.670482843781755 139.74113396077803 8.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ffb73196-99d1-416b-acb8-aa4b71a1d405">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ffb73196-99d1-416b-acb8-aa4b71a1d405">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ffb73196-99d1-416b-acb8-aa4b71a1d405">
											<gml:posList>35.670463289620834 139.74122376735463 36.362 35.67049694725024 139.74122423681658 36.362 35.67049694725024 139.74122423681658 41.346 35.670463289620834 139.74122376735463 41.346 35.670463289620834 139.74122376735463 36.362</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-18d0f4c6-2430-49c9-ad0f-e2452bc49413">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-18d0f4c6-2430-49c9-ad0f-e2452bc49413">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-18d0f4c6-2430-49c9-ad0f-e2452bc49413">
											<gml:posList>35.67049479090029 139.7412215329564 41.346 35.67049479090029 139.7412215329564 40.101 35.67046548694965 139.74122112477147 40.101 35.67046548694965 139.74122112477147 41.346 35.67049479090029 139.7412215329564 41.346</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f1d69aef-310b-4462-a3b8-d18f1c5beef8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f1d69aef-310b-4462-a3b8-d18f1c5beef8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f1d69aef-310b-4462-a3b8-d18f1c5beef8">
											<gml:posList>35.670465727980066 139.7411945029807 41.346 35.670465727980066 139.7411945029807 40.101 35.67049503193076 139.7411949111559 40.101 35.67049503193076 139.7411949111559 41.346 35.670465727980066 139.7411945029807 41.346</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-fdde9a87-c8c3-4eb6-ba1e-237d208f51b0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fdde9a87-c8c3-4eb6-ba1e-237d208f51b0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fdde9a87-c8c3-4eb6-ba1e-237d208f51b0">
											<gml:posList>35.670463580651614 139.74119181015826 36.802 35.670463580651614 139.74119181015826 41.346 35.670497238281115 139.7411922796068 41.346 35.670497238281115 139.7411922796068 36.802 35.670463580651614 139.74119181015826 36.802</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-cebce600-2118-402a-aef5-2a6f6f667c93">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cebce600-2118-402a-aef5-2a6f6f667c93">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cebce600-2118-402a-aef5-2a6f6f667c93">
											<gml:posList>35.67047327416162 139.74114960225793 30.911 35.67047327416162 139.74114960225793 33.776 35.670488371665144 139.74114895526193 33.776 35.670488371665144 139.74114895526193 30.911 35.67047327416162 139.74114960225793 30.911</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4a6e0865-71ed-4506-bb18-05d315b16e98">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4a6e0865-71ed-4506-bb18-05d315b16e98">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4a6e0865-71ed-4506-bb18-05d315b16e98">
											<gml:posList>35.6704837127584 139.74110342787804 8.85 35.670482843781755 139.74113396077803 8.85 35.670482843781755 139.74113396077803 30.911 35.6704837127584 139.74110342787804 30.911 35.6704837127584 139.74110342787804 8.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b9fe0ac7-e401-4a98-8682-3da342564d36">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b9fe0ac7-e401-4a98-8682-3da342564d36">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b9fe0ac7-e401-4a98-8682-3da342564d36">
											<gml:posList>35.670488371665144 139.74114895526193 30.911 35.670488371665144 139.74114895526193 33.776 35.670494982587364 139.7411775464678 33.776 35.670494982587364 139.7411775464678 30.911 35.670488371665144 139.74114895526193 30.911</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3ed9be4e-c343-48b6-918e-e23abd34f455">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3ed9be4e-c343-48b6-918e-e23abd34f455">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3ed9be4e-c343-48b6-918e-e23abd34f455">
											<gml:posList>35.67047197095905 139.74117810313845 33.776 35.67047197095905 139.74117810313845 8.85 35.67051344236174 139.74117709444525 8.85 35.67051344236174 139.74117709444525 27.851 35.67051344236174 139.74117709444525 30.911 35.670494982587364 139.7411775464678 30.911 35.670494982587364 139.7411775464678 33.776 35.67047197095905 139.74117810313845 33.776</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ba3ef0e6-4b6a-43d9-b1ef-f95590890502">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ba3ef0e6-4b6a-43d9-b1ef-f95590890502">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ba3ef0e6-4b6a-43d9-b1ef-f95590890502">
											<gml:posList>35.67049503193076 139.7411949111559 41.346 35.67049503193076 139.7411949111559 40.101 35.67049479090029 139.7412215329564 40.101 35.67049479090029 139.7412215329564 41.346 35.67049503193076 139.7411949111559 41.346</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-88d5d088-7d57-487b-abd9-0506412e8f53">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-88d5d088-7d57-487b-abd9-0506412e8f53">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-88d5d088-7d57-487b-abd9-0506412e8f53">
											<gml:posList>35.67049694725024 139.74122423681658 41.346 35.67049694725024 139.74122423681658 36.362 35.670497238281115 139.7411922796068 36.362 35.670497238281115 139.7411922796068 36.802 35.670497238281115 139.7411922796068 41.346 35.67049694725024 139.74122423681658 41.346</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2c132443-1a4d-4188-a201-f23496971867">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2c132443-1a4d-4188-a201-f23496971867">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2c132443-1a4d-4188-a201-f23496971867">
											<gml:posList>35.67051373040979 139.74118836131765 27.851 35.67051373040979 139.74118836131765 8.85 35.67045943954058 139.74118683304934 8.85 35.67045943954058 139.74118683304934 36.802 35.67053650847579 139.74118884326847 36.802 35.67053650847579 139.74118884326847 27.851 35.67051373040979 139.74118836131765 27.851</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ffefb602-f295-45c3-92ef-c4d058a79cf0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ffefb602-f295-45c3-92ef-c4d058a79cf0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ffefb602-f295-45c3-92ef-c4d058a79cf0">
											<gml:posList>35.670539604682034 139.7412536371973 36.802 35.670539604682034 139.7412536371973 36.362 35.67046137170206 139.74124996026583 36.362 35.67046137170206 139.74124996026583 36.802 35.670539604682034 139.7412536371973 36.802</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-733a51f7-3df5-4c94-ae1e-228d25c53a37">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-733a51f7-3df5-4c94-ae1e-228d25c53a37">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-733a51f7-3df5-4c94-ae1e-228d25c53a37">
											<gml:posList>35.6704837127584 139.74110342787804 8.85 35.6704837127584 139.74110342787804 30.911 35.670500639928896 139.74110262412069 30.911 35.670500639928896 139.74110262412069 27.851 35.6705191174004 139.74110174125565 27.851 35.6705191174004 139.74110174125565 8.85 35.6704837127584 139.74110342787804 8.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3e557d2a-6b66-402c-974b-e8172c04d1ff">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3e557d2a-6b66-402c-974b-e8172c04d1ff">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3e557d2a-6b66-402c-974b-e8172c04d1ff">
											<gml:posList>35.670500639928896 139.74110262412069 27.851 35.670500639928896 139.74110262412069 30.911 35.67051344236174 139.74117709444525 30.911 35.67051344236174 139.74117709444525 27.851 35.670500639928896 139.74110262412069 27.851</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b5920a2c-861e-4537-8a92-0f979607ff4a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b5920a2c-861e-4537-8a92-0f979607ff4a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b5920a2c-861e-4537-8a92-0f979607ff4a">
											<gml:posList>35.67051344236174 139.74117709444525 8.85 35.67051373040979 139.74118836131765 8.85 35.67051373040979 139.74118836131765 27.851 35.67051344236174 139.74117709444525 27.851 35.67051344236174 139.74117709444525 8.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c1644473-2a76-4190-b64f-f91a631e269b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c1644473-2a76-4190-b64f-f91a631e269b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c1644473-2a76-4190-b64f-f91a631e269b">
											<gml:posList>35.670497238281115 139.7411922796068 36.802 35.670497238281115 139.7411922796068 36.362 35.67053429388946 139.74119249108625 36.362 35.67053429388946 139.74119249108625 36.802 35.670497238281115 139.7411922796068 36.802</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-20ed6779-be52-4338-b95e-7c5d001a93c7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-20ed6779-be52-4338-b95e-7c5d001a93c7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-20ed6779-be52-4338-b95e-7c5d001a93c7">
											<gml:posList>35.67053650847579 139.74118884326847 27.851 35.67053650847579 139.74118884326847 36.802 35.67054797276216 139.74124621553128 36.802 35.670558839861314 139.74130063913816 28.447 35.670558839861314 139.74130063913816 8.85 35.6705191174004 139.74110174125565 8.85 35.6705191174004 139.74110174125565 27.851 35.67053650847579 139.74118884326847 27.851</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2609b77c-ec35-4253-b08b-cf9d7cce29e2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2609b77c-ec35-4253-b08b-cf9d7cce29e2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2609b77c-ec35-4253-b08b-cf9d7cce29e2">
											<gml:posList>35.67053429388946 139.74119249108625 36.802 35.67053429388946 139.74119249108625 36.362 35.67054481692015 139.7412448604632 36.362 35.67054481692015 139.7412448604632 36.802 35.67053429388946 139.74119249108625 36.802</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ee40e491-d4e9-4b06-a185-3656417689ee">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ee40e491-d4e9-4b06-a185-3656417689ee">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ee40e491-d4e9-4b06-a185-3656417689ee">
											<gml:posList>35.67054481692015 139.7412448604632 36.802 35.67054481692015 139.7412448604632 36.362 35.670539604682034 139.7412536371973 36.362 35.670539604682034 139.7412536371973 36.802 35.67054481692015 139.7412448604632 36.802</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ba4834b0-ae9c-4387-a5a2-021da12e2c4a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ba4834b0-ae9c-4387-a5a2-021da12e2c4a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ba4834b0-ae9c-4387-a5a2-021da12e2c4a">
											<gml:posList>35.670548574685746 139.7413143483118 8.85 35.670558839861314 139.74130063913816 8.85 35.670558839861314 139.74130063913816 28.447 35.670548574685746 139.7413143483118 28.447 35.670548574685746 139.7413143483118 8.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-284</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">276.30465</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1210</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>7</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.01</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>