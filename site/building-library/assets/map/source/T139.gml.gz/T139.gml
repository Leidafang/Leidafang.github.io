<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_2466c9c3-aec7-4b92-887c-984ef7cee05a">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="説明注記">
				<gen:value>地下駐入口屋根</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>18</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103018002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">401</bldg:usage>
			<bldg:measuredHeight uom="m">31</bldg:measuredHeight>
			<bldg:storeysAboveGround>0</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.66954710076822 139.74734636148548 0 35.66966238469915 139.74747028624245 0 35.66970362658963 139.74741280200922 0 35.66958825246313 139.74728887736813 0 35.66954710076822 139.74734636148548 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66954710076822 139.74734636148548 4.869 35.66958825246313 139.74728887736813 4.869 35.66970362658963 139.74741280200922 4.869 35.66966238469915 139.74747028624245 4.869 35.66954710076822 139.74734636148548 4.869</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66954710076822 139.74734636148548 4.869 35.66966238469915 139.74747028624245 4.869 35.66966238469915 139.74747028624245 35.85 35.66954710076822 139.74734636148548 35.85 35.66954710076822 139.74734636148548 4.869</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66966238469915 139.74747028624245 4.869 35.66970362658963 139.74741280200922 4.869 35.66970362658963 139.74741280200922 35.85 35.66966238469915 139.74747028624245 35.85 35.66966238469915 139.74747028624245 4.869</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66970362658963 139.74741280200922 4.869 35.66958825246313 139.74728887736813 4.869 35.66958825246313 139.74728887736813 35.85 35.66970362658963 139.74741280200922 35.85 35.66970362658963 139.74741280200922 4.869</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66958825246313 139.74728887736813 4.869 35.66954710076822 139.74734636148548 4.869 35.66954710076822 139.74734636148548 35.85 35.66958825246313 139.74728887736813 35.85 35.66958825246313 139.74728887736813 4.869</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66954710076822 139.74734636148548 35.85 35.66966238469915 139.74747028624245 35.85 35.66970362658963 139.74741280200922 35.85 35.66958825246313 139.74728887736813 35.85 35.66954710076822 139.74734636148548 35.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-3453e691-53f1-41f5-a86f-126943c70350"/>
							<gml:surfaceMember xlink:href="#poly-db04c6f0-9db7-419c-913a-f661f4f56866"/>
							<gml:surfaceMember xlink:href="#poly-6268ca83-44d3-4b0a-a514-f399838012ec"/>
							<gml:surfaceMember xlink:href="#poly-9ef3da01-f41e-4925-b54c-2a60a12045c8"/>
							<gml:surfaceMember xlink:href="#poly-0584611c-63bb-4b01-952b-bdb5903fc57b"/>
							<gml:surfaceMember xlink:href="#poly-4a007b24-77be-47e6-a7f1-f8337460888b"/>
							<gml:surfaceMember xlink:href="#poly-a8d0f7f6-d83b-4520-ac24-fa94e38d6930"/>
							<gml:surfaceMember xlink:href="#poly-c27f503b-7b96-4cbd-97b3-d3f8938e5b86"/>
							<gml:surfaceMember xlink:href="#poly-44fd9ff3-e4cf-434b-abbb-5378d9d50209"/>
							<gml:surfaceMember xlink:href="#poly-5de46652-a2a3-4c2b-8685-6cd5e860cea8"/>
							<gml:surfaceMember xlink:href="#poly-a749125f-8b0c-4aa5-974e-de309d1e4cd2"/>
							<gml:surfaceMember xlink:href="#poly-081a3072-f059-4d5d-b685-c75282573395"/>
							<gml:surfaceMember xlink:href="#poly-0cddadd7-1881-4d11-80bd-ff9ac802aeaf"/>
							<gml:surfaceMember xlink:href="#poly-44245047-e21d-427c-b24e-b57133035c83"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-3453e691-53f1-41f5-a86f-126943c70350">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3453e691-53f1-41f5-a86f-126943c70350">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3453e691-53f1-41f5-a86f-126943c70350">
											<gml:posList>35.66954710076823 139.74734636148548 4.869 35.66958825246311 139.74728887736813 4.869 35.669703626589595 139.7474128020092 4.869 35.669662384699116 139.74747028624245 4.869 35.66954710076823 139.74734636148548 4.869</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-db04c6f0-9db7-419c-913a-f661f4f56866">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-db04c6f0-9db7-419c-913a-f661f4f56866">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-db04c6f0-9db7-419c-913a-f661f4f56866">
											<gml:posList>35.66954710076823 139.74734636148548 36.6 35.669549597428244 139.74734615997738 36.6 35.669588425910284 139.74729193696584 36.6 35.66958825246311 139.74728887736813 36.6 35.66954710076823 139.74734636148548 36.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-6268ca83-44d3-4b0a-a514-f399838012ec">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6268ca83-44d3-4b0a-a514-f399838012ec">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6268ca83-44d3-4b0a-a514-f399838012ec">
											<gml:posList>35.669662384699116 139.74747028624245 36.6 35.66966222027019 139.74746722663187 36.6 35.669549597428244 139.74734615997738 36.6 35.66954710076823 139.74734636148548 36.6 35.669662384699116 139.74747028624245 36.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-9ef3da01-f41e-4925-b54c-2a60a12045c8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9ef3da01-f41e-4925-b54c-2a60a12045c8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9ef3da01-f41e-4925-b54c-2a60a12045c8">
											<gml:posList>35.669701138943246 139.74741300350598 36.189 35.669588425910284 139.74729193696584 36.189 35.669549597428244 139.74734615997738 36.189 35.66966222027019 139.74746722663187 36.189 35.669701138943246 139.74741300350598 36.189</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-0584611c-63bb-4b01-952b-bdb5903fc57b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0584611c-63bb-4b01-952b-bdb5903fc57b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0584611c-63bb-4b01-952b-bdb5903fc57b">
											<gml:posList>35.66958825246311 139.74728887736813 36.6 35.669588425910284 139.74729193696584 36.6 35.669701138943246 139.74741300350598 36.6 35.669703626589595 139.7474128020092 36.6 35.66958825246311 139.74728887736813 36.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-4a007b24-77be-47e6-a7f1-f8337460888b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4a007b24-77be-47e6-a7f1-f8337460888b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4a007b24-77be-47e6-a7f1-f8337460888b">
											<gml:posList>35.669703626589595 139.7474128020092 36.6 35.669701138943246 139.74741300350598 36.6 35.66966222027019 139.74746722663187 36.6 35.669662384699116 139.74747028624245 36.6 35.669703626589595 139.7474128020092 36.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a8d0f7f6-d83b-4520-ac24-fa94e38d6930">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a8d0f7f6-d83b-4520-ac24-fa94e38d6930">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a8d0f7f6-d83b-4520-ac24-fa94e38d6930">
											<gml:posList>35.669588425910284 139.74729193696584 36.6 35.669588425910284 139.74729193696584 36.189 35.669701138943246 139.74741300350598 36.189 35.669701138943246 139.74741300350598 36.6 35.669588425910284 139.74729193696584 36.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c27f503b-7b96-4cbd-97b3-d3f8938e5b86">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c27f503b-7b96-4cbd-97b3-d3f8938e5b86">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c27f503b-7b96-4cbd-97b3-d3f8938e5b86">
											<gml:posList>35.66966222027019 139.74746722663187 36.6 35.66966222027019 139.74746722663187 36.189 35.669549597428244 139.74734615997738 36.189 35.669549597428244 139.74734615997738 36.6 35.66966222027019 139.74746722663187 36.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-44fd9ff3-e4cf-434b-abbb-5378d9d50209">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-44fd9ff3-e4cf-434b-abbb-5378d9d50209">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-44fd9ff3-e4cf-434b-abbb-5378d9d50209">
											<gml:posList>35.669701138943246 139.74741300350598 36.6 35.669701138943246 139.74741300350598 36.189 35.66966222027019 139.74746722663187 36.189 35.66966222027019 139.74746722663187 36.6 35.669701138943246 139.74741300350598 36.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5de46652-a2a3-4c2b-8685-6cd5e860cea8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5de46652-a2a3-4c2b-8685-6cd5e860cea8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5de46652-a2a3-4c2b-8685-6cd5e860cea8">
											<gml:posList>35.669662384699116 139.74747028624245 4.869 35.669703626589595 139.7474128020092 4.869 35.669703626589595 139.7474128020092 36.6 35.669662384699116 139.74747028624245 36.6 35.669662384699116 139.74747028624245 4.869</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a749125f-8b0c-4aa5-974e-de309d1e4cd2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a749125f-8b0c-4aa5-974e-de309d1e4cd2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a749125f-8b0c-4aa5-974e-de309d1e4cd2">
											<gml:posList>35.66958825246311 139.74728887736813 4.869 35.66954710076823 139.74734636148548 4.869 35.66954710076823 139.74734636148548 36.6 35.66958825246311 139.74728887736813 36.6 35.66958825246311 139.74728887736813 4.869</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-081a3072-f059-4d5d-b685-c75282573395">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-081a3072-f059-4d5d-b685-c75282573395">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-081a3072-f059-4d5d-b685-c75282573395">
											<gml:posList>35.669549597428244 139.74734615997738 36.6 35.669549597428244 139.74734615997738 36.189 35.669588425910284 139.74729193696584 36.189 35.669588425910284 139.74729193696584 36.6 35.669549597428244 139.74734615997738 36.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0cddadd7-1881-4d11-80bd-ff9ac802aeaf">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0cddadd7-1881-4d11-80bd-ff9ac802aeaf">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0cddadd7-1881-4d11-80bd-ff9ac802aeaf">
											<gml:posList>35.669703626589595 139.7474128020092 4.869 35.66958825246311 139.74728887736813 4.869 35.66958825246311 139.74728887736813 36.6 35.669703626589595 139.7474128020092 36.6 35.669703626589595 139.7474128020092 4.869</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-44245047-e21d-427c-b24e-b57133035c83">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-44245047-e21d-427c-b24e-b57133035c83">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-44245047-e21d-427c-b24e-b57133035c83">
											<gml:posList>35.66954710076823 139.74734636148548 4.869 35.669662384699116 139.74747028624245 4.869 35.669662384699116 139.74747028624245 36.6 35.66954710076823 139.74734636148548 36.6 35.66954710076823 139.74734636148548 4.869</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区虎ノ門二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-2486</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">77.36624</uro:buildingRoofEdgeArea>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1210</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>7</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.03</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>