<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_26936c14-34ee-407e-b77b-42fb2fe47520">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>18</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103018002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">401</bldg:usage>
			<bldg:measuredHeight uom="m">66.1</bldg:measuredHeight>
			<bldg:storeysAboveGround>16</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>2</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.67002956988339 139.74679287070603 0 35.67005829492017 139.74675285240087 0 35.669999209257355 139.74668929004866 0 35.6700852037906 139.74656901425246 0 35.670078528460564 139.74656184143407 0 35.67008681280824 139.7465503444001 0 35.6699922756089 139.74644871116172 0 35.66998471173122 139.74645932371556 0 35.66997668322003 139.74645060591303 0 35.669589031753276 139.74699239783644 0 35.66968329785118 139.74709370011286 0 35.669607297987824 139.74719993539293 0 35.66961325162929 139.74720633576675 0 35.669602806214876 139.74722103837044 0 35.66969689168829 139.7473221202037 0 35.669707337272705 139.74730763851906 0 35.66971518521107 139.74731602518693 0 35.670063397543906 139.74682928670842 0 35.67002956988339 139.74679287070603 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67002956988339 139.74679287070603 5.67 35.670063397543906 139.74682928670842 5.67 35.66971518521107 139.74731602518693 5.67 35.669707337272705 139.74730763851906 5.67 35.66969689168829 139.7473221202037 5.67 35.669602806214876 139.74722103837044 5.67 35.66961325162929 139.74720633576675 5.67 35.669607297987824 139.74719993539293 5.67 35.66968329785118 139.74709370011286 5.67 35.669589031753276 139.74699239783644 5.67 35.66997668322003 139.74645060591303 5.67 35.66998471173122 139.74645932371556 5.67 35.6699922756089 139.74644871116172 5.67 35.67008681280824 139.7465503444001 5.67 35.670078528460564 139.74656184143407 5.67 35.6700852037906 139.74656901425246 5.67 35.669999209257355 139.74668929004866 5.67 35.67005829492017 139.74675285240087 5.67 35.67002956988339 139.74679287070603 5.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67002956988339 139.74679287070603 5.67 35.67005829492017 139.74675285240087 5.67 35.67005829492017 139.74675285240087 69.15 35.67002956988339 139.74679287070603 69.15 35.67002956988339 139.74679287070603 5.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67005829492017 139.74675285240087 5.67 35.669999209257355 139.74668929004866 5.67 35.669999209257355 139.74668929004866 69.15 35.67005829492017 139.74675285240087 69.15 35.67005829492017 139.74675285240087 5.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669999209257355 139.74668929004866 5.67 35.6700852037906 139.74656901425246 5.67 35.6700852037906 139.74656901425246 69.15 35.669999209257355 139.74668929004866 69.15 35.669999209257355 139.74668929004866 5.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6700852037906 139.74656901425246 5.67 35.670078528460564 139.74656184143407 5.67 35.670078528460564 139.74656184143407 69.15 35.6700852037906 139.74656901425246 69.15 35.6700852037906 139.74656901425246 5.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670078528460564 139.74656184143407 5.67 35.67008681280824 139.7465503444001 5.67 35.67008681280824 139.7465503444001 69.15 35.670078528460564 139.74656184143407 69.15 35.670078528460564 139.74656184143407 5.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67008681280824 139.7465503444001 5.67 35.6699922756089 139.74644871116172 5.67 35.6699922756089 139.74644871116172 69.15 35.67008681280824 139.7465503444001 69.15 35.67008681280824 139.7465503444001 5.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6699922756089 139.74644871116172 5.67 35.66998471173122 139.74645932371556 5.67 35.66998471173122 139.74645932371556 69.15 35.6699922756089 139.74644871116172 69.15 35.6699922756089 139.74644871116172 5.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66998471173122 139.74645932371556 5.67 35.66997668322003 139.74645060591303 5.67 35.66997668322003 139.74645060591303 69.15 35.66998471173122 139.74645932371556 69.15 35.66998471173122 139.74645932371556 5.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66997668322003 139.74645060591303 5.67 35.669589031753276 139.74699239783644 5.67 35.669589031753276 139.74699239783644 69.15 35.66997668322003 139.74645060591303 69.15 35.66997668322003 139.74645060591303 5.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669589031753276 139.74699239783644 5.67 35.66968329785118 139.74709370011286 5.67 35.66968329785118 139.74709370011286 69.15 35.669589031753276 139.74699239783644 69.15 35.669589031753276 139.74699239783644 5.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66968329785118 139.74709370011286 5.67 35.669607297987824 139.74719993539293 5.67 35.669607297987824 139.74719993539293 69.15 35.66968329785118 139.74709370011286 69.15 35.66968329785118 139.74709370011286 5.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669607297987824 139.74719993539293 5.67 35.66961325162929 139.74720633576675 5.67 35.66961325162929 139.74720633576675 69.15 35.669607297987824 139.74719993539293 69.15 35.669607297987824 139.74719993539293 5.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66961325162929 139.74720633576675 5.67 35.669602806214876 139.74722103837044 5.67 35.669602806214876 139.74722103837044 69.15 35.66961325162929 139.74720633576675 69.15 35.66961325162929 139.74720633576675 5.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669602806214876 139.74722103837044 5.67 35.66969689168829 139.7473221202037 5.67 35.66969689168829 139.7473221202037 69.15 35.669602806214876 139.74722103837044 69.15 35.669602806214876 139.74722103837044 5.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66969689168829 139.7473221202037 5.67 35.669707337272705 139.74730763851906 5.67 35.669707337272705 139.74730763851906 69.15 35.66969689168829 139.7473221202037 69.15 35.66969689168829 139.7473221202037 5.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669707337272705 139.74730763851906 5.67 35.66971518521107 139.74731602518693 5.67 35.66971518521107 139.74731602518693 69.15 35.669707337272705 139.74730763851906 69.15 35.669707337272705 139.74730763851906 5.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66971518521107 139.74731602518693 5.67 35.670063397543906 139.74682928670842 5.67 35.670063397543906 139.74682928670842 69.15 35.66971518521107 139.74731602518693 69.15 35.66971518521107 139.74731602518693 5.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670063397543906 139.74682928670842 5.67 35.67002956988339 139.74679287070603 5.67 35.67002956988339 139.74679287070603 69.15 35.670063397543906 139.74682928670842 69.15 35.670063397543906 139.74682928670842 5.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67002956988339 139.74679287070603 69.15 35.67005829492017 139.74675285240087 69.15 35.669999209257355 139.74668929004866 69.15 35.6700852037906 139.74656901425246 69.15 35.670078528460564 139.74656184143407 69.15 35.67008681280824 139.7465503444001 69.15 35.6699922756089 139.74644871116172 69.15 35.66998471173122 139.74645932371556 69.15 35.66997668322003 139.74645060591303 69.15 35.669589031753276 139.74699239783644 69.15 35.66968329785118 139.74709370011286 69.15 35.669607297987824 139.74719993539293 69.15 35.66961325162929 139.74720633576675 69.15 35.669602806214876 139.74722103837044 69.15 35.66969689168829 139.7473221202037 69.15 35.669707337272705 139.74730763851906 69.15 35.66971518521107 139.74731602518693 69.15 35.670063397543906 139.74682928670842 69.15 35.67002956988339 139.74679287070603 69.15</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-5b2c0855-2456-4297-aac4-a4a0b90e3dfd"/>
							<gml:surfaceMember xlink:href="#poly-bf387382-aada-46b3-8ff2-3d6bff81d4c9"/>
							<gml:surfaceMember xlink:href="#poly-47461dbf-9861-49c9-bc19-f161d4f618bc"/>
							<gml:surfaceMember xlink:href="#poly-57e309fe-614a-4e14-9b48-adc4d15cc497"/>
							<gml:surfaceMember xlink:href="#poly-ab233cc8-79d7-4cfd-9353-747a281e4d23"/>
							<gml:surfaceMember xlink:href="#poly-880fd5c6-d481-45fc-b88f-c888b4f82c10"/>
							<gml:surfaceMember xlink:href="#poly-85fb25d1-43c6-4ad4-a264-31527040ca60"/>
							<gml:surfaceMember xlink:href="#poly-9cff2c50-a2c0-4e2c-9d50-8bbd08e75fd2"/>
							<gml:surfaceMember xlink:href="#poly-89901751-55b7-47dc-ac23-e8cbdc504154"/>
							<gml:surfaceMember xlink:href="#poly-996a4fbd-80d3-4007-b7b0-c1a1876b1d74"/>
							<gml:surfaceMember xlink:href="#poly-9a521cc2-3fa4-4650-98d7-dda3c3052081"/>
							<gml:surfaceMember xlink:href="#poly-6ab2a82d-9c2c-48bc-b0ae-21e3d8def375"/>
							<gml:surfaceMember xlink:href="#poly-36375764-f5b8-4bd4-8eb4-baedc84188a2"/>
							<gml:surfaceMember xlink:href="#poly-68c8482a-ce8c-4ed4-93f4-a3f1a5f917e9"/>
							<gml:surfaceMember xlink:href="#poly-d46f735d-f7b3-4422-8fb3-0b36f8562fae"/>
							<gml:surfaceMember xlink:href="#poly-ed057181-b9bc-49b8-bd99-46180d434b1b"/>
							<gml:surfaceMember xlink:href="#poly-8387e812-d7eb-494a-a2a7-27cc5020f9e8"/>
							<gml:surfaceMember xlink:href="#poly-ee95a372-6490-4a5f-a953-3ec230220b34"/>
							<gml:surfaceMember xlink:href="#poly-4cc16a70-8bb2-4895-9f8e-fdec575653a4"/>
							<gml:surfaceMember xlink:href="#poly-5d7d1e4f-e0b5-4291-b06e-14eb8ff6517a"/>
							<gml:surfaceMember xlink:href="#poly-853fde9e-f1b2-4758-b315-508412f9c9ed"/>
							<gml:surfaceMember xlink:href="#poly-78371c03-7bd0-4f3f-8894-b9b9f193480f"/>
							<gml:surfaceMember xlink:href="#poly-0291ba73-3e28-454f-a816-e599dbe4643a"/>
							<gml:surfaceMember xlink:href="#poly-1081724c-9299-46ef-844b-cbab343a1ec8"/>
							<gml:surfaceMember xlink:href="#poly-13650ad2-8b17-449a-9b4d-3b81382e6dfe"/>
							<gml:surfaceMember xlink:href="#poly-ef9e656e-4ec2-4624-b1bf-64d32ccae5bf"/>
							<gml:surfaceMember xlink:href="#poly-8dcc8adc-d4b8-4a54-aad8-878136667010"/>
							<gml:surfaceMember xlink:href="#poly-d766567d-2d0f-4df4-9138-b226c105519f"/>
							<gml:surfaceMember xlink:href="#poly-16c6f560-11f8-4788-af83-dabb45c142ab"/>
							<gml:surfaceMember xlink:href="#poly-69913194-556e-4ca9-a94d-c3c14f835f47"/>
							<gml:surfaceMember xlink:href="#poly-9ef17217-9945-414f-8533-d1b90c7fa191"/>
							<gml:surfaceMember xlink:href="#poly-6030a69e-45b3-448e-9824-8870816cefca"/>
							<gml:surfaceMember xlink:href="#poly-e8bce30b-2138-4c44-aebf-d511a969fdaf"/>
							<gml:surfaceMember xlink:href="#poly-1add9d4c-f68e-478d-b992-ed8e28939e7a"/>
							<gml:surfaceMember xlink:href="#poly-94c57b6d-9e6b-48fc-a5ca-df8cedd97627"/>
							<gml:surfaceMember xlink:href="#poly-2f2ce4cc-5908-494a-a630-6d74d0437e7e"/>
							<gml:surfaceMember xlink:href="#poly-5a4bf574-6502-4b95-8fb7-18a5c2731be9"/>
							<gml:surfaceMember xlink:href="#poly-e5003887-8849-4f2f-98c3-a461fea82a24"/>
							<gml:surfaceMember xlink:href="#poly-28940ca7-0745-462e-aa8f-1f2786402a10"/>
							<gml:surfaceMember xlink:href="#poly-712317c3-7c05-439a-88a1-2dae02d08d54"/>
							<gml:surfaceMember xlink:href="#poly-2e7f9066-3bdc-4b8e-883d-cfb9b1eb611c"/>
							<gml:surfaceMember xlink:href="#poly-2924b0e7-2de0-43db-81fa-39cf6d434298"/>
							<gml:surfaceMember xlink:href="#poly-7a749815-c8ca-481e-bd4c-7315fd7f22fd"/>
							<gml:surfaceMember xlink:href="#poly-7c452cfc-7aaa-4a89-9c3c-2b7c47bf7286"/>
							<gml:surfaceMember xlink:href="#poly-0c9df1b2-961c-4c35-aaf7-de79f693b22a"/>
							<gml:surfaceMember xlink:href="#poly-e5b69807-af4d-4b95-8ff3-1b694f08085d"/>
							<gml:surfaceMember xlink:href="#poly-c1b94c19-ea2b-4abc-bcf8-a7f020144610"/>
							<gml:surfaceMember xlink:href="#poly-b9296e96-deab-40d4-86f1-9e53f5c7d534"/>
							<gml:surfaceMember xlink:href="#poly-4fa48160-21cc-4208-844a-ad658d0e22d5"/>
							<gml:surfaceMember xlink:href="#poly-26cd363e-8a57-4d5d-9284-7f8d0ff8c86d"/>
							<gml:surfaceMember xlink:href="#poly-dcd0feb9-b24e-4951-9cdc-a9b636c36f8f"/>
							<gml:surfaceMember xlink:href="#poly-e505083c-f424-45c6-9e77-8307589d3d0b"/>
							<gml:surfaceMember xlink:href="#poly-a5f554c5-23dc-4ec9-9513-052cf18a14ca"/>
							<gml:surfaceMember xlink:href="#poly-6945ee0a-9efb-462f-b827-05f48bcf2200"/>
							<gml:surfaceMember xlink:href="#poly-bd2a382a-d114-4872-a114-583616740e31"/>
							<gml:surfaceMember xlink:href="#poly-4f890637-e3f9-4206-8939-4d1aea42ee75"/>
							<gml:surfaceMember xlink:href="#poly-923bfbdf-773f-4c8b-b73f-beda5022bf51"/>
							<gml:surfaceMember xlink:href="#poly-43648d17-e657-41cb-a9c1-a79394dfa902"/>
							<gml:surfaceMember xlink:href="#poly-0dc629aa-2528-4b42-bd42-479a437e1cfb"/>
							<gml:surfaceMember xlink:href="#poly-941aa71a-b14c-4051-887e-a67a1dcf0257"/>
							<gml:surfaceMember xlink:href="#poly-29075ecc-2b0e-4269-a3e1-843c8ece8db6"/>
							<gml:surfaceMember xlink:href="#poly-8ebfbceb-26df-4130-9c15-db235d1da65a"/>
							<gml:surfaceMember xlink:href="#poly-dd632096-17e3-477d-bde6-6c584618ee3a"/>
							<gml:surfaceMember xlink:href="#poly-539e19e8-f1da-4fd6-9593-cbae487edfd1"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_26936c14-34ee-407e-b77b-42fb2fe47520_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f0d6b4e7-687b-4097-9998-cc3d1e48b08f">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66996580886618 139.74662040888205 71.5 35.66995417213992 139.7466078950748 71.5 35.66996184455353 139.74659777950072 71.5 35.6699731841143 139.7466106912925 71.5 35.66996580886618 139.74662040888205 71.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-95d7087c-ef62-4ada-a8eb-679c44d8d2ea">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66996269307645 139.74662452143912 66.889 35.66995135351713 139.7466116096471 66.889 35.66995417213992 139.7466078950748 66.889 35.66996580886618 139.74662040888205 66.889 35.66996269307645 139.74662452143912 66.889</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7cf4bdfe-1ebf-4ae9-b342-5343cdc638cc">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66996107206635 139.7466641127812 66.889 35.669955867507774 139.74667158563935 66.889 35.66990222239159 139.7466153964011 66.889 35.66990742694672 139.7466079235443 66.889 35.66996107206635 139.7466641127812 66.889</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7f922a89-3e22-458a-aa16-7113776ec4c6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66994536814068 139.74668637680344 66.889 35.66989181384461 139.74663112639078 66.889 35.66989671218068 139.74662399629915 66.889 35.669950266479965 139.7466792467104 66.889 35.66994536814068 139.74668637680344 66.889</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-19c63c98-7195-4471-a584-8530c2e5ecf4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66993200701008 139.74669504041572 66.889 35.669926694372265 139.7467026348941 66.889 35.669884216619074 139.74665804312914 66.889 35.669889529246156 139.74665043760564 66.889 35.66993200701008 139.74669504041572 66.889</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c6495617-86b6-423e-ab1d-95363dfc5eb6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669859048215336 139.74671780812278 66.889 35.66984880958793 139.74670662939607 66.889 35.66985427551503 139.746699112083 66.889 35.66986451414313 139.74671029080955 66.889 35.669859048215336 139.74671780812278 66.889</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1d566ad5-f375-4723-a5af-9700a68704e3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66991067331923 139.74681038574775 66.889 35.669893697161136 139.74679324932933 66.889 35.66989936073657 139.74678481497054 66.889 35.669916345909584 139.74680195137867 66.889 35.66991067331923 139.74681038574775 66.889</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a20d53b7-29fc-42c5-9099-dabb6545cc64">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6698756149213 139.7468173716339 66.889 35.669881314910526 139.74680943431804 66.889 35.66989712824822 139.7468265057147 66.889 35.66989142825788 139.74683444303093 66.889 35.6698756149213 139.7468173716339 66.889</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-67c27766-bb21-4ff9-b455-e08e20063f9b">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669754457727635 139.74681233275697 66.889 35.66975928424259 139.74680558938226 66.889 35.669834606241814 139.7468854161979 66.889 35.66982922134728 139.74689282294722 66.889 35.6697539444612 139.74681305131213 66.889 35.669754457727635 139.74681233275697 66.889</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e4a7f651-61fb-4078-91cc-9314aba5a0e3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6698174339969 139.74690901831246 66.889 35.66974571040188 139.74683184973705 66.889 35.66975152744366 139.74682373557002 66.889 35.669823296152074 139.74690095932604 66.889 35.6698174339969 139.74690901831246 66.889</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a7bfa939-78be-43b1-a789-da5f3683b524">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66986275987681 139.7468780843123 66.889 35.66984769551843 139.7468621719546 66.889 35.66985299018654 139.74685464379078 66.889 35.66986815377619 139.74687066650299 66.889 35.66986275987681 139.7468780843123 66.889</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a80a682a-6e62-4de3-bc13-07ed4546dab4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66970662211031 139.74688799539095 72.582 35.669690791847195 139.74691011583462 72.582 35.66967697214004 139.74689525154866 72.582 35.66969280240839 139.74687314215203 72.582 35.66970662211031 139.74688799539095 72.582</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d0bd6b58-2204-478f-875f-ee95692baf49">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66977297572795 139.74691803572875 72.582 35.66973369995626 139.74687626830192 72.582 35.66974138988877 139.74686541266894 72.582 35.66978066565624 139.74690716904828 72.582 35.66977297572795 139.74691803572875 72.582</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fbfc1b87-3316-49ad-98c4-add181a6167f">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6698408575113 139.74689203716935 66.889 35.66984265260649 139.74689393517804 66.889 35.669837357920045 139.74690144124594 66.889 35.66983546360264 139.7468994439285 66.889 35.6698408575113 139.74689203716935 66.889</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-03d2d2e3-a5e0-463a-9fac-e047034d7fac">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66989310245834 139.74686881697724 66.889 35.66992860752157 139.74690644622348 66.889 35.669942366506035 139.74688694589594 66.889 35.66994776984289 139.74689267304825 66.889 35.669934010857524 139.74691217337613 66.889 35.66994888580993 139.74692793131763 66.889 35.66994355510619 139.74693549266303 66.889 35.66988777175827 139.74687637832133 66.889 35.66989310245834 139.74686881697724 66.889</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b8e7662a-e07b-4109-8db9-97aab929072c">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66984879587808 139.74691334775162 66.889 35.669838900289854 139.74690286454123 66.889 35.66984411394009 139.74689548006867 66.889 35.66985400953688 139.74690597432502 66.889 35.66984879587808 139.74691334775162 66.889</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f4463fca-9550-4a25-96d0-3c4753f0f472">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66967532204301 139.74691955488606 72.582 35.66966706635054 139.74690823042164 72.582 35.66967588386596 139.74689857761695 72.582 35.66968413956727 139.7469099131278 72.582 35.66967532204301 139.74691955488606 72.582</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-45442faf-808a-44ac-bd45-88cabfdd2625">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66982950239174 139.74690763557723 66.889 35.66983294829857 139.7469113433809 66.889 35.66982713125097 139.74691945754986 66.889 35.66982364023612 139.74691569456377 66.889 35.66982950239174 139.74690763557723 66.889</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e5c0b8e0-6809-4944-9426-6007e9fdf688">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66987661508253 139.74687961583925 66.889 35.66993870369062 139.7469452295923 66.889 35.66993340900898 139.746952746712 66.889 35.669871221182596 139.7468870336487 66.889 35.66987661508253 139.74687961583925 66.889</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7be9928f-8128-45ca-af73-6279d2fbe474">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66966492070206 139.74693282149 72.582 35.66965712551936 139.7469226232377 72.582 35.669664582740346 139.7469140544258 72.582 35.669672386937485 139.7469242526685 72.582 35.66966492070206 139.74693282149 72.582</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f2da7af5-b139-498c-8c4b-02d160f8deca">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669693787978396 139.7469779139691 72.582 35.66967156982173 139.7469537468028 72.582 35.669690353868226 139.74692782330928 72.582 35.66971257203002 139.74695199047397 72.582 35.669693787978396 139.7469779139691 72.582</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8f3782ea-d982-4e69-91e2-72fcd9d4f8c1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669776283021115 139.74695468337913 72.582 35.66977973790856 139.74695834698798 72.582 35.669763952843944 139.74698066622048 72.582 35.66976049795717 139.74697700261135 72.582 35.669776283021115 139.74695468337913 72.582</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6ecc4533-ea1f-4938-8b3c-516b1ec0d30f">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66971834269656 139.74700488435982 72.582 35.66969717921461 139.74698080441212 72.582 35.669715973080876 139.74695599656906 72.582 35.669737136567726 139.7469800765158 72.582 35.66971834269656 139.74700488435982 72.582</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ac5b63ce-2b21-4507-8855-b256c72d4c6a">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66963120901663 139.7469700612736 74.742 35.669636964471316 139.7469766054458 74.742 35.6696214935448 139.74699705749634 74.742 35.669615729077485 139.74699051333369 74.742 35.66963120901663 139.7469700612736 74.742</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fd0a1194-8a0c-4e08-9864-19e248b841ed">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66964999832692 139.74698917298346 74.742 35.66963502358874 139.74701023203937 74.742 35.6696290609469 139.74700386482652 74.742 35.669644035683994 139.74698280577098 74.742 35.66964999832692 139.74698917298346 74.742</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d269bed6-f4d6-4db5-a0d8-423093bea8d4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669658400814015 139.74699152781335 74.742 35.66966412947976 139.7469984254953 74.742 35.669647802182354 139.7470187901012 74.742 35.669642064504025 139.7470118924289 74.742 35.669658400814015 139.74699152781335 74.742</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ebbf5f92-2266-4310-bcf8-b14b02573701">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6697359761974 139.74699599529842 72.582 35.66974532207508 139.74700666688366 72.582 35.66973463285555 139.7470207291221 72.582 35.66972528697909 139.74701005753664 72.582 35.6697359761974 139.74699599529842 72.582</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-44a85521-bce9-4d4c-99a7-7233f320f47d">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6696702720796 139.7470043506703 74.742 35.669676451280424 139.74701103799202 74.742 35.669662313777835 139.74703064910256 74.742 35.669656134586 139.7470239728266 74.742 35.6696702720796 139.7470043506703 74.742</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cd269370-64f6-462b-8a47-e805d243bed1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66986895602421 139.74700889765506 66.889 35.66979565790412 139.7471117060409 66.889 35.669771320188325 139.74708564114448 66.889 35.66984461829438 139.7469828438123 66.889 35.66986895602421 139.74700889765506 66.889</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-075376ce-3410-4470-b533-f475b7cef486">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66980279552089 139.7471351273143 66.889 35.66979708643309 139.7471429762396 66.889 35.66975262296642 139.74709439878012 66.889 35.66975833205108 139.74708654985577 66.889 35.66980279552089 139.7471351273143 66.889</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9f3672a0-6910-42ce-af38-cd1d04a4fa2f">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66970425091265 139.74712606493767 71.5 35.66972200315313 139.74714452609228 71.5 35.66971708673487 139.74715162301752 71.5 35.66969933449546 139.74713316186248 71.5 35.66970425091265 139.74712606493767 71.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3c568eba-06c6-42b1-94dc-bccbd42ab87b">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6697666826002 139.74714225778285 66.889 35.66975829005442 139.74715378796455 66.889 35.66974992778483 139.74714465072117 66.889 35.66975420509004 139.74713875851262 66.889 35.66975840877525 139.74714334920213 66.889 35.669762514993565 139.74713770019267 66.889 35.6697666826002 139.74714225778285 66.889</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2b4db041-b94d-4eac-9732-a6574a26f48d">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66977448252431 139.74713392058092 66.889 35.66979442634774 139.7471541246941 66.889 35.66978534058189 139.74716682651845 66.889 35.6697657034486 139.74714693136764 66.889 35.66977448252431 139.74713392058092 66.889</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e7cf73e0-961a-45e3-80cc-db6edecfe31b">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66968049808246 139.7471741412883 71.5 35.66967485086646 139.74716768535134 71.5 35.669691096369725 139.74714634879422 71.5 35.66969674358685 139.74715280473097 71.5 35.66968049808246 139.7471741412883 71.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b13265c7-b650-47e6-8bc8-7fb1a08936d2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66974609693682 139.7471824217037 71.5 35.66972796667907 139.74716473417337 71.5 35.66973269368338 139.7471574607128 71.5 35.66975082395009 139.74717515928873 71.5 35.66974609693682 139.7471824217037 71.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b3f008e7-f8bb-4d4d-9b10-5f49119ad111">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66967878708698 139.7471763965442 71.5 35.66966231644854 139.74719803158018 71.5 35.669656669233824 139.74719157564303 71.5 35.66967313987111 139.74716994060725 71.5 35.66967878708698 139.7471763965442 71.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-19f891ad-ee8f-4400-b044-94faa5340ec1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66974656477029 139.74720639139602 71.5 35.669731401638174 139.74722875408727 71.5 35.6697251325255 139.7472223650873 71.5 35.66974030467808 139.7472000134331 71.5 35.66974656477029 139.74720639139602 71.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f2382980-7b68-4d0f-b7db-6036e8105be6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66965293568152 139.74722677271967 71.5 35.66965834744839 139.74721910087237 71.5 35.66967560380139 139.74723739687707 71.5 35.66967019202547 139.74724505767864 71.5 35.66965293568152 139.74722677271967 71.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6d555e36-ef2f-4ff2-aa97-e84265f82f2c">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66972309693233 139.7472244770919 71.5 35.669729249214 139.7472313522488 71.5 35.66971366142134 139.74725230147686 71.5 35.66970750913294 139.74724541527354 71.5 35.66972309693233 139.7472244770919 71.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6d05ef7f-4438-4d50-bf4e-ea2fe6b1467c">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66969075070616 139.74726797848987 71.5 35.66967293493828 139.74724888775202 71.5 35.669678733972944 139.7472407625958 71.5 35.669696549749986 139.74725986437934 71.5 35.66969075070616 139.74726797848987 71.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-73bd0e69-41e8-4ca3-b15b-fda2ad6eb93c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-73bd0e69-41e8-4ca3-b15b-fda2ad6eb93c_0">
											<gml:posList>35.66990222239159 139.7466153964011 68.702 35.66990222239159 139.7466153964011 66.889 35.669955867507774 139.74667158563935 66.889 35.669955867507774 139.74667158563935 68.702 35.66990222239159 139.7466153964011 68.702</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3dc24225-bbdb-4c5a-9c95-d6fd3248e56a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3dc24225-bbdb-4c5a-9c95-d6fd3248e56a_0">
											<gml:posList>35.669950266479965 139.7466792467104 68.702 35.669950266479965 139.7466792467104 66.889 35.66989671218068 139.74662399629915 66.889 35.66989671218068 139.74662399629915 68.702 35.669950266479965 139.7466792467104 68.702</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-08fe7305-9f35-4ac7-94c5-1bada464ac7a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-08fe7305-9f35-4ac7-94c5-1bada464ac7a_0">
											<gml:posList>35.66994355510619 139.74693549266303 66.889 35.66994355510619 139.74693549266303 68.472 35.66988777175827 139.74687637832133 68.472 35.66988777175827 139.74687637832133 66.889 35.66994355510619 139.74693549266303 66.889</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-92cb8235-51b5-4a21-aebe-8a493d735d8c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-92cb8235-51b5-4a21-aebe-8a493d735d8c_0">
											<gml:posList>35.66972309693233 139.7472244770919 73.92 35.669729249214 139.7472313522488 73.92 35.669729249214 139.7472313522488 71.5 35.66972309693233 139.7472244770919 71.5 35.66972309693233 139.7472244770919 73.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-51c6f201-11cc-4b33-a7fe-6ebcefb5b11a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-51c6f201-11cc-4b33-a7fe-6ebcefb5b11a_0">
											<gml:posList>35.66967019202547 139.74724505767864 73.92 35.66967019202547 139.74724505767864 71.5 35.66967560380139 139.74723739687707 71.5 35.66967560380139 139.74723739687707 73.92 35.66967019202547 139.74724505767864 73.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6eed9c33-9c9e-4a23-897c-3c70dc0cf7d1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6eed9c33-9c9e-4a23-897c-3c70dc0cf7d1_0">
											<gml:posList>35.66975928424259 139.74680558938226 66.889 35.669754457727635 139.74681233275697 66.889 35.669754457727635 139.74681233275697 68.834 35.66975928424259 139.74680558938226 68.834 35.66975928424259 139.74680558938226 66.889</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fc6202ee-dd09-4871-bfb7-41d082506f79">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fc6202ee-dd09-4871-bfb7-41d082506f79_0">
											<gml:posList>35.669754457727635 139.74681233275697 66.889 35.6697539444612 139.74681305131213 66.889 35.6697539444612 139.74681305131213 68.834 35.669754457727635 139.74681233275697 68.834 35.669754457727635 139.74681233275697 66.889</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ad1cde80-6d9e-4f08-8ea9-ce865284e111">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ad1cde80-6d9e-4f08-8ea9-ce865284e111_0">
											<gml:posList>35.66975152744366 139.74682373557002 66.889 35.66974571040188 139.74683184973705 66.889 35.66974571040188 139.74683184973705 69.04 35.66975152744366 139.74682373557002 69.04 35.66975152744366 139.74682373557002 66.889</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e7ddf7e8-a817-4756-846f-832b16156fd1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e7ddf7e8-a817-4756-846f-832b16156fd1_0">
											<gml:posList>35.669834606241814 139.7468854161979 68.834 35.669834606241814 139.7468854161979 66.889 35.66975928424259 139.74680558938226 66.889 35.66975928424259 139.74680558938226 68.834 35.669834606241814 139.7468854161979 68.834</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-86591514-78e0-4e26-b95f-19954207bcdb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-86591514-78e0-4e26-b95f-19954207bcdb_0">
											<gml:posList>35.66982922134728 139.74689282294722 68.834 35.669834606241814 139.7468854161979 68.834 35.66975928424259 139.74680558938226 68.834 35.669754457727635 139.74681233275697 68.834 35.6697539444612 139.74681305131213 68.834 35.66982922134728 139.74689282294722 68.834</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-12eb6ca1-36b9-4922-818f-8b83ef890b5b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-12eb6ca1-36b9-4922-818f-8b83ef890b5b_0">
											<gml:posList>35.6697539444612 139.74681305131213 68.834 35.6697539444612 139.74681305131213 66.889 35.66982922134728 139.74689282294722 66.889 35.66982922134728 139.74689282294722 68.834 35.6697539444612 139.74681305131213 68.834</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-62d4629e-8e8a-4e9e-bda4-648069455948">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-62d4629e-8e8a-4e9e-bda4-648069455948_0">
											<gml:posList>35.669823296152074 139.74690095932604 69.04 35.669823296152074 139.74690095932604 66.889 35.66975152744366 139.74682373557002 66.889 35.66975152744366 139.74682373557002 69.04 35.669823296152074 139.74690095932604 69.04</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fe539880-09ca-40f3-ada1-09d4589084dc">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fe539880-09ca-40f3-ada1-09d4589084dc_0">
											<gml:posList>35.6698174339969 139.74690901831246 69.04 35.669823296152074 139.74690095932604 69.04 35.66975152744366 139.74682373557002 69.04 35.66974571040188 139.74683184973705 69.04 35.6698174339969 139.74690901831246 69.04</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ca92fd12-db7a-4724-8cf2-3c6cab76a4ca">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ca92fd12-db7a-4724-8cf2-3c6cab76a4ca_0">
											<gml:posList>35.6698174339969 139.74690901831246 66.889 35.6698174339969 139.74690901831246 69.04 35.66974571040188 139.74683184973705 69.04 35.66974571040188 139.74683184973705 66.889 35.6698174339969 139.74690901831246 66.889</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8e87fed6-891f-4420-a077-47bbf272da74">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8e87fed6-891f-4420-a077-47bbf272da74_0">
											<gml:posList>35.66974138988877 139.74686541266894 72.582 35.66973369995626 139.74687626830192 72.582 35.66973369995626 139.74687626830192 73.683 35.66974138988877 139.74686541266894 73.683 35.66974138988877 139.74686541266894 72.582</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c7703cd0-204c-4ee0-87a9-518398a1b46d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c7703cd0-204c-4ee0-87a9-518398a1b46d_0">
											<gml:posList>35.66970662211031 139.74688799539095 72.582 35.66969280240839 139.74687314215203 72.582 35.66969280240839 139.74687314215203 74.028 35.66970662211031 139.74688799539095 74.028 35.66970662211031 139.74688799539095 72.582</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c5219998-eafa-4912-b160-dab61a2262ab">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c5219998-eafa-4912-b160-dab61a2262ab_0">
											<gml:posList>35.66969280240839 139.74687314215203 72.582 35.66967697214004 139.74689525154866 72.582 35.66967697214004 139.74689525154866 74.028 35.66969280240839 139.74687314215203 74.028 35.66969280240839 139.74687314215203 72.582</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e781b70b-1219-4248-a8bf-8d4e96f78e2f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e781b70b-1219-4248-a8bf-8d4e96f78e2f_0">
											<gml:posList>35.66978066565624 139.74690716904828 72.582 35.66974138988877 139.74686541266894 72.582 35.66974138988877 139.74686541266894 73.683 35.66978066565624 139.74690716904828 73.683 35.66978066565624 139.74690716904828 72.582</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a4f49561-fdc4-4303-aa0a-3c896be37d71">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a4f49561-fdc4-4303-aa0a-3c896be37d71_0">
											<gml:posList>35.66982922134728 139.74689282294722 66.889 35.669834606241814 139.7468854161979 66.889 35.669834606241814 139.7468854161979 68.834 35.66982922134728 139.74689282294722 68.834 35.66982922134728 139.74689282294722 66.889</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1d42bfac-780c-458f-9a01-ec4b8ebefbdc">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1d42bfac-780c-458f-9a01-ec4b8ebefbdc_0">
											<gml:posList>35.66970662211031 139.74688799539095 74.028 35.66969280240839 139.74687314215203 74.028 35.66967697214004 139.74689525154866 74.028 35.669690791847195 139.74691011583462 74.028 35.66970662211031 139.74688799539095 74.028</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-19678e1e-fa83-43db-b282-944a51b3cbbf">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-19678e1e-fa83-43db-b282-944a51b3cbbf_0">
											<gml:posList>35.66977297572795 139.74691803572875 73.683 35.66978066565624 139.74690716904828 73.683 35.66974138988877 139.74686541266894 73.683 35.66973369995626 139.74687626830192 73.683 35.66977297572795 139.74691803572875 73.683</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e74eb415-c38c-4ff3-98f1-b6186ad77b55">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e74eb415-c38c-4ff3-98f1-b6186ad77b55_0">
											<gml:posList>35.6698408575113 139.74689203716935 66.889 35.6698408575113 139.74689203716935 68.834 35.66984265260649 139.74689393517804 68.834 35.66984265260649 139.74689393517804 66.889 35.6698408575113 139.74689203716935 66.889</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-86c7c358-0bd7-418b-8fb8-5015538a9c91">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-86c7c358-0bd7-418b-8fb8-5015538a9c91_0">
											<gml:posList>35.6698408575113 139.74689203716935 66.889 35.66983546360264 139.7468994439285 66.889 35.66983546360264 139.7468994439285 68.834 35.6698408575113 139.74689203716935 68.834 35.6698408575113 139.74689203716935 66.889</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2aa27609-0a41-4574-905e-48fa48cb112e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2aa27609-0a41-4574-905e-48fa48cb112e_0">
											<gml:posList>35.6698408575113 139.74689203716935 68.834 35.66983546360264 139.7468994439285 68.834 35.669837357920045 139.74690144124594 68.834 35.66984265260649 139.74689393517804 68.834 35.6698408575113 139.74689203716935 68.834</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bd0488f3-30b5-4c86-ac3e-5f2d14d6edfd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bd0488f3-30b5-4c86-ac3e-5f2d14d6edfd_0">
											<gml:posList>35.66977297572795 139.74691803572875 73.683 35.66973369995626 139.74687626830192 73.683 35.66973369995626 139.74687626830192 72.582 35.66977297572795 139.74691803572875 72.582 35.66977297572795 139.74691803572875 73.683</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9ee02fa4-070e-4dd5-967f-538e76d9413d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9ee02fa4-070e-4dd5-967f-538e76d9413d_0">
											<gml:posList>35.669837357920045 139.74690144124594 66.889 35.66984265260649 139.74689393517804 66.889 35.66984265260649 139.74689393517804 68.834 35.669837357920045 139.74690144124594 68.834 35.669837357920045 139.74690144124594 66.889</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1e4e6ac7-4710-4635-b152-4112d3171a0f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1e4e6ac7-4710-4635-b152-4112d3171a0f_0">
											<gml:posList>35.66970662211031 139.74688799539095 74.028 35.669690791847195 139.74691011583462 74.028 35.669690791847195 139.74691011583462 72.582 35.66970662211031 139.74688799539095 72.582 35.66970662211031 139.74688799539095 74.028</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e67500f0-5ebe-4c5c-a632-249ee3683c1f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e67500f0-5ebe-4c5c-a632-249ee3683c1f_0">
											<gml:posList>35.66984411394009 139.74689548006867 66.889 35.669838900289854 139.74690286454123 66.889 35.669838900289854 139.74690286454123 69.293 35.66984411394009 139.74689548006867 69.293 35.66984411394009 139.74689548006867 66.889</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3d59c13a-5630-4f95-ade5-7f13b97ffad5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3d59c13a-5630-4f95-ade5-7f13b97ffad5_0">
											<gml:posList>35.66983546360264 139.7468994439285 66.889 35.669837357920045 139.74690144124594 66.889 35.669837357920045 139.74690144124594 68.834 35.66983546360264 139.7468994439285 68.834 35.66983546360264 139.7468994439285 66.889</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6f3ccb71-b619-4914-8f51-f485cef580b4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6f3ccb71-b619-4914-8f51-f485cef580b4_0">
											<gml:posList>35.66967697214004 139.74689525154866 72.582 35.669690791847195 139.74691011583462 72.582 35.669690791847195 139.74691011583462 74.028 35.66967697214004 139.74689525154866 74.028 35.66967697214004 139.74689525154866 72.582</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-40ac2f5c-7e00-4093-a4e0-5a87d8dd1e28">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-40ac2f5c-7e00-4093-a4e0-5a87d8dd1e28_0">
											<gml:posList>35.66967588386596 139.74689857761695 72.582 35.66966706635054 139.74690823042164 72.582 35.66966706635054 139.74690823042164 74.978 35.66967588386596 139.74689857761695 74.978 35.66967588386596 139.74689857761695 72.582</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-627674dd-6eab-4f77-863e-66a18a99c478">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-627674dd-6eab-4f77-863e-66a18a99c478_0">
											<gml:posList>35.66968413956727 139.7469099131278 72.582 35.66967588386596 139.74689857761695 72.582 35.66967588386596 139.74689857761695 74.978 35.66968413956727 139.7469099131278 74.978 35.66968413956727 139.7469099131278 72.582</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-96079111-0482-4a68-a092-9b314d73a792">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-96079111-0482-4a68-a092-9b314d73a792_0">
											<gml:posList>35.669823296152074 139.74690095932604 69.04 35.6698174339969 139.74690901831246 69.04 35.6698174339969 139.74690901831246 66.889 35.669823296152074 139.74690095932604 66.889 35.669823296152074 139.74690095932604 69.04</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8d638c40-ef9f-44c5-9500-bc9910763f88">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8d638c40-ef9f-44c5-9500-bc9910763f88_0">
											<gml:posList>35.66967532204301 139.74691955488606 74.978 35.66968413956727 139.7469099131278 74.978 35.66967588386596 139.74689857761695 74.978 35.66966706635054 139.74690823042164 74.978 35.66967532204301 139.74691955488606 74.978</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3be020ca-7150-485f-8805-0cb046fe61e3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3be020ca-7150-485f-8805-0cb046fe61e3_0">
											<gml:posList>35.66982950239174 139.74690763557723 66.889 35.66982950239174 139.74690763557723 69.04 35.66983294829857 139.7469113433809 69.04 35.66983294829857 139.7469113433809 66.889 35.66982950239174 139.74690763557723 66.889</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-52ba851e-f8ad-4ebe-912b-7632b86f9fdf">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-52ba851e-f8ad-4ebe-912b-7632b86f9fdf_0">
											<gml:posList>35.66982364023612 139.74691569456377 69.04 35.66982950239174 139.74690763557723 69.04 35.66982950239174 139.74690763557723 66.889 35.66982364023612 139.74691569456377 66.889 35.66982364023612 139.74691569456377 69.04</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d3cda949-f13f-4a44-88cd-5b4dc52099b8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d3cda949-f13f-4a44-88cd-5b4dc52099b8_0">
											<gml:posList>35.66977297572795 139.74691803572875 72.582 35.66978066565624 139.74690716904828 72.582 35.66978066565624 139.74690716904828 73.683 35.66977297572795 139.74691803572875 73.683 35.66977297572795 139.74691803572875 72.582</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-751d7a33-e382-4b37-b7e0-f2e0311fe123">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-751d7a33-e382-4b37-b7e0-f2e0311fe123_0">
											<gml:posList>35.66982950239174 139.74690763557723 69.04 35.66982364023612 139.74691569456377 69.04 35.66982713125097 139.74691945754986 69.04 35.66983294829857 139.7469113433809 69.04 35.66982950239174 139.74690763557723 69.04</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-37ea1b16-05b0-49c1-82c4-f7cb7c962bd6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-37ea1b16-05b0-49c1-82c4-f7cb7c962bd6_0">
											<gml:posList>35.66967532204301 139.74691955488606 74.978 35.66966706635054 139.74690823042164 74.978 35.66966706635054 139.74690823042164 72.582 35.66967532204301 139.74691955488606 72.582 35.66967532204301 139.74691955488606 74.978</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-382d7259-6813-43cf-8bd7-102bdb977115">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-382d7259-6813-43cf-8bd7-102bdb977115_0">
											<gml:posList>35.66967532204301 139.74691955488606 72.582 35.66968413956727 139.7469099131278 72.582 35.66968413956727 139.7469099131278 74.978 35.66967532204301 139.74691955488606 74.978 35.66967532204301 139.74691955488606 72.582</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a3ac8817-84e2-4b1d-8e65-e013139ad1b4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a3ac8817-84e2-4b1d-8e65-e013139ad1b4_0">
											<gml:posList>35.66983294829857 139.7469113433809 69.04 35.66982713125097 139.74691945754986 69.04 35.66982713125097 139.74691945754986 66.889 35.66983294829857 139.7469113433809 66.889 35.66983294829857 139.7469113433809 69.04</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-735d6f48-df63-4af2-83ec-b13b06da2656">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-735d6f48-df63-4af2-83ec-b13b06da2656_0">
											<gml:posList>35.66982364023612 139.74691569456377 69.04 35.66982364023612 139.74691569456377 66.889 35.66982713125097 139.74691945754986 66.889 35.66982713125097 139.74691945754986 69.04 35.66982364023612 139.74691569456377 69.04</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3e5752aa-36a8-4063-bd53-61db6ad4672d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3e5752aa-36a8-4063-bd53-61db6ad4672d_0">
											<gml:posList>35.669664582740346 139.7469140544258 72.582 35.66965712551936 139.7469226232377 72.582 35.66965712551936 139.7469226232377 75.324 35.669664582740346 139.7469140544258 75.324 35.669664582740346 139.7469140544258 72.582</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7d9c3309-60a5-4900-b467-c2fb5756b812">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7d9c3309-60a5-4900-b467-c2fb5756b812_0">
											<gml:posList>35.669672386937485 139.7469242526685 72.582 35.669664582740346 139.7469140544258 72.582 35.669664582740346 139.7469140544258 75.324 35.669672386937485 139.7469242526685 75.324 35.669672386937485 139.7469242526685 72.582</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bc21cc5b-af0d-42be-a069-016db5cd0a83">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bc21cc5b-af0d-42be-a069-016db5cd0a83_0">
											<gml:posList>35.66966492070206 139.74693282149 75.324 35.669672386937485 139.7469242526685 75.324 35.669664582740346 139.7469140544258 75.324 35.66965712551936 139.7469226232377 75.324 35.66966492070206 139.74693282149 75.324</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4bedf718-b69d-45a9-8981-a9cd06e073af">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4bedf718-b69d-45a9-8981-a9cd06e073af_0">
											<gml:posList>35.66966492070206 139.74693282149 72.582 35.66966492070206 139.74693282149 75.324 35.66965712551936 139.7469226232377 75.324 35.66965712551936 139.7469226232377 72.582 35.66966492070206 139.74693282149 72.582</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3583aff6-0d62-4abe-8efd-55d05513d783">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3583aff6-0d62-4abe-8efd-55d05513d783_0">
											<gml:posList>35.66966492070206 139.74693282149 72.582 35.669672386937485 139.7469242526685 72.582 35.669672386937485 139.7469242526685 75.324 35.66966492070206 139.74693282149 75.324 35.66966492070206 139.74693282149 72.582</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8cd3b3a0-cdba-4d12-9929-ec8751737a22">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8cd3b3a0-cdba-4d12-9929-ec8751737a22_0">
											<gml:posList>35.669690353868226 139.74692782330928 76.17 35.66971257203002 139.74695199047397 76.17 35.66971257203002 139.74695199047397 72.582 35.669690353868226 139.74692782330928 72.582 35.669690353868226 139.74692782330928 76.17</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-13e9174f-86a6-4e2a-887a-50d6fb2da6d4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-13e9174f-86a6-4e2a-887a-50d6fb2da6d4_0">
											<gml:posList>35.669690353868226 139.74692782330928 76.17 35.669690353868226 139.74692782330928 72.582 35.66967156982173 139.7469537468028 72.582 35.66967156982173 139.7469537468028 76.17 35.669690353868226 139.74692782330928 76.17</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fa7dafe2-83d4-4f51-a421-4dae859ed0e8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fa7dafe2-83d4-4f51-a421-4dae859ed0e8_0">
											<gml:posList>35.669690353868226 139.74692782330928 76.17 35.66967156982173 139.7469537468028 76.17 35.669693787978396 139.7469779139691 76.17 35.66971257203002 139.74695199047397 76.17 35.669690353868226 139.74692782330928 76.17</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0c39cd99-bcbb-4e9e-a385-854270faf49b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0c39cd99-bcbb-4e9e-a385-854270faf49b_0">
											<gml:posList>35.669776283021115 139.74695468337913 74.812 35.66977973790856 139.74695834698798 74.812 35.66977973790856 139.74695834698798 72.582 35.669776283021115 139.74695468337913 72.582 35.669776283021115 139.74695468337913 74.812</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2e230fff-cf60-4f32-bc1d-20d5795d4998">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2e230fff-cf60-4f32-bc1d-20d5795d4998_0">
											<gml:posList>35.669693787978396 139.7469779139691 72.582 35.66971257203002 139.74695199047397 72.582 35.66971257203002 139.74695199047397 76.17 35.669693787978396 139.7469779139691 76.17 35.669693787978396 139.7469779139691 72.582</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9d15c751-791f-427e-802e-e02c92d8257a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9d15c751-791f-427e-802e-e02c92d8257a_0">
											<gml:posList>35.66967156982173 139.7469537468028 72.582 35.669693787978396 139.7469779139691 72.582 35.669693787978396 139.7469779139691 76.17 35.66967156982173 139.7469537468028 76.17 35.66967156982173 139.7469537468028 72.582</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-adefb595-c9b7-4008-b311-312645c1d9a9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-adefb595-c9b7-4008-b311-312645c1d9a9_0">
											<gml:posList>35.669776283021115 139.74695468337913 72.582 35.66976049795717 139.74697700261135 72.582 35.66976049795717 139.74697700261135 74.812 35.669776283021115 139.74695468337913 74.812 35.669776283021115 139.74695468337913 72.582</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-02ca68c2-e273-4acc-893a-b837b1e8186c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-02ca68c2-e273-4acc-893a-b837b1e8186c_0">
											<gml:posList>35.669776283021115 139.74695468337913 74.812 35.66976049795717 139.74697700261135 74.812 35.669763952843944 139.74698066622048 74.812 35.66977973790856 139.74695834698798 74.812 35.669776283021115 139.74695468337913 74.812</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-63b5906d-1cec-4ec0-ab10-49165116462f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-63b5906d-1cec-4ec0-ab10-49165116462f_0">
											<gml:posList>35.669737136567726 139.7469800765158 72.582 35.669715973080876 139.74695599656906 72.582 35.669715973080876 139.74695599656906 76.17 35.669737136567726 139.7469800765158 76.17 35.669737136567726 139.7469800765158 72.582</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a5f60af5-541e-4ead-90b8-0240b6468df9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a5f60af5-541e-4ead-90b8-0240b6468df9_0">
											<gml:posList>35.669715973080876 139.74695599656906 72.582 35.66969717921461 139.74698080441212 72.582 35.66969717921461 139.74698080441212 76.17 35.669715973080876 139.74695599656906 76.17 35.669715973080876 139.74695599656906 72.582</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-04128b1c-eb24-4b9a-a120-65c205d988ad">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-04128b1c-eb24-4b9a-a120-65c205d988ad_0">
											<gml:posList>35.669763952843944 139.74698066622048 72.582 35.66977973790856 139.74695834698798 72.582 35.66977973790856 139.74695834698798 74.812 35.669763952843944 139.74698066622048 74.812 35.669763952843944 139.74698066622048 72.582</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fe9ab024-14e1-4704-b8b5-155f47769a7e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fe9ab024-14e1-4704-b8b5-155f47769a7e_0">
											<gml:posList>35.66963120901663 139.7469700612736 77.413 35.669636964471316 139.7469766054458 77.413 35.669636964471316 139.7469766054458 74.742 35.66963120901663 139.7469700612736 74.742 35.66963120901663 139.7469700612736 77.413</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bb85f9e4-8ca3-4099-b05a-9455a9aae8e2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bb85f9e4-8ca3-4099-b05a-9455a9aae8e2_0">
											<gml:posList>35.66976049795717 139.74697700261135 72.582 35.669763952843944 139.74698066622048 72.582 35.669763952843944 139.74698066622048 74.812 35.66976049795717 139.74697700261135 74.812 35.66976049795717 139.74697700261135 72.582</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-808e8262-5224-48f5-a70f-035078b84a5d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-808e8262-5224-48f5-a70f-035078b84a5d_0">
											<gml:posList>35.66963120901663 139.7469700612736 74.742 35.669615729077485 139.74699051333369 74.742 35.669615729077485 139.74699051333369 77.413 35.66963120901663 139.7469700612736 77.413 35.66963120901663 139.7469700612736 74.742</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6f0941c6-259f-460e-bc26-efa9abeb2d0e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6f0941c6-259f-460e-bc26-efa9abeb2d0e_0">
											<gml:posList>35.66971834269656 139.74700488435982 76.17 35.669737136567726 139.7469800765158 76.17 35.669715973080876 139.74695599656906 76.17 35.66969717921461 139.74698080441212 76.17 35.66971834269656 139.74700488435982 76.17</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-94bc35d0-873a-4bf4-b9fd-29183fac8436">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-94bc35d0-873a-4bf4-b9fd-29183fac8436_0">
											<gml:posList>35.66963120901663 139.7469700612736 77.413 35.669615729077485 139.74699051333369 77.413 35.6696214935448 139.74699705749634 77.413 35.669636964471316 139.7469766054458 77.413 35.66963120901663 139.7469700612736 77.413</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f7721049-7b7b-4353-863a-e827d7c241b4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f7721049-7b7b-4353-863a-e827d7c241b4_0">
											<gml:posList>35.66964999832692 139.74698917298346 74.742 35.669644035683994 139.74698280577098 74.742 35.669644035683994 139.74698280577098 77.413 35.66964999832692 139.74698917298346 77.413 35.66964999832692 139.74698917298346 74.742</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f999a0c7-d134-4304-ab26-406467ab2b18">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f999a0c7-d134-4304-ab26-406467ab2b18_0">
											<gml:posList>35.6696214935448 139.74699705749634 74.742 35.669636964471316 139.7469766054458 74.742 35.669636964471316 139.7469766054458 77.413 35.6696214935448 139.74699705749634 77.413 35.6696214935448 139.74699705749634 74.742</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-32a1ce18-af83-4314-a8eb-4471ae7bd7d7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-32a1ce18-af83-4314-a8eb-4471ae7bd7d7_0">
											<gml:posList>35.66971834269656 139.74700488435982 72.582 35.669737136567726 139.7469800765158 72.582 35.669737136567726 139.7469800765158 76.17 35.66971834269656 139.74700488435982 76.17 35.66971834269656 139.74700488435982 72.582</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-79c0598a-fdb5-4cd2-a132-c29770bf6578">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-79c0598a-fdb5-4cd2-a132-c29770bf6578_0">
											<gml:posList>35.66971834269656 139.74700488435982 76.17 35.66969717921461 139.74698080441212 76.17 35.66969717921461 139.74698080441212 72.582 35.66971834269656 139.74700488435982 72.582 35.66971834269656 139.74700488435982 76.17</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-afb063bb-ee33-402f-9604-900aa26fdbb4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-afb063bb-ee33-402f-9604-900aa26fdbb4_0">
											<gml:posList>35.669644035683994 139.74698280577098 74.742 35.6696290609469 139.74700386482652 74.742 35.6696290609469 139.74700386482652 77.413 35.669644035683994 139.74698280577098 77.413 35.669644035683994 139.74698280577098 74.742</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-56801b3a-635a-4378-b365-4598db17f58e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-56801b3a-635a-4378-b365-4598db17f58e_0">
											<gml:posList>35.669615729077485 139.74699051333369 74.742 35.6696214935448 139.74699705749634 74.742 35.6696214935448 139.74699705749634 77.413 35.669615729077485 139.74699051333369 77.413 35.669615729077485 139.74699051333369 74.742</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7e1194c7-bf41-4478-bc87-4abbe47b91e8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7e1194c7-bf41-4478-bc87-4abbe47b91e8_0">
											<gml:posList>35.669658400814015 139.74699152781335 77.413 35.66966412947976 139.7469984254953 77.413 35.66966412947976 139.7469984254953 74.742 35.669658400814015 139.74699152781335 74.742 35.669658400814015 139.74699152781335 77.413</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bab332f1-c643-4b80-bb52-8cb181c67f2b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bab332f1-c643-4b80-bb52-8cb181c67f2b_0">
											<gml:posList>35.66964999832692 139.74698917298346 77.413 35.669644035683994 139.74698280577098 77.413 35.6696290609469 139.74700386482652 77.413 35.66963502358874 139.74701023203937 77.413 35.66964999832692 139.74698917298346 77.413</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-df7589b6-cb75-4419-925d-da58d04bc6de">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-df7589b6-cb75-4419-925d-da58d04bc6de_0">
											<gml:posList>35.66964999832692 139.74698917298346 74.742 35.66964999832692 139.74698917298346 77.413 35.66963502358874 139.74701023203937 77.413 35.66963502358874 139.74701023203937 74.742 35.66964999832692 139.74698917298346 74.742</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6d79f15a-1212-4c68-a52e-99dd44b3ca3f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6d79f15a-1212-4c68-a52e-99dd44b3ca3f_0">
											<gml:posList>35.6697359761974 139.74699599529842 72.582 35.6697359761974 139.74699599529842 74.896 35.66974532207508 139.74700666688366 74.896 35.66974532207508 139.74700666688366 72.582 35.6697359761974 139.74699599529842 72.582</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-15255fc5-c281-4207-89dc-5d6522146b37">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-15255fc5-c281-4207-89dc-5d6522146b37_0">
											<gml:posList>35.669658400814015 139.74699152781335 74.742 35.669642064504025 139.7470118924289 74.742 35.669642064504025 139.7470118924289 77.413 35.669658400814015 139.74699152781335 77.413 35.669658400814015 139.74699152781335 74.742</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3c3f3950-5e1e-4c54-987d-3527ce15c0e1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3c3f3950-5e1e-4c54-987d-3527ce15c0e1_0">
											<gml:posList>35.6697359761974 139.74699599529842 72.582 35.66972528697909 139.74701005753664 72.582 35.66972528697909 139.74701005753664 74.896 35.6697359761974 139.74699599529842 74.896 35.6697359761974 139.74699599529842 72.582</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-53dba592-296e-49af-b236-a7a042d072cc">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-53dba592-296e-49af-b236-a7a042d072cc_0">
											<gml:posList>35.669658400814015 139.74699152781335 77.413 35.669642064504025 139.7470118924289 77.413 35.669647802182354 139.7470187901012 77.413 35.66966412947976 139.7469984254953 77.413 35.669658400814015 139.74699152781335 77.413</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bab222d0-4eee-4c45-83e7-599fed0055c3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bab222d0-4eee-4c45-83e7-599fed0055c3_0">
											<gml:posList>35.6696290609469 139.74700386482652 74.742 35.66963502358874 139.74701023203937 74.742 35.66963502358874 139.74701023203937 77.413 35.6696290609469 139.74700386482652 77.413 35.6696290609469 139.74700386482652 74.742</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ea9ad91f-574e-4aab-a666-1d14394fa8ec">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ea9ad91f-574e-4aab-a666-1d14394fa8ec_0">
											<gml:posList>35.6696702720796 139.7470043506703 77.413 35.669676451280424 139.74701103799202 77.413 35.669676451280424 139.74701103799202 74.742 35.6696702720796 139.7470043506703 74.742 35.6696702720796 139.7470043506703 77.413</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-761360ed-3ce3-4fd7-8f43-83f19bc8882e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-761360ed-3ce3-4fd7-8f43-83f19bc8882e_0">
											<gml:posList>35.6697359761974 139.74699599529842 74.896 35.66972528697909 139.74701005753664 74.896 35.66973463285555 139.7470207291221 74.896 35.66974532207508 139.74700666688366 74.896 35.6697359761974 139.74699599529842 74.896</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-36a54b39-6a9a-47f2-891a-ba73f31314fa">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-36a54b39-6a9a-47f2-891a-ba73f31314fa_0">
											<gml:posList>35.669647802182354 139.7470187901012 77.413 35.669647802182354 139.7470187901012 74.742 35.66966412947976 139.7469984254953 74.742 35.66966412947976 139.7469984254953 77.413 35.669647802182354 139.7470187901012 77.413</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5cb21b47-bf98-4bb9-8c29-999423334b33">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5cb21b47-bf98-4bb9-8c29-999423334b33_0">
											<gml:posList>35.66973463285555 139.7470207291221 72.582 35.66974532207508 139.74700666688366 72.582 35.66974532207508 139.74700666688366 74.896 35.66973463285555 139.7470207291221 74.896 35.66973463285555 139.7470207291221 72.582</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ff162ff5-ca8a-4ecd-b5c6-ca2dde0bcb1a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ff162ff5-ca8a-4ecd-b5c6-ca2dde0bcb1a_0">
											<gml:posList>35.6696702720796 139.7470043506703 74.742 35.669656134586 139.7470239728266 74.742 35.669656134586 139.7470239728266 77.413 35.6696702720796 139.7470043506703 77.413 35.6696702720796 139.7470043506703 74.742</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-dbc010ac-01fc-467f-a188-bce64c7f0774">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-dbc010ac-01fc-467f-a188-bce64c7f0774_0">
											<gml:posList>35.669642064504025 139.7470118924289 74.742 35.669647802182354 139.7470187901012 74.742 35.669647802182354 139.7470187901012 77.413 35.669642064504025 139.7470118924289 77.413 35.669642064504025 139.7470118924289 74.742</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4642997d-b71e-4edd-932b-6393add77c58">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4642997d-b71e-4edd-932b-6393add77c58_0">
											<gml:posList>35.66972528697909 139.74701005753664 74.896 35.66972528697909 139.74701005753664 72.582 35.66973463285555 139.7470207291221 72.582 35.66973463285555 139.7470207291221 74.896 35.66972528697909 139.74701005753664 74.896</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-addf40b5-d89c-4334-b8b6-5c1c8dc208de">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-addf40b5-d89c-4334-b8b6-5c1c8dc208de_0">
											<gml:posList>35.6696702720796 139.7470043506703 77.413 35.669656134586 139.7470239728266 77.413 35.669662313777835 139.74703064910256 77.413 35.669676451280424 139.74701103799202 77.413 35.6696702720796 139.7470043506703 77.413</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ccb602d5-489e-4cb1-b52c-042b4d8d36ce">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ccb602d5-489e-4cb1-b52c-042b4d8d36ce_0">
											<gml:posList>35.669662313777835 139.74703064910256 77.413 35.669662313777835 139.74703064910256 74.742 35.669676451280424 139.74701103799202 74.742 35.669676451280424 139.74701103799202 77.413 35.669662313777835 139.74703064910256 77.413</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c0fa0393-efa4-4bd6-92fd-533e8041c39c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c0fa0393-efa4-4bd6-92fd-533e8041c39c_0">
											<gml:posList>35.669656134586 139.7470239728266 74.742 35.669662313777835 139.74703064910256 74.742 35.669662313777835 139.74703064910256 77.413 35.669656134586 139.7470239728266 77.413 35.669656134586 139.7470239728266 74.742</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f6bfa7fe-8185-4325-9ef0-dad01554c074">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f6bfa7fe-8185-4325-9ef0-dad01554c074_0">
											<gml:posList>35.66984461829438 139.7469828438123 66.889 35.669771320188325 139.74708564114448 66.889 35.669771320188325 139.74708564114448 71.5 35.66984461829438 139.7469828438123 71.5 35.66984461829438 139.7469828438123 66.889</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-dfe746d7-9fe2-4954-9864-3f805536e3c2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-dfe746d7-9fe2-4954-9864-3f805536e3c2_0">
											<gml:posList>35.66986895602421 139.74700889765506 71.5 35.66984461829438 139.7469828438123 71.5 35.669771320188325 139.74708564114448 71.5 35.66979565790412 139.7471117060409 71.5 35.66986895602421 139.74700889765506 71.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4828e071-5c21-4e28-bd04-21bcd0bac7eb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4828e071-5c21-4e28-bd04-21bcd0bac7eb_0">
											<gml:posList>35.66979565790412 139.7471117060409 66.889 35.66986895602421 139.74700889765506 66.889 35.66986895602421 139.74700889765506 71.5 35.66979565790412 139.7471117060409 71.5 35.66979565790412 139.7471117060409 66.889</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7a9dbd70-9f4a-4815-9fee-6ab7f52b0215">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7a9dbd70-9f4a-4815-9fee-6ab7f52b0215_0">
											<gml:posList>35.66975833205108 139.74708654985577 68.911 35.66975833205108 139.74708654985577 66.889 35.66975262296642 139.74709439878012 66.889 35.66975262296642 139.74709439878012 68.911 35.66975833205108 139.74708654985577 68.911</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7af19806-7afc-4b88-aff1-bac0cde67993">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7af19806-7afc-4b88-aff1-bac0cde67993_0">
											<gml:posList>35.669771320188325 139.74708564114448 66.889 35.66979565790412 139.7471117060409 66.889 35.66979565790412 139.7471117060409 71.5 35.669771320188325 139.74708564114448 71.5 35.669771320188325 139.74708564114448 66.889</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b2735098-8c41-4ddc-a9ce-e76061a1ff2a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b2735098-8c41-4ddc-a9ce-e76061a1ff2a_0">
											<gml:posList>35.66980279552089 139.7471351273143 66.889 35.66975833205108 139.74708654985577 66.889 35.66975833205108 139.74708654985577 68.911 35.66980279552089 139.7471351273143 68.911 35.66980279552089 139.7471351273143 66.889</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5d7c53e8-5446-4982-95ed-1f0836ccc8e5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5d7c53e8-5446-4982-95ed-1f0836ccc8e5_0">
											<gml:posList>35.66980279552089 139.7471351273143 68.911 35.66975833205108 139.74708654985577 68.911 35.66975262296642 139.74709439878012 68.911 35.66979708643309 139.7471429762396 68.911 35.66980279552089 139.7471351273143 68.911</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-924eb6f6-a214-45d6-b68e-8675ed8df780">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-924eb6f6-a214-45d6-b68e-8675ed8df780_0">
											<gml:posList>35.66975262296642 139.74709439878012 66.889 35.66979708643309 139.7471429762396 66.889 35.66979708643309 139.7471429762396 68.911 35.66975262296642 139.74709439878012 68.911 35.66975262296642 139.74709439878012 66.889</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ba339d25-fb3c-4db5-b51e-57cbd5183aed">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ba339d25-fb3c-4db5-b51e-57cbd5183aed_0">
											<gml:posList>35.66970425091265 139.74712606493767 71.5 35.66969933449546 139.74713316186248 71.5 35.66969933449546 139.74713316186248 73.92 35.66970425091265 139.74712606493767 73.92 35.66970425091265 139.74712606493767 71.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ff32192e-df04-4c1d-abc4-229eca0e2209">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ff32192e-df04-4c1d-abc4-229eca0e2209_0">
											<gml:posList>35.66972200315313 139.74714452609228 73.92 35.66972200315313 139.74714452609228 71.5 35.66970425091265 139.74712606493767 71.5 35.66970425091265 139.74712606493767 73.92 35.66972200315313 139.74714452609228 73.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6a660340-2dd5-46a0-8373-92b4e0e51eca">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6a660340-2dd5-46a0-8373-92b4e0e51eca_0">
											<gml:posList>35.66971708673487 139.74715162301752 73.92 35.66972200315313 139.74714452609228 73.92 35.66970425091265 139.74712606493767 73.92 35.66969933449546 139.74713316186248 73.92 35.66971708673487 139.74715162301752 73.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-77c11b72-0d4e-4588-8e6a-1bcd133e38ba">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-77c11b72-0d4e-4588-8e6a-1bcd133e38ba_0">
											<gml:posList>35.66980279552089 139.7471351273143 68.911 35.66979708643309 139.7471429762396 68.911 35.66979708643309 139.7471429762396 66.889 35.66980279552089 139.7471351273143 66.889 35.66980279552089 139.7471351273143 68.911</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cdbacb09-6487-4d32-b626-d1b4c98c2bdd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cdbacb09-6487-4d32-b626-d1b4c98c2bdd_0">
											<gml:posList>35.669762514993565 139.74713770019267 66.889 35.669762514993565 139.74713770019267 71.254 35.6697666826002 139.74714225778285 71.254 35.6697666826002 139.74714225778285 66.889 35.669762514993565 139.74713770019267 66.889</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-256b656e-0a27-4e1a-ba93-10d5fa6f7ab5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-256b656e-0a27-4e1a-ba93-10d5fa6f7ab5_0">
											<gml:posList>35.66977448252431 139.74713392058092 66.889 35.6697657034486 139.74714693136764 66.889 35.6697657034486 139.74714693136764 68.15 35.66977448252431 139.74713392058092 68.15 35.66977448252431 139.74713392058092 66.889</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6b792dc5-e30b-43ba-9d7b-c0fce3060717">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6b792dc5-e30b-43ba-9d7b-c0fce3060717_0">
											<gml:posList>35.669762514993565 139.74713770019267 66.889 35.66975840877525 139.74714334920213 66.889 35.66975840877525 139.74714334920213 71.254 35.669762514993565 139.74713770019267 71.254 35.669762514993565 139.74713770019267 66.889</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a6c33314-4c43-4a8f-a240-c35c4b38edb6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a6c33314-4c43-4a8f-a240-c35c4b38edb6_0">
											<gml:posList>35.66975840877525 139.74714334920213 66.889 35.66975420509004 139.74713875851262 66.889 35.66975420509004 139.74713875851262 71.254 35.66975840877525 139.74714334920213 71.254 35.66975840877525 139.74714334920213 66.889</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f72dbd85-d2bc-463d-80e9-c688082a54b1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f72dbd85-d2bc-463d-80e9-c688082a54b1_0">
											<gml:posList>35.66975420509004 139.74713875851262 66.889 35.66974992778483 139.74714465072117 66.889 35.66974992778483 139.74714465072117 71.254 35.66975420509004 139.74713875851262 71.254 35.66975420509004 139.74713875851262 66.889</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3598cc8f-9090-4adf-b5bc-6b09c00793d3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3598cc8f-9090-4adf-b5bc-6b09c00793d3_0">
											<gml:posList>35.66971708673487 139.74715162301752 73.92 35.66969933449546 139.74713316186248 73.92 35.66969933449546 139.74713316186248 71.5 35.66971708673487 139.74715162301752 71.5 35.66971708673487 139.74715162301752 73.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c876dab7-051b-4845-80fd-12da8d5731d7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c876dab7-051b-4845-80fd-12da8d5731d7_0">
											<gml:posList>35.66977448252431 139.74713392058092 66.889 35.66977448252431 139.74713392058092 68.15 35.66979442634774 139.7471541246941 68.15 35.66979442634774 139.7471541246941 66.889 35.66977448252431 139.74713392058092 66.889</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b60d5580-d799-4ba9-a916-5f7ae99d04a2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b60d5580-d799-4ba9-a916-5f7ae99d04a2_0">
											<gml:posList>35.66975840877525 139.74714334920213 71.254 35.66975420509004 139.74713875851262 71.254 35.66974992778483 139.74714465072117 71.254 35.66975829005442 139.74715378796455 71.254 35.6697666826002 139.74714225778285 71.254 35.669762514993565 139.74713770019267 71.254 35.66975840877525 139.74714334920213 71.254</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-83a743c6-644f-43f3-9ae1-eee16c24190f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-83a743c6-644f-43f3-9ae1-eee16c24190f_0">
											<gml:posList>35.66975829005442 139.74715378796455 66.889 35.6697666826002 139.74714225778285 66.889 35.6697666826002 139.74714225778285 71.254 35.66975829005442 139.74715378796455 71.254 35.66975829005442 139.74715378796455 66.889</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d7d5eda5-ea5f-48b6-8456-2c0b2b3f8c6e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d7d5eda5-ea5f-48b6-8456-2c0b2b3f8c6e_0">
											<gml:posList>35.66971708673487 139.74715162301752 73.92 35.66971708673487 139.74715162301752 71.5 35.66972200315313 139.74714452609228 71.5 35.66972200315313 139.74714452609228 73.92 35.66971708673487 139.74715162301752 73.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4da1eb22-5071-4eb0-88c8-365b8330c68c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4da1eb22-5071-4eb0-88c8-365b8330c68c_0">
											<gml:posList>35.66974992778483 139.74714465072117 66.889 35.66975829005442 139.74715378796455 66.889 35.66975829005442 139.74715378796455 71.254 35.66974992778483 139.74714465072117 71.254 35.66974992778483 139.74714465072117 66.889</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7f5ee87a-03b6-4340-8242-4072d9dd6f58">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7f5ee87a-03b6-4340-8242-4072d9dd6f58_0">
											<gml:posList>35.669691096369725 139.74714634879422 73.92 35.66969674358685 139.74715280473097 73.92 35.66969674358685 139.74715280473097 71.5 35.669691096369725 139.74714634879422 71.5 35.669691096369725 139.74714634879422 73.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f5df8b5f-9eaf-46aa-9e7f-7a6463a1cf96">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f5df8b5f-9eaf-46aa-9e7f-7a6463a1cf96_0">
											<gml:posList>35.66978534058189 139.74716682651845 68.15 35.66979442634774 139.7471541246941 68.15 35.66977448252431 139.74713392058092 68.15 35.6697657034486 139.74714693136764 68.15 35.66978534058189 139.74716682651845 68.15</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-72fa4ccc-57e9-4e34-8635-6a15265ae58b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-72fa4ccc-57e9-4e34-8635-6a15265ae58b_0">
											<gml:posList>35.6697657034486 139.74714693136764 66.889 35.66978534058189 139.74716682651845 66.889 35.66978534058189 139.74716682651845 68.15 35.6697657034486 139.74714693136764 68.15 35.6697657034486 139.74714693136764 66.889</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a99a6660-3367-41ac-973c-120329990bc5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a99a6660-3367-41ac-973c-120329990bc5_0">
											<gml:posList>35.669691096369725 139.74714634879422 73.92 35.669691096369725 139.74714634879422 71.5 35.66967485086646 139.74716768535134 71.5 35.66967485086646 139.74716768535134 73.92 35.669691096369725 139.74714634879422 73.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-924ea48e-7b61-4279-ab6d-f67d939f0c78">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-924ea48e-7b61-4279-ab6d-f67d939f0c78_0">
											<gml:posList>35.669691096369725 139.74714634879422 73.92 35.66967485086646 139.74716768535134 73.92 35.66968049808246 139.7471741412883 73.92 35.66969674358685 139.74715280473097 73.92 35.669691096369725 139.74714634879422 73.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4dd7122c-9326-4073-b359-4b9f9b76bad7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4dd7122c-9326-4073-b359-4b9f9b76bad7_0">
											<gml:posList>35.66978534058189 139.74716682651845 66.889 35.66979442634774 139.7471541246941 66.889 35.66979442634774 139.7471541246941 68.15 35.66978534058189 139.74716682651845 68.15 35.66978534058189 139.74716682651845 66.889</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3f8c3e89-fcbc-4f84-ac3e-b36a816e6994">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3f8c3e89-fcbc-4f84-ac3e-b36a816e6994_0">
											<gml:posList>35.66973269368338 139.7471574607128 71.5 35.66972796667907 139.74716473417337 71.5 35.66972796667907 139.74716473417337 73.92 35.66973269368338 139.7471574607128 73.92 35.66973269368338 139.7471574607128 71.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2915617e-8422-44e2-940f-77df166e1577">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2915617e-8422-44e2-940f-77df166e1577_0">
											<gml:posList>35.66968049808246 139.7471741412883 71.5 35.66969674358685 139.74715280473097 71.5 35.66969674358685 139.74715280473097 73.92 35.66968049808246 139.7471741412883 73.92 35.66968049808246 139.7471741412883 71.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ae8cb017-41c7-49bd-a980-ee25ca5f2899">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ae8cb017-41c7-49bd-a980-ee25ca5f2899_0">
											<gml:posList>35.66975082395009 139.74717515928873 71.5 35.66973269368338 139.7471574607128 71.5 35.66973269368338 139.7471574607128 73.92 35.66975082395009 139.74717515928873 73.92 35.66975082395009 139.74717515928873 71.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d158abc9-836f-46f1-bb55-7409b19aa355">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d158abc9-836f-46f1-bb55-7409b19aa355_0">
											<gml:posList>35.66974609693682 139.7471824217037 73.92 35.66975082395009 139.74717515928873 73.92 35.66973269368338 139.7471574607128 73.92 35.66972796667907 139.74716473417337 73.92 35.66974609693682 139.7471824217037 73.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-eb0d5cef-f649-41a6-beca-dcbae1fb3d10">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-eb0d5cef-f649-41a6-beca-dcbae1fb3d10_0">
											<gml:posList>35.66967485086646 139.74716768535134 73.92 35.66967485086646 139.74716768535134 71.5 35.66968049808246 139.7471741412883 71.5 35.66968049808246 139.7471741412883 73.92 35.66967485086646 139.74716768535134 73.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-39e733b4-13be-485e-b6b7-5c96d073cc46">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-39e733b4-13be-485e-b6b7-5c96d073cc46_0">
											<gml:posList>35.66967878708698 139.7471763965442 71.5 35.66967313987111 139.74716994060725 71.5 35.66967313987111 139.74716994060725 73.92 35.66967878708698 139.7471763965442 73.92 35.66967878708698 139.7471763965442 71.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d6d1cd68-5316-44cc-b30d-6d1ba168093e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d6d1cd68-5316-44cc-b30d-6d1ba168093e_0">
											<gml:posList>35.66974609693682 139.7471824217037 73.92 35.66972796667907 139.74716473417337 73.92 35.66972796667907 139.74716473417337 71.5 35.66974609693682 139.7471824217037 71.5 35.66974609693682 139.7471824217037 73.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-803d98ca-7813-487c-a0f4-59af12a16ba4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-803d98ca-7813-487c-a0f4-59af12a16ba4_0">
											<gml:posList>35.66974609693682 139.7471824217037 71.5 35.66975082395009 139.74717515928873 71.5 35.66975082395009 139.74717515928873 73.92 35.66974609693682 139.7471824217037 73.92 35.66974609693682 139.7471824217037 71.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fa38502b-741f-4c8d-8276-bbe418af6836">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fa38502b-741f-4c8d-8276-bbe418af6836_0">
											<gml:posList>35.66967313987111 139.74716994060725 73.92 35.66967313987111 139.74716994060725 71.5 35.669656669233824 139.74719157564303 71.5 35.669656669233824 139.74719157564303 73.92 35.66967313987111 139.74716994060725 73.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b1472fee-2382-4109-8b0f-e346bec40d85">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b1472fee-2382-4109-8b0f-e346bec40d85_0">
											<gml:posList>35.66967878708698 139.7471763965442 73.92 35.66967313987111 139.74716994060725 73.92 35.669656669233824 139.74719157564303 73.92 35.66966231644854 139.74719803158018 73.92 35.66967878708698 139.7471763965442 73.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-796b14c2-7e5b-4db9-b6ee-d33ae0d6b02d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-796b14c2-7e5b-4db9-b6ee-d33ae0d6b02d_0">
											<gml:posList>35.66967878708698 139.7471763965442 73.92 35.66966231644854 139.74719803158018 73.92 35.66966231644854 139.74719803158018 71.5 35.66967878708698 139.7471763965442 71.5 35.66967878708698 139.7471763965442 73.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-031a5e1b-7234-4bb8-bfe3-14b1a5d8f508">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-031a5e1b-7234-4bb8-bfe3-14b1a5d8f508_0">
											<gml:posList>35.669656669233824 139.74719157564303 73.92 35.669656669233824 139.74719157564303 71.5 35.66966231644854 139.74719803158018 71.5 35.66966231644854 139.74719803158018 73.92 35.669656669233824 139.74719157564303 73.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bfb221da-016e-4b10-89af-76a4b0ce0b7c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bfb221da-016e-4b10-89af-76a4b0ce0b7c_0">
											<gml:posList>35.66974656477029 139.74720639139602 71.5 35.66974030467808 139.7472000134331 71.5 35.66974030467808 139.7472000134331 73.92 35.66974656477029 139.74720639139602 73.92 35.66974656477029 139.74720639139602 71.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b7cad523-577b-4142-aae0-7fbc1282958d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b7cad523-577b-4142-aae0-7fbc1282958d_0">
											<gml:posList>35.66974030467808 139.7472000134331 71.5 35.6697251325255 139.7472223650873 71.5 35.6697251325255 139.7472223650873 73.92 35.66974030467808 139.7472000134331 73.92 35.66974030467808 139.7472000134331 71.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c962a593-eb10-41c7-bf68-634e75d90db9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c962a593-eb10-41c7-bf68-634e75d90db9_0">
											<gml:posList>35.66974656477029 139.74720639139602 73.92 35.66974030467808 139.7472000134331 73.92 35.6697251325255 139.7472223650873 73.92 35.669731401638174 139.74722875408727 73.92 35.66974656477029 139.74720639139602 73.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-15763335-d54d-4778-af01-75a972fa7e6e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-15763335-d54d-4778-af01-75a972fa7e6e_0">
											<gml:posList>35.66974656477029 139.74720639139602 73.92 35.669731401638174 139.74722875408727 73.92 35.669731401638174 139.74722875408727 71.5 35.66974656477029 139.74720639139602 71.5 35.66974656477029 139.74720639139602 73.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6def423c-bad2-4198-9db5-646dcae7f8d5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6def423c-bad2-4198-9db5-646dcae7f8d5_0">
											<gml:posList>35.66965293568152 139.74722677271967 73.92 35.66965834744839 139.74721910087237 73.92 35.66965834744839 139.74721910087237 71.5 35.66965293568152 139.74722677271967 71.5 35.66965293568152 139.74722677271967 73.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-71dc61a8-fc4a-41c8-bc54-294213d7866b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-71dc61a8-fc4a-41c8-bc54-294213d7866b_0">
											<gml:posList>35.6697251325255 139.7472223650873 71.5 35.669731401638174 139.74722875408727 71.5 35.669731401638174 139.74722875408727 73.92 35.6697251325255 139.7472223650873 73.92 35.6697251325255 139.7472223650873 71.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-054aa163-1d88-46bb-816c-9cc9532912ad">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-054aa163-1d88-46bb-816c-9cc9532912ad_0">
											<gml:posList>35.66967560380139 139.74723739687707 71.5 35.66965834744839 139.74721910087237 71.5 35.66965834744839 139.74721910087237 73.92 35.66967560380139 139.74723739687707 73.92 35.66967560380139 139.74723739687707 71.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2d66d4f2-991d-4463-9913-36050e5e807e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2d66d4f2-991d-4463-9913-36050e5e807e_0">
											<gml:posList>35.66965293568152 139.74722677271967 73.92 35.66967019202547 139.74724505767864 73.92 35.66967560380139 139.74723739687707 73.92 35.66965834744839 139.74721910087237 73.92 35.66965293568152 139.74722677271967 73.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b70c06b6-139e-42c7-aead-48d962edbe64">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b70c06b6-139e-42c7-aead-48d962edbe64_0">
											<gml:posList>35.66972309693233 139.7472244770919 71.5 35.66970750913294 139.74724541527354 71.5 35.66970750913294 139.74724541527354 73.92 35.66972309693233 139.7472244770919 73.92 35.66972309693233 139.7472244770919 71.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b58cb4cf-07dc-4660-9f3f-8218812a9a76">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b58cb4cf-07dc-4660-9f3f-8218812a9a76_0">
											<gml:posList>35.66965293568152 139.74722677271967 71.5 35.66967019202547 139.74724505767864 71.5 35.66967019202547 139.74724505767864 73.92 35.66965293568152 139.74722677271967 73.92 35.66965293568152 139.74722677271967 71.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-16d13df3-074d-4c74-b9c7-9c1eb9537905">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-16d13df3-074d-4c74-b9c7-9c1eb9537905_0">
											<gml:posList>35.66972309693233 139.7472244770919 73.92 35.66970750913294 139.74724541527354 73.92 35.66971366142134 139.74725230147686 73.92 35.669729249214 139.7472313522488 73.92 35.66972309693233 139.7472244770919 73.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a7888e09-756b-4da7-bbba-c0e318751264">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a7888e09-756b-4da7-bbba-c0e318751264_0">
											<gml:posList>35.66971366142134 139.74725230147686 71.5 35.669729249214 139.7472313522488 71.5 35.669729249214 139.7472313522488 73.92 35.66971366142134 139.74725230147686 73.92 35.66971366142134 139.74725230147686 71.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5b583ee1-611b-45f6-a6ba-929d4af7c26c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5b583ee1-611b-45f6-a6ba-929d4af7c26c_0">
											<gml:posList>35.669678733972944 139.7472407625958 71.5 35.66967293493828 139.74724888775202 71.5 35.66967293493828 139.74724888775202 73.92 35.669678733972944 139.7472407625958 73.92 35.669678733972944 139.7472407625958 71.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ac699e98-1084-42bc-ac19-b1f614a65b68">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ac699e98-1084-42bc-ac19-b1f614a65b68_0">
											<gml:posList>35.66970750913294 139.74724541527354 73.92 35.66970750913294 139.74724541527354 71.5 35.66971366142134 139.74725230147686 71.5 35.66971366142134 139.74725230147686 73.92 35.66970750913294 139.74724541527354 73.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-de27eda7-43bd-4841-a2bd-167ef1bfb109">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-de27eda7-43bd-4841-a2bd-167ef1bfb109_0">
											<gml:posList>35.669696549749986 139.74725986437934 71.5 35.669678733972944 139.7472407625958 71.5 35.669678733972944 139.7472407625958 73.92 35.669696549749986 139.74725986437934 73.92 35.669696549749986 139.74725986437934 71.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0e189a28-75d0-45c1-a6f6-6d9102fe1191">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0e189a28-75d0-45c1-a6f6-6d9102fe1191_0">
											<gml:posList>35.66969075070616 139.74726797848987 73.92 35.669696549749986 139.74725986437934 73.92 35.669678733972944 139.7472407625958 73.92 35.66967293493828 139.74724888775202 73.92 35.66969075070616 139.74726797848987 73.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e29fd9a3-57b8-445f-b2e5-3d21bf54fb25">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e29fd9a3-57b8-445f-b2e5-3d21bf54fb25_0">
											<gml:posList>35.66969075070616 139.74726797848987 71.5 35.66969075070616 139.74726797848987 73.92 35.66967293493828 139.74724888775202 73.92 35.66967293493828 139.74724888775202 71.5 35.66969075070616 139.74726797848987 71.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-76a969db-9e4b-4ca8-a596-6eb5925bce7c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-76a969db-9e4b-4ca8-a596-6eb5925bce7c_0">
											<gml:posList>35.66969075070616 139.74726797848987 71.5 35.669696549749986 139.74725986437934 71.5 35.669696549749986 139.74725986437934 73.92 35.66969075070616 139.74726797848987 73.92 35.66969075070616 139.74726797848987 71.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-71bcbf7f-054e-4efd-baf2-48abe988bad3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-71bcbf7f-054e-4efd-baf2-48abe988bad3_0">
											<gml:posList>35.66984879587808 139.74691334775162 69.293 35.669838900289854 139.74690286454123 69.293 35.669838900289854 139.74690286454123 66.889 35.66984879587808 139.74691334775162 66.889 35.66984879587808 139.74691334775162 69.293</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b6706118-6f1b-42f4-be87-2ef9f323b379">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b6706118-6f1b-42f4-be87-2ef9f323b379_0">
											<gml:posList>35.66984879587808 139.74691334775162 69.293 35.66985400953688 139.74690597432502 69.293 35.66984411394009 139.74689548006867 69.293 35.669838900289854 139.74690286454123 69.293 35.66984879587808 139.74691334775162 69.293</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9ee7c22a-af45-4b82-b1a0-d9e075981810">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9ee7c22a-af45-4b82-b1a0-d9e075981810_0">
											<gml:posList>35.66985400953688 139.74690597432502 69.293 35.66985400953688 139.74690597432502 66.889 35.66984411394009 139.74689548006867 66.889 35.66984411394009 139.74689548006867 69.293 35.66985400953688 139.74690597432502 69.293</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e2d534f8-76bf-45db-a2d2-a269a06ea92d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e2d534f8-76bf-45db-a2d2-a269a06ea92d_0">
											<gml:posList>35.66985299018654 139.74685464379078 66.889 35.66984769551843 139.7468621719546 66.889 35.66984769551843 139.7468621719546 68.472 35.66985299018654 139.74685464379078 68.472 35.66985299018654 139.74685464379078 66.889</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5fbd35c7-9b07-4605-bca9-88edbea1ead9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5fbd35c7-9b07-4605-bca9-88edbea1ead9_0">
											<gml:posList>35.66984879587808 139.74691334775162 66.889 35.66985400953688 139.74690597432502 66.889 35.66985400953688 139.74690597432502 69.293 35.66984879587808 139.74691334775162 69.293 35.66984879587808 139.74691334775162 66.889</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-643d69c8-ebb2-47e9-862d-c6aa549521af">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-643d69c8-ebb2-47e9-862d-c6aa549521af_0">
											<gml:posList>35.66984880958793 139.74670662939607 69.468 35.66985427551503 139.746699112083 69.468 35.66985427551503 139.746699112083 66.889 35.66984880958793 139.74670662939607 66.889 35.66984880958793 139.74670662939607 69.468</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-81847c9b-e9cc-483f-8969-acff4a9fff79">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-81847c9b-e9cc-483f-8969-acff4a9fff79_0">
											<gml:posList>35.669859048215336 139.74671780812278 69.468 35.66984880958793 139.74670662939607 69.468 35.66984880958793 139.74670662939607 66.889 35.669859048215336 139.74671780812278 66.889 35.669859048215336 139.74671780812278 69.468</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d3f7ed13-bcbf-434f-bdbf-ae392258bce5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d3f7ed13-bcbf-434f-bdbf-ae392258bce5_0">
											<gml:posList>35.66986275987681 139.7468780843123 66.889 35.66986275987681 139.7468780843123 68.472 35.66984769551843 139.7468621719546 68.472 35.66984769551843 139.7468621719546 66.889 35.66986275987681 139.7468780843123 66.889</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-db783bd6-cc2f-48cb-a48f-a29b070a7f6b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-db783bd6-cc2f-48cb-a48f-a29b070a7f6b_0">
											<gml:posList>35.66984461829438 139.7469828438123 66.889 35.66984461829438 139.7469828438123 71.5 35.66986895602421 139.74700889765506 71.5 35.66986895602421 139.74700889765506 66.889 35.66984461829438 139.7469828438123 66.889</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d1cd53ea-c6aa-4799-be46-4775ff5a72de">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d1cd53ea-c6aa-4799-be46-4775ff5a72de_0">
											<gml:posList>35.669859048215336 139.74671780812278 69.468 35.66986451414313 139.74671029080955 69.468 35.66985427551503 139.746699112083 69.468 35.66984880958793 139.74670662939607 69.468 35.669859048215336 139.74671780812278 69.468</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b92f35b4-c9fb-42b8-a1c8-5e518db8e1a6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b92f35b4-c9fb-42b8-a1c8-5e518db8e1a6_0">
											<gml:posList>35.66986275987681 139.7468780843123 68.472 35.66986815377619 139.74687066650299 68.472 35.66985299018654 139.74685464379078 68.472 35.66984769551843 139.7468621719546 68.472 35.66986275987681 139.7468780843123 68.472</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c338890d-8b5e-4420-a1ab-639c7142c9ca">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c338890d-8b5e-4420-a1ab-639c7142c9ca_0">
											<gml:posList>35.66986451414313 139.74671029080955 66.889 35.66985427551503 139.746699112083 66.889 35.66985427551503 139.746699112083 69.468 35.66986451414313 139.74671029080955 69.468 35.66986451414313 139.74671029080955 66.889</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d5353449-452e-4f2e-a896-a97f4d01ede3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d5353449-452e-4f2e-a896-a97f4d01ede3_0">
											<gml:posList>35.66986815377619 139.74687066650299 66.889 35.66985299018654 139.74685464379078 66.889 35.66985299018654 139.74685464379078 68.472 35.66986815377619 139.74687066650299 68.472 35.66986815377619 139.74687066650299 66.889</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-da52093e-f5a0-456c-a9a1-b6c538410ab3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-da52093e-f5a0-456c-a9a1-b6c538410ab3_0">
											<gml:posList>35.669859048215336 139.74671780812278 66.889 35.66986451414313 139.74671029080955 66.889 35.66986451414313 139.74671029080955 69.468 35.669859048215336 139.74671780812278 69.468 35.669859048215336 139.74671780812278 66.889</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c91bb9fc-c484-4c4b-8e76-31edd9e79857">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c91bb9fc-c484-4c4b-8e76-31edd9e79857_0">
											<gml:posList>35.66986815377619 139.74687066650299 68.472 35.66986275987681 139.7468780843123 68.472 35.66986275987681 139.7468780843123 66.889 35.66986815377619 139.74687066650299 66.889 35.66986815377619 139.74687066650299 68.472</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a967962f-da0a-4398-bc31-adb802d4dc2e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a967962f-da0a-4398-bc31-adb802d4dc2e_0">
											<gml:posList>35.66987661508253 139.74687961583925 66.889 35.669871221182596 139.7468870336487 66.889 35.669871221182596 139.7468870336487 68.472 35.66987661508253 139.74687961583925 68.472 35.66987661508253 139.74687961583925 66.889</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c4c93230-bd6f-4f75-9c70-6211c2167937">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c4c93230-bd6f-4f75-9c70-6211c2167937_0">
											<gml:posList>35.6698756149213 139.7468173716339 72.854 35.669881314910526 139.74680943431804 72.854 35.669881314910526 139.74680943431804 66.889 35.6698756149213 139.7468173716339 66.889 35.6698756149213 139.7468173716339 72.854</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-83041aad-f53f-4ce6-87f9-8b42356c60f3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-83041aad-f53f-4ce6-87f9-8b42356c60f3_0">
											<gml:posList>35.6698756149213 139.7468173716339 66.889 35.66989142825788 139.74683444303093 66.889 35.66989142825788 139.74683444303093 72.854 35.6698756149213 139.7468173716339 72.854 35.6698756149213 139.7468173716339 66.889</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-29819684-2329-46c8-b780-d8a572b56a6f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-29819684-2329-46c8-b780-d8a572b56a6f_0">
											<gml:posList>35.6698756149213 139.7468173716339 72.854 35.66989142825788 139.74683444303093 72.854 35.66989712824822 139.7468265057147 72.854 35.669881314910526 139.74680943431804 72.854 35.6698756149213 139.7468173716339 72.854</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6060e45f-b8db-4073-9841-9a578304bb73">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6060e45f-b8db-4073-9841-9a578304bb73_0">
											<gml:posList>35.669889529246156 139.74665043760564 66.889 35.669884216619074 139.74665804312914 66.889 35.669884216619074 139.74665804312914 69.539 35.669889529246156 139.74665043760564 69.539 35.669889529246156 139.74665043760564 66.889</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cbe8cf52-a22e-4664-b962-f7359f58b895">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cbe8cf52-a22e-4664-b962-f7359f58b895_0">
											<gml:posList>35.66989712824822 139.7468265057147 72.854 35.66989712824822 139.7468265057147 66.889 35.669881314910526 139.74680943431804 66.889 35.669881314910526 139.74680943431804 72.854 35.66989712824822 139.7468265057147 72.854</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d20b6527-9b0c-4751-b883-6a07bdf760c0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d20b6527-9b0c-4751-b883-6a07bdf760c0_0">
											<gml:posList>35.66989310245834 139.74686881697724 66.889 35.66988777175827 139.74687637832133 66.889 35.66988777175827 139.74687637832133 68.472 35.66989310245834 139.74686881697724 68.472 35.66989310245834 139.74686881697724 66.889</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0f73073b-b94e-4628-9b76-ce6131275d53">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0f73073b-b94e-4628-9b76-ce6131275d53_0">
											<gml:posList>35.66989142825788 139.74683444303093 72.854 35.66989142825788 139.74683444303093 66.889 35.66989712824822 139.7468265057147 66.889 35.66989712824822 139.7468265057147 72.854 35.66989142825788 139.74683444303093 72.854</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b5ff33fa-0836-4aba-89c4-a8bb8f227ea8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b5ff33fa-0836-4aba-89c4-a8bb8f227ea8_0">
											<gml:posList>35.66989671218068 139.74662399629915 66.889 35.66989181384461 139.74663112639078 66.889 35.66989181384461 139.74663112639078 68.702 35.66989671218068 139.74662399629915 68.702 35.66989671218068 139.74662399629915 66.889</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-168d0443-3c18-4135-8b20-8403d3530b45">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-168d0443-3c18-4135-8b20-8403d3530b45_0">
											<gml:posList>35.66989936073657 139.74678481497054 66.889 35.669893697161136 139.74679324932933 66.889 35.669893697161136 139.74679324932933 72.854 35.66989936073657 139.74678481497054 72.854 35.66989936073657 139.74678481497054 66.889</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c8566223-7498-4a44-9ffd-c26def2354b3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c8566223-7498-4a44-9ffd-c26def2354b3_0">
											<gml:posList>35.66991067331923 139.74681038574775 72.854 35.669893697161136 139.74679324932933 72.854 35.669893697161136 139.74679324932933 66.889 35.66991067331923 139.74681038574775 66.889 35.66991067331923 139.74681038574775 72.854</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-772dfec9-4c93-4666-9457-89a8a620e8dd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-772dfec9-4c93-4666-9457-89a8a620e8dd_0">
											<gml:posList>35.669871221182596 139.7468870336487 68.472 35.669871221182596 139.7468870336487 66.889 35.66993340900898 139.746952746712 66.889 35.66993340900898 139.746952746712 68.472 35.669871221182596 139.7468870336487 68.472</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cfcbe4f2-3bf7-401c-9940-732cd5c45b2d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cfcbe4f2-3bf7-401c-9940-732cd5c45b2d_0">
											<gml:posList>35.66987661508253 139.74687961583925 68.472 35.669871221182596 139.7468870336487 68.472 35.66993340900898 139.746952746712 68.472 35.66993870369062 139.7469452295923 68.472 35.66987661508253 139.74687961583925 68.472</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cc44999c-5e3c-4362-b2f3-bd45298c1978">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cc44999c-5e3c-4362-b2f3-bd45298c1978_0">
											<gml:posList>35.66990222239159 139.7466153964011 68.702 35.66990742694672 139.7466079235443 68.702 35.66990742694672 139.7466079235443 66.889 35.66990222239159 139.7466153964011 66.889 35.66990222239159 139.7466153964011 68.702</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4c521c78-ba06-4726-9770-9efd06d89be1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4c521c78-ba06-4726-9770-9efd06d89be1_0">
											<gml:posList>35.66991067331923 139.74681038574775 72.854 35.669916345909584 139.74680195137867 72.854 35.66989936073657 139.74678481497054 72.854 35.669893697161136 139.74679324932933 72.854 35.66991067331923 139.74681038574775 72.854</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bdb2f9a3-2f51-4330-95d1-c5400dae5c35">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bdb2f9a3-2f51-4330-95d1-c5400dae5c35_0">
											<gml:posList>35.669884216619074 139.74665804312914 69.539 35.669884216619074 139.74665804312914 66.889 35.669926694372265 139.7467026348941 66.889 35.669926694372265 139.7467026348941 69.539 35.669884216619074 139.74665804312914 69.539</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-528c7dcc-5311-4f82-bfd4-e3ef8923d817">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-528c7dcc-5311-4f82-bfd4-e3ef8923d817_0">
											<gml:posList>35.66987661508253 139.74687961583925 68.472 35.66993870369062 139.7469452295923 68.472 35.66993870369062 139.7469452295923 66.889 35.66987661508253 139.74687961583925 66.889 35.66987661508253 139.74687961583925 68.472</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4655ba9d-3324-4543-bdf8-0965fa2d01f7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4655ba9d-3324-4543-bdf8-0965fa2d01f7_0">
											<gml:posList>35.669916345909584 139.74680195137867 72.854 35.669916345909584 139.74680195137867 66.889 35.66989936073657 139.74678481497054 66.889 35.66989936073657 139.74678481497054 72.854 35.669916345909584 139.74680195137867 72.854</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-11814d07-7290-445a-9265-e2be4685abab">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-11814d07-7290-445a-9265-e2be4685abab_0">
											<gml:posList>35.66993200701008 139.74669504041572 69.539 35.669889529246156 139.74665043760564 69.539 35.669884216619074 139.74665804312914 69.539 35.669926694372265 139.7467026348941 69.539 35.66993200701008 139.74669504041572 69.539</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6139ce17-f783-40a8-8b9a-e29ddf811a04">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6139ce17-f783-40a8-8b9a-e29ddf811a04_0">
											<gml:posList>35.66992860752157 139.74690644622348 68.472 35.66992860752157 139.74690644622348 66.889 35.66989310245834 139.74686881697724 66.889 35.66989310245834 139.74686881697724 68.472 35.66992860752157 139.74690644622348 68.472</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-11e54516-7ba0-42a7-9d05-da4b8d6b26aa">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-11e54516-7ba0-42a7-9d05-da4b8d6b26aa_0">
											<gml:posList>35.66993200701008 139.74669504041572 66.889 35.669889529246156 139.74665043760564 66.889 35.669889529246156 139.74665043760564 69.539 35.66993200701008 139.74669504041572 69.539 35.66993200701008 139.74669504041572 66.889</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2674732d-c24c-469d-beab-963aec4f6d75">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2674732d-c24c-469d-beab-963aec4f6d75_0">
											<gml:posList>35.66991067331923 139.74681038574775 66.889 35.669916345909584 139.74680195137867 66.889 35.669916345909584 139.74680195137867 72.854 35.66991067331923 139.74681038574775 72.854 35.66991067331923 139.74681038574775 66.889</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0eea644c-8cfe-45bb-8e5c-2f06e697bd9e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0eea644c-8cfe-45bb-8e5c-2f06e697bd9e_0">
											<gml:posList>35.66994355510619 139.74693549266303 68.472 35.66994888580993 139.74692793131763 68.472 35.669934010857524 139.74691217337613 68.472 35.66992860752157 139.74690644622348 68.472 35.66989310245834 139.74686881697724 68.472 35.66988777175827 139.74687637832133 68.472 35.66994355510619 139.74693549266303 68.472</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-10d1238f-ba54-4b5a-b3e3-c2c203a94c7b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-10d1238f-ba54-4b5a-b3e3-c2c203a94c7b_0">
											<gml:posList>35.66994536814068 139.74668637680344 66.889 35.66994536814068 139.74668637680344 68.702 35.66989181384461 139.74663112639078 68.702 35.66989181384461 139.74663112639078 66.889 35.66994536814068 139.74668637680344 66.889</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d9894c45-58d5-41ea-9e7c-47dfb4d20947">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d9894c45-58d5-41ea-9e7c-47dfb4d20947_0">
											<gml:posList>35.66994536814068 139.74668637680344 68.702 35.669950266479965 139.7466792467104 68.702 35.66989671218068 139.74662399629915 68.702 35.66989181384461 139.74663112639078 68.702 35.66994536814068 139.74668637680344 68.702</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cb66f0a9-13fc-4596-8380-86d6d98e434a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cb66f0a9-13fc-4596-8380-86d6d98e434a_0">
											<gml:posList>35.66993200701008 139.74669504041572 69.539 35.669926694372265 139.7467026348941 69.539 35.669926694372265 139.7467026348941 66.889 35.66993200701008 139.74669504041572 66.889 35.66993200701008 139.74669504041572 69.539</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0d4f560b-5475-459f-b2b2-55edf29ddb7d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0d4f560b-5475-459f-b2b2-55edf29ddb7d_0">
											<gml:posList>35.66992860752157 139.74690644622348 68.472 35.669934010857524 139.74691217337613 68.472 35.669934010857524 139.74691217337613 72.854 35.66992860752157 139.74690644622348 72.854 35.66992860752157 139.74690644622348 68.472</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4f8934c8-05e8-498d-b44f-b261f3248324">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4f8934c8-05e8-498d-b44f-b261f3248324_0">
											<gml:posList>35.66990222239159 139.7466153964011 68.702 35.669955867507774 139.74667158563935 68.702 35.66996107206635 139.7466641127812 68.702 35.66990742694672 139.7466079235443 68.702 35.66990222239159 139.7466153964011 68.702</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2f750eba-c092-49e0-8e57-ca31239d2ce1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2f750eba-c092-49e0-8e57-ca31239d2ce1_0">
											<gml:posList>35.66996107206635 139.7466641127812 68.702 35.66996107206635 139.7466641127812 66.889 35.66990742694672 139.7466079235443 66.889 35.66990742694672 139.7466079235443 68.702 35.66996107206635 139.7466641127812 68.702</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b25ca281-781d-40bb-959c-3585b060fb2c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b25ca281-781d-40bb-959c-3585b060fb2c_0">
											<gml:posList>35.66992860752157 139.74690644622348 68.472 35.66992860752157 139.74690644622348 72.854 35.669942366506035 139.74688694589594 72.854 35.669942366506035 139.74688694589594 66.889 35.66992860752157 139.74690644622348 66.889 35.66992860752157 139.74690644622348 68.472</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a59d8830-0002-4f17-8647-8de23b19481f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a59d8830-0002-4f17-8647-8de23b19481f_0">
											<gml:posList>35.66993340900898 139.746952746712 66.889 35.66993870369062 139.7469452295923 66.889 35.66993870369062 139.7469452295923 68.472 35.66993340900898 139.746952746712 68.472 35.66993340900898 139.746952746712 66.889</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c8006ff2-c365-4f3e-805c-f9ec9933c5c1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c8006ff2-c365-4f3e-805c-f9ec9933c5c1_0">
											<gml:posList>35.66994776984289 139.74689267304825 72.854 35.669942366506035 139.74688694589594 72.854 35.66992860752157 139.74690644622348 72.854 35.669934010857524 139.74691217337613 72.854 35.66994776984289 139.74689267304825 72.854</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7fa189d3-03cd-437d-9e15-100cd53269fe">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7fa189d3-03cd-437d-9e15-100cd53269fe_0">
											<gml:posList>35.66994776984289 139.74689267304825 66.889 35.66994776984289 139.74689267304825 72.854 35.669934010857524 139.74691217337613 72.854 35.669934010857524 139.74691217337613 68.472 35.669934010857524 139.74691217337613 66.889 35.66994776984289 139.74689267304825 66.889</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5f66a0a6-806a-4ed4-bca7-576bcdba411e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5f66a0a6-806a-4ed4-bca7-576bcdba411e_0">
											<gml:posList>35.66994888580993 139.74692793131763 68.472 35.66994888580993 139.74692793131763 66.889 35.669934010857524 139.74691217337613 66.889 35.669934010857524 139.74691217337613 68.472 35.66994888580993 139.74692793131763 68.472</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-54f05896-cd06-4690-9adc-1b214c366b0d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-54f05896-cd06-4690-9adc-1b214c366b0d_0">
											<gml:posList>35.66994776984289 139.74689267304825 72.854 35.66994776984289 139.74689267304825 66.889 35.669942366506035 139.74688694589594 66.889 35.669942366506035 139.74688694589594 72.854 35.66994776984289 139.74689267304825 72.854</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8eb3c042-c680-4d50-93ab-34db50936492">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8eb3c042-c680-4d50-93ab-34db50936492_0">
											<gml:posList>35.66994888580993 139.74692793131763 68.472 35.66994355510619 139.74693549266303 68.472 35.66994355510619 139.74693549266303 66.889 35.66994888580993 139.74692793131763 66.889 35.66994888580993 139.74692793131763 68.472</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e36ff582-840a-418d-a853-6abc8b340889">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e36ff582-840a-418d-a853-6abc8b340889_0">
											<gml:posList>35.66994536814068 139.74668637680344 66.889 35.669950266479965 139.7466792467104 66.889 35.669950266479965 139.7466792467104 68.702 35.66994536814068 139.74668637680344 68.702 35.66994536814068 139.74668637680344 66.889</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-eb7270ce-80f0-48af-8513-fa35d6d9b9ce">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-eb7270ce-80f0-48af-8513-fa35d6d9b9ce_0">
											<gml:posList>35.66995417213992 139.7466078950748 71.5 35.66995417213992 139.7466078950748 66.889 35.66995135351713 139.7466116096471 66.889 35.66995135351713 139.7466116096471 73.694 35.66996184455353 139.74659777950072 73.694 35.66996184455353 139.74659777950072 71.5 35.66995417213992 139.7466078950748 71.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0391c6aa-2c7c-40d3-a816-5582825be2f6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0391c6aa-2c7c-40d3-a816-5582825be2f6_0">
											<gml:posList>35.66995135351713 139.7466116096471 66.889 35.66996269307645 139.74662452143912 66.889 35.66996269307645 139.74662452143912 73.694 35.66995135351713 139.7466116096471 73.694 35.66995135351713 139.7466116096471 66.889</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-62d08005-14d5-4f61-9056-588616198e4c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-62d08005-14d5-4f61-9056-588616198e4c_0">
											<gml:posList>35.669955867507774 139.74667158563935 66.889 35.66996107206635 139.7466641127812 66.889 35.66996107206635 139.7466641127812 68.702 35.669955867507774 139.74667158563935 68.702 35.669955867507774 139.74667158563935 66.889</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1300fdfc-46bc-4e1d-89cb-623bb506eb21">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1300fdfc-46bc-4e1d-89cb-623bb506eb21_0">
											<gml:posList>35.66995417213992 139.7466078950748 71.5 35.66996580886618 139.74662040888205 71.5 35.66996580886618 139.74662040888205 66.889 35.66995417213992 139.7466078950748 66.889 35.66995417213992 139.7466078950748 71.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e916cd3a-f9ca-44e5-86e0-ab6e8802f064">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e916cd3a-f9ca-44e5-86e0-ab6e8802f064_0">
											<gml:posList>35.66996184455353 139.74659777950072 73.694 35.66995135351713 139.7466116096471 73.694 35.66996269307645 139.74662452143912 73.694 35.6699731841143 139.7466106912925 73.694 35.66996184455353 139.74659777950072 73.694</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c4997a01-cd7c-4117-aea0-10cf280c2893">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c4997a01-cd7c-4117-aea0-10cf280c2893_0">
											<gml:posList>35.66996184455353 139.74659777950072 73.694 35.6699731841143 139.7466106912925 73.694 35.6699731841143 139.7466106912925 71.5 35.66996184455353 139.74659777950072 71.5 35.66996184455353 139.74659777950072 73.694</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-eda4ae73-4bfb-48cd-abf6-f1c9fef4b062">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-eda4ae73-4bfb-48cd-abf6-f1c9fef4b062_0">
											<gml:posList>35.6699731841143 139.7466106912925 73.694 35.66996269307645 139.74662452143912 73.694 35.66996269307645 139.74662452143912 66.889 35.66996580886618 139.74662040888205 66.889 35.66996580886618 139.74662040888205 71.5 35.6699731841143 139.7466106912925 71.5 35.6699731841143 139.7466106912925 73.694</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_26936c14-34ee-407e-b77b-42fb2fe47520_BuildingInstallation_1031">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7cbc7b6d-1210-4113-9662-8399752feb75">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66983404074838 139.7467883318892 66.889 35.66982052757257 139.74677357772865 66.889 35.669828181671086 139.7467630424521 66.889 35.6698126929216 139.74674611433247 66.889 35.669866658854936 139.74667193612322 66.889 35.66987077235701 139.7466764385226 66.889 35.669821642017595 139.74674397275479 66.889 35.66984254325901 139.7467668157875 66.889 35.669838338002506 139.74677259748276 66.889 35.66984232519752 139.7467769453755 66.889 35.66983404074838 139.7467883318892 66.889</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-46ce5b4b-5caf-4740-8450-c9a1c3d637d5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66981893009663 139.7469841528349 66.889 35.66979907437918 139.74701143619083 66.889 35.669806372199915 139.74701940367663 66.889 35.66979240565627 139.74703859487872 66.889 35.669785658109454 139.74703123434006 66.889 35.669774861284424 139.74704608097665 66.889 35.66978205085904 139.7470539381179 66.889 35.66974718402403 139.74710187184297 66.889 35.669766046498495 139.74712248581253 66.889 35.66974775760385 139.7471476244745 66.889 35.66974248043945 139.7471418529989 66.889 35.66975378155469 139.74712632097624 66.889 35.66973355694837 139.7471042282869 66.889 35.66975738381515 139.74707146180165 66.889 35.669745521475605 139.7470585063572 66.889 35.66983518283653 139.7469352559629 66.889 35.669825016386596 139.74692414341098 66.889 35.6698289965213 139.74691866021428 66.889 35.669838612698555 139.7469291658188 66.889 35.669860062248695 139.74689968251943 66.889 35.66984626041738 139.7468846083071 66.889 35.66982040749558 139.7469201386136 66.889 35.66981424627766 139.74691339603658 66.889 35.669840099197486 139.74687786573068 66.889 35.66977821643093 139.74681025253017 66.889 35.66978326814599 139.7468033100791 66.889 35.669822788320836 139.7468464800976 66.889 35.66983145097108 139.7468345629666 66.889 35.66983725135082 139.74684089721936 66.889 35.66990578715826 139.74674668761568 66.889 35.66989960790326 139.74673994506432 66.889 35.6699086307502 139.74672755253496 66.889 35.66991595566252 139.74673556416127 66.889 35.66990954422939 139.74674438594977 66.889 35.66991658949273 139.7467520885862 66.889 35.66984003036967 139.74685733094577 66.889 35.66986111199094 139.74688035055783 66.889 35.66988753220215 139.74684403532888 66.889 35.66989586743727 139.74685315049334 66.889 35.66987005956193 139.74688863659864 66.889 35.66989710394252 139.7469181891471 66.889 35.669886712337146 139.7469324609809 66.889 35.66990461863253 139.74695202658802 66.889 35.66989667634775 139.74696293773766 66.889 35.669904028293544 139.74697096040134 66.889 35.66988098486487 139.74700263255997 66.889 35.66986964571817 139.74699023989803 66.889 35.669877083728 139.74698001416175 66.889 35.669858230259074 139.7469594222799 66.889 35.669845686499464 139.74697666784368 66.889 35.669840652895616 139.74697117226458 66.889 35.66982577687647 139.7469916237276 66.889 35.66981893009663 139.7469841528349 66.889</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-224b1df3-ed7a-4490-a715-0a71e099fae7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-224b1df3-ed7a-4490-a715-0a71e099fae7_0">
											<gml:posList>35.669860062248695 139.74689968251943 66.889 35.669838612698555 139.7469291658188 66.889 35.669838612698555 139.7469291658188 70.559 35.669860062248695 139.74689968251943 70.559 35.669860062248695 139.74689968251943 66.889</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-dbd88e77-9ec8-4dde-80dd-2d70e5d385fa">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-dbd88e77-9ec8-4dde-80dd-2d70e5d385fa_0">
											<gml:posList>35.66987077235701 139.7466764385226 66.889 35.669866658854936 139.74667193612322 66.889 35.669866658854936 139.74667193612322 70.94 35.66987077235701 139.7466764385226 70.94 35.66987077235701 139.7466764385226 66.889</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7a53ad21-feee-4b90-86a4-7bf1344d1ddc">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7a53ad21-feee-4b90-86a4-7bf1344d1ddc_0">
											<gml:posList>35.669866658854936 139.74667193612322 66.889 35.6698126929216 139.74674611433247 66.889 35.6698126929216 139.74674611433247 70.94 35.669866658854936 139.74667193612322 70.94 35.669866658854936 139.74667193612322 66.889</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7ed40d6e-b48d-4cdd-8f60-2abc320f6ba0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7ed40d6e-b48d-4cdd-8f60-2abc320f6ba0_0">
											<gml:posList>35.66987077235701 139.7466764385226 66.889 35.66987077235701 139.7466764385226 70.94 35.669821642017595 139.74674397275479 70.94 35.669821642017595 139.74674397275479 66.889 35.66987077235701 139.7466764385226 66.889</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7eb90e77-6c38-4df9-9b57-a9eeb3a4482e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7eb90e77-6c38-4df9-9b57-a9eeb3a4482e_0">
											<gml:posList>35.669866658854936 139.74667193612322 70.94 35.6698126929216 139.74674611433247 70.94 35.669828181671086 139.7467630424521 70.94 35.66982052757257 139.74677357772865 70.94 35.66983404074838 139.7467883318892 70.94 35.66984232519752 139.7467769453755 70.94 35.669838338002506 139.74677259748276 70.94 35.66984254325901 139.7467668157875 70.94 35.669821642017595 139.74674397275479 70.94 35.66987077235701 139.7466764385226 70.94 35.669866658854936 139.74667193612322 70.94</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-691ea205-af46-4d15-88b1-d4a970cc9510">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-691ea205-af46-4d15-88b1-d4a970cc9510_0">
											<gml:posList>35.66991595566252 139.74673556416127 66.889 35.6699086307502 139.74672755253496 66.889 35.6699086307502 139.74672755253496 70.559 35.66991595566252 139.74673556416127 70.559 35.66991595566252 139.74673556416127 66.889</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c8d1188e-7790-4c34-a5d6-81ef42f44ff2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c8d1188e-7790-4c34-a5d6-81ef42f44ff2_0">
											<gml:posList>35.6699086307502 139.74672755253496 66.889 35.66989960790326 139.74673994506432 66.889 35.66989960790326 139.74673994506432 70.559 35.6699086307502 139.74672755253496 70.559 35.6699086307502 139.74672755253496 66.889</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-003c66d2-6b38-49ac-b1ca-0d60c42c34de">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-003c66d2-6b38-49ac-b1ca-0d60c42c34de_0">
											<gml:posList>35.66990954422939 139.74674438594977 66.889 35.66991595566252 139.74673556416127 66.889 35.66991595566252 139.74673556416127 70.559 35.66990954422939 139.74674438594977 70.559 35.66990954422939 139.74674438594977 66.889</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-05b54675-2539-42de-8d98-e84cf21ad186">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-05b54675-2539-42de-8d98-e84cf21ad186_0">
											<gml:posList>35.66989960790326 139.74673994506432 66.889 35.66990578715826 139.74674668761568 66.889 35.66990578715826 139.74674668761568 70.559 35.66989960790326 139.74673994506432 70.559 35.66989960790326 139.74673994506432 66.889</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-31dec6c0-e223-4bb4-8476-19451b4559ed">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-31dec6c0-e223-4bb4-8476-19451b4559ed_0">
											<gml:posList>35.66991658949273 139.7467520885862 66.889 35.66990954422939 139.74674438594977 66.889 35.66990954422939 139.74674438594977 70.559 35.66991658949273 139.7467520885862 70.559 35.66991658949273 139.7467520885862 66.889</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-45d2f077-02f4-4a48-b94e-934365074f67">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-45d2f077-02f4-4a48-b94e-934365074f67_0">
											<gml:posList>35.6698126929216 139.74674611433247 66.889 35.669828181671086 139.7467630424521 66.889 35.669828181671086 139.7467630424521 70.94 35.6698126929216 139.74674611433247 70.94 35.6698126929216 139.74674611433247 66.889</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4144dadf-492d-418c-a978-603355a983a7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4144dadf-492d-418c-a978-603355a983a7_0">
											<gml:posList>35.66984254325901 139.7467668157875 66.889 35.669821642017595 139.74674397275479 66.889 35.669821642017595 139.74674397275479 70.94 35.66984254325901 139.7467668157875 70.94 35.66984254325901 139.7467668157875 66.889</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ce79a401-7e0c-4da0-b93b-9e0e7fd89a34">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ce79a401-7e0c-4da0-b93b-9e0e7fd89a34_0">
											<gml:posList>35.669828181671086 139.7467630424521 66.889 35.66982052757257 139.74677357772865 66.889 35.66982052757257 139.74677357772865 70.94 35.669828181671086 139.7467630424521 70.94 35.669828181671086 139.7467630424521 66.889</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-807f730d-eb58-480c-929b-98f5fb03fe44">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-807f730d-eb58-480c-929b-98f5fb03fe44_0">
											<gml:posList>35.669838338002506 139.74677259748276 66.889 35.66984254325901 139.7467668157875 66.889 35.66984254325901 139.7467668157875 70.94 35.669838338002506 139.74677259748276 70.94 35.669838338002506 139.74677259748276 66.889</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-849be69b-e0ce-4ffe-bf66-a01c6df9d051">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-849be69b-e0ce-4ffe-bf66-a01c6df9d051_0">
											<gml:posList>35.66984232519752 139.7467769453755 66.889 35.669838338002506 139.74677259748276 66.889 35.669838338002506 139.74677259748276 70.94 35.66984232519752 139.7467769453755 70.94 35.66984232519752 139.7467769453755 66.889</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9b6acdc9-7763-44f8-9003-750a1addfbb5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9b6acdc9-7763-44f8-9003-750a1addfbb5_0">
											<gml:posList>35.66982052757257 139.74677357772865 66.889 35.66983404074838 139.7467883318892 66.889 35.66983404074838 139.7467883318892 70.94 35.66982052757257 139.74677357772865 70.94 35.66982052757257 139.74677357772865 66.889</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8c710551-4451-4682-ad05-51cbf3e9cdd0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8c710551-4451-4682-ad05-51cbf3e9cdd0_0">
											<gml:posList>35.66983404074838 139.7467883318892 66.889 35.66984232519752 139.7467769453755 66.889 35.66984232519752 139.7467769453755 70.94 35.66983404074838 139.7467883318892 70.94 35.66983404074838 139.7467883318892 66.889</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-05c4aebe-723a-43a9-8445-332879934b9d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-05c4aebe-723a-43a9-8445-332879934b9d_0">
											<gml:posList>35.66990578715826 139.74674668761568 66.889 35.66983725135082 139.74684089721936 66.889 35.66983725135082 139.74684089721936 70.559 35.66990578715826 139.74674668761568 70.559 35.66990578715826 139.74674668761568 66.889</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e351edb6-7e4b-4f13-8ad4-d1fca0260343">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e351edb6-7e4b-4f13-8ad4-d1fca0260343_0">
											<gml:posList>35.66991658949273 139.7467520885862 66.889 35.66991658949273 139.7467520885862 70.559 35.66984003036967 139.74685733094577 70.559 35.66984003036967 139.74685733094577 66.889 35.66991658949273 139.7467520885862 66.889</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c81fb36d-388e-4d2f-b541-58dc5380deb5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c81fb36d-388e-4d2f-b541-58dc5380deb5_0">
											<gml:posList>35.66977821643093 139.74681025253017 66.889 35.66977821643093 139.74681025253017 70.559 35.66978326814599 139.7468033100791 70.559 35.66978326814599 139.7468033100791 66.889 35.66977821643093 139.74681025253017 66.889</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d1d8f367-0ec6-4fd1-9c34-2b6a2cb396f4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d1d8f367-0ec6-4fd1-9c34-2b6a2cb396f4_0">
											<gml:posList>35.66978326814599 139.7468033100791 66.889 35.66978326814599 139.7468033100791 70.559 35.669822788320836 139.7468464800976 70.559 35.669822788320836 139.7468464800976 66.889 35.66978326814599 139.7468033100791 66.889</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f5b8320c-3311-4fef-8758-9d2ee42a0bad">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f5b8320c-3311-4fef-8758-9d2ee42a0bad_0">
											<gml:posList>35.66983145097108 139.7468345629666 66.889 35.66983145097108 139.7468345629666 70.559 35.66983725135082 139.74684089721936 70.559 35.66983725135082 139.74684089721936 66.889 35.66983145097108 139.7468345629666 66.889</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c39d546d-e9c7-4014-a849-4c6243ec1ffa">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c39d546d-e9c7-4014-a849-4c6243ec1ffa_0">
											<gml:posList>35.66983145097108 139.7468345629666 66.889 35.669822788320836 139.7468464800976 66.889 35.669822788320836 139.7468464800976 70.559 35.66983145097108 139.7468345629666 70.559 35.66983145097108 139.7468345629666 66.889</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b51c6823-2173-411c-ae38-43f366c5658f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b51c6823-2173-411c-ae38-43f366c5658f_0">
											<gml:posList>35.669840099197486 139.74687786573068 66.889 35.669840099197486 139.74687786573068 70.559 35.66977821643093 139.74681025253017 70.559 35.66977821643093 139.74681025253017 66.889 35.669840099197486 139.74687786573068 66.889</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-81079f13-fb6e-4e42-890b-2465b211f3b9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-81079f13-fb6e-4e42-890b-2465b211f3b9_0">
											<gml:posList>35.66989586743727 139.74685315049334 66.889 35.66988753220215 139.74684403532888 66.889 35.66988753220215 139.74684403532888 70.559 35.66989586743727 139.74685315049334 70.559 35.66989586743727 139.74685315049334 66.889</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-487d7127-ae14-4072-b3c6-666b96759fd0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-487d7127-ae14-4072-b3c6-666b96759fd0_0">
											<gml:posList>35.66988753220215 139.74684403532888 66.889 35.66986111199094 139.74688035055783 66.889 35.66986111199094 139.74688035055783 70.559 35.66988753220215 139.74684403532888 70.559 35.66988753220215 139.74684403532888 66.889</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-be2fdbc5-5b5b-4472-8859-38205f56c137">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-be2fdbc5-5b5b-4472-8859-38205f56c137_0">
											<gml:posList>35.66986111199094 139.74688035055783 66.889 35.66984003036967 139.74685733094577 66.889 35.66984003036967 139.74685733094577 70.559 35.66986111199094 139.74688035055783 70.559 35.66986111199094 139.74688035055783 66.889</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-59830e1c-b046-4ccf-a3dd-d15b05e0721f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-59830e1c-b046-4ccf-a3dd-d15b05e0721f_0">
											<gml:posList>35.66987005956193 139.74688863659864 66.889 35.66989586743727 139.74685315049334 66.889 35.66989586743727 139.74685315049334 70.559 35.66987005956193 139.74688863659864 70.559 35.66987005956193 139.74688863659864 66.889</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2b309969-a1a6-4892-8676-0c6e785a12cc">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2b309969-a1a6-4892-8676-0c6e785a12cc_0">
											<gml:posList>35.669860062248695 139.74689968251943 66.889 35.669860062248695 139.74689968251943 70.559 35.66984626041738 139.7468846083071 70.559 35.66984626041738 139.7468846083071 66.889 35.669860062248695 139.74689968251943 66.889</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4ef49c03-a549-4943-b710-1a313390b927">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4ef49c03-a549-4943-b710-1a313390b927_0">
											<gml:posList>35.669840099197486 139.74687786573068 66.889 35.66981424627766 139.74691339603658 66.889 35.66981424627766 139.74691339603658 70.559 35.669840099197486 139.74687786573068 70.559 35.669840099197486 139.74687786573068 66.889</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6fa46a78-f32a-4960-b14d-cc27e2322edd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6fa46a78-f32a-4960-b14d-cc27e2322edd_0">
											<gml:posList>35.66984626041738 139.7468846083071 66.889 35.66984626041738 139.7468846083071 70.559 35.66982040749558 139.7469201386136 70.559 35.66982040749558 139.7469201386136 66.889 35.66984626041738 139.7468846083071 66.889</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d97f075d-8130-49ec-b754-b987eff2e410">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d97f075d-8130-49ec-b754-b987eff2e410_0">
											<gml:posList>35.66987005956193 139.74688863659864 66.889 35.66987005956193 139.74688863659864 70.559 35.66989710394252 139.7469181891471 70.559 35.66989710394252 139.7469181891471 66.889 35.66987005956193 139.74688863659864 66.889</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b481b07b-1686-468f-b546-1c1e891463a6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b481b07b-1686-468f-b546-1c1e891463a6_0">
											<gml:posList>35.66981424627766 139.74691339603658 66.889 35.66982040749558 139.7469201386136 66.889 35.66982040749558 139.7469201386136 70.559 35.66981424627766 139.74691339603658 70.559 35.66981424627766 139.74691339603658 66.889</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7a5d59c0-8585-4ad5-be34-2184721a74fa">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7a5d59c0-8585-4ad5-be34-2184721a74fa_0">
											<gml:posList>35.669825016386596 139.74692414341098 66.889 35.669825016386596 139.74692414341098 70.559 35.6698289965213 139.74691866021428 70.559 35.6698289965213 139.74691866021428 66.889 35.669825016386596 139.74692414341098 66.889</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f8a44dc2-0344-42e6-a993-3d2c8af46566">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f8a44dc2-0344-42e6-a993-3d2c8af46566_0">
											<gml:posList>35.6698289965213 139.74691866021428 66.889 35.6698289965213 139.74691866021428 70.559 35.669838612698555 139.7469291658188 70.559 35.669838612698555 139.7469291658188 66.889 35.6698289965213 139.74691866021428 66.889</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-29cf403f-c7ea-43d5-8942-7cfcd78301a6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-29cf403f-c7ea-43d5-8942-7cfcd78301a6_0">
											<gml:posList>35.669886712337146 139.7469324609809 66.889 35.66989710394252 139.7469181891471 66.889 35.66989710394252 139.7469181891471 70.559 35.669886712337146 139.7469324609809 70.559 35.669886712337146 139.7469324609809 66.889</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ff838ba0-cc84-4172-bc7b-416f8fe48d44">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ff838ba0-cc84-4172-bc7b-416f8fe48d44_0">
											<gml:posList>35.669825016386596 139.74692414341098 66.889 35.66983518283653 139.7469352559629 66.889 35.66983518283653 139.7469352559629 70.559 35.669825016386596 139.74692414341098 70.559 35.669825016386596 139.74692414341098 66.889</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-039352c4-9a0d-4af1-9628-5d50b7c2b053">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-039352c4-9a0d-4af1-9628-5d50b7c2b053_0">
											<gml:posList>35.669840652895616 139.74697117226458 70.559 35.669845686499464 139.74697666784368 70.559 35.669858230259074 139.7469594222799 70.559 35.669877083728 139.74698001416175 70.559 35.66986964571817 139.74699023989803 70.559 35.66988098486487 139.74700263255997 70.559 35.669904028293544 139.74697096040134 70.559 35.66989667634775 139.74696293773766 70.559 35.66990461863253 139.74695202658802 70.559 35.669886712337146 139.7469324609809 70.559 35.66989710394252 139.7469181891471 70.559 35.66987005956193 139.74688863659864 70.559 35.66989586743727 139.74685315049334 70.559 35.66988753220215 139.74684403532888 70.559 35.66986111199094 139.74688035055783 70.559 35.66984003036967 139.74685733094577 70.559 35.66991658949273 139.7467520885862 70.559 35.66990954422939 139.74674438594977 70.559 35.66991595566252 139.74673556416127 70.559 35.6699086307502 139.74672755253496 70.559 35.66989960790326 139.74673994506432 70.559 35.66990578715826 139.74674668761568 70.559 35.66983725135082 139.74684089721936 70.559 35.66983145097108 139.7468345629666 70.559 35.669822788320836 139.7468464800976 70.559 35.66978326814599 139.7468033100791 70.559 35.66977821643093 139.74681025253017 70.559 35.669840099197486 139.74687786573068 70.559 35.66981424627766 139.74691339603658 70.559 35.66982040749558 139.7469201386136 70.559 35.66984626041738 139.7468846083071 70.559 35.669860062248695 139.74689968251943 70.559 35.669838612698555 139.7469291658188 70.559 35.6698289965213 139.74691866021428 70.559 35.669825016386596 139.74692414341098 70.559 35.66983518283653 139.7469352559629 70.559 35.669745521475605 139.7470585063572 70.559 35.66975738381515 139.74707146180165 70.559 35.66973355694837 139.7471042282869 70.559 35.66975378155469 139.74712632097624 70.559 35.66974248043945 139.7471418529989 70.559 35.66974775760385 139.7471476244745 70.559 35.669766046498495 139.74712248581253 70.559 35.66974718402403 139.74710187184297 70.559 35.66978205085904 139.7470539381179 70.559 35.669774861284424 139.74704608097665 70.559 35.669785658109454 139.74703123434006 70.559 35.66979240565627 139.74703859487872 70.559 35.669806372199915 139.74701940367663 70.559 35.66979907437918 139.74701143619083 70.559 35.66981893009663 139.7469841528349 70.559 35.66982577687647 139.7469916237276 70.559 35.669840652895616 139.74697117226458 70.559</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-60d694b4-1697-412e-8029-f533fc0eccba">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-60d694b4-1697-412e-8029-f533fc0eccba_0">
											<gml:posList>35.669886712337146 139.7469324609809 66.889 35.669886712337146 139.7469324609809 70.559 35.66990461863253 139.74695202658802 70.559 35.66990461863253 139.74695202658802 66.889 35.669886712337146 139.7469324609809 66.889</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-84887880-3f30-4318-9237-b1a384e39245">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-84887880-3f30-4318-9237-b1a384e39245_0">
											<gml:posList>35.66989667634775 139.74696293773766 66.889 35.66990461863253 139.74695202658802 66.889 35.66990461863253 139.74695202658802 70.559 35.66989667634775 139.74696293773766 70.559 35.66989667634775 139.74696293773766 66.889</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fba92680-1b81-4646-9f37-7619db742594">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fba92680-1b81-4646-9f37-7619db742594_0">
											<gml:posList>35.669904028293544 139.74697096040134 66.889 35.66989667634775 139.74696293773766 66.889 35.66989667634775 139.74696293773766 70.559 35.669904028293544 139.74697096040134 70.559 35.669904028293544 139.74697096040134 66.889</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d3148415-3b4f-4c28-8578-3e836a5deb47">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d3148415-3b4f-4c28-8578-3e836a5deb47_0">
											<gml:posList>35.669845686499464 139.74697666784368 66.889 35.669858230259074 139.7469594222799 66.889 35.669858230259074 139.7469594222799 70.559 35.669845686499464 139.74697666784368 70.559 35.669845686499464 139.74697666784368 66.889</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d84c2859-1687-46ae-901b-337d9f99c063">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d84c2859-1687-46ae-901b-337d9f99c063_0">
											<gml:posList>35.669858230259074 139.7469594222799 66.889 35.669877083728 139.74698001416175 66.889 35.669877083728 139.74698001416175 70.559 35.669858230259074 139.7469594222799 70.559 35.669858230259074 139.7469594222799 66.889</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4fc9443e-a6bd-434c-bc3e-c4e85a535fd7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4fc9443e-a6bd-434c-bc3e-c4e85a535fd7_0">
											<gml:posList>35.669840652895616 139.74697117226458 66.889 35.669845686499464 139.74697666784368 66.889 35.669845686499464 139.74697666784368 70.559 35.669840652895616 139.74697117226458 70.559 35.669840652895616 139.74697117226458 66.889</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-156e31a6-a34c-4a30-8481-97b86f8cb23e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-156e31a6-a34c-4a30-8481-97b86f8cb23e_0">
											<gml:posList>35.66982577687647 139.7469916237276 66.889 35.669840652895616 139.74697117226458 66.889 35.669840652895616 139.74697117226458 70.559 35.66982577687647 139.7469916237276 70.559 35.66982577687647 139.7469916237276 66.889</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b4845542-7e15-4069-9da7-822ba17a65ef">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b4845542-7e15-4069-9da7-822ba17a65ef_0">
											<gml:posList>35.669877083728 139.74698001416175 66.889 35.66986964571817 139.74699023989803 66.889 35.66986964571817 139.74699023989803 70.559 35.669877083728 139.74698001416175 70.559 35.669877083728 139.74698001416175 66.889</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-97468b8b-2208-44bf-9dfa-263f713a1382">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-97468b8b-2208-44bf-9dfa-263f713a1382_0">
											<gml:posList>35.66988098486487 139.74700263255997 66.889 35.669904028293544 139.74697096040134 66.889 35.669904028293544 139.74697096040134 70.559 35.66988098486487 139.74700263255997 70.559 35.66988098486487 139.74700263255997 66.889</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7d6f984f-6b25-409a-88c3-e21bfee6057c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7d6f984f-6b25-409a-88c3-e21bfee6057c_0">
											<gml:posList>35.66981893009663 139.7469841528349 66.889 35.66982577687647 139.7469916237276 66.889 35.66982577687647 139.7469916237276 70.559 35.66981893009663 139.7469841528349 70.559 35.66981893009663 139.7469841528349 66.889</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-81d36dc9-e3f0-4a41-b1ea-e05e3ce80130">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-81d36dc9-e3f0-4a41-b1ea-e05e3ce80130_0">
											<gml:posList>35.66986964571817 139.74699023989803 66.889 35.66988098486487 139.74700263255997 66.889 35.66988098486487 139.74700263255997 70.559 35.66986964571817 139.74699023989803 70.559 35.66986964571817 139.74699023989803 66.889</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-38da87d4-9e0a-47de-a7b4-698631169a54">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-38da87d4-9e0a-47de-a7b4-698631169a54_0">
											<gml:posList>35.66983518283653 139.7469352559629 66.889 35.669745521475605 139.7470585063572 66.889 35.669745521475605 139.7470585063572 70.559 35.66983518283653 139.7469352559629 70.559 35.66983518283653 139.7469352559629 66.889</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-43eec434-33b3-4aee-9478-68d25bff07c0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-43eec434-33b3-4aee-9478-68d25bff07c0_0">
											<gml:posList>35.66979907437918 139.74701143619083 66.889 35.66981893009663 139.7469841528349 66.889 35.66981893009663 139.7469841528349 70.559 35.66979907437918 139.74701143619083 70.559 35.66979907437918 139.74701143619083 66.889</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d1047660-bd9c-412a-8ee4-3acbaca81743">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d1047660-bd9c-412a-8ee4-3acbaca81743_0">
											<gml:posList>35.669806372199915 139.74701940367663 66.889 35.66979907437918 139.74701143619083 66.889 35.66979907437918 139.74701143619083 70.559 35.669806372199915 139.74701940367663 70.559 35.669806372199915 139.74701940367663 66.889</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b5785bf0-c1f8-44bf-b972-7224a35889d9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b5785bf0-c1f8-44bf-b972-7224a35889d9_0">
											<gml:posList>35.669806372199915 139.74701940367663 66.889 35.669806372199915 139.74701940367663 70.559 35.66979240565627 139.74703859487872 70.559 35.66979240565627 139.74703859487872 66.889 35.669806372199915 139.74701940367663 66.889</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4ebf508e-c485-45fb-817c-7c5391ef559f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4ebf508e-c485-45fb-817c-7c5391ef559f_0">
											<gml:posList>35.669785658109454 139.74703123434006 66.889 35.66979240565627 139.74703859487872 66.889 35.66979240565627 139.74703859487872 70.559 35.669785658109454 139.74703123434006 70.559 35.669785658109454 139.74703123434006 66.889</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1a661d30-326b-43e0-b97e-e13839067e71">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1a661d30-326b-43e0-b97e-e13839067e71_0">
											<gml:posList>35.669785658109454 139.74703123434006 66.889 35.669785658109454 139.74703123434006 70.559 35.669774861284424 139.74704608097665 70.559 35.669774861284424 139.74704608097665 66.889 35.669785658109454 139.74703123434006 66.889</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9967026a-1360-48a6-91f2-8bb332d9f60d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9967026a-1360-48a6-91f2-8bb332d9f60d_0">
											<gml:posList>35.66975378155469 139.74712632097624 66.889 35.66975378155469 139.74712632097624 70.559 35.66973355694837 139.7471042282869 70.559 35.66973355694837 139.7471042282869 66.889 35.66975378155469 139.74712632097624 66.889</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-89d4cb21-95a4-4f47-83bd-317ac557cd00">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-89d4cb21-95a4-4f47-83bd-317ac557cd00_0">
											<gml:posList>35.66974248043945 139.7471418529989 66.889 35.66974775760385 139.7471476244745 66.889 35.66974775760385 139.7471476244745 70.559 35.66974248043945 139.7471418529989 70.559 35.66974248043945 139.7471418529989 66.889</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e6505997-31a8-4cb2-a84c-4ded1d5a00d7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e6505997-31a8-4cb2-a84c-4ded1d5a00d7_0">
											<gml:posList>35.66975738381515 139.74707146180165 66.889 35.66973355694837 139.7471042282869 66.889 35.66973355694837 139.7471042282869 70.559 35.66975738381515 139.74707146180165 70.559 35.66975738381515 139.74707146180165 66.889</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d3354674-c2a1-4211-b9d9-aa53d08f5421">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d3354674-c2a1-4211-b9d9-aa53d08f5421_0">
											<gml:posList>35.66975378155469 139.74712632097624 66.889 35.66974248043945 139.7471418529989 66.889 35.66974248043945 139.7471418529989 70.559 35.66975378155469 139.74712632097624 70.559 35.66975378155469 139.74712632097624 66.889</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0ad8a622-fa36-4eb7-b1f9-1e231a418205">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0ad8a622-fa36-4eb7-b1f9-1e231a418205_0">
											<gml:posList>35.66975738381515 139.74707146180165 66.889 35.66975738381515 139.74707146180165 70.559 35.669745521475605 139.7470585063572 70.559 35.669745521475605 139.7470585063572 66.889 35.66975738381515 139.74707146180165 66.889</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1b6c2b56-db10-4350-9e02-e896ca43bb7f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1b6c2b56-db10-4350-9e02-e896ca43bb7f_0">
											<gml:posList>35.66974718402403 139.74710187184297 66.889 35.66974718402403 139.74710187184297 70.559 35.669766046498495 139.74712248581253 70.559 35.669766046498495 139.74712248581253 66.889 35.66974718402403 139.74710187184297 66.889</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-32f1acbb-7da5-443b-b9c8-99db4130c822">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-32f1acbb-7da5-443b-b9c8-99db4130c822_0">
											<gml:posList>35.66974775760385 139.7471476244745 66.889 35.669766046498495 139.74712248581253 66.889 35.669766046498495 139.74712248581253 70.559 35.66974775760385 139.7471476244745 70.559 35.66974775760385 139.7471476244745 66.889</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a5e9ade0-757a-4963-811b-b4df42870f81">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a5e9ade0-757a-4963-811b-b4df42870f81_0">
											<gml:posList>35.66978205085904 139.7470539381179 66.889 35.66978205085904 139.7470539381179 70.559 35.66974718402403 139.74710187184297 70.559 35.66974718402403 139.74710187184297 66.889 35.66978205085904 139.7470539381179 66.889</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d9828cf9-2840-46e7-8c42-b4e31108d446">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d9828cf9-2840-46e7-8c42-b4e31108d446_0">
											<gml:posList>35.66978205085904 139.7470539381179 66.889 35.669774861284424 139.74704608097665 66.889 35.669774861284424 139.74704608097665 70.559 35.66978205085904 139.7470539381179 70.559 35.66978205085904 139.7470539381179 66.889</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_26936c14-34ee-407e-b77b-42fb2fe47520_BuildingInstallation_1041">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-674ebb3d-e462-4ceb-8690-7ba18bb6cbf1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6700214345492 139.74656054453882 71.5 35.66998413564675 139.7466104806154 71.5 35.669952670319574 139.74657517785147 71.5 35.66998997822129 139.74652524176832 71.5 35.6700214345492 139.74656054453882 71.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a96c4a40-98dc-4eee-bc32-df2096741edf">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66987755299016 139.7466671192553 66.889 35.669913789642635 139.74670671383726 66.889 35.669898067212735 139.74672832613257 66.889 35.66986183056728 139.74668873154857 66.889 35.66987755299016 139.7466671192553 66.889</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-59b8bb3f-ad5f-4e4d-aff9-6eb32fd2069f">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66986024707933 139.74678053813173 66.889 35.66982392024205 139.74674084422452 66.889 35.669839903818186 139.74671887819164 66.889 35.6698762306626 139.74675857209678 66.889 35.66986024707933 139.74678053813173 66.889</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f251c603-cf4f-44e9-bd98-3e7ef550fc68">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66978433499234 139.746795256264 66.889 35.669801597257 139.7467715214835 66.889 35.66983829393276 139.74681161265718 66.889 35.66982102264658 139.74683534744966 66.889 35.66978433499234 139.746795256264 66.889</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fa9dd611-a6d2-4014-89cd-1f97007f2ea6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66996423038858 139.7468696129232 66.889 35.66993371336359 139.74683679443783 66.889 35.66996877764735 139.74678782192964 66.889 35.669999294693426 139.7468206514569 66.889 35.66996423038858 139.7468696129232 66.889</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8d85e3fe-b548-41ef-8e93-5faa365fc160">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66969737543906 139.7472422559043 71.5 35.669666921452304 139.74720921639505 71.5 35.66970243643351 139.74716004489738 71.5 35.66973289944729 139.74719308439288 71.5 35.66969737543906 139.7472422559043 71.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1949b50b-e225-41af-b2cd-37a5baf24860">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1949b50b-e225-41af-b2cd-37a5baf24860_0">
											<gml:posList>35.669666921452304 139.74720921639505 71.5 35.66969737543906 139.7472422559043 71.5 35.66969737543906 139.7472422559043 72.921 35.669666921452304 139.74720921639505 72.921 35.669666921452304 139.74720921639505 71.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9ad02d15-490e-4bfe-8d83-3d29d646aefd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9ad02d15-490e-4bfe-8d83-3d29d646aefd_0">
											<gml:posList>35.669666921452304 139.74720921639505 71.5 35.669666921452304 139.74720921639505 72.921 35.66970243643351 139.74716004489738 72.921 35.66970243643351 139.74716004489738 71.5 35.669666921452304 139.74720921639505 71.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a4d97f08-b36c-46d5-8603-c6fdabb2e6bc">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a4d97f08-b36c-46d5-8603-c6fdabb2e6bc_0">
											<gml:posList>35.66969737543906 139.7472422559043 72.921 35.66973289944729 139.74719308439288 72.921 35.66970243643351 139.74716004489738 72.921 35.669666921452304 139.74720921639505 72.921 35.66969737543906 139.7472422559043 72.921</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a2c5771b-b297-479e-9471-b51a246525d0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a2c5771b-b297-479e-9471-b51a246525d0_0">
											<gml:posList>35.66973289944729 139.74719308439288 71.5 35.66973289944729 139.74719308439288 72.921 35.66969737543906 139.7472422559043 72.921 35.66969737543906 139.7472422559043 71.5 35.66973289944729 139.74719308439288 71.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0cfe660f-d6d1-434d-90a4-e90ecae7a660">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0cfe660f-d6d1-434d-90a4-e90ecae7a660_0">
											<gml:posList>35.66973289944729 139.74719308439288 71.5 35.66970243643351 139.74716004489738 71.5 35.66970243643351 139.74716004489738 72.921 35.66973289944729 139.74719308439288 72.921 35.66973289944729 139.74719308439288 71.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e1d3df28-cc10-4fc1-8c4e-9ecd8811d452">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e1d3df28-cc10-4fc1-8c4e-9ecd8811d452_0">
											<gml:posList>35.669801597257 139.7467715214835 66.889 35.66978433499234 139.746795256264 66.889 35.66978433499234 139.746795256264 70.94 35.669801597257 139.7467715214835 70.94 35.669801597257 139.7467715214835 66.889</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-31a33585-5351-4684-8c2b-ed3c40119f51">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-31a33585-5351-4684-8c2b-ed3c40119f51_0">
											<gml:posList>35.66978433499234 139.746795256264 66.889 35.66982102264658 139.74683534744966 66.889 35.66982102264658 139.74683534744966 70.94 35.66978433499234 139.746795256264 70.94 35.66978433499234 139.746795256264 66.889</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-eda6f826-b952-431e-b756-32e9e7f659e2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-eda6f826-b952-431e-b756-32e9e7f659e2_0">
											<gml:posList>35.66983829393276 139.74681161265718 70.94 35.669801597257 139.7467715214835 70.94 35.66978433499234 139.746795256264 70.94 35.66982102264658 139.74683534744966 70.94 35.66983829393276 139.74681161265718 70.94</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7679193a-8167-4a33-8638-c34bf55e1de7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7679193a-8167-4a33-8638-c34bf55e1de7_0">
											<gml:posList>35.66983829393276 139.74681161265718 66.889 35.669801597257 139.7467715214835 66.889 35.669801597257 139.7467715214835 70.94 35.66983829393276 139.74681161265718 70.94 35.66983829393276 139.74681161265718 66.889</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-94eaf4a5-ca36-4f33-913a-2c3a7ac80cd7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-94eaf4a5-ca36-4f33-913a-2c3a7ac80cd7_0">
											<gml:posList>35.66982102264658 139.74683534744966 66.889 35.66983829393276 139.74681161265718 66.889 35.66983829393276 139.74681161265718 70.94 35.66982102264658 139.74683534744966 70.94 35.66982102264658 139.74683534744966 66.889</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9a714720-f1dd-4338-ac90-422206db3be7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9a714720-f1dd-4338-ac90-422206db3be7_0">
											<gml:posList>35.669839903818186 139.74671887819164 66.889 35.66982392024205 139.74674084422452 66.889 35.66982392024205 139.74674084422452 70.94 35.669839903818186 139.74671887819164 70.94 35.669839903818186 139.74671887819164 66.889</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f4a7f035-23c1-44a6-9065-c3d4186b8bcd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f4a7f035-23c1-44a6-9065-c3d4186b8bcd_0">
											<gml:posList>35.66982392024205 139.74674084422452 66.889 35.66986024707933 139.74678053813173 66.889 35.66986024707933 139.74678053813173 70.94 35.66982392024205 139.74674084422452 70.94 35.66982392024205 139.74674084422452 66.889</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b9432003-17b7-4a61-b5a4-84646d964bce">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b9432003-17b7-4a61-b5a4-84646d964bce_0">
											<gml:posList>35.66986024707933 139.74678053813173 70.94 35.6698762306626 139.74675857209678 70.94 35.669839903818186 139.74671887819164 70.94 35.66982392024205 139.74674084422452 70.94 35.66986024707933 139.74678053813173 70.94</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-45312b8d-2284-4c64-b85b-ace383b768a1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-45312b8d-2284-4c64-b85b-ace383b768a1_0">
											<gml:posList>35.6698762306626 139.74675857209678 66.889 35.669839903818186 139.74671887819164 66.889 35.669839903818186 139.74671887819164 70.94 35.6698762306626 139.74675857209678 70.94 35.6698762306626 139.74675857209678 66.889</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b6a43d62-c53d-409b-b623-413ed53604b2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b6a43d62-c53d-409b-b623-413ed53604b2_0">
											<gml:posList>35.6698762306626 139.74675857209678 70.94 35.66986024707933 139.74678053813173 70.94 35.66986024707933 139.74678053813173 66.889 35.6698762306626 139.74675857209678 66.889 35.6698762306626 139.74675857209678 70.94</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9d5119a1-687f-4fd8-a6e1-f2f4341ce9af">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9d5119a1-687f-4fd8-a6e1-f2f4341ce9af_0">
											<gml:posList>35.66987755299016 139.7466671192553 66.889 35.66986183056728 139.74668873154857 66.889 35.66986183056728 139.74668873154857 70.94 35.66987755299016 139.7466671192553 70.94 35.66987755299016 139.7466671192553 66.889</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-42dcbdf7-69eb-403c-8b3e-964300db9e27">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-42dcbdf7-69eb-403c-8b3e-964300db9e27_0">
											<gml:posList>35.669898067212735 139.74672832613257 66.889 35.669898067212735 139.74672832613257 70.94 35.66986183056728 139.74668873154857 70.94 35.66986183056728 139.74668873154857 66.889 35.669898067212735 139.74672832613257 66.889</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4475d2ec-00ec-4f28-8672-0fad97f35ed3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4475d2ec-00ec-4f28-8672-0fad97f35ed3_0">
											<gml:posList>35.669898067212735 139.74672832613257 70.94 35.669913789642635 139.74670671383726 70.94 35.66987755299016 139.7466671192553 70.94 35.66986183056728 139.74668873154857 70.94 35.669898067212735 139.74672832613257 70.94</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6fc74ca7-7374-4d48-aa74-ae914722944c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6fc74ca7-7374-4d48-aa74-ae914722944c_0">
											<gml:posList>35.669913789642635 139.74670671383726 66.889 35.66987755299016 139.7466671192553 66.889 35.66987755299016 139.7466671192553 70.94 35.669913789642635 139.74670671383726 70.94 35.669913789642635 139.74670671383726 66.889</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c6e70e22-f212-4e50-a063-fb80ecfe9cb0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c6e70e22-f212-4e50-a063-fb80ecfe9cb0_0">
											<gml:posList>35.669898067212735 139.74672832613257 66.889 35.669913789642635 139.74670671383726 66.889 35.669913789642635 139.74670671383726 70.94 35.669898067212735 139.74672832613257 70.94 35.669898067212735 139.74672832613257 66.889</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-28485e09-326f-413d-afd0-e963b8a317b3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-28485e09-326f-413d-afd0-e963b8a317b3_0">
											<gml:posList>35.66993371336359 139.74683679443783 66.889 35.66996423038858 139.7468696129232 66.889 35.66996423038858 139.7468696129232 72.711 35.66993371336359 139.74683679443783 72.711 35.66993371336359 139.74683679443783 66.889</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7a5d6f8e-f234-438a-8b8e-c8df63652500">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7a5d6f8e-f234-438a-8b8e-c8df63652500_0">
											<gml:posList>35.66996877764735 139.74678782192964 66.889 35.66993371336359 139.74683679443783 66.889 35.66993371336359 139.74683679443783 72.711 35.66996877764735 139.74678782192964 72.711 35.66996877764735 139.74678782192964 66.889</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a4e9fe55-00fb-44f9-8523-13c6825b00b2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a4e9fe55-00fb-44f9-8523-13c6825b00b2_0">
											<gml:posList>35.66996877764735 139.74678782192964 72.711 35.66993371336359 139.74683679443783 72.711 35.66996423038858 139.7468696129232 72.711 35.669999294693426 139.7468206514569 72.711 35.66996877764735 139.74678782192964 72.711</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-66b1035a-9242-415f-830b-3da0bdf61fd9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-66b1035a-9242-415f-830b-3da0bdf61fd9_0">
											<gml:posList>35.669952670319574 139.74657517785147 71.5 35.66998413564675 139.7466104806154 71.5 35.66998413564675 139.7466104806154 72.535 35.669952670319574 139.74657517785147 72.535 35.669952670319574 139.74657517785147 71.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6305ec90-4372-411b-a4c4-e141939b7a73">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6305ec90-4372-411b-a4c4-e141939b7a73_0">
											<gml:posList>35.669952670319574 139.74657517785147 71.5 35.669952670319574 139.74657517785147 72.535 35.66998997822129 139.74652524176832 72.535 35.66998997822129 139.74652524176832 71.5 35.669952670319574 139.74657517785147 71.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-edad9555-8f10-4797-abbd-7c28bda144a0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-edad9555-8f10-4797-abbd-7c28bda144a0_0">
											<gml:posList>35.669999294693426 139.7468206514569 66.889 35.669999294693426 139.7468206514569 72.711 35.66996423038858 139.7468696129232 72.711 35.66996423038858 139.7468696129232 66.889 35.669999294693426 139.7468206514569 66.889</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f3dbade6-f043-4a16-ad7c-d6385134d8a8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f3dbade6-f043-4a16-ad7c-d6385134d8a8_0">
											<gml:posList>35.66996877764735 139.74678782192964 66.889 35.66996877764735 139.74678782192964 72.711 35.669999294693426 139.7468206514569 72.711 35.669999294693426 139.7468206514569 66.889 35.66996877764735 139.74678782192964 66.889</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-66858582-74e8-43ed-8627-a177b1de287d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-66858582-74e8-43ed-8627-a177b1de287d_0">
											<gml:posList>35.6700214345492 139.74656054453882 72.535 35.66998997822129 139.74652524176832 72.535 35.669952670319574 139.74657517785147 72.535 35.66998413564675 139.7466104806154 72.535 35.6700214345492 139.74656054453882 72.535</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-50131373-df82-4966-8c56-762691a27b9f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-50131373-df82-4966-8c56-762691a27b9f_0">
											<gml:posList>35.66998413564675 139.7466104806154 71.5 35.6700214345492 139.74656054453882 71.5 35.6700214345492 139.74656054453882 72.535 35.66998413564675 139.7466104806154 72.535 35.66998413564675 139.7466104806154 71.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-904cfc66-cbf9-4b5f-ac73-fbb78cf4c510">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-904cfc66-cbf9-4b5f-ac73-fbb78cf4c510_0">
											<gml:posList>35.66998997822129 139.74652524176832 71.5 35.66998997822129 139.74652524176832 72.535 35.6700214345492 139.74656054453882 72.535 35.6700214345492 139.74656054453882 71.5 35.66998997822129 139.74652524176832 71.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-5b2c0855-2456-4297-aac4-a4a0b90e3dfd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5b2c0855-2456-4297-aac4-a4a0b90e3dfd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5b2c0855-2456-4297-aac4-a4a0b90e3dfd">
											<gml:posList>35.67002956988339 139.74679287070603 5.67 35.670063397543885 139.74682928670842 5.67 35.66971518521105 139.74731602518693 5.67 35.669707337272676 139.74730763851903 5.67 35.66969689168827 139.74732212020368 5.67 35.669602806214876 139.74722103837044 5.67 35.66961325162928 139.74720633576675 5.67 35.669607297987795 139.74719993539293 5.67 35.66968329785116 139.74709370011288 5.67 35.66958903175328 139.74699239783644 5.67 35.66997668322 139.746450605913 5.67 35.6699847117312 139.74645932371556 5.67 35.6699922756089 139.74644871116172 5.67 35.670086812808236 139.7465503444001 5.67 35.670078528460536 139.74656184143407 5.67 35.67008520379059 139.74656901425246 5.67 35.66999920925731 139.74668929004864 5.67 35.67005829492015 139.74675285240085 5.67 35.67002956988339 139.74679287070603 5.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-bf387382-aada-46b3-8ff2-3d6bff81d4c9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bf387382-aada-46b3-8ff2-3d6bff81d4c9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bf387382-aada-46b3-8ff2-3d6bff81d4c9">
											<gml:posList>35.66961325162928 139.74720633576675 71.5 35.669602806214876 139.74722103837044 71.5 35.6696415539615 139.74721783755444 71.5 35.66965199938333 139.74720314598937 71.5 35.66961325162928 139.74720633576675 71.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-47461dbf-9861-49c9-bc19-f161d4f618bc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-47461dbf-9861-49c9-bc19-f161d4f618bc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-47461dbf-9861-49c9-bc19-f161d4f618bc">
											<gml:posList>35.66961325162928 139.74720633576675 71.5 35.66965199938333 139.74720314598937 71.5 35.66964610888521 139.74719681182182 71.5 35.669607297987795 139.74719993539293 71.5 35.66961325162928 139.74720633576675 71.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-57e309fe-614a-4e14-9b48-adc4d15cc497">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-57e309fe-614a-4e14-9b48-adc4d15cc497">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-57e309fe-614a-4e14-9b48-adc4d15cc497">
											<gml:posList>35.66969469095916 139.74710593805634 74.742 35.66969411523139 139.74709495878693 74.742 35.669597990881584 139.746991670189 74.742 35.66958903175328 139.74699239783644 74.742 35.66969469095916 139.74710593805634 74.742</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ab233cc8-79d7-4cfd-9353-747a281e4d23">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ab233cc8-79d7-4cfd-9353-747a281e4d23">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ab233cc8-79d7-4cfd-9353-747a281e4d23">
											<gml:posList>35.669607297987795 139.74719993539293 71.5 35.66964610888521 139.74719681182182 71.5 35.66968584674454 139.74714127320152 71.5 35.66968329785116 139.74709370011288 71.5 35.669607297987795 139.74719993539293 71.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-880fd5c6-d481-45fc-b88f-c888b4f82c10">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-880fd5c6-d481-45fc-b88f-c888b4f82c10">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-880fd5c6-d481-45fc-b88f-c888b4f82c10">
											<gml:posList>35.66969689168827 139.74732212020368 71.5 35.66969442405301 139.74727463538474 71.5 35.6696415539615 139.74721783755444 71.5 35.669602806214876 139.74722103837044 71.5 35.66969689168827 139.74732212020368 71.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-85fb25d1-43c6-4ad4-a264-31527040ca60">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-85fb25d1-43c6-4ad4-a264-31527040ca60">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-85fb25d1-43c6-4ad4-a264-31527040ca60">
											<gml:posList>35.669597990881584 139.746991670189 74.742 35.66969411523139 139.74709495878693 74.742 35.66973646440333 139.74703576098972 74.742 35.669640340003454 139.74693247240842 74.742 35.669597990881584 139.746991670189 74.742</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-9cff2c50-a2c0-4e2c-9d50-8bbd08e75fd2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9cff2c50-a2c0-4e2c-9d50-8bbd08e75fd2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9cff2c50-a2c0-4e2c-9d50-8bbd08e75fd2">
											<gml:posList>35.66969469095916 139.74710593805634 71.5 35.66968329785116 139.74709370011288 71.5 35.66968584674454 139.74714127320152 71.5 35.669697239847714 139.7471535111522 71.5 35.66969469095916 139.74710593805634 71.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-89901751-55b7-47dc-ac23-e8cbdc504154">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-89901751-55b7-47dc-ac23-e8cbdc504154">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-89901751-55b7-47dc-ac23-e8cbdc504154">
											<gml:posList>35.669707337272676 139.74730763851903 71.5 35.66970482461047 139.7472602200197 71.5 35.66969442405301 139.74727463538474 71.5 35.66969689168827 139.74732212020368 71.5 35.669707337272676 139.74730763851903 71.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-996a4fbd-80d3-4007-b7b0-c1a1876b1d74">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-996a4fbd-80d3-4007-b7b0-c1a1876b1d74">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-996a4fbd-80d3-4007-b7b0-c1a1876b1d74">
											<gml:posList>35.66969469095916 139.74710593805634 71.5 35.669697239847714 139.7471535111522 71.5 35.66972016586961 139.74712146366608 71.5 35.66969948146738 139.74709923892772 71.5 35.66969469095916 139.74710593805634 71.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-9a521cc2-3fa4-4650-98d7-dda3c3052081">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9a521cc2-3fa4-4650-98d7-dda3c3052081">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9a521cc2-3fa4-4650-98d7-dda3c3052081">
											<gml:posList>35.66971259136544 139.74726851840052 71.5 35.669775363348954 139.7471807775158 71.5 35.66972016586961 139.74712146366608 71.5 35.669697239847714 139.7471535111522 71.5 35.66968584674454 139.74714127320152 71.5 35.66964610888521 139.74719681182182 71.5 35.66965199938333 139.74720314598937 71.5 35.6696415539615 139.74721783755444 71.5 35.66969442405301 139.74727463538474 71.5 35.66970482461047 139.7472602200197 71.5 35.66971259136544 139.74726851840052 71.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-6ab2a82d-9c2c-48bc-b0ae-21e3d8def375">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6ab2a82d-9c2c-48bc-b0ae-21e3d8def375">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6ab2a82d-9c2c-48bc-b0ae-21e3d8def375">
											<gml:posList>35.669707337272676 139.74730763851903 71.5 35.66971518521105 139.74731602518693 71.5 35.66971259136544 139.74726851840052 71.5 35.66970482461047 139.7472602200197 71.5 35.669707337272676 139.74730763851903 71.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-36375764-f5b8-4bd4-8eb4-baedc84188a2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-36375764-f5b8-4bd4-8eb4-baedc84188a2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-36375764-f5b8-4bd4-8eb4-baedc84188a2">
											<gml:posList>35.66969469095916 139.74710593805634 74.742 35.66982129717408 139.746928963555 74.742 35.6698123470523 139.74692968015566 74.742 35.66973646440333 139.74703576098972 74.742 35.66969411523139 139.74709495878693 74.742 35.66969469095916 139.74710593805634 74.742</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-68c8482a-ce8c-4ed4-93f4-a3f1a5f917e9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-68c8482a-ce8c-4ed4-93f4-a3f1a5f917e9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-68c8482a-ce8c-4ed4-93f4-a3f1a5f917e9">
											<gml:posList>35.66971518521105 139.74731602518693 71.5 35.670063397543885 139.74682928670842 71.5 35.67002458665104 139.7468323994279 71.5 35.669775363348954 139.7471807775158 71.5 35.66971259136544 139.74726851840052 71.5 35.66971518521105 139.74731602518693 71.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d46f735d-f7b3-4422-8fb3-0b36f8562fae">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d46f735d-f7b3-4422-8fb3-0b36f8562fae">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d46f735d-f7b3-4422-8fb3-0b36f8562fae">
											<gml:posList>35.6699847117312 139.74645932371556 71.5 35.669987197914644 139.74650708481602 71.5 35.66999485184616 139.74649635066058 71.5 35.6699922756089 139.74644871116172 71.5 35.6699847117312 139.74645932371556 71.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ed057181-b9bc-49b8-bd99-46180d434b1b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ed057181-b9bc-49b8-bd99-46180d434b1b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ed057181-b9bc-49b8-bd99-46180d434b1b">
											<gml:posList>35.6699847117312 139.74645932371556 71.5 35.66997668322 139.746450605913 71.5 35.669979124306394 139.7464983228724 71.5 35.669987197914644 139.74650708481602 71.5 35.6699847117312 139.74645932371556 71.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-8387e812-d7eb-494a-a2a7-27cc5020f9e8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8387e812-d7eb-494a-a2a7-27cc5020f9e8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8387e812-d7eb-494a-a2a7-27cc5020f9e8">
											<gml:posList>35.6699922756089 139.74644871116172 71.5 35.66999485184616 139.74649635066058 71.5 35.67004791173793 139.74655339107582 71.5 35.670086812808236 139.7465503444001 71.5 35.6699922756089 139.74644871116172 71.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ee95a372-6490-4a5f-a953-3ec230220b34">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ee95a372-6490-4a5f-a953-3ec230220b34">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ee95a372-6490-4a5f-a953-3ec230220b34">
											<gml:posList>35.670078528460536 139.74656184143407 71.5 35.670086812808236 139.7465503444001 71.5 35.67004791173793 139.74655339107582 71.5 35.670039618384116 139.74656489915986 71.5 35.670078528460536 139.74656184143407 71.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-4cc16a70-8bb2-4895-9f8e-fdec575653a4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4cc16a70-8bb2-4895-9f8e-fdec575653a4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4cc16a70-8bb2-4895-9f8e-fdec575653a4">
											<gml:posList>35.670078528460536 139.74656184143407 71.5 35.670039618384116 139.74656489915986 71.5 35.67004637490122 139.74657216025687 71.5 35.67008520379059 139.74656901425246 71.5 35.670078528460536 139.74656184143407 71.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-5d7d1e4f-e0b5-4291-b06e-14eb8ff6517a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5d7d1e4f-e0b5-4291-b06e-14eb8ff6517a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5d7d1e4f-e0b5-4291-b06e-14eb8ff6517a">
											<gml:posList>35.670039618384116 139.74656489915986 71.5 35.67004791173793 139.74655339107582 71.5 35.66999485184616 139.74649635066058 71.5 35.669987197914644 139.74650708481602 71.5 35.669979124306394 139.7464983228724 71.5 35.669923952751304 139.74657542984949 71.5 35.66999186067319 139.74664839388694 71.5 35.67004637490122 139.74657216025687 71.5 35.670039618384116 139.74656489915986 71.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-853fde9e-f1b2-4758-b315-508412f9c9ed">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-853fde9e-f1b2-4758-b315-508412f9c9ed">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-853fde9e-f1b2-4758-b315-508412f9c9ed">
											<gml:posList>35.67008520379059 139.74656901425246 71.5 35.67004637490122 139.74657216025687 71.5 35.66999186067319 139.74664839388694 71.5 35.66996038936199 139.74669241388926 71.5 35.66999920925731 139.74668929004864 71.5 35.67008520379059 139.74656901425246 71.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-78371c03-7bd0-4f3f-8894-b9b9f193480f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-78371c03-7bd0-4f3f-8894-b9b9f193480f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-78371c03-7bd0-4f3f-8894-b9b9f193480f">
											<gml:posList>35.66997668322 139.746450605913 71.5 35.66971563781951 139.74681544548207 71.5 35.669754457727635 139.74681233275697 71.5 35.669923952751304 139.74657542984949 71.5 35.669979124306394 139.7464983228724 71.5 35.66997668322 139.746450605913 71.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-0291ba73-3e28-454f-a816-e599dbe4643a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0291ba73-3e28-454f-a816-e599dbe4643a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0291ba73-3e28-454f-a816-e599dbe4643a">
											<gml:posList>35.66999920925731 139.74668929004864 71.5 35.66996038936199 139.74669241388926 71.5 35.6700194389448 139.74675594311339 71.5 35.67005829492015 139.74675285240085 71.5 35.66999920925731 139.74668929004864 71.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-1081724c-9299-46ef-844b-cbab343a1ec8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1081724c-9299-46ef-844b-cbab343a1ec8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1081724c-9299-46ef-844b-cbab343a1ec8">
											<gml:posList>35.67002956988339 139.74679287070603 71.5 35.67005829492015 139.74675285240085 71.5 35.6700194389448 139.74675594311339 71.5 35.669990722912566 139.7467959503421 71.5 35.67002956988339 139.74679287070603 71.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-13650ad2-8b17-449a-9b4d-3b81382e6dfe">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-13650ad2-8b17-449a-9b4d-3b81382e6dfe">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-13650ad2-8b17-449a-9b4d-3b81382e6dfe">
											<gml:posList>35.67002956988339 139.74679287070603 71.5 35.669990722912566 139.7467959503421 71.5 35.67002458665104 139.7468323994279 71.5 35.670063397543885 139.74682928670842 71.5 35.67002956988339 139.74679287070603 71.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ef9e656e-4ec2-4624-b1bf-64d32ccae5bf">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ef9e656e-4ec2-4624-b1bf-64d32ccae5bf">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ef9e656e-4ec2-4624-b1bf-64d32ccae5bf">
											<gml:posList>35.669754457727635 139.74681233275697 71.5 35.66971563781951 139.74681544548207 71.5 35.66973633128768 139.74683767014182 71.5 35.669754457727635 139.74681233275697 71.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-8dcc8adc-d4b8-4a54-aad8-878136667010">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8dcc8adc-d4b8-4a54-aad8-878136667010">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8dcc8adc-d4b8-4a54-aad8-878136667010">
											<gml:posList>35.66971563781951 139.74681544548207 74.742 35.669716222578565 139.74682641369648 74.742 35.6698123470523 139.74692968015566 74.742 35.66982129717408 139.746928963555 74.742 35.66971563781951 139.74681544548207 74.742</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d766567d-2d0f-4df4-9138-b226c105519f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d766567d-2d0f-4df4-9138-b226c105519f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d766567d-2d0f-4df4-9138-b226c105519f">
											<gml:posList>35.669990722912566 139.7467959503421 66.889 35.6700194389448 139.74675594311339 66.889 35.66996038936199 139.74669241388926 66.889 35.66999186067319 139.74664839388694 66.889 35.669923952751304 139.74657542984949 66.889 35.669754457727635 139.74681233275697 66.889 35.66973633128768 139.74683767014182 66.889 35.66982129717408 139.746928963555 66.889 35.66969948146738 139.74709923892772 66.889 35.66972016586961 139.74712146366608 66.889 35.669775363348954 139.7471807775158 66.889 35.67002458665104 139.7468323994279 66.889 35.669990722912566 139.7467959503421 66.889</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-16c6f560-11f8-4788-af83-dabb45c142ab">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-16c6f560-11f8-4788-af83-dabb45c142ab">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-16c6f560-11f8-4788-af83-dabb45c142ab">
											<gml:posList>35.66971563781951 139.74681544548207 74.742 35.66958903175328 139.74699239783644 74.742 35.669597990881584 139.746991670189 74.742 35.669640340003454 139.74693247240842 74.742 35.669716222578565 139.74682641369648 74.742 35.66971563781951 139.74681544548207 74.742</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-69913194-556e-4ca9-a94d-c3c14f835f47">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-69913194-556e-4ca9-a94d-c3c14f835f47">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-69913194-556e-4ca9-a94d-c3c14f835f47">
											<gml:posList>35.6698123470523 139.74692968015566 72.582 35.669716222578565 139.74682641369648 72.582 35.669640340003454 139.74693247240842 72.582 35.66973646440333 139.74703576098972 72.582 35.6698123470523 139.74692968015566 72.582</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9ef17217-9945-414f-8533-d1b90c7fa191">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9ef17217-9945-414f-8533-d1b90c7fa191">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9ef17217-9945-414f-8533-d1b90c7fa191">
											<gml:posList>35.66999186067319 139.74664839388694 71.5 35.66999186067319 139.74664839388694 66.889 35.66996038936199 139.74669241388926 66.889 35.66996038936199 139.74669241388926 71.5 35.66999186067319 139.74664839388694 71.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6030a69e-45b3-448e-9824-8870816cefca">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6030a69e-45b3-448e-9824-8870816cefca">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6030a69e-45b3-448e-9824-8870816cefca">
											<gml:posList>35.66973633128768 139.74683767014182 71.5 35.66973633128768 139.74683767014182 66.889 35.669754457727635 139.74681233275697 66.889 35.669754457727635 139.74681233275697 71.5 35.66973633128768 139.74683767014182 71.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e8bce30b-2138-4c44-aebf-d511a969fdaf">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e8bce30b-2138-4c44-aebf-d511a969fdaf">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e8bce30b-2138-4c44-aebf-d511a969fdaf">
											<gml:posList>35.669640340003454 139.74693247240842 74.742 35.669640340003454 139.74693247240842 72.582 35.669716222578565 139.74682641369648 72.582 35.669716222578565 139.74682641369648 74.742 35.669640340003454 139.74693247240842 74.742</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1add9d4c-f68e-478d-b992-ed8e28939e7a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1add9d4c-f68e-478d-b992-ed8e28939e7a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1add9d4c-f68e-478d-b992-ed8e28939e7a">
											<gml:posList>35.6698123470523 139.74692968015566 74.742 35.6698123470523 139.74692968015566 72.582 35.66973646440333 139.74703576098972 72.582 35.66973646440333 139.74703576098972 74.742 35.6698123470523 139.74692968015566 74.742</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-94c57b6d-9e6b-48fc-a5ca-df8cedd97627">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-94c57b6d-9e6b-48fc-a5ca-df8cedd97627">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-94c57b6d-9e6b-48fc-a5ca-df8cedd97627">
											<gml:posList>35.66973646440333 139.74703576098972 74.742 35.66973646440333 139.74703576098972 72.582 35.669640340003454 139.74693247240842 72.582 35.669640340003454 139.74693247240842 74.742 35.66973646440333 139.74703576098972 74.742</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2f2ce4cc-5908-494a-a630-6d74d0437e7e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2f2ce4cc-5908-494a-a630-6d74d0437e7e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2f2ce4cc-5908-494a-a630-6d74d0437e7e">
											<gml:posList>35.67002458665104 139.7468323994279 71.5 35.67002458665104 139.7468323994279 66.889 35.669775363348954 139.7471807775158 66.889 35.669775363348954 139.7471807775158 71.5 35.67002458665104 139.7468323994279 71.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5a4bf574-6502-4b95-8fb7-18a5c2731be9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5a4bf574-6502-4b95-8fb7-18a5c2731be9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5a4bf574-6502-4b95-8fb7-18a5c2731be9">
											<gml:posList>35.6699922756089 139.74644871116172 5.67 35.6699847117312 139.74645932371556 5.67 35.6699847117312 139.74645932371556 71.5 35.6699922756089 139.74644871116172 71.5 35.6699922756089 139.74644871116172 5.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e5003887-8849-4f2f-98c3-a461fea82a24">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e5003887-8849-4f2f-98c3-a461fea82a24">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e5003887-8849-4f2f-98c3-a461fea82a24">
											<gml:posList>35.6699847117312 139.74645932371556 5.67 35.66997668322 139.746450605913 5.67 35.66997668322 139.746450605913 71.5 35.6699847117312 139.74645932371556 71.5 35.6699847117312 139.74645932371556 5.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-28940ca7-0745-462e-aa8f-1f2786402a10">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-28940ca7-0745-462e-aa8f-1f2786402a10">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-28940ca7-0745-462e-aa8f-1f2786402a10">
											<gml:posList>35.670086812808236 139.7465503444001 5.67 35.6699922756089 139.74644871116172 5.67 35.6699922756089 139.74644871116172 71.5 35.670086812808236 139.7465503444001 71.5 35.670086812808236 139.7465503444001 5.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-712317c3-7c05-439a-88a1-2dae02d08d54">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-712317c3-7c05-439a-88a1-2dae02d08d54">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-712317c3-7c05-439a-88a1-2dae02d08d54">
											<gml:posList>35.670078528460536 139.74656184143407 5.67 35.670086812808236 139.7465503444001 5.67 35.670086812808236 139.7465503444001 71.5 35.670078528460536 139.74656184143407 71.5 35.670078528460536 139.74656184143407 5.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2e7f9066-3bdc-4b8e-883d-cfb9b1eb611c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2e7f9066-3bdc-4b8e-883d-cfb9b1eb611c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2e7f9066-3bdc-4b8e-883d-cfb9b1eb611c">
											<gml:posList>35.67008520379059 139.74656901425246 5.67 35.670078528460536 139.74656184143407 5.67 35.670078528460536 139.74656184143407 71.5 35.67008520379059 139.74656901425246 71.5 35.67008520379059 139.74656901425246 5.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2924b0e7-2de0-43db-81fa-39cf6d434298">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2924b0e7-2de0-43db-81fa-39cf6d434298">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2924b0e7-2de0-43db-81fa-39cf6d434298">
											<gml:posList>35.669923952751304 139.74657542984949 71.5 35.669923952751304 139.74657542984949 66.889 35.66999186067319 139.74664839388694 66.889 35.66999186067319 139.74664839388694 71.5 35.669923952751304 139.74657542984949 71.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7a749815-c8ca-481e-bd4c-7315fd7f22fd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7a749815-c8ca-481e-bd4c-7315fd7f22fd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7a749815-c8ca-481e-bd4c-7315fd7f22fd">
											<gml:posList>35.66999920925731 139.74668929004864 5.67 35.67008520379059 139.74656901425246 5.67 35.67008520379059 139.74656901425246 71.5 35.66999920925731 139.74668929004864 71.5 35.66999920925731 139.74668929004864 5.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7c452cfc-7aaa-4a89-9c3c-2b7c47bf7286">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7c452cfc-7aaa-4a89-9c3c-2b7c47bf7286">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7c452cfc-7aaa-4a89-9c3c-2b7c47bf7286">
											<gml:posList>35.669754457727635 139.74681233275697 71.5 35.669754457727635 139.74681233275697 66.889 35.669923952751304 139.74657542984949 66.889 35.669923952751304 139.74657542984949 71.5 35.669754457727635 139.74681233275697 71.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0c9df1b2-961c-4c35-aaf7-de79f693b22a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0c9df1b2-961c-4c35-aaf7-de79f693b22a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0c9df1b2-961c-4c35-aaf7-de79f693b22a">
											<gml:posList>35.67005829492015 139.74675285240085 5.67 35.66999920925731 139.74668929004864 5.67 35.66999920925731 139.74668929004864 71.5 35.67005829492015 139.74675285240085 71.5 35.67005829492015 139.74675285240085 5.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e5b69807-af4d-4b95-8ff3-1b694f08085d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e5b69807-af4d-4b95-8ff3-1b694f08085d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e5b69807-af4d-4b95-8ff3-1b694f08085d">
											<gml:posList>35.66958903175328 139.74699239783644 5.67 35.66958903175328 139.74699239783644 74.742 35.66971563781951 139.74681544548207 74.742 35.66971563781951 139.74681544548207 71.5 35.66997668322 139.746450605913 71.5 35.66997668322 139.746450605913 5.67 35.66958903175328 139.74699239783644 5.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c1b94c19-ea2b-4abc-bcf8-a7f020144610">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c1b94c19-ea2b-4abc-bcf8-a7f020144610">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c1b94c19-ea2b-4abc-bcf8-a7f020144610">
											<gml:posList>35.66996038936199 139.74669241388926 71.5 35.66996038936199 139.74669241388926 66.889 35.6700194389448 139.74675594311339 66.889 35.6700194389448 139.74675594311339 71.5 35.66996038936199 139.74669241388926 71.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b9296e96-deab-40d4-86f1-9e53f5c7d534">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b9296e96-deab-40d4-86f1-9e53f5c7d534">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b9296e96-deab-40d4-86f1-9e53f5c7d534">
											<gml:posList>35.67002956988339 139.74679287070603 5.67 35.67005829492015 139.74675285240085 5.67 35.67005829492015 139.74675285240085 71.5 35.67002956988339 139.74679287070603 71.5 35.67002956988339 139.74679287070603 5.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4fa48160-21cc-4208-844a-ad658d0e22d5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4fa48160-21cc-4208-844a-ad658d0e22d5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4fa48160-21cc-4208-844a-ad658d0e22d5">
											<gml:posList>35.6700194389448 139.74675594311339 71.5 35.6700194389448 139.74675594311339 66.889 35.669990722912566 139.7467959503421 66.889 35.669990722912566 139.7467959503421 71.5 35.6700194389448 139.74675594311339 71.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-26cd363e-8a57-4d5d-9284-7f8d0ff8c86d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-26cd363e-8a57-4d5d-9284-7f8d0ff8c86d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-26cd363e-8a57-4d5d-9284-7f8d0ff8c86d">
											<gml:posList>35.670063397543885 139.74682928670842 5.67 35.67002956988339 139.74679287070603 5.67 35.67002956988339 139.74679287070603 71.5 35.670063397543885 139.74682928670842 71.5 35.670063397543885 139.74682928670842 5.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-dcd0feb9-b24e-4951-9cdc-a9b636c36f8f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-dcd0feb9-b24e-4951-9cdc-a9b636c36f8f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-dcd0feb9-b24e-4951-9cdc-a9b636c36f8f">
											<gml:posList>35.669990722912566 139.7467959503421 71.5 35.669990722912566 139.7467959503421 66.889 35.67002458665104 139.7468323994279 66.889 35.67002458665104 139.7468323994279 71.5 35.669990722912566 139.7467959503421 71.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e505083c-f424-45c6-9e77-8307589d3d0b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e505083c-f424-45c6-9e77-8307589d3d0b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e505083c-f424-45c6-9e77-8307589d3d0b">
											<gml:posList>35.66973633128768 139.74683767014182 71.5 35.66971563781951 139.74681544548207 71.5 35.66971563781951 139.74681544548207 74.742 35.66982129717408 139.746928963555 74.742 35.66982129717408 139.746928963555 66.889 35.66973633128768 139.74683767014182 66.889 35.66973633128768 139.74683767014182 71.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a5f554c5-23dc-4ec9-9513-052cf18a14ca">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a5f554c5-23dc-4ec9-9513-052cf18a14ca">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a5f554c5-23dc-4ec9-9513-052cf18a14ca">
											<gml:posList>35.669716222578565 139.74682641369648 74.742 35.669716222578565 139.74682641369648 72.582 35.6698123470523 139.74692968015566 72.582 35.6698123470523 139.74692968015566 74.742 35.669716222578565 139.74682641369648 74.742</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6945ee0a-9efb-462f-b827-05f48bcf2200">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6945ee0a-9efb-462f-b827-05f48bcf2200">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6945ee0a-9efb-462f-b827-05f48bcf2200">
											<gml:posList>35.66969469095916 139.74710593805634 74.742 35.66969469095916 139.74710593805634 71.5 35.66969948146738 139.74709923892772 71.5 35.66969948146738 139.74709923892772 66.889 35.66982129717408 139.746928963555 66.889 35.66982129717408 139.746928963555 74.742 35.66969469095916 139.74710593805634 74.742</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-bd2a382a-d114-4872-a114-583616740e31">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bd2a382a-d114-4872-a114-583616740e31">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bd2a382a-d114-4872-a114-583616740e31">
											<gml:posList>35.66971518521105 139.74731602518693 5.67 35.670063397543885 139.74682928670842 5.67 35.670063397543885 139.74682928670842 71.5 35.66971518521105 139.74731602518693 71.5 35.66971518521105 139.74731602518693 5.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4f890637-e3f9-4206-8939-4d1aea42ee75">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4f890637-e3f9-4206-8939-4d1aea42ee75">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4f890637-e3f9-4206-8939-4d1aea42ee75">
											<gml:posList>35.66972016586961 139.74712146366608 71.5 35.66972016586961 139.74712146366608 66.889 35.66969948146738 139.74709923892772 66.889 35.66969948146738 139.74709923892772 71.5 35.66972016586961 139.74712146366608 71.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-923bfbdf-773f-4c8b-b73f-beda5022bf51">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-923bfbdf-773f-4c8b-b73f-beda5022bf51">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-923bfbdf-773f-4c8b-b73f-beda5022bf51">
											<gml:posList>35.669775363348954 139.7471807775158 71.5 35.669775363348954 139.7471807775158 66.889 35.66972016586961 139.74712146366608 66.889 35.66972016586961 139.74712146366608 71.5 35.669775363348954 139.7471807775158 71.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-43648d17-e657-41cb-a9c1-a79394dfa902">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-43648d17-e657-41cb-a9c1-a79394dfa902">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-43648d17-e657-41cb-a9c1-a79394dfa902">
											<gml:posList>35.669602806214876 139.74722103837044 5.67 35.66969689168827 139.74732212020368 5.67 35.66969689168827 139.74732212020368 71.5 35.669602806214876 139.74722103837044 71.5 35.669602806214876 139.74722103837044 5.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0dc629aa-2528-4b42-bd42-479a437e1cfb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0dc629aa-2528-4b42-bd42-479a437e1cfb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0dc629aa-2528-4b42-bd42-479a437e1cfb">
											<gml:posList>35.669707337272676 139.74730763851903 5.67 35.66971518521105 139.74731602518693 5.67 35.66971518521105 139.74731602518693 71.5 35.669707337272676 139.74730763851903 71.5 35.669707337272676 139.74730763851903 5.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-941aa71a-b14c-4051-887e-a67a1dcf0257">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-941aa71a-b14c-4051-887e-a67a1dcf0257">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-941aa71a-b14c-4051-887e-a67a1dcf0257">
											<gml:posList>35.66969689168827 139.74732212020368 5.67 35.669707337272676 139.74730763851903 5.67 35.669707337272676 139.74730763851903 71.5 35.66969689168827 139.74732212020368 71.5 35.66969689168827 139.74732212020368 5.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-29075ecc-2b0e-4269-a3e1-843c8ece8db6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-29075ecc-2b0e-4269-a3e1-843c8ece8db6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-29075ecc-2b0e-4269-a3e1-843c8ece8db6">
											<gml:posList>35.66958903175328 139.74699239783644 74.742 35.66958903175328 139.74699239783644 5.67 35.66968329785116 139.74709370011288 5.67 35.66968329785116 139.74709370011288 71.5 35.66969469095916 139.74710593805634 71.5 35.66969469095916 139.74710593805634 74.742 35.66958903175328 139.74699239783644 74.742</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8ebfbceb-26df-4130-9c15-db235d1da65a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8ebfbceb-26df-4130-9c15-db235d1da65a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8ebfbceb-26df-4130-9c15-db235d1da65a">
											<gml:posList>35.66968329785116 139.74709370011288 5.67 35.669607297987795 139.74719993539293 5.67 35.669607297987795 139.74719993539293 71.5 35.66968329785116 139.74709370011288 71.5 35.66968329785116 139.74709370011288 5.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-dd632096-17e3-477d-bde6-6c584618ee3a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-dd632096-17e3-477d-bde6-6c584618ee3a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-dd632096-17e3-477d-bde6-6c584618ee3a">
											<gml:posList>35.669607297987795 139.74719993539293 5.67 35.66961325162928 139.74720633576675 5.67 35.66961325162928 139.74720633576675 71.5 35.669607297987795 139.74719993539293 71.5 35.669607297987795 139.74719993539293 5.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-539e19e8-f1da-4fd6-9593-cbae487edfd1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-539e19e8-f1da-4fd6-9593-cbae487edfd1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-539e19e8-f1da-4fd6-9593-cbae487edfd1">
											<gml:posList>35.66961325162928 139.74720633576675 5.67 35.669602806214876 139.74722103837044 5.67 35.669602806214876 139.74722103837044 71.5 35.66961325162928 139.74720633576675 71.5 35.66961325162928 139.74720633576675 5.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区虎ノ門二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-2213</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">1829.87269</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1210</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>7</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.01</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>