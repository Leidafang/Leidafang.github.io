<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_2768dc9c-a265-453e-8e41-6798c9dbb333">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>0.80</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">401</bldg:usage>
			<bldg:measuredHeight uom="m">20.5</bldg:measuredHeight>
			<bldg:storeysAboveGround>10</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.67042265645615 139.74103638100428 0 35.670421126292545 139.74100393988502 0 35.67034463092622 139.74100937436137 0 35.67034893729904 139.74110061147056 0 35.67043333728137 139.74109461567392 0 35.670430561067676 139.74103581959147 0 35.67042265645615 139.74103638100428 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67042265645615 139.74103638100428 8.942 35.670430561067676 139.74103581959147 8.942 35.67043333728137 139.74109461567392 8.942 35.67034893729904 139.74110061147056 8.942 35.67034463092622 139.74100937436137 8.942 35.670421126292545 139.74100393988502 8.942 35.67042265645615 139.74103638100428 8.942</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67042265645615 139.74103638100428 8.942 35.670421126292545 139.74100393988502 8.942 35.670421126292545 139.74100393988502 29.43 35.67042265645615 139.74103638100428 29.43 35.67042265645615 139.74103638100428 8.942</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670421126292545 139.74100393988502 8.942 35.67034463092622 139.74100937436137 8.942 35.67034463092622 139.74100937436137 29.43 35.670421126292545 139.74100393988502 29.43 35.670421126292545 139.74100393988502 8.942</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67034463092622 139.74100937436137 8.942 35.67034893729904 139.74110061147056 8.942 35.67034893729904 139.74110061147056 29.43 35.67034463092622 139.74100937436137 29.43 35.67034463092622 139.74100937436137 8.942</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67034893729904 139.74110061147056 8.942 35.67043333728137 139.74109461567392 8.942 35.67043333728137 139.74109461567392 29.43 35.67034893729904 139.74110061147056 29.43 35.67034893729904 139.74110061147056 8.942</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67043333728137 139.74109461567392 8.942 35.670430561067676 139.74103581959147 8.942 35.670430561067676 139.74103581959147 29.43 35.67043333728137 139.74109461567392 29.43 35.67043333728137 139.74109461567392 8.942</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670430561067676 139.74103581959147 8.942 35.67042265645615 139.74103638100428 8.942 35.67042265645615 139.74103638100428 29.43 35.670430561067676 139.74103581959147 29.43 35.670430561067676 139.74103581959147 8.942</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67042265645615 139.74103638100428 29.43 35.670421126292545 139.74100393988502 29.43 35.67034463092622 139.74100937436137 29.43 35.67034893729904 139.74110061147056 29.43 35.67043333728137 139.74109461567392 29.43 35.670430561067676 139.74103581959147 29.43 35.67042265645615 139.74103638100428 29.43</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-f8b7b599-a881-4bc1-9abf-96a7b527b7a6"/>
							<gml:surfaceMember xlink:href="#poly-7abb1e19-fa89-486f-8f7f-54db1cf99356"/>
							<gml:surfaceMember xlink:href="#poly-4f355018-8dd6-48e0-a67d-443ae201c77c"/>
							<gml:surfaceMember xlink:href="#poly-b703c85f-bb32-486d-8372-2e54a99ee37c"/>
							<gml:surfaceMember xlink:href="#poly-74650355-47a1-4b04-a456-97ab8423f32a"/>
							<gml:surfaceMember xlink:href="#poly-65c01b56-de7e-4f05-9db4-5b5c07835a56"/>
							<gml:surfaceMember xlink:href="#poly-563a6146-93d0-442f-aedb-8aeec725c7dd"/>
							<gml:surfaceMember xlink:href="#poly-f9ca56d0-1185-4122-abd5-7b7fcdce0d2a"/>
							<gml:surfaceMember xlink:href="#poly-8e08df0e-f1e3-45fe-b56c-7d83b7df01a2"/>
							<gml:surfaceMember xlink:href="#poly-24d9b954-558c-4379-9dac-afc52d580e72"/>
							<gml:surfaceMember xlink:href="#poly-6c9c364c-e9f2-433b-abec-6f23f516c489"/>
							<gml:surfaceMember xlink:href="#poly-16a7ba4d-5567-44cc-b49d-44edfd3eb033"/>
							<gml:surfaceMember xlink:href="#poly-548be11f-8d82-4f49-9625-642e504cbad6"/>
							<gml:surfaceMember xlink:href="#poly-03eee14a-da73-4c7e-a5db-7a8666b5bf15"/>
							<gml:surfaceMember xlink:href="#poly-5741302d-1a74-4bed-9313-6e5dde9c5dd9"/>
							<gml:surfaceMember xlink:href="#poly-a0bdb461-151e-4cac-bdc0-301f705f060a"/>
							<gml:surfaceMember xlink:href="#poly-3a30558e-21da-44ab-8b8b-663daa0222b8"/>
							<gml:surfaceMember xlink:href="#poly-c672868e-6efe-4cc5-9579-7436f8fe20bc"/>
							<gml:surfaceMember xlink:href="#poly-83550973-7221-4d7a-934f-ae728c191bac"/>
							<gml:surfaceMember xlink:href="#poly-bb174dcf-3bb7-4d25-9561-c70ae026e5af"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-f8b7b599-a881-4bc1-9abf-96a7b527b7a6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f8b7b599-a881-4bc1-9abf-96a7b527b7a6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f8b7b599-a881-4bc1-9abf-96a7b527b7a6">
											<gml:posList>35.67042265645614 139.74103638100425 8.942 35.67043056106767 139.74103581959147 8.942 35.67043333728134 139.7410946156739 8.942 35.670348937299025 139.74110061147053 8.942 35.67034463092621 139.74100937436134 8.942 35.670421126292545 139.74100393988502 8.942 35.67042265645614 139.74103638100425 8.942</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-7abb1e19-fa89-486f-8f7f-54db1cf99356">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7abb1e19-fa89-486f-8f7f-54db1cf99356">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7abb1e19-fa89-486f-8f7f-54db1cf99356">
											<gml:posList>35.67034463092621 139.74100937436134 30.13 35.67034921374246 139.74101438408414 30.13 35.670417047370265 139.74100954503828 30.13 35.670421126292545 139.74100393988502 30.13 35.67034463092621 139.74100937436134 30.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-4f355018-8dd6-48e0-a67d-443ae201c77c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4f355018-8dd6-48e0-a67d-443ae201c77c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4f355018-8dd6-48e0-a67d-443ae201c77c">
											<gml:posList>35.67042265645614 139.74103638100425 30.13 35.670421126292545 139.74100393988502 30.13 35.670417047370265 139.74100954503828 30.13 35.67041857753235 139.741041986156 30.13 35.67042265645614 139.74103638100425 30.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b703c85f-bb32-486d-8372-2e54a99ee37c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b703c85f-bb32-486d-8372-2e54a99ee37c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b703c85f-bb32-486d-8372-2e54a99ee37c">
											<gml:posList>35.67042265645614 139.74103638100425 30.13 35.67041857753235 139.741041986156 30.13 35.67042648216084 139.7410414468363 30.13 35.67043056106767 139.74103581959147 30.13 35.67042265645614 139.74103638100425 30.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-74650355-47a1-4b04-a456-97ab8423f32a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-74650355-47a1-4b04-a456-97ab8423f32a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-74650355-47a1-4b04-a456-97ab8423f32a">
											<gml:posList>35.670353025239315 139.74109500631627 29.496 35.670428763482214 139.7410896059309 29.496 35.67042648216084 139.7410414468363 29.496 35.67041857753235 139.741041986156 29.496 35.670417047370265 139.74100954503828 29.496 35.67034921374246 139.74101438408414 29.496 35.670353025239315 139.74109500631627 29.496</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-65c01b56-de7e-4f05-9db4-5b5c07835a56">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-65c01b56-de7e-4f05-9db4-5b5c07835a56">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-65c01b56-de7e-4f05-9db4-5b5c07835a56">
											<gml:posList>35.670348937299025 139.74110061147053 30.13 35.670353025239315 139.74109500631627 30.13 35.67034921374246 139.74101438408414 30.13 35.67034463092621 139.74100937436134 30.13 35.670348937299025 139.74110061147053 30.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-563a6146-93d0-442f-aedb-8aeec725c7dd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-563a6146-93d0-442f-aedb-8aeec725c7dd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-563a6146-93d0-442f-aedb-8aeec725c7dd">
											<gml:posList>35.67043056106767 139.74103581959147 30.13 35.67042648216084 139.7410414468363 30.13 35.670428763482214 139.7410896059309 30.13 35.67043333728134 139.7410946156739 30.13 35.67043056106767 139.74103581959147 30.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f9ca56d0-1185-4122-abd5-7b7fcdce0d2a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f9ca56d0-1185-4122-abd5-7b7fcdce0d2a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f9ca56d0-1185-4122-abd5-7b7fcdce0d2a">
											<gml:posList>35.67043333728134 139.7410946156739 30.13 35.670428763482214 139.7410896059309 30.13 35.670353025239315 139.74109500631627 30.13 35.670348937299025 139.74110061147053 30.13 35.67043333728134 139.7410946156739 30.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8e08df0e-f1e3-45fe-b56c-7d83b7df01a2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8e08df0e-f1e3-45fe-b56c-7d83b7df01a2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8e08df0e-f1e3-45fe-b56c-7d83b7df01a2">
											<gml:posList>35.67034463092621 139.74100937436134 8.942 35.670348937299025 139.74110061147053 8.942 35.670348937299025 139.74110061147053 30.13 35.67034463092621 139.74100937436134 30.13 35.67034463092621 139.74100937436134 8.942</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-24d9b954-558c-4379-9dac-afc52d580e72">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-24d9b954-558c-4379-9dac-afc52d580e72">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-24d9b954-558c-4379-9dac-afc52d580e72">
											<gml:posList>35.670353025239315 139.74109500631627 30.13 35.670353025239315 139.74109500631627 29.496 35.67034921374246 139.74101438408414 29.496 35.67034921374246 139.74101438408414 30.13 35.670353025239315 139.74109500631627 30.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6c9c364c-e9f2-433b-abec-6f23f516c489">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6c9c364c-e9f2-433b-abec-6f23f516c489">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6c9c364c-e9f2-433b-abec-6f23f516c489">
											<gml:posList>35.670421126292545 139.74100393988502 30.13 35.670421126292545 139.74100393988502 8.942 35.67034463092621 139.74100937436134 8.942 35.67034463092621 139.74100937436134 30.13 35.670421126292545 139.74100393988502 30.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-16a7ba4d-5567-44cc-b49d-44edfd3eb033">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-16a7ba4d-5567-44cc-b49d-44edfd3eb033">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-16a7ba4d-5567-44cc-b49d-44edfd3eb033">
											<gml:posList>35.67034921374246 139.74101438408414 30.13 35.67034921374246 139.74101438408414 29.496 35.670417047370265 139.74100954503828 29.496 35.670417047370265 139.74100954503828 30.13 35.67034921374246 139.74101438408414 30.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-548be11f-8d82-4f49-9625-642e504cbad6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-548be11f-8d82-4f49-9625-642e504cbad6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-548be11f-8d82-4f49-9625-642e504cbad6">
											<gml:posList>35.670428763482214 139.7410896059309 30.13 35.670428763482214 139.7410896059309 29.496 35.670353025239315 139.74109500631627 29.496 35.670353025239315 139.74109500631627 30.13 35.670428763482214 139.7410896059309 30.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-03eee14a-da73-4c7e-a5db-7a8666b5bf15">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-03eee14a-da73-4c7e-a5db-7a8666b5bf15">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-03eee14a-da73-4c7e-a5db-7a8666b5bf15">
											<gml:posList>35.670348937299025 139.74110061147053 30.13 35.670348937299025 139.74110061147053 8.942 35.67043333728134 139.7410946156739 8.942 35.67043333728134 139.7410946156739 30.13 35.670348937299025 139.74110061147053 30.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5741302d-1a74-4bed-9313-6e5dde9c5dd9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5741302d-1a74-4bed-9313-6e5dde9c5dd9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5741302d-1a74-4bed-9313-6e5dde9c5dd9">
											<gml:posList>35.670417047370265 139.74100954503828 30.13 35.670417047370265 139.74100954503828 29.496 35.67041857753235 139.741041986156 29.496 35.67041857753235 139.741041986156 30.13 35.670417047370265 139.74100954503828 30.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a0bdb461-151e-4cac-bdc0-301f705f060a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a0bdb461-151e-4cac-bdc0-301f705f060a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a0bdb461-151e-4cac-bdc0-301f705f060a">
											<gml:posList>35.670421126292545 139.74100393988502 8.942 35.670421126292545 139.74100393988502 30.13 35.67042265645614 139.74103638100425 30.13 35.67042265645614 139.74103638100425 8.942 35.670421126292545 139.74100393988502 8.942</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3a30558e-21da-44ab-8b8b-663daa0222b8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3a30558e-21da-44ab-8b8b-663daa0222b8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3a30558e-21da-44ab-8b8b-663daa0222b8">
											<gml:posList>35.67041857753235 139.741041986156 30.13 35.67041857753235 139.741041986156 29.496 35.67042648216084 139.7410414468363 29.496 35.67042648216084 139.7410414468363 30.13 35.67041857753235 139.741041986156 30.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c672868e-6efe-4cc5-9579-7436f8fe20bc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c672868e-6efe-4cc5-9579-7436f8fe20bc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c672868e-6efe-4cc5-9579-7436f8fe20bc">
											<gml:posList>35.67042265645614 139.74103638100425 8.942 35.67042265645614 139.74103638100425 30.13 35.67043056106767 139.74103581959147 30.13 35.67043056106767 139.74103581959147 8.942 35.67042265645614 139.74103638100425 8.942</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-83550973-7221-4d7a-934f-ae728c191bac">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-83550973-7221-4d7a-934f-ae728c191bac">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-83550973-7221-4d7a-934f-ae728c191bac">
											<gml:posList>35.67042648216084 139.7410414468363 30.13 35.67042648216084 139.7410414468363 29.496 35.670428763482214 139.7410896059309 29.496 35.670428763482214 139.7410896059309 30.13 35.67042648216084 139.7410414468363 30.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-bb174dcf-3bb7-4d25-9561-c70ae026e5af">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bb174dcf-3bb7-4d25-9561-c70ae026e5af">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bb174dcf-3bb7-4d25-9561-c70ae026e5af">
											<gml:posList>35.67043333728134 139.7410946156739 30.13 35.67043333728134 139.7410946156739 8.942 35.67043056106767 139.74103581959147 8.942 35.67043056106767 139.74103581959147 30.13 35.67043333728134 139.7410946156739 30.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-5617</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">167.65994</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1210</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>7</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.02</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">2</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>