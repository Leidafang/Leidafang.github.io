<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_2844695d-c670-403e-9b00-194ee78938c9">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001001</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">422</bldg:usage>
			<bldg:measuredHeight uom="m">9.2</bldg:measuredHeight>
			<bldg:storeysAboveGround>3</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.66775927187053 139.7424972513292 0 35.66772707811456 139.7424777365665 0 35.667712953143834 139.74251298896718 0 35.667697893387626 139.7425039483944 0 35.6676833186389 139.74254041633458 0 35.66767583383052 139.74253589599584 0 35.66765936968592 139.7425770053304 0 35.66771410798127 139.74261008105304 0 35.66775927187053 139.7424972513292 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66775927187053 139.7424972513292 28.57 35.66771410798127 139.74261008105304 28.57 35.66765936968592 139.7425770053304 28.57 35.66767583383052 139.74253589599584 28.57 35.6676833186389 139.74254041633458 28.57 35.667697893387626 139.7425039483944 28.57 35.667712953143834 139.74251298896718 28.57 35.66772707811456 139.7424777365665 28.57 35.66775927187053 139.7424972513292 28.57</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66775927187053 139.7424972513292 28.57 35.66772707811456 139.7424777365665 28.57 35.66772707811456 139.7424777365665 37.79 35.66775927187053 139.7424972513292 37.79 35.66775927187053 139.7424972513292 28.57</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66772707811456 139.7424777365665 28.57 35.667712953143834 139.74251298896718 28.57 35.667712953143834 139.74251298896718 37.79 35.66772707811456 139.7424777365665 37.79 35.66772707811456 139.7424777365665 28.57</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667712953143834 139.74251298896718 28.57 35.667697893387626 139.7425039483944 28.57 35.667697893387626 139.7425039483944 37.79 35.667712953143834 139.74251298896718 37.79 35.667712953143834 139.74251298896718 28.57</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667697893387626 139.7425039483944 28.57 35.6676833186389 139.74254041633458 28.57 35.6676833186389 139.74254041633458 37.79 35.667697893387626 139.7425039483944 37.79 35.667697893387626 139.7425039483944 28.57</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6676833186389 139.74254041633458 28.57 35.66767583383052 139.74253589599584 28.57 35.66767583383052 139.74253589599584 37.79 35.6676833186389 139.74254041633458 37.79 35.6676833186389 139.74254041633458 28.57</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66767583383052 139.74253589599584 28.57 35.66765936968592 139.7425770053304 28.57 35.66765936968592 139.7425770053304 37.79 35.66767583383052 139.74253589599584 37.79 35.66767583383052 139.74253589599584 28.57</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66765936968592 139.7425770053304 28.57 35.66771410798127 139.74261008105304 28.57 35.66771410798127 139.74261008105304 37.79 35.66765936968592 139.7425770053304 37.79 35.66765936968592 139.7425770053304 28.57</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66771410798127 139.74261008105304 28.57 35.66775927187053 139.7424972513292 28.57 35.66775927187053 139.7424972513292 37.79 35.66771410798127 139.74261008105304 37.79 35.66771410798127 139.74261008105304 28.57</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66775927187053 139.7424972513292 37.79 35.66772707811456 139.7424777365665 37.79 35.667712953143834 139.74251298896718 37.79 35.667697893387626 139.7425039483944 37.79 35.6676833186389 139.74254041633458 37.79 35.66767583383052 139.74253589599584 37.79 35.66765936968592 139.7425770053304 37.79 35.66771410798127 139.74261008105304 37.79 35.66775927187053 139.7424972513292 37.79</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-66b4840a-f6a9-4b13-a6f8-219d4d6e9d86"/>
							<gml:surfaceMember xlink:href="#poly-92d472bc-90c8-412b-9258-db19743b7d0d"/>
							<gml:surfaceMember xlink:href="#poly-e215cfa2-9102-4775-bebd-b012a20510c1"/>
							<gml:surfaceMember xlink:href="#poly-24be71ca-ada4-4a23-b913-6b59af4952ff"/>
							<gml:surfaceMember xlink:href="#poly-1940fc32-c0b7-43b6-b2be-5e593fa12abc"/>
							<gml:surfaceMember xlink:href="#poly-f0976dcc-4c0f-4fca-9656-288b527afdda"/>
							<gml:surfaceMember xlink:href="#poly-9a5dc0f4-87d2-48c8-9196-f0f611703701"/>
							<gml:surfaceMember xlink:href="#poly-9b6438a7-843d-45c1-9c96-b4441a4552f3"/>
							<gml:surfaceMember xlink:href="#poly-58ca9be6-159a-405b-8a09-8efb6602a888"/>
							<gml:surfaceMember xlink:href="#poly-551b9828-5b1d-4629-a1ef-729527b1ad2a"/>
							<gml:surfaceMember xlink:href="#poly-99905e0d-1736-4916-8657-65a6f217cf73"/>
							<gml:surfaceMember xlink:href="#poly-936e5e40-3ca0-4db8-b8c4-574644713e9e"/>
							<gml:surfaceMember xlink:href="#poly-228e221c-796a-48ad-8f66-670d28ccf1a3"/>
							<gml:surfaceMember xlink:href="#poly-db0ab02b-b8a6-4270-b39a-ffde370a81f8"/>
							<gml:surfaceMember xlink:href="#poly-034607c5-13f2-4c3f-9a84-52989fe7e034"/>
							<gml:surfaceMember xlink:href="#poly-727fb369-0d2b-47d5-84f4-e2b62037d806"/>
							<gml:surfaceMember xlink:href="#poly-3ab99f12-0ae0-47a9-bbf8-71bf4f6da615"/>
							<gml:surfaceMember xlink:href="#poly-2a7dec99-e8cb-4165-be5e-281ae2bc9933"/>
							<gml:surfaceMember xlink:href="#poly-67343a8b-21cf-4bc4-be55-6d59b45364a0"/>
							<gml:surfaceMember xlink:href="#poly-06589fbf-51d9-4bc3-a292-3012ab10384d"/>
							<gml:surfaceMember xlink:href="#poly-66122e4f-ba6d-444c-b45a-5c96e0457585"/>
							<gml:surfaceMember xlink:href="#poly-4af20680-1d10-4dc5-a38c-fee2debc0bb6"/>
							<gml:surfaceMember xlink:href="#poly-b9a87ec6-c3a6-4ffe-b888-cf2cca1bce77"/>
							<gml:surfaceMember xlink:href="#poly-594daef0-8540-4afa-9857-b1e18bf31b43"/>
							<gml:surfaceMember xlink:href="#poly-bf658117-f373-488e-a48f-e9f9c731a6f6"/>
							<gml:surfaceMember xlink:href="#poly-f83b9153-8a48-4d13-a0a3-1060348550e6"/>
							<gml:surfaceMember xlink:href="#poly-a3bcf2d6-650b-4a94-945a-c6d07eedec9d"/>
							<gml:surfaceMember xlink:href="#poly-3c29c0ad-3fc3-4336-aa9a-5f9c50d15b85"/>
							<gml:surfaceMember xlink:href="#poly-bbe822a3-b8d5-4778-992a-bce224fd4615"/>
							<gml:surfaceMember xlink:href="#poly-c4f3bf6e-c58c-4f47-9f1d-9e1090a4aa63"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_2844695d-c670-403e-9b00-194ee78938c9_BuildingInstallation_1041">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c999bf2d-c666-4af2-9612-d644e29a183c">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667729800988425 139.742490646132 37.979 35.66774942259971 139.74250088554103 37.979 35.66774182250414 139.7425227760706 37.979 35.6677222008947 139.74251253665716 37.979 35.667729800988425 139.742490646132 37.979</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e166a794-b62f-48c7-b2af-6bdd1f557d8b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e166a794-b62f-48c7-b2af-6bdd1f557d8b_0">
											<gml:posList>35.6677222008947 139.74251253665716 37.979 35.6677222008947 139.74251253665716 40.429 35.667729800988425 139.742490646132 40.429 35.667729800988425 139.742490646132 37.979 35.6677222008947 139.74251253665716 37.979</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-330496b3-dcfa-489b-92a9-05d2ddc4225e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-330496b3-dcfa-489b-92a9-05d2ddc4225e_0">
											<gml:posList>35.66774182250414 139.7425227760706 37.979 35.66774182250414 139.7425227760706 40.429 35.6677222008947 139.74251253665716 40.429 35.6677222008947 139.74251253665716 37.979 35.66774182250414 139.7425227760706 37.979</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-545150cb-ddfe-4250-a162-abaab190bfec">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-545150cb-ddfe-4250-a162-abaab190bfec_0">
											<gml:posList>35.66774182250414 139.7425227760706 40.429 35.66774942259971 139.74250088554103 40.429 35.667729800988425 139.742490646132 40.429 35.6677222008947 139.74251253665716 40.429 35.66774182250414 139.7425227760706 40.429</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1fb6fc58-bf9f-4ac4-b55e-95cebfea926d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1fb6fc58-bf9f-4ac4-b55e-95cebfea926d_0">
											<gml:posList>35.667729800988425 139.742490646132 37.979 35.667729800988425 139.742490646132 40.429 35.66774942259971 139.74250088554103 40.429 35.66774942259971 139.74250088554103 37.979 35.667729800988425 139.742490646132 37.979</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5515c30c-2e93-4d63-b546-065952bd333f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5515c30c-2e93-4d63-b546-065952bd333f_0">
											<gml:posList>35.66774942259971 139.74250088554103 37.979 35.66774942259971 139.74250088554103 40.429 35.66774182250414 139.7425227760706 40.429 35.66774182250414 139.7425227760706 37.979 35.66774942259971 139.74250088554103 37.979</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_2844695d-c670-403e-9b00-194ee78938c9_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6f67f0dd-2317-4ad9-9b77-cb7a53bc7f4c">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667727329268246 139.74257172579553 37.979 35.66772280236236 139.74256905781326 37.979 35.66773810590718 139.7425308327376 37.979 35.66774263280558 139.74253348967233 37.979 35.667727329268246 139.74257172579553 37.979</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2fa227ad-042a-4fb8-afb5-a57ffe7163a7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66774263280558 139.74253348967233 38.7 35.667744183857955 139.74253440472535 38.7 35.66772888032034 139.74257264084912 38.7 35.667727329268246 139.74257172579553 38.7 35.66774263280558 139.74253348967233 38.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-60bf0824-9dac-4cc2-b5dc-611598dc9a2c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-60bf0824-9dac-4cc2-b5dc-611598dc9a2c_0">
											<gml:posList>35.66773810590718 139.7425308327376 37.979 35.66773810590718 139.7425308327376 40.289 35.667744183857955 139.74253440472535 40.289 35.667744183857955 139.74253440472535 38.7 35.66774263280558 139.74253348967233 38.7 35.66774263280558 139.74253348967233 37.979 35.66773810590718 139.7425308327376 37.979</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2a6a5680-2c48-4852-935f-f247393a7bb2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2a6a5680-2c48-4852-935f-f247393a7bb2_0">
											<gml:posList>35.66772280236236 139.74256905781326 37.979 35.66772280236236 139.74256905781326 40.289 35.66773810590718 139.7425308327376 40.289 35.66773810590718 139.7425308327376 37.979 35.66772280236236 139.74256905781326 37.979</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f69685c2-7fa8-4bf1-8c29-46bb2604fff6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f69685c2-7fa8-4bf1-8c29-46bb2604fff6_0">
											<gml:posList>35.66773810590718 139.7425308327376 40.289 35.66772280236236 139.74256905781326 40.289 35.66772888032034 139.74257264084912 40.289 35.667744183857955 139.74253440472535 40.289 35.66773810590718 139.7425308327376 40.289</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-31c7f2b4-da5b-45b1-945b-49570f866431">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-31c7f2b4-da5b-45b1-945b-49570f866431_0">
											<gml:posList>35.66774263280558 139.74253348967233 38.7 35.667727329268246 139.74257172579553 38.7 35.667727329268246 139.74257172579553 37.979 35.66774263280558 139.74253348967233 37.979 35.66774263280558 139.74253348967233 38.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4b360e9c-5b45-4635-b46e-1fe634050c99">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4b360e9c-5b45-4635-b46e-1fe634050c99_0">
											<gml:posList>35.667744183857955 139.74253440472535 38.7 35.667744183857955 139.74253440472535 40.289 35.66772888032034 139.74257264084912 40.289 35.66772888032034 139.74257264084912 38.7 35.667744183857955 139.74253440472535 38.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8ec5382c-c561-4325-8829-62b42d5e7ee8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8ec5382c-c561-4325-8829-62b42d5e7ee8_0">
											<gml:posList>35.667727329268246 139.74257172579553 38.7 35.66772888032034 139.74257264084912 38.7 35.66772888032034 139.74257264084912 40.289 35.66772280236236 139.74256905781326 40.289 35.66772280236236 139.74256905781326 37.979 35.667727329268246 139.74257172579553 37.979 35.667727329268246 139.74257172579553 38.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-66b4840a-f6a9-4b13-a6f8-219d4d6e9d86">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-66b4840a-f6a9-4b13-a6f8-219d4d6e9d86">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-66b4840a-f6a9-4b13-a6f8-219d4d6e9d86">
											<gml:posList>35.6677592718705 139.7424972513292 28.57 35.667714107981254 139.74261008105304 28.57 35.66765936968594 139.7425770053304 28.57 35.66767583383051 139.74253589599581 28.57 35.66768331863889 139.74254041633458 28.57 35.66769789338761 139.7425039483944 28.57 35.66771295314383 139.74251298896718 28.57 35.667727078114545 139.74247773656649 28.57 35.6677592718705 139.7424972513292 28.57</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-92d472bc-90c8-412b-9258-db19743b7d0d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-92d472bc-90c8-412b-9258-db19743b7d0d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-92d472bc-90c8-412b-9258-db19743b7d0d">
											<gml:posList>35.667670001715464 139.74258342200258 38.7 35.66767257883399 139.74258234763494 38.7 35.66768543537126 139.7425503883751 38.7 35.66768456764674 139.74254719709577 38.7 35.667670001715464 139.74258342200258 38.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e215cfa2-9102-4775-bebd-b012a20510c1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e215cfa2-9102-4775-bebd-b012a20510c1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e215cfa2-9102-4775-bebd-b012a20510c1">
											<gml:posList>35.66770811959495 139.74251008937233 35.8 35.66769789338761 139.7425039483944 35.8 35.66768331863889 139.74254041633458 35.8 35.66767583383051 139.74253589599581 35.8 35.66765936968594 139.7425770053304 35.8 35.667670001715464 139.74258342200258 35.8 35.66768456764674 139.74254719709577 35.8 35.66769152056984 139.74255161862527 35.8 35.66770811959495 139.74251008937233 35.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-24be71ca-ada4-4a23-b913-6b59af4952ff">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-24be71ca-ada4-4a23-b913-6b59af4952ff">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-24be71ca-ada4-4a23-b913-6b59af4952ff">
											<gml:posList>35.66769152056984 139.74255161862527 38.7 35.66768456764674 139.74254719709577 38.7 35.66768543537126 139.7425503883751 38.7 35.66769238830257 139.74255482095077 38.7 35.66769152056984 139.74255161862527 38.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-1940fc32-c0b7-43b6-b2be-5e593fa12abc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1940fc32-c0b7-43b6-b2be-5e593fa12abc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1940fc32-c0b7-43b6-b2be-5e593fa12abc">
											<gml:posList>35.667714107981254 139.74261008105304 38.7 35.66771323127788 139.7426069339657 38.7 35.66767257883399 139.74258234763494 38.7 35.667670001715464 139.74258342200258 38.7 35.667714107981254 139.74261008105304 38.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f0976dcc-4c0f-4fca-9656-288b527afdda">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f0976dcc-4c0f-4fca-9656-288b527afdda">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f0976dcc-4c0f-4fca-9656-288b527afdda">
											<gml:posList>35.66769152056984 139.74255161862527 38.7 35.66769238830257 139.74255482095077 38.7 35.66770900532291 139.7425132474941 38.7 35.66770811959495 139.74251008937233 38.7 35.66769152056984 139.74255161862527 38.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-9a5dc0f4-87d2-48c8-9196-f0f611703701">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9a5dc0f4-87d2-48c8-9196-f0f611703701">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9a5dc0f4-87d2-48c8-9196-f0f611703701">
											<gml:posList>35.66771295314383 139.74251298896718 38.7 35.66770811959495 139.74251008937233 38.7 35.66770900532291 139.7425132474941 38.7 35.66771382985799 139.7425161470994 38.7 35.66771295314383 139.74251298896718 38.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-9b6438a7-843d-45c1-9c96-b4441a4552f3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9b6438a7-843d-45c1-9c96-b4441a4552f3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9b6438a7-843d-45c1-9c96-b4441a4552f3">
											<gml:posList>35.66771382985799 139.7425161470994 37.979 35.66770900532291 139.7425132474941 37.979 35.66769238830257 139.74255482095077 37.979 35.66768543537126 139.7425503883751 37.979 35.66767257883399 139.74258234763494 37.979 35.66771323127788 139.7426069339657 37.979 35.66775670377485 139.74249833673645 37.979 35.667727954837964 139.74248090574477 37.979 35.66771382985799 139.7425161470994 37.979</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-58ca9be6-159a-405b-8a09-8efb6602a888">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-58ca9be6-159a-405b-8a09-8efb6602a888">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-58ca9be6-159a-405b-8a09-8efb6602a888">
											<gml:posList>35.66771295314383 139.74251298896718 38.7 35.66771382985799 139.7425161470994 38.7 35.667727954837964 139.74248090574477 38.7 35.667727078114545 139.74247773656649 38.7 35.66771295314383 139.74251298896718 38.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-551b9828-5b1d-4629-a1ef-729527b1ad2a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-551b9828-5b1d-4629-a1ef-729527b1ad2a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-551b9828-5b1d-4629-a1ef-729527b1ad2a">
											<gml:posList>35.6677592718705 139.7424972513292 38.7 35.66775670377485 139.74249833673645 38.7 35.66771323127788 139.7426069339657 38.7 35.667714107981254 139.74261008105304 38.7 35.6677592718705 139.7424972513292 38.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-99905e0d-1736-4916-8657-65a6f217cf73">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-99905e0d-1736-4916-8657-65a6f217cf73">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-99905e0d-1736-4916-8657-65a6f217cf73">
											<gml:posList>35.667727078114545 139.74247773656649 38.7 35.667727954837964 139.74248090574477 38.7 35.66775670377485 139.74249833673645 38.7 35.6677592718705 139.7424972513292 38.7 35.667727078114545 139.74247773656649 38.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-936e5e40-3ca0-4db8-b8c4-574644713e9e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-936e5e40-3ca0-4db8-b8c4-574644713e9e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-936e5e40-3ca0-4db8-b8c4-574644713e9e">
											<gml:posList>35.66771382985799 139.7425161470994 38.7 35.66771382985799 139.7425161470994 37.979 35.667727954837964 139.74248090574477 37.979 35.667727954837964 139.74248090574477 38.7 35.66771382985799 139.7425161470994 38.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-228e221c-796a-48ad-8f66-670d28ccf1a3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-228e221c-796a-48ad-8f66-670d28ccf1a3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-228e221c-796a-48ad-8f66-670d28ccf1a3">
											<gml:posList>35.6677592718705 139.7424972513292 28.57 35.667727078114545 139.74247773656649 28.57 35.667727078114545 139.74247773656649 38.7 35.6677592718705 139.7424972513292 38.7 35.6677592718705 139.7424972513292 28.57</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-db0ab02b-b8a6-4270-b39a-ffde370a81f8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-db0ab02b-b8a6-4270-b39a-ffde370a81f8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-db0ab02b-b8a6-4270-b39a-ffde370a81f8">
											<gml:posList>35.667727954837964 139.74248090574477 38.7 35.667727954837964 139.74248090574477 37.979 35.66775670377485 139.74249833673645 37.979 35.66775670377485 139.74249833673645 38.7 35.667727954837964 139.74248090574477 38.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-034607c5-13f2-4c3f-9a84-52989fe7e034">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-034607c5-13f2-4c3f-9a84-52989fe7e034">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-034607c5-13f2-4c3f-9a84-52989fe7e034">
											<gml:posList>35.667727078114545 139.74247773656649 28.57 35.66771295314383 139.74251298896718 28.57 35.66771295314383 139.74251298896718 38.7 35.667727078114545 139.74247773656649 38.7 35.667727078114545 139.74247773656649 28.57</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-727fb369-0d2b-47d5-84f4-e2b62037d806">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-727fb369-0d2b-47d5-84f4-e2b62037d806">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-727fb369-0d2b-47d5-84f4-e2b62037d806">
											<gml:posList>35.66769789338761 139.7425039483944 28.57 35.66769789338761 139.7425039483944 35.8 35.66770811959495 139.74251008937233 35.8 35.66770811959495 139.74251008937233 38.7 35.66771295314383 139.74251298896718 38.7 35.66771295314383 139.74251298896718 28.57 35.66769789338761 139.7425039483944 28.57</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3ab99f12-0ae0-47a9-bbf8-71bf4f6da615">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3ab99f12-0ae0-47a9-bbf8-71bf4f6da615">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3ab99f12-0ae0-47a9-bbf8-71bf4f6da615">
											<gml:posList>35.66770900532291 139.7425132474941 38.7 35.66770900532291 139.7425132474941 37.979 35.66771382985799 139.7425161470994 37.979 35.66771382985799 139.7425161470994 38.7 35.66770900532291 139.7425132474941 38.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2a7dec99-e8cb-4165-be5e-281ae2bc9933">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2a7dec99-e8cb-4165-be5e-281ae2bc9933">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2a7dec99-e8cb-4165-be5e-281ae2bc9933">
											<gml:posList>35.66769789338761 139.7425039483944 28.57 35.66768331863889 139.74254041633458 28.57 35.66768331863889 139.74254041633458 35.8 35.66769789338761 139.7425039483944 35.8 35.66769789338761 139.7425039483944 28.57</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-67343a8b-21cf-4bc4-be55-6d59b45364a0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-67343a8b-21cf-4bc4-be55-6d59b45364a0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-67343a8b-21cf-4bc4-be55-6d59b45364a0">
											<gml:posList>35.66769152056984 139.74255161862527 35.8 35.66769152056984 139.74255161862527 38.7 35.66770811959495 139.74251008937233 38.7 35.66770811959495 139.74251008937233 35.8 35.66769152056984 139.74255161862527 35.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-06589fbf-51d9-4bc3-a292-3012ab10384d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-06589fbf-51d9-4bc3-a292-3012ab10384d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-06589fbf-51d9-4bc3-a292-3012ab10384d">
											<gml:posList>35.66769238830257 139.74255482095077 38.7 35.66769238830257 139.74255482095077 37.979 35.66770900532291 139.7425132474941 37.979 35.66770900532291 139.7425132474941 38.7 35.66769238830257 139.74255482095077 38.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-66122e4f-ba6d-444c-b45a-5c96e0457585">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-66122e4f-ba6d-444c-b45a-5c96e0457585">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-66122e4f-ba6d-444c-b45a-5c96e0457585">
											<gml:posList>35.66768331863889 139.74254041633458 28.57 35.66767583383051 139.74253589599581 28.57 35.66767583383051 139.74253589599581 35.8 35.66768331863889 139.74254041633458 35.8 35.66768331863889 139.74254041633458 28.57</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4af20680-1d10-4dc5-a38c-fee2debc0bb6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4af20680-1d10-4dc5-a38c-fee2debc0bb6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4af20680-1d10-4dc5-a38c-fee2debc0bb6">
											<gml:posList>35.66768456764674 139.74254719709577 35.8 35.66768456764674 139.74254719709577 38.7 35.66769152056984 139.74255161862527 38.7 35.66769152056984 139.74255161862527 35.8 35.66768456764674 139.74254719709577 35.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b9a87ec6-c3a6-4ffe-b888-cf2cca1bce77">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b9a87ec6-c3a6-4ffe-b888-cf2cca1bce77">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b9a87ec6-c3a6-4ffe-b888-cf2cca1bce77">
											<gml:posList>35.66768543537126 139.7425503883751 38.7 35.66768543537126 139.7425503883751 37.979 35.66769238830257 139.74255482095077 37.979 35.66769238830257 139.74255482095077 38.7 35.66768543537126 139.7425503883751 38.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-594daef0-8540-4afa-9857-b1e18bf31b43">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-594daef0-8540-4afa-9857-b1e18bf31b43">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-594daef0-8540-4afa-9857-b1e18bf31b43">
											<gml:posList>35.66775670377485 139.74249833673645 38.7 35.66775670377485 139.74249833673645 37.979 35.66771323127788 139.7426069339657 37.979 35.66771323127788 139.7426069339657 38.7 35.66775670377485 139.74249833673645 38.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-bf658117-f373-488e-a48f-e9f9c731a6f6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bf658117-f373-488e-a48f-e9f9c731a6f6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bf658117-f373-488e-a48f-e9f9c731a6f6">
											<gml:posList>35.6677592718705 139.7424972513292 38.7 35.667714107981254 139.74261008105304 38.7 35.667714107981254 139.74261008105304 28.57 35.6677592718705 139.7424972513292 28.57 35.6677592718705 139.7424972513292 38.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f83b9153-8a48-4d13-a0a3-1060348550e6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f83b9153-8a48-4d13-a0a3-1060348550e6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f83b9153-8a48-4d13-a0a3-1060348550e6">
											<gml:posList>35.66767583383051 139.74253589599581 28.57 35.66765936968594 139.7425770053304 28.57 35.66765936968594 139.7425770053304 35.8 35.66767583383051 139.74253589599581 35.8 35.66767583383051 139.74253589599581 28.57</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a3bcf2d6-650b-4a94-945a-c6d07eedec9d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a3bcf2d6-650b-4a94-945a-c6d07eedec9d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a3bcf2d6-650b-4a94-945a-c6d07eedec9d">
											<gml:posList>35.667670001715464 139.74258342200258 35.8 35.667670001715464 139.74258342200258 38.7 35.66768456764674 139.74254719709577 38.7 35.66768456764674 139.74254719709577 35.8 35.667670001715464 139.74258342200258 35.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3c29c0ad-3fc3-4336-aa9a-5f9c50d15b85">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3c29c0ad-3fc3-4336-aa9a-5f9c50d15b85">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3c29c0ad-3fc3-4336-aa9a-5f9c50d15b85">
											<gml:posList>35.66767257883399 139.74258234763494 38.7 35.66767257883399 139.74258234763494 37.979 35.66768543537126 139.7425503883751 37.979 35.66768543537126 139.7425503883751 38.7 35.66767257883399 139.74258234763494 38.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-bbe822a3-b8d5-4778-992a-bce224fd4615">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bbe822a3-b8d5-4778-992a-bce224fd4615">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bbe822a3-b8d5-4778-992a-bce224fd4615">
											<gml:posList>35.667714107981254 139.74261008105304 28.57 35.667714107981254 139.74261008105304 38.7 35.667670001715464 139.74258342200258 38.7 35.667670001715464 139.74258342200258 35.8 35.66765936968594 139.7425770053304 35.8 35.66765936968594 139.7425770053304 28.57 35.667714107981254 139.74261008105304 28.57</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c4f3bf6e-c58c-4f47-9f1d-9e1090a4aa63">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c4f3bf6e-c58c-4f47-9f1d-9e1090a4aa63">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c4f3bf6e-c58c-4f47-9f1d-9e1090a4aa63">
											<gml:posList>35.66771323127788 139.7426069339657 38.7 35.66771323127788 139.7426069339657 37.979 35.66767257883399 139.74258234763494 37.979 35.66767257883399 139.74258234763494 38.7 35.66771323127788 139.7426069339657 38.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂一丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-7051</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">63.74195</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1003</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">6</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">214</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1123</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.6</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>4</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.06</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">21</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>