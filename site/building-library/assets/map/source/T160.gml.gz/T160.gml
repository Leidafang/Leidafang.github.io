<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_2948178b-9330-4f5c-8414-a89a5d859d77">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>3</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001003</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">402</bldg:usage>
			<bldg:measuredHeight uom="m">19.9</bldg:measuredHeight>
			<bldg:storeysAboveGround>5</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.6735172048136 139.73813081939514 0 35.67341227939943 139.7377823108725 0 35.67329028019752 139.73784111404538 0 35.673342065343476 139.73801338037163 0 35.67339718584213 139.73818630576258 0 35.6735172048136 139.73813081939514 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6735172048136 139.73813081939514 8.64 35.67339718584213 139.73818630576258 8.64 35.673342065343476 139.73801338037163 8.64 35.67329028019752 139.73784111404538 8.64 35.67341227939943 139.7377823108725 8.64 35.6735172048136 139.73813081939514 8.64</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6735172048136 139.73813081939514 8.64 35.67341227939943 139.7377823108725 8.64 35.67341227939943 139.7377823108725 28.51 35.6735172048136 139.73813081939514 28.51 35.6735172048136 139.73813081939514 8.64</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67341227939943 139.7377823108725 8.64 35.67329028019752 139.73784111404538 8.64 35.67329028019752 139.73784111404538 28.51 35.67341227939943 139.7377823108725 28.51 35.67341227939943 139.7377823108725 8.64</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67329028019752 139.73784111404538 8.64 35.673342065343476 139.73801338037163 8.64 35.673342065343476 139.73801338037163 28.51 35.67329028019752 139.73784111404538 28.51 35.67329028019752 139.73784111404538 8.64</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.673342065343476 139.73801338037163 8.64 35.67339718584213 139.73818630576258 8.64 35.67339718584213 139.73818630576258 28.51 35.673342065343476 139.73801338037163 28.51 35.673342065343476 139.73801338037163 8.64</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67339718584213 139.73818630576258 8.64 35.6735172048136 139.73813081939514 8.64 35.6735172048136 139.73813081939514 28.51 35.67339718584213 139.73818630576258 28.51 35.67339718584213 139.73818630576258 8.64</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6735172048136 139.73813081939514 28.51 35.67341227939943 139.7377823108725 28.51 35.67329028019752 139.73784111404538 28.51 35.673342065343476 139.73801338037163 28.51 35.67339718584213 139.73818630576258 28.51 35.6735172048136 139.73813081939514 28.51</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-b6852cb3-562f-418c-9054-dfb40899e8bd"/>
							<gml:surfaceMember xlink:href="#poly-79b01cb5-e0c7-4206-96ff-3ac0dc0c0bc6"/>
							<gml:surfaceMember xlink:href="#poly-7fd83b4e-3e61-41a2-9b35-3abb7de59d6b"/>
							<gml:surfaceMember xlink:href="#poly-fadd5334-d635-49e2-a54b-78063e42d134"/>
							<gml:surfaceMember xlink:href="#poly-0fdaf034-4913-4834-a98a-6ffa0346a576"/>
							<gml:surfaceMember xlink:href="#poly-ca38ea08-d806-47e7-9891-d8f762f9fabb"/>
							<gml:surfaceMember xlink:href="#poly-4c737b9f-962a-462c-8dd7-e70dc46ed6d6"/>
							<gml:surfaceMember xlink:href="#poly-276dc600-ef0d-4b9f-8a14-639785470453"/>
							<gml:surfaceMember xlink:href="#poly-766a7fc4-8732-4be7-ba4a-f9b36d112470"/>
							<gml:surfaceMember xlink:href="#poly-61e4bd66-f391-440c-a3fd-0f5aa35d1437"/>
							<gml:surfaceMember xlink:href="#poly-99c4529c-a9a7-4360-bad3-f90f964eed58"/>
							<gml:surfaceMember xlink:href="#poly-8d461c0a-c4e7-44fc-8965-982ded81319c"/>
							<gml:surfaceMember xlink:href="#poly-95b6548f-658a-4930-917f-912e085df8eb"/>
							<gml:surfaceMember xlink:href="#poly-50df434d-4eac-4e3e-be49-3cfc6a22c5bf"/>
							<gml:surfaceMember xlink:href="#poly-1a34db56-b4cc-47de-aaae-60986f775fa5"/>
							<gml:surfaceMember xlink:href="#poly-694f7922-c6be-49d8-86b3-3b113e618208"/>
							<gml:surfaceMember xlink:href="#poly-d9bca413-fa81-44f7-b8ce-21557424984e"/>
							<gml:surfaceMember xlink:href="#poly-795f8beb-f378-403a-b9fd-bfd91f24b397"/>
							<gml:surfaceMember xlink:href="#poly-be4299a4-7992-4671-b382-0ed49b003322"/>
							<gml:surfaceMember xlink:href="#poly-ffaf958f-ef44-4936-9c90-d715aa45167f"/>
							<gml:surfaceMember xlink:href="#poly-980c17f5-4ead-48d3-8631-631747113185"/>
							<gml:surfaceMember xlink:href="#poly-78ddba9f-09e8-456d-8ea5-988219ea50d7"/>
							<gml:surfaceMember xlink:href="#poly-5ca3c094-e7e5-4888-82cb-5f9b0789c460"/>
							<gml:surfaceMember xlink:href="#poly-a58cb88a-eccc-4730-a8f7-2adc4ef8ca92"/>
							<gml:surfaceMember xlink:href="#poly-678c2e83-fc0c-4b90-a37c-ea1141f012a8"/>
							<gml:surfaceMember xlink:href="#poly-e04b49db-6f8c-442e-a85c-e039ee501db7"/>
							<gml:surfaceMember xlink:href="#poly-623b15a8-6e1d-4efa-8525-eb02f8a47212"/>
							<gml:surfaceMember xlink:href="#poly-613b79e6-333d-49b7-be95-7296216692ac"/>
							<gml:surfaceMember xlink:href="#poly-602a5f14-ca5d-4971-980b-7f79bebaf6c2"/>
							<gml:surfaceMember xlink:href="#poly-f9f87eca-8250-4c81-b1eb-a0d0a074be08"/>
							<gml:surfaceMember xlink:href="#poly-811d3d58-f7f3-4d9e-bcd2-de3a983a5ec2"/>
							<gml:surfaceMember xlink:href="#poly-8b7a8652-896b-4a50-b69c-7ba8cca07a67"/>
							<gml:surfaceMember xlink:href="#poly-f6b8374b-3d7e-4a68-a994-56878b864bf4"/>
							<gml:surfaceMember xlink:href="#poly-5d1ee640-8d4c-4acb-9a55-8b440b877bf2"/>
							<gml:surfaceMember xlink:href="#poly-1f290844-0346-4d55-99cc-121d5ef6faaa"/>
							<gml:surfaceMember xlink:href="#poly-975eff23-ec23-42b4-8f0b-5be50c38881d"/>
							<gml:surfaceMember xlink:href="#poly-a5865fb0-a07e-437e-9fe8-ed0e28a2bba0"/>
							<gml:surfaceMember xlink:href="#poly-6e5b83fa-333d-4266-81b3-c588a7541c65"/>
							<gml:surfaceMember xlink:href="#poly-980a03ba-9743-4817-b8ae-eddd43d76d53"/>
							<gml:surfaceMember xlink:href="#poly-cedeadc9-53e1-485a-9bf7-05f084688892"/>
							<gml:surfaceMember xlink:href="#poly-4f015ec7-26af-451f-8347-c6f23a0e96fc"/>
							<gml:surfaceMember xlink:href="#poly-010ad211-5e5e-409d-9e97-73a2be01a3ba"/>
							<gml:surfaceMember xlink:href="#poly-b4c5cafb-34a4-4866-bbde-e14bbfb3397d"/>
							<gml:surfaceMember xlink:href="#poly-2cb75e11-32fe-4585-977f-4a42e8e07c9b"/>
							<gml:surfaceMember xlink:href="#poly-874321c9-3634-4550-b0f8-7f8fb59f360a"/>
							<gml:surfaceMember xlink:href="#poly-4d2547f5-a62d-4241-a690-c2632d2ac6c3"/>
							<gml:surfaceMember xlink:href="#poly-da65150e-44a5-4aab-acaa-89bb9f749e7d"/>
							<gml:surfaceMember xlink:href="#poly-c674f2e5-2277-4be7-858a-5ec53467163c"/>
							<gml:surfaceMember xlink:href="#poly-a5958912-3f82-44d6-b818-6847174de9fb"/>
							<gml:surfaceMember xlink:href="#poly-75199b7c-a3c8-4461-8820-ba77a051b052"/>
							<gml:surfaceMember xlink:href="#poly-a637c44f-3b17-4966-a659-17d2b6ddbdc8"/>
							<gml:surfaceMember xlink:href="#poly-a58fdc46-66fa-460e-a718-b6a1a1e135b2"/>
							<gml:surfaceMember xlink:href="#poly-659cd850-0228-4c6e-b658-1fde7ec1126c"/>
							<gml:surfaceMember xlink:href="#poly-9f5f57ba-65e4-462b-a4b8-eb43bb9f95ca"/>
							<gml:surfaceMember xlink:href="#poly-80938e77-b5ea-4823-bb9f-242474cc8c88"/>
							<gml:surfaceMember xlink:href="#poly-a2ea8d18-abdc-477c-917d-a64f93b6d8cc"/>
							<gml:surfaceMember xlink:href="#poly-df9dc057-8625-4985-8948-7aaaf35da862"/>
							<gml:surfaceMember xlink:href="#poly-24672cbe-2a53-4e97-b8b1-da067c18447c"/>
							<gml:surfaceMember xlink:href="#poly-27ed806f-8565-4d66-a42f-334be0d7fb86"/>
							<gml:surfaceMember xlink:href="#poly-4c028d85-86f3-4477-a5ad-1f7939d49541"/>
							<gml:surfaceMember xlink:href="#poly-e43f802d-1f1e-4830-81c4-0b81e61de735"/>
							<gml:surfaceMember xlink:href="#poly-3653307d-a698-4017-b25c-6639fde22f55"/>
							<gml:surfaceMember xlink:href="#poly-e4fe24ed-a6b2-464b-ac21-5d24bcc3322b"/>
							<gml:surfaceMember xlink:href="#poly-7efb2895-0304-4511-a947-0cb67c22bb06"/>
							<gml:surfaceMember xlink:href="#poly-2d9f633d-8b7d-46c3-ae50-6585959811aa"/>
							<gml:surfaceMember xlink:href="#poly-48e8b2d4-aeaf-404e-b1ee-7d06b2d3533e"/>
							<gml:surfaceMember xlink:href="#poly-158b0562-2ded-47fb-87ce-eb70840c1807"/>
							<gml:surfaceMember xlink:href="#poly-44c4b1ee-28a8-4781-9778-453e2bcaa8bc"/>
							<gml:surfaceMember xlink:href="#poly-a18ab6e6-be6c-407a-ae49-3a32037dcb16"/>
							<gml:surfaceMember xlink:href="#poly-400c6f1f-3039-40d0-8798-1ac0a669086b"/>
							<gml:surfaceMember xlink:href="#poly-a54d0344-5ee5-48f0-8cb0-40fffe67fc98"/>
							<gml:surfaceMember xlink:href="#poly-87cec90c-c437-47ff-ac34-2e310229fb0d"/>
							<gml:surfaceMember xlink:href="#poly-3c9b77a0-51f8-4c48-8b7f-b6df476c8d0f"/>
							<gml:surfaceMember xlink:href="#poly-a09368b6-a152-42a6-b56f-8cc97da583f4"/>
							<gml:surfaceMember xlink:href="#poly-8efbd528-f1f9-4029-aed7-d6c3223bf7e7"/>
							<gml:surfaceMember xlink:href="#poly-3fa8e460-445c-488c-8703-085d7210ba36"/>
							<gml:surfaceMember xlink:href="#poly-ad53214a-257f-4be2-bff8-4a94522e50ac"/>
							<gml:surfaceMember xlink:href="#poly-08ebb0e7-1d5e-47c3-96d2-b0902cede05b"/>
							<gml:surfaceMember xlink:href="#poly-b0ac89c9-1049-4758-97e8-d6b01bd8702d"/>
							<gml:surfaceMember xlink:href="#poly-0e481747-2d60-4f6b-b96e-4ad68e472832"/>
							<gml:surfaceMember xlink:href="#poly-e60c2494-67b3-4649-a13e-e87885d2fb09"/>
							<gml:surfaceMember xlink:href="#poly-b577034a-c725-46c0-9e5a-442514224534"/>
							<gml:surfaceMember xlink:href="#poly-3ca03861-9f05-4ecf-b61c-6e1f464aee6a"/>
							<gml:surfaceMember xlink:href="#poly-13bd4f0b-ddf2-4863-ae35-290113d748bf"/>
							<gml:surfaceMember xlink:href="#poly-1797ba14-0548-4056-9367-c5b0f57b8d34"/>
							<gml:surfaceMember xlink:href="#poly-2f51acad-0382-4283-bdd5-ab27323ed3a3"/>
							<gml:surfaceMember xlink:href="#poly-ad71abad-e8bf-411a-aa13-94bf19799b5f"/>
							<gml:surfaceMember xlink:href="#poly-c6d2e947-45cd-4cdc-83dc-8f97de7fd3bc"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_2948178b-9330-4f5c-8414-a89a5d859d77_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3254acd6-b764-4c8a-8d22-36aa5af3699a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3254acd6-b764-4c8a-8d22-36aa5af3699a_0">
											<gml:posList>35.673349810447064 139.73782292660047 31.139 35.673365035984844 139.73787009983735 28.262 35.673365035984844 139.73787009983735 31.139 35.673349810447064 139.73782292660047 31.139</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6dc9bfcc-9b0f-4fc5-84dc-9c3a7553e921">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6dc9bfcc-9b0f-4fc5-84dc-9c3a7553e921_0">
											<gml:posList>35.673349810447064 139.73782292660047 31.139 35.673349810447064 139.73782292660047 28.262 35.673365035984844 139.73787009983735 28.262 35.673349810447064 139.73782292660047 31.139</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-aebf2c0b-8856-407e-8a7e-e82ec048b6fe">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-aebf2c0b-8856-407e-8a7e-e82ec048b6fe_0">
											<gml:posList>35.673349810447064 139.73782292660047 31.139 35.673408223960145 139.73779459961023 28.262 35.673349810447064 139.73782292660047 28.262 35.673349810447064 139.73782292660047 31.139</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4e3d2315-31cb-4961-87d8-21beb6f8e9e9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4e3d2315-31cb-4961-87d8-21beb6f8e9e9_0">
											<gml:posList>35.673349810447064 139.73782292660047 31.139 35.673408223960145 139.73779459961023 31.139 35.673408223960145 139.73779459961023 28.262 35.673349810447064 139.73782292660047 31.139</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-09aafb95-efb2-4984-8827-3c917e30a346">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-09aafb95-efb2-4984-8827-3c917e30a346_0">
											<gml:posList>35.67340299621942 139.73785169506007 29.018 35.67338807522315 139.737858926309 29.993 35.67340299621942 139.73785169506007 28.262 35.67340299621942 139.73785169506007 29.018</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8c258c5c-6039-4108-bd59-e9ca37ad59a7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8c258c5c-6039-4108-bd59-e9ca37ad59a7_0">
											<gml:posList>35.67340299621942 139.73785169506007 28.262 35.67338807522315 139.737858926309 29.993 35.673365035984844 139.73787009983735 28.262 35.67340299621942 139.73785169506007 28.262</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-90311688-21d0-435b-aa28-74d7e964535e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-90311688-21d0-435b-aa28-74d7e964535e_0">
											<gml:posList>35.673365035984844 139.73787009983735 28.262 35.67338261500373 139.7378615729665 30.196 35.673365035984844 139.73787009983735 31.139 35.673365035984844 139.73787009983735 28.262</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-18b9f4c4-8674-4410-9750-0e36275caacf">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-18b9f4c4-8674-4410-9750-0e36275caacf_0">
											<gml:posList>35.67338261500373 139.7378615729665 30.196 35.67338935468053 139.73785830617152 31.139 35.673365035984844 139.73787009983735 31.139 35.67338261500373 139.7378615729665 30.196</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7a61a584-8f84-42f6-8861-867a47195f00">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7a61a584-8f84-42f6-8861-867a47195f00_0">
											<gml:posList>35.673365035984844 139.73787009983735 28.262 35.67338807522315 139.737858926309 29.993 35.67338261500373 139.7378615729665 30.196 35.673365035984844 139.73787009983735 28.262</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ead5a0ed-c6ec-4863-a8ee-2cf160a50d48">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ead5a0ed-c6ec-4863-a8ee-2cf160a50d48_0">
											<gml:posList>35.67338776231469 139.73790765355878 33.718 35.673381373996534 139.7378879538988 31.641 35.67338776231469 139.73790765355878 31.641 35.67338776231469 139.73790765355878 33.718</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2d0043d2-c33a-419f-b94d-37f288115e0b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2d0043d2-c33a-419f-b94d-37f288115e0b_0">
											<gml:posList>35.67338776231469 139.73790765355878 33.718 35.673381373996534 139.7378879538988 33.718 35.673381373996534 139.7378879538988 31.641 35.67338776231469 139.73790765355878 33.718</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fe22480a-67df-45cb-aa9a-85483fd4e8e7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fe22480a-67df-45cb-aa9a-85483fd4e8e7_0">
											<gml:posList>35.6733884560552 139.73788450995167 33.718 35.673381373996534 139.7378879538988 31.641 35.673381373996534 139.7378879538988 33.718 35.6733884560552 139.73788450995167 33.718</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e55d9bfd-8518-48b3-9c29-ad317f3dda6f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e55d9bfd-8518-48b3-9c29-ad317f3dda6f_0">
											<gml:posList>35.6733884560552 139.73788450995167 33.718 35.6733884560552 139.73788450995167 31.641 35.673381373996534 139.7378879538988 31.641 35.6733884560552 139.73788450995167 33.718</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d12691da-a19f-4aa3-837c-ae89f208d5b2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d12691da-a19f-4aa3-837c-ae89f208d5b2_0">
											<gml:posList>35.67338935468053 139.73785830617152 31.139 35.673408223960145 139.73779459961023 31.139 35.673349810447064 139.73782292660047 31.139 35.67338935468053 139.73785830617152 31.139</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-134ae8ed-affb-40dc-a2d5-2262cd9e15f4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-134ae8ed-affb-40dc-a2d5-2262cd9e15f4_0">
											<gml:posList>35.673349810447064 139.73782292660047 31.139 35.673365035984844 139.73787009983735 31.139 35.67338935468053 139.73785830617152 31.139 35.673349810447064 139.73782292660047 31.139</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1527d50b-b885-4ea9-a0cd-9891c5e66bd3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1527d50b-b885-4ea9-a0cd-9891c5e66bd3_0">
											<gml:posList>35.67342344950891 139.73784177287607 31.139 35.673408223960145 139.73779459961023 31.139 35.67338935468053 139.73785830617152 31.139 35.67342344950891 139.73784177287607 31.139</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-50f128ef-98a7-4305-b8b8-bb5677c47343">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-50f128ef-98a7-4305-b8b8-bb5677c47343_0">
											<gml:posList>35.67338776231469 139.73790765355878 33.718 35.6733884560552 139.73788450995167 33.718 35.673381373996534 139.7378879538988 33.718 35.67338776231469 139.73790765355878 33.718</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2057bbe7-92aa-42d9-94e8-bd1f319f01d5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2057bbe7-92aa-42d9-94e8-bd1f319f01d5_0">
											<gml:posList>35.67338776231469 139.73790765355878 33.718 35.67339484436517 139.73790419856647 33.718 35.6733884560552 139.73788450995167 33.718 35.67338776231469 139.73790765355878 33.718</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0a4cc843-31e8-4ca2-991c-f537ed2cb1f7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0a4cc843-31e8-4ca2-991c-f537ed2cb1f7_0">
											<gml:posList>35.6733884560552 139.73788450995167 33.718 35.67339484436517 139.73790419856647 31.641 35.6733884560552 139.73788450995167 31.641 35.6733884560552 139.73788450995167 33.718</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3431bc53-4fdb-491a-babe-38b6893860c8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3431bc53-4fdb-491a-babe-38b6893860c8_0">
											<gml:posList>35.6733884560552 139.73788450995167 33.718 35.67339484436517 139.73790419856647 33.718 35.67339484436517 139.73790419856647 31.641 35.6733884560552 139.73788450995167 33.718</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e3e782ef-54fb-4d50-a0c4-953144f2a7f4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e3e782ef-54fb-4d50-a0c4-953144f2a7f4_0">
											<gml:posList>35.67342344950891 139.73784177287607 28.262 35.673408223960145 139.73779459961023 31.139 35.67342344950891 139.73784177287607 31.139 35.67342344950891 139.73784177287607 28.262</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3d12b7b1-6f53-4ed1-8573-5f37ec58f584">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3d12b7b1-6f53-4ed1-8573-5f37ec58f584_0">
											<gml:posList>35.67342344950891 139.73784177287607 28.262 35.673408223960145 139.73779459961023 28.262 35.673408223960145 139.73779459961023 31.139 35.67342344950891 139.73784177287607 28.262</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d06e927c-5e77-42b5-8845-454c24a33d5b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d06e927c-5e77-42b5-8845-454c24a33d5b_0">
											<gml:posList>35.67340299621942 139.73785169506007 28.262 35.67342344950891 139.73784177287607 28.262 35.67340299621942 139.73785169506007 29.018 35.67340299621942 139.73785169506007 28.262</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4c65afc5-358e-4623-a3dd-92af92d97614">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4c65afc5-358e-4623-a3dd-92af92d97614_0">
											<gml:posList>35.67342344950891 139.73784177287607 28.262 35.67342344950891 139.73784177287607 31.139 35.67340299621942 139.73785169506007 29.018 35.67342344950891 139.73784177287607 28.262</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-60bf8a84-35c1-45e0-9482-11f8614aec1a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-60bf8a84-35c1-45e0-9482-11f8614aec1a_0">
											<gml:posList>35.67338807522315 139.737858926309 29.993 35.67338935468053 139.73785830617152 31.139 35.67338261500373 139.7378615729665 30.196 35.67338807522315 139.737858926309 29.993</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0885f3db-f4e2-4ef1-9bf1-6365664b6cff">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0885f3db-f4e2-4ef1-9bf1-6365664b6cff_0">
											<gml:posList>35.67340299621942 139.73785169506007 29.018 35.67342344950891 139.73784177287607 31.139 35.67338935468053 139.73785830617152 31.139 35.67340299621942 139.73785169506007 29.018</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ddb44efb-c1cd-49b2-9119-9b3037738797">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ddb44efb-c1cd-49b2-9119-9b3037738797_0">
											<gml:posList>35.67338807522315 139.737858926309 29.993 35.67340299621942 139.73785169506007 29.018 35.67338935468053 139.73785830617152 31.139 35.67338807522315 139.737858926309 29.993</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-56045f8d-1180-4505-b917-7bb76707a243">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-56045f8d-1180-4505-b917-7bb76707a243_0">
											<gml:posList>35.673401070399564 139.73787836402818 33.718 35.673393609913816 139.7378819962204 31.641 35.673393609913816 139.7378819962204 33.718 35.673401070399564 139.73787836402818 33.718</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7ddbab78-2396-4393-99b8-348ed208b7b3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7ddbab78-2396-4393-99b8-348ed208b7b3_0">
											<gml:posList>35.673401070399564 139.73787836402818 33.718 35.673401070399564 139.73787836402818 31.641 35.673393609913816 139.7378819962204 31.641 35.673401070399564 139.73787836402818 33.718</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3f6d95cd-5a7a-421e-bf3b-4730a8d6e195">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3f6d95cd-5a7a-421e-bf3b-4730a8d6e195_0">
											<gml:posList>35.67340745871052 139.7378980526456 33.718 35.673401070399564 139.73787836402818 31.641 35.673401070399564 139.73787836402818 33.718 35.67340745871052 139.7378980526456 33.718</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5d03484c-0fb1-4218-969a-85865b435f54">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5d03484c-0fb1-4218-969a-85865b435f54_0">
											<gml:posList>35.67340745871052 139.7378980526456 33.718 35.67340745871052 139.7378980526456 31.641 35.673401070399564 139.73787836402818 31.641 35.67340745871052 139.7378980526456 33.718</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-be9b0d49-5754-4366-9c13-2a4aea5465ed">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-be9b0d49-5754-4366-9c13-2a4aea5465ed_0">
											<gml:posList>35.673399998224184 139.73790168483626 33.718 35.673401070399564 139.73787836402818 33.718 35.673393609913816 139.7378819962204 33.718 35.673399998224184 139.73790168483626 33.718</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8f75ba55-222d-48f8-ba33-58c97eaeda8d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8f75ba55-222d-48f8-ba33-58c97eaeda8d_0">
											<gml:posList>35.673399998224184 139.73790168483626 33.718 35.67340745871052 139.7378980526456 33.718 35.673401070399564 139.73787836402818 33.718 35.673399998224184 139.73790168483626 33.718</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d176d462-d700-4d18-bc23-e395dc8007cf">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d176d462-d700-4d18-bc23-e395dc8007cf_0">
											<gml:posList>35.673399998224184 139.73790168483626 33.718 35.673393609913816 139.7378819962204 31.641 35.673399998224184 139.73790168483626 31.641 35.673399998224184 139.73790168483626 33.718</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3729b5e5-d770-4931-894f-55d8bbe61dc8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3729b5e5-d770-4931-894f-55d8bbe61dc8_0">
											<gml:posList>35.673399998224184 139.73790168483626 33.718 35.673393609913816 139.7378819962204 33.718 35.673393609913816 139.7378819962204 31.641 35.673399998224184 139.73790168483626 33.718</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0bc09e0e-7074-4069-87b5-50e1eefe11b9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0bc09e0e-7074-4069-87b5-50e1eefe11b9_0">
											<gml:posList>35.67340745871052 139.7378980526456 33.718 35.673399998224184 139.73790168483626 31.641 35.67340745871052 139.7378980526456 31.641 35.67340745871052 139.7378980526456 33.718</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-32a9bc2c-898b-405f-8dd6-bcf09afe55c7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-32a9bc2c-898b-405f-8dd6-bcf09afe55c7_0">
											<gml:posList>35.67340745871052 139.7378980526456 33.718 35.673399998224184 139.73790168483626 33.718 35.673399998224184 139.73790168483626 31.641 35.67340745871052 139.7378980526456 33.718</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2414d944-cd92-47db-91b7-c28443cc8751">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2414d944-cd92-47db-91b7-c28443cc8751_0">
											<gml:posList>35.67344336899316 139.73789754593614 33.418 35.673446875560835 139.7379092070577 32.097 35.67344336899316 139.73789754593614 32.097 35.67344336899316 139.73789754593614 33.418</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1269b2b8-1c41-467b-a88e-fb9b099dbcca">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1269b2b8-1c41-467b-a88e-fb9b099dbcca_0">
											<gml:posList>35.67344336899316 139.73789754593614 33.418 35.673446875560835 139.7379092070577 33.418 35.673446875560835 139.7379092070577 32.097 35.67344336899316 139.73789754593614 33.418</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-723a9e9c-c996-4d1f-a352-13c7b045f622">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-723a9e9c-c996-4d1f-a352-13c7b045f622_0">
											<gml:posList>35.67344598355299 139.73790964998668 32.097 35.673442485964046 139.73789794466785 31.641 35.673442485964046 139.73789794466785 32.097 35.67344598355299 139.73790964998668 32.097</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-86fd8c63-6826-4c84-957d-9c74433e9efb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-86fd8c63-6826-4c84-957d-9c74433e9efb_0">
											<gml:posList>35.67344598355299 139.73790964998668 32.097 35.67344598355299 139.73790964998668 31.641 35.673442485964046 139.73789794466785 31.641 35.67344598355299 139.73790964998668 32.097</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2109abdf-849a-4c20-a4d8-9d05a01d4a21">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2109abdf-849a-4c20-a4d8-9d05a01d4a21_0">
											<gml:posList>35.673351094007046 139.73799809209405 37.206 35.673342291604776 139.73796900564 35.089 35.673351094007046 139.73799809209405 35.089 35.673351094007046 139.73799809209405 37.206</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ad022c2b-5770-403c-ada4-96ad78218dcc">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ad022c2b-5770-403c-ada4-96ad78218dcc_0">
											<gml:posList>35.673351094007046 139.73799809209405 37.206 35.673342291604776 139.73796900564 37.206 35.673342291604776 139.73796900564 35.089 35.673351094007046 139.73799809209405 37.206</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d66e631d-23ed-468a-a8d6-19dfbe893d91">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d66e631d-23ed-468a-a8d6-19dfbe893d91_0">
											<gml:posList>35.67336031256543 139.73796080966758 37.206 35.673342291604776 139.73796900564 35.089 35.673342291604776 139.73796900564 37.206 35.67336031256543 139.73796080966758 37.206</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-eeba9d98-b964-455c-9e17-302ab4410c0e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-eeba9d98-b964-455c-9e17-302ab4410c0e_0">
											<gml:posList>35.67336031256543 139.73796080966758 37.206 35.67336031256543 139.73796080966758 35.089 35.673342291604776 139.73796900564 35.089 35.67336031256543 139.73796080966758 37.206</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0d475f1e-c092-4c2d-bea8-424a2435085b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0d475f1e-c092-4c2d-bea8-424a2435085b_0">
											<gml:posList>35.6733691149784 139.73798990717393 37.206 35.673342291604776 139.73796900564 37.206 35.673351094007046 139.73799809209405 37.206 35.6733691149784 139.73798990717393 37.206</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-78f5a74d-fd1e-4395-8769-e37f1909e46f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-78f5a74d-fd1e-4395-8769-e37f1909e46f_0">
											<gml:posList>35.6733691149784 139.73798990717393 37.206 35.67336031256543 139.73796080966758 37.206 35.673342291604776 139.73796900564 37.206 35.6733691149784 139.73798990717393 37.206</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d9e9d856-97e3-4ee3-a2d4-a1396d95a79a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d9e9d856-97e3-4ee3-a2d4-a1396d95a79a_0">
											<gml:posList>35.6733691149784 139.73798990717393 37.206 35.673351094007046 139.73799809209405 35.089 35.6733691149784 139.73798990717393 35.089 35.6733691149784 139.73798990717393 37.206</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f87e5590-2a42-46f8-a76f-15f50a26f8c5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f87e5590-2a42-46f8-a76f-15f50a26f8c5_0">
											<gml:posList>35.6733691149784 139.73798990717393 37.206 35.673351094007046 139.73799809209405 37.206 35.673351094007046 139.73799809209405 35.089 35.6733691149784 139.73798990717393 37.206</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4a63f778-589e-44a9-8c52-08cef29834e4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4a63f778-589e-44a9-8c52-08cef29834e4_0">
											<gml:posList>35.67336031256543 139.73796080966758 37.206 35.6733691149784 139.73798990717393 35.089 35.67336031256543 139.73796080966758 35.089 35.67336031256543 139.73796080966758 37.206</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6305b648-a2d3-4966-8ecf-6427b9ecae90">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6305b648-a2d3-4966-8ecf-6427b9ecae90_0">
											<gml:posList>35.67336031256543 139.73796080966758 37.206 35.6733691149784 139.73798990717393 37.206 35.6733691149784 139.73798990717393 35.089 35.67336031256543 139.73796080966758 37.206</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9f5b69a3-80a2-49a1-b5ee-db97901f12ea">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9f5b69a3-80a2-49a1-b5ee-db97901f12ea_0">
											<gml:posList>35.67337092739099 139.73795658825793 36.734 35.673367592517316 139.73794546822793 35.089 35.67337092739099 139.73795658825793 35.089 35.67337092739099 139.73795658825793 36.734</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-02607ee2-ba27-497e-bd51-94f7e0a567f2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-02607ee2-ba27-497e-bd51-94f7e0a567f2_0">
											<gml:posList>35.67337092739099 139.73795658825793 36.734 35.673367592517316 139.73794546822793 36.734 35.673367592517316 139.73794546822793 35.089 35.67337092739099 139.73795658825793 36.734</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-85d4a676-193b-4c2a-8c10-d46168508414">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-85d4a676-193b-4c2a-8c10-d46168508414_0">
											<gml:posList>35.673367592517316 139.73794546822793 36.734 35.673376062392606 139.7379416470483 35.089 35.673367592517316 139.73794546822793 35.089 35.673367592517316 139.73794546822793 36.734</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-07b060e5-f53a-4bfb-b923-54828ce21680">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-07b060e5-f53a-4bfb-b923-54828ce21680_0">
											<gml:posList>35.673367592517316 139.73794546822793 36.734 35.673376062392606 139.7379416470483 36.734 35.673376062392606 139.7379416470483 35.089 35.673367592517316 139.73794546822793 36.734</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fa0c0d9d-4541-48f3-969f-dd475d3b7bc7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fa0c0d9d-4541-48f3-969f-dd475d3b7bc7_0">
											<gml:posList>35.673367592517316 139.73794546822793 36.734 35.67337939727539 139.73795277812596 36.734 35.673376062392606 139.7379416470483 36.734 35.673367592517316 139.73794546822793 36.734</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0c8854d7-3876-4a6c-a641-c2880b680d6d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0c8854d7-3876-4a6c-a641-c2880b680d6d_0">
											<gml:posList>35.673367592517316 139.73794546822793 36.734 35.67337092739099 139.73795658825793 36.734 35.67337939727539 139.73795277812596 36.734 35.673367592517316 139.73794546822793 36.734</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-99d9f826-eb60-4f6e-8c91-4a626bd80cd4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-99d9f826-eb60-4f6e-8c91-4a626bd80cd4_0">
											<gml:posList>35.67337939727539 139.73795277812596 36.734 35.67337092739099 139.73795658825793 35.089 35.67337939727539 139.73795277812596 35.089 35.67337939727539 139.73795277812596 36.734</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e668b6cd-b118-4453-bd05-3dfb72ed79bd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e668b6cd-b118-4453-bd05-3dfb72ed79bd_0">
											<gml:posList>35.67337939727539 139.73795277812596 36.734 35.67337092739099 139.73795658825793 36.734 35.67337092739099 139.73795658825793 35.089 35.67337939727539 139.73795277812596 36.734</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cad98282-cfff-414c-acd3-e17e2096cb31">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cad98282-cfff-414c-acd3-e17e2096cb31_0">
											<gml:posList>35.673376062392606 139.7379416470483 36.734 35.67337939727539 139.73795277812596 35.089 35.673376062392606 139.7379416470483 35.089 35.673376062392606 139.7379416470483 36.734</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-55b3cf28-ca44-4129-8fce-50bb82b5099a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-55b3cf28-ca44-4129-8fce-50bb82b5099a_0">
											<gml:posList>35.673376062392606 139.7379416470483 36.734 35.67337939727539 139.73795277812596 36.734 35.67337939727539 139.73795277812596 35.089 35.673376062392606 139.7379416470483 36.734</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-454bb158-95b9-4e13-9021-181abbc837f0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-454bb158-95b9-4e13-9021-181abbc837f0_0">
											<gml:posList>35.67338776517131 139.73792263284474 33.418 35.67338830744739 139.7379244659472 31.641 35.67338830744739 139.7379244659472 33.418 35.67338776517131 139.73792263284474 33.418</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5c1aa19b-134b-462f-ad84-a69d27019cff">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5c1aa19b-134b-462f-ad84-a69d27019cff_0">
											<gml:posList>35.67338776517131 139.73792263284474 33.418 35.67338776517131 139.73792263284474 31.641 35.67338830744739 139.7379244659472 31.641 35.67338776517131 139.73792263284474 33.418</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b14fc204-b4b9-44d9-b4e7-862fc2dea038">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b14fc204-b4b9-44d9-b4e7-862fc2dea038_0">
											<gml:posList>35.67339185919485 139.7379362706149 33.418 35.67338831646111 139.73792446593646 31.641 35.67339185919485 139.7379362706149 31.641 35.67339185919485 139.7379362706149 33.418</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-21b5447e-402e-402b-bb24-02bb79245f84">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-21b5447e-402e-402b-bb24-02bb79245f84_0">
											<gml:posList>35.67339185919485 139.7379362706149 33.418 35.67338831646111 139.73792446593646 33.418 35.67338831646111 139.73792446593646 31.641 35.67339185919485 139.7379362706149 33.418</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6b2db7da-0e12-438b-a818-2e2607c56a3b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6b2db7da-0e12-438b-a818-2e2607c56a3b_0">
											<gml:posList>35.67339484436517 139.73790419856647 33.718 35.67338776231469 139.73790765355878 31.641 35.67339484436517 139.73790419856647 31.641 35.67339484436517 139.73790419856647 33.718</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bfe5606e-1bd7-4eac-a9b7-fa7ff8db7ea4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bfe5606e-1bd7-4eac-a9b7-fa7ff8db7ea4_0">
											<gml:posList>35.67339484436517 139.73790419856647 33.718 35.67338776231469 139.73790765355878 33.718 35.67338776231469 139.73790765355878 31.641 35.67339484436517 139.73790419856647 33.718</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9c698d3d-7f02-4184-97d8-8ac8a7fb2851">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9c698d3d-7f02-4184-97d8-8ac8a7fb2851_0">
											<gml:posList>35.673414114871235 139.73800555098447 29.93 35.67341633032441 139.73801450720558 28.021 35.67341633032441 139.73801450720558 29.93 35.673414114871235 139.73800555098447 29.93</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2f556cd7-42a7-4b6e-b5e0-fd8fe32e68ed">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2f556cd7-42a7-4b6e-b5e0-fd8fe32e68ed_0">
											<gml:posList>35.673414114871235 139.73800555098447 29.93 35.673414114871235 139.73800555098447 28.021 35.67341633032441 139.73801450720558 28.021 35.673414114871235 139.73800555098447 29.93</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-14b6e756-f0c2-4a00-a179-f013b4eded0f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-14b6e756-f0c2-4a00-a179-f013b4eded0f_0">
											<gml:posList>35.67344336899316 139.73789754593614 33.418 35.67344336899316 139.73789754593614 32.097 35.673442485964046 139.73789794466785 32.097 35.67344336899316 139.73789754593614 33.418</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-549f15f6-6938-4d90-9fe3-ff75b592a1de">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-549f15f6-6938-4d90-9fe3-ff75b592a1de_0">
											<gml:posList>35.67344336899316 139.73789754593614 33.418 35.673442485964046 139.73789794466785 32.097 35.67338776517131 139.73792263284474 33.418 35.67344336899316 139.73789754593614 33.418</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3208fab2-3f09-4280-a70e-b291e2db1bee">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3208fab2-3f09-4280-a70e-b291e2db1bee_0">
											<gml:posList>35.673442485964046 139.73789794466785 32.097 35.67338776517131 139.73792263284474 31.641 35.67338776517131 139.73792263284474 33.418 35.673442485964046 139.73789794466785 32.097</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9b9d68b5-c87e-43a3-a57e-ec4a243f5338">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9b9d68b5-c87e-43a3-a57e-ec4a243f5338_0">
											<gml:posList>35.673442485964046 139.73789794466785 32.097 35.673442485964046 139.73789794466785 31.641 35.67338776517131 139.73792263284474 31.641 35.673442485964046 139.73789794466785 32.097</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-74f74cb2-8e64-46e5-8042-dea719c20ca0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-74f74cb2-8e64-46e5-8042-dea719c20ca0_0">
											<gml:posList>35.673446875560835 139.7379092070577 32.097 35.673446875560835 139.7379092070577 33.418 35.67344598355299 139.73790964998668 32.097 35.673446875560835 139.7379092070577 32.097</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9e5a878d-4479-439d-b0e4-6d9da04e7272">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9e5a878d-4479-439d-b0e4-6d9da04e7272_0">
											<gml:posList>35.67344598355299 139.73790964998668 31.641 35.67344598355299 139.73790964998668 32.097 35.67339185919485 139.7379362706149 31.641 35.67344598355299 139.73790964998668 31.641</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-308aacc8-98d7-40c8-8f32-1ffafb911fe9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-308aacc8-98d7-40c8-8f32-1ffafb911fe9_0">
											<gml:posList>35.67339185919485 139.7379362706149 31.641 35.67344598355299 139.73790964998668 32.097 35.67339185919485 139.7379362706149 33.418 35.67339185919485 139.7379362706149 31.641</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2eff6098-6d78-45cc-8134-2ec41514d7ae">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2eff6098-6d78-45cc-8134-2ec41514d7ae_0">
											<gml:posList>35.67344598355299 139.73790964998668 32.097 35.673446875560835 139.7379092070577 33.418 35.67339185919485 139.7379362706149 33.418 35.67344598355299 139.73790964998668 32.097</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f3a50c35-be76-43b8-8ec0-9caf7e41dc05">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f3a50c35-be76-43b8-8ec0-9caf7e41dc05_0">
											<gml:posList>35.673414114871235 139.73800555098447 29.93 35.67342599147879 139.7380011513306 28.021 35.673414114871235 139.73800555098447 28.021 35.673414114871235 139.73800555098447 29.93</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8f1d92de-c8de-419c-a0a4-ed4db44a9d73">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8f1d92de-c8de-419c-a0a4-ed4db44a9d73_0">
											<gml:posList>35.673414114871235 139.73800555098447 29.93 35.67342599147879 139.7380011513306 29.93 35.67342599147879 139.7380011513306 28.021 35.673414114871235 139.73800555098447 29.93</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-17ce8e7d-68ae-481b-8c74-fb26cc8bb240">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-17ce8e7d-68ae-481b-8c74-fb26cc8bb240_0">
											<gml:posList>35.673414114871235 139.73800555098447 29.93 35.67342819790983 139.73801009651694 29.93 35.67342599147879 139.7380011513306 29.93 35.673414114871235 139.73800555098447 29.93</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-906e09ae-e1ea-49ea-aa63-9f5c26880886">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-906e09ae-e1ea-49ea-aa63-9f5c26880886_0">
											<gml:posList>35.673414114871235 139.73800555098447 29.93 35.67341633032441 139.73801450720558 29.93 35.67342819790983 139.73801009651694 29.93 35.673414114871235 139.73800555098447 29.93</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fdbc2ca2-7ef7-4b5c-882f-7ddd333f1c6f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fdbc2ca2-7ef7-4b5c-882f-7ddd333f1c6f_0">
											<gml:posList>35.67342819790983 139.73801009651694 29.93 35.67341633032441 139.73801450720558 28.021 35.67342819790983 139.73801009651694 28.021 35.67342819790983 139.73801009651694 29.93</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-550e0776-6aaf-4681-9726-7ba614e56015">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-550e0776-6aaf-4681-9726-7ba614e56015_0">
											<gml:posList>35.67342819790983 139.73801009651694 29.93 35.67341633032441 139.73801450720558 29.93 35.67341633032441 139.73801450720558 28.021 35.67342819790983 139.73801009651694 29.93</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d788aa94-f992-44e7-828c-4faffe8df64b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d788aa94-f992-44e7-828c-4faffe8df64b_0">
											<gml:posList>35.67342599147879 139.7380011513306 29.93 35.67342819790983 139.73801009651694 28.021 35.67342599147879 139.7380011513306 28.021 35.67342599147879 139.7380011513306 29.93</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-dc59808e-df1a-4af8-9a4f-d32fe85143b7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-dc59808e-df1a-4af8-9a4f-d32fe85143b7_0">
											<gml:posList>35.67342599147879 139.7380011513306 29.93 35.67342819790983 139.73801009651694 29.93 35.67342819790983 139.73801009651694 28.021 35.67342599147879 139.7380011513306 29.93</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5765694b-ac7d-4506-a571-f7f7a946fa95">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5765694b-ac7d-4506-a571-f7f7a946fa95_0">
											<gml:posList>35.67338776517131 139.73792263284474 33.418 35.67338831646111 139.73792446593646 33.418 35.67344336899316 139.73789754593614 33.418 35.67338776517131 139.73792263284474 33.418</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-57099ea7-3351-4ea3-af80-a33d682b64bc">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-57099ea7-3351-4ea3-af80-a33d682b64bc_0">
											<gml:posList>35.67344336899316 139.73789754593614 33.418 35.67338831646111 139.73792446593646 33.418 35.673446875560835 139.7379092070577 33.418 35.67344336899316 139.73789754593614 33.418</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-646927fe-a8f2-426a-93f2-f691ba90f889">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-646927fe-a8f2-426a-93f2-f691ba90f889_0">
											<gml:posList>35.67338831646111 139.73792446593646 33.418 35.67339185919485 139.7379362706149 33.418 35.673446875560835 139.7379092070577 33.418 35.67338831646111 139.73792446593646 33.418</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8a372666-53f7-4a1c-ad14-e82cf4893bef">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.673342291604776 139.73796900564 35.089 35.6733691149784 139.73798990717393 35.089 35.673351094007046 139.73799809209405 35.089 35.673342291604776 139.73796900564 35.089</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-29c78487-0b4b-4d28-8bd8-c6935c356787">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.673342291604776 139.73796900564 35.089 35.67336031256543 139.73796080966758 35.089 35.6733691149784 139.73798990717393 35.089 35.673342291604776 139.73796900564 35.089</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-dc804ed5-63ee-41a7-b886-f1c45bc7f304">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67337939727539 139.73795277812596 35.089 35.673367592517316 139.73794546822793 35.089 35.673376062392606 139.7379416470483 35.089 35.67337939727539 139.73795277812596 35.089</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-56b46c02-122d-413a-a8ab-3b32963c4538">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67337939727539 139.73795277812596 35.089 35.67337092739099 139.73795658825793 35.089 35.673367592517316 139.73794546822793 35.089 35.67337939727539 139.73795277812596 35.089</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f50ac535-4b78-475b-bcb7-1cc8f412ce25">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.673365035984844 139.73787009983735 28.262 35.673349810447064 139.73782292660047 28.262 35.67340299621942 139.73785169506007 28.262 35.673365035984844 139.73787009983735 28.262</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a40c957f-98ef-45b8-b6f6-02cd4b24839e">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67340299621942 139.73785169506007 28.262 35.673408223960145 139.73779459961023 28.262 35.67342344950891 139.73784177287607 28.262 35.67340299621942 139.73785169506007 28.262</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4990c1c5-113b-4e23-83d2-ed9c3efb034f">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67340299621942 139.73785169506007 28.262 35.673349810447064 139.73782292660047 28.262 35.673408223960145 139.73779459961023 28.262 35.67340299621942 139.73785169506007 28.262</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1d6fcd4e-915f-45b9-a96d-e939eeea5ba8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6733884560552 139.73788450995167 31.641 35.67338776231469 139.73790765355878 31.641 35.673381373996534 139.7378879538988 31.641 35.6733884560552 139.73788450995167 31.641</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f49ee0cb-ee5f-40f9-81af-c8c802e5ae04">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6733884560552 139.73788450995167 31.641 35.67339484436517 139.73790419856647 31.641 35.67338776231469 139.73790765355878 31.641 35.6733884560552 139.73788450995167 31.641</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f7fb977c-efae-4588-8c23-f9dd9381ecbc">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.673399998224184 139.73790168483626 31.641 35.673401070399564 139.73787836402818 31.641 35.67340745871052 139.7378980526456 31.641 35.673399998224184 139.73790168483626 31.641</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-06b1d312-9e34-40b5-a8f3-fe45c270cc35">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.673399998224184 139.73790168483626 31.641 35.673393609913816 139.7378819962204 31.641 35.673401070399564 139.73787836402818 31.641 35.673399998224184 139.73790168483626 31.641</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a7ea9eaa-b857-4339-9f8d-6c85d80a0031">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.673414114871235 139.73800555098447 28.021 35.67342819790983 139.73801009651694 28.021 35.67341633032441 139.73801450720558 28.021 35.673414114871235 139.73800555098447 28.021</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-627116c8-86f3-41ad-8ef8-354b31d67eda">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.673414114871235 139.73800555098447 28.021 35.67342599147879 139.7380011513306 28.021 35.67342819790983 139.73801009651694 28.021 35.673414114871235 139.73800555098447 28.021</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b680d098-a4d0-45dd-970c-b515768bcf73">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.673442485964046 139.73789794466785 32.097 35.673446875560835 139.7379092070577 32.097 35.67344598355299 139.73790964998668 32.097 35.673442485964046 139.73789794466785 32.097</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-502f8e35-62f5-49f6-910a-06d309f0dc80">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.673442485964046 139.73789794466785 32.097 35.67344336899316 139.73789754593614 32.097 35.673446875560835 139.7379092070577 32.097 35.673442485964046 139.73789794466785 32.097</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d0d1aed1-c5ed-45e6-bb30-fae26ebddffe">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67339185919485 139.7379362706149 31.641 35.67338831646111 139.73792446593646 31.641 35.67344598355299 139.73790964998668 31.641 35.67339185919485 139.7379362706149 31.641</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9b412ab5-37ce-44ac-a324-3ecda1e613b9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67344598355299 139.73790964998668 31.641 35.67338831646111 139.73792446593646 31.641 35.673442485964046 139.73789794466785 31.641 35.67344598355299 139.73790964998668 31.641</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8555c483-9b4b-4342-8e65-8749a6f638fb">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67338831646111 139.73792446593646 31.641 35.67338776517131 139.73792263284474 31.641 35.673442485964046 139.73789794466785 31.641 35.67338831646111 139.73792446593646 31.641</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_2948178b-9330-4f5c-8414-a89a5d859d77_BuildingInstallation_1041">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-802cdcc4-dec8-44d9-8e8b-d9a30ab3430f">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6733997639629 139.73794730788384 31.641 35.673432273868386 139.73793264339898 31.641 35.67343898876438 139.73795498284315 31.641 35.67340647886495 139.73796965836684 31.641 35.6733997639629 139.73794730788384 31.641</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-726ae7f5-8d2a-4956-a1a3-4c395cebdbfe">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67347170910548 139.73812647684207 25.546 35.673464723270634 139.7381034307084 25.546 35.67349691773223 139.73808878874306 25.546 35.67350390356112 139.738111823838 25.546 35.67347170910548 139.73812647684207 25.546</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-406df737-77d1-4ad8-8648-c573ef3a3f21">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-406df737-77d1-4ad8-8648-c573ef3a3f21_0">
											<gml:posList>35.6733997639629 139.73794730788384 34.821 35.6733997639629 139.73794730788384 31.641 35.67340647886495 139.73796965836684 31.641 35.67340647886495 139.73796965836684 34.821 35.6733997639629 139.73794730788384 34.821</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6bacf90b-0ae2-4a53-b08a-5cc904d591d0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6bacf90b-0ae2-4a53-b08a-5cc904d591d0_0">
											<gml:posList>35.6733997639629 139.73794730788384 34.821 35.673432273868386 139.73793264339898 34.821 35.673432273868386 139.73793264339898 31.641 35.6733997639629 139.73794730788384 31.641 35.6733997639629 139.73794730788384 34.821</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-39a1b8f1-eb81-4795-a5bf-45dbca5259e9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-39a1b8f1-eb81-4795-a5bf-45dbca5259e9_0">
											<gml:posList>35.6733997639629 139.73794730788384 34.821 35.67340647886495 139.73796965836684 34.821 35.67343898876438 139.73795498284315 34.821 35.673432273868386 139.73793264339898 34.821 35.6733997639629 139.73794730788384 34.821</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-37fc40f3-d202-410c-958f-71c33c407480">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-37fc40f3-d202-410c-958f-71c33c407480_0">
											<gml:posList>35.67343898876438 139.73795498284315 34.821 35.67340647886495 139.73796965836684 34.821 35.67340647886495 139.73796965836684 31.641 35.67343898876438 139.73795498284315 31.641 35.67343898876438 139.73795498284315 34.821</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d4172b5b-2a8e-4493-abec-ed4f31bee157">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d4172b5b-2a8e-4493-abec-ed4f31bee157_0">
											<gml:posList>35.67343898876438 139.73795498284315 34.821 35.67343898876438 139.73795498284315 31.641 35.673432273868386 139.73793264339898 31.641 35.673432273868386 139.73793264339898 34.821 35.67343898876438 139.73795498284315 34.821</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-07ec2589-2929-4601-b3df-4b8768634135">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-07ec2589-2929-4601-b3df-4b8768634135_0">
											<gml:posList>35.67347170910548 139.73812647684207 27.8 35.673464723270634 139.7381034307084 27.8 35.673464723270634 139.7381034307084 25.546 35.67347170910548 139.73812647684207 25.546 35.67347170910548 139.73812647684207 27.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4f41b1c7-7ca4-4fd7-8462-158208e8cef0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4f41b1c7-7ca4-4fd7-8462-158208e8cef0_0">
											<gml:posList>35.673464723270634 139.7381034307084 27.8 35.67349691773223 139.73808878874306 27.8 35.67349691773223 139.73808878874306 25.546 35.673464723270634 139.7381034307084 25.546 35.673464723270634 139.7381034307084 27.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8589a14b-5451-4fc1-8b5a-d5e4ec64d058">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8589a14b-5451-4fc1-8b5a-d5e4ec64d058_0">
											<gml:posList>35.67347170910548 139.73812647684207 27.8 35.67350390356112 139.738111823838 27.8 35.67349691773223 139.73808878874306 27.8 35.673464723270634 139.7381034307084 27.8 35.67347170910548 139.73812647684207 27.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-83938e1d-370e-4e44-a87e-8d4ba6d44fa4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-83938e1d-370e-4e44-a87e-8d4ba6d44fa4_0">
											<gml:posList>35.67347170910548 139.73812647684207 27.8 35.67347170910548 139.73812647684207 25.546 35.67350390356112 139.738111823838 25.546 35.67350390356112 139.738111823838 27.8 35.67347170910548 139.73812647684207 27.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bb27f071-0b2a-4c5a-825f-de0448258945">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bb27f071-0b2a-4c5a-825f-de0448258945_0">
											<gml:posList>35.67349691773223 139.73808878874306 27.8 35.67350390356112 139.738111823838 27.8 35.67350390356112 139.738111823838 25.546 35.67349691773223 139.73808878874306 25.546 35.67349691773223 139.73808878874306 27.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-b6852cb3-562f-418c-9054-dfb40899e8bd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b6852cb3-562f-418c-9054-dfb40899e8bd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b6852cb3-562f-418c-9054-dfb40899e8bd">
											<gml:posList>35.673517204813585 139.73813081939514 8.64 35.67339718584212 139.73818630576258 8.64 35.673342065343476 139.73801338037163 8.64 35.67329028019753 139.73784111404538 8.64 35.6734122793994 139.7377823108725 8.64 35.673517204813585 139.73813081939514 8.64</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-79b01cb5-e0c7-4206-96ff-3ac0dc0c0bc6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-79b01cb5-e0c7-4206-96ff-3ac0dc0c0bc6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-79b01cb5-e0c7-4206-96ff-3ac0dc0c0bc6">
											<gml:posList>35.6732956096262 139.7378440350624 29.018 35.67329028019753 139.73784111404538 29.018 35.67330739734427 139.73789806129497 29.018 35.67331137988399 139.7378961344347 29.018 35.6732956096262 139.7378440350624 29.018</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-7fd83b4e-3e61-41a2-9b35-3abb7de59d6b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7fd83b4e-3e61-41a2-9b35-3abb7de59d6b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7fd83b4e-3e61-41a2-9b35-3abb7de59d6b">
											<gml:posList>35.67331263659061 139.73790092719048 32.097 35.67330739734427 139.73789806129497 32.097 35.67332403546824 139.73795340737246 32.097 35.67332789196555 139.73795166845775 32.097 35.67331263659061 139.73790092719048 32.097</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-fadd5334-d635-49e2-a54b-78063e42d134">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fadd5334-d635-49e2-a54b-78063e42d134">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fadd5334-d635-49e2-a54b-78063e42d134">
											<gml:posList>35.6733295543485 139.73795653805945 35.796 35.67332403546824 139.73795340737246 35.796 35.673342065343476 139.73801338037163 35.796 35.67334461086473 139.73800660573775 35.796 35.6733295543485 139.73795653805945 35.796</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-0fdaf034-4913-4834-a98a-6ffa0346a576">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0fdaf034-4913-4834-a98a-6ffa0346a576">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0fdaf034-4913-4834-a98a-6ffa0346a576">
											<gml:posList>35.67329028019753 139.73784111404538 29.018 35.6732956096262 139.7378440350624 29.018 35.67340982395786 139.73778899703842 29.018 35.6734122793994 139.7377823108725 29.018 35.67329028019753 139.73784111404538 29.018</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ca38ea08-d806-47e7-9891-d8f762f9fabb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ca38ea08-d806-47e7-9891-d8f762f9fabb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ca38ea08-d806-47e7-9891-d8f762f9fabb">
											<gml:posList>35.67332403546824 139.73795340737246 35.796 35.6733295543485 139.73795653805945 35.796 35.673385761922034 139.7379312295407 35.796 35.67338830744739 139.7379244659472 35.796 35.67332403546824 139.73795340737246 35.796</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-4c737b9f-962a-462c-8dd7-e70dc46ed6d6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4c737b9f-962a-462c-8dd7-e70dc46ed6d6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4c737b9f-962a-462c-8dd7-e70dc46ed6d6">
											<gml:posList>35.673348395745336 139.73801687463865 28.512 35.673342065343476 139.73801338037163 28.512 35.67337268886619 139.738109438956 28.512 35.673375458993156 139.73810172508865 28.512 35.673348395745336 139.73801687463865 28.512</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-276dc600-ef0d-4b9f-8a14-639785470453">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-276dc600-ef0d-4b9f-8a14-639785470453">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-276dc600-ef0d-4b9f-8a14-639785470453">
											<gml:posList>35.67342543176457 139.73784080945384 28.262 35.67340982395786 139.73778899703842 28.262 35.6732956096262 139.7378440350624 28.262 35.67331137988399 139.7378961344347 28.262 35.67342543176457 139.73784080945384 28.262</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-766a7fc4-8732-4be7-ba4a-f9b36d112470">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-766a7fc4-8732-4be7-ba4a-f9b36d112470">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-766a7fc4-8732-4be7-ba4a-f9b36d112470">
											<gml:posList>35.6733295543485 139.73795653805945 35.089 35.67334461086473 139.73800660573775 35.089 35.67340073713279 139.7379810543192 35.089 35.673385761922034 139.7379312295407 35.089 35.6733295543485 139.73795653805945 35.089</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-61e4bd66-f391-440c-a3fd-0f5aa35d1437">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-61e4bd66-f391-440c-a3fd-0f5aa35d1437">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-61e4bd66-f391-440c-a3fd-0f5aa35d1437">
											<gml:posList>35.673429225085314 139.73783897118668 32.097 35.67330739734427 139.73789806129497 32.097 35.67331263659061 139.73790092719048 32.097 35.67342681462162 139.73784554683195 32.097 35.673429225085314 139.73783897118668 32.097</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-99c4529c-a9a7-4360-bad3-f90f964eed58">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-99c4529c-a9a7-4360-bad3-f90f964eed58">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-99c4529c-a9a7-4360-bad3-f90f964eed58">
											<gml:posList>35.67338830744739 139.7379244659472 31.641 35.67342681462162 139.73784554683195 31.641 35.67331263659061 139.73790092719048 31.641 35.67332789196555 139.73795166845775 31.641 35.67338830744739 139.7379244659472 31.641</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-8d461c0a-c4e7-44fc-8965-982ded81319c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8d461c0a-c4e7-44fc-8965-982ded81319c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8d461c0a-c4e7-44fc-8965-982ded81319c">
											<gml:posList>35.67338602571871 139.73803670286387 28.021 35.673348395745336 139.73801687463865 28.021 35.673375458993156 139.73810172508865 28.021 35.67339318236375 139.73805916329235 28.021 35.67338602571871 139.73803670286387 28.021</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-95b6548f-658a-4930-917f-912e085df8eb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-95b6548f-658a-4930-917f-912e085df8eb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-95b6548f-658a-4930-917f-912e085df8eb">
											<gml:posList>35.67334461086473 139.73800660573775 35.796 35.673342065343476 139.73801338037163 35.796 35.67340624698105 139.73798416292846 35.796 35.67340073713279 139.7379810543192 35.796 35.67334461086473 139.73800660573775 35.796</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-50df434d-4eac-4e3e-be49-3cfc6a22c5bf">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-50df434d-4eac-4e3e-be49-3cfc6a22c5bf">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-50df434d-4eac-4e3e-be49-3cfc6a22c5bf">
											<gml:posList>35.67337268886619 139.738109438956 26.316 35.67339718584212 139.73818630576258 26.316 35.673399560313236 139.7381797854061 26.316 35.67337655429209 139.73810758957043 26.316 35.67337268886619 139.738109438956 26.316</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-1a34db56-b4cc-47de-aaae-60986f775fa5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1a34db56-b4cc-47de-aaae-60986f775fa5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1a34db56-b4cc-47de-aaae-60986f775fa5">
											<gml:posList>35.67338830744739 139.7379244659472 35.796 35.673385761922034 139.7379312295407 35.796 35.67340073713279 139.7379810543192 35.796 35.67340624698105 139.73798416292846 35.796 35.67338830744739 139.7379244659472 35.796</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-694f7922-c6be-49d8-86b3-3b113e618208">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-694f7922-c6be-49d8-86b3-3b113e618208">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-694f7922-c6be-49d8-86b3-3b113e618208">
											<gml:posList>35.67338602571871 139.73803670286387 32.582 35.67339318236375 139.73805916329235 32.582 35.673410229875145 139.73805100163196 32.582 35.67340306421488 139.73802854121018 32.582 35.67338602571871 139.73803670286387 32.582</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d9bca413-fa81-44f7-b8ce-21557424984e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d9bca413-fa81-44f7-b8ce-21557424984e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d9bca413-fa81-44f7-b8ce-21557424984e">
											<gml:posList>35.673461828648 139.73796522908592 28.512 35.67346469795156 139.73795755927378 28.512 35.673342065343476 139.73801338037163 28.512 35.673348395745336 139.73801687463865 28.512 35.673461828648 139.73796522908592 28.512</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-795f8beb-f378-403a-b9fd-bfd91f24b397">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-795f8beb-f378-403a-b9fd-bfd91f24b397">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-795f8beb-f378-403a-b9fd-bfd91f24b397">
											<gml:posList>35.673461828648 139.73796522908592 28.021 35.673348395745336 139.73801687463865 28.021 35.67338602571871 139.73803670286387 28.021 35.67340306421488 139.73802854121018 28.021 35.673461828648 139.73796522908592 28.021</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-be4299a4-7992-4671-b382-0ed49b003322">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-be4299a4-7992-4671-b382-0ed49b003322">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-be4299a4-7992-4671-b382-0ed49b003322">
											<gml:posList>35.673375458993156 139.73810172508865 28.512 35.67337268886619 139.738109438956 28.512 35.67345293472282 139.73807102269836 28.512 35.67345127184633 139.7380655234265 28.512 35.673375458993156 139.73810172508865 28.512</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ffaf958f-ef44-4936-9c90-d715aa45167f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ffaf958f-ef44-4936-9c90-d715aa45167f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ffaf958f-ef44-4936-9c90-d715aa45167f">
											<gml:posList>35.67339318236375 139.73805916329235 28.021 35.673375458993156 139.73810172508865 28.021 35.67345127184633 139.7380655234265 28.021 35.673410229875145 139.73805100163196 28.021 35.67339318236375 139.73805916329235 28.021</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-980c17f5-4ead-48d3-8631-631747113185">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-980c17f5-4ead-48d3-8631-631747113185">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-980c17f5-4ead-48d3-8631-631747113185">
											<gml:posList>35.673429225085314 139.73783897118668 29.018 35.6734122793994 139.7377823108725 29.018 35.67340982395786 139.73778899703842 29.018 35.67342543176457 139.73784080945384 29.018 35.673429225085314 139.73783897118668 29.018</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-78ddba9f-09e8-456d-8ea5-988219ea50d7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-78ddba9f-09e8-456d-8ea5-988219ea50d7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-78ddba9f-09e8-456d-8ea5-988219ea50d7">
											<gml:posList>35.67338830744739 139.7379244659472 31.641 35.673404819052124 139.73797941455612 31.641 35.673459422564314 139.73795458294532 31.641 35.67342681462162 139.73784554683195 31.641 35.67338830744739 139.7379244659472 31.641</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-5ca3c094-e7e5-4888-82cb-5f9b0789c460">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5ca3c094-e7e5-4888-82cb-5f9b0789c460">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5ca3c094-e7e5-4888-82cb-5f9b0789c460">
											<gml:posList>35.67340624698105 139.73798416292846 32.097 35.67346469795156 139.73795755927378 32.097 35.673459422564314 139.73795458294532 32.097 35.673404819052124 139.73797941455612 32.097 35.67340624698105 139.73798416292846 32.097</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a58cb88a-eccc-4730-a8f7-2adc4ef8ca92">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a58cb88a-eccc-4730-a8f7-2adc4ef8ca92">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a58cb88a-eccc-4730-a8f7-2adc4ef8ca92">
											<gml:posList>35.673410229875145 139.73805100163196 28.021 35.67345127184633 139.7380655234265 28.021 35.673447982269856 139.73805467949407 28.021 35.673463651495 139.73804754680697 28.021 35.673451261328 139.7380066777622 28.021 35.67347158897165 139.73799742960892 28.021 35.673461828648 139.73796522908592 28.021 35.67340306421488 139.73802854121018 28.021 35.673410229875145 139.73805100163196 28.021</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-678c2e83-fc0c-4b90-a37c-ea1141f012a8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-678c2e83-fc0c-4b90-a37c-ea1141f012a8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-678c2e83-fc0c-4b90-a37c-ea1141f012a8">
											<gml:posList>35.673458899340055 139.73809068975388 25.546 35.67345293472282 139.73807102269836 25.546 35.67337655429209 139.73810758957043 25.546 35.673399560313236 139.7381797854061 25.546 35.67351188437078 139.73812785415353 25.546 35.6734955629872 139.73807399883677 25.546 35.673458899340055 139.73809068975388 25.546</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e04b49db-6f8c-442e-a85c-e039ee501db7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e04b49db-6f8c-442e-a85c-e039ee501db7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e04b49db-6f8c-442e-a85c-e039ee501db7">
											<gml:posList>35.67346469795156 139.73795755927378 32.097 35.673429225085314 139.73783897118668 32.097 35.67342681462162 139.73784554683195 32.097 35.673459422564314 139.73795458294532 32.097 35.67346469795156 139.73795755927378 32.097</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-623b15a8-6e1d-4efa-8525-eb02f8a47212">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-623b15a8-6e1d-4efa-8525-eb02f8a47212">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-623b15a8-6e1d-4efa-8525-eb02f8a47212">
											<gml:posList>35.673458899340055 139.73809068975388 32.762 35.673460986109774 139.73808510869947 32.762 35.673452527202635 139.73805722587616 32.762 35.673447982269856 139.73805467949407 32.762 35.673458899340055 139.73809068975388 32.762</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-613b79e6-333d-49b7-be95-7296216692ac">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-613b79e6-333d-49b7-be95-7296216692ac">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-613b79e6-333d-49b7-be95-7296216692ac">
											<gml:posList>35.67339718584212 139.73818630576258 26.316 35.673517204813585 139.73813081939514 26.316 35.67351188437078 139.73812785415353 26.316 35.673399560313236 139.7381797854061 26.316 35.67339718584212 139.73818630576258 26.316</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-602a5f14-ca5d-4971-980b-7f79bebaf6c2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-602a5f14-ca5d-4971-980b-7f79bebaf6c2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-602a5f14-ca5d-4971-980b-7f79bebaf6c2">
											<gml:posList>35.673463651495 139.73804754680697 32.762 35.673447982269856 139.73805467949407 32.762 35.673452527202635 139.73805722587616 32.762 35.67346819641918 139.73805008214248 32.762 35.673463651495 139.73804754680697 32.762</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f9f87eca-8250-4c81-b1eb-a0d0a074be08">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f9f87eca-8250-4c81-b1eb-a0d0a074be08">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f9f87eca-8250-4c81-b1eb-a0d0a074be08">
											<gml:posList>35.673455806270546 139.73800923518834 32.762 35.673451261328 139.7380066777622 32.762 35.673463651495 139.73804754680697 32.762 35.67346819641918 139.73805008214248 32.762 35.673455806270546 139.73800923518834 32.762</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-811d3d58-f7f3-4d9e-bcd2-de3a983a5ec2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-811d3d58-f7f3-4d9e-bcd2-de3a983a5ec2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-811d3d58-f7f3-4d9e-bcd2-de3a983a5ec2">
											<gml:posList>35.673455806270546 139.73800923518834 32.762 35.67347405248907 139.7380009284786 32.762 35.67347614827706 139.73799535845677 32.762 35.673451261328 139.7380066777622 32.762 35.673455806270546 139.73800923518834 32.762</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-8b7a8652-896b-4a50-b69c-7ba8cca07a67">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8b7a8652-896b-4a50-b69c-7ba8cca07a67">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8b7a8652-896b-4a50-b69c-7ba8cca07a67">
											<gml:posList>35.67346469795156 139.73795755927378 28.512 35.673461828648 139.73796522908592 28.512 35.67347158897165 139.73799742960892 28.512 35.67347614827706 139.73799535845677 28.512 35.67346469795156 139.73795755927378 28.512</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f6b8374b-3d7e-4a68-a994-56878b864bf4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f6b8374b-3d7e-4a68-a994-56878b864bf4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f6b8374b-3d7e-4a68-a994-56878b864bf4">
											<gml:posList>35.67346819641918 139.73805008214248 32.359 35.673452527202635 139.73805722587616 32.359 35.673460986109774 139.73808510869947 32.359 35.673494892537455 139.73806965828487 32.359 35.67347405248907 139.7380009284786 32.359 35.673455806270546 139.73800923518834 32.359 35.67346819641918 139.73805008214248 32.359</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-5d1ee640-8d4c-4acb-9a55-8b440b877bf2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5d1ee640-8d4c-4acb-9a55-8b440b877bf2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5d1ee640-8d4c-4acb-9a55-8b440b877bf2">
											<gml:posList>35.673460986109774 139.73808510869947 32.762 35.673458899340055 139.73809068975388 32.762 35.67349944650109 139.73807222675197 32.762 35.673494892537455 139.73806965828487 32.762 35.673460986109774 139.73808510869947 32.762</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-1f290844-0346-4d55-99cc-121d5ef6faaa">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1f290844-0346-4d55-99cc-121d5ef6faaa">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1f290844-0346-4d55-99cc-121d5ef6faaa">
											<gml:posList>35.673494892537455 139.73806965828487 32.762 35.67349944650109 139.73807222675197 32.762 35.67347614827706 139.73799535845677 32.762 35.67347405248907 139.7380009284786 32.762 35.673494892537455 139.73806965828487 32.762</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-975eff23-ec23-42b4-8f0b-5be50c38881d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-975eff23-ec23-42b4-8f0b-5be50c38881d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-975eff23-ec23-42b4-8f0b-5be50c38881d">
											<gml:posList>35.6734955629872 139.73807399883677 26.316 35.67351188437078 139.73812785415353 26.316 35.673517204813585 139.73813081939514 26.316 35.67349944650109 139.73807222675197 26.316 35.6734955629872 139.73807399883677 26.316</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a5865fb0-a07e-437e-9fe8-ed0e28a2bba0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a5865fb0-a07e-437e-9fe8-ed0e28a2bba0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a5865fb0-a07e-437e-9fe8-ed0e28a2bba0">
											<gml:posList>35.673385761922034 139.7379312295407 35.089 35.673385761922034 139.7379312295407 35.796 35.6733295543485 139.73795653805945 35.796 35.6733295543485 139.73795653805945 35.089 35.673385761922034 139.7379312295407 35.089</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6e5b83fa-333d-4266-81b3-c588a7541c65">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6e5b83fa-333d-4266-81b3-c588a7541c65">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6e5b83fa-333d-4266-81b3-c588a7541c65">
											<gml:posList>35.67337268886619 139.738109438956 26.316 35.67337268886619 139.738109438956 28.512 35.673342065343476 139.73801338037163 28.512 35.673342065343476 139.73801338037163 8.64 35.67339718584212 139.73818630576258 8.64 35.67339718584212 139.73818630576258 26.316 35.67337268886619 139.738109438956 26.316</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-980a03ba-9743-4817-b8ae-eddd43d76d53">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-980a03ba-9743-4817-b8ae-eddd43d76d53">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-980a03ba-9743-4817-b8ae-eddd43d76d53">
											<gml:posList>35.673429225085314 139.73783897118668 29.018 35.6734122793994 139.7377823108725 8.64 35.6734122793994 139.7377823108725 29.018 35.673429225085314 139.73783897118668 29.018</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-cedeadc9-53e1-485a-9bf7-05f084688892">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cedeadc9-53e1-485a-9bf7-05f084688892">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cedeadc9-53e1-485a-9bf7-05f084688892">
											<gml:posList>35.67329028019753 139.73784111404538 29.018 35.6734122793994 139.7377823108725 29.018 35.6734122793994 139.7377823108725 8.64 35.67329028019753 139.73784111404538 8.64 35.67329028019753 139.73784111404538 29.018</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4f015ec7-26af-451f-8347-c6f23a0e96fc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4f015ec7-26af-451f-8347-c6f23a0e96fc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4f015ec7-26af-451f-8347-c6f23a0e96fc">
											<gml:posList>35.67342543176457 139.73784080945384 28.262 35.67342543176457 139.73784080945384 29.018 35.67340982395786 139.73778899703842 29.018 35.67340982395786 139.73778899703842 28.262 35.67342543176457 139.73784080945384 28.262</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-010ad211-5e5e-409d-9e97-73a2be01a3ba">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-010ad211-5e5e-409d-9e97-73a2be01a3ba">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-010ad211-5e5e-409d-9e97-73a2be01a3ba">
											<gml:posList>35.67340982395786 139.73778899703842 28.262 35.67340982395786 139.73778899703842 29.018 35.6732956096262 139.7378440350624 29.018 35.6732956096262 139.7378440350624 28.262 35.67340982395786 139.73778899703842 28.262</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b4c5cafb-34a4-4866-bbde-e14bbfb3397d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b4c5cafb-34a4-4866-bbde-e14bbfb3397d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b4c5cafb-34a4-4866-bbde-e14bbfb3397d">
											<gml:posList>35.67342543176457 139.73784080945384 29.018 35.67342543176457 139.73784080945384 28.262 35.67331137988399 139.7378961344347 28.262 35.67331137988399 139.7378961344347 29.018 35.67330739734427 139.73789806129497 29.018 35.67330739734427 139.73789806129497 32.097 35.673429225085314 139.73783897118668 32.097 35.673429225085314 139.73783897118668 29.018 35.67342543176457 139.73784080945384 29.018</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2cb75e11-32fe-4585-977f-4a42e8e07c9b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2cb75e11-32fe-4585-977f-4a42e8e07c9b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2cb75e11-32fe-4585-977f-4a42e8e07c9b">
											<gml:posList>35.67331137988399 139.7378961344347 29.018 35.67331137988399 139.7378961344347 28.262 35.6732956096262 139.7378440350624 28.262 35.6732956096262 139.7378440350624 29.018 35.67331137988399 139.7378961344347 29.018</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-874321c9-3634-4550-b0f8-7f8fb59f360a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-874321c9-3634-4550-b0f8-7f8fb59f360a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-874321c9-3634-4550-b0f8-7f8fb59f360a">
											<gml:posList>35.67331263659061 139.73790092719048 31.641 35.67342681462162 139.73784554683195 31.641 35.67342681462162 139.73784554683195 32.097 35.67331263659061 139.73790092719048 32.097 35.67331263659061 139.73790092719048 31.641</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4d2547f5-a62d-4241-a690-c2632d2ac6c3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4d2547f5-a62d-4241-a690-c2632d2ac6c3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4d2547f5-a62d-4241-a690-c2632d2ac6c3">
											<gml:posList>35.673429225085314 139.73783897118668 29.018 35.67346469795156 139.73795755927378 32.097 35.67346469795156 139.73795755927378 28.512 35.673429225085314 139.73783897118668 29.018</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-da65150e-44a5-4aab-acaa-89bb9f749e7d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-da65150e-44a5-4aab-acaa-89bb9f749e7d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-da65150e-44a5-4aab-acaa-89bb9f749e7d">
											<gml:posList>35.673429225085314 139.73783897118668 29.018 35.673429225085314 139.73783897118668 32.097 35.67346469795156 139.73795755927378 32.097 35.673429225085314 139.73783897118668 29.018</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c674f2e5-2277-4be7-858a-5ec53467163c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c674f2e5-2277-4be7-858a-5ec53467163c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c674f2e5-2277-4be7-858a-5ec53467163c">
											<gml:posList>35.673459422564314 139.73795458294532 32.097 35.67342681462162 139.73784554683195 32.097 35.67342681462162 139.73784554683195 31.641 35.673459422564314 139.73795458294532 31.641 35.673459422564314 139.73795458294532 32.097</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a5958912-3f82-44d6-b818-6847174de9fb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a5958912-3f82-44d6-b818-6847174de9fb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a5958912-3f82-44d6-b818-6847174de9fb">
											<gml:posList>35.67332789196555 139.73795166845775 31.641 35.67331263659061 139.73790092719048 31.641 35.67331263659061 139.73790092719048 32.097 35.67332789196555 139.73795166845775 32.097 35.67332789196555 139.73795166845775 31.641</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-75199b7c-a3c8-4461-8820-ba77a051b052">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-75199b7c-a3c8-4461-8820-ba77a051b052">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-75199b7c-a3c8-4461-8820-ba77a051b052">
											<gml:posList>35.67330739734427 139.73789806129497 29.018 35.67329028019753 139.73784111404538 29.018 35.67329028019753 139.73784111404538 8.64 35.673342065343476 139.73801338037163 8.64 35.673342065343476 139.73801338037163 28.512 35.673342065343476 139.73801338037163 35.796 35.67332403546824 139.73795340737246 35.796 35.67332403546824 139.73795340737246 32.097 35.67330739734427 139.73789806129497 32.097 35.67330739734427 139.73789806129497 29.018</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a637c44f-3b17-4966-a659-17d2b6ddbdc8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a637c44f-3b17-4966-a659-17d2b6ddbdc8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a637c44f-3b17-4966-a659-17d2b6ddbdc8">
											<gml:posList>35.67332789196555 139.73795166845775 32.097 35.67332403546824 139.73795340737246 32.097 35.67332403546824 139.73795340737246 35.796 35.67338830744739 139.7379244659472 35.796 35.67338830744739 139.7379244659472 31.641 35.67332789196555 139.73795166845775 31.641 35.67332789196555 139.73795166845775 32.097</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a58fdc46-66fa-460e-a718-b6a1a1e135b2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a58fdc46-66fa-460e-a718-b6a1a1e135b2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a58fdc46-66fa-460e-a718-b6a1a1e135b2">
											<gml:posList>35.67340624698105 139.73798416292846 35.796 35.67340624698105 139.73798416292846 32.097 35.673404819052124 139.73797941455612 32.097 35.673404819052124 139.73797941455612 31.641 35.67338830744739 139.7379244659472 31.641 35.67338830744739 139.7379244659472 35.796 35.67340624698105 139.73798416292846 35.796</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-659cd850-0228-4c6e-b658-1fde7ec1126c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-659cd850-0228-4c6e-b658-1fde7ec1126c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-659cd850-0228-4c6e-b658-1fde7ec1126c">
											<gml:posList>35.673429225085314 139.73783897118668 29.018 35.67346469795156 139.73795755927378 28.512 35.67349944650109 139.73807222675197 26.316 35.673429225085314 139.73783897118668 29.018</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9f5f57ba-65e4-462b-a4b8-eb43bb9f95ca">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9f5f57ba-65e4-462b-a4b8-eb43bb9f95ca">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9f5f57ba-65e4-462b-a4b8-eb43bb9f95ca">
											<gml:posList>35.673385761922034 139.7379312295407 35.796 35.673385761922034 139.7379312295407 35.089 35.67340073713279 139.7379810543192 35.089 35.67340073713279 139.7379810543192 35.796 35.673385761922034 139.7379312295407 35.796</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-80938e77-b5ea-4823-bb9f-242474cc8c88">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-80938e77-b5ea-4823-bb9f-242474cc8c88">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-80938e77-b5ea-4823-bb9f-242474cc8c88">
											<gml:posList>35.673429225085314 139.73783897118668 29.018 35.673517204813585 139.73813081939514 8.64 35.6734122793994 139.7377823108725 8.64 35.673429225085314 139.73783897118668 29.018</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a2ea8d18-abdc-477c-917d-a64f93b6d8cc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a2ea8d18-abdc-477c-917d-a64f93b6d8cc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a2ea8d18-abdc-477c-917d-a64f93b6d8cc">
											<gml:posList>35.673459422564314 139.73795458294532 31.641 35.673404819052124 139.73797941455612 31.641 35.673404819052124 139.73797941455612 32.097 35.673459422564314 139.73795458294532 32.097 35.673459422564314 139.73795458294532 31.641</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-df9dc057-8625-4985-8948-7aaaf35da862">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-df9dc057-8625-4985-8948-7aaaf35da862">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-df9dc057-8625-4985-8948-7aaaf35da862">
											<gml:posList>35.67347158897165 139.73799742960892 28.021 35.67347158897165 139.73799742960892 28.512 35.673461828648 139.73796522908592 28.512 35.673461828648 139.73796522908592 28.021 35.67347158897165 139.73799742960892 28.021</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-24672cbe-2a53-4e97-b8b1-da067c18447c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-24672cbe-2a53-4e97-b8b1-da067c18447c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-24672cbe-2a53-4e97-b8b1-da067c18447c">
											<gml:posList>35.6733295543485 139.73795653805945 35.089 35.6733295543485 139.73795653805945 35.796 35.67334461086473 139.73800660573775 35.796 35.67334461086473 139.73800660573775 35.089 35.6733295543485 139.73795653805945 35.089</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-27ed806f-8565-4d66-a42f-334be0d7fb86">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-27ed806f-8565-4d66-a42f-334be0d7fb86">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-27ed806f-8565-4d66-a42f-334be0d7fb86">
											<gml:posList>35.673429225085314 139.73783897118668 29.018 35.67349944650109 139.73807222675197 26.316 35.673517204813585 139.73813081939514 8.64 35.673429225085314 139.73783897118668 29.018</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4c028d85-86f3-4477-a5ad-1f7939d49541">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4c028d85-86f3-4477-a5ad-1f7939d49541">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4c028d85-86f3-4477-a5ad-1f7939d49541">
											<gml:posList>35.673342065343476 139.73801338037163 35.796 35.673342065343476 139.73801338037163 28.512 35.67346469795156 139.73795755927378 28.512 35.67346469795156 139.73795755927378 32.097 35.67340624698105 139.73798416292846 32.097 35.67340624698105 139.73798416292846 35.796 35.673342065343476 139.73801338037163 35.796</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e43f802d-1f1e-4830-81c4-0b81e61de735">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e43f802d-1f1e-4830-81c4-0b81e61de735">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e43f802d-1f1e-4830-81c4-0b81e61de735">
											<gml:posList>35.673348395745336 139.73801687463865 28.512 35.673348395745336 139.73801687463865 28.021 35.673461828648 139.73796522908592 28.021 35.673461828648 139.73796522908592 28.512 35.673348395745336 139.73801687463865 28.512</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3653307d-a698-4017-b25c-6639fde22f55">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3653307d-a698-4017-b25c-6639fde22f55">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3653307d-a698-4017-b25c-6639fde22f55">
											<gml:posList>35.67340073713279 139.7379810543192 35.796 35.67340073713279 139.7379810543192 35.089 35.67334461086473 139.73800660573775 35.089 35.67334461086473 139.73800660573775 35.796 35.67340073713279 139.7379810543192 35.796</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e4fe24ed-a6b2-464b-ac21-5d24bcc3322b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e4fe24ed-a6b2-464b-ac21-5d24bcc3322b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e4fe24ed-a6b2-464b-ac21-5d24bcc3322b">
											<gml:posList>35.67347614827706 139.73799535845677 32.762 35.67347614827706 139.73799535845677 28.512 35.67347158897165 139.73799742960892 28.512 35.67347158897165 139.73799742960892 28.021 35.673451261328 139.7380066777622 28.021 35.673451261328 139.7380066777622 32.762 35.67347614827706 139.73799535845677 32.762</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7efb2895-0304-4511-a947-0cb67c22bb06">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7efb2895-0304-4511-a947-0cb67c22bb06">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7efb2895-0304-4511-a947-0cb67c22bb06">
											<gml:posList>35.673455806270546 139.73800923518834 32.762 35.673455806270546 139.73800923518834 32.359 35.67347405248907 139.7380009284786 32.359 35.67347405248907 139.7380009284786 32.762 35.673455806270546 139.73800923518834 32.762</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2d9f633d-8b7d-46c3-ae50-6585959811aa">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2d9f633d-8b7d-46c3-ae50-6585959811aa">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2d9f633d-8b7d-46c3-ae50-6585959811aa">
											<gml:posList>35.67346469795156 139.73795755927378 28.512 35.67347614827706 139.73799535845677 28.512 35.67349944650109 139.73807222675197 26.316 35.67346469795156 139.73795755927378 28.512</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-48e8b2d4-aeaf-404e-b1ee-7d06b2d3533e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-48e8b2d4-aeaf-404e-b1ee-7d06b2d3533e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-48e8b2d4-aeaf-404e-b1ee-7d06b2d3533e">
											<gml:posList>35.673463651495 139.73804754680697 32.762 35.673451261328 139.7380066777622 32.762 35.673451261328 139.7380066777622 28.021 35.673463651495 139.73804754680697 28.021 35.673463651495 139.73804754680697 32.762</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-158b0562-2ded-47fb-87ce-eb70840c1807">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-158b0562-2ded-47fb-87ce-eb70840c1807">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-158b0562-2ded-47fb-87ce-eb70840c1807">
											<gml:posList>35.673455806270546 139.73800923518834 32.359 35.673455806270546 139.73800923518834 32.762 35.67346819641918 139.73805008214248 32.762 35.67346819641918 139.73805008214248 32.359 35.673455806270546 139.73800923518834 32.359</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-44c4b1ee-28a8-4781-9778-453e2bcaa8bc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-44c4b1ee-28a8-4781-9778-453e2bcaa8bc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-44c4b1ee-28a8-4781-9778-453e2bcaa8bc">
											<gml:posList>35.67340306421488 139.73802854121018 32.582 35.67340306421488 139.73802854121018 28.021 35.67338602571871 139.73803670286387 28.021 35.67338602571871 139.73803670286387 32.582 35.67340306421488 139.73802854121018 32.582</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a18ab6e6-be6c-407a-ae49-3a32037dcb16">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a18ab6e6-be6c-407a-ae49-3a32037dcb16">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a18ab6e6-be6c-407a-ae49-3a32037dcb16">
											<gml:posList>35.67347614827706 139.73799535845677 28.512 35.67347614827706 139.73799535845677 32.762 35.67349944650109 139.73807222675197 32.762 35.67347614827706 139.73799535845677 28.512</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-400c6f1f-3039-40d0-8798-1ac0a669086b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-400c6f1f-3039-40d0-8798-1ac0a669086b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-400c6f1f-3039-40d0-8798-1ac0a669086b">
											<gml:posList>35.67347614827706 139.73799535845677 28.512 35.67349944650109 139.73807222675197 32.762 35.67349944650109 139.73807222675197 26.316 35.67347614827706 139.73799535845677 28.512</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a54d0344-5ee5-48f0-8cb0-40fffe67fc98">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a54d0344-5ee5-48f0-8cb0-40fffe67fc98">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a54d0344-5ee5-48f0-8cb0-40fffe67fc98">
											<gml:posList>35.67347405248907 139.7380009284786 32.762 35.67347405248907 139.7380009284786 32.359 35.673494892537455 139.73806965828487 32.359 35.673494892537455 139.73806965828487 32.762 35.67347405248907 139.7380009284786 32.762</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-87cec90c-c437-47ff-ac34-2e310229fb0d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-87cec90c-c437-47ff-ac34-2e310229fb0d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-87cec90c-c437-47ff-ac34-2e310229fb0d">
											<gml:posList>35.673410229875145 139.73805100163196 32.582 35.673410229875145 139.73805100163196 28.021 35.67340306421488 139.73802854121018 28.021 35.67340306421488 139.73802854121018 32.582 35.673410229875145 139.73805100163196 32.582</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3c9b77a0-51f8-4c48-8b7f-b6df476c8d0f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3c9b77a0-51f8-4c48-8b7f-b6df476c8d0f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3c9b77a0-51f8-4c48-8b7f-b6df476c8d0f">
											<gml:posList>35.67338602571871 139.73803670286387 32.582 35.67338602571871 139.73803670286387 28.021 35.67339318236375 139.73805916329235 28.021 35.67339318236375 139.73805916329235 32.582 35.67338602571871 139.73803670286387 32.582</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a09368b6-a152-42a6-b56f-8cc97da583f4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a09368b6-a152-42a6-b56f-8cc97da583f4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a09368b6-a152-42a6-b56f-8cc97da583f4">
											<gml:posList>35.673463651495 139.73804754680697 28.021 35.673447982269856 139.73805467949407 28.021 35.673447982269856 139.73805467949407 32.762 35.673463651495 139.73804754680697 32.762 35.673463651495 139.73804754680697 28.021</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8efbd528-f1f9-4029-aed7-d6c3223bf7e7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8efbd528-f1f9-4029-aed7-d6c3223bf7e7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8efbd528-f1f9-4029-aed7-d6c3223bf7e7">
											<gml:posList>35.673452527202635 139.73805722587616 32.762 35.673452527202635 139.73805722587616 32.359 35.67346819641918 139.73805008214248 32.359 35.67346819641918 139.73805008214248 32.762 35.673452527202635 139.73805722587616 32.762</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3fa8e460-445c-488c-8703-085d7210ba36">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3fa8e460-445c-488c-8703-085d7210ba36">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3fa8e460-445c-488c-8703-085d7210ba36">
											<gml:posList>35.67339318236375 139.73805916329235 28.021 35.673410229875145 139.73805100163196 28.021 35.673410229875145 139.73805100163196 32.582 35.67339318236375 139.73805916329235 32.582 35.67339318236375 139.73805916329235 28.021</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ad53214a-257f-4be2-bff8-4a94522e50ac">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ad53214a-257f-4be2-bff8-4a94522e50ac">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ad53214a-257f-4be2-bff8-4a94522e50ac">
											<gml:posList>35.673348395745336 139.73801687463865 28.021 35.673348395745336 139.73801687463865 28.512 35.673375458993156 139.73810172508865 28.512 35.673375458993156 139.73810172508865 28.021 35.673348395745336 139.73801687463865 28.021</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-08ebb0e7-1d5e-47c3-96d2-b0902cede05b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-08ebb0e7-1d5e-47c3-96d2-b0902cede05b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-08ebb0e7-1d5e-47c3-96d2-b0902cede05b">
											<gml:posList>35.673452527202635 139.73805722587616 32.359 35.673452527202635 139.73805722587616 32.762 35.673460986109774 139.73808510869947 32.762 35.673460986109774 139.73808510869947 32.359 35.673452527202635 139.73805722587616 32.359</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b0ac89c9-1049-4758-97e8-d6b01bd8702d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b0ac89c9-1049-4758-97e8-d6b01bd8702d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b0ac89c9-1049-4758-97e8-d6b01bd8702d">
											<gml:posList>35.673447982269856 139.73805467949407 28.021 35.67345127184633 139.7380655234265 28.021 35.67345127184633 139.7380655234265 28.512 35.67345293472282 139.73807102269836 28.512 35.67345293472282 139.73807102269836 25.546 35.673458899340055 139.73809068975388 25.546 35.673458899340055 139.73809068975388 32.762 35.673447982269856 139.73805467949407 32.762 35.673447982269856 139.73805467949407 28.021</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0e481747-2d60-4f6b-b96e-4ad68e472832">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0e481747-2d60-4f6b-b96e-4ad68e472832">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0e481747-2d60-4f6b-b96e-4ad68e472832">
											<gml:posList>35.673494892537455 139.73806965828487 32.762 35.673494892537455 139.73806965828487 32.359 35.673460986109774 139.73808510869947 32.359 35.673460986109774 139.73808510869947 32.762 35.673494892537455 139.73806965828487 32.762</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e60c2494-67b3-4649-a13e-e87885d2fb09">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e60c2494-67b3-4649-a13e-e87885d2fb09">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e60c2494-67b3-4649-a13e-e87885d2fb09">
											<gml:posList>35.673458899340055 139.73809068975388 25.546 35.6734955629872 139.73807399883677 25.546 35.6734955629872 139.73807399883677 26.316 35.67349944650109 139.73807222675197 26.316 35.67349944650109 139.73807222675197 32.762 35.673458899340055 139.73809068975388 32.762 35.673458899340055 139.73809068975388 25.546</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b577034a-c725-46c0-9e5a-442514224534">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b577034a-c725-46c0-9e5a-442514224534">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b577034a-c725-46c0-9e5a-442514224534">
											<gml:posList>35.673375458993156 139.73810172508865 28.021 35.673375458993156 139.73810172508865 28.512 35.67345127184633 139.7380655234265 28.512 35.67345127184633 139.7380655234265 28.021 35.673375458993156 139.73810172508865 28.021</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3ca03861-9f05-4ecf-b61c-6e1f464aee6a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3ca03861-9f05-4ecf-b61c-6e1f464aee6a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3ca03861-9f05-4ecf-b61c-6e1f464aee6a">
											<gml:posList>35.67337268886619 139.738109438956 28.512 35.67337268886619 139.738109438956 26.316 35.67337655429209 139.73810758957043 26.316 35.67337655429209 139.73810758957043 25.546 35.67345293472282 139.73807102269836 25.546 35.67345293472282 139.73807102269836 28.512 35.67337268886619 139.738109438956 28.512</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-13bd4f0b-ddf2-4863-ae35-290113d748bf">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-13bd4f0b-ddf2-4863-ae35-290113d748bf">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-13bd4f0b-ddf2-4863-ae35-290113d748bf">
											<gml:posList>35.673399560313236 139.7381797854061 26.316 35.673399560313236 139.7381797854061 25.546 35.67337655429209 139.73810758957043 25.546 35.67337655429209 139.73810758957043 26.316 35.673399560313236 139.7381797854061 26.316</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1797ba14-0548-4056-9367-c5b0f57b8d34">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1797ba14-0548-4056-9367-c5b0f57b8d34">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1797ba14-0548-4056-9367-c5b0f57b8d34">
											<gml:posList>35.673399560313236 139.7381797854061 26.316 35.67351188437078 139.73812785415353 26.316 35.67351188437078 139.73812785415353 25.546 35.673399560313236 139.7381797854061 25.546 35.673399560313236 139.7381797854061 26.316</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2f51acad-0382-4283-bdd5-ab27323ed3a3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2f51acad-0382-4283-bdd5-ab27323ed3a3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2f51acad-0382-4283-bdd5-ab27323ed3a3">
											<gml:posList>35.67339718584212 139.73818630576258 26.316 35.67339718584212 139.73818630576258 8.64 35.673517204813585 139.73813081939514 8.64 35.673517204813585 139.73813081939514 26.316 35.67339718584212 139.73818630576258 26.316</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ad71abad-e8bf-411a-aa13-94bf19799b5f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ad71abad-e8bf-411a-aa13-94bf19799b5f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ad71abad-e8bf-411a-aa13-94bf19799b5f">
											<gml:posList>35.6734955629872 139.73807399883677 26.316 35.6734955629872 139.73807399883677 25.546 35.67351188437078 139.73812785415353 25.546 35.67351188437078 139.73812785415353 26.316 35.6734955629872 139.73807399883677 26.316</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c6d2e947-45cd-4cdc-83dc-8f97de7fd3bc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c6d2e947-45cd-4cdc-83dc-8f97de7fd3bc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c6d2e947-45cd-4cdc-83dc-8f97de7fd3bc">
											<gml:posList>35.67349944650109 139.73807222675197 26.316 35.673517204813585 139.73813081939514 26.316 35.673517204813585 139.73813081939514 8.64 35.67349944650109 139.73807222675197 26.316</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂三丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-6928</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">243.4365</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1221</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>5</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.09</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>