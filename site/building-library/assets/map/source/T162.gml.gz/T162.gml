<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_29a671bb-3c25-404e-8003-58dd8909b70f">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="再開発等促進区を定める地区計画">
				<gen:value>虎ノ門駅南地区</gen:value>
			</gen:stringAttribute>
			<bldg:measuredHeight uom="m">12.7</bldg:measuredHeight>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.668739199189396 139.7498239382414 0 35.668779257561944 139.74984301026214 0 35.66880711547899 139.74975513558095 0 35.66876706609488 139.7497360635916 0 35.668739199189396 139.7498239382414 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668739199189396 139.7498239382414 5.887 35.66876706609488 139.7497360635916 5.887 35.66880711547899 139.74975513558095 5.887 35.668779257561944 139.74984301026214 5.887 35.668739199189396 139.7498239382414 5.887</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668739199189396 139.7498239382414 5.887 35.668779257561944 139.74984301026214 5.887 35.668779257561944 139.74984301026214 18.62 35.668739199189396 139.7498239382414 18.62 35.668739199189396 139.7498239382414 5.887</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668779257561944 139.74984301026214 5.887 35.66880711547899 139.74975513558095 5.887 35.66880711547899 139.74975513558095 18.62 35.668779257561944 139.74984301026214 18.62 35.668779257561944 139.74984301026214 5.887</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66880711547899 139.74975513558095 5.887 35.66876706609488 139.7497360635916 5.887 35.66876706609488 139.7497360635916 18.62 35.66880711547899 139.74975513558095 18.62 35.66880711547899 139.74975513558095 5.887</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66876706609488 139.7497360635916 5.887 35.668739199189396 139.7498239382414 5.887 35.668739199189396 139.7498239382414 18.62 35.66876706609488 139.7497360635916 18.62 35.66876706609488 139.7497360635916 5.887</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668739199189396 139.7498239382414 18.62 35.668779257561944 139.74984301026214 18.62 35.66880711547899 139.74975513558095 18.62 35.66876706609488 139.7497360635916 18.62 35.668739199189396 139.7498239382414 18.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-1678d434-3204-4e94-85c7-7bab6e50b288"/>
							<gml:surfaceMember xlink:href="#poly-99ae9682-bb77-46a9-84cf-6947c5e2e706"/>
							<gml:surfaceMember xlink:href="#poly-14c1bce2-6a86-48a3-b807-61d9018f8685"/>
							<gml:surfaceMember xlink:href="#poly-236004a4-5766-4c9c-882b-93c954b8a36c"/>
							<gml:surfaceMember xlink:href="#poly-0d2f329f-3c38-430b-af4a-b6df9337d0ce"/>
							<gml:surfaceMember xlink:href="#poly-29ff7d21-5eb2-43e6-b48f-a62427a0dae7"/>
							<gml:surfaceMember xlink:href="#poly-2fe827b5-cb3b-4348-a4a8-25e3a2516b02"/>
							<gml:surfaceMember xlink:href="#poly-bcca1bfc-96b2-4eca-bb53-3fe420f6b2c2"/>
							<gml:surfaceMember xlink:href="#poly-ed76617e-f147-4b63-92ad-9d65830dc2c2"/>
							<gml:surfaceMember xlink:href="#poly-f777babb-f065-4e9d-89d5-1935cf2f7916"/>
							<gml:surfaceMember xlink:href="#poly-ad48c8d3-3f57-439f-a2e9-624f5eb95f7a"/>
							<gml:surfaceMember xlink:href="#poly-fe784266-d67d-4e94-b614-ea561b864321"/>
							<gml:surfaceMember xlink:href="#poly-92993697-4013-4319-a218-80d521fd11f2"/>
							<gml:surfaceMember xlink:href="#poly-ee298d5e-fa83-4c18-b1dc-7a0c86ca7ebc"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-1678d434-3204-4e94-85c7-7bab6e50b288">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1678d434-3204-4e94-85c7-7bab6e50b288">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1678d434-3204-4e94-85c7-7bab6e50b288">
											<gml:posList>35.668739140854576 139.7498239697198 5.887 35.66876704041168 139.74973599210728 5.887 35.668807173807934 139.74975510410417 5.887 35.668779283250835 139.74984308174476 5.887 35.668739140854576 139.7498239697198 5.887</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-99ae9682-bb77-46a9-84cf-6947c5e2e706">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-99ae9682-bb77-46a9-84cf-6947c5e2e706">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-99ae9682-bb77-46a9-84cf-6947c5e2e706">
											<gml:posList>35.668739140854576 139.7498239697198 18.9 35.66874149256413 139.74982270802258 18.9 35.6687680789918 139.74973887404045 18.9 35.66876704041168 139.74973599210728 18.9 35.668739140854576 139.7498239697198 18.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-14c1bce2-6a86-48a3-b807-61d9018f8685">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-14c1bce2-6a86-48a3-b807-61d9018f8685">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-14c1bce2-6a86-48a3-b807-61d9018f8685">
											<gml:posList>35.668779283250835 139.74984308174476 18.9 35.66877825368694 139.74984019980045 18.9 35.66874149256413 139.74982270802258 18.9 35.668739140854576 139.7498239697198 18.9 35.668779283250835 139.74984308174476 18.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-236004a4-5766-4c9c-882b-93c954b8a36c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-236004a4-5766-4c9c-882b-93c954b8a36c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-236004a4-5766-4c9c-882b-93c954b8a36c">
											<gml:posList>35.668804831112844 139.74975636579504 18.418 35.6687680789918 139.74973887404045 18.418 35.66874149256413 139.74982270802258 18.418 35.66877825368694 139.74984019980045 18.418 35.668804831112844 139.74975636579504 18.418</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-0d2f329f-3c38-430b-af4a-b6df9337d0ce">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0d2f329f-3c38-430b-af4a-b6df9337d0ce">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0d2f329f-3c38-430b-af4a-b6df9337d0ce">
											<gml:posList>35.66876704041168 139.74973599210728 18.9 35.6687680789918 139.74973887404045 18.9 35.668804831112844 139.74975636579504 18.9 35.668807173807934 139.74975510410417 18.9 35.66876704041168 139.74973599210728 18.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-29ff7d21-5eb2-43e6-b48f-a62427a0dae7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-29ff7d21-5eb2-43e6-b48f-a62427a0dae7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-29ff7d21-5eb2-43e6-b48f-a62427a0dae7">
											<gml:posList>35.668807173807934 139.74975510410417 18.9 35.668804831112844 139.74975636579504 18.9 35.66877825368694 139.74984019980045 18.9 35.668779283250835 139.74984308174476 18.9 35.668807173807934 139.74975510410417 18.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2fe827b5-cb3b-4348-a4a8-25e3a2516b02">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2fe827b5-cb3b-4348-a4a8-25e3a2516b02">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2fe827b5-cb3b-4348-a4a8-25e3a2516b02">
											<gml:posList>35.668807173807934 139.74975510410417 5.887 35.66876704041168 139.74973599210728 5.887 35.66876704041168 139.74973599210728 18.9 35.668807173807934 139.74975510410417 18.9 35.668807173807934 139.74975510410417 5.887</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-bcca1bfc-96b2-4eca-bb53-3fe420f6b2c2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bcca1bfc-96b2-4eca-bb53-3fe420f6b2c2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bcca1bfc-96b2-4eca-bb53-3fe420f6b2c2">
											<gml:posList>35.6687680789918 139.74973887404045 18.9 35.6687680789918 139.74973887404045 18.418 35.668804831112844 139.74975636579504 18.418 35.668804831112844 139.74975636579504 18.9 35.6687680789918 139.74973887404045 18.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ed76617e-f147-4b63-92ad-9d65830dc2c2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ed76617e-f147-4b63-92ad-9d65830dc2c2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ed76617e-f147-4b63-92ad-9d65830dc2c2">
											<gml:posList>35.66876704041168 139.74973599210728 5.887 35.668739140854576 139.7498239697198 5.887 35.668739140854576 139.7498239697198 18.9 35.66876704041168 139.74973599210728 18.9 35.66876704041168 139.74973599210728 5.887</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f777babb-f065-4e9d-89d5-1935cf2f7916">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f777babb-f065-4e9d-89d5-1935cf2f7916">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f777babb-f065-4e9d-89d5-1935cf2f7916">
											<gml:posList>35.66874149256413 139.74982270802258 18.9 35.66874149256413 139.74982270802258 18.418 35.6687680789918 139.74973887404045 18.418 35.6687680789918 139.74973887404045 18.9 35.66874149256413 139.74982270802258 18.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ad48c8d3-3f57-439f-a2e9-624f5eb95f7a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ad48c8d3-3f57-439f-a2e9-624f5eb95f7a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ad48c8d3-3f57-439f-a2e9-624f5eb95f7a">
											<gml:posList>35.668804831112844 139.74975636579504 18.9 35.668804831112844 139.74975636579504 18.418 35.66877825368694 139.74984019980045 18.418 35.66877825368694 139.74984019980045 18.9 35.668804831112844 139.74975636579504 18.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-fe784266-d67d-4e94-b614-ea561b864321">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fe784266-d67d-4e94-b614-ea561b864321">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fe784266-d67d-4e94-b614-ea561b864321">
											<gml:posList>35.668779283250835 139.74984308174476 5.887 35.668807173807934 139.74975510410417 5.887 35.668807173807934 139.74975510410417 18.9 35.668779283250835 139.74984308174476 18.9 35.668779283250835 139.74984308174476 5.887</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-92993697-4013-4319-a218-80d521fd11f2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-92993697-4013-4319-a218-80d521fd11f2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-92993697-4013-4319-a218-80d521fd11f2">
											<gml:posList>35.66877825368694 139.74984019980045 18.9 35.66877825368694 139.74984019980045 18.418 35.66874149256413 139.74982270802258 18.418 35.66874149256413 139.74982270802258 18.9 35.66877825368694 139.74984019980045 18.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ee298d5e-fa83-4c18-b1dc-7a0c86ca7ebc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ee298d5e-fa83-4c18-b1dc-7a0c86ca7ebc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ee298d5e-fa83-4c18-b1dc-7a0c86ca7ebc">
											<gml:posList>35.668739140854576 139.7498239697198 5.887 35.668779283250835 139.74984308174476 5.887 35.668779283250835 139.74984308174476 18.9 35.668739140854576 139.7498239697198 18.9 35.668739140854576 139.7498239697198 5.887</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-8</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">211</uro:landUseType>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>7</uro:specifiedFloorAreaRate>
					<uro:surveyYear>0001</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>