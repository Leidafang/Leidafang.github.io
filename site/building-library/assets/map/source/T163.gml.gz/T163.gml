<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_29a7632d-d6d2-4a89-a1ea-3349161cedfa">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>29</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103029002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">401</bldg:usage>
			<bldg:measuredHeight uom="m">59.6</bldg:measuredHeight>
			<bldg:storeysAboveGround>20</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.66771881025997 139.73908553015346 0 35.66763672055341 139.73902589051298 0 35.66760900316005 139.73908325121613 0 35.6675776174933 139.7390604231492 0 35.667569248216694 139.7390776645492 0 35.66755887655162 139.73907016554867 0 35.66751298121594 139.73916565576891 0 35.667670185513074 139.73928708635756 0 35.6677460666844 139.73913018981386 0 35.6677099100778 139.73910393202374 0 35.66771881025997 139.73908553015346 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66771881025997 139.73908553015346 11.69 35.6677099100778 139.73910393202374 11.69 35.6677460666844 139.73913018981386 11.69 35.667670185513074 139.73928708635756 11.69 35.66751298121594 139.73916565576891 11.69 35.66755887655162 139.73907016554867 11.69 35.667569248216694 139.7390776645492 11.69 35.6675776174933 139.7390604231492 11.69 35.66760900316005 139.73908325121613 11.69 35.66763672055341 139.73902589051298 11.69 35.66771881025997 139.73908553015346 11.69</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66771881025997 139.73908553015346 11.69 35.66763672055341 139.73902589051298 11.69 35.66763672055341 139.73902589051298 71.33 35.66771881025997 139.73908553015346 71.33 35.66771881025997 139.73908553015346 11.69</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66763672055341 139.73902589051298 11.69 35.66760900316005 139.73908325121613 11.69 35.66760900316005 139.73908325121613 71.33 35.66763672055341 139.73902589051298 71.33 35.66763672055341 139.73902589051298 11.69</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66760900316005 139.73908325121613 11.69 35.6675776174933 139.7390604231492 11.69 35.6675776174933 139.7390604231492 71.33 35.66760900316005 139.73908325121613 71.33 35.66760900316005 139.73908325121613 11.69</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6675776174933 139.7390604231492 11.69 35.667569248216694 139.7390776645492 11.69 35.667569248216694 139.7390776645492 71.33 35.6675776174933 139.7390604231492 71.33 35.6675776174933 139.7390604231492 11.69</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667569248216694 139.7390776645492 11.69 35.66755887655162 139.73907016554867 11.69 35.66755887655162 139.73907016554867 71.33 35.667569248216694 139.7390776645492 71.33 35.667569248216694 139.7390776645492 11.69</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66755887655162 139.73907016554867 11.69 35.66751298121594 139.73916565576891 11.69 35.66751298121594 139.73916565576891 71.33 35.66755887655162 139.73907016554867 71.33 35.66755887655162 139.73907016554867 11.69</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66751298121594 139.73916565576891 11.69 35.667670185513074 139.73928708635756 11.69 35.667670185513074 139.73928708635756 71.33 35.66751298121594 139.73916565576891 71.33 35.66751298121594 139.73916565576891 11.69</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667670185513074 139.73928708635756 11.69 35.6677460666844 139.73913018981386 11.69 35.6677460666844 139.73913018981386 71.33 35.667670185513074 139.73928708635756 71.33 35.667670185513074 139.73928708635756 11.69</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6677460666844 139.73913018981386 11.69 35.6677099100778 139.73910393202374 11.69 35.6677099100778 139.73910393202374 71.33 35.6677460666844 139.73913018981386 71.33 35.6677460666844 139.73913018981386 11.69</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6677099100778 139.73910393202374 11.69 35.66771881025997 139.73908553015346 11.69 35.66771881025997 139.73908553015346 71.33 35.6677099100778 139.73910393202374 71.33 35.6677099100778 139.73910393202374 11.69</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66771881025997 139.73908553015346 71.33 35.66763672055341 139.73902589051298 71.33 35.66760900316005 139.73908325121613 71.33 35.6675776174933 139.7390604231492 71.33 35.667569248216694 139.7390776645492 71.33 35.66755887655162 139.73907016554867 71.33 35.66751298121594 139.73916565576891 71.33 35.667670185513074 139.73928708635756 71.33 35.6677460666844 139.73913018981386 71.33 35.6677099100778 139.73910393202374 71.33 35.66771881025997 139.73908553015346 71.33</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-9e7aa61a-fe88-43b8-990e-36ae6032e265"/>
							<gml:surfaceMember xlink:href="#poly-4b463024-8729-41b4-a223-391874a517e6"/>
							<gml:surfaceMember xlink:href="#poly-0a8e9bf2-ebd9-40e6-9728-b4783984b1e1"/>
							<gml:surfaceMember xlink:href="#poly-a2c0e245-7257-4daf-b25d-1c269ab20e11"/>
							<gml:surfaceMember xlink:href="#poly-d667e40f-d1c8-45b7-a488-7c39c5dabe0a"/>
							<gml:surfaceMember xlink:href="#poly-1161fba7-398a-4b47-a6a9-2dc4f3b775d6"/>
							<gml:surfaceMember xlink:href="#poly-13a690c8-e997-4698-88df-3272c3a2cecd"/>
							<gml:surfaceMember xlink:href="#poly-da55eafe-e919-488b-bd8d-1bad6485fdcc"/>
							<gml:surfaceMember xlink:href="#poly-e6ee2339-26f4-4e19-8ff3-706d4e27738e"/>
							<gml:surfaceMember xlink:href="#poly-64860ef7-fdb9-495b-b2c0-b4dfaa51116c"/>
							<gml:surfaceMember xlink:href="#poly-450c1ee7-4b25-4e1c-8a3a-990e594a8dcf"/>
							<gml:surfaceMember xlink:href="#poly-c5ed334d-723a-448f-aa0e-06b039546281"/>
							<gml:surfaceMember xlink:href="#poly-b687aaf1-4f92-460e-b480-f9cd73bdb72b"/>
							<gml:surfaceMember xlink:href="#poly-43efcb7a-df6d-487a-8cf7-b686d05ef069"/>
							<gml:surfaceMember xlink:href="#poly-48c6847a-e23a-4f4a-b4f1-eab4e6d0ae32"/>
							<gml:surfaceMember xlink:href="#poly-ab5bd4fe-9a07-4341-941e-9c5148506cfa"/>
							<gml:surfaceMember xlink:href="#poly-07699f4b-b418-4181-8ff4-bb9de3b25fd0"/>
							<gml:surfaceMember xlink:href="#poly-3e83c208-ebe5-4a0a-a6fd-0fa61af0fa33"/>
							<gml:surfaceMember xlink:href="#poly-29848284-ddcb-4ec7-be2e-0e47f7c82569"/>
							<gml:surfaceMember xlink:href="#poly-0e9cd9a6-678b-4294-94ca-3fe77aec6dde"/>
							<gml:surfaceMember xlink:href="#poly-f4c891a7-c290-4c1b-af61-7ff9f77d081c"/>
							<gml:surfaceMember xlink:href="#poly-e444cb65-983e-4be8-a236-6e7bf1e8966b"/>
							<gml:surfaceMember xlink:href="#poly-3102a825-e325-4f8d-a262-4b68b5610606"/>
							<gml:surfaceMember xlink:href="#poly-1d4f143c-3c16-415f-99ef-5167f2f71c7c"/>
							<gml:surfaceMember xlink:href="#poly-c4eabb7a-d702-46fe-b54c-98327ca3f0c2"/>
							<gml:surfaceMember xlink:href="#poly-cbc26ec6-17d5-43a7-bb02-564162272ef8"/>
							<gml:surfaceMember xlink:href="#poly-d93003ba-6da7-4b5c-9114-dc85dc05fc0e"/>
							<gml:surfaceMember xlink:href="#poly-ea60b6c9-40b6-4813-abf4-26841c21f5c1"/>
							<gml:surfaceMember xlink:href="#poly-04a590b0-49be-4aba-80aa-b1ed24b52cf0"/>
							<gml:surfaceMember xlink:href="#poly-0384720a-d8aa-4ccc-bfb1-00b8a513cd96"/>
							<gml:surfaceMember xlink:href="#poly-76936894-8d9a-4682-b63c-a9eb9880e3b6"/>
							<gml:surfaceMember xlink:href="#poly-3f506f33-22bd-4e96-b433-514a1e2d3429"/>
							<gml:surfaceMember xlink:href="#poly-938d3d0a-1766-47dd-bac7-3a4d08acd2ec"/>
							<gml:surfaceMember xlink:href="#poly-2aeb5e26-5e91-45de-946d-c7c08949a1b0"/>
							<gml:surfaceMember xlink:href="#poly-d41231d3-a14f-44c3-a33d-da8010aa7721"/>
							<gml:surfaceMember xlink:href="#poly-b2e7ef9e-b065-43a9-8cfc-1c5137e7c2e3"/>
							<gml:surfaceMember xlink:href="#poly-b30d37c6-de27-4970-85aa-6072fb0c1a7c"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_29a7632d-d6d2-4a89-a1ea-3349161cedfa_BuildingInstallation_1041">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a970dfba-2532-4b48-aee5-99d0c0fd6fda">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667643200518825 139.7392321205593 71.435 35.667618435237955 139.73921476340908 71.435 35.66762801882252 139.7391942399608 71.435 35.66765278410629 139.73921159710673 71.435 35.667643200518825 139.7392321205593 71.435</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8fec8656-1357-49d1-a63c-5774d4c65150">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8fec8656-1357-49d1-a63c-5774d4c65150_0">
											<gml:posList>35.667618435237955 139.73921476340908 71.435 35.667618435237955 139.73921476340908 74.513 35.66762801882252 139.7391942399608 74.513 35.66762801882252 139.7391942399608 71.435 35.667618435237955 139.73921476340908 71.435</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a644c99b-67ce-4313-9862-506d6e9fef51">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a644c99b-67ce-4313-9862-506d6e9fef51_0">
											<gml:posList>35.667643200518825 139.7392321205593 71.435 35.667643200518825 139.7392321205593 74.513 35.667618435237955 139.73921476340908 74.513 35.667618435237955 139.73921476340908 71.435 35.667643200518825 139.7392321205593 71.435</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-be589146-2289-4285-8507-058621dda1cd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-be589146-2289-4285-8507-058621dda1cd_0">
											<gml:posList>35.667643200518825 139.7392321205593 74.513 35.66765278410629 139.73921159710673 74.513 35.66762801882252 139.7391942399608 74.513 35.667618435237955 139.73921476340908 74.513 35.667643200518825 139.7392321205593 74.513</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1e06bbbf-aa78-4731-a94b-9af9c4938295">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1e06bbbf-aa78-4731-a94b-9af9c4938295_0">
											<gml:posList>35.66762801882252 139.7391942399608 71.435 35.66762801882252 139.7391942399608 74.513 35.66765278410629 139.73921159710673 74.513 35.66765278410629 139.73921159710673 71.435 35.66762801882252 139.7391942399608 71.435</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cb2d0b89-234e-4430-ae1d-dd2461f6414c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cb2d0b89-234e-4430-ae1d-dd2461f6414c_0">
											<gml:posList>35.66765278410629 139.73921159710673 71.435 35.66765278410629 139.73921159710673 74.513 35.667643200518825 139.7392321205593 74.513 35.667643200518825 139.7392321205593 71.435 35.66765278410629 139.73921159710673 71.435</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_29a7632d-d6d2-4a89-a1ea-3349161cedfa_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c265b6c8-5289-465e-821d-bef63d9cd0a9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66764778191996 139.7391660387114 71.435 35.66766343004651 139.73917792779883 71.435 35.66765354825194 139.73919747957044 71.435 35.66763789111357 139.73918559049125 71.435 35.66764778191996 139.7391660387114 71.435</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4a91713c-755b-4a4a-a957-d512c648050c">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6676513191107 139.73913633217705 71.435 35.667685230290694 139.73916131127672 71.435 35.66767925470392 139.73917350190823 71.435 35.6676453345127 139.7391485228158 71.435 35.6676513191107 139.73913633217705 71.435</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-64c44930-50ba-48db-9edd-99124c663a32">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66772204195613 139.7391722918454 71.435 35.66771738036869 139.73918191829182 71.435 35.6676942109251 139.73916508946962 71.435 35.66769887251122 139.73915546302504 71.435 35.66772204195613 139.7391722918454 71.435</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7d862d12-6780-432d-b229-46de9df95d7a">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66772204195613 139.7391722918454 72.538 35.66769887251122 139.73915546302504 72.538 35.66770050142987 139.7391521804825 72.538 35.66772557385121 139.73917038780422 72.538 35.66771931942534 139.73918332988927 72.538 35.66771738036869 139.73918191829182 72.538 35.66772204195613 139.7391722918454 72.538</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-46474aff-ac75-4fd8-a7a6-4bcf6a3202b1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-46474aff-ac75-4fd8-a7a6-4bcf6a3202b1_0">
											<gml:posList>35.66764778191996 139.7391660387114 71.435 35.66764778191996 139.7391660387114 74.02 35.66766343004651 139.73917792779883 74.02 35.66766343004651 139.73917792779883 71.435 35.66764778191996 139.7391660387114 71.435</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1485e58e-fcad-457b-af6c-d0a10a44562f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1485e58e-fcad-457b-af6c-d0a10a44562f_0">
											<gml:posList>35.66772557385121 139.73917038780422 72.538 35.66770050142987 139.7391521804825 72.538 35.66770050142987 139.7391521804825 73.129 35.66772557385121 139.73917038780422 73.129 35.66772557385121 139.73917038780422 72.538</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8529ce71-df22-4160-843c-0267d5bf6e86">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8529ce71-df22-4160-843c-0267d5bf6e86_0">
											<gml:posList>35.6676513191107 139.73913633217705 71.435 35.6676453345127 139.7391485228158 71.435 35.6676453345127 139.7391485228158 74.491 35.6676513191107 139.73913633217705 74.491 35.6676513191107 139.73913633217705 71.435</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f91c3709-1381-43ee-a79a-d8bde60fee84">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f91c3709-1381-43ee-a79a-d8bde60fee84_0">
											<gml:posList>35.6676513191107 139.73913633217705 71.435 35.6676513191107 139.73913633217705 74.491 35.667685230290694 139.73916131127672 74.491 35.667685230290694 139.73916131127672 71.435 35.6676513191107 139.73913633217705 71.435</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ebdcf6ac-4f04-41ce-ab7f-31f39f590bb6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ebdcf6ac-4f04-41ce-ab7f-31f39f590bb6_0">
											<gml:posList>35.6676513191107 139.73913633217705 74.491 35.6676453345127 139.7391485228158 74.491 35.66767925470392 139.73917350190823 74.491 35.667685230290694 139.73916131127672 74.491 35.6676513191107 139.73913633217705 74.491</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-53c80392-db7b-40d0-8d54-52774513c2ac">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-53c80392-db7b-40d0-8d54-52774513c2ac_0">
											<gml:posList>35.6676942109251 139.73916508946962 71.435 35.6676942109251 139.73916508946962 73.129 35.66770050142987 139.7391521804825 73.129 35.66770050142987 139.7391521804825 72.538 35.66769887251122 139.73915546302504 72.538 35.66769887251122 139.73915546302504 71.435 35.6676942109251 139.73916508946962 71.435</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-603b7d6c-24c6-43a6-9654-824b1509a7d8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-603b7d6c-24c6-43a6-9654-824b1509a7d8_0">
											<gml:posList>35.6676453345127 139.7391485228158 71.435 35.66767925470392 139.73917350190823 71.435 35.66767925470392 139.73917350190823 74.491 35.6676453345127 139.7391485228158 74.491 35.6676453345127 139.7391485228158 71.435</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6282ae0e-e196-46e2-bd60-041089ff7a3c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6282ae0e-e196-46e2-bd60-041089ff7a3c_0">
											<gml:posList>35.66770053750206 139.7391522025319 72.538 35.66772557385121 139.73917038780422 72.626 35.66772557385121 139.73917038780422 72.538 35.66770053750206 139.7391522025319 72.538</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e5b2bcd1-10a3-4575-8d61-f17bb839cdea">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e5b2bcd1-10a3-4575-8d61-f17bb839cdea_0">
											<gml:posList>35.66770053750206 139.7391522025319 73.129 35.66772557385121 139.73917038780422 72.626 35.66770053750206 139.7391522025319 72.538 35.66770053750206 139.7391522025319 73.129</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-54f13303-b4be-4474-868d-2ebed607baab">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-54f13303-b4be-4474-868d-2ebed607baab_0">
											<gml:posList>35.667721127553264 139.73916715657893 73.129 35.66772557385121 139.73917038780422 72.626 35.66770053750206 139.7391522025319 73.129 35.667721127553264 139.73916715657893 73.129</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ada398a5-7fe8-472e-baf5-8922b17f4dfb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ada398a5-7fe8-472e-baf5-8922b17f4dfb_0">
											<gml:posList>35.66769887251122 139.73915546302504 71.435 35.66769887251122 139.73915546302504 72.538 35.66772204195613 139.7391722918454 72.538 35.66772204195613 139.7391722918454 71.435 35.66769887251122 139.73915546302504 71.435</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9cd7ec99-fd2a-44a0-bbd1-62cbbfe01841">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9cd7ec99-fd2a-44a0-bbd1-62cbbfe01841_0">
											<gml:posList>35.66767925470392 139.73917350190823 71.435 35.667685230290694 139.73916131127672 71.435 35.667685230290694 139.73916131127672 74.491 35.66767925470392 139.73917350190823 74.491 35.66767925470392 139.73917350190823 71.435</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f6ffe530-36d1-4998-b740-a22afddcc99b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f6ffe530-36d1-4998-b740-a22afddcc99b_0">
											<gml:posList>35.66770050142987 139.7391521804825 73.129 35.6676942109251 139.73916508946962 73.129 35.66771931942534 139.73918332988927 73.129 35.66772557385121 139.73917038780422 73.129 35.66770050142987 139.7391521804825 73.129</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f5a40f7a-0876-4703-8522-ef8697ed2344">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f5a40f7a-0876-4703-8522-ef8697ed2344_0">
											<gml:posList>35.667721127553264 139.73916715657893 73.129 35.66772557385121 139.73917038780422 73.129 35.66772557385121 139.73917038780422 72.626 35.667721127553264 139.73916715657893 73.129</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8a864208-3d68-40dc-beb6-87fe25474bbe">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8a864208-3d68-40dc-beb6-87fe25474bbe_0">
											<gml:posList>35.66771931942534 139.73918332988927 73.129 35.6676942109251 139.73916508946962 73.129 35.6676942109251 139.73916508946962 71.435 35.66771738036869 139.73918191829182 71.435 35.66771738036869 139.73918191829182 72.538 35.66771931942534 139.73918332988927 72.538 35.66771931942534 139.73918332988927 73.129</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9eca0916-155b-4e3c-8538-7a553fd3f8f9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9eca0916-155b-4e3c-8538-7a553fd3f8f9_0">
											<gml:posList>35.66763789111357 139.73918559049125 74.02 35.66764778191996 139.7391660387114 74.02 35.66764778191996 139.7391660387114 71.435 35.66763789111357 139.73918559049125 71.435 35.66763789111357 139.73918559049125 74.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2c13a6cb-3ee6-4e39-9313-00807977740f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2c13a6cb-3ee6-4e39-9313-00807977740f_0">
											<gml:posList>35.66771931942534 139.73918332988927 72.538 35.66772557385121 139.73917038780422 72.538 35.66772557385121 139.73917038780422 73.129 35.66771931942534 139.73918332988927 73.129 35.66771931942534 139.73918332988927 72.538</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d4395a4a-6535-4ec5-910b-503b7f871a94">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d4395a4a-6535-4ec5-910b-503b7f871a94_0">
											<gml:posList>35.66772204195613 139.7391722918454 72.538 35.66771738036869 139.73918191829182 72.538 35.66771738036869 139.73918191829182 71.435 35.66772204195613 139.7391722918454 71.435 35.66772204195613 139.7391722918454 72.538</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3c21a349-8d90-4434-9fce-366f62a161fb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3c21a349-8d90-4434-9fce-366f62a161fb_0">
											<gml:posList>35.66764778191996 139.7391660387114 74.02 35.66763789111357 139.73918559049125 74.02 35.66765354825194 139.73919747957044 74.02 35.66766343004651 139.73917792779883 74.02 35.66764778191996 139.7391660387114 74.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7f42ed93-3652-4c90-8139-28efa9cc95b6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7f42ed93-3652-4c90-8139-28efa9cc95b6_0">
											<gml:posList>35.66765354825194 139.73919747957044 71.435 35.66766343004651 139.73917792779883 71.435 35.66766343004651 139.73917792779883 74.02 35.66765354825194 139.73919747957044 74.02 35.66765354825194 139.73919747957044 71.435</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e69edae9-b04d-4f4a-994a-431bd8827f9d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e69edae9-b04d-4f4a-994a-431bd8827f9d_0">
											<gml:posList>35.66765354825194 139.73919747957044 71.435 35.66765354825194 139.73919747957044 74.02 35.66763789111357 139.73918559049125 74.02 35.66763789111357 139.73918559049125 71.435 35.66765354825194 139.73919747957044 71.435</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_29a7632d-d6d2-4a89-a1ea-3349161cedfa_BuildingInstallation_1060">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6c15bf7c-87d7-42ad-ac6e-757461f2d198">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66771881025998 139.73908553015346 11.69 35.66775495786546 139.73911179899468 11.69 35.667746066684394 139.7391301898139 11.69 35.66770991007777 139.73910393202374 11.69 35.66771881025998 139.73908553015346 11.69</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c5484285-b8da-4e49-a04e-912cb88ba57a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c5484285-b8da-4e49-a04e-912cb88ba57a_0">
											<gml:posList>35.66771881025998 139.73908553015346 72.538 35.66771881025998 139.73908553015346 11.69 35.66770991007777 139.73910393202374 11.69 35.66770991007777 139.73910393202374 72.538 35.66771881025998 139.73908553015346 72.538</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-00ab188c-96a9-44e5-bb98-e43165941dfb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-00ab188c-96a9-44e5-bb98-e43165941dfb_0">
											<gml:posList>35.66775495786546 139.73911179899468 11.69 35.66771881025998 139.73908553015346 11.69 35.66771881025998 139.73908553015346 72.538 35.66775495786546 139.73911179899468 69.799 35.66775495786546 139.73911179899468 11.69</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-130738b6-4442-4333-974b-740666ce5af0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-130738b6-4442-4333-974b-740666ce5af0_0">
											<gml:posList>35.667746066684394 139.7391301898139 69.799 35.66775495786546 139.73911179899468 69.799 35.66771881025998 139.73908553015346 72.538 35.66770991007777 139.73910393202374 72.538 35.667746066684394 139.7391301898139 69.799</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ef4b18fe-506d-4962-a05d-e714c5cde3ad">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ef4b18fe-506d-4962-a05d-e714c5cde3ad_0">
											<gml:posList>35.667746066684394 139.7391301898139 69.799 35.66770991007777 139.73910393202374 72.538 35.66770991007777 139.73910393202374 11.69 35.667746066684394 139.7391301898139 11.69 35.667746066684394 139.7391301898139 69.799</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bfe2669e-403a-456e-9fd7-1a60f18bfdc2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bfe2669e-403a-456e-9fd7-1a60f18bfdc2_0">
											<gml:posList>35.667746066684394 139.7391301898139 11.69 35.66775495786546 139.73911179899468 11.69 35.66775495786546 139.73911179899468 69.799 35.667746066684394 139.7391301898139 69.799 35.667746066684394 139.7391301898139 11.69</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-9e7aa61a-fe88-43b8-990e-36ae6032e265">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9e7aa61a-fe88-43b8-990e-36ae6032e265">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9e7aa61a-fe88-43b8-990e-36ae6032e265">
											<gml:posList>35.667670185513046 139.73928708635756 11.69 35.66751298121595 139.73916565576891 11.69 35.66755887655159 139.73907016554867 11.69 35.6675692482167 139.7390776645492 11.69 35.667577617493286 139.7390604231492 11.69 35.66760900316006 139.73908325121613 11.69 35.66763672055342 139.73902589051298 11.69 35.66771881025998 139.73908553015346 11.69 35.66770991007777 139.73910393202374 11.69 35.667746066684394 139.7391301898139 11.69 35.667670185513046 139.73928708635756 11.69</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-4b463024-8729-41b4-a223-391874a517e6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4b463024-8729-41b4-a223-391874a517e6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4b463024-8729-41b4-a223-391874a517e6">
											<gml:posList>35.66755999837808 139.7390754331103 72.538 35.6675703520154 139.73908293213276 72.538 35.6675692482167 139.7390776645492 72.538 35.66755887655159 139.73907016554867 72.538 35.66755999837808 139.7390754331103 72.538</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-0a8e9bf2-ebd9-40e6-9728-b4783984b1e1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0a8e9bf2-ebd9-40e6-9728-b4783984b1e1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0a8e9bf2-ebd9-40e6-9728-b4783984b1e1">
											<gml:posList>35.66755999837808 139.7390754331103 72.538 35.66755887655159 139.73907016554867 72.538 35.66751298121595 139.73916565576891 72.538 35.66751724371529 139.73916438048872 72.538 35.66755999837808 139.7390754331103 72.538</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a2c0e245-7257-4daf-b25d-1c269ab20e11">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a2c0e245-7257-4daf-b25d-1c269ab20e11">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a2c0e245-7257-4daf-b25d-1c269ab20e11">
											<gml:posList>35.66771451176724 139.7390868828046 72.538 35.66771881025998 139.73908553015346 72.538 35.66763672055342 139.73902589051298 72.538 35.66763782436302 139.73903116914613 72.538 35.66771451176724 139.7390868828046 72.538</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d667e40f-d1c8-45b7-a488-7c39c5dabe0a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d667e40f-d1c8-45b7-a488-7c39c5dabe0a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d667e40f-d1c8-45b7-a488-7c39c5dabe0a">
											<gml:posList>35.66763782436302 139.73903116914613 72.538 35.66763672055342 139.73902589051298 72.538 35.66760900316006 139.73908325121613 72.538 35.667610115980885 139.7390885298377 72.538 35.66763782436302 139.73903116914613 72.538</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-1161fba7-398a-4b47-a6a9-2dc4f3b775d6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1161fba7-398a-4b47-a6a9-2dc4f3b775d6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1161fba7-398a-4b47-a6a9-2dc4f3b775d6">
											<gml:posList>35.66757872129274 139.73906569073307 72.538 35.667577617493286 139.7390604231492 72.538 35.6675692482167 139.7390776645492 72.538 35.6675703520154 139.73908293213276 72.538 35.66757872129274 139.73906569073307 72.538</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-13a690c8-e997-4698-88df-3272c3a2cecd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-13a690c8-e997-4698-88df-3272c3a2cecd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-13a690c8-e997-4698-88df-3272c3a2cecd">
											<gml:posList>35.66757872129274 139.73906569073307 72.538 35.667610115980885 139.7390885298377 72.538 35.66760900316006 139.73908325121613 72.538 35.667577617493286 139.7390604231492 72.538 35.66757872129274 139.73906569073307 72.538</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-da55eafe-e919-488b-bd8d-1bad6485fdcc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-da55eafe-e919-488b-bd8d-1bad6485fdcc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-da55eafe-e919-488b-bd8d-1bad6485fdcc">
											<gml:posList>35.66771451176724 139.7390868828046 72.538 35.667707213435 139.73910196902406 72.538 35.66770991007777 139.73910393202374 72.538 35.66771881025998 139.73908553015346 72.538 35.66771451176724 139.7390868828046 72.538</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e6ee2339-26f4-4e19-8ff3-706d4e27738e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e6ee2339-26f4-4e19-8ff3-706d4e27738e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e6ee2339-26f4-4e19-8ff3-706d4e27738e">
											<gml:posList>35.667707213435 139.73910196902406 72.538 35.66768588535854 139.7391460340441 72.538 35.66769019287432 139.73914469243186 72.538 35.66770991007777 139.73910393202374 72.538 35.667707213435 139.73910196902406 72.538</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-64860ef7-fdb9-495b-b2c0-b4dfaa51116c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-64860ef7-fdb9-495b-b2c0-b4dfaa51116c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-64860ef7-fdb9-495b-b2c0-b4dfaa51116c">
											<gml:posList>35.667746066684394 139.7391301898139 76.634 35.66770991007777 139.73910393202374 76.634 35.66769019287432 139.73914469243186 76.634 35.6677263494722 139.73917095023398 76.634 35.667746066684394 139.7391301898139 76.634</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-450c1ee7-4b25-4e1c-8a3a-990e594a8dcf">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-450c1ee7-4b25-4e1c-8a3a-990e594a8dcf">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-450c1ee7-4b25-4e1c-8a3a-990e594a8dcf">
											<gml:posList>35.667610115980885 139.7390885298377 71.435 35.66757872129274 139.73906569073307 71.435 35.6675703520154 139.73908293213276 71.435 35.66755999837808 139.7390754331103 71.435 35.66751724371529 139.73916438048872 71.435 35.667669126705626 139.73928170825297 71.435 35.66772204195613 139.7391722918454 71.435 35.66768588535854 139.7391460340441 71.435 35.667707213435 139.73910196902406 71.435 35.66771451176724 139.7390868828046 71.435 35.66763782436302 139.73903116914613 71.435 35.667610115980885 139.7390885298377 71.435</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c5ed334d-723a-448f-aa0e-06b039546281">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c5ed334d-723a-448f-aa0e-06b039546281">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c5ed334d-723a-448f-aa0e-06b039546281">
											<gml:posList>35.66772204195613 139.7391722918454 72.538 35.6677263494722 139.73917095023398 72.538 35.66769019287432 139.73914469243186 72.538 35.66768588535854 139.7391460340441 72.538 35.66772204195613 139.7391722918454 72.538</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b687aaf1-4f92-460e-b480-f9cd73bdb72b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b687aaf1-4f92-460e-b480-f9cd73bdb72b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b687aaf1-4f92-460e-b480-f9cd73bdb72b">
											<gml:posList>35.66751724371529 139.73916438048872 72.538 35.66751298121595 139.73916565576891 72.538 35.667670185513046 139.73928708635756 72.538 35.667669126705626 139.73928170825297 72.538 35.66751724371529 139.73916438048872 72.538</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-43efcb7a-df6d-487a-8cf7-b686d05ef069">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-43efcb7a-df6d-487a-8cf7-b686d05ef069">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-43efcb7a-df6d-487a-8cf7-b686d05ef069">
											<gml:posList>35.667669126705626 139.73928170825297 72.538 35.667670185513046 139.73928708635756 72.538 35.6677263494722 139.73917095023398 72.538 35.66772204195613 139.7391722918454 72.538 35.667669126705626 139.73928170825297 72.538</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-48c6847a-e23a-4f4a-b4f1-eab4e6d0ae32">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-48c6847a-e23a-4f4a-b4f1-eab4e6d0ae32">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-48c6847a-e23a-4f4a-b4f1-eab4e6d0ae32">
											<gml:posList>35.66760900316006 139.73908325121613 72.538 35.66763672055342 139.73902589051298 72.538 35.66763672055342 139.73902589051298 11.69 35.66760900316006 139.73908325121613 11.69 35.66760900316006 139.73908325121613 72.538</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ab5bd4fe-9a07-4341-941e-9c5148506cfa">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ab5bd4fe-9a07-4341-941e-9c5148506cfa">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ab5bd4fe-9a07-4341-941e-9c5148506cfa">
											<gml:posList>35.66763672055342 139.73902589051298 72.538 35.66771881025998 139.73908553015346 72.538 35.66771881025998 139.73908553015346 11.69 35.66763672055342 139.73902589051298 11.69 35.66763672055342 139.73902589051298 72.538</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-07699f4b-b418-4181-8ff4-bb9de3b25fd0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-07699f4b-b418-4181-8ff4-bb9de3b25fd0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-07699f4b-b418-4181-8ff4-bb9de3b25fd0">
											<gml:posList>35.66771451176724 139.7390868828046 71.435 35.66771451176724 139.7390868828046 72.538 35.66763782436302 139.73903116914613 72.538 35.66763782436302 139.73903116914613 71.435 35.66771451176724 139.7390868828046 71.435</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3e83c208-ebe5-4a0a-a6fd-0fa61af0fa33">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3e83c208-ebe5-4a0a-a6fd-0fa61af0fa33">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3e83c208-ebe5-4a0a-a6fd-0fa61af0fa33">
											<gml:posList>35.66763782436302 139.73903116914613 71.435 35.66763782436302 139.73903116914613 72.538 35.667610115980885 139.7390885298377 72.538 35.667610115980885 139.7390885298377 71.435 35.66763782436302 139.73903116914613 71.435</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-29848284-ddcb-4ec7-be2e-0e47f7c82569">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-29848284-ddcb-4ec7-be2e-0e47f7c82569">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-29848284-ddcb-4ec7-be2e-0e47f7c82569">
											<gml:posList>35.6675692482167 139.7390776645492 72.538 35.667577617493286 139.7390604231492 72.538 35.667577617493286 139.7390604231492 11.69 35.6675692482167 139.7390776645492 11.69 35.6675692482167 139.7390776645492 72.538</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0e9cd9a6-678b-4294-94ca-3fe77aec6dde">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0e9cd9a6-678b-4294-94ca-3fe77aec6dde">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0e9cd9a6-678b-4294-94ca-3fe77aec6dde">
											<gml:posList>35.667577617493286 139.7390604231492 72.538 35.66760900316006 139.73908325121613 72.538 35.66760900316006 139.73908325121613 11.69 35.667577617493286 139.7390604231492 11.69 35.667577617493286 139.7390604231492 72.538</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f4c891a7-c290-4c1b-af61-7ff9f77d081c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f4c891a7-c290-4c1b-af61-7ff9f77d081c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f4c891a7-c290-4c1b-af61-7ff9f77d081c">
											<gml:posList>35.66755887655159 139.73907016554867 72.538 35.6675692482167 139.7390776645492 72.538 35.6675692482167 139.7390776645492 11.69 35.66755887655159 139.73907016554867 11.69 35.66755887655159 139.73907016554867 72.538</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e444cb65-983e-4be8-a236-6e7bf1e8966b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e444cb65-983e-4be8-a236-6e7bf1e8966b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e444cb65-983e-4be8-a236-6e7bf1e8966b">
											<gml:posList>35.66757872129274 139.73906569073307 71.435 35.66757872129274 139.73906569073307 72.538 35.6675703520154 139.73908293213276 72.538 35.6675703520154 139.73908293213276 71.435 35.66757872129274 139.73906569073307 71.435</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3102a825-e325-4f8d-a262-4b68b5610606">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3102a825-e325-4f8d-a262-4b68b5610606">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3102a825-e325-4f8d-a262-4b68b5610606">
											<gml:posList>35.667610115980885 139.7390885298377 71.435 35.667610115980885 139.7390885298377 72.538 35.66757872129274 139.73906569073307 72.538 35.66757872129274 139.73906569073307 71.435 35.667610115980885 139.7390885298377 71.435</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1d4f143c-3c16-415f-99ef-5167f2f71c7c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1d4f143c-3c16-415f-99ef-5167f2f71c7c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1d4f143c-3c16-415f-99ef-5167f2f71c7c">
											<gml:posList>35.6675703520154 139.73908293213276 71.435 35.6675703520154 139.73908293213276 72.538 35.66755999837808 139.7390754331103 72.538 35.66755999837808 139.7390754331103 71.435 35.6675703520154 139.73908293213276 71.435</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c4eabb7a-d702-46fe-b54c-98327ca3f0c2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c4eabb7a-d702-46fe-b54c-98327ca3f0c2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c4eabb7a-d702-46fe-b54c-98327ca3f0c2">
											<gml:posList>35.667707213435 139.73910196902406 71.435 35.667707213435 139.73910196902406 72.538 35.66771451176724 139.7390868828046 72.538 35.66771451176724 139.7390868828046 71.435 35.667707213435 139.73910196902406 71.435</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-cbc26ec6-17d5-43a7-bb02-564162272ef8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cbc26ec6-17d5-43a7-bb02-564162272ef8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cbc26ec6-17d5-43a7-bb02-564162272ef8">
											<gml:posList>35.66771881025998 139.73908553015346 72.538 35.66770991007777 139.73910393202374 72.538 35.66770991007777 139.73910393202374 11.69 35.66771881025998 139.73908553015346 11.69 35.66771881025998 139.73908553015346 72.538</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d93003ba-6da7-4b5c-9114-dc85dc05fc0e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d93003ba-6da7-4b5c-9114-dc85dc05fc0e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d93003ba-6da7-4b5c-9114-dc85dc05fc0e">
											<gml:posList>35.667746066684394 139.7391301898139 76.634 35.667746066684394 139.7391301898139 11.69 35.66770991007777 139.73910393202374 11.69 35.66770991007777 139.73910393202374 72.538 35.66770991007777 139.73910393202374 76.634 35.667746066684394 139.7391301898139 76.634</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ea60b6c9-40b6-4813-abf4-26841c21f5c1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ea60b6c9-40b6-4813-abf4-26841c21f5c1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ea60b6c9-40b6-4813-abf4-26841c21f5c1">
											<gml:posList>35.66751298121595 139.73916565576891 72.538 35.66755887655159 139.73907016554867 72.538 35.66755887655159 139.73907016554867 11.69 35.66751298121595 139.73916565576891 11.69 35.66751298121595 139.73916565576891 72.538</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-04a590b0-49be-4aba-80aa-b1ed24b52cf0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-04a590b0-49be-4aba-80aa-b1ed24b52cf0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-04a590b0-49be-4aba-80aa-b1ed24b52cf0">
											<gml:posList>35.66755999837808 139.7390754331103 71.435 35.66755999837808 139.7390754331103 72.538 35.66751724371529 139.73916438048872 72.538 35.66751724371529 139.73916438048872 71.435 35.66755999837808 139.7390754331103 71.435</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0384720a-d8aa-4ccc-bfb1-00b8a513cd96">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0384720a-d8aa-4ccc-bfb1-00b8a513cd96">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0384720a-d8aa-4ccc-bfb1-00b8a513cd96">
											<gml:posList>35.66768588535854 139.7391460340441 71.435 35.66768588535854 139.7391460340441 72.538 35.667707213435 139.73910196902406 72.538 35.667707213435 139.73910196902406 71.435 35.66768588535854 139.7391460340441 71.435</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-76936894-8d9a-4682-b63c-a9eb9880e3b6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-76936894-8d9a-4682-b63c-a9eb9880e3b6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-76936894-8d9a-4682-b63c-a9eb9880e3b6">
											<gml:posList>35.66770991007777 139.73910393202374 72.538 35.66769019287432 139.73914469243186 72.538 35.66769019287432 139.73914469243186 76.634 35.66770991007777 139.73910393202374 76.634 35.66770991007777 139.73910393202374 72.538</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3f506f33-22bd-4e96-b433-514a1e2d3429">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3f506f33-22bd-4e96-b433-514a1e2d3429">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3f506f33-22bd-4e96-b433-514a1e2d3429">
											<gml:posList>35.66769019287432 139.73914469243186 76.634 35.66769019287432 139.73914469243186 72.538 35.6677263494722 139.73917095023398 72.538 35.6677263494722 139.73917095023398 76.634 35.66769019287432 139.73914469243186 76.634</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-938d3d0a-1766-47dd-bac7-3a4d08acd2ec">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-938d3d0a-1766-47dd-bac7-3a4d08acd2ec">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-938d3d0a-1766-47dd-bac7-3a4d08acd2ec">
											<gml:posList>35.66772204195613 139.7391722918454 71.435 35.66772204195613 139.7391722918454 72.538 35.66768588535854 139.7391460340441 72.538 35.66768588535854 139.7391460340441 71.435 35.66772204195613 139.7391722918454 71.435</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2aeb5e26-5e91-45de-946d-c7c08949a1b0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2aeb5e26-5e91-45de-946d-c7c08949a1b0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2aeb5e26-5e91-45de-946d-c7c08949a1b0">
											<gml:posList>35.667746066684394 139.7391301898139 11.69 35.667746066684394 139.7391301898139 76.634 35.6677263494722 139.73917095023398 76.634 35.6677263494722 139.73917095023398 72.538 35.667670185513046 139.73928708635756 72.538 35.667670185513046 139.73928708635756 11.69 35.667746066684394 139.7391301898139 11.69</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d41231d3-a14f-44c3-a33d-da8010aa7721">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d41231d3-a14f-44c3-a33d-da8010aa7721">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d41231d3-a14f-44c3-a33d-da8010aa7721">
											<gml:posList>35.66751724371529 139.73916438048872 71.435 35.66751724371529 139.73916438048872 72.538 35.667669126705626 139.73928170825297 72.538 35.667669126705626 139.73928170825297 71.435 35.66751724371529 139.73916438048872 71.435</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b2e7ef9e-b065-43a9-8cfc-1c5137e7c2e3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b2e7ef9e-b065-43a9-8cfc-1c5137e7c2e3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b2e7ef9e-b065-43a9-8cfc-1c5137e7c2e3">
											<gml:posList>35.667670185513046 139.73928708635756 72.538 35.66751298121595 139.73916565576891 72.538 35.66751298121595 139.73916565576891 11.69 35.667670185513046 139.73928708635756 11.69 35.667670185513046 139.73928708635756 72.538</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b30d37c6-de27-4970-85aa-6072fb0c1a7c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b30d37c6-de27-4970-85aa-6072fb0c1a7c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b30d37c6-de27-4970-85aa-6072fb0c1a7c">
											<gml:posList>35.667669126705626 139.73928170825297 71.435 35.667669126705626 139.73928170825297 72.538 35.66772204195613 139.7391722918454 72.538 35.66772204195613 139.7391722918454 71.435 35.667669126705626 139.73928170825297 71.435</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区六本木二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-8962</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">339.7843</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1210</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>7</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.03</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">2</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>