<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_2d7d0269-3cce-4cf6-b158-c3755a22449d">
			<core:creationDate>2024-03-15</core:creationDate>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3003</bldg:class>
			<bldg:measuredHeight uom="m">3.6</bldg:measuredHeight>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.669743348620806 139.73817987186217 0 35.66972865370716 139.73811965453947 0 35.66969700658617 139.73813116908616 0 35.66973126144473 139.73827147000063 0 35.66976308047646 139.73826076167126 0 35.669757564180635 139.73823806832576 0 35.6697756134859 139.73823148549022 0 35.66976138890923 139.7381732890254 0 35.669743348620806 139.73817987186217 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669743348620806 139.73817987186217 20.417 35.66976138890923 139.7381732890254 20.417 35.6697756134859 139.73823148549022 20.417 35.669757564180635 139.73823806832576 20.417 35.66976308047646 139.73826076167126 20.417 35.66973126144473 139.73827147000063 20.417 35.66969700658617 139.73813116908616 20.417 35.66972865370716 139.73811965453947 20.417 35.669743348620806 139.73817987186217 20.417</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669743348620806 139.73817987186217 20.417 35.66972865370716 139.73811965453947 20.417 35.66972865370716 139.73811965453947 23.99 35.669743348620806 139.73817987186217 23.99 35.669743348620806 139.73817987186217 20.417</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66972865370716 139.73811965453947 20.417 35.66969700658617 139.73813116908616 20.417 35.66969700658617 139.73813116908616 23.99 35.66972865370716 139.73811965453947 23.99 35.66972865370716 139.73811965453947 20.417</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66969700658617 139.73813116908616 20.417 35.66973126144473 139.73827147000063 20.417 35.66973126144473 139.73827147000063 23.99 35.66969700658617 139.73813116908616 23.99 35.66969700658617 139.73813116908616 20.417</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66973126144473 139.73827147000063 20.417 35.66976308047646 139.73826076167126 20.417 35.66976308047646 139.73826076167126 23.99 35.66973126144473 139.73827147000063 23.99 35.66973126144473 139.73827147000063 20.417</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66976308047646 139.73826076167126 20.417 35.669757564180635 139.73823806832576 20.417 35.669757564180635 139.73823806832576 23.99 35.66976308047646 139.73826076167126 23.99 35.66976308047646 139.73826076167126 20.417</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669757564180635 139.73823806832576 20.417 35.6697756134859 139.73823148549022 20.417 35.6697756134859 139.73823148549022 23.99 35.669757564180635 139.73823806832576 23.99 35.669757564180635 139.73823806832576 20.417</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6697756134859 139.73823148549022 20.417 35.66976138890923 139.7381732890254 20.417 35.66976138890923 139.7381732890254 23.99 35.6697756134859 139.73823148549022 23.99 35.6697756134859 139.73823148549022 20.417</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66976138890923 139.7381732890254 20.417 35.669743348620806 139.73817987186217 20.417 35.669743348620806 139.73817987186217 23.99 35.66976138890923 139.7381732890254 23.99 35.66976138890923 139.7381732890254 20.417</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669743348620806 139.73817987186217 23.99 35.66972865370716 139.73811965453947 23.99 35.66969700658617 139.73813116908616 23.99 35.66973126144473 139.73827147000063 23.99 35.66976308047646 139.73826076167126 23.99 35.669757564180635 139.73823806832576 23.99 35.6697756134859 139.73823148549022 23.99 35.66976138890923 139.7381732890254 23.99 35.669743348620806 139.73817987186217 23.99</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-1b3ce9fa-d19c-4561-979f-128c18bf87ab"/>
							<gml:surfaceMember xlink:href="#poly-baf9595d-225b-4f2c-a2cd-40a81698e6be"/>
							<gml:surfaceMember xlink:href="#poly-8062cd0e-5f05-440f-9eea-7184e1b0be7d"/>
							<gml:surfaceMember xlink:href="#poly-34b73814-c54d-422c-8a25-e35e52bc7d94"/>
							<gml:surfaceMember xlink:href="#poly-753d3fd1-ecb1-4a13-958b-c09b097a0ae5"/>
							<gml:surfaceMember xlink:href="#poly-2e89cbc0-c891-46b1-bc37-f4823811ef6b"/>
							<gml:surfaceMember xlink:href="#poly-9bf68015-a0ea-4583-83c9-052d5c05c15c"/>
							<gml:surfaceMember xlink:href="#poly-6b5e971b-4908-40ef-865d-0833d2379ab5"/>
							<gml:surfaceMember xlink:href="#poly-061ffa14-a04a-411e-b5b0-0d504089ab7d"/>
							<gml:surfaceMember xlink:href="#poly-01439af7-1b10-4d40-b882-ecda4b72fa21"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-1b3ce9fa-d19c-4561-979f-128c18bf87ab">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1b3ce9fa-d19c-4561-979f-128c18bf87ab">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1b3ce9fa-d19c-4561-979f-128c18bf87ab">
											<gml:posList>35.669763080476436 139.73826076167123 20.416 35.66973126144471 139.73827147000063 20.416 35.669697006586155 139.73813116908616 20.416 35.66972865370716 139.73811965453947 20.416 35.669743348620806 139.73817987186217 20.416 35.66976138890921 139.73817328902538 20.416 35.669775613485896 139.73823148549022 20.416 35.66975756418062 139.73823806832576 20.416 35.669763080476436 139.73826076167123 20.416</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-baf9595d-225b-4f2c-a2cd-40a81698e6be">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-baf9595d-225b-4f2c-a2cd-40a81698e6be">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-baf9595d-225b-4f2c-a2cd-40a81698e6be">
											<gml:posList>35.669697006586155 139.73813116908616 24.57 35.66973126144471 139.73827147000063 24.57 35.669763080476436 139.73826076167123 24.57 35.66975756418062 139.73823806832576 24.57 35.669775613485896 139.73823148549022 24.57 35.66976138890921 139.73817328902538 24.57 35.669743348620806 139.73817987186217 24.57 35.66972865370716 139.73811965453947 24.57 35.669697006586155 139.73813116908616 24.57</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8062cd0e-5f05-440f-9eea-7184e1b0be7d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8062cd0e-5f05-440f-9eea-7184e1b0be7d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8062cd0e-5f05-440f-9eea-7184e1b0be7d">
											<gml:posList>35.669763080476436 139.73826076167123 24.57 35.66973126144471 139.73827147000063 24.57 35.66973126144471 139.73827147000063 20.416 35.669763080476436 139.73826076167123 20.416 35.669763080476436 139.73826076167123 24.57</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-34b73814-c54d-422c-8a25-e35e52bc7d94">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-34b73814-c54d-422c-8a25-e35e52bc7d94">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-34b73814-c54d-422c-8a25-e35e52bc7d94">
											<gml:posList>35.669697006586155 139.73813116908616 24.57 35.66972865370716 139.73811965453947 24.57 35.66972865370716 139.73811965453947 20.416 35.669697006586155 139.73813116908616 20.416 35.669697006586155 139.73813116908616 24.57</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-753d3fd1-ecb1-4a13-958b-c09b097a0ae5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-753d3fd1-ecb1-4a13-958b-c09b097a0ae5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-753d3fd1-ecb1-4a13-958b-c09b097a0ae5">
											<gml:posList>35.66973126144471 139.73827147000063 24.57 35.669697006586155 139.73813116908616 24.57 35.669697006586155 139.73813116908616 20.416 35.66973126144471 139.73827147000063 20.416 35.66973126144471 139.73827147000063 24.57</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2e89cbc0-c891-46b1-bc37-f4823811ef6b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2e89cbc0-c891-46b1-bc37-f4823811ef6b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2e89cbc0-c891-46b1-bc37-f4823811ef6b">
											<gml:posList>35.66972865370716 139.73811965453947 24.57 35.669743348620806 139.73817987186217 24.57 35.669743348620806 139.73817987186217 20.416 35.66972865370716 139.73811965453947 20.416 35.66972865370716 139.73811965453947 24.57</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9bf68015-a0ea-4583-83c9-052d5c05c15c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9bf68015-a0ea-4583-83c9-052d5c05c15c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9bf68015-a0ea-4583-83c9-052d5c05c15c">
											<gml:posList>35.669743348620806 139.73817987186217 24.57 35.66976138890921 139.73817328902538 24.57 35.66976138890921 139.73817328902538 20.416 35.669743348620806 139.73817987186217 20.416 35.669743348620806 139.73817987186217 24.57</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6b5e971b-4908-40ef-865d-0833d2379ab5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6b5e971b-4908-40ef-865d-0833d2379ab5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6b5e971b-4908-40ef-865d-0833d2379ab5">
											<gml:posList>35.66975756418062 139.73823806832576 24.57 35.669763080476436 139.73826076167123 24.57 35.669763080476436 139.73826076167123 20.416 35.66975756418062 139.73823806832576 20.416 35.66975756418062 139.73823806832576 24.57</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-061ffa14-a04a-411e-b5b0-0d504089ab7d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-061ffa14-a04a-411e-b5b0-0d504089ab7d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-061ffa14-a04a-411e-b5b0-0d504089ab7d">
											<gml:posList>35.669775613485896 139.73823148549022 24.57 35.66975756418062 139.73823806832576 24.57 35.66975756418062 139.73823806832576 20.416 35.669775613485896 139.73823148549022 20.416 35.669775613485896 139.73823148549022 24.57</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-01439af7-1b10-4d40-b882-ecda4b72fa21">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-01439af7-1b10-4d40-b882-ecda4b72fa21">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-01439af7-1b10-4d40-b882-ecda4b72fa21">
											<gml:posList>35.66976138890921 139.73817328902538 24.57 35.669775613485896 139.73823148549022 24.57 35.669775613485896 139.73823148549022 20.416 35.66976138890921 139.73817328902538 20.416 35.66976138890921 139.73817328902538 24.57</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-9770</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">211</uro:landUseType>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>4</uro:specifiedFloorAreaRate>
					<uro:surveyYear>0001</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>