<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_2d8e3f73-090c-4ac8-9886-cb7d03641f85">
			<core:creationDate>2023-08-22</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>18</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103018002</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="再開発等促進区を定める地区計画">
				<gen:value>環状第二号線新橋・虎ノ門地区</gen:value>
			</gen:stringAttribute>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">402</bldg:usage>
			<bldg:measuredHeight uom="m">18.7</bldg:measuredHeight>
			<bldg:storeysAboveGround>6</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.668540655263804 139.74798112479453 0 35.668496393487864 139.74795974266846 0 35.66848140871597 139.74799613972417 0 35.668487814872584 139.74807134953502 0 35.66850838493775 139.74808128342391 0 35.668540655263804 139.74798112479453 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668540655263804 139.74798112479453 5.425 35.66850838493775 139.74808128342391 5.425 35.668487814872584 139.74807134953502 5.425 35.66848140871597 139.74799613972417 5.425 35.668496393487864 139.74795974266846 5.425 35.668540655263804 139.74798112479453 5.425</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668540655263804 139.74798112479453 5.425 35.668496393487864 139.74795974266846 5.425 35.668496393487864 139.74795974266846 23.759 35.668540655263804 139.74798112479453 23.759 35.668540655263804 139.74798112479453 5.425</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668496393487864 139.74795974266846 5.425 35.66848140871597 139.74799613972417 5.425 35.66848140871597 139.74799613972417 23.759 35.668496393487864 139.74795974266846 23.759 35.668496393487864 139.74795974266846 5.425</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66848140871597 139.74799613972417 5.425 35.668487814872584 139.74807134953502 5.425 35.668487814872584 139.74807134953502 23.759 35.66848140871597 139.74799613972417 23.759 35.66848140871597 139.74799613972417 5.425</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668487814872584 139.74807134953502 5.425 35.66850838493775 139.74808128342391 5.425 35.66850838493775 139.74808128342391 23.759 35.668487814872584 139.74807134953502 23.759 35.668487814872584 139.74807134953502 5.425</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66850838493775 139.74808128342391 5.425 35.668540655263804 139.74798112479453 5.425 35.668540655263804 139.74798112479453 23.759 35.66850838493775 139.74808128342391 23.759 35.66850838493775 139.74808128342391 5.425</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668540655263804 139.74798112479453 23.759 35.668496393487864 139.74795974266846 23.759 35.66848140871597 139.74799613972417 23.759 35.668487814872584 139.74807134953502 23.759 35.66850838493775 139.74808128342391 23.759 35.668540655263804 139.74798112479453 23.759</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly_TMmnt0164_p935_0"/>
							<gml:surfaceMember xlink:href="#poly_TMmnt0164_p935_1"/>
							<gml:surfaceMember xlink:href="#poly_TMmnt0164_p935_2"/>
							<gml:surfaceMember xlink:href="#poly_TMmnt0164_p935_3"/>
							<gml:surfaceMember xlink:href="#poly_TMmnt0164_p935_4"/>
							<gml:surfaceMember xlink:href="#poly_TMmnt0164_p935_5"/>
							<gml:surfaceMember xlink:href="#poly_TMmnt0164_b_0"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="gml_8932409b-c284-4ada-8aea-99eff059a607">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_965820d3-16bf-46e0-b278-744c4585493f">
									<gml:exterior>
										<gml:LinearRing gml:id="line_13d7df15-00a7-4a2a-958d-411eb49af266">
											<gml:posList>35.6685060789318 139.7480815754277 6.294249772327959 35.66848439858094 139.74807148387893 6.294249772327959 35.668478803429096 139.74800302523607 6.294249772327959 35.66849280434337 139.74795785347334 6.294249772327959 35.66853791774639 139.7479788522809 6.294249772327959 35.6685060789318 139.7480815754277 6.294249772327959</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="gnd_TMmnt0164_b_0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly_TMmnt0164_b_0">
									<gml:exterior>
										<gml:LinearRing gml:id="line_TMmnt0164_b_0">
											<gml:posList>35.6685084192584 139.7480812911246 5.44051301 35.66848788377913 139.7480713663035 5.43950448 35.66848147798382 139.74799615588034 5.43866936 35.6684964274823 139.74795974985204 5.43909036 35.668540655183804 139.74798112524994 5.44126129 35.6685084192584 139.7480812911246 5.44051301</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:OuterCeilingSurface gml:id="gml_787cb926-61f8-4747-84b8-eff16bbfac7d">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_48480778-23a7-4f83-a49d-aa0c7a183937">
									<gml:exterior>
										<gml:LinearRing gml:id="line_6aee9659-f5ca-4f67-8c8b-c474bee7141f">
											<gml:posList>35.668482250456854 139.74804520084598 8.613814591663896 35.66847935645226 139.74800979069232 8.613814591663896 35.66848261499287 139.74801130753295 8.613814591663896 35.66848386109155 139.748011887531 8.613814591663896 35.66849196190255 139.748015658276 8.613814591663896 35.668482250456854 139.74804520084598 8.613814591663896</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:OuterCeilingSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:OuterCeilingSurface gml:id="gml_f3fdd69a-5d3b-4623-b97b-e75675e5edc2">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_f3261f5d-d772-464f-b891-fe0f610809dc">
									<gml:exterior>
										<gml:LinearRing gml:id="line_9f32049b-214c-41eb-9d51-27f360fffb0f">
											<gml:posList>35.66850965653016 139.74807003312242 17.392256974476396 35.66850564241849 139.74808298394694 17.392256974476396 35.66848453551788 139.74807315927464 17.392256974476396 35.66848327644575 139.7480577539261 17.392256974476396 35.668487872164825 139.74805989314493 17.392256974476396 35.668502433506944 139.74806667101078 17.392256974476396 35.66850965653016 139.74807003312242 17.392256974476396</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:OuterCeilingSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="gml_4f400b1e-3194-448f-a885-ff113d4510b8">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_0a42ab39-b91a-4acd-909d-6a69a40ee2c6">
									<gml:exterior>
										<gml:LinearRing gml:id="line_0cdaf60c-d48b-40ee-9a5b-c678038d0e51">
											<gml:posList>35.66848453551788 139.74807315927464 24.452750443714677 35.66850564241849 139.74808298394694 24.452750443714677 35.66853791774639 139.7479788522809 24.452750443714677 35.66849280434337 139.74795785347334 24.452750443714677 35.668478803429096 139.74800302523607 24.452750443714677 35.66848453551788 139.74807315927464 24.452750443714677</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="roof_TMmnt0164_p935_0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly_TMmnt0164_p935_0">
									<gml:exterior>
										<gml:LinearRing gml:id="line_TMmnt0164_p935_0">
											<gml:posList>35.66849635815226 139.74795973357445 24.15980167 35.668481408697865 139.74799613949597 24.15938067 35.66848781447428 139.7480713496986 24.16021578 35.66850834989307 139.7480812744906 24.16122431 35.66854058572357 139.74798110890973 24.16197259 35.66849635815226 139.74795973357445 24.15980167</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="wall_TMmnt0164_p935_2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly_TMmnt0164_p935_2">
									<gml:exterior>
										<gml:LinearRing gml:id="line_TMmnt0164_p935_2">
											<gml:posList>35.66850834989307 139.7480812744906 24.16122431 35.66848781447428 139.7480713496986 24.16021578 35.66848788377913 139.7480713663035 5.43950448 35.6685084192584 139.7480812911246 5.44051301 35.66850834989307 139.7480812744906 24.16122431</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="wall_TMmnt0164_p935_4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly_TMmnt0164_p935_4">
									<gml:exterior>
										<gml:LinearRing gml:id="line_TMmnt0164_p935_4">
											<gml:posList>35.668481408697865 139.74799613949597 24.15938067 35.66849635815226 139.74795973357445 24.15980167 35.6684964274823 139.74795974985204 5.43909036 35.66848147798382 139.74799615588034 5.43866936 35.668481408697865 139.74799613949597 24.15938067</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_8f767cf0-1d9d-4137-8cf7-14ee2a5ee574">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_37f07caa-dfda-41cc-9b85-ce61d0826341">
									<gml:exterior>
										<gml:LinearRing gml:id="line_ab643391-c789-4284-9667-f565197dfb8c">
											<gml:posList>35.6685060789318 139.7480815754277 6.360244035023271 35.66848439858094 139.74807148387893 6.360244035023271 35.66848439858094 139.74807148387893 6.294249772327959 35.6685060789318 139.7480815754277 6.294249772327959 35.6685060789318 139.7480815754277 6.360244035023271</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_9a3a2bc4-c2e5-4254-9a4e-d5d876602c8f">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_45c8f879-a207-479b-91ae-f86127083266">
									<gml:exterior>
										<gml:LinearRing gml:id="line_93041ffa-ab7d-4a96-a87a-6ed6d6642447">
											<gml:posList>35.66848261499287 139.74801130753295 6.360244035023271 35.66848261499287 139.74801130753295 8.613814591663896 35.66847935645226 139.74800979069232 8.613814591663896 35.66847935645226 139.74800979069232 6.360244035023271 35.66848261499287 139.74801130753295 6.360244035023271</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
					<bldg:opening>
						<bldg:Window gml:id="wnd_9abc55e8-9af4-43a9-a8be-4344d39e2f23">
							<bldg:lod3MultiSurface>
								<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_5676bba4-8fed-4248-abfd-af9fe1b98e9c">
											<gml:exterior>
												<gml:LinearRing gml:id="line_4189f198-9673-4a53-99eb-335aa9cb7cba">
													<gml:posList>35.66848386109155 139.748011887531 8.613814591663896 35.66848261499287 139.74801130753295 8.613814591663896 35.66848261499287 139.74801130753295 6.360244035023271 35.66848386109155 139.748011887531 6.360244035023271 35.66848386109155 139.748011887531 8.613814591663896</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
								</gml:MultiSurface>
							</bldg:lod3MultiSurface>
						</bldg:Window>
					</bldg:opening>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_da44ae03-71bf-469b-b7ac-94bca217486b">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_49d473f6-6c0d-407e-bd57-4142a40a0a81">
									<gml:exterior>
										<gml:LinearRing gml:id="line_fe343470-af75-4468-bb59-d038cbbcbcb8">
											<gml:posList>35.66848275061765 139.74805131997527 8.613814591663896 35.668482250456854 139.74804520084598 8.613814591663896 35.668482250456854 139.74804520084598 6.751509904163896 35.66848275061765 139.74805131997527 6.751509904163896 35.66848275061765 139.74805131997527 8.613814591663896</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_2e6e02a4-0bee-4274-8153-c47e54686ded">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_7eece2af-c860-484a-b5f9-9a9ec40ab8d7">
									<gml:exterior>
										<gml:LinearRing gml:id="line_ab0dedf1-45a5-491d-bf94-f1172d4fdd2a">
											<gml:posList>35.668482250456854 139.74804520084598 6.360244035023271 35.668482250456854 139.74804520084598 6.751509904163896 35.66849196190255 139.748015658276 6.751509904163896 35.66849196190255 139.748015658276 6.360244035023271 35.668482250456854 139.74804520084598 6.360244035023271</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
					<bldg:opening>
						<bldg:Door gml:id="dor_628b2ae2-6d5a-4a59-899f-18fdbd4eaed3">
							<bldg:lod3MultiSurface>
								<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_54a43187-fbf7-4b58-98a0-ec3958aa407b">
											<gml:exterior>
												<gml:LinearRing gml:id="line_1fbcaead-972b-4e3a-92b8-e045ecd3a34a">
													<gml:posList>35.66849196190255 139.748015658276 8.613814591663896 35.66848386109155 139.748011887531 8.613814591663896 35.66848386109155 139.748011887531 6.360244035023271 35.66849196190255 139.748015658276 6.360244035023271 35.66849196190255 139.748015658276 6.751509904163896 35.66849196190255 139.748015658276 8.613814591663896</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
								</gml:MultiSurface>
							</bldg:lod3MultiSurface>
						</bldg:Door>
					</bldg:opening>
					<bldg:opening>
						<bldg:Window gml:id="wnd_c464dcbc-8880-4bb5-8a31-ac7f9cc47026">
							<bldg:lod3MultiSurface>
								<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_97e0a7b0-33c5-4d37-bb9d-1caf1cdd0bb3">
											<gml:exterior>
												<gml:LinearRing gml:id="line_331bf091-2df2-4e05-9620-276b5d8f9383">
													<gml:posList>35.66849196190255 139.748015658276 6.751509904163896 35.668482250456854 139.74804520084598 6.751509904163896 35.668482250456854 139.74804520084598 8.613814591663896 35.66849196190255 139.748015658276 8.613814591663896 35.66849196190255 139.748015658276 6.751509904163896</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
								</gml:MultiSurface>
							</bldg:lod3MultiSurface>
						</bldg:Window>
					</bldg:opening>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_255ca090-7f94-4cca-bafa-6d4ccb9e4b0a">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_dc5d05ac-3459-46b8-a9c1-d0b17fb8e3f3">
									<gml:exterior>
										<gml:LinearRing gml:id="line_31ccf60a-730d-4e45-a727-7ec047ffb2b7">
											<gml:posList>35.66848439858094 139.74807148387893 6.294249772327959 35.66848327644575 139.7480577539261 6.360244035023271 35.668482250456854 139.74804520084598 6.360244035023271 35.66848439858094 139.74807148387893 6.294249772327959</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_a5ff8550-746c-41cb-a251-129874d2fe0a">
									<gml:exterior>
										<gml:LinearRing gml:id="line_dda2462c-292e-480d-9e3c-2c01b10889da">
											<gml:posList>35.66848327644575 139.7480577539261 6.360244035023271 35.66848439858094 139.74807148387893 6.294249772327959 35.66848439858094 139.74807148387893 6.360244035023271 35.66848327644575 139.7480577539261 6.360244035023271</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_2e744ce7-1c3f-4bcf-97d1-bdd33f3a22df">
									<gml:exterior>
										<gml:LinearRing gml:id="line_1be095c1-9c08-457d-a23e-02196e4e1e4d">
											<gml:posList>35.66848439858094 139.74807148387893 6.294249772327959 35.668482250456854 139.74804520084598 6.360244035023271 35.668478803429096 139.74800302523607 6.294249772327959 35.66848439858094 139.74807148387893 6.294249772327959</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_bac0b78d-e450-426a-a1cb-84a0fdab1c8f">
									<gml:exterior>
										<gml:LinearRing gml:id="line_6096fa8f-1b34-40a4-b497-aab56c43cf09">
											<gml:posList>35.66848453551788 139.74807315927464 24.452750443714677 35.66848236602842 139.74804661535114 23.209189652699052 35.66848236602842 139.74804661535114 21.75299763609749 35.66848453551788 139.74807315927464 24.452750443714677</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_86383d1c-c5fb-4aa5-96a2-453f31f55dde">
									<gml:exterior>
										<gml:LinearRing gml:id="line_4b75623d-b864-4c23-8344-dfcfee7c2c5a">
											<gml:posList>35.66848236602842 139.74804661535114 23.209189652699052 35.66848453551788 139.74807315927464 24.452750443714677 35.668478803429096 139.74800302523607 24.452750443714677 35.66848236602842 139.74804661535114 23.209189652699052</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_790c4fbd-c1d3-428c-9968-c451ee1457fa">
									<gml:exterior>
										<gml:LinearRing gml:id="line_810ca639-d8d7-4e65-b3fd-7f0c167511b0">
											<gml:posList>35.66848453551788 139.74807315927464 24.452750443714677 35.66848236602842 139.74804661535114 21.75299763609749 35.66848350592355 139.74806056237534 20.32539296080452 35.66848453551788 139.74807315927464 24.452750443714677</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_e9d59326-5297-4834-a123-0ccb83f3602c">
									<gml:exterior>
										<gml:LinearRing gml:id="line_b7b362c0-c7fb-4828-a058-98e1690e8ff4">
											<gml:posList>35.66848453551788 139.74807315927464 24.452750443714677 35.66848350592355 139.74806056237534 20.32539296080452 35.66848453551788 139.74807315927464 20.32539296080452 35.66848453551788 139.74807315927464 24.452750443714677</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_59d299ad-019a-478c-b303-dc1293f3028f">
									<gml:exterior>
										<gml:LinearRing gml:id="line_3f110838-9904-4f2e-a728-91866d6e7e4e">
											<gml:posList>35.66848236602842 139.74804661535114 18.86920094420296 35.66848350592355 139.74806056237534 20.32539296080452 35.66848236602842 139.74804661535114 20.32539296080452 35.66848236602842 139.74804661535114 18.86920094420296</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_29172ddd-20d9-4cee-9347-d05f7c56a204">
									<gml:exterior>
										<gml:LinearRing gml:id="line_ec4b3d96-80d4-4f64-b98e-605d6c807765">
											<gml:posList>35.66848350592355 139.74806056237534 20.32539296080452 35.66848236602842 139.74804661535114 18.86920094420296 35.66848350592355 139.74806056237534 18.86920094420296 35.66848350592355 139.74806056237534 20.32539296080452</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_8093730d-5ebe-4c8e-8803-d4c1b61fb6e1">
									<gml:exterior>
										<gml:LinearRing gml:id="line_9e0891f4-0f91-4ec3-a655-7e8340e3fdad">
											<gml:posList>35.66848350592355 139.74806056237534 18.86920094420296 35.66848236602842 139.74804661535114 18.86920094420296 35.66848327644575 139.7480577539261 17.392256974476396 35.66848350592355 139.74806056237534 18.86920094420296</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_91014902-c8e0-48f2-83fd-0f4469d0b2c4">
									<gml:exterior>
										<gml:LinearRing gml:id="line_396d08de-70bd-417e-a259-c7a020be4e1c">
											<gml:posList>35.66848350592355 139.74806056237534 18.86920094420296 35.66848327644575 139.7480577539261 17.392256974476396 35.66848453551788 139.74807315927464 17.392256974476396 35.66848350592355 139.74806056237534 18.86920094420296</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_632e1a3d-1b8b-43bd-9c7d-c6ccd0397c2a">
									<gml:exterior>
										<gml:LinearRing gml:id="line_8d8891d9-7559-4147-b707-3d5f89f79896">
											<gml:posList>35.66848236602842 139.74804661535114 17.392256974476396 35.66848236602842 139.74804661535114 18.86920094420296 35.668480348453784 139.74802192867259 18.86920094420296 35.66848236602842 139.74804661535114 17.392256974476396</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_bef172cd-1e47-4486-9fc8-9895f08fe216">
									<gml:exterior>
										<gml:LinearRing gml:id="line_23aff34c-cf12-44fe-9bed-15bad6118243">
											<gml:posList>35.66848236602842 139.74804661535114 18.86920094420296 35.66848236602842 139.74804661535114 17.392256974476396 35.66848327644575 139.7480577539261 17.392256974476396 35.66848236602842 139.74804661535114 18.86920094420296</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_153fd34a-3946-4fa8-a32b-3c5d332b32f2">
									<gml:exterior>
										<gml:LinearRing gml:id="line_4de92db0-e785-4775-92ab-bdc26a6e2c85">
											<gml:posList>35.668480348453784 139.74802192867259 23.209189652699052 35.668478803429096 139.74800302523607 24.452750443714677 35.668480348453784 139.74802192867259 21.75299763609749 35.668480348453784 139.74802192867259 23.209189652699052</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_91fe7fca-2a67-4755-8e59-b4b6654f9d3d">
									<gml:exterior>
										<gml:LinearRing gml:id="line_5b77f62b-00ad-42d6-8854-46a9b568cf1f">
											<gml:posList>35.668478803429096 139.74800302523607 24.452750443714677 35.668480348453784 139.74802192867259 23.209189652699052 35.66848236602842 139.74804661535114 23.209189652699052 35.668478803429096 139.74800302523607 24.452750443714677</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_394bace8-35a5-4b88-94b2-057bd700be2f">
									<gml:exterior>
										<gml:LinearRing gml:id="line_f26ae4c1-c519-4cec-b458-12b2cf1b07df">
											<gml:posList>35.668480348453784 139.74802192867259 21.75299763609749 35.668478803429096 139.74800302523607 24.452750443714677 35.668480348453784 139.74802192867259 20.32539296080452 35.668480348453784 139.74802192867259 21.75299763609749</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_280419a1-0301-48e1-93b9-45bb010fa5d3">
									<gml:exterior>
										<gml:LinearRing gml:id="line_9231846d-f937-4b66-9903-c22cefce84af">
											<gml:posList>35.668480348453784 139.74802192867259 20.32539296080452 35.668478803429096 139.74800302523607 24.452750443714677 35.668480348453784 139.74802192867259 18.86920094420296 35.668480348453784 139.74802192867259 20.32539296080452</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_ebdf8ced-afca-461b-bbc4-225cfb332f22">
									<gml:exterior>
										<gml:LinearRing gml:id="line_5074d89e-1888-4398-bff2-f5dbdffacbf4">
											<gml:posList>35.668480348453784 139.74802192867259 21.75299763609749 35.668480348453784 139.74802192867259 20.32539296080452 35.66848236602842 139.74804661535114 21.75299763609749 35.668480348453784 139.74802192867259 21.75299763609749</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_dc9375ba-4bee-4e21-b79f-06a78f5fe925">
									<gml:exterior>
										<gml:LinearRing gml:id="line_045f41b8-194f-47c8-a434-da37b377af20">
											<gml:posList>35.66848236602842 139.74804661535114 21.75299763609749 35.668480348453784 139.74802192867259 20.32539296080452 35.66848236602842 139.74804661535114 20.32539296080452 35.66848236602842 139.74804661535114 21.75299763609749</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_0d8b92b0-63b8-4604-a505-0b28afadfacf">
									<gml:exterior>
										<gml:LinearRing gml:id="line_bebb8c49-240a-4b42-975f-8654d40b1547">
											<gml:posList>35.66848236602842 139.74804661535114 21.75299763609749 35.66848236602842 139.74804661535114 20.32539296080452 35.66848350592355 139.74806056237534 20.32539296080452 35.66848236602842 139.74804661535114 21.75299763609749</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_ebc78441-53ef-49e3-b0a7-2b1cfc6fa8c3">
									<gml:exterior>
										<gml:LinearRing gml:id="line_4ec2d94b-28d3-40c1-8c60-2358ac193882">
											<gml:posList>35.668480348453784 139.74802192867259 18.86920094420296 35.668478803429096 139.74800302523607 24.452750443714677 35.668480348453784 139.74802192867259 17.392256974476396 35.668480348453784 139.74802192867259 18.86920094420296</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_72b6fa8c-1576-4fa5-9cda-487e9b52216f">
									<gml:exterior>
										<gml:LinearRing gml:id="line_c8dacc76-2131-4e47-8e1b-9806fa01b3b7">
											<gml:posList>35.668480348453784 139.74802192867259 17.392256974476396 35.668478803429096 139.74800302523607 24.452750443714677 35.668480348453784 139.74802192867259 15.936064957874834 35.668480348453784 139.74802192867259 17.392256974476396</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_2a4d8532-1af6-4d49-960e-44f52bb1193c">
									<gml:exterior>
										<gml:LinearRing gml:id="line_101fb4ee-4c57-4b3e-bfd6-acaeef601343">
											<gml:posList>35.668480348453784 139.74802192867259 18.86920094420296 35.668480348453784 139.74802192867259 17.392256974476396 35.66848236602842 139.74804661535114 17.392256974476396 35.668480348453784 139.74802192867259 18.86920094420296</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_41ad79d7-7013-44b8-a28d-77dba467c018">
									<gml:exterior>
										<gml:LinearRing gml:id="line_05972505-aecd-4a1b-a605-10e09f96d623">
											<gml:posList>35.66848350592355 139.74806056237534 18.86920094420296 35.66848453551788 139.74807315927464 17.392256974476396 35.66848453551788 139.74807315927464 18.86920094420296 35.66848350592355 139.74806056237534 18.86920094420296</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_df40d704-6f7a-4d4c-9384-a481d56e7998">
									<gml:exterior>
										<gml:LinearRing gml:id="line_ccb0e82c-c0f7-4a93-8da4-8fc293622854">
											<gml:posList>35.66847935645226 139.74800979069232 8.613814591663896 35.668478803429096 139.74800302523607 24.452750443714677 35.668478803429096 139.74800302523607 6.294249772327959 35.66847935645226 139.74800979069232 8.613814591663896</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_2a57d78a-a5f6-4ebd-a384-14a30a864c98">
									<gml:exterior>
										<gml:LinearRing gml:id="line_ce4995c8-bab1-4847-8ac0-b1bfc07eca8b">
											<gml:posList>35.668478803429096 139.74800302523607 24.452750443714677 35.66847935645226 139.74800979069232 8.613814591663896 35.668480348453784 139.74802192867259 15.936064957874834 35.668478803429096 139.74800302523607 24.452750443714677</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_3c889d87-35bc-4167-a9b2-ddf5a393205b">
									<gml:exterior>
										<gml:LinearRing gml:id="line_6dadc6e7-f84d-4332-9a8a-f19f2140096e">
											<gml:posList>35.668480348453784 139.74802192867259 15.936064957874834 35.668480348453784 139.74802192867259 14.438369035023271 35.66848236602842 139.74804661535114 14.438369035023271 35.668480348453784 139.74802192867259 15.936064957874834</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_9e35a4eb-501e-43a3-843b-ddd8b4e2e87b">
									<gml:exterior>
										<gml:LinearRing gml:id="line_4ea40644-4cb0-45f2-8942-58cb0155a3b3">
											<gml:posList>35.668480348453784 139.74802192867259 14.438369035023271 35.668480348453784 139.74802192867259 15.936064957874834 35.66847935645226 139.74800979069232 8.613814591663896 35.668480348453784 139.74802192867259 14.438369035023271</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_aa6ed2ec-7fe2-420c-8db6-d551b3fc0c2d">
									<gml:exterior>
										<gml:LinearRing gml:id="line_60c7d04e-15f6-4aa7-9125-00a5132302f8">
											<gml:posList>35.668480348453784 139.74802192867259 14.438369035023271 35.66847935645226 139.74800979069232 8.613814591663896 35.668480348453784 139.74802192867259 12.982177018421709 35.668480348453784 139.74802192867259 14.438369035023271</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_af859a77-04c4-4159-a86c-c7121fe12346">
									<gml:exterior>
										<gml:LinearRing gml:id="line_2351edd0-c703-4fc8-b8f0-cde54bbbc5f6">
											<gml:posList>35.668480348453784 139.74802192867259 12.982177018421709 35.66847935645226 139.74800979069232 8.613814591663896 35.668480348453784 139.74802192867259 11.48450398375374 35.668480348453784 139.74802192867259 12.982177018421709</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_06668810-8497-4545-942f-4990eb772b84">
									<gml:exterior>
										<gml:LinearRing gml:id="line_709dd6fa-10ca-4ba1-9683-26f53d167b33">
											<gml:posList>35.668480348453784 139.74802192867259 12.982177018421709 35.668480348453784 139.74802192867259 11.48450398375374 35.66848236602842 139.74804661535114 11.48450398375374 35.668480348453784 139.74802192867259 12.982177018421709</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_bfe59e01-e06e-4f05-b088-cb138c15d151">
									<gml:exterior>
										<gml:LinearRing gml:id="line_4f800bb6-1fd2-48c6-9589-b2c656c62cc5">
											<gml:posList>35.668480348453784 139.74802192867259 11.48450398375374 35.66847935645226 139.74800979069232 8.613814591663896 35.668480348453784 139.74802192867259 10.028311967152177 35.668480348453784 139.74802192867259 11.48450398375374</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_47081e07-481f-4654-a059-72c880a1fc71">
									<gml:exterior>
										<gml:LinearRing gml:id="line_674c4015-0f6e-495f-a138-3879c4eece96">
											<gml:posList>35.668480348453784 139.74802192867259 10.028311967152177 35.66847935645226 139.74800979069232 8.613814591663896 35.668482250456854 139.74804520084598 8.613814591663896 35.668480348453784 139.74802192867259 10.028311967152177</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_e2ed9ca8-8c76-439d-8d15-b1d077529d58">
									<gml:exterior>
										<gml:LinearRing gml:id="line_833fece3-d7b8-4fd4-b35f-9d86b05a3479">
											<gml:posList>35.668480348453784 139.74802192867259 10.028311967152177 35.668482250456854 139.74804520084598 8.613814591663896 35.66848236602842 139.74804661535114 10.028311967152177 35.668480348453784 139.74802192867259 10.028311967152177</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_2ab24e4b-c802-45db-8f0d-576efd3d0735">
									<gml:exterior>
										<gml:LinearRing gml:id="line_dcfa3004-f3dd-41f4-b878-2f0d05b14b2d">
											<gml:posList>35.66847935645226 139.74800979069232 8.613814591663896 35.668478803429096 139.74800302523607 6.294249772327959 35.66847935645226 139.74800979069232 6.360244035023271 35.66847935645226 139.74800979069232 8.613814591663896</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_3f5136d5-79b7-4d05-8fc9-d1bcdb1194d5">
									<gml:exterior>
										<gml:LinearRing gml:id="line_e9fc307f-3bbd-4b9f-918f-ce0e579bca9d">
											<gml:posList>35.66847935645226 139.74800979069232 6.360244035023271 35.668478803429096 139.74800302523607 6.294249772327959 35.668482250456854 139.74804520084598 6.360244035023271 35.66847935645226 139.74800979069232 6.360244035023271</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_bab061fa-adfd-4ec9-b526-7bb38825a7b0">
									<gml:exterior>
										<gml:LinearRing gml:id="line_1a88637c-e03a-40c1-856b-0872c0412e6e">
											<gml:posList>35.66848236602842 139.74804661535114 15.936064957874834 35.66848327644575 139.7480577539261 17.392256974476396 35.66848236602842 139.74804661535114 17.392256974476396 35.66848236602842 139.74804661535114 15.936064957874834</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_42d2ae2f-5bc1-4630-90c5-8a87c5ad6358">
									<gml:exterior>
										<gml:LinearRing gml:id="line_3b89be3b-7420-4e21-b2dd-633c378cd1c7">
											<gml:posList>35.66848327644575 139.7480577539261 17.392256974476396 35.66848236602842 139.74804661535114 15.936064957874834 35.66848236602842 139.74804661535114 14.438369035023271 35.66848327644575 139.7480577539261 17.392256974476396</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_010eb204-6bb2-49f0-a205-57dbad960f68">
									<gml:exterior>
										<gml:LinearRing gml:id="line_eac1c5ac-367f-4d48-9930-014b3ca0732e">
											<gml:posList>35.66848327644575 139.7480577539261 17.392256974476396 35.66848236602842 139.74804661535114 14.438369035023271 35.66848236602842 139.74804661535114 12.982177018421709 35.66848327644575 139.7480577539261 17.392256974476396</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_5f9cff77-8e72-44a9-ae9e-82098a728ac8">
									<gml:exterior>
										<gml:LinearRing gml:id="line_e0dbfcd6-193b-416d-9bca-083dd686c9c1">
											<gml:posList>35.66848236602842 139.74804661535114 14.438369035023271 35.66848236602842 139.74804661535114 15.936064957874834 35.668480348453784 139.74802192867259 15.936064957874834 35.66848236602842 139.74804661535114 14.438369035023271</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_e961916f-cc3c-4ab5-9d63-e3dfc6963e82">
									<gml:exterior>
										<gml:LinearRing gml:id="line_37d4a94f-01b6-4e73-ac06-3999578d80b0">
											<gml:posList>35.66848327644575 139.7480577539261 17.392256974476396 35.66848236602842 139.74804661535114 12.982177018421709 35.66848236602842 139.74804661535114 11.48450398375374 35.66848327644575 139.7480577539261 17.392256974476396</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_3f3f72ec-1eba-4925-9bbb-5d82a4578ea4">
									<gml:exterior>
										<gml:LinearRing gml:id="line_731843c3-c153-4520-a0f6-217d10af664d">
											<gml:posList>35.66848275061765 139.74805131997527 8.613814591663896 35.66848327644575 139.7480577539261 17.392256974476396 35.66848236602842 139.74804661535114 11.48450398375374 35.66848275061765 139.74805131997527 8.613814591663896</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_b1e197d2-c423-445f-af7f-4185a39ed5b3">
									<gml:exterior>
										<gml:LinearRing gml:id="line_fc3ef05f-46bc-4396-9ea3-d8a8d44eea66">
											<gml:posList>35.66848327644575 139.7480577539261 17.392256974476396 35.66848275061765 139.74805131997527 8.613814591663896 35.66848327644575 139.7480577539261 6.360244035023271 35.66848327644575 139.7480577539261 17.392256974476396</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_31b7ac0f-0b66-40ee-a7ef-9cd23d2f7265">
									<gml:exterior>
										<gml:LinearRing gml:id="line_155e2ea6-477d-4416-923f-f78ada13a736">
											<gml:posList>35.66848236602842 139.74804661535114 11.48450398375374 35.66848236602842 139.74804661535114 12.982177018421709 35.668480348453784 139.74802192867259 12.982177018421709 35.66848236602842 139.74804661535114 11.48450398375374</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_7624eead-94ad-49a9-9452-afceafda7040">
									<gml:exterior>
										<gml:LinearRing gml:id="line_4f541dff-bd93-45b2-8d3e-95a0b66023e0">
											<gml:posList>35.66848275061765 139.74805131997527 8.613814591663896 35.66848236602842 139.74804661535114 11.48450398375374 35.66848236602842 139.74804661535114 10.028311967152177 35.66848275061765 139.74805131997527 8.613814591663896</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_e9a9c2d1-d7e2-4b95-a1cf-5f299326d626">
									<gml:exterior>
										<gml:LinearRing gml:id="line_dafe5693-9dcc-4066-9775-aa44f1becba1">
											<gml:posList>35.66848275061765 139.74805131997527 8.613814591663896 35.66848236602842 139.74804661535114 10.028311967152177 35.668482250456854 139.74804520084598 8.613814591663896 35.66848275061765 139.74805131997527 8.613814591663896</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_5d67d97d-c9ca-42e5-8a97-7c6b86e66c11">
									<gml:exterior>
										<gml:LinearRing gml:id="line_915eae1b-b1f5-42f0-b254-222187f86fb6">
											<gml:posList>35.66848327644575 139.7480577539261 6.360244035023271 35.66848275061765 139.74805131997527 8.613814591663896 35.66848275061765 139.74805131997527 6.751509904163896 35.66848327644575 139.7480577539261 6.360244035023271</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_c94673b7-d710-4f34-9d07-a80c8c881939">
									<gml:exterior>
										<gml:LinearRing gml:id="line_2e275953-97b8-4e6e-be31-582ecff60efb">
											<gml:posList>35.66848327644575 139.7480577539261 6.360244035023271 35.66848275061765 139.74805131997527 6.751509904163896 35.668482250456854 139.74804520084598 6.360244035023271 35.66848327644575 139.7480577539261 6.360244035023271</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_81739c80-60ea-4490-8933-887160fc870a">
									<gml:exterior>
										<gml:LinearRing gml:id="line_60ef7d1d-7a38-412d-b3ec-1b1b2c494a0d">
											<gml:posList>35.668482250456854 139.74804520084598 6.360244035023271 35.66848275061765 139.74805131997527 6.751509904163896 35.668482250456854 139.74804520084598 6.751509904163896 35.668482250456854 139.74804520084598 6.360244035023271</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
					<bldg:opening>
						<bldg:Window gml:id="wnd_4dd09fa2-e9c0-4c01-99bd-20e2a44648c1">
							<bldg:lod3MultiSurface>
								<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_46922e5f-c36f-4b10-9d40-c489de6722da">
											<gml:exterior>
												<gml:LinearRing gml:id="line_cb0fdc46-0897-47a6-a6b2-08da4b49da0e">
													<gml:posList>35.66848236602842 139.74804661535114 23.209189652699052 35.668480348453784 139.74802192867259 23.209189652699052 35.668480348453784 139.74802192867259 21.75299763609749 35.66848236602842 139.74804661535114 21.75299763609749 35.66848236602842 139.74804661535114 23.209189652699052</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
								</gml:MultiSurface>
							</bldg:lod3MultiSurface>
						</bldg:Window>
					</bldg:opening>
					<bldg:opening>
						<bldg:Window gml:id="wnd_cdaa7f21-0666-45da-8291-273dbed3cfaa">
							<bldg:lod3MultiSurface>
								<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_f778343e-15fd-4b0d-83af-d87afa875930">
											<gml:exterior>
												<gml:LinearRing gml:id="line_91e93060-2147-4bdc-ba2c-a92ebe556a6a">
													<gml:posList>35.66848236602842 139.74804661535114 17.392256974476396 35.668480348453784 139.74802192867259 17.392256974476396 35.668480348453784 139.74802192867259 15.936064957874834 35.66848236602842 139.74804661535114 15.936064957874834 35.66848236602842 139.74804661535114 17.392256974476396</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
								</gml:MultiSurface>
							</bldg:lod3MultiSurface>
						</bldg:Window>
					</bldg:opening>
					<bldg:opening>
						<bldg:Window gml:id="wnd_fcac5f19-e4b5-4263-a44e-3ca76c3ed026">
							<bldg:lod3MultiSurface>
								<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_7b28451d-3b8a-4fa2-bf4a-5d6840115772">
											<gml:exterior>
												<gml:LinearRing gml:id="line_a30053d3-970c-4ef9-8066-25549e8e3306">
													<gml:posList>35.66848236602842 139.74804661535114 20.32539296080452 35.668480348453784 139.74802192867259 20.32539296080452 35.668480348453784 139.74802192867259 18.86920094420296 35.66848236602842 139.74804661535114 18.86920094420296 35.66848236602842 139.74804661535114 20.32539296080452</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
								</gml:MultiSurface>
							</bldg:lod3MultiSurface>
						</bldg:Window>
					</bldg:opening>
					<bldg:opening>
						<bldg:Window gml:id="wnd_894a6e1f-4153-4623-a8ac-cdd222c43c97">
							<bldg:lod3MultiSurface>
								<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_68bf1ff1-7e75-4d8c-a183-32e7c97aae50">
											<gml:exterior>
												<gml:LinearRing gml:id="line_56974a9f-8873-436d-bbf1-68349e85524f">
													<gml:posList>35.66848453551788 139.74807315927464 18.86920094420296 35.66848453551788 139.74807315927464 20.32539296080452 35.66848350592355 139.74806056237534 20.32539296080452 35.66848350592355 139.74806056237534 18.86920094420296 35.66848453551788 139.74807315927464 18.86920094420296</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
								</gml:MultiSurface>
							</bldg:lod3MultiSurface>
						</bldg:Window>
					</bldg:opening>
					<bldg:opening>
						<bldg:Window gml:id="wnd_394ca1e5-8cc2-4dc6-ba6a-b79d32c55464">
							<bldg:lod3MultiSurface>
								<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_ed4feff3-0525-4e9d-98fa-388c0880dc50">
											<gml:exterior>
												<gml:LinearRing gml:id="line_0f8d9645-bf2c-4828-8685-ed631e216470">
													<gml:posList>35.66848236602842 139.74804661535114 14.438369035023271 35.668480348453784 139.74802192867259 14.438369035023271 35.668480348453784 139.74802192867259 12.982177018421709 35.66848236602842 139.74804661535114 12.982177018421709 35.66848236602842 139.74804661535114 14.438369035023271</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
								</gml:MultiSurface>
							</bldg:lod3MultiSurface>
						</bldg:Window>
					</bldg:opening>
					<bldg:opening>
						<bldg:Window gml:id="wnd_43536ae7-6115-46c0-a2a6-e90ff9b3e3c8">
							<bldg:lod3MultiSurface>
								<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_d144005c-16ea-4b10-b3f2-26f3c4d5789b">
											<gml:exterior>
												<gml:LinearRing gml:id="line_cd8d9c0e-8282-4aae-9f5e-23e6067b742b">
													<gml:posList>35.66848236602842 139.74804661535114 11.48450398375374 35.668480348453784 139.74802192867259 11.48450398375374 35.668480348453784 139.74802192867259 10.028311967152177 35.66848236602842 139.74804661535114 10.028311967152177 35.66848236602842 139.74804661535114 11.48450398375374</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
								</gml:MultiSurface>
							</bldg:lod3MultiSurface>
						</bldg:Window>
					</bldg:opening>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_e5132450-6f76-42c7-87a9-7d891e5f0451">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_a4a4d342-b418-4f3c-810f-d406765393c8">
									<gml:exterior>
										<gml:LinearRing gml:id="line_6fa6100e-d26a-49b0-9e1a-bac43f8fe27f">
											<gml:posList>35.66853791774639 139.7479788522809 24.452750443714677 35.66853791774639 139.7479788522809 6.294249772327959 35.66849280434337 139.74795785347334 6.294249772327959 35.66849280434337 139.74795785347334 24.452750443714677 35.66853791774639 139.7479788522809 24.452750443714677</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="wall_TMmnt0164_p935_5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly_TMmnt0164_p935_5">
									<gml:exterior>
										<gml:LinearRing gml:id="line_TMmnt0164_p935_5">
											<gml:posList>35.66849635815226 139.74795973357445 24.15980167 35.66854058572357 139.74798110890973 24.16197259 35.668540655183804 139.74798112524994 5.44126129 35.6684964274823 139.74795974985204 5.43909036 35.66849635815226 139.74795973357445 24.15980167</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_aa268d6e-771b-4055-80a7-5d238334fdca">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_e625d9e8-565b-4751-a20c-b5183c08991a">
									<gml:exterior>
										<gml:LinearRing gml:id="line_034351da-026b-478c-a1a5-400b2ce1f813">
											<gml:posList>35.66848327644575 139.7480577539261 6.360244035023271 35.6684888308502 139.74806033928476 8.582152604359209 35.668487872027285 139.74805989314507 10.028311967152177 35.66848327644575 139.7480577539261 6.360244035023271</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_e347ff21-1b14-48c4-86f3-1f39d914e41e">
									<gml:exterior>
										<gml:LinearRing gml:id="line_b6e806c1-f19d-4907-8ab5-7c2abd5496d2">
											<gml:posList>35.6684888308502 139.74806033928476 8.582152604359209 35.66848327644575 139.7480577539261 6.360244035023271 35.6684888308502 139.74806033928476 6.360244035023271 35.6684888308502 139.74806033928476 8.582152604359209</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_bd1da2d5-4c8c-41d5-8c85-737a13bd0bff">
									<gml:exterior>
										<gml:LinearRing gml:id="line_ade23190-eb35-46c2-b6a5-c6f8dcb93ecf">
											<gml:posList>35.66848327644575 139.7480577539261 6.360244035023271 35.668487872027285 139.74805989314507 10.028311967152177 35.668487872027285 139.74805989314507 11.48450398375374 35.66848327644575 139.7480577539261 6.360244035023271</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_8cd9ae65-986b-4abf-95e6-81b2b87bbec5">
									<gml:exterior>
										<gml:LinearRing gml:id="line_9740964e-c6a7-4868-a29f-9a33311e8b2e">
											<gml:posList>35.66848327644575 139.7480577539261 6.360244035023271 35.668487872027285 139.74805989314507 11.48450398375374 35.66848327644575 139.7480577539261 17.392256974476396 35.66848327644575 139.7480577539261 6.360244035023271</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_56e05333-f497-4f08-ae87-f22c68209ad2">
									<gml:exterior>
										<gml:LinearRing gml:id="line_c0294fdd-8d03-44bb-96cc-35cd37eb8589">
											<gml:posList>35.66848327644575 139.7480577539261 17.392256974476396 35.668487872027285 139.74805989314507 11.48450398375374 35.668487872027285 139.74805989314507 12.982177018421709 35.66848327644575 139.7480577539261 17.392256974476396</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_4f65fdcf-9362-4d86-b436-e740bbf6756f">
									<gml:exterior>
										<gml:LinearRing gml:id="line_efe17b99-f40b-4535-b605-928f3c52474a">
											<gml:posList>35.66850253160428 139.74806671658314 8.582152604359209 35.66850965653016 139.74807003312242 6.360244035023271 35.668502433369405 139.74806667101092 10.028311967152177 35.66850253160428 139.74806671658314 8.582152604359209</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_752bb99e-0dd8-4eac-95c4-b7a2cf6d07a3">
									<gml:exterior>
										<gml:LinearRing gml:id="line_e0c29b67-0908-4745-be2c-60a1efee6923">
											<gml:posList>35.66850965653016 139.74807003312242 6.360244035023271 35.66850253160428 139.74806671658314 8.582152604359209 35.66850253160428 139.74806671658314 6.360244035023271 35.66850965653016 139.74807003312242 6.360244035023271</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_598ab1a6-e9e3-43cd-9111-e60529d34222">
									<gml:exterior>
										<gml:LinearRing gml:id="line_0e84f814-aa8d-4d9c-8033-cab85974c15c">
											<gml:posList>35.668502433369405 139.74806667101092 10.028311967152177 35.66850965653016 139.74807003312242 6.360244035023271 35.668502433369405 139.74806667101092 11.48450398375374 35.668502433369405 139.74806667101092 10.028311967152177</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_c04cd17d-49e4-48cc-bb6b-822970e62aed">
									<gml:exterior>
										<gml:LinearRing gml:id="line_33be830f-0b8f-4291-92d7-3ed243948e77">
											<gml:posList>35.668502433506944 139.74806667101078 15.936064957874834 35.66850965653016 139.74807003312242 17.392256974476396 35.668502433506944 139.74806667101078 17.392256974476396 35.668502433506944 139.74806667101078 15.936064957874834</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_e91c6ded-b019-47dc-a793-37cdd91142bb">
									<gml:exterior>
										<gml:LinearRing gml:id="line_2518f0be-150e-41eb-a3fe-159b5fe47833">
											<gml:posList>35.66850965653016 139.74807003312242 17.392256974476396 35.668502433506944 139.74806667101078 15.936064957874834 35.668502433369405 139.74806667101092 14.438369035023271 35.66850965653016 139.74807003312242 17.392256974476396</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_7fa76108-c110-408d-a53e-4c32361997df">
									<gml:exterior>
										<gml:LinearRing gml:id="line_f61fb17c-ba03-42f1-a674-33c9e56bba33">
											<gml:posList>35.66850253160428 139.74806671658314 8.582152604359209 35.668502433369405 139.74806667101092 10.028311967152177 35.66849536911799 139.74806338272387 8.582152604359209 35.66850253160428 139.74806671658314 8.582152604359209</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_e8e8a9a5-3f6c-4f20-b0c2-938cf80b4024">
									<gml:exterior>
										<gml:LinearRing gml:id="line_efac1683-0d66-453d-9ee8-772474283cdc">
											<gml:posList>35.66849536911799 139.74806338272387 8.582152604359209 35.668502433369405 139.74806667101092 10.028311967152177 35.668487872027285 139.74805989314507 10.028311967152177 35.66849536911799 139.74806338272387 8.582152604359209</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_14a4c4c4-c789-4135-a408-5fb367e02955">
									<gml:exterior>
										<gml:LinearRing gml:id="line_90e78937-543c-4dae-9c1a-ff90bab9e809">
											<gml:posList>35.66849536911799 139.74806338272387 8.582152604359209 35.668487872027285 139.74805989314507 10.028311967152177 35.6684888308502 139.74806033928476 8.582152604359209 35.66849536911799 139.74806338272387 8.582152604359209</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_bbed0cbd-256f-4e51-a394-06e0e6869ea8">
									<gml:exterior>
										<gml:LinearRing gml:id="line_43dd08e2-2572-4812-a14f-dd1fcdfbc0c3">
											<gml:posList>35.66850965653016 139.74807003312242 17.392256974476396 35.668502433369405 139.74806667101092 12.982177018421709 35.668502433369405 139.74806667101092 11.48450398375374 35.66850965653016 139.74807003312242 17.392256974476396</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_da97e705-26e8-453b-9324-a7ad9e11e270">
									<gml:exterior>
										<gml:LinearRing gml:id="line_90695da6-adab-4eb1-bebf-fc4d1441df14">
											<gml:posList>35.668502433369405 139.74806667101092 12.982177018421709 35.66850965653016 139.74807003312242 17.392256974476396 35.668502433369405 139.74806667101092 14.438369035023271 35.668502433369405 139.74806667101092 12.982177018421709</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_2877074b-1711-4d9e-a7f2-ce9ca1244a93">
									<gml:exterior>
										<gml:LinearRing gml:id="line_9e7e7f50-7b13-4763-86a6-19febbb27e33">
											<gml:posList>35.668502433369405 139.74806667101092 14.438369035023271 35.668502433506944 139.74806667101078 15.936064957874834 35.668487872164825 139.74805989314493 15.936064957874834 35.668502433369405 139.74806667101092 14.438369035023271</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_540bdce5-2984-4195-adb4-c9fe5273fabf">
									<gml:exterior>
										<gml:LinearRing gml:id="line_c7a3dc46-0cec-4537-b9c1-7e98c0016914">
											<gml:posList>35.668502433369405 139.74806667101092 11.48450398375374 35.66850965653016 139.74807003312242 6.360244035023271 35.66850965653016 139.74807003312242 17.392256974476396 35.668502433369405 139.74806667101092 11.48450398375374</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_2f2717f7-9116-4084-b92f-db35e8052ba4">
									<gml:exterior>
										<gml:LinearRing gml:id="line_8144dad2-9c4d-46a8-81cf-f678bc11982d">
											<gml:posList>35.668502433369405 139.74806667101092 14.438369035023271 35.668487872164825 139.74805989314493 15.936064957874834 35.668487872027285 139.74805989314507 14.438369035023271 35.668502433369405 139.74806667101092 14.438369035023271</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_2d397cf6-64a4-4f3c-87f1-95ddfb251a6c">
									<gml:exterior>
										<gml:LinearRing gml:id="line_14c126d8-335c-4fa9-a9f8-5a1f6d9d3469">
											<gml:posList>35.668487872027285 139.74805989314507 14.438369035023271 35.668487872164825 139.74805989314493 15.936064957874834 35.66848327644575 139.7480577539261 17.392256974476396 35.668487872027285 139.74805989314507 14.438369035023271</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_b4a69a4f-26a2-4211-80d3-8d100e0abece">
									<gml:exterior>
										<gml:LinearRing gml:id="line_d1d6825d-1b4f-4643-8f01-0284d1a1cbfe">
											<gml:posList>35.66848327644575 139.7480577539261 17.392256974476396 35.668487872164825 139.74805989314493 15.936064957874834 35.668487872164825 139.74805989314493 17.392256974476396 35.66848327644575 139.7480577539261 17.392256974476396</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_0ebf91f5-8e08-4fef-bdd3-b1c58287586f">
									<gml:exterior>
										<gml:LinearRing gml:id="line_6f1b2fc5-f5bb-427e-b2b2-42c82794f9a1">
											<gml:posList>35.668487872027285 139.74805989314507 14.438369035023271 35.66848327644575 139.7480577539261 17.392256974476396 35.668487872027285 139.74805989314507 12.982177018421709 35.668487872027285 139.74805989314507 14.438369035023271</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_30eee722-05e2-49a4-813e-2e40022d7b54">
									<gml:exterior>
										<gml:LinearRing gml:id="line_0ff1d411-96ea-4dc3-be4c-984b03f70c61">
											<gml:posList>35.668487872027285 139.74805989314507 12.982177018421709 35.668502433369405 139.74806667101092 11.48450398375374 35.668502433369405 139.74806667101092 12.982177018421709 35.668487872027285 139.74805989314507 12.982177018421709</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_1c39b3b7-879b-4f9c-a505-8890ad9182f4">
									<gml:exterior>
										<gml:LinearRing gml:id="line_aca57545-fa2d-496a-9ed9-efddd60545c6">
											<gml:posList>35.668502433369405 139.74806667101092 11.48450398375374 35.668487872027285 139.74805989314507 12.982177018421709 35.668487872027285 139.74805989314507 11.48450398375374 35.668502433369405 139.74806667101092 11.48450398375374</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
					<bldg:opening>
						<bldg:Door gml:id="dor_be53c588-d4a7-4f09-8b30-7f4638610740">
							<bldg:lod3MultiSurface>
								<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_3f5c1392-5d1f-46b1-90ba-1d827d3729a9">
											<gml:exterior>
												<gml:LinearRing gml:id="line_51809f7a-ead4-4352-88ec-229a4f7dcdcc">
													<gml:posList>35.66849536911799 139.74806338272387 6.360244035023271 35.66849536911799 139.74806338272387 8.582152604359209 35.6684888308502 139.74806033928476 8.582152604359209 35.6684888308502 139.74806033928476 6.360244035023271 35.66849536911799 139.74806338272387 6.360244035023271</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
								</gml:MultiSurface>
							</bldg:lod3MultiSurface>
						</bldg:Door>
					</bldg:opening>
					<bldg:opening>
						<bldg:Window gml:id="wnd_cb9a0b72-5166-4e28-97c3-7c5dc8fa8170">
							<bldg:lod3MultiSurface>
								<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_0c54a3ff-cc96-4768-bcb6-609c3c72c86f">
											<gml:exterior>
												<gml:LinearRing gml:id="line_7b4ebef2-50c1-47ea-b781-d164f701ce70">
													<gml:posList>35.668487872164825 139.74805989314493 15.936064957874834 35.668502433506944 139.74806667101078 15.936064957874834 35.668502433506944 139.74806667101078 17.392256974476396 35.668487872164825 139.74805989314493 17.392256974476396 35.668487872164825 139.74805989314493 15.936064957874834</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
								</gml:MultiSurface>
							</bldg:lod3MultiSurface>
						</bldg:Window>
					</bldg:opening>
					<bldg:opening>
						<bldg:Window gml:id="wnd_f14f5ff0-cbeb-4eee-aa69-702d0b0600a3">
							<bldg:lod3MultiSurface>
								<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_37abebcb-8c8b-4129-87d1-cd34701a5e9e">
											<gml:exterior>
												<gml:LinearRing gml:id="line_9fa99b6b-e229-46fb-89e1-bf6ca3cd25de">
													<gml:posList>35.668487872027285 139.74805989314507 14.438369035023271 35.668487872027285 139.74805989314507 12.982177018421709 35.668502433369405 139.74806667101092 12.982177018421709 35.668502433369405 139.74806667101092 14.438369035023271 35.668487872027285 139.74805989314507 14.438369035023271</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
								</gml:MultiSurface>
							</bldg:lod3MultiSurface>
						</bldg:Window>
					</bldg:opening>
					<bldg:opening>
						<bldg:Window gml:id="wnd_0eb461dd-f795-4d4f-a890-fe117ac25215">
							<bldg:lod3MultiSurface>
								<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_7deefc0c-38be-4d06-b853-07a879b9e357">
											<gml:exterior>
												<gml:LinearRing gml:id="line_908f1c14-6a10-4f70-b867-50004ce8e75e">
													<gml:posList>35.66850253160428 139.74806671658314 8.582152604359209 35.66849536911799 139.74806338272387 8.582152604359209 35.66849536911799 139.74806338272387 6.360244035023271 35.66850253160428 139.74806671658314 6.360244035023271 35.66850253160428 139.74806671658314 8.582152604359209</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
								</gml:MultiSurface>
							</bldg:lod3MultiSurface>
						</bldg:Window>
					</bldg:opening>
					<bldg:opening>
						<bldg:Window gml:id="wnd_95266b7d-615a-4931-b6a5-d4b58552ae53">
							<bldg:lod3MultiSurface>
								<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_cced1348-0cc5-44fc-87f4-484315687540">
											<gml:exterior>
												<gml:LinearRing gml:id="line_837de118-ae9c-4c9a-a370-c6c3dd549e5b">
													<gml:posList>35.668487872027285 139.74805989314507 11.48450398375374 35.668487872027285 139.74805989314507 10.028311967152177 35.668502433369405 139.74806667101092 10.028311967152177 35.668502433369405 139.74806667101092 11.48450398375374 35.668487872027285 139.74805989314507 11.48450398375374</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
								</gml:MultiSurface>
							</bldg:lod3MultiSurface>
						</bldg:Window>
					</bldg:opening>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="wall_TMmnt0164_p935_3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly_TMmnt0164_p935_3">
									<gml:exterior>
										<gml:LinearRing gml:id="line_TMmnt0164_p935_3">
											<gml:posList>35.66848781447428 139.7480713496986 24.16021578 35.668481408697865 139.74799613949597 24.15938067 35.66848147798382 139.74799615588034 5.43866936 35.66848788377913 139.7480713663035 5.43950448 35.66848781447428 139.7480713496986 24.16021578</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_59de25d8-a384-495e-85e0-17bcbc83bb73">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_ffd600ea-9a52-4932-b628-6da08ca44ec5">
									<gml:exterior>
										<gml:LinearRing gml:id="line_32d1cbb1-dde2-4617-86ce-114e36604b73">
											<gml:posList>35.66850803850799 139.74807525344528 18.86920094420296 35.66850564241849 139.74808298394694 18.86920094420296 35.66850564241849 139.74808298394694 17.392256974476396 35.66850965653016 139.74807003312242 17.392256974476396 35.66850965653016 139.74807003312242 6.360244035023271 35.6685060789318 139.7480815754277 6.360244035023271 35.6685060789318 139.7480815754277 6.294249772327959 35.66853791774639 139.7479788522809 6.294249772327959 35.66853791774639 139.7479788522809 24.452750443714677 35.66850564241849 139.74808298394694 24.452750443714677 35.66850564241849 139.74808298394694 20.32539296080452 35.66850803850799 139.74807525344528 20.32539296080452 35.66850803850799 139.74807525344528 18.86920094420296</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
					<bldg:opening>
						<bldg:Window gml:id="wnd_d8a005f4-82d9-4c5f-b6ad-af5a095ea504">
							<bldg:lod3MultiSurface>
								<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_60bdf5a5-2982-4906-b476-f794309a8cb9">
											<gml:exterior>
												<gml:LinearRing gml:id="line_d69aa5dc-e55f-4936-baaa-4af51efca626">
													<gml:posList>35.66850564241849 139.74808298394694 20.32539296080452 35.66850564241849 139.74808298394694 18.86920094420296 35.66850803850799 139.74807525344528 18.86920094420296 35.66850803850799 139.74807525344528 20.32539296080452 35.66850564241849 139.74808298394694 20.32539296080452</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
								</gml:MultiSurface>
							</bldg:lod3MultiSurface>
						</bldg:Window>
					</bldg:opening>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_53094435-1b03-427e-9d40-f811e8a82c3e">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_b691a4dd-956e-461d-bdff-8061fe6cc47f">
									<gml:exterior>
										<gml:LinearRing gml:id="line_25ce7896-2d7d-4e5a-b4d6-c59cef8d02c2">
											<gml:posList>35.66850564241849 139.74808298394694 18.86920094420296 35.66848453551788 139.74807315927464 18.86920094420296 35.66848453551788 139.74807315927464 17.392256974476396 35.66850564241849 139.74808298394694 17.392256974476396 35.66850564241849 139.74808298394694 18.86920094420296</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
					<bldg:opening>
						<bldg:Window gml:id="wnd_9ab9d653-3bf7-447b-8a4d-9f06f63e1243">
							<bldg:lod3MultiSurface>
								<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_57df8186-f910-48d5-b029-fae1c65eb1b8">
											<gml:exterior>
												<gml:LinearRing gml:id="line_640f2d66-d839-4d87-8856-2fb345cee36e">
													<gml:posList>35.66848453551788 139.74807315927464 20.32539296080452 35.66848453551788 139.74807315927464 18.86920094420296 35.66850564241849 139.74808298394694 18.86920094420296 35.66850564241849 139.74808298394694 20.32539296080452 35.66848453551788 139.74807315927464 20.32539296080452</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
								</gml:MultiSurface>
							</bldg:lod3MultiSurface>
						</bldg:Window>
					</bldg:opening>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="wall_TMmnt0164_p935_1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly_TMmnt0164_p935_1">
									<gml:exterior>
										<gml:LinearRing gml:id="line_TMmnt0164_p935_1">
											<gml:posList>35.66854058572357 139.74798110890973 24.16197259 35.66850834989307 139.7480812744906 24.16122431 35.6685084192584 139.7480812911246 5.44051301 35.668540655183804 139.74798112524994 5.44126129 35.66854058572357 139.74798110890973 24.16197259</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_8d89d47b-7bc8-4b4d-b632-37b627c7de24">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_4370d34b-0825-43b9-a474-7de83996e6a3">
									<gml:exterior>
										<gml:LinearRing gml:id="line_87e2d0b0-6f6e-4ea5-a314-1af1ef173dbe">
											<gml:posList>35.66848247035328 139.7479911946181 19.95741200377327 35.668478803429096 139.74800302523607 24.452750443714677 35.668484251669526 139.74798544757564 19.95741200377327 35.66848247035328 139.7479911946181 19.95741200377327</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_537d591e-9b4f-483e-b690-d1bc90cebc80">
									<gml:exterior>
										<gml:LinearRing gml:id="line_2811cd73-cf31-44d9-b92c-4b9dee84fde6">
											<gml:posList>35.668478803429096 139.74800302523607 24.452750443714677 35.66848247035328 139.7479911946181 19.95741200377327 35.66848247035328 139.7479911946181 19.154258012074052 35.668478803429096 139.74800302523607 24.452750443714677</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_bc5e5dac-325e-48ef-9431-63a38c3b6101">
									<gml:exterior>
										<gml:LinearRing gml:id="line_593d097f-1ab7-441a-9097-2a3894693b8b">
											<gml:posList>35.668478803429096 139.74800302523607 24.452750443714677 35.66848247035328 139.7479911946181 19.154258012074052 35.66848247035328 139.7479911946181 17.069419144886552 35.668478803429096 139.74800302523607 24.452750443714677</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_40447075-6c64-45e0-ba02-36dd86981426">
									<gml:exterior>
										<gml:LinearRing gml:id="line_8b752415-27d4-4dac-a190-a49293dcf5a8">
											<gml:posList>35.668484251669526 139.74798544757564 19.95741200377327 35.668478803429096 139.74800302523607 24.452750443714677 35.66849280434337 139.74795785347334 24.452750443714677 35.668484251669526 139.74798544757564 19.95741200377327</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_8b71c019-cdc0-4e03-b666-744868fd21ad">
									<gml:exterior>
										<gml:LinearRing gml:id="line_821bf786-0749-433e-99fc-a0c1e054e120">
											<gml:posList>35.668484251669526 139.74798544757564 19.95741200377327 35.66849280434337 139.74795785347334 24.452750443714677 35.668484251669526 139.74798544757564 19.154258012074052 35.668484251669526 139.74798544757564 19.95741200377327</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_203a73a2-2b43-4704-a96a-c01c1bede9a0">
									<gml:exterior>
										<gml:LinearRing gml:id="line_e9308a06-1a96-42dc-9a49-bab04213fc97">
											<gml:posList>35.668484251669526 139.74798544757564 19.154258012074052 35.66849280434337 139.74795785347334 24.452750443714677 35.668484251669526 139.74798544757564 17.069419144886552 35.668484251669526 139.74798544757564 19.154258012074052</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_8e3ef8f7-0455-4e92-b683-6f9bd51a9e41">
									<gml:exterior>
										<gml:LinearRing gml:id="line_49b76d85-c21c-4901-92f6-a729770e3aaa">
											<gml:posList>35.668484251669526 139.74798544757564 17.069419144886552 35.66849280434337 139.74795785347334 24.452750443714677 35.668484251669526 139.74798544757564 16.266272782581865 35.668484251669526 139.74798544757564 17.069419144886552</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_affca2c8-e3b5-4753-8408-b81f1b64e896">
									<gml:exterior>
										<gml:LinearRing gml:id="line_f2809b92-15a8-4a80-b764-54f1606bd035">
											<gml:posList>35.668484251669526 139.74798544757564 16.266272782581865 35.66849280434337 139.74795785347334 24.452750443714677 35.66849280434337 139.74795785347334 6.294249772327959 35.668484251669526 139.74798544757564 16.266272782581865</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_ef9b4329-d83a-4de5-9595-6874d7837855">
									<gml:exterior>
										<gml:LinearRing gml:id="line_1e805c4a-8552-4e45-a3a1-388ac1923530">
											<gml:posList>35.66848247035328 139.7479911946181 17.069419144886552 35.66848247035328 139.7479911946181 19.154258012074052 35.668484251669526 139.74798544757564 19.154258012074052 35.66848247035328 139.7479911946181 17.069419144886552</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_1cc5fd7c-c5ff-4afe-b174-edac2ec36241">
									<gml:exterior>
										<gml:LinearRing gml:id="line_aafc507b-18df-4d9b-99d0-bd57e2defc10">
											<gml:posList>35.66848247035328 139.7479911946181 17.069419144886552 35.668484251669526 139.74798544757564 19.154258012074052 35.668484251669526 139.74798544757564 17.069419144886552 35.66848247035328 139.7479911946181 17.069419144886552</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_f290e6a8-e9aa-4133-ab16-519edaabe5a3">
									<gml:exterior>
										<gml:LinearRing gml:id="line_107f84b8-3895-406f-b9e9-b942edb0b814">
											<gml:posList>35.668478803429096 139.74800302523607 6.294249772327959 35.66848247035328 139.7479911946181 16.266272782581865 35.668484251669526 139.74798544757564 16.266272782581865 35.668478803429096 139.74800302523607 6.294249772327959</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_98a416fa-84c1-4191-85d3-46b67cd18d12">
									<gml:exterior>
										<gml:LinearRing gml:id="line_9a15d4f4-ab0c-49e2-ba78-ed00dcc1ca0f">
											<gml:posList>35.66848247035328 139.7479911946181 16.266272782581865 35.668478803429096 139.74800302523607 6.294249772327959 35.668478803429096 139.74800302523607 24.452750443714677 35.66848247035328 139.7479911946181 16.266272782581865</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_226b99db-7d9c-4f1e-aa60-2a0552ac94a0">
									<gml:exterior>
										<gml:LinearRing gml:id="line_ac4cce90-e349-4372-b8d9-8b06af0fcb4b">
											<gml:posList>35.668478803429096 139.74800302523607 6.294249772327959 35.668484251669526 139.74798544757564 16.266272782581865 35.66849280434337 139.74795785347334 6.294249772327959 35.668478803429096 139.74800302523607 6.294249772327959</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_32b48be5-fb10-4f48-8345-f008efd48a36">
									<gml:exterior>
										<gml:LinearRing gml:id="line_20dd55a2-57fc-42db-abc3-cde5ce108420">
											<gml:posList>35.66848247035328 139.7479911946181 16.266272782581865 35.668478803429096 139.74800302523607 24.452750443714677 35.66848247035328 139.7479911946181 17.069419144886552 35.66848247035328 139.7479911946181 16.266272782581865</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
					<bldg:opening>
						<bldg:Window gml:id="wnd_b860022d-a80b-4f37-8252-d5e0914788dd">
							<bldg:lod3MultiSurface>
								<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_51e52955-9a1d-42dc-916c-c7bbdaba5c96">
											<gml:exterior>
												<gml:LinearRing gml:id="line_20c9fa7a-0172-40ee-bee7-3ec075e8bc68">
													<gml:posList>35.66848247035328 139.7479911946181 16.266272782581865 35.66848247035328 139.7479911946181 17.069419144886552 35.668484251669526 139.74798544757564 17.069419144886552 35.668484251669526 139.74798544757564 16.266272782581865 35.66848247035328 139.7479911946181 16.266272782581865</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
								</gml:MultiSurface>
							</bldg:lod3MultiSurface>
						</bldg:Window>
					</bldg:opening>
					<bldg:opening>
						<bldg:Window gml:id="wnd_bc4e3bab-442a-4826-b3a8-50333c90783e">
							<bldg:lod3MultiSurface>
								<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_ef9c90a3-1c8f-4a15-9e51-fc2fbdfc2cb3">
											<gml:exterior>
												<gml:LinearRing gml:id="line_8a5bc0cd-0a6a-4f76-a9f1-7c501184a717">
													<gml:posList>35.66848247035328 139.7479911946181 19.154258012074052 35.66848247035328 139.7479911946181 19.95741200377327 35.668484251669526 139.74798544757564 19.95741200377327 35.668484251669526 139.74798544757564 19.154258012074052 35.66848247035328 139.7479911946181 19.154258012074052</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
								</gml:MultiSurface>
							</bldg:lod3MultiSurface>
						</bldg:Window>
					</bldg:opening>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_77aa6dd1-0017-49e5-9152-3e194c59d156">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_8b73f1c8-3314-4f70-bf88-e63988dcb0a9">
									<gml:exterior>
										<gml:LinearRing gml:id="line_f0358aa6-1086-4c58-874d-f91df1983b05">
											<gml:posList>35.66848453551788 139.74807315927464 20.32539296080452 35.66850564241849 139.74808298394694 20.32539296080452 35.66850564241849 139.74808298394694 24.452750443714677 35.66848453551788 139.74807315927464 24.452750443714677 35.66848453551788 139.74807315927464 20.32539296080452</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:OuterFloorSurface gml:id="gml_f616b98b-af43-4514-90ff-566f2da773a3">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_b121b386-0d97-4672-8fe9-4f81de08aa3b">
									<gml:exterior>
										<gml:LinearRing gml:id="line_20e88502-3a72-44ad-a049-7a7c14778666">
											<gml:posList>35.66850965653016 139.74807003312242 6.360244035023271 35.66850253160428 139.74806671658314 6.360244035023271 35.66849536911799 139.74806338272387 6.360244035023271 35.6684888308502 139.74806033928476 6.360244035023271 35.66848327644575 139.7480577539261 6.360244035023271 35.66848439858094 139.74807148387893 6.360244035023271 35.6685060789318 139.7480815754277 6.360244035023271 35.66850965653016 139.74807003312242 6.360244035023271</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:OuterFloorSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:OuterFloorSurface gml:id="gml_3eada630-7f8b-46c8-9329-473508c533fe">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_ddefbd7f-f3df-4804-8104-1b4f245675ef">
									<gml:exterior>
										<gml:LinearRing gml:id="line_d6d0b24b-5591-4b32-bf9d-7ef8ae02e964">
											<gml:posList>35.668482250456854 139.74804520084598 6.360244035023271 35.66849196190255 139.748015658276 6.360244035023271 35.66848386109155 139.748011887531 6.360244035023271 35.66848261499287 139.74801130753295 6.360244035023271 35.66847935645226 139.74800979069232 6.360244035023271 35.668482250456854 139.74804520084598 6.360244035023271</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:OuterFloorSurface>
			</bldg:boundedBy>
			<bldg:lod3Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#Poly_7deefc0c-38be-4d06-b853-07a879b9e357"/>
							<gml:surfaceMember xlink:href="#Poly_cced1348-0cc5-44fc-87f4-484315687540"/>
							<gml:surfaceMember xlink:href="#Poly_37abebcb-8c8b-4129-87d1-cd34701a5e9e"/>
							<gml:surfaceMember xlink:href="#Poly_0c54a3ff-cc96-4768-bcb6-609c3c72c86f"/>
							<gml:surfaceMember xlink:href="#Poly_60bdf5a5-2982-4906-b476-f794309a8cb9"/>
							<gml:surfaceMember xlink:href="#Poly_57df8186-f910-48d5-b029-fae1c65eb1b8"/>
							<gml:surfaceMember xlink:href="#Poly_b691a4dd-956e-461d-bdff-8061fe6cc47f"/>
							<gml:surfaceMember xlink:href="#Poly_68bf1ff1-7e75-4d8c-a183-32e7c97aae50"/>
							<gml:surfaceMember xlink:href="#Poly_3f5c1392-5d1f-46b1-90ba-1d827d3729a9"/>
							<gml:surfaceMember xlink:href="#Poly_51e52955-9a1d-42dc-916c-c7bbdaba5c96"/>
							<gml:surfaceMember xlink:href="#Poly_ef9c90a3-1c8f-4a15-9e51-fc2fbdfc2cb3"/>
							<gml:surfaceMember xlink:href="#Poly_dc5d05ac-3459-46b8-a9c1-d0b17fb8e3f3"/>
							<gml:surfaceMember xlink:href="#Poly_a5ff8550-746c-41cb-a251-129874d2fe0a"/>
							<gml:surfaceMember xlink:href="#Poly_2e744ce7-1c3f-4bcf-97d1-bdd33f3a22df"/>
							<gml:surfaceMember xlink:href="#Poly_bac0b78d-e450-426a-a1cb-84a0fdab1c8f"/>
							<gml:surfaceMember xlink:href="#Poly_86383d1c-c5fb-4aa5-96a2-453f31f55dde"/>
							<gml:surfaceMember xlink:href="#Poly_790c4fbd-c1d3-428c-9968-c451ee1457fa"/>
							<gml:surfaceMember xlink:href="#Poly_e9d59326-5297-4834-a123-0ccb83f3602c"/>
							<gml:surfaceMember xlink:href="#Poly_59d299ad-019a-478c-b303-dc1293f3028f"/>
							<gml:surfaceMember xlink:href="#Poly_29172ddd-20d9-4cee-9347-d05f7c56a204"/>
							<gml:surfaceMember xlink:href="#Poly_8093730d-5ebe-4c8e-8803-d4c1b61fb6e1"/>
							<gml:surfaceMember xlink:href="#Poly_91014902-c8e0-48f2-83fd-0f4469d0b2c4"/>
							<gml:surfaceMember xlink:href="#Poly_632e1a3d-1b8b-43bd-9c7d-c6ccd0397c2a"/>
							<gml:surfaceMember xlink:href="#Poly_bef172cd-1e47-4486-9fc8-9895f08fe216"/>
							<gml:surfaceMember xlink:href="#Poly_153fd34a-3946-4fa8-a32b-3c5d332b32f2"/>
							<gml:surfaceMember xlink:href="#Poly_91fe7fca-2a67-4755-8e59-b4b6654f9d3d"/>
							<gml:surfaceMember xlink:href="#Poly_394bace8-35a5-4b88-94b2-057bd700be2f"/>
							<gml:surfaceMember xlink:href="#Poly_280419a1-0301-48e1-93b9-45bb010fa5d3"/>
							<gml:surfaceMember xlink:href="#Poly_ebdf8ced-afca-461b-bbc4-225cfb332f22"/>
							<gml:surfaceMember xlink:href="#Poly_dc9375ba-4bee-4e21-b79f-06a78f5fe925"/>
							<gml:surfaceMember xlink:href="#Poly_0d8b92b0-63b8-4604-a505-0b28afadfacf"/>
							<gml:surfaceMember xlink:href="#Poly_ebc78441-53ef-49e3-b0a7-2b1cfc6fa8c3"/>
							<gml:surfaceMember xlink:href="#Poly_72b6fa8c-1576-4fa5-9cda-487e9b52216f"/>
							<gml:surfaceMember xlink:href="#Poly_2a4d8532-1af6-4d49-960e-44f52bb1193c"/>
							<gml:surfaceMember xlink:href="#Poly_41ad79d7-7013-44b8-a28d-77dba467c018"/>
							<gml:surfaceMember xlink:href="#Poly_df40d704-6f7a-4d4c-9384-a481d56e7998"/>
							<gml:surfaceMember xlink:href="#Poly_2a57d78a-a5f6-4ebd-a384-14a30a864c98"/>
							<gml:surfaceMember xlink:href="#Poly_3c889d87-35bc-4167-a9b2-ddf5a393205b"/>
							<gml:surfaceMember xlink:href="#Poly_9e35a4eb-501e-43a3-843b-ddd8b4e2e87b"/>
							<gml:surfaceMember xlink:href="#Poly_aa6ed2ec-7fe2-420c-8db6-d551b3fc0c2d"/>
							<gml:surfaceMember xlink:href="#Poly_af859a77-04c4-4159-a86c-c7121fe12346"/>
							<gml:surfaceMember xlink:href="#Poly_06668810-8497-4545-942f-4990eb772b84"/>
							<gml:surfaceMember xlink:href="#Poly_bfe59e01-e06e-4f05-b088-cb138c15d151"/>
							<gml:surfaceMember xlink:href="#Poly_47081e07-481f-4654-a059-72c880a1fc71"/>
							<gml:surfaceMember xlink:href="#Poly_e2ed9ca8-8c76-439d-8d15-b1d077529d58"/>
							<gml:surfaceMember xlink:href="#Poly_2ab24e4b-c802-45db-8f0d-576efd3d0735"/>
							<gml:surfaceMember xlink:href="#Poly_3f5136d5-79b7-4d05-8fc9-d1bcdb1194d5"/>
							<gml:surfaceMember xlink:href="#Poly_bab061fa-adfd-4ec9-b526-7bb38825a7b0"/>
							<gml:surfaceMember xlink:href="#Poly_42d2ae2f-5bc1-4630-90c5-8a87c5ad6358"/>
							<gml:surfaceMember xlink:href="#Poly_010eb204-6bb2-49f0-a205-57dbad960f68"/>
							<gml:surfaceMember xlink:href="#Poly_5f9cff77-8e72-44a9-ae9e-82098a728ac8"/>
							<gml:surfaceMember xlink:href="#Poly_e961916f-cc3c-4ab5-9d63-e3dfc6963e82"/>
							<gml:surfaceMember xlink:href="#Poly_3f3f72ec-1eba-4925-9bbb-5d82a4578ea4"/>
							<gml:surfaceMember xlink:href="#Poly_b1e197d2-c423-445f-af7f-4185a39ed5b3"/>
							<gml:surfaceMember xlink:href="#Poly_31b7ac0f-0b66-40ee-a7ef-9cd23d2f7265"/>
							<gml:surfaceMember xlink:href="#Poly_7624eead-94ad-49a9-9452-afceafda7040"/>
							<gml:surfaceMember xlink:href="#Poly_e9a9c2d1-d7e2-4b95-a1cf-5f299326d626"/>
							<gml:surfaceMember xlink:href="#Poly_5d67d97d-c9ca-42e5-8a97-7c6b86e66c11"/>
							<gml:surfaceMember xlink:href="#Poly_c94673b7-d710-4f34-9d07-a80c8c881939"/>
							<gml:surfaceMember xlink:href="#Poly_81739c80-60ea-4490-8933-887160fc870a"/>
							<gml:surfaceMember xlink:href="#Poly_7eece2af-c860-484a-b5f9-9a9ec40ab8d7"/>
							<gml:surfaceMember xlink:href="#Poly_5676bba4-8fed-4248-abfd-af9fe1b98e9c"/>
							<gml:surfaceMember xlink:href="#Poly_54a43187-fbf7-4b58-98a0-ec3958aa407b"/>
							<gml:surfaceMember xlink:href="#Poly_ed4feff3-0525-4e9d-98fa-388c0880dc50"/>
							<gml:surfaceMember xlink:href="#Poly_d144005c-16ea-4b10-b3f2-26f3c4d5789b"/>
							<gml:surfaceMember xlink:href="#Poly_f778343e-15fd-4b0d-83af-d87afa875930"/>
							<gml:surfaceMember xlink:href="#Poly_7b28451d-3b8a-4fa2-bf4a-5d6840115772"/>
							<gml:surfaceMember xlink:href="#Poly_46922e5f-c36f-4b10-9d40-c489de6722da"/>
							<gml:surfaceMember xlink:href="#Poly_45c8f879-a207-479b-91ae-f86127083266"/>
							<gml:surfaceMember xlink:href="#Poly_49d473f6-6c0d-407e-bd57-4142a40a0a81"/>
							<gml:surfaceMember xlink:href="#Poly_8b73f1c8-3314-4f70-bf88-e63988dcb0a9"/>
							<gml:surfaceMember xlink:href="#Poly_ffd600ea-9a52-4932-b628-6da08ca44ec5"/>
							<gml:surfaceMember xlink:href="#Poly_a4a4d342-b418-4f3c-810f-d406765393c8"/>
							<gml:surfaceMember xlink:href="#Poly_4370d34b-0825-43b9-a474-7de83996e6a3"/>
							<gml:surfaceMember xlink:href="#Poly_537d591e-9b4f-483e-b690-d1bc90cebc80"/>
							<gml:surfaceMember xlink:href="#Poly_bc5e5dac-325e-48ef-9431-63a38c3b6101"/>
							<gml:surfaceMember xlink:href="#Poly_40447075-6c64-45e0-ba02-36dd86981426"/>
							<gml:surfaceMember xlink:href="#Poly_8b71c019-cdc0-4e03-b666-744868fd21ad"/>
							<gml:surfaceMember xlink:href="#Poly_203a73a2-2b43-4704-a96a-c01c1bede9a0"/>
							<gml:surfaceMember xlink:href="#Poly_8e3ef8f7-0455-4e92-b683-6f9bd51a9e41"/>
							<gml:surfaceMember xlink:href="#Poly_affca2c8-e3b5-4753-8408-b81f1b64e896"/>
							<gml:surfaceMember xlink:href="#Poly_ef9b4329-d83a-4de5-9595-6874d7837855"/>
							<gml:surfaceMember xlink:href="#Poly_1cc5fd7c-c5ff-4afe-b174-edac2ec36241"/>
							<gml:surfaceMember xlink:href="#Poly_f290e6a8-e9aa-4133-ab16-519edaabe5a3"/>
							<gml:surfaceMember xlink:href="#Poly_98a416fa-84c1-4191-85d3-46b67cd18d12"/>
							<gml:surfaceMember xlink:href="#Poly_226b99db-7d9c-4f1e-aa60-2a0552ac94a0"/>
							<gml:surfaceMember xlink:href="#Poly_32b48be5-fb10-4f48-8345-f008efd48a36"/>
							<gml:surfaceMember xlink:href="#Poly_0a42ab39-b91a-4acd-909d-6a69a40ee2c6"/>
							<gml:surfaceMember xlink:href="#Poly_e625d9e8-565b-4751-a20c-b5183c08991a"/>
							<gml:surfaceMember xlink:href="#Poly_e347ff21-1b14-48c4-86f3-1f39d914e41e"/>
							<gml:surfaceMember xlink:href="#Poly_bd1da2d5-4c8c-41d5-8c85-737a13bd0bff"/>
							<gml:surfaceMember xlink:href="#Poly_8cd9ae65-986b-4abf-95e6-81b2b87bbec5"/>
							<gml:surfaceMember xlink:href="#Poly_56e05333-f497-4f08-ae87-f22c68209ad2"/>
							<gml:surfaceMember xlink:href="#Poly_4f65fdcf-9362-4d86-b436-e740bbf6756f"/>
							<gml:surfaceMember xlink:href="#Poly_752bb99e-0dd8-4eac-95c4-b7a2cf6d07a3"/>
							<gml:surfaceMember xlink:href="#Poly_598ab1a6-e9e3-43cd-9111-e60529d34222"/>
							<gml:surfaceMember xlink:href="#Poly_c04cd17d-49e4-48cc-bb6b-822970e62aed"/>
							<gml:surfaceMember xlink:href="#Poly_e91c6ded-b019-47dc-a793-37cdd91142bb"/>
							<gml:surfaceMember xlink:href="#Poly_7fa76108-c110-408d-a53e-4c32361997df"/>
							<gml:surfaceMember xlink:href="#Poly_e8e8a9a5-3f6c-4f20-b0c2-938cf80b4024"/>
							<gml:surfaceMember xlink:href="#Poly_14a4c4c4-c789-4135-a408-5fb367e02955"/>
							<gml:surfaceMember xlink:href="#Poly_bbed0cbd-256f-4e51-a394-06e0e6869ea8"/>
							<gml:surfaceMember xlink:href="#Poly_da97e705-26e8-453b-9324-a7ad9e11e270"/>
							<gml:surfaceMember xlink:href="#Poly_2877074b-1711-4d9e-a7f2-ce9ca1244a93"/>
							<gml:surfaceMember xlink:href="#Poly_540bdce5-2984-4195-adb4-c9fe5273fabf"/>
							<gml:surfaceMember xlink:href="#Poly_2f2717f7-9116-4084-b92f-db35e8052ba4"/>
							<gml:surfaceMember xlink:href="#Poly_2d397cf6-64a4-4f3c-87f1-95ddfb251a6c"/>
							<gml:surfaceMember xlink:href="#Poly_b4a69a4f-26a2-4211-80d3-8d100e0abece"/>
							<gml:surfaceMember xlink:href="#Poly_0ebf91f5-8e08-4fef-bdd3-b1c58287586f"/>
							<gml:surfaceMember xlink:href="#Poly_30eee722-05e2-49a4-813e-2e40022d7b54"/>
							<gml:surfaceMember xlink:href="#Poly_1c39b3b7-879b-4f9c-a505-8890ad9182f4"/>
							<gml:surfaceMember xlink:href="#Poly_f3261f5d-d772-464f-b891-fe0f610809dc"/>
							<gml:surfaceMember xlink:href="#Poly_48480778-23a7-4f83-a49d-aa0c7a183937"/>
							<gml:surfaceMember xlink:href="#Poly_97e0a7b0-33c5-4d37-bb9d-1caf1cdd0bb3"/>
							<gml:surfaceMember xlink:href="#Poly_ddefbd7f-f3df-4804-8104-1b4f245675ef"/>
							<gml:surfaceMember xlink:href="#Poly_b121b386-0d97-4672-8fe9-4f81de08aa3b"/>
							<gml:surfaceMember xlink:href="#Poly_37f07caa-dfda-41cc-9b85-ce61d0826341"/>
							<gml:surfaceMember xlink:href="#Poly_965820d3-16bf-46e0-b278-744c4585493f"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod3Solid>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区虎ノ門二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">3</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">2</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">2</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.0</uro:lodType>
					<uro:lodType>3.0</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">51.63649</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">9</uro:districtsAndZonesType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1221</uro:detailedUsage>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.35</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-2395200000</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">2</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>