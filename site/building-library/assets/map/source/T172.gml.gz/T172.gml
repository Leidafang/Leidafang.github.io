<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_2d93816d-cba1-43b5-91ac-8ec6a7a769b5">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">413</bldg:usage>
			<bldg:measuredHeight uom="m">17.8</bldg:measuredHeight>
			<bldg:storeysAboveGround>5</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.67263974280557 139.73858440624446 0 35.67267920802839 139.73856546995793 0 35.672641952616864 139.73844888430136 0 35.6726024874122 139.73846782063637 0 35.67263974280557 139.73858440624446 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67263974280557 139.73858440624446 9.259 35.6726024874122 139.73846782063637 9.259 35.672641952616864 139.73844888430136 9.259 35.67267920802839 139.73856546995793 9.259 35.67263974280557 139.73858440624446 9.259</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67263974280557 139.73858440624446 9.259 35.67267920802839 139.73856546995793 9.259 35.67267920802839 139.73856546995793 27.01 35.67263974280557 139.73858440624446 27.01 35.67263974280557 139.73858440624446 9.259</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67267920802839 139.73856546995793 9.259 35.672641952616864 139.73844888430136 9.259 35.672641952616864 139.73844888430136 27.01 35.67267920802839 139.73856546995793 27.01 35.67267920802839 139.73856546995793 9.259</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672641952616864 139.73844888430136 9.259 35.6726024874122 139.73846782063637 9.259 35.6726024874122 139.73846782063637 27.01 35.672641952616864 139.73844888430136 27.01 35.672641952616864 139.73844888430136 9.259</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6726024874122 139.73846782063637 9.259 35.67263974280557 139.73858440624446 9.259 35.67263974280557 139.73858440624446 27.01 35.6726024874122 139.73846782063637 27.01 35.6726024874122 139.73846782063637 9.259</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67263974280557 139.73858440624446 27.01 35.67267920802839 139.73856546995793 27.01 35.672641952616864 139.73844888430136 27.01 35.6726024874122 139.73846782063637 27.01 35.67263974280557 139.73858440624446 27.01</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-34302428-8f14-4ced-9111-15ff9264f866"/>
							<gml:surfaceMember xlink:href="#poly-a4323763-b3e7-403d-8f50-14c265e00d27"/>
							<gml:surfaceMember xlink:href="#poly-713fbe67-e395-400a-9a0f-e58e9164428c"/>
							<gml:surfaceMember xlink:href="#poly-b856b74f-6fe0-4e2a-b2bf-73870c65a791"/>
							<gml:surfaceMember xlink:href="#poly-d8359870-7639-4624-a7a3-d74b68fc7532"/>
							<gml:surfaceMember xlink:href="#poly-34215e63-d4fe-473d-b696-70470a0ddb1c"/>
							<gml:surfaceMember xlink:href="#poly-9561d7ad-f933-4347-9364-572ba475f119"/>
							<gml:surfaceMember xlink:href="#poly-446bb71c-f254-49cf-84af-6964b025ef7d"/>
							<gml:surfaceMember xlink:href="#poly-b4210135-2391-4053-b4e5-68fd4da86ed0"/>
							<gml:surfaceMember xlink:href="#poly-f3e835ae-b459-45ef-9fe5-87da820c2623"/>
							<gml:surfaceMember xlink:href="#poly-e7ed7129-cc88-46be-9977-5618c1a1e7a1"/>
							<gml:surfaceMember xlink:href="#poly-d1e516f9-c17f-489d-8ade-223fab44b6fc"/>
							<gml:surfaceMember xlink:href="#poly-fe4d680e-de93-445e-9997-a970afe126de"/>
							<gml:surfaceMember xlink:href="#poly-fd6524d5-5adc-4161-a160-2c30f77db298"/>
							<gml:surfaceMember xlink:href="#poly-4f30c29a-1aa9-45b2-96d9-3a285439fd70"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_2d93816d-cba1-43b5-91ac-8ec6a7a769b5_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c089ca56-9ad3-4b89-b9be-526eff641f50">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67265905135291 139.73851715398015 31.267 35.67266242178537 139.73852771051847 31.267 35.67265363672326 139.73853192965132 31.267 35.672650257277446 139.73852137312466 31.267 35.67265905135291 139.73851715398015 31.267</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8afcdb30-4d7b-488d-aacd-9425f02d4afa">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8afcdb30-4d7b-488d-aacd-9425f02d4afa_0">
											<gml:posList>35.67265363672326 139.73853192965132 31.267 35.67265363672326 139.73853192965132 33.072 35.672650257277446 139.73852137312466 33.072 35.672650257277446 139.73852137312466 31.267 35.67265363672326 139.73853192965132 31.267</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b47fd4ec-f096-4e58-b2d6-b874e653bea5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b47fd4ec-f096-4e58-b2d6-b874e653bea5_0">
											<gml:posList>35.672650257277446 139.73852137312466 31.267 35.672650257277446 139.73852137312466 33.072 35.67265905135291 139.73851715398015 33.072 35.67265905135291 139.73851715398015 31.267 35.672650257277446 139.73852137312466 31.267</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b4e947bb-7a68-4a5f-9fa9-53445c669615">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b4e947bb-7a68-4a5f-9fa9-53445c669615_0">
											<gml:posList>35.67265905135291 139.73851715398015 33.072 35.672650257277446 139.73852137312466 33.072 35.67265363672326 139.73853192965132 33.072 35.67266242178537 139.73852771051847 33.072 35.67265905135291 139.73851715398015 33.072</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fbf660e7-3519-48b8-a92a-eac70ddc6437">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fbf660e7-3519-48b8-a92a-eac70ddc6437_0">
											<gml:posList>35.67266242178537 139.73852771051847 31.267 35.67266242178537 139.73852771051847 33.072 35.67265363672326 139.73853192965132 33.072 35.67265363672326 139.73853192965132 31.267 35.67266242178537 139.73852771051847 31.267</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1729e0f4-4911-4390-b78a-38c48f7e20d3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1729e0f4-4911-4390-b78a-38c48f7e20d3_0">
											<gml:posList>35.67265905135291 139.73851715398015 31.267 35.67265905135291 139.73851715398015 33.072 35.67266242178537 139.73852771051847 33.072 35.67266242178537 139.73852771051847 31.267 35.67265905135291 139.73851715398015 31.267</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-34302428-8f14-4ced-9111-15ff9264f866">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-34302428-8f14-4ced-9111-15ff9264f866">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-34302428-8f14-4ced-9111-15ff9264f866">
											<gml:posList>35.67263974280555 139.73858440624443 9.259 35.6726024874122 139.73846782063634 9.259 35.67264195261687 139.73844888430133 9.259 35.672679208028384 139.7385654699579 9.259 35.67263974280555 139.73858440624443 9.259</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a4323763-b3e7-403d-8f50-14c265e00d27">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a4323763-b3e7-403d-8f50-14c265e00d27">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a4323763-b3e7-403d-8f50-14c265e00d27">
											<gml:posList>35.672633896542195 139.7385661310808 28.025 35.67267337076721 139.73854718372945 28.025 35.67266817507759 139.7385309293147 28.025 35.67265016344603 139.73853957798627 28.025 35.67264477799759 139.73852272728627 28.025 35.67264194875974 139.73852408936037 28.025 35.67263646391464 139.73850692947673 28.025 35.672646591515395 139.73850206805287 28.025 35.672643971081314 139.73849387459668 28.025 35.672654684347016 139.738488725267 28.025 35.67264195261687 139.73844888430133 28.025 35.6726024874122 139.73846782063634 28.025 35.672633896542195 139.7385661310808 28.025</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-713fbe67-e395-400a-9a0f-e58e9164428c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-713fbe67-e395-400a-9a0f-e58e9164428c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-713fbe67-e395-400a-9a0f-e58e9164428c">
											<gml:posList>35.67264477799759 139.73852272728627 31.267 35.67265016344603 139.73853957798627 31.267 35.67266817507759 139.7385309293147 31.267 35.672654684347016 139.738488725267 31.267 35.672643971081314 139.73849387459668 31.267 35.672646591515395 139.73850206805287 31.267 35.67263646391464 139.73850692947673 31.267 35.67264194875974 139.73852408936037 31.267 35.67264477799759 139.73852272728627 31.267</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b856b74f-6fe0-4e2a-b2bf-73870c65a791">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b856b74f-6fe0-4e2a-b2bf-73870c65a791">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b856b74f-6fe0-4e2a-b2bf-73870c65a791">
											<gml:posList>35.672633896542195 139.7385661310808 28.025 35.67263974280555 139.73858440624443 23.266 35.672679208028384 139.7385654699579 23.266 35.67267337076721 139.73854718372945 28.025 35.672633896542195 139.7385661310808 28.025</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d8359870-7639-4624-a7a3-d74b68fc7532">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d8359870-7639-4624-a7a3-d74b68fc7532">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d8359870-7639-4624-a7a3-d74b68fc7532">
											<gml:posList>35.6726024874122 139.73846782063634 28.025 35.6726024874122 139.73846782063634 9.259 35.67263974280555 139.73858440624443 9.259 35.67263974280555 139.73858440624443 23.266 35.672633896542195 139.7385661310808 28.025 35.6726024874122 139.73846782063634 28.025</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-34215e63-d4fe-473d-b696-70470a0ddb1c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-34215e63-d4fe-473d-b696-70470a0ddb1c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-34215e63-d4fe-473d-b696-70470a0ddb1c">
											<gml:posList>35.67264195261687 139.73844888430133 9.259 35.6726024874122 139.73846782063634 9.259 35.6726024874122 139.73846782063634 28.025 35.67264195261687 139.73844888430133 28.025 35.67264195261687 139.73844888430133 9.259</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9561d7ad-f933-4347-9364-572ba475f119">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9561d7ad-f933-4347-9364-572ba475f119">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9561d7ad-f933-4347-9364-572ba475f119">
											<gml:posList>35.67264194875974 139.73852408936037 31.267 35.67263646391464 139.73850692947673 31.267 35.67263646391464 139.73850692947673 28.025 35.67264194875974 139.73852408936037 28.025 35.67264194875974 139.73852408936037 31.267</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-446bb71c-f254-49cf-84af-6964b025ef7d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-446bb71c-f254-49cf-84af-6964b025ef7d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-446bb71c-f254-49cf-84af-6964b025ef7d">
											<gml:posList>35.67263646391464 139.73850692947673 31.267 35.672646591515395 139.73850206805287 31.267 35.672646591515395 139.73850206805287 28.025 35.67263646391464 139.73850692947673 28.025 35.67263646391464 139.73850692947673 31.267</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b4210135-2391-4053-b4e5-68fd4da86ed0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b4210135-2391-4053-b4e5-68fd4da86ed0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b4210135-2391-4053-b4e5-68fd4da86ed0">
											<gml:posList>35.67264477799759 139.73852272728627 31.267 35.67264194875974 139.73852408936037 31.267 35.67264194875974 139.73852408936037 28.025 35.67264477799759 139.73852272728627 28.025 35.67264477799759 139.73852272728627 31.267</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f3e835ae-b459-45ef-9fe5-87da820c2623">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f3e835ae-b459-45ef-9fe5-87da820c2623">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f3e835ae-b459-45ef-9fe5-87da820c2623">
											<gml:posList>35.672646591515395 139.73850206805287 31.267 35.672643971081314 139.73849387459668 31.267 35.672643971081314 139.73849387459668 28.025 35.672646591515395 139.73850206805287 28.025 35.672646591515395 139.73850206805287 31.267</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e7ed7129-cc88-46be-9977-5618c1a1e7a1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e7ed7129-cc88-46be-9977-5618c1a1e7a1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e7ed7129-cc88-46be-9977-5618c1a1e7a1">
											<gml:posList>35.67265016344603 139.73853957798627 31.267 35.67264477799759 139.73852272728627 31.267 35.67264477799759 139.73852272728627 28.025 35.67265016344603 139.73853957798627 28.025 35.67265016344603 139.73853957798627 31.267</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d1e516f9-c17f-489d-8ade-223fab44b6fc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d1e516f9-c17f-489d-8ade-223fab44b6fc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d1e516f9-c17f-489d-8ade-223fab44b6fc">
											<gml:posList>35.672643971081314 139.73849387459668 31.267 35.672654684347016 139.738488725267 31.267 35.672654684347016 139.738488725267 28.025 35.672643971081314 139.73849387459668 28.025 35.672643971081314 139.73849387459668 31.267</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-fe4d680e-de93-445e-9997-a970afe126de">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fe4d680e-de93-445e-9997-a970afe126de">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fe4d680e-de93-445e-9997-a970afe126de">
											<gml:posList>35.67266817507759 139.7385309293147 31.267 35.67265016344603 139.73853957798627 31.267 35.67265016344603 139.73853957798627 28.025 35.67266817507759 139.7385309293147 28.025 35.67266817507759 139.7385309293147 31.267</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-fd6524d5-5adc-4161-a160-2c30f77db298">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fd6524d5-5adc-4161-a160-2c30f77db298">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fd6524d5-5adc-4161-a160-2c30f77db298">
											<gml:posList>35.67263974280555 139.73858440624443 9.259 35.672679208028384 139.7385654699579 9.259 35.672679208028384 139.7385654699579 23.266 35.67263974280555 139.73858440624443 23.266 35.67263974280555 139.73858440624443 9.259</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4f30c29a-1aa9-45b2-96d9-3a285439fd70">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4f30c29a-1aa9-45b2-96d9-3a285439fd70">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4f30c29a-1aa9-45b2-96d9-3a285439fd70">
											<gml:posList>35.672679208028384 139.7385654699579 23.266 35.672679208028384 139.7385654699579 9.259 35.67264195261687 139.73844888430133 9.259 35.67264195261687 139.73844888430133 28.025 35.672654684347016 139.738488725267 28.025 35.672654684347016 139.738488725267 31.267 35.67266817507759 139.7385309293147 31.267 35.67266817507759 139.7385309293147 28.025 35.67267337076721 139.73854718372945 28.025 35.672679208028384 139.7385654699579 23.266</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-8273</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">62.18718</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">211</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1230</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>5</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.01</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>