<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_2db8221c-7b4d-4929-a5c3-8552a87d3ac7">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">412</bldg:usage>
			<bldg:measuredHeight uom="m">16.8</bldg:measuredHeight>
			<bldg:storeysAboveGround>5</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>1</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.671169395983036 139.73985242220166 0 35.671177685690836 139.73984865677068 0 35.67114768359691 139.73975015817638 0 35.67114083557244 139.7397532591516 0 35.67113197945798 139.7397241070902 0 35.6711189141991 139.73973008737966 0 35.6711068951159 139.73969044498116 0 35.671009311038155 139.73973496526781 0 35.671012745009996 139.7397462285324 0 35.670982830099526 139.73975996091588 0 35.670993674287146 139.73979562795037 0 35.6709734907583 139.73980493042419 0 35.671017409671734 139.73994947587545 0 35.67103705264535 139.73994050545303 0 35.67104374010389 139.73996281129178 0 35.67105049799664 139.73995971044323 0 35.67105384138206 139.7399704215111 0 35.671077539075604 139.73995956848717 0 35.67108088280363 139.7399707214125 0 35.67114702021895 139.73994059828385 0 35.67114177889374 139.73992337206093 0 35.67118457667265 139.73990089806685 0 35.671169395983036 139.73985242220166 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671169395983036 139.73985242220166 15.32 35.67118457667265 139.73990089806685 15.32 35.67114177889374 139.73992337206093 15.32 35.67114702021895 139.73994059828385 15.32 35.67108088280363 139.7399707214125 15.32 35.671077539075604 139.73995956848717 15.32 35.67105384138206 139.7399704215111 15.32 35.67105049799664 139.73995971044323 15.32 35.67104374010389 139.73996281129178 15.32 35.67103705264535 139.73994050545303 15.32 35.671017409671734 139.73994947587545 15.32 35.6709734907583 139.73980493042419 15.32 35.670993674287146 139.73979562795037 15.32 35.670982830099526 139.73975996091588 15.32 35.671012745009996 139.7397462285324 15.32 35.671009311038155 139.73973496526781 15.32 35.6711068951159 139.73969044498116 15.32 35.6711189141991 139.73973008737966 15.32 35.67113197945798 139.7397241070902 15.32 35.67114083557244 139.7397532591516 15.32 35.67114768359691 139.73975015817638 15.32 35.671177685690836 139.73984865677068 15.32 35.671169395983036 139.73985242220166 15.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671169395983036 139.73985242220166 15.32 35.671177685690836 139.73984865677068 15.32 35.671177685690836 139.73984865677068 32.07 35.671169395983036 139.73985242220166 32.07 35.671169395983036 139.73985242220166 15.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671177685690836 139.73984865677068 15.32 35.67114768359691 139.73975015817638 15.32 35.67114768359691 139.73975015817638 32.07 35.671177685690836 139.73984865677068 32.07 35.671177685690836 139.73984865677068 15.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67114768359691 139.73975015817638 15.32 35.67114083557244 139.7397532591516 15.32 35.67114083557244 139.7397532591516 32.07 35.67114768359691 139.73975015817638 32.07 35.67114768359691 139.73975015817638 15.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67114083557244 139.7397532591516 15.32 35.67113197945798 139.7397241070902 15.32 35.67113197945798 139.7397241070902 32.07 35.67114083557244 139.7397532591516 32.07 35.67114083557244 139.7397532591516 15.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67113197945798 139.7397241070902 15.32 35.6711189141991 139.73973008737966 15.32 35.6711189141991 139.73973008737966 32.07 35.67113197945798 139.7397241070902 32.07 35.67113197945798 139.7397241070902 15.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6711189141991 139.73973008737966 15.32 35.6711068951159 139.73969044498116 15.32 35.6711068951159 139.73969044498116 32.07 35.6711189141991 139.73973008737966 32.07 35.6711189141991 139.73973008737966 15.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6711068951159 139.73969044498116 15.32 35.671009311038155 139.73973496526781 15.32 35.671009311038155 139.73973496526781 32.07 35.6711068951159 139.73969044498116 32.07 35.6711068951159 139.73969044498116 15.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671009311038155 139.73973496526781 15.32 35.671012745009996 139.7397462285324 15.32 35.671012745009996 139.7397462285324 32.07 35.671009311038155 139.73973496526781 32.07 35.671009311038155 139.73973496526781 15.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671012745009996 139.7397462285324 15.32 35.670982830099526 139.73975996091588 15.32 35.670982830099526 139.73975996091588 32.07 35.671012745009996 139.7397462285324 32.07 35.671012745009996 139.7397462285324 15.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670982830099526 139.73975996091588 15.32 35.670993674287146 139.73979562795037 15.32 35.670993674287146 139.73979562795037 32.07 35.670982830099526 139.73975996091588 32.07 35.670982830099526 139.73975996091588 15.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670993674287146 139.73979562795037 15.32 35.6709734907583 139.73980493042419 15.32 35.6709734907583 139.73980493042419 32.07 35.670993674287146 139.73979562795037 32.07 35.670993674287146 139.73979562795037 15.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6709734907583 139.73980493042419 15.32 35.671017409671734 139.73994947587545 15.32 35.671017409671734 139.73994947587545 32.07 35.6709734907583 139.73980493042419 32.07 35.6709734907583 139.73980493042419 15.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671017409671734 139.73994947587545 15.32 35.67103705264535 139.73994050545303 15.32 35.67103705264535 139.73994050545303 32.07 35.671017409671734 139.73994947587545 32.07 35.671017409671734 139.73994947587545 15.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67103705264535 139.73994050545303 15.32 35.67104374010389 139.73996281129178 15.32 35.67104374010389 139.73996281129178 32.07 35.67103705264535 139.73994050545303 32.07 35.67103705264535 139.73994050545303 15.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67104374010389 139.73996281129178 15.32 35.67105049799664 139.73995971044323 15.32 35.67105049799664 139.73995971044323 32.07 35.67104374010389 139.73996281129178 32.07 35.67104374010389 139.73996281129178 15.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67105049799664 139.73995971044323 15.32 35.67105384138206 139.7399704215111 15.32 35.67105384138206 139.7399704215111 32.07 35.67105049799664 139.73995971044323 32.07 35.67105049799664 139.73995971044323 15.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67105384138206 139.7399704215111 15.32 35.671077539075604 139.73995956848717 15.32 35.671077539075604 139.73995956848717 32.07 35.67105384138206 139.7399704215111 32.07 35.67105384138206 139.7399704215111 15.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671077539075604 139.73995956848717 15.32 35.67108088280363 139.7399707214125 15.32 35.67108088280363 139.7399707214125 32.07 35.671077539075604 139.73995956848717 32.07 35.671077539075604 139.73995956848717 15.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67108088280363 139.7399707214125 15.32 35.67114702021895 139.73994059828385 15.32 35.67114702021895 139.73994059828385 32.07 35.67108088280363 139.7399707214125 32.07 35.67108088280363 139.7399707214125 15.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67114702021895 139.73994059828385 15.32 35.67114177889374 139.73992337206093 15.32 35.67114177889374 139.73992337206093 32.07 35.67114702021895 139.73994059828385 32.07 35.67114702021895 139.73994059828385 15.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67114177889374 139.73992337206093 15.32 35.67118457667265 139.73990089806685 15.32 35.67118457667265 139.73990089806685 32.07 35.67114177889374 139.73992337206093 32.07 35.67114177889374 139.73992337206093 15.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67118457667265 139.73990089806685 15.32 35.671169395983036 139.73985242220166 15.32 35.671169395983036 139.73985242220166 32.07 35.67118457667265 139.73990089806685 32.07 35.67118457667265 139.73990089806685 15.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671169395983036 139.73985242220166 32.07 35.671177685690836 139.73984865677068 32.07 35.67114768359691 139.73975015817638 32.07 35.67114083557244 139.7397532591516 32.07 35.67113197945798 139.7397241070902 32.07 35.6711189141991 139.73973008737966 32.07 35.6711068951159 139.73969044498116 32.07 35.671009311038155 139.73973496526781 32.07 35.671012745009996 139.7397462285324 32.07 35.670982830099526 139.73975996091588 32.07 35.670993674287146 139.73979562795037 32.07 35.6709734907583 139.73980493042419 32.07 35.671017409671734 139.73994947587545 32.07 35.67103705264535 139.73994050545303 32.07 35.67104374010389 139.73996281129178 32.07 35.67105049799664 139.73995971044323 32.07 35.67105384138206 139.7399704215111 32.07 35.671077539075604 139.73995956848717 32.07 35.67108088280363 139.7399707214125 32.07 35.67114702021895 139.73994059828385 32.07 35.67114177889374 139.73992337206093 32.07 35.67118457667265 139.73990089806685 32.07 35.671169395983036 139.73985242220166 32.07</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-7b2e0aa4-4b7e-405a-9184-c4464f4bf5f5"/>
							<gml:surfaceMember xlink:href="#poly-0fe99ccb-9da8-42a7-bfb3-1f0158b55aa8"/>
							<gml:surfaceMember xlink:href="#poly-4e8aa60e-fad2-4c43-8cec-7ea62c53bf88"/>
							<gml:surfaceMember xlink:href="#poly-7e6f98c5-6d14-48ad-bac3-7a47a2f917e7"/>
							<gml:surfaceMember xlink:href="#poly-3a01ab4b-03ac-4fa9-ad15-a6bc5ef2ff54"/>
							<gml:surfaceMember xlink:href="#poly-1fc85cf4-86da-4472-b201-b18fc0125a02"/>
							<gml:surfaceMember xlink:href="#poly-35d14551-d1f7-4e66-ad24-5c8aa5be82d2"/>
							<gml:surfaceMember xlink:href="#poly-26543fd6-d147-4e17-a2a6-cb62097de9de"/>
							<gml:surfaceMember xlink:href="#poly-786cd443-6da9-4cef-8913-af15a6430e9e"/>
							<gml:surfaceMember xlink:href="#poly-6d31a33f-4c21-4d3e-8c5f-8e1259f95684"/>
							<gml:surfaceMember xlink:href="#poly-cecd7269-6cd6-42b0-bdb1-21be49d5a4af"/>
							<gml:surfaceMember xlink:href="#poly-9c497f47-9586-4ae7-a8dd-144420c8ca8d"/>
							<gml:surfaceMember xlink:href="#poly-e378b4a5-ba28-413f-93a1-3f74569c2162"/>
							<gml:surfaceMember xlink:href="#poly-11b262dd-ad59-4dd6-8e7f-5dec0971feb4"/>
							<gml:surfaceMember xlink:href="#poly-bcf5df9d-1c1a-46e8-a674-b0d117e2ba7c"/>
							<gml:surfaceMember xlink:href="#poly-4a50bdc7-7ac0-49d9-89d5-10326ad20cf8"/>
							<gml:surfaceMember xlink:href="#poly-25b29ca3-edd1-40f2-b85c-268ddee845c0"/>
							<gml:surfaceMember xlink:href="#poly-4f3c9512-2cfc-443e-9660-1acb69add77c"/>
							<gml:surfaceMember xlink:href="#poly-bbf10f50-ae72-4f3b-ae94-69d400d1af51"/>
							<gml:surfaceMember xlink:href="#poly-58bb2616-ef6f-4b96-83d6-6bc0316a435d"/>
							<gml:surfaceMember xlink:href="#poly-e0ee7d2a-5a50-4a67-bd53-0e50473da499"/>
							<gml:surfaceMember xlink:href="#poly-b5d4a41f-0213-4f68-879e-18ca00fdaf36"/>
							<gml:surfaceMember xlink:href="#poly-860a1555-4844-4552-bf5c-6bdcdce9fdb6"/>
							<gml:surfaceMember xlink:href="#poly-b6ccfbf0-b9b9-4322-b62c-bf42fb41aaf3"/>
							<gml:surfaceMember xlink:href="#poly-7879ce85-db69-4500-8285-a6d44f445d5e"/>
							<gml:surfaceMember xlink:href="#poly-6490b8c7-e89a-4e10-b295-99e7d903d5a1"/>
							<gml:surfaceMember xlink:href="#poly-ea45eb77-38a9-4233-8a17-cfe4b6582120"/>
							<gml:surfaceMember xlink:href="#poly-6d6d5d25-c642-4914-82da-9514c206ffd5"/>
							<gml:surfaceMember xlink:href="#poly-a66edd34-0602-4c2d-a5ae-1b28b1e72046"/>
							<gml:surfaceMember xlink:href="#poly-9e0613a6-16e2-418f-af3a-2b405f6c6514"/>
							<gml:surfaceMember xlink:href="#poly-20886890-75c4-4f97-bd98-b54856bb9096"/>
							<gml:surfaceMember xlink:href="#poly-faea5c42-4af6-41bf-b54a-32ca3cf30112"/>
							<gml:surfaceMember xlink:href="#poly-ec465b9b-5e98-4697-9598-dece70ff5240"/>
							<gml:surfaceMember xlink:href="#poly-a7bedefd-48a3-4cc3-af7f-b8f82b8f7a8a"/>
							<gml:surfaceMember xlink:href="#poly-e95443c8-33ce-4a6a-8a51-7ab6fb35eedb"/>
							<gml:surfaceMember xlink:href="#poly-84821839-8fdf-49f6-a265-1e5796464c98"/>
							<gml:surfaceMember xlink:href="#poly-d1b649de-6a5f-49b4-846f-22ff632b184e"/>
							<gml:surfaceMember xlink:href="#poly-17b902a1-087f-4fef-9a0d-21a61e0577cd"/>
							<gml:surfaceMember xlink:href="#poly-95e6a1d8-cffa-453f-aeac-c17c6e054373"/>
							<gml:surfaceMember xlink:href="#poly-d7cd191f-bbab-4b6d-928c-403360b27779"/>
							<gml:surfaceMember xlink:href="#poly-5acb7559-4d01-4280-b61b-cfc20924beab"/>
							<gml:surfaceMember xlink:href="#poly-10afdafa-bfbf-4a26-abfc-5ea8afee5d08"/>
							<gml:surfaceMember xlink:href="#poly-ed34589f-3f3a-4901-9f71-0d7a5ebded25"/>
							<gml:surfaceMember xlink:href="#poly-1024f12d-7ceb-4f38-b87f-756cbd4f858b"/>
							<gml:surfaceMember xlink:href="#poly-799fe9b5-1e53-4010-97ff-13f4b56d9ba8"/>
							<gml:surfaceMember xlink:href="#poly-4cd024ad-d0ea-4c94-82a2-e91cf930410f"/>
							<gml:surfaceMember xlink:href="#poly-33a2113d-04d6-4e92-b899-c453c5131f0e"/>
							<gml:surfaceMember xlink:href="#poly-516e0a06-94ca-46e6-996e-1bae5d33700f"/>
							<gml:surfaceMember xlink:href="#poly-c18561ae-3d70-4c96-b456-2d5b32d2a1eb"/>
							<gml:surfaceMember xlink:href="#poly-2dadecde-380c-4446-aa3e-b07718ec2b80"/>
							<gml:surfaceMember xlink:href="#poly-bb109642-9f21-418f-9f28-82fc056da1ed"/>
							<gml:surfaceMember xlink:href="#poly-b11014f0-4854-4241-99db-6aea4dd45d04"/>
							<gml:surfaceMember xlink:href="#poly-05e4aa72-dfbf-4c7c-9325-7c97eca492af"/>
							<gml:surfaceMember xlink:href="#poly-4ebeb4a6-0928-4bd3-9ffa-24ad18b9acb5"/>
							<gml:surfaceMember xlink:href="#poly-edb84b56-e8b7-41c7-a08f-25aa3084cdd8"/>
							<gml:surfaceMember xlink:href="#poly-4d2b9ebe-f0b8-4202-afca-fc7ee7c9a1ca"/>
							<gml:surfaceMember xlink:href="#poly-fc1fb86e-5277-497f-8fc1-c379bcdb71c4"/>
							<gml:surfaceMember xlink:href="#poly-2b2c840b-cea7-430c-90b4-59fc867f2a7a"/>
							<gml:surfaceMember xlink:href="#poly-5396b8ae-f424-4447-8ed7-a5b6c2135965"/>
							<gml:surfaceMember xlink:href="#poly-661ef4ac-566b-4e04-9f16-b1c3ff19ba2b"/>
							<gml:surfaceMember xlink:href="#poly-9e43f652-caf7-478c-85d3-80d4b4267bc1"/>
							<gml:surfaceMember xlink:href="#poly-b82eddc9-f127-43bb-bb1c-16a60ae0563e"/>
							<gml:surfaceMember xlink:href="#poly-3391937b-9332-4254-8338-46b977ce06a2"/>
							<gml:surfaceMember xlink:href="#poly-5b857004-daca-47bf-9e1b-b5fb276ccd98"/>
							<gml:surfaceMember xlink:href="#poly-cdd7f6de-9ebb-43c6-9590-c1a23193c77b"/>
							<gml:surfaceMember xlink:href="#poly-025b1264-b9cd-4db9-aaa6-90446a52220a"/>
							<gml:surfaceMember xlink:href="#poly-9793c6e3-162a-4dff-8174-3efaf439605c"/>
							<gml:surfaceMember xlink:href="#poly-c481978d-13d8-4cba-9211-b62c06b45bee"/>
							<gml:surfaceMember xlink:href="#poly-807b5ece-9146-4d7a-9b8a-93b3b8cd2366"/>
							<gml:surfaceMember xlink:href="#poly-0920db1a-7939-4e9d-8e23-c9a23c47cce5"/>
							<gml:surfaceMember xlink:href="#poly-4987c40d-130e-4827-b151-d9ea45e206a1"/>
							<gml:surfaceMember xlink:href="#poly-76c44c04-7fe1-4fa3-af55-35199b8ad4d7"/>
							<gml:surfaceMember xlink:href="#poly-4e873a81-5b47-43c1-b70f-0a96273c869d"/>
							<gml:surfaceMember xlink:href="#poly-ce85c559-8044-4df0-ba31-d8d617257d54"/>
							<gml:surfaceMember xlink:href="#poly-4eb5c612-f2bc-4d50-921d-38eac86ac5e6"/>
							<gml:surfaceMember xlink:href="#poly-8a387df7-c969-4e1d-9380-0b90bc68ab6d"/>
							<gml:surfaceMember xlink:href="#poly-774214bc-aebf-4742-9bfe-2eaba08b3e82"/>
							<gml:surfaceMember xlink:href="#poly-12f71afe-0363-4357-b978-82eb1695a419"/>
							<gml:surfaceMember xlink:href="#poly-3e2bfd0d-a517-4b63-9e46-6dda2db13613"/>
							<gml:surfaceMember xlink:href="#poly-18d419f5-6ead-4e63-ae9f-da44e98dad92"/>
							<gml:surfaceMember xlink:href="#poly-9fdebbd1-3d0f-457b-baf0-be182e1b377b"/>
							<gml:surfaceMember xlink:href="#poly-2ffb74b8-5ecd-463e-addf-320c38d7e3c4"/>
							<gml:surfaceMember xlink:href="#poly-be2112b6-464e-4481-9e52-cc7ba7533d86"/>
							<gml:surfaceMember xlink:href="#poly-ecd8be1d-6a3f-4e60-b0aa-8daa16219665"/>
							<gml:surfaceMember xlink:href="#poly-b0a2df09-08b0-4474-9b50-fdd87c1b8722"/>
							<gml:surfaceMember xlink:href="#poly-46a40716-5734-4c21-bb49-b8318e64e5c9"/>
							<gml:surfaceMember xlink:href="#poly-49ab232b-cec5-4ab3-a436-a95fd13a43e1"/>
							<gml:surfaceMember xlink:href="#poly-cc22f1e1-b718-43f4-9680-33a391b1b4e7"/>
							<gml:surfaceMember xlink:href="#poly-bb792eec-9334-49da-a03b-c5ab7d84be30"/>
							<gml:surfaceMember xlink:href="#poly-02bc9360-f284-4b15-a4c6-088477ef5d45"/>
							<gml:surfaceMember xlink:href="#poly-390d99e1-0c6d-4863-86fd-6e49536f92eb"/>
							<gml:surfaceMember xlink:href="#poly-4b7a1e99-5a6d-4364-80e3-c839c624d01a"/>
							<gml:surfaceMember xlink:href="#poly-e6ba5286-b6eb-45da-8ad7-f29f81f0735c"/>
							<gml:surfaceMember xlink:href="#poly-c46599b5-6078-4c4e-9a32-35f95e7deaa0"/>
							<gml:surfaceMember xlink:href="#poly-1bb0866b-a3ef-4bbe-a949-d82039c7714b"/>
							<gml:surfaceMember xlink:href="#poly-e4a1a732-59b5-4b6e-9ff4-dda34189a0ed"/>
							<gml:surfaceMember xlink:href="#poly-dab3b590-7fd5-4a6a-b6d9-cd9c662c8b89"/>
							<gml:surfaceMember xlink:href="#poly-a39f10db-ee0f-41ce-9fcc-fd06af5cc225"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_2db8221c-7b4d-4929-a5c3-8552a87d3ac7_BuildingInstallation_1041">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3297fcfc-0e44-4710-b6f6-d0185383f17e">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671059865592206 139.7398117225884 31.967 35.671098871114154 139.73979252270448 31.967 35.6711095687392 139.739825185356 31.967 35.67111616440086 139.73984532622558 31.967 35.671078915868854 139.7398636513776 31.967 35.67107440731124 139.7398498597363 31.967 35.67107940802278 139.73984740161455 31.967 35.67107732993535 139.7398410523833 31.967 35.671070563212076 139.73984438522663 31.967 35.671059865592206 139.7398117225884 31.967</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a7a44781-a19c-4144-a6ea-de9b8329de89">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a7a44781-a19c-4144-a6ea-de9b8329de89_0">
											<gml:posList>35.671098871114154 139.73979252270448 40.824 35.67106678548779 139.73980831223957 40.824 35.67106756249532 139.7398106642066 40.824 35.67109771091842 139.73979583796554 40.824 35.671098871114154 139.73979252270448 40.824</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e2d7442a-9482-4f5e-9fe4-71d906cc8228">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e2d7442a-9482-4f5e-9fe4-71d906cc8228_0">
											<gml:posList>35.671098871114154 139.73979252270448 31.967 35.671059865592206 139.7398117225884 31.967 35.671059865592206 139.7398117225884 40.824 35.67106678548779 139.73980831223957 40.824 35.671098871114154 139.73979252270448 40.824 35.671098871114154 139.73979252270448 31.967</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-69ca2b9a-43f2-44a5-8a38-915cc7157e8a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-69ca2b9a-43f2-44a5-8a38-915cc7157e8a_0">
											<gml:posList>35.67109771091842 139.73979583796554 40.824 35.67106756249532 139.7398106642066 40.824 35.67106756249532 139.7398106642066 39.978 35.67109771091842 139.73979583796554 39.978 35.67109771091842 139.73979583796554 40.824</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9eccff05-3d26-48d2-a941-eb8798a3e9df">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9eccff05-3d26-48d2-a941-eb8798a3e9df_0">
											<gml:posList>35.6711095687392 139.739825185356 40.824 35.671098871114154 139.73979252270448 40.824 35.67109771091842 139.73979583796554 40.824 35.67110687253846 139.73982377456656 40.824 35.6711095687392 139.739825185356 40.824</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ad7c6092-d14d-4efc-8510-6ebb1833d260">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ad7c6092-d14d-4efc-8510-6ebb1833d260_0">
											<gml:posList>35.671098871114154 139.73979252270448 31.967 35.671098871114154 139.73979252270448 40.824 35.6711095687392 139.739825185356 40.824 35.6711095687392 139.739825185356 35.497 35.6711095687392 139.739825185356 31.967 35.671098871114154 139.73979252270448 31.967</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-21b33722-e187-474f-9de9-ee7d6cdeda7c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-21b33722-e187-474f-9de9-ee7d6cdeda7c_0">
											<gml:posList>35.67110687253846 139.73982377456656 40.824 35.67109771091842 139.73979583796554 40.824 35.67109771091842 139.73979583796554 39.978 35.67110687253846 139.73982377456656 39.978 35.67110687253846 139.73982377456656 40.824</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d998b510-aa1b-44ec-8759-b4e21599c2bb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d998b510-aa1b-44ec-8759-b4e21599c2bb_0">
											<gml:posList>35.67106678548779 139.73980831223957 40.824 35.671059865592206 139.7398117225884 40.824 35.67106255277936 139.73981313338712 40.824 35.67106756249532 139.7398106642066 40.824 35.67106678548779 139.73980831223957 40.824</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-33504abd-d8bd-4f83-b8f6-d38e3f523ab2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-33504abd-d8bd-4f83-b8f6-d38e3f523ab2_0">
											<gml:posList>35.67106756249532 139.7398106642066 40.824 35.67106255277936 139.73981313338712 40.824 35.67106255277936 139.73981313338712 39.978 35.67106756249532 139.7398106642066 39.978 35.67106756249532 139.7398106642066 40.824</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-392a517c-55ac-4e57-badf-2125a173b1fc">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-392a517c-55ac-4e57-badf-2125a173b1fc_0">
											<gml:posList>35.671071714395445 139.7398410699779 39.978 35.67110687253846 139.73982377456656 39.978 35.67109771091842 139.73979583796554 39.978 35.67106756249532 139.7398106642066 39.978 35.67106255277936 139.73981313338712 39.978 35.671071714395445 139.7398410699779 39.978</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-06709848-d7b4-4ce6-b748-c675ad991aea">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-06709848-d7b4-4ce6-b748-c675ad991aea_0">
											<gml:posList>35.67106255277936 139.73981313338712 40.824 35.671071714395445 139.7398410699779 40.824 35.671071714395445 139.7398410699779 39.978 35.67106255277936 139.73981313338712 39.978 35.67106255277936 139.73981313338712 40.824</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4d9d74bf-6d59-4e37-8487-57af49311804">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4d9d74bf-6d59-4e37-8487-57af49311804_0">
											<gml:posList>35.671059865592206 139.7398117225884 40.824 35.671070563212076 139.73984438522663 40.824 35.671071714395445 139.7398410699779 40.824 35.67106255277936 139.73981313338712 40.824 35.671059865592206 139.7398117225884 40.824</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7b9714ef-50e4-440b-8b67-ac68f7dafd5b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7b9714ef-50e4-440b-8b67-ac68f7dafd5b_0">
											<gml:posList>35.671059865592206 139.7398117225884 31.967 35.671070563212076 139.73984438522663 31.967 35.671070563212076 139.73984438522663 40.824 35.671059865592206 139.7398117225884 40.824 35.671059865592206 139.7398117225884 31.967</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-09280c95-f513-4477-93c9-de6f3775521c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-09280c95-f513-4477-93c9-de6f3775521c_0">
											<gml:posList>35.671071714395445 139.7398410699779 40.824 35.67110687253846 139.73982377456656 40.824 35.67110687253846 139.73982377456656 39.978 35.671071714395445 139.7398410699779 39.978 35.671071714395445 139.7398410699779 40.824</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-78e0fb6d-3bdf-4bbc-a210-8634226c9ae9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-78e0fb6d-3bdf-4bbc-a210-8634226c9ae9_0">
											<gml:posList>35.671070563212076 139.73984438522663 40.824 35.6711095687392 139.739825185356 40.824 35.67110687253846 139.73982377456656 40.824 35.671071714395445 139.7398410699779 40.824 35.671070563212076 139.73984438522663 40.824</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e41cdb59-7656-492a-a743-94c638314dce">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e41cdb59-7656-492a-a743-94c638314dce_0">
											<gml:posList>35.67107732993535 139.7398410523833 35.497 35.6711095687392 139.739825185356 35.497 35.6711095687392 139.739825185356 40.824 35.671070563212076 139.73984438522663 40.824 35.671070563212076 139.73984438522663 31.967 35.67107732993535 139.7398410523833 31.967 35.67107732993535 139.7398410523833 35.497</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cd7616ef-002f-4558-9dd8-f1846a3e543f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cd7616ef-002f-4558-9dd8-f1846a3e543f_0">
											<gml:posList>35.6711095687392 139.739825185356 31.967 35.6711095687392 139.739825185356 35.497 35.67111616440086 139.73984532622558 35.497 35.67111616440086 139.73984532622558 31.967 35.6711095687392 139.739825185356 31.967</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0f58c0b0-c45a-49fc-9d04-8bf60bf24a58">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0f58c0b0-c45a-49fc-9d04-8bf60bf24a58_0">
											<gml:posList>35.67107732993535 139.7398410523833 31.967 35.67107940802278 139.73984740161455 31.967 35.67107940802278 139.73984740161455 35.497 35.67107732993535 139.7398410523833 35.497 35.67107732993535 139.7398410523833 31.967</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9e3459ef-73c9-4c04-8c33-1eebc5f9b5b3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9e3459ef-73c9-4c04-8c33-1eebc5f9b5b3_0">
											<gml:posList>35.671078915868854 139.7398636513776 35.497 35.67111616440086 139.73984532622558 35.497 35.6711095687392 139.739825185356 35.497 35.67107732993535 139.7398410523833 35.497 35.67107940802278 139.73984740161455 35.497 35.67107440731124 139.7398498597363 35.497 35.671078915868854 139.7398636513776 35.497</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f45e7592-8e21-4c03-b249-71d2e329ea7d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f45e7592-8e21-4c03-b249-71d2e329ea7d_0">
											<gml:posList>35.67107940802278 139.73984740161455 31.967 35.67107440731124 139.7398498597363 31.967 35.67107440731124 139.7398498597363 35.497 35.67107940802278 139.73984740161455 35.497 35.67107940802278 139.73984740161455 31.967</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fcbdc01f-2cc0-4d25-a0f2-2f8a56c6a084">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fcbdc01f-2cc0-4d25-a0f2-2f8a56c6a084_0">
											<gml:posList>35.671078915868854 139.7398636513776 31.967 35.67111616440086 139.73984532622558 31.967 35.67111616440086 139.73984532622558 35.497 35.671078915868854 139.7398636513776 35.497 35.671078915868854 139.7398636513776 31.967</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a31cda5a-f0c1-4fa9-aadb-1c9e14064928">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a31cda5a-f0c1-4fa9-aadb-1c9e14064928_0">
											<gml:posList>35.67107440731124 139.7398498597363 31.967 35.671078915868854 139.7398636513776 31.967 35.671078915868854 139.7398636513776 35.497 35.67107440731124 139.7398498597363 35.497 35.67107440731124 139.7398498597363 31.967</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_2db8221c-7b4d-4929-a5c3-8552a87d3ac7_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f4e29421-0067-44cb-a2da-bfe3f68e038e">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67104416418297 139.7398471996897 31.967 35.671056995185474 139.73984134120798 31.967 35.671062055793534 139.7398579821613 31.967 35.67104921576792 139.73986382960496 31.967 35.67104416418297 139.7398471996897 31.967</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4581eddd-ea2b-4b71-b4ac-d6d94fa33aa0">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67106182424693 139.73979195837765 31.967 35.67106678548779 139.73980831223957 31.967 35.67105986558362 139.73981171154205 31.967 35.6710705632035 139.73984437418028 31.967 35.67107564317625 139.73986273834547 31.967 35.671065875757684 139.73986720141318 31.967 35.67104530793042 139.73979948916605 31.967 35.671035114388644 139.7397659532942 31.967 35.671032807691375 139.73976700538938 31.967 35.67102852421675 139.73975289315464 31.967 35.67103984145035 139.73974773234602 31.967 35.671044124925565 139.73976184458246 31.967 35.671096602278396 139.73973790111086 31.967 35.67110678681419 139.73977143701532 31.967 35.67106182424693 139.73979195837765 31.967</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8bfb813a-53be-4a36-8d37-14e3bf198827">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67108271052004 139.7398054437031 39.978 35.671090119332874 139.73982804695356 39.978 35.67107600021808 139.7398350005312 39.978 35.67106860042026 139.7398123972735 39.978 35.67108271052004 139.7398054437031 39.978</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-98d9577d-48fd-4182-838a-3a1a455411ed">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671081922719814 139.7399285341677 31.967 35.671093402747715 139.73992406911128 31.967 35.67109713660515 139.73993849130488 31.967 35.671085647563004 139.73994295636996 31.967 35.671081922719814 139.7399285341677 31.967</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-73013f87-62b1-478d-8db2-90d713bf617d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-73013f87-62b1-478d-8db2-90d713bf617d_0">
											<gml:posList>35.67102852421675 139.73975289315464 31.967 35.67102852421675 139.73975289315464 33.645 35.67103984145035 139.73974773234602 33.645 35.67103984145035 139.73974773234602 31.967 35.67102852421675 139.73975289315464 31.967</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a0030e9b-a5eb-4b45-b12d-f7db97376dc8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a0030e9b-a5eb-4b45-b12d-f7db97376dc8_0">
											<gml:posList>35.671035114388644 139.7397659532942 33.645 35.671035114388644 139.7397659532942 34.024 35.671096602278396 139.73973790111086 34.024 35.671096602278396 139.73973790111086 31.967 35.671044124925565 139.73976184458246 31.967 35.671044124925565 139.73976184458246 33.645 35.671035114388644 139.7397659532942 33.645</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5e2e8e6e-e74f-4de6-ab2f-11662a2402c0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5e2e8e6e-e74f-4de6-ab2f-11662a2402c0_0">
											<gml:posList>35.671096602278396 139.73973790111086 34.024 35.67110678681419 139.73977143701532 34.024 35.67110678681419 139.73977143701532 31.967 35.671096602278396 139.73973790111086 31.967 35.671096602278396 139.73973790111086 34.024</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e8954011-3bc9-47fb-907f-88469e9f5717">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e8954011-3bc9-47fb-907f-88469e9f5717_0">
											<gml:posList>35.671044124925565 139.73976184458246 31.967 35.67103984145035 139.73974773234602 31.967 35.67103984145035 139.73974773234602 33.645 35.671044124925565 139.73976184458246 33.645 35.671044124925565 139.73976184458246 31.967</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-eb7cc69a-f9b8-4714-bf30-0bca595577eb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-eb7cc69a-f9b8-4714-bf30-0bca595577eb_0">
											<gml:posList>35.67103984145035 139.73974773234602 33.645 35.67102852421675 139.73975289315464 33.645 35.671032807691375 139.73976700538938 33.645 35.671035114388644 139.7397659532942 33.645 35.671044124925565 139.73976184458246 33.645 35.67103984145035 139.73974773234602 33.645</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4c4c63b0-9eab-494d-b858-daab1dd41ed9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4c4c63b0-9eab-494d-b858-daab1dd41ed9_0">
											<gml:posList>35.67102852421675 139.73975289315464 31.967 35.671032807691375 139.73976700538938 31.967 35.671032807691375 139.73976700538938 33.645 35.67102852421675 139.73975289315464 33.645 35.67102852421675 139.73975289315464 31.967</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0542bb81-9eb4-4634-a0b3-5cd12fc46aea">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0542bb81-9eb4-4634-a0b3-5cd12fc46aea_0">
											<gml:posList>35.671035114388644 139.7397659532942 33.645 35.671032807691375 139.73976700538938 33.645 35.671032807691375 139.73976700538938 31.967 35.671035114388644 139.7397659532942 31.967 35.671035114388644 139.7397659532942 33.645</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ffd57973-6320-497a-958a-ac9b9f8da08d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ffd57973-6320-497a-958a-ac9b9f8da08d_0">
											<gml:posList>35.67104530793042 139.73979948916605 34.024 35.67110678681419 139.73977143701532 34.024 35.671096602278396 139.73973790111086 34.024 35.671035114388644 139.7397659532942 34.024 35.67104530793042 139.73979948916605 34.024</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-745cd589-abee-4c30-9e74-4ed0970b1651">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-745cd589-abee-4c30-9e74-4ed0970b1651_0">
											<gml:posList>35.671035114388644 139.7397659532942 33.645 35.671035114388644 139.7397659532942 31.967 35.67104530793042 139.73979948916605 31.967 35.67104530793042 139.73979948916605 33.158 35.67104530793042 139.73979948916605 34.024 35.671035114388644 139.7397659532942 34.024 35.671035114388644 139.7397659532942 33.645</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0ae208d9-4eb7-4781-aa27-322e6541e053">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0ae208d9-4eb7-4781-aa27-322e6541e053_0">
											<gml:posList>35.67106182424693 139.73979195837765 33.158 35.67106182424693 139.73979195837765 31.967 35.67110678681419 139.73977143701532 31.967 35.67110678681419 139.73977143701532 34.024 35.67104530793042 139.73979948916605 34.024 35.67104530793042 139.73979948916605 33.158 35.67106182424693 139.73979195837765 33.158</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-886f7012-f1f3-4e4a-920c-7212386ec8c8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-886f7012-f1f3-4e4a-920c-7212386ec8c8_0">
											<gml:posList>35.67106678548779 139.73980831223957 31.967 35.67106182424693 139.73979195837765 31.967 35.67106182424693 139.73979195837765 33.158 35.67106678548779 139.73980831223957 33.158 35.67106678548779 139.73980831223957 31.967</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ebab84df-b341-4a81-80ff-8777efffe864">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ebab84df-b341-4a81-80ff-8777efffe864_0">
											<gml:posList>35.67106860042026 139.7398123972735 39.978 35.67106860042026 139.7398123972735 40.824 35.67108271052004 139.7398054437031 40.824 35.67108271052004 139.7398054437031 39.978 35.67106860042026 139.7398123972735 39.978</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d932364c-dfe5-4df4-8991-8dce59a72558">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d932364c-dfe5-4df4-8991-8dce59a72558_0">
											<gml:posList>35.67105986558362 139.73981171154205 33.158 35.67105986558362 139.73981171154205 31.967 35.67106678548779 139.73980831223957 31.967 35.67106678548779 139.73980831223957 33.158 35.67105986558362 139.73981171154205 33.158</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3e4a72ca-ea75-43e1-9bc0-1e6fad36aaba">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3e4a72ca-ea75-43e1-9bc0-1e6fad36aaba_0">
											<gml:posList>35.671090119332874 139.73982804695356 39.978 35.67108271052004 139.7398054437031 39.978 35.67108271052004 139.7398054437031 40.824 35.671090119332874 139.73982804695356 40.824 35.671090119332874 139.73982804695356 39.978</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3c3ed391-c815-466a-9319-c120ec363c1b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3c3ed391-c815-466a-9319-c120ec363c1b_0">
											<gml:posList>35.67107600021808 139.7398350005312 40.824 35.671090119332874 139.73982804695356 40.824 35.67108271052004 139.7398054437031 40.824 35.67106860042026 139.7398123972735 40.824 35.67107600021808 139.7398350005312 40.824</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f174ee15-fdb6-47a6-8f64-1f1c2bc92215">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f174ee15-fdb6-47a6-8f64-1f1c2bc92215_0">
											<gml:posList>35.67106860042026 139.7398123972735 39.978 35.67107600021808 139.7398350005312 39.978 35.67107600021808 139.7398350005312 40.824 35.67106860042026 139.7398123972735 40.824 35.67106860042026 139.7398123972735 39.978</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5e6fbf7f-1146-44a3-927d-7ec3966f237d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5e6fbf7f-1146-44a3-927d-7ec3966f237d_0">
											<gml:posList>35.67105986558362 139.73981171154205 31.967 35.67105986558362 139.73981171154205 33.158 35.6710705632035 139.73984437418028 33.158 35.6710705632035 139.73984437418028 31.967 35.67105986558362 139.73981171154205 31.967</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3ef57669-4bfe-4586-b44c-8b98ce447c6b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3ef57669-4bfe-4586-b44c-8b98ce447c6b_0">
											<gml:posList>35.67104530793042 139.73979948916605 33.158 35.671065875757684 139.73986720141318 33.158 35.67107564317625 139.73986273834547 33.158 35.6710705632035 139.73984437418028 33.158 35.67105986558362 139.73981171154205 33.158 35.67106678548779 139.73980831223957 33.158 35.67106182424693 139.73979195837765 33.158 35.67104530793042 139.73979948916605 33.158</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ba9719aa-6937-465a-880b-9b1bd84cbd28">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ba9719aa-6937-465a-880b-9b1bd84cbd28_0">
											<gml:posList>35.67107600021808 139.7398350005312 39.978 35.671090119332874 139.73982804695356 39.978 35.671090119332874 139.73982804695356 40.824 35.67107600021808 139.7398350005312 40.824 35.67107600021808 139.7398350005312 39.978</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-80aa06b5-eb87-4075-9a83-4cb288aa01df">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-80aa06b5-eb87-4075-9a83-4cb288aa01df_0">
											<gml:posList>35.67104530793042 139.73979948916605 31.967 35.671065875757684 139.73986720141318 31.967 35.671065875757684 139.73986720141318 33.158 35.67104530793042 139.73979948916605 33.158 35.67104530793042 139.73979948916605 31.967</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-88c6ea49-d4ea-428c-b124-ec4fc5b04b86">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-88c6ea49-d4ea-428c-b124-ec4fc5b04b86_0">
											<gml:posList>35.67104416418297 139.7398471996897 33.39 35.671056995185474 139.73984134120798 33.39 35.671056995185474 139.73984134120798 31.967 35.67104416418297 139.7398471996897 31.967 35.67104416418297 139.7398471996897 33.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-de37c643-0928-4996-9bf3-f554538b1ee5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-de37c643-0928-4996-9bf3-f554538b1ee5_0">
											<gml:posList>35.671062055793534 139.7398579821613 31.967 35.671056995185474 139.73984134120798 31.967 35.671056995185474 139.73984134120798 33.39 35.671062055793534 139.7398579821613 33.39 35.671062055793534 139.7398579821613 31.967</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f6648edf-85ab-4c94-adc8-9f2370290096">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f6648edf-85ab-4c94-adc8-9f2370290096_0">
											<gml:posList>35.67104416418297 139.7398471996897 33.39 35.67104921576792 139.73986382960496 33.39 35.671062055793534 139.7398579821613 33.39 35.671056995185474 139.73984134120798 33.39 35.67104416418297 139.7398471996897 33.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-af6c7211-e6b2-4f87-a9a2-4c5dabe2daab">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-af6c7211-e6b2-4f87-a9a2-4c5dabe2daab_0">
											<gml:posList>35.67107564317625 139.73986273834547 31.967 35.6710705632035 139.73984437418028 31.967 35.6710705632035 139.73984437418028 33.158 35.67107564317625 139.73986273834547 33.158 35.67107564317625 139.73986273834547 31.967</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-07327e98-0471-4094-a6f2-a6b630a99964">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-07327e98-0471-4094-a6f2-a6b630a99964_0">
											<gml:posList>35.67104416418297 139.7398471996897 31.967 35.67104921576792 139.73986382960496 31.967 35.67104921576792 139.73986382960496 33.39 35.67104416418297 139.7398471996897 33.39 35.67104416418297 139.7398471996897 31.967</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-36684eca-e4e2-4678-a637-438665dd7218">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-36684eca-e4e2-4678-a637-438665dd7218_0">
											<gml:posList>35.67104921576792 139.73986382960496 31.967 35.671062055793534 139.7398579821613 31.967 35.671062055793534 139.7398579821613 33.39 35.67104921576792 139.73986382960496 33.39 35.67104921576792 139.73986382960496 31.967</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ba873e1b-208e-4a1b-806e-11e4ac506071">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ba873e1b-208e-4a1b-806e-11e4ac506071_0">
											<gml:posList>35.671065875757684 139.73986720141318 31.967 35.67107564317625 139.73986273834547 31.967 35.67107564317625 139.73986273834547 33.158 35.671065875757684 139.73986720141318 33.158 35.671065875757684 139.73986720141318 31.967</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-78ce38c6-de33-4f78-8b37-f7832f39ea1c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-78ce38c6-de33-4f78-8b37-f7832f39ea1c_0">
											<gml:posList>35.671081922719814 139.7399285341677 33.343 35.671093402747715 139.73992406911128 33.343 35.671093402747715 139.73992406911128 31.967 35.671081922719814 139.7399285341677 31.967 35.671081922719814 139.7399285341677 33.343</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-dc8d5afb-f628-487f-b0ec-90061642e37c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-dc8d5afb-f628-487f-b0ec-90061642e37c_0">
											<gml:posList>35.67109713660515 139.73993849130488 33.343 35.67109713660515 139.73993849130488 31.967 35.671093402747715 139.73992406911128 31.967 35.671093402747715 139.73992406911128 33.343 35.67109713660515 139.73993849130488 33.343</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ddc0df67-d3a8-4ee4-b01a-396257870c76">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ddc0df67-d3a8-4ee4-b01a-396257870c76_0">
											<gml:posList>35.671081922719814 139.7399285341677 33.343 35.671085647563004 139.73994295636996 33.343 35.67109713660515 139.73993849130488 33.343 35.671093402747715 139.73992406911128 33.343 35.671081922719814 139.7399285341677 33.343</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-df00f070-940d-4d8a-b58b-016ff8718020">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-df00f070-940d-4d8a-b58b-016ff8718020_0">
											<gml:posList>35.671081922719814 139.7399285341677 31.967 35.671085647563004 139.73994295636996 31.967 35.671085647563004 139.73994295636996 33.343 35.671081922719814 139.7399285341677 33.343 35.671081922719814 139.7399285341677 31.967</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4c1c62bd-1ab2-4924-86eb-4028ce3d1659">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4c1c62bd-1ab2-4924-86eb-4028ce3d1659_0">
											<gml:posList>35.671085647563004 139.73994295636996 31.967 35.67109713660515 139.73993849130488 31.967 35.67109713660515 139.73993849130488 33.343 35.671085647563004 139.73994295636996 33.343 35.671085647563004 139.73994295636996 31.967</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-7b2e0aa4-4b7e-405a-9184-c4464f4bf5f5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7b2e0aa4-4b7e-405a-9184-c4464f4bf5f5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7b2e0aa4-4b7e-405a-9184-c4464f4bf5f5">
											<gml:posList>35.67103705264534 139.73994050545303 15.32 35.67101740967173 139.73994947587545 15.32 35.6709734907583 139.73980493042419 15.32 35.670993674287125 139.73979562795037 15.32 35.67098283009953 139.73975996091588 15.32 35.67101274501002 139.73974622853237 15.32 35.671009311038134 139.7397349652678 15.32 35.67110689511589 139.73969044498114 15.32 35.67111891419908 139.73973008737966 15.32 35.67113197945798 139.7397241070902 15.32 35.67114083557243 139.7397532591516 15.32 35.67114768359688 139.73975015817638 15.32 35.67117768569082 139.73984865677068 15.32 35.67116939598299 139.73985242220166 15.32 35.67118457667265 139.73990089806685 15.32 35.671141778893734 139.73992337206093 15.32 35.671147020218925 139.73994059828385 15.32 35.671080882803615 139.7399707214125 15.32 35.67107753907561 139.73995956848717 15.32 35.671053841382054 139.7399704215111 15.32 35.67105049799664 139.7399597104432 15.32 35.671043740103876 139.73996281129178 15.32 35.67103705264534 139.73994050545303 15.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-0fe99ccb-9da8-42a7-bfb3-1f0158b55aa8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0fe99ccb-9da8-42a7-bfb3-1f0158b55aa8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0fe99ccb-9da8-42a7-bfb3-1f0158b55aa8">
											<gml:posList>35.67104382860783 139.73993745981358 31.904 35.6710505070275 139.7399597325254 31.904 35.671053841382054 139.7399704215111 31.904 35.67104382860783 139.73993745981358 31.904</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-4e8aa60e-fad2-4c43-8cec-7ea62c53bf88">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4e8aa60e-fad2-4c43-8cec-7ea62c53bf88">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4e8aa60e-fad2-4c43-8cec-7ea62c53bf88">
											<gml:posList>35.67100439682296 139.73979073295618 32.203 35.6709734907583 139.73980493042419 32.203 35.67097814387211 139.73980754297915 32.203 35.67099014587643 139.73980202789966 32.203 35.671009049937055 139.7397933455113 32.203 35.67100439682296 139.73979073295618 32.203</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-7e6f98c5-6d14-48ad-bac3-7a47a2f917e7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7e6f98c5-6d14-48ad-bac3-7a47a2f917e7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7e6f98c5-6d14-48ad-bac3-7a47a2f917e7">
											<gml:posList>35.670993674287125 139.73979562795037 31.904 35.67100439682296 139.73979073295618 31.904 35.670993552633924 139.73975506591756 31.904 35.67098283009953 139.73975996091588 31.904 35.670993674287125 139.73979562795037 31.904</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-3a01ab4b-03ac-4fa9-ad15-a6bc5ef2ff54">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3a01ab4b-03ac-4fa9-ad15-a6bc5ef2ff54">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3a01ab4b-03ac-4fa9-ad15-a6bc5ef2ff54">
											<gml:posList>35.67101740967173 139.73994947587545 32.203 35.671019541511704 139.73994378452343 32.203 35.67097814387211 139.73980754297915 32.203 35.6709734907583 139.73980493042419 32.203 35.67101740967173 139.73994947587545 32.203</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-1fc85cf4-86da-4472-b201-b18fc0125a02">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1fc85cf4-86da-4472-b201-b18fc0125a02">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1fc85cf4-86da-4472-b201-b18fc0125a02">
											<gml:posList>35.67100439682296 139.73979073295618 32.203 35.671009049937055 139.7397933455113 32.203 35.670998205748795 139.73975767847026 32.203 35.670993552633924 139.73975506591756 32.203 35.67100439682296 139.73979073295618 32.203</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-35d14551-d1f7-4e66-ad24-5c8aa5be82d2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-35d14551-d1f7-4e66-ad24-5c8aa5be82d2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-35d14551-d1f7-4e66-ad24-5c8aa5be82d2">
											<gml:posList>35.67097814387211 139.73980754297915 32.203 35.671019541511704 139.73994378452343 32.203 35.67103275096677 139.7399377599229 32.203 35.67099014587643 139.73980202789966 32.203 35.67097814387211 139.73980754297915 32.203</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-26543fd6-d147-4e17-a2a6-cb62097de9de">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-26543fd6-d147-4e17-a2a6-cb62097de9de">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-26543fd6-d147-4e17-a2a6-cb62097de9de">
											<gml:posList>35.67101274501002 139.73974622853237 32.203 35.670993552633924 139.73975506591756 32.203 35.670998205748795 139.73975767847026 32.203 35.671017398116476 139.73974883003885 32.203 35.67101274501002 139.73974622853237 32.203</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-786cd443-6da9-4cef-8913-af15a6430e9e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-786cd443-6da9-4cef-8913-af15a6430e9e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-786cd443-6da9-4cef-8913-af15a6430e9e">
											<gml:posList>35.67101274501002 139.73974622853237 32.203 35.671017398116476 139.73974883003885 32.203 35.67101396415343 139.73973757781982 32.203 35.671009311038134 139.7397349652678 32.203 35.67101274501002 139.73974622853237 32.203</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-6d31a33f-4c21-4d3e-8c5f-8e1259f95684">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6d31a33f-4c21-4d3e-8c5f-8e1259f95684">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6d31a33f-4c21-4d3e-8c5f-8e1259f95684">
											<gml:posList>35.67104382860783 139.73993745981358 32.203 35.671045960430085 139.7399317463667 32.203 35.67103275096677 139.7399377599229 32.203 35.671019541511704 139.73994378452343 32.203 35.67101740967173 139.73994947587545 32.203 35.67104382860783 139.73993745981358 32.203</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-cecd7269-6cd6-42b0-bdb1-21be49d5a4af">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cecd7269-6cd6-42b0-bdb1-21be49d5a4af">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cecd7269-6cd6-42b0-bdb1-21be49d5a4af">
											<gml:posList>35.671043740103876 139.73996281129178 31.904 35.6710505070275 139.7399597325254 31.904 35.67104382860783 139.73993745981358 31.904 35.67103705264534 139.73994050545303 31.904 35.671043740103876 139.73996281129178 31.904</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-9c497f47-9586-4ae7-a8dd-144420c8ca8d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9c497f47-9586-4ae7-a8dd-144420c8ca8d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9c497f47-9586-4ae7-a8dd-144420c8ca8d">
											<gml:posList>35.67104382860783 139.73993745981358 32.203 35.671053841382054 139.7399704215111 32.203 35.67105596420072 139.73996471912122 32.203 35.671045960430085 139.7399317463667 32.203 35.67104382860783 139.73993745981358 32.203</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e378b4a5-ba28-413f-93a1-3f74569c2162">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e378b4a5-ba28-413f-93a1-3f74569c2162">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e378b4a5-ba28-413f-93a1-3f74569c2162">
											<gml:posList>35.671009311038134 139.7397349652678 32.203 35.67101396415343 139.73973757781982 32.203 35.67110476330511 139.73969615843876 32.203 35.67110689511589 139.73969044498114 32.203 35.671009311038134 139.7397349652678 32.203</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-11b262dd-ad59-4dd6-8e7f-5dec0971feb4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-11b262dd-ad59-4dd6-8e7f-5dec0971feb4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-11b262dd-ad59-4dd6-8e7f-5dec0971feb4">
											<gml:posList>35.67107753907561 139.73995956848717 32.203 35.67107967991262 139.739953855028 32.203 35.67105596420072 139.73996471912122 32.203 35.671053841382054 139.7399704215111 32.203 35.67107753907561 139.73995956848717 32.203</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-bcf5df9d-1c1a-46e8-a674-b0d117e2ba7c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bcf5df9d-1c1a-46e8-a674-b0d117e2ba7c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bcf5df9d-1c1a-46e8-a674-b0d117e2ba7c">
											<gml:posList>35.67107753907561 139.73995956848717 32.203 35.671080882803615 139.7399707214125 32.203 35.67108303266345 139.73996501898924 32.203 35.67107967991262 139.739953855028 32.203 35.67107753907561 139.73995956848717 32.203</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-4a50bdc7-7ac0-49d9-89d5-10326ad20cf8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4a50bdc7-7ac0-49d9-89d5-10326ad20cf8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4a50bdc7-7ac0-49d9-89d5-10326ad20cf8">
											<gml:posList>35.67116469781026 139.73984982073682 31.967 35.67117302356432 139.7398460442174 31.967 35.67114555177471 139.73975586058899 31.967 35.671138694736385 139.73975896157413 31.967 35.671129847645624 139.73972982054872 31.967 35.67111678238642 139.73973580083705 31.967 35.67110476330511 139.73969615843876 31.967 35.67101396415343 139.73973757781982 31.967 35.671017398116476 139.73974883003885 31.967 35.670998205748795 139.73975767847026 31.967 35.671009049937055 139.7397933455113 31.967 35.67099014587643 139.73980202789966 31.967 35.67103275096677 139.7399377599229 31.967 35.671045960430085 139.7399317463667 31.967 35.67105596420072 139.73996471912122 31.967 35.67107967991262 139.739953855028 31.967 35.67108303266345 139.73996501898924 31.967 35.67114235810296 139.73993799677254 31.967 35.67113718001913 139.7399209582653 31.967 35.67116597616589 139.7399058353766 31.967 35.67115943402233 139.7398849543206 31.967 35.671173616458766 139.73987828787625 31.967 35.67116469781026 139.73984982073682 31.967</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-25b29ca3-edd1-40f2-b85c-268ddee845c0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-25b29ca3-edd1-40f2-b85c-268ddee845c0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-25b29ca3-edd1-40f2-b85c-268ddee845c0">
											<gml:posList>35.67111891419908 139.73973008737966 32.203 35.67110689511589 139.73969044498114 32.203 35.67110476330511 139.73969615843876 32.203 35.67111678238642 139.73973580083705 32.203 35.67111891419908 139.73973008737966 32.203</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-4f3c9512-2cfc-443e-9660-1acb69add77c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4f3c9512-2cfc-443e-9660-1acb69add77c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4f3c9512-2cfc-443e-9660-1acb69add77c">
											<gml:posList>35.671147020218925 139.73994059828385 32.203 35.67114235810296 139.73993799677254 32.203 35.67108303266345 139.73996501898924 32.203 35.671080882803615 139.7399707214125 32.203 35.671147020218925 139.73994059828385 32.203</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-bbf10f50-ae72-4f3b-ae94-69d400d1af51">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bbf10f50-ae72-4f3b-ae94-69d400d1af51">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bbf10f50-ae72-4f3b-ae94-69d400d1af51">
											<gml:posList>35.67111891419908 139.73973008737966 32.203 35.67111678238642 139.73973580083705 32.203 35.671129847645624 139.73972982054872 32.203 35.67113197945798 139.7397241070902 32.203 35.67111891419908 139.73973008737966 32.203</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-58bb2616-ef6f-4b96-83d6-6bc0316a435d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-58bb2616-ef6f-4b96-83d6-6bc0316a435d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-58bb2616-ef6f-4b96-83d6-6bc0316a435d">
											<gml:posList>35.67114083557243 139.7397532591516 32.203 35.67113197945798 139.7397241070902 32.203 35.671129847645624 139.73972982054872 32.203 35.671138694736385 139.73975896157413 32.203 35.67114083557243 139.7397532591516 32.203</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e0ee7d2a-5a50-4a67-bd53-0e50473da499">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e0ee7d2a-5a50-4a67-bd53-0e50473da499">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e0ee7d2a-5a50-4a67-bd53-0e50473da499">
											<gml:posList>35.671141778893734 139.73992337206093 32.203 35.67113718001913 139.7399209582653 32.203 35.67114235810296 139.73993799677254 32.203 35.671147020218925 139.73994059828385 32.203 35.671141778893734 139.73992337206093 32.203</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b5d4a41f-0213-4f68-879e-18ca00fdaf36">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b5d4a41f-0213-4f68-879e-18ca00fdaf36">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b5d4a41f-0213-4f68-879e-18ca00fdaf36">
											<gml:posList>35.67114083557243 139.7397532591516 32.203 35.671138694736385 139.73975896157413 32.203 35.67114555177471 139.73975586058899 32.203 35.67114768359688 139.73975015817638 32.203 35.67114083557243 139.7397532591516 32.203</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-860a1555-4844-4552-bf5c-6bdcdce9fdb6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-860a1555-4844-4552-bf5c-6bdcdce9fdb6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-860a1555-4844-4552-bf5c-6bdcdce9fdb6">
											<gml:posList>35.671141778893734 139.73992337206093 32.203 35.67117060207338 139.73990823809436 32.203 35.67116597616589 139.7399058353766 32.203 35.67113718001913 139.7399209582653 32.203 35.671141778893734 139.73992337206093 32.203</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b6ccfbf0-b9b9-4322-b62c-bf42fb41aaf3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b6ccfbf0-b9b9-4322-b62c-bf42fb41aaf3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b6ccfbf0-b9b9-4322-b62c-bf42fb41aaf3">
											<gml:posList>35.67114768359688 139.73975015817638 32.203 35.67114555177471 139.73975586058899 32.203 35.67117302356432 139.7398460442174 32.203 35.67117768569082 139.73984865677068 32.203 35.67114768359688 139.73975015817638 32.203</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-7879ce85-db69-4500-8285-a6d44f445d5e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7879ce85-db69-4500-8285-a6d44f445d5e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7879ce85-db69-4500-8285-a6d44f445d5e">
											<gml:posList>35.671164114124004 139.73988750057654 32.203 35.67115943402233 139.7398849543206 32.203 35.67116597616589 139.7399058353766 32.203 35.67117060207338 139.73990823809436 32.203 35.671164114124004 139.73988750057654 32.203</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-6490b8c7-e89a-4e10-b295-99e7d903d5a1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6490b8c7-e89a-4e10-b295-99e7d903d5a1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6490b8c7-e89a-4e10-b295-99e7d903d5a1">
											<gml:posList>35.671164114124004 139.73988750057654 32.203 35.67117829656057 139.7398808341323 32.203 35.671173616458766 139.73987828787625 32.203 35.67115943402233 139.7398849543206 32.203 35.671164114124004 139.73988750057654 32.203</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ea45eb77-38a9-4233-8a17-cfe4b6582120">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ea45eb77-38a9-4233-8a17-cfe4b6582120">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ea45eb77-38a9-4233-8a17-cfe4b6582120">
											<gml:posList>35.67116939598299 139.73985242220166 32.203 35.67117768569082 139.73984865677068 32.203 35.67117302356432 139.7398460442174 32.203 35.67116469781026 139.73984982073682 32.203 35.67116939598299 139.73985242220166 32.203</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-6d6d5d25-c642-4914-82da-9514c206ffd5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6d6d5d25-c642-4914-82da-9514c206ffd5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6d6d5d25-c642-4914-82da-9514c206ffd5">
											<gml:posList>35.67116939598299 139.73985242220166 32.203 35.67116469781026 139.73984982073682 32.203 35.671173616458766 139.73987828787625 32.203 35.67117829656057 139.7398808341323 32.203 35.67116939598299 139.73985242220166 32.203</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a66edd34-0602-4c2d-a5ae-1b28b1e72046">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a66edd34-0602-4c2d-a5ae-1b28b1e72046">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a66edd34-0602-4c2d-a5ae-1b28b1e72046">
											<gml:posList>35.67118457667265 139.73990089806685 31.904 35.67117829656057 139.7398808341323 31.904 35.671164114124004 139.73988750057654 31.904 35.67117060207338 139.73990823809436 31.904 35.67118457667265 139.73990089806685 31.904</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9e0613a6-16e2-418f-af3a-2b405f6c6514">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9e0613a6-16e2-418f-af3a-2b405f6c6514">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9e0613a6-16e2-418f-af3a-2b405f6c6514">
											<gml:posList>35.670993674287125 139.73979562795037 31.904 35.6709734907583 139.73980493042419 31.904 35.6709734907583 139.73980493042419 32.203 35.670993674287125 139.73979562795037 31.904</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-20886890-75c4-4f97-bd98-b54856bb9096">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-20886890-75c4-4f97-bd98-b54856bb9096">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-20886890-75c4-4f97-bd98-b54856bb9096">
											<gml:posList>35.670993674287125 139.73979562795037 15.32 35.6709734907583 139.73980493042419 15.32 35.6709734907583 139.73980493042419 31.904 35.670993674287125 139.73979562795037 31.904 35.670993674287125 139.73979562795037 15.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-faea5c42-4af6-41bf-b54a-32ca3cf30112">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-faea5c42-4af6-41bf-b54a-32ca3cf30112">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-faea5c42-4af6-41bf-b54a-32ca3cf30112">
											<gml:posList>35.67098283009953 139.73975996091588 15.32 35.670993674287125 139.73979562795037 15.32 35.670993674287125 139.73979562795037 31.904 35.67098283009953 139.73975996091588 31.904 35.67098283009953 139.73975996091588 15.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ec465b9b-5e98-4697-9598-dece70ff5240">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ec465b9b-5e98-4697-9598-dece70ff5240">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ec465b9b-5e98-4697-9598-dece70ff5240">
											<gml:posList>35.670993674287125 139.73979562795037 31.904 35.6709734907583 139.73980493042419 32.203 35.67100439682296 139.73979073295618 31.904 35.670993674287125 139.73979562795037 31.904</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a7bedefd-48a3-4cc3-af7f-b8f82b8f7a8a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a7bedefd-48a3-4cc3-af7f-b8f82b8f7a8a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a7bedefd-48a3-4cc3-af7f-b8f82b8f7a8a">
											<gml:posList>35.6709734907583 139.73980493042419 32.203 35.67100439682296 139.73979073295618 32.203 35.67100439682296 139.73979073295618 31.904 35.6709734907583 139.73980493042419 32.203</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e95443c8-33ce-4a6a-8a51-7ab6fb35eedb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e95443c8-33ce-4a6a-8a51-7ab6fb35eedb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e95443c8-33ce-4a6a-8a51-7ab6fb35eedb">
											<gml:posList>35.67101740967173 139.73994947587545 31.904 35.67101740967173 139.73994947587545 32.203 35.6709734907583 139.73980493042419 32.203 35.6709734907583 139.73980493042419 31.904 35.67101740967173 139.73994947587545 31.904</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-84821839-8fdf-49f6-a265-1e5796464c98">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-84821839-8fdf-49f6-a265-1e5796464c98">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-84821839-8fdf-49f6-a265-1e5796464c98">
											<gml:posList>35.6709734907583 139.73980493042419 15.32 35.67101740967173 139.73994947587545 15.32 35.67101740967173 139.73994947587545 31.904 35.6709734907583 139.73980493042419 31.904 35.6709734907583 139.73980493042419 15.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d1b649de-6a5f-49b4-846f-22ff632b184e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d1b649de-6a5f-49b4-846f-22ff632b184e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d1b649de-6a5f-49b4-846f-22ff632b184e">
											<gml:posList>35.67101274501002 139.73974622853237 15.32 35.67098283009953 139.73975996091588 15.32 35.67098283009953 139.73975996091588 31.904 35.670993552633924 139.73975506591756 31.904 35.67101274501002 139.73974622853237 31.904 35.67101274501002 139.73974622853237 15.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-17b902a1-087f-4fef-9a0d-21a61e0577cd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-17b902a1-087f-4fef-9a0d-21a61e0577cd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-17b902a1-087f-4fef-9a0d-21a61e0577cd">
											<gml:posList>35.67100439682296 139.73979073295618 31.904 35.67100439682296 139.73979073295618 32.203 35.670993552633924 139.73975506591756 32.203 35.670993552633924 139.73975506591756 31.904 35.67100439682296 139.73979073295618 31.904</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-95e6a1d8-cffa-453f-aeac-c17c6e054373">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-95e6a1d8-cffa-453f-aeac-c17c6e054373">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-95e6a1d8-cffa-453f-aeac-c17c6e054373">
											<gml:posList>35.67099014587643 139.73980202789966 32.203 35.67099014587643 139.73980202789966 31.967 35.671009049937055 139.7397933455113 31.967 35.671009049937055 139.7397933455113 32.203 35.67099014587643 139.73980202789966 32.203</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d7cd191f-bbab-4b6d-928c-403360b27779">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d7cd191f-bbab-4b6d-928c-403360b27779">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d7cd191f-bbab-4b6d-928c-403360b27779">
											<gml:posList>35.67101274501002 139.73974622853237 32.203 35.67101274501002 139.73974622853237 31.904 35.670993552633924 139.73975506591756 31.904 35.670993552633924 139.73975506591756 32.203 35.67101274501002 139.73974622853237 32.203</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5acb7559-4d01-4280-b61b-cfc20924beab">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5acb7559-4d01-4280-b61b-cfc20924beab">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5acb7559-4d01-4280-b61b-cfc20924beab">
											<gml:posList>35.671009049937055 139.7397933455113 32.203 35.671009049937055 139.7397933455113 31.967 35.670998205748795 139.73975767847026 31.967 35.670998205748795 139.73975767847026 32.203 35.671009049937055 139.7397933455113 32.203</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-10afdafa-bfbf-4a26-abfc-5ea8afee5d08">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-10afdafa-bfbf-4a26-abfc-5ea8afee5d08">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-10afdafa-bfbf-4a26-abfc-5ea8afee5d08">
											<gml:posList>35.670998205748795 139.73975767847026 32.203 35.670998205748795 139.73975767847026 31.967 35.671017398116476 139.73974883003885 31.967 35.671017398116476 139.73974883003885 32.203 35.670998205748795 139.73975767847026 32.203</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ed34589f-3f3a-4901-9f71-0d7a5ebded25">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ed34589f-3f3a-4901-9f71-0d7a5ebded25">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ed34589f-3f3a-4901-9f71-0d7a5ebded25">
											<gml:posList>35.671009311038134 139.7397349652678 15.32 35.67101274501002 139.73974622853237 15.32 35.67101274501002 139.73974622853237 31.904 35.671009311038134 139.7397349652678 31.904 35.671009311038134 139.7397349652678 15.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1024f12d-7ceb-4f38-b87f-756cbd4f858b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1024f12d-7ceb-4f38-b87f-756cbd4f858b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1024f12d-7ceb-4f38-b87f-756cbd4f858b">
											<gml:posList>35.67101274501002 139.73974622853237 31.904 35.67101274501002 139.73974622853237 32.203 35.671009311038134 139.7397349652678 32.203 35.671009311038134 139.7397349652678 31.904 35.67101274501002 139.73974622853237 31.904</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-799fe9b5-1e53-4010-97ff-13f4b56d9ba8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-799fe9b5-1e53-4010-97ff-13f4b56d9ba8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-799fe9b5-1e53-4010-97ff-13f4b56d9ba8">
											<gml:posList>35.67103275096677 139.7399377599229 32.203 35.67103275096677 139.7399377599229 31.967 35.67099014587643 139.73980202789966 31.967 35.67099014587643 139.73980202789966 32.203 35.67103275096677 139.7399377599229 32.203</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4cd024ad-d0ea-4c94-82a2-e91cf930410f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4cd024ad-d0ea-4c94-82a2-e91cf930410f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4cd024ad-d0ea-4c94-82a2-e91cf930410f">
											<gml:posList>35.671017398116476 139.73974883003885 32.203 35.671017398116476 139.73974883003885 31.967 35.67101396415343 139.73973757781982 31.967 35.67101396415343 139.73973757781982 32.203 35.671017398116476 139.73974883003885 32.203</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-33a2113d-04d6-4e92-b899-c453c5131f0e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-33a2113d-04d6-4e92-b899-c453c5131f0e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-33a2113d-04d6-4e92-b899-c453c5131f0e">
											<gml:posList>35.67101740967173 139.73994947587545 15.32 35.67103705264534 139.73994050545303 15.32 35.67103705264534 139.73994050545303 31.904 35.67101740967173 139.73994947587545 31.904 35.67101740967173 139.73994947587545 15.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-516e0a06-94ca-46e6-996e-1bae5d33700f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-516e0a06-94ca-46e6-996e-1bae5d33700f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-516e0a06-94ca-46e6-996e-1bae5d33700f">
											<gml:posList>35.67104382860783 139.73993745981358 32.203 35.67101740967173 139.73994947587545 32.203 35.67101740967173 139.73994947587545 31.904 35.67103705264534 139.73994050545303 31.904 35.67104382860783 139.73993745981358 31.904 35.67104382860783 139.73993745981358 32.203</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c18561ae-3d70-4c96-b456-2d5b32d2a1eb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c18561ae-3d70-4c96-b456-2d5b32d2a1eb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c18561ae-3d70-4c96-b456-2d5b32d2a1eb">
											<gml:posList>35.671045960430085 139.7399317463667 32.203 35.671045960430085 139.7399317463667 31.967 35.67103275096677 139.7399377599229 31.967 35.67103275096677 139.7399377599229 32.203 35.671045960430085 139.7399317463667 32.203</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2dadecde-380c-4446-aa3e-b07718ec2b80">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2dadecde-380c-4446-aa3e-b07718ec2b80">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2dadecde-380c-4446-aa3e-b07718ec2b80">
											<gml:posList>35.67103705264534 139.73994050545303 15.32 35.671043740103876 139.73996281129178 15.32 35.671043740103876 139.73996281129178 31.904 35.67103705264534 139.73994050545303 31.904 35.67103705264534 139.73994050545303 15.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-bb109642-9f21-418f-9f28-82fc056da1ed">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bb109642-9f21-418f-9f28-82fc056da1ed">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bb109642-9f21-418f-9f28-82fc056da1ed">
											<gml:posList>35.671043740103876 139.73996281129178 15.32 35.67105049799664 139.7399597104432 15.32 35.6710505070275 139.7399597325254 31.904 35.671043740103876 139.73996281129178 31.904 35.671043740103876 139.73996281129178 15.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b11014f0-4854-4241-99db-6aea4dd45d04">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b11014f0-4854-4241-99db-6aea4dd45d04">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b11014f0-4854-4241-99db-6aea4dd45d04">
											<gml:posList>35.671053841382054 139.7399704215111 32.203 35.67104382860783 139.73993745981358 32.203 35.67104382860783 139.73993745981358 31.904 35.671053841382054 139.7399704215111 32.203</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-05e4aa72-dfbf-4c7c-9325-7c97eca492af">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-05e4aa72-dfbf-4c7c-9325-7c97eca492af">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-05e4aa72-dfbf-4c7c-9325-7c97eca492af">
											<gml:posList>35.671053841382054 139.7399704215111 32.203 35.67104382860783 139.73993745981358 31.904 35.671053841382054 139.7399704215111 31.904 35.671053841382054 139.7399704215111 32.203</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4ebeb4a6-0928-4bd3-9ffa-24ad18b9acb5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4ebeb4a6-0928-4bd3-9ffa-24ad18b9acb5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4ebeb4a6-0928-4bd3-9ffa-24ad18b9acb5">
											<gml:posList>35.67105596420072 139.73996471912122 32.203 35.67105596420072 139.73996471912122 31.967 35.671045960430085 139.7399317463667 31.967 35.671045960430085 139.7399317463667 32.203 35.67105596420072 139.73996471912122 32.203</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-edb84b56-e8b7-41c7-a08f-25aa3084cdd8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-edb84b56-e8b7-41c7-a08f-25aa3084cdd8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-edb84b56-e8b7-41c7-a08f-25aa3084cdd8">
											<gml:posList>35.67105049799664 139.7399597104432 15.32 35.671053841382054 139.7399704215111 15.32 35.671053841382054 139.7399704215111 31.904 35.6710505070275 139.7399597325254 31.904 35.67105049799664 139.7399597104432 15.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4d2b9ebe-f0b8-4202-afca-fc7ee7c9a1ca">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4d2b9ebe-f0b8-4202-afca-fc7ee7c9a1ca">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4d2b9ebe-f0b8-4202-afca-fc7ee7c9a1ca">
											<gml:posList>35.671009311038134 139.7397349652678 31.904 35.671009311038134 139.7397349652678 32.203 35.67110689511589 139.73969044498114 32.203 35.67110689511589 139.73969044498114 31.904 35.671009311038134 139.7397349652678 31.904</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-fc1fb86e-5277-497f-8fc1-c379bcdb71c4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fc1fb86e-5277-497f-8fc1-c379bcdb71c4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fc1fb86e-5277-497f-8fc1-c379bcdb71c4">
											<gml:posList>35.67110689511589 139.73969044498114 15.32 35.671009311038134 139.7397349652678 15.32 35.671009311038134 139.7397349652678 31.904 35.67110689511589 139.73969044498114 31.904 35.67110689511589 139.73969044498114 15.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2b2c840b-cea7-430c-90b4-59fc867f2a7a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2b2c840b-cea7-430c-90b4-59fc867f2a7a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2b2c840b-cea7-430c-90b4-59fc867f2a7a">
											<gml:posList>35.67101396415343 139.73973757781982 32.203 35.67101396415343 139.73973757781982 31.967 35.67110476330511 139.73969615843876 31.967 35.67110476330511 139.73969615843876 32.203 35.67101396415343 139.73973757781982 32.203</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5396b8ae-f424-4447-8ed7-a5b6c2135965">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5396b8ae-f424-4447-8ed7-a5b6c2135965">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5396b8ae-f424-4447-8ed7-a5b6c2135965">
											<gml:posList>35.67107753907561 139.73995956848717 31.904 35.67107753907561 139.73995956848717 32.203 35.671053841382054 139.7399704215111 32.203 35.671053841382054 139.7399704215111 31.904 35.67107753907561 139.73995956848717 31.904</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-661ef4ac-566b-4e04-9f16-b1c3ff19ba2b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-661ef4ac-566b-4e04-9f16-b1c3ff19ba2b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-661ef4ac-566b-4e04-9f16-b1c3ff19ba2b">
											<gml:posList>35.671053841382054 139.7399704215111 15.32 35.67107753907561 139.73995956848717 15.32 35.67107753907561 139.73995956848717 31.904 35.671053841382054 139.7399704215111 31.904 35.671053841382054 139.7399704215111 15.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9e43f652-caf7-478c-85d3-80d4b4267bc1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9e43f652-caf7-478c-85d3-80d4b4267bc1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9e43f652-caf7-478c-85d3-80d4b4267bc1">
											<gml:posList>35.67107967991262 139.739953855028 32.203 35.67107967991262 139.739953855028 31.967 35.67105596420072 139.73996471912122 31.967 35.67105596420072 139.73996471912122 32.203 35.67107967991262 139.739953855028 32.203</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b82eddc9-f127-43bb-bb1c-16a60ae0563e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b82eddc9-f127-43bb-bb1c-16a60ae0563e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b82eddc9-f127-43bb-bb1c-16a60ae0563e">
											<gml:posList>35.67107753907561 139.73995956848717 15.32 35.671080882803615 139.7399707214125 15.32 35.671080882803615 139.7399707214125 31.904 35.67107753907561 139.73995956848717 31.904 35.67107753907561 139.73995956848717 15.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3391937b-9332-4254-8338-46b977ce06a2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3391937b-9332-4254-8338-46b977ce06a2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3391937b-9332-4254-8338-46b977ce06a2">
											<gml:posList>35.671080882803615 139.7399707214125 31.904 35.671080882803615 139.7399707214125 32.203 35.67107753907561 139.73995956848717 32.203 35.67107753907561 139.73995956848717 31.904 35.671080882803615 139.7399707214125 31.904</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5b857004-daca-47bf-9e1b-b5fb276ccd98">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5b857004-daca-47bf-9e1b-b5fb276ccd98">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5b857004-daca-47bf-9e1b-b5fb276ccd98">
											<gml:posList>35.67108303266345 139.73996501898924 32.203 35.67108303266345 139.73996501898924 31.967 35.67107967991262 139.739953855028 31.967 35.67107967991262 139.739953855028 32.203 35.67108303266345 139.73996501898924 32.203</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-cdd7f6de-9ebb-43c6-9590-c1a23193c77b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cdd7f6de-9ebb-43c6-9590-c1a23193c77b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cdd7f6de-9ebb-43c6-9590-c1a23193c77b">
											<gml:posList>35.67110476330511 139.73969615843876 32.203 35.67110476330511 139.73969615843876 31.967 35.67111678238642 139.73973580083705 31.967 35.67111678238642 139.73973580083705 32.203 35.67110476330511 139.73969615843876 32.203</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-025b1264-b9cd-4db9-aaa6-90446a52220a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-025b1264-b9cd-4db9-aaa6-90446a52220a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-025b1264-b9cd-4db9-aaa6-90446a52220a">
											<gml:posList>35.67114235810296 139.73993799677254 32.203 35.67114235810296 139.73993799677254 31.967 35.67108303266345 139.73996501898924 31.967 35.67108303266345 139.73996501898924 32.203 35.67114235810296 139.73993799677254 32.203</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9793c6e3-162a-4dff-8174-3efaf439605c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9793c6e3-162a-4dff-8174-3efaf439605c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9793c6e3-162a-4dff-8174-3efaf439605c">
											<gml:posList>35.67110689511589 139.73969044498114 31.904 35.67110689511589 139.73969044498114 32.203 35.67111891419908 139.73973008737966 32.203 35.67111891419908 139.73973008737966 31.904 35.67110689511589 139.73969044498114 31.904</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c481978d-13d8-4cba-9211-b62c06b45bee">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c481978d-13d8-4cba-9211-b62c06b45bee">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c481978d-13d8-4cba-9211-b62c06b45bee">
											<gml:posList>35.67111891419908 139.73973008737966 15.32 35.67110689511589 139.73969044498114 15.32 35.67110689511589 139.73969044498114 31.904 35.67111891419908 139.73973008737966 31.904 35.67111891419908 139.73973008737966 15.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-807b5ece-9146-4d7a-9b8a-93b3b8cd2366">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-807b5ece-9146-4d7a-9b8a-93b3b8cd2366">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-807b5ece-9146-4d7a-9b8a-93b3b8cd2366">
											<gml:posList>35.671147020218925 139.73994059828385 31.904 35.671147020218925 139.73994059828385 32.203 35.671080882803615 139.7399707214125 32.203 35.671080882803615 139.7399707214125 31.904 35.671147020218925 139.73994059828385 31.904</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0920db1a-7939-4e9d-8e23-c9a23c47cce5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0920db1a-7939-4e9d-8e23-c9a23c47cce5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0920db1a-7939-4e9d-8e23-c9a23c47cce5">
											<gml:posList>35.671080882803615 139.7399707214125 15.32 35.671147020218925 139.73994059828385 15.32 35.671147020218925 139.73994059828385 31.904 35.671080882803615 139.7399707214125 31.904 35.671080882803615 139.7399707214125 15.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4987c40d-130e-4827-b151-d9ea45e206a1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4987c40d-130e-4827-b151-d9ea45e206a1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4987c40d-130e-4827-b151-d9ea45e206a1">
											<gml:posList>35.67111678238642 139.73973580083705 32.203 35.67111678238642 139.73973580083705 31.967 35.671129847645624 139.73972982054872 31.967 35.671129847645624 139.73972982054872 32.203 35.67111678238642 139.73973580083705 32.203</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-76c44c04-7fe1-4fa3-af55-35199b8ad4d7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-76c44c04-7fe1-4fa3-af55-35199b8ad4d7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-76c44c04-7fe1-4fa3-af55-35199b8ad4d7">
											<gml:posList>35.67113197945798 139.7397241070902 15.32 35.67111891419908 139.73973008737966 15.32 35.67111891419908 139.73973008737966 31.904 35.67113197945798 139.7397241070902 31.904 35.67113197945798 139.7397241070902 15.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4e873a81-5b47-43c1-b70f-0a96273c869d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4e873a81-5b47-43c1-b70f-0a96273c869d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4e873a81-5b47-43c1-b70f-0a96273c869d">
											<gml:posList>35.67111891419908 139.73973008737966 31.904 35.67111891419908 139.73973008737966 32.203 35.67113197945798 139.7397241070902 32.203 35.67113197945798 139.7397241070902 31.904 35.67111891419908 139.73973008737966 31.904</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ce85c559-8044-4df0-ba31-d8d617257d54">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ce85c559-8044-4df0-ba31-d8d617257d54">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ce85c559-8044-4df0-ba31-d8d617257d54">
											<gml:posList>35.671129847645624 139.73972982054872 32.203 35.671129847645624 139.73972982054872 31.967 35.671138694736385 139.73975896157413 31.967 35.671138694736385 139.73975896157413 32.203 35.671129847645624 139.73972982054872 32.203</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4eb5c612-f2bc-4d50-921d-38eac86ac5e6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4eb5c612-f2bc-4d50-921d-38eac86ac5e6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4eb5c612-f2bc-4d50-921d-38eac86ac5e6">
											<gml:posList>35.67114083557243 139.7397532591516 15.32 35.67113197945798 139.7397241070902 15.32 35.67113197945798 139.7397241070902 31.904 35.67114083557243 139.7397532591516 31.904 35.67114083557243 139.7397532591516 15.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8a387df7-c969-4e1d-9380-0b90bc68ab6d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8a387df7-c969-4e1d-9380-0b90bc68ab6d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8a387df7-c969-4e1d-9380-0b90bc68ab6d">
											<gml:posList>35.67113197945798 139.7397241070902 31.904 35.67113197945798 139.7397241070902 32.203 35.67114083557243 139.7397532591516 32.203 35.67114083557243 139.7397532591516 31.904 35.67113197945798 139.7397241070902 31.904</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-774214bc-aebf-4742-9bfe-2eaba08b3e82">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-774214bc-aebf-4742-9bfe-2eaba08b3e82">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-774214bc-aebf-4742-9bfe-2eaba08b3e82">
											<gml:posList>35.67113718001913 139.7399209582653 32.203 35.67113718001913 139.7399209582653 31.967 35.67114235810296 139.73993799677254 31.967 35.67114235810296 139.73993799677254 32.203 35.67113718001913 139.7399209582653 32.203</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-12f71afe-0363-4357-b978-82eb1695a419">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-12f71afe-0363-4357-b978-82eb1695a419">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-12f71afe-0363-4357-b978-82eb1695a419">
											<gml:posList>35.671138694736385 139.73975896157413 32.203 35.671138694736385 139.73975896157413 31.967 35.67114555177471 139.73975586058899 31.967 35.67114555177471 139.73975586058899 32.203 35.671138694736385 139.73975896157413 32.203</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3e2bfd0d-a517-4b63-9e46-6dda2db13613">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3e2bfd0d-a517-4b63-9e46-6dda2db13613">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3e2bfd0d-a517-4b63-9e46-6dda2db13613">
											<gml:posList>35.671147020218925 139.73994059828385 15.32 35.671141778893734 139.73992337206093 15.32 35.671141778893734 139.73992337206093 31.904 35.671147020218925 139.73994059828385 31.904 35.671147020218925 139.73994059828385 15.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-18d419f5-6ead-4e63-ae9f-da44e98dad92">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-18d419f5-6ead-4e63-ae9f-da44e98dad92">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-18d419f5-6ead-4e63-ae9f-da44e98dad92">
											<gml:posList>35.671141778893734 139.73992337206093 31.904 35.671141778893734 139.73992337206093 32.203 35.671147020218925 139.73994059828385 32.203 35.671147020218925 139.73994059828385 31.904 35.671141778893734 139.73992337206093 31.904</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9fdebbd1-3d0f-457b-baf0-be182e1b377b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9fdebbd1-3d0f-457b-baf0-be182e1b377b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9fdebbd1-3d0f-457b-baf0-be182e1b377b">
											<gml:posList>35.67114768359688 139.73975015817638 15.32 35.67114083557243 139.7397532591516 15.32 35.67114083557243 139.7397532591516 31.904 35.67114768359688 139.73975015817638 31.904 35.67114768359688 139.73975015817638 15.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2ffb74b8-5ecd-463e-addf-320c38d7e3c4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2ffb74b8-5ecd-463e-addf-320c38d7e3c4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2ffb74b8-5ecd-463e-addf-320c38d7e3c4">
											<gml:posList>35.67114083557243 139.7397532591516 31.904 35.67114083557243 139.7397532591516 32.203 35.67114768359688 139.73975015817638 32.203 35.67114768359688 139.73975015817638 31.904 35.67114083557243 139.7397532591516 31.904</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-be2112b6-464e-4481-9e52-cc7ba7533d86">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-be2112b6-464e-4481-9e52-cc7ba7533d86">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-be2112b6-464e-4481-9e52-cc7ba7533d86">
											<gml:posList>35.67116597616589 139.7399058353766 32.203 35.67116597616589 139.7399058353766 31.967 35.67113718001913 139.7399209582653 31.967 35.67113718001913 139.7399209582653 32.203 35.67116597616589 139.7399058353766 32.203</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ecd8be1d-6a3f-4e60-b0aa-8daa16219665">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ecd8be1d-6a3f-4e60-b0aa-8daa16219665">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ecd8be1d-6a3f-4e60-b0aa-8daa16219665">
											<gml:posList>35.671141778893734 139.73992337206093 32.203 35.671141778893734 139.73992337206093 31.904 35.67117060207338 139.73990823809436 31.904 35.67117060207338 139.73990823809436 32.203 35.671141778893734 139.73992337206093 32.203</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b0a2df09-08b0-4474-9b50-fdd87c1b8722">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b0a2df09-08b0-4474-9b50-fdd87c1b8722">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b0a2df09-08b0-4474-9b50-fdd87c1b8722">
											<gml:posList>35.67114555177471 139.73975586058899 32.203 35.67114555177471 139.73975586058899 31.967 35.67117302356432 139.7398460442174 31.967 35.67117302356432 139.7398460442174 32.203 35.67114555177471 139.73975586058899 32.203</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-46a40716-5734-4c21-bb49-b8318e64e5c9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-46a40716-5734-4c21-bb49-b8318e64e5c9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-46a40716-5734-4c21-bb49-b8318e64e5c9">
											<gml:posList>35.67115943402233 139.7398849543206 32.203 35.67115943402233 139.7398849543206 31.967 35.67116597616589 139.7399058353766 31.967 35.67116597616589 139.7399058353766 32.203 35.67115943402233 139.7398849543206 32.203</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-49ab232b-cec5-4ab3-a436-a95fd13a43e1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-49ab232b-cec5-4ab3-a436-a95fd13a43e1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-49ab232b-cec5-4ab3-a436-a95fd13a43e1">
											<gml:posList>35.67114768359688 139.73975015817638 31.904 35.67114768359688 139.73975015817638 32.203 35.67117768569082 139.73984865677068 32.203 35.67117768569082 139.73984865677068 31.904 35.67114768359688 139.73975015817638 31.904</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-cc22f1e1-b718-43f4-9680-33a391b1b4e7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cc22f1e1-b718-43f4-9680-33a391b1b4e7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cc22f1e1-b718-43f4-9680-33a391b1b4e7">
											<gml:posList>35.67117768569082 139.73984865677068 15.32 35.67114768359688 139.73975015817638 15.32 35.67114768359688 139.73975015817638 31.904 35.67117768569082 139.73984865677068 31.904 35.67117768569082 139.73984865677068 15.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-bb792eec-9334-49da-a03b-c5ab7d84be30">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bb792eec-9334-49da-a03b-c5ab7d84be30">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bb792eec-9334-49da-a03b-c5ab7d84be30">
											<gml:posList>35.671141778893734 139.73992337206093 15.32 35.67118457667265 139.73990089806685 15.32 35.67118457667265 139.73990089806685 31.904 35.67117060207338 139.73990823809436 31.904 35.671141778893734 139.73992337206093 31.904 35.671141778893734 139.73992337206093 15.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-02bc9360-f284-4b15-a4c6-088477ef5d45">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-02bc9360-f284-4b15-a4c6-088477ef5d45">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-02bc9360-f284-4b15-a4c6-088477ef5d45">
											<gml:posList>35.671173616458766 139.73987828787625 32.203 35.671173616458766 139.73987828787625 31.967 35.67115943402233 139.7398849543206 31.967 35.67115943402233 139.7398849543206 32.203 35.671173616458766 139.73987828787625 32.203</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-390d99e1-0c6d-4863-86fd-6e49536f92eb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-390d99e1-0c6d-4863-86fd-6e49536f92eb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-390d99e1-0c6d-4863-86fd-6e49536f92eb">
											<gml:posList>35.67117060207338 139.73990823809436 32.203 35.67117060207338 139.73990823809436 31.904 35.671164114124004 139.73988750057654 31.904 35.671164114124004 139.73988750057654 32.203 35.67117060207338 139.73990823809436 32.203</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4b7a1e99-5a6d-4364-80e3-c839c624d01a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4b7a1e99-5a6d-4364-80e3-c839c624d01a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4b7a1e99-5a6d-4364-80e3-c839c624d01a">
											<gml:posList>35.67117302356432 139.7398460442174 32.203 35.67117302356432 139.7398460442174 31.967 35.67116469781026 139.73984982073682 31.967 35.67116469781026 139.73984982073682 32.203 35.67117302356432 139.7398460442174 32.203</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e6ba5286-b6eb-45da-8ad7-f29f81f0735c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e6ba5286-b6eb-45da-8ad7-f29f81f0735c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e6ba5286-b6eb-45da-8ad7-f29f81f0735c">
											<gml:posList>35.67116469781026 139.73984982073682 32.203 35.67116469781026 139.73984982073682 31.967 35.671173616458766 139.73987828787625 31.967 35.671173616458766 139.73987828787625 32.203 35.67116469781026 139.73984982073682 32.203</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c46599b5-6078-4c4e-9a32-35f95e7deaa0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c46599b5-6078-4c4e-9a32-35f95e7deaa0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c46599b5-6078-4c4e-9a32-35f95e7deaa0">
											<gml:posList>35.67117829656057 139.7398808341323 32.203 35.671164114124004 139.73988750057654 32.203 35.671164114124004 139.73988750057654 31.904 35.67117829656057 139.7398808341323 31.904 35.67117829656057 139.7398808341323 32.203</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1bb0866b-a3ef-4bbe-a949-d82039c7714b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1bb0866b-a3ef-4bbe-a949-d82039c7714b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1bb0866b-a3ef-4bbe-a949-d82039c7714b">
											<gml:posList>35.67117768569082 139.73984865677068 31.904 35.67117768569082 139.73984865677068 32.203 35.67116939598299 139.73985242220166 32.203 35.67116939598299 139.73985242220166 31.904 35.67117768569082 139.73984865677068 31.904</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e4a1a732-59b5-4b6e-9ff4-dda34189a0ed">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e4a1a732-59b5-4b6e-9ff4-dda34189a0ed">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e4a1a732-59b5-4b6e-9ff4-dda34189a0ed">
											<gml:posList>35.67116939598299 139.73985242220166 15.32 35.67117768569082 139.73984865677068 15.32 35.67117768569082 139.73984865677068 31.904 35.67116939598299 139.73985242220166 31.904 35.67116939598299 139.73985242220166 15.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-dab3b590-7fd5-4a6a-b6d9-cd9c662c8b89">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-dab3b590-7fd5-4a6a-b6d9-cd9c662c8b89">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-dab3b590-7fd5-4a6a-b6d9-cd9c662c8b89">
											<gml:posList>35.67116939598299 139.73985242220166 31.904 35.67116939598299 139.73985242220166 32.203 35.67117829656057 139.7398808341323 32.203 35.67117829656057 139.7398808341323 31.904 35.67116939598299 139.73985242220166 31.904</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a39f10db-ee0f-41ce-9fcc-fd06af5cc225">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a39f10db-ee0f-41ce-9fcc-fd06af5cc225">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a39f10db-ee0f-41ce-9fcc-fd06af5cc225">
											<gml:posList>35.67118457667265 139.73990089806685 15.32 35.67116939598299 139.73985242220166 15.32 35.67116939598299 139.73985242220166 31.904 35.67117829656057 139.7398808341323 31.904 35.67118457667265 139.73990089806685 31.904 35.67118457667265 139.73990089806685 15.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-4273</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">395.7882</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">211</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1320</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>4</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.16</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>