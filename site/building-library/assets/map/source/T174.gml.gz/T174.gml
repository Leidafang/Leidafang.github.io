<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_2dd0bf13-a9ae-42e5-a9d4-274702512b3d">
			<core:creationDate>2024-03-15</core:creationDate>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3001</bldg:class>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.667151981962675 139.741029398189 0 35.667151803720145 139.74103204938973 0 35.667152077264596 139.74103613602634 0 35.66715262012014 139.74103878639704 0 35.6671534333028 139.74104132599854 0 35.66715451672796 139.74104364437272 0 35.66715514853544 139.74104474822707 0 35.66715659234029 139.74104684527035 0 35.66715740425301 139.74104772800112 0 35.66715911813106 139.74104938290102 0 35.66716011023367 139.7410501549664 0 35.667161012114356 139.74105081667742 0 35.66716308611819 139.7410519188722 0 35.66716407796684 139.7410523595634 0 35.66716624168471 139.74105290936419 0 35.66716984726046 139.741053015673 0 35.667171018960374 139.74105290386643 0 35.66717318183176 139.7410523490865 0 35.6671752543966 139.74105157349408 0 35.66717723648553 139.741050356173 0 35.66717813726573 139.74104958192908 0 35.66717993874149 139.74104792298303 0 35.66718146963608 139.74104604343194 0 35.6671821899724 139.7410450484792 0 35.667183359979234 139.74104272751066 0 35.6671838999563 139.74104162230722 0 35.667185068777755 139.7410377549252 0 35.66718551743225 139.74103510341212 0 35.66718569465884 139.74103112671315 0 35.66718515070235 139.74102704038611 0 35.66718478922187 139.74102582576214 0 35.66718397603889 139.74102328615984 0 35.667182892613354 139.74102096778506 0 35.66718153886065 139.74101876017974 0 35.6671808170003 139.7410177668871 0 35.66717919317446 139.74101600142555 0 35.667177299106065 139.74101445719157 0 35.667175315154495 139.74101324443572 0 35.66717324131964 139.74101236315792 0 35.66717107760157 139.7410118133582 0 35.66716891413755 139.7410115949327 0 35.667166660875004 139.7410118184433 0 35.667164497919124 139.74101226276622 0 35.66716242543925 139.74101314881761 0 35.667160443265985 139.74101425568128 0 35.667158551568754 139.7410158042734 0 35.66715774092604 139.74101657841376 0 35.6671561199793 139.74101856852667 0 35.66715476952907 139.74102066878623 0 35.66715422955213 139.7410217739894 0 35.66715368965992 139.74102298965056 0 35.66715279014999 139.7410254207653 0 35.66715243061698 139.741026746677 0 35.667151981962675 139.741029398189 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667151981962675 139.741029398189 24.595 35.66715243061698 139.741026746677 24.595 35.66715279014999 139.7410254207653 24.595 35.66715368965992 139.74102298965056 24.595 35.66715422955213 139.7410217739894 24.595 35.66715476952907 139.74102066878623 24.595 35.6671561199793 139.74101856852667 24.595 35.66715774092604 139.74101657841376 24.595 35.667158551568754 139.7410158042734 24.595 35.667160443265985 139.74101425568128 24.595 35.66716242543925 139.74101314881761 24.595 35.667164497919124 139.74101226276622 24.595 35.667166660875004 139.7410118184433 24.595 35.66716891413755 139.7410115949327 24.595 35.66717107760157 139.7410118133582 24.595 35.66717324131964 139.74101236315792 24.595 35.667175315154495 139.74101324443572 24.595 35.667177299106065 139.74101445719157 24.595 35.66717919317446 139.74101600142555 24.595 35.6671808170003 139.7410177668871 24.595 35.66718153886065 139.74101876017974 24.595 35.667182892613354 139.74102096778506 24.595 35.66718397603889 139.74102328615984 24.595 35.66718478922187 139.74102582576214 24.595 35.66718515070235 139.74102704038611 24.595 35.66718569465884 139.74103112671315 24.595 35.66718551743225 139.74103510341212 24.595 35.667185068777755 139.7410377549252 24.595 35.6671838999563 139.74104162230722 24.595 35.667183359979234 139.74104272751066 24.595 35.6671821899724 139.7410450484792 24.595 35.66718146963608 139.74104604343194 24.595 35.66717993874149 139.74104792298303 24.595 35.66717813726573 139.74104958192908 24.595 35.66717723648553 139.741050356173 24.595 35.6671752543966 139.74105157349408 24.595 35.66717318183176 139.7410523490865 24.595 35.667171018960374 139.74105290386643 24.595 35.66716984726046 139.741053015673 24.595 35.66716624168471 139.74105290936419 24.595 35.66716407796684 139.7410523595634 24.595 35.66716308611819 139.7410519188722 24.595 35.667161012114356 139.74105081667742 24.595 35.66716011023367 139.7410501549664 24.595 35.66715911813106 139.74104938290102 24.595 35.66715740425301 139.74104772800112 24.595 35.66715659234029 139.74104684527035 24.595 35.66715514853544 139.74104474822707 24.595 35.66715451672796 139.74104364437272 24.595 35.6671534333028 139.74104132599854 24.595 35.66715262012014 139.74103878639704 24.595 35.667152077264596 139.74103613602634 24.595 35.667151803720145 139.74103204938973 24.595 35.667151981962675 139.741029398189 24.595</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667151981962675 139.741029398189 24.595 35.667151803720145 139.74103204938973 24.595 35.667151803720145 139.74103204938973 27.595 35.667151981962675 139.741029398189 27.595 35.667151981962675 139.741029398189 24.595</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667151803720145 139.74103204938973 24.595 35.667152077264596 139.74103613602634 24.595 35.667152077264596 139.74103613602634 27.595 35.667151803720145 139.74103204938973 27.595 35.667151803720145 139.74103204938973 24.595</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667152077264596 139.74103613602634 24.595 35.66715262012014 139.74103878639704 24.595 35.66715262012014 139.74103878639704 27.595 35.667152077264596 139.74103613602634 27.595 35.667152077264596 139.74103613602634 24.595</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66715262012014 139.74103878639704 24.595 35.6671534333028 139.74104132599854 24.595 35.6671534333028 139.74104132599854 27.595 35.66715262012014 139.74103878639704 27.595 35.66715262012014 139.74103878639704 24.595</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6671534333028 139.74104132599854 24.595 35.66715451672796 139.74104364437272 24.595 35.66715451672796 139.74104364437272 27.595 35.6671534333028 139.74104132599854 27.595 35.6671534333028 139.74104132599854 24.595</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66715451672796 139.74104364437272 24.595 35.66715514853544 139.74104474822707 24.595 35.66715514853544 139.74104474822707 27.595 35.66715451672796 139.74104364437272 27.595 35.66715451672796 139.74104364437272 24.595</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66715514853544 139.74104474822707 24.595 35.66715659234029 139.74104684527035 24.595 35.66715659234029 139.74104684527035 27.595 35.66715514853544 139.74104474822707 27.595 35.66715514853544 139.74104474822707 24.595</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66715659234029 139.74104684527035 24.595 35.66715740425301 139.74104772800112 24.595 35.66715740425301 139.74104772800112 27.595 35.66715659234029 139.74104684527035 27.595 35.66715659234029 139.74104684527035 24.595</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66715740425301 139.74104772800112 24.595 35.66715911813106 139.74104938290102 24.595 35.66715911813106 139.74104938290102 27.595 35.66715740425301 139.74104772800112 27.595 35.66715740425301 139.74104772800112 24.595</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66715911813106 139.74104938290102 24.595 35.66716011023367 139.7410501549664 24.595 35.66716011023367 139.7410501549664 27.595 35.66715911813106 139.74104938290102 27.595 35.66715911813106 139.74104938290102 24.595</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66716011023367 139.7410501549664 24.595 35.667161012114356 139.74105081667742 24.595 35.667161012114356 139.74105081667742 27.595 35.66716011023367 139.7410501549664 27.595 35.66716011023367 139.7410501549664 24.595</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667161012114356 139.74105081667742 24.595 35.66716308611819 139.7410519188722 24.595 35.66716308611819 139.7410519188722 27.595 35.667161012114356 139.74105081667742 27.595 35.667161012114356 139.74105081667742 24.595</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66716308611819 139.7410519188722 24.595 35.66716407796684 139.7410523595634 24.595 35.66716407796684 139.7410523595634 27.595 35.66716308611819 139.7410519188722 27.595 35.66716308611819 139.7410519188722 24.595</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66716407796684 139.7410523595634 24.595 35.66716624168471 139.74105290936419 24.595 35.66716624168471 139.74105290936419 27.595 35.66716407796684 139.7410523595634 27.595 35.66716407796684 139.7410523595634 24.595</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66716624168471 139.74105290936419 24.595 35.66716984726046 139.741053015673 24.595 35.66716984726046 139.741053015673 27.595 35.66716624168471 139.74105290936419 27.595 35.66716624168471 139.74105290936419 24.595</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66716984726046 139.741053015673 24.595 35.667171018960374 139.74105290386643 24.595 35.667171018960374 139.74105290386643 27.595 35.66716984726046 139.741053015673 27.595 35.66716984726046 139.741053015673 24.595</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667171018960374 139.74105290386643 24.595 35.66717318183176 139.7410523490865 24.595 35.66717318183176 139.7410523490865 27.595 35.667171018960374 139.74105290386643 27.595 35.667171018960374 139.74105290386643 24.595</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66717318183176 139.7410523490865 24.595 35.6671752543966 139.74105157349408 24.595 35.6671752543966 139.74105157349408 27.595 35.66717318183176 139.7410523490865 27.595 35.66717318183176 139.7410523490865 24.595</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6671752543966 139.74105157349408 24.595 35.66717723648553 139.741050356173 24.595 35.66717723648553 139.741050356173 27.595 35.6671752543966 139.74105157349408 27.595 35.6671752543966 139.74105157349408 24.595</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66717723648553 139.741050356173 24.595 35.66717813726573 139.74104958192908 24.595 35.66717813726573 139.74104958192908 27.595 35.66717723648553 139.741050356173 27.595 35.66717723648553 139.741050356173 24.595</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66717813726573 139.74104958192908 24.595 35.66717993874149 139.74104792298303 24.595 35.66717993874149 139.74104792298303 27.595 35.66717813726573 139.74104958192908 27.595 35.66717813726573 139.74104958192908 24.595</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66717993874149 139.74104792298303 24.595 35.66718146963608 139.74104604343194 24.595 35.66718146963608 139.74104604343194 27.595 35.66717993874149 139.74104792298303 27.595 35.66717993874149 139.74104792298303 24.595</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66718146963608 139.74104604343194 24.595 35.6671821899724 139.7410450484792 24.595 35.6671821899724 139.7410450484792 27.595 35.66718146963608 139.74104604343194 27.595 35.66718146963608 139.74104604343194 24.595</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6671821899724 139.7410450484792 24.595 35.667183359979234 139.74104272751066 24.595 35.667183359979234 139.74104272751066 27.595 35.6671821899724 139.7410450484792 27.595 35.6671821899724 139.7410450484792 24.595</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667183359979234 139.74104272751066 24.595 35.6671838999563 139.74104162230722 24.595 35.6671838999563 139.74104162230722 27.595 35.667183359979234 139.74104272751066 27.595 35.667183359979234 139.74104272751066 24.595</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6671838999563 139.74104162230722 24.595 35.667185068777755 139.7410377549252 24.595 35.667185068777755 139.7410377549252 27.595 35.6671838999563 139.74104162230722 27.595 35.6671838999563 139.74104162230722 24.595</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667185068777755 139.7410377549252 24.595 35.66718551743225 139.74103510341212 24.595 35.66718551743225 139.74103510341212 27.595 35.667185068777755 139.7410377549252 27.595 35.667185068777755 139.7410377549252 24.595</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66718551743225 139.74103510341212 24.595 35.66718569465884 139.74103112671315 24.595 35.66718569465884 139.74103112671315 27.595 35.66718551743225 139.74103510341212 27.595 35.66718551743225 139.74103510341212 24.595</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66718569465884 139.74103112671315 24.595 35.66718515070235 139.74102704038611 24.595 35.66718515070235 139.74102704038611 27.595 35.66718569465884 139.74103112671315 27.595 35.66718569465884 139.74103112671315 24.595</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66718515070235 139.74102704038611 24.595 35.66718478922187 139.74102582576214 24.595 35.66718478922187 139.74102582576214 27.595 35.66718515070235 139.74102704038611 27.595 35.66718515070235 139.74102704038611 24.595</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66718478922187 139.74102582576214 24.595 35.66718397603889 139.74102328615984 24.595 35.66718397603889 139.74102328615984 27.595 35.66718478922187 139.74102582576214 27.595 35.66718478922187 139.74102582576214 24.595</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66718397603889 139.74102328615984 24.595 35.667182892613354 139.74102096778506 24.595 35.667182892613354 139.74102096778506 27.595 35.66718397603889 139.74102328615984 27.595 35.66718397603889 139.74102328615984 24.595</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667182892613354 139.74102096778506 24.595 35.66718153886065 139.74101876017974 24.595 35.66718153886065 139.74101876017974 27.595 35.667182892613354 139.74102096778506 27.595 35.667182892613354 139.74102096778506 24.595</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66718153886065 139.74101876017974 24.595 35.6671808170003 139.7410177668871 24.595 35.6671808170003 139.7410177668871 27.595 35.66718153886065 139.74101876017974 27.595 35.66718153886065 139.74101876017974 24.595</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6671808170003 139.7410177668871 24.595 35.66717919317446 139.74101600142555 24.595 35.66717919317446 139.74101600142555 27.595 35.6671808170003 139.7410177668871 27.595 35.6671808170003 139.7410177668871 24.595</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66717919317446 139.74101600142555 24.595 35.667177299106065 139.74101445719157 24.595 35.667177299106065 139.74101445719157 27.595 35.66717919317446 139.74101600142555 27.595 35.66717919317446 139.74101600142555 24.595</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667177299106065 139.74101445719157 24.595 35.667175315154495 139.74101324443572 24.595 35.667175315154495 139.74101324443572 27.595 35.667177299106065 139.74101445719157 27.595 35.667177299106065 139.74101445719157 24.595</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667175315154495 139.74101324443572 24.595 35.66717324131964 139.74101236315792 24.595 35.66717324131964 139.74101236315792 27.595 35.667175315154495 139.74101324443572 27.595 35.667175315154495 139.74101324443572 24.595</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66717324131964 139.74101236315792 24.595 35.66717107760157 139.7410118133582 24.595 35.66717107760157 139.7410118133582 27.595 35.66717324131964 139.74101236315792 27.595 35.66717324131964 139.74101236315792 24.595</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66717107760157 139.7410118133582 24.595 35.66716891413755 139.7410115949327 24.595 35.66716891413755 139.7410115949327 27.595 35.66717107760157 139.7410118133582 27.595 35.66717107760157 139.7410118133582 24.595</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66716891413755 139.7410115949327 24.595 35.667166660875004 139.7410118184433 24.595 35.667166660875004 139.7410118184433 27.595 35.66716891413755 139.7410115949327 27.595 35.66716891413755 139.7410115949327 24.595</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667166660875004 139.7410118184433 24.595 35.667164497919124 139.74101226276622 24.595 35.667164497919124 139.74101226276622 27.595 35.667166660875004 139.7410118184433 27.595 35.667166660875004 139.7410118184433 24.595</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667164497919124 139.74101226276622 24.595 35.66716242543925 139.74101314881761 24.595 35.66716242543925 139.74101314881761 27.595 35.667164497919124 139.74101226276622 27.595 35.667164497919124 139.74101226276622 24.595</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66716242543925 139.74101314881761 24.595 35.667160443265985 139.74101425568128 24.595 35.667160443265985 139.74101425568128 27.595 35.66716242543925 139.74101314881761 27.595 35.66716242543925 139.74101314881761 24.595</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667160443265985 139.74101425568128 24.595 35.667158551568754 139.7410158042734 24.595 35.667158551568754 139.7410158042734 27.595 35.667160443265985 139.74101425568128 27.595 35.667160443265985 139.74101425568128 24.595</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667158551568754 139.7410158042734 24.595 35.66715774092604 139.74101657841376 24.595 35.66715774092604 139.74101657841376 27.595 35.667158551568754 139.7410158042734 27.595 35.667158551568754 139.7410158042734 24.595</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66715774092604 139.74101657841376 24.595 35.6671561199793 139.74101856852667 24.595 35.6671561199793 139.74101856852667 27.595 35.66715774092604 139.74101657841376 27.595 35.66715774092604 139.74101657841376 24.595</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6671561199793 139.74101856852667 24.595 35.66715476952907 139.74102066878623 24.595 35.66715476952907 139.74102066878623 27.595 35.6671561199793 139.74101856852667 27.595 35.6671561199793 139.74101856852667 24.595</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66715476952907 139.74102066878623 24.595 35.66715422955213 139.7410217739894 24.595 35.66715422955213 139.7410217739894 27.595 35.66715476952907 139.74102066878623 27.595 35.66715476952907 139.74102066878623 24.595</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66715422955213 139.7410217739894 24.595 35.66715368965992 139.74102298965056 24.595 35.66715368965992 139.74102298965056 27.595 35.66715422955213 139.7410217739894 27.595 35.66715422955213 139.7410217739894 24.595</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66715368965992 139.74102298965056 24.595 35.66715279014999 139.7410254207653 24.595 35.66715279014999 139.7410254207653 27.595 35.66715368965992 139.74102298965056 27.595 35.66715368965992 139.74102298965056 24.595</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66715279014999 139.7410254207653 24.595 35.66715243061698 139.741026746677 24.595 35.66715243061698 139.741026746677 27.595 35.66715279014999 139.7410254207653 27.595 35.66715279014999 139.7410254207653 24.595</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66715243061698 139.741026746677 24.595 35.667151981962675 139.741029398189 24.595 35.667151981962675 139.741029398189 27.595 35.66715243061698 139.741026746677 27.595 35.66715243061698 139.741026746677 24.595</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667151981962675 139.741029398189 27.595 35.667151803720145 139.74103204938973 27.595 35.667152077264596 139.74103613602634 27.595 35.66715262012014 139.74103878639704 27.595 35.6671534333028 139.74104132599854 27.595 35.66715451672796 139.74104364437272 27.595 35.66715514853544 139.74104474822707 27.595 35.66715659234029 139.74104684527035 27.595 35.66715740425301 139.74104772800112 27.595 35.66715911813106 139.74104938290102 27.595 35.66716011023367 139.7410501549664 27.595 35.667161012114356 139.74105081667742 27.595 35.66716308611819 139.7410519188722 27.595 35.66716407796684 139.7410523595634 27.595 35.66716624168471 139.74105290936419 27.595 35.66716984726046 139.741053015673 27.595 35.667171018960374 139.74105290386643 27.595 35.66717318183176 139.7410523490865 27.595 35.6671752543966 139.74105157349408 27.595 35.66717723648553 139.741050356173 27.595 35.66717813726573 139.74104958192908 27.595 35.66717993874149 139.74104792298303 27.595 35.66718146963608 139.74104604343194 27.595 35.6671821899724 139.7410450484792 27.595 35.667183359979234 139.74104272751066 27.595 35.6671838999563 139.74104162230722 27.595 35.667185068777755 139.7410377549252 27.595 35.66718551743225 139.74103510341212 27.595 35.66718569465884 139.74103112671315 27.595 35.66718515070235 139.74102704038611 27.595 35.66718478922187 139.74102582576214 27.595 35.66718397603889 139.74102328615984 27.595 35.667182892613354 139.74102096778506 27.595 35.66718153886065 139.74101876017974 27.595 35.6671808170003 139.7410177668871 27.595 35.66717919317446 139.74101600142555 27.595 35.667177299106065 139.74101445719157 27.595 35.667175315154495 139.74101324443572 27.595 35.66717324131964 139.74101236315792 27.595 35.66717107760157 139.7410118133582 27.595 35.66716891413755 139.7410115949327 27.595 35.667166660875004 139.7410118184433 27.595 35.667164497919124 139.74101226276622 27.595 35.66716242543925 139.74101314881761 27.595 35.667160443265985 139.74101425568128 27.595 35.667158551568754 139.7410158042734 27.595 35.66715774092604 139.74101657841376 27.595 35.6671561199793 139.74101856852667 27.595 35.66715476952907 139.74102066878623 27.595 35.66715422955213 139.7410217739894 27.595 35.66715368965992 139.74102298965056 27.595 35.66715279014999 139.7410254207653 27.595 35.66715243061698 139.741026746677 27.595 35.667151981962675 139.741029398189 27.595</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-78f950c9-e73f-44f3-a460-0a4e9a2dfc85"/>
							<gml:surfaceMember xlink:href="#poly-d12d3185-e5f8-458a-870d-1feda443474c"/>
							<gml:surfaceMember xlink:href="#poly-733da60f-5315-4eef-ba61-94ab2356ba1f"/>
							<gml:surfaceMember xlink:href="#poly-e1c6bdc4-7495-4578-854d-edb7e4cf6283"/>
							<gml:surfaceMember xlink:href="#poly-6c3d7286-9641-409a-b201-0dfe263be0a6"/>
							<gml:surfaceMember xlink:href="#poly-05fe6cdd-0304-48a0-9561-781889dd8ae8"/>
							<gml:surfaceMember xlink:href="#poly-47dc43a9-7f8e-40d0-a33a-0b3ac07fa052"/>
							<gml:surfaceMember xlink:href="#poly-766f338e-c58c-49a9-98a3-de7e2f78cc6c"/>
							<gml:surfaceMember xlink:href="#poly-6666db44-a86a-45fd-b65c-bf7f3472de34"/>
							<gml:surfaceMember xlink:href="#poly-47627787-ae66-469f-90b9-e2fa07da63f5"/>
							<gml:surfaceMember xlink:href="#poly-9bd76be3-7201-4144-bce3-2e87d14be17f"/>
							<gml:surfaceMember xlink:href="#poly-704a4410-db3a-4540-bd8b-f9c088aedaef"/>
							<gml:surfaceMember xlink:href="#poly-4de5bf73-b659-4537-83f9-70311cc3f38b"/>
							<gml:surfaceMember xlink:href="#poly-e9cf9a31-cf13-4652-a241-8ea396eb5f9c"/>
							<gml:surfaceMember xlink:href="#poly-a1d5fca5-2334-4650-897f-cdde7eda75f8"/>
							<gml:surfaceMember xlink:href="#poly-3e13de38-3295-4b84-a783-8776a9d7fb78"/>
							<gml:surfaceMember xlink:href="#poly-61e483be-a0ad-406e-96f0-261e944d2bdb"/>
							<gml:surfaceMember xlink:href="#poly-22e3db41-e067-434f-8540-5c560201eb46"/>
							<gml:surfaceMember xlink:href="#poly-f4fb074d-0ab5-406c-91ee-e797988bb3c3"/>
							<gml:surfaceMember xlink:href="#poly-28fed832-e630-41c9-8e5a-aba98ac98194"/>
							<gml:surfaceMember xlink:href="#poly-08d822c0-d609-4fa4-82b7-ca6716449163"/>
							<gml:surfaceMember xlink:href="#poly-93551f3a-3294-465a-acff-542972eb377c"/>
							<gml:surfaceMember xlink:href="#poly-15a07470-eea2-4ea6-9993-571155b30a83"/>
							<gml:surfaceMember xlink:href="#poly-8421244e-0347-418d-bd69-b6844207a3fc"/>
							<gml:surfaceMember xlink:href="#poly-b0855ac0-a9f8-46e9-868d-3ea07d66660f"/>
							<gml:surfaceMember xlink:href="#poly-3fb5a8cd-bfbc-46d5-8de8-f165c23d7e41"/>
							<gml:surfaceMember xlink:href="#poly-6294b472-2e53-4e40-b82c-09ee30245eb2"/>
							<gml:surfaceMember xlink:href="#poly-67a44542-b6b6-4f2e-8cda-3cd91f289bd0"/>
							<gml:surfaceMember xlink:href="#poly-8cc5ce21-5915-4479-a901-d0617956dca7"/>
							<gml:surfaceMember xlink:href="#poly-632af944-5d01-48fa-8f13-e81a3b4bde7e"/>
							<gml:surfaceMember xlink:href="#poly-9345b309-831b-4b38-b44c-d94bb6944398"/>
							<gml:surfaceMember xlink:href="#poly-59438924-5b2c-4949-93f1-5afa5d66a114"/>
							<gml:surfaceMember xlink:href="#poly-320287f1-4fc9-475a-a823-d4bc421bb235"/>
							<gml:surfaceMember xlink:href="#poly-b24d872d-ea9a-4002-87ae-f71a53af507b"/>
							<gml:surfaceMember xlink:href="#poly-2d359e63-284e-460f-8fe2-0662b921dc92"/>
							<gml:surfaceMember xlink:href="#poly-d43783d5-7d1a-4707-a66a-db95c99ca40f"/>
							<gml:surfaceMember xlink:href="#poly-dbc86064-eb19-4c1b-84d3-2f94762413fa"/>
							<gml:surfaceMember xlink:href="#poly-9c748010-4cff-467c-9f3b-049738a21551"/>
							<gml:surfaceMember xlink:href="#poly-abedca0f-183f-450d-a319-d938c9bcf136"/>
							<gml:surfaceMember xlink:href="#poly-f0573924-cdc1-4e20-9677-5fa7b98b8b92"/>
							<gml:surfaceMember xlink:href="#poly-b73d1afd-bbdd-4166-808e-7b2213068930"/>
							<gml:surfaceMember xlink:href="#poly-8c2eb03b-416b-4447-ad64-aa13d8708114"/>
							<gml:surfaceMember xlink:href="#poly-c5a9983f-622e-498e-9a6c-a982c2262f17"/>
							<gml:surfaceMember xlink:href="#poly-07496c00-df53-493c-81d6-d4a7716f6b59"/>
							<gml:surfaceMember xlink:href="#poly-08952d15-3730-4995-9814-4c65dc95ce32"/>
							<gml:surfaceMember xlink:href="#poly-7a056cf0-88a1-4846-b91b-1046ff2671d2"/>
							<gml:surfaceMember xlink:href="#poly-06db3d03-0edb-4906-93d1-126bf7ce1e19"/>
							<gml:surfaceMember xlink:href="#poly-2135a0df-d64d-4595-a3a5-4b2cd8ab0fce"/>
							<gml:surfaceMember xlink:href="#poly-8917e102-aa4c-4831-8c58-bc79c3cebd91"/>
							<gml:surfaceMember xlink:href="#poly-799259bb-c913-48bd-8060-2a44063f5891"/>
							<gml:surfaceMember xlink:href="#poly-fa442ab6-0d89-4b95-b5c3-d74f3d0a724c"/>
							<gml:surfaceMember xlink:href="#poly-f45235b7-826a-4757-8837-7dfa10f75c94"/>
							<gml:surfaceMember xlink:href="#poly-976969df-2232-4e59-83f3-4d7bb3262a35"/>
							<gml:surfaceMember xlink:href="#poly-1e0c054a-2fe0-422c-8c04-0deabfd026db"/>
							<gml:surfaceMember xlink:href="#poly-8dd271a7-2fca-420c-bde1-8ddffafbab96"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-78f950c9-e73f-44f3-a460-0a4e9a2dfc85">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-78f950c9-e73f-44f3-a460-0a4e9a2dfc85">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-78f950c9-e73f-44f3-a460-0a4e9a2dfc85">
											<gml:posList>35.667151981962654 139.741029398189 24.595 35.66715243061694 139.741026746677 24.595 35.66715279014998 139.7410254207653 24.595 35.667153689659905 139.74102298965056 24.595 35.66715422955213 139.7410217739894 24.595 35.66715476952902 139.74102066878623 24.595 35.667156119979275 139.74101856852667 24.595 35.667157740926015 139.74101657841373 24.595 35.66715855156874 139.7410158042734 24.595 35.667160443265985 139.74101425568128 24.595 35.66716242543924 139.7410131488176 24.595 35.66716449791912 139.74101226276622 24.595 35.66716666087501 139.7410118184433 24.595 35.667168914137555 139.7410115949327 24.595 35.667171077601566 139.7410118133582 24.595 35.667173241319624 139.74101236315792 24.595 35.667175315154466 139.74101324443572 24.595 35.667177299106065 139.74101445719157 24.595 35.667179193174434 139.74101600142552 24.595 35.6671808170003 139.74101776688707 24.595 35.66718153886063 139.74101876017974 24.595 35.66718289261334 139.74102096778503 24.595 35.667183976038864 139.74102328615982 24.595 35.66718478922185 139.74102582576214 24.595 35.66718515070235 139.74102704038611 24.595 35.667185694658805 139.74103112671315 24.595 35.66718551743222 139.74103510341212 24.595 35.667185068777755 139.7410377549252 24.595 35.66718389995628 139.74104162230722 24.595 35.66718335997919 139.74104272751063 24.595 35.66718218997239 139.7410450484792 24.595 35.66718146963606 139.74104604343194 24.595 35.66717993874148 139.74104792298303 24.595 35.66717813726572 139.74104958192905 24.595 35.667177236485514 139.741050356173 24.595 35.667175254396575 139.74105157349408 24.595 35.66717318183176 139.7410523490865 24.595 35.66717101896036 139.74105290386643 24.595 35.66716984726042 139.741053015673 24.595 35.6671662416847 139.74105290936419 24.595 35.66716407796682 139.7410523595634 24.595 35.66716308611818 139.7410519188722 24.595 35.66716101211432 139.74105081667742 24.595 35.667160110233645 139.7410501549664 24.595 35.66715911813105 139.74104938290102 24.595 35.66715740425302 139.74104772800112 24.595 35.66715659234029 139.74104684527032 24.595 35.66715514853543 139.74104474822707 24.595 35.66715451672794 139.74104364437272 24.595 35.6671534333028 139.74104132599854 24.595 35.667152620120135 139.74103878639704 24.595 35.66715207726458 139.74103613602634 24.595 35.66715180372014 139.7410320493897 24.595 35.667151981962654 139.741029398189 24.595</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d12d3185-e5f8-458a-870d-1feda443474c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d12d3185-e5f8-458a-870d-1feda443474c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d12d3185-e5f8-458a-870d-1feda443474c">
											<gml:posList>35.66716242543924 139.7410131488176 30.9 35.667160443265985 139.74101425568128 30.9 35.66715855156874 139.7410158042734 30.9 35.667157740926015 139.74101657841373 30.9 35.667156119979275 139.74101856852667 30.9 35.66715476952902 139.74102066878623 30.9 35.66715422955213 139.7410217739894 30.9 35.667153689659905 139.74102298965056 30.9 35.66715279014998 139.7410254207653 30.9 35.66715243061694 139.741026746677 30.9 35.667151981962654 139.741029398189 30.9 35.66715180372014 139.7410320493897 30.9 35.66715207726458 139.74103613602634 30.9 35.667152620120135 139.74103878639704 30.9 35.6671534333028 139.74104132599854 30.9 35.66715451672794 139.74104364437272 30.9 35.66715514853543 139.74104474822707 30.9 35.66715659234029 139.74104684527032 30.9 35.66715740425302 139.74104772800112 30.9 35.66715911813105 139.74104938290102 30.9 35.667160110233645 139.7410501549664 30.9 35.66716101211432 139.74105081667742 30.9 35.66716308611818 139.7410519188722 30.9 35.66716407796682 139.7410523595634 30.9 35.6671662416847 139.74105290936419 30.9 35.66716984726042 139.741053015673 30.9 35.66717101896036 139.74105290386643 30.9 35.66717318183176 139.7410523490865 30.9 35.667175254396575 139.74105157349408 30.9 35.667177236485514 139.741050356173 30.9 35.66717813726572 139.74104958192905 30.9 35.66717993874148 139.74104792298303 30.9 35.66718146963606 139.74104604343194 30.9 35.66718218997239 139.7410450484792 30.9 35.66718335997919 139.74104272751063 30.9 35.66718389995628 139.74104162230722 30.9 35.667185068777755 139.7410377549252 30.9 35.66718551743222 139.74103510341212 30.9 35.667185694658805 139.74103112671315 30.9 35.66718515070235 139.74102704038611 30.9 35.66718478922185 139.74102582576214 30.9 35.667183976038864 139.74102328615982 30.9 35.66718289261334 139.74102096778503 30.9 35.66718153886063 139.74101876017974 30.9 35.6671808170003 139.74101776688707 30.9 35.667179193174434 139.74101600142552 30.9 35.667177299106065 139.74101445719157 30.9 35.667175315154466 139.74101324443572 30.9 35.667173241319624 139.74101236315792 30.9 35.667171077601566 139.7410118133582 30.9 35.667168914137555 139.7410115949327 30.9 35.66716666087501 139.7410118184433 30.9 35.66716449791912 139.74101226276622 30.9 35.66716242543924 139.7410131488176 30.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-733da60f-5315-4eef-ba61-94ab2356ba1f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-733da60f-5315-4eef-ba61-94ab2356ba1f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-733da60f-5315-4eef-ba61-94ab2356ba1f">
											<gml:posList>35.66715451672794 139.74104364437272 24.595 35.66715514853543 139.74104474822707 24.595 35.66715514853543 139.74104474822707 30.9 35.66715451672794 139.74104364437272 30.9 35.66715451672794 139.74104364437272 24.595</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e1c6bdc4-7495-4578-854d-edb7e4cf6283">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e1c6bdc4-7495-4578-854d-edb7e4cf6283">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e1c6bdc4-7495-4578-854d-edb7e4cf6283">
											<gml:posList>35.66715514853543 139.74104474822707 24.595 35.66715659234029 139.74104684527032 24.595 35.66715659234029 139.74104684527032 30.9 35.66715514853543 139.74104474822707 30.9 35.66715514853543 139.74104474822707 24.595</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6c3d7286-9641-409a-b201-0dfe263be0a6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6c3d7286-9641-409a-b201-0dfe263be0a6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6c3d7286-9641-409a-b201-0dfe263be0a6">
											<gml:posList>35.66715659234029 139.74104684527032 24.595 35.66715740425302 139.74104772800112 24.595 35.66715740425302 139.74104772800112 30.9 35.66715659234029 139.74104684527032 30.9 35.66715659234029 139.74104684527032 24.595</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-05fe6cdd-0304-48a0-9561-781889dd8ae8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-05fe6cdd-0304-48a0-9561-781889dd8ae8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-05fe6cdd-0304-48a0-9561-781889dd8ae8">
											<gml:posList>35.66715740425302 139.74104772800112 24.595 35.66715911813105 139.74104938290102 24.595 35.66715911813105 139.74104938290102 30.9 35.66715740425302 139.74104772800112 30.9 35.66715740425302 139.74104772800112 24.595</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-47dc43a9-7f8e-40d0-a33a-0b3ac07fa052">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-47dc43a9-7f8e-40d0-a33a-0b3ac07fa052">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-47dc43a9-7f8e-40d0-a33a-0b3ac07fa052">
											<gml:posList>35.66715911813105 139.74104938290102 24.595 35.667160110233645 139.7410501549664 24.595 35.667160110233645 139.7410501549664 30.9 35.66715911813105 139.74104938290102 30.9 35.66715911813105 139.74104938290102 24.595</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-766f338e-c58c-49a9-98a3-de7e2f78cc6c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-766f338e-c58c-49a9-98a3-de7e2f78cc6c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-766f338e-c58c-49a9-98a3-de7e2f78cc6c">
											<gml:posList>35.667160110233645 139.7410501549664 24.595 35.66716101211432 139.74105081667742 24.595 35.66716101211432 139.74105081667742 30.9 35.667160110233645 139.7410501549664 30.9 35.667160110233645 139.7410501549664 24.595</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6666db44-a86a-45fd-b65c-bf7f3472de34">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6666db44-a86a-45fd-b65c-bf7f3472de34">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6666db44-a86a-45fd-b65c-bf7f3472de34">
											<gml:posList>35.66716101211432 139.74105081667742 24.595 35.66716308611818 139.7410519188722 24.595 35.66716308611818 139.7410519188722 30.9 35.66716101211432 139.74105081667742 30.9 35.66716101211432 139.74105081667742 24.595</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-47627787-ae66-469f-90b9-e2fa07da63f5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-47627787-ae66-469f-90b9-e2fa07da63f5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-47627787-ae66-469f-90b9-e2fa07da63f5">
											<gml:posList>35.667168914137555 139.7410115949327 24.595 35.66716666087501 139.7410118184433 24.595 35.66716666087501 139.7410118184433 30.9 35.667168914137555 139.7410115949327 30.9 35.667168914137555 139.7410115949327 24.595</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9bd76be3-7201-4144-bce3-2e87d14be17f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9bd76be3-7201-4144-bce3-2e87d14be17f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9bd76be3-7201-4144-bce3-2e87d14be17f">
											<gml:posList>35.667171077601566 139.7410118133582 24.595 35.667168914137555 139.7410115949327 24.595 35.667168914137555 139.7410115949327 30.9 35.667171077601566 139.7410118133582 30.9 35.667171077601566 139.7410118133582 24.595</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-704a4410-db3a-4540-bd8b-f9c088aedaef">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-704a4410-db3a-4540-bd8b-f9c088aedaef">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-704a4410-db3a-4540-bd8b-f9c088aedaef">
											<gml:posList>35.66716666087501 139.7410118184433 24.595 35.66716449791912 139.74101226276622 24.595 35.66716449791912 139.74101226276622 30.9 35.66716666087501 139.7410118184433 30.9 35.66716666087501 139.7410118184433 24.595</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4de5bf73-b659-4537-83f9-70311cc3f38b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4de5bf73-b659-4537-83f9-70311cc3f38b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4de5bf73-b659-4537-83f9-70311cc3f38b">
											<gml:posList>35.667173241319624 139.74101236315792 24.595 35.667171077601566 139.7410118133582 24.595 35.667171077601566 139.7410118133582 30.9 35.667173241319624 139.74101236315792 30.9 35.667173241319624 139.74101236315792 24.595</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e9cf9a31-cf13-4652-a241-8ea396eb5f9c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e9cf9a31-cf13-4652-a241-8ea396eb5f9c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e9cf9a31-cf13-4652-a241-8ea396eb5f9c">
											<gml:posList>35.66716449791912 139.74101226276622 24.595 35.66716242543924 139.7410131488176 24.595 35.66716242543924 139.7410131488176 30.9 35.66716449791912 139.74101226276622 30.9 35.66716449791912 139.74101226276622 24.595</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a1d5fca5-2334-4650-897f-cdde7eda75f8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a1d5fca5-2334-4650-897f-cdde7eda75f8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a1d5fca5-2334-4650-897f-cdde7eda75f8">
											<gml:posList>35.667175315154466 139.74101324443572 24.595 35.667173241319624 139.74101236315792 24.595 35.667173241319624 139.74101236315792 30.9 35.667175315154466 139.74101324443572 30.9 35.667175315154466 139.74101324443572 24.595</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3e13de38-3295-4b84-a783-8776a9d7fb78">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3e13de38-3295-4b84-a783-8776a9d7fb78">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3e13de38-3295-4b84-a783-8776a9d7fb78">
											<gml:posList>35.66716242543924 139.7410131488176 24.595 35.667160443265985 139.74101425568128 24.595 35.667160443265985 139.74101425568128 30.9 35.66716242543924 139.7410131488176 30.9 35.66716242543924 139.7410131488176 24.595</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-61e483be-a0ad-406e-96f0-261e944d2bdb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-61e483be-a0ad-406e-96f0-261e944d2bdb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-61e483be-a0ad-406e-96f0-261e944d2bdb">
											<gml:posList>35.667177299106065 139.74101445719157 24.595 35.667175315154466 139.74101324443572 24.595 35.667175315154466 139.74101324443572 30.9 35.667177299106065 139.74101445719157 30.9 35.667177299106065 139.74101445719157 24.595</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-22e3db41-e067-434f-8540-5c560201eb46">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-22e3db41-e067-434f-8540-5c560201eb46">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-22e3db41-e067-434f-8540-5c560201eb46">
											<gml:posList>35.667160443265985 139.74101425568128 24.595 35.66715855156874 139.7410158042734 24.595 35.66715855156874 139.7410158042734 30.9 35.667160443265985 139.74101425568128 30.9 35.667160443265985 139.74101425568128 24.595</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f4fb074d-0ab5-406c-91ee-e797988bb3c3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f4fb074d-0ab5-406c-91ee-e797988bb3c3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f4fb074d-0ab5-406c-91ee-e797988bb3c3">
											<gml:posList>35.667179193174434 139.74101600142552 24.595 35.667177299106065 139.74101445719157 24.595 35.667177299106065 139.74101445719157 30.9 35.667179193174434 139.74101600142552 30.9 35.667179193174434 139.74101600142552 24.595</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-28fed832-e630-41c9-8e5a-aba98ac98194">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-28fed832-e630-41c9-8e5a-aba98ac98194">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-28fed832-e630-41c9-8e5a-aba98ac98194">
											<gml:posList>35.66715855156874 139.7410158042734 24.595 35.667157740926015 139.74101657841373 24.595 35.667157740926015 139.74101657841373 30.9 35.66715855156874 139.7410158042734 30.9 35.66715855156874 139.7410158042734 24.595</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-08d822c0-d609-4fa4-82b7-ca6716449163">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-08d822c0-d609-4fa4-82b7-ca6716449163">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-08d822c0-d609-4fa4-82b7-ca6716449163">
											<gml:posList>35.6671808170003 139.74101776688707 24.595 35.667179193174434 139.74101600142552 24.595 35.667179193174434 139.74101600142552 30.9 35.6671808170003 139.74101776688707 30.9 35.6671808170003 139.74101776688707 24.595</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-93551f3a-3294-465a-acff-542972eb377c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-93551f3a-3294-465a-acff-542972eb377c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-93551f3a-3294-465a-acff-542972eb377c">
											<gml:posList>35.667157740926015 139.74101657841373 24.595 35.667156119979275 139.74101856852667 24.595 35.667156119979275 139.74101856852667 30.9 35.667157740926015 139.74101657841373 30.9 35.667157740926015 139.74101657841373 24.595</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-15a07470-eea2-4ea6-9993-571155b30a83">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-15a07470-eea2-4ea6-9993-571155b30a83">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-15a07470-eea2-4ea6-9993-571155b30a83">
											<gml:posList>35.66718153886063 139.74101876017974 24.595 35.6671808170003 139.74101776688707 24.595 35.6671808170003 139.74101776688707 30.9 35.66718153886063 139.74101876017974 30.9 35.66718153886063 139.74101876017974 24.595</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8421244e-0347-418d-bd69-b6844207a3fc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8421244e-0347-418d-bd69-b6844207a3fc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8421244e-0347-418d-bd69-b6844207a3fc">
											<gml:posList>35.667156119979275 139.74101856852667 24.595 35.66715476952902 139.74102066878623 24.595 35.66715476952902 139.74102066878623 30.9 35.667156119979275 139.74101856852667 30.9 35.667156119979275 139.74101856852667 24.595</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b0855ac0-a9f8-46e9-868d-3ea07d66660f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b0855ac0-a9f8-46e9-868d-3ea07d66660f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b0855ac0-a9f8-46e9-868d-3ea07d66660f">
											<gml:posList>35.66718289261334 139.74102096778503 24.595 35.66718153886063 139.74101876017974 24.595 35.66718153886063 139.74101876017974 30.9 35.66718289261334 139.74102096778503 30.9 35.66718289261334 139.74102096778503 24.595</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3fb5a8cd-bfbc-46d5-8de8-f165c23d7e41">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3fb5a8cd-bfbc-46d5-8de8-f165c23d7e41">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3fb5a8cd-bfbc-46d5-8de8-f165c23d7e41">
											<gml:posList>35.66715476952902 139.74102066878623 24.595 35.66715422955213 139.7410217739894 24.595 35.66715422955213 139.7410217739894 30.9 35.66715476952902 139.74102066878623 30.9 35.66715476952902 139.74102066878623 24.595</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6294b472-2e53-4e40-b82c-09ee30245eb2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6294b472-2e53-4e40-b82c-09ee30245eb2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6294b472-2e53-4e40-b82c-09ee30245eb2">
											<gml:posList>35.667183976038864 139.74102328615982 24.595 35.66718289261334 139.74102096778503 24.595 35.66718289261334 139.74102096778503 30.9 35.667183976038864 139.74102328615982 30.9 35.667183976038864 139.74102328615982 24.595</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-67a44542-b6b6-4f2e-8cda-3cd91f289bd0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-67a44542-b6b6-4f2e-8cda-3cd91f289bd0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-67a44542-b6b6-4f2e-8cda-3cd91f289bd0">
											<gml:posList>35.66715422955213 139.7410217739894 24.595 35.667153689659905 139.74102298965056 24.595 35.667153689659905 139.74102298965056 30.9 35.66715422955213 139.7410217739894 30.9 35.66715422955213 139.7410217739894 24.595</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8cc5ce21-5915-4479-a901-d0617956dca7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8cc5ce21-5915-4479-a901-d0617956dca7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8cc5ce21-5915-4479-a901-d0617956dca7">
											<gml:posList>35.667153689659905 139.74102298965056 24.595 35.66715279014998 139.7410254207653 24.595 35.66715279014998 139.7410254207653 30.9 35.667153689659905 139.74102298965056 30.9 35.667153689659905 139.74102298965056 24.595</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-632af944-5d01-48fa-8f13-e81a3b4bde7e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-632af944-5d01-48fa-8f13-e81a3b4bde7e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-632af944-5d01-48fa-8f13-e81a3b4bde7e">
											<gml:posList>35.66718478922185 139.74102582576214 24.595 35.667183976038864 139.74102328615982 24.595 35.667183976038864 139.74102328615982 30.9 35.66718478922185 139.74102582576214 30.9 35.66718478922185 139.74102582576214 24.595</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9345b309-831b-4b38-b44c-d94bb6944398">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9345b309-831b-4b38-b44c-d94bb6944398">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9345b309-831b-4b38-b44c-d94bb6944398">
											<gml:posList>35.66715279014998 139.7410254207653 24.595 35.66715243061694 139.741026746677 24.595 35.66715243061694 139.741026746677 30.9 35.66715279014998 139.7410254207653 30.9 35.66715279014998 139.7410254207653 24.595</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-59438924-5b2c-4949-93f1-5afa5d66a114">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-59438924-5b2c-4949-93f1-5afa5d66a114">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-59438924-5b2c-4949-93f1-5afa5d66a114">
											<gml:posList>35.66718515070235 139.74102704038611 24.595 35.66718478922185 139.74102582576214 24.595 35.66718478922185 139.74102582576214 30.9 35.66718515070235 139.74102704038611 30.9 35.66718515070235 139.74102704038611 24.595</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-320287f1-4fc9-475a-a823-d4bc421bb235">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-320287f1-4fc9-475a-a823-d4bc421bb235">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-320287f1-4fc9-475a-a823-d4bc421bb235">
											<gml:posList>35.66715243061694 139.741026746677 24.595 35.667151981962654 139.741029398189 24.595 35.667151981962654 139.741029398189 30.9 35.66715243061694 139.741026746677 30.9 35.66715243061694 139.741026746677 24.595</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b24d872d-ea9a-4002-87ae-f71a53af507b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b24d872d-ea9a-4002-87ae-f71a53af507b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b24d872d-ea9a-4002-87ae-f71a53af507b">
											<gml:posList>35.667185694658805 139.74103112671315 24.595 35.66718515070235 139.74102704038611 24.595 35.66718515070235 139.74102704038611 30.9 35.667185694658805 139.74103112671315 30.9 35.667185694658805 139.74103112671315 24.595</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2d359e63-284e-460f-8fe2-0662b921dc92">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2d359e63-284e-460f-8fe2-0662b921dc92">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2d359e63-284e-460f-8fe2-0662b921dc92">
											<gml:posList>35.667151981962654 139.741029398189 24.595 35.66715180372014 139.7410320493897 24.595 35.66715180372014 139.7410320493897 30.9 35.667151981962654 139.741029398189 30.9 35.667151981962654 139.741029398189 24.595</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d43783d5-7d1a-4707-a66a-db95c99ca40f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d43783d5-7d1a-4707-a66a-db95c99ca40f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d43783d5-7d1a-4707-a66a-db95c99ca40f">
											<gml:posList>35.66718551743222 139.74103510341212 24.595 35.667185694658805 139.74103112671315 24.595 35.667185694658805 139.74103112671315 30.9 35.66718551743222 139.74103510341212 30.9 35.66718551743222 139.74103510341212 24.595</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-dbc86064-eb19-4c1b-84d3-2f94762413fa">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-dbc86064-eb19-4c1b-84d3-2f94762413fa">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-dbc86064-eb19-4c1b-84d3-2f94762413fa">
											<gml:posList>35.66715180372014 139.7410320493897 24.595 35.66715207726458 139.74103613602634 24.595 35.66715207726458 139.74103613602634 30.9 35.66715180372014 139.7410320493897 30.9 35.66715180372014 139.7410320493897 24.595</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9c748010-4cff-467c-9f3b-049738a21551">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9c748010-4cff-467c-9f3b-049738a21551">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9c748010-4cff-467c-9f3b-049738a21551">
											<gml:posList>35.667185068777755 139.7410377549252 24.595 35.66718551743222 139.74103510341212 24.595 35.66718551743222 139.74103510341212 30.9 35.667185068777755 139.7410377549252 30.9 35.667185068777755 139.7410377549252 24.595</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-abedca0f-183f-450d-a319-d938c9bcf136">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-abedca0f-183f-450d-a319-d938c9bcf136">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-abedca0f-183f-450d-a319-d938c9bcf136">
											<gml:posList>35.66715207726458 139.74103613602634 24.595 35.667152620120135 139.74103878639704 24.595 35.667152620120135 139.74103878639704 30.9 35.66715207726458 139.74103613602634 30.9 35.66715207726458 139.74103613602634 24.595</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f0573924-cdc1-4e20-9677-5fa7b98b8b92">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f0573924-cdc1-4e20-9677-5fa7b98b8b92">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f0573924-cdc1-4e20-9677-5fa7b98b8b92">
											<gml:posList>35.66718389995628 139.74104162230722 24.595 35.667185068777755 139.7410377549252 24.595 35.667185068777755 139.7410377549252 30.9 35.66718389995628 139.74104162230722 30.9 35.66718389995628 139.74104162230722 24.595</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b73d1afd-bbdd-4166-808e-7b2213068930">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b73d1afd-bbdd-4166-808e-7b2213068930">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b73d1afd-bbdd-4166-808e-7b2213068930">
											<gml:posList>35.667152620120135 139.74103878639704 24.595 35.6671534333028 139.74104132599854 24.595 35.6671534333028 139.74104132599854 30.9 35.667152620120135 139.74103878639704 30.9 35.667152620120135 139.74103878639704 24.595</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8c2eb03b-416b-4447-ad64-aa13d8708114">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8c2eb03b-416b-4447-ad64-aa13d8708114">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8c2eb03b-416b-4447-ad64-aa13d8708114">
											<gml:posList>35.66718335997919 139.74104272751063 24.595 35.66718389995628 139.74104162230722 24.595 35.66718389995628 139.74104162230722 30.9 35.66718335997919 139.74104272751063 30.9 35.66718335997919 139.74104272751063 24.595</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c5a9983f-622e-498e-9a6c-a982c2262f17">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c5a9983f-622e-498e-9a6c-a982c2262f17">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c5a9983f-622e-498e-9a6c-a982c2262f17">
											<gml:posList>35.6671534333028 139.74104132599854 24.595 35.66715451672794 139.74104364437272 24.595 35.66715451672794 139.74104364437272 30.9 35.6671534333028 139.74104132599854 30.9 35.6671534333028 139.74104132599854 24.595</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-07496c00-df53-493c-81d6-d4a7716f6b59">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-07496c00-df53-493c-81d6-d4a7716f6b59">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-07496c00-df53-493c-81d6-d4a7716f6b59">
											<gml:posList>35.66718218997239 139.7410450484792 24.595 35.66718335997919 139.74104272751063 24.595 35.66718335997919 139.74104272751063 30.9 35.66718218997239 139.7410450484792 30.9 35.66718218997239 139.7410450484792 24.595</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-08952d15-3730-4995-9814-4c65dc95ce32">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-08952d15-3730-4995-9814-4c65dc95ce32">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-08952d15-3730-4995-9814-4c65dc95ce32">
											<gml:posList>35.66718146963606 139.74104604343194 24.595 35.66718218997239 139.7410450484792 24.595 35.66718218997239 139.7410450484792 30.9 35.66718146963606 139.74104604343194 30.9 35.66718146963606 139.74104604343194 24.595</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7a056cf0-88a1-4846-b91b-1046ff2671d2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7a056cf0-88a1-4846-b91b-1046ff2671d2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7a056cf0-88a1-4846-b91b-1046ff2671d2">
											<gml:posList>35.66717993874148 139.74104792298303 24.595 35.66718146963606 139.74104604343194 24.595 35.66718146963606 139.74104604343194 30.9 35.66717993874148 139.74104792298303 30.9 35.66717993874148 139.74104792298303 24.595</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-06db3d03-0edb-4906-93d1-126bf7ce1e19">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-06db3d03-0edb-4906-93d1-126bf7ce1e19">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-06db3d03-0edb-4906-93d1-126bf7ce1e19">
											<gml:posList>35.66717813726572 139.74104958192905 24.595 35.66717993874148 139.74104792298303 24.595 35.66717993874148 139.74104792298303 30.9 35.66717813726572 139.74104958192905 30.9 35.66717813726572 139.74104958192905 24.595</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2135a0df-d64d-4595-a3a5-4b2cd8ab0fce">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2135a0df-d64d-4595-a3a5-4b2cd8ab0fce">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2135a0df-d64d-4595-a3a5-4b2cd8ab0fce">
											<gml:posList>35.667177236485514 139.741050356173 24.595 35.66717813726572 139.74104958192905 24.595 35.66717813726572 139.74104958192905 30.9 35.667177236485514 139.741050356173 30.9 35.667177236485514 139.741050356173 24.595</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8917e102-aa4c-4831-8c58-bc79c3cebd91">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8917e102-aa4c-4831-8c58-bc79c3cebd91">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8917e102-aa4c-4831-8c58-bc79c3cebd91">
											<gml:posList>35.667175254396575 139.74105157349408 24.595 35.667177236485514 139.741050356173 24.595 35.667177236485514 139.741050356173 30.9 35.667175254396575 139.74105157349408 30.9 35.667175254396575 139.74105157349408 24.595</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-799259bb-c913-48bd-8060-2a44063f5891">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-799259bb-c913-48bd-8060-2a44063f5891">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-799259bb-c913-48bd-8060-2a44063f5891">
											<gml:posList>35.66717318183176 139.7410523490865 24.595 35.667175254396575 139.74105157349408 24.595 35.667175254396575 139.74105157349408 30.9 35.66717318183176 139.7410523490865 30.9 35.66717318183176 139.7410523490865 24.595</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-fa442ab6-0d89-4b95-b5c3-d74f3d0a724c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fa442ab6-0d89-4b95-b5c3-d74f3d0a724c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fa442ab6-0d89-4b95-b5c3-d74f3d0a724c">
											<gml:posList>35.66716308611818 139.7410519188722 24.595 35.66716407796682 139.7410523595634 24.595 35.66716407796682 139.7410523595634 30.9 35.66716308611818 139.7410519188722 30.9 35.66716308611818 139.7410519188722 24.595</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f45235b7-826a-4757-8837-7dfa10f75c94">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f45235b7-826a-4757-8837-7dfa10f75c94">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f45235b7-826a-4757-8837-7dfa10f75c94">
											<gml:posList>35.66716407796682 139.7410523595634 24.595 35.6671662416847 139.74105290936419 24.595 35.6671662416847 139.74105290936419 30.9 35.66716407796682 139.7410523595634 30.9 35.66716407796682 139.7410523595634 24.595</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-976969df-2232-4e59-83f3-4d7bb3262a35">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-976969df-2232-4e59-83f3-4d7bb3262a35">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-976969df-2232-4e59-83f3-4d7bb3262a35">
											<gml:posList>35.66717101896036 139.74105290386643 24.595 35.66717318183176 139.7410523490865 24.595 35.66717318183176 139.7410523490865 30.9 35.66717101896036 139.74105290386643 30.9 35.66717101896036 139.74105290386643 24.595</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1e0c054a-2fe0-422c-8c04-0deabfd026db">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1e0c054a-2fe0-422c-8c04-0deabfd026db">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1e0c054a-2fe0-422c-8c04-0deabfd026db">
											<gml:posList>35.6671662416847 139.74105290936419 24.595 35.66716984726042 139.741053015673 24.595 35.66716984726042 139.741053015673 30.9 35.6671662416847 139.74105290936419 30.9 35.6671662416847 139.74105290936419 24.595</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8dd271a7-2fca-420c-bde1-8ddffafbab96">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8dd271a7-2fca-420c-bde1-8ddffafbab96">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8dd271a7-2fca-420c-bde1-8ddffafbab96">
											<gml:posList>35.66716984726042 139.741053015673 24.595 35.66717101896036 139.74105290386643 24.595 35.66717101896036 139.74105290386643 30.9 35.66716984726042 139.741053015673 30.9 35.66716984726042 139.741053015673 24.595</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-8310</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>7</uro:specifiedFloorAreaRate>
					<uro:surveyYear>0001</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.23</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">0</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>