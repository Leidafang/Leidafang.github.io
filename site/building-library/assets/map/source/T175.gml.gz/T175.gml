<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_2de7d495-5537-4895-be7b-6f710401a133">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>0.90</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001001</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3003</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">401</bldg:usage>
			<bldg:measuredHeight uom="m">14.8</bldg:measuredHeight>
			<bldg:storeysAboveGround>2</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.667118445797676 139.74097576520114 0 35.66713292115815 139.740974853818 0 35.66715085661235 139.74097240308097 0 35.66716554619259 139.74096874104177 0 35.66718149599993 139.74096286838574 0 35.6672009585338 139.74095356747603 0 35.667221951197135 139.74094139288448 0 35.66723294226624 139.7409339795171 0 35.66724429227344 139.74092446702684 0 35.667258703047416 139.7409098699247 0 35.66727365226907 139.74089217936373 0 35.6672890497996 139.74087139544585 0 35.66730480550023 139.74084751827286 0 35.667321009506374 139.74082054773862 0 35.667334874096625 139.74079899235488 0 35.66734972790053 139.74077445344452 0 35.66732681698447 139.7407536032551 0 35.667355624385706 139.7407060728713 0 35.6673537227509 139.74069469785016 0 35.66731803467868 139.74070291300004 0 35.66730057149525 139.74073341967843 0 35.667230172330314 139.7407309604357 0 35.6672275797519 139.74075879890907 0 35.66722426292767 139.74078255126145 0 35.667220670594375 139.7407996764352 0 35.667216625365704 139.7408139302158 0 35.6672117670331 139.74082575485195 0 35.66720582611865 139.74083636569497 0 35.66719871265515 139.7408459837649 0 35.66719051678008 139.74085460895762 0 35.66718114835642 139.7408622413771 0 35.6671706975216 139.7408688809193 0 35.66715754231368 139.7408751922036 0 35.66714312399621 139.74087995852815 0 35.6671275327067 139.74088317978976 0 35.66711121913159 139.74088485546952 0 35.66709499425208 139.74088465325914 0 35.6670911191821 139.74093271803036 0 35.66711681145909 139.74093679746613 0 35.667118445797676 139.74097576520114 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667118445797676 139.74097576520114 11.3 35.66711681145909 139.74093679746613 11.3 35.6670911191821 139.74093271803036 11.3 35.66709499425208 139.74088465325914 11.3 35.66711121913159 139.74088485546952 11.3 35.6671275327067 139.74088317978976 11.3 35.66714312399621 139.74087995852815 11.3 35.66715754231368 139.7408751922036 11.3 35.6671706975216 139.7408688809193 11.3 35.66718114835642 139.7408622413771 11.3 35.66719051678008 139.74085460895762 11.3 35.66719871265515 139.7408459837649 11.3 35.66720582611865 139.74083636569497 11.3 35.6672117670331 139.74082575485195 11.3 35.667216625365704 139.7408139302158 11.3 35.667220670594375 139.7407996764352 11.3 35.66722426292767 139.74078255126145 11.3 35.6672275797519 139.74075879890907 11.3 35.667230172330314 139.7407309604357 11.3 35.66730057149525 139.74073341967843 11.3 35.66731803467868 139.74070291300004 11.3 35.6673537227509 139.74069469785016 11.3 35.667355624385706 139.7407060728713 11.3 35.66732681698447 139.7407536032551 11.3 35.66734972790053 139.74077445344452 11.3 35.667334874096625 139.74079899235488 11.3 35.667321009506374 139.74082054773862 11.3 35.66730480550023 139.74084751827286 11.3 35.6672890497996 139.74087139544585 11.3 35.66727365226907 139.74089217936373 11.3 35.667258703047416 139.7409098699247 11.3 35.66724429227344 139.74092446702684 11.3 35.66723294226624 139.7409339795171 11.3 35.667221951197135 139.74094139288448 11.3 35.6672009585338 139.74095356747603 11.3 35.66718149599993 139.74096286838574 11.3 35.66716554619259 139.74096874104177 11.3 35.66715085661235 139.74097240308097 11.3 35.66713292115815 139.740974853818 11.3 35.667118445797676 139.74097576520114 11.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667118445797676 139.74097576520114 11.3 35.66713292115815 139.740974853818 11.3 35.66713292115815 139.740974853818 26.14 35.667118445797676 139.74097576520114 26.14 35.667118445797676 139.74097576520114 11.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66713292115815 139.740974853818 11.3 35.66715085661235 139.74097240308097 11.3 35.66715085661235 139.74097240308097 26.14 35.66713292115815 139.740974853818 26.14 35.66713292115815 139.740974853818 11.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66715085661235 139.74097240308097 11.3 35.66716554619259 139.74096874104177 11.3 35.66716554619259 139.74096874104177 26.14 35.66715085661235 139.74097240308097 26.14 35.66715085661235 139.74097240308097 11.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66716554619259 139.74096874104177 11.3 35.66718149599993 139.74096286838574 11.3 35.66718149599993 139.74096286838574 26.14 35.66716554619259 139.74096874104177 26.14 35.66716554619259 139.74096874104177 11.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66718149599993 139.74096286838574 11.3 35.6672009585338 139.74095356747603 11.3 35.6672009585338 139.74095356747603 26.14 35.66718149599993 139.74096286838574 26.14 35.66718149599993 139.74096286838574 11.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6672009585338 139.74095356747603 11.3 35.667221951197135 139.74094139288448 11.3 35.667221951197135 139.74094139288448 26.14 35.6672009585338 139.74095356747603 26.14 35.6672009585338 139.74095356747603 11.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667221951197135 139.74094139288448 11.3 35.66723294226624 139.7409339795171 11.3 35.66723294226624 139.7409339795171 26.14 35.667221951197135 139.74094139288448 26.14 35.667221951197135 139.74094139288448 11.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66723294226624 139.7409339795171 11.3 35.66724429227344 139.74092446702684 11.3 35.66724429227344 139.74092446702684 26.14 35.66723294226624 139.7409339795171 26.14 35.66723294226624 139.7409339795171 11.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66724429227344 139.74092446702684 11.3 35.667258703047416 139.7409098699247 11.3 35.667258703047416 139.7409098699247 26.14 35.66724429227344 139.74092446702684 26.14 35.66724429227344 139.74092446702684 11.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667258703047416 139.7409098699247 11.3 35.66727365226907 139.74089217936373 11.3 35.66727365226907 139.74089217936373 26.14 35.667258703047416 139.7409098699247 26.14 35.667258703047416 139.7409098699247 11.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66727365226907 139.74089217936373 11.3 35.6672890497996 139.74087139544585 11.3 35.6672890497996 139.74087139544585 26.14 35.66727365226907 139.74089217936373 26.14 35.66727365226907 139.74089217936373 11.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6672890497996 139.74087139544585 11.3 35.66730480550023 139.74084751827286 11.3 35.66730480550023 139.74084751827286 26.14 35.6672890497996 139.74087139544585 26.14 35.6672890497996 139.74087139544585 11.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66730480550023 139.74084751827286 11.3 35.667321009506374 139.74082054773862 11.3 35.667321009506374 139.74082054773862 26.14 35.66730480550023 139.74084751827286 26.14 35.66730480550023 139.74084751827286 11.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667321009506374 139.74082054773862 11.3 35.667334874096625 139.74079899235488 11.3 35.667334874096625 139.74079899235488 26.14 35.667321009506374 139.74082054773862 26.14 35.667321009506374 139.74082054773862 11.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667334874096625 139.74079899235488 11.3 35.66734972790053 139.74077445344452 11.3 35.66734972790053 139.74077445344452 26.14 35.667334874096625 139.74079899235488 26.14 35.667334874096625 139.74079899235488 11.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66734972790053 139.74077445344452 11.3 35.66732681698447 139.7407536032551 11.3 35.66732681698447 139.7407536032551 26.14 35.66734972790053 139.74077445344452 26.14 35.66734972790053 139.74077445344452 11.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66732681698447 139.7407536032551 11.3 35.667355624385706 139.7407060728713 11.3 35.667355624385706 139.7407060728713 26.14 35.66732681698447 139.7407536032551 26.14 35.66732681698447 139.7407536032551 11.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667355624385706 139.7407060728713 11.3 35.6673537227509 139.74069469785016 11.3 35.6673537227509 139.74069469785016 26.14 35.667355624385706 139.7407060728713 26.14 35.667355624385706 139.7407060728713 11.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6673537227509 139.74069469785016 11.3 35.66731803467868 139.74070291300004 11.3 35.66731803467868 139.74070291300004 26.14 35.6673537227509 139.74069469785016 26.14 35.6673537227509 139.74069469785016 11.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66731803467868 139.74070291300004 11.3 35.66730057149525 139.74073341967843 11.3 35.66730057149525 139.74073341967843 26.14 35.66731803467868 139.74070291300004 26.14 35.66731803467868 139.74070291300004 11.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66730057149525 139.74073341967843 11.3 35.667230172330314 139.7407309604357 11.3 35.667230172330314 139.7407309604357 26.14 35.66730057149525 139.74073341967843 26.14 35.66730057149525 139.74073341967843 11.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667230172330314 139.7407309604357 11.3 35.6672275797519 139.74075879890907 11.3 35.6672275797519 139.74075879890907 26.14 35.667230172330314 139.7407309604357 26.14 35.667230172330314 139.7407309604357 11.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6672275797519 139.74075879890907 11.3 35.66722426292767 139.74078255126145 11.3 35.66722426292767 139.74078255126145 26.14 35.6672275797519 139.74075879890907 26.14 35.6672275797519 139.74075879890907 11.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66722426292767 139.74078255126145 11.3 35.667220670594375 139.7407996764352 11.3 35.667220670594375 139.7407996764352 26.14 35.66722426292767 139.74078255126145 26.14 35.66722426292767 139.74078255126145 11.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667220670594375 139.7407996764352 11.3 35.667216625365704 139.7408139302158 11.3 35.667216625365704 139.7408139302158 26.14 35.667220670594375 139.7407996764352 26.14 35.667220670594375 139.7407996764352 11.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667216625365704 139.7408139302158 11.3 35.6672117670331 139.74082575485195 11.3 35.6672117670331 139.74082575485195 26.14 35.667216625365704 139.7408139302158 26.14 35.667216625365704 139.7408139302158 11.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6672117670331 139.74082575485195 11.3 35.66720582611865 139.74083636569497 11.3 35.66720582611865 139.74083636569497 26.14 35.6672117670331 139.74082575485195 26.14 35.6672117670331 139.74082575485195 11.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66720582611865 139.74083636569497 11.3 35.66719871265515 139.7408459837649 11.3 35.66719871265515 139.7408459837649 26.14 35.66720582611865 139.74083636569497 26.14 35.66720582611865 139.74083636569497 11.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66719871265515 139.7408459837649 11.3 35.66719051678008 139.74085460895762 11.3 35.66719051678008 139.74085460895762 26.14 35.66719871265515 139.7408459837649 26.14 35.66719871265515 139.7408459837649 11.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66719051678008 139.74085460895762 11.3 35.66718114835642 139.7408622413771 11.3 35.66718114835642 139.7408622413771 26.14 35.66719051678008 139.74085460895762 26.14 35.66719051678008 139.74085460895762 11.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66718114835642 139.7408622413771 11.3 35.6671706975216 139.7408688809193 11.3 35.6671706975216 139.7408688809193 26.14 35.66718114835642 139.7408622413771 26.14 35.66718114835642 139.7408622413771 11.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6671706975216 139.7408688809193 11.3 35.66715754231368 139.7408751922036 11.3 35.66715754231368 139.7408751922036 26.14 35.6671706975216 139.7408688809193 26.14 35.6671706975216 139.7408688809193 11.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66715754231368 139.7408751922036 11.3 35.66714312399621 139.74087995852815 11.3 35.66714312399621 139.74087995852815 26.14 35.66715754231368 139.7408751922036 26.14 35.66715754231368 139.7408751922036 11.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66714312399621 139.74087995852815 11.3 35.6671275327067 139.74088317978976 11.3 35.6671275327067 139.74088317978976 26.14 35.66714312399621 139.74087995852815 26.14 35.66714312399621 139.74087995852815 11.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6671275327067 139.74088317978976 11.3 35.66711121913159 139.74088485546952 11.3 35.66711121913159 139.74088485546952 26.14 35.6671275327067 139.74088317978976 26.14 35.6671275327067 139.74088317978976 11.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66711121913159 139.74088485546952 11.3 35.66709499425208 139.74088465325914 11.3 35.66709499425208 139.74088465325914 26.14 35.66711121913159 139.74088485546952 26.14 35.66711121913159 139.74088485546952 11.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66709499425208 139.74088465325914 11.3 35.6670911191821 139.74093271803036 11.3 35.6670911191821 139.74093271803036 26.14 35.66709499425208 139.74088465325914 26.14 35.66709499425208 139.74088465325914 11.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6670911191821 139.74093271803036 11.3 35.66711681145909 139.74093679746613 11.3 35.66711681145909 139.74093679746613 26.14 35.6670911191821 139.74093271803036 26.14 35.6670911191821 139.74093271803036 11.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66711681145909 139.74093679746613 11.3 35.667118445797676 139.74097576520114 11.3 35.667118445797676 139.74097576520114 26.14 35.66711681145909 139.74093679746613 26.14 35.66711681145909 139.74093679746613 11.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667118445797676 139.74097576520114 26.14 35.66713292115815 139.740974853818 26.14 35.66715085661235 139.74097240308097 26.14 35.66716554619259 139.74096874104177 26.14 35.66718149599993 139.74096286838574 26.14 35.6672009585338 139.74095356747603 26.14 35.667221951197135 139.74094139288448 26.14 35.66723294226624 139.7409339795171 26.14 35.66724429227344 139.74092446702684 26.14 35.667258703047416 139.7409098699247 26.14 35.66727365226907 139.74089217936373 26.14 35.6672890497996 139.74087139544585 26.14 35.66730480550023 139.74084751827286 26.14 35.667321009506374 139.74082054773862 26.14 35.667334874096625 139.74079899235488 26.14 35.66734972790053 139.74077445344452 26.14 35.66732681698447 139.7407536032551 26.14 35.667355624385706 139.7407060728713 26.14 35.6673537227509 139.74069469785016 26.14 35.66731803467868 139.74070291300004 26.14 35.66730057149525 139.74073341967843 26.14 35.667230172330314 139.7407309604357 26.14 35.6672275797519 139.74075879890907 26.14 35.66722426292767 139.74078255126145 26.14 35.667220670594375 139.7407996764352 26.14 35.667216625365704 139.7408139302158 26.14 35.6672117670331 139.74082575485195 26.14 35.66720582611865 139.74083636569497 26.14 35.66719871265515 139.7408459837649 26.14 35.66719051678008 139.74085460895762 26.14 35.66718114835642 139.7408622413771 26.14 35.6671706975216 139.7408688809193 26.14 35.66715754231368 139.7408751922036 26.14 35.66714312399621 139.74087995852815 26.14 35.6671275327067 139.74088317978976 26.14 35.66711121913159 139.74088485546952 26.14 35.66709499425208 139.74088465325914 26.14 35.6670911191821 139.74093271803036 26.14 35.66711681145909 139.74093679746613 26.14 35.667118445797676 139.74097576520114 26.14</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-ea82f5f6-eb3a-4122-a5dc-b7a25dad5820"/>
							<gml:surfaceMember xlink:href="#poly-fd75c8c9-d562-4070-a395-2be3d10304da"/>
							<gml:surfaceMember xlink:href="#poly-435b3b7b-2f1b-48f0-a82c-ee428cdfa579"/>
							<gml:surfaceMember xlink:href="#poly-9a5821a2-6feb-4380-aa7c-64dee152774b"/>
							<gml:surfaceMember xlink:href="#poly-ea404d08-d706-4af2-a7bc-6a23c3e317af"/>
							<gml:surfaceMember xlink:href="#poly-154c63b9-4e77-474d-ba5e-03d0c900a8f7"/>
							<gml:surfaceMember xlink:href="#poly-c5ee1172-f6db-4e11-a50d-e8aac931c5d0"/>
							<gml:surfaceMember xlink:href="#poly-5a73a456-972e-4c86-b67f-a5c48dcbd157"/>
							<gml:surfaceMember xlink:href="#poly-2b4d7e90-5276-40c0-948e-6c02b1ed24c8"/>
							<gml:surfaceMember xlink:href="#poly-47872f20-90a6-4d24-910e-c2181c33b0ba"/>
							<gml:surfaceMember xlink:href="#poly-284ae58c-bc82-4914-bfcd-2ada95fde52d"/>
							<gml:surfaceMember xlink:href="#poly-5de72cd9-2aa5-4658-968c-9d9c0ea67fb3"/>
							<gml:surfaceMember xlink:href="#poly-2335620d-fd02-42c8-9470-7c544e413a73"/>
							<gml:surfaceMember xlink:href="#poly-f24e0c7c-e5be-4291-b829-dddfc7d59a55"/>
							<gml:surfaceMember xlink:href="#poly-a25b9167-5fe2-40a1-ac0c-64007da9b125"/>
							<gml:surfaceMember xlink:href="#poly-3e90ead0-6df6-47fd-ad9e-411c671439b1"/>
							<gml:surfaceMember xlink:href="#poly-c2302c20-cc77-452d-a781-0eec3cdea256"/>
							<gml:surfaceMember xlink:href="#poly-a59dae34-cd28-423f-a537-653911d8a276"/>
							<gml:surfaceMember xlink:href="#poly-914954a0-a94b-4458-b85c-e3096b4bd17b"/>
							<gml:surfaceMember xlink:href="#poly-36c68e88-98da-4b3b-95d3-725cd8dbc583"/>
							<gml:surfaceMember xlink:href="#poly-f136b5f3-dcfb-4b4f-9bc8-a46a15ccafe8"/>
							<gml:surfaceMember xlink:href="#poly-b1d3a403-7446-46b4-aabd-b022cbf75650"/>
							<gml:surfaceMember xlink:href="#poly-9550722f-fb08-4c6e-8547-0621adff55a6"/>
							<gml:surfaceMember xlink:href="#poly-44df88d1-fecf-4fc8-ae66-69913e0c93b9"/>
							<gml:surfaceMember xlink:href="#poly-eeceaa18-4914-46cd-8206-275fec488b6d"/>
							<gml:surfaceMember xlink:href="#poly-fdfc00c3-50d1-49ed-ab0f-5d86afadd62e"/>
							<gml:surfaceMember xlink:href="#poly-b0fe160d-2a50-46c5-8dd2-f3bfa28c2c2c"/>
							<gml:surfaceMember xlink:href="#poly-37d078bc-e0a3-4ead-a6ce-64c10a0fc4f5"/>
							<gml:surfaceMember xlink:href="#poly-f6867408-39fc-4c4f-b0df-7c8060bf47c9"/>
							<gml:surfaceMember xlink:href="#poly-5cb7fe06-9a1f-4852-9b88-1b68674b41b2"/>
							<gml:surfaceMember xlink:href="#poly-c1a35a51-71ec-48fe-8375-29e2ba321cfd"/>
							<gml:surfaceMember xlink:href="#poly-31e12b1c-f317-4124-a66b-ee2fe99858b3"/>
							<gml:surfaceMember xlink:href="#poly-bb98ad53-5a70-4333-b9f2-33d1b22b1ee2"/>
							<gml:surfaceMember xlink:href="#poly-3d0a4912-a469-44ca-bd51-6372a0247670"/>
							<gml:surfaceMember xlink:href="#poly-c34bb817-3ad5-46c9-a830-8abd8f344294"/>
							<gml:surfaceMember xlink:href="#poly-ba889e68-52e4-4852-b07b-60e74681e3f3"/>
							<gml:surfaceMember xlink:href="#poly-5c96bd33-3b42-48fb-a323-98af2f4c9733"/>
							<gml:surfaceMember xlink:href="#poly-dd372502-7b8c-4c11-a771-e23fc3a5b9a5"/>
							<gml:surfaceMember xlink:href="#poly-f5cb6f12-2795-4501-96ff-286538f2a12b"/>
							<gml:surfaceMember xlink:href="#poly-34c499df-a323-4748-8e9c-9b9ee68fea59"/>
							<gml:surfaceMember xlink:href="#poly-9bf6a402-d4f9-4fcc-9325-513504bb6ba9"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-ea82f5f6-eb3a-4122-a5dc-b7a25dad5820">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ea82f5f6-eb3a-4122-a5dc-b7a25dad5820">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ea82f5f6-eb3a-4122-a5dc-b7a25dad5820">
											<gml:posList>35.66728904979959 139.74087139544585 11.3 35.66727365226903 139.74089217936375 11.3 35.667258703047416 139.74090986992468 11.3 35.6672442922734 139.74092446702684 11.3 35.66723294226621 139.74093397951708 11.3 35.66722195119712 139.74094139288448 11.3 35.6672009585338 139.74095356747603 11.3 35.6671814959999 139.74096286838574 11.3 35.66716554619257 139.74096874104177 11.3 35.667150856612366 139.74097240308097 11.3 35.66713292115812 139.740974853818 11.3 35.66711844579764 139.74097576520114 11.3 35.66711681145907 139.74093679746613 11.3 35.667091119182096 139.74093271803034 11.3 35.66709499425208 139.74088465325914 11.3 35.66711121913159 139.7408848554695 11.3 35.66712753270668 139.74088317978973 11.3 35.667143123996205 139.74087995852815 11.3 35.66715754231365 139.7408751922036 11.3 35.6671706975216 139.74086888091932 11.3 35.66718114835642 139.74086224137707 11.3 35.66719051678009 139.74085460895765 11.3 35.66719871265514 139.7408459837649 11.3 35.66720582611863 139.74083636569497 11.3 35.66721176703306 139.74082575485195 11.3 35.66721662536571 139.7408139302158 11.3 35.66722067059437 139.7407996764352 11.3 35.6672242629277 139.74078255126145 11.3 35.66722757975186 139.74075879890907 11.3 35.6672301723303 139.74073096043568 11.3 35.66730057149526 139.74073341967843 11.3 35.66731803467868 139.740702913 11.3 35.667353722750875 139.74069469785016 11.3 35.66735562438569 139.7407060728713 11.3 35.66732681698449 139.74075360325506 11.3 35.66734972790054 139.74077445344452 11.3 35.66733487409658 139.74079899235485 11.3 35.66732100950636 139.74082054773862 11.3 35.66730480550023 139.74084751827283 11.3 35.66728904979959 139.74087139544585 11.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-fd75c8c9-d562-4070-a395-2be3d10304da">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fd75c8c9-d562-4070-a395-2be3d10304da">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fd75c8c9-d562-4070-a395-2be3d10304da">
											<gml:posList>35.66711121913159 139.7408848554695 25.1 35.66709499425208 139.74088465325914 25.1 35.667091119182096 139.74093271803034 25.1 35.66711681145907 139.74093679746613 25.1 35.66711844579764 139.74097576520114 25.1 35.66713292115812 139.740974853818 25.1 35.667150856612366 139.74097240308097 25.1 35.66716554619257 139.74096874104177 25.1 35.6671814959999 139.74096286838574 25.1 35.6672009585338 139.74095356747603 25.1 35.66722195119712 139.74094139288448 25.1 35.66723294226621 139.74093397951708 25.1 35.6672442922734 139.74092446702684 25.1 35.667258703047416 139.74090986992468 25.1 35.66727365226903 139.74089217936375 25.1 35.66728904979959 139.74087139544585 25.1 35.66730480550023 139.74084751827283 25.1 35.66732100950636 139.74082054773862 25.1 35.66733487409658 139.74079899235485 25.1 35.66734972790054 139.74077445344452 25.1 35.66732681698449 139.74075360325506 25.1 35.66735562438569 139.7407060728713 25.1 35.667353722750875 139.74069469785016 25.1 35.66731803467868 139.740702913 25.1 35.66730057149526 139.74073341967843 25.1 35.6672301723303 139.74073096043568 25.1 35.66722757975186 139.74075879890907 25.1 35.6672242629277 139.74078255126145 25.1 35.66722067059437 139.7407996764352 25.1 35.66721662536571 139.7408139302158 25.1 35.66721176703306 139.74082575485195 25.1 35.66720582611863 139.74083636569497 25.1 35.66719871265514 139.7408459837649 25.1 35.66719051678009 139.74085460895765 25.1 35.66718114835642 139.74086224137707 25.1 35.6671706975216 139.74086888091932 25.1 35.66715754231365 139.7408751922036 25.1 35.667143123996205 139.74087995852815 25.1 35.66712753270668 139.74088317978973 25.1 35.66711121913159 139.7408848554695 25.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-435b3b7b-2f1b-48f0-a82c-ee428cdfa579">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-435b3b7b-2f1b-48f0-a82c-ee428cdfa579">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-435b3b7b-2f1b-48f0-a82c-ee428cdfa579">
											<gml:posList>35.66735562438569 139.7407060728713 11.3 35.667353722750875 139.74069469785016 11.3 35.667353722750875 139.74069469785016 25.1 35.66735562438569 139.7407060728713 25.1 35.66735562438569 139.7407060728713 11.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9a5821a2-6feb-4380-aa7c-64dee152774b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9a5821a2-6feb-4380-aa7c-64dee152774b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9a5821a2-6feb-4380-aa7c-64dee152774b">
											<gml:posList>35.66730480550023 139.74084751827283 11.3 35.66732100950636 139.74082054773862 11.3 35.66732100950636 139.74082054773862 25.1 35.66730480550023 139.74084751827283 25.1 35.66730480550023 139.74084751827283 11.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ea404d08-d706-4af2-a7bc-6a23c3e317af">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ea404d08-d706-4af2-a7bc-6a23c3e317af">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ea404d08-d706-4af2-a7bc-6a23c3e317af">
											<gml:posList>35.66720582611863 139.74083636569497 11.3 35.66719871265514 139.7408459837649 11.3 35.66719871265514 139.7408459837649 25.1 35.66720582611863 139.74083636569497 25.1 35.66720582611863 139.74083636569497 11.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-154c63b9-4e77-474d-ba5e-03d0c900a8f7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-154c63b9-4e77-474d-ba5e-03d0c900a8f7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-154c63b9-4e77-474d-ba5e-03d0c900a8f7">
											<gml:posList>35.66719871265514 139.7408459837649 11.3 35.66719051678009 139.74085460895765 11.3 35.66719051678009 139.74085460895765 25.1 35.66719871265514 139.7408459837649 25.1 35.66719871265514 139.7408459837649 11.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c5ee1172-f6db-4e11-a50d-e8aac931c5d0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c5ee1172-f6db-4e11-a50d-e8aac931c5d0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c5ee1172-f6db-4e11-a50d-e8aac931c5d0">
											<gml:posList>35.66719051678009 139.74085460895765 11.3 35.66718114835642 139.74086224137707 11.3 35.66718114835642 139.74086224137707 25.1 35.66719051678009 139.74085460895765 25.1 35.66719051678009 139.74085460895765 11.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5a73a456-972e-4c86-b67f-a5c48dcbd157">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5a73a456-972e-4c86-b67f-a5c48dcbd157">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5a73a456-972e-4c86-b67f-a5c48dcbd157">
											<gml:posList>35.66728904979959 139.74087139544585 11.3 35.66730480550023 139.74084751827283 11.3 35.66730480550023 139.74084751827283 25.1 35.66728904979959 139.74087139544585 25.1 35.66728904979959 139.74087139544585 11.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2b4d7e90-5276-40c0-948e-6c02b1ed24c8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2b4d7e90-5276-40c0-948e-6c02b1ed24c8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2b4d7e90-5276-40c0-948e-6c02b1ed24c8">
											<gml:posList>35.66718114835642 139.74086224137707 11.3 35.6671706975216 139.74086888091932 11.3 35.6671706975216 139.74086888091932 25.1 35.66718114835642 139.74086224137707 25.1 35.66718114835642 139.74086224137707 11.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-47872f20-90a6-4d24-910e-c2181c33b0ba">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-47872f20-90a6-4d24-910e-c2181c33b0ba">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-47872f20-90a6-4d24-910e-c2181c33b0ba">
											<gml:posList>35.6671706975216 139.74086888091932 11.3 35.66715754231365 139.7408751922036 11.3 35.66715754231365 139.7408751922036 25.1 35.6671706975216 139.74086888091932 25.1 35.6671706975216 139.74086888091932 11.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-284ae58c-bc82-4914-bfcd-2ada95fde52d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-284ae58c-bc82-4914-bfcd-2ada95fde52d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-284ae58c-bc82-4914-bfcd-2ada95fde52d">
											<gml:posList>35.66715754231365 139.7408751922036 11.3 35.667143123996205 139.74087995852815 11.3 35.667143123996205 139.74087995852815 25.1 35.66715754231365 139.7408751922036 25.1 35.66715754231365 139.7408751922036 11.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5de72cd9-2aa5-4658-968c-9d9c0ea67fb3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5de72cd9-2aa5-4658-968c-9d9c0ea67fb3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5de72cd9-2aa5-4658-968c-9d9c0ea67fb3">
											<gml:posList>35.667143123996205 139.74087995852815 11.3 35.66712753270668 139.74088317978973 11.3 35.66712753270668 139.74088317978973 25.1 35.667143123996205 139.74087995852815 25.1 35.667143123996205 139.74087995852815 11.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2335620d-fd02-42c8-9470-7c544e413a73">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2335620d-fd02-42c8-9470-7c544e413a73">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2335620d-fd02-42c8-9470-7c544e413a73">
											<gml:posList>35.66727365226903 139.74089217936375 11.3 35.66728904979959 139.74087139544585 11.3 35.66728904979959 139.74087139544585 25.1 35.66727365226903 139.74089217936375 25.1 35.66727365226903 139.74089217936375 11.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f24e0c7c-e5be-4291-b829-dddfc7d59a55">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f24e0c7c-e5be-4291-b829-dddfc7d59a55">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f24e0c7c-e5be-4291-b829-dddfc7d59a55">
											<gml:posList>35.66712753270668 139.74088317978973 11.3 35.66711121913159 139.7408848554695 11.3 35.66711121913159 139.7408848554695 25.1 35.66712753270668 139.74088317978973 25.1 35.66712753270668 139.74088317978973 11.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a25b9167-5fe2-40a1-ac0c-64007da9b125">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a25b9167-5fe2-40a1-ac0c-64007da9b125">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a25b9167-5fe2-40a1-ac0c-64007da9b125">
											<gml:posList>35.66711121913159 139.7408848554695 11.3 35.66709499425208 139.74088465325914 11.3 35.66709499425208 139.74088465325914 25.1 35.66711121913159 139.7408848554695 25.1 35.66711121913159 139.7408848554695 11.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3e90ead0-6df6-47fd-ad9e-411c671439b1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3e90ead0-6df6-47fd-ad9e-411c671439b1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3e90ead0-6df6-47fd-ad9e-411c671439b1">
											<gml:posList>35.667258703047416 139.74090986992468 11.3 35.66727365226903 139.74089217936375 11.3 35.66727365226903 139.74089217936375 25.1 35.667258703047416 139.74090986992468 25.1 35.667258703047416 139.74090986992468 11.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c2302c20-cc77-452d-a781-0eec3cdea256">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c2302c20-cc77-452d-a781-0eec3cdea256">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c2302c20-cc77-452d-a781-0eec3cdea256">
											<gml:posList>35.66709499425208 139.74088465325914 11.3 35.667091119182096 139.74093271803034 11.3 35.667091119182096 139.74093271803034 25.1 35.66709499425208 139.74088465325914 25.1 35.66709499425208 139.74088465325914 11.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a59dae34-cd28-423f-a537-653911d8a276">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a59dae34-cd28-423f-a537-653911d8a276">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a59dae34-cd28-423f-a537-653911d8a276">
											<gml:posList>35.6672442922734 139.74092446702684 11.3 35.667258703047416 139.74090986992468 11.3 35.667258703047416 139.74090986992468 25.1 35.6672442922734 139.74092446702684 25.1 35.6672442922734 139.74092446702684 11.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-914954a0-a94b-4458-b85c-e3096b4bd17b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-914954a0-a94b-4458-b85c-e3096b4bd17b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-914954a0-a94b-4458-b85c-e3096b4bd17b">
											<gml:posList>35.66723294226621 139.74093397951708 11.3 35.6672442922734 139.74092446702684 11.3 35.6672442922734 139.74092446702684 25.1 35.66723294226621 139.74093397951708 25.1 35.66723294226621 139.74093397951708 11.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-36c68e88-98da-4b3b-95d3-725cd8dbc583">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-36c68e88-98da-4b3b-95d3-725cd8dbc583">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-36c68e88-98da-4b3b-95d3-725cd8dbc583">
											<gml:posList>35.667091119182096 139.74093271803034 11.3 35.66711681145907 139.74093679746613 11.3 35.66711681145907 139.74093679746613 25.1 35.667091119182096 139.74093271803034 25.1 35.667091119182096 139.74093271803034 11.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f136b5f3-dcfb-4b4f-9bc8-a46a15ccafe8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f136b5f3-dcfb-4b4f-9bc8-a46a15ccafe8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f136b5f3-dcfb-4b4f-9bc8-a46a15ccafe8">
											<gml:posList>35.66722195119712 139.74094139288448 11.3 35.66723294226621 139.74093397951708 11.3 35.66723294226621 139.74093397951708 25.1 35.66722195119712 139.74094139288448 25.1 35.66722195119712 139.74094139288448 11.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b1d3a403-7446-46b4-aabd-b022cbf75650">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b1d3a403-7446-46b4-aabd-b022cbf75650">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b1d3a403-7446-46b4-aabd-b022cbf75650">
											<gml:posList>35.6672009585338 139.74095356747603 11.3 35.66722195119712 139.74094139288448 11.3 35.66722195119712 139.74094139288448 25.1 35.6672009585338 139.74095356747603 25.1 35.6672009585338 139.74095356747603 11.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9550722f-fb08-4c6e-8547-0621adff55a6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9550722f-fb08-4c6e-8547-0621adff55a6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9550722f-fb08-4c6e-8547-0621adff55a6">
											<gml:posList>35.66711681145907 139.74093679746613 11.3 35.66711844579764 139.74097576520114 11.3 35.66711844579764 139.74097576520114 25.1 35.66711681145907 139.74093679746613 25.1 35.66711681145907 139.74093679746613 11.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-44df88d1-fecf-4fc8-ae66-69913e0c93b9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-44df88d1-fecf-4fc8-ae66-69913e0c93b9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-44df88d1-fecf-4fc8-ae66-69913e0c93b9">
											<gml:posList>35.6671814959999 139.74096286838574 11.3 35.6672009585338 139.74095356747603 11.3 35.6672009585338 139.74095356747603 25.1 35.6671814959999 139.74096286838574 25.1 35.6671814959999 139.74096286838574 11.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-eeceaa18-4914-46cd-8206-275fec488b6d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-eeceaa18-4914-46cd-8206-275fec488b6d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-eeceaa18-4914-46cd-8206-275fec488b6d">
											<gml:posList>35.66716554619257 139.74096874104177 11.3 35.6671814959999 139.74096286838574 11.3 35.6671814959999 139.74096286838574 25.1 35.66716554619257 139.74096874104177 25.1 35.66716554619257 139.74096874104177 11.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-fdfc00c3-50d1-49ed-ab0f-5d86afadd62e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fdfc00c3-50d1-49ed-ab0f-5d86afadd62e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fdfc00c3-50d1-49ed-ab0f-5d86afadd62e">
											<gml:posList>35.667150856612366 139.74097240308097 11.3 35.66716554619257 139.74096874104177 11.3 35.66716554619257 139.74096874104177 25.1 35.667150856612366 139.74097240308097 25.1 35.667150856612366 139.74097240308097 11.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b0fe160d-2a50-46c5-8dd2-f3bfa28c2c2c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b0fe160d-2a50-46c5-8dd2-f3bfa28c2c2c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b0fe160d-2a50-46c5-8dd2-f3bfa28c2c2c">
											<gml:posList>35.66713292115812 139.740974853818 11.3 35.667150856612366 139.74097240308097 11.3 35.667150856612366 139.74097240308097 25.1 35.66713292115812 139.740974853818 25.1 35.66713292115812 139.740974853818 11.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-37d078bc-e0a3-4ead-a6ce-64c10a0fc4f5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-37d078bc-e0a3-4ead-a6ce-64c10a0fc4f5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-37d078bc-e0a3-4ead-a6ce-64c10a0fc4f5">
											<gml:posList>35.66711844579764 139.74097576520114 11.3 35.66713292115812 139.740974853818 11.3 35.66713292115812 139.740974853818 25.1 35.66711844579764 139.74097576520114 25.1 35.66711844579764 139.74097576520114 11.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f6867408-39fc-4c4f-b0df-7c8060bf47c9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f6867408-39fc-4c4f-b0df-7c8060bf47c9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f6867408-39fc-4c4f-b0df-7c8060bf47c9">
											<gml:posList>35.66721176703306 139.74082575485195 11.3 35.66720582611863 139.74083636569497 11.3 35.66720582611863 139.74083636569497 25.1 35.66721176703306 139.74082575485195 25.1 35.66721176703306 139.74082575485195 11.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5cb7fe06-9a1f-4852-9b88-1b68674b41b2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5cb7fe06-9a1f-4852-9b88-1b68674b41b2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5cb7fe06-9a1f-4852-9b88-1b68674b41b2">
											<gml:posList>35.66721662536571 139.7408139302158 11.3 35.66721176703306 139.74082575485195 11.3 35.66721176703306 139.74082575485195 25.1 35.66721662536571 139.7408139302158 25.1 35.66721662536571 139.7408139302158 11.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c1a35a51-71ec-48fe-8375-29e2ba321cfd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c1a35a51-71ec-48fe-8375-29e2ba321cfd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c1a35a51-71ec-48fe-8375-29e2ba321cfd">
											<gml:posList>35.66722067059437 139.7407996764352 11.3 35.66721662536571 139.7408139302158 11.3 35.66721662536571 139.7408139302158 25.1 35.66722067059437 139.7407996764352 25.1 35.66722067059437 139.7407996764352 11.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-31e12b1c-f317-4124-a66b-ee2fe99858b3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-31e12b1c-f317-4124-a66b-ee2fe99858b3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-31e12b1c-f317-4124-a66b-ee2fe99858b3">
											<gml:posList>35.6672242629277 139.74078255126145 11.3 35.66722067059437 139.7407996764352 11.3 35.66722067059437 139.7407996764352 25.1 35.6672242629277 139.74078255126145 25.1 35.6672242629277 139.74078255126145 11.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-bb98ad53-5a70-4333-b9f2-33d1b22b1ee2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bb98ad53-5a70-4333-b9f2-33d1b22b1ee2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bb98ad53-5a70-4333-b9f2-33d1b22b1ee2">
											<gml:posList>35.66722757975186 139.74075879890907 11.3 35.6672242629277 139.74078255126145 11.3 35.6672242629277 139.74078255126145 25.1 35.66722757975186 139.74075879890907 25.1 35.66722757975186 139.74075879890907 11.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3d0a4912-a469-44ca-bd51-6372a0247670">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3d0a4912-a469-44ca-bd51-6372a0247670">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3d0a4912-a469-44ca-bd51-6372a0247670">
											<gml:posList>35.6672301723303 139.74073096043568 11.3 35.66722757975186 139.74075879890907 11.3 35.66722757975186 139.74075879890907 25.1 35.6672301723303 139.74073096043568 25.1 35.6672301723303 139.74073096043568 11.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c34bb817-3ad5-46c9-a830-8abd8f344294">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c34bb817-3ad5-46c9-a830-8abd8f344294">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c34bb817-3ad5-46c9-a830-8abd8f344294">
											<gml:posList>35.66730057149526 139.74073341967843 11.3 35.6672301723303 139.74073096043568 11.3 35.6672301723303 139.74073096043568 25.1 35.66730057149526 139.74073341967843 25.1 35.66730057149526 139.74073341967843 11.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ba889e68-52e4-4852-b07b-60e74681e3f3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ba889e68-52e4-4852-b07b-60e74681e3f3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ba889e68-52e4-4852-b07b-60e74681e3f3">
											<gml:posList>35.66731803467868 139.740702913 11.3 35.66730057149526 139.74073341967843 11.3 35.66730057149526 139.74073341967843 25.1 35.66731803467868 139.740702913 25.1 35.66731803467868 139.740702913 11.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5c96bd33-3b42-48fb-a323-98af2f4c9733">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5c96bd33-3b42-48fb-a323-98af2f4c9733">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5c96bd33-3b42-48fb-a323-98af2f4c9733">
											<gml:posList>35.66732100950636 139.74082054773862 11.3 35.66733487409658 139.74079899235485 11.3 35.66733487409658 139.74079899235485 25.1 35.66732100950636 139.74082054773862 25.1 35.66732100950636 139.74082054773862 11.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-dd372502-7b8c-4c11-a771-e23fc3a5b9a5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-dd372502-7b8c-4c11-a771-e23fc3a5b9a5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-dd372502-7b8c-4c11-a771-e23fc3a5b9a5">
											<gml:posList>35.667353722750875 139.74069469785016 11.3 35.66731803467868 139.740702913 11.3 35.66731803467868 139.740702913 25.1 35.667353722750875 139.74069469785016 25.1 35.667353722750875 139.74069469785016 11.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f5cb6f12-2795-4501-96ff-286538f2a12b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f5cb6f12-2795-4501-96ff-286538f2a12b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f5cb6f12-2795-4501-96ff-286538f2a12b">
											<gml:posList>35.66734972790054 139.74077445344452 11.3 35.66732681698449 139.74075360325506 11.3 35.66732681698449 139.74075360325506 25.1 35.66734972790054 139.74077445344452 25.1 35.66734972790054 139.74077445344452 11.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-34c499df-a323-4748-8e9c-9b9ee68fea59">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-34c499df-a323-4748-8e9c-9b9ee68fea59">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-34c499df-a323-4748-8e9c-9b9ee68fea59">
											<gml:posList>35.66732681698449 139.74075360325506 11.3 35.66735562438569 139.7407060728713 11.3 35.66735562438569 139.7407060728713 25.1 35.66732681698449 139.74075360325506 25.1 35.66732681698449 139.74075360325506 11.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9bf6a402-d4f9-4fcc-9325-513504bb6ba9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9bf6a402-d4f9-4fcc-9325-513504bb6ba9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9bf6a402-d4f9-4fcc-9325-513504bb6ba9">
											<gml:posList>35.66733487409658 139.74079899235485 11.3 35.66734972790054 139.74077445344452 11.3 35.66734972790054 139.74077445344452 25.1 35.66733487409658 139.74079899235485 25.1 35.66733487409658 139.74079899235485 11.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂一丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-526</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">668.53622</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1002</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1210</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>7</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.05</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">12</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">2</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">2</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>