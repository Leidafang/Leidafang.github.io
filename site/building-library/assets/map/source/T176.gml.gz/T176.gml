<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_2e23cbae-5fee-43cc-9779-5011d101d655">
			<core:creationDate>2024-03-15</core:creationDate>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.666767784800086 139.7463257421286 0 35.6666878545935 139.74628085055647 0 35.666669789941636 139.74632918427298 0 35.66674972013048 139.74637407588324 0 35.666767784800086 139.7463257421286 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.666767784800086 139.7463257421286 7.55 35.66674972013048 139.74637407588324 7.55 35.666669789941636 139.74632918427298 7.55 35.6666878545935 139.74628085055647 7.55 35.666767784800086 139.7463257421286 7.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.666767784800086 139.7463257421286 7.55 35.6666878545935 139.74628085055647 7.55 35.6666878545935 139.74628085055647 10.55 35.666767784800086 139.7463257421286 10.55 35.666767784800086 139.7463257421286 7.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6666878545935 139.74628085055647 7.55 35.666669789941636 139.74632918427298 7.55 35.666669789941636 139.74632918427298 10.55 35.6666878545935 139.74628085055647 10.55 35.6666878545935 139.74628085055647 7.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.666669789941636 139.74632918427298 7.55 35.66674972013048 139.74637407588324 7.55 35.66674972013048 139.74637407588324 10.55 35.666669789941636 139.74632918427298 10.55 35.666669789941636 139.74632918427298 7.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66674972013048 139.74637407588324 7.55 35.666767784800086 139.7463257421286 7.55 35.666767784800086 139.7463257421286 10.55 35.66674972013048 139.74637407588324 10.55 35.66674972013048 139.74637407588324 7.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.666767784800086 139.7463257421286 10.55 35.6666878545935 139.74628085055647 10.55 35.666669789941636 139.74632918427298 10.55 35.66674972013048 139.74637407588324 10.55 35.666767784800086 139.7463257421286 10.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-a3281e25-1dee-4e0f-a22c-7b9609ce3641"/>
							<gml:surfaceMember xlink:href="#poly-e8d44361-1d9a-45f3-8667-f91bbb834c44"/>
							<gml:surfaceMember xlink:href="#poly-f0fb1e6d-709b-49d2-bf5b-15205567d098"/>
							<gml:surfaceMember xlink:href="#poly-d6a7f980-9aeb-404a-bca2-49f733d60e95"/>
							<gml:surfaceMember xlink:href="#poly-b7843de3-5ba7-4eb4-8fbb-ea2ad11a9a79"/>
							<gml:surfaceMember xlink:href="#poly-5a0b2289-25e0-41d3-ad2c-89b738090422"/>
							<gml:surfaceMember xlink:href="#poly-1a3be929-bf1c-4032-b877-7690a3916735"/>
							<gml:surfaceMember xlink:href="#poly-928d9bca-4a0f-4c69-8e43-3881adb40f3a"/>
							<gml:surfaceMember xlink:href="#poly-75b54d3d-b670-4816-8a07-fb031bb2f77e"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-a3281e25-1dee-4e0f-a22c-7b9609ce3641">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a3281e25-1dee-4e0f-a22c-7b9609ce3641">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a3281e25-1dee-4e0f-a22c-7b9609ce3641">
											<gml:posList>35.66676778480006 139.7463257421286 7.55 35.66674972013046 139.7463740758832 7.55 35.666669789941615 139.74632918427298 7.55 35.666687854593484 139.74628085055647 7.55 35.66676778480006 139.7463257421286 7.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e8d44361-1d9a-45f3-8667-f91bbb834c44">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e8d44361-1d9a-45f3-8667-f91bbb834c44">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e8d44361-1d9a-45f3-8667-f91bbb834c44">
											<gml:posList>35.666669789941615 139.74632918427298 11.3 35.66674972013046 139.7463740758832 11.3 35.666754236303674 139.74636199796947 12.548 35.666674378076564 139.7463169074672 12.561 35.666669789941615 139.74632918427298 11.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f0fb1e6d-709b-49d2-bf5b-15205567d098">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f0fb1e6d-709b-49d2-bf5b-15205567d098">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f0fb1e6d-709b-49d2-bf5b-15205567d098">
											<gml:posList>35.666758761481425 139.74634990899884 12.823 35.66667883128372 139.74630501740765 12.823 35.666674378076564 139.7463169074672 12.561 35.666754236303674 139.74636199796947 12.548 35.666758761481425 139.74634990899884 12.823</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d6a7f980-9aeb-404a-bca2-49f733d60e95">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d6a7f980-9aeb-404a-bca2-49f733d60e95">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d6a7f980-9aeb-404a-bca2-49f733d60e95">
											<gml:posList>35.66667883128372 139.74630501740765 12.823 35.666758761481425 139.74634990899884 12.823 35.6667632776522 139.74633783108237 12.485 35.66668334745007 139.74629293950073 12.485 35.66667883128372 139.74630501740765 12.823</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b7843de3-5ba7-4eb4-8fbb-ea2ad11a9a79">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b7843de3-5ba7-4eb4-8fbb-ea2ad11a9a79">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b7843de3-5ba7-4eb4-8fbb-ea2ad11a9a79">
											<gml:posList>35.66676778480006 139.7463257421286 11.3 35.666687854593484 139.74628085055647 11.3 35.66668334745007 139.74629293950073 12.485 35.6667632776522 139.74633783108237 12.485 35.66676778480006 139.7463257421286 11.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5a0b2289-25e0-41d3-ad2c-89b738090422">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5a0b2289-25e0-41d3-ad2c-89b738090422">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5a0b2289-25e0-41d3-ad2c-89b738090422">
											<gml:posList>35.66676778480006 139.7463257421286 7.55 35.666687854593484 139.74628085055647 7.55 35.666687854593484 139.74628085055647 11.3 35.66676778480006 139.7463257421286 11.3 35.66676778480006 139.7463257421286 7.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1a3be929-bf1c-4032-b877-7690a3916735">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1a3be929-bf1c-4032-b877-7690a3916735">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1a3be929-bf1c-4032-b877-7690a3916735">
											<gml:posList>35.666669789941615 139.74632918427298 11.3 35.666674378076564 139.7463169074672 12.561 35.66667883128372 139.74630501740765 12.823 35.66668334745007 139.74629293950073 12.485 35.666687854593484 139.74628085055647 11.3 35.666687854593484 139.74628085055647 7.55 35.666669789941615 139.74632918427298 7.55 35.666669789941615 139.74632918427298 11.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-928d9bca-4a0f-4c69-8e43-3881adb40f3a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-928d9bca-4a0f-4c69-8e43-3881adb40f3a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-928d9bca-4a0f-4c69-8e43-3881adb40f3a">
											<gml:posList>35.66676778480006 139.7463257421286 11.3 35.6667632776522 139.74633783108237 12.485 35.666758761481425 139.74634990899884 12.823 35.666754236303674 139.74636199796947 12.548 35.66674972013046 139.7463740758832 11.3 35.66674972013046 139.7463740758832 7.55 35.66676778480006 139.7463257421286 7.55 35.66676778480006 139.7463257421286 11.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-75b54d3d-b670-4816-8a07-fb031bb2f77e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-75b54d3d-b670-4816-8a07-fb031bb2f77e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-75b54d3d-b670-4816-8a07-fb031bb2f77e">
											<gml:posList>35.666669789941615 139.74632918427298 7.55 35.66674972013046 139.7463740758832 7.55 35.66674972013046 139.7463740758832 11.3 35.666669789941615 139.74632918427298 11.3 35.666669789941615 139.74632918427298 7.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-3148</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>6</uro:specifiedFloorAreaRate>
					<uro:surveyYear>0001</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">0</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>