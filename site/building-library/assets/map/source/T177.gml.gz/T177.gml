<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_2e2ff6f0-b7b0-4a81-a725-496d4d9a252d">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001001</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">401</bldg:usage>
			<bldg:measuredHeight uom="m">29.8</bldg:measuredHeight>
			<bldg:storeysAboveGround>9</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.66890316085242 139.7417252721285 0 35.66881404437891 139.741645400587 0 35.668795499735 139.7416764611686 0 35.66872424260522 139.74161258610098 0 35.66874440768351 139.74157887262982 0 35.66863192963832 139.74147815118985 0 35.668530204263696 139.7416484866557 0 35.66862680725696 139.74173508743658 0 35.66865561453432 139.7416868938722 0 35.66874283684016 139.74176511056044 0 35.66871366957063 139.74181407778227 0 35.66880233499594 139.74189361854476 0 35.6688348332633 139.74183923493408 0 35.668846919879954 139.74185004626966 0 35.66888211863411 139.7417909097252 0 35.668870302591955 139.7417803190059 0 35.66890316085242 139.7417252721285 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66890316085242 139.7417252721285 15.47 35.668870302591955 139.7417803190059 15.47 35.66888211863411 139.7417909097252 15.47 35.668846919879954 139.74185004626966 15.47 35.6688348332633 139.74183923493408 15.47 35.66880233499594 139.74189361854476 15.47 35.66871366957063 139.74181407778227 15.47 35.66874283684016 139.74176511056044 15.47 35.66865561453432 139.7416868938722 15.47 35.66862680725696 139.74173508743658 15.47 35.668530204263696 139.7416484866557 15.47 35.66863192963832 139.74147815118985 15.47 35.66874440768351 139.74157887262982 15.47 35.66872424260522 139.74161258610098 15.47 35.668795499735 139.7416764611686 15.47 35.66881404437891 139.741645400587 15.47 35.66890316085242 139.7417252721285 15.47</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66890316085242 139.7417252721285 15.47 35.66881404437891 139.741645400587 15.47 35.66881404437891 139.741645400587 45.24 35.66890316085242 139.7417252721285 45.24 35.66890316085242 139.7417252721285 15.47</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66881404437891 139.741645400587 15.47 35.668795499735 139.7416764611686 15.47 35.668795499735 139.7416764611686 45.24 35.66881404437891 139.741645400587 45.24 35.66881404437891 139.741645400587 15.47</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668795499735 139.7416764611686 15.47 35.66872424260522 139.74161258610098 15.47 35.66872424260522 139.74161258610098 45.24 35.668795499735 139.7416764611686 45.24 35.668795499735 139.7416764611686 15.47</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66872424260522 139.74161258610098 15.47 35.66874440768351 139.74157887262982 15.47 35.66874440768351 139.74157887262982 45.24 35.66872424260522 139.74161258610098 45.24 35.66872424260522 139.74161258610098 15.47</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66874440768351 139.74157887262982 15.47 35.66863192963832 139.74147815118985 15.47 35.66863192963832 139.74147815118985 45.24 35.66874440768351 139.74157887262982 45.24 35.66874440768351 139.74157887262982 15.47</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66863192963832 139.74147815118985 15.47 35.668530204263696 139.7416484866557 15.47 35.668530204263696 139.7416484866557 45.24 35.66863192963832 139.74147815118985 45.24 35.66863192963832 139.74147815118985 15.47</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668530204263696 139.7416484866557 15.47 35.66862680725696 139.74173508743658 15.47 35.66862680725696 139.74173508743658 45.24 35.668530204263696 139.7416484866557 45.24 35.668530204263696 139.7416484866557 15.47</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66862680725696 139.74173508743658 15.47 35.66865561453432 139.7416868938722 15.47 35.66865561453432 139.7416868938722 45.24 35.66862680725696 139.74173508743658 45.24 35.66862680725696 139.74173508743658 15.47</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66865561453432 139.7416868938722 15.47 35.66874283684016 139.74176511056044 15.47 35.66874283684016 139.74176511056044 45.24 35.66865561453432 139.7416868938722 45.24 35.66865561453432 139.7416868938722 15.47</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66874283684016 139.74176511056044 15.47 35.66871366957063 139.74181407778227 15.47 35.66871366957063 139.74181407778227 45.24 35.66874283684016 139.74176511056044 45.24 35.66874283684016 139.74176511056044 15.47</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66871366957063 139.74181407778227 15.47 35.66880233499594 139.74189361854476 15.47 35.66880233499594 139.74189361854476 45.24 35.66871366957063 139.74181407778227 45.24 35.66871366957063 139.74181407778227 15.47</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66880233499594 139.74189361854476 15.47 35.6688348332633 139.74183923493408 15.47 35.6688348332633 139.74183923493408 45.24 35.66880233499594 139.74189361854476 45.24 35.66880233499594 139.74189361854476 15.47</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6688348332633 139.74183923493408 15.47 35.668846919879954 139.74185004626966 15.47 35.668846919879954 139.74185004626966 45.24 35.6688348332633 139.74183923493408 45.24 35.6688348332633 139.74183923493408 15.47</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668846919879954 139.74185004626966 15.47 35.66888211863411 139.7417909097252 15.47 35.66888211863411 139.7417909097252 45.24 35.668846919879954 139.74185004626966 45.24 35.668846919879954 139.74185004626966 15.47</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66888211863411 139.7417909097252 15.47 35.668870302591955 139.7417803190059 15.47 35.668870302591955 139.7417803190059 45.24 35.66888211863411 139.7417909097252 45.24 35.66888211863411 139.7417909097252 15.47</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668870302591955 139.7417803190059 15.47 35.66890316085242 139.7417252721285 15.47 35.66890316085242 139.7417252721285 45.24 35.668870302591955 139.7417803190059 45.24 35.668870302591955 139.7417803190059 15.47</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66890316085242 139.7417252721285 45.24 35.66881404437891 139.741645400587 45.24 35.668795499735 139.7416764611686 45.24 35.66872424260522 139.74161258610098 45.24 35.66874440768351 139.74157887262982 45.24 35.66863192963832 139.74147815118985 45.24 35.668530204263696 139.7416484866557 45.24 35.66862680725696 139.74173508743658 45.24 35.66865561453432 139.7416868938722 45.24 35.66874283684016 139.74176511056044 45.24 35.66871366957063 139.74181407778227 45.24 35.66880233499594 139.74189361854476 45.24 35.6688348332633 139.74183923493408 45.24 35.668846919879954 139.74185004626966 45.24 35.66888211863411 139.7417909097252 45.24 35.668870302591955 139.7417803190059 45.24 35.66890316085242 139.7417252721285 45.24</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-e1e47cd8-2d89-4867-9a05-f8826cbec5f7"/>
							<gml:surfaceMember xlink:href="#poly-80024b1a-9eb9-4da8-9ba5-a3af4a830879"/>
							<gml:surfaceMember xlink:href="#poly-c4619bf2-d2ea-4313-b84c-26ea46a00179"/>
							<gml:surfaceMember xlink:href="#poly-c26b516d-262f-4979-bcb3-42b92baa0e89"/>
							<gml:surfaceMember xlink:href="#poly-9bcb826e-2cf9-4430-b1ea-781e8d0b8b94"/>
							<gml:surfaceMember xlink:href="#poly-41eb5184-0816-428b-9a37-ba23a9d31e49"/>
							<gml:surfaceMember xlink:href="#poly-cbe4a53d-9499-4bb5-9722-7f5ef66e29ae"/>
							<gml:surfaceMember xlink:href="#poly-34a51592-e0c0-484f-8174-beae6ffc73d1"/>
							<gml:surfaceMember xlink:href="#poly-5cba4139-6a04-4725-ad1c-fb92e8efe81a"/>
							<gml:surfaceMember xlink:href="#poly-c66013d6-a99e-4cdd-9bb8-a762d3d58ecb"/>
							<gml:surfaceMember xlink:href="#poly-b455dd89-98aa-4934-a07f-cf3052683cde"/>
							<gml:surfaceMember xlink:href="#poly-d96bea3d-6d93-45a8-b39a-4cf7a2010afb"/>
							<gml:surfaceMember xlink:href="#poly-f5eab0c9-34ba-4941-8bf4-df5479657bab"/>
							<gml:surfaceMember xlink:href="#poly-1f11d068-d621-4209-bd59-cccbea4621b6"/>
							<gml:surfaceMember xlink:href="#poly-3ae363c1-a4f3-4144-a1fc-9946ce9d0ad6"/>
							<gml:surfaceMember xlink:href="#poly-60302d18-2344-4583-aecc-f2e4cc9c8a76"/>
							<gml:surfaceMember xlink:href="#poly-78e349b5-dd1e-4f52-b0fa-3a6c3cb94724"/>
							<gml:surfaceMember xlink:href="#poly-ea95a036-e7d6-4eb8-9095-88b090161537"/>
							<gml:surfaceMember xlink:href="#poly-d8bb573e-8ff4-47fa-b311-358309747baf"/>
							<gml:surfaceMember xlink:href="#poly-a608719b-fb98-4ab7-aeab-ba80176cd9da"/>
							<gml:surfaceMember xlink:href="#poly-51c97761-b96d-4628-95a7-768878925d9c"/>
							<gml:surfaceMember xlink:href="#poly-0b023086-3803-44bb-baf0-6091dae8a54c"/>
							<gml:surfaceMember xlink:href="#poly-d790a865-db4f-4ff6-9545-0f53973e456f"/>
							<gml:surfaceMember xlink:href="#poly-7fc4882e-3da3-455a-8efb-8d58fcd59b34"/>
							<gml:surfaceMember xlink:href="#poly-93fed382-c0e8-4526-b554-76c2e9ada3ac"/>
							<gml:surfaceMember xlink:href="#poly-a6dcbf17-ec8f-4079-8588-0a2134949b67"/>
							<gml:surfaceMember xlink:href="#poly-8af6cada-f731-4bde-9a9d-0c3877f6f9f2"/>
							<gml:surfaceMember xlink:href="#poly-baaa77bd-637a-46a7-8574-b9bca437683c"/>
							<gml:surfaceMember xlink:href="#poly-5a0b487c-2917-4254-9bbf-a728ce516d25"/>
							<gml:surfaceMember xlink:href="#poly-3a282ea8-8c24-4607-9604-04057bfb5727"/>
							<gml:surfaceMember xlink:href="#poly-569cf1f7-f53f-454e-8b87-707b051eb252"/>
							<gml:surfaceMember xlink:href="#poly-db8cac79-fdee-4cfa-a14b-fcfb9f57de79"/>
							<gml:surfaceMember xlink:href="#poly-a977ebf2-b9d7-4f1a-b4b9-1183c2447b3f"/>
							<gml:surfaceMember xlink:href="#poly-6ee9ef1b-8d8a-4e6b-9bf4-92501b79abce"/>
							<gml:surfaceMember xlink:href="#poly-c3ea497a-2894-4e7e-b11c-f660d5ddfcde"/>
							<gml:surfaceMember xlink:href="#poly-c3202439-b056-495d-a924-61ecf69f230b"/>
							<gml:surfaceMember xlink:href="#poly-bd836709-ebd4-4405-9d8b-3eb33f91f3f2"/>
							<gml:surfaceMember xlink:href="#poly-fa7930ab-da2d-4579-8a91-52e7ab0a6838"/>
							<gml:surfaceMember xlink:href="#poly-961b1b61-8d84-4e2e-a251-fb4f874f980f"/>
							<gml:surfaceMember xlink:href="#poly-0d8cc3a1-14fe-459d-b000-acaeeffb1765"/>
							<gml:surfaceMember xlink:href="#poly-54fc2dd5-cf7c-4440-a64a-48407e132fe7"/>
							<gml:surfaceMember xlink:href="#poly-04774235-c003-44aa-b2a2-ea2e6ff2c1ec"/>
							<gml:surfaceMember xlink:href="#poly-b17b9141-f03b-4bd5-859f-da0257769425"/>
							<gml:surfaceMember xlink:href="#poly-75752dfb-a412-48b4-9ab5-e7ff5b2db3b0"/>
							<gml:surfaceMember xlink:href="#poly-06c6fbc0-fe6a-4902-b82b-f2466780d2e1"/>
							<gml:surfaceMember xlink:href="#poly-3d2a1754-470e-4a9a-96d6-b0913b26636c"/>
							<gml:surfaceMember xlink:href="#poly-bca0d7ed-a6e7-4386-84b3-66d4b2139f08"/>
							<gml:surfaceMember xlink:href="#poly-f89ea899-d104-4110-9bb6-b7bae55eb7b9"/>
							<gml:surfaceMember xlink:href="#poly-860bcc8d-c4e4-4dc6-94e8-b31fb63d47c4"/>
							<gml:surfaceMember xlink:href="#poly-df9066d7-e360-4552-9dc4-2fd5ed410a3e"/>
							<gml:surfaceMember xlink:href="#poly-afe37983-7151-4dd9-9ad2-e329beefc7a5"/>
							<gml:surfaceMember xlink:href="#poly-d974826d-4be4-4943-8c88-5f9c97ed19b0"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_2e2ff6f0-b7b0-4a81-a725-496d4d9a252d_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7c8ec137-5a3a-4388-896b-e43082693a3c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7c8ec137-5a3a-4388-896b-e43082693a3c_0">
											<gml:posList>35.6687269657186 139.7416375249258 45.899 35.66880149738111 139.74170476531845 46.899 35.6687269657186 139.7416375249258 46.899 35.6687269657186 139.7416375249258 45.899</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d71a8925-e28c-4fe2-9854-ca52524777ca">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d71a8925-e28c-4fe2-9854-ca52524777ca_0">
											<gml:posList>35.6687269657186 139.7416375249258 45.899 35.66880149738111 139.74170476531845 45.899 35.66880149738111 139.74170476531845 46.899 35.6687269657186 139.7416375249258 45.899</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-05c63970-a724-4041-aa81-346fc8f1a73c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-05c63970-a724-4041-aa81-346fc8f1a73c_0">
											<gml:posList>35.66880149738111 139.74170476531845 45.899 35.66882020422895 139.74167363827937 46.899 35.66880149738111 139.74170476531845 46.899 35.66880149738111 139.74170476531845 45.899</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-103c1382-d8cf-4131-8125-b526616ac3d6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-103c1382-d8cf-4131-8125-b526616ac3d6_0">
											<gml:posList>35.66880149738111 139.74170476531845 45.899 35.66882020422895 139.74167363827937 45.899 35.66882020422895 139.74167363827937 46.899 35.66880149738111 139.74170476531845 45.899</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-310106a3-b26d-444b-bf17-3435b73005c9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-310106a3-b26d-444b-bf17-3435b73005c9_0">
											<gml:posList>35.66863666426392 139.7415049544549 43.7 35.6686792294608 139.74154350051964 46.899 35.6686792294608 139.74154350051964 43.7 35.66863666426392 139.7415049544549 43.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6e9e860c-791d-44e3-bd67-883b1ad27161">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6e9e860c-791d-44e3-bd67-883b1ad27161_0">
											<gml:posList>35.66863666426392 139.7415049544549 43.7 35.66863666426392 139.7415049544549 46.899 35.6686792294608 139.74154350051964 46.899 35.66863666426392 139.7415049544549 43.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-25143b11-8011-4ea9-8178-f83755bce8d9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-25143b11-8011-4ea9-8178-f83755bce8d9_0">
											<gml:posList>35.668677825113086 139.74154585493062 43.7 35.668637478818056 139.74150930565375 46.899 35.668637478818056 139.74150930565375 43.7 35.668677825113086 139.74154585493062 43.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d58d4888-fad6-4d2c-8d5c-672cdcf35911">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d58d4888-fad6-4d2c-8d5c-672cdcf35911_0">
											<gml:posList>35.668677825113086 139.74154585493062 43.7 35.668677825113086 139.74154585493062 46.899 35.668637478818056 139.74150930565375 46.899 35.668677825113086 139.74154585493062 43.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f47283d9-a6cd-43b1-8f13-e4a6b7118661">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f47283d9-a6cd-43b1-8f13-e4a6b7118661_0">
											<gml:posList>35.66865991195235 139.7415420866506 43.7 35.668643243724574 139.7415278563659 47.999 35.66865991195235 139.7415420866506 47.999 35.66865991195235 139.7415420866506 43.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d92d3637-8da9-4981-a4d0-d2ed10dce362">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d92d3637-8da9-4981-a4d0-d2ed10dce362_0">
											<gml:posList>35.66865991195235 139.7415420866506 43.7 35.668643243724574 139.7415278563659 43.7 35.668643243724574 139.7415278563659 47.999 35.66865991195235 139.7415420866506 43.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d506d804-e871-4704-8e7d-46fef458c674">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d506d804-e871-4704-8e7d-46fef458c674_0">
											<gml:posList>35.668643243724574 139.7415278563659 43.7 35.66863445810914 139.74154331980566 47.999 35.668643243724574 139.7415278563659 47.999 35.668643243724574 139.7415278563659 43.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-700759e8-cd88-41d6-b9c5-a86a0130232c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-700759e8-cd88-41d6-b9c5-a86a0130232c_0">
											<gml:posList>35.668643243724574 139.7415278563659 43.7 35.66863445810914 139.74154331980566 43.7 35.66863445810914 139.74154331980566 47.999 35.668643243724574 139.7415278563659 43.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-56df6941-ea19-4d5a-9301-be5a7ad36478">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-56df6941-ea19-4d5a-9301-be5a7ad36478_0">
											<gml:posList>35.66865991195235 139.7415420866506 47.999 35.668643243724574 139.7415278563659 47.999 35.66863445810914 139.74154331980566 47.999 35.66865991195235 139.7415420866506 47.999</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-09964a51-c478-4ca1-a765-71ca8c83fe24">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-09964a51-c478-4ca1-a765-71ca8c83fe24_0">
											<gml:posList>35.66865113534043 139.74155753903574 47.999 35.66865991195235 139.7415420866506 47.999 35.66863445810914 139.74154331980566 47.999 35.66865113534043 139.74155753903574 47.999</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-75fb0863-eb92-472f-9040-2ed3f65d2af6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-75fb0863-eb92-472f-9040-2ed3f65d2af6_0">
											<gml:posList>35.6686792294608 139.74154350051964 43.7 35.668677825113086 139.74154585493062 46.899 35.668677825113086 139.74154585493062 43.7 35.6686792294608 139.74154350051964 43.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5de25fbd-6960-445e-9356-622baaea8380">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5de25fbd-6960-445e-9356-622baaea8380_0">
											<gml:posList>35.6686792294608 139.74154350051964 43.7 35.6686792294608 139.74154350051964 46.899 35.668677825113086 139.74154585493062 46.899 35.6686792294608 139.74154350051964 43.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-71602cab-a3ca-49c3-8f23-be7065880037">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-71602cab-a3ca-49c3-8f23-be7065880037_0">
											<gml:posList>35.668586647186714 139.7415879010139 43.7 35.66863666426392 139.7415049544549 46.899 35.66863666426392 139.7415049544549 43.7 35.668586647186714 139.7415879010139 43.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0db494ed-8fc2-4381-b337-b23001f43c73">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0db494ed-8fc2-4381-b337-b23001f43c73_0">
											<gml:posList>35.668586647186714 139.7415879010139 43.7 35.668586647186714 139.7415879010139 46.899 35.66863666426392 139.7415049544549 46.899 35.668586647186714 139.7415879010139 43.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-52443cbc-d1bb-451b-aa7e-7a317dbf4021">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-52443cbc-d1bb-451b-aa7e-7a317dbf4021_0">
											<gml:posList>35.668637478818056 139.74150930565375 43.7 35.668590396509444 139.74158738860731 46.899 35.668590396509444 139.74158738860731 43.7 35.668637478818056 139.74150930565375 43.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ef9bb97d-f8bb-4036-9ad6-4170f72b41dd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ef9bb97d-f8bb-4036-9ad6-4170f72b41dd_0">
											<gml:posList>35.668637478818056 139.74150930565375 43.7 35.668637478818056 139.74150930565375 46.899 35.668590396509444 139.74158738860731 46.899 35.668637478818056 139.74150930565375 43.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-66b882c7-3cb5-43f7-96a8-a9ac9b1c546c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-66b882c7-3cb5-43f7-96a8-a9ac9b1c546c_0">
											<gml:posList>35.66865113534043 139.74155753903574 43.7 35.66865991195235 139.7415420866506 47.999 35.66865113534043 139.74155753903574 47.999 35.66865113534043 139.74155753903574 43.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-abedac30-86f9-4d59-8487-d639b1c4dce6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-abedac30-86f9-4d59-8487-d639b1c4dce6_0">
											<gml:posList>35.66865113534043 139.74155753903574 43.7 35.66865991195235 139.7415420866506 43.7 35.66865991195235 139.7415420866506 47.999 35.66865113534043 139.74155753903574 43.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-153eebad-acf2-4b14-b365-da9ff2e19407">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-153eebad-acf2-4b14-b365-da9ff2e19407_0">
											<gml:posList>35.66865113534043 139.74155753903574 43.7 35.66863445810914 139.74154331980566 47.999 35.66863445810914 139.74154331980566 43.7 35.66865113534043 139.74155753903574 43.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a15b41b9-20f8-443f-8454-fcea47c50f85">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a15b41b9-20f8-443f-8454-fcea47c50f85_0">
											<gml:posList>35.66865113534043 139.74155753903574 43.7 35.66865113534043 139.74155753903574 47.999 35.66863445810914 139.74154331980566 47.999 35.66865113534043 139.74155753903574 43.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b4daeaf7-1407-4ea2-99de-3e3db8d638c2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b4daeaf7-1407-4ea2-99de-3e3db8d638c2_0">
											<gml:posList>35.668657598150254 139.74165215186503 46.899 35.66868255271125 139.74161077805772 46.899 35.668657721449264 139.7416483518924 46.899 35.668657598150254 139.74165215186503 46.899</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2dc779da-2a0b-4a63-863e-17b0255fccb9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2dc779da-2a0b-4a63-863e-17b0255fccb9_0">
											<gml:posList>35.668657598150254 139.74165215186503 46.899 35.668590396509444 139.74158738860731 46.899 35.668586647186714 139.7415879010139 46.899 35.668657598150254 139.74165215186503 46.899</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c2d3b221-28b0-4f62-95d4-27211420a822">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c2d3b221-28b0-4f62-95d4-27211420a822_0">
											<gml:posList>35.668590396509444 139.74158738860731 46.899 35.66863666426392 139.7415049544549 46.899 35.668586647186714 139.7415879010139 46.899 35.668590396509444 139.74158738860731 46.899</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-25268ae6-25f6-44a6-89c5-311dcce7c82e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-25268ae6-25f6-44a6-89c5-311dcce7c82e_0">
											<gml:posList>35.668677825113086 139.74154585493062 46.899 35.6686792294608 139.74154350051964 46.899 35.668637478818056 139.74150930565375 46.899 35.668677825113086 139.74154585493062 46.899</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a99d742e-2b7d-4e1b-92d6-77f2b3459a72">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a99d742e-2b7d-4e1b-92d6-77f2b3459a72_0">
											<gml:posList>35.668637478818056 139.74150930565375 46.899 35.6686792294608 139.74154350051964 46.899 35.66863666426392 139.7415049544549 46.899 35.668637478818056 139.74150930565375 46.899</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7ae2c963-2559-4618-81bf-5e052352f39e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7ae2c963-2559-4618-81bf-5e052352f39e_0">
											<gml:posList>35.668657721449264 139.7416483518924 46.899 35.66868255271125 139.74161077805772 46.899 35.66868114561087 139.74160952042044 46.899 35.668657721449264 139.7416483518924 46.899</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-77caa7e7-eaeb-4bc7-bfff-cbf16a533a68">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-77caa7e7-eaeb-4bc7-bfff-cbf16a533a68_0">
											<gml:posList>35.668590396509444 139.74158738860731 46.899 35.668637478818056 139.74150930565375 46.899 35.66863666426392 139.7415049544549 46.899 35.668590396509444 139.74158738860731 46.899</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-998ca073-5d5e-4b93-a375-6067a03aa9e2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-998ca073-5d5e-4b93-a375-6067a03aa9e2_0">
											<gml:posList>35.668657598150254 139.74165215186503 46.899 35.668657721449264 139.7416483518924 46.899 35.668590396509444 139.74158738860731 46.899 35.668657598150254 139.74165215186503 46.899</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bc2268b3-6e3e-4bbc-bfe3-ce03794b1689">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bc2268b3-6e3e-4bbc-bfe3-ce03794b1689_0">
											<gml:posList>35.66868114561087 139.74160952042044 46.899 35.66868255271125 139.74161077805772 43.7 35.66868114561087 139.74160952042044 43.7 35.66868114561087 139.74160952042044 46.899</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c3e09cb4-7aa5-4b82-8a8b-f010c65c1717">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c3e09cb4-7aa5-4b82-8a8b-f010c65c1717_0">
											<gml:posList>35.66868114561087 139.74160952042044 46.899 35.66868255271125 139.74161077805772 46.899 35.66868255271125 139.74161077805772 43.7 35.66868114561087 139.74160952042044 46.899</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-098ca7f1-2b9c-4cc3-8c44-d6dd4bd922c5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-098ca7f1-2b9c-4cc3-8c44-d6dd4bd922c5_0">
											<gml:posList>35.668590396509444 139.74158738860731 43.7 35.668657721449264 139.7416483518924 46.899 35.668657721449264 139.7416483518924 43.7 35.668590396509444 139.74158738860731 43.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-72062083-c505-45aa-86fd-677664b7170f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-72062083-c505-45aa-86fd-677664b7170f_0">
											<gml:posList>35.668590396509444 139.74158738860731 43.7 35.668590396509444 139.74158738860731 46.899 35.668657721449264 139.7416483518924 46.899 35.668590396509444 139.74158738860731 43.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1087b714-ae3f-44d1-8489-9ac97747e7c2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1087b714-ae3f-44d1-8489-9ac97747e7c2_0">
											<gml:posList>35.668586647186714 139.7415879010139 46.899 35.668657598150254 139.74165215186503 43.7 35.668657598150254 139.74165215186503 46.899 35.668586647186714 139.7415879010139 46.899</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7eaacb9d-3db3-47d4-956c-283e515dca92">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7eaacb9d-3db3-47d4-956c-283e515dca92_0">
											<gml:posList>35.668586647186714 139.7415879010139 46.899 35.668586647186714 139.7415879010139 43.7 35.668657598150254 139.74165215186503 43.7 35.668586647186714 139.7415879010139 46.899</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0da11e92-e484-4d65-bad4-ca90907bb5de">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0da11e92-e484-4d65-bad4-ca90907bb5de_0">
											<gml:posList>35.668657721449264 139.7416483518924 43.7 35.66868114561087 139.74160952042044 46.899 35.66868114561087 139.74160952042044 43.7 35.668657721449264 139.7416483518924 43.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-918dafc4-09bc-4824-80e6-520b7f098f7d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-918dafc4-09bc-4824-80e6-520b7f098f7d_0">
											<gml:posList>35.668657721449264 139.7416483518924 43.7 35.668657721449264 139.7416483518924 46.899 35.66868114561087 139.74160952042044 46.899 35.668657721449264 139.7416483518924 43.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d55bab9b-0a51-4678-a25e-1bd0d4b9519d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d55bab9b-0a51-4678-a25e-1bd0d4b9519d_0">
											<gml:posList>35.66868255271125 139.74161077805772 43.7 35.668657598150254 139.74165215186503 46.899 35.668657598150254 139.74165215186503 43.7 35.66868255271125 139.74161077805772 43.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ef3eed3b-6428-463d-9995-55e1aed55326">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ef3eed3b-6428-463d-9995-55e1aed55326_0">
											<gml:posList>35.66868255271125 139.74161077805772 43.7 35.66868255271125 139.74161077805772 46.899 35.668657598150254 139.74165215186503 46.899 35.66868255271125 139.74161077805772 43.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a22aa68f-ff27-4d0a-adc0-99aec56502ae">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a22aa68f-ff27-4d0a-adc0-99aec56502ae_0">
											<gml:posList>35.66872639432099 139.74163288624595 43.7 35.66870312331811 139.74167162918968 46.899 35.66872639432099 139.74163288624595 46.899 35.66872639432099 139.74163288624595 43.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d9b9397f-abaf-41be-b3ec-27fb36afaa2c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d9b9397f-abaf-41be-b3ec-27fb36afaa2c_0">
											<gml:posList>35.66872639432099 139.74163288624595 43.7 35.66870312331811 139.74167162918968 43.7 35.66870312331811 139.74167162918968 46.899 35.66872639432099 139.74163288624595 43.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-69ce1921-3233-42d3-9d83-e5dcfa653fab">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-69ce1921-3233-42d3-9d83-e5dcfa653fab_0">
											<gml:posList>35.6687269657186 139.7416375249258 46.899 35.66870689953096 139.741670917927 45.899 35.6687269657186 139.7416375249258 45.899 35.6687269657186 139.7416375249258 46.899</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4c03ac88-2699-4cea-a24a-9c2f72365f65">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4c03ac88-2699-4cea-a24a-9c2f72365f65_0">
											<gml:posList>35.6687269657186 139.7416375249258 46.899 35.66870689953096 139.741670917927 46.899 35.66870689953096 139.741670917927 45.899 35.6687269657186 139.7416375249258 46.899</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3d968b03-9f86-4332-b0c6-b5dbc95ec9a7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3d968b03-9f86-4332-b0c6-b5dbc95ec9a7_0">
											<gml:posList>35.66872639432099 139.74163288624595 43.7 35.66880092599448 139.74170013767983 46.899 35.66880092599448 139.74170013767983 43.7 35.66872639432099 139.74163288624595 43.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-33632d88-8e47-4144-9d3e-7a6d6ba25c99">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-33632d88-8e47-4144-9d3e-7a6d6ba25c99_0">
											<gml:posList>35.66872639432099 139.74163288624595 43.7 35.66872639432099 139.74163288624595 46.899 35.66880092599448 139.74170013767983 46.899 35.66872639432099 139.74163288624595 43.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9485a14e-4b1f-4801-bc45-141ed02dae2e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9485a14e-4b1f-4801-bc45-141ed02dae2e_0">
											<gml:posList>35.66880092599448 139.74170013767983 46.899 35.6687269657186 139.7416375249258 46.899 35.66880149738111 139.74170476531845 46.899 35.66880092599448 139.74170013767983 46.899</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6149dbbf-4d2d-4151-a64b-b5eb34ec1ddc">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6149dbbf-4d2d-4151-a64b-b5eb34ec1ddc_0">
											<gml:posList>35.66880092599448 139.74170013767983 46.899 35.66872639432099 139.74163288624595 46.899 35.6687269657186 139.7416375249258 46.899 35.66880092599448 139.74170013767983 46.899</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a7e9dc33-44ef-4de7-b8ff-0d2e519c0ba0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a7e9dc33-44ef-4de7-b8ff-0d2e519c0ba0_0">
											<gml:posList>35.668763060211646 139.74167764703822 45.899 35.66877199904346 139.74168582193448 47.212 35.66877199904346 139.74168582193448 45.899 35.668763060211646 139.74167764703822 45.899</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-77f9eee5-6081-4682-b6e8-4cdff4e25903">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-77f9eee5-6081-4682-b6e8-4cdff4e25903_0">
											<gml:posList>35.668763060211646 139.74167764703822 45.899 35.668763060211646 139.74167764703822 47.212 35.66877199904346 139.74168582193448 47.212 35.668763060211646 139.74167764703822 45.899</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-051d2bce-d80f-4b6c-8b5e-709040beda1f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-051d2bce-d80f-4b6c-8b5e-709040beda1f_0">
											<gml:posList>35.66874916035433 139.7417004398509 45.899 35.668763060211646 139.74167764703822 47.212 35.668763060211646 139.74167764703822 45.899 35.66874916035433 139.7417004398509 45.899</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8f567114-bef8-4443-8a0b-b020b0462d24">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8f567114-bef8-4443-8a0b-b020b0462d24_0">
											<gml:posList>35.66874916035433 139.7417004398509 45.899 35.66874916035433 139.7417004398509 47.212 35.668763060211646 139.74167764703822 47.212 35.66874916035433 139.7417004398509 45.899</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-40bf5e9f-55d1-4318-a58a-191a59397c97">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-40bf5e9f-55d1-4318-a58a-191a59397c97_0">
											<gml:posList>35.668763060211646 139.74167764703822 47.212 35.66875809017089 139.7417086147586 47.212 35.66877199904346 139.74168582193448 47.212 35.668763060211646 139.74167764703822 47.212</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c47ffa92-4fb1-458f-8cee-91fc6e422a95">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c47ffa92-4fb1-458f-8cee-91fc6e422a95_0">
											<gml:posList>35.668763060211646 139.74167764703822 47.212 35.66874916035433 139.7417004398509 47.212 35.66875809017089 139.7417086147586 47.212 35.668763060211646 139.74167764703822 47.212</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-99fd3ece-445f-4158-92a3-99674c61e357">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-99fd3ece-445f-4158-92a3-99674c61e357_0">
											<gml:posList>35.66875809017089 139.7417086147586 45.899 35.66877199904346 139.74168582193448 47.212 35.66875809017089 139.7417086147586 47.212 35.66875809017089 139.7417086147586 45.899</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9f6b141b-dfab-4f55-a0c3-bfa8a2c3713e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9f6b141b-dfab-4f55-a0c3-bfa8a2c3713e_0">
											<gml:posList>35.66875809017089 139.7417086147586 45.899 35.66877199904346 139.74168582193448 45.899 35.66877199904346 139.74168582193448 47.212 35.66875809017089 139.7417086147586 45.899</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ff188c93-ec4b-4ee1-86eb-b166da0146d7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ff188c93-ec4b-4ee1-86eb-b166da0146d7_0">
											<gml:posList>35.668784950870936 139.74170831895975 45.899 35.66877296405655 139.74169838017684 47.212 35.668784950870936 139.74170831895975 47.212 35.668784950870936 139.74170831895975 45.899</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-256be0d9-1f15-4b5b-ab4c-5e524e986e72">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-256be0d9-1f15-4b5b-ab4c-5e524e986e72_0">
											<gml:posList>35.668784950870936 139.74170831895975 45.899 35.66877296405655 139.74169838017684 45.899 35.66877296405655 139.74169838017684 47.212 35.668784950870936 139.74170831895975 45.899</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2c9d19ed-eec7-4561-9aff-e7085b803bcb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2c9d19ed-eec7-4561-9aff-e7085b803bcb_0">
											<gml:posList>35.66874916035433 139.7417004398509 45.899 35.66875809017089 139.7417086147586 47.212 35.66874916035433 139.7417004398509 47.212 35.66874916035433 139.7417004398509 45.899</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0a1d3a67-3e56-4d54-93f7-15a7afa39eb7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0a1d3a67-3e56-4d54-93f7-15a7afa39eb7_0">
											<gml:posList>35.66874916035433 139.7417004398509 45.899 35.66875809017089 139.7417086147586 45.899 35.66875809017089 139.7417086147586 47.212 35.66874916035433 139.7417004398509 45.899</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-239433a0-0626-488c-8356-fd5d8c141772">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-239433a0-0626-488c-8356-fd5d8c141772_0">
											<gml:posList>35.66877296405655 139.74169838017684 45.899 35.668761550369986 139.74171904930918 47.212 35.66877296405655 139.74169838017684 47.212 35.66877296405655 139.74169838017684 45.899</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-15d052ae-dfe0-4408-9a5d-6027ee610ada">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-15d052ae-dfe0-4408-9a5d-6027ee610ada_0">
											<gml:posList>35.66877296405655 139.74169838017684 45.899 35.668761550369986 139.74171904930918 45.899 35.668761550369986 139.74171904930918 47.212 35.66877296405655 139.74169838017684 45.899</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-32c5dd48-2741-4dd9-b1fe-0c7d9e8da629">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-32c5dd48-2741-4dd9-b1fe-0c7d9e8da629_0">
											<gml:posList>35.66877296405655 139.74169838017684 47.212 35.66877353718271 139.7417289880938 47.212 35.668784950870936 139.74170831895975 47.212 35.66877296405655 139.74169838017684 47.212</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-152c3090-b03c-47fd-9f13-c85ccb38c71e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-152c3090-b03c-47fd-9f13-c85ccb38c71e_0">
											<gml:posList>35.66877296405655 139.74169838017684 47.212 35.668761550369986 139.74171904930918 47.212 35.66877353718271 139.7417289880938 47.212 35.66877296405655 139.74169838017684 47.212</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9cb2f672-ac69-4b9b-b2f3-e6fa482472cb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9cb2f672-ac69-4b9b-b2f3-e6fa482472cb_0">
											<gml:posList>35.66870689953096 139.741670917927 45.899 35.668811377317546 139.74176517588572 46.899 35.668811377317546 139.74176517588572 45.899 35.66870689953096 139.741670917927 45.899</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3e3d0d96-4d4e-4c23-9b89-7dbc1f62dc2e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3e3d0d96-4d4e-4c23-9b89-7dbc1f62dc2e_0">
											<gml:posList>35.66870689953096 139.741670917927 45.899 35.66870689953096 139.741670917927 46.899 35.668811377317546 139.74176517588572 46.899 35.66870689953096 139.741670917927 45.899</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3e86040f-9d5e-43b0-8527-ef68684699cb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3e86040f-9d5e-43b0-8527-ef68684699cb_0">
											<gml:posList>35.66877353718271 139.7417289880938 45.899 35.668784950870936 139.74170831895975 47.212 35.66877353718271 139.7417289880938 47.212 35.66877353718271 139.7417289880938 45.899</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7e67e141-4102-4fe1-b6ce-28eb802cd632">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7e67e141-4102-4fe1-b6ce-28eb802cd632_0">
											<gml:posList>35.66877353718271 139.7417289880938 45.899 35.668784950870936 139.74170831895975 45.899 35.668784950870936 139.74170831895975 47.212 35.66877353718271 139.7417289880938 45.899</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2d5dc270-847e-4a74-8d73-846868c801a6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2d5dc270-847e-4a74-8d73-846868c801a6_0">
											<gml:posList>35.668811377317546 139.74176517588572 46.899 35.66870312331811 139.74167162918968 46.899 35.66881195772379 139.74176981456117 46.899 35.668811377317546 139.74176517588572 46.899</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6cbb65ba-4968-49ba-aeb0-77e6203d2f3e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6cbb65ba-4968-49ba-aeb0-77e6203d2f3e_0">
											<gml:posList>35.668811377317546 139.74176517588572 46.899 35.66870689953096 139.741670917927 46.899 35.66870312331811 139.74167162918968 46.899 35.668811377317546 139.74176517588572 46.899</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f8f43898-62d1-4802-8a82-516e7945cbb6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f8f43898-62d1-4802-8a82-516e7945cbb6_0">
											<gml:posList>35.66870312331811 139.74167162918968 43.7 35.66881195772379 139.74176981456117 46.899 35.66870312331811 139.74167162918968 46.899 35.66870312331811 139.74167162918968 43.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9623e05d-40fb-495c-a172-a11cbb287309">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9623e05d-40fb-495c-a172-a11cbb287309_0">
											<gml:posList>35.66870312331811 139.74167162918968 43.7 35.66881195772379 139.74176981456117 43.7 35.66881195772379 139.74176981456117 46.899 35.66870312331811 139.74167162918968 43.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5ea122e5-177b-41e0-b3b8-d3c605986b14">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5ea122e5-177b-41e0-b3b8-d3c605986b14_0">
											<gml:posList>35.668761550369986 139.74171904930918 45.899 35.66877353718271 139.7417289880938 47.212 35.668761550369986 139.74171904930918 47.212 35.668761550369986 139.74171904930918 45.899</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5274e166-034f-48f9-8996-a00e853075a8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5274e166-034f-48f9-8996-a00e853075a8_0">
											<gml:posList>35.668761550369986 139.74171904930918 45.899 35.66877353718271 139.7417289880938 45.899 35.66877353718271 139.7417289880938 47.212 35.668761550369986 139.74171904930918 45.899</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ada1a496-fe5e-4601-8726-b744230502ed">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ada1a496-fe5e-4601-8726-b744230502ed_0">
											<gml:posList>35.66885391759329 139.74169995561374 43.7 35.6688196238274 139.74166901065016 46.899 35.66885391759329 139.74169995561374 46.899 35.66885391759329 139.74169995561374 43.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0fd1e38a-6dab-4529-a424-a5187084f649">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0fd1e38a-6dab-4529-a424-a5187084f649_0">
											<gml:posList>35.66885391759329 139.74169995561374 43.7 35.6688196238274 139.74166901065016 43.7 35.6688196238274 139.74166901065016 46.899 35.66885391759329 139.74169995561374 43.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3b7b275a-4827-45df-bb4c-9052d24edce5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3b7b275a-4827-45df-bb4c-9052d24edce5_0">
											<gml:posList>35.66880092599448 139.74170013767983 43.7 35.6688196238274 139.74166901065016 46.899 35.6688196238274 139.74166901065016 43.7 35.66880092599448 139.74170013767983 43.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f96370f5-33b1-40dd-925f-16ff058ee697">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f96370f5-33b1-40dd-925f-16ff058ee697_0">
											<gml:posList>35.66880092599448 139.74170013767983 43.7 35.66880092599448 139.74170013767983 46.899 35.6688196238274 139.74166901065016 46.899 35.66880092599448 139.74170013767983 43.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d09dd635-4266-4a6c-80b1-747773c70a6c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d09dd635-4266-4a6c-80b1-747773c70a6c_0">
											<gml:posList>35.66885391759329 139.74169995561374 46.899 35.66882020422895 139.74167363827937 46.899 35.66885014137195 139.74170065583033 46.899 35.66885391759329 139.74169995561374 46.899</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-58a99bf9-f4f4-46a9-9f08-9266d1ac5546">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-58a99bf9-f4f4-46a9-9f08-9266d1ac5546_0">
											<gml:posList>35.66885391759329 139.74169995561374 46.899 35.6688196238274 139.74166901065016 46.899 35.66882020422895 139.74167363827937 46.899 35.66885391759329 139.74169995561374 46.899</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-121af2d6-6b9f-40fa-bf50-fe6785db94ec">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-121af2d6-6b9f-40fa-bf50-fe6785db94ec_0">
											<gml:posList>35.66880092599448 139.74170013767983 46.899 35.66880149738111 139.74170476531845 46.899 35.66882020422895 139.74167363827937 46.899 35.66880092599448 139.74170013767983 46.899</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-97a4fa41-18c4-44a9-b028-bd691486aada">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-97a4fa41-18c4-44a9-b028-bd691486aada_0">
											<gml:posList>35.6688196238274 139.74166901065016 46.899 35.66880092599448 139.74170013767983 46.899 35.66882020422895 139.74167363827937 46.899 35.6688196238274 139.74166901065016 46.899</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-17858b28-c268-44a7-8810-b1ffd4a0f081">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-17858b28-c268-44a7-8810-b1ffd4a0f081_0">
											<gml:posList>35.66882020422895 139.74167363827937 45.899 35.66885014137195 139.74170065583033 46.899 35.66882020422895 139.74167363827937 46.899 35.66882020422895 139.74167363827937 45.899</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d831fafd-8244-4488-96a9-453514e9b258">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d831fafd-8244-4488-96a9-453514e9b258_0">
											<gml:posList>35.66882020422895 139.74167363827937 45.899 35.66885014137195 139.74170065583033 45.899 35.66885014137195 139.74170065583033 46.899 35.66882020422895 139.74167363827937 45.899</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e6e47b49-9c5d-488d-a8cd-a27498d0f12b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e6e47b49-9c5d-488d-a8cd-a27498d0f12b_0">
											<gml:posList>35.66885014137195 139.74170065583033 45.899 35.668811377317546 139.74176517588572 46.899 35.66885014137195 139.74170065583033 46.899 35.66885014137195 139.74170065583033 45.899</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7492410d-2c03-414c-8611-ff05655c7c33">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7492410d-2c03-414c-8611-ff05655c7c33_0">
											<gml:posList>35.66885014137195 139.74170065583033 45.899 35.668811377317546 139.74176517588572 45.899 35.668811377317546 139.74176517588572 46.899 35.66885014137195 139.74170065583033 45.899</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5dc1025f-c7ea-4221-8bf4-07e45fa6d6fa">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5dc1025f-c7ea-4221-8bf4-07e45fa6d6fa_0">
											<gml:posList>35.66885014137195 139.74170065583033 46.899 35.66881195772379 139.74176981456117 46.899 35.66885391759329 139.74169995561374 46.899 35.66885014137195 139.74170065583033 46.899</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8989aeaa-cec0-4343-a3bd-3acd8e5f9d8d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8989aeaa-cec0-4343-a3bd-3acd8e5f9d8d_0">
											<gml:posList>35.66885014137195 139.74170065583033 46.899 35.668811377317546 139.74176517588572 46.899 35.66881195772379 139.74176981456117 46.899 35.66885014137195 139.74170065583033 46.899</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1f319978-5e4c-45aa-9b26-48389293eedd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1f319978-5e4c-45aa-9b26-48389293eedd_0">
											<gml:posList>35.66885391759329 139.74169995561374 43.7 35.66881195772379 139.74176981456117 46.899 35.66881195772379 139.74176981456117 43.7 35.66885391759329 139.74169995561374 43.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1962976f-c60e-48e3-bd86-2019174047f8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1962976f-c60e-48e3-bd86-2019174047f8_0">
											<gml:posList>35.66885391759329 139.74169995561374 43.7 35.66885391759329 139.74169995561374 46.899 35.66881195772379 139.74176981456117 46.899 35.66885391759329 139.74169995561374 43.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1c5d3af8-fdf4-4476-9889-0efd5edfcac6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1c5d3af8-fdf4-4476-9889-0efd5edfcac6_0">
											<gml:posList>35.66870689953096 139.741670917927 46.899 35.66872639432099 139.74163288624595 46.899 35.66870312331811 139.74167162918968 46.899 35.66870689953096 139.741670917927 46.899</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e590d723-f61d-413a-90a9-f965c0d20caa">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e590d723-f61d-413a-90a9-f965c0d20caa_0">
											<gml:posList>35.66870689953096 139.741670917927 46.899 35.6687269657186 139.7416375249258 46.899 35.66872639432099 139.74163288624595 46.899 35.66870689953096 139.741670917927 46.899</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bb2cae68-65c5-4e78-a606-93c85874f6d6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bb2cae68-65c5-4e78-a606-93c85874f6d6_0">
											<gml:posList>35.668811377317546 139.74176517588572 45.899 35.66885014137195 139.74170065583033 45.899 35.66880149738111 139.74170476531845 45.899 35.668811377317546 139.74176517588572 45.899</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7cad0ddf-900c-4f09-bc78-8bfba13dc90c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7cad0ddf-900c-4f09-bc78-8bfba13dc90c_0">
											<gml:posList>35.66885014137195 139.74170065583033 45.899 35.66882020422895 139.74167363827937 45.899 35.66880149738111 139.74170476531845 45.899 35.66885014137195 139.74170065583033 45.899</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c3afcf19-da7e-47ae-ae06-924a5130732e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c3afcf19-da7e-47ae-ae06-924a5130732e_0">
											<gml:posList>35.66870689953096 139.741670917927 45.899 35.668811377317546 139.74176517588572 45.899 35.66880149738111 139.74170476531845 45.899 35.66870689953096 139.741670917927 45.899</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fb33605c-0cc4-4b90-a993-9238c0c1911c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fb33605c-0cc4-4b90-a993-9238c0c1911c_0">
											<gml:posList>35.6687269657186 139.7416375249258 45.899 35.66870689953096 139.741670917927 45.899 35.66880149738111 139.74170476531845 45.899 35.6687269657186 139.7416375249258 45.899</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9a83237b-0eec-40f3-abd8-7b3a5955e1cb">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66868255271125 139.74161077805772 43.7 35.668657598150254 139.74165215186503 43.7 35.668657721449264 139.7416483518924 43.7 35.66868255271125 139.74161077805772 43.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a70fdda3-16dc-4751-b291-d322ff96f17a">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668677825113086 139.74154585493062 43.7 35.668637478818056 139.74150930565375 43.7 35.6686792294608 139.74154350051964 43.7 35.668677825113086 139.74154585493062 43.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-db5909d0-e56d-4905-bc8a-649bcef4928b">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668637478818056 139.74150930565375 43.7 35.66863666426392 139.7415049544549 43.7 35.6686792294608 139.74154350051964 43.7 35.668637478818056 139.74150930565375 43.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0f3e4c0b-78f0-4556-ab87-9831d877239c">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668657598150254 139.74165215186503 43.7 35.668586647186714 139.7415879010139 43.7 35.668590396509444 139.74158738860731 43.7 35.668657598150254 139.74165215186503 43.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f22e1cf0-a769-45e1-a174-d8b12456cc31">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66868114561087 139.74160952042044 43.7 35.66868255271125 139.74161077805772 43.7 35.668657721449264 139.7416483518924 43.7 35.66868114561087 139.74160952042044 43.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c1b94688-d0a7-4ed5-88d0-8fc13a69e159">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66863666426392 139.7415049544549 43.7 35.668590396509444 139.74158738860731 43.7 35.668586647186714 139.7415879010139 43.7 35.66863666426392 139.7415049544549 43.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-99990b39-d352-41c1-95e0-33001ebe15a7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668590396509444 139.74158738860731 43.7 35.66863666426392 139.7415049544549 43.7 35.668637478818056 139.74150930565375 43.7 35.668590396509444 139.74158738860731 43.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7409e605-f6eb-41ff-828d-ec42dfa39b05">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668657598150254 139.74165215186503 43.7 35.668590396509444 139.74158738860731 43.7 35.668657721449264 139.7416483518924 43.7 35.668657598150254 139.74165215186503 43.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e15f08ec-7e7d-4d98-b1fc-4523a9b3d0dd">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66863445810914 139.74154331980566 43.7 35.668643243724574 139.7415278563659 43.7 35.66865991195235 139.7415420866506 43.7 35.66863445810914 139.74154331980566 43.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7cb4506a-7846-424d-88db-b185c5743597">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66865113534043 139.74155753903574 43.7 35.66863445810914 139.74154331980566 43.7 35.66865991195235 139.7415420866506 43.7 35.66865113534043 139.74155753903574 43.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d6a9f680-24ce-4e7d-9d89-122557c7e917">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66875809017089 139.7417086147586 45.899 35.668763060211646 139.74167764703822 45.899 35.66877199904346 139.74168582193448 45.899 35.66875809017089 139.7417086147586 45.899</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bfb5ce44-4e0a-4435-833c-e7f1b8908ee4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66875809017089 139.7417086147586 45.899 35.66874916035433 139.7417004398509 45.899 35.668763060211646 139.74167764703822 45.899 35.66875809017089 139.7417086147586 45.899</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-15a36aab-9103-441e-9a9a-ee1fa473ca9b">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66877296405655 139.74169838017684 45.899 35.66877353718271 139.7417289880938 45.899 35.668761550369986 139.74171904930918 45.899 35.66877296405655 139.74169838017684 45.899</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8ef93630-ca75-4efc-9acd-468bb9748d20">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66877296405655 139.74169838017684 45.899 35.668784950870936 139.74170831895975 45.899 35.66877353718271 139.7417289880938 45.899 35.66877296405655 139.74169838017684 45.899</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e2b86d3e-f0d5-4b77-8fd4-f18f5b2e1d75">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6688196238274 139.74166901065016 43.7 35.66885391759329 139.74169995561374 43.7 35.66880092599448 139.74170013767983 43.7 35.6688196238274 139.74166901065016 43.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d41b26d2-4fdf-4e7e-ae74-a524625de510">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66885391759329 139.74169995561374 43.7 35.66881195772379 139.74176981456117 43.7 35.66880092599448 139.74170013767983 43.7 35.66885391759329 139.74169995561374 43.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ce1d7edc-9f19-46fe-9999-3d539e0cb179">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66880092599448 139.74170013767983 43.7 35.66870312331811 139.74167162918968 43.7 35.66872639432099 139.74163288624595 43.7 35.66880092599448 139.74170013767983 43.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4e03de2c-9f19-4c22-8798-19545e14f142">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66880092599448 139.74170013767983 43.7 35.66881195772379 139.74176981456117 43.7 35.66870312331811 139.74167162918968 43.7 35.66880092599448 139.74170013767983 43.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_2e2ff6f0-b7b0-4a81-a725-496d4d9a252d_BuildingInstallation_1061">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-96bf0485-67d7-4d4e-9fa8-e61c91cfc28b">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668885523403866 139.74172846249672 43.7 35.66879864179251 139.74187307711892 43.7 35.66873316621695 139.7418140002989 43.7 35.66876041630111 139.7417686362624 43.7 35.668651527777634 139.7416704068333 43.7 35.668624448763815 139.74171547240346 43.7 35.66855023280438 139.74164851898416 43.7 35.668586647186714 139.7415879010139 43.7 35.668588306856805 139.74158940137264 43.7 35.66855306277785 139.74164807390792 43.7 35.668624022546936 139.74171209280905 43.7 35.668651290587064 139.74166668459523 43.7 35.668763399231075 139.74176782649536 43.7 35.668736131144975 139.74181322369245 43.7 35.668798548962044 139.74186953144545 43.7 35.668883026938104 139.74172890719095 43.7 35.668852873329264 139.7417017020829 43.7 35.66885392660702 139.74169995560345 43.7 35.668885523403866 139.74172846249672 43.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e9dc9850-b58a-45da-a498-ce37956b9b4c">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668728884407344 139.74158856671752 43.7 35.66871073572547 139.741618765236 43.7 35.66872639432099 139.74163288624595 43.7 35.668725287037525 139.74163473219954 43.7 35.668708257405264 139.74161936455636 43.7 35.66872655018909 139.7415890112296 43.7 35.66872071398279 139.74158334024744 43.7 35.6687216592204 139.7415817595834 43.7 35.668728884407344 139.74158856671752 43.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e19b0a41-3025-4193-8f22-fd658490ad4c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e19b0a41-3025-4193-8f22-fd658490ad4c_0">
											<gml:posList>35.66872071397438 139.74158332920143 46.779 35.66872165020668 139.74158175959374 46.779 35.6687216592204 139.7415817595834 43.7 35.66872071398279 139.74158334024744 43.7 35.66872071397438 139.74158332920143 46.779</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3a8ccdaa-f59c-4839-ba30-f09e4e1bc200">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3a8ccdaa-f59c-4839-ba30-f09e4e1bc200_0">
											<gml:posList>35.66872165020668 139.74158175959374 46.779 35.668728884407344 139.74158856671752 46.779 35.668728884407344 139.74158856671752 43.7 35.6687216592204 139.7415817595834 43.7 35.66872165020668 139.74158175959374 46.779</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9556403b-70d9-4e5b-83f0-e76867f66128">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9556403b-70d9-4e5b-83f0-e76867f66128_0">
											<gml:posList>35.66872071398279 139.74158334024744 43.7 35.66872655018909 139.7415890112296 43.7 35.66872655018909 139.7415890112296 46.779 35.66872071397438 139.74158332920143 46.779 35.66872071398279 139.74158334024744 43.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-996f01df-8cd2-422d-9069-154b43c0f48f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-996f01df-8cd2-422d-9069-154b43c0f48f_0">
											<gml:posList>35.668586647186714 139.7415879010139 43.7 35.668586647186714 139.7415879010139 46.779 35.668588306856805 139.74158940137264 46.779 35.668588306856805 139.74158940137264 43.7 35.668586647186714 139.7415879010139 43.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b9d755e0-b83c-46d3-8bae-54ec32c5a9ba">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b9d755e0-b83c-46d3-8bae-54ec32c5a9ba_0">
											<gml:posList>35.668728884407344 139.74158856671752 43.7 35.668728884407344 139.74158856671752 46.779 35.66871073572547 139.741618765236 46.779 35.66871073572547 139.741618765236 43.7 35.668728884407344 139.74158856671752 43.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bababa12-96fe-4c92-93d0-d3e21300f990">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bababa12-96fe-4c92-93d0-d3e21300f990_0">
											<gml:posList>35.668708257405264 139.74161936455636 43.7 35.668708257405264 139.74161936455636 46.779 35.66872655018909 139.7415890112296 46.779 35.66872655018909 139.7415890112296 43.7 35.668708257405264 139.74161936455636 43.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-04619e20-629e-49e6-837a-4bf089a41c4e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-04619e20-629e-49e6-837a-4bf089a41c4e_0">
											<gml:posList>35.66871073572547 139.741618765236 46.779 35.668728884407344 139.74158856671752 46.779 35.66872165020668 139.74158175959374 46.779 35.66872071397438 139.74158332920143 46.779 35.66872655018909 139.7415890112296 46.779 35.668708257405264 139.74161936455636 46.779 35.668725287037525 139.74163473219954 46.779 35.66872639432099 139.74163288624595 46.779 35.66871073572547 139.741618765236 46.779</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-876f4484-c5d3-4e38-83cb-9e94e5f8c83d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-876f4484-c5d3-4e38-83cb-9e94e5f8c83d_0">
											<gml:posList>35.66855023280438 139.74164851898416 43.7 35.66855023280438 139.74164851898416 46.779 35.668586647186714 139.7415879010139 46.779 35.668586647186714 139.7415879010139 43.7 35.66855023280438 139.74164851898416 43.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3681aa38-dec3-486b-9287-d0a7b1538557">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3681aa38-dec3-486b-9287-d0a7b1538557_0">
											<gml:posList>35.668588306856805 139.74158940137264 43.7 35.668588306856805 139.74158940137264 46.779 35.66855306277785 139.74164807390792 46.779 35.66855306277785 139.74164807390792 43.7 35.668588306856805 139.74158940137264 43.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-15c3e8df-68fe-4921-af22-10e79a65e2d4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-15c3e8df-68fe-4921-af22-10e79a65e2d4_0">
											<gml:posList>35.66871073572547 139.741618765236 43.7 35.66871073572547 139.741618765236 46.779 35.66872639432099 139.74163288624595 46.779 35.66872639432099 139.74163288624595 43.7 35.66871073572547 139.741618765236 43.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9fb93161-21f4-4cab-8d20-8ececf8ca57d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9fb93161-21f4-4cab-8d20-8ececf8ca57d_0">
											<gml:posList>35.668725287037525 139.74163473219954 43.7 35.668725287037525 139.74163473219954 46.779 35.668708257405264 139.74161936455636 46.779 35.668708257405264 139.74161936455636 43.7 35.668725287037525 139.74163473219954 43.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-dc3228e8-edd6-4fbd-8e1b-63b00bedf60e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-dc3228e8-edd6-4fbd-8e1b-63b00bedf60e_0">
											<gml:posList>35.66872639432099 139.74163288624595 46.779 35.668725287037525 139.74163473219954 46.779 35.668725287037525 139.74163473219954 43.7 35.66872639432099 139.74163288624595 43.7 35.66872639432099 139.74163288624595 46.779</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-01087712-e46c-4517-9fed-ea131013a925">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-01087712-e46c-4517-9fed-ea131013a925_0">
											<gml:posList>35.66855306277785 139.74164807390792 46.779 35.668624022546936 139.74171209280905 46.779 35.668624022546936 139.74171209280905 43.7 35.66855306277785 139.74164807390792 43.7 35.66855306277785 139.74164807390792 46.779</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-46fcabb6-1c9e-4db2-8791-360f31c4ad44">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-46fcabb6-1c9e-4db2-8791-360f31c4ad44_0">
											<gml:posList>35.668624448763815 139.74171547240346 43.7 35.668624448763815 139.74171547240346 46.779 35.66855023280438 139.74164851898416 46.779 35.66855023280438 139.74164851898416 43.7 35.668624448763815 139.74171547240346 43.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-44cee78a-e878-4aaa-987e-b9aff8630cf8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-44cee78a-e878-4aaa-987e-b9aff8630cf8_0">
											<gml:posList>35.668624022546936 139.74171209280905 43.7 35.668624022546936 139.74171209280905 46.779 35.668651290587064 139.74166668459523 46.779 35.668651290587064 139.74166668459523 43.7 35.668624022546936 139.74171209280905 43.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c320cd7c-b31e-4bb1-9e17-920a9f40eba7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c320cd7c-b31e-4bb1-9e17-920a9f40eba7_0">
											<gml:posList>35.668651527777634 139.7416704068333 43.7 35.668651527777634 139.7416704068333 46.779 35.668624448763815 139.74171547240346 46.779 35.668624448763815 139.74171547240346 43.7 35.668651527777634 139.7416704068333 43.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-854c027e-82ea-4b5e-b11c-036d875a5873">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-854c027e-82ea-4b5e-b11c-036d875a5873_0">
											<gml:posList>35.668852873329264 139.7417017020829 43.7 35.668852873329264 139.7417017020829 46.779 35.66885392660702 139.74169995560345 46.779 35.66885392660702 139.74169995560345 43.7 35.668852873329264 139.7417017020829 43.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ed60a90a-1ac3-4e64-9e64-cd777a18da19">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ed60a90a-1ac3-4e64-9e64-cd777a18da19_0">
											<gml:posList>35.66885392660702 139.74169995560345 43.7 35.66885392660702 139.74169995560345 46.779 35.668885523403866 139.74172846249672 46.779 35.668885523403866 139.74172846249672 43.7 35.66885392660702 139.74169995560345 43.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8b4513d1-4f1c-4937-b8ee-2479740ac054">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8b4513d1-4f1c-4937-b8ee-2479740ac054_0">
											<gml:posList>35.668883026938104 139.74172890719095 46.779 35.668852873329264 139.7417017020829 46.779 35.668852873329264 139.7417017020829 43.7 35.668883026938104 139.74172890719095 43.7 35.668883026938104 139.74172890719095 46.779</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-38676e0e-ae29-4bb6-a50e-a8d5012ed1d6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-38676e0e-ae29-4bb6-a50e-a8d5012ed1d6_0">
											<gml:posList>35.668651290587064 139.74166668459523 43.7 35.668651290587064 139.74166668459523 46.779 35.668763399231075 139.74176782649536 46.779 35.668763399231075 139.74176782649536 43.7 35.668651290587064 139.74166668459523 43.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3bf92749-e2c6-4c48-af1c-4fa15f4726b0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3bf92749-e2c6-4c48-af1c-4fa15f4726b0_0">
											<gml:posList>35.66876041630111 139.7417686362624 43.7 35.66876041630111 139.7417686362624 46.779 35.668651527777634 139.7416704068333 46.779 35.668651527777634 139.7416704068333 43.7 35.66876041630111 139.7417686362624 43.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a6236926-c412-483d-9643-c6ea6eb3588c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a6236926-c412-483d-9643-c6ea6eb3588c_0">
											<gml:posList>35.668852873329264 139.7417017020829 46.779 35.668883026938104 139.74172890719095 46.779 35.668798548962044 139.74186953144545 46.779 35.668736131144975 139.74181322369245 46.779 35.668763399231075 139.74176782649536 46.779 35.668651290587064 139.74166668459523 46.779 35.668624022546936 139.74171209280905 46.779 35.66855306277785 139.74164807390792 46.779 35.668588306856805 139.74158940137264 46.779 35.668586647186714 139.7415879010139 46.779 35.66855023280438 139.74164851898416 46.779 35.668624448763815 139.74171547240346 46.779 35.668651527777634 139.7416704068333 46.779 35.66876041630111 139.7417686362624 46.779 35.66873316621695 139.7418140002989 46.779 35.66879864179251 139.74187307711892 46.779 35.668885523403866 139.74172846249672 46.779 35.66885392660702 139.74169995560345 46.779 35.668852873329264 139.7417017020829 46.779</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6167d234-f097-49d4-b367-e71bbb51b24a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6167d234-f097-49d4-b367-e71bbb51b24a_0">
											<gml:posList>35.668763399231075 139.74176782649536 46.779 35.668736131144975 139.74181322369245 46.779 35.668736131144975 139.74181322369245 43.7 35.668763399231075 139.74176782649536 43.7 35.668763399231075 139.74176782649536 46.779</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e676ce7c-05fc-44f7-b88b-d05e53188a0b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e676ce7c-05fc-44f7-b88b-d05e53188a0b_0">
											<gml:posList>35.66873316621695 139.7418140002989 43.7 35.66873316621695 139.7418140002989 46.779 35.66876041630111 139.7417686362624 46.779 35.66876041630111 139.7417686362624 43.7 35.66873316621695 139.7418140002989 43.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fcd8d0ff-1cca-47ff-99e8-46733bb560de">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fcd8d0ff-1cca-47ff-99e8-46733bb560de_0">
											<gml:posList>35.668798548962044 139.74186953144545 46.779 35.668883026938104 139.74172890719095 46.779 35.668883026938104 139.74172890719095 43.7 35.668798548962044 139.74186953144545 43.7 35.668798548962044 139.74186953144545 46.779</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-53b97bd5-b247-4534-a57d-5207f377e531">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-53b97bd5-b247-4534-a57d-5207f377e531_0">
											<gml:posList>35.668885523403866 139.74172846249672 46.779 35.66879864179251 139.74187307711892 46.779 35.66879864179251 139.74187307711892 43.7 35.668885523403866 139.74172846249672 43.7 35.668885523403866 139.74172846249672 46.779</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-05bd7455-ab04-428c-8f8b-d81c0e5c3ffc">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-05bd7455-ab04-428c-8f8b-d81c0e5c3ffc_0">
											<gml:posList>35.668736131144975 139.74181322369245 43.7 35.668736131144975 139.74181322369245 46.779 35.668798548962044 139.74186953144545 46.779 35.668798548962044 139.74186953144545 43.7 35.668736131144975 139.74181322369245 43.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-45d5009c-d1f1-4ae1-93c3-2473f21ff053">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-45d5009c-d1f1-4ae1-93c3-2473f21ff053_0">
											<gml:posList>35.66879864179251 139.74187307711892 46.779 35.66873316621695 139.7418140002989 46.779 35.66873316621695 139.7418140002989 43.7 35.66879864179251 139.74187307711892 43.7 35.66879864179251 139.74187307711892 46.779</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-e1e47cd8-2d89-4867-9a05-f8826cbec5f7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e1e47cd8-2d89-4867-9a05-f8826cbec5f7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e1e47cd8-2d89-4867-9a05-f8826cbec5f7">
											<gml:posList>35.66883483326331 139.74183923493405 15.47 35.66880233499594 139.74189361854476 15.47 35.668713669570614 139.74181407778227 15.47 35.66874283684017 139.74176511056046 15.47 35.66865561453431 139.7416868938722 15.47 35.66862680725696 139.7417350874366 15.47 35.66853020426368 139.74164848665566 15.47 35.6686319296383 139.74147815118982 15.47 35.668744407683505 139.74157887262982 15.47 35.66872424260523 139.74161258610098 15.47 35.66879549973497 139.74167646116857 15.47 35.66881404437891 139.74164540058698 15.47 35.668903160852416 139.74172527212846 15.47 35.668870302591934 139.74178031900587 15.47 35.66888211863408 139.7417909097252 15.47 35.66884691987995 139.74185004626963 15.47 35.66883483326331 139.74183923493405 15.47</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-80024b1a-9eb9-4da8-9ba5-a3af4a830879">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-80024b1a-9eb9-4da8-9ba5-a3af4a830879">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-80024b1a-9eb9-4da8-9ba5-a3af4a830879">
											<gml:posList>35.66862680725696 139.7417350874366 45.3 35.668625800616105 139.74172704708553 45.3 35.66853678334152 139.74164724198025 45.3 35.66853020426368 139.74164848665566 45.3 35.66862680725696 139.7417350874366 45.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c4619bf2-d2ea-4313-b84c-26ea46a00179">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c4619bf2-d2ea-4313-b84c-26ea46a00179">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c4619bf2-d2ea-4313-b84c-26ea46a00179">
											<gml:posList>35.66853020426368 139.74164848665566 45.3 35.66853678334152 139.74164724198025 45.3 35.66863295433164 139.74148620256372 45.3 35.6686319296383 139.74147815118982 45.3 35.66853020426368 139.74164848665566 45.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c26b516d-262f-4979-bcb3-42b92baa0e89">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c26b516d-262f-4979-bcb3-42b92baa0e89">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c26b516d-262f-4979-bcb3-42b92baa0e89">
											<gml:posList>35.66865561453431 139.7416868938722 45.3 35.66865460788184 139.74167884247285 45.3 35.668625800616105 139.74172704708553 45.3 35.66862680725696 139.7417350874366 45.3 35.66865561453431 139.7416868938722 45.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-9bcb826e-2cf9-4430-b1ea-781e8d0b8b94">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9bcb826e-2cf9-4430-b1ea-781e8d0b8b94">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9bcb826e-2cf9-4430-b1ea-781e8d0b8b94">
											<gml:posList>35.66868160763951 139.74152977863346 45.3 35.66868539598954 139.7415331654261 45.3 35.66868816867164 139.74152851187452 45.3 35.6686319296383 139.74147815118982 45.3 35.66863295433164 139.74148620256372 45.3 35.66868160763951 139.74152977863346 45.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-41eb5184-0816-428b-9a37-ba23a9d31e49">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-41eb5184-0816-428b-9a37-ba23a9d31e49">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-41eb5184-0816-428b-9a37-ba23a9d31e49">
											<gml:posList>35.66868816867164 139.74152851187452 50.303 35.668654239280436 139.74158541564196 50.303 35.66868255271125 139.74161077805772 50.303 35.66869903579625 139.74158313308646 50.303 35.66871324212585 139.7415958639491 50.303 35.66873069745222 139.74156659408476 50.303 35.66868816867164 139.74152851187452 50.303</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-cbe4a53d-9499-4bb5-9722-7f5ef66e29ae">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cbe4a53d-9499-4bb5-9722-7f5ef66e29ae">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cbe4a53d-9499-4bb5-9722-7f5ef66e29ae">
											<gml:posList>35.66874283684017 139.74176511056046 45.3 35.668749397883126 139.7417638548658 45.3 35.66865460788184 139.74167884247285 45.3 35.66865561453431 139.7416868938722 45.3 35.66874283684017 139.74176511056046 45.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-34a51592-e0c0-484f-8174-beae6ffc73d1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-34a51592-e0c0-484f-8174-beae6ffc73d1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-34a51592-e0c0-484f-8174-beae6ffc73d1">
											<gml:posList>35.66871324212585 139.7415958639491 43.7 35.66869903579625 139.74158313308646 43.7 35.66868255271125 139.74161077805772 43.7 35.668654239280436 139.74158541564196 43.7 35.66868539598954 139.7415331654261 43.7 35.66868160763951 139.74152977863346 43.7 35.66863295433164 139.74148620256372 43.7 35.66853678334152 139.74164724198025 43.7 35.668625800616105 139.74172704708553 43.7 35.66865460788184 139.74167884247285 43.7 35.668749397883126 139.7417638548658 43.7 35.66872023963625 139.74181283312782 43.7 35.66880131935195 139.74188557818437 43.7 35.66889658177418 139.74172651680328 43.7 35.66881506005576 139.7416534630376 43.7 35.668796515401326 139.7416845125717 43.7 35.66871767255011 139.74161384181792 43.7 35.668737837628754 139.74158012834982 43.7 35.66873172214807 139.74157465651572 43.7 35.66872792476867 139.74157124763747 43.7 35.66871324212585 139.7415958639491 43.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-5cba4139-6a04-4725-ad1c-fb92e8efe81a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5cba4139-6a04-4725-ad1c-fb92e8efe81a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5cba4139-6a04-4725-ad1c-fb92e8efe81a">
											<gml:posList>35.66872424260523 139.74161258610098 45.3 35.668744407683505 139.74157887262982 45.3 35.668737837628754 139.74158012834982 45.3 35.66871767255011 139.74161384181792 45.3 35.66872424260523 139.74161258610098 45.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c66013d6-a99e-4cdd-9bb8-a762d3d58ecb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c66013d6-a99e-4cdd-9bb8-a762d3d58ecb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c66013d6-a99e-4cdd-9bb8-a762d3d58ecb">
											<gml:posList>35.66874283684017 139.74176511056046 45.3 35.668713669570614 139.74181407778227 45.3 35.66872023963625 139.74181283312782 45.3 35.668749397883126 139.7417638548658 45.3 35.66874283684017 139.74176511056046 45.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b455dd89-98aa-4934-a07f-cf3052683cde">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b455dd89-98aa-4934-a07f-cf3052683cde">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b455dd89-98aa-4934-a07f-cf3052683cde">
											<gml:posList>35.66873172214807 139.74157465651572 45.3 35.668737837628754 139.74158012834982 45.3 35.668744407683505 139.74157887262982 45.3 35.66873069745222 139.74156659408476 45.3 35.66872792476867 139.74157124763747 45.3 35.66873172214807 139.74157465651572 45.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d96bea3d-6d93-45a8-b39a-4cf7a2010afb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d96bea3d-6d93-45a8-b39a-4cf7a2010afb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d96bea3d-6d93-45a8-b39a-4cf7a2010afb">
											<gml:posList>35.66872424260523 139.74161258610098 45.3 35.66871767255011 139.74161384181792 45.3 35.668796515401326 139.7416845125717 45.3 35.66879549973497 139.74167646116857 45.3 35.66872424260523 139.74161258610098 45.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f5eab0c9-34ba-4941-8bf4-df5479657bab">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f5eab0c9-34ba-4941-8bf4-df5479657bab">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f5eab0c9-34ba-4941-8bf4-df5479657bab">
											<gml:posList>35.66880233499594 139.74189361854476 45.3 35.66880131935195 139.74188557818437 45.3 35.66872023963625 139.74181283312782 45.3 35.668713669570614 139.74181407778227 45.3 35.66880233499594 139.74189361854476 45.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-1f11d068-d621-4209-bd59-cccbea4621b6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1f11d068-d621-4209-bd59-cccbea4621b6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1f11d068-d621-4209-bd59-cccbea4621b6">
											<gml:posList>35.66879549973497 139.74167646116857 45.3 35.668796515401326 139.7416845125717 45.3 35.66881506005576 139.7416534630376 45.3 35.66881404437891 139.74164540058698 45.3 35.66879549973497 139.74167646116857 45.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-3ae363c1-a4f3-4144-a1fc-9946ce9d0ad6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3ae363c1-a4f3-4144-a1fc-9946ce9d0ad6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3ae363c1-a4f3-4144-a1fc-9946ce9d0ad6">
											<gml:posList>35.668903160852416 139.74172527212846 45.3 35.66889658177418 139.74172651680328 45.3 35.66880131935195 139.74188557818437 45.3 35.66880233499594 139.74189361854476 45.3 35.668903160852416 139.74172527212846 45.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-60302d18-2344-4583-aecc-f2e4cc9c8a76">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-60302d18-2344-4583-aecc-f2e4cc9c8a76">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-60302d18-2344-4583-aecc-f2e4cc9c8a76">
											<gml:posList>35.66883483326331 139.74183923493405 42.4 35.66884691987995 139.74185004626963 42.4 35.66888211863408 139.7417909097252 42.4 35.668870302591934 139.74178031900587 42.4 35.66883483326331 139.74183923493405 42.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-78e349b5-dd1e-4f52-b0fa-3a6c3cb94724">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-78e349b5-dd1e-4f52-b0fa-3a6c3cb94724">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-78e349b5-dd1e-4f52-b0fa-3a6c3cb94724">
											<gml:posList>35.66881404437891 139.74164540058698 45.3 35.66881506005576 139.7416534630376 45.3 35.66889658177418 139.74172651680328 45.3 35.668903160852416 139.74172527212846 45.3 35.66881404437891 139.74164540058698 45.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ea95a036-e7d6-4eb8-9095-88b090161537">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ea95a036-e7d6-4eb8-9095-88b090161537">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ea95a036-e7d6-4eb8-9095-88b090161537">
											<gml:posList>35.66863295433164 139.74148620256372 45.3 35.66863295433164 139.74148620256372 43.7 35.66868160763951 139.74152977863346 43.7 35.66868160763951 139.74152977863346 45.3 35.66863295433164 139.74148620256372 45.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d8bb573e-8ff4-47fa-b311-358309747baf">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d8bb573e-8ff4-47fa-b311-358309747baf">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d8bb573e-8ff4-47fa-b311-358309747baf">
											<gml:posList>35.66868816867164 139.74152851187452 45.3 35.66868816867164 139.74152851187452 50.303 35.66873069745222 139.74156659408476 50.303 35.66873069745222 139.74156659408476 45.3 35.668744407683505 139.74157887262982 45.3 35.668744407683505 139.74157887262982 15.47 35.6686319296383 139.74147815118982 15.47 35.6686319296383 139.74147815118982 45.3 35.66868816867164 139.74152851187452 45.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a608719b-fb98-4ab7-aeab-ba80176cd9da">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a608719b-fb98-4ab7-aeab-ba80176cd9da">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a608719b-fb98-4ab7-aeab-ba80176cd9da">
											<gml:posList>35.66868160763951 139.74152977863346 45.3 35.66868160763951 139.74152977863346 43.7 35.66868539598954 139.7415331654261 43.7 35.66868539598954 139.7415331654261 45.3 35.66868160763951 139.74152977863346 45.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-51c97761-b96d-4628-95a7-768878925d9c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-51c97761-b96d-4628-95a7-768878925d9c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-51c97761-b96d-4628-95a7-768878925d9c">
											<gml:posList>35.66868539598954 139.7415331654261 45.3 35.66868539598954 139.7415331654261 43.7 35.668654239280436 139.74158541564196 43.7 35.668654239280436 139.74158541564196 50.303 35.66868816867164 139.74152851187452 50.303 35.66868816867164 139.74152851187452 45.3 35.66868539598954 139.7415331654261 45.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0b023086-3803-44bb-baf0-6091dae8a54c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0b023086-3803-44bb-baf0-6091dae8a54c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0b023086-3803-44bb-baf0-6091dae8a54c">
											<gml:posList>35.6686319296383 139.74147815118982 15.47 35.66853020426368 139.74164848665566 15.47 35.66853020426368 139.74164848665566 45.3 35.6686319296383 139.74147815118982 45.3 35.6686319296383 139.74147815118982 15.47</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d790a865-db4f-4ff6-9545-0f53973e456f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d790a865-db4f-4ff6-9545-0f53973e456f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d790a865-db4f-4ff6-9545-0f53973e456f">
											<gml:posList>35.66853678334152 139.74164724198025 45.3 35.66853678334152 139.74164724198025 43.7 35.66863295433164 139.74148620256372 43.7 35.66863295433164 139.74148620256372 45.3 35.66853678334152 139.74164724198025 45.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7fc4882e-3da3-455a-8efb-8d58fcd59b34">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7fc4882e-3da3-455a-8efb-8d58fcd59b34">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7fc4882e-3da3-455a-8efb-8d58fcd59b34">
											<gml:posList>35.66872792476867 139.74157124763747 45.3 35.66872792476867 139.74157124763747 43.7 35.66873172214807 139.74157465651572 43.7 35.66873172214807 139.74157465651572 45.3 35.66872792476867 139.74157124763747 45.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-93fed382-c0e8-4526-b554-76c2e9ada3ac">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-93fed382-c0e8-4526-b554-76c2e9ada3ac">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-93fed382-c0e8-4526-b554-76c2e9ada3ac">
											<gml:posList>35.66873172214807 139.74157465651572 45.3 35.66873172214807 139.74157465651572 43.7 35.668737837628754 139.74158012834982 43.7 35.668737837628754 139.74158012834982 45.3 35.66873172214807 139.74157465651572 45.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a6dcbf17-ec8f-4079-8588-0a2134949b67">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a6dcbf17-ec8f-4079-8588-0a2134949b67">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a6dcbf17-ec8f-4079-8588-0a2134949b67">
											<gml:posList>35.66872792476867 139.74157124763747 45.3 35.66873069745222 139.74156659408476 45.3 35.66873069745222 139.74156659408476 50.303 35.66871324212585 139.7415958639491 50.303 35.66871324212585 139.7415958639491 43.7 35.66872792476867 139.74157124763747 43.7 35.66872792476867 139.74157124763747 45.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8af6cada-f731-4bde-9a9d-0c3877f6f9f2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8af6cada-f731-4bde-9a9d-0c3877f6f9f2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8af6cada-f731-4bde-9a9d-0c3877f6f9f2">
											<gml:posList>35.66869903579625 139.74158313308646 43.7 35.66871324212585 139.7415958639491 43.7 35.66871324212585 139.7415958639491 50.303 35.66869903579625 139.74158313308646 50.303 35.66869903579625 139.74158313308646 43.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-baaa77bd-637a-46a7-8574-b9bca437683c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-baaa77bd-637a-46a7-8574-b9bca437683c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-baaa77bd-637a-46a7-8574-b9bca437683c">
											<gml:posList>35.66872424260523 139.74161258610098 15.47 35.668744407683505 139.74157887262982 15.47 35.668744407683505 139.74157887262982 45.3 35.66872424260523 139.74161258610098 45.3 35.66872424260523 139.74161258610098 15.47</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5a0b487c-2917-4254-9bbf-a728ce516d25">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5a0b487c-2917-4254-9bbf-a728ce516d25">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5a0b487c-2917-4254-9bbf-a728ce516d25">
											<gml:posList>35.66868255271125 139.74161077805772 43.7 35.66869903579625 139.74158313308646 43.7 35.66869903579625 139.74158313308646 50.303 35.66868255271125 139.74161077805772 50.303 35.66868255271125 139.74161077805772 43.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3a282ea8-8c24-4607-9604-04057bfb5727">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3a282ea8-8c24-4607-9604-04057bfb5727">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3a282ea8-8c24-4607-9604-04057bfb5727">
											<gml:posList>35.668737837628754 139.74158012834982 45.3 35.668737837628754 139.74158012834982 43.7 35.66871767255011 139.74161384181792 43.7 35.66871767255011 139.74161384181792 45.3 35.668737837628754 139.74158012834982 45.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-569cf1f7-f53f-454e-8b87-707b051eb252">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-569cf1f7-f53f-454e-8b87-707b051eb252">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-569cf1f7-f53f-454e-8b87-707b051eb252">
											<gml:posList>35.668654239280436 139.74158541564196 43.7 35.66868255271125 139.74161077805772 43.7 35.66868255271125 139.74161077805772 50.303 35.668654239280436 139.74158541564196 50.303 35.668654239280436 139.74158541564196 43.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-db8cac79-fdee-4cfa-a14b-fcfb9f57de79">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-db8cac79-fdee-4cfa-a14b-fcfb9f57de79">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-db8cac79-fdee-4cfa-a14b-fcfb9f57de79">
											<gml:posList>35.66879549973497 139.74167646116857 15.47 35.66872424260523 139.74161258610098 15.47 35.66872424260523 139.74161258610098 45.3 35.66879549973497 139.74167646116857 45.3 35.66879549973497 139.74167646116857 15.47</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a977ebf2-b9d7-4f1a-b4b9-1183c2447b3f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a977ebf2-b9d7-4f1a-b4b9-1183c2447b3f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a977ebf2-b9d7-4f1a-b4b9-1183c2447b3f">
											<gml:posList>35.66871767255011 139.74161384181792 45.3 35.66871767255011 139.74161384181792 43.7 35.668796515401326 139.7416845125717 43.7 35.668796515401326 139.7416845125717 45.3 35.66871767255011 139.74161384181792 45.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6ee9ef1b-8d8a-4e6b-9bf4-92501b79abce">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6ee9ef1b-8d8a-4e6b-9bf4-92501b79abce">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6ee9ef1b-8d8a-4e6b-9bf4-92501b79abce">
											<gml:posList>35.66881404437891 139.74164540058698 15.47 35.66879549973497 139.74167646116857 15.47 35.66879549973497 139.74167646116857 45.3 35.66881404437891 139.74164540058698 45.3 35.66881404437891 139.74164540058698 15.47</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c3ea497a-2894-4e7e-b11c-f660d5ddfcde">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c3ea497a-2894-4e7e-b11c-f660d5ddfcde">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c3ea497a-2894-4e7e-b11c-f660d5ddfcde">
											<gml:posList>35.668796515401326 139.7416845125717 45.3 35.668796515401326 139.7416845125717 43.7 35.66881506005576 139.7416534630376 43.7 35.66881506005576 139.7416534630376 45.3 35.668796515401326 139.7416845125717 45.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c3202439-b056-495d-a924-61ecf69f230b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c3202439-b056-495d-a924-61ecf69f230b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c3202439-b056-495d-a924-61ecf69f230b">
											<gml:posList>35.668903160852416 139.74172527212846 15.47 35.66881404437891 139.74164540058698 15.47 35.66881404437891 139.74164540058698 45.3 35.668903160852416 139.74172527212846 45.3 35.668903160852416 139.74172527212846 15.47</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-bd836709-ebd4-4405-9d8b-3eb33f91f3f2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bd836709-ebd4-4405-9d8b-3eb33f91f3f2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bd836709-ebd4-4405-9d8b-3eb33f91f3f2">
											<gml:posList>35.668625800616105 139.74172704708553 45.3 35.668625800616105 139.74172704708553 43.7 35.66853678334152 139.74164724198025 43.7 35.66853678334152 139.74164724198025 45.3 35.668625800616105 139.74172704708553 45.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-fa7930ab-da2d-4579-8a91-52e7ab0a6838">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fa7930ab-da2d-4579-8a91-52e7ab0a6838">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fa7930ab-da2d-4579-8a91-52e7ab0a6838">
											<gml:posList>35.66881506005576 139.7416534630376 45.3 35.66881506005576 139.7416534630376 43.7 35.66889658177418 139.74172651680328 43.7 35.66889658177418 139.74172651680328 45.3 35.66881506005576 139.7416534630376 45.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-961b1b61-8d84-4e2e-a251-fb4f874f980f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-961b1b61-8d84-4e2e-a251-fb4f874f980f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-961b1b61-8d84-4e2e-a251-fb4f874f980f">
											<gml:posList>35.66853020426368 139.74164848665566 15.47 35.66862680725696 139.7417350874366 15.47 35.66862680725696 139.7417350874366 45.3 35.66853020426368 139.74164848665566 45.3 35.66853020426368 139.74164848665566 15.47</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0d8cc3a1-14fe-459d-b000-acaeeffb1765">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0d8cc3a1-14fe-459d-b000-acaeeffb1765">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0d8cc3a1-14fe-459d-b000-acaeeffb1765">
											<gml:posList>35.66865460788184 139.74167884247285 45.3 35.66865460788184 139.74167884247285 43.7 35.668625800616105 139.74172704708553 43.7 35.668625800616105 139.74172704708553 45.3 35.66865460788184 139.74167884247285 45.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-54fc2dd5-cf7c-4440-a64a-48407e132fe7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-54fc2dd5-cf7c-4440-a64a-48407e132fe7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-54fc2dd5-cf7c-4440-a64a-48407e132fe7">
											<gml:posList>35.66862680725696 139.7417350874366 15.47 35.66865561453431 139.7416868938722 15.47 35.66865561453431 139.7416868938722 45.3 35.66862680725696 139.7417350874366 45.3 35.66862680725696 139.7417350874366 15.47</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-04774235-c003-44aa-b2a2-ea2e6ff2c1ec">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-04774235-c003-44aa-b2a2-ea2e6ff2c1ec">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-04774235-c003-44aa-b2a2-ea2e6ff2c1ec">
											<gml:posList>35.668749397883126 139.7417638548658 45.3 35.668749397883126 139.7417638548658 43.7 35.66865460788184 139.74167884247285 43.7 35.66865460788184 139.74167884247285 45.3 35.668749397883126 139.7417638548658 45.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b17b9141-f03b-4bd5-859f-da0257769425">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b17b9141-f03b-4bd5-859f-da0257769425">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b17b9141-f03b-4bd5-859f-da0257769425">
											<gml:posList>35.66865561453431 139.7416868938722 15.47 35.66874283684017 139.74176511056046 15.47 35.66874283684017 139.74176511056046 45.3 35.66865561453431 139.7416868938722 45.3 35.66865561453431 139.7416868938722 15.47</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-75752dfb-a412-48b4-9ab5-e7ff5b2db3b0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-75752dfb-a412-48b4-9ab5-e7ff5b2db3b0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-75752dfb-a412-48b4-9ab5-e7ff5b2db3b0">
											<gml:posList>35.66888211863408 139.7417909097252 15.47 35.668870302591934 139.74178031900587 15.47 35.668870302591934 139.74178031900587 42.4 35.66888211863408 139.7417909097252 42.4 35.66888211863408 139.7417909097252 15.47</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-06c6fbc0-fe6a-4902-b82b-f2466780d2e1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-06c6fbc0-fe6a-4902-b82b-f2466780d2e1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-06c6fbc0-fe6a-4902-b82b-f2466780d2e1">
											<gml:posList>35.66872023963625 139.74181283312782 45.3 35.66872023963625 139.74181283312782 43.7 35.668749397883126 139.7417638548658 43.7 35.668749397883126 139.7417638548658 45.3 35.66872023963625 139.74181283312782 45.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3d2a1754-470e-4a9a-96d6-b0913b26636c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3d2a1754-470e-4a9a-96d6-b0913b26636c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3d2a1754-470e-4a9a-96d6-b0913b26636c">
											<gml:posList>35.66874283684017 139.74176511056046 15.47 35.668713669570614 139.74181407778227 15.47 35.668713669570614 139.74181407778227 45.3 35.66874283684017 139.74176511056046 45.3 35.66874283684017 139.74176511056046 15.47</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-bca0d7ed-a6e7-4386-84b3-66d4b2139f08">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bca0d7ed-a6e7-4386-84b3-66d4b2139f08">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bca0d7ed-a6e7-4386-84b3-66d4b2139f08">
											<gml:posList>35.66889658177418 139.74172651680328 45.3 35.66889658177418 139.74172651680328 43.7 35.66880131935195 139.74188557818437 43.7 35.66880131935195 139.74188557818437 45.3 35.66889658177418 139.74172651680328 45.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f89ea899-d104-4110-9bb6-b7bae55eb7b9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f89ea899-d104-4110-9bb6-b7bae55eb7b9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f89ea899-d104-4110-9bb6-b7bae55eb7b9">
											<gml:posList>35.668870302591934 139.74178031900587 42.4 35.668870302591934 139.74178031900587 15.47 35.668903160852416 139.74172527212846 15.47 35.668903160852416 139.74172527212846 45.3 35.66880233499594 139.74189361854476 45.3 35.66880233499594 139.74189361854476 15.47 35.66883483326331 139.74183923493405 15.47 35.66883483326331 139.74183923493405 42.4 35.668870302591934 139.74178031900587 42.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-860bcc8d-c4e4-4dc6-94e8-b31fb63d47c4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-860bcc8d-c4e4-4dc6-94e8-b31fb63d47c4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-860bcc8d-c4e4-4dc6-94e8-b31fb63d47c4">
											<gml:posList>35.66884691987995 139.74185004626963 15.47 35.66888211863408 139.7417909097252 15.47 35.66888211863408 139.7417909097252 42.4 35.66884691987995 139.74185004626963 42.4 35.66884691987995 139.74185004626963 15.47</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-df9066d7-e360-4552-9dc4-2fd5ed410a3e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-df9066d7-e360-4552-9dc4-2fd5ed410a3e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-df9066d7-e360-4552-9dc4-2fd5ed410a3e">
											<gml:posList>35.66883483326331 139.74183923493405 15.47 35.66884691987995 139.74185004626963 15.47 35.66884691987995 139.74185004626963 42.4 35.66883483326331 139.74183923493405 42.4 35.66883483326331 139.74183923493405 15.47</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-afe37983-7151-4dd9-9ad2-e329beefc7a5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-afe37983-7151-4dd9-9ad2-e329beefc7a5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-afe37983-7151-4dd9-9ad2-e329beefc7a5">
											<gml:posList>35.66880131935195 139.74188557818437 45.3 35.66880131935195 139.74188557818437 43.7 35.66872023963625 139.74181283312782 43.7 35.66872023963625 139.74181283312782 45.3 35.66880131935195 139.74188557818437 45.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d974826d-4be4-4943-8c88-5f9c97ed19b0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d974826d-4be4-4943-8c88-5f9c97ed19b0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d974826d-4be4-4943-8c88-5f9c97ed19b0">
											<gml:posList>35.668713669570614 139.74181407778227 15.47 35.66880233499594 139.74189361854476 15.47 35.66880233499594 139.74189361854476 45.3 35.668713669570614 139.74181407778227 45.3 35.668713669570614 139.74181407778227 15.47</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂一丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-1510</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">622.84315</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">6</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1210</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.6</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>4</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.01</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:bldgRealEstateIDAttribute>
				<uro:RealEstateIDAttribute>
					<uro:realEstateIDOfBuilding>0104000014595-0000</uro:realEstateIDOfBuilding>
					<uro:numberOfRealEstateIDOfLand>1</uro:numberOfRealEstateIDOfLand>
					<uro:realEstateIDOfLand>0104000012222-0000</uro:realEstateIDOfLand>
					<uro:matchingScore>51</uro:matchingScore>
				</uro:RealEstateIDAttribute>
			</uro:bldgRealEstateIDAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>