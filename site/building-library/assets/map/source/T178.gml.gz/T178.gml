<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_2e8c24e9-2bcc-4985-b0d5-e0cdd102d005">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>18</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>3</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103018003</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">401</bldg:usage>
			<bldg:measuredHeight uom="m">29</bldg:measuredHeight>
			<bldg:storeysAboveGround>8</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.66679223911783 139.74722869590147 0 35.66678096832234 139.7472236269523 0 35.66680569633601 139.74714009439458 0 35.66673338313252 139.74710791851055 0 35.66668590521706 139.74726813295482 0 35.66676957930812 139.74730537782634 0 35.66679223911783 139.74722869590147 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66679223911783 139.74722869590147 6.14 35.66676957930812 139.74730537782634 6.14 35.66668590521706 139.74726813295482 6.14 35.66673338313252 139.74710791851055 6.14 35.66680569633601 139.74714009439458 6.14 35.66678096832234 139.7472236269523 6.14 35.66679223911783 139.74722869590147 6.14</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66679223911783 139.74722869590147 6.14 35.66678096832234 139.7472236269523 6.14 35.66678096832234 139.7472236269523 34.17 35.66679223911783 139.74722869590147 34.17 35.66679223911783 139.74722869590147 6.14</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66678096832234 139.7472236269523 6.14 35.66680569633601 139.74714009439458 6.14 35.66680569633601 139.74714009439458 34.17 35.66678096832234 139.7472236269523 34.17 35.66678096832234 139.7472236269523 6.14</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66680569633601 139.74714009439458 6.14 35.66673338313252 139.74710791851055 6.14 35.66673338313252 139.74710791851055 34.17 35.66680569633601 139.74714009439458 34.17 35.66680569633601 139.74714009439458 6.14</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66673338313252 139.74710791851055 6.14 35.66668590521706 139.74726813295482 6.14 35.66668590521706 139.74726813295482 34.17 35.66673338313252 139.74710791851055 34.17 35.66673338313252 139.74710791851055 6.14</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66668590521706 139.74726813295482 6.14 35.66676957930812 139.74730537782634 6.14 35.66676957930812 139.74730537782634 34.17 35.66668590521706 139.74726813295482 34.17 35.66668590521706 139.74726813295482 6.14</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66676957930812 139.74730537782634 6.14 35.66679223911783 139.74722869590147 6.14 35.66679223911783 139.74722869590147 34.17 35.66676957930812 139.74730537782634 34.17 35.66676957930812 139.74730537782634 6.14</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66679223911783 139.74722869590147 34.17 35.66678096832234 139.7472236269523 34.17 35.66680569633601 139.74714009439458 34.17 35.66673338313252 139.74710791851055 34.17 35.66668590521706 139.74726813295482 34.17 35.66676957930812 139.74730537782634 34.17 35.66679223911783 139.74722869590147 34.17</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-061ec346-819d-42cd-9222-990c75911cb4"/>
							<gml:surfaceMember xlink:href="#poly-2c8bcfaa-cc6e-4084-b6fe-9bee2ff8f190"/>
							<gml:surfaceMember xlink:href="#poly-7e76d881-8b51-42db-9a6e-c6d0fdfb3de7"/>
							<gml:surfaceMember xlink:href="#poly-25941549-3281-4577-bd2d-418c1eb1bc2d"/>
							<gml:surfaceMember xlink:href="#poly-8ea8e7ff-5f94-4b51-b150-801f0e8f97c7"/>
							<gml:surfaceMember xlink:href="#poly-0921a163-843b-4d8a-b574-ec88dfb57f0d"/>
							<gml:surfaceMember xlink:href="#poly-aaf00885-23e3-4423-90e6-de2f63a17a28"/>
							<gml:surfaceMember xlink:href="#poly-088462bb-d0b9-4977-8541-27bbb6fff465"/>
							<gml:surfaceMember xlink:href="#poly-2c42f5da-1f32-4817-9507-c46d5e8c22c2"/>
							<gml:surfaceMember xlink:href="#poly-abb42414-fd97-45fe-8776-db4177d9dc74"/>
							<gml:surfaceMember xlink:href="#poly-8b70e7f6-f49d-45dd-a4ad-763d3290f916"/>
							<gml:surfaceMember xlink:href="#poly-4f32b7dc-f7bc-4351-855b-a5041a2190a5"/>
							<gml:surfaceMember xlink:href="#poly-67cb32d1-c4e4-44c9-97ad-3e7e347dfd96"/>
							<gml:surfaceMember xlink:href="#poly-ae14f0da-b719-454b-87ce-7e714b800d0e"/>
							<gml:surfaceMember xlink:href="#poly-d5b7a3fe-77ae-4dff-9e2e-c805603f2789"/>
							<gml:surfaceMember xlink:href="#poly-fef21ab9-2fa5-463c-87c7-df89240d1580"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_2e8c24e9-2bcc-4985-b0d5-e0cdd102d005_BuildingInstallation_1041">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-50671d30-c9ff-41a9-b315-daabb1129a88">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66674808440303 139.7471958932245 34.6 35.66674143031197 139.7472183674457 34.6 35.666715787088144 139.74720696262744 34.6 35.66672244117711 139.74718448841247 34.6 35.66674808440303 139.7471958932245 34.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-05180c0e-8779-4844-b6d0-c62740e5c622">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-05180c0e-8779-4844-b6d0-c62740e5c622_0">
											<gml:posList>35.66672244117711 139.74718448841247 34.6 35.666715787088144 139.74720696262744 34.6 35.666715787088144 139.74720696262744 37.04 35.66672244117711 139.74718448841247 37.04 35.66672244117711 139.74718448841247 34.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0b20a8fd-9368-449f-9ad7-fd263ecc0331">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0b20a8fd-9368-449f-9ad7-fd263ecc0331_0">
											<gml:posList>35.666715787088144 139.74720696262744 34.6 35.66674143031197 139.7472183674457 34.6 35.66674143031197 139.7472183674457 37.04 35.666715787088144 139.74720696262744 37.04 35.666715787088144 139.74720696262744 34.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2359e918-dc2b-4da8-939d-39bff9af99b4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2359e918-dc2b-4da8-939d-39bff9af99b4_0">
											<gml:posList>35.66674808440303 139.7471958932245 37.04 35.66672244117711 139.74718448841247 37.04 35.666715787088144 139.74720696262744 37.04 35.66674143031197 139.7472183674457 37.04 35.66674808440303 139.7471958932245 37.04</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4e190dbe-8851-4e25-bbe7-7d54fd2a9c38">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4e190dbe-8851-4e25-bbe7-7d54fd2a9c38_0">
											<gml:posList>35.66674808440303 139.7471958932245 34.6 35.66672244117711 139.74718448841247 34.6 35.66672244117711 139.74718448841247 37.04 35.66674808440303 139.7471958932245 37.04 35.66674808440303 139.7471958932245 34.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-62f8170a-be4c-410a-9aee-446139e755f2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-62f8170a-be4c-410a-9aee-446139e755f2_0">
											<gml:posList>35.66674143031197 139.7472183674457 34.6 35.66674808440303 139.7471958932245 34.6 35.66674808440303 139.7471958932245 37.04 35.66674143031197 139.7472183674457 37.04 35.66674143031197 139.7472183674457 34.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_2e8c24e9-2bcc-4985-b0d5-e0cdd102d005_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e00ee554-51eb-40ca-aa06-6e956d6a7547">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66676250121949 139.74716348051896 32.5 35.66676056793088 139.74716999959574 32.5 35.66672357278838 139.74715353698744 32.5 35.666725506076105 139.74714701791328 32.5 35.66676250121949 139.74716348051896 32.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-919669b4-e5c0-4ee1-b696-e2f29f30e456">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.666762610068645 139.74726526709645 38.963 35.66676193438629 139.7472657538352 38.963 35.66676123161536 139.74726617432842 38.963 35.66676050175588 139.74726652857615 38.963 35.66675975380578 139.7472667944772 38.963 35.66675897875134 139.74726697204127 38.963 35.66675820364163 139.74726707228504 38.963 35.666757419455024 139.74726708417245 38.963 35.66675663521317 139.74726701873962 38.963 35.66675585992977 139.74726687597686 38.963 35.66675510260278 139.74726663378297 38.963 35.66675436325588 139.74726632529521 38.963 35.66675364188118 139.74726593946784 38.963 35.666752956498236 139.74726546523578 38.963 35.66675230713073 139.74726493573627 38.963 35.666751702776615 139.74726432886814 38.963 35.66675113443794 139.74726366673252 38.963 35.666750620134266 139.74726293826438 38.963 35.66675015988139 139.74726216555518 38.963 35.66674975367141 139.7472613375592 38.963 35.666749410533846 139.74726047635826 38.963 35.66674913046869 139.74725958195233 38.963 35.66674891347596 139.74725865434144 38.963 35.66674876858517 139.74725771560736 38.963 35.66674868677468 139.74725675471407 38.963 35.6667486680603 139.74725579375306 38.963 35.66674872146364 139.74725484376037 38.963 35.66674884697681 139.7472538936903 38.963 35.66674903559399 139.74725295459822 38.963 35.666749296344676 139.747252048566 38.963 35.66674961120142 139.74725117561297 38.963 35.66674998917796 139.74725033572946 38.963 35.66675043028219 139.74724953996122 38.963 35.66675092550038 139.7472487883179 38.963 35.666751465834594 139.7472481029007 38.963 35.666752060290655 139.74724747265418 38.963 35.66675269084902 139.74724690864346 38.963 35.66675336652341 139.74724641085888 38.963 35.66675406929427 139.7472459903655 38.963 35.66675479916158 139.74724564716337 38.963 35.66675555612537 139.74724538125247 38.963 35.66675632215816 139.74724519265214 38.963 35.66675710628157 139.7472450923985 38.963 35.66675788145445 139.7472450805205 38.963 35.666758665696314 139.74724514595312 38.963 35.66675944098764 139.74724529976146 38.963 35.66676020732049 139.74724553089973 38.963 35.66676094666744 139.7472458393873 38.963 35.66676165902849 139.7472462252242 38.963 35.6667623444115 139.74724669945616 38.963 35.66676299377908 139.7472472289556 38.963 35.66676360714702 139.74724783581402 38.963 35.66676416647994 139.74724850900503 38.963 35.666764680775806 139.7472492264274 38.963 35.66676514103667 139.74725001018243 38.963 35.66676554723883 139.74725082713277 38.963 35.66676589037646 139.74725168833388 38.963 35.66676617044956 139.7472525937857 38.963 35.66676638743445 139.74725351035104 38.963 35.66676653233316 139.74725446013107 38.963 35.666766623149506 139.7472554099691 38.963 35.66676663285017 139.74725637094002 38.963 35.66676657945471 139.74725733197866 38.963 35.666766453941506 139.74725828204896 38.963 35.666766265316404 139.74725921009548 38.963 35.66676601357939 139.74726011611818 38.963 35.66676568971674 139.74726100012677 38.963 35.66676531174012 139.74726184001042 38.963 35.66676487063582 139.74726263577875 38.963 35.66676437540965 139.74726337637637 38.963 35.66676383507536 139.74726406179354 38.963 35.66676324964083 139.74726470307613 38.963 35.666762610068645 139.74726526709645 38.963</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c432ad8b-3809-4ea6-9b3b-e6b4074c0213">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66677465123097 139.7472131733979 38.963 35.666774759885506 139.74721385811856 38.963 35.66677483248512 139.7472145428779 38.963 35.666774851010246 139.74721523874112 38.963 35.666774815445095 139.74721592361666 38.963 35.666774734811284 139.74721660854058 38.963 35.66677460910882 139.7472172935129 38.963 35.666774438314015 139.74721794539636 38.963 35.66677421342892 139.74721858629212 38.963 35.66677394345149 139.74721919409905 38.963 35.66677363739542 139.7472197688074 38.963 35.6667732862549 139.74722032147267 38.963 35.66677289901998 139.74722081894785 38.963 35.66677247570644 139.74722128332448 38.963 35.66677202532011 139.74722170354713 38.963 35.66677153883936 139.74722206857976 38.963 35.66677103429166 139.7472223784029 38.963 35.66677051167701 139.7472226330167 38.963 35.6667699710033 139.74722284346677 38.963 35.66676942126057 139.74722297660628 38.963 35.666768853458784 139.74722306558212 38.963 35.6667682856096 139.74722308828342 38.963 35.66676772672675 139.74722304470052 38.963 35.66676716780443 139.74722294588886 38.963 35.666766617856325 139.74722279183874 38.963 35.66676607687456 139.74722257150444 38.963 35.66676556290239 139.7472223069581 38.963 35.66676505789656 139.74722197612755 38.963 35.666764588914056 139.74722160107527 38.963 35.66676414693323 139.74722117076516 38.963 35.66676373196201 139.74722069624303 38.963 35.66676335301411 139.74722017749914 38.963 35.66676301009742 139.74721962557933 38.963 35.66676271221779 139.74721902942807 38.963 35.666762459391 139.74721841113694 38.963 35.666762251617065 139.7472177707059 38.963 35.66676208889597 139.74721710813495 38.963 35.66676197123563 139.74721643446983 38.963 35.66676189862813 139.74721573866483 38.963 35.666761889116735 139.74721504279205 38.963 35.666761915668154 139.74721435792634 38.963 35.66676199630194 139.7472136730025 38.963 35.66676212201229 139.74721299907605 38.963 35.6667623018129 139.74721233613724 38.963 35.666762526697966 139.74721169524153 38.963 35.66676278766163 139.74721108744436 38.963 35.66676310273139 139.74721051272635 38.963 35.666763444866014 139.74720997111658 38.963 35.666763832093004 139.74720946259563 38.963 35.666764255406505 139.74720899821898 38.963 35.66676471480652 139.7472085779866 38.963 35.666765192273495 139.74720821296364 38.963 35.66676569682116 139.7472079031404 38.963 35.66676621943578 139.74720764852657 38.963 35.66676676010947 139.74720743807637 38.963 35.666767318865915 139.7472073049271 38.963 35.66676787765395 139.74720721596086 38.963 35.666768445511025 139.74720720430517 38.963 35.666769004385976 139.7472072368422 38.963 35.66676957232205 139.74720733564408 38.963 35.66677012227017 139.7472074896941 38.963 35.666770654238235 139.74720771003797 38.963 35.666771177232064 139.74720798562032 38.963 35.6667716732163 139.74720830541477 38.963 35.666772151220485 139.74720869150306 38.963 35.66677259319344 139.74720911076736 38.963 35.66677300816472 139.7472095852895 38.963 35.66677337809894 139.74721010404303 38.963 35.666773721015666 139.7472106559629 38.963 35.66677401889533 139.74721125211423 38.963 35.66677427172217 139.74721187040544 38.963 35.66677447949613 139.74721251083656 38.963 35.66677465123097 139.7472131733979 38.963</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f4748d36-e204-4479-94d7-33a349da116a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f4748d36-e204-4479-94d7-33a349da116a_0">
											<gml:posList>35.666725506076105 139.74714701791328 32.5 35.66672357278838 139.74715353698744 32.5 35.66672357278838 139.74715353698744 33.834 35.666725506076105 139.74714701791328 33.834 35.666725506076105 139.74714701791328 32.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-810c3299-fc10-41f5-9bd5-ff48cd647779">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-810c3299-fc10-41f5-9bd5-ff48cd647779_0">
											<gml:posList>35.66676056793088 139.74716999959574 33.834 35.66672357278838 139.74715353698744 33.834 35.66672357278838 139.74715353698744 32.5 35.66676056793088 139.74716999959574 32.5 35.66676056793088 139.74716999959574 33.834</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c41adfd0-eddf-4a3e-ad88-6fc096075690">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c41adfd0-eddf-4a3e-ad88-6fc096075690_0">
											<gml:posList>35.66676250121949 139.74716348051896 33.834 35.666725506076105 139.74714701791328 33.834 35.66672357278838 139.74715353698744 33.834 35.66676056793088 139.74716999959574 33.834 35.66676250121949 139.74716348051896 33.834</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8eb2c1e5-543c-4593-926b-c687d7192a99">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8eb2c1e5-543c-4593-926b-c687d7192a99_0">
											<gml:posList>35.66676250121949 139.74716348051896 32.5 35.666725506076105 139.74714701791328 32.5 35.666725506076105 139.74714701791328 33.834 35.66676250121949 139.74716348051896 33.834 35.66676250121949 139.74716348051896 32.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8c68296b-8523-4fb7-8d95-6daab975d777">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8c68296b-8523-4fb7-8d95-6daab975d777_0">
											<gml:posList>35.6667486680603 139.74725579375306 38.963 35.66674868677468 139.74725675471407 38.963 35.66674868677468 139.74725675471407 41.329 35.6667486680603 139.74725579375306 41.329 35.6667486680603 139.74725579375306 38.963</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-44db06e2-308d-470b-a518-67683a47a294">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-44db06e2-308d-470b-a518-67683a47a294_0">
											<gml:posList>35.66674872146364 139.74725484376037 38.963 35.6667486680603 139.74725579375306 38.963 35.6667486680603 139.74725579375306 41.329 35.66674872146364 139.74725484376037 41.329 35.66674872146364 139.74725484376037 38.963</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1203502e-d839-43ee-b4a7-c6b3c480379e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1203502e-d839-43ee-b4a7-c6b3c480379e_0">
											<gml:posList>35.66674868677468 139.74725675471407 38.963 35.66674876858517 139.74725771560736 38.963 35.66674876858517 139.74725771560736 41.329 35.66674868677468 139.74725675471407 41.329 35.66674868677468 139.74725675471407 38.963</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d4f586de-2bab-4ea0-9703-4b81b4f6c49b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d4f586de-2bab-4ea0-9703-4b81b4f6c49b_0">
											<gml:posList>35.66674884697681 139.7472538936903 38.963 35.66674872146364 139.74725484376037 38.963 35.66674872146364 139.74725484376037 41.329 35.66674884697681 139.7472538936903 41.329 35.66674884697681 139.7472538936903 38.963</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-64e8555c-2138-441a-80ff-4f9d854b7d48">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-64e8555c-2138-441a-80ff-4f9d854b7d48_0">
											<gml:posList>35.66674876858517 139.74725771560736 38.963 35.66674891347596 139.74725865434144 38.963 35.66674891347596 139.74725865434144 41.329 35.66674876858517 139.74725771560736 41.329 35.66674876858517 139.74725771560736 38.963</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-558a49a2-5cf4-456e-979b-15afda2fb32d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-558a49a2-5cf4-456e-979b-15afda2fb32d_0">
											<gml:posList>35.66674903559399 139.74725295459822 38.963 35.66674884697681 139.7472538936903 38.963 35.66674884697681 139.7472538936903 41.329 35.66674903559399 139.74725295459822 41.329 35.66674903559399 139.74725295459822 38.963</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-65e29435-50ce-42a2-a1ce-b761b105f73c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-65e29435-50ce-42a2-a1ce-b761b105f73c_0">
											<gml:posList>35.66674891347596 139.74725865434144 38.963 35.66674913046869 139.74725958195233 38.963 35.66674913046869 139.74725958195233 41.329 35.66674891347596 139.74725865434144 41.329 35.66674891347596 139.74725865434144 38.963</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-44b26960-d2b7-4e86-be48-c22c1472436e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-44b26960-d2b7-4e86-be48-c22c1472436e_0">
											<gml:posList>35.666749296344676 139.747252048566 38.963 35.66674903559399 139.74725295459822 38.963 35.66674903559399 139.74725295459822 41.329 35.666749296344676 139.747252048566 41.329 35.666749296344676 139.747252048566 38.963</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-58ad1c34-2785-4b78-863e-59e1a0c50b62">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-58ad1c34-2785-4b78-863e-59e1a0c50b62_0">
											<gml:posList>35.66674913046869 139.74725958195233 38.963 35.666749410533846 139.74726047635826 38.963 35.666749410533846 139.74726047635826 41.329 35.66674913046869 139.74725958195233 41.329 35.66674913046869 139.74725958195233 38.963</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-516e5230-41dd-4d24-a309-aa6c00795c1b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-516e5230-41dd-4d24-a309-aa6c00795c1b_0">
											<gml:posList>35.66674961120142 139.74725117561297 38.963 35.666749296344676 139.747252048566 38.963 35.666749296344676 139.747252048566 41.329 35.66674961120142 139.74725117561297 41.329 35.66674961120142 139.74725117561297 38.963</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-077ea229-2589-4b0d-869c-4e72fbb15bd3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-077ea229-2589-4b0d-869c-4e72fbb15bd3_0">
											<gml:posList>35.666749410533846 139.74726047635826 38.963 35.66674975367141 139.7472613375592 38.963 35.66674975367141 139.7472613375592 41.329 35.666749410533846 139.74726047635826 41.329 35.666749410533846 139.74726047635826 38.963</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3f532038-46a8-461a-adb0-1a606a554264">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3f532038-46a8-461a-adb0-1a606a554264_0">
											<gml:posList>35.66674998917796 139.74725033572946 38.963 35.66674961120142 139.74725117561297 38.963 35.66674961120142 139.74725117561297 41.329 35.66674998917796 139.74725033572946 41.329 35.66674998917796 139.74725033572946 38.963</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8e3906bb-5590-42bf-a5b0-74501a6948f6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8e3906bb-5590-42bf-a5b0-74501a6948f6_0">
											<gml:posList>35.66674975367141 139.7472613375592 38.963 35.66675015988139 139.74726216555518 38.963 35.66675015988139 139.74726216555518 41.329 35.66674975367141 139.7472613375592 41.329 35.66674975367141 139.7472613375592 38.963</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-778ca2a8-f39d-4bcd-b860-c7878db53ceb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-778ca2a8-f39d-4bcd-b860-c7878db53ceb_0">
											<gml:posList>35.66675043028219 139.74724953996122 38.963 35.66674998917796 139.74725033572946 38.963 35.66674998917796 139.74725033572946 41.329 35.66675043028219 139.74724953996122 41.329 35.66675043028219 139.74724953996122 38.963</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-adcb48d7-b2eb-4bfb-9a69-bc9fc0c0c023">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-adcb48d7-b2eb-4bfb-9a69-bc9fc0c0c023_0">
											<gml:posList>35.66675015988139 139.74726216555518 38.963 35.666750620134266 139.74726293826438 38.963 35.666750620134266 139.74726293826438 41.329 35.66675015988139 139.74726216555518 41.329 35.66675015988139 139.74726216555518 38.963</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-af0673ef-d031-450c-9a72-27447a060a78">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-af0673ef-d031-450c-9a72-27447a060a78_0">
											<gml:posList>35.66675092550038 139.7472487883179 38.963 35.66675043028219 139.74724953996122 38.963 35.66675043028219 139.74724953996122 41.329 35.66675092550038 139.7472487883179 41.329 35.66675092550038 139.7472487883179 38.963</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3101d742-1fae-4372-911a-5246f0476f1e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3101d742-1fae-4372-911a-5246f0476f1e_0">
											<gml:posList>35.666750620134266 139.74726293826438 38.963 35.66675113443794 139.74726366673252 38.963 35.66675113443794 139.74726366673252 41.329 35.666750620134266 139.74726293826438 41.329 35.666750620134266 139.74726293826438 38.963</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8ff12a42-4d12-4a53-a8d1-65e3180b15d0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8ff12a42-4d12-4a53-a8d1-65e3180b15d0_0">
											<gml:posList>35.666751465834594 139.7472481029007 38.963 35.66675092550038 139.7472487883179 38.963 35.66675092550038 139.7472487883179 41.329 35.666751465834594 139.7472481029007 41.329 35.666751465834594 139.7472481029007 38.963</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4d83d59f-98d6-45e8-97be-d6cd5628b993">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4d83d59f-98d6-45e8-97be-d6cd5628b993_0">
											<gml:posList>35.66675113443794 139.74726366673252 38.963 35.666751702776615 139.74726432886814 38.963 35.666751702776615 139.74726432886814 41.329 35.66675113443794 139.74726366673252 41.329 35.66675113443794 139.74726366673252 38.963</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-664b4f04-55f5-44b5-a2e7-aab01cf13a2c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-664b4f04-55f5-44b5-a2e7-aab01cf13a2c_0">
											<gml:posList>35.666752060290655 139.74724747265418 38.963 35.666751465834594 139.7472481029007 38.963 35.666751465834594 139.7472481029007 41.329 35.666752060290655 139.74724747265418 41.329 35.666752060290655 139.74724747265418 38.963</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e53078fb-d64e-4e52-8610-7f9346683ce0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e53078fb-d64e-4e52-8610-7f9346683ce0_0">
											<gml:posList>35.666751702776615 139.74726432886814 38.963 35.66675230713073 139.74726493573627 38.963 35.66675230713073 139.74726493573627 41.329 35.666751702776615 139.74726432886814 41.329 35.666751702776615 139.74726432886814 38.963</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b166297f-6c6b-44ce-aa83-eeecdcfdaeda">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b166297f-6c6b-44ce-aa83-eeecdcfdaeda_0">
											<gml:posList>35.66675269084902 139.74724690864346 38.963 35.666752060290655 139.74724747265418 38.963 35.666752060290655 139.74724747265418 41.329 35.66675269084902 139.74724690864346 41.329 35.66675269084902 139.74724690864346 38.963</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f2c051e4-8d18-4fd6-b22e-f9418d416c52">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f2c051e4-8d18-4fd6-b22e-f9418d416c52_0">
											<gml:posList>35.66675230713073 139.74726493573627 38.963 35.666752956498236 139.74726546523578 38.963 35.666752956498236 139.74726546523578 41.329 35.66675230713073 139.74726493573627 41.329 35.66675230713073 139.74726493573627 38.963</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-232d51ff-031a-4525-9200-c33df860ea4c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-232d51ff-031a-4525-9200-c33df860ea4c_0">
											<gml:posList>35.66675336652341 139.74724641085888 38.963 35.66675269084902 139.74724690864346 38.963 35.66675269084902 139.74724690864346 41.329 35.66675336652341 139.74724641085888 41.329 35.66675336652341 139.74724641085888 38.963</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-80b6c3c0-c94a-4617-bf7c-56b10227fb37">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-80b6c3c0-c94a-4617-bf7c-56b10227fb37_0">
											<gml:posList>35.666752956498236 139.74726546523578 38.963 35.66675364188118 139.74726593946784 38.963 35.66675364188118 139.74726593946784 41.329 35.666752956498236 139.74726546523578 41.329 35.666752956498236 139.74726546523578 38.963</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f69982df-d05a-411a-b812-e2ff72d0ae69">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f69982df-d05a-411a-b812-e2ff72d0ae69_0">
											<gml:posList>35.66675406929427 139.7472459903655 38.963 35.66675336652341 139.74724641085888 38.963 35.66675336652341 139.74724641085888 41.329 35.66675406929427 139.7472459903655 41.329 35.66675406929427 139.7472459903655 38.963</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-baeb9365-6efc-4426-b43f-67bd799ce59e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-baeb9365-6efc-4426-b43f-67bd799ce59e_0">
											<gml:posList>35.66675364188118 139.74726593946784 38.963 35.66675436325588 139.74726632529521 38.963 35.66675436325588 139.74726632529521 41.329 35.66675364188118 139.74726593946784 41.329 35.66675364188118 139.74726593946784 38.963</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e1b814ac-42bb-4b24-8cc3-e8c49e9f9ee0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e1b814ac-42bb-4b24-8cc3-e8c49e9f9ee0_0">
											<gml:posList>35.66675479916158 139.74724564716337 38.963 35.66675406929427 139.7472459903655 38.963 35.66675406929427 139.7472459903655 41.329 35.66675479916158 139.74724564716337 41.329 35.66675479916158 139.74724564716337 38.963</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5327d4ee-8bbc-47cc-8ad1-8d5b21f9cf96">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5327d4ee-8bbc-47cc-8ad1-8d5b21f9cf96_0">
											<gml:posList>35.66675436325588 139.74726632529521 38.963 35.66675510260278 139.74726663378297 38.963 35.66675510260278 139.74726663378297 41.329 35.66675436325588 139.74726632529521 41.329 35.66675436325588 139.74726632529521 38.963</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cc679aba-53d9-4d52-9148-8c4915756992">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cc679aba-53d9-4d52-9148-8c4915756992_0">
											<gml:posList>35.66675555612537 139.74724538125247 38.963 35.66675479916158 139.74724564716337 38.963 35.66675479916158 139.74724564716337 41.329 35.66675555612537 139.74724538125247 41.329 35.66675555612537 139.74724538125247 38.963</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-410f3230-7a33-4677-9389-ac1030aba991">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-410f3230-7a33-4677-9389-ac1030aba991_0">
											<gml:posList>35.66675510260278 139.74726663378297 38.963 35.66675585992977 139.74726687597686 38.963 35.66675585992977 139.74726687597686 41.329 35.66675510260278 139.74726663378297 41.329 35.66675510260278 139.74726663378297 38.963</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-41b25dea-4ad3-4c4c-9be1-a517bf601294">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-41b25dea-4ad3-4c4c-9be1-a517bf601294_0">
											<gml:posList>35.66675632215816 139.74724519265214 38.963 35.66675555612537 139.74724538125247 38.963 35.66675555612537 139.74724538125247 41.329 35.66675632215816 139.74724519265214 41.329 35.66675632215816 139.74724519265214 38.963</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b7c58b12-3ded-4f73-ab93-fb0f634252c9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b7c58b12-3ded-4f73-ab93-fb0f634252c9_0">
											<gml:posList>35.66675585992977 139.74726687597686 38.963 35.66675663521317 139.74726701873962 38.963 35.66675663521317 139.74726701873962 41.329 35.66675585992977 139.74726687597686 41.329 35.66675585992977 139.74726687597686 38.963</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-73a1c8db-3622-479b-9451-84adc3e0babc">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-73a1c8db-3622-479b-9451-84adc3e0babc_0">
											<gml:posList>35.66675710628157 139.7472450923985 38.963 35.66675632215816 139.74724519265214 38.963 35.66675632215816 139.74724519265214 41.329 35.66675710628157 139.7472450923985 41.329 35.66675710628157 139.7472450923985 38.963</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c911953e-c159-4742-8911-f4ee2a2d9f2f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c911953e-c159-4742-8911-f4ee2a2d9f2f_0">
											<gml:posList>35.66675663521317 139.74726701873962 38.963 35.666757419455024 139.74726708417245 38.963 35.666757419455024 139.74726708417245 41.329 35.66675663521317 139.74726701873962 41.329 35.66675663521317 139.74726701873962 38.963</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-46881c84-fbbf-4029-8a01-5b4c5c007f1c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-46881c84-fbbf-4029-8a01-5b4c5c007f1c_0">
											<gml:posList>35.66675710628157 139.7472450923985 38.963 35.66675710628157 139.7472450923985 41.329 35.66675788145445 139.7472450805205 41.329 35.66675788145445 139.7472450805205 38.963 35.66675710628157 139.7472450923985 38.963</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bc365910-3b2e-4198-895f-de8bfe662c39">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bc365910-3b2e-4198-895f-de8bfe662c39_0">
											<gml:posList>35.66676383507536 139.74726406179354 41.329 35.66676437540965 139.74726337637637 41.329 35.66676487063582 139.74726263577875 41.329 35.66676531174012 139.74726184001042 41.329 35.66676568971674 139.74726100012677 41.329 35.66676601357939 139.74726011611818 41.329 35.666766265316404 139.74725921009548 41.329 35.666766453941506 139.74725828204896 41.329 35.66676657945471 139.74725733197866 41.329 35.66676663285017 139.74725637094002 41.329 35.666766623149506 139.7472554099691 41.329 35.66676653233316 139.74725446013107 41.329 35.66676638743445 139.74725351035104 41.329 35.66676617044956 139.7472525937857 41.329 35.66676589037646 139.74725168833388 41.329 35.66676554723883 139.74725082713277 41.329 35.66676514103667 139.74725001018243 41.329 35.666764680775806 139.7472492264274 41.329 35.66676416647994 139.74724850900503 41.329 35.66676360714702 139.74724783581402 41.329 35.66676299377908 139.7472472289556 41.329 35.6667623444115 139.74724669945616 41.329 35.66676165902849 139.7472462252242 41.329 35.66676094666744 139.7472458393873 41.329 35.66676020732049 139.74724553089973 41.329 35.66675944098764 139.74724529976146 41.329 35.666758665696314 139.74724514595312 41.329 35.66675788145445 139.7472450805205 41.329 35.66675710628157 139.7472450923985 41.329 35.66675632215816 139.74724519265214 41.329 35.66675555612537 139.74724538125247 41.329 35.66675479916158 139.74724564716337 41.329 35.66675406929427 139.7472459903655 41.329 35.66675336652341 139.74724641085888 41.329 35.66675269084902 139.74724690864346 41.329 35.666752060290655 139.74724747265418 41.329 35.666751465834594 139.7472481029007 41.329 35.66675092550038 139.7472487883179 41.329 35.66675043028219 139.74724953996122 41.329 35.66674998917796 139.74725033572946 41.329 35.66674961120142 139.74725117561297 41.329 35.666749296344676 139.747252048566 41.329 35.66674903559399 139.74725295459822 41.329 35.66674884697681 139.7472538936903 41.329 35.66674872146364 139.74725484376037 41.329 35.6667486680603 139.74725579375306 41.329 35.66674868677468 139.74725675471407 41.329 35.66674876858517 139.74725771560736 41.329 35.66674891347596 139.74725865434144 41.329 35.66674913046869 139.74725958195233 41.329 35.666749410533846 139.74726047635826 41.329 35.66674975367141 139.7472613375592 41.329 35.66675015988139 139.74726216555518 41.329 35.666750620134266 139.74726293826438 41.329 35.66675113443794 139.74726366673252 41.329 35.666751702776615 139.74726432886814 41.329 35.66675230713073 139.74726493573627 41.329 35.666752956498236 139.74726546523578 41.329 35.66675364188118 139.74726593946784 41.329 35.66675436325588 139.74726632529521 41.329 35.66675510260278 139.74726663378297 41.329 35.66675585992977 139.74726687597686 41.329 35.66675663521317 139.74726701873962 41.329 35.666757419455024 139.74726708417245 41.329 35.66675820364163 139.74726707228504 41.329 35.66675897875134 139.74726697204127 41.329 35.66675975380578 139.7472667944772 41.329 35.66676050175588 139.74726652857615 41.329 35.66676123161536 139.74726617432842 41.329 35.66676193438629 139.7472657538352 41.329 35.666762610068645 139.74726526709645 41.329 35.66676324964083 139.74726470307613 41.329 35.66676383507536 139.74726406179354 41.329</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-37571205-1d6d-4f27-a926-b36eda33c438">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-37571205-1d6d-4f27-a926-b36eda33c438_0">
											<gml:posList>35.666757419455024 139.74726708417245 38.963 35.66675820364163 139.74726707228504 38.963 35.66675820364163 139.74726707228504 41.329 35.666757419455024 139.74726708417245 41.329 35.666757419455024 139.74726708417245 38.963</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d79320b6-e630-455e-b190-31f869fbf86b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d79320b6-e630-455e-b190-31f869fbf86b_0">
											<gml:posList>35.666758665696314 139.74724514595312 38.963 35.66675788145445 139.7472450805205 38.963 35.66675788145445 139.7472450805205 41.329 35.666758665696314 139.74724514595312 41.329 35.666758665696314 139.74724514595312 38.963</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-88a34a6d-24f6-4f8f-8db9-f823f386c57e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-88a34a6d-24f6-4f8f-8db9-f823f386c57e_0">
											<gml:posList>35.66675820364163 139.74726707228504 38.963 35.66675897875134 139.74726697204127 38.963 35.66675897875134 139.74726697204127 41.329 35.66675820364163 139.74726707228504 41.329 35.66675820364163 139.74726707228504 38.963</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-af9a84a6-e637-49d7-a9a8-24535517f662">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-af9a84a6-e637-49d7-a9a8-24535517f662_0">
											<gml:posList>35.66675944098764 139.74724529976146 38.963 35.666758665696314 139.74724514595312 38.963 35.666758665696314 139.74724514595312 41.329 35.66675944098764 139.74724529976146 41.329 35.66675944098764 139.74724529976146 38.963</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-75d98370-0e56-47f2-ad68-a7c41cef2f0d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-75d98370-0e56-47f2-ad68-a7c41cef2f0d_0">
											<gml:posList>35.66675897875134 139.74726697204127 38.963 35.66675975380578 139.7472667944772 38.963 35.66675975380578 139.7472667944772 41.329 35.66675897875134 139.74726697204127 41.329 35.66675897875134 139.74726697204127 38.963</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-02a8756f-7456-42fb-becf-3e2579324efe">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-02a8756f-7456-42fb-becf-3e2579324efe_0">
											<gml:posList>35.66676020732049 139.74724553089973 38.963 35.66675944098764 139.74724529976146 38.963 35.66675944098764 139.74724529976146 41.329 35.66676020732049 139.74724553089973 41.329 35.66676020732049 139.74724553089973 38.963</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f2489ad0-2b6d-44c5-800b-4538fd446e9a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f2489ad0-2b6d-44c5-800b-4538fd446e9a_0">
											<gml:posList>35.66675975380578 139.7472667944772 38.963 35.66676050175588 139.74726652857615 38.963 35.66676050175588 139.74726652857615 41.329 35.66675975380578 139.7472667944772 41.329 35.66675975380578 139.7472667944772 38.963</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-418bb860-b94e-4885-b802-f513ebe2bdad">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-418bb860-b94e-4885-b802-f513ebe2bdad_0">
											<gml:posList>35.66676094666744 139.7472458393873 38.963 35.66676020732049 139.74724553089973 38.963 35.66676020732049 139.74724553089973 41.329 35.66676094666744 139.7472458393873 41.329 35.66676094666744 139.7472458393873 38.963</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cef1b90c-5c64-4103-875b-cb0452e863e8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cef1b90c-5c64-4103-875b-cb0452e863e8_0">
											<gml:posList>35.66676050175588 139.74726652857615 38.963 35.66676123161536 139.74726617432842 38.963 35.66676123161536 139.74726617432842 41.329 35.66676050175588 139.74726652857615 41.329 35.66676050175588 139.74726652857615 38.963</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a24ab34d-6c66-4cfe-a3c7-372802193b0d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a24ab34d-6c66-4cfe-a3c7-372802193b0d_0">
											<gml:posList>35.66676165902849 139.7472462252242 38.963 35.66676094666744 139.7472458393873 38.963 35.66676094666744 139.7472458393873 41.329 35.66676165902849 139.7472462252242 41.329 35.66676165902849 139.7472462252242 38.963</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7966bd29-2a6c-4e31-826c-8cd492a4cd66">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7966bd29-2a6c-4e31-826c-8cd492a4cd66_0">
											<gml:posList>35.66676123161536 139.74726617432842 38.963 35.66676193438629 139.7472657538352 38.963 35.66676193438629 139.7472657538352 41.329 35.66676123161536 139.74726617432842 41.329 35.66676123161536 139.74726617432842 38.963</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c30e5c51-bbf0-48a5-9a46-0ca8baf8ba58">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c30e5c51-bbf0-48a5-9a46-0ca8baf8ba58_0">
											<gml:posList>35.66676056793088 139.74716999959574 32.5 35.66676250121949 139.74716348051896 32.5 35.66676250121949 139.74716348051896 33.834 35.66676056793088 139.74716999959574 33.834 35.66676056793088 139.74716999959574 32.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d9798589-aca1-41a7-aab8-e18bdb3eb783">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d9798589-aca1-41a7-aab8-e18bdb3eb783_0">
											<gml:posList>35.666761889116735 139.74721504279205 38.963 35.66676189862813 139.74721573866483 38.963 35.66676189862813 139.74721573866483 40.847 35.666761889116735 139.74721504279205 40.847 35.666761889116735 139.74721504279205 38.963</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e0557301-bd16-4bbf-8e58-bfb16dd09863">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e0557301-bd16-4bbf-8e58-bfb16dd09863_0">
											<gml:posList>35.666761915668154 139.74721435792634 38.963 35.666761889116735 139.74721504279205 38.963 35.666761889116735 139.74721504279205 40.847 35.666761915668154 139.74721435792634 40.847 35.666761915668154 139.74721435792634 38.963</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6278509f-09fb-4326-bd78-3923d0b3cc4c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6278509f-09fb-4326-bd78-3923d0b3cc4c_0">
											<gml:posList>35.66676189862813 139.74721573866483 38.963 35.66676197123563 139.74721643446983 38.963 35.66676197123563 139.74721643446983 40.847 35.66676189862813 139.74721573866483 40.847 35.66676189862813 139.74721573866483 38.963</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b0ef9215-c6df-4fcb-8a19-1e5af1037b08">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b0ef9215-c6df-4fcb-8a19-1e5af1037b08_0">
											<gml:posList>35.66676199630194 139.7472136730025 38.963 35.666761915668154 139.74721435792634 38.963 35.666761915668154 139.74721435792634 40.847 35.66676199630194 139.7472136730025 40.847 35.66676199630194 139.7472136730025 38.963</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ea299478-b6b5-458b-b9d9-78db20d3e01b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ea299478-b6b5-458b-b9d9-78db20d3e01b_0">
											<gml:posList>35.6667623444115 139.74724669945616 38.963 35.66676165902849 139.7472462252242 38.963 35.66676165902849 139.7472462252242 41.329 35.6667623444115 139.74724669945616 41.329 35.6667623444115 139.74724669945616 38.963</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-08844d08-56c2-4d37-ba7b-bf6c56a95a5d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-08844d08-56c2-4d37-ba7b-bf6c56a95a5d_0">
											<gml:posList>35.66676197123563 139.74721643446983 38.963 35.66676208889597 139.74721710813495 38.963 35.66676208889597 139.74721710813495 40.847 35.66676197123563 139.74721643446983 40.847 35.66676197123563 139.74721643446983 38.963</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-569124d7-90ff-46f6-8789-2dc0b20ed3f8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-569124d7-90ff-46f6-8789-2dc0b20ed3f8_0">
											<gml:posList>35.66676212201229 139.74721299907605 38.963 35.66676199630194 139.7472136730025 38.963 35.66676199630194 139.7472136730025 40.847 35.66676212201229 139.74721299907605 40.847 35.66676212201229 139.74721299907605 38.963</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cc45a795-4556-4443-a26d-7c6426ac2f78">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cc45a795-4556-4443-a26d-7c6426ac2f78_0">
											<gml:posList>35.66676208889597 139.74721710813495 38.963 35.666762251617065 139.7472177707059 38.963 35.666762251617065 139.7472177707059 40.847 35.66676208889597 139.74721710813495 40.847 35.66676208889597 139.74721710813495 38.963</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d11124d3-aa7e-40ed-b23d-43565e5d19b9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d11124d3-aa7e-40ed-b23d-43565e5d19b9_0">
											<gml:posList>35.6667623018129 139.74721233613724 38.963 35.66676212201229 139.74721299907605 38.963 35.66676212201229 139.74721299907605 40.847 35.6667623018129 139.74721233613724 40.847 35.6667623018129 139.74721233613724 38.963</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f0481cd4-b412-4a46-b6c1-5a0d6016c46e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f0481cd4-b412-4a46-b6c1-5a0d6016c46e_0">
											<gml:posList>35.66676193438629 139.7472657538352 38.963 35.666762610068645 139.74726526709645 38.963 35.666762610068645 139.74726526709645 41.329 35.66676193438629 139.7472657538352 41.329 35.66676193438629 139.7472657538352 38.963</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ee9e072d-52fe-4bd4-ba1e-3d210da73a41">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ee9e072d-52fe-4bd4-ba1e-3d210da73a41_0">
											<gml:posList>35.666762251617065 139.7472177707059 38.963 35.666762459391 139.74721841113694 38.963 35.666762459391 139.74721841113694 40.847 35.666762251617065 139.7472177707059 40.847 35.666762251617065 139.7472177707059 38.963</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3be0144a-b1ed-4f66-bcb4-caaeaba0ef8d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3be0144a-b1ed-4f66-bcb4-caaeaba0ef8d_0">
											<gml:posList>35.666762526697966 139.74721169524153 38.963 35.6667623018129 139.74721233613724 38.963 35.6667623018129 139.74721233613724 40.847 35.666762526697966 139.74721169524153 40.847 35.666762526697966 139.74721169524153 38.963</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-30e1c61d-0ddc-44c2-8e34-e1c5580d0e5f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-30e1c61d-0ddc-44c2-8e34-e1c5580d0e5f_0">
											<gml:posList>35.666762459391 139.74721841113694 38.963 35.66676271221779 139.74721902942807 38.963 35.66676271221779 139.74721902942807 40.847 35.666762459391 139.74721841113694 40.847 35.666762459391 139.74721841113694 38.963</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e3da6814-e939-418c-a777-7d63d1613467">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e3da6814-e939-418c-a777-7d63d1613467_0">
											<gml:posList>35.66676299377908 139.7472472289556 38.963 35.6667623444115 139.74724669945616 38.963 35.6667623444115 139.74724669945616 41.329 35.66676299377908 139.7472472289556 41.329 35.66676299377908 139.7472472289556 38.963</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-714818ce-95cc-4c6a-b243-74d38d485349">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-714818ce-95cc-4c6a-b243-74d38d485349_0">
											<gml:posList>35.66676278766163 139.74721108744436 38.963 35.666762526697966 139.74721169524153 38.963 35.666762526697966 139.74721169524153 40.847 35.66676278766163 139.74721108744436 40.847 35.66676278766163 139.74721108744436 38.963</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7d3db870-3dba-4446-bd07-77c8bc6b6376">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7d3db870-3dba-4446-bd07-77c8bc6b6376_0">
											<gml:posList>35.66676271221779 139.74721902942807 38.963 35.66676301009742 139.74721962557933 38.963 35.66676301009742 139.74721962557933 40.847 35.66676271221779 139.74721902942807 40.847 35.66676271221779 139.74721902942807 38.963</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1c9b5d3b-3d0a-41f1-acac-6225d6acc643">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1c9b5d3b-3d0a-41f1-acac-6225d6acc643_0">
											<gml:posList>35.666762610068645 139.74726526709645 38.963 35.66676324964083 139.74726470307613 38.963 35.66676324964083 139.74726470307613 41.329 35.666762610068645 139.74726526709645 41.329 35.666762610068645 139.74726526709645 38.963</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9d7a1435-86b1-43be-b81e-1ff54a8da704">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9d7a1435-86b1-43be-b81e-1ff54a8da704_0">
											<gml:posList>35.66676310273139 139.74721051272635 38.963 35.66676278766163 139.74721108744436 38.963 35.66676278766163 139.74721108744436 40.847 35.66676310273139 139.74721051272635 40.847 35.66676310273139 139.74721051272635 38.963</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-65ea646c-950b-4d85-832c-de220062c77a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-65ea646c-950b-4d85-832c-de220062c77a_0">
											<gml:posList>35.66676301009742 139.74721962557933 38.963 35.66676335301411 139.74722017749914 38.963 35.66676335301411 139.74722017749914 40.847 35.66676301009742 139.74721962557933 40.847 35.66676301009742 139.74721962557933 38.963</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-47c9cb1e-056d-438b-a979-62950bc6399f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-47c9cb1e-056d-438b-a979-62950bc6399f_0">
											<gml:posList>35.666763444866014 139.74720997111658 38.963 35.66676310273139 139.74721051272635 38.963 35.66676310273139 139.74721051272635 40.847 35.666763444866014 139.74720997111658 40.847 35.666763444866014 139.74720997111658 38.963</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e9a502b3-585a-49bb-a323-8a2d7bb91a4d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e9a502b3-585a-49bb-a323-8a2d7bb91a4d_0">
											<gml:posList>35.66676360714702 139.74724783581402 38.963 35.66676299377908 139.7472472289556 38.963 35.66676299377908 139.7472472289556 41.329 35.66676360714702 139.74724783581402 41.329 35.66676360714702 139.74724783581402 38.963</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-df680d41-02c0-41b7-b8ef-41a393ee1611">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-df680d41-02c0-41b7-b8ef-41a393ee1611_0">
											<gml:posList>35.66676324964083 139.74726470307613 38.963 35.66676383507536 139.74726406179354 38.963 35.66676383507536 139.74726406179354 41.329 35.66676324964083 139.74726470307613 41.329 35.66676324964083 139.74726470307613 38.963</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-30dfa6c7-9916-46f6-b4c1-2d5ad961cfba">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-30dfa6c7-9916-46f6-b4c1-2d5ad961cfba_0">
											<gml:posList>35.66676335301411 139.74722017749914 38.963 35.66676373196201 139.74722069624303 38.963 35.66676373196201 139.74722069624303 40.847 35.66676335301411 139.74722017749914 40.847 35.66676335301411 139.74722017749914 38.963</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d391cb03-af21-4c5d-b895-b327898f14a0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d391cb03-af21-4c5d-b895-b327898f14a0_0">
											<gml:posList>35.666763832093004 139.74720946259563 38.963 35.666763444866014 139.74720997111658 38.963 35.666763444866014 139.74720997111658 40.847 35.666763832093004 139.74720946259563 40.847 35.666763832093004 139.74720946259563 38.963</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fddc6c5b-d47b-4dab-aab9-b229b4c39e4f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fddc6c5b-d47b-4dab-aab9-b229b4c39e4f_0">
											<gml:posList>35.66676416647994 139.74724850900503 38.963 35.66676360714702 139.74724783581402 38.963 35.66676360714702 139.74724783581402 41.329 35.66676416647994 139.74724850900503 41.329 35.66676416647994 139.74724850900503 38.963</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-587b104b-c2bc-44d0-a87a-52a6b583a729">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-587b104b-c2bc-44d0-a87a-52a6b583a729_0">
											<gml:posList>35.66676373196201 139.74722069624303 38.963 35.66676414693323 139.74722117076516 38.963 35.66676414693323 139.74722117076516 40.847 35.66676373196201 139.74722069624303 40.847 35.66676373196201 139.74722069624303 38.963</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b7515500-43a9-4206-b379-86f82946a34b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b7515500-43a9-4206-b379-86f82946a34b_0">
											<gml:posList>35.666764255406505 139.74720899821898 38.963 35.666763832093004 139.74720946259563 38.963 35.666763832093004 139.74720946259563 40.847 35.666764255406505 139.74720899821898 40.847 35.666764255406505 139.74720899821898 38.963</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fa1a0fe9-af4a-49f9-806a-14df3f1a4063">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fa1a0fe9-af4a-49f9-806a-14df3f1a4063_0">
											<gml:posList>35.66676383507536 139.74726406179354 38.963 35.66676437540965 139.74726337637637 38.963 35.66676437540965 139.74726337637637 41.329 35.66676383507536 139.74726406179354 41.329 35.66676383507536 139.74726406179354 38.963</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5f178879-329a-4842-9708-3afa061bf8d1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5f178879-329a-4842-9708-3afa061bf8d1_0">
											<gml:posList>35.66676414693323 139.74722117076516 38.963 35.666764588914056 139.74722160107527 38.963 35.666764588914056 139.74722160107527 40.847 35.66676414693323 139.74722117076516 40.847 35.66676414693323 139.74722117076516 38.963</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7a73c7a4-af22-4ea0-9533-e0d28bb7ba17">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7a73c7a4-af22-4ea0-9533-e0d28bb7ba17_0">
											<gml:posList>35.666764680775806 139.7472492264274 38.963 35.66676416647994 139.74724850900503 38.963 35.66676416647994 139.74724850900503 41.329 35.666764680775806 139.7472492264274 41.329 35.666764680775806 139.7472492264274 38.963</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4fc42735-40b9-4264-a888-d2bcc179d728">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4fc42735-40b9-4264-a888-d2bcc179d728_0">
											<gml:posList>35.66676471480652 139.7472085779866 38.963 35.666764255406505 139.74720899821898 38.963 35.666764255406505 139.74720899821898 40.847 35.66676471480652 139.7472085779866 40.847 35.66676471480652 139.7472085779866 38.963</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b18fe1d6-676c-47ae-85fb-0dea071e0ed0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b18fe1d6-676c-47ae-85fb-0dea071e0ed0_0">
											<gml:posList>35.66676437540965 139.74726337637637 38.963 35.66676487063582 139.74726263577875 38.963 35.66676487063582 139.74726263577875 41.329 35.66676437540965 139.74726337637637 41.329 35.66676437540965 139.74726337637637 38.963</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b9b16528-db7c-4707-ab7d-05178de8a787">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b9b16528-db7c-4707-ab7d-05178de8a787_0">
											<gml:posList>35.666764588914056 139.74722160107527 38.963 35.66676505789656 139.74722197612755 38.963 35.66676505789656 139.74722197612755 40.847 35.666764588914056 139.74722160107527 40.847 35.666764588914056 139.74722160107527 38.963</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e73df0ec-8657-4d8d-85ed-88b1ad8ae902">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e73df0ec-8657-4d8d-85ed-88b1ad8ae902_0">
											<gml:posList>35.66676514103667 139.74725001018243 38.963 35.666764680775806 139.7472492264274 38.963 35.666764680775806 139.7472492264274 41.329 35.66676514103667 139.74725001018243 41.329 35.66676514103667 139.74725001018243 38.963</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e9913d65-c7c4-4598-b4c6-6b81f84ddd5d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e9913d65-c7c4-4598-b4c6-6b81f84ddd5d_0">
											<gml:posList>35.666765192273495 139.74720821296364 38.963 35.66676471480652 139.7472085779866 38.963 35.66676471480652 139.7472085779866 40.847 35.666765192273495 139.74720821296364 40.847 35.666765192273495 139.74720821296364 38.963</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7124aecd-3543-432f-8e73-92d593b9b0bd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7124aecd-3543-432f-8e73-92d593b9b0bd_0">
											<gml:posList>35.66676487063582 139.74726263577875 38.963 35.66676531174012 139.74726184001042 38.963 35.66676531174012 139.74726184001042 41.329 35.66676487063582 139.74726263577875 41.329 35.66676487063582 139.74726263577875 38.963</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-03042524-28b2-4188-977a-2a10879c3fa9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-03042524-28b2-4188-977a-2a10879c3fa9_0">
											<gml:posList>35.66676505789656 139.74722197612755 38.963 35.66676556290239 139.7472223069581 38.963 35.66676556290239 139.7472223069581 40.847 35.66676505789656 139.74722197612755 40.847 35.66676505789656 139.74722197612755 38.963</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-84a589fc-f1d4-4802-9202-ec45bcbf6521">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-84a589fc-f1d4-4802-9202-ec45bcbf6521_0">
											<gml:posList>35.66676554723883 139.74725082713277 38.963 35.66676514103667 139.74725001018243 38.963 35.66676514103667 139.74725001018243 41.329 35.66676554723883 139.74725082713277 41.329 35.66676554723883 139.74725082713277 38.963</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4b04acd4-3953-44a3-a4a5-46a58bf9c7df">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4b04acd4-3953-44a3-a4a5-46a58bf9c7df_0">
											<gml:posList>35.66676569682116 139.7472079031404 38.963 35.666765192273495 139.74720821296364 38.963 35.666765192273495 139.74720821296364 40.847 35.66676569682116 139.7472079031404 40.847 35.66676569682116 139.7472079031404 38.963</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8503a57e-bb22-4581-8301-bde2dd42d0a3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8503a57e-bb22-4581-8301-bde2dd42d0a3_0">
											<gml:posList>35.66676531174012 139.74726184001042 38.963 35.66676568971674 139.74726100012677 38.963 35.66676568971674 139.74726100012677 41.329 35.66676531174012 139.74726184001042 41.329 35.66676531174012 139.74726184001042 38.963</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6a777735-8e30-4d36-a2e9-229b010ae1cc">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6a777735-8e30-4d36-a2e9-229b010ae1cc_0">
											<gml:posList>35.66676589037646 139.74725168833388 38.963 35.66676554723883 139.74725082713277 38.963 35.66676554723883 139.74725082713277 41.329 35.66676589037646 139.74725168833388 41.329 35.66676589037646 139.74725168833388 38.963</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b40bb913-67be-4b31-ad87-e3e4366abc7e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b40bb913-67be-4b31-ad87-e3e4366abc7e_0">
											<gml:posList>35.66676556290239 139.7472223069581 38.963 35.66676607687456 139.74722257150444 38.963 35.66676607687456 139.74722257150444 40.847 35.66676556290239 139.7472223069581 40.847 35.66676556290239 139.7472223069581 38.963</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-dfc9a2bd-c7eb-4fb9-af20-543c3817a27f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-dfc9a2bd-c7eb-4fb9-af20-543c3817a27f_0">
											<gml:posList>35.66676568971674 139.74726100012677 38.963 35.66676601357939 139.74726011611818 38.963 35.66676601357939 139.74726011611818 41.329 35.66676568971674 139.74726100012677 41.329 35.66676568971674 139.74726100012677 38.963</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a105efb8-1357-483b-a833-368fbaab8807">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a105efb8-1357-483b-a833-368fbaab8807_0">
											<gml:posList>35.66676621943578 139.74720764852657 38.963 35.66676569682116 139.7472079031404 38.963 35.66676569682116 139.7472079031404 40.847 35.66676621943578 139.74720764852657 40.847 35.66676621943578 139.74720764852657 38.963</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3a431b57-4ead-4f65-a009-493e2469923f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3a431b57-4ead-4f65-a009-493e2469923f_0">
											<gml:posList>35.66676617044956 139.7472525937857 38.963 35.66676589037646 139.74725168833388 38.963 35.66676589037646 139.74725168833388 41.329 35.66676617044956 139.7472525937857 41.329 35.66676617044956 139.7472525937857 38.963</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1275b5a1-d1d1-4962-89fd-4f32c4405f36">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1275b5a1-d1d1-4962-89fd-4f32c4405f36_0">
											<gml:posList>35.66676601357939 139.74726011611818 38.963 35.666766265316404 139.74725921009548 38.963 35.666766265316404 139.74725921009548 41.329 35.66676601357939 139.74726011611818 41.329 35.66676601357939 139.74726011611818 38.963</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d5923078-41f5-4399-9f0d-61440712b394">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d5923078-41f5-4399-9f0d-61440712b394_0">
											<gml:posList>35.66676638743445 139.74725351035104 38.963 35.66676617044956 139.7472525937857 38.963 35.66676617044956 139.7472525937857 41.329 35.66676638743445 139.74725351035104 41.329 35.66676638743445 139.74725351035104 38.963</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4b18a812-bb98-4e5b-b8cf-eb082786cc53">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4b18a812-bb98-4e5b-b8cf-eb082786cc53_0">
											<gml:posList>35.666766265316404 139.74725921009548 38.963 35.666766453941506 139.74725828204896 38.963 35.666766453941506 139.74725828204896 41.329 35.666766265316404 139.74725921009548 41.329 35.666766265316404 139.74725921009548 38.963</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f16b1caf-0a60-4a64-acad-c85c446d380c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f16b1caf-0a60-4a64-acad-c85c446d380c_0">
											<gml:posList>35.66676607687456 139.74722257150444 38.963 35.666766617856325 139.74722279183874 38.963 35.666766617856325 139.74722279183874 40.847 35.66676607687456 139.74722257150444 40.847 35.66676607687456 139.74722257150444 38.963</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-de35e64e-c9f8-4853-addf-a8d49317ff78">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-de35e64e-c9f8-4853-addf-a8d49317ff78_0">
											<gml:posList>35.66676653233316 139.74725446013107 38.963 35.66676638743445 139.74725351035104 38.963 35.66676638743445 139.74725351035104 41.329 35.66676653233316 139.74725446013107 41.329 35.66676653233316 139.74725446013107 38.963</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b5b1052b-ae4b-4265-95cc-aec2c4a60330">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b5b1052b-ae4b-4265-95cc-aec2c4a60330_0">
											<gml:posList>35.666766453941506 139.74725828204896 38.963 35.66676657945471 139.74725733197866 38.963 35.66676657945471 139.74725733197866 41.329 35.666766453941506 139.74725828204896 41.329 35.666766453941506 139.74725828204896 38.963</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-abc1506d-b971-4b1b-80b1-c289a92c0098">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-abc1506d-b971-4b1b-80b1-c289a92c0098_0">
											<gml:posList>35.66676676010947 139.74720743807637 38.963 35.66676621943578 139.74720764852657 38.963 35.66676621943578 139.74720764852657 40.847 35.66676676010947 139.74720743807637 40.847 35.66676676010947 139.74720743807637 38.963</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e1d8f9ca-6f6e-49e5-85bf-f2e42af135a1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e1d8f9ca-6f6e-49e5-85bf-f2e42af135a1_0">
											<gml:posList>35.666766623149506 139.7472554099691 38.963 35.66676653233316 139.74725446013107 38.963 35.66676653233316 139.74725446013107 41.329 35.666766623149506 139.7472554099691 41.329 35.666766623149506 139.7472554099691 38.963</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e8d72c38-25a6-4286-a2bb-39bcf533b16c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e8d72c38-25a6-4286-a2bb-39bcf533b16c_0">
											<gml:posList>35.66676657945471 139.74725733197866 38.963 35.66676663285017 139.74725637094002 38.963 35.66676663285017 139.74725637094002 41.329 35.66676657945471 139.74725733197866 41.329 35.66676657945471 139.74725733197866 38.963</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5ca7240a-a546-43a5-ad0f-8bb0d0b8af8a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5ca7240a-a546-43a5-ad0f-8bb0d0b8af8a_0">
											<gml:posList>35.66676663285017 139.74725637094002 38.963 35.666766623149506 139.7472554099691 38.963 35.666766623149506 139.7472554099691 41.329 35.66676663285017 139.74725637094002 41.329 35.66676663285017 139.74725637094002 38.963</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-915306ab-a122-49dd-a393-c2303571dc19">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-915306ab-a122-49dd-a393-c2303571dc19_0">
											<gml:posList>35.666766617856325 139.74722279183874 38.963 35.66676716780443 139.74722294588886 38.963 35.66676716780443 139.74722294588886 40.847 35.666766617856325 139.74722279183874 40.847 35.666766617856325 139.74722279183874 38.963</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0f4a4e65-b233-4a2e-ab45-4419588fa264">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0f4a4e65-b233-4a2e-ab45-4419588fa264_0">
											<gml:posList>35.666767318865915 139.7472073049271 38.963 35.66676676010947 139.74720743807637 38.963 35.66676676010947 139.74720743807637 40.847 35.666767318865915 139.7472073049271 40.847 35.666767318865915 139.7472073049271 38.963</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d99d85f9-03d4-42f4-a331-24a059c342a8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d99d85f9-03d4-42f4-a331-24a059c342a8_0">
											<gml:posList>35.66676716780443 139.74722294588886 38.963 35.66676772672675 139.74722304470052 38.963 35.66676772672675 139.74722304470052 40.847 35.66676716780443 139.74722294588886 40.847 35.66676716780443 139.74722294588886 38.963</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5d082658-9213-4099-8fec-8a18003f32da">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5d082658-9213-4099-8fec-8a18003f32da_0">
											<gml:posList>35.66676787765395 139.74720721596086 38.963 35.666767318865915 139.7472073049271 38.963 35.666767318865915 139.7472073049271 40.847 35.66676787765395 139.74720721596086 40.847 35.66676787765395 139.74720721596086 38.963</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7994e6f0-7785-4692-b34a-a8546a14ce19">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7994e6f0-7785-4692-b34a-a8546a14ce19_0">
											<gml:posList>35.66676772672675 139.74722304470052 38.963 35.6667682856096 139.74722308828342 38.963 35.6667682856096 139.74722308828342 40.847 35.66676772672675 139.74722304470052 40.847 35.66676772672675 139.74722304470052 38.963</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2ef742b4-9d3f-4fac-9eb8-63784ea4521f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2ef742b4-9d3f-4fac-9eb8-63784ea4521f_0">
											<gml:posList>35.666768445511025 139.74720720430517 38.963 35.66676787765395 139.74720721596086 38.963 35.66676787765395 139.74720721596086 40.847 35.666768445511025 139.74720720430517 40.847 35.666768445511025 139.74720720430517 38.963</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-471af0db-da10-412f-be4e-c27e62cfd2d8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-471af0db-da10-412f-be4e-c27e62cfd2d8_0">
											<gml:posList>35.66677427172217 139.74721187040544 40.847 35.66677401889533 139.74721125211423 40.847 35.666773721015666 139.7472106559629 40.847 35.66677337809894 139.74721010404303 40.847 35.66677300816472 139.7472095852895 40.847 35.66677259319344 139.74720911076736 40.847 35.666772151220485 139.74720869150306 40.847 35.6667716732163 139.74720830541477 40.847 35.666771177232064 139.74720798562032 40.847 35.666770654238235 139.74720771003797 40.847 35.66677012227017 139.7472074896941 40.847 35.66676957232205 139.74720733564408 40.847 35.666769004385976 139.7472072368422 40.847 35.666768445511025 139.74720720430517 40.847 35.66676787765395 139.74720721596086 40.847 35.666767318865915 139.7472073049271 40.847 35.66676676010947 139.74720743807637 40.847 35.66676621943578 139.74720764852657 40.847 35.66676569682116 139.7472079031404 40.847 35.666765192273495 139.74720821296364 40.847 35.66676471480652 139.7472085779866 40.847 35.666764255406505 139.74720899821898 40.847 35.666763832093004 139.74720946259563 40.847 35.666763444866014 139.74720997111658 40.847 35.66676310273139 139.74721051272635 40.847 35.66676278766163 139.74721108744436 40.847 35.666762526697966 139.74721169524153 40.847 35.6667623018129 139.74721233613724 40.847 35.66676212201229 139.74721299907605 40.847 35.66676199630194 139.7472136730025 40.847 35.666761915668154 139.74721435792634 40.847 35.666761889116735 139.74721504279205 40.847 35.66676189862813 139.74721573866483 40.847 35.66676197123563 139.74721643446983 40.847 35.66676208889597 139.74721710813495 40.847 35.666762251617065 139.7472177707059 40.847 35.666762459391 139.74721841113694 40.847 35.66676271221779 139.74721902942807 40.847 35.66676301009742 139.74721962557933 40.847 35.66676335301411 139.74722017749914 40.847 35.66676373196201 139.74722069624303 40.847 35.66676414693323 139.74722117076516 40.847 35.666764588914056 139.74722160107527 40.847 35.66676505789656 139.74722197612755 40.847 35.66676556290239 139.7472223069581 40.847 35.66676607687456 139.74722257150444 40.847 35.666766617856325 139.74722279183874 40.847 35.66676716780443 139.74722294588886 40.847 35.66676772672675 139.74722304470052 40.847 35.6667682856096 139.74722308828342 40.847 35.666768853458784 139.74722306558212 40.847 35.66676942126057 139.74722297660628 40.847 35.6667699710033 139.74722284346677 40.847 35.66677051167701 139.7472226330167 40.847 35.66677103429166 139.7472223784029 40.847 35.66677153883936 139.74722206857976 40.847 35.66677202532011 139.74722170354713 40.847 35.66677247570644 139.74722128332448 40.847 35.66677289901998 139.74722081894785 40.847 35.6667732862549 139.74722032147267 40.847 35.66677363739542 139.7472197688074 40.847 35.66677394345149 139.74721919409905 40.847 35.66677421342892 139.74721858629212 40.847 35.666774438314015 139.74721794539636 40.847 35.66677460910882 139.7472172935129 40.847 35.666774734811284 139.74721660854058 40.847 35.666774815445095 139.74721592361666 40.847 35.666774851010246 139.74721523874112 40.847 35.66677483248512 139.7472145428779 40.847 35.666774759885506 139.74721385811856 40.847 35.66677465123097 139.7472131733979 40.847 35.66677447949613 139.74721251083656 40.847 35.66677427172217 139.74721187040544 40.847</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4ca1b44f-1fd1-4749-805d-e43a784d3249">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4ca1b44f-1fd1-4749-805d-e43a784d3249_0">
											<gml:posList>35.6667682856096 139.74722308828342 38.963 35.666768853458784 139.74722306558212 38.963 35.666768853458784 139.74722306558212 40.847 35.6667682856096 139.74722308828342 40.847 35.6667682856096 139.74722308828342 38.963</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-852c26fa-cb5d-47fc-bff2-18cfb864d205">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-852c26fa-cb5d-47fc-bff2-18cfb864d205_0">
											<gml:posList>35.666769004385976 139.7472072368422 38.963 35.666768445511025 139.74720720430517 38.963 35.666768445511025 139.74720720430517 40.847 35.666769004385976 139.7472072368422 40.847 35.666769004385976 139.7472072368422 38.963</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7ccdb0ae-39fd-47aa-b199-c73c078cca08">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7ccdb0ae-39fd-47aa-b199-c73c078cca08_0">
											<gml:posList>35.666768853458784 139.74722306558212 38.963 35.66676942126057 139.74722297660628 38.963 35.66676942126057 139.74722297660628 40.847 35.666768853458784 139.74722306558212 40.847 35.666768853458784 139.74722306558212 38.963</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0aa94f62-265e-4a50-a6f8-dd34703f8a4e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0aa94f62-265e-4a50-a6f8-dd34703f8a4e_0">
											<gml:posList>35.66676957232205 139.74720733564408 38.963 35.666769004385976 139.7472072368422 38.963 35.666769004385976 139.7472072368422 40.847 35.66676957232205 139.74720733564408 40.847 35.66676957232205 139.74720733564408 38.963</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ec68c888-8101-4921-a654-1a873e84c942">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ec68c888-8101-4921-a654-1a873e84c942_0">
											<gml:posList>35.66676942126057 139.74722297660628 38.963 35.6667699710033 139.74722284346677 38.963 35.6667699710033 139.74722284346677 40.847 35.66676942126057 139.74722297660628 40.847 35.66676942126057 139.74722297660628 38.963</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e4cf874f-80a5-4692-a6b7-38502b58c295">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e4cf874f-80a5-4692-a6b7-38502b58c295_0">
											<gml:posList>35.66677012227017 139.7472074896941 38.963 35.66676957232205 139.74720733564408 38.963 35.66676957232205 139.74720733564408 40.847 35.66677012227017 139.7472074896941 40.847 35.66677012227017 139.7472074896941 38.963</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-eb98545d-c0a2-42af-9d4e-baaf95ba0b5a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-eb98545d-c0a2-42af-9d4e-baaf95ba0b5a_0">
											<gml:posList>35.6667699710033 139.74722284346677 38.963 35.66677051167701 139.7472226330167 38.963 35.66677051167701 139.7472226330167 40.847 35.6667699710033 139.74722284346677 40.847 35.6667699710033 139.74722284346677 38.963</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-49194c36-10e6-4bd1-8810-6a56c62ba44b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-49194c36-10e6-4bd1-8810-6a56c62ba44b_0">
											<gml:posList>35.666770654238235 139.74720771003797 38.963 35.66677012227017 139.7472074896941 38.963 35.66677012227017 139.7472074896941 40.847 35.666770654238235 139.74720771003797 40.847 35.666770654238235 139.74720771003797 38.963</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-75d08a69-5d1e-40e2-98b4-614afc6736cd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-75d08a69-5d1e-40e2-98b4-614afc6736cd_0">
											<gml:posList>35.66677051167701 139.7472226330167 38.963 35.66677103429166 139.7472223784029 38.963 35.66677103429166 139.7472223784029 40.847 35.66677051167701 139.7472226330167 40.847 35.66677051167701 139.7472226330167 38.963</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6c6994b9-eaf7-4b6d-b231-4c9666e5bfab">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6c6994b9-eaf7-4b6d-b231-4c9666e5bfab_0">
											<gml:posList>35.666771177232064 139.74720798562032 38.963 35.666770654238235 139.74720771003797 38.963 35.666770654238235 139.74720771003797 40.847 35.666771177232064 139.74720798562032 40.847 35.666771177232064 139.74720798562032 38.963</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1140db2b-a83e-4407-9be6-b803b531f741">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1140db2b-a83e-4407-9be6-b803b531f741_0">
											<gml:posList>35.66677103429166 139.7472223784029 38.963 35.66677153883936 139.74722206857976 38.963 35.66677153883936 139.74722206857976 40.847 35.66677103429166 139.7472223784029 40.847 35.66677103429166 139.7472223784029 38.963</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3f0146ad-9a7a-4461-8aed-c1f673796ddb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3f0146ad-9a7a-4461-8aed-c1f673796ddb_0">
											<gml:posList>35.6667716732163 139.74720830541477 38.963 35.666771177232064 139.74720798562032 38.963 35.666771177232064 139.74720798562032 40.847 35.6667716732163 139.74720830541477 40.847 35.6667716732163 139.74720830541477 38.963</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a89805c4-5d77-4761-9f94-3378235fdf85">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a89805c4-5d77-4761-9f94-3378235fdf85_0">
											<gml:posList>35.66677153883936 139.74722206857976 38.963 35.66677202532011 139.74722170354713 38.963 35.66677202532011 139.74722170354713 40.847 35.66677153883936 139.74722206857976 40.847 35.66677153883936 139.74722206857976 38.963</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8b7d05dd-fc99-47f3-ac8f-ca33c99cfa7e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8b7d05dd-fc99-47f3-ac8f-ca33c99cfa7e_0">
											<gml:posList>35.666772151220485 139.74720869150306 38.963 35.6667716732163 139.74720830541477 38.963 35.6667716732163 139.74720830541477 40.847 35.666772151220485 139.74720869150306 40.847 35.666772151220485 139.74720869150306 38.963</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cc51fab4-5f18-4569-8519-436c7d05b158">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cc51fab4-5f18-4569-8519-436c7d05b158_0">
											<gml:posList>35.66677202532011 139.74722170354713 38.963 35.66677247570644 139.74722128332448 38.963 35.66677247570644 139.74722128332448 40.847 35.66677202532011 139.74722170354713 40.847 35.66677202532011 139.74722170354713 38.963</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4495414a-7df0-4e30-9705-28dad1524931">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4495414a-7df0-4e30-9705-28dad1524931_0">
											<gml:posList>35.66677259319344 139.74720911076736 38.963 35.666772151220485 139.74720869150306 38.963 35.666772151220485 139.74720869150306 40.847 35.66677259319344 139.74720911076736 40.847 35.66677259319344 139.74720911076736 38.963</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7315321d-98e6-471e-9399-b58371c3ede8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7315321d-98e6-471e-9399-b58371c3ede8_0">
											<gml:posList>35.66677247570644 139.74722128332448 38.963 35.66677289901998 139.74722081894785 38.963 35.66677289901998 139.74722081894785 40.847 35.66677247570644 139.74722128332448 40.847 35.66677247570644 139.74722128332448 38.963</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-07da4a89-6a59-4a7c-a9c5-5487d5d065eb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-07da4a89-6a59-4a7c-a9c5-5487d5d065eb_0">
											<gml:posList>35.66677300816472 139.7472095852895 38.963 35.66677259319344 139.74720911076736 38.963 35.66677259319344 139.74720911076736 40.847 35.66677300816472 139.7472095852895 40.847 35.66677300816472 139.7472095852895 38.963</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6905a6eb-c1d9-4ae5-8bcc-5020bc7d1419">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6905a6eb-c1d9-4ae5-8bcc-5020bc7d1419_0">
											<gml:posList>35.66677289901998 139.74722081894785 38.963 35.6667732862549 139.74722032147267 38.963 35.6667732862549 139.74722032147267 40.847 35.66677289901998 139.74722081894785 40.847 35.66677289901998 139.74722081894785 38.963</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-eb16d1e0-fa8b-4fe5-af44-48c7285d893b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-eb16d1e0-fa8b-4fe5-af44-48c7285d893b_0">
											<gml:posList>35.66677337809894 139.74721010404303 38.963 35.66677300816472 139.7472095852895 38.963 35.66677300816472 139.7472095852895 40.847 35.66677337809894 139.74721010404303 40.847 35.66677337809894 139.74721010404303 38.963</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5042a28b-4f48-4843-88ff-b711b325109c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5042a28b-4f48-4843-88ff-b711b325109c_0">
											<gml:posList>35.6667732862549 139.74722032147267 38.963 35.66677363739542 139.7472197688074 38.963 35.66677363739542 139.7472197688074 40.847 35.6667732862549 139.74722032147267 40.847 35.6667732862549 139.74722032147267 38.963</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b5511ded-a8d7-4751-90bd-6f3af366a614">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b5511ded-a8d7-4751-90bd-6f3af366a614_0">
											<gml:posList>35.666773721015666 139.7472106559629 38.963 35.66677337809894 139.74721010404303 38.963 35.66677337809894 139.74721010404303 40.847 35.666773721015666 139.7472106559629 40.847 35.666773721015666 139.7472106559629 38.963</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1af530de-f389-4fc0-ae55-622c71c25e76">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1af530de-f389-4fc0-ae55-622c71c25e76_0">
											<gml:posList>35.66677363739542 139.7472197688074 38.963 35.66677394345149 139.74721919409905 38.963 35.66677394345149 139.74721919409905 40.847 35.66677363739542 139.7472197688074 40.847 35.66677363739542 139.7472197688074 38.963</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-04eb3d99-e4b1-4e7b-aac0-d6103f7ca1fb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-04eb3d99-e4b1-4e7b-aac0-d6103f7ca1fb_0">
											<gml:posList>35.66677401889533 139.74721125211423 38.963 35.666773721015666 139.7472106559629 38.963 35.666773721015666 139.7472106559629 40.847 35.66677401889533 139.74721125211423 40.847 35.66677401889533 139.74721125211423 38.963</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-40ff053f-28a7-44d4-979b-eb4232df3860">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-40ff053f-28a7-44d4-979b-eb4232df3860_0">
											<gml:posList>35.66677394345149 139.74721919409905 38.963 35.66677421342892 139.74721858629212 38.963 35.66677421342892 139.74721858629212 40.847 35.66677394345149 139.74721919409905 40.847 35.66677394345149 139.74721919409905 38.963</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ea55fa3a-5cf3-4a60-a01c-e839d12fcd5a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ea55fa3a-5cf3-4a60-a01c-e839d12fcd5a_0">
											<gml:posList>35.66677427172217 139.74721187040544 38.963 35.66677401889533 139.74721125211423 38.963 35.66677401889533 139.74721125211423 40.847 35.66677427172217 139.74721187040544 40.847 35.66677427172217 139.74721187040544 38.963</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7b50d41f-9feb-4413-a76d-4affe19f528e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7b50d41f-9feb-4413-a76d-4affe19f528e_0">
											<gml:posList>35.66677421342892 139.74721858629212 38.963 35.666774438314015 139.74721794539636 38.963 35.666774438314015 139.74721794539636 40.847 35.66677421342892 139.74721858629212 40.847 35.66677421342892 139.74721858629212 38.963</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4d925e3b-8413-4abb-acac-a02af4f62443">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4d925e3b-8413-4abb-acac-a02af4f62443_0">
											<gml:posList>35.66677447949613 139.74721251083656 38.963 35.66677427172217 139.74721187040544 38.963 35.66677427172217 139.74721187040544 40.847 35.66677447949613 139.74721251083656 40.847 35.66677447949613 139.74721251083656 38.963</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a9014070-bb3b-4af4-85ae-46378b831e41">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a9014070-bb3b-4af4-85ae-46378b831e41_0">
											<gml:posList>35.666774438314015 139.74721794539636 38.963 35.66677460910882 139.7472172935129 38.963 35.66677460910882 139.7472172935129 40.847 35.666774438314015 139.74721794539636 40.847 35.666774438314015 139.74721794539636 38.963</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4f963f9c-0245-4c08-870e-2f598ec45a04">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4f963f9c-0245-4c08-870e-2f598ec45a04_0">
											<gml:posList>35.66677465123097 139.7472131733979 38.963 35.66677447949613 139.74721251083656 38.963 35.66677447949613 139.74721251083656 40.847 35.66677465123097 139.7472131733979 40.847 35.66677465123097 139.7472131733979 38.963</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-78e844ca-eb73-4fc0-82b4-a68179374ba3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-78e844ca-eb73-4fc0-82b4-a68179374ba3_0">
											<gml:posList>35.66677460910882 139.7472172935129 38.963 35.666774734811284 139.74721660854058 38.963 35.666774734811284 139.74721660854058 40.847 35.66677460910882 139.7472172935129 40.847 35.66677460910882 139.7472172935129 38.963</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-20329347-1ecb-41bf-98eb-02cf0894496e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-20329347-1ecb-41bf-98eb-02cf0894496e_0">
											<gml:posList>35.666774759885506 139.74721385811856 38.963 35.66677465123097 139.7472131733979 38.963 35.66677465123097 139.7472131733979 40.847 35.666774759885506 139.74721385811856 40.847 35.666774759885506 139.74721385811856 38.963</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-62c54c6c-c667-4bfe-8704-13d60fda8b8e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-62c54c6c-c667-4bfe-8704-13d60fda8b8e_0">
											<gml:posList>35.666774734811284 139.74721660854058 38.963 35.666774815445095 139.74721592361666 38.963 35.666774815445095 139.74721592361666 40.847 35.666774734811284 139.74721660854058 40.847 35.666774734811284 139.74721660854058 38.963</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1c5c9a5e-4e7c-4a6f-9bb7-e1d4b2a95414">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1c5c9a5e-4e7c-4a6f-9bb7-e1d4b2a95414_0">
											<gml:posList>35.66677483248512 139.7472145428779 38.963 35.666774759885506 139.74721385811856 38.963 35.666774759885506 139.74721385811856 40.847 35.66677483248512 139.7472145428779 40.847 35.66677483248512 139.7472145428779 38.963</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a31ceb7f-d99c-4ca4-826d-806e84552a72">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a31ceb7f-d99c-4ca4-826d-806e84552a72_0">
											<gml:posList>35.666774815445095 139.74721592361666 38.963 35.666774851010246 139.74721523874112 38.963 35.666774851010246 139.74721523874112 40.847 35.666774815445095 139.74721592361666 40.847 35.666774815445095 139.74721592361666 38.963</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1a6c1c3d-9e35-438a-80a3-459c98f58698">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1a6c1c3d-9e35-438a-80a3-459c98f58698_0">
											<gml:posList>35.666774851010246 139.74721523874112 38.963 35.66677483248512 139.7472145428779 38.963 35.66677483248512 139.7472145428779 40.847 35.666774851010246 139.74721523874112 40.847 35.666774851010246 139.74721523874112 38.963</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-061ec346-819d-42cd-9222-990c75911cb4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-061ec346-819d-42cd-9222-990c75911cb4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-061ec346-819d-42cd-9222-990c75911cb4">
											<gml:posList>35.66673338313249 139.74710791851052 6.14 35.66680569633599 139.74714009439458 6.14 35.66678096832232 139.7472236269523 6.14 35.66679223911781 139.74722869590147 6.14 35.66676957930808 139.74730537782634 6.14 35.66668590521704 139.74726813295482 6.14 35.66673338313249 139.74710791851052 6.14</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-2c8bcfaa-cc6e-4084-b6fe-9bee2ff8f190">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2c8bcfaa-cc6e-4084-b6fe-9bee2ff8f190">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2c8bcfaa-cc6e-4084-b6fe-9bee2ff8f190">
											<gml:posList>35.66677545109153 139.7472855222899 32.5 35.666691759045946 139.7472483879132 32.5 35.66668590521704 139.74726813295482 32.5 35.66676957930808 139.74730537782634 32.5 35.66677545109153 139.7472855222899 32.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-7e76d881-8b51-42db-9a6e-c6d0fdfb3de7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7e76d881-8b51-42db-9a6e-c6d0fdfb3de7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7e76d881-8b51-42db-9a6e-c6d0fdfb3de7">
											<gml:posList>35.66676102863259 139.74719659729445 34.6 35.66678571609376 139.74720757235747 34.6 35.666792621974494 139.74718426942002 34.6 35.66672029976096 139.74715208246525 34.6 35.666691759045946 139.7472483879132 34.6 35.66673943880084 139.74726953353803 34.6 35.66676102863259 139.74719659729445 34.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-25941549-3281-4577-bd2d-418c1eb1bc2d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-25941549-3281-4577-bd2d-418c1eb1bc2d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-25941549-3281-4577-bd2d-418c1eb1bc2d">
											<gml:posList>35.66673943880084 139.74726953353803 38.963 35.66676413526132 139.74728049756516 38.963 35.66678571609376 139.74720757235747 38.963 35.66676102863259 139.74719659729445 38.963 35.66673943880084 139.74726953353803 38.963</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-8ea8e7ff-5f94-4b51-b150-801f0e8f97c7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8ea8e7ff-5f94-4b51-b150-801f0e8f97c7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8ea8e7ff-5f94-4b51-b150-801f0e8f97c7">
											<gml:posList>35.66673338313249 139.74710791851052 32.5 35.66672029976096 139.74715208246525 32.5 35.666792621974494 139.74718426942002 32.5 35.66680569633599 139.74714009439458 32.5 35.66673338313249 139.74710791851052 32.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-0921a163-843b-4d8a-b574-ec88dfb57f0d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0921a163-843b-4d8a-b574-ec88dfb57f0d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0921a163-843b-4d8a-b574-ec88dfb57f0d">
											<gml:posList>35.66676413526132 139.74728049756516 34.6 35.66677545109153 139.7472855222899 34.6 35.66679223911781 139.74722869590147 34.6 35.66678096832232 139.7472236269523 34.6 35.66676413526132 139.74728049756516 34.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-aaf00885-23e3-4423-90e6-de2f63a17a28">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-aaf00885-23e3-4423-90e6-de2f63a17a28">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-aaf00885-23e3-4423-90e6-de2f63a17a28">
											<gml:posList>35.666691759045946 139.7472483879132 32.5 35.666691759045946 139.7472483879132 34.6 35.66672029976096 139.74715208246525 34.6 35.66672029976096 139.74715208246525 32.5 35.66673338313249 139.74710791851052 32.5 35.66673338313249 139.74710791851052 6.14 35.66668590521704 139.74726813295482 6.14 35.66668590521704 139.74726813295482 32.5 35.666691759045946 139.7472483879132 32.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-088462bb-d0b9-4977-8541-27bbb6fff465">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-088462bb-d0b9-4977-8541-27bbb6fff465">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-088462bb-d0b9-4977-8541-27bbb6fff465">
											<gml:posList>35.66668590521704 139.74726813295482 6.14 35.66676957930808 139.74730537782634 6.14 35.66676957930808 139.74730537782634 32.5 35.66668590521704 139.74726813295482 32.5 35.66668590521704 139.74726813295482 6.14</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2c42f5da-1f32-4817-9507-c46d5e8c22c2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2c42f5da-1f32-4817-9507-c46d5e8c22c2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2c42f5da-1f32-4817-9507-c46d5e8c22c2">
											<gml:posList>35.66673943880084 139.74726953353803 34.6 35.666691759045946 139.7472483879132 34.6 35.666691759045946 139.7472483879132 32.5 35.66677545109153 139.7472855222899 32.5 35.66677545109153 139.7472855222899 34.6 35.66676413526132 139.74728049756516 34.6 35.66676413526132 139.74728049756516 38.963 35.66673943880084 139.74726953353803 38.963 35.66673943880084 139.74726953353803 34.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-abb42414-fd97-45fe-8776-db4177d9dc74">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-abb42414-fd97-45fe-8776-db4177d9dc74">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-abb42414-fd97-45fe-8776-db4177d9dc74">
											<gml:posList>35.66673943880084 139.74726953353803 38.963 35.66676102863259 139.74719659729445 38.963 35.66676102863259 139.74719659729445 34.6 35.66673943880084 139.74726953353803 34.6 35.66673943880084 139.74726953353803 38.963</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8b70e7f6-f49d-45dd-a4ad-763d3290f916">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8b70e7f6-f49d-45dd-a4ad-763d3290f916">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8b70e7f6-f49d-45dd-a4ad-763d3290f916">
											<gml:posList>35.66672029976096 139.74715208246525 34.6 35.666792621974494 139.74718426942002 34.6 35.666792621974494 139.74718426942002 32.5 35.66672029976096 139.74715208246525 32.5 35.66672029976096 139.74715208246525 34.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4f32b7dc-f7bc-4351-855b-a5041a2190a5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4f32b7dc-f7bc-4351-855b-a5041a2190a5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4f32b7dc-f7bc-4351-855b-a5041a2190a5">
											<gml:posList>35.66680569633599 139.74714009439458 6.14 35.66673338313249 139.74710791851052 6.14 35.66673338313249 139.74710791851052 32.5 35.66680569633599 139.74714009439458 32.5 35.66680569633599 139.74714009439458 6.14</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-67cb32d1-c4e4-44c9-97ad-3e7e347dfd96">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-67cb32d1-c4e4-44c9-97ad-3e7e347dfd96">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-67cb32d1-c4e4-44c9-97ad-3e7e347dfd96">
											<gml:posList>35.66676102863259 139.74719659729445 38.963 35.66678571609376 139.74720757235747 38.963 35.66678571609376 139.74720757235747 34.6 35.66676102863259 139.74719659729445 34.6 35.66676102863259 139.74719659729445 38.963</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ae14f0da-b719-454b-87ce-7e714b800d0e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ae14f0da-b719-454b-87ce-7e714b800d0e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ae14f0da-b719-454b-87ce-7e714b800d0e">
											<gml:posList>35.66679223911781 139.74722869590147 6.14 35.66679223911781 139.74722869590147 34.6 35.66677545109153 139.7472855222899 34.6 35.66677545109153 139.7472855222899 32.5 35.66676957930808 139.74730537782634 32.5 35.66676957930808 139.74730537782634 6.14 35.66679223911781 139.74722869590147 6.14</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d5b7a3fe-77ae-4dff-9e2e-c805603f2789">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d5b7a3fe-77ae-4dff-9e2e-c805603f2789">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d5b7a3fe-77ae-4dff-9e2e-c805603f2789">
											<gml:posList>35.66678096832232 139.7472236269523 34.6 35.66678096832232 139.7472236269523 6.14 35.66680569633599 139.74714009439458 6.14 35.66680569633599 139.74714009439458 32.5 35.666792621974494 139.74718426942002 32.5 35.666792621974494 139.74718426942002 34.6 35.66678571609376 139.74720757235747 34.6 35.66678571609376 139.74720757235747 38.963 35.66676413526132 139.74728049756516 38.963 35.66676413526132 139.74728049756516 34.6 35.66678096832232 139.7472236269523 34.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-fef21ab9-2fa5-463c-87c7-df89240d1580">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fef21ab9-2fa5-463c-87c7-df89240d1580">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fef21ab9-2fa5-463c-87c7-df89240d1580">
											<gml:posList>35.66679223911781 139.74722869590147 6.14 35.66678096832232 139.7472236269523 6.14 35.66678096832232 139.7472236269523 34.6 35.66679223911781 139.74722869590147 34.6 35.66679223911781 139.74722869590147 6.14</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区虎ノ門三丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-1393</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">144.9177</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1210</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>7</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>