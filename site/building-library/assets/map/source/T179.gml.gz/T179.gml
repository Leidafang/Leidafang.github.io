<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_2f046a86-c70b-4fab-aac7-3fcc3ce22845">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>0.85</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>46</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13101046002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3001</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">402</bldg:usage>
			<bldg:measuredHeight uom="m">14.6</bldg:measuredHeight>
			<bldg:storeysAboveGround>3</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.674791299692984 139.74183422672905 0 35.674841411985305 139.74182894435964 0 35.67488410658457 139.74182445477956 0 35.67497721992346 139.7418146603636 0 35.674972390323994 139.74174584373807 0 35.674879286029665 139.74175567136368 0 35.67487719043824 139.74172617859014 0 35.674834423791765 139.74173074563262 0 35.67481446001524 139.74173287839716 0 35.674812090980275 139.74169940908737 0 35.67474854932362 139.74170610983703 0 35.67475319766334 139.7417736008516 0 35.67474454516753 139.74177449448285 0 35.674749010676344 139.74183867164825 0 35.674791299692984 139.74183422672905 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.674791299692984 139.74183422672905 9.5 35.674749010676344 139.74183867164825 9.5 35.67474454516753 139.74177449448285 9.5 35.67475319766334 139.7417736008516 9.5 35.67474854932362 139.74170610983703 9.5 35.674812090980275 139.74169940908737 9.5 35.67481446001524 139.74173287839716 9.5 35.674834423791765 139.74173074563262 9.5 35.67487719043824 139.74172617859014 9.5 35.674879286029665 139.74175567136368 9.5 35.674972390323994 139.74174584373807 9.5 35.67497721992346 139.7418146603636 9.5 35.67488410658457 139.74182445477956 9.5 35.674841411985305 139.74182894435964 9.5 35.674791299692984 139.74183422672905 9.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.674791299692984 139.74183422672905 9.5 35.674841411985305 139.74182894435964 9.5 35.674841411985305 139.74182894435964 20.6 35.674791299692984 139.74183422672905 20.6 35.674791299692984 139.74183422672905 9.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.674841411985305 139.74182894435964 9.5 35.67488410658457 139.74182445477956 9.5 35.67488410658457 139.74182445477956 20.6 35.674841411985305 139.74182894435964 20.6 35.674841411985305 139.74182894435964 9.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67488410658457 139.74182445477956 9.5 35.67497721992346 139.7418146603636 9.5 35.67497721992346 139.7418146603636 20.6 35.67488410658457 139.74182445477956 20.6 35.67488410658457 139.74182445477956 9.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67497721992346 139.7418146603636 9.5 35.674972390323994 139.74174584373807 9.5 35.674972390323994 139.74174584373807 20.6 35.67497721992346 139.7418146603636 20.6 35.67497721992346 139.7418146603636 9.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.674972390323994 139.74174584373807 9.5 35.674879286029665 139.74175567136368 9.5 35.674879286029665 139.74175567136368 20.6 35.674972390323994 139.74174584373807 20.6 35.674972390323994 139.74174584373807 9.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.674879286029665 139.74175567136368 9.5 35.67487719043824 139.74172617859014 9.5 35.67487719043824 139.74172617859014 20.6 35.674879286029665 139.74175567136368 20.6 35.674879286029665 139.74175567136368 9.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67487719043824 139.74172617859014 9.5 35.674834423791765 139.74173074563262 9.5 35.674834423791765 139.74173074563262 20.6 35.67487719043824 139.74172617859014 20.6 35.67487719043824 139.74172617859014 9.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.674834423791765 139.74173074563262 9.5 35.67481446001524 139.74173287839716 9.5 35.67481446001524 139.74173287839716 20.6 35.674834423791765 139.74173074563262 20.6 35.674834423791765 139.74173074563262 9.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67481446001524 139.74173287839716 9.5 35.674812090980275 139.74169940908737 9.5 35.674812090980275 139.74169940908737 20.6 35.67481446001524 139.74173287839716 20.6 35.67481446001524 139.74173287839716 9.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.674812090980275 139.74169940908737 9.5 35.67474854932362 139.74170610983703 9.5 35.67474854932362 139.74170610983703 20.6 35.674812090980275 139.74169940908737 20.6 35.674812090980275 139.74169940908737 9.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67474854932362 139.74170610983703 9.5 35.67475319766334 139.7417736008516 9.5 35.67475319766334 139.7417736008516 20.6 35.67474854932362 139.74170610983703 20.6 35.67474854932362 139.74170610983703 9.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67475319766334 139.7417736008516 9.5 35.67474454516753 139.74177449448285 9.5 35.67474454516753 139.74177449448285 20.6 35.67475319766334 139.7417736008516 20.6 35.67475319766334 139.7417736008516 9.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67474454516753 139.74177449448285 9.5 35.674749010676344 139.74183867164825 9.5 35.674749010676344 139.74183867164825 20.6 35.67474454516753 139.74177449448285 20.6 35.67474454516753 139.74177449448285 9.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.674749010676344 139.74183867164825 9.5 35.674791299692984 139.74183422672905 9.5 35.674791299692984 139.74183422672905 20.6 35.674749010676344 139.74183867164825 20.6 35.674749010676344 139.74183867164825 9.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.674791299692984 139.74183422672905 20.6 35.674841411985305 139.74182894435964 20.6 35.67488410658457 139.74182445477956 20.6 35.67497721992346 139.7418146603636 20.6 35.674972390323994 139.74174584373807 20.6 35.674879286029665 139.74175567136368 20.6 35.67487719043824 139.74172617859014 20.6 35.674834423791765 139.74173074563262 20.6 35.67481446001524 139.74173287839716 20.6 35.674812090980275 139.74169940908737 20.6 35.67474854932362 139.74170610983703 20.6 35.67475319766334 139.7417736008516 20.6 35.67474454516753 139.74177449448285 20.6 35.674749010676344 139.74183867164825 20.6 35.674791299692984 139.74183422672905 20.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-a3562d70-22ef-4da8-a444-c1d75250344f"/>
							<gml:surfaceMember xlink:href="#poly-63f3ed7a-1531-4f1c-9526-180149e48003"/>
							<gml:surfaceMember xlink:href="#poly-8b765481-2a11-4e8e-9686-251038067368"/>
							<gml:surfaceMember xlink:href="#poly-6bb52128-ca00-4e03-826c-44fbecc66bf1"/>
							<gml:surfaceMember xlink:href="#poly-b7af1828-b2fa-492b-b897-99314fbe1967"/>
							<gml:surfaceMember xlink:href="#poly-9dad1427-0e16-4807-8143-d333df3f7c12"/>
							<gml:surfaceMember xlink:href="#poly-d7742447-6c57-4681-950c-7c4bb11e0300"/>
							<gml:surfaceMember xlink:href="#poly-01a565c2-f9b6-4a87-b041-b4e3b92a0208"/>
							<gml:surfaceMember xlink:href="#poly-b6485272-b648-4005-8f90-41a6acb14f64"/>
							<gml:surfaceMember xlink:href="#poly-ba651c4e-43d5-41fc-9960-bd553a741e02"/>
							<gml:surfaceMember xlink:href="#poly-ce5b45d6-cfe1-4a6b-aa78-037ca180040d"/>
							<gml:surfaceMember xlink:href="#poly-18c9ae59-204d-4222-8c69-0f70ca08ccae"/>
							<gml:surfaceMember xlink:href="#poly-3ccc6794-b793-417c-827e-5884c44cf0a5"/>
							<gml:surfaceMember xlink:href="#poly-9759665a-9e21-4f6d-9a43-8aa6d419829f"/>
							<gml:surfaceMember xlink:href="#poly-72218d68-519a-4a3b-a6ac-0773e92cfba2"/>
							<gml:surfaceMember xlink:href="#poly-2f26ba6d-d534-4688-8283-693e3d806bf8"/>
							<gml:surfaceMember xlink:href="#poly-764b18cf-dd87-4af3-9d59-698568664e4b"/>
							<gml:surfaceMember xlink:href="#poly-4e4e22bb-1a38-48b8-a1ac-aa390ce910e8"/>
							<gml:surfaceMember xlink:href="#poly-de7cd410-cfab-464b-b192-4d701bd0ff51"/>
							<gml:surfaceMember xlink:href="#poly-aabaf67f-2725-4129-9a37-9fd815f537fd"/>
							<gml:surfaceMember xlink:href="#poly-b481b0d6-d3ce-4523-b9c4-1ee88f0235bc"/>
							<gml:surfaceMember xlink:href="#poly-c2b75960-c4b9-4af6-800e-32c73e6edfce"/>
							<gml:surfaceMember xlink:href="#poly-758e81d1-c73c-461a-bdc7-1a98a7b54c8c"/>
							<gml:surfaceMember xlink:href="#poly-0ff66820-9dea-49f8-8c76-154c75f501da"/>
							<gml:surfaceMember xlink:href="#poly-0f8d36a1-e05d-4ec1-b262-81051bd0df88"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-a3562d70-22ef-4da8-a444-c1d75250344f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a3562d70-22ef-4da8-a444-c1d75250344f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a3562d70-22ef-4da8-a444-c1d75250344f">
											<gml:posList>35.674753197663314 139.74177360085156 9.5 35.674748549323596 139.741706109837 9.5 35.67481209098025 139.74169940908735 9.5 35.67481446001521 139.7417328783972 9.5 35.67483442379175 139.7417307456326 9.5 35.674877190438224 139.74172617859014 9.5 35.67487928602966 139.74175567136368 9.5 35.674972390323965 139.74174584373807 9.5 35.67497721992344 139.7418146603636 9.5 35.67488410658456 139.74182445477956 9.5 35.6748414119937 139.7418289554065 9.5 35.674749010676344 139.74183867164825 9.5 35.67474454516752 139.74177449448285 9.5 35.674753197663314 139.74177360085156 9.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-63f3ed7a-1531-4f1c-9526-180149e48003">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-63f3ed7a-1531-4f1c-9526-180149e48003">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-63f3ed7a-1531-4f1c-9526-180149e48003">
											<gml:posList>35.67481446001521 139.7417328783972 19.1 35.67481209098025 139.74169940908735 19.1 35.674748549323596 139.741706109837 19.1 35.674753197663314 139.74177360085156 19.1 35.67474454516752 139.74177449448285 19.1 35.674749010676344 139.74183867164825 19.1 35.674791299692984 139.74183422672903 19.1 35.67478437404514 139.74173529889825 19.1 35.67481446001521 139.7417328783972 19.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-8b765481-2a11-4e8e-9686-251038067368">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8b765481-2a11-4e8e-9686-251038067368">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8b765481-2a11-4e8e-9686-251038067368">
											<gml:posList>35.67483442379175 139.7417307456326 24.111 35.6748414119937 139.7418289554065 24.111 35.67488410658456 139.74182445477956 21.9 35.67487928602966 139.74175567136368 21.9 35.674877190438224 139.74172617859014 21.9 35.67483442379175 139.7417307456326 24.111</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-6bb52128-ca00-4e03-826c-44fbecc66bf1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6bb52128-ca00-4e03-826c-44fbecc66bf1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6bb52128-ca00-4e03-826c-44fbecc66bf1">
											<gml:posList>35.6748414119937 139.7418289554065 24.111 35.67483442379175 139.7417307456326 24.111 35.67481446001521 139.7417328783972 21.9 35.6748414119937 139.7418289554065 24.111</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b7af1828-b2fa-492b-b897-99314fbe1967">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b7af1828-b2fa-492b-b897-99314fbe1967">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b7af1828-b2fa-492b-b897-99314fbe1967">
											<gml:posList>35.674791299692984 139.74183422672903 21.9 35.6748414119937 139.7418289554065 24.111 35.67481446001521 139.7417328783972 21.9 35.674791299692984 139.74183422672903 21.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-9dad1427-0e16-4807-8143-d333df3f7c12">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9dad1427-0e16-4807-8143-d333df3f7c12">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9dad1427-0e16-4807-8143-d333df3f7c12">
											<gml:posList>35.67481446001521 139.7417328783972 21.9 35.67478437404514 139.74173529889825 21.9 35.674791299692984 139.74183422672903 21.9 35.67481446001521 139.7417328783972 21.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d7742447-6c57-4681-950c-7c4bb11e0300">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d7742447-6c57-4681-950c-7c4bb11e0300">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d7742447-6c57-4681-950c-7c4bb11e0300">
											<gml:posList>35.67488410658456 139.74182445477956 21.9 35.67497721992344 139.7418146603636 19.1 35.674972390323965 139.74174584373807 19.1 35.67487928602966 139.74175567136368 21.9 35.67488410658456 139.74182445477956 21.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-01a565c2-f9b6-4a87-b041-b4e3b92a0208">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-01a565c2-f9b6-4a87-b041-b4e3b92a0208">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-01a565c2-f9b6-4a87-b041-b4e3b92a0208">
											<gml:posList>35.67481209098025 139.74169940908735 9.5 35.674748549323596 139.741706109837 9.5 35.674748549323596 139.741706109837 19.1 35.67481209098025 139.74169940908735 19.1 35.67481209098025 139.74169940908735 9.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b6485272-b648-4005-8f90-41a6acb14f64">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b6485272-b648-4005-8f90-41a6acb14f64">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b6485272-b648-4005-8f90-41a6acb14f64">
											<gml:posList>35.67481446001521 139.7417328783972 9.5 35.67481209098025 139.74169940908735 9.5 35.67481209098025 139.74169940908735 19.1 35.67481446001521 139.7417328783972 19.1 35.67481446001521 139.7417328783972 9.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ba651c4e-43d5-41fc-9960-bd553a741e02">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ba651c4e-43d5-41fc-9960-bd553a741e02">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ba651c4e-43d5-41fc-9960-bd553a741e02">
											<gml:posList>35.674877190438224 139.74172617859014 21.9 35.674877190438224 139.74172617859014 9.5 35.67483442379175 139.7417307456326 9.5 35.67483442379175 139.7417307456326 24.111 35.674877190438224 139.74172617859014 21.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ce5b45d6-cfe1-4a6b-aa78-037ca180040d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ce5b45d6-cfe1-4a6b-aa78-037ca180040d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ce5b45d6-cfe1-4a6b-aa78-037ca180040d">
											<gml:posList>35.67481446001521 139.7417328783972 19.1 35.67483442379175 139.7417307456326 24.111 35.67483442379175 139.7417307456326 9.5 35.67481446001521 139.7417328783972 19.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-18c9ae59-204d-4222-8c69-0f70ca08ccae">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-18c9ae59-204d-4222-8c69-0f70ca08ccae">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-18c9ae59-204d-4222-8c69-0f70ca08ccae">
											<gml:posList>35.67481446001521 139.7417328783972 19.1 35.67481446001521 139.7417328783972 21.9 35.67483442379175 139.7417307456326 24.111 35.67481446001521 139.7417328783972 19.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3ccc6794-b793-417c-827e-5884c44cf0a5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3ccc6794-b793-417c-827e-5884c44cf0a5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3ccc6794-b793-417c-827e-5884c44cf0a5">
											<gml:posList>35.67481446001521 139.7417328783972 19.1 35.67483442379175 139.7417307456326 9.5 35.67481446001521 139.7417328783972 9.5 35.67481446001521 139.7417328783972 19.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9759665a-9e21-4f6d-9a43-8aa6d419829f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9759665a-9e21-4f6d-9a43-8aa6d419829f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9759665a-9e21-4f6d-9a43-8aa6d419829f">
											<gml:posList>35.67481446001521 139.7417328783972 19.1 35.67478437404514 139.74173529889825 19.1 35.67478437404514 139.74173529889825 21.9 35.67481446001521 139.7417328783972 19.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-72218d68-519a-4a3b-a6ac-0773e92cfba2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-72218d68-519a-4a3b-a6ac-0773e92cfba2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-72218d68-519a-4a3b-a6ac-0773e92cfba2">
											<gml:posList>35.67481446001521 139.7417328783972 19.1 35.67478437404514 139.74173529889825 21.9 35.67481446001521 139.7417328783972 21.9 35.67481446001521 139.7417328783972 19.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2f26ba6d-d534-4688-8283-693e3d806bf8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2f26ba6d-d534-4688-8283-693e3d806bf8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2f26ba6d-d534-4688-8283-693e3d806bf8">
											<gml:posList>35.674748549323596 139.741706109837 9.5 35.674753197663314 139.74177360085156 9.5 35.674753197663314 139.74177360085156 19.1 35.674748549323596 139.741706109837 19.1 35.674748549323596 139.741706109837 9.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-764b18cf-dd87-4af3-9d59-698568664e4b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-764b18cf-dd87-4af3-9d59-698568664e4b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-764b18cf-dd87-4af3-9d59-698568664e4b">
											<gml:posList>35.67487928602966 139.74175567136368 21.9 35.67487928602966 139.74175567136368 9.5 35.674877190438224 139.74172617859014 9.5 35.674877190438224 139.74172617859014 21.9 35.67487928602966 139.74175567136368 21.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4e4e22bb-1a38-48b8-a1ac-aa390ce910e8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4e4e22bb-1a38-48b8-a1ac-aa390ce910e8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4e4e22bb-1a38-48b8-a1ac-aa390ce910e8">
											<gml:posList>35.674972390323965 139.74174584373807 19.1 35.674972390323965 139.74174584373807 9.5 35.67487928602966 139.74175567136368 9.5 35.67487928602966 139.74175567136368 21.9 35.674972390323965 139.74174584373807 19.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-de7cd410-cfab-464b-b192-4d701bd0ff51">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-de7cd410-cfab-464b-b192-4d701bd0ff51">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-de7cd410-cfab-464b-b192-4d701bd0ff51">
											<gml:posList>35.674753197663314 139.74177360085156 9.5 35.67474454516752 139.74177449448285 9.5 35.67474454516752 139.74177449448285 19.1 35.674753197663314 139.74177360085156 19.1 35.674753197663314 139.74177360085156 9.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-aabaf67f-2725-4129-9a37-9fd815f537fd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-aabaf67f-2725-4129-9a37-9fd815f537fd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-aabaf67f-2725-4129-9a37-9fd815f537fd">
											<gml:posList>35.67497721992344 139.7418146603636 19.1 35.67497721992344 139.7418146603636 9.5 35.674972390323965 139.74174584373807 9.5 35.674972390323965 139.74174584373807 19.1 35.67497721992344 139.7418146603636 19.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b481b0d6-d3ce-4523-b9c4-1ee88f0235bc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b481b0d6-d3ce-4523-b9c4-1ee88f0235bc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b481b0d6-d3ce-4523-b9c4-1ee88f0235bc">
											<gml:posList>35.674791299692984 139.74183422672903 21.9 35.67478437404514 139.74173529889825 21.9 35.67478437404514 139.74173529889825 19.1 35.674791299692984 139.74183422672903 19.1 35.674791299692984 139.74183422672903 21.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c2b75960-c4b9-4af6-800e-32c73e6edfce">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c2b75960-c4b9-4af6-800e-32c73e6edfce">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c2b75960-c4b9-4af6-800e-32c73e6edfce">
											<gml:posList>35.67474454516752 139.74177449448285 9.5 35.674749010676344 139.74183867164825 9.5 35.674749010676344 139.74183867164825 19.1 35.67474454516752 139.74177449448285 19.1 35.67474454516752 139.74177449448285 9.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-758e81d1-c73c-461a-bdc7-1a98a7b54c8c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-758e81d1-c73c-461a-bdc7-1a98a7b54c8c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-758e81d1-c73c-461a-bdc7-1a98a7b54c8c">
											<gml:posList>35.67488410658456 139.74182445477956 21.9 35.67488410658456 139.74182445477956 9.5 35.67497721992344 139.7418146603636 9.5 35.67497721992344 139.7418146603636 19.1 35.67488410658456 139.74182445477956 21.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0ff66820-9dea-49f8-8c76-154c75f501da">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0ff66820-9dea-49f8-8c76-154c75f501da">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0ff66820-9dea-49f8-8c76-154c75f501da">
											<gml:posList>35.6748414119937 139.7418289554065 24.111 35.6748414119937 139.7418289554065 9.5 35.67488410658456 139.74182445477956 9.5 35.67488410658456 139.74182445477956 21.9 35.6748414119937 139.7418289554065 24.111</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0f8d36a1-e05d-4ec1-b262-81051bd0df88">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0f8d36a1-e05d-4ec1-b262-81051bd0df88">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0f8d36a1-e05d-4ec1-b262-81051bd0df88">
											<gml:posList>35.6748414119937 139.7418289554065 24.111 35.674791299692984 139.74183422672903 21.9 35.674791299692984 139.74183422672903 19.1 35.674749010676344 139.74183867164825 19.1 35.674749010676344 139.74183867164825 9.5 35.6748414119937 139.7418289554065 9.5 35.6748414119937 139.7418289554065 24.111</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都千代田区永田町二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13101-bldg-4617</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13101</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">209.40619</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1003</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1242</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>5</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.0</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">21</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">2</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>