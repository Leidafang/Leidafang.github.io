<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_2f7ece93-6409-4624-83d5-bba7280c4be2">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>29</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103029002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3001</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">411</bldg:usage>
			<bldg:measuredHeight uom="m">7</bldg:measuredHeight>
			<bldg:storeysAboveGround>2</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.66737232671139 139.73842552842268 0 35.6673587064941 139.7384135045746 0 35.66733665254844 139.7384511969949 0 35.667413502746314 139.73851870666573 0 35.66747849439297 139.73840761892964 0 35.66741535449545 139.7383521330462 0 35.66737232671139 139.73842552842268 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66737232671139 139.73842552842268 13.82 35.66741535449545 139.7383521330462 13.82 35.66747849439297 139.73840761892964 13.82 35.667413502746314 139.73851870666573 13.82 35.66733665254844 139.7384511969949 13.82 35.6673587064941 139.7384135045746 13.82 35.66737232671139 139.73842552842268 13.82</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66737232671139 139.73842552842268 13.82 35.6673587064941 139.7384135045746 13.82 35.6673587064941 139.7384135045746 20.78 35.66737232671139 139.73842552842268 20.78 35.66737232671139 139.73842552842268 13.82</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6673587064941 139.7384135045746 13.82 35.66733665254844 139.7384511969949 13.82 35.66733665254844 139.7384511969949 20.78 35.6673587064941 139.7384135045746 20.78 35.6673587064941 139.7384135045746 13.82</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66733665254844 139.7384511969949 13.82 35.667413502746314 139.73851870666573 13.82 35.667413502746314 139.73851870666573 20.78 35.66733665254844 139.7384511969949 20.78 35.66733665254844 139.7384511969949 13.82</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667413502746314 139.73851870666573 13.82 35.66747849439297 139.73840761892964 13.82 35.66747849439297 139.73840761892964 20.78 35.667413502746314 139.73851870666573 20.78 35.667413502746314 139.73851870666573 13.82</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66747849439297 139.73840761892964 13.82 35.66741535449545 139.7383521330462 13.82 35.66741535449545 139.7383521330462 20.78 35.66747849439297 139.73840761892964 20.78 35.66747849439297 139.73840761892964 13.82</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66741535449545 139.7383521330462 13.82 35.66737232671139 139.73842552842268 13.82 35.66737232671139 139.73842552842268 20.78 35.66741535449545 139.7383521330462 20.78 35.66741535449545 139.7383521330462 13.82</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66737232671139 139.73842552842268 20.78 35.6673587064941 139.7384135045746 20.78 35.66733665254844 139.7384511969949 20.78 35.667413502746314 139.73851870666573 20.78 35.66747849439297 139.73840761892964 20.78 35.66741535449545 139.7383521330462 20.78 35.66737232671139 139.73842552842268 20.78</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-1701b29c-5d31-4b62-8fff-d34644f196d1"/>
							<gml:surfaceMember xlink:href="#poly-1e5a234e-fd1a-4da6-8a4b-b48766c1de68"/>
							<gml:surfaceMember xlink:href="#poly-074aef96-1757-4468-bf3b-3c80df9b0a90"/>
							<gml:surfaceMember xlink:href="#poly-03a0a9ad-ce43-49ef-a053-55323d1f3702"/>
							<gml:surfaceMember xlink:href="#poly-3d516500-06dc-4e98-bb4d-b1a4f2e8a7be"/>
							<gml:surfaceMember xlink:href="#poly-f8e5dcd9-6bf8-47a4-a013-913e6e1a606e"/>
							<gml:surfaceMember xlink:href="#poly-a03e0ecf-34ad-4c16-a596-e675a0d964db"/>
							<gml:surfaceMember xlink:href="#poly-0e1d221b-02b9-4bba-ad28-a55e4225e986"/>
							<gml:surfaceMember xlink:href="#poly-2da544bd-601c-4216-8eda-76cfba70fa72"/>
							<gml:surfaceMember xlink:href="#poly-288698de-ac49-4e4e-870e-c1dd3c2a44b4"/>
							<gml:surfaceMember xlink:href="#poly-fce2e31a-684e-4187-9728-a64835e751e5"/>
							<gml:surfaceMember xlink:href="#poly-5c818ae2-09f5-4385-b5d2-902e0a8d6ef0"/>
							<gml:surfaceMember xlink:href="#poly-837bda73-f951-47b5-887d-ea4bd94df8db"/>
							<gml:surfaceMember xlink:href="#poly-67344a76-9b97-4b91-a4f4-37a05abfd5fa"/>
							<gml:surfaceMember xlink:href="#poly-6dee1d44-c60b-4b99-8e86-caee83c91533"/>
							<gml:surfaceMember xlink:href="#poly-93a168e3-ec85-472a-abf7-0aef528ace1b"/>
							<gml:surfaceMember xlink:href="#poly-bf18e6cd-dba8-4b10-919a-e40b147c0195"/>
							<gml:surfaceMember xlink:href="#poly-17a4f5fd-2336-45a9-b003-394bf33e7fef"/>
							<gml:surfaceMember xlink:href="#poly-573cab6c-284e-482e-8aa3-74d87d59ea36"/>
							<gml:surfaceMember xlink:href="#poly-ee512206-1276-4713-afcb-3b4901dd70ac"/>
							<gml:surfaceMember xlink:href="#poly-bb5adf54-e98c-4ee9-a0a4-08209e32cad6"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-1701b29c-5d31-4b62-8fff-d34644f196d1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1701b29c-5d31-4b62-8fff-d34644f196d1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1701b29c-5d31-4b62-8fff-d34644f196d1">
											<gml:posList>35.66737232671137 139.73842552842268 13.82 35.66741535449548 139.73835213304616 13.82 35.66747849439295 139.73840761892964 13.82 35.66741350274631 139.7385187066657 13.82 35.66733665254843 139.7384511969949 13.82 35.66735870649409 139.73841350457457 13.82 35.66737232671137 139.73842552842268 13.82</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-1e5a234e-fd1a-4da6-8a4b-b48766c1de68">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1e5a234e-fd1a-4da6-8a4b-b48766c1de68">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1e5a234e-fd1a-4da6-8a4b-b48766c1de68">
											<gml:posList>35.6674271901509 139.7384100766144 21.834 35.667441946837954 139.73842303802462 21.071 35.667445508299465 139.73837861842648 21.854 35.6674271901509 139.7384100766144 21.834</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-074aef96-1757-4468-bf3b-3c80df9b0a90">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-074aef96-1757-4468-bf3b-3c80df9b0a90">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-074aef96-1757-4468-bf3b-3c80df9b0a90">
											<gml:posList>35.667441946837954 139.73842303802462 21.071 35.66747849439295 139.73840761892964 20.111 35.667445508299465 139.73837861842648 21.854 35.667441946837954 139.73842303802462 21.071</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-03a0a9ad-ce43-49ef-a053-55323d1f3702">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-03a0a9ad-ce43-49ef-a053-55323d1f3702">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-03a0a9ad-ce43-49ef-a053-55323d1f3702">
											<gml:posList>35.66737246200432 139.738425638721 20.068 35.66739035583147 139.73847337978603 21.795 35.6674271901509 139.7384100766144 21.834 35.667445508299465 139.73837861842648 21.854 35.667415336459314 139.7383521220217 20.117 35.66737246200432 139.738425638721 20.068</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-3d516500-06dc-4e98-bb4d-b1a4f2e8a7be">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3d516500-06dc-4e98-bb4d-b1a4f2e8a7be">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3d516500-06dc-4e98-bb4d-b1a4f2e8a7be">
											<gml:posList>35.66737246200432 139.738425638721 17.672 35.66735870649409 139.73841350457457 17.672 35.66733665254843 139.7384511969949 17.672 35.667352978716195 139.73846554831738 17.672 35.66737246200432 139.738425638721 17.672</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f8e5dcd9-6bf8-47a4-a013-913e6e1a606e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f8e5dcd9-6bf8-47a4-a013-913e6e1a606e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f8e5dcd9-6bf8-47a4-a013-913e6e1a606e">
											<gml:posList>35.667441946837954 139.73842303802462 21.826 35.6674271901509 139.7384100766144 21.834 35.66739035583147 139.73847337978603 21.795 35.6674049772189 139.73848623090353 21.784 35.667441946837954 139.73842303802462 21.826</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a03e0ecf-34ad-4c16-a596-e675a0d964db">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a03e0ecf-34ad-4c16-a596-e675a0d964db">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a03e0ecf-34ad-4c16-a596-e675a0d964db">
											<gml:posList>35.66737246200432 139.738425638721 20.068 35.667352978716195 139.73846554831738 20.186 35.6673807331739 139.73848991575522 21.784 35.66739035583147 139.73847337978603 21.795 35.66737246200432 139.738425638721 20.068</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-0e1d221b-02b9-4bba-ad28-a55e4225e986">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0e1d221b-02b9-4bba-ad28-a55e4225e986">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0e1d221b-02b9-4bba-ad28-a55e4225e986">
											<gml:posList>35.667441946837954 139.73842303802462 21.071 35.6674049772189 139.73848623090353 21.048 35.66741350274631 139.7385187066657 20.111 35.66747849439295 139.73840761892964 20.111 35.667441946837954 139.73842303802462 21.071</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-2da544bd-601c-4216-8eda-76cfba70fa72">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2da544bd-601c-4216-8eda-76cfba70fa72">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2da544bd-601c-4216-8eda-76cfba70fa72">
											<gml:posList>35.6673807331739 139.73848991575522 21.784 35.6674049772189 139.73848623090353 21.048 35.66739035583147 139.73847337978603 21.795 35.6673807331739 139.73848991575522 21.784</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-288698de-ac49-4e4e-870e-c1dd3c2a44b4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-288698de-ac49-4e4e-870e-c1dd3c2a44b4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-288698de-ac49-4e4e-870e-c1dd3c2a44b4">
											<gml:posList>35.6673807331739 139.73848991575522 21.784 35.66741350274631 139.7385187066657 20.111 35.6674049772189 139.73848623090353 21.048 35.6673807331739 139.73848991575522 21.784</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-fce2e31a-684e-4187-9728-a64835e751e5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fce2e31a-684e-4187-9728-a64835e751e5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fce2e31a-684e-4187-9728-a64835e751e5">
											<gml:posList>35.667445508299465 139.73837861842648 21.854 35.66747849439295 139.73840761892964 20.111 35.66747849439295 139.73840761892964 13.82 35.66741535449548 139.73835213304616 13.82 35.667415336459314 139.7383521220217 20.117 35.667445508299465 139.73837861842648 21.854</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5c818ae2-09f5-4385-b5d2-902e0a8d6ef0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5c818ae2-09f5-4385-b5d2-902e0a8d6ef0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5c818ae2-09f5-4385-b5d2-902e0a8d6ef0">
											<gml:posList>35.667415336459314 139.7383521220217 20.117 35.66741535449548 139.73835213304616 13.82 35.66737232671137 139.73842552842268 13.82 35.667415336459314 139.7383521220217 20.117</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-837bda73-f951-47b5-887d-ea4bd94df8db">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-837bda73-f951-47b5-887d-ea4bd94df8db">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-837bda73-f951-47b5-887d-ea4bd94df8db">
											<gml:posList>35.66737246200432 139.738425638721 17.672 35.66737246200432 139.738425638721 20.068 35.667415336459314 139.7383521220217 20.117 35.66737232671137 139.73842552842268 13.82 35.66737246200432 139.738425638721 17.672</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-67344a76-9b97-4b91-a4f4-37a05abfd5fa">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-67344a76-9b97-4b91-a4f4-37a05abfd5fa">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-67344a76-9b97-4b91-a4f4-37a05abfd5fa">
											<gml:posList>35.6674271901509 139.7384100766144 21.834 35.667441946837954 139.73842303802462 21.826 35.667441946837954 139.73842303802462 21.071 35.6674271901509 139.7384100766144 21.834</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6dee1d44-c60b-4b99-8e86-caee83c91533">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6dee1d44-c60b-4b99-8e86-caee83c91533">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6dee1d44-c60b-4b99-8e86-caee83c91533">
											<gml:posList>35.66735870649409 139.73841350457457 17.672 35.66737246200432 139.738425638721 17.672 35.66737232671137 139.73842552842268 13.82 35.66735870649409 139.73841350457457 13.82 35.66735870649409 139.73841350457457 17.672</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-93a168e3-ec85-472a-abf7-0aef528ace1b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-93a168e3-ec85-472a-abf7-0aef528ace1b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-93a168e3-ec85-472a-abf7-0aef528ace1b">
											<gml:posList>35.66735870649409 139.73841350457457 13.82 35.66733665254843 139.7384511969949 13.82 35.66733665254843 139.7384511969949 17.672 35.66735870649409 139.73841350457457 17.672 35.66735870649409 139.73841350457457 13.82</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-bf18e6cd-dba8-4b10-919a-e40b147c0195">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bf18e6cd-dba8-4b10-919a-e40b147c0195">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bf18e6cd-dba8-4b10-919a-e40b147c0195">
											<gml:posList>35.66737246200432 139.738425638721 20.068 35.66737246200432 139.738425638721 17.672 35.667352978716195 139.73846554831738 17.672 35.667352978716195 139.73846554831738 20.186 35.66737246200432 139.738425638721 20.068</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-17a4f5fd-2336-45a9-b003-394bf33e7fef">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-17a4f5fd-2336-45a9-b003-394bf33e7fef">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-17a4f5fd-2336-45a9-b003-394bf33e7fef">
											<gml:posList>35.667441946837954 139.73842303802462 21.071 35.667441946837954 139.73842303802462 21.826 35.6674049772189 139.73848623090353 21.784 35.6674049772189 139.73848623090353 21.048 35.667441946837954 139.73842303802462 21.071</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-573cab6c-284e-482e-8aa3-74d87d59ea36">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-573cab6c-284e-482e-8aa3-74d87d59ea36">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-573cab6c-284e-482e-8aa3-74d87d59ea36">
											<gml:posList>35.66741350274631 139.7385187066657 13.82 35.66747849439295 139.73840761892964 13.82 35.66747849439295 139.73840761892964 20.111 35.66741350274631 139.7385187066657 20.111 35.66741350274631 139.7385187066657 13.82</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ee512206-1276-4713-afcb-3b4901dd70ac">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ee512206-1276-4713-afcb-3b4901dd70ac">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ee512206-1276-4713-afcb-3b4901dd70ac">
											<gml:posList>35.6674049772189 139.73848623090353 21.048 35.6674049772189 139.73848623090353 21.784 35.66739035583147 139.73847337978603 21.795 35.6674049772189 139.73848623090353 21.048</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-bb5adf54-e98c-4ee9-a0a4-08209e32cad6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bb5adf54-e98c-4ee9-a0a4-08209e32cad6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bb5adf54-e98c-4ee9-a0a4-08209e32cad6">
											<gml:posList>35.66733665254843 139.7384511969949 17.672 35.66733665254843 139.7384511969949 13.82 35.66741350274631 139.7385187066657 13.82 35.66741350274631 139.7385187066657 20.111 35.6673807331739 139.73848991575522 21.784 35.667352978716195 139.73846554831738 20.186 35.667352978716195 139.73846554831738 17.672 35.66733665254843 139.7384511969949 17.672</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区六本木二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-5091</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">110.96606</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1003</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">5</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">211</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1310</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.6</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>3</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingLandSlideRiskAttribute>
					<uro:description codeSpace="../../codelists/LandSlideRiskAttribute_description.xml">1</uro:description>
					<uro:areaType codeSpace="../../codelists/LandSlideRiskAttribute_areaType.xml">1</uro:areaType>
				</uro:BuildingLandSlideRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">21</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">105</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key105.xml">3</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">20</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>