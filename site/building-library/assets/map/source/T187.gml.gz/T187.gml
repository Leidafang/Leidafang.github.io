<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_3107a84b-7e2a-4d02-8b3b-e01ad0d4d9bb">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>29</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103029002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">401</bldg:usage>
			<bldg:measuredHeight uom="m">11.8</bldg:measuredHeight>
			<bldg:storeysAboveGround>4</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.66689254892003 139.73834082286365 0 35.66686476066888 139.73830793937296 0 35.66682000740724 139.7383649885739 0 35.666847795555945 139.73839776160847 0 35.66689254892003 139.73834082286365 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66689254892003 139.73834082286365 12.428 35.666847795555945 139.73839776160847 12.428 35.66682000740724 139.7383649885739 12.428 35.66686476066888 139.73830793937296 12.428 35.66689254892003 139.73834082286365 12.428</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66689254892003 139.73834082286365 12.428 35.66686476066888 139.73830793937296 12.428 35.66686476066888 139.73830793937296 24.22 35.66689254892003 139.73834082286365 24.22 35.66689254892003 139.73834082286365 12.428</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66686476066888 139.73830793937296 12.428 35.66682000740724 139.7383649885739 12.428 35.66682000740724 139.7383649885739 24.22 35.66686476066888 139.73830793937296 24.22 35.66686476066888 139.73830793937296 12.428</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66682000740724 139.7383649885739 12.428 35.666847795555945 139.73839776160847 12.428 35.666847795555945 139.73839776160847 24.22 35.66682000740724 139.7383649885739 24.22 35.66682000740724 139.7383649885739 12.428</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.666847795555945 139.73839776160847 12.428 35.66689254892003 139.73834082286365 12.428 35.66689254892003 139.73834082286365 24.22 35.666847795555945 139.73839776160847 24.22 35.666847795555945 139.73839776160847 12.428</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66689254892003 139.73834082286365 24.22 35.66686476066888 139.73830793937296 24.22 35.66682000740724 139.7383649885739 24.22 35.666847795555945 139.73839776160847 24.22 35.66689254892003 139.73834082286365 24.22</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-d4defb04-060f-4cfb-8b7c-d7ae15099c7a"/>
							<gml:surfaceMember xlink:href="#poly-71695eca-beda-4217-9e50-cedad5d89728"/>
							<gml:surfaceMember xlink:href="#poly-39a284e0-6924-4191-ae41-be8743c3c83c"/>
							<gml:surfaceMember xlink:href="#poly-e665984a-0c64-4d03-936b-25274b6843e0"/>
							<gml:surfaceMember xlink:href="#poly-7c8860fb-85e4-4deb-83b3-92de1a41b88d"/>
							<gml:surfaceMember xlink:href="#poly-ceb51c75-4350-49f3-a9c0-58f91573b268"/>
							<gml:surfaceMember xlink:href="#poly-bcfef94b-f2cb-4102-be85-84b26275381a"/>
							<gml:surfaceMember xlink:href="#poly-0ec376b5-3cbb-41d0-b72a-0ebd12fcc278"/>
							<gml:surfaceMember xlink:href="#poly-d630a5b5-568d-4d6f-8b29-7d6d1555c005"/>
							<gml:surfaceMember xlink:href="#poly-a81f38b7-836e-4e63-8725-0977d6cafc25"/>
							<gml:surfaceMember xlink:href="#poly-e1fa61d1-adcc-4b21-a8ed-faa8d6721100"/>
							<gml:surfaceMember xlink:href="#poly-8d02e67e-216b-4bb5-93e8-fe52cbddef61"/>
							<gml:surfaceMember xlink:href="#poly-afaddd4f-0b1b-4ee6-b55a-642fcacfb0fc"/>
							<gml:surfaceMember xlink:href="#poly-3f8dc8de-ceb5-4819-894c-2ac57134494a"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-d4defb04-060f-4cfb-8b7c-d7ae15099c7a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d4defb04-060f-4cfb-8b7c-d7ae15099c7a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d4defb04-060f-4cfb-8b7c-d7ae15099c7a">
											<gml:posList>35.66689254892002 139.73834082286365 12.428 35.6668477955559 139.73839776160847 12.428 35.666820007407196 139.7383649885739 12.428 35.666864760668865 139.73830793937296 12.428 35.66689254892002 139.73834082286365 12.428</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-71695eca-beda-4217-9e50-cedad5d89728">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-71695eca-beda-4217-9e50-cedad5d89728">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-71695eca-beda-4217-9e50-cedad5d89728">
											<gml:posList>35.666864760668865 139.73830793937296 25.052 35.66686478951435 139.7383102258142 25.052 35.66689068311331 139.73834086925706 25.052 35.66689254892002 139.73834082286365 25.052 35.666864760668865 139.73830793937296 25.052</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-39a284e0-6924-4191-ae41-be8743c3c83c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-39a284e0-6924-4191-ae41-be8743c3c83c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-39a284e0-6924-4191-ae41-be8743c3c83c">
											<gml:posList>35.666820007407196 139.7383649885739 25.052 35.66682187320522 139.73836493113535 25.052 35.66686478951435 139.7383102258142 25.052 35.666864760668865 139.73830793937296 25.052 35.666820007407196 139.7383649885739 25.052</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e665984a-0c64-4d03-936b-25274b6843e0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e665984a-0c64-4d03-936b-25274b6843e0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e665984a-0c64-4d03-936b-25274b6843e0">
											<gml:posList>35.66689068311331 139.73834086925706 24.764 35.66686478951435 139.7383102258142 24.764 35.66682187320522 139.73836493113535 24.764 35.666847757698356 139.73839547517832 24.764 35.66689068311331 139.73834086925706 24.764</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-7c8860fb-85e4-4deb-83b3-92de1a41b88d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7c8860fb-85e4-4deb-83b3-92de1a41b88d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7c8860fb-85e4-4deb-83b3-92de1a41b88d">
											<gml:posList>35.66689254892002 139.73834082286365 25.052 35.66689068311331 139.73834086925706 25.052 35.666847757698356 139.73839547517832 25.052 35.6668477955559 139.73839776160847 25.052 35.66689254892002 139.73834082286365 25.052</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ceb51c75-4350-49f3-a9c0-58f91573b268">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ceb51c75-4350-49f3-a9c0-58f91573b268">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ceb51c75-4350-49f3-a9c0-58f91573b268">
											<gml:posList>35.6668477955559 139.73839776160847 25.052 35.666847757698356 139.73839547517832 25.052 35.66682187320522 139.73836493113535 25.052 35.666820007407196 139.7383649885739 25.052 35.6668477955559 139.73839776160847 25.052</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-bcfef94b-f2cb-4102-be85-84b26275381a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bcfef94b-f2cb-4102-be85-84b26275381a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bcfef94b-f2cb-4102-be85-84b26275381a">
											<gml:posList>35.66682187320522 139.73836493113535 25.052 35.66682187320522 139.73836493113535 24.764 35.66686478951435 139.7383102258142 24.764 35.66686478951435 139.7383102258142 25.052 35.66682187320522 139.73836493113535 25.052</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0ec376b5-3cbb-41d0-b72a-0ebd12fcc278">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0ec376b5-3cbb-41d0-b72a-0ebd12fcc278">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0ec376b5-3cbb-41d0-b72a-0ebd12fcc278">
											<gml:posList>35.66689068311331 139.73834086925706 25.052 35.66689068311331 139.73834086925706 24.764 35.666847757698356 139.73839547517832 24.764 35.666847757698356 139.73839547517832 25.052 35.66689068311331 139.73834086925706 25.052</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d630a5b5-568d-4d6f-8b29-7d6d1555c005">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d630a5b5-568d-4d6f-8b29-7d6d1555c005">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d630a5b5-568d-4d6f-8b29-7d6d1555c005">
											<gml:posList>35.66689254892002 139.73834082286365 12.428 35.666864760668865 139.73830793937296 12.428 35.666864760668865 139.73830793937296 25.052 35.66689254892002 139.73834082286365 25.052 35.66689254892002 139.73834082286365 12.428</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a81f38b7-836e-4e63-8725-0977d6cafc25">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a81f38b7-836e-4e63-8725-0977d6cafc25">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a81f38b7-836e-4e63-8725-0977d6cafc25">
											<gml:posList>35.66686478951435 139.7383102258142 25.052 35.66686478951435 139.7383102258142 24.764 35.66689068311331 139.73834086925706 24.764 35.66689068311331 139.73834086925706 25.052 35.66686478951435 139.7383102258142 25.052</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e1fa61d1-adcc-4b21-a8ed-faa8d6721100">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e1fa61d1-adcc-4b21-a8ed-faa8d6721100">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e1fa61d1-adcc-4b21-a8ed-faa8d6721100">
											<gml:posList>35.666864760668865 139.73830793937296 12.428 35.666820007407196 139.7383649885739 12.428 35.666820007407196 139.7383649885739 25.052 35.666864760668865 139.73830793937296 25.052 35.666864760668865 139.73830793937296 12.428</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8d02e67e-216b-4bb5-93e8-fe52cbddef61">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8d02e67e-216b-4bb5-93e8-fe52cbddef61">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8d02e67e-216b-4bb5-93e8-fe52cbddef61">
											<gml:posList>35.6668477955559 139.73839776160847 12.428 35.66689254892002 139.73834082286365 12.428 35.66689254892002 139.73834082286365 25.052 35.6668477955559 139.73839776160847 25.052 35.6668477955559 139.73839776160847 12.428</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-afaddd4f-0b1b-4ee6-b55a-642fcacfb0fc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-afaddd4f-0b1b-4ee6-b55a-642fcacfb0fc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-afaddd4f-0b1b-4ee6-b55a-642fcacfb0fc">
											<gml:posList>35.666847757698356 139.73839547517832 25.052 35.666847757698356 139.73839547517832 24.764 35.66682187320522 139.73836493113535 24.764 35.66682187320522 139.73836493113535 25.052 35.666847757698356 139.73839547517832 25.052</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3f8dc8de-ceb5-4819-894c-2ac57134494a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3f8dc8de-ceb5-4819-894c-2ac57134494a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3f8dc8de-ceb5-4819-894c-2ac57134494a">
											<gml:posList>35.666820007407196 139.7383649885739 12.428 35.6668477955559 139.73839776160847 12.428 35.6668477955559 139.73839776160847 25.052 35.666820007407196 139.7383649885739 25.052 35.666820007407196 139.7383649885739 12.428</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区六本木二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-3857</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">30.66365</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1002</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1210</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>7</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.03</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">12</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>