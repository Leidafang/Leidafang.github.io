<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_3197767b-37f8-4993-8b05-83ba4b86cd57">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>18</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103018001</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="再開発等促進区を定める地区計画">
				<gen:value>虎ノ門駅南地区</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">401</bldg:usage>
			<bldg:measuredHeight uom="m">12.5</bldg:measuredHeight>
			<bldg:storeysAboveGround>3</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.668867544649835 139.74989353657566 0 35.66883327570575 139.74999950382988 0 35.66887601521936 139.7500203364508 0 35.66891028418149 139.74991436914888 0 35.668867544649835 139.74989353657566 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668867544649835 139.74989353657566 5.885 35.66891028418149 139.74991436914888 5.885 35.66887601521936 139.7500203364508 5.885 35.66883327570575 139.74999950382988 5.885 35.668867544649835 139.74989353657566 5.885</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668867544649835 139.74989353657566 5.885 35.66883327570575 139.74999950382988 5.885 35.66883327570575 139.74999950382988 18.35 35.668867544649835 139.74989353657566 18.35 35.668867544649835 139.74989353657566 5.885</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66883327570575 139.74999950382988 5.885 35.66887601521936 139.7500203364508 5.885 35.66887601521936 139.7500203364508 18.35 35.66883327570575 139.74999950382988 18.35 35.66883327570575 139.74999950382988 5.885</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66887601521936 139.7500203364508 5.885 35.66891028418149 139.74991436914888 5.885 35.66891028418149 139.74991436914888 18.35 35.66887601521936 139.7500203364508 18.35 35.66887601521936 139.7500203364508 5.885</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66891028418149 139.74991436914888 5.885 35.668867544649835 139.74989353657566 5.885 35.668867544649835 139.74989353657566 18.35 35.66891028418149 139.74991436914888 18.35 35.66891028418149 139.74991436914888 5.885</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668867544649835 139.74989353657566 18.35 35.66883327570575 139.74999950382988 18.35 35.66887601521936 139.7500203364508 18.35 35.66891028418149 139.74991436914888 18.35 35.668867544649835 139.74989353657566 18.35</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-2a408083-7d38-48c3-9744-6d9ef86cc72c"/>
							<gml:surfaceMember xlink:href="#poly-79284c3c-abaa-4a4b-8877-a10bc5437872"/>
							<gml:surfaceMember xlink:href="#poly-6d2a4e9d-d26b-46fb-8223-3fed30044147"/>
							<gml:surfaceMember xlink:href="#poly-8ec02081-dec2-4eba-bd1c-8745de0dfde9"/>
							<gml:surfaceMember xlink:href="#poly-0aaeaf7a-e24d-4ac5-a5de-e6491bc65f5a"/>
							<gml:surfaceMember xlink:href="#poly-6ac92051-feaa-4d64-a558-a5e7e399600c"/>
							<gml:surfaceMember xlink:href="#poly-bf86bf01-1253-4695-bb13-7a6ed13c6935"/>
							<gml:surfaceMember xlink:href="#poly-17da261b-72c7-4f2a-ad75-01f404fe2b2f"/>
							<gml:surfaceMember xlink:href="#poly-90b2d004-b08b-4423-ad3d-a6b318ced278"/>
							<gml:surfaceMember xlink:href="#poly-389efe71-1bba-49bb-8386-04be3254f126"/>
							<gml:surfaceMember xlink:href="#poly-3013781a-c792-4c2a-b02c-3d407ac41330"/>
							<gml:surfaceMember xlink:href="#poly-d81b5d47-16b0-4c63-9560-a7d56cd14d8a"/>
							<gml:surfaceMember xlink:href="#poly-a210662a-761a-40f1-83f9-19932cab6b5d"/>
							<gml:surfaceMember xlink:href="#poly-e0814a62-a51a-4d20-b488-013c3e9b7e8d"/>
							<gml:surfaceMember xlink:href="#poly-bb9035b3-8500-4b02-9277-e75591d92673"/>
							<gml:surfaceMember xlink:href="#poly-7916a85d-0c7b-4e58-9985-bd48db60cc2c"/>
							<gml:surfaceMember xlink:href="#poly-354fcaf2-6a24-4c7e-9d29-2a2d3298f070"/>
							<gml:surfaceMember xlink:href="#poly-f159d0cc-69ed-4f53-8c07-d5f9e2bc00c4"/>
							<gml:surfaceMember xlink:href="#poly-7ff8cdb1-4c7c-4e31-be1f-fc33bc6f9707"/>
							<gml:surfaceMember xlink:href="#poly-1e729ef1-e578-414f-a86a-b55910d584ea"/>
							<gml:surfaceMember xlink:href="#poly-61331178-b852-42c3-a484-1b0e291dd238"/>
							<gml:surfaceMember xlink:href="#poly-ce84d47e-5925-4775-9675-5432ae1a2256"/>
							<gml:surfaceMember xlink:href="#poly-fdc8a1e3-4a05-4554-a245-ace7543df794"/>
							<gml:surfaceMember xlink:href="#poly-e3f273a7-d752-4898-9896-42d0b833c6d7"/>
							<gml:surfaceMember xlink:href="#poly-d0bd98a6-ed1a-40b5-b94f-8aeb012f8daa"/>
							<gml:surfaceMember xlink:href="#poly-ae7e4b1a-d053-4a2b-ae05-3ff0fd61bddb"/>
							<gml:surfaceMember xlink:href="#poly-f0299c2f-44fa-480c-9362-7669cf0bb310"/>
							<gml:surfaceMember xlink:href="#poly-1c2b7683-be7c-4997-b31e-1619083cad66"/>
							<gml:surfaceMember xlink:href="#poly-8ca596cd-ea09-4ca0-8219-3432ef8d6618"/>
							<gml:surfaceMember xlink:href="#poly-a81eda7d-aa2f-4195-901d-4cbb35e1565e"/>
							<gml:surfaceMember xlink:href="#poly-3a6c4cbe-8891-4318-84a4-3d703e95de08"/>
							<gml:surfaceMember xlink:href="#poly-cb53cf4e-c113-4ad2-a5e1-a1b8493c5b80"/>
							<gml:surfaceMember xlink:href="#poly-2ab98aaf-59d6-4d18-8de8-1ba187c9ee5f"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-2a408083-7d38-48c3-9744-6d9ef86cc72c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2a408083-7d38-48c3-9744-6d9ef86cc72c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2a408083-7d38-48c3-9744-6d9ef86cc72c">
											<gml:posList>35.66886754464984 139.74989353657563 5.885 35.66891028418148 139.74991436914885 5.885 35.66887601521935 139.7500203364508 5.885 35.66883327570573 139.74999950382988 5.885 35.66886754464984 139.74989353657563 5.885</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-79284c3c-abaa-4a4b-8877-a10bc5437872">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-79284c3c-abaa-4a4b-8877-a10bc5437872">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-79284c3c-abaa-4a4b-8877-a10bc5437872">
											<gml:posList>35.66883327570573 139.74999950382988 16.1 35.668858118173006 139.74998737153942 19.7 35.66887614298292 139.74993145977444 19.7 35.66886754464984 139.74989353657563 16.1 35.66883327570573 139.74999950382988 16.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-6d2a4e9d-d26b-46fb-8223-3fed30044147">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6d2a4e9d-d26b-46fb-8223-3fed30044147">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6d2a4e9d-d26b-46fb-8223-3fed30044147">
											<gml:posList>35.66887601521935 139.7500203364508 16.1 35.66888279705468 139.74999935294747 19.7 35.668858118173006 139.74998737153942 19.7 35.66883327570573 139.74999950382988 16.1 35.66887601521935 139.7500203364508 16.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-8ec02081-dec2-4eba-bd1c-8745de0dfde9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8ec02081-dec2-4eba-bd1c-8745de0dfde9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8ec02081-dec2-4eba-bd1c-8745de0dfde9">
											<gml:posList>35.668858118173006 139.74998737153942 19.7 35.668860677131136 139.7499860102152 19.7 35.66887727184862 139.7499345625412 19.7 35.66887614298292 139.74993145977444 19.7 35.668858118173006 139.74998737153942 19.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-0aaeaf7a-e24d-4ac5-a5de-e6491bc65f5a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0aaeaf7a-e24d-4ac5-a5de-e6491bc65f5a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0aaeaf7a-e24d-4ac5-a5de-e6491bc65f5a">
											<gml:posList>35.66888279705468 139.74999935294747 19.7 35.66888169520888 139.74999621701332 19.7 35.668860677131136 139.7499860102152 19.7 35.668858118173006 139.74998737153942 19.7 35.66888279705468 139.74999935294747 19.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-6ac92051-feaa-4d64-a558-a5e7e399600c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6ac92051-feaa-4d64-a558-a5e7e399600c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6ac92051-feaa-4d64-a558-a5e7e399600c">
											<gml:posList>35.66889845192532 139.7499444046396 19.489 35.66889914441415 139.74994213947787 19.489 35.66888706212582 139.74993652960194 19.489 35.668886360623375 139.74993879477276 19.489 35.66888491796036 139.7499381224639 19.489 35.66887727184862 139.7499345625412 19.489 35.668860677131136 139.7499860102152 19.489 35.66888169520888 139.74999621701332 19.489 35.66889845192532 139.7499444046396 19.489</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-bf86bf01-1253-4695-bb13-7a6ed13c6935">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bf86bf01-1253-4695-bb13-7a6ed13c6935">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bf86bf01-1253-4695-bb13-7a6ed13c6935">
											<gml:posList>35.668885610449074 139.7499358573025 19.7 35.66887614298292 139.74993145977444 19.7 35.66887727184862 139.7499345625412 19.7 35.66888491796036 139.7499381224639 19.7 35.668885610449074 139.7499358573025 19.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-17da261b-72c7-4f2a-ad75-01f404fe2b2f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-17da261b-72c7-4f2a-ad75-01f404fe2b2f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-17da261b-72c7-4f2a-ad75-01f404fe2b2f">
											<gml:posList>35.66887614298292 139.74993145977444 19.7 35.668885610449074 139.7499358573025 19.7 35.66889500975443 139.74990691790626 16.1 35.66886754464984 139.74989353657563 16.1 35.66887614298292 139.74993145977444 19.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-90b2d004-b08b-4423-ad3d-a6b318ced278">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-90b2d004-b08b-4423-ad3d-a6b318ced278">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-90b2d004-b08b-4423-ad3d-a6b318ced278">
											<gml:posList>35.668885610449074 139.7499358573025 19.7 35.66888491796036 139.7499381224639 19.7 35.668886360623375 139.74993879477276 19.7 35.66888706212582 139.74993652960194 19.7 35.668885610449074 139.7499358573025 19.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-389efe71-1bba-49bb-8386-04be3254f126">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-389efe71-1bba-49bb-8386-04be3254f126">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-389efe71-1bba-49bb-8386-04be3254f126">
											<gml:posList>35.668885610449074 139.7499358573025 21.5 35.66888672773048 139.74993524860741 21.5 35.66889548843093 139.74990828711913 21.5 35.66889500975443 139.74990691790626 21.5 35.668885610449074 139.7499358573025 21.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-3013781a-c792-4c2a-b02c-3d407ac41330">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3013781a-c792-4c2a-b02c-3d407ac41330">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3013781a-c792-4c2a-b02c-3d407ac41330">
											<gml:posList>35.66890101987373 139.74994301016582 19.7 35.66889845192532 139.7499444046396 19.7 35.66888169520888 139.74999621701332 19.7 35.66888279705468 139.74999935294747 19.7 35.66890101987373 139.74994301016582 19.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d81b5d47-16b0-4c63-9560-a7d56cd14d8a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d81b5d47-16b0-4c63-9560-a7d56cd14d8a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d81b5d47-16b0-4c63-9560-a7d56cd14d8a">
											<gml:posList>35.66890101987373 139.74994301016582 21.5 35.668900532199196 139.7499416630541 21.5 35.66888672773048 139.74993524860741 21.5 35.668885610449074 139.7499358573025 21.5 35.66890101987373 139.74994301016582 21.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a210662a-761a-40f1-83f9-19932cab6b5d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a210662a-761a-40f1-83f9-19932cab6b5d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a210662a-761a-40f1-83f9-19932cab6b5d">
											<gml:posList>35.668900532199196 139.7499416630541 21.277 35.668909166892526 139.7499149667984 21.277 35.66889548843093 139.74990828711913 21.277 35.66888672773048 139.74993524860741 21.277 35.668900532199196 139.7499416630541 21.277</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e0814a62-a51a-4d20-b488-013c3e9b7e8d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e0814a62-a51a-4d20-b488-013c3e9b7e8d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e0814a62-a51a-4d20-b488-013c3e9b7e8d">
											<gml:posList>35.66889845192532 139.7499444046396 19.7 35.66890101987373 139.74994301016582 19.7 35.66889914441415 139.74994213947787 19.7 35.66889845192532 139.7499444046396 19.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-bb9035b3-8500-4b02-9277-e75591d92673">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bb9035b3-8500-4b02-9277-e75591d92673">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bb9035b3-8500-4b02-9277-e75591d92673">
											<gml:posList>35.66889500975443 139.74990691790626 21.5 35.66889548843093 139.74990828711913 21.5 35.668909166892526 139.7499149667984 21.5 35.66891028418148 139.74991436914885 21.5 35.66889500975443 139.74990691790626 21.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-7916a85d-0c7b-4e58-9985-bd48db60cc2c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7916a85d-0c7b-4e58-9985-bd48db60cc2c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7916a85d-0c7b-4e58-9985-bd48db60cc2c">
											<gml:posList>35.66891028418148 139.74991436914885 21.5 35.668909166892526 139.7499149667984 21.5 35.668900532199196 139.7499416630541 21.5 35.66890101987373 139.74994301016582 21.5 35.66891028418148 139.74991436914885 21.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-354fcaf2-6a24-4c7e-9d29-2a2d3298f070">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-354fcaf2-6a24-4c7e-9d29-2a2d3298f070">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-354fcaf2-6a24-4c7e-9d29-2a2d3298f070">
											<gml:posList>35.66888672773048 139.74993524860741 21.5 35.66888672773048 139.74993524860741 21.277 35.66889548843093 139.74990828711913 21.277 35.66889548843093 139.74990828711913 21.5 35.66888672773048 139.74993524860741 21.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f159d0cc-69ed-4f53-8c07-d5f9e2bc00c4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f159d0cc-69ed-4f53-8c07-d5f9e2bc00c4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f159d0cc-69ed-4f53-8c07-d5f9e2bc00c4">
											<gml:posList>35.668886360623375 139.74993879477276 19.7 35.668886360623375 139.74993879477276 19.489 35.66888706212582 139.74993652960194 19.489 35.66888706212582 139.74993652960194 19.7 35.668886360623375 139.74993879477276 19.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7ff8cdb1-4c7c-4e31-be1f-fc33bc6f9707">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7ff8cdb1-4c7c-4e31-be1f-fc33bc6f9707">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7ff8cdb1-4c7c-4e31-be1f-fc33bc6f9707">
											<gml:posList>35.668860677131136 139.7499860102152 19.7 35.668860677131136 139.7499860102152 19.489 35.66887727184862 139.7499345625412 19.489 35.66887727184862 139.7499345625412 19.7 35.668860677131136 139.7499860102152 19.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1e729ef1-e578-414f-a86a-b55910d584ea">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1e729ef1-e578-414f-a86a-b55910d584ea">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1e729ef1-e578-414f-a86a-b55910d584ea">
											<gml:posList>35.66886754464984 139.74989353657563 5.885 35.66883327570573 139.74999950382988 5.885 35.66883327570573 139.74999950382988 16.1 35.66886754464984 139.74989353657563 16.1 35.66886754464984 139.74989353657563 5.885</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-61331178-b852-42c3-a484-1b0e291dd238">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-61331178-b852-42c3-a484-1b0e291dd238">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-61331178-b852-42c3-a484-1b0e291dd238">
											<gml:posList>35.66883327570573 139.74999950382988 5.885 35.66887601521935 139.7500203364508 5.885 35.66887601521935 139.7500203364508 16.1 35.66883327570573 139.74999950382988 16.1 35.66883327570573 139.74999950382988 5.885</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ce84d47e-5925-4775-9675-5432ae1a2256">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ce84d47e-5925-4775-9675-5432ae1a2256">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ce84d47e-5925-4775-9675-5432ae1a2256">
											<gml:posList>35.66888169520888 139.74999621701332 19.7 35.66888169520888 139.74999621701332 19.489 35.668860677131136 139.7499860102152 19.489 35.668860677131136 139.7499860102152 19.7 35.66888169520888 139.74999621701332 19.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-fdc8a1e3-4a05-4554-a245-ace7543df794">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fdc8a1e3-4a05-4554-a245-ace7543df794">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fdc8a1e3-4a05-4554-a245-ace7543df794">
											<gml:posList>35.66887727184862 139.7499345625412 19.7 35.66887727184862 139.7499345625412 19.489 35.66888491796036 139.7499381224639 19.489 35.66888491796036 139.7499381224639 19.7 35.66887727184862 139.7499345625412 19.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e3f273a7-d752-4898-9896-42d0b833c6d7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e3f273a7-d752-4898-9896-42d0b833c6d7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e3f273a7-d752-4898-9896-42d0b833c6d7">
											<gml:posList>35.66888491796036 139.7499381224639 19.7 35.66888491796036 139.7499381224639 19.489 35.668886360623375 139.74993879477276 19.489 35.668886360623375 139.74993879477276 19.7 35.66888491796036 139.7499381224639 19.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d0bd98a6-ed1a-40b5-b94f-8aeb012f8daa">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d0bd98a6-ed1a-40b5-b94f-8aeb012f8daa">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d0bd98a6-ed1a-40b5-b94f-8aeb012f8daa">
											<gml:posList>35.66891028418148 139.74991436914885 5.885 35.66886754464984 139.74989353657563 5.885 35.66886754464984 139.74989353657563 16.1 35.66889500975443 139.74990691790626 16.1 35.66889500975443 139.74990691790626 21.5 35.66891028418148 139.74991436914885 21.5 35.66891028418148 139.74991436914885 5.885</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ae7e4b1a-d053-4a2b-ae05-3ff0fd61bddb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ae7e4b1a-d053-4a2b-ae05-3ff0fd61bddb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ae7e4b1a-d053-4a2b-ae05-3ff0fd61bddb">
											<gml:posList>35.66889845192532 139.7499444046396 19.7 35.66889845192532 139.7499444046396 19.489 35.66888169520888 139.74999621701332 19.489 35.66888169520888 139.74999621701332 19.7 35.66889845192532 139.7499444046396 19.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f0299c2f-44fa-480c-9362-7669cf0bb310">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f0299c2f-44fa-480c-9362-7669cf0bb310">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f0299c2f-44fa-480c-9362-7669cf0bb310">
											<gml:posList>35.66889500975443 139.74990691790626 16.1 35.668885610449074 139.7499358573025 19.7 35.668885610449074 139.7499358573025 21.5 35.66889500975443 139.74990691790626 21.5 35.66889500975443 139.74990691790626 16.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1c2b7683-be7c-4997-b31e-1619083cad66">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1c2b7683-be7c-4997-b31e-1619083cad66">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1c2b7683-be7c-4997-b31e-1619083cad66">
											<gml:posList>35.66890101987373 139.74994301016582 19.7 35.66888279705468 139.74999935294747 19.7 35.66887601521935 139.7500203364508 16.1 35.66887601521935 139.7500203364508 5.885 35.66891028418148 139.74991436914885 5.885 35.66891028418148 139.74991436914885 21.5 35.66890101987373 139.74994301016582 21.5 35.66890101987373 139.74994301016582 19.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8ca596cd-ea09-4ca0-8219-3432ef8d6618">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8ca596cd-ea09-4ca0-8219-3432ef8d6618">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8ca596cd-ea09-4ca0-8219-3432ef8d6618">
											<gml:posList>35.66888706212582 139.74993652960194 19.7 35.66888706212582 139.74993652960194 19.489 35.66889914441415 139.74994213947787 19.489 35.66889914441415 139.74994213947787 19.7 35.66890101987373 139.74994301016582 19.7 35.66890101987373 139.74994301016582 21.5 35.668885610449074 139.7499358573025 21.5 35.668885610449074 139.7499358573025 19.7 35.66888706212582 139.74993652960194 19.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a81eda7d-aa2f-4195-901d-4cbb35e1565e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a81eda7d-aa2f-4195-901d-4cbb35e1565e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a81eda7d-aa2f-4195-901d-4cbb35e1565e">
											<gml:posList>35.668900532199196 139.7499416630541 21.5 35.668900532199196 139.7499416630541 21.277 35.66888672773048 139.74993524860741 21.277 35.66888672773048 139.74993524860741 21.5 35.668900532199196 139.7499416630541 21.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3a6c4cbe-8891-4318-84a4-3d703e95de08">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3a6c4cbe-8891-4318-84a4-3d703e95de08">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3a6c4cbe-8891-4318-84a4-3d703e95de08">
											<gml:posList>35.66889914441415 139.74994213947787 19.7 35.66889914441415 139.74994213947787 19.489 35.66889845192532 139.7499444046396 19.489 35.66889845192532 139.7499444046396 19.7 35.66889914441415 139.74994213947787 19.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-cb53cf4e-c113-4ad2-a5e1-a1b8493c5b80">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cb53cf4e-c113-4ad2-a5e1-a1b8493c5b80">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cb53cf4e-c113-4ad2-a5e1-a1b8493c5b80">
											<gml:posList>35.66889548843093 139.74990828711913 21.5 35.66889548843093 139.74990828711913 21.277 35.668909166892526 139.7499149667984 21.277 35.668909166892526 139.7499149667984 21.5 35.66889548843093 139.74990828711913 21.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2ab98aaf-59d6-4d18-8de8-1ba187c9ee5f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2ab98aaf-59d6-4d18-8de8-1ba187c9ee5f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2ab98aaf-59d6-4d18-8de8-1ba187c9ee5f">
											<gml:posList>35.668909166892526 139.7499149667984 21.5 35.668909166892526 139.7499149667984 21.277 35.668900532199196 139.7499416630541 21.277 35.668900532199196 139.7499416630541 21.5 35.668909166892526 139.7499149667984 21.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区虎ノ門一丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-2795</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">52.6575</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1210</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>7</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.01</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>