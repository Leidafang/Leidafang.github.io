<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_34277639-1b38-4c2f-8f99-640ea30967b1">
			<core:creationDate>2024-03-15</core:creationDate>
			<bldg:measuredHeight uom="m">6</bldg:measuredHeight>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.669808732597645 139.73893362981056 0 35.66979213926027 139.7389463303595 0 35.6697592110205 139.73895645427925 0 35.66977308219709 139.73902426147035 0 35.669844552895135 139.73900229491096 0 35.6698425079446 139.73899227842688 0 35.66993948135164 139.73896247214313 0 35.66992570970723 139.7388951949223 0 35.66992264577779 139.7388961374578 0 35.66992120709452 139.73888912481783 0 35.66990249008826 139.73889487983934 0 35.66988504889359 139.7389068523611 0 35.66985546395212 139.7389159561227 0 35.66985749983465 139.73892589529382 0 35.66982818522537 139.73893489931126 0 35.66982679176013 139.73892807441075 0 35.669808732597645 139.73893362981056 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669808732597645 139.73893362981056 20.52 35.66982679176013 139.73892807441075 20.52 35.66982818522537 139.73893489931126 20.52 35.66985749983465 139.73892589529382 20.52 35.66985546395212 139.7389159561227 20.52 35.66988504889359 139.7389068523611 20.52 35.66990249008826 139.73889487983934 20.52 35.66992120709452 139.73888912481783 20.52 35.66992264577779 139.7388961374578 20.52 35.66992570970723 139.7388951949223 20.52 35.66993948135164 139.73896247214313 20.52 35.6698425079446 139.73899227842688 20.52 35.669844552895135 139.73900229491096 20.52 35.66977308219709 139.73902426147035 20.52 35.6697592110205 139.73895645427925 20.52 35.66979213926027 139.7389463303595 20.52 35.669808732597645 139.73893362981056 20.52</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669808732597645 139.73893362981056 20.52 35.66979213926027 139.7389463303595 20.52 35.66979213926027 139.7389463303595 26.48 35.669808732597645 139.73893362981056 26.48 35.669808732597645 139.73893362981056 20.52</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66979213926027 139.7389463303595 20.52 35.6697592110205 139.73895645427925 20.52 35.6697592110205 139.73895645427925 26.48 35.66979213926027 139.7389463303595 26.48 35.66979213926027 139.7389463303595 20.52</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6697592110205 139.73895645427925 20.52 35.66977308219709 139.73902426147035 20.52 35.66977308219709 139.73902426147035 26.48 35.6697592110205 139.73895645427925 26.48 35.6697592110205 139.73895645427925 20.52</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66977308219709 139.73902426147035 20.52 35.669844552895135 139.73900229491096 20.52 35.669844552895135 139.73900229491096 26.48 35.66977308219709 139.73902426147035 26.48 35.66977308219709 139.73902426147035 20.52</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669844552895135 139.73900229491096 20.52 35.6698425079446 139.73899227842688 20.52 35.6698425079446 139.73899227842688 26.48 35.669844552895135 139.73900229491096 26.48 35.669844552895135 139.73900229491096 20.52</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6698425079446 139.73899227842688 20.52 35.66993948135164 139.73896247214313 20.52 35.66993948135164 139.73896247214313 26.48 35.6698425079446 139.73899227842688 26.48 35.6698425079446 139.73899227842688 20.52</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66993948135164 139.73896247214313 20.52 35.66992570970723 139.7388951949223 20.52 35.66992570970723 139.7388951949223 26.48 35.66993948135164 139.73896247214313 26.48 35.66993948135164 139.73896247214313 20.52</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66992570970723 139.7388951949223 20.52 35.66992264577779 139.7388961374578 20.52 35.66992264577779 139.7388961374578 26.48 35.66992570970723 139.7388951949223 26.48 35.66992570970723 139.7388951949223 20.52</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66992264577779 139.7388961374578 20.52 35.66992120709452 139.73888912481783 20.52 35.66992120709452 139.73888912481783 26.48 35.66992264577779 139.7388961374578 26.48 35.66992264577779 139.7388961374578 20.52</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66992120709452 139.73888912481783 20.52 35.66990249008826 139.73889487983934 20.52 35.66990249008826 139.73889487983934 26.48 35.66992120709452 139.73888912481783 26.48 35.66992120709452 139.73888912481783 20.52</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66990249008826 139.73889487983934 20.52 35.66988504889359 139.7389068523611 20.52 35.66988504889359 139.7389068523611 26.48 35.66990249008826 139.73889487983934 26.48 35.66990249008826 139.73889487983934 20.52</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66988504889359 139.7389068523611 20.52 35.66985546395212 139.7389159561227 20.52 35.66985546395212 139.7389159561227 26.48 35.66988504889359 139.7389068523611 26.48 35.66988504889359 139.7389068523611 20.52</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66985546395212 139.7389159561227 20.52 35.66985749983465 139.73892589529382 20.52 35.66985749983465 139.73892589529382 26.48 35.66985546395212 139.7389159561227 26.48 35.66985546395212 139.7389159561227 20.52</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66985749983465 139.73892589529382 20.52 35.66982818522537 139.73893489931126 20.52 35.66982818522537 139.73893489931126 26.48 35.66985749983465 139.73892589529382 26.48 35.66985749983465 139.73892589529382 20.52</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66982818522537 139.73893489931126 20.52 35.66982679176013 139.73892807441075 20.52 35.66982679176013 139.73892807441075 26.48 35.66982818522537 139.73893489931126 26.48 35.66982818522537 139.73893489931126 20.52</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66982679176013 139.73892807441075 20.52 35.669808732597645 139.73893362981056 20.52 35.669808732597645 139.73893362981056 26.48 35.66982679176013 139.73892807441075 26.48 35.66982679176013 139.73892807441075 20.52</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669808732597645 139.73893362981056 26.48 35.66979213926027 139.7389463303595 26.48 35.6697592110205 139.73895645427925 26.48 35.66977308219709 139.73902426147035 26.48 35.669844552895135 139.73900229491096 26.48 35.6698425079446 139.73899227842688 26.48 35.66993948135164 139.73896247214313 26.48 35.66992570970723 139.7388951949223 26.48 35.66992264577779 139.7388961374578 26.48 35.66992120709452 139.73888912481783 26.48 35.66990249008826 139.73889487983934 26.48 35.66988504889359 139.7389068523611 26.48 35.66985546395212 139.7389159561227 26.48 35.66985749983465 139.73892589529382 26.48 35.66982818522537 139.73893489931126 26.48 35.66982679176013 139.73892807441075 26.48 35.669808732597645 139.73893362981056 26.48</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-7ccb309f-28d2-42bf-a890-c59991b074e9"/>
							<gml:surfaceMember xlink:href="#poly-09525bd4-468c-47aa-89bd-aadaffcd0182"/>
							<gml:surfaceMember xlink:href="#poly-2ab4cd48-2cf0-4221-ac58-5ed4ec6a8dff"/>
							<gml:surfaceMember xlink:href="#poly-9a487060-42d6-464f-aa44-fda34f7519bd"/>
							<gml:surfaceMember xlink:href="#poly-a7899615-ae52-4fc7-9f3e-9d6b79fe2bcf"/>
							<gml:surfaceMember xlink:href="#poly-a4fec5bd-6fca-4ad6-8903-5541bb62b00f"/>
							<gml:surfaceMember xlink:href="#poly-e1cfc94e-1197-4c70-9a49-a1223fb5315c"/>
							<gml:surfaceMember xlink:href="#poly-449e0f3c-9fdd-4101-bb0a-9129638b7b3d"/>
							<gml:surfaceMember xlink:href="#poly-db2ca658-e03e-46fd-ae22-6a1516772bb5"/>
							<gml:surfaceMember xlink:href="#poly-5a2f88d0-3fbe-49cc-8629-5cd54623e9db"/>
							<gml:surfaceMember xlink:href="#poly-59ed2f6d-6397-4f12-8ca7-a9a60289832f"/>
							<gml:surfaceMember xlink:href="#poly-2a024516-87fe-4a6c-9780-f02fec36952b"/>
							<gml:surfaceMember xlink:href="#poly-4911a6a7-869e-47eb-a6cd-65568a45dc4c"/>
							<gml:surfaceMember xlink:href="#poly-b8d000e9-4e4f-4170-9bfd-dba2edf7b8ef"/>
							<gml:surfaceMember xlink:href="#poly-9cb33269-b055-42e6-806f-bdbaab3ef617"/>
							<gml:surfaceMember xlink:href="#poly-ed1bb44a-f47a-42a1-b54f-78090245b216"/>
							<gml:surfaceMember xlink:href="#poly-562b5cc3-9dbd-4765-a2da-f52977aab5eb"/>
							<gml:surfaceMember xlink:href="#poly-60dfa414-040a-4794-852e-4baf231cd0d5"/>
							<gml:surfaceMember xlink:href="#poly-9da1dae2-0195-4ce2-abc8-cff058f9de04"/>
							<gml:surfaceMember xlink:href="#poly-06d70daa-8f66-4389-9c59-2334806d8af5"/>
							<gml:surfaceMember xlink:href="#poly-0742207c-28da-4861-84df-9c17acb8ecea"/>
							<gml:surfaceMember xlink:href="#poly-9ae02754-606d-4d20-b7e1-a76deab81fe3"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-7ccb309f-28d2-42bf-a890-c59991b074e9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7ccb309f-28d2-42bf-a890-c59991b074e9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7ccb309f-28d2-42bf-a890-c59991b074e9">
											<gml:posList>35.66979213926026 139.7389463303595 20.52 35.66980873259762 139.73893362981056 20.52 35.66982679176014 139.73892807441072 20.52 35.669828185225356 139.73893489931126 20.52 35.669857499834656 139.7389258952938 20.52 35.669855463952125 139.73891595612267 20.52 35.6698850488936 139.7389068523611 20.52 35.66990249008824 139.73889487983934 20.52 35.669921207094504 139.7388891248178 20.52 35.669922645777795 139.7388961374578 20.52 35.66992570970723 139.73889519492226 20.52 35.669939481351655 139.73896247214313 20.52 35.66984250794461 139.73899227842688 20.52 35.66984455289514 139.73900229491096 20.52 35.669773082197096 139.73902426147035 20.52 35.6697592110205 139.73895645427922 20.52 35.66979213926026 139.7389463303595 20.52</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-09525bd4-468c-47aa-89bd-aadaffcd0182">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-09525bd4-468c-47aa-89bd-aadaffcd0182">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-09525bd4-468c-47aa-89bd-aadaffcd0182">
											<gml:posList>35.669857499834656 139.7389258952938 27.107 35.66986939844655 139.73898401737597 27.107 35.669939481351655 139.73896247214313 27.107 35.66992570970723 139.73889519492226 27.107 35.669922645777795 139.7388961374578 27.107 35.669921207094504 139.7388891248178 27.107 35.66990249008824 139.73889487983934 27.107 35.6698850488936 139.7389068523611 27.107 35.669855463952125 139.73891595612267 27.107 35.669857499834656 139.7389258952938 27.107</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-2ab4cd48-2cf0-4221-ac58-5ed4ec6a8dff">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2ab4cd48-2cf0-4221-ac58-5ed4ec6a8dff">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2ab4cd48-2cf0-4221-ac58-5ed4ec6a8dff">
											<gml:posList>35.669857499834656 139.7389258952938 23.704 35.669828185225356 139.73893489931126 23.704 35.66984250794461 139.73899227842688 23.704 35.66986939844655 139.73898401737597 23.704 35.669857499834656 139.7389258952938 23.704</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-9a487060-42d6-464f-aa44-fda34f7519bd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9a487060-42d6-464f-aa44-fda34f7519bd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9a487060-42d6-464f-aa44-fda34f7519bd">
											<gml:posList>35.66979213926026 139.7389463303595 27.107 35.6697592110205 139.73895645427922 27.107 35.669773082197096 139.73902426147035 27.107 35.66984455289514 139.73900229491096 27.107 35.66984250794461 139.73899227842688 27.107 35.669828185225356 139.73893489931126 27.107 35.66982679176014 139.73892807441072 27.107 35.66980873259762 139.73893362981056 27.107 35.66979213926026 139.7389463303595 27.107</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a7899615-ae52-4fc7-9f3e-9d6b79fe2bcf">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a7899615-ae52-4fc7-9f3e-9d6b79fe2bcf">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a7899615-ae52-4fc7-9f3e-9d6b79fe2bcf">
											<gml:posList>35.669921207094504 139.7388891248178 20.52 35.66990249008824 139.73889487983934 20.52 35.66990249008824 139.73889487983934 27.107 35.669921207094504 139.7388891248178 27.107 35.669921207094504 139.7388891248178 20.52</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a4fec5bd-6fca-4ad6-8903-5541bb62b00f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a4fec5bd-6fca-4ad6-8903-5541bb62b00f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a4fec5bd-6fca-4ad6-8903-5541bb62b00f">
											<gml:posList>35.669922645777795 139.7388961374578 20.52 35.669921207094504 139.7388891248178 20.52 35.669921207094504 139.7388891248178 27.107 35.669922645777795 139.7388961374578 27.107 35.669922645777795 139.7388961374578 20.52</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e1cfc94e-1197-4c70-9a49-a1223fb5315c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e1cfc94e-1197-4c70-9a49-a1223fb5315c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e1cfc94e-1197-4c70-9a49-a1223fb5315c">
											<gml:posList>35.66992570970723 139.73889519492226 20.52 35.669922645777795 139.7388961374578 20.52 35.669922645777795 139.7388961374578 27.107 35.66992570970723 139.73889519492226 27.107 35.66992570970723 139.73889519492226 20.52</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-449e0f3c-9fdd-4101-bb0a-9129638b7b3d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-449e0f3c-9fdd-4101-bb0a-9129638b7b3d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-449e0f3c-9fdd-4101-bb0a-9129638b7b3d">
											<gml:posList>35.66990249008824 139.73889487983934 20.52 35.6698850488936 139.7389068523611 20.52 35.6698850488936 139.7389068523611 27.107 35.66990249008824 139.73889487983934 27.107 35.66990249008824 139.73889487983934 20.52</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-db2ca658-e03e-46fd-ae22-6a1516772bb5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-db2ca658-e03e-46fd-ae22-6a1516772bb5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-db2ca658-e03e-46fd-ae22-6a1516772bb5">
											<gml:posList>35.6698850488936 139.7389068523611 20.52 35.669855463952125 139.73891595612267 20.52 35.669855463952125 139.73891595612267 27.107 35.6698850488936 139.7389068523611 27.107 35.6698850488936 139.7389068523611 20.52</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5a2f88d0-3fbe-49cc-8629-5cd54623e9db">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5a2f88d0-3fbe-49cc-8629-5cd54623e9db">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5a2f88d0-3fbe-49cc-8629-5cd54623e9db">
											<gml:posList>35.669855463952125 139.73891595612267 27.107 35.669855463952125 139.73891595612267 20.52 35.669857499834656 139.7389258952938 20.52 35.669857499834656 139.7389258952938 23.704 35.669857499834656 139.7389258952938 27.107 35.669855463952125 139.73891595612267 27.107</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-59ed2f6d-6397-4f12-8ca7-a9a60289832f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-59ed2f6d-6397-4f12-8ca7-a9a60289832f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-59ed2f6d-6397-4f12-8ca7-a9a60289832f">
											<gml:posList>35.669939481351655 139.73896247214313 20.52 35.66992570970723 139.73889519492226 20.52 35.66992570970723 139.73889519492226 27.107 35.669939481351655 139.73896247214313 27.107 35.669939481351655 139.73896247214313 20.52</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2a024516-87fe-4a6c-9780-f02fec36952b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2a024516-87fe-4a6c-9780-f02fec36952b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2a024516-87fe-4a6c-9780-f02fec36952b">
											<gml:posList>35.669857499834656 139.7389258952938 23.704 35.669857499834656 139.7389258952938 20.52 35.669828185225356 139.73893489931126 20.52 35.669828185225356 139.73893489931126 23.704 35.669857499834656 139.7389258952938 23.704</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4911a6a7-869e-47eb-a6cd-65568a45dc4c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4911a6a7-869e-47eb-a6cd-65568a45dc4c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4911a6a7-869e-47eb-a6cd-65568a45dc4c">
											<gml:posList>35.66982679176014 139.73892807441072 20.52 35.66980873259762 139.73893362981056 20.52 35.66980873259762 139.73893362981056 27.107 35.66982679176014 139.73892807441072 27.107 35.66982679176014 139.73892807441072 20.52</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b8d000e9-4e4f-4170-9bfd-dba2edf7b8ef">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b8d000e9-4e4f-4170-9bfd-dba2edf7b8ef">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b8d000e9-4e4f-4170-9bfd-dba2edf7b8ef">
											<gml:posList>35.66982679176014 139.73892807441072 20.52 35.66982679176014 139.73892807441072 27.107 35.669828185225356 139.73893489931126 27.107 35.669828185225356 139.73893489931126 23.704 35.669828185225356 139.73893489931126 20.52 35.66982679176014 139.73892807441072 20.52</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9cb33269-b055-42e6-806f-bdbaab3ef617">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9cb33269-b055-42e6-806f-bdbaab3ef617">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9cb33269-b055-42e6-806f-bdbaab3ef617">
											<gml:posList>35.66980873259762 139.73893362981056 20.52 35.66979213926026 139.7389463303595 20.52 35.66979213926026 139.7389463303595 27.107 35.66980873259762 139.73893362981056 27.107 35.66980873259762 139.73893362981056 20.52</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ed1bb44a-f47a-42a1-b54f-78090245b216">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ed1bb44a-f47a-42a1-b54f-78090245b216">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ed1bb44a-f47a-42a1-b54f-78090245b216">
											<gml:posList>35.66979213926026 139.7389463303595 20.52 35.6697592110205 139.73895645427922 20.52 35.6697592110205 139.73895645427922 27.107 35.66979213926026 139.7389463303595 27.107 35.66979213926026 139.7389463303595 20.52</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-562b5cc3-9dbd-4765-a2da-f52977aab5eb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-562b5cc3-9dbd-4765-a2da-f52977aab5eb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-562b5cc3-9dbd-4765-a2da-f52977aab5eb">
											<gml:posList>35.669857499834656 139.7389258952938 27.107 35.669857499834656 139.7389258952938 23.704 35.66986939844655 139.73898401737597 23.704 35.66986939844655 139.73898401737597 27.107 35.669857499834656 139.7389258952938 27.107</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-60dfa414-040a-4794-852e-4baf231cd0d5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-60dfa414-040a-4794-852e-4baf231cd0d5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-60dfa414-040a-4794-852e-4baf231cd0d5">
											<gml:posList>35.66984250794461 139.73899227842688 27.107 35.66984250794461 139.73899227842688 23.704 35.669828185225356 139.73893489931126 23.704 35.669828185225356 139.73893489931126 27.107 35.66984250794461 139.73899227842688 27.107</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9da1dae2-0195-4ce2-abc8-cff058f9de04">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9da1dae2-0195-4ce2-abc8-cff058f9de04">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9da1dae2-0195-4ce2-abc8-cff058f9de04">
											<gml:posList>35.66984250794461 139.73899227842688 20.52 35.669939481351655 139.73896247214313 20.52 35.669939481351655 139.73896247214313 27.107 35.66986939844655 139.73898401737597 27.107 35.66986939844655 139.73898401737597 23.704 35.66984250794461 139.73899227842688 23.704 35.66984250794461 139.73899227842688 20.52</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-06d70daa-8f66-4389-9c59-2334806d8af5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-06d70daa-8f66-4389-9c59-2334806d8af5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-06d70daa-8f66-4389-9c59-2334806d8af5">
											<gml:posList>35.6697592110205 139.73895645427922 20.52 35.669773082197096 139.73902426147035 20.52 35.669773082197096 139.73902426147035 27.107 35.6697592110205 139.73895645427922 27.107 35.6697592110205 139.73895645427922 20.52</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0742207c-28da-4861-84df-9c17acb8ecea">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0742207c-28da-4861-84df-9c17acb8ecea">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0742207c-28da-4861-84df-9c17acb8ecea">
											<gml:posList>35.66984455289514 139.73900229491096 27.107 35.66984455289514 139.73900229491096 20.52 35.66984250794461 139.73899227842688 20.52 35.66984250794461 139.73899227842688 23.704 35.66984250794461 139.73899227842688 27.107 35.66984455289514 139.73900229491096 27.107</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9ae02754-606d-4d20-b7e1-a76deab81fe3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9ae02754-606d-4d20-b7e1-a76deab81fe3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9ae02754-606d-4d20-b7e1-a76deab81fe3">
											<gml:posList>35.669773082197096 139.73902426147035 20.52 35.66984455289514 139.73900229491096 20.52 35.66984455289514 139.73900229491096 27.107 35.669773082197096 139.73902426147035 27.107 35.669773082197096 139.73902426147035 20.52</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-4311</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">211</uro:landUseType>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>4</uro:specifiedFloorAreaRate>
					<uro:surveyYear>0001</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>