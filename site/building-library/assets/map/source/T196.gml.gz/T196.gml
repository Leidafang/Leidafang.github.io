<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_345f1a5e-ffe7-4ca3-9133-bd37b3ffb271">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">401</bldg:usage>
			<bldg:measuredHeight uom="m">20.4</bldg:measuredHeight>
			<bldg:storeysAboveGround>6</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.67058833190153 139.73811157506583 0 35.67055078975955 139.7381230304626 0 35.670556481519945 139.738151014986 0 35.67054828095404 139.73815345490343 0 35.67055687742392 139.73819575196435 0 35.67070791152096 139.73815017243655 0 35.67068809380481 139.7380519943421 0 35.67058176632523 139.73808425434945 0 35.67058833190153 139.73811157506583 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67058833190153 139.73811157506583 17.354 35.67058176632523 139.73808425434945 17.354 35.67068809380481 139.7380519943421 17.354 35.67070791152096 139.73815017243655 17.354 35.67055687742392 139.73819575196435 17.354 35.67054828095404 139.73815345490343 17.354 35.670556481519945 139.738151014986 17.354 35.67055078975955 139.7381230304626 17.354 35.67058833190153 139.73811157506583 17.354</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67058833190153 139.73811157506583 17.354 35.67055078975955 139.7381230304626 17.354 35.67055078975955 139.7381230304626 37.74 35.67058833190153 139.73811157506583 37.74 35.67058833190153 139.73811157506583 17.354</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67055078975955 139.7381230304626 17.354 35.670556481519945 139.738151014986 17.354 35.670556481519945 139.738151014986 37.74 35.67055078975955 139.7381230304626 37.74 35.67055078975955 139.7381230304626 17.354</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670556481519945 139.738151014986 17.354 35.67054828095404 139.73815345490343 17.354 35.67054828095404 139.73815345490343 37.74 35.670556481519945 139.738151014986 37.74 35.670556481519945 139.738151014986 17.354</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67054828095404 139.73815345490343 17.354 35.67055687742392 139.73819575196435 17.354 35.67055687742392 139.73819575196435 37.74 35.67054828095404 139.73815345490343 37.74 35.67054828095404 139.73815345490343 17.354</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67055687742392 139.73819575196435 17.354 35.67070791152096 139.73815017243655 17.354 35.67070791152096 139.73815017243655 37.74 35.67055687742392 139.73819575196435 37.74 35.67055687742392 139.73819575196435 17.354</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67070791152096 139.73815017243655 17.354 35.67068809380481 139.7380519943421 17.354 35.67068809380481 139.7380519943421 37.74 35.67070791152096 139.73815017243655 37.74 35.67070791152096 139.73815017243655 17.354</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67068809380481 139.7380519943421 17.354 35.67058176632523 139.73808425434945 17.354 35.67058176632523 139.73808425434945 37.74 35.67068809380481 139.7380519943421 37.74 35.67068809380481 139.7380519943421 17.354</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67058176632523 139.73808425434945 17.354 35.67058833190153 139.73811157506583 17.354 35.67058833190153 139.73811157506583 37.74 35.67058176632523 139.73808425434945 37.74 35.67058176632523 139.73808425434945 17.354</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67058833190153 139.73811157506583 37.74 35.67055078975955 139.7381230304626 37.74 35.670556481519945 139.738151014986 37.74 35.67054828095404 139.73815345490343 37.74 35.67055687742392 139.73819575196435 37.74 35.67070791152096 139.73815017243655 37.74 35.67068809380481 139.7380519943421 37.74 35.67058176632523 139.73808425434945 37.74 35.67058833190153 139.73811157506583 37.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-0332f0b7-fb65-4485-808a-6c45ecc7e58e"/>
							<gml:surfaceMember xlink:href="#poly-8745b50e-5d8c-4760-a95f-b16b3ffe2dde"/>
							<gml:surfaceMember xlink:href="#poly-900091a5-c6e4-46f6-bf4a-d068b481d2b8"/>
							<gml:surfaceMember xlink:href="#poly-36a2df70-f2b3-429f-a440-4f7feca0d7be"/>
							<gml:surfaceMember xlink:href="#poly-4b0002d3-3967-4131-b8b4-f68192ff8caa"/>
							<gml:surfaceMember xlink:href="#poly-2c8d726c-9be1-46c0-ad95-7d138f1dfbae"/>
							<gml:surfaceMember xlink:href="#poly-69134154-d2c9-42d2-8043-f3f978f48baf"/>
							<gml:surfaceMember xlink:href="#poly-911ac8ee-c62e-4fe2-9fc3-9afe68fcd627"/>
							<gml:surfaceMember xlink:href="#poly-1a5696b9-3c9d-47ce-9f12-35918e444d3c"/>
							<gml:surfaceMember xlink:href="#poly-43091cee-3fb5-4600-ab20-bdae10674088"/>
							<gml:surfaceMember xlink:href="#poly-90e63341-b897-4656-8002-2d1accdb1ad2"/>
							<gml:surfaceMember xlink:href="#poly-81e70a79-99ec-4df4-8848-48842c485571"/>
							<gml:surfaceMember xlink:href="#poly-2d725ef4-b2ec-4758-952f-54ea31822f5d"/>
							<gml:surfaceMember xlink:href="#poly-3f2789aa-b202-48bb-bc7c-c53843d4c8b5"/>
							<gml:surfaceMember xlink:href="#poly-a94d582f-d483-477e-a399-35df8f598d17"/>
							<gml:surfaceMember xlink:href="#poly-947538c4-2559-4a68-9370-995bc31b028a"/>
							<gml:surfaceMember xlink:href="#poly-b4f059a0-3519-4a54-bc5a-e56cfecc2d31"/>
							<gml:surfaceMember xlink:href="#poly-f14c190d-ab03-491c-ab96-6ad5901985dd"/>
							<gml:surfaceMember xlink:href="#poly-86a4602e-730b-415c-a98b-4b09471d789e"/>
							<gml:surfaceMember xlink:href="#poly-e8e5d83c-1bd2-4a1c-942c-6001b89cdb9c"/>
							<gml:surfaceMember xlink:href="#poly-79fb1392-81a3-4c71-8b0d-d985205fba5d"/>
							<gml:surfaceMember xlink:href="#poly-930e3902-2f7f-4361-907c-949a9ee9e5cd"/>
							<gml:surfaceMember xlink:href="#poly-10985b20-f9c7-414f-ba31-e81f49a4bae6"/>
							<gml:surfaceMember xlink:href="#poly-cece860d-bb09-4ea2-9334-73da1f6ca387"/>
							<gml:surfaceMember xlink:href="#poly-c868f209-247a-41f1-9ed7-e90c2d8cffdc"/>
							<gml:surfaceMember xlink:href="#poly-3699ab9d-5c8e-4216-889f-34d29bba1e75"/>
							<gml:surfaceMember xlink:href="#poly-55b6d072-2251-4457-a06d-7e939cb5cb13"/>
							<gml:surfaceMember xlink:href="#poly-ff22af20-ccd8-4e5f-ad5b-7950cc943c05"/>
							<gml:surfaceMember xlink:href="#poly-85a7055e-4337-4742-9631-dc2f1374f17d"/>
							<gml:surfaceMember xlink:href="#poly-cf2d8c60-16fe-406f-9e05-9164c8448192"/>
							<gml:surfaceMember xlink:href="#poly-1b3b53b4-c80e-4f38-a568-be9f7a8729bb"/>
							<gml:surfaceMember xlink:href="#poly-fcd36789-fea8-4fb2-9d2f-67d931a2a8a0"/>
							<gml:surfaceMember xlink:href="#poly-252d8f46-8ff2-49ba-817c-873155188865"/>
							<gml:surfaceMember xlink:href="#poly-1e396fc0-3a99-4d9c-ae02-79fca64065ee"/>
							<gml:surfaceMember xlink:href="#poly-fda21ea4-4ccf-4197-8184-ebd61c808266"/>
							<gml:surfaceMember xlink:href="#poly-56fc46e0-4882-4b37-a75a-952e2c1c2fd2"/>
							<gml:surfaceMember xlink:href="#poly-64ecb37f-01a6-4f97-8c5d-be6ad1dac7b4"/>
							<gml:surfaceMember xlink:href="#poly-6a33038c-1f7e-4794-8ef4-2ab21ab19ee8"/>
							<gml:surfaceMember xlink:href="#poly-249c8c34-b93a-4d04-8197-75657d647ac7"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_345f1a5e-ffe7-4ca3-9133-bd37b3ffb271_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f3418fc5-c5ef-47bb-80fe-1f9d14118324">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670628525462824 139.73809047309481 38.758 35.67063291440694 139.738112328497 38.758 35.67061512553927 139.73811768498257 38.758 35.670610736604864 139.7380958406312 38.758 35.670628525462824 139.73809047309481 38.758</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6a5338a6-abf3-4dc8-a33a-b6f8c5fdc55b">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67056823007545 139.7381556515247 44.335 35.67056468286487 139.7381381584207 44.335 35.67057951588787 139.7381336339243 44.335 35.67058307211281 139.73815112702061 44.335 35.67056823007545 139.7381556515247 44.335</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6fd609ee-d5c0-4c40-abf3-b218927b3091">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6fd609ee-d5c0-4c40-abf3-b218927b3091_0">
											<gml:posList>35.670628525462824 139.73809047309481 38.758 35.670610736604864 139.7380958406312 38.758 35.670610736604864 139.7380958406312 40.712 35.670628525462824 139.73809047309481 40.712 35.670628525462824 139.73809047309481 38.758</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8b8ef9c7-66e4-4f43-838f-e89fcedb9fae">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8b8ef9c7-66e4-4f43-838f-e89fcedb9fae_0">
											<gml:posList>35.67063291440694 139.738112328497 38.758 35.670628525462824 139.73809047309481 38.758 35.670628525462824 139.73809047309481 40.712 35.67063291440694 139.738112328497 40.712 35.67063291440694 139.738112328497 38.758</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bd4e762f-53a6-48dd-b659-936dff1881df">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bd4e762f-53a6-48dd-b659-936dff1881df_0">
											<gml:posList>35.670628525462824 139.73809047309481 40.712 35.670610736604864 139.7380958406312 40.712 35.67061512553927 139.73811768498257 40.712 35.67063291440694 139.738112328497 40.712 35.670628525462824 139.73809047309481 40.712</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8130d9e1-af45-4ed6-9e38-835b792af086">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8130d9e1-af45-4ed6-9e38-835b792af086_0">
											<gml:posList>35.670610736604864 139.7380958406312 38.758 35.67061512553927 139.73811768498257 38.758 35.67061512553927 139.73811768498257 40.712 35.670610736604864 139.7380958406312 40.712 35.670610736604864 139.7380958406312 38.758</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d339f475-775e-4e5e-8e58-6900b9fdf9b4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d339f475-775e-4e5e-8e58-6900b9fdf9b4_0">
											<gml:posList>35.67061512553927 139.73811768498257 38.758 35.67063291440694 139.738112328497 38.758 35.67063291440694 139.738112328497 40.712 35.67061512553927 139.73811768498257 40.712 35.67061512553927 139.73811768498257 38.758</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b7a4c9a2-c895-4b2e-98db-38b76f8913ee">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b7a4c9a2-c895-4b2e-98db-38b76f8913ee_0">
											<gml:posList>35.67057951588787 139.7381336339243 44.335 35.67056468286487 139.7381381584207 44.335 35.67056468286487 139.7381381584207 44.685 35.67057951588787 139.7381336339243 44.685 35.67057951588787 139.7381336339243 44.335</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-45311f02-0daa-420b-8e45-30c0f1622b98">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-45311f02-0daa-420b-8e45-30c0f1622b98_0">
											<gml:posList>35.67058307211281 139.73815112702061 44.335 35.67057951588787 139.7381336339243 44.335 35.67057951588787 139.7381336339243 44.685 35.67058307211281 139.73815112702061 44.685 35.67058307211281 139.73815112702061 44.335</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d2ba71dc-ff3f-43b3-b605-25d13ea0d1c4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d2ba71dc-ff3f-43b3-b605-25d13ea0d1c4_0">
											<gml:posList>35.67056823007545 139.7381556515247 44.685 35.67058307211281 139.73815112702061 44.685 35.67057951588787 139.7381336339243 44.685 35.67056468286487 139.7381381584207 44.685 35.67056823007545 139.7381556515247 44.685</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-621fe5b8-8aba-42eb-ba36-1260aab8beed">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-621fe5b8-8aba-42eb-ba36-1260aab8beed_0">
											<gml:posList>35.67056823007545 139.7381556515247 44.335 35.67056823007545 139.7381556515247 44.685 35.67056468286487 139.7381381584207 44.685 35.67056468286487 139.7381381584207 44.335 35.67056823007545 139.7381556515247 44.335</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4b4913b4-c012-4f7c-b4e0-a7c15364e971">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4b4913b4-c012-4f7c-b4e0-a7c15364e971_0">
											<gml:posList>35.67056823007545 139.7381556515247 44.335 35.67058307211281 139.73815112702061 44.335 35.67058307211281 139.73815112702061 44.685 35.67056823007545 139.7381556515247 44.685 35.67056823007545 139.7381556515247 44.335</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_345f1a5e-ffe7-4ca3-9133-bd37b3ffb271_BuildingInstallation_1060">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-69e435e0-4314-4c4f-9af0-ceb5af3793b0">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67058176632521 139.73808425434945 17.354 35.67058833190153 139.7381115750658 17.354 35.670550789759524 139.7381230304626 17.354 35.670545170347005 139.73809535515312 17.354 35.67058176632521 139.73808425434945 17.354</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d34f2f5e-0829-43e7-bb16-31cbcea7c03f">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67060051586856 139.7381196906647 38.758 35.670607049232686 139.73815188284271 38.758 35.6705976231499 139.73815476606802 38.758 35.67059108077283 139.73812257390423 38.758 35.67060051586856 139.7381196906647 38.758</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7474c5e4-3668-4f87-82b0-7f02f95fca51">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7474c5e4-3668-4f87-82b0-7f02f95fca51_0">
											<gml:posList>35.670545170347005 139.73809535515312 17.354 35.670550789759524 139.7381230304626 17.354 35.670550789759524 139.7381230304626 39.246 35.670545170347005 139.73809535515312 39.246 35.670545170347005 139.73809535515312 17.354</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7647e3c8-c3d9-4a29-b1a0-a48865e5afbf">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7647e3c8-c3d9-4a29-b1a0-a48865e5afbf_0">
											<gml:posList>35.67058176632521 139.73808425434945 17.354 35.670545170347005 139.73809535515312 17.354 35.670545170347005 139.73809535515312 39.246 35.67058176632521 139.73808425434945 39.246 35.67058176632521 139.73808425434945 17.354</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3b8d0801-f02d-4030-b2ab-a341ef2c6e0f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3b8d0801-f02d-4030-b2ab-a341ef2c6e0f_0">
											<gml:posList>35.67058176632521 139.73808425434945 39.246 35.670545170347005 139.73809535515312 39.246 35.670550789759524 139.7381230304626 39.246 35.67058833190153 139.7381115750658 39.246 35.67058176632521 139.73808425434945 39.246</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-60bede7a-fa79-4483-9c01-d7a530405217">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-60bede7a-fa79-4483-9c01-d7a530405217_0">
											<gml:posList>35.670550789759524 139.7381230304626 39.246 35.670550789759524 139.7381230304626 17.354 35.67058833190153 139.7381115750658 17.354 35.67058833190153 139.7381115750658 39.246 35.670550789759524 139.7381230304626 39.246</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ef516f35-7918-4e9d-a49f-948339ed5854">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ef516f35-7918-4e9d-a49f-948339ed5854_0">
											<gml:posList>35.67058833190153 139.7381115750658 17.354 35.67058176632521 139.73808425434945 17.354 35.67058176632521 139.73808425434945 39.246 35.67058833190153 139.7381115750658 39.246 35.67058833190153 139.7381115750658 17.354</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-90b8e8bd-f577-400c-b749-51532a7dc653">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-90b8e8bd-f577-400c-b749-51532a7dc653_0">
											<gml:posList>35.6705976231499 139.73815476606802 39.286 35.67059108077283 139.73812257390423 39.286 35.67059108077283 139.73812257390423 38.758 35.6705976231499 139.73815476606802 38.758 35.6705976231499 139.73815476606802 39.286</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7ac7c095-b4a7-4466-8d97-59f7fc4b406e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7ac7c095-b4a7-4466-8d97-59f7fc4b406e_0">
											<gml:posList>35.67059108077283 139.73812257390423 38.758 35.67059108077283 139.73812257390423 39.286 35.67060051586856 139.7381196906647 39.286 35.67060051586856 139.7381196906647 38.758 35.67059108077283 139.73812257390423 38.758</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4590459c-8cab-4fd6-ab48-055b11530a21">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4590459c-8cab-4fd6-ab48-055b11530a21_0">
											<gml:posList>35.67060051586856 139.7381196906647 39.286 35.67059108077283 139.73812257390423 39.286 35.6705976231499 139.73815476606802 39.286 35.670607049232686 139.73815188284271 39.286 35.67060051586856 139.7381196906647 39.286</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d07464c8-7370-42fc-8589-9e94459c29b2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d07464c8-7370-42fc-8589-9e94459c29b2_0">
											<gml:posList>35.6705976231499 139.73815476606802 38.758 35.670607049232686 139.73815188284271 38.758 35.670607049232686 139.73815188284271 39.286 35.6705976231499 139.73815476606802 39.286 35.6705976231499 139.73815476606802 38.758</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-66b897e7-e934-4342-a01c-f1ce5aab8395">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-66b897e7-e934-4342-a01c-f1ce5aab8395_0">
											<gml:posList>35.670607049232686 139.73815188284271 38.758 35.67060051586856 139.7381196906647 38.758 35.67060051586856 139.7381196906647 39.286 35.670607049232686 139.73815188284271 39.286 35.670607049232686 139.73815188284271 38.758</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-0332f0b7-fb65-4485-808a-6c45ecc7e58e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0332f0b7-fb65-4485-808a-6c45ecc7e58e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0332f0b7-fb65-4485-808a-6c45ecc7e58e">
											<gml:posList>35.67055687742392 139.73819575196435 17.354 35.67054828095402 139.73815345490343 17.354 35.67055648151995 139.738151014986 17.354 35.670550789759524 139.7381230304626 17.354 35.67058833190153 139.7381115750658 17.354 35.67058176632521 139.73808425434945 17.354 35.67068809380479 139.73805199434213 17.354 35.67070791152094 139.73815017243658 17.354 35.67055687742392 139.73819575196435 17.354</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-8745b50e-5d8c-4760-a95f-b16b3ffe2dde">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8745b50e-5d8c-4760-a95f-b16b3ffe2dde">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8745b50e-5d8c-4760-a95f-b16b3ffe2dde">
											<gml:posList>35.67063977378377 139.73806665496716 39.246 35.67063690300337 139.73807246872917 39.246 35.67065473928579 139.73816127081167 39.246 35.67065947426601 139.73816477791377 39.246 35.67063977378377 139.73806665496716 39.246</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-900091a5-c6e4-46f6-bf4a-d068b481d2b8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-900091a5-c6e4-46f6-bf4a-d068b481d2b8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-900091a5-c6e4-46f6-bf4a-d068b481d2b8">
											<gml:posList>35.67068809380479 139.73805199434213 31.365 35.67063977378377 139.73806665496716 39.246 35.67065947426601 139.73816477791377 39.246 35.67070791152094 139.73815017243658 31.365 35.67068809380479 139.73805199434213 31.365</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-36a2df70-f2b3-429f-a440-4f7feca0d7be">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-36a2df70-f2b3-429f-a440-4f7feca0d7be">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-36a2df70-f2b3-429f-a440-4f7feca0d7be">
											<gml:posList>35.67058176632521 139.73808425434945 39.246 35.670586681538474 139.73808770599825 39.246 35.67063690300337 139.73807246872917 39.246 35.67063977378377 139.73806665496716 39.246 35.67058176632521 139.73808425434945 39.246</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-4b0002d3-3967-4131-b8b4-f68192ff8caa">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4b0002d3-3967-4131-b8b4-f68192ff8caa">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4b0002d3-3967-4131-b8b4-f68192ff8caa">
											<gml:posList>35.67058833190153 139.7381115750658 39.246 35.67059305722313 139.73811426474822 39.246 35.670586681538474 139.73808770599825 39.246 35.67058176632521 139.73808425434945 39.246 35.67058833190153 139.7381115750658 39.246</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-2c8d726c-9be1-46c0-ad95-7d138f1dfbae">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2c8d726c-9be1-46c0-ad95-7d138f1dfbae">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2c8d726c-9be1-46c0-ad95-7d138f1dfbae">
											<gml:posList>35.67058833190153 139.7381115750658 39.246 35.670550789759524 139.7381230304626 39.246 35.67055537161247 139.73812667029515 39.246 35.67059305722313 139.73811426474822 39.246 35.67058833190153 139.7381115750658 39.246</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-69134154-d2c9-42d2-8043-f3f978f48baf">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-69134154-d2c9-42d2-8043-f3f978f48baf">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-69134154-d2c9-42d2-8043-f3f978f48baf">
											<gml:posList>35.67055537161247 139.73812667029515 39.246 35.670550789759524 139.7381230304626 39.246 35.67055252713668 139.73813155612987 39.246 35.67055614077451 139.73813045825702 39.246 35.67055537161247 139.73812667029515 39.246</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-911ac8ee-c62e-4fe2-9fc3-9afe68fcd627">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-911ac8ee-c62e-4fe2-9fc3-9afe68fcd627">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-911ac8ee-c62e-4fe2-9fc3-9afe68fcd627">
											<gml:posList>35.67055252713668 139.73813155612987 44.794 35.67055665782295 139.7381345889531 44.794 35.67058807211128 139.7381250076604 44.794 35.67059054689318 139.73811995656794 44.794 35.67055252713668 139.73813155612987 44.794</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-1a5696b9-3c9d-47ce-9f12-35918e444d3c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1a5696b9-3c9d-47ce-9f12-35918e444d3c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1a5696b9-3c9d-47ce-9f12-35918e444d3c">
											<gml:posList>35.67059305722313 139.73811426474822 38.758 35.67055537161247 139.73812667029515 38.758 35.67055614077451 139.73813045825702 38.758 35.67059054689318 139.73811995656794 38.758 35.67059801225046 139.73815667661415 38.758 35.67055999249043 139.7381682761598 38.758 35.67055742259679 139.73815563121534 38.758 35.670553033970734 139.73815697302527 38.758 35.67055973920533 139.73818994926953 38.758 35.67065473928579 139.73816127081167 38.758 35.67063690300337 139.73807246872917 38.758 35.670586681538474 139.73808770599825 38.758 35.67059305722313 139.73811426474822 38.758</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-43091cee-3fb5-4600-ab20-bdae10674088">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-43091cee-3fb5-4600-ab20-bdae10674088">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-43091cee-3fb5-4600-ab20-bdae10674088">
											<gml:posList>35.67059054689318 139.73811995656794 44.794 35.67058807211128 139.7381250076604 44.794 35.67059388155604 139.73815363274198 44.794 35.67059801225046 139.73815667661415 44.794 35.67059054689318 139.73811995656794 44.794</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-90e63341-b897-4656-8002-2d1accdb1ad2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-90e63341-b897-4656-8002-2d1accdb1ad2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-90e63341-b897-4656-8002-2d1accdb1ad2">
											<gml:posList>35.67059388155604 139.73815363274198 44.335 35.67058807211128 139.7381250076604 44.335 35.67055665782295 139.7381345889531 44.335 35.67056246726544 139.73816321402415 44.335 35.67059388155604 139.73815363274198 44.335</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-81e70a79-99ec-4df4-8848-48842c485571">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-81e70a79-99ec-4df4-8848-48842c485571">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-81e70a79-99ec-4df4-8848-48842c485571">
											<gml:posList>35.67055999249043 139.7381682761598 44.794 35.67056246726544 139.73816321402415 44.794 35.67055665782295 139.7381345889531 44.794 35.67055252713668 139.73813155612987 44.794 35.67055999249043 139.7381682761598 44.794</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-2d725ef4-b2ec-4758-952f-54ea31822f5d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2d725ef4-b2ec-4758-952f-54ea31822f5d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2d725ef4-b2ec-4758-952f-54ea31822f5d">
											<gml:posList>35.67055648151995 139.738151014986 39.246 35.67054828095402 139.73815345490343 39.246 35.670553033970734 139.73815697302527 39.246 35.67055742259679 139.73815563121534 39.246 35.67055648151995 139.738151014986 39.246</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-3f2789aa-b202-48bb-bc7c-c53843d4c8b5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3f2789aa-b202-48bb-bc7c-c53843d4c8b5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3f2789aa-b202-48bb-bc7c-c53843d4c8b5">
											<gml:posList>35.67059801225046 139.73815667661415 44.794 35.67059388155604 139.73815363274198 44.794 35.67056246726544 139.73816321402415 44.794 35.67055999249043 139.7381682761598 44.794 35.67059801225046 139.73815667661415 44.794</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a94d582f-d483-477e-a399-35df8f598d17">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a94d582f-d483-477e-a399-35df8f598d17">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a94d582f-d483-477e-a399-35df8f598d17">
											<gml:posList>35.67055687742392 139.73819575196435 39.246 35.67055973920533 139.73818994926953 39.246 35.670553033970734 139.73815697302527 39.246 35.67054828095402 139.73815345490343 39.246 35.67055687742392 139.73819575196435 39.246</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-947538c4-2559-4a68-9370-995bc31b028a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-947538c4-2559-4a68-9370-995bc31b028a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-947538c4-2559-4a68-9370-995bc31b028a">
											<gml:posList>35.67065947426601 139.73816477791377 39.246 35.67065473928579 139.73816127081167 39.246 35.67055973920533 139.73818994926953 39.246 35.67055687742392 139.73819575196435 39.246 35.67065947426601 139.73816477791377 39.246</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b4f059a0-3519-4a54-bc5a-e56cfecc2d31">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b4f059a0-3519-4a54-bc5a-e56cfecc2d31">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b4f059a0-3519-4a54-bc5a-e56cfecc2d31">
											<gml:posList>35.670553033970734 139.73815697302527 39.246 35.670553033970734 139.73815697302527 38.758 35.67055742259679 139.73815563121534 38.758 35.67055742259679 139.73815563121534 39.246 35.670553033970734 139.73815697302527 39.246</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f14c190d-ab03-491c-ab96-6ad5901985dd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f14c190d-ab03-491c-ab96-6ad5901985dd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f14c190d-ab03-491c-ab96-6ad5901985dd">
											<gml:posList>35.67055648151995 139.738151014986 17.354 35.67054828095402 139.73815345490343 17.354 35.67054828095402 139.73815345490343 39.246 35.67055648151995 139.738151014986 39.246 35.67055648151995 139.738151014986 17.354</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-86a4602e-730b-415c-a98b-4b09471d789e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-86a4602e-730b-415c-a98b-4b09471d789e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-86a4602e-730b-415c-a98b-4b09471d789e">
											<gml:posList>35.67054828095402 139.73815345490343 17.354 35.67055687742392 139.73819575196435 17.354 35.67055687742392 139.73819575196435 39.246 35.67054828095402 139.73815345490343 39.246 35.67054828095402 139.73815345490343 17.354</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e8e5d83c-1bd2-4a1c-942c-6001b89cdb9c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e8e5d83c-1bd2-4a1c-942c-6001b89cdb9c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e8e5d83c-1bd2-4a1c-942c-6001b89cdb9c">
											<gml:posList>35.67055999249043 139.7381682761598 38.758 35.67055999249043 139.7381682761598 44.794 35.67055252713668 139.73813155612987 44.794 35.67055252713668 139.73813155612987 39.246 35.670550789759524 139.7381230304626 39.246 35.670550789759524 139.7381230304626 17.354 35.67055648151995 139.738151014986 17.354 35.67055648151995 139.738151014986 39.246 35.67055742259679 139.73815563121534 39.246 35.67055742259679 139.73815563121534 38.758 35.67055999249043 139.7381682761598 38.758</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-79fb1392-81a3-4c71-8b0d-d985205fba5d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-79fb1392-81a3-4c71-8b0d-d985205fba5d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-79fb1392-81a3-4c71-8b0d-d985205fba5d">
											<gml:posList>35.67055614077451 139.73813045825702 39.246 35.67055614077451 139.73813045825702 38.758 35.67055537161247 139.73812667029515 38.758 35.67055537161247 139.73812667029515 39.246 35.67055614077451 139.73813045825702 39.246</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-930e3902-2f7f-4361-907c-949a9ee9e5cd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-930e3902-2f7f-4361-907c-949a9ee9e5cd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-930e3902-2f7f-4361-907c-949a9ee9e5cd">
											<gml:posList>35.67055973920533 139.73818994926953 39.246 35.67055973920533 139.73818994926953 38.758 35.670553033970734 139.73815697302527 38.758 35.670553033970734 139.73815697302527 39.246 35.67055973920533 139.73818994926953 39.246</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-10985b20-f9c7-414f-ba31-e81f49a4bae6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-10985b20-f9c7-414f-ba31-e81f49a4bae6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-10985b20-f9c7-414f-ba31-e81f49a4bae6">
											<gml:posList>35.67056246726544 139.73816321402415 44.794 35.67056246726544 139.73816321402415 44.335 35.67055665782295 139.7381345889531 44.335 35.67055665782295 139.7381345889531 44.794 35.67056246726544 139.73816321402415 44.794</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-cece860d-bb09-4ea2-9334-73da1f6ca387">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cece860d-bb09-4ea2-9334-73da1f6ca387">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cece860d-bb09-4ea2-9334-73da1f6ca387">
											<gml:posList>35.67058833190153 139.7381115750658 17.354 35.670550789759524 139.7381230304626 17.354 35.670550789759524 139.7381230304626 39.246 35.67058833190153 139.7381115750658 39.246 35.67058833190153 139.7381115750658 17.354</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c868f209-247a-41f1-9ed7-e90c2d8cffdc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c868f209-247a-41f1-9ed7-e90c2d8cffdc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c868f209-247a-41f1-9ed7-e90c2d8cffdc">
											<gml:posList>35.67055614077451 139.73813045825702 39.246 35.67055252713668 139.73813155612987 39.246 35.67055252713668 139.73813155612987 44.794 35.67059054689318 139.73811995656794 44.794 35.67059054689318 139.73811995656794 38.758 35.67055614077451 139.73813045825702 38.758 35.67055614077451 139.73813045825702 39.246</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3699ab9d-5c8e-4216-889f-34d29bba1e75">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3699ab9d-5c8e-4216-889f-34d29bba1e75">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3699ab9d-5c8e-4216-889f-34d29bba1e75">
											<gml:posList>35.67055665782295 139.7381345889531 44.794 35.67055665782295 139.7381345889531 44.335 35.67058807211128 139.7381250076604 44.335 35.67058807211128 139.7381250076604 44.794 35.67055665782295 139.7381345889531 44.794</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-55b6d072-2251-4457-a06d-7e939cb5cb13">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-55b6d072-2251-4457-a06d-7e939cb5cb13">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-55b6d072-2251-4457-a06d-7e939cb5cb13">
											<gml:posList>35.67055537161247 139.73812667029515 39.246 35.67055537161247 139.73812667029515 38.758 35.67059305722313 139.73811426474822 38.758 35.67059305722313 139.73811426474822 39.246 35.67055537161247 139.73812667029515 39.246</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ff22af20-ccd8-4e5f-ad5b-7950cc943c05">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ff22af20-ccd8-4e5f-ad5b-7950cc943c05">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ff22af20-ccd8-4e5f-ad5b-7950cc943c05">
											<gml:posList>35.67059388155604 139.73815363274198 44.794 35.67059388155604 139.73815363274198 44.335 35.67056246726544 139.73816321402415 44.335 35.67056246726544 139.73816321402415 44.794 35.67059388155604 139.73815363274198 44.794</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-85a7055e-4337-4742-9631-dc2f1374f17d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-85a7055e-4337-4742-9631-dc2f1374f17d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-85a7055e-4337-4742-9631-dc2f1374f17d">
											<gml:posList>35.67055999249043 139.7381682761598 38.758 35.67059801225046 139.73815667661415 38.758 35.67059801225046 139.73815667661415 44.794 35.67055999249043 139.7381682761598 44.794 35.67055999249043 139.7381682761598 38.758</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-cf2d8c60-16fe-406f-9e05-9164c8448192">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cf2d8c60-16fe-406f-9e05-9164c8448192">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cf2d8c60-16fe-406f-9e05-9164c8448192">
											<gml:posList>35.67058176632521 139.73808425434945 17.354 35.67058833190153 139.7381115750658 17.354 35.67058833190153 139.7381115750658 39.246 35.67058176632521 139.73808425434945 39.246 35.67058176632521 139.73808425434945 17.354</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1b3b53b4-c80e-4f38-a568-be9f7a8729bb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1b3b53b4-c80e-4f38-a568-be9f7a8729bb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1b3b53b4-c80e-4f38-a568-be9f7a8729bb">
											<gml:posList>35.67059305722313 139.73811426474822 39.246 35.67059305722313 139.73811426474822 38.758 35.670586681538474 139.73808770599825 38.758 35.670586681538474 139.73808770599825 39.246 35.67059305722313 139.73811426474822 39.246</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-fcd36789-fea8-4fb2-9d2f-67d931a2a8a0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fcd36789-fea8-4fb2-9d2f-67d931a2a8a0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fcd36789-fea8-4fb2-9d2f-67d931a2a8a0">
											<gml:posList>35.67058807211128 139.7381250076604 44.794 35.67058807211128 139.7381250076604 44.335 35.67059388155604 139.73815363274198 44.335 35.67059388155604 139.73815363274198 44.794 35.67058807211128 139.7381250076604 44.794</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-252d8f46-8ff2-49ba-817c-873155188865">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-252d8f46-8ff2-49ba-817c-873155188865">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-252d8f46-8ff2-49ba-817c-873155188865">
											<gml:posList>35.67059054689318 139.73811995656794 44.794 35.67059801225046 139.73815667661415 44.794 35.67059801225046 139.73815667661415 38.758 35.67059054689318 139.73811995656794 38.758 35.67059054689318 139.73811995656794 44.794</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1e396fc0-3a99-4d9c-ae02-79fca64065ee">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1e396fc0-3a99-4d9c-ae02-79fca64065ee">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1e396fc0-3a99-4d9c-ae02-79fca64065ee">
											<gml:posList>35.67065473928579 139.73816127081167 39.246 35.67065473928579 139.73816127081167 38.758 35.67055973920533 139.73818994926953 38.758 35.67055973920533 139.73818994926953 39.246 35.67065473928579 139.73816127081167 39.246</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-fda21ea4-4ccf-4197-8184-ebd61c808266">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fda21ea4-4ccf-4197-8184-ebd61c808266">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fda21ea4-4ccf-4197-8184-ebd61c808266">
											<gml:posList>35.670586681538474 139.73808770599825 39.246 35.670586681538474 139.73808770599825 38.758 35.67063690300337 139.73807246872917 38.758 35.67063690300337 139.73807246872917 39.246 35.670586681538474 139.73808770599825 39.246</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-56fc46e0-4882-4b37-a75a-952e2c1c2fd2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-56fc46e0-4882-4b37-a75a-952e2c1c2fd2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-56fc46e0-4882-4b37-a75a-952e2c1c2fd2">
											<gml:posList>35.67065947426601 139.73816477791377 39.246 35.67055687742392 139.73819575196435 39.246 35.67055687742392 139.73819575196435 17.354 35.67070791152094 139.73815017243658 17.354 35.67070791152094 139.73815017243658 31.365 35.67065947426601 139.73816477791377 39.246</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-64ecb37f-01a6-4f97-8c5d-be6ad1dac7b4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-64ecb37f-01a6-4f97-8c5d-be6ad1dac7b4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-64ecb37f-01a6-4f97-8c5d-be6ad1dac7b4">
											<gml:posList>35.67058176632521 139.73808425434945 39.246 35.67063977378377 139.73806665496716 39.246 35.67068809380479 139.73805199434213 31.365 35.67068809380479 139.73805199434213 17.354 35.67058176632521 139.73808425434945 17.354 35.67058176632521 139.73808425434945 39.246</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6a33038c-1f7e-4794-8ef4-2ab21ab19ee8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6a33038c-1f7e-4794-8ef4-2ab21ab19ee8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6a33038c-1f7e-4794-8ef4-2ab21ab19ee8">
											<gml:posList>35.67063690300337 139.73807246872917 39.246 35.67063690300337 139.73807246872917 38.758 35.67065473928579 139.73816127081167 38.758 35.67065473928579 139.73816127081167 39.246 35.67063690300337 139.73807246872917 39.246</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-249c8c34-b93a-4d04-8197-75657d647ac7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-249c8c34-b93a-4d04-8197-75657d647ac7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-249c8c34-b93a-4d04-8197-75657d647ac7">
											<gml:posList>35.67070791152094 139.73815017243658 17.354 35.67068809380479 139.73805199434213 17.354 35.67068809380479 139.73805199434213 31.365 35.67070791152094 139.73815017243658 31.365 35.67070791152094 139.73815017243658 17.354</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-6530</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">152.87514</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1210</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>4</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>