<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_34954c13-f794-4797-9fb5-6301ecdcdb2e">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">412</bldg:usage>
			<bldg:measuredHeight uom="m">17.9</bldg:measuredHeight>
			<bldg:storeysAboveGround>4</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>1</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.67131576359139 139.73833558244206 0 35.671175005081345 139.73838114979947 0 35.67118667510351 139.7384348213384 0 35.67119829984351 139.73843105181246 0 35.67121919802682 139.73852812471034 0 35.671348241713304 139.73848632721837 0 35.67131576359139 139.73833558244206 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67131576359139 139.73833558244206 15.2 35.671348241713304 139.73848632721837 15.2 35.67121919802682 139.73852812471034 15.2 35.67119829984351 139.73843105181246 15.2 35.67118667510351 139.7384348213384 15.2 35.671175005081345 139.73838114979947 15.2 35.67131576359139 139.73833558244206 15.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67131576359139 139.73833558244206 15.2 35.671175005081345 139.73838114979947 15.2 35.671175005081345 139.73838114979947 33.14 35.67131576359139 139.73833558244206 33.14 35.67131576359139 139.73833558244206 15.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671175005081345 139.73838114979947 15.2 35.67118667510351 139.7384348213384 15.2 35.67118667510351 139.7384348213384 33.14 35.671175005081345 139.73838114979947 33.14 35.671175005081345 139.73838114979947 15.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67118667510351 139.7384348213384 15.2 35.67119829984351 139.73843105181246 15.2 35.67119829984351 139.73843105181246 33.14 35.67118667510351 139.7384348213384 33.14 35.67118667510351 139.7384348213384 15.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67119829984351 139.73843105181246 15.2 35.67121919802682 139.73852812471034 15.2 35.67121919802682 139.73852812471034 33.14 35.67119829984351 139.73843105181246 33.14 35.67119829984351 139.73843105181246 15.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67121919802682 139.73852812471034 15.2 35.671348241713304 139.73848632721837 15.2 35.671348241713304 139.73848632721837 33.14 35.67121919802682 139.73852812471034 33.14 35.67121919802682 139.73852812471034 15.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671348241713304 139.73848632721837 15.2 35.67131576359139 139.73833558244206 15.2 35.67131576359139 139.73833558244206 33.14 35.671348241713304 139.73848632721837 33.14 35.671348241713304 139.73848632721837 15.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67131576359139 139.73833558244206 33.14 35.671175005081345 139.73838114979947 33.14 35.67118667510351 139.7384348213384 33.14 35.67119829984351 139.73843105181246 33.14 35.67121919802682 139.73852812471034 33.14 35.671348241713304 139.73848632721837 33.14 35.67131576359139 139.73833558244206 33.14</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-5573db66-c22e-4999-bc10-7e5070043577"/>
							<gml:surfaceMember xlink:href="#poly-a153e3b2-cbf5-460e-b413-bfe97bbb327d"/>
							<gml:surfaceMember xlink:href="#poly-61b53d53-b663-42c8-b4da-07ff166d6635"/>
							<gml:surfaceMember xlink:href="#poly-4095a0a3-9574-483d-ad2f-d1a4ae556605"/>
							<gml:surfaceMember xlink:href="#poly-94479e2d-4e24-442a-9226-fd10fffa2da2"/>
							<gml:surfaceMember xlink:href="#poly-c4a06f7a-544f-4311-87ce-aee972b4ed06"/>
							<gml:surfaceMember xlink:href="#poly-6415da06-1451-4e9a-a50d-451ac110d4ee"/>
							<gml:surfaceMember xlink:href="#poly-c53e4a86-fec6-4804-a5e5-692fce1da668"/>
							<gml:surfaceMember xlink:href="#poly-e05b36b9-d4a6-4e40-9d2a-ee129bcb3b95"/>
							<gml:surfaceMember xlink:href="#poly-cd01e373-7259-4d7e-8dc8-deb59ea5173a"/>
							<gml:surfaceMember xlink:href="#poly-e46b7169-b50a-403e-b885-5f6af82a2a0a"/>
							<gml:surfaceMember xlink:href="#poly-cf54e89e-5daf-4ce4-8ae2-dee7922f9fa3"/>
							<gml:surfaceMember xlink:href="#poly-2794fef2-999d-4a1c-ae91-fe5c43063134"/>
							<gml:surfaceMember xlink:href="#poly-991c029e-0e73-4ba3-af39-d98edb2b0d5f"/>
							<gml:surfaceMember xlink:href="#poly-a7b0fe34-2ab9-4056-92cb-c43498fc72ba"/>
							<gml:surfaceMember xlink:href="#poly-df4cfd35-9c35-4584-8a8f-81ecac765bea"/>
							<gml:surfaceMember xlink:href="#poly-ffc6e053-31a4-44b5-b9df-ad60b1188761"/>
							<gml:surfaceMember xlink:href="#poly-97ef06f8-cc83-420c-aa28-707c18eea866"/>
							<gml:surfaceMember xlink:href="#poly-91c8c096-5d3c-4893-81bf-8cfcd1a86879"/>
							<gml:surfaceMember xlink:href="#poly-f8efa6d9-55b3-4b06-98a1-3044a598ed58"/>
							<gml:surfaceMember xlink:href="#poly-4df18a74-d46d-4f46-89d2-55ec0f2092d4"/>
							<gml:surfaceMember xlink:href="#poly-3ffda10b-3eee-4a34-b198-3171cf4c8d77"/>
							<gml:surfaceMember xlink:href="#poly-8c3451e3-91e0-4a67-8c64-27f97aeffebb"/>
							<gml:surfaceMember xlink:href="#poly-1ebed2e3-d2cb-4647-816f-de1c5f900be2"/>
							<gml:surfaceMember xlink:href="#poly-4152ecec-10c9-4d84-946f-69a04cd8ac8a"/>
							<gml:surfaceMember xlink:href="#poly-f08d32a3-dcd1-48b3-914a-7518452b664b"/>
							<gml:surfaceMember xlink:href="#poly-f223289d-1026-48f1-8f7c-ad23f04d195a"/>
							<gml:surfaceMember xlink:href="#poly-195d0646-5da7-4f1c-9fe2-49bf01a86bf9"/>
							<gml:surfaceMember xlink:href="#poly-bcdb9765-06f2-4a83-bca9-361176a5a9ce"/>
							<gml:surfaceMember xlink:href="#poly-7643e294-b2c0-486e-8b75-071f315c097c"/>
							<gml:surfaceMember xlink:href="#poly-b86d6b9b-184a-4368-85f5-8f5283f88446"/>
							<gml:surfaceMember xlink:href="#poly-b2581d06-2133-424a-88b6-56a5210470e4"/>
							<gml:surfaceMember xlink:href="#poly-3be0e75a-9398-434b-a225-da1116b5e4f6"/>
							<gml:surfaceMember xlink:href="#poly-cdd5ad88-25c4-4b1a-9493-58bf71d94864"/>
							<gml:surfaceMember xlink:href="#poly-98dc9a14-2f9f-416a-b5d4-d5c4300689af"/>
							<gml:surfaceMember xlink:href="#poly-a91762fc-65b0-4ae4-975a-071096393aa0"/>
							<gml:surfaceMember xlink:href="#poly-f30a8d66-d9ad-44ce-b8d3-42cc90502201"/>
							<gml:surfaceMember xlink:href="#poly-8d8b7b77-b4c3-4ead-9e5b-8d34b8c7051a"/>
							<gml:surfaceMember xlink:href="#poly-79b72764-347c-486a-8d49-2512401bbe92"/>
							<gml:surfaceMember xlink:href="#poly-173a1042-8d33-4f6d-8e31-4a54ca65562e"/>
							<gml:surfaceMember xlink:href="#poly-25aef6ba-fba6-43c4-92fe-19b42305927f"/>
							<gml:surfaceMember xlink:href="#poly-7201d83c-ea58-46fd-ad1b-7e692c586041"/>
							<gml:surfaceMember xlink:href="#poly-7f5a7fa7-7748-4d54-926e-337bc461e2d6"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_34954c13-f794-4797-9fb5-6301ecdcdb2e_BuildingInstallation_1041">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f478d31e-b9e9-4203-8e81-51f2b3d348c0">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67118361754007 139.7383866627846 33.165 35.67122845798595 139.7383716087039 33.165 35.6712362281826 139.73840636244958 33.165 35.6711913787187 139.738421416523 33.165 35.67118361754007 139.7383866627846 33.165</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-91c11f2a-a814-4d07-a619-a5124f26ad96">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-91c11f2a-a814-4d07-a619-a5124f26ad96_0">
											<gml:posList>35.67118361754007 139.7383866627846 36.508 35.67122845798595 139.7383716087039 36.508 35.67122845798595 139.7383716087039 33.165 35.67118361754007 139.7383866627846 33.165 35.67118361754007 139.7383866627846 36.508</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f5ee8547-3655-4d31-8aac-ede441bc9fea">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f5ee8547-3655-4d31-8aac-ede441bc9fea_0">
											<gml:posList>35.67122845798595 139.7383716087039 36.508 35.6712362281826 139.73840636244958 36.508 35.6712362281826 139.73840636244958 33.165 35.67122845798595 139.7383716087039 33.165 35.67122845798595 139.7383716087039 36.508</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-02fdb45d-8371-4e58-8ea0-c2a32ef56c5e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-02fdb45d-8371-4e58-8ea0-c2a32ef56c5e_0">
											<gml:posList>35.67122845798595 139.7383716087039 36.508 35.67118361754007 139.7383866627846 36.508 35.6711913787187 139.738421416523 36.508 35.6712362281826 139.73840636244958 36.508 35.67122845798595 139.7383716087039 36.508</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ae07f82a-2bba-4c52-8dcc-efc424347025">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ae07f82a-2bba-4c52-8dcc-efc424347025_0">
											<gml:posList>35.6711913787187 139.738421416523 36.508 35.67118361754007 139.7383866627846 36.508 35.67118361754007 139.7383866627846 33.165 35.6711913787187 139.738421416523 33.165 35.6711913787187 139.738421416523 36.508</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9fe38ab5-22ed-48d3-8ec6-c21bd0cd5391">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9fe38ab5-22ed-48d3-8ec6-c21bd0cd5391_0">
											<gml:posList>35.6712362281826 139.73840636244958 36.508 35.6711913787187 139.738421416523 36.508 35.6711913787187 139.738421416523 33.165 35.6712362281826 139.73840636244958 33.165 35.6712362281826 139.73840636244958 36.508</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-5573db66-c22e-4999-bc10-7e5070043577">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5573db66-c22e-4999-bc10-7e5070043577">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5573db66-c22e-4999-bc10-7e5070043577">
											<gml:posList>35.67131576359136 139.73833558244206 15.2 35.67134824171328 139.73848632721834 15.2 35.67121919802682 139.7385281247103 15.2 35.67119829984352 139.73843105181246 15.2 35.67118667510351 139.7384348213384 15.2 35.671175005081324 139.73838114979944 15.2 35.67131576359136 139.73833558244206 15.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a153e3b2-cbf5-460e-b413-bfe97bbb327d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a153e3b2-cbf5-460e-b413-bfe97bbb327d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a153e3b2-cbf5-460e-b413-bfe97bbb327d">
											<gml:posList>35.67118667510351 139.7384348213384 33.583 35.67118894280891 139.7384300576685 33.583 35.67117891924 139.73838393989527 33.583 35.671175005081324 139.73838114979944 33.583 35.67118667510351 139.7384348213384 33.583</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-61b53d53-b663-42c8-b4da-07ff166d6635">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-61b53d53-b663-42c8-b4da-07ff166d6635">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-61b53d53-b663-42c8-b4da-07ff166d6635">
											<gml:posList>35.67119829984352 139.73843105181246 33.583 35.67120057656248 139.73842628813108 33.583 35.67118894280891 139.7384300576685 33.583 35.67118667510351 139.7384348213384 33.583 35.67119829984352 139.73843105181246 33.583</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-4095a0a3-9574-483d-ad2f-d1a4ae556605">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4095a0a3-9574-483d-ad2f-d1a4ae556605">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4095a0a3-9574-483d-ad2f-d1a4ae556605">
											<gml:posList>35.67117891924 139.73838393989527 33.165 35.67118894280891 139.7384300576685 33.165 35.67120057656248 139.73842628813108 33.165 35.67122147474091 139.7385233499841 33.165 35.671220241219785 139.73846785445485 33.165 35.67120946787219 139.73841963873554 33.165 35.67117891924 139.73838393989527 33.165</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-94479e2d-4e24-442a-9226-fd10fffa2da2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-94479e2d-4e24-442a-9226-fd10fffa2da2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-94479e2d-4e24-442a-9226-fd10fffa2da2">
											<gml:posList>35.67119829984352 139.73843105181246 33.583 35.67121919802682 139.7385281247103 33.583 35.67122147474091 139.7385233499841 33.583 35.67120057656248 139.73842628813108 33.583 35.67119829984352 139.73843105181246 33.583</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c4a06f7a-544f-4311-87ce-aee972b4ed06">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c4a06f7a-544f-4311-87ce-aee972b4ed06">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c4a06f7a-544f-4311-87ce-aee972b4ed06">
											<gml:posList>35.67120946787219 139.73841963873554 36.276 35.67121132573484 139.73842095105462 36.276 35.6712180121482 139.73841870072508 36.276 35.671219064951124 139.73841641287913 36.276 35.67120946787219 139.73841963873554 36.276</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-6415da06-1451-4e9a-a50d-451ac110d4ee">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6415da06-1451-4e9a-a50d-451ac110d4ee">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6415da06-1451-4e9a-a50d-451ac110d4ee">
											<gml:posList>35.671220241219785 139.73846785445485 36.276 35.67122130304605 139.7384655776452 36.276 35.67121132573484 139.73842095105462 36.276 35.67120946787219 139.73841963873554 36.276 35.671220241219785 139.73846785445485 36.276</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c53e4a86-fec6-4804-a5e5-692fce1da668">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c53e4a86-fec6-4804-a5e5-692fce1da668">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c53e4a86-fec6-4804-a5e5-692fce1da668">
											<gml:posList>35.671220114234636 139.7384210952999 36.276 35.671219064951124 139.73841641287913 36.276 35.6712180121482 139.73841870072508 36.276 35.671219061431636 139.7384233831458 36.276 35.671220114234636 139.7384210952999 36.276</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e05b36b9-d4a6-4e40-9d2a-ee129bcb3b95">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e05b36b9-d4a6-4e40-9d2a-ee129bcb3b95">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e05b36b9-d4a6-4e40-9d2a-ee129bcb3b95">
											<gml:posList>35.671220114234636 139.7384210952999 36.276 35.671219061431636 139.7384233831458 36.276 35.671227487031686 139.73842054529948 36.276 35.67122855786208 139.73841825743196 36.276 35.671220114234636 139.7384210952999 36.276</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-cd01e373-7259-4d7e-8dc8-deb59ea5173a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cd01e373-7259-4d7e-8dc8-deb59ea5173a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cd01e373-7259-4d7e-8dc8-deb59ea5173a">
											<gml:posList>35.67122130304605 139.7384655776452 35.948 35.671236424083666 139.73846050051233 35.948 35.671227487031686 139.73842054529948 35.948 35.671219061431636 139.7384233831458 35.948 35.6712180121482 139.73841870072508 35.948 35.67121132573484 139.73842095105462 35.948 35.67122130304605 139.7384655776452 35.948</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e46b7169-b50a-403e-b885-5f6af82a2a0a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e46b7169-b50a-403e-b885-5f6af82a2a0a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e46b7169-b50a-403e-b885-5f6af82a2a0a">
											<gml:posList>35.671175005081324 139.73838114979944 33.583 35.67117891924 139.73838393989527 33.583 35.67127177299348 139.73835387214254 33.583 35.671274040678185 139.73834908637255 33.583 35.671175005081324 139.73838114979944 33.583</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-cf54e89e-5daf-4ce4-8ae2-dee7922f9fa3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cf54e89e-5daf-4ce4-8ae2-dee7922f9fa3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cf54e89e-5daf-4ce4-8ae2-dee7922f9fa3">
											<gml:posList>35.67122855786208 139.73841825743196 33.165 35.67127177299348 139.73835387214254 33.165 35.67117891924 139.73838393989527 33.165 35.67120946787219 139.73841963873554 33.165 35.671219064951124 139.73841641287913 33.165 35.671220114234636 139.7384210952999 33.165 35.67122855786208 139.73841825743196 33.165</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-2794fef2-999d-4a1c-ae91-fe5c43063134">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2794fef2-999d-4a1c-ae91-fe5c43063134">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2794fef2-999d-4a1c-ae91-fe5c43063134">
											<gml:posList>35.671238290950896 139.73846180177577 36.276 35.671236424083666 139.73846050051233 36.276 35.67122130304605 139.7384655776452 36.276 35.671220241219785 139.73846785445485 36.276 35.671238290950896 139.73846180177577 36.276</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-991c029e-0e73-4ba3-af39-d98edb2b0d5f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-991c029e-0e73-4ba3-af39-d98edb2b0d5f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-991c029e-0e73-4ba3-af39-d98edb2b0d5f">
											<gml:posList>35.67122855786208 139.73841825743196 36.276 35.671227487031686 139.73842054529948 36.276 35.671236424083666 139.73846050051233 36.276 35.671238290950896 139.73846180177577 36.276 35.67122855786208 139.73841825743196 36.276</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a7b0fe34-2ab9-4056-92cb-c43498fc72ba">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a7b0fe34-2ab9-4056-92cb-c43498fc72ba">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a7b0fe34-2ab9-4056-92cb-c43498fc72ba">
											<gml:posList>35.671238290950896 139.73846180177577 33.165 35.671220241219785 139.73846785445485 33.165 35.67122147474091 139.7385233499841 33.165 35.67130239765983 139.73849748307026 33.165 35.671238290950896 139.73846180177577 33.165</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-df4cfd35-9c35-4584-8a8f-81ecac765bea">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-df4cfd35-9c35-4584-8a8f-81ecac765bea">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-df4cfd35-9c35-4584-8a8f-81ecac765bea">
											<gml:posList>35.671306536819465 139.738499842101 33.583 35.67130239765983 139.73849748307026 33.583 35.67122147474091 139.7385233499841 33.583 35.67121919802682 139.7385281247103 33.583 35.671306536819465 139.738499842101 33.583</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ffc6e053-31a4-44b5-b9df-ad60b1188761">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ffc6e053-31a4-44b5-b9df-ad60b1188761">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ffc6e053-31a4-44b5-b9df-ad60b1188761">
											<gml:posList>35.671238290950896 139.73846180177577 33.165 35.67130239765983 139.73849748307026 33.165 35.67127177299348 139.73835387214254 33.165 35.67122855786208 139.73841825743196 33.165 35.671238290950896 139.73846180177577 33.165</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-97ef06f8-cc83-420c-aa28-707c18eea866">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-97ef06f8-cc83-420c-aa28-707c18eea866">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-97ef06f8-cc83-420c-aa28-707c18eea866">
											<gml:posList>35.671274040678185 139.73834908637255 33.583 35.67127177299348 139.73835387214254 33.583 35.67130239765983 139.73849748307026 33.583 35.671306536819465 139.738499842101 33.583 35.671274040678185 139.73834908637255 33.583</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-91c8c096-5d3c-4893-81bf-8cfcd1a86879">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-91c8c096-5d3c-4893-81bf-8cfcd1a86879">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-91c8c096-5d3c-4893-81bf-8cfcd1a86879">
											<gml:posList>35.67131576359136 139.73833558244206 26.069 35.671274040678185 139.73834908637255 33.583 35.671306536819465 139.738499842101 33.583 35.67134824171328 139.73848632721834 26.069 35.67131576359136 139.73833558244206 26.069</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f8efa6d9-55b3-4b06-98a1-3044a598ed58">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f8efa6d9-55b3-4b06-98a1-3044a598ed58">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f8efa6d9-55b3-4b06-98a1-3044a598ed58">
											<gml:posList>35.6712180121482 139.73841870072508 36.276 35.6712180121482 139.73841870072508 35.948 35.671219061431636 139.7384233831458 35.948 35.671219061431636 139.7384233831458 36.276 35.6712180121482 139.73841870072508 36.276</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4df18a74-d46d-4f46-89d2-55ec0f2092d4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4df18a74-d46d-4f46-89d2-55ec0f2092d4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4df18a74-d46d-4f46-89d2-55ec0f2092d4">
											<gml:posList>35.671175005081324 139.73838114979944 15.2 35.67118667510351 139.7384348213384 15.2 35.67118667510351 139.7384348213384 33.583 35.671175005081324 139.73838114979944 33.583 35.671175005081324 139.73838114979944 15.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3ffda10b-3eee-4a34-b198-3171cf4c8d77">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3ffda10b-3eee-4a34-b198-3171cf4c8d77">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3ffda10b-3eee-4a34-b198-3171cf4c8d77">
											<gml:posList>35.67118894280891 139.7384300576685 33.583 35.67118894280891 139.7384300576685 33.165 35.67117891924 139.73838393989527 33.165 35.67117891924 139.73838393989527 33.583 35.67118894280891 139.7384300576685 33.583</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8c3451e3-91e0-4a67-8c64-27f97aeffebb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8c3451e3-91e0-4a67-8c64-27f97aeffebb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8c3451e3-91e0-4a67-8c64-27f97aeffebb">
											<gml:posList>35.67118667510351 139.7384348213384 15.2 35.67119829984352 139.73843105181246 15.2 35.67119829984352 139.73843105181246 33.583 35.67118667510351 139.7384348213384 33.583 35.67118667510351 139.7384348213384 15.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1ebed2e3-d2cb-4647-816f-de1c5f900be2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1ebed2e3-d2cb-4647-816f-de1c5f900be2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1ebed2e3-d2cb-4647-816f-de1c5f900be2">
											<gml:posList>35.67120057656248 139.73842628813108 33.583 35.67120057656248 139.73842628813108 33.165 35.67118894280891 139.7384300576685 33.165 35.67118894280891 139.7384300576685 33.583 35.67120057656248 139.73842628813108 33.583</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4152ecec-10c9-4d84-946f-69a04cd8ac8a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4152ecec-10c9-4d84-946f-69a04cd8ac8a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4152ecec-10c9-4d84-946f-69a04cd8ac8a">
											<gml:posList>35.67119829984352 139.73843105181246 15.2 35.67121919802682 139.7385281247103 15.2 35.67121919802682 139.7385281247103 33.583 35.67119829984352 139.73843105181246 33.583 35.67119829984352 139.73843105181246 15.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f08d32a3-dcd1-48b3-914a-7518452b664b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f08d32a3-dcd1-48b3-914a-7518452b664b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f08d32a3-dcd1-48b3-914a-7518452b664b">
											<gml:posList>35.67122147474091 139.7385233499841 33.583 35.67122147474091 139.7385233499841 33.165 35.67120057656248 139.73842628813108 33.165 35.67120057656248 139.73842628813108 33.583 35.67122147474091 139.7385233499841 33.583</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f223289d-1026-48f1-8f7c-ad23f04d195a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f223289d-1026-48f1-8f7c-ad23f04d195a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f223289d-1026-48f1-8f7c-ad23f04d195a">
											<gml:posList>35.67120946787219 139.73841963873554 36.276 35.671219064951124 139.73841641287913 36.276 35.671219064951124 139.73841641287913 33.165 35.67120946787219 139.73841963873554 33.165 35.67120946787219 139.73841963873554 36.276</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-195d0646-5da7-4f1c-9fe2-49bf01a86bf9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-195d0646-5da7-4f1c-9fe2-49bf01a86bf9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-195d0646-5da7-4f1c-9fe2-49bf01a86bf9">
											<gml:posList>35.67121132573484 139.73842095105462 36.276 35.67121132573484 139.73842095105462 35.948 35.6712180121482 139.73841870072508 35.948 35.6712180121482 139.73841870072508 36.276 35.67121132573484 139.73842095105462 36.276</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-bcdb9765-06f2-4a83-bca9-361176a5a9ce">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bcdb9765-06f2-4a83-bca9-361176a5a9ce">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bcdb9765-06f2-4a83-bca9-361176a5a9ce">
											<gml:posList>35.67120946787219 139.73841963873554 33.165 35.671220241219785 139.73846785445485 33.165 35.671220241219785 139.73846785445485 36.276 35.67120946787219 139.73841963873554 36.276 35.67120946787219 139.73841963873554 33.165</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7643e294-b2c0-486e-8b75-071f315c097c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7643e294-b2c0-486e-8b75-071f315c097c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7643e294-b2c0-486e-8b75-071f315c097c">
											<gml:posList>35.67122130304605 139.7384655776452 36.276 35.67122130304605 139.7384655776452 35.948 35.67121132573484 139.73842095105462 35.948 35.67121132573484 139.73842095105462 36.276 35.67122130304605 139.7384655776452 36.276</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b86d6b9b-184a-4368-85f5-8f5283f88446">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b86d6b9b-184a-4368-85f5-8f5283f88446">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b86d6b9b-184a-4368-85f5-8f5283f88446">
											<gml:posList>35.671219064951124 139.73841641287913 36.276 35.671220114234636 139.7384210952999 36.276 35.671220114234636 139.7384210952999 33.165 35.671219064951124 139.73841641287913 33.165 35.671219064951124 139.73841641287913 36.276</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b2581d06-2133-424a-88b6-56a5210470e4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b2581d06-2133-424a-88b6-56a5210470e4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b2581d06-2133-424a-88b6-56a5210470e4">
											<gml:posList>35.671219061431636 139.7384233831458 36.276 35.671219061431636 139.7384233831458 35.948 35.671227487031686 139.73842054529948 35.948 35.671227487031686 139.73842054529948 36.276 35.671219061431636 139.7384233831458 36.276</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3be0e75a-9398-434b-a225-da1116b5e4f6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3be0e75a-9398-434b-a225-da1116b5e4f6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3be0e75a-9398-434b-a225-da1116b5e4f6">
											<gml:posList>35.671220114234636 139.7384210952999 36.276 35.67122855786208 139.73841825743196 36.276 35.67122855786208 139.73841825743196 33.165 35.671220114234636 139.7384210952999 33.165 35.671220114234636 139.7384210952999 36.276</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-cdd5ad88-25c4-4b1a-9493-58bf71d94864">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cdd5ad88-25c4-4b1a-9493-58bf71d94864">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cdd5ad88-25c4-4b1a-9493-58bf71d94864">
											<gml:posList>35.67117891924 139.73838393989527 33.583 35.67117891924 139.73838393989527 33.165 35.67127177299348 139.73835387214254 33.165 35.67127177299348 139.73835387214254 33.583 35.67117891924 139.73838393989527 33.583</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-98dc9a14-2f9f-416a-b5d4-d5c4300689af">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-98dc9a14-2f9f-416a-b5d4-d5c4300689af">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-98dc9a14-2f9f-416a-b5d4-d5c4300689af">
											<gml:posList>35.671236424083666 139.73846050051233 36.276 35.671236424083666 139.73846050051233 35.948 35.67122130304605 139.7384655776452 35.948 35.67122130304605 139.7384655776452 36.276 35.671236424083666 139.73846050051233 36.276</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a91762fc-65b0-4ae4-975a-071096393aa0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a91762fc-65b0-4ae4-975a-071096393aa0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a91762fc-65b0-4ae4-975a-071096393aa0">
											<gml:posList>35.671220241219785 139.73846785445485 33.165 35.671238290950896 139.73846180177577 33.165 35.671238290950896 139.73846180177577 36.276 35.671220241219785 139.73846785445485 36.276 35.671220241219785 139.73846785445485 33.165</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f30a8d66-d9ad-44ce-b8d3-42cc90502201">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f30a8d66-d9ad-44ce-b8d3-42cc90502201">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f30a8d66-d9ad-44ce-b8d3-42cc90502201">
											<gml:posList>35.671227487031686 139.73842054529948 36.276 35.671227487031686 139.73842054529948 35.948 35.671236424083666 139.73846050051233 35.948 35.671236424083666 139.73846050051233 36.276 35.671227487031686 139.73842054529948 36.276</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8d8b7b77-b4c3-4ead-9e5b-8d34b8c7051a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8d8b7b77-b4c3-4ead-9e5b-8d34b8c7051a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8d8b7b77-b4c3-4ead-9e5b-8d34b8c7051a">
											<gml:posList>35.67122855786208 139.73841825743196 36.276 35.671238290950896 139.73846180177577 36.276 35.671238290950896 139.73846180177577 33.165 35.67122855786208 139.73841825743196 33.165 35.67122855786208 139.73841825743196 36.276</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-79b72764-347c-486a-8d49-2512401bbe92">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-79b72764-347c-486a-8d49-2512401bbe92">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-79b72764-347c-486a-8d49-2512401bbe92">
											<gml:posList>35.67131576359136 139.73833558244206 26.069 35.67131576359136 139.73833558244206 15.2 35.671175005081324 139.73838114979944 15.2 35.671175005081324 139.73838114979944 33.583 35.671274040678185 139.73834908637255 33.583 35.67131576359136 139.73833558244206 26.069</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-173a1042-8d33-4f6d-8e31-4a54ca65562e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-173a1042-8d33-4f6d-8e31-4a54ca65562e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-173a1042-8d33-4f6d-8e31-4a54ca65562e">
											<gml:posList>35.67130239765983 139.73849748307026 33.583 35.67130239765983 139.73849748307026 33.165 35.67122147474091 139.7385233499841 33.165 35.67122147474091 139.7385233499841 33.583 35.67130239765983 139.73849748307026 33.583</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-25aef6ba-fba6-43c4-92fe-19b42305927f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-25aef6ba-fba6-43c4-92fe-19b42305927f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-25aef6ba-fba6-43c4-92fe-19b42305927f">
											<gml:posList>35.671306536819465 139.738499842101 33.583 35.67121919802682 139.7385281247103 33.583 35.67121919802682 139.7385281247103 15.2 35.67134824171328 139.73848632721834 15.2 35.67134824171328 139.73848632721834 26.069 35.671306536819465 139.738499842101 33.583</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7201d83c-ea58-46fd-ad1b-7e692c586041">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7201d83c-ea58-46fd-ad1b-7e692c586041">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7201d83c-ea58-46fd-ad1b-7e692c586041">
											<gml:posList>35.67127177299348 139.73835387214254 33.583 35.67127177299348 139.73835387214254 33.165 35.67130239765983 139.73849748307026 33.165 35.67130239765983 139.73849748307026 33.583 35.67127177299348 139.73835387214254 33.583</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7f5a7fa7-7748-4d54-926e-337bc461e2d6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7f5a7fa7-7748-4d54-926e-337bc461e2d6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7f5a7fa7-7748-4d54-926e-337bc461e2d6">
											<gml:posList>35.67134824171328 139.73848632721834 15.2 35.67131576359136 139.73833558244206 15.2 35.67131576359136 139.73833558244206 26.069 35.67134824171328 139.73848632721834 26.069 35.67134824171328 139.73848632721834 15.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-2942</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">215.7367</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">211</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1320</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>4</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.03</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>