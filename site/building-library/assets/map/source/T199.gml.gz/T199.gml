<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_3527661b-cd63-44a5-b12a-2a8cfb4430bc">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">401</bldg:usage>
			<bldg:measuredHeight uom="m">23.1</bldg:measuredHeight>
			<bldg:storeysAboveGround>5</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.6709701410294 139.7407189085617 0 35.670889406168854 139.7406383636155 0 35.670860145408575 139.74068236182092 0 35.670876653098105 139.74069869131 0 35.67085171389063 139.74073616716433 0 35.67091603115015 139.7408003825426 0 35.6709701410294 139.7407189085617 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6709701410294 139.7407189085617 9.817 35.67091603115015 139.7408003825426 9.817 35.67085171389063 139.74073616716433 9.817 35.670876653098105 139.74069869131 9.817 35.670860145408575 139.74068236182092 9.817 35.670889406168854 139.7406383636155 9.817 35.6709701410294 139.7407189085617 9.817</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6709701410294 139.7407189085617 9.817 35.670889406168854 139.7406383636155 9.817 35.670889406168854 139.7406383636155 32.93 35.6709701410294 139.7407189085617 32.93 35.6709701410294 139.7407189085617 9.817</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670889406168854 139.7406383636155 9.817 35.670860145408575 139.74068236182092 9.817 35.670860145408575 139.74068236182092 32.93 35.670889406168854 139.7406383636155 32.93 35.670889406168854 139.7406383636155 9.817</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670860145408575 139.74068236182092 9.817 35.670876653098105 139.74069869131 9.817 35.670876653098105 139.74069869131 32.93 35.670860145408575 139.74068236182092 32.93 35.670860145408575 139.74068236182092 9.817</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670876653098105 139.74069869131 9.817 35.67085171389063 139.74073616716433 9.817 35.67085171389063 139.74073616716433 32.93 35.670876653098105 139.74069869131 32.93 35.670876653098105 139.74069869131 9.817</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67085171389063 139.74073616716433 9.817 35.67091603115015 139.7408003825426 9.817 35.67091603115015 139.7408003825426 32.93 35.67085171389063 139.74073616716433 32.93 35.67085171389063 139.74073616716433 9.817</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67091603115015 139.7408003825426 9.817 35.6709701410294 139.7407189085617 9.817 35.6709701410294 139.7407189085617 32.93 35.67091603115015 139.7408003825426 32.93 35.67091603115015 139.7408003825426 9.817</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6709701410294 139.7407189085617 32.93 35.670889406168854 139.7406383636155 32.93 35.670860145408575 139.74068236182092 32.93 35.670876653098105 139.74069869131 32.93 35.67085171389063 139.74073616716433 32.93 35.67091603115015 139.7408003825426 32.93 35.6709701410294 139.7407189085617 32.93</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-d411885a-c7b9-4c74-a725-837f8c2741df"/>
							<gml:surfaceMember xlink:href="#poly-0b677857-e85a-4786-80ca-c0386d3845eb"/>
							<gml:surfaceMember xlink:href="#poly-4f08f1bb-222b-4c9a-8e1b-c52330c5a107"/>
							<gml:surfaceMember xlink:href="#poly-13a20c1d-706b-4c3a-9dce-584c1554aedd"/>
							<gml:surfaceMember xlink:href="#poly-46b779b6-afec-4d0d-8328-06b6c42170e7"/>
							<gml:surfaceMember xlink:href="#poly-26ee5e1b-ae58-4800-9f07-bee48d4414e6"/>
							<gml:surfaceMember xlink:href="#poly-392ab041-59df-419b-90dd-796136d0f910"/>
							<gml:surfaceMember xlink:href="#poly-16ef2c25-8e46-472e-8ac7-446607490d5c"/>
							<gml:surfaceMember xlink:href="#poly-228b4046-a8bb-452b-8974-08e901f7bfd1"/>
							<gml:surfaceMember xlink:href="#poly-dcd6c163-c5d7-4324-a0e9-3c54fcc0dd7f"/>
							<gml:surfaceMember xlink:href="#poly-c89e9b79-83ba-4dd8-bbd9-956b1b0a7be9"/>
							<gml:surfaceMember xlink:href="#poly-68f5ed1a-8138-4a5a-8367-c13200bd0d7e"/>
							<gml:surfaceMember xlink:href="#poly-b29c54be-befb-4d04-8faf-5517e3dc3477"/>
							<gml:surfaceMember xlink:href="#poly-c9174a7c-d3a6-4be1-b7b3-2b46b4bb40c6"/>
							<gml:surfaceMember xlink:href="#poly-ada4573f-60ae-44fa-8b20-96b01e46e4ee"/>
							<gml:surfaceMember xlink:href="#poly-0c1b7ab9-52f8-4444-bf38-c45eb3e5b12c"/>
							<gml:surfaceMember xlink:href="#poly-e20af7df-2e38-410f-b2b7-82d8082d1e6f"/>
							<gml:surfaceMember xlink:href="#poly-826c0b0c-1c8b-46e2-ab8b-d32e6b337334"/>
							<gml:surfaceMember xlink:href="#poly-e8939354-5830-423c-9a5b-53533b08e0b6"/>
							<gml:surfaceMember xlink:href="#poly-7e78e96c-2c25-4b6e-854c-9f678331c520"/>
							<gml:surfaceMember xlink:href="#poly-e59eef1c-227f-4cab-895e-fc209bce361c"/>
							<gml:surfaceMember xlink:href="#poly-80da85a6-c894-4c35-a5ee-f8c97de2bb10"/>
							<gml:surfaceMember xlink:href="#poly-96e05977-36a6-4a32-afb1-b448185609ba"/>
							<gml:surfaceMember xlink:href="#poly-a0ea73e8-430f-4050-b3ba-bcfd4f0409b0"/>
							<gml:surfaceMember xlink:href="#poly-55ca4f0b-017e-43f4-bc42-9b981c57dd12"/>
							<gml:surfaceMember xlink:href="#poly-a24e9d26-baf1-432e-87b0-b1b031da8714"/>
							<gml:surfaceMember xlink:href="#poly-0cae6c6f-fd43-4956-9c87-83ab64ca3c34"/>
							<gml:surfaceMember xlink:href="#poly-0963f503-6ec1-4412-b673-2d94b44405bb"/>
							<gml:surfaceMember xlink:href="#poly-7122a7c4-011f-4d8d-a6e1-e782f9d1e88c"/>
							<gml:surfaceMember xlink:href="#poly-9f4924dc-19ef-4826-b6f5-20df4d05357a"/>
							<gml:surfaceMember xlink:href="#poly-f7051242-61ce-4dd0-ab77-7999a579994d"/>
							<gml:surfaceMember xlink:href="#poly-00a1f1b9-880f-454e-8be1-78f79e0289df"/>
							<gml:surfaceMember xlink:href="#poly-78536387-03d6-4e5e-b338-735656223b29"/>
							<gml:surfaceMember xlink:href="#poly-1e185ac6-2395-4faa-807c-5884a4169bda"/>
							<gml:surfaceMember xlink:href="#poly-3d790a26-8778-4355-95a9-ad31380c3b23"/>
							<gml:surfaceMember xlink:href="#poly-c4c9607e-63d5-45c0-a91b-6ea38793b484"/>
							<gml:surfaceMember xlink:href="#poly-09d2c35f-aa1b-4ccc-beb4-01f7cd35c94f"/>
							<gml:surfaceMember xlink:href="#poly-6472aaea-60df-479d-ba09-6c63fa3694db"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_3527661b-cd63-44a5-b12a-2a8cfb4430bc_BuildingInstallation_1041">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f8039627-d237-46e0-a54e-c883a126f2d5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67088555133824 139.7406891701397 33.764 35.67087295850138 139.74067660292397 33.764 35.67088246600036 139.74066230903352 33.764 35.67089505884719 139.7406748872948 33.764 35.67088555133824 139.7406891701397 33.764</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6c494647-5bc3-465f-92b9-9557825ce1fc">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6c494647-5bc3-465f-92b9-9557825ce1fc_0">
											<gml:posList>35.67088246600036 139.74066230903352 33.764 35.67088246600036 139.74066230903352 36.349 35.67089505884719 139.7406748872948 36.349 35.67089505884719 139.7406748872948 33.764 35.67088246600036 139.74066230903352 33.764</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a9b717bd-f158-4419-96df-7979e84741e9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a9b717bd-f158-4419-96df-7979e84741e9_0">
											<gml:posList>35.67087295850138 139.74067660292397 33.764 35.67087295850138 139.74067660292397 36.349 35.67088246600036 139.74066230903352 36.349 35.67088246600036 139.74066230903352 33.764 35.67087295850138 139.74067660292397 33.764</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ba80eacb-9b18-422a-a6bd-f549c50d572b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ba80eacb-9b18-422a-a6bd-f549c50d572b_0">
											<gml:posList>35.67088246600036 139.74066230903352 36.349 35.67087295850138 139.74067660292397 36.349 35.67088555133824 139.7406891701397 36.349 35.67089505884719 139.7406748872948 36.349 35.67088246600036 139.74066230903352 36.349</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8f9b5316-1848-4fba-a1a1-53a0848e9b32">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8f9b5316-1848-4fba-a1a1-53a0848e9b32_0">
											<gml:posList>35.67089505884719 139.7406748872948 33.764 35.67089505884719 139.7406748872948 36.349 35.67088555133824 139.7406891701397 36.349 35.67088555133824 139.7406891701397 33.764 35.67089505884719 139.7406748872948 33.764</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ade05f7d-73a3-43c5-b734-3e5c7f000d8b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ade05f7d-73a3-43c5-b734-3e5c7f000d8b_0">
											<gml:posList>35.67088555133824 139.7406891701397 33.764 35.67088555133824 139.7406891701397 36.349 35.67087295850138 139.74067660292397 36.349 35.67087295850138 139.74067660292397 33.764 35.67088555133824 139.7406891701397 33.764</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_3527661b-cd63-44a5-b12a-2a8cfb4430bc_BuildingInstallation_1060">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e09c6878-0672-4916-ace2-a7faa2fe0089">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67090205534729 139.7407007165781 33.764 35.67089040506739 139.74071824951744 33.764 35.670882142142545 139.7407099964085 33.764 35.67089379242126 139.7406924634698 33.764 35.67090205534729 139.7407007165781 33.764</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cb304393-2c22-4d64-a7c7-4d6ae20b7798">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cb304393-2c22-4d64-a7c7-4d6ae20b7798_0">
											<gml:posList>35.67089379242126 139.7406924634698 33.764 35.67089379242126 139.7406924634698 34.074 35.67090205534729 139.7407007165781 34.074 35.67090205534729 139.7407007165781 33.764 35.67089379242126 139.7406924634698 33.764</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-73e04ba2-f4e8-4bbb-996b-a8fe23125855">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-73e04ba2-f4e8-4bbb-996b-a8fe23125855_0">
											<gml:posList>35.670882142142545 139.7407099964085 34.074 35.67089379242126 139.7406924634698 34.074 35.67089379242126 139.7406924634698 33.764 35.670882142142545 139.7407099964085 33.764 35.670882142142545 139.7407099964085 34.074</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4f975e3d-ebb2-42cd-b146-9fbbcf1e83d4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4f975e3d-ebb2-42cd-b146-9fbbcf1e83d4_0">
											<gml:posList>35.67090205534729 139.7407007165781 34.074 35.67089379242126 139.7406924634698 34.074 35.670882142142545 139.7407099964085 34.074 35.67089040506739 139.74071824951744 34.074 35.67090205534729 139.7407007165781 34.074</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0d286fdc-0594-4d85-a83f-88e319b7d0b8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0d286fdc-0594-4d85-a83f-88e319b7d0b8_0">
											<gml:posList>35.67090205534729 139.7407007165781 34.074 35.67089040506739 139.74071824951744 34.074 35.67089040506739 139.74071824951744 33.764 35.67090205534729 139.7407007165781 33.764 35.67090205534729 139.7407007165781 34.074</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fbe7c793-6594-4644-841d-24c52dd63705">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fbe7c793-6594-4644-841d-24c52dd63705_0">
											<gml:posList>35.670882142142545 139.7407099964085 34.074 35.670882142142545 139.7407099964085 33.764 35.67089040506739 139.74071824951744 33.764 35.67089040506739 139.74071824951744 34.074 35.670882142142545 139.7407099964085 34.074</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_3527661b-cd63-44a5-b12a-2a8cfb4430bc_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-998b167d-8ea8-4f75-85f7-50b109c53985">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670877497695045 139.74075378941814 38.1 35.670869478338474 139.74074579009113 38.1 35.67088218201305 139.74072667631867 38.1 35.670890201379386 139.74073468669135 38.1 35.670877497695045 139.74075378941814 38.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a0730f27-2e94-4e13-8985-b0c3c24bd1ce">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a0730f27-2e94-4e13-8985-b0c3c24bd1ce_0">
											<gml:posList>35.67088218201305 139.74072667631867 38.1 35.67088218201305 139.74072667631867 40.761 35.670890201379386 139.74073468669135 40.761 35.670890201379386 139.74073468669135 38.1 35.67088218201305 139.74072667631867 38.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ec8445d3-c1f4-48bf-99f7-dd563eb352a3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ec8445d3-c1f4-48bf-99f7-dd563eb352a3_0">
											<gml:posList>35.670869478338474 139.74074579009113 38.1 35.670869478338474 139.74074579009113 40.761 35.67088218201305 139.74072667631867 40.761 35.67088218201305 139.74072667631867 38.1 35.670869478338474 139.74074579009113 38.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fbf9150e-1e99-45d2-b9fc-6e87c9f6709d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fbf9150e-1e99-45d2-b9fc-6e87c9f6709d_0">
											<gml:posList>35.67088218201305 139.74072667631867 40.761 35.670869478338474 139.74074579009113 40.761 35.670877497695045 139.74075378941814 40.761 35.670890201379386 139.74073468669135 40.761 35.67088218201305 139.74072667631867 40.761</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-61afd4f4-46c3-427f-aaed-c51b319c99ef">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-61afd4f4-46c3-427f-aaed-c51b319c99ef_0">
											<gml:posList>35.670890201379386 139.74073468669135 38.1 35.670890201379386 139.74073468669135 40.761 35.670877497695045 139.74075378941814 40.761 35.670877497695045 139.74075378941814 38.1 35.670890201379386 139.74073468669135 38.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-72917883-292b-4bca-882a-4f43efd247d8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-72917883-292b-4bca-882a-4f43efd247d8_0">
											<gml:posList>35.670877497695045 139.74075378941814 38.1 35.670877497695045 139.74075378941814 40.761 35.670869478338474 139.74074579009113 40.761 35.670869478338474 139.74074579009113 38.1 35.670877497695045 139.74075378941814 38.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-d411885a-c7b9-4c74-a725-837f8c2741df">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d411885a-c7b9-4c74-a725-837f8c2741df">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d411885a-c7b9-4c74-a725-837f8c2741df">
											<gml:posList>35.670970141029386 139.7407189085617 9.817 35.67091603115015 139.7408003825426 9.817 35.67085171389063 139.74073616716433 9.817 35.67087665309809 139.74069869131 9.817 35.67086014540856 139.74068236182092 9.817 35.67088940616883 139.7406383636155 9.817 35.670970141029386 139.7407189085617 9.817</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-0b677857-e85a-4786-80ca-c0386d3845eb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0b677857-e85a-4786-80ca-c0386d3845eb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0b677857-e85a-4786-80ca-c0386d3845eb">
											<gml:posList>35.67088940616883 139.7406383636155 34.366 35.67088968822178 139.74064177660526 34.366 35.67092815229198 139.7406801402435 34.366 35.670930937268565 139.74067979458874 34.366 35.67088940616883 139.7406383636155 34.366</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-4f08f1bb-222b-4c9a-8e1b-c52330c5a107">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4f08f1bb-222b-4c9a-8e1b-c52330c5a107">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4f08f1bb-222b-4c9a-8e1b-c52330c5a107">
											<gml:posList>35.67086014540856 139.74068236182092 34.366 35.67086294840412 139.7406820050994 34.366 35.67088968822178 139.74064177660526 34.366 35.67088940616883 139.7406383636155 34.366 35.67086014540856 139.74068236182092 34.366</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-13a20c1d-706b-4c3a-9dce-584c1554aedd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-13a20c1d-706b-4c3a-9dce-584c1554aedd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-13a20c1d-706b-4c3a-9dce-584c1554aedd">
											<gml:posList>35.67087665309809 139.74069869131 34.366 35.67087943806625 139.74069833460976 34.366 35.67086294840412 139.7406820050994 34.366 35.67086014540856 139.74068236182092 34.366 35.67087665309809 139.74069869131 34.366</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-46b779b6-afec-4d0d-8328-06b6c42170e7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-46b779b6-afec-4d0d-8328-06b6c42170e7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-46b779b6-afec-4d0d-8328-06b6c42170e7">
											<gml:posList>35.67092815229198 139.7406801402435 33.764 35.67088968822178 139.74064177660526 33.764 35.67086294840412 139.7406820050994 33.764 35.67087943806625 139.74069833460976 33.764 35.67085449885891 139.7407358104655 33.764 35.670857917684366 139.7407392198315 33.764 35.67087926454747 139.74070711664118 33.764 35.670897874180945 139.74072571925544 33.764 35.67092815229198 139.7406801402435 33.764</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-26ee5e1b-ae58-4800-9f07-bee48d4414e6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-26ee5e1b-ae58-4800-9f07-bee48d4414e6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-26ee5e1b-ae58-4800-9f07-bee48d4414e6">
											<gml:posList>35.670930937268565 139.74067979458874 34.366 35.67092815229198 139.7406801402435 34.366 35.670897874180945 139.74072571925544 34.366 35.67089816525362 139.7407291432818 34.366 35.670930937268565 139.74067979458874 34.366</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-392ab041-59df-419b-90dd-796136d0f910">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-392ab041-59df-419b-90dd-796136d0f910">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-392ab041-59df-419b-90dd-796136d0f910">
											<gml:posList>35.67087665309809 139.74069869131 34.366 35.67085171389063 139.74073616716433 34.366 35.67085449885891 139.7407358104655 34.366 35.67087943806625 139.74069833460976 34.366 35.67087665309809 139.74069869131 34.366</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-16ef2c25-8e46-472e-8ac7-446607490d5c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-16ef2c25-8e46-472e-8ac7-446607490d5c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-16ef2c25-8e46-472e-8ac7-446607490d5c">
											<gml:posList>35.67087953759324 139.7407105406875 34.366 35.67089816525362 139.7407291432818 34.366 35.670897874180945 139.74072571925544 34.366 35.67087926454747 139.74070711664118 34.366 35.67087953759324 139.7407105406875 34.366</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-228b4046-a8bb-452b-8974-08e901f7bfd1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-228b4046-a8bb-452b-8974-08e901f7bfd1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-228b4046-a8bb-452b-8974-08e901f7bfd1">
											<gml:posList>35.67087953759324 139.7407105406875 38.224 35.67087988329247 139.7407146716149 38.224 35.670900594727506 139.7407353595602 38.224 35.67090397455046 139.7407349358961 38.224 35.67087953759324 139.7407105406875 38.224</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-dcd6c163-c5d7-4324-a0e9-3c54fcc0dd7f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-dcd6c163-c5d7-4324-a0e9-3c54fcc0dd7f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-dcd6c163-c5d7-4324-a0e9-3c54fcc0dd7f">
											<gml:posList>35.670970141029386 139.7407189085617 26.772 35.670930937268565 139.74067979458874 34.366 35.67089816525362 139.7407291432818 34.366 35.67093736899015 139.74076824621662 26.772 35.670970141029386 139.7407189085617 26.772</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c89e9b79-83ba-4dd8-bbd9-956b1b0a7be9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c89e9b79-83ba-4dd8-bbd9-956b1b0a7be9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c89e9b79-83ba-4dd8-bbd9-956b1b0a7be9">
											<gml:posList>35.67087953759324 139.7407105406875 34.366 35.67087926454747 139.74070711664118 34.366 35.670857917684366 139.7407392198315 34.366 35.67085819974294 139.7407426438666 34.366 35.67087953759324 139.7407105406875 34.366</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-68f5ed1a-8138-4a5a-8367-c13200bd0d7e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-68f5ed1a-8138-4a5a-8367-c13200bd0d7e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-68f5ed1a-8138-4a5a-8367-c13200bd0d7e">
											<gml:posList>35.67085819974294 139.7407426438666 38.224 35.670861570543714 139.7407422091672 38.224 35.67087988329247 139.7407146716149 38.224 35.67087953759324 139.7407105406875 38.224 35.67085819974294 139.7407426438666 38.224</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b29c54be-befb-4d04-8faf-5517e3dc3477">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b29c54be-befb-4d04-8faf-5517e3dc3477">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b29c54be-befb-4d04-8faf-5517e3dc3477">
											<gml:posList>35.670900594727506 139.7407353595602 38.1 35.67087988329247 139.7407146716149 38.1 35.670861570543714 139.7407422091672 38.1 35.67088228197409 139.74076289711485 38.1 35.670900594727506 139.7407353595602 38.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c9174a7c-d3a6-4be1-b7b3-2b46b4bb40c6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c9174a7c-d3a6-4be1-b7b3-2b46b4bb40c6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c9174a7c-d3a6-4be1-b7b3-2b46b4bb40c6">
											<gml:posList>35.67085819974294 139.7407426438666 34.366 35.670857917684366 139.7407392198315 34.366 35.67085449885891 139.7407358104655 34.366 35.67085171389063 139.74073616716433 34.366 35.67085819974294 139.7407426438666 34.366</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ada4573f-60ae-44fa-8b20-96b01e46e4ee">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ada4573f-60ae-44fa-8b20-96b01e46e4ee">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ada4573f-60ae-44fa-8b20-96b01e46e4ee">
											<gml:posList>35.67090397455046 139.7407349358961 38.224 35.670900594727506 139.7407353595602 38.224 35.67088228197409 139.74076289711485 38.224 35.67088263669375 139.74076703907858 38.224 35.67090397455046 139.7407349358961 38.224</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-0c1b7ab9-52f8-4444-bf38-c45eb3e5b12c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0c1b7ab9-52f8-4444-bf38-c45eb3e5b12c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0c1b7ab9-52f8-4444-bf38-c45eb3e5b12c">
											<gml:posList>35.67088263669375 139.74076703907858 38.224 35.67088228197409 139.74076289711485 38.224 35.670861570543714 139.7407422091672 38.224 35.67085819974294 139.7407426438666 38.224 35.67088263669375 139.74076703907858 38.224</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e20af7df-2e38-410f-b2b7-82d8082d1e6f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e20af7df-2e38-410f-b2b7-82d8082d1e6f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e20af7df-2e38-410f-b2b7-82d8082d1e6f">
											<gml:posList>35.67091603115015 139.7408003825426 26.772 35.67093736899015 139.74076824621662 26.772 35.67090397455046 139.7407349358961 34.366 35.67088263669375 139.74076703907858 34.366 35.67091603115015 139.7408003825426 26.772</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-826c0b0c-1c8b-46e2-ab8b-d32e6b337334">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-826c0b0c-1c8b-46e2-ab8b-d32e6b337334">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-826c0b0c-1c8b-46e2-ab8b-d32e6b337334">
											<gml:posList>35.670897874180945 139.74072571925544 34.366 35.670897874180945 139.74072571925544 33.764 35.67087926454747 139.74070711664118 33.764 35.67087926454747 139.74070711664118 34.366 35.670897874180945 139.74072571925544 34.366</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e8939354-5830-423c-9a5b-53533b08e0b6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e8939354-5830-423c-9a5b-53533b08e0b6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e8939354-5830-423c-9a5b-53533b08e0b6">
											<gml:posList>35.67087926454747 139.74070711664118 34.366 35.67087926454747 139.74070711664118 33.764 35.670857917684366 139.7407392198315 33.764 35.670857917684366 139.7407392198315 34.366 35.67087926454747 139.74070711664118 34.366</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7e78e96c-2c25-4b6e-854c-9f678331c520">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7e78e96c-2c25-4b6e-854c-9f678331c520">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7e78e96c-2c25-4b6e-854c-9f678331c520">
											<gml:posList>35.67087988329247 139.7407146716149 38.224 35.67087988329247 139.7407146716149 38.1 35.670900594727506 139.7407353595602 38.1 35.670900594727506 139.7407353595602 38.224 35.67087988329247 139.7407146716149 38.224</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e59eef1c-227f-4cab-895e-fc209bce361c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e59eef1c-227f-4cab-895e-fc209bce361c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e59eef1c-227f-4cab-895e-fc209bce361c">
											<gml:posList>35.670861570543714 139.7407422091672 38.224 35.670861570543714 139.7407422091672 38.1 35.67087988329247 139.7407146716149 38.1 35.67087988329247 139.7407146716149 38.224 35.670861570543714 139.7407422091672 38.224</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-80da85a6-c894-4c35-a5ee-f8c97de2bb10">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-80da85a6-c894-4c35-a5ee-f8c97de2bb10">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-80da85a6-c894-4c35-a5ee-f8c97de2bb10">
											<gml:posList>35.670900594727506 139.7407353595602 38.224 35.670900594727506 139.7407353595602 38.1 35.67088228197409 139.74076289711485 38.1 35.67088228197409 139.74076289711485 38.224 35.670900594727506 139.7407353595602 38.224</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-96e05977-36a6-4a32-afb1-b448185609ba">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-96e05977-36a6-4a32-afb1-b448185609ba">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-96e05977-36a6-4a32-afb1-b448185609ba">
											<gml:posList>35.67088228197409 139.74076289711485 38.224 35.67088228197409 139.74076289711485 38.1 35.670861570543714 139.7407422091672 38.1 35.670861570543714 139.7407422091672 38.224 35.67088228197409 139.74076289711485 38.224</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a0ea73e8-430f-4050-b3ba-bcfd4f0409b0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a0ea73e8-430f-4050-b3ba-bcfd4f0409b0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a0ea73e8-430f-4050-b3ba-bcfd4f0409b0">
											<gml:posList>35.67087665309809 139.74069869131 9.817 35.67085171389063 139.74073616716433 9.817 35.67085171389063 139.74073616716433 34.366 35.67087665309809 139.74069869131 34.366 35.67087665309809 139.74069869131 9.817</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-55ca4f0b-017e-43f4-bc42-9b981c57dd12">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-55ca4f0b-017e-43f4-bc42-9b981c57dd12">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-55ca4f0b-017e-43f4-bc42-9b981c57dd12">
											<gml:posList>35.67085449885891 139.7407358104655 34.366 35.67085449885891 139.7407358104655 33.764 35.67087943806625 139.74069833460976 33.764 35.67087943806625 139.74069833460976 34.366 35.67085449885891 139.7407358104655 34.366</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a24e9d26-baf1-432e-87b0-b1b031da8714">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a24e9d26-baf1-432e-87b0-b1b031da8714">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a24e9d26-baf1-432e-87b0-b1b031da8714">
											<gml:posList>35.67086014540856 139.74068236182092 9.817 35.67087665309809 139.74069869131 9.817 35.67087665309809 139.74069869131 34.366 35.67086014540856 139.74068236182092 34.366 35.67086014540856 139.74068236182092 9.817</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0cae6c6f-fd43-4956-9c87-83ab64ca3c34">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0cae6c6f-fd43-4956-9c87-83ab64ca3c34">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0cae6c6f-fd43-4956-9c87-83ab64ca3c34">
											<gml:posList>35.67085819974294 139.7407426438666 38.224 35.67087953759324 139.7407105406875 38.224 35.67087953759324 139.7407105406875 34.366 35.67085819974294 139.7407426438666 34.366 35.67085819974294 139.7407426438666 38.224</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0963f503-6ec1-4412-b673-2d94b44405bb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0963f503-6ec1-4412-b673-2d94b44405bb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0963f503-6ec1-4412-b673-2d94b44405bb">
											<gml:posList>35.67087943806625 139.74069833460976 34.366 35.67087943806625 139.74069833460976 33.764 35.67086294840412 139.7406820050994 33.764 35.67086294840412 139.7406820050994 34.366 35.67087943806625 139.74069833460976 34.366</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7122a7c4-011f-4d8d-a6e1-e782f9d1e88c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7122a7c4-011f-4d8d-a6e1-e782f9d1e88c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7122a7c4-011f-4d8d-a6e1-e782f9d1e88c">
											<gml:posList>35.67088940616883 139.7406383636155 9.817 35.67086014540856 139.74068236182092 9.817 35.67086014540856 139.74068236182092 34.366 35.67088940616883 139.7406383636155 34.366 35.67088940616883 139.7406383636155 9.817</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9f4924dc-19ef-4826-b6f5-20df4d05357a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9f4924dc-19ef-4826-b6f5-20df4d05357a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9f4924dc-19ef-4826-b6f5-20df4d05357a">
											<gml:posList>35.67086294840412 139.7406820050994 34.366 35.67086294840412 139.7406820050994 33.764 35.67088968822178 139.74064177660526 33.764 35.67088968822178 139.74064177660526 34.366 35.67086294840412 139.7406820050994 34.366</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f7051242-61ce-4dd0-ab77-7999a579994d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f7051242-61ce-4dd0-ab77-7999a579994d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f7051242-61ce-4dd0-ab77-7999a579994d">
											<gml:posList>35.67088968822178 139.74064177660526 34.366 35.67088968822178 139.74064177660526 33.764 35.67092815229198 139.7406801402435 33.764 35.67092815229198 139.7406801402435 34.366 35.67088968822178 139.74064177660526 34.366</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-00a1f1b9-880f-454e-8be1-78f79e0289df">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-00a1f1b9-880f-454e-8be1-78f79e0289df">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-00a1f1b9-880f-454e-8be1-78f79e0289df">
											<gml:posList>35.67092815229198 139.7406801402435 34.366 35.67092815229198 139.7406801402435 33.764 35.670897874180945 139.74072571925544 33.764 35.670897874180945 139.74072571925544 34.366 35.67092815229198 139.7406801402435 34.366</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-78536387-03d6-4e5e-b338-735656223b29">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-78536387-03d6-4e5e-b338-735656223b29">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-78536387-03d6-4e5e-b338-735656223b29">
											<gml:posList>35.67088940616883 139.7406383636155 34.366 35.670930937268565 139.74067979458874 34.366 35.670970141029386 139.7407189085617 26.772 35.670970141029386 139.7407189085617 9.817 35.67088940616883 139.7406383636155 9.817 35.67088940616883 139.7406383636155 34.366</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1e185ac6-2395-4faa-807c-5884a4169bda">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1e185ac6-2395-4faa-807c-5884a4169bda">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1e185ac6-2395-4faa-807c-5884a4169bda">
											<gml:posList>35.670857917684366 139.7407392198315 34.366 35.670857917684366 139.7407392198315 33.764 35.67085449885891 139.7407358104655 33.764 35.67085449885891 139.7407358104655 34.366 35.670857917684366 139.7407392198315 34.366</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3d790a26-8778-4355-95a9-ad31380c3b23">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3d790a26-8778-4355-95a9-ad31380c3b23">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3d790a26-8778-4355-95a9-ad31380c3b23">
											<gml:posList>35.67085171389063 139.74073616716433 9.817 35.67091603115015 139.7408003825426 9.817 35.67091603115015 139.7408003825426 26.772 35.67088263669375 139.74076703907858 34.366 35.67088263669375 139.74076703907858 38.224 35.67085819974294 139.7407426438666 38.224 35.67085819974294 139.7407426438666 34.366 35.67085171389063 139.74073616716433 34.366 35.67085171389063 139.74073616716433 9.817</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c4c9607e-63d5-45c0-a91b-6ea38793b484">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c4c9607e-63d5-45c0-a91b-6ea38793b484">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c4c9607e-63d5-45c0-a91b-6ea38793b484">
											<gml:posList>35.67090397455046 139.7407349358961 38.224 35.67088263669375 139.74076703907858 38.224 35.67088263669375 139.74076703907858 34.366 35.67090397455046 139.7407349358961 34.366 35.67090397455046 139.7407349358961 38.224</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-09d2c35f-aa1b-4ccc-beb4-01f7cd35c94f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-09d2c35f-aa1b-4ccc-beb4-01f7cd35c94f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-09d2c35f-aa1b-4ccc-beb4-01f7cd35c94f">
											<gml:posList>35.67090397455046 139.7407349358961 34.366 35.67093736899015 139.74076824621662 26.772 35.67089816525362 139.7407291432818 34.366 35.67087953759324 139.7407105406875 34.366 35.67087953759324 139.7407105406875 38.224 35.67090397455046 139.7407349358961 38.224 35.67090397455046 139.7407349358961 34.366</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6472aaea-60df-479d-ba09-6c63fa3694db">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6472aaea-60df-479d-ba09-6c63fa3694db">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6472aaea-60df-479d-ba09-6c63fa3694db">
											<gml:posList>35.67091603115015 139.7408003825426 9.817 35.670970141029386 139.7407189085617 9.817 35.670970141029386 139.7407189085617 26.772 35.67093736899015 139.74076824621662 26.772 35.67091603115015 139.7408003825426 26.772 35.67091603115015 139.7408003825426 9.817</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-1489</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">99.5519</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1210</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>6</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.03</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>